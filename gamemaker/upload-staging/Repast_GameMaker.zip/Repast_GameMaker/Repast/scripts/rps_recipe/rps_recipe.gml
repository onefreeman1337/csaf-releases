/// REPAST - rps_recipe. The system: recipes, discovery, cooking, quality, spoilage and buffs.
///
/// This file is the half a buyer wires into their game. rps_plate draws; this decides WHAT is
/// drawn, and it is designed so that a game can use as little or as much of it as it wants:
/// rps_recipe_cook() alone is a complete cooking mechanic, and the discovery ledger and the
/// spoilage clock are optional layers on top of it that need no changes to the rest.
///
/// ⛔ EVERY GLOBAL AND MACRO IN THIS PACKAGE IS NAMESPACED `rps_` / `RPS_`. GML's global namespace
/// is flat and a collision inside a buyer's project is a support ticket that cannot be debugged
/// remotely. There is exactly one global in the whole package (`global.rps_lx` / `global.rps_ly`,
/// the lamp) plus the optional ledger created by rps_ledger_new(), and the ledger is handed back
/// to the caller to store wherever they like rather than kept here.
///
/// -- THE DESIGN DECISION WORTH READING --------------------------------------------------------
/// ⭐ A RECIPE DOES NOT STORE A PICTURE, AND IT DOES NOT STORE A RESULT. It stores a METHOD.
///
/// The tempting design is: recipe -> named output item -> icon. That works, and it is why most
/// cooking systems have three tiers of "soup" that are the same picture at three brightnesses.
/// Here a recipe names its components and its method, and the DISH is computed from the recipe
/// plus how well it was cooked. Two players who cook the same recipe at different skill get
/// different doneness, a different tier, a different number of garnishes and therefore genuinely
/// different plates - from one recipe definition and no extra art.
/// ============================================================================================

/// -- A RECIPE ----------------------------------------------------------------------------------

/// Build a recipe. The buyer's game calls this once per recipe, at startup or from a data file.
///
///   _id      a short stable string, used by the discovery ledger
///   _name    what the player sees
///   _base    a form name from rps_corpus_in_slot("base"), or "" for no bed
///   _hero    a form name - the thing the dish is named after
///   _sides   an array of form names, 0 to 3 of them
///   _cook    the method: a cook state name from rps_cook_names()
///   _diff    difficulty 0..1 - how much skill it takes to hit the window
function rps_recipe_new(_id, _name, _base, _hero, _sides, _cook, _diff) {
    return {
        id: _id,
        name: _name,
        base_form: _base,
        hero_form: _hero,
        side_forms: _sides,
        cook: _cook,
        difficulty: clamp(_diff, 0, 1),
        // The ideal doneness for this method. Not 1.0 - "fully browned" is not the target for
        // most food, and a system whose ideal is always the maximum has no skill in it.
        ideal: rps_recipe_ideal(_cook),
    };
}

/// Where the window sits for a method. A sear wants to be taken far; a poach wants barely any.
///
/// ⚠️ THESE ARE THE NUMBERS THAT MAKE COOKING FEEL LIKE COOKING. If every method peaked at the
/// same doneness the heat dial would be cosmetic. A player who learns that fish comes off early
/// and beef goes on longer has learned something the system actually models.
function rps_recipe_ideal(_cook) {
    switch (_cook) {
        case "raw":      return 0.00;
        case "blanched": return 0.30;
        case "steamed":  return 0.45;
        case "boiled":   return 0.55;
        case "poached":  return 0.38;
        case "seared":   return 0.72;
        case "roasted":  return 0.78;
        case "fried":    return 0.74;
        case "braised":  return 0.86;
        case "charred":  return 0.92;
        case "candied":  return 0.80;
        case "cured":    return 0.66;
    }
    return 0.60;
}

/// -- COOKING -----------------------------------------------------------------------------------

/// The quality tier for a given error against the window, at a given difficulty.
///
/// _err is |actual - ideal|. A harder recipe has a TIGHTER window, which is the whole meaning of
/// difficulty here - not a lower ceiling, a narrower target. A skilled player can masterwork a
/// hard recipe; an unskilled one cannot reliably plain it.
function rps_recipe_tier(_err, _difficulty) {
    var _w = lerp(0.20, 0.075, clamp(_difficulty, 0, 1));   // half-width of the perfect band
    if (_err <= _w)            return 4;   // masterwork
    if (_err <= _w * 2.0)      return 3;   // fine
    if (_err <= _w * 3.4)      return 2;   // good
    if (_err <= _w * 5.2)      return 1;   // plain
    return 0;                              // ruined
}

/// Cook a recipe and get back a DISH: everything rps_palette_build and rps_plate_compose need.
///
///   _recipe   from rps_recipe_new
///   _heat     0..1, what the player actually did
///   _skill    0..1, the cook's skill - it pulls the result toward the ideal and widens nothing
///   _seed     makes every seeded form in the dish deterministic
///
/// ⚠️ SKILL PULLS, IT DOES NOT ADD. A skill term added to the tier would let a high-skill cook
/// masterwork by accident with the dial at zero, which players notice immediately and correctly
/// call broken. Pulling the ACHIEVED doneness toward the ideal models what skill really is:
/// hitting what you aimed at.
/// ⛔ GUARD PASS 2026-09-08. The adversarial harness measured 36 of 52 hostile calls against the
/// DOCUMENTED entry points taking the room down. Refusal values are stated in the Readme.
function rps_recipe_cook(_recipe, _heat, _skill, _seed) {
    if (!is_struct(_recipe)) return undefined;
    if (!is_numeric(_heat) || !is_numeric(_skill) || !is_numeric(_seed)) return undefined;
    var _sk = clamp(_skill, 0, 1);
    var _raw = clamp(_heat, 0, 1);
    var _done = lerp(_raw, _recipe.ideal, _sk * 0.55);
    var _err = abs(_done - _recipe.ideal);
    var _tier = rps_recipe_tier(_err, _recipe.difficulty);

    // ⛔ A RUINED DISH IS OVERCOOKED, NOT "THE SAME DISH LABELLED BAD". It is forced up the
    // trajectory into char, so the picture itself tells the player what went wrong. This one line
    // is why the quality tier does not need a number printed next to it.
    var _shown = (_tier == 0 && _done > _recipe.ideal) ? clamp(_done + 0.22, 0, 1) : _done;
    var _cook = (_tier == 0 && _done > _recipe.ideal) ? "charred" : _recipe.cook;

    // Components take their substance from the corpus spec unless the recipe overrode it.
    var _hero_spec = rps_corpus_spec(_recipe.hero_form);
    var _base_spec = (_recipe.base_form == "")
        ? { mat: "grain", slot: "base", w: 0.8, stack: true }
        : rps_corpus_spec(_recipe.base_form);

    var _sides = _recipe.side_forms;
    var _side_mat = (array_length(_sides) > 0) ? rps_corpus_spec(_sides[0]).mat : "root";

    // ⭐ GARNISH IS EARNED, NOT DECLARED. The number of finishing touches is a function of the
    // tier, so a masterwork plate is visibly more finished than a plain one WITHOUT the recipe
    // author choosing garnishes per tier. This is the single feature that makes quality legible
    // at a glance, and it is four lines.
    var _garn = [];
    var _st = rps_rng(_seed + 101);
    var _pool = ["sprig", "seeds", "dusting", "leafwhole", "berries", "citrus"];
    var _count = max(0, _tier - 1);                       // 0,0,1,2,3
    for (var _i = 0; _i < _count; _i++) {
        array_push(_garn, _pool[(floor(rps_rng_next(_st) * array_length(_pool)) + _i)
                                % array_length(_pool)]);
    }
    // Anything hot and freshly cooked steams. A ruined dish does not - it smokes, and a smoking
    // dish reading as "appetisingly steamy" would be the wrong signal entirely.
    if (_tier >= 1 && _done > 0.35) array_push(_garn, "steam");

    return {
        recipe_id:  _recipe.id,
        name:       _recipe.name,
        tier:       _tier,
        doneness:   _done,
        error:      _err,
        seed:       _seed,

        // what rps_plate_compose reads
        base_form:  _recipe.base_form,
        hero_form:  _recipe.hero_form,
        side_forms: _sides,
        garn_forms: _garn,
        ware:       "earthen",
        deep:       0.0,
        ware_wear:  0.25,

        // what rps_palette_build reads
        hue_shift:  0,
        base_mat:   _base_spec.mat,  base_cook: _cook, base_done: _shown * 0.85,
        hero_mat:   _hero_spec.mat,  hero_cook: _cook, hero_done: _shown,
        side_mat:   _side_mat,       side_cook: _cook, side_done: _shown * 0.90,
        garn_mat:   "leaf",          garn_cook: "raw", garn_done: 0.0,

        // freshness, driven by rps_dish_age()
        freshness:  1.0,
    };
}

/// Put a dish on a different vessel. Returned as a NEW struct rather than mutated, because a
/// dish is a value in this design and a caller holding one should not have it change underneath.
/// ⛔ REFUSES AN UNKNOWN VESSEL NAME, not only a wrong type. This takes one of eight strings, so a
/// misspelling is the likeliest mistake with it and a type check sails straight past one.
function rps_dish_on(_dish, _ware, _deep, _wear) {
    if (!is_struct(_dish) || !is_string(_ware)) return undefined;
    if (!is_numeric(_deep) || !is_numeric(_wear)) return undefined;
    if (!rps_name_in(rps_ware_names(), _ware)) return undefined;
    var _d = variable_clone(_dish);
    _d.ware = _ware;
    _d.deep = clamp(_deep, 0, 1);
    _d.ware_wear = clamp(_wear, 0, 1);
    return _d;
}

/// -- SPOILAGE ----------------------------------------------------------------------------------

/// Age a dish by _hours. Returns a NEW dish.
///
/// ⛔ SPOILAGE IS VISIBLE OR IT IS NOT A MECHANIC. A freshness float that only shows up in a
/// tooltip is a number, not a system. Ageing here pushes the components' doneness UP (food dries
/// and darkens as it sits) and strips the garnish, which is exactly what a plate left out looks
/// like: the sprig wilts off it and the steam stops. The player can see a stale meal.
///
/// _keeps is how many hours this dish stays good - a stew keeps, a dressed salad does not.
function rps_dish_age(_dish, _hours, _keeps) {
    var _d = variable_clone(_dish);
    var _k = max(0.5, _keeps);
    _d.freshness = clamp(1 - (_hours / _k), 0, 1);

    var _stale = 1 - _d.freshness;
    // ⚠️ 0.34 / 0.28 / 0.30, RAISED FROM 0.20 / 0.16 / 0.18. At the lower values a dish at zero
    // freshness was barely darker than a fresh one, so the only visible signal was the garnish
    // coming off - and a mechanic whose whole claim is "spoilage is visible" has to move the food
    // as well as its decoration. Measured on the spoilage sheet.
    _d.hero_done = clamp(_d.hero_done + _stale * 0.34, 0, 1);
    _d.base_done = clamp(_d.base_done + _stale * 0.28, 0, 1);
    _d.side_done = clamp(_d.side_done + _stale * 0.30, 0, 1);
    // Herbs go first and they go furthest - a wilted garnish is the earliest visible sign.
    _d.garn_cook = "boiled";
    _d.garn_done = clamp(_stale * 0.85, 0, 1);

    // Steam stops as soon as it is not hot, and the finishing touches come off as it goes stale.
    var _keep = [];
    var _n = array_length(_d.garn_forms);
    var _allow = (_d.freshness > 0.75) ? _n : ((_d.freshness > 0.40) ? 1 : 0);
    for (var _i = 0; _i < _n; _i++) {
        if (_d.garn_forms[_i] == "steam" && _d.freshness < 0.92) continue;
        if (array_length(_keep) >= _allow) break;
        array_push(_keep, _d.garn_forms[_i]);
    }
    _d.garn_forms = _keep;
    return _d;
}

/// -- BUFFS -------------------------------------------------------------------------------------

/// What eating this dish does. Returns { nourish, vigour, warmth, duration, potency }.
///
/// ⚠️ THE BUFF IS DERIVED FROM WHAT IS ACTUALLY ON THE PLATE, not stored on the recipe. That is
/// the difference between a cooking system and a crafting menu: adding a root vegetable to a
/// recipe changes what the meal does, without anyone editing a buff table.
///
/// ⛔ AND THE TIER SCALES DURATION, NOT MAGNITUDE. A masterwork meal that hits twice as hard is a
/// balance problem in every game that uses it; a masterwork meal that lasts twice as long is a
/// reward the designer can price. This is the one place this package takes a design position on
/// behalf of the buyer, and it is stated here so it can be argued with and changed in one line.
function rps_dish_buff(_dish) {
    if (!is_struct(_dish)) return undefined;
    var _nourish = 0, _vigour = 0, _warmth = 0;

    var _mats = [_dish.hero_mat, _dish.base_mat, _dish.side_mat];
    var _wts  = [1.0, 0.7, 0.5];
    for (var _i = 0; _i < 3; _i++) {
        var _b = rps_material_nutrition(_mats[_i]);
        _nourish += _b[0] * _wts[_i];
        _vigour  += _b[1] * _wts[_i];
        _warmth  += _b[2] * _wts[_i];
    }

    // A hot method warms; a raw one does not.
    var _hot = rps_recipe_ideal(_dish.hero_cook);
    _warmth += _hot * 0.6;

    // Ruined food nourishes almost nothing and a stale dish is worse than a fresh one.
    var _q = (_dish.tier == 0) ? 0.15 : (0.55 + _dish.tier * 0.15);
    var _f = 0.35 + _dish.freshness * 0.65;

    return {
        nourish:  _nourish * _q * _f,
        vigour:   _vigour  * _q * _f,
        warmth:   _warmth  * _q * _f,
        duration: (40 + _dish.tier * 55) * _f,
        potency:  _q * _f,
    };
}

/// What a substance contributes, as [nourish, vigour, warmth]. Deliberately coarse: three numbers
/// a designer can reason about, not a nutrition model.
function rps_material_nutrition(_mat) {
    switch (_mat) {
        case "beef":     return [1.00, 0.85, 0.55];
        case "pork":     return [0.95, 0.70, 0.50];
        case "poultry":  return [0.80, 0.75, 0.40];
        case "game":     return [0.90, 1.00, 0.45];
        case "fish":     return [0.70, 0.80, 0.30];
        case "salmon":   return [0.80, 0.90, 0.35];
        case "shell":    return [0.60, 0.85, 0.25];
        case "fat":      return [0.85, 0.20, 0.90];
        case "root":     return [0.60, 0.35, 0.55];
        case "tuber":    return [0.90, 0.25, 0.60];
        case "brassica": return [0.45, 0.60, 0.30];
        case "leaf":     return [0.25, 0.70, 0.15];
        case "allium":   return [0.30, 0.55, 0.45];
        case "gourd":    return [0.65, 0.40, 0.60];
        case "fungus":   return [0.45, 0.65, 0.35];
        case "pulse":    return [0.75, 0.50, 0.40];
        case "grain":    return [0.95, 0.30, 0.50];
        case "dough":    return [0.90, 0.25, 0.55];
        case "cheese":   return [0.80, 0.45, 0.60];
        case "egg":      return [0.70, 0.65, 0.40];
        case "yolk":     return [0.75, 0.70, 0.45];
        case "berry":    return [0.35, 0.80, 0.20];
        case "citrus":   return [0.25, 0.95, 0.15];
        case "nut":      return [0.70, 0.60, 0.45];
    }
    return [0.50, 0.50, 0.40];
}

/// -- DISCOVERY ---------------------------------------------------------------------------------

/// A ledger of what the player has found. Handed back to the caller to store; this package keeps
/// no global state for it.
function rps_ledger_new() {
    return { known: {}, cooked: {}, best: {} };
}

/// Record a cook. Returns true the FIRST time a recipe is completed, which is the moment a game
/// wants to fire "new recipe discovered".
///
/// ⚠️ A RUINED ATTEMPT DOES NOT DISCOVER THE RECIPE, and that is a deliberate design position:
/// discovery should feel like an achievement, and burning something is not one. It IS recorded in
/// `cooked`, so a game that wants to be gentler can check that instead.
function rps_ledger_record(_ledger, _dish) {
    if (!is_struct(_ledger) || !is_struct(_dish)) return undefined;
    var _id = _dish.recipe_id;
    var _n = variable_struct_exists(_ledger.cooked, _id)
        ? variable_struct_get(_ledger.cooked, _id) : 0;
    variable_struct_set(_ledger.cooked, _id, _n + 1);

    var _b = variable_struct_exists(_ledger.best, _id)
        ? variable_struct_get(_ledger.best, _id) : -1;
    if (_dish.tier > _b) variable_struct_set(_ledger.best, _id, _dish.tier);

    if (_dish.tier == 0) return false;
    if (variable_struct_exists(_ledger.known, _id)) return false;
    variable_struct_set(_ledger.known, _id, true);
    return true;
}

/// Refuses with FALSE: "is this recipe known" is a question whose honest answer for a non-ledger is
/// no, and a caller branching on it must not be handed undefined.
function rps_ledger_knows(_ledger, _id) {
    if (!is_struct(_ledger)) return false;
    return variable_struct_exists(_ledger.known, _id);
}

/// Refuses with -1, which is what it already returns for a recipe with no recorded best, so a caller
/// needs no new branch.
function rps_ledger_best(_ledger, _id) {
    if (!is_struct(_ledger)) return -1;
    return variable_struct_exists(_ledger.best, _id)
        ? variable_struct_get(_ledger.best, _id) : -1;
}

/// -- A STARTER BOOK ----------------------------------------------------------------------------
///
/// Twelve worked recipes, spanning every method and every slot shape, so a buyer has something
/// running in the first five minutes and a worked example of each field. They are ordinary data
/// and are meant to be replaced.
function rps_recipe_book() {
    return [
        rps_recipe_new("seared_chop",  "Seared Chop",        "mash",       "chop",
                       ["root", "sprout"],            "seared",   0.55),
        rps_recipe_new("roast_bird",   "Roast Bird",         "",           "bird",
                       ["roastpotato", "cabbage"],    "roasted",  0.70),
        rps_recipe_new("pan_fish",     "Pan-Fried Fish",     "",           "fish",
                       ["leek", "citrus"],            "fried",    0.62),
        rps_recipe_new("braised_shin", "Braised Shin",       "stew",       "joint",
                       ["root"],                      "braised",  0.48),
        rps_recipe_new("poached_egg",  "Poached Egg",        "breadslice", "egg_fried",
                       [],                            "poached",  0.75),
        rps_recipe_new("harvest_pie",  "Harvest Pie",        "",           "lattice",
                       ["squash"],                    "roasted",  0.66),
        rps_recipe_new("dumplings",    "Steamed Dumplings",  "",           "dumpling",
                       ["prawn", "leek"],             "steamed",  0.58),
        rps_recipe_new("noodle_bowl",  "Noodle Bowl",        "noodles",    "fillet",
                       ["mushroom", "pod"],           "poached",  0.52),
        rps_recipe_new("cheese_board", "Cheese and Fruit",   "",           "cheese",
                       ["applehalf", "fig"],          "raw",      0.20),
        rps_recipe_new("honeyed_root", "Honeyed Roots",      "",           "splitroot",
                       ["comb"],                      "candied",  0.68),
        rps_recipe_new("cured_plate",  "Cured Plate",        "",           "cheese",
                       ["berries"],                   "cured",    0.40),
        rps_recipe_new("grain_bowl",   "Grain and Greens",   "grainmound", "sprout",
                       ["peas", "pod"],               "blanched", 0.35),
    ];
}
