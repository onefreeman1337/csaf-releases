/// REPAST - rps_corpus. The index of the corpus: dispatch, names, and what each form IS.
///
/// The forty-six form functions live in rps_ingredient, rps_produce, rps_larder, rps_orchard and
/// rps_garnish. This file is the only thing that knows they exist as a set, which is what lets
/// the self-test and the store sheets iterate the whole corpus without either of them carrying
/// its own copy of the list.
///
/// ⛔ THE LIST AND THE DISPATCH ARE ASSERTED AGAINST EACH OTHER. rps_selftest calls every name in
/// rps_corpus_names() through rps_ingredient_form() and requires a non-empty part list back. A
/// name with no case, or a case with no name, goes red. This wing has shipped a "PASS" that
/// scanned zero assets and a strict-subset check that passed over an empty set; a list and a
/// switch that can drift apart silently is the same defect waiting to happen.
/// ============================================================================================

/// Every form name, in corpus order. RPS_FORM_N is asserted against array_length of this.
function rps_corpus_names() {
    return [
        // meat and fish (10)
        "chop", "steak", "joint", "sausage", "drumstick",
        "bird", "fish", "fillet", "prawn", "scallop",
        // vegetables (12)
        "root", "roastpotato", "mash", "onionring", "leek", "mushroom",
        "cabbage", "sprout", "peas", "pod", "squash", "splitroot",
        // egg, dairy, grain, pastry (12)
        "egg_fried", "egg_halved", "cheese", "butter", "loaf", "breadslice",
        "lattice", "dumpling", "grainmound", "noodles", "tartslice", "stew",
        // fruit and sweet (6)
        "applehalf", "fig", "berries", "citrus", "drizzle", "comb",
        // garnish and finishing (6)
        "sprig", "leafwhole", "seeds", "dusting", "saucepool", "steam",
    ];
}

/// Build one form by name. _seed makes the seeded forms deterministic per dish.
///
/// ⚠️ AN UNKNOWN NAME RETURNS AN EMPTY LIST RATHER THAN A PLACEHOLDER. An empty list draws
/// nothing, which is visible immediately as a missing component on a plate; a magenta box would
/// be more visible but would also ship if nobody looked. The self-test is what catches the typo,
/// and it cannot be fooled by a placeholder that draws successfully.
function rps_ingredient_form(_name, _seed) {
    var _s = is_undefined(_seed) ? 0 : _seed;
    switch (_name) {
        case "chop":        return rps_form_chop(_s);
        case "steak":       return rps_form_steak(_s);
        case "joint":       return rps_form_joint(_s);
        case "sausage":     return rps_form_sausage(_s);
        case "drumstick":   return rps_form_drumstick(_s);
        case "bird":        return rps_form_bird(_s);
        case "fish":        return rps_form_fish(_s);
        case "fillet":      return rps_form_fillet(_s);
        case "prawn":       return rps_form_prawn(_s);
        case "scallop":     return rps_form_scallop(_s);

        case "root":        return rps_form_root(_s);
        case "roastpotato": return rps_form_roastpotato(_s);
        case "mash":        return rps_form_mash(_s);
        case "onionring":   return rps_form_onionring(_s);
        case "leek":        return rps_form_leek(_s);
        case "mushroom":    return rps_form_mushroom(_s);
        case "cabbage":     return rps_form_cabbage(_s);
        case "sprout":      return rps_form_sprout(_s);
        case "peas":        return rps_form_peas(_s);
        case "pod":         return rps_form_pod(_s);
        case "squash":      return rps_form_squash(_s);
        case "splitroot":   return rps_form_splitroot(_s);

        case "egg_fried":   return rps_form_egg_fried(_s);
        case "egg_halved":  return rps_form_egg_halved(_s);
        case "cheese":      return rps_form_cheese(_s);
        case "butter":      return rps_form_butter(_s);
        case "loaf":        return rps_form_loaf(_s);
        case "breadslice":  return rps_form_breadslice(_s);
        case "lattice":     return rps_form_lattice(_s);
        case "dumpling":    return rps_form_dumpling(_s);
        case "grainmound":  return rps_form_grainmound(_s);
        case "noodles":     return rps_form_noodles(_s);
        case "tartslice":   return rps_form_tartslice(_s);
        case "stew":        return rps_form_stew(_s);

        case "applehalf":   return rps_form_applehalf(_s);
        case "fig":         return rps_form_fig(_s);
        case "berries":     return rps_form_berries(_s);
        case "citrus":      return rps_form_citrus(_s);
        case "drizzle":     return rps_form_drizzle(_s);
        case "comb":        return rps_form_comb(_s);

        case "sprig":       return rps_form_sprig(_s);
        case "leafwhole":   return rps_form_leafwhole(_s);
        case "seeds":       return rps_form_seeds(_s);
        case "dusting":     return rps_form_dusting(_s);
        case "saucepool":   return rps_form_saucepool(_s);
        case "steam":       return rps_form_steam(_s);
    }
    return [];
}

/// What a form IS, as far as the rest of the package needs to know.
///
///   mat    the substance it is made of unless a recipe overrides it
///   slot   where it wants to sit on a plate: "base", "hero", "side" or "garn"
///   w      how much plate width it wants, 0..1 of the plate's usable span
///   stack  true if other components may be laid ON it (a base), false otherwise
///
/// ⭐ THE SLOT IS THE FIELD THAT MAKES PLATING AUTOMATIC. A recipe names ingredients; it does not
/// say where they go. rps_plate reads the slot of each and composes the plate from it, which is
/// why a buyer can add an ingredient to a recipe and get a sensible plate back without
/// hand-placing anything. Getting this table right is most of the difference between "a cooking
/// system" and "a list of items with pictures".
function rps_corpus_spec(_name) {
    switch (_name) {
        case "chop":        return { mat: "pork",     slot: "hero", w: 0.62, stack: false };
        case "steak":       return { mat: "beef",     slot: "hero", w: 0.66, stack: false };
        case "joint":       return { mat: "beef",     slot: "hero", w: 0.64, stack: false };
        case "sausage":     return { mat: "pork",     slot: "hero", w: 0.70, stack: false };
        case "drumstick":   return { mat: "poultry",  slot: "hero", w: 0.60, stack: false };
        case "bird":        return { mat: "poultry",  slot: "hero", w: 0.74, stack: false };
        case "fish":        return { mat: "fish",     slot: "hero", w: 0.82, stack: false };
        case "fillet":      return { mat: "salmon",   slot: "hero", w: 0.62, stack: false };
        case "prawn":       return { mat: "shell",    slot: "side", w: 0.50, stack: false };
        case "scallop":     return { mat: "shell",    slot: "side", w: 0.46, stack: false };

        case "root":        return { mat: "root",     slot: "side", w: 0.70, stack: false };
        case "roastpotato": return { mat: "tuber",    slot: "side", w: 0.54, stack: false };
        case "mash":        return { mat: "tuber",    slot: "base", w: 0.80, stack: true  };
        case "onionring":   return { mat: "allium",   slot: "garn", w: 0.58, stack: false };
        case "leek":        return { mat: "allium",   slot: "side", w: 0.48, stack: false };
        case "mushroom":    return { mat: "fungus",   slot: "side", w: 0.52, stack: false };
        case "cabbage":     return { mat: "brassica", slot: "side", w: 0.66, stack: false };
        case "sprout":      return { mat: "brassica", slot: "side", w: 0.42, stack: false };
        case "peas":        return { mat: "pulse",    slot: "side", w: 0.72, stack: false };
        case "pod":         return { mat: "pulse",    slot: "side", w: 0.74, stack: false };
        case "squash":      return { mat: "gourd",    slot: "side", w: 0.76, stack: false };
        case "splitroot":   return { mat: "root",     slot: "side", w: 0.72, stack: false };

        case "egg_fried":   return { mat: "egg",      slot: "hero", w: 0.80, stack: false };
        case "egg_halved":  return { mat: "egg",      slot: "side", w: 0.48, stack: false };
        case "cheese":      return { mat: "cheese",   slot: "side", w: 0.68, stack: false };
        case "butter":      return { mat: "fat",      slot: "garn", w: 0.40, stack: false };
        case "loaf":        return { mat: "dough",    slot: "hero", w: 0.74, stack: false };
        case "breadslice":  return { mat: "dough",    slot: "side", w: 0.60, stack: false };
        case "lattice":     return { mat: "dough",    slot: "hero", w: 0.84, stack: false };
        case "dumpling":    return { mat: "dough",    slot: "side", w: 0.58, stack: false };
        case "grainmound":  return { mat: "grain",    slot: "base", w: 0.78, stack: true  };
        case "noodles":     return { mat: "grain",    slot: "base", w: 0.82, stack: true  };
        case "tartslice":   return { mat: "dough",    slot: "hero", w: 0.72, stack: false };
        case "stew":        return { mat: "beef",     slot: "base", w: 0.88, stack: true  };

        case "applehalf":   return { mat: "berry",    slot: "side", w: 0.58, stack: false };
        case "fig":         return { mat: "berry",    slot: "side", w: 0.50, stack: false };
        case "berries":     return { mat: "berry",    slot: "garn", w: 0.64, stack: false };
        case "citrus":      return { mat: "citrus",   slot: "garn", w: 0.54, stack: false };
        case "drizzle":     return { mat: "berry",    slot: "garn", w: 0.46, stack: false };
        case "comb":        return { mat: "nut",      slot: "side", w: 0.56, stack: false };

        case "sprig":       return { mat: "leaf",     slot: "garn", w: 0.44, stack: false };
        case "leafwhole":   return { mat: "leaf",     slot: "garn", w: 0.62, stack: false };
        case "seeds":       return { mat: "nut",      slot: "garn", w: 0.66, stack: false };
        case "dusting":     return { mat: "grain",    slot: "garn", w: 0.70, stack: false };
        case "saucepool":   return { mat: "beef",     slot: "base", w: 0.86, stack: true  };
        case "steam":       return { mat: "grain",    slot: "garn", w: 0.40, stack: false };
    }
    return { mat: "grain", slot: "side", w: 0.50, stack: false };
}

/// Every form whose slot is _slot. Used by the recipe generator so it can pick a base that is
/// actually a base.
function rps_corpus_in_slot(_slot) {
    var _names = rps_corpus_names();
    var _out = [];
    for (var _i = 0; _i < array_length(_names); _i++) {
        if (rps_corpus_spec(_names[_i]).slot == _slot) array_push(_out, _names[_i]);
    }
    return _out;
}

/// ⚠️ THE ONE FORM THAT DOES NOT SIT ON THE GROUND, BY NAME.
///
/// rps_form_steam is authored in the TOP half of the unit box because rps_plate draws it above
/// the dish rather than on it. Corpus rule 1 (lowest point on RPS_GROUND) does not apply to it.
///
/// ⛔ THIS IS A NAMED EXCEPTION AND NOT A GENERAL ESCAPE HATCH, and the difference matters. A
/// flag like `ignore_ground` on the spec struct would let any future form opt out of the rule
/// silently, and the rule would rot. A function that returns exactly one name means adding a
/// second exception is a deliberate edit that a reviewer sees.
function rps_corpus_is_airborne(_name) {
    return (_name == "steam");
}
