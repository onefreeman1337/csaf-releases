{
  "$GMScript": "v1",
  "%Name": "rps_selftest",
  "name": "rps_selftest",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}