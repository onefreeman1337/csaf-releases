/// REPAST - rps_selftest. The in-engine assertion suite.
///
/// ⛔ READ THIS BEFORE TRUSTING ANY NUMBER THIS FILE PRINTS.
///
/// GML cannot be unit-tested outside the engine. This wing says so in its own constitution rather
/// than papering over it, and this file is the compensation: the product tests ITSELF, inside a
/// real Igor-built executable, and writes its result to a file the build harness reads. That is
/// strictly better than a mock, and it is strictly worse than a real test framework, and both
/// halves of that sentence are true.
///
/// -- THE FIVE TRAPS ON THIS ROUTE, EVERY ONE MEASURED BY THIS WING ------------------------------
///   1. Driving Igor directly gives `Reason Code - 0000002A / Permission Error` without
///      `--uf=<user folder>` - the exact signature of a lapsed licence, on a healthy machine.
///      Shell out to gm_gate.ps1 instead.
///   2. `show_debug_message` + `-debugoutput` is DEAD in a release build.
///   3. `game_end(n)` does not propagate its argument. A pass/fail bit at best.
///   4. `file_text_open_write` into %LOCALAPPDATA%\<Game>\ is the ONE route that works.
///   5. A GML runtime error opens a MODAL DIALOG, so headless the process never exits. The
///      unhandled-exception handler below is installed FIRST for exactly that reason, and it
///      records the stage it died in.
///
/// -- AND THE TRAP THAT IS NOT ABOUT GML --------------------------------------------------------
/// ⛔ AN ASSERTION THAT CANNOT FAIL IS NOT AN ASSERTION. This factory has shipped a "PASS" that
/// scanned zero assets, a strict-subset check that passed over an empty set, and a distinctness
/// check written at a tolerance below GML's default epsilon so it could never fire in either
/// direction. Every count below is asserted to be NON-ZERO before it is used, and STAGE 0 exists
/// to prove the suite itself goes red.
///
/// ⛔ GML'S DEFAULT COMPARISON EPSILON IS 0.00001 ON THIS RUNTIME. Never write a tolerance at or
/// below it. And GML has no exponent-literal syntax - `1e-5` is a lexer error that reads like a
/// bracket bug.
/// ============================================================================================

/// Assertion state. Kept on a struct handed through the run rather than in globals.
function rps_test_new() {
    return { pass: 0, fail: 0, notes: [], stage: -1 };
}

/// The stage the suite is in, mirrored into a global so the unhandled-exception handler can
/// report it. Top-level script code runs once at game start, before the first room.
global.rps_stage = -1;

/// ⛔ ONE WRITER, TWO READERS. The suite reads _t.stage; the crash handler reads the global. An
/// earlier draft of this file set the global only AFTER the run finished, so a crash - the one
/// case the handler exists for - would have reported stage -1 forever. Every stage change goes
/// through here.
function rps_set_stage(_t, _n) {
    _t.stage = _n;
    global.rps_stage = _n;
}

function rps_check(_t, _cond, _label) {
    if (_cond) { _t.pass += 1; return true; }
    _t.fail += 1;
    array_push(_t.notes, "FAIL: " + string(_label));
    return false;
}

/// Assert a COUNT is at least _min. Used before any loop whose body carries assertions, so a loop
/// that runs zero times is a failure rather than a silent pass.
function rps_check_count(_t, _n, _min, _label) {
    return rps_check(_t, _n >= _min,
                     _label + " count " + string(_n) + " < required " + string(_min));
}

/// Perceptual distance between two GameMaker colours, as a rough Oklab-ish separation.
///
/// ⚠️ IT IS DELIBERATELY CRUDE AND IT IS ONLY EVER USED WITH A GENEROUS FLOOR. A precise metric
/// here would invite a precise threshold, and a precise threshold on a perceptual quantity is how
/// a distinctness assertion becomes a number nobody can defend. What it must catch is "these two
/// ramps are the same ramp", which is a large difference or none.
function rps_col_dist(_a, _b) {
    var _dr = (colour_get_red(_a)   - colour_get_red(_b))   / 255;
    var _dg = (colour_get_green(_a) - colour_get_green(_b)) / 255;
    var _db = (colour_get_blue(_a)  - colour_get_blue(_b))  / 255;
    return sqrt(_dr * _dr * 0.30 + _dg * _dg * 0.59 + _db * _db * 0.11);
}

/// A dish used by several stages.
function rps_test_dish() {
    var _book = rps_recipe_book();
    return rps_recipe_cook(_book[0], 0.72, 0.5, 12345);
}

/// ============================================================================================
/// THE SUITE
/// ============================================================================================
function rps_selftest_run() {
    var _t = rps_test_new();

    // -- STAGE 0: PROVE THE SUITE CAN GO RED --------------------------------------------------
    // ⛔ WITHOUT THIS STAGE EVERY NUMBER BELOW IS UNFALSIFIABLE. It runs the failure path on
    // purpose, confirms the counter moved, and then removes the damage. A suite that has never
    // been seen to fail is a suite nobody has tested.
    rps_set_stage(_t, 0);
    var _f0 = _t.fail;
    rps_check(_t, false, "STAGE 0 deliberate failure - this must appear and be retracted");
    var _fired = (_t.fail == _f0 + 1);
    _t.fail = _f0;
    array_pop(_t.notes);
    rps_check(_t, _fired, "STAGE 0: rps_check did NOT register a failure - the suite is blind");
    // And the count guard must also fire on zero.
    var _f0b = _t.fail;
    rps_check_count(_t, 0, 1, "STAGE 0 zero-count probe");
    var _fired2 = (_t.fail == _f0b + 1);
    _t.fail = _f0b;
    array_pop(_t.notes);
    rps_check(_t, _fired2, "STAGE 0: rps_check_count passed on ZERO - every loop guard is fake");

    // -- STAGE 1: THE ENVIRONMENT --------------------------------------------------------------
    rps_set_stage(_t, 1);
    // The lamp's top-level script code must have run at game start, before the first room.
    rps_check(_t, variable_global_exists("rps_lx"), "STAGE 1: global.rps_lx not initialised");
    rps_check(_t, abs(global.rps_lx - RPS_LX) < 0.001, "STAGE 1: lamp x not at the default");
    rps_check(_t, abs(global.rps_ly - RPS_LY) < 0.001, "STAGE 1: lamp y not at the default");
    // Record the epsilon rather than assuming it. This is the number that made a previous
    // product's distinctness suite vacuous.
    array_push(_t.notes, "epsilon=" + string_format(math_get_epsilon(), 1, 12));

    // -- STAGE 2: THE CORPUS EXISTS AND IS THE SIZE IT CLAIMS ----------------------------------
    rps_set_stage(_t, 2);
    var _names = rps_corpus_names();
    var _n = array_length(_names);
    rps_check_count(_t, _n, 40, "STAGE 2: corpus");
    rps_check(_t, _n == RPS_FORM_N,
              "STAGE 2: RPS_FORM_N " + string(RPS_FORM_N) + " != names " + string(_n));

    // Every name must build a NON-EMPTY part list. A name with no case returns [] and this is
    // what catches it.
    var _empty = 0;
    for (var _i = 0; _i < _n; _i++) {
        if (array_length(rps_ingredient_form(_names[_i], _i * 17 + 3)) == 0) {
            _empty += 1;
            array_push(_t.notes, "empty form: " + _names[_i]);
        }
    }
    rps_check(_t, _empty == 0, "STAGE 2: " + string(_empty) + " form(s) built nothing");

    // No duplicate names - a duplicate would make the dispatch unreachable for one of them.
    var _dupes = 0;
    for (var _i = 0; _i < _n; _i++) {
        for (var _j = _i + 1; _j < _n; _j++) {
            if (_names[_i] == _names[_j]) _dupes += 1;
        }
    }
    rps_check(_t, _dupes == 0, "STAGE 2: " + string(_dupes) + " duplicate form name(s)");

    // -- STAGE 3: EVERY FORM OBEYS THE CORPUS CONTRACT -----------------------------------------
    rps_set_stage(_t, 3);
    var _oob = 0, _offground = 0, _checked = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _nm = _names[_i];
        var _parts = rps_ingredient_form(_nm, _i * 31 + 7);
        if (array_length(_parts) == 0) continue;
        _checked += 1;
        var _bb = rps_render_bounds(_parts);

        // RULE 2: inside the unit box. A small tolerance, well above the default epsilon.
        if (_bb[0] < -0.52 || _bb[1] < -0.52 || _bb[2] > 0.52 || _bb[3] > 0.52) {
            _oob += 1;
            array_push(_t.notes, "out of box: " + _nm + " ["
                       + string_format(_bb[0], 1, 3) + "," + string_format(_bb[1], 1, 3) + ","
                       + string_format(_bb[2], 1, 3) + "," + string_format(_bb[3], 1, 3) + "]");
        }

        // RULE 1: sits on the ground - except the one named airborne form.
        if (!rps_corpus_is_airborne(_nm)) {
            if (_bb[3] < RPS_GROUND - 0.10) {
                _offground += 1;
                array_push(_t.notes, "floats: " + _nm + " lowest y "
                           + string_format(_bb[3], 1, 3));
            }
        }
    }
    rps_check_count(_t, _checked, 40, "STAGE 3: forms actually measured");
    rps_check(_t, _oob == 0, "STAGE 3: " + string(_oob) + " form(s) outside the unit box");
    rps_check(_t, _offground == 0, "STAGE 3: " + string(_offground) + " form(s) not on the ground");

    // ⚠️ AND THE AIRBORNE EXCEPTION MUST BE REAL. If rps_form_steam ever gets moved down onto the
    // ground, the exception above becomes a lie that hides a rule. Assert it is genuinely high.
    var _steam_bb = rps_render_bounds(rps_ingredient_form("steam", 5));
    rps_check(_t, _steam_bb[3] < RPS_GROUND - 0.02,
              "STAGE 3: the airborne exception is claimed but steam sits on the ground");

    // -- STAGE 4: THE COOK MODEL ACTUALLY MOVES THE PICTURE -------------------------------------
    rps_set_stage(_t, 4);
    var _cooks = rps_cook_names();
    var _cn = array_length(_cooks);
    rps_check_count(_t, _cn, 10, "STAGE 4: cook states");
    rps_check(_t, _cn == RPS_COOK_N,
              "STAGE 4: RPS_COOK_N " + string(RPS_COOK_N) + " != names " + string(_cn));

    var _mats = rps_material_names();
    rps_check_count(_t, array_length(_mats), 20, "STAGE 4: substances");
    rps_check(_t, array_length(_mats) == RPS_MAT_N,
              "STAGE 4: RPS_MAT_N != material names");

    // ⭐ THE CENTRAL CLAIM OF THIS PRODUCT, ASSERTED: raw and done are visibly different, for
    // every substance and every cook state that is not "raw". A recolour would pass this; what it
    // rules out is a cook model that does nothing, which is the failure that would make every
    // screenshot on the store page a lie.
    var _flat = 0, _pairs = 0;
    for (var _m = 0; _m < array_length(_mats); _m++) {
        for (var _c = 1; _c < _cn; _c++) {
            var _r0 = rps_material_ramp(_mats[_m], _cooks[_c], 0.0, 0);
            var _r1 = rps_material_ramp(_mats[_m], _cooks[_c], 1.0, 0);
            _pairs += 1;
            if (rps_col_dist(_r0[2], _r1[2]) < 0.045) {
                _flat += 1;
                array_push(_t.notes, "cook does nothing: " + _mats[_m] + "/" + _cooks[_c]);
            }
        }
    }
    rps_check_count(_t, _pairs, 200, "STAGE 4: raw-vs-done pairs compared");
    rps_check(_t, _flat == 0,
              "STAGE 4: " + string(_flat) + " of " + string(_pairs)
              + " substance/cook pairs are visually identical raw and done");

    // ⭐ AND THE CHROMA ARCH IS REAL, NOT A LINE. seared and charred must differ by more than
    // lightness - if the arch were removed they would be the same hue at two brightnesses, which
    // is exactly the "one texture, two brightnesses" tell this product is sold against.
    // ⚠️ THE SPECS ARE READ, NOT RETYPED. An earlier version of this block hard-coded 1.45/0.78
    // and 1.30/0.32 as literals, which meant it was asserting about numbers that had been COPIED
    // out of rps_cook_spec rather than about the model - so tuning the model would have left the
    // assertion quietly testing the old one. Reading the spec is what makes this a test.
    var _ss = rps_cook_spec("seared");
    var _sc = rps_cook_spec("charred");
    var _sear = rps_material_ramp("beef", "seared", 1.0, 0);
    var _chr  = rps_material_ramp("beef", "charred", 1.0, 0);
    var _cs = rps_cook_chroma(1.0, _ss.dC, _ss.arch, _ss.flr);
    var _cc = rps_cook_chroma(1.0, _sc.dC, _sc.arch, _sc.flr);
    rps_check(_t, _cs > _cc + 0.10,
              "STAGE 4: the chroma arch is flat - seared and charred end at the same chroma ("
              + string_format(_cs, 1, 3) + " vs " + string_format(_cc, 1, 3) + ")");
    rps_check(_t, rps_col_dist(_sear[2], _chr[2]) > 0.05,
              "STAGE 4: seared and charred beef are the same colour");

    // The arch must RISE before it falls, which is the physical claim the file's header makes.
    rps_check(_t, rps_cook_chroma(0.5, _ss.dC, _ss.arch, _ss.flr)
                > rps_cook_chroma(0.0, _ss.dC, _ss.arch, _ss.flr),
              "STAGE 4: chroma does not rise on the way to the peak");
    rps_check(_t, rps_cook_chroma(1.0, _sc.dC, _sc.arch, _sc.flr)
                < rps_cook_chroma(_sc.arch, _sc.dC, _sc.arch, _sc.flr),
              "STAGE 4: chroma does not fall after the peak");

    // ⛔ AND EVERY STATE MUST DECLARE A FLOOR. A missing `flr` silently defaults to 0.18 inside
    // rps_cook_chroma, which is the single hard-coded value this whole change existed to remove -
    // so a state added later without one would quietly reintroduce the flat arch.
    var _noflr = 0;
    for (var _c = 0; _c < _cn; _c++) {
        if (is_undefined(rps_cook_spec(_cooks[_c]).flr)) {
            _noflr += 1;
            array_push(_t.notes, "cook state has no chroma floor: " + _cooks[_c]);
        }
    }
    rps_check(_t, _noflr == 0,
              "STAGE 4: " + string(_noflr) + " cook state(s) declare no chroma floor");

    // -- STAGE 5: RAMPS ARE ORDERED AND SEPARATED ----------------------------------------------
    rps_set_stage(_t, 5);
    var _unordered = 0, _flatramp = 0, _ramps = 0;
    for (var _m = 0; _m < array_length(_mats); _m++) {
        var _r = rps_material_ramp(_mats[_m], "seared", 0.5, 0);
        _ramps += 1;
        // m0 (facing away) must be darker than m4 (facing the lamp). If this inverts, every
        // object in the package is lit from the wrong side.
        var _l0 = colour_get_red(_r[0]) + colour_get_green(_r[0]) + colour_get_blue(_r[0]);
        var _l4 = colour_get_red(_r[4]) + colour_get_green(_r[4]) + colour_get_blue(_r[4]);
        if (_l4 <= _l0) { _unordered += 1; array_push(_t.notes, "ramp inverted: " + _mats[_m]); }
        if (rps_col_dist(_r[0], _r[4]) < 0.04) {
            _flatramp += 1;
            array_push(_t.notes, "ramp flat: " + _mats[_m]);
        }
    }
    rps_check_count(_t, _ramps, 20, "STAGE 5: ramps built");
    rps_check(_t, _unordered == 0, "STAGE 5: " + string(_unordered) + " ramp(s) run dark-to-light backwards");
    rps_check(_t, _flatramp == 0, "STAGE 5: " + string(_flatramp) + " ramp(s) have no relief at all");

    // -- STAGE 6: THE PALETTE RESOLVES EVERY ROLE THE CORPUS EMITS -----------------------------
    rps_set_stage(_t, 6);
    var _dish = rps_test_dish();
    var _pal = rps_palette_build(_dish);
    var _roles = rps_palette_roles(_pal);
    // ⛔ NON-EMPTY FIRST. A subset check over an empty set passes vacuously, and this factory has
    // shipped exactly that.
    rps_check_count(_t, array_length(_roles), 40, "STAGE 6: palette roles");

    var _unres = 0, _emitted = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _used = rps_roles_used(rps_ingredient_form(_names[_i], _i + 1));
        for (var _k = 0; _k < array_length(_used); _k++) {
            _emitted += 1;
            if (!variable_struct_exists(_pal, _used[_k])) {
                _unres += 1;
                array_push(_t.notes, "unresolved role '" + _used[_k] + "' from " + _names[_i]);
            }
        }
    }
    rps_check_count(_t, _emitted, 100, "STAGE 6: roles emitted by the corpus");
    rps_check(_t, _unres == 0,
              "STAGE 6: " + string(_unres) + " role(s) fall through to the ink colour");

    // -- STAGE 7: THE RECIPE SYSTEM ------------------------------------------------------------
    rps_set_stage(_t, 7);
    var _book = rps_recipe_book();
    rps_check_count(_t, array_length(_book), 10, "STAGE 7: starter recipes");

    // Every recipe must name forms that exist, in slots that make sense.
    var _badform = 0;
    for (var _i = 0; _i < array_length(_book); _i++) {
        var _rc = _book[_i];
        if (array_length(rps_ingredient_form(_rc.hero_form, 1)) == 0) {
            _badform += 1; array_push(_t.notes, "recipe hero unknown: " + _rc.id);
        }
        if (_rc.base_form != "" && array_length(rps_ingredient_form(_rc.base_form, 1)) == 0) {
            _badform += 1; array_push(_t.notes, "recipe base unknown: " + _rc.id);
        }
        for (var _k = 0; _k < array_length(_rc.side_forms); _k++) {
            if (array_length(rps_ingredient_form(_rc.side_forms[_k], 1)) == 0) {
                _badform += 1; array_push(_t.notes, "recipe side unknown: " + _rc.id);
            }
        }
    }
    rps_check(_t, _badform == 0, "STAGE 7: " + string(_badform) + " recipe component(s) name a form that does not exist");

    // ⭐ SKILL MUST HELP AND THE WINDOW MUST BE REAL. Cooking at the ideal beats cooking wildly
    // off it, and a skilled cook beats an unskilled one from the SAME input. If either of these
    // stops being true the mechanic has no gradient and the quality tier is noise.
    var _r0 = _book[0];
    var _perfect = rps_recipe_cook(_r0, _r0.ideal, 0, 1);
    var _awful   = rps_recipe_cook(_r0, 0.02, 0, 1);
    rps_check(_t, _perfect.tier > _awful.tier, "STAGE 7: hitting the window is no better than missing it");
    var _lo = rps_recipe_cook(_r0, 0.30, 0.0, 1);
    var _hi = rps_recipe_cook(_r0, 0.30, 1.0, 1);
    rps_check(_t, _hi.tier >= _lo.tier, "STAGE 7: skill makes the result worse");
    rps_check(_t, abs(_hi.doneness - _r0.ideal) < abs(_lo.doneness - _r0.ideal) - 0.001,
              "STAGE 7: skill does not pull the result toward the ideal");

    // A harder recipe has a TIGHTER window, not a lower ceiling.
    rps_check(_t, rps_recipe_tier(0.12, 0.0) >= rps_recipe_tier(0.12, 1.0),
              "STAGE 7: difficulty does not tighten the window");
    rps_check(_t, rps_recipe_tier(0.0, 1.0) == 4,
              "STAGE 7: a perfect cook on a hard recipe cannot reach masterwork");

    // ⭐ GARNISH IS EARNED. A masterwork plate must carry more finishing than a plain one - this
    // is the assertion behind the claim that quality is visible without a number.
    var _plain = rps_recipe_cook(_r0, _r0.ideal + 0.19, 0, 3);
    var _master = rps_recipe_cook(_r0, _r0.ideal, 0, 3);
    rps_check(_t, array_length(_master.garn_forms) > array_length(_plain.garn_forms),
              "STAGE 7: a masterwork dish is not visibly more finished than a plain one");

    // -- STAGE 8: SPOILAGE AND BUFFS -----------------------------------------------------------
    rps_set_stage(_t, 8);
    var _fresh = rps_test_dish();
    var _stale = rps_dish_age(_fresh, 40, 8);
    rps_check(_t, _stale.freshness < 0.20, "STAGE 8: ageing does not reduce freshness");
    rps_check(_t, array_length(_stale.garn_forms) < array_length(_fresh.garn_forms),
              "STAGE 8: a stale dish keeps all its garnish - spoilage is invisible");
    rps_check(_t, _stale.hero_done > _fresh.hero_done,
              "STAGE 8: ageing does not darken the food");
    // ⚠️ AND IT MUST NOT MUTATE THE ORIGINAL. A caller holding a dish should not have it change.
    rps_check(_t, array_length(_fresh.garn_forms) > 0,
              "STAGE 8: rps_dish_age MUTATED the dish it was given");

    var _bf = rps_dish_buff(_fresh);
    var _bs = rps_dish_buff(_stale);
    rps_check(_t, _bf.nourish > 0, "STAGE 8: a fresh meal nourishes nothing");
    rps_check(_t, _bs.nourish < _bf.nourish, "STAGE 8: staleness does not reduce the buff");
    rps_check(_t, _bf.duration > 0, "STAGE 8: buff duration is zero");
    // Tier scales DURATION, not magnitude - the stated design position.
    var _d_master = rps_recipe_cook(_r0, _r0.ideal, 0, 9);
    var _d_plain  = rps_recipe_cook(_r0, _r0.ideal + 0.19, 0, 9);
    var _bm = rps_dish_buff(_d_master);
    var _bp = rps_dish_buff(_d_plain);
    rps_check(_t, _bm.duration > _bp.duration, "STAGE 8: tier does not extend buff duration");

    // -- STAGE 9: THE LEDGER -------------------------------------------------------------------
    rps_set_stage(_t, 9);
    var _led = rps_ledger_new();
    var _good = rps_recipe_cook(_r0, _r0.ideal, 0, 2);
    var _bad = rps_recipe_cook(_r0, 0.02, 0, 2);
    rps_check(_t, _bad.tier == 0, "STAGE 9: the deliberately ruined dish is not ruined");
    rps_check(_t, rps_ledger_record(_led, _bad) == false,
              "STAGE 9: a ruined dish discovered the recipe");
    rps_check(_t, rps_ledger_knows(_led, _r0.id) == false,
              "STAGE 9: a ruined dish entered the known list");
    rps_check(_t, rps_ledger_record(_led, _good) == true,
              "STAGE 9: a good dish did not report a first discovery");
    rps_check(_t, rps_ledger_record(_led, _good) == false,
              "STAGE 9: the same recipe reported discovery twice");
    rps_check(_t, rps_ledger_best(_led, _r0.id) == _good.tier,
              "STAGE 9: the ledger did not record the best tier");

    // -- STAGE 10: A WHOLE PLATE COMPOSES ------------------------------------------------------
    rps_set_stage(_t, 10);
    var _composed = 0, _thin = 0, _plate_oob = 0;
    for (var _i = 0; _i < array_length(_book); _i++) {
        var _dd = rps_recipe_cook(_book[_i], _book[_i].ideal, 0.4, _i * 91 + 5);
        var _parts = rps_plate_compose(_dd);
        _composed += 1;
        // ⛔ COUNT THE WORK. A plate that composes to nine parts is an empty plate that returned
        // successfully, which is precisely the shape of green lie this suite exists to stop.
        if (array_length(_parts) < 120) {
            _thin += 1;
            array_push(_t.notes, "thin plate: " + _book[_i].id + " -> "
                       + string(array_length(_parts)) + " parts");
        }
        var _pb = rps_render_bounds(_parts);
        if (_pb[0] < -0.60 || _pb[2] > 0.60 || _pb[3] > 0.60) {
            _plate_oob += 1;
            array_push(_t.notes, "plate overflows: " + _book[_i].id);
        }
    }
    rps_check_count(_t, _composed, 10, "STAGE 10: plates composed");
    rps_check(_t, _thin == 0, "STAGE 10: " + string(_thin) + " plate(s) came back nearly empty");
    rps_check(_t, _plate_oob == 0, "STAGE 10: " + string(_plate_oob) + " plate(s) overflow the box");

    // Every vessel must produce a plate.
    var _wares = rps_ware_names();
    rps_check_count(_t, array_length(_wares), 8, "STAGE 10: vessels");
    var _badware = 0;
    for (var _i = 0; _i < array_length(_wares); _i++) {
        if (array_length(rps_plate_form(_wares[_i], 0.5, _i)) < 8) _badware += 1;
    }
    rps_check(_t, _badware == 0, "STAGE 10: " + string(_badware) + " vessel(s) drew almost nothing");

    // ⭐ THE VOLUME CLAIM, ASSERTED RATHER THAN ADVERTISED. Twelve recipes at three skill levels
    // must produce plates that differ from each other. This is the claim the store page makes.
    var _same = 0, _cmp = 0;
    for (var _i = 0; _i < array_length(_book); _i++) {
        var _a = rps_plate_compose(rps_recipe_cook(_book[_i], _book[_i].ideal, 1.0, 7));
        var _b = rps_plate_compose(rps_recipe_cook(_book[_i], 0.10, 0.0, 7));
        _cmp += 1;
        if (array_length(_a) == array_length(_b)) {
            _same += 1;
            array_push(_t.notes, "identical part count at both extremes: " + _book[_i].id);
        }
    }
    rps_check_count(_t, _cmp, 10, "STAGE 10: quality comparisons");
    rps_check(_t, _same <= 2,
              "STAGE 10: " + string(_same) + " recipe(s) compose identically at masterwork and ruined");

    // ⛔ THE RIM STRADDLES THE FOOD, AND THIS IS THE ONLY THING THAT CAN SEE IT.
    // The rim used to be one closed ellipse appended last, which ran a gilt line straight across
    // the hero on every plate. The picture is unreachable from a test - a gilt line is ink, and it
    // is ink exactly where the plate is, so the ink box, the extent check and the density floor all
    // passed. What IS testable is the ordering contract: some gild must be laid down BEFORE the
    // food and some AFTER it. See rps_plate_rim_back.
    var _rim_seen = 0, _rim_bad = 0;
    for (var _i = 0; _i < array_length(_book); _i++) {
        var _md = rps_recipe_cook(_book[_i], _book[_i].ideal, 1.0, _i * 13 + 3);
        if (_md.tier < 3) continue;              // only fine and masterwork dishes carry a rim
        var _mp = rps_plate_compose(_md);
        var _first = -1, _last = -1, _mid = 0;
        for (var _j = 0; _j < array_length(_mp); _j++) {
            if (_mp[_j].role == "gild") {
                if (_first < 0) _first = _j;
                _last = _j;
            }
        }
        if (_first < 0 || _last <= _first) { _rim_bad += 1; continue; }
        // Something that is not rim must sit between the two halves, or both halves are adjacent
        // and the rim is effectively still one ring.
        for (var _j = _first + 1; _j < _last; _j++) {
            if (_mp[_j].role != "gild") _mid += 1;
        }
        _rim_seen += 1;
        if (_mid < 1) {
            _rim_bad += 1;
            array_push(_t.notes, "rim is one ring, nothing drawn between its halves: " + _book[_i].id);
        }
    }
    // ⚠️ VACUITY GUARD. Every assertion above depends on at least one recipe actually reaching
    // tier 3; without this the whole check passes over an empty loop.
    rps_check_count(_t, _rim_seen, 1, "STAGE 10: rimmed plates examined");
    rps_check(_t, _rim_bad == 0,
              "STAGE 10: " + string(_rim_bad) + " plate(s) draw the whole rim on one side of the food");

    // And the two halves must genuinely be opposite halves, not two copies of the same arc.
    var _rb = rps_plate_rim_back("porcelain", 0.5, 4);
    var _rf = rps_plate_rim_front("porcelain", 0.5, 4);
    rps_check_count(_t, array_length(_rb), 1, "STAGE 10: back rim parts");
    rps_check_count(_t, array_length(_rf), 1, "STAGE 10: front rim parts");
    var _bb = rps_render_bounds(_rb);
    var _fb = rps_render_bounds(_rf);
    rps_check(_t, _bb[1] < RPS_PLATE_Y + 0.0001,
              "STAGE 10: the back rim reaches below the plate centre - it is not the far half");
    rps_check(_t, _fb[3] > RPS_PLATE_Y - 0.0001,
              "STAGE 10: the front rim does not reach below the plate centre - it is not the near half");

    rps_set_stage(_t, 99);
    return _t;
}

/// ============================================================================================
/// THE RESULT FILE
///
/// ⛔ THIS FUNCTION DOES NOT INSTALL A CRASH HANDLER, DELIBERATELY. obj_rps_demo's Create event
/// installs one as its first statement, and that one records the MESSAGE AND THE STACKTRACE -
/// function and line - where an earlier draft of this file recorded only the message. Two
/// handlers would also mean whichever was installed last silently won. One handler, owned by the
/// entry point, reading global.rps_stage which rps_set_stage() keeps current.
///
/// ⛔ AND THE ROUTE IS file_text_open_write, WHICH LANDS IN %LOCALAPPDATA%\Repast\. It is the
/// only one of the four candidates that survives a release build: show_debug_message with
/// -debugoutput is dead, game_end(n) does not propagate its argument, and there is no stdout.
function rps_selftest_write(_t) {
    var _notes = "";
    for (var _i = 0; _i < array_length(_t.notes); _i++) {
        if (_i > 0) _notes += " | ";
        _notes += string_replace_all(string(_t.notes[_i]), "\"", "'");
    }
    var _f = file_text_open_write("rps_selftest.json");
    file_text_write_string(_f,
        "{\"ok\":" + ((_t.fail == 0) ? "true" : "false")
        + ",\"pass\":" + string(_t.pass)
        + ",\"fail\":" + string(_t.fail)
        + ",\"stage\":" + string(_t.stage)
        + ",\"epsilon\":" + string_format(math_get_epsilon(), 1, 12)
        + ",\"notes\":\"" + _notes + "\"}");
    file_text_close(_f);
}
