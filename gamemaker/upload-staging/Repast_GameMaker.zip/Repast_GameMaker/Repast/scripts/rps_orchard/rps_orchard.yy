{
  "$GMScript": "v1",
  "%Name": "rps_orchard",
  "name": "rps_orchard",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}