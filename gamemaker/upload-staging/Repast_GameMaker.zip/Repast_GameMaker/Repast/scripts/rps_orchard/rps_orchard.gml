/// REPAST - rps_orchard. The CORPUS, part 4: six fruit and sweet forms.
///
/// Same contract as rps_ingredient.
///
/// ⭐ FRUIT IS THE GROUP WHERE THE CUT FACE MATTERS MOST. A whole apple is a circle and a circle
/// is the least informative shape in a corpus; a HALVED apple shows its core, its seeds and the
/// blush under its skin, and is unmistakable at any size. Five of the six forms here are cut open
/// for exactly that reason. The exception is the berry cluster, where the whole point is that
/// there are many of them.
/// ============================================================================================

/// A halved apple or pear: the cut face, the core chamber, two pips, and the skin as a rim.
function rps_form_applehalf(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.62));
    // A pear-ish profile rather than a circle: narrower at the top, which serves both fruits and
    // is more informative than a disc.
    var _body = [];
    for (var _i = 0; _i <= 26; _i++) {
        var _a = RPS_TAU * (_i / 26);
        var _t = (sin(_a - pi * 0.5) + 1) * 0.5;
        var _rx = 0.180 * (0.80 + 0.30 * _t);
        _body[_i] = [cos(_a) * _rx, RPS_GROUND - 0.180 + sin(_a) * 0.185];
    }
    rps_append(_out, rps_raise(_body, 0.040, 3, "m4"));
    // The skin: a rim band, in the garnish ramp so a red apple and a green one are one form.
    rps_append(_out, rps_map_roles([rps_ribbon(_body, 0.022, "m3")], rps_material_map("leafm")));
    // The core: a sunken lens on the cut face, with two pips in it.
    var _core = [[0, RPS_GROUND - 0.290], [0.052, RPS_GROUND - 0.180],
                 [0, RPS_GROUND - 0.070], [-0.052, RPS_GROUND - 0.180]];
    rps_append(_out, rps_sink(_core, 0.018, 2, "m3"));
    rps_append(_out, rps_map_roles(rps_boss(0, RPS_GROUND - 0.215, 0.022, 10),
                                   rps_material_map("side")));
    rps_append(_out, rps_map_roles(rps_boss(0, RPS_GROUND - 0.145, 0.022, 10),
                                   rps_material_map("side")));
    // The stalk.
    array_push(_out, rps_ribbon(rps_qbez([0, RPS_GROUND - 0.360], [0.02, RPS_GROUND - 0.410],
                                         [0.05, RPS_GROUND - 0.440], 8), 0.008, "crumb"));
    return _out;
}

/// A split fig: the teardrop body and the seeded heart, which is the most recognisable cut face
/// of any fruit and the reason figs are in this corpus at all.
function rps_form_fig(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.54));
    var _body = [];
    for (var _i = 0; _i <= 24; _i++) {
        var _a = RPS_TAU * (_i / 24);
        var _t = (sin(_a - pi * 0.5) + 1) * 0.5;
        _body[_i] = [cos(_a) * 0.175 * (0.62 + 0.48 * _t),
                     RPS_GROUND - 0.175 + sin(_a) * 0.175];
    }
    rps_append(_out, rps_raise(_body, 0.038, 3, "m2"));
    // The pale flesh ring inside the skin.
    rps_append(_out, rps_map_roles(
        rps_raise(rps_inset(_body, 0.030, rps_out_sign(_body)), 0.018, 2, "m4"),
        rps_material_map("side")));
    // The seeded heart: a dense scatter in a teardrop, in the garnish ramp. The DENSITY is what
    // reads as a fig; a few dots read as a plum.
    rps_append(_out, rps_map_roles(
        rps_scatter(0, RPS_GROUND - 0.165, 0.075, 0.098, 26, 0.013, _seed),
        rps_material_map("peel")));
    return _out;
}

/// A cluster of berries. Overlapping spheres with a highlight on each - the highlight is the
/// entire difference between a berry and a bead.
function rps_form_berries(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.66));
    var _st = rps_rng(_seed);
    // Back row first, then front, so the overlap builds depth in painter's order.
    for (var _row = 0; _row < 2; _row++) {
        var _n = (_row == 0) ? 4 : 3;
        for (var _i = 0; _i < _n; _i++) {
            var _x = -0.20 + _i * (0.40 / max(1, _n - 1)) + (_row == 1 ? 0.065 : 0);
            var _y = RPS_GROUND - 0.075 - _row * 0.085;
            var _r = 0.078 + rps_rng_next(_st) * 0.022;
            rps_append(_out, rps_boss(_x, _y, _r, 16));
            // ⭐ THE SPECULAR DOT. One small pale mark up and left on every berry, at the lamp
            // side. It is drawn in the flat `gloss` role, NOT in a ramp stop - a highlight is a
            // reflection of the lamp, not a lit face of the fruit, and shading it would make it
            // turn with the surface instead of staying where the light is.
            array_push(_out, rps_dot(_x - _r * 0.34, _y - _r * 0.38, _r * 0.24, "gloss"));
        }
    }
    return _out;
}

/// A wheel of citrus: the peel, the pith and the segments radiating from the centre.
function rps_form_citrus(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.56));
    var _cy = RPS_GROUND - 0.170;
    // Peel, then pith, then flesh: three concentric discs, each raised a little less, which gives
    // the slice a real edge profile instead of three flat rings.
    rps_append(_out, rps_map_roles(
        rps_raise(rps_ellipse_pts(0, _cy, 0.215, 0.205, 26), 0.030, 3, "m3"),
        rps_material_map("peel")));
    rps_append(_out, rps_raise(rps_ellipse_pts(0, _cy, 0.190, 0.180, 24), 0.014, 2, "m4"));
    rps_append(_out, rps_raise(rps_ellipse_pts(0, _cy, 0.172, 0.162, 24), 0.012, 2, "m2"));
    // ⭐ NINE SEGMENTS, NOT EIGHT AND NOT TWELVE. Citrus segment counts cluster around nine to
    // eleven; eight reads as a pie chart because the quarters line up with the axes, and twelve
    // is too fine to resolve at icon size. The dividing walls are incised, and each segment
    // carries two short strokes for the juice vesicles - count-carried tone again.
    for (var _i = 0; _i < 9; _i++) {
        var _a = RPS_TAU * (_i / 9) + 0.2;
        rps_append(_out, rps_incise([[0, _cy],
                                     [cos(_a) * 0.170, _cy + sin(_a) * 0.160]], false, 0.013));
        var _m = _a + RPS_TAU / 18;
        for (var _k = 0; _k < 2; _k++) {
            var _rr = 0.075 + _k * 0.055;
            array_push(_out, rps_poly([[cos(_m) * _rr, _cy + sin(_m) * _rr * 0.94],
                                       [cos(_m) * (_rr + 0.035),
                                        _cy + sin(_m) * (_rr + 0.035) * 0.94]],
                                      false, 0.006, "m4"));
        }
    }
    rps_append(_out, rps_raise(rps_ellipse_pts(0, _cy, 0.026, 0.024, 10), 0.008, 2, "m4"));
    return _out;
}

/// A drizzle of honey or syrup: a ribbon falling from above with a pool where it lands.
///
/// ⚠️ THIS IS THE ONE FORM THAT DELIBERATELY BREAKS THE GROUND RULE'S SPIRIT WHILE KEEPING ITS
/// LETTER. Its lowest point is on RPS_GROUND, as required - but that point is the POOL, and the
/// ribbon above it is meant to be read as falling from off the top of the box. It is the only
/// form in the corpus that is not a solid object, and it is here because a drizzle over a plated
/// dish is the single strongest "this was cooked with care" signal available.
function rps_form_drizzle(_seed) {
    var _out = [];
    var _st = rps_rng(_seed);
    // The pool, wide and shallow and glossy.
    rps_append(_out, rps_map_roles(
        [rps_fill(rps_blob_pts(0, RPS_GROUND - 0.030, 0.235, 0.048, 24, 0.16, _seed), "m2")],
        rps_material_map("sauce")));
    // Two falling ribbons at slightly different offsets, tapering as they fall - a real drizzle
    // thins as it stretches.
    for (var _i = 0; _i < 2; _i++) {
        var _x = -0.06 + _i * 0.10 + rps_rng_next(_st) * 0.03;
        rps_append(_out, rps_map_roles(
            rps_strand([_x, RPS_GROUND - 0.470], [_x + 0.055, RPS_GROUND - 0.240],
                       [_x - 0.020, RPS_GROUND - 0.045], 0.026, 0.014, "m3"),
            rps_material_map("sauce")));
    }
    // The gloss run down the lamp side of the thicker ribbon.
    array_push(_out, rps_ribbon(rps_qbez([-0.075, RPS_GROUND - 0.440],
                                         [-0.020, RPS_GROUND - 0.245],
                                         [-0.090, RPS_GROUND - 0.070], 12), 0.006, "gloss"));
    return _out;
}

/// A cut of honeycomb or a set curd square - a slab with an open cell structure on its face.
function rps_form_comb(_seed) {
    var _out = [];
    rps_append(_out, rps_contact(0, 0.64));
    var _slab = rps_round_rect_pts(-0.235, RPS_GROUND - 0.265, 0.235, RPS_GROUND - 0.020,
                                   0.030, 3);
    rps_append(_out, rps_raise(_slab, 0.040, 3, "m3"));
    // ⭐ A HEXAGONAL LATTICE ON A HALF-OFFSET GRID. The offset is the whole thing: hexagons on a
    // square grid leave visible gaps in rows and read as a mistake, while the half-offset packs
    // them and reads instantly as comb. Cells are SUNKEN, because a comb cell is a hole.
    for (var _r = 0; _r < 4; _r++) {
        var _n = (_r % 2 == 0) ? 4 : 3;
        for (var _c = 0; _c < _n; _c++) {
            var _x = -0.155 + _c * 0.103 + ((_r % 2 == 0) ? 0 : 0.052);
            var _y = RPS_GROUND - 0.225 + _r * 0.055;
            rps_append(_out, rps_sink(rps_star_pts(_x, _y, 0.046, 6, 0.5236), 0.014, 2, "m1"));
        }
    }
    return _out;
}
