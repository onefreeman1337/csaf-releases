/// REPAST - rps_bake. Renders the store sheets with the product's own draw functions.
///
/// ⭐ WHY THE GALLERY IS BAKED IN-ENGINE RATHER THAN DRAWN BY A SIDE PREVIEWER. A gallery rendered
/// by a re-implementation is a picture of the re-implementation. A sibling product in this wing
/// shipped a JS previewer whose defect was invisible in the previewer and plainly visible in
/// engine. Baking through the real functions lets the listing truthfully say "every image on this
/// page was rendered by the product itself", and makes that sentence checkable.
///
/// -- THE EXTENT CHECK, AND WHY ONE NUMBER IS NOT ENOUGH ----------------------------------------
/// ⛔ A SHEET FUNCTION RETURNING THE y IT FINISHED AT IS BLIND IN TWO DIRECTIONS. It answers only
/// "did the LAST thing drawn fall off the BOTTOM" - not whether anything ran off the RIGHT edge,
/// and not whether the sheet is mostly empty. Both blind spots have shipped in this wing while
/// the check reported ok: body copy cut mid-word at the right margin, and a surface 35% bare.
///
/// So this file measures the RENDERED PIXELS. buffer_get_surface plus a scan against the page
/// ground gives an ink bounding box, which answers clipping AND emptiness.
///
/// ⛔ AND THE INK BOX HAS TWO BLIND SPOTS OF ITS OWN, BOTH MEASURED IN THIS WING:
///   1. A STRIDE OF 2 MISSES A 1px FEATURE ON AN ODD ROW - including a title rule, which is
///      exactly the shape that lands on one row. y steps by 1 here. (x by 2 is fine: nothing
///      draws a 1px-wide vertical feature.)
///   2. A FLAT FILL CLOSE TO THE PAGE COLOUR IS NOT COUNTED AS INK, at any stride. A panel
///      running off the bottom in a near-ground colour reported ok. The defence is not a lower
///      tolerance - it is to SOLVE such panels' dimensions from the space available so they
///      cannot clip by construction.
///
/// ⛔ AND THE COVERAGE FLOOR NEEDS A SECOND BOX. A full-width rule under a title satisfies any
/// x-fill floor on its own, which turns the floor into decoration. `full` is used for the CLIP
/// test (a clipped hairline IS caught) and `content`, measured below the title band, for the
/// coverage floors.
/// ============================================================================================

#macro RPS_SHEET_W 1600
#macro RPS_SHEET_H 900

/// The band at the top of every sheet that holds the title. Coverage is measured BELOW it.
#macro RPS_TITLE_H 118

/// Ink bounds of a surface, as { full: [x0,y0,x1,y1], content: [...], any: bool }.
///
/// _ground is the page colour; a pixel counts as ink if any channel differs from it by more than
/// _tol. 10 per channel is the measured working value - low enough to catch a dark plate on a
/// dark page, high enough not to count compression noise.
function rps_bk_ink_bounds(_surf, _ground, _tol) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf);
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _surf, 0);

    var _gr = colour_get_red(_ground), _gg = colour_get_green(_ground),
        _gb = colour_get_blue(_ground);

    var _fx0 = _w, _fy0 = _h, _fx1 = -1, _fy1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;

    // ⛔ y STEPS BY 1. See the header: a 1px feature on an odd row is invisible to a stride of 2,
    // and a clipped hairline is precisely that shape.
    for (var _y = 0; _y < _h; _y += 1) {
        var _row = _y * _w * 4;
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = _row + _x * 4;
            var _r = buffer_peek(_buf, _o, buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_r - _gr) > _tol || abs(_g - _gg) > _tol || abs(_b - _gb) > _tol) {
                if (_x < _fx0) _fx0 = _x;
                if (_x > _fx1) _fx1 = _x;
                if (_y < _fy0) _fy0 = _y;
                if (_y > _fy1) _fy1 = _y;
                if (_y >= RPS_TITLE_H) {
                    if (_x < _cx0) _cx0 = _x;
                    if (_x > _cx1) _cx1 = _x;
                    if (_y < _cy0) _cy0 = _y;
                    if (_y > _cy1) _cy1 = _y;
                }
            }
        }
    }
    buffer_delete(_buf);
    return {
        full:    [_fx0, _fy0, _fx1, _fy1],
        content: [_cx0, _cy0, _cx1, _cy1],
        any:     (_fx1 >= 0),
    };
}

/// Judge one baked sheet. Returns a struct with a verdict and the numbers behind it.
///
/// ⚠️ THE x FLOOR IS HONESTLY WEAKER THAN THE y FLOOR AND THIS SAYS SO. A full-width rule would
/// satisfy an x-fill floor by itself, which is why coverage is measured on `content` rather than
/// `full` - but a sheet whose content genuinely spans the page will pass the x floor easily, so
/// the x floor earns most of its keep through the EDGE-CLIP test rather than through coverage.
function rps_bk_judge(_name, _surf, _ground) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf);
    var _ib = rps_bk_ink_bounds(_surf, _ground, 10);
    var _issues = [];

    if (!_ib.any) {
        array_push(_issues, "BLANK - no ink at all");
        return { name: _name, ok: false, issues: _issues, fillx: 0, filly: 0 };
    }

    var _margin = 6;
    if (_ib.full[0] < _margin) array_push(_issues, "clipped LEFT at x=" + string(_ib.full[0]));
    if (_ib.full[1] < _margin) array_push(_issues, "clipped TOP at y=" + string(_ib.full[1]));
    if (_ib.full[2] > _w - 1 - _margin)
        array_push(_issues, "clipped RIGHT: ink at x=" + string(_ib.full[2]) + " on a "
                   + string(_w) + "px surface");
    if (_ib.full[3] > _h - 1 - _margin)
        array_push(_issues, "clipped BOTTOM: ink at y=" + string(_ib.full[3]) + " on a "
                   + string(_h) + "px surface");

    var _fillx = 0, _filly = 0;
    if (_ib.content[2] >= 0) {
        _fillx = (_ib.content[2] - _ib.content[0]) / _w;
        _filly = (_ib.content[3] - _ib.content[1]) / (_h - RPS_TITLE_H);
        if (_fillx < 0.86) array_push(_issues, "content fills only "
                                      + string_format(_fillx * 100, 1, 0) + "% of the width");
        if (_filly < 0.80) array_push(_issues, "content fills only "
                                      + string_format(_filly * 100, 1, 0) + "% of the height");
    } else {
        array_push(_issues, "NO CONTENT below the title band");
    }

    return {
        name: _name, ok: (array_length(_issues) == 0), issues: _issues,
        fillx: _fillx, filly: _filly,
    };
}

/// A sheet title, drawn the same way on every sheet.
function rps_bk_title(_text, _sub, _pal) {
    draw_set_font(fnt_repast_title);
    // ⛔ rps_text_fit CENTRES ON THE x IT IS GIVEN. Passing a left edge here centres the string on
    // that edge and loses half of it off the page - four call sites in this studio have done it,
    // and one of them shipped a cover with its first letter missing.
    rps_text_fit(string_upper(_text), RPS_SHEET_W * 0.5, 34, RPS_SHEET_W - 160, 44,
                 _pal.label_sh, _pal.label);
    draw_set_font(fnt_repast);
    rps_text_fit(_sub, RPS_SHEET_W * 0.5, 88, RPS_SHEET_W - 240, 20, _pal.label_sh, _pal.crumb);
}

/// A captioned cell. Used by every grid sheet so the caption style cannot drift between them.
///
/// ⛔ TIGHT FIT, NOT BOX FIT, AND THE DIFFERENCE IS 40% OF THE PAGE. A form's ink occupies only
/// the lower half of its unit box, because the corpus anchors every form's contact line on
/// RPS_GROUND = 0.44 — so fitting the BOX into a cell throws away everything above it and leaves
/// the grid full of holes, which is CLAUDE.md §4.2b's complaint stated exactly. rps_render_in_rect_tight
/// fits the CONTENT, and rps_render's own header already says that is what it is for: "USE IT FOR
/// A DETACHED PIECE - one ingredient on a swatch sheet". The function existed and nothing called it.
///
/// ⚠️ AND THE NARROW VERSION OF THAT RULE IS THE TRUE ONE. An earlier draft of this comment said
/// tight fitting was "wrong for a whole plated dish" because it would destroy relative size. That
/// is over-drawn and it cost three layout rounds. Tight-fitting a WHOLE COMPOSITION scales every
/// component in it by ONE factor, so a quail egg is still smaller than a rib roast on the same
/// plate — which is the comparison that carries meaning. What must never be tight-fitted is an
/// INDIVIDUAL FORM inside a composition, because that is where the shared ground line and the
/// shared scale live. The plate sheets fit their content.
function rps_bk_cell(_parts, _pal, _label, _x, _y, _w, _h) {
    rps_render_in_rect_tight(_parts, _pal, _x + _w * 0.05, _y,
                             _w * 0.90, _h - 21, undefined);
    draw_set_font(fnt_repast);
    rps_text_fit(_label, _x + _w * 0.5, _y + _h - 20, _w - 8, 15, _pal.label_sh, _pal.crumb);
}

/// ============================================================================================
/// THE SHEETS
/// ============================================================================================

/// 1. The hero: one masterwork plate large on the left, the same recipe cooked three other ways
///    stacked on the right.
///
/// ⚠️ IT IS NOT ONE PLATE, AND IT CANNOT BE. A plate is 0.94 of a square unit box, so a single one
/// fitted to the height of a 1600x900 page reaches 47% of its width and leaves half the image
/// empty — measured, twice. Showing the same recipe at four points on its cook trajectory fills
/// the page AND makes the product's actual argument in one image, which one plate never could.
function rps_bk_sheet_hero(_pal) {
    var _book = rps_recipe_book();
    rps_bk_title("Repast", "every dish on this page was drawn by the product, from the recipe that made it", _pal);

    // ⛔ THE CHOP, NOT THE BIRD. The hero image must make the product's argument, and the argument
    // is a colour trajectory — so the subject has to be something whose colour a thumbnail can
    // carry. Poultry's chroma is 0.040, the lowest in the corpus after egg, so the roast bird's
    // three variants were three grey-brown lumps under three different captions. The chop has pink
    // meat, a cream fat rim, a pale bone and a green herb against a browning crust.
    var _r = _book[0];
    var _d = rps_dish_on(rps_recipe_cook(_r, _r.ideal, 1.0, 4), "porcelain", 0.1, 0.1);
    var _p = rps_palette_build(_d);
    // The hero plate across the TOP BAND, and the trajectory strip along the BOTTOM. A tall plate
    // beside a tall column left the lower-left quarter of the page empty - measured at 77% width
    // fill. A wide band over a wide band fills both axes, and reads in the order a viewer scans.
    rps_render_in_rect_tight(rps_plate_compose(_d), _p, 60, RPS_TITLE_H - 4, 1480, 470, undefined);

    // Raw to ruined, which is the range the captions actually claim.
    var _heats = [0.06, _r.ideal, 1.0];
    var _caps  = ["barely cooked", "the window", "taken too far"];
    for (var _i = 0; _i < 3; _i++) {
        var _v = rps_dish_on(rps_recipe_cook(_r, _heats[_i], 0, 4), "porcelain", 0.1, 0.1);
        var _vp = rps_palette_build(_v);
        var _x = 25 + _i * 520;
        rps_render_in_rect_tight(rps_plate_compose(_v), _vp, _x, 630, 500, 200, undefined);
        draw_set_font(fnt_repast);
        rps_text_fit(_caps[_i], _x + 255, 862, 470, 20, _pal.label_sh, _pal.crumb);
    }
    return _p;
}

/// 2. The corpus: all 46 authored forms in a grid. THE volume sheet.
function rps_bk_sheet_corpus(_pal) {
    rps_bk_title("Forty-six authored forms", "no sprites, no atlas, no texture page - every one is geometry", _pal);
    var _names = rps_corpus_names();
    var _n = array_length(_names);
    var _cols = 10, _rows = ceil(_n / _cols);
    var _cw = (RPS_SHEET_W - 80) / _cols;
    var _ch = (RPS_SHEET_H - RPS_TITLE_H - 40) / _rows;
    for (var _i = 0; _i < _n; _i++) {
        // ⛔ EACH FORM IN ITS OWN SUBSTANCE. Drawn through one shared palette every cell inherited
        // the same hero ramp, and the sheet was forty-six brown blobs — a carrot, a cabbage, an
        // egg and a fig all salmon. rps_corpus_spec() already knew what each form is made of and
        // nothing was reading it. Lightly cooked rather than raw, because that is how a buyer
        // will see most of them.
        var _spec = rps_corpus_spec(_names[_i]);
        var _p = variable_clone(_pal);
        rps_material_into(_p, "m",    _spec.mat, "roasted", 0.30, 0);
        rps_material_into(_p, "side", _spec.mat, "seared",  0.55, 0);
        rps_material_into(_p, "garn", "leaf",    "blanched", 0.4, 0);
        var _cx = 40 + (_i mod _cols) * _cw;
        var _cy = RPS_TITLE_H + 10 + floor(_i / _cols) * _ch;
        rps_bk_cell(rps_ingredient_form(_names[_i], _i * 13 + 1), _p, _names[_i],
                    _cx, _cy, _cw, _ch);
    }
}

/// 3. The cook model: one form, twelve methods. THE argument sheet.
function rps_bk_sheet_cooks(_pal) {
    rps_bk_title("One ingredient, twelve methods", "the cook state is a trajectory through colour, not a second picture", _pal);
    var _cooks = rps_cook_names();
    var _n = array_length(_cooks);
    // ⚠️ 6 x 2, DELIBERATELY A DIFFERENT GRID RHYTHM FROM THE RECIPES SHEET. At 4 x 3 the two
    // sheets hashed as duplicates (Kernel/capture/dedupe.js, d=8) even though their SUBJECTS are
    // completely different - twelve chops against twelve plated dishes - because a perceptual hash
    // keys hard on layout geometry and both sat on the same dark ground. Two gallery slots that
    // read as one picture waste a slot, and the fix is a genuinely different composition rather
    // than a looser threshold.
    var _cols = 6, _rows = ceil(_n / _cols);
    var _cw = (RPS_SHEET_W - 80) / _cols;
    var _ch = (RPS_SHEET_H - RPS_TITLE_H - 26) / _rows;
    for (var _i = 0; _i < _n; _i++) {
        // ⛔ CLONE A REAL PALETTE AND OVERRIDE THE RAMPS. An earlier version built a bare struct
        // listing the roles this sheet "needs" — and crashed in rps_bk_cell, which draws a caption
        // and therefore reads label_sh. The roles a callee reads are not knowable from the caller,
        // which is the same defect as a missing role string one layer up. Cloning cannot miss one.
        var _p = variable_clone(_pal);
        rps_material_into(_p, "m", "pork", _cooks[_i], rps_recipe_ideal(_cooks[_i]), 0);
        rps_material_into(_p, "side", "fat", _cooks[_i], rps_recipe_ideal(_cooks[_i]), 0);
        rps_ware_into(_p, "ware", "pewter", 0.3, 0);
        var _cx = 40 + (_i mod _cols) * _cw;
        var _cy = RPS_TITLE_H + 10 + floor(_i / _cols) * _ch;
        rps_bk_cell(rps_ingredient_form("chop", 3), _p, _cooks[_i], _cx, _cy, _cw, _ch);
    }
}

/// 4. The trajectory: TWO substances, five doneness steps each, under ONE law.
///
/// ⚠️ TWO ROWS, NOT ONE. A single substance across ten steps shows continuity; two substances
/// across five shows continuity AND that the same law starts from different colours, which is the
/// argument that actually distinguishes this from a set of pre-drawn stages. It is also what took
/// the sheet off the density gate's THIN list, which was the gate making the same point in its
/// own language.
function rps_bk_sheet_trajectory(_pal) {
    rps_bk_title("One law, two ingredients",
                 "every step between is a real colour, not a blend of two pictures", _pal);
    var _rows = 2, _cols = 5;
    var _subs  = ["dough", "beef"];
    var _forms = ["loaf",  "steak"];
    var _cw = (RPS_SHEET_W - 80) / _cols;
    var _ch = (RPS_SHEET_H - RPS_TITLE_H - 24) / _rows;
    for (var _r = 0; _r < _rows; _r++) {
        for (var _i = 0; _i < _cols; _i++) {
            var _t = _i / (_cols - 1);
            // Cloned, for the reason given in rps_bk_sheet_cooks.
            var _p = variable_clone(_pal);
            rps_material_into(_p, "m",    _subs[_r], "roasted", _t, 0);
            rps_material_into(_p, "side", "fat",     "roasted", _t, 0);
            var _cx = 40 + _i * _cw;
            var _cy = RPS_TITLE_H + 10 + _r * _ch;
            rps_bk_cell(rps_ingredient_form(_forms[_r], 8), _p,
                        _subs[_r] + "  -  doneness " + string_format(_t, 1, 2),
                        _cx, _cy, _cw, _ch);
        }
    }
}

/// 5. The vessels: the same dish on eight kinds of ware.
function rps_bk_sheet_wares(_pal) {
    rps_bk_title("Eight vessels", "the plate is generated too, and it is a wealth tell the player reads without a caption", _pal);
    var _book = rps_recipe_book();
    var _wares = rps_ware_names();
    var _n = array_length(_wares);
    var _cols = 4, _rows = 2;
    var _cw = (RPS_SHEET_W - 80) / _cols;
    var _ch = (RPS_SHEET_H - RPS_TITLE_H - 40) / _rows;
    for (var _i = 0; _i < _n; _i++) {
        var _d = rps_dish_on(rps_recipe_cook(_book[0], _book[0].ideal, 0.8, 21),
                             _wares[_i], (_i >= 4) ? 0.5 : 0.12, 0.3);
        var _p = rps_palette_build(_d);
        var _cx = 40 + (_i mod _cols) * _cw;
        var _cy = RPS_TITLE_H + 10 + floor(_i / _cols) * _ch;
        rps_render_in_rect_tight(rps_plate_compose(_d), _p, _cx + 6, _cy, _cw - 12, _ch - 26, undefined);
        draw_set_font(fnt_repast);
        rps_text_fit(_wares[_i], _cx + _cw * 0.5, _cy + _ch - 20, _cw - 8, 16,
                     _pal.label_sh, _pal.crumb);
    }
}

/// 6. The tiers: one recipe cooked five ways. THE "quality is visible" sheet.
function rps_bk_sheet_tiers(_pal) {
    rps_bk_title("Quality you can see", "garnish is earned, not declared - the same recipe at five tiers", _pal);
    var _book = rps_recipe_book();
    var _r = _book[0];
    // ⛔ THE HEATS ARE DERIVED FROM THE TIER BOUNDARIES, NOT GUESSED. Hand-picked offsets landed
    // on PLAIN, FINE, FINE, MASTERWORK, MASTERWORK - so a sheet captioned "the same recipe at five
    // tiers" showed three tiers with two duplicates, which is a false claim on a store image.
    // rps_recipe_tier bands the error at w, 2w, 3.4w and 5.2w where w = lerp(0.20, 0.075, diff),
    // so an error just inside each band is what actually produces each tier.
    var _w = lerp(0.20, 0.075, _r.difficulty);
    // ⚠️ THE RUINED CELL IS OVERCOOKED, NOT UNDERCOOKED. Both miss the window and both score 0,
    // but an undercooked ruin looks like a plain dish and a BURNT one looks ruined - and
    // rps_recipe_cook only forces the char trajectory when the error is on the hot side. A store
    // image captioned RUINED that is indistinguishable from the one captioned PLAIN teaches a
    // buyer nothing.
    var _heats = [min(1, _r.ideal + _w * 6.0), max(0, _r.ideal - _w * 4.2),
                  max(0, _r.ideal - _w * 2.6), max(0, _r.ideal - _w * 1.5), _r.ideal];
    var _tiers = rps_tier_names();
    // ⚠️ 3 + 2, NOT 5 ACROSS. One row of five plates leaves 45% of the page empty — measured.
    var _ch = (RPS_SHEET_H - RPS_TITLE_H - 30) / 2;
    for (var _i = 0; _i < 5; _i++) {
        var _row = (_i < 3) ? 0 : 1;
        var _col = (_i < 3) ? _i : (_i - 3);
        var _cols = (_row == 0) ? 3 : 2;
        var _cw = (RPS_SHEET_W - 80) / _cols;
        var _d = rps_recipe_cook(_r, _heats[_i], 0, 33);
        var _p = rps_palette_build(_d);
        var _cx = 40 + _col * _cw;
        var _cy = RPS_TITLE_H + 6 + _row * _ch;
        rps_render_in_rect_tight(rps_plate_compose(_d), _p, _cx + 6, _cy, _cw - 12, _ch - 32, undefined);
        draw_set_font(fnt_repast);
        rps_text_fit(string_upper(_tiers[_d.tier]) + "  -  " + string(array_length(_d.garn_forms))
                     + " garnish", _cx + _cw * 0.5, _cy + _ch - 26, _cw - 8, 19,
                     _pal.label_sh, _pal.label);
    }
}

/// 7. The starter book: twelve recipes, plated.
function rps_bk_sheet_recipes(_pal) {
    rps_bk_title("Twelve worked recipes", "a recipe stores a method, not a picture - the dish is computed from how it was cooked", _pal);
    var _book = rps_recipe_book();
    var _n = array_length(_book);
    var _cols = 4, _rows = 3;
    var _cw = (RPS_SHEET_W - 80) / _cols;
    var _ch = (RPS_SHEET_H - RPS_TITLE_H - 40) / _rows;
    for (var _i = 0; _i < _n; _i++) {
        var _d = rps_recipe_cook(_book[_i], _book[_i].ideal, 0.9, _i * 17 + 2);
        var _p = rps_palette_build(_d);
        var _cx = 40 + (_i mod _cols) * _cw;
        var _cy = RPS_TITLE_H + 10 + floor(_i / _cols) * _ch;
        rps_render_in_rect_tight(rps_plate_compose(_d), _p, _cx + 6, _cy, _cw - 12, _ch - 24, undefined);
        draw_set_font(fnt_repast);
        rps_text_fit(_book[_i].name, _cx + _cw * 0.5, _cy + _ch - 18, _cw - 8, 16,
                     _pal.label_sh, _pal.crumb);
    }
}

/// 8. Spoilage: one dish, six ages.
function rps_bk_sheet_spoilage(_pal) {
    rps_bk_title("Food that goes off", "spoilage is visible or it is not a mechanic - the garnish wilts and the steam stops", _pal);
    var _book = rps_recipe_book();
    var _base = rps_recipe_cook(_book[7], _book[7].ideal, 1.0, 44);
    // ⚠️ 3 x 2, NOT 6 ACROSS - same measurement as the tiers sheet.
    var _cols = 3;
    var _cw = (RPS_SHEET_W - 80) / _cols;
    var _ch = (RPS_SHEET_H - RPS_TITLE_H - 30) / 2;
    for (var _i = 0; _i < 6; _i++) {
        var _d = rps_dish_age(_base, _i * 2.0, 9);
        var _p = rps_palette_build(_d);
        var _cx = 40 + (_i mod _cols) * _cw;
        var _cy = RPS_TITLE_H + 6 + floor(_i / _cols) * _ch;
        rps_render_in_rect_tight(rps_plate_compose(_d), _p, _cx + 6, _cy, _cw - 12, _ch - 32, undefined);
        draw_set_font(fnt_repast);
        rps_text_fit("freshness " + string_format(_d.freshness, 1, 2),
                     _cx + _cw * 0.5, _cy + _ch - 26, _cw - 8, 18, _pal.label_sh, _pal.crumb);
    }
}

/// How far off the window slot _i of the book page is cooked, in multiples of the tier band.
/// Spread across the tiers on purpose - see rps_bk_sheet_book.
function rps_bk_book_offset(_i) {
    var _t = [0.0, 1.5, 2.6, 0.0, 4.2, 1.5, 2.6, 0.0];
    return _t[_i mod array_length(_t)];
}

/// 9. In context: a recipe book page, drawn in the package's own UI chrome.
///
/// ⚠️ EVERYTHING HERE IS IN PIXEL COORDINATES AND RENDERED RAW. rps_render_parts_raw draws a part
/// list exactly as given, so handing the UI builders sheet pixels and rendering without a
/// transform is the honest way to lay out an interface — no scale factor to get wrong, and the
/// bevel depths are the pixel depths you asked for.
function rps_bk_sheet_book(_pal) {
    rps_bk_title("In your game", "the interface is bevelled by the same light as the food - no windowskin, no nine-slice", _pal);

    var _book = rps_recipe_book();
    var _uimap = rps_material_map("ui");

    // The page.
    rps_render_parts_raw(rps_map_roles(rps_ui_panel(36, RPS_TITLE_H - 4, 1564, 872, 26, 16, "panel"),
                                       _uimap), _pal);

    // Eight slots, two rows of four.
    for (var _i = 0; _i < 8; _i++) {
        var _col = _i mod 4, _row = floor(_i / 4);
        var _x0 = 74 + _col * 366;
        var _y0 = RPS_TITLE_H + 34 + _row * 372;
        var _x1 = _x0 + 330;
        var _y1 = _y0 + 300;

        rps_render_parts_raw(rps_map_roles(rps_ui_well(_x0, _y0, _x1, _y1, 18, 11, "felt"),
                                           _uimap), _pal);

        // ⚠️ THE TIERS VARY ACROSS THE PAGE. Cooking all eight at the ideal made every slot read
        // MASTERWORK, which shows the layout and wastes the tier system - a buyer looking at an
        // inventory wants to see that a mediocre meal and a great one are different objects in it.
        var _off = rps_bk_book_offset(_i) * lerp(0.20, 0.075, _book[_i].difficulty);
        var _d = rps_recipe_cook(_book[_i], clamp(_book[_i].ideal - _off, 0, 1), 0, _i * 29 + 6);
        var _p = rps_palette_build(_d);
        rps_render_in_rect_tight(rps_plate_compose(_d), _p,
                                 _x0 + 16, _y0 + 14, _x1 - _x0 - 32, _y1 - _y0 - 74, undefined);

        // The readout: name, tier, and the derived buff - the same three things the demo shows.
        var _tiers = rps_tier_names();
        var _b = rps_dish_buff(_d);
        draw_set_font(fnt_repast);
        rps_text_fit(_book[_i].name, (_x0 + _x1) * 0.5, _y1 - 52, _x1 - _x0 - 24, 21,
                     _pal.label_sh, _pal.label);
        rps_text_fit(string_upper(_tiers[_d.tier]) + "   nourish "
                     + string_format(_b.nourish, 1, 1) + "   vigour "
                     + string_format(_b.vigour, 1, 1),
                     (_x0 + _x1) * 0.5, _y1 - 24, _x1 - _x0 - 24, 16, _pal.label_sh, _pal.crumb);
    }
}

/// ============================================================================================
/// THE STORE GIF
///
/// Renders a ping-pong sweep of one dish along its cook trajectory as numbered PNGs, for ffmpeg
/// to assemble. Same surface path as the sheets, so the frames are exact product output.
/// ============================================================================================
#macro RPS_GIF_W 760
#macro RPS_GIF_H 470
#macro RPS_GIF_N 44

/// Zero-pad an integer to three digits. Built by arithmetic rather than by padding a formatted
/// string, so there is no whitespace to replace and no way for the one-vs-all bug to come back.
function rps_pad3(_n) {
    var _v = clamp(floor(_n), 0, 999);
    return string(floor(_v / 100)) + string(floor((_v mod 100) / 10)) + string(_v mod 10);
}

function rps_frames_run() {
    var _book = rps_recipe_book();
    var _r = _book[0];
    var _tiers = rps_tier_names();
    var _base = rps_palette_build(rps_recipe_cook(_r, _r.ideal, 0, 1));

    for (var _f = 0; _f < RPS_GIF_N; _f++) {
        // Ping-pong: 0 -> 1 -> 0 across the frame count, so the loop has no snap.
        var _u = _f / (RPS_GIF_N - 1);
        var _t = (_u <= 0.5) ? (_u * 2) : (2 - _u * 2);
        var _heat = 0.04 + _t * 0.96;

        var _d = rps_dish_on(rps_recipe_cook(_r, _heat, 0, 4), "porcelain", 0.1, 0.1);
        var _p = rps_palette_build(_d);

        var _s = surface_create(RPS_GIF_W, RPS_GIF_H);
        surface_set_target(_s);
        draw_clear_alpha(_base.ground, 1);

        rps_render_in_rect_tight(rps_plate_compose(_d), _p, 20, 8, RPS_GIF_W - 40,
                                 RPS_GIF_H - 96, undefined);

        // The dial, drawn in the package's own UI furniture so the GIF also shows the chrome.
        var _tx0 = 90, _tx1 = RPS_GIF_W - 90, _ty = RPS_GIF_H - 74;
        rps_render_parts_raw(rps_map_roles(rps_ui_well(_tx0, _ty, _tx1, _ty + 16, 8, 5, "felt"),
                                           rps_material_map("ui")), _base);
        var _kx = lerp(_tx0 + 10, _tx1 - 10, _heat);
        rps_render_parts_raw(rps_map_roles(rps_ui_panel(_kx - 9, _ty - 5, _kx + 9, _ty + 21,
                                                        8, 6, "panel"),
                                           rps_material_map("ui")), _base);

        draw_set_font(fnt_repast);
        rps_text_fit("heat " + string_format(_heat, 1, 2) + "      "
                     + string_upper(_tiers[_d.tier]) + "      "
                     + string(array_length(_d.garn_forms)) + " garnish",
                     RPS_GIF_W * 0.5, RPS_GIF_H - 34, RPS_GIF_W - 60, 19,
                     _base.label_sh, _base.label);

        surface_reset_target();
        // ⛔ string_replace REPLACES ONE OCCURRENCE. string_replace_all REPLACES ALL. This line
        // used the first, so string_format(_f, 3, 0) -> "  0" became "0 0" and the frames landed
        // as frame_0 0.png. MEASURED 2026-08-30: ffmpeg could find no sequence, and the frame
        // COUNT check upstream still read 44 of 44 - because it globbed frame_*.png and counted
        // correctly while every name was wrong. Counting the work is necessary and not
        // sufficient; the shape of what was produced has to be looked at too.
        surface_save(_s, "frame_" + rps_pad3(_f) + ".png");
        surface_free(_s);
    }

    var _fh = file_text_open_write("rps_frames.json");
    file_text_write_string(_fh, "{\"frames\":" + string(RPS_GIF_N)
        + ",\"w\":" + string(RPS_GIF_W) + ",\"h\":" + string(RPS_GIF_H) + "}");
    file_text_close(_fh);
}

/// ============================================================================================
/// THE RUNNER
///
/// ⛔ NOT CALLABLE FROM A DRAW EVENT. surface_set_target inside a draw event nests render targets,
/// and on some drivers that silently produces an EMPTY surface rather than an error - which would
/// save eight blank PNGs and report success. It is called from Create, before the first draw.
/// ============================================================================================
function rps_bake_run() {
    var _pal = rps_palette_build(rps_recipe_cook(rps_recipe_book()[0], 0.7, 0.5, 1));
    var _sheets = ["hero", "corpus", "cooks", "trajectory", "wares", "tiers", "recipes",
                   "spoilage", "book"];
    var _report = "";
    var _bad = 0;

    for (var _i = 0; _i < array_length(_sheets); _i++) {
        var _s = surface_create(RPS_SHEET_W, RPS_SHEET_H);
        surface_set_target(_s);
        draw_clear_alpha(_pal.ground, 1);

        switch (_sheets[_i]) {
            case "hero":       rps_bk_sheet_hero(_pal);       break;
            case "corpus":     rps_bk_sheet_corpus(_pal);     break;
            case "cooks":      rps_bk_sheet_cooks(_pal);      break;
            case "trajectory": rps_bk_sheet_trajectory(_pal); break;
            case "wares":      rps_bk_sheet_wares(_pal);      break;
            case "tiers":      rps_bk_sheet_tiers(_pal);      break;
            case "recipes":    rps_bk_sheet_recipes(_pal);    break;
            case "spoilage":   rps_bk_sheet_spoilage(_pal);   break;
            case "book":       rps_bk_sheet_book(_pal);       break;
        }

        // ⚠️ JUDGED WHILE THE SURFACE IS STILL THE TARGET IS WRONG - buffer_get_surface reads the
        // surface, not the target, but resetting first is the honest order and costs nothing.
        surface_reset_target();

        var _v = rps_bk_judge(_sheets[_i], _s, _pal.ground);
        surface_save(_s, "sheet_" + string(_i + 1) + "_" + _sheets[_i] + ".png");
        surface_free(_s);

        if (_i > 0) _report += ",";
        _report += "{\"name\":\"" + _v.name + "\",\"ok\":" + (_v.ok ? "true" : "false")
                 + ",\"fillx\":" + string_format(_v.fillx, 1, 3)
                 + ",\"filly\":" + string_format(_v.filly, 1, 3)
                 + ",\"issues\":\"";
        for (var _k = 0; _k < array_length(_v.issues); _k++) {
            if (_k > 0) _report += "; ";
            _report += string_replace_all(_v.issues[_k], "\"", "'");
        }
        _report += "\"}";
        if (!_v.ok) _bad += 1;
    }

    var _f = file_text_open_write("rps_bake.json");
    file_text_write_string(_f, "{\"sheets\":" + string(array_length(_sheets))
        + ",\"bad\":" + string(_bad) + ",\"results\":[" + _report + "]}");
    file_text_close(_f);
}
