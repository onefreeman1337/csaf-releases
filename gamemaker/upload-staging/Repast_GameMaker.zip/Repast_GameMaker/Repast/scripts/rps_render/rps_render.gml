/// REPAST - rps_render. Part of the shared drawing foundation.
///
/// This file is the studio's cross-product drawing/colour layer, carried forward with more
/// than 2,300 in-engine assertions behind it - including the GML default-epsilon fix
/// described below, which had produced a suite of assertions that could never go red.
///
/// ⛔ GML APPLIES A DEFAULT EPSILON TO NUMERIC COMPARISONS, and it is 0.00001 on this runtime
/// - MEASURED by rps_selftest, which prints math_get_epsilon() into its own result file at
/// twelve decimals. Any tolerance at or below about 0.00001 can NEVER fire, in either
/// direction, so a distinctness assertion written that way passes vacuously forever and an
/// equality assertion written that way goes red on two values that are the same object.
/// Never write one here. And GML has no exponent-literal syntax at all: `1e-5` is a lexer
/// error that reads like a bracket bug.
///
/// The ONLY file in this package that talks to the GPU.
///
/// Everything above it produces PART LISTS - arrays of {kind, points, role} structs in a
/// unit box - and everything a buyer might want to change lives there. This file turns a
/// part list into draw calls, resolves a role against a surface, and does nothing else.
///
/// ⛔ THE STROKE FLOOR IS 1.0 PIXEL AND IT IS NOT NEGOTIABLE. draw_line_width lays down an
/// unantialiased quad, so a 0.55px stroke rasterises to a row of pixels on some scanlines
/// and nothing on others: a field of tone turns into a field of dashes. Anything that needs
/// to read finer than a pixel must carry its gradient in HOW MANY strokes and HOW FAR each
/// runs, never in how wide they are. On this product that law decides how grill marks, scoring,
/// crumb and the fibres in a cut of meat are drawn - they are the fine detail on every dish,
/// and every one of them is carried by COUNT and LENGTH.
/// ============================================================================================
#macro RPS_MIN_STROKE 1.0

/// How many segments an arc is sampled at per full turn.
#macro RPS_ARC_SEGS 48

/// ============================================================================================
/// SURFACE LOOKUP
/// ============================================================================================

function rps_render_colour(_pal, _role) {
    if (variable_struct_exists(_pal, _role)) return variable_struct_get(_pal, _role);
    return _pal.line;
}

/// ============================================================================================
/// FITTING
/// ============================================================================================

/// Where to put the unit box so it fits (_x,_y,_w,_h) without distortion.
///
/// UNIFORM SCALE, ALWAYS. Mapping x by width and y by height independently would fill an oblong
/// slot exactly and turn every circle in the package into an ellipse - which on a product whose
/// forms are told apart by their outlines is not a cosmetic problem. A rim curve IS the
/// difference between a shallow bowl and a deep one, and a non-uniform scale changes every
/// curve in the corpus by the slot it happened to be drawn into. A form that does not fill
/// its slot is correct; a stretched one is a defect.
function rps_render_fit(_x, _y, _w, _h) {
    var _s = min(_w, _h);
    return { cx: _x + _w * 0.5, cy: _y + _h * 0.5, s: _s };
}

/// ============================================================================================
/// THE FIVE PRIMITIVES
/// ============================================================================================

function rps_render_poly(_pts, _closed, _w) {
    var _n = array_length(_pts);
    if (_n < 2) return;
    var _ww = max(RPS_MIN_STROKE, _w);
    for (var _i = 0; _i < _n - 1; _i++) {
        draw_line_width(_pts[_i][0], _pts[_i][1], _pts[_i + 1][0], _pts[_i + 1][1], _ww);
    }
    if (_closed) draw_line_width(_pts[_n - 1][0], _pts[_n - 1][1], _pts[0][0], _pts[0][1], _ww);
}

/// Fill a triangle fan. The caller is responsible for the outline being star-shaped about pts[0];
/// rps_ring_fill is the helper that guarantees it and closes the final wedge.
function rps_render_fill(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return;
    draw_primitive_begin(pr_trianglefan);
    for (var _i = 0; _i < _n; _i++) draw_vertex(_pts[_i][0], _pts[_i][1]);
    draw_primitive_end();
}

/// Fill a triangle strip between two rails. A rail-length mismatch draws NOTHING rather than the
/// overlapping part: a strip whose rails disagree means the producer's two loops disagree, and
/// drawing the common prefix would render a plausible half-shape and hide the defect.
function rps_render_strip(_a, _b) {
    var _n = array_length(_a);
    if (_n < 2 || array_length(_b) != _n) return;
    draw_primitive_begin(pr_trianglestrip);
    for (var _i = 0; _i < _n; _i++) {
        draw_vertex(_a[_i][0], _a[_i][1]);
        draw_vertex(_b[_i][0], _b[_i][1]);
    }
    draw_primitive_end();
}

function rps_render_arc(_cx, _cy, _r, _a0, _a1, _w) {
    var _sweep = abs(_a1 - _a0);
    var _segs = max(3, ceil(RPS_ARC_SEGS * _sweep / RPS_TAU));
    var _ww = max(RPS_MIN_STROKE, _w);
    var _px = _cx + cos(_a0) * _r, _py = _cy + sin(_a0) * _r;
    for (var _i = 1; _i <= _segs; _i++) {
        var _a = _a0 + (_a1 - _a0) * (_i / _segs);
        var _qx = _cx + cos(_a) * _r, _qy = _cy + sin(_a) * _r;
        draw_line_width(_px, _py, _qx, _qy, _ww);
        _px = _qx; _py = _qy;
    }
}

/// ============================================================================================
/// THE DRAW LOOP
/// ============================================================================================

function rps_render_part(_p, _pal) {
    draw_set_colour(rps_render_colour(_pal, _p.role));
    switch (_p.kind) {
        case RPS_DOT:   draw_circle(_p.cx, _p.cy, max(0.5, _p.r), false);       break;
        case RPS_ARC:   rps_render_arc(_p.cx, _p.cy, _p.r, _p.a0, _p.a1, _p.w); break;
        case RPS_FILL:  rps_render_fill(_p.pts);                                break;
        case RPS_STRIP: rps_render_strip(_p.a, _p.b);                           break;
        default:        rps_render_poly(_p.pts, _p.closed, _p.w);               break;
    }
}

function rps_render_parts_raw(_parts, _pal) {
    var _n = array_length(_parts);
    for (var _i = 0; _i < _n; _i++) rps_render_part(_parts[_i], _pal);
}

/// Place a unit-box part list at (_cx,_cy) at scale _s and draw it.
///
/// _rot, _wscale and _map are optional. _wscale defaults to _s, which is the constant-PROPORTION
/// rule the primitive layer's header argues for: holding stroke weight constant in screen space
/// instead made a thumbnail-scale form's incisions 32% of its own width while a hero-scale one's were
/// 6%, so small forms rendered as solid blobs.
function rps_render_parts(_parts, _pal, _cx, _cy, _s, _rot, _wscale, _map) {
    var _r  = is_undefined(_rot)    ? 0  : _rot;
    var _ws = is_undefined(_wscale) ? _s : _wscale;
    rps_render_parts_raw(rps_place(_parts, _cx, _cy, _s, _r, _ws, _map), _pal);
}

function rps_render_in_rect(_parts, _pal, _x, _y, _w, _h, _rot, _map) {
    var _fit = rps_render_fit(_x, _y, _w, _h);
    rps_render_parts(_parts, _pal, _fit.cx, _fit.cy, _fit.s, _rot, _fit.s, _map);
}

/// ============================================================================================
/// MEASUREMENT - what the self-test asserts against
/// ============================================================================================

/// The bounding box of a part list in unit-box space, as [x0, y0, x1, y1].
///
/// It walks the ACTUAL VERTICES rather than a form's declared extents, and that is the point: a
/// declared extent is a claim and the vertices are evidence. Containment failures in this wing have
/// twice been a builder whose stated half width was right and whose geometry had drifted.
function rps_render_bounds(_parts) {
    var _n = array_length(_parts);
    var _x0 = 999, _y0 = 999, _x1 = -999, _y1 = -999;
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case RPS_DOT: {
                _x0 = min(_x0, _p.cx - _p.r); _x1 = max(_x1, _p.cx + _p.r);
                _y0 = min(_y0, _p.cy - _p.r); _y1 = max(_y1, _p.cy + _p.r);
            } break;
            case RPS_ARC: {
                _x0 = min(_x0, _p.cx - _p.r - _p.w); _x1 = max(_x1, _p.cx + _p.r + _p.w);
                _y0 = min(_y0, _p.cy - _p.r - _p.w); _y1 = max(_y1, _p.cy + _p.r + _p.w);
            } break;
            case RPS_STRIP: {
                for (var _k = 0; _k < array_length(_p.a); _k++) {
                    _x0 = min(_x0, _p.a[_k][0]); _x1 = max(_x1, _p.a[_k][0]);
                    _y0 = min(_y0, _p.a[_k][1]); _y1 = max(_y1, _p.a[_k][1]);
                }
                for (var _k = 0; _k < array_length(_p.b); _k++) {
                    _x0 = min(_x0, _p.b[_k][0]); _x1 = max(_x1, _p.b[_k][0]);
                    _y0 = min(_y0, _p.b[_k][1]); _y1 = max(_y1, _p.b[_k][1]);
                }
            } break;
            case RPS_FILL: {
                for (var _k = 0; _k < array_length(_p.pts); _k++) {
                    _x0 = min(_x0, _p.pts[_k][0]); _x1 = max(_x1, _p.pts[_k][0]);
                    _y0 = min(_y0, _p.pts[_k][1]); _y1 = max(_y1, _p.pts[_k][1]);
                }
            } break;
            default: {
                var _hw = _p.w * 0.5;
                for (var _k = 0; _k < array_length(_p.pts); _k++) {
                    _x0 = min(_x0, _p.pts[_k][0] - _hw); _x1 = max(_x1, _p.pts[_k][0] + _hw);
                    _y0 = min(_y0, _p.pts[_k][1] - _hw); _y1 = max(_y1, _p.pts[_k][1] + _hw);
                }
            } break;
        }
    }
    return [_x0, _y0, _x1, _y1];
}

/// Fit a part list's ACTUAL CONTENT into a rectangle rather than fitting the unit box.
///
/// ⚠️ USE IT FOR A DETACHED PIECE - one ingredient on a swatch sheet, a single garnish in a
/// catalogue cell, a lone plate. A WHOLE PLATED DISH must go through rps_render_in_rect, because
/// the unit box is the frame the corpus is authored in and the GROUND LINE inside it is shared.
/// Tight fitting a whole dish makes a single quail egg and a standing rib roast the same height on
/// screen and stands them on different lines, which destroys the two proportions that say "this is
/// a feast" - relative size, and a plate that shares one surface.
function rps_render_fit_parts(_parts, _x, _y, _w, _h) {
    var _bb = rps_render_bounds(_parts);
    var _bw = max(0.0001, _bb[2] - _bb[0]);
    var _bh = max(0.0001, _bb[3] - _bb[1]);
    var _s = min(_w / _bw, _h / _bh);
    var _mx = (_bb[0] + _bb[2]) * 0.5;
    var _my = (_bb[1] + _bb[3]) * 0.5;
    return { cx: _x + _w * 0.5 - _mx * _s, cy: _y + _h * 0.5 - _my * _s, s: _s };
}

function rps_render_in_rect_tight(_parts, _pal, _x, _y, _w, _h, _map) {
    var _f = rps_render_fit_parts(_parts, _x, _y, _w, _h);
    rps_render_parts(_parts, _pal, _f.cx, _f.cy, _f.s, 0, _f.s, _map);
}

/// ============================================================================================
/// MADE LETTERING
///
/// ⛔ TEXT IS THE ONE THING IN THIS PACKAGE THAT IS NOT GEOMETRY, and it still has to look made.
/// The trick is the same two-pass emboss the relief engine uses on a groove: draw the string once
/// offset AWAY from the lamp in the material's deepest stop, then again in place in its brightest.
/// Two draw calls, and the label reads as metal rather than as a caption laid over a picture of
/// metal.
///
/// ⚠️ EVERY STRING IN THIS FILE IS MEASURED AND SCALED TO ITS SPACE. Wings/GameMaker/CLAUDE.md
/// records this wing shipping the SAME overflow defect twice - "WickthorSt Cuthman's" on one
/// product and "HEDGEHOG FUNGUSCAULIFLOWER FUNGUS" on the next - because the first fix shortened
/// the DATA instead of making the caption honest about its width. Form names come from the
/// BUYER's game and cannot be shortened by us at all, so nothing here is allowed to assume a
/// length. No ink check will ever catch an overflow: overprinted text is ink exactly where ink
/// belongs.
/// ============================================================================================

/// The emboss offset for lettering, in pixels, at a given nominal size.
function rps_text_relief(_px) {
    return max(1, round(_px * 0.085));
}

/// One line of made text, centred at (_x,_y), scaled DOWN if it will not fit _maxw.
///
/// Returns the scale actually used, so a caller that cares can notice it was shrunk.
/// ⛔ _x AND _y ARE THE CENTRE OF THE STRING, NOT ITS TOP LEFT, AND THREE CALL SITES IN THIS
/// PACKAGE GOT THAT WRONG AT ONCE. halign is CENTRE and valign is MIDDLE below - which is right for
/// a title, and is the opposite convention to rps_text_line and rps_text_body two functions away.
/// Passing a left edge to it centres the string ON that edge, so half of it leaves the frame: a product cover lost its first letter, a wordmark hung off its header panel, and the
/// ledger heading floated over the top of a recessed well. All three looked like layout arithmetic
/// and all three were this. If you are passing a left edge, you want rps_text_line.
function rps_text_fit(_text, _x, _y, _maxw, _px, _col_shadow, _col_face) {
    draw_set_font(fnt_repast_title);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    var _o = rps_text_relief(_px);
    draw_set_colour(_col_shadow);
    draw_text_transformed(_x - RPS_LX * _o, _y - RPS_LY * _o, _text, _sc, _sc, 0);
    draw_set_colour(_col_face);
    draw_text_transformed(_x, _y, _text, _sc, _sc, 0);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    return _sc;
}

/// A label made around an arc, one glyph at a time.
///
/// _a_mid is the angle the middle of the string sits at (-RPS_TAU/4 is the top of the form) and
/// _sweep is how much of the circle the whole string may occupy. The string is laid out by ADVANCE
/// so that letter spacing is even in ARC LENGTH - spacing the glyphs evenly in ANGLE instead
/// bunches the narrow letters and was the first thing this looked wrong doing.
///
/// ⚠️ THE ROTATION IS DERIVED, NOT GUESSED. GML's draw_text_transformed takes DEGREES and rotates
/// counter-clockwise on a y-DOWN screen, so a glyph's own x-axis lands at (cos t, -sin t). The
/// tangent to the circle at angle a is (-sin a, cos a). Solving the two gives
/// t = atan2(-cos a, -sin a), which is checkable in one place: at the top of the form a is
/// -TAU/4, the tangent is (1,0), and t comes out 0.
function rps_text_arc(_text, _cx, _cy, _r, _a_mid, _sweep, _px, _col_shadow, _col_face) {
    var _n = string_length(_text);
    if (_n <= 0 || _r <= 0) return 0;
    draw_set_font(fnt_repast_title);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _total = 0;
    for (var _i = 1; _i <= _n; _i++) _total += string_width(string_char_at(_text, _i)) * _sc;
    var _arc = _r * _sweep;
    if (_total > _arc && _total > 0) {
        _sc *= _arc / _total;
        _total = _arc;
    }

    var _o = rps_text_relief(_px);
    var _run = 0;
    for (var _i = 1; _i <= _n; _i++) {
        var _ch = string_char_at(_text, _i);
        var _cw = string_width(_ch) * _sc;
        // Centre of this glyph along the run, converted to an angle about the form's centre.
        var _a = _a_mid + ((_run + _cw * 0.5) - _total * 0.5) / _r;
        var _t = radtodeg(arctan2(-cos(_a), -sin(_a)));
        var _px2 = _cx + cos(_a) * _r, _py2 = _cy + sin(_a) * _r;
        draw_set_colour(_col_shadow);
        draw_text_transformed(_px2 - RPS_LX * _o, _py2 - RPS_LY * _o, _ch, _sc, _sc, _t);
        draw_set_colour(_col_face);
        draw_text_transformed(_px2, _py2, _ch, _sc, _sc, _t);
        _run += _cw;
    }
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    return _sc;
}

/// A wrapped block of body copy, in the plain face, left aligned. No emboss: paragraph text made
/// in relief is unreadable, and the panels this appears on are paper, not metal.
function rps_text_body(_text, _x, _y, _w, _px, _col) {
    draw_set_font(fnt_repast);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_colour(_col);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    draw_text_ext_transformed(_x, _y, _text, _base * 1.34, _w / _sc, _sc, _sc, 0);
    return string_height_ext(_text, _base * 1.34, _w / _sc) * _sc;
}

/// One line of plain text, left aligned, scaled to fit.
/// A LEFT-ANCHORED label drawn as a light face over a dark shadow.
///
/// ⛔ THIS EXISTS BECAUSE rps_text_fit IS CENTRE-ANCHORED AND rps_text_line IS LEFT-ANCHORED, AND
/// SWAPPING ONE FOR THE OTHER SILENTLY MOVES EVERY CAPTION BY HALF ITS OWN WIDTH.
/// MEASURED 2026-08-28 on a sibling product in this series (the receipt is kept verbatim rather
/// than reworded, because a defect this quiet is only believable with its evidence attached): a fix
/// for caption CONTRAST swapped rps_text_line for rps_text_fit, which solved the contrast and
/// clipped every left-edge caption on the store sheets off the page - the hero sheet read
/// "atch, cob, one storey". The two functions differ in two ways at once and only one of them is
/// in their names, so the trap is in the API, not in the caller.
///
/// The shadow is offset along the same lamp vector as every bevel in the package, so a label reads
/// as struck into the page rather than as text with a drop shadow bolted on.
function rps_text_label(_text, _x, _y, _maxw, _px, _col_shadow, _col_face) {
    draw_set_font(fnt_repast_title);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    var _o = rps_text_relief(_px);
    draw_set_colour(_col_shadow);
    draw_text_transformed(_x - RPS_LX * _o, _y - RPS_LY * _o, _text, _sc, _sc, 0);
    draw_set_colour(_col_face);
    draw_text_transformed(_x, _y, _text, _sc, _sc, 0);
    return _sc;
}

function rps_text_line(_text, _x, _y, _maxw, _px, _col, _bold) {
    draw_set_font(_bold ? fnt_repast_title : fnt_repast);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_colour(_col);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    draw_text_transformed(_x, _y, _text, _sc, _sc, 0);
    return _sc;
}

/// ============================================================================================
/// SCREEN EFFECTS - the only alpha-blended draws in the package, and they live here
///
/// ⚠️ THE PART PATH DELIBERATELY HAS NO ALPHA. A role resolves to a colour, and that is the whole
/// contract - it is what lets the relief engine reason about five discrete values and what stops a
/// buyer's own blend mode changing what a form looks like. The readout flash and the shock ring
/// genuinely need blending, so they are written here as two named functions that set alpha and put
/// it back, rather than as loose draw calls in the toast where the next edit would forget the
/// second half.
/// ============================================================================================

/// A soft radial flash, drawn as a few nested discs of falling alpha.
///
/// Nested discs rather than a gradient sprite, because this package ships no sprite of any kind
/// and a genuine radial gradient in GML needs a texture or a shader. Six rings is enough that the
/// banding is invisible at the sizes this is used, and it is checked by looking.
/// ⛔ LARGEST DISC FIRST, SMALLEST LAST, AND THE FIRST VERSION HAD IT BACKWARDS. MEASURED BY LOOKING
/// at the strike sheet: drawn smallest-first, every dim outer disc is painted straight over the
/// bright core, so the whole thing flattens into a uniform grey donut - the exact opposite of a
/// flash. Painter's order is not a detail when the layers are translucent; it IS the gradient.
/// ⚠️ TWELVE DISCS, AND SIX LEFT VISIBLE BANDING. On a near-black page each step in the stack shows
/// as a concentric ring, and six of them read as a target rather than as a glow. Doubling the count
/// and halving the per-disc alpha costs nothing measurable and the banding goes. It is still a step
/// function - a true radial gradient needs a texture or a shader, and this package ships neither -
/// but at twelve steps the step is under two per cent of the range and invisible at any size the
/// flash is drawn at.
function rps_render_flash(_cx, _cy, _r, _col, _alpha) {
    if (_alpha <= 0 || _r <= 0) return;
    var _old = draw_get_alpha();
    draw_set_colour(_col);
    for (var _i = 11; _i >= 0; _i--) {
        var _t = _i / 11;
        draw_set_alpha(_alpha * (1 - _t) * 0.155);
        draw_circle(_cx, _cy, _r * (0.22 + _t * 0.78), false);
    }
    draw_set_alpha(_old);
}

/// An expanding shock ring.
function rps_render_ring(_cx, _cy, _r, _w, _col, _alpha) {
    if (_alpha <= 0 || _r <= 0) return;
    var _old = draw_get_alpha();
    draw_set_alpha(_alpha);
    draw_set_colour(_col);
    rps_render_arc(_cx, _cy, _r, 0, RPS_TAU, _w);
    draw_set_alpha(_old);
}

/// A SMOOTH VERTICAL GRADIENT between two colours.
///
/// ⛔ THIS IS THE ONE DRAW CALL IN THE PACKAGE THAT IS NOT A PART, and it is here rather than
/// in rps_shell so that the claim at the top of this file stays literally true: this is still
/// the only file that talks to the GPU.
///
/// draw_rectangle_colour takes FOUR corner colours and interpolates across the quad in
/// hardware. Passing the same colour to both top corners and both bottom corners gives a pure
/// vertical ramp with no banding at any resolution - which a stack of flat bands cannot do
/// without hundreds of them.
///
/// ⚠️ THE ALPHA IS SET AND RESTORED. A gradient drawn at whatever alpha the caller happened to
/// leave behind is the kind of defect that only appears when a fade runs at the same time.
function rps_render_vgrad(_x, _y, _w, _h, _top, _bot) {
    if (_h <= 0 || _w <= 0) return;
    var _old = draw_get_alpha();
    draw_set_alpha(1.0);
    draw_rectangle_colour(_x, _y, _x + _w, _y + _h, _top, _top, _bot, _bot, false);
    draw_set_alpha(_old);
}

/// A whole ramp of stops as a stack of gradient bands.
///
/// _stops is an array of colours, top of the frame first. Each adjacent pair becomes one
/// hardware-interpolated band, so five stops cost four draw calls for a whole backdrop.
///
/// ⚠️ THE BANDS ARE NOT EVENLY SPACED, AND THAT IS THE WHOLE POINT OF _weights. The backdrop
/// behind a table spends most of its height on the upper stops and compresses the pale band
/// where the cloth meets it into the last tenth of the frame; spacing them evenly puts that pale
/// colour a third of the way up the picture and the backdrop reads as a beach towel. The same
/// weighting draws a tall backdrop that lightens toward its top without banding.
function rps_render_ramp(_x, _y, _w, _h, _stops, _weights) {
    var _n = array_length(_stops);
    if (_n < 2) return;
    var _total = 0;
    for (var _i = 0; _i < _n - 1; _i++) _total += _weights[_i];
    if (_total <= 0) return;
    var _yy = _y;
    for (var _i = 0; _i < _n - 1; _i++) {
        var _bh = _h * (_weights[_i] / _total);
        rps_render_vgrad(_x, _yy, _w, _bh + 1, _stops[_i], _stops[_i + 1]);
        _yy += _bh;
    }
}

/// A flat filled rectangle at an alpha - the scrim behind a modal panel, and the night wash over
/// a whole banquet table.
function rps_render_scrim(_x, _y, _w, _h, _col, _alpha) {
    if (_alpha <= 0) return;
    var _old = draw_get_alpha();
    draw_set_alpha(_alpha);
    draw_set_colour(_col);
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);
    draw_set_alpha(_old);
}

/// ============================================================================================
/// CACHING - the path a buyer's game should actually use
/// ============================================================================================

/// Render a part list once into a sprite and hand it back.
///
/// A furnished room is a few thousand primitives. A house of twelve of them redrawn every frame
/// from geometry is tens of thousands of draw calls per frame and it WILL show up in a buyer's
/// profiler, so the honest thing is to ship the cache rather than let them discover the cost and
/// write their own. A room only changes when its state changes, which is the ideal case for
/// caching: build the sprite once, redraw it when rps_dish_derive moves the state.
///
/// ⭐ AND A PLATED DISH IS THE STRONGEST CASE FOR THIS IN THE SERIES SO FAR. A cooked dish is an
/// INVENTORY ITEM: it is drawn into a slot, a tooltip, a recipe page and a hotbar, often all four
/// on one frame, and it does not change again until it is eaten. Re-deriving that geometry every
/// frame for every slot is the pathological case, so the cache is not an optimisation a careful
/// buyer might want, it is the normal path.
///
/// ⚠️ THE CALLER OWNS THE SPRITE AND MUST sprite_delete IT. A generator that hands out sprites with
/// no stated ownership is a leak with a nice API on top; the demo object's Clean Up event deletes
/// every sprite it made, and the Readme says this in the same words.
///
/// ⚠️ AND IT MUST NOT BE CALLED FROM A DRAW EVENT. surface_set_target inside a draw event nests
/// render targets, and on some drivers that silently produces an empty sprite rather than an error
/// - the exact shape of failure this wing keeps recording. Build in Create, draw in Draw.
/// ⛔ IT TAKES A PART LIST, NOT A DISH, AND NOW REFUSES ANYTHING ELSE WITH -1. GML's array_length()
/// on a struct returns 0 instead of throwing, so this shape hands back a live, correctly sized,
/// COMPLETELY EMPTY sprite. Measured as a shipped defect in a sibling product on 2026-09-08.
function rps_render_to_sprite(_parts, _pal, _w, _h, _pad) {
    if (!is_array(_parts) || !is_struct(_pal)) return -1;
    var _pd = is_undefined(_pad) ? 0 : _pad;
    var _surf = surface_create(_w, _h);
    surface_set_target(_surf);
    draw_clear_alpha(_pal.ground, 0);
    rps_render_in_rect(_parts, _pal, _pd, _pd, _w - _pd * 2, _h - _pd * 2, 0, undefined);
    surface_reset_target();
    var _spr = sprite_create_from_surface(_surf, 0, 0, _w, _h, false, false, _w * 0.5, _h * 0.5);
    surface_free(_surf);
    return _spr;
}
