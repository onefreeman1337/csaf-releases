/// @description Draw GUI

// The whole product, in one call. Everything above and below this line is the demo's readout.
draw_set_colour(pal.ground);
draw_rectangle(0, 0, room_width, room_height, false);

rps_plate_draw(dish, pal, rx, ry, rw, rh);

// -- the readout --------------------------------------------------------------------------------
// ⚠️ THE OVERLAY IS DRAWN WITH THE PACKAGE'S OWN TEXT HELPERS, which measure the string and scale
// it to the cell it is given. This wing has shipped an overprinted caption twice - once because a
// later fix SHORTENED the data and re-opened a defect a hand-tuned size had been hiding. Measuring
// is the only thing that makes renaming safe, and no ink check will ever catch overprinted text,
// because overprinted text is ink exactly where ink belongs.
var _tiers = rps_tier_names();

draw_set_font(fnt_repast_title);
// rps_text_fit CENTRES on the x it is given - see its header, and see the fourth call site in
// this studio to have passed it a left edge and lost half the string.
rps_text_fit(string_upper(dish.name), rx + rw * 0.5, 26, rw, 30, pal.label_sh, pal.label);

draw_set_font(fnt_repast);

// ⭐ THE TIER IS SHOWN AS A WORD BESIDE THE PLATE, AND THE PLATE ALREADY SAID IT. That is the
// point being demonstrated: the number of garnishes, the steam and the colour of the crust have
// already told the player how it went. The word is here to prove the picture was not a guess.
var _tier_line = "  " + string_upper(_tiers[dish.tier])
               + "      garnish " + string(array_length(dish.garn_forms))
               + "      freshness " + string_format(dish.freshness, 1, 2);
rps_text_line(_tier_line, rx + rw + 30, ry + 10, 440, 22, pal.label, true);

var _state = "heat " + string_format(heat, 1, 2)
           + "    doneness " + string_format(dish.doneness, 1, 2)
           + "    ideal " + string_format(book[r_idx].ideal, 1, 2)
           + "    error " + string_format(dish.error, 1, 3);
rps_text_line(_state, rx + rw + 30, ry + 46, 440, 17, pal.label, false);

var _make = "method " + dish.hero_cook
          + "    skill " + string_format(skill, 1, 1)
          + "    vessel " + dish.ware;
rps_text_line(_make, rx + rw + 30, ry + 70, 440, 17, pal.label, false);

// The buff, because it is derived from what is on the plate rather than stored on the recipe, and
// a buyer should be able to watch it change as the ingredients and the tier change.
var _b = rps_dish_buff(dish);
var _buff = "nourish " + string_format(_b.nourish, 1, 2)
          + "    vigour " + string_format(_b.vigour, 1, 2)
          + "    warmth " + string_format(_b.warmth, 1, 2)
          + "    for " + string(round(_b.duration)) + "s";
rps_text_line(_buff, rx + rw + 30, ry + 100, 440, 17, pal.crumb, false);

// What is actually on the plate, named. This is the line that shows the composition rule doing
// its work: the same four slots, filled differently by every recipe.
var _comp = "base " + ((dish.base_form == "") ? "-" : dish.base_form)
          + "    hero " + dish.hero_form
          + "    sides " + string(array_length(dish.side_forms));
rps_text_line(_comp, rx + rw + 30, ry + 130, 440, 17, pal.label, false);

var _keys = "LEFT/RIGHT recipe    UP/DOWN vessel    H/J hold to cook    "
          + "K skill   E let it sit   SPACE reseed   A autoplay";
rps_text_line(_keys, rx, ry + rh + 24, rw + 460, 15, pal.crumb, false);

// ⛔ THE PRODUCT'S OWN VERDICT IS ON SCREEN, NOT HIDDEN. A ruined dish says so in the flame
// colour rather than letting a burnt plate look like an artistic choice. A gate a buyer cannot
// see is a gate that can quietly stop working.
if (dish.tier == 0) {
    rps_text_line("RUINED - the method was taken past its window, and the plate shows it.",
                  rx, ry + rh + 48, rw + 460, 15, pal.scorch, true);
}
