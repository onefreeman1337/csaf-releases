/// @description Step

// ⚠️ ONE PLACE REBUILDS THE DISH, AND EVERY CONTROL ROUTES THROUGH IT. A demo that rebuilds
// inline at each key handler is a demo where one branch forgets to rebuild the palette, and the
// symptom is a plate whose colours belong to the previous recipe. Cooking and rebuilding
// together, once, makes that impossible.
var _rebuild = false;

if (keyboard_check_pressed(vk_right)) { r_idx = (r_idx + 1) mod array_length(book); heat = book[r_idx].ideal; _rebuild = true; }
if (keyboard_check_pressed(vk_left))  { r_idx = (r_idx + array_length(book) - 1) mod array_length(book); heat = book[r_idx].ideal; _rebuild = true; }
if (keyboard_check_pressed(vk_down))  { w_idx = (w_idx + 1) mod array_length(wares); _rebuild = true; }
if (keyboard_check_pressed(vk_up))    { w_idx = (w_idx + array_length(wares) - 1) mod array_length(wares); _rebuild = true; }
if (keyboard_check_pressed(vk_space)) { seed += 1; _rebuild = true; }
if (keyboard_check_pressed(ord("A"))) { auto = !auto; }

// ⭐ HEAT IS HELD, NOT TAPPED, AND IT IS THE CONTROL THE WHOLE PRODUCT IS FOR. Holding H or J
// walks the dish continuously along the cook trajectory - raw, through the window, into char -
// and the plate redraws every frame. A buyer who holds one key for three seconds has seen the
// entire claim this package makes, which is why it is a held key and not a discrete step.
if (keyboard_check(ord("J"))) { heat = clamp(heat + 0.006, 0, 1); _rebuild = true; auto = false; }
if (keyboard_check(ord("H"))) { heat = clamp(heat - 0.006, 0, 1); _rebuild = true; auto = false; }

if (keyboard_check_pressed(ord("K"))) { skill = (skill > 0.5) ? 0.0 : 1.0; _rebuild = true; }

// Spoilage, on one key, because a mechanic nobody can see is not a mechanic. Pressing E ages the
// plate in place: the garnish comes off, the steam stops and the food darkens.
if (keyboard_check_pressed(ord("E"))) {
    dish = rps_dish_age(dish, 14, 8);
    pal = rps_palette_build(dish);
}

if (auto) {
    timer += 1;
    if (timer > 130) {
        timer = 0;
        r_idx = (r_idx + 1) mod array_length(book);
        heat = book[r_idx].ideal;
        if (r_idx == 0) w_idx = (w_idx + 1) mod array_length(wares);
        _rebuild = true;
    }
}

if (_rebuild) {
    // ⛔ THE VESSEL IS APPLIED AFTER THE COOK, NOT INSIDE IT. rps_recipe_cook returns a dish on
    // the default earthenware, because what a dish is served ON is not a property of how it was
    // cooked - and folding the two together is how a system ends up unable to serve the same
    // stew in a bowl and on a board.
    dish = rps_dish_on(rps_recipe_cook(book[r_idx], heat, skill, seed),
                       wares[w_idx], (w_idx == 5 || w_idx == 4) ? 0.55 : 0.15, 0.25);
    pal = rps_palette_build(dish);
}
