/// @description Create

// ⛔ THE FIRST LINE OF ANY HEADLESS ENTRY POINT, AND IT IS NOT OPTIONAL.
// A GML runtime error opens a MODAL DIALOG. Headless, nothing dismisses it and the process never
// exits - a build robot then reports a 180-second timeout instead of a defect. Installing a
// handler that records the stage number and ends the game turns an opaque hang into a named line
// in a result file. This wing measured that exact conversion on a previous product: an opaque
// 180 s hang became "CRASH at stage 5: Variable Index [25] out of range [25]", a real bug.
//
// ⛔ AND IT RECORDS THE STACKTRACE, NOT JUST THE MESSAGE. A stage is a whole block calling
// hundreds of functions, so the message alone sends you guessing through the call graph. GML's
// exception struct carries .stacktrace, which names the function AND the line, and writing it
// costs one string. A diagnostic that narrows to a 300-line block is barely better than none.
//
// ⛔ THIS IS THE ONLY exception_unhandled_handler IN THE PACKAGE. An earlier draft of
// rps_selftest installed a second, weaker one that recorded only the message; whichever is
// installed last silently wins, so two handlers is a coin toss over how much you learn from a
// crash. rps_set_stage() keeps global.rps_stage current for this one to read.
global.rps_stage = -1;
exception_unhandled_handler(function(_ex) {
    var _st = "";
    try {
        var _tr = _ex.stacktrace;
        for (var _i = 0; _i < array_length(_tr); _i++) {
            if (_i > 0) _st += " <- ";
            _st += string(_tr[_i]);
        }
    } catch (_e) { _st = "(no stacktrace)"; }
    var _f = file_text_open_write("rps_crash.json");
    file_text_write_string(_f, "{\"stage\":" + string(global.rps_stage)
        + ",\"message\":\"" + string_replace_all(string(_ex.message), "\"", "'") + "\""
        + ",\"where\":\"" + string_replace_all(_st, "\"", "'") + "\"}");
    file_text_close(_f);
    game_end(1);
});

// ⛔ THE HEADLESS BRANCHES BELOW LEAVE Create PART WAY THROUGH, AND Clean Up STILL RUNS AT GAME
// END. A sibling product in this wing threw "variable not set before reading it" AFTER a fully
// green self-test, because its Clean Up read an instance variable that the early `exit` had
// skipped past - a crash after the work is done still fails the run and still hides the result.
// The fix chosen here is the one with no moving parts: NOTHING this object's other events touch
// is declared after the branch, and Clean Up is deliberately empty. If a future edit adds a
// surface or a sprite cache to this object, it must be created BEFORE the branch or freed
// somewhere other than Clean Up.
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i + 1) + " ";

// -- headless modes: run, write the result file, exit -----------------------------------------
if (string_pos("-selftest", _args) > 0) {
    rps_selftest_write(rps_selftest_run());
    game_end(0);
    exit;
}
if (string_pos("-bake", _args) > 0) {
    rps_bake_run();
    game_end(0);
    exit;
}
if (string_pos("-frames", _args) > 0) {
    rps_frames_run();
    game_end(0);
    exit;
}

// -- the interactive demo ---------------------------------------------------------------------
// ⛔ A RUNNABLE DEMO ROOM IS MANDATORY IN THIS WING. It is the buyer's quickstart, the source of
// the store GIF, and the only real smoke test GML permits - all three at once. A buyer who
// cannot press Play cannot evaluate the product.
//
// It is deliberately the SHORTEST CORRECT USE OF THE API:
//     pick a recipe -> cook it -> build a palette -> draw the plate.
// Everything else in these events is the readout that shows what the state currently is.
book    = rps_recipe_book();
wares   = rps_ware_names();
r_idx   = 0;
w_idx   = 0;
heat    = book[0].ideal;
skill   = 0.5;
seed    = 1;

dish = rps_dish_on(rps_recipe_cook(book[r_idx], heat, skill, seed), wares[w_idx], 0.15, 0.25);
pal  = rps_palette_build(dish);

auto  = true;
timer = 0;

// The rect the plate is drawn into. Deliberately not the whole window: the margin is what proves
// rps_plate_draw stays inside the rect it is given, and a buyer can see that it does.
rx = 90;
ry = 60;
rw = 700;
rh = 520;
