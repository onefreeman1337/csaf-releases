# Repast — a cooking system that draws every dish it makes

**For GameMaker 2024.11 and newer. Pure GML. No sprites, no shaders, no extensions.**

You give Repast a recipe and how well it was cooked. It gives you back a **plated dish**: the
vessel, the bed, the main ingredient in the exact state your heat left it in, the accompaniments
fanned behind it, the garnish it earned, and the steam coming off it — composed and drawn from
geometry, with no image file anywhere in the package.

Most cooking systems store a recipe and an icon. That is why they have three tiers of "soup" that
are the same picture at three brightnesses, and why they cannot answer *"sear it a little less"*.

**Repast stores a METHOD and computes the dish.** Two players who cook the same recipe at
different skill do not see the same picture with a different label on it. They see different food.

Every image on the store page was rendered by this package, by the functions you are buying.

---

## Install

1. In the IDE: **Tools ▸ Import Local Package**, choose `Repast.yymps`.
2. Import **all** resources when the dialog asks.
3. Open **`rm_rps_demo`** and press **Run**.

That room is the quickstart and it is also the smoke test — if it runs, the package imported
cleanly.

**Hold `J`.** That one key walks a dish along its entire cook trajectory, redrawing every frame,
and it is the whole product in three seconds. `H` walks it back.

| key | what it does |
| --- | --- |
| `←` `→` | previous / next recipe |
| `↑` `↓` | previous / next vessel |
| **`H` / `J`** | **hold to cook — the control this package exists for** |
| `K` | toggle the cook's skill between 0 and 1 |
| `E` | let the dish sit — spoilage, applied in place |
| `space` | reseed |
| `A` | autoplay |

### What you get

| | |
| --- | --- |
| `scripts/rps_*` | 15 scripts, raw readable GML, header-documented |
| `objects/obj_rps_demo` | the demo driver — read it, it is the shortest usage example there is |
| `rooms/rm_rps_demo` | the runnable demo room |
| `fonts/fnt_repast*` | Open Sans, used **only** by the demo readout (see *Fonts* below) |

---

## The whole thing in four calls

```gml
// once, at startup
book = rps_recipe_book();               // twelve worked recipes; replace them with your own

// when the player cooks
dish = rps_recipe_cook(book[0], heat, skill, seed);   // heat and skill are 0..1
pal  = rps_palette_build(dish);

// when you draw
rps_plate_draw(dish, pal, x, y, w, h);
```

That is a complete cooking mechanic. `dish.tier` is 0–4 (`rps_tier_names()`), `dish.doneness` is
what the cook actually achieved, and `rps_dish_buff(dish)` tells you what eating it does.

### Choosing the vessel

A cooked dish is plated on earthenware by default. To put it on one of the other seven, copy it onto
the vessel you want — the dish you pass in is not modified:

```gml
var _plated = rps_dish_on(dish, "copper", 0.1, 0.2);   // ware, how deep 0..1, how worn 0..1
rps_plate_draw(_plated, rps_palette_build(_plated), x, y, w, h);
```

`rps_ware_names()` returns all eight: `earthen`, `porcelain`, `stoneware`, `pewter`, `copper`,
`iron`, `board`, `leafware`. The palette is derived from the dish, so rebuild it after changing ware.

### The discovery ledger

The ledger is a plain struct you own and store wherever your save data lives:

```gml
ledger = rps_ledger_new();                  // once, per player
rps_ledger_record(ledger, dish);            // after each cook
rps_ledger_knows(ledger, recipe.id)         // has this recipe been discovered
rps_ledger_best(ledger, recipe.id)          // the best tier reached, or undefined
```

`ledger.cooked` counts every attempt including ruined ones; `ledger.known` holds only discoveries.
See *Design positions* below for why those differ.

### Bad input is refused, not fatal

Nothing in this package throws at your code. Calls that **return a dish, palette, buff or ledger
value** (`rps_recipe_cook`, `rps_dish_on`, `rps_palette_build`, `rps_dish_buff`, `rps_ledger_record`)
return `undefined` if handed something they cannot use — check with `is_struct()`.
`rps_plate_to_sprite` returns `-1`, which `sprite_exists()` reports as false. `rps_plate_draw` draws
nothing and returns. `rps_ledger_knows` returns `false` and `rps_ledger_best` returns `-1`, which is
what it already answers for a recipe with no recorded best, so neither needs a new branch.

That covers wrong types *and* wrong names: `rps_dish_on(dish, "coper", 0.1, 0.1)` is refused, because
a misspelled vessel is the likeliest mistake with an API of eight named strings.

### Caching, and why it is the normal path here

A cooked dish is an **inventory item**: it gets drawn into a slot, a tooltip, a recipe page and a
hotbar, often on the same frame, and it does not change again until it is eaten. Re-deriving that
geometry every frame for every slot is the pathological case, so bake it once:

```gml
spr = rps_plate_to_sprite(dish, pal, 128, 128);   // YOU own this sprite
// ... later ...
sprite_delete(spr);
```

⚠️ **The caller owns the sprite and must `sprite_delete` it.** A generator that hands out sprites
with no stated ownership is a leak with a nice API on top. ⚠️ **Do not call it from a Draw event** —
`surface_set_target` inside a draw event nests render targets, and on some drivers that silently
produces an empty sprite rather than an error.

---

## What is actually in it

**46 hand-authored ingredient forms** — chop, steak, tied joint, coiled sausage, drumstick, whole
bird, whole fish, flaking fillet, curled prawn, seared scallop, roots, roast and mashed potato,
onion rings, leek, mushroom, cabbage, sprout, peas, pods, squash, fried and halved eggs, cheese,
butter, loaf, bread slice, lattice pie, dumpling, grain, noodles, tart, stew, apple, fig, berries,
citrus, drizzle, comb, herb sprig, leaf, seeds, dusting, sauce pool, steam.

**24 substances × 12 cook states.** Every form is authored *once*, in no particular material; what
it is made of and how it was cooked are two independent axes applied at draw time. That is why the
corpus is 46 files' worth of drawing and not 46 × 24 × 12 pictures.

**8 vessels** — earthenware, porcelain, stoneware, pewter, copper, iron, wooden board, leaf — each
generated, each with its own wear, and only the board gets a grain.

**A complete system on top:** recipes, a discovery ledger, five quality tiers, spoilage on a clock,
and buffs derived from what is actually on the plate.

---

## The idea worth reading before you buy

**A cook state is not a recolour. It is a trajectory.**

The obvious way to do "seared beef" is a second hex colour next to "raw beef". Here a cook state is
a set of coefficients — applied to *whatever material it is given*, scaled by a continuous doneness
— so the same searing law browns beef, halloumi, a scallop and a slice of bread, each from its own
starting colour, and **every value in between is a real colour rather than a blend of two pictures**.

The coefficients are what the Maillard reaction actually does to a surface:

- **Lightness** falls, and fastest at the end, because browning accelerates once it starts.
- **Chroma** *rises* first — raw grey-pink beef to a saturated red-brown crust — and then
  *collapses* as carbon takes over. A model that only darkens gives you mud at every setting; the
  rise is what makes a crust look appetising instead of dirty.
- **Hue** travels *toward* amber from wherever the substance started. (It pulls toward a target; it
  does not add a fixed offset. Adding one browns beef correctly and turns poultry, dough and grain
  **olive** — which is a real bug this package had, and the corpus sheet is what caught it.)

That is why `charred` and `seared` are different-looking states and not one texture at two
brightnesses.

### Quality is visible without a number

The number of finishing touches on a plate is a function of the tier, so a masterwork dish is
*visibly* more finished than a plain one — more garnish, a gilt rim, a beaded edge, steam — without
the recipe author choosing garnishes per tier. A ruined dish is not the same dish with a label; it
is forced up the trajectory into char, so **the picture tells the player what went wrong.**

---

## Design positions this package takes on your behalf

Two, and they are stated so you can disagree and change them in one line each.

1. **Tier scales buff DURATION, not magnitude.** A masterwork meal that hits twice as hard is a
   balance problem in every game that uses it; one that lasts twice as long is a reward you can
   price. `rps_dish_buff()`.
2. **A ruined attempt does not discover a recipe.** Discovery should feel earned, and burning
   something is not an achievement. The attempt *is* recorded in `ledger.cooked`, so a gentler game
   can check that instead. `rps_ledger_record()`.

---

## Namespacing

Every function, macro and global is prefixed `rps_` / `RPS_`. GML's global namespace is flat and a
collision inside your project is a support ticket nobody can debug remotely. The package owns
exactly **two** globals — `global.rps_lx` and `global.rps_ly`, the lamp direction — plus
`global.rps_stage`, which only the demo object's crash handler uses. The discovery ledger is
handed back to you to store wherever you like rather than kept here.

No absolute paths. No hardcoded room or layer indices. No `sprites/` folder — there isn't one.

---

## Verification, stated honestly

GML cannot be unit-tested outside the engine. This package's answer is that it **tests itself
inside a real build**:

```
Repast.exe -selftest      →  %LOCALAPPDATA%\Repast\rps_selftest.json
```

**MEASURED on the shipped build: 65 assertions passed, 0 failed, suite ran to completion.**

Alongside it, a **buyer harness** installs this package into a blank project and drives it using only
the calls on this page (44 checks), and a **52-attack adversarial pass** throws `undefined`, negative,
absurd and wrong-typed arguments at every documented entry point: **52 attacks, 0 crashes.**

It checks the corpus is the size it claims and that every named form builds something; that every
form sits on the ground line and stays inside its box; that every substance/cook pair is *visibly*
different raw and done (264 pairs compared); that the chroma arch genuinely rises and falls; that
every role the corpus emits resolves in the palette; that skill helps, that difficulty tightens the
window rather than lowering the ceiling, that a masterwork plate carries more finishing than a
plain one, that ageing is visible and does not mutate the dish you gave it, and that all twelve
starter recipes compose to a full plate inside the frame.

**Stage 0 deliberately fails an assertion and checks the counter moved.** A suite that has never
been seen to go red is a suite nobody has tested, and a "PASS" over zero checks is not a pass.

The limits, plainly: this proves the code runs and produces the values it claims in a real Igor
build. It does not prove your taste agrees with mine about how a dumpling should look, and it
cannot prove the IDE's import dialog accepts the manifest, because that path cannot be driven
headlessly.

---

## Fonts

`fnt_repast` and `fnt_repast_title` are **Open Sans**, licensed Apache-2.0; the licence text and
the notices file travel in `fonts/`. They are used **only** by the demo room's readout. The dishes
themselves draw no text at all — if you import without the fonts you lose the readout, not the
product.

---

## Compatibility

Built and gated against GameMaker runtime **2024.14.4.268** (the current stable/legacy runtime),
IDE 2024.11+. Nothing here uses a GMRT-only feature; GMRT is not a dependency.

No extensions, no shaders, no third-party libraries, no network access, no file I/O except the two
opt-in headless modes (`-selftest`, `-bake`) which write into `%LOCALAPPDATA%`.

---

## Licence

See `LICENSE.txt`. In short: build whatever you want with it, in unlimited commercial or free
games, forever. Do not resell or redistribute the package itself.

Repast is AI-authored. Code: yes. Graphics: yes (generated by this code). Sounds: none. Text:
authored for this package.

© 2026 Core Systems Asset Factory.
