# Trove

**Procedural item icons and a spring-animated inventory for GameMaker.**
75 item forms × 12 material palettes = **900 distinct icons, and not one of them is an image.**

---

## What you actually bought

Two things that are normally sold by two different people:

1. **An icon forge.** Seventy-five item forms — weapons, armour, supplies, arcane, materials —
   described as polygons, discs and strokes on a ten-by-ten grid and drawn with primitives at draw
   time. Colour comes from a five-role *material* palette applied at render, so the same nine
   polygons are an iron sword, a gold sword and a cursed obsidian sword.
2. **An inventory presentation layer** built on top of them: a grid with spring-driven hover and
   drag-and-drop, six rarity treatments, a live detail panel, a category rail and a loot-toast queue.

**Nothing here is a sprite.** No PNG, no atlas, no texture page, no fixed resolution. Dropping Trove
into an existing project cannot disturb that project's texture packing, because it adds nothing to it.

---

## Install

1. In GameMaker: **Tools → Import Local Package**, choose `Trove.yymps`.
2. Import everything, or just the scripts if you do not want the demo.
3. Open **`rm_trv_demo`** and press **F5**.

Arrow keys change page, **T** cycles the four themes, the mouse hovers and drags.

**Requires GameMaker 2023.x or newer** (structs, `static` methods, constructors). Built and verified
against runtime **2024.14.4.268**. Nothing here uses a platform-specific function; it should run
anywhere GameMaker does, though only Windows has been compiled and tested by us — see *Honest limits*.

---

## The five-minute version

```gml
// Create
inv = new TrvGrid(300, 150, 6, 5, 88, 12);       // x, y, cols, rows, cell px, gap px
inv.add(new TrvItem("SUNBRAND", "SWORD", "GOLD", TRV_RARITY_LEGENDARY)
        .with_stats([{k: "DAMAGE", v: "96-118"}, {k: "WEIGHT", v: "7.0"}])
        .with_blurb("FORGED AT NOON, QUENCHED AT DAWN.")
        .with_value(9800));

// Step
inv.update(delta_time / 1000000,
           device_mouse_x_to_gui(0), device_mouse_y_to_gui(0),
           mouse_check_button_pressed(mb_left),
           mouse_check_button_released(mb_left));

// Draw GUI
inv.draw();
trv_draw_detail(940, 150, 330, 500, inv.item_selected());
```

Icon and material are named as **strings**, not indices, on purpose: inserting a new icon form should
not silently renumber your item table.

To draw a single icon anywhere — a hotbar, a shop, a quest reward, a map pin:

```gml
trv_icon_draw(trv_icon_find("POTION"), x, y, 48, trv_material_palette(trv_material_find("EMBER")));
```

---

## The files

| File | What it is |
| --- | --- |
| `trv_icon.gml` | **The forge.** 75 form definitions, 12 materials, the renderer, ear-clipping triangulation |
| `trv_item.gml` | `TrvItem` and the six rarity tiers |
| `trv_inventory.gml` | `TrvGrid`, slot rendering, the detail panel, `TrvToasts`, the filter rail |
| `trv_draw.gml` | Primitive layer: rounded rects, gradients, glow, arcs, panels, corner ticks |
| `trv_font.gml` | A 61-glyph geometric stroke typeface. No font resource, no glyph atlas |
| `trv_theme.gml` | Six seed colours → ~20 derived roles. Four themes ship |
| `trv_ease.gml` | Easing curves, the spring integrator, the stagger function. **Pure — no engine calls** |

Every public function has a header block. The code is raw and readable because you are a developer
who will need to extend it.

---

## Making your own icons

This is the part the product is *for*, so it is deliberately easy.

```gml
array_push(_i, { n: "MY_THING", c: TRV_CAT_MATERIAL, s: [
    trv_sp(TRV_ROLE_MAIN,   [2,8, 5,1, 8,8]),        // filled polygon
    trv_sl(TRV_ROLE_ACCENT, 0.4, [3,6, 7,6]),        // stroked polyline, weight in grid units
    trv_sd(TRV_ROLE_LIGHT,  5, 4, 0.8)               // filled disc
]});
```

Add it to the array in `trv_icon_build()`. Coordinates run 0–10 on both axes, y downward.

**Concave shapes are fine** — polygons are triangulated by ear clipping, not fanned, and the result
is cached at first draw. **Self-intersecting shapes are not**: a bowtie has no ear to clip and will
render partially. Split it into two polygons, which is what the shipped `HOURGLASS` does.

Three things learned the hard way while authoring the seventy-five, worth knowing before you start:

- **Silhouette first.** An icon that is unreadable in one flat colour is unreadable at 20 px.
- **Three to nine shapes.** More turns to mud below 48 px.
- **One accent area only.** Two competing accents read as clutter.

A new material is one line:

```gml
trv_material_make(make_colour_rgb(120, 40, 60), make_colour_rgb(40, 30, 30), make_colour_rgb(255, 90, 120))
```

Shade and light are *derived* from the body and accent rather than supplied, which is why twelve
materials look like one designed set instead of twelve guesses.

---

## Why springs and not GameMaker's Animation Curves

GameMaker ships built-in Animation Curves, and you should use them for a great many things. They
cannot do this one.

An animation curve is a **fixed schedule over a known duration**. To retarget it mid-flight you have
to restart it. An inventory is the one screen a player pokes at continuously — hover, hover, drag,
drop, hover again — so mid-flight retargeting is the normal case, not the exception, and every
restart is a visible hitch. Sweep the cursor quickly across a row of hand-rolled slots and the
highlight stutters.

A spring has no duration and no schedule. It holds position and velocity and is simply given a new
target each frame, so a fast sweep is one continuous motion. That is the whole reason `trv_ease.gml`
exists and it is not a claim curves can match.

---

## Works with what you already have

Trove owns pixels and pointer state. It does **not** own your item database, your save format, your
equip rules or your crafting.

If you already use **Magpie**, or your own struct-based inventory, keep it — build `TrvItem` views of
your data when the screen opens and hand them over. `TrvItem` has a `data` struct that Trove never
reads; put whatever you like in it.

Pointer coordinates are **passed in** rather than read from `mouse_x`, because Trove has no idea
whether you are drawing in the GUI layer, inside a scaled viewport, on a surface, or navigating with
a gamepad. Pass whatever space you are drawing in.

---

## ⚠️ The demo object contains scaffolding — do not copy it

`obj_trv_demo` has two blocks that exist only so this package can photograph and record itself:

- a **self-drive** block that moves the selection when nothing has touched the mouse;
- a **command-line parser** (`--page=`, `--theme=`, `--still`) for deterministic captures.

Both are commented as scaffolding in the source. **A game that ships the self-drive has an inventory
that plays with itself.** The item table in the same file *is* worth copying — that is the intended
shape.

---

## Honest limits

Stated plainly, because you can check all of them.

- **It is not pixel art and does not try to be.** This is a clean geometric look, chosen because it
  is what survives arbitrary scaling. If your game is 16×16 pixel art, a pixel icon pack will match
  it better and Trove will not.
- **Verified by compiling and by looking, not by a unit-test suite.** GML cannot be unit-tested
  outside the engine. What was actually done: a real headless Igor build (exit 0, 0 errors, 0
  warnings, 290 resources), the `.yymps` payload extracted and compiled again on its own, and every
  demo page rendered from the real executable and inspected. Five visual defects were found that way
  and fixed — including three icons that a triangle-fan renderer was silently mangling.
- **Compiled and captured on Windows.** No platform-specific function is used, but other targets are
  untested by us.
- **The IDE's import dialog has not been driven headlessly**, because it cannot be. The package
  format was mirrored from a real vendor `.yymps` and its payload is proven to compile.

---

## Support

Questions, bugs and requests for icon forms: leave a comment on the itch.io page.

Trove is by **CSAF — Core Systems Asset Factory**.

**AI disclosure:** the code in this package is AI-written, and the store images are generated. This
is disclosed on the listing and is stated here for the same reason.

Licence: see `LICENSE.txt`. Short version — unlimited games, commercial or free, forever; do not
resell or redistribute the source itself.
