/// @file  obj_trv_demo — Step
/// @brief Input, self-drive, and one update call into the library.

// STILL MODE IS NOT A FREEZE AT ZERO — it is a deterministic run to a settled state, then a hold.
// Freezing at t=0 photographs every spring at its start value, so a "still" capture of a
// spring-animated interface would show none of the motion's end state: no hover lift, no glow, no
// entrance completed. It looks like a different, worse product. Fixed step so the same command
// produces the same pixels on any machine.
var _dt;
if (still) _dt = (elapsed < 1.75) ? (1 / 60) : 0;
else       _dt = delta_time / 1000000;

elapsed += _dt;
pageAge += _dt;

// --- keyboard -----------------------------------------------------------------------------------
if (keyboard_check_pressed(vk_right) || keyboard_check_pressed(vk_pagedown)) {
    page = (page + 1) mod PAGE_COUNT; pageAge = 0; grid.reveal(); userActive = true;
}
if (keyboard_check_pressed(vk_left) || keyboard_check_pressed(vk_pageup)) {
    page = (page + PAGE_COUNT - 1) mod PAGE_COUNT; pageAge = 0; grid.reveal(); userActive = true;
}
if (keyboard_check_pressed(ord("T"))) {
    themeIndex = (themeIndex + 1) mod trv_theme_count();
    trv_theme_set(trv_theme_by_index(themeIndex));
    userActive = true;
}
if (keyboard_check_pressed(vk_space)) { grid.reveal(); pageAge = 0; userActive = true; }
if (keyboard_check_pressed(vk_escape)) game_end();

// --- pointer ---------------------------------------------------------------------------------
var _mx = device_mouse_x_to_gui(0);
var _my = device_mouse_y_to_gui(0);
if (mouse_check_button_pressed(mb_left) || mouse_check_button_pressed(mb_right)) userActive = true;

// SELF-DRIVE. Only until a human touches something, and only when it will not fight them. This is
// demo scaffolding — see the header of Create. A buyer copying this into a shipping game gets an
// inventory that plays with itself.
if (selfDrive && !userActive && page == PAGE_INVENTORY) {
    if (still) {
        // One fixed slot, chosen because it is legendary: the still then shows the selection ring,
        // the hover lift, the rarity frame AND the travelling highlight in one frame.
        driveTarget = 1;
    } else {
        driveClock -= _dt;
        if (driveClock <= 0) {
            driveClock  = 0.62;
            driveTarget = (driveTarget + 1 + irandom(2)) mod 30;
        }
    }
    _mx = grid.slot_x(driveTarget) + grid.cell * 0.5;
    _my = grid.slot_y(driveTarget) + grid.cell * 0.5;
    grid.selected = driveTarget;
}

// --- library update ----------------------------------------------------------------------------
if (page == PAGE_INVENTORY) {
    grid.update(_dt, _mx, _my,
                mouse_check_button_pressed(mb_left),
                mouse_check_button_released(mb_left));
    filterHover = trv_filter_index_at(60, 152, 200, 52, _mx, _my);
    if (mouse_check_button_pressed(mb_left) && filterHover >= 0) filterActive = filterHover;

    // A loot toast every few seconds, so the notification queue is visible in a recording without
    // anyone having to trigger it.
    toasts.update(_dt);
    if (!still) {
        toastClock -= _dt;
        if (toastClock <= 0) {
            toastClock = 2.6;
            toasts.push(demoItems[toastNext]);
            toastNext = (toastNext + 1) mod array_length(demoItems);
        }
    }
}
