/// @file  obj_trv_demo — Create
/// @brief Builds the demo item set and the four demo pages.
///
/// WHAT A BUYER SHOULD COPY FROM THIS FILE and what they should not:
///
///   COPY the item table. It is the intended shape — items declared as data, with icon forms and
///   materials named as strings rather than as indices, so inserting a new icon form cannot
///   silently renumber your item table.
///
///   DO NOT COPY the self-drive block in Step, or the command-line parser below. They exist so an
///   unattended screen recording has something to record and so store captures are deterministic.
///   A game that ships the self-drive has a menu that navigates itself.

// A FIXED SEED, not randomise(). Store captures have to be reproducible: the same command must
// produce the same pixels, or a gallery cannot be rebuilt after a code change and nothing can be
// compared against a previous screenshot to catch a visual regression.
random_set_seed(20260810);

// --- pages ------------------------------------------------------------------------------------
PAGE_INVENTORY = 0;
PAGE_FORGE     = 1;
PAGE_MATERIALS = 2;
PAGE_RARITY    = 3;
PAGE_COUNT     = 4;

page      = PAGE_INVENTORY;
themeIndex = 0;
elapsed   = 0;
pageAge   = 0;
still     = false;      // freeze all motion at a settled state, for still captures
selfDrive = true;       // drive the UI when nothing has touched the mouse or keyboard

// --- command line -------------------------------------------------------------------------------
// Captures are driven by ARGUMENTS, never by synthetic keystrokes. An unfocused GameMaker window
// stops repainting, so a capture harness that sends keys to a background window gets two
// byte-identical frames three seconds apart and no error. Learned the hard way; see the wing devlog.
var _argc = parameter_count();
for (var _i = 1; _i <= _argc; _i++) {
    var _a = string_lower(parameter_string(_i));
    if (string_copy(_a, 1, 7) == "--page=")  page       = real(string_delete(_a, 1, 7));
    if (string_copy(_a, 1, 8) == "--theme=") themeIndex = real(string_delete(_a, 1, 8));
    if (_a == "--still")   still = true;
    if (_a == "--nodrive") selfDrive = false;
}
page = clamp(page, 0, PAGE_COUNT - 1);
trv_theme_set(trv_theme_by_index(themeIndex));

// --- the item set --------------------------------------------------------------------------------
// Thirty items across the five categories, deliberately spread over every rarity tier and most of
// the twelve materials, so the inventory page shows the whole visual range at once rather than a
// wall of grey commons.
demoItems = [
    new TrvItem("VOIDCLEAVER",    "GREATSWORD", "OBSIDIAN", TRV_RARITY_MYTHIC)
        .with_stats([{k:"DAMAGE", v:"148-192"}, {k:"WEIGHT", v:"14.5"}, {k:"CRIT", v:"+18%"}])
        .with_blurb("IT REMEMBERS EVERY EDGE IT HAS TAKEN.").with_value(24000),
    new TrvItem("SUNBRAND",       "SWORD",      "GOLD",     TRV_RARITY_LEGENDARY)
        .with_stats([{k:"DAMAGE", v:"96-118"}, {k:"WEIGHT", v:"7.0"}, {k:"BURN", v:"+22"}])
        .with_blurb("FORGED AT NOON, QUENCHED AT DAWN.").with_value(9800),
    new TrvItem("TIDEWARD PLATE", "CUIRASS",    "TIDE",     TRV_RARITY_EPIC)
        .with_stats([{k:"ARMOUR", v:"212"}, {k:"WEIGHT", v:"22.0"}, {k:"RESIST", v:"+40"}])
        .with_blurb("SALT-SCOURED AND STILL BRIGHT.").with_value(4400),
    new TrvItem("WITCHWOOD STAFF","STAFF",      "ARCANE",   TRV_RARITY_EPIC)
        .with_stats([{k:"POWER", v:"88"}, {k:"FOCUS", v:"+31"}]).with_value(3900),
    new TrvItem("EMBER AXE",      "AXE",        "EMBER",    TRV_RARITY_RARE)
        .with_stats([{k:"DAMAGE", v:"64-81"}, {k:"WEIGHT", v:"11.2"}]).with_value(1250),
    new TrvItem("WARDEN HELM",    "HELM",       "STEEL",    TRV_RARITY_RARE)
        .with_stats([{k:"ARMOUR", v:"96"}, {k:"SIGHT", v:"-4"}]).with_value(980),
    new TrvItem("KITE SHIELD",    "SHIELD",     "BRONZE",   TRV_RARITY_UNCOMMON)
        .with_stats([{k:"BLOCK", v:"74"}, {k:"WEIGHT", v:"9.4"}]).with_value(420),
    new TrvItem("HUNTER'S BOW",   "BOW",        "WOOD",     TRV_RARITY_UNCOMMON)
        .with_stats([{k:"DAMAGE", v:"38-52"}, {k:"RANGE", v:"64"}]).with_value(360),
    new TrvItem("IRON DAGGER",    "DAGGER",     "IRON",     TRV_RARITY_COMMON)
        .with_stats([{k:"DAMAGE", v:"12-18"}]).with_value(45),
    new TrvItem("TRAVEL BOOTS",   "BOOTS",      "WOOD",     TRV_RARITY_COMMON)
        .with_stats([{k:"ARMOUR", v:"14"}, {k:"SPEED", v:"+2"}]).with_value(60),

    new TrvItem("GREATER HEALING","POTION",     "EMBER",    TRV_RARITY_RARE,  6)
        .with_stats([{k:"RESTORES", v:"240 HP"}]).with_blurb("TASTES OF IRON AND MINT.").with_value(180),
    new TrvItem("MANA VIAL",      "VIAL",       "TIDE",     TRV_RARITY_UNCOMMON, 12)
        .with_stats([{k:"RESTORES", v:"90 MP"}]).with_value(75),
    new TrvItem("ELIXIR OF NIGHT","ELIXIR",     "ARCANE",   TRV_RARITY_EPIC,  2)
        .with_stats([{k:"DURATION", v:"180 S"}, {k:"STEALTH", v:"+45"}]).with_value(1600),
    new TrvItem("MOONCAP",        "MUSHROOM",   "VERDANT",  TRV_RARITY_COMMON, 24),
    new TrvItem("BLACKROOT",      "HERB",       "VERDANT",  TRV_RARITY_UNCOMMON, 9),
    new TrvItem("TRAIL BREAD",    "BREAD",      "WOOD",     TRV_RARITY_COMMON, 5),
    new TrvItem("SALT COD",       "FISH",       "SILVER",   TRV_RARITY_COMMON, 3),

    new TrvItem("SEALED DECREE",  "SCROLL",     "BONE",     TRV_RARITY_RARE)
        .with_blurb("THE WAX IS STILL WARM.").with_value(700),
    new TrvItem("GRIMOIRE",       "TOME",       "OBSIDIAN", TRV_RARITY_LEGENDARY)
        .with_stats([{k:"SPELLS", v:"7"}, {k:"POWER", v:"+64"}]).with_value(8200),
    new TrvItem("SOULSTONE",      "CRYSTAL",    "ARCANE",   TRV_RARITY_MYTHIC, 1)
        .with_stats([{k:"CHARGE", v:"FULL"}]).with_blurb("SOMETHING INSIDE IS COUNTING.").with_value(31000),
    new TrvItem("SEEING ORB",     "ORB",        "TIDE",     TRV_RARITY_EPIC).with_value(2900),
    new TrvItem("VAULT KEY",      "KEY",        "GOLD",     TRV_RARITY_RARE).with_value(0),
    new TrvItem("BONE CHARM",     "TALISMAN",   "BONE",     TRV_RARITY_UNCOMMON, 2).with_value(140),
    new TrvItem("WAYFINDER",      "COMPASS",    "BRONZE",   TRV_RARITY_RARE).with_value(890),
    new TrvItem("PITCH LANTERN",  "LANTERN",    "IRON",     TRV_RARITY_UNCOMMON).with_value(210),

    new TrvItem("STEEL INGOT",    "INGOT",      "STEEL",    TRV_RARITY_COMMON, 32),
    new TrvItem("GOLD ORE",       "ORE",        "GOLD",     TRV_RARITY_UNCOMMON, 18),
    new TrvItem("CROWN MARKS",    "COINSTACK",  "GOLD",     TRV_RARITY_COMMON, 99),
    new TrvItem("SPUN THREAD",    "SPOOL",      "VERDANT",  TRV_RARITY_COMMON, 14),
    new TrvItem("CLOCK GEAR",     "GEAR",       "BRONZE",   TRV_RARITY_UNCOMMON, 7)
];

// --- page 0: the inventory screen ----------------------------------------------------------------
grid = new TrvGrid(304, 152, 6, 5, 88, 12);
for (var _i = 0; _i < array_length(demoItems); _i++) grid.set(_i, demoItems[_i]);
grid.selected = 0;

// Narrow and low-left, because the only clear column on this page is under the filter rail: the
// grid well starts at x=282 and the detail panel at x=890. A 300px toast at x=60 overlapped the
// well by 78px, which the first capture showed plainly.
toasts = new TrvToasts(60, 548, 216);
filterActive = 0;
filterHover  = -1;
toastClock   = 1.2;
toastNext    = 0;

// --- self-drive state ------------------------------------------------------------------------
// Two toasts seeded so a STILL capture photographs the notification queue. Without this the
// gallery would silently omit a shipped feature, because the toast clock only ticks when the demo
// is running live.
// THIRTY STEPS, NOT 120. The slide and rise springs settle in about 0.4 s, so half a second is
// plenty — and the budget is tight from the other end: a still runs the clock for a further 1.75 s
// before it freezes, and a toast expires at 3.4 s. Pre-ageing by two seconds put the total at 3.75
// and both toasts expired and were reaped before the shutter, so the capture came back with an
// empty column and no error anywhere. A feature can be missing from a store gallery for arithmetic
// reasons.
toasts.push(demoItems[19]);
toasts.push(demoItems[1]);
for (var _s = 0; _s < 30; _s++) toasts.update(1 / 60);

driveTarget = 0;
driveClock  = 0;
userActive  = false;
