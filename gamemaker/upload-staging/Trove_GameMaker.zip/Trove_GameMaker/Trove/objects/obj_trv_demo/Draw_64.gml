/// @file  obj_trv_demo — Draw GUI
/// @brief Four pages. Drawn in the GUI layer so the demo is resolution-independent end to end.
///
/// NOTE ON STRUCTURE: every local is declared ONCE, here at the top, and the page branches only
/// assign to them. GML scopes `var` to the whole function, not to the enclosing block, so a second
/// `var _cell` in a later switch case is a redeclaration in the same scope — which the compiler
/// rejects. Declaring up front is not style, it is the only arrangement that builds.

var _th = trv_theme_get();
var _W  = display_get_gui_width();
var _H  = display_get_gui_height();

var _i = 0, _r = 0, _m = 0, _f = 0, _n = 0;
var _cell = 0, _gapX = 0, _gapY = 0, _cols = 0, _rows = 0;
var _ox = 0, _oy = 0, _tw = 0, _cx = 0, _cy = 0, _by = 0, _ty = 0;
var _t = 0, _e = 0, _ns = 0, _nm = "", _idx = 0;
var _pal = 0, _item = undefined, _it = undefined;

trv_draw_backdrop(0, 0, _W, _H);

// --- chrome shared by every page ----------------------------------------------------------------
var _titles = ["THE INVENTORY", "THE ICON FORGE", "ONE FORM, TWELVE MATERIALS", "SIX RARITY TIERS"];
var _subs   = [
    "SPRING-DRIVEN HOVER, DRAG AND DROP, RARITY TREATMENTS, LIVE DETAIL PANEL AND LOOT TOASTS.",
    string(trv_icon_count()) + " ITEM FORMS. NOT ONE OF THEM IS AN IMAGE - EVERY ONE IS POLYGONS AND COLOUR MATHS.",
    string(trv_icon_count()) + " FORMS X " + string(trv_material_count()) + " MATERIALS = " +
        string(trv_icon_count() * trv_material_count()) + " DISTINCT ICONS FROM ZERO PNG FILES.",
    "RARITY IS A TREATMENT, NOT A COLOUR ON A NAME. FRAME, TICKS, GLOW AND A TRAVELLING LIGHT."
];

trv_draw_text(60, 46, "TROVE", 30, _th.text, 1);
trv_draw_text(60 + trv_text_width("TROVE", 30) + 18, 52, _titles[page], 20, _th.accent, 0.95);
trv_draw_text(60, 92, _subs[page], 11, _th.textDim, 0.85);

for (_i = 0; _i < PAGE_COUNT; _i++) {
    _cx = _W - 60 - (PAGE_COUNT - 1 - _i) * 22;
    if (_i == page) trv_draw_round_rect(_cx - 9, 50, 18, 6, 3, _th.accent, 1);
    else            trv_draw_round_rect(_cx - 7, 51, 14, 4, 2, _th.textDim, 0.4);
}
trv_draw_text_right(_W - 60, 74, "ARROWS - PAGE     T - THEME (" + trv_theme_name(themeIndex) + ")",
                    10, _th.textDim, 0.65);

switch (page) {

// =================================================================================================
case 0: {   // THE INVENTORY
// =================================================================================================
    trv_draw_filter_rail(60, 152, 200, 52, filterActive, filterHover, min(1, pageAge / 0.6));

    // A well behind the grid, so the slots sit on something instead of floating on the backdrop.
    _tw = grid.cols * grid.cell + (grid.cols - 1) * grid.gap;
    _by = grid.rows * grid.cell + (grid.rows - 1) * grid.gap;
    trv_draw_panel(grid.gridX - 22, grid.gridY - 22, _tw + 44, _by + 44, 0.9);
    grid.draw();

    // The capacity readout lives UNDER THE FILTER RAIL, not under the grid. Under the grid it sat
    // at y=680 and the footer sits at y=686, so the two strings printed through each other — found
    // by looking at the first capture, invisible to every automated check.
    _n = 0;
    for (_i = 0; _i < grid.capacity; _i++) if (!is_undefined(grid.items[_i])) _n++;
    trv_draw_text(60, 470, "CARRIED", 12, _th.textDim, 0.8);
    trv_draw_text(60, 492, string(_n) + " / " + string(grid.capacity), 22, _th.accent, 0.95);

    _item = grid.item_selected();
    trv_draw_detail(_W - 60 - 330, 152, 330, 496, _item, min(1, pageAge / 0.5), elapsed);

    toasts.draw();
    break;
}

// =================================================================================================
case 1: {   // THE ICON FORGE — every form, once
// =================================================================================================
    _n = trv_icon_count();
    _cols = 16;  _cell = 62;  _gapX = 12;  _gapY = 34;
    _rows = ceil(_n / _cols);
    _tw = _cols * _cell + (_cols - 1) * _gapX;
    _ox = (_W - _tw) * 0.5;
    _oy = 168;

    // Each form is drawn in the material that suits its category, so the page reads as a set of
    // real items rather than as a wireframe dump. Index order matches the TRV_CAT_* constants.
    var _matFor = [0, 0, 9, 11, 3];   // weapon STEEL, armour STEEL, supplies VERDANT, arcane ARCANE, material GOLD

    for (_i = 0; _i < _n; _i++) {
        _t = trv_stagger(_i, _n, pageAge, 0.30, 0.975);
        if (_t <= 0) continue;
        _e = trv_ease(_t, TRV_EASE_OUT_CUBIC);
        _cx = _ox + (_i mod _cols) * (_cell + _gapX);
        _cy = _oy + (_i div _cols) * (_cell + _gapY) + (1 - _e) * 14;

        trv_draw_round_rect(_cx, _cy, _cell, _cell, _cell * 0.16, _th.surfaceLo, _e * 0.85);
        trv_draw_round_rect_outline(_cx, _cy, _cell, _cell, _cell * 0.16, _th.edge,
                                    _e * _th.edgeAlpha * 0.8, 1);
        trv_icon_draw(_i, _cx + _cell * 0.16, _cy + _cell * 0.14, _cell * 0.68,
                      trv_material_palette(_matFor[trv_icon_category(_i)]), _e);

        _nm = trv_icon_name(_i);
        _ns = trv_text_fit_size(_nm, 8, _cell + _gapX - 2);
        trv_draw_text_centred(_cx + _cell * 0.5, _cy + _cell + 7, _nm, _ns, _th.textDim, _e * 0.8);
    }

    trv_draw_text_centred(_W * 0.5, _oy + _rows * (_cell + _gapY) + 18,
                          "EVERY FORM ABOVE IS ALSO AVAILABLE IN ELEVEN OTHER MATERIALS. PRESS RIGHT.",
                          11, _th.accent, 0.8);
    break;
}

// =================================================================================================
case 2: {   // ONE FORM, TWELVE MATERIALS — the recolour matrix
// =================================================================================================
    _m = trv_material_count();
    var _forms = ["SWORD", "HELM", "POTION", "CRYSTAL", "COIN", "GEAR"];
    // Row pitch and origin tightened after the first capture: at gapY 16 from y 196 the closing
    // two lines landed at 666 and 688 and printed straight through the footer at 686.
    _cell = 60;  _gapX = 14;  _gapY = 12;
    _tw = _m * _cell + (_m - 1) * _gapX;
    _ox = (_W - _tw) * 0.5 + 46;
    _oy = 178;

    // Material names and a five-role swatch strip across the top, so the derivation is visible
    // rather than asserted.
    for (_i = 0; _i < _m; _i++) {
        _cx = _ox + _i * (_cell + _gapX);
        _nm = trv_material_name(_i);
        _ns = trv_text_fit_size(_nm, 9, _cell + _gapX - 2);
        trv_draw_text_centred(_cx + _cell * 0.5, _oy - 26, _nm, _ns, _th.textDim, 0.85);
        _pal = trv_material_palette(_i);
        for (_r = 0; _r < 5; _r++) {
            draw_set_alpha(0.95);
            draw_set_colour(_pal[_r]);
            draw_rectangle(_cx + _r * (_cell / 5), _oy - 13, _cx + (_r + 1) * (_cell / 5) - 1, _oy - 7, false);
        }
    }
    draw_set_alpha(1);
    draw_set_colour(c_white);

    for (_f = 0; _f < array_length(_forms); _f++) {
        _idx = trv_icon_find(_forms[_f]);
        _cy = _oy + _f * (_cell + _gapY);
        trv_draw_text_right(_ox - 18, _cy + _cell * 0.38, _forms[_f], 11, _th.text, 0.9);
        for (_i = 0; _i < _m; _i++) {
            _t = trv_stagger(_f * _m + _i, array_length(_forms) * _m, pageAge, 0.26, 0.98);
            if (_t <= 0) continue;
            _e = trv_ease(_t, TRV_EASE_OUT_CUBIC);
            trv_icon_draw(_idx, _ox + _i * (_cell + _gapX), _cy, _cell, trv_material_palette(_i), _e);
        }
    }

    _by = _oy + array_length(_forms) * (_cell + _gapY) + 14;
    trv_draw_text_centred(_W * 0.5, _by,
        "A MATERIAL IS THREE SEED COLOURS. SHADE AND LIGHT ARE DERIVED, WHICH IS WHY TWELVE OF THEM LOOK LIKE ONE SET.",
        11, _th.accent, 0.85);
    trv_draw_text_centred(_W * 0.5, _by + 22,
        "YOUR THIRTEENTH MATERIAL IS ONE LINE: TRV_MATERIAL_MAKE(BODY, GRIP, ACCENT).",
        11, _th.textDim, 0.8);
    break;
}

// =================================================================================================
case 3: {   // SIX RARITY TIERS
// =================================================================================================
    _n = trv_rarity_count();
    _cell = 132;  _gapX = 26;
    _tw = _n * _cell + (_n - 1) * _gapX;
    _ox = (_W - _tw) * 0.5;
    _oy = 158;

    var _demoForms = ["DAGGER", "SHIELD", "AXE", "STAFF", "SWORD", "CRYSTAL"];
    var _demoMats  = ["IRON", "BRONZE", "STEEL", "TIDE", "GOLD", "ARCANE"];
    var _notes     = ["PLAIN", "CORNER TICKS", "FULL FRAME", "FRAME + TRAVEL",
                      "GLOW + FAST TRAVEL", "EVERYTHING"];

    for (_r = 0; _r < _n; _r++) {
        _t = trv_stagger(_r, _n, pageAge, 0.36, 0.75);
        if (_t <= 0) continue;
        _e = trv_ease(_t, TRV_EASE_OUT_CUBIC);
        _cx = _ox + _r * (_cell + _gapX);

        _it = new TrvItem(trv_rarity(_r).n, _demoForms[_r], _demoMats[_r], _r);
        trv_draw_slot(_cx, _oy, _cell, _it, 0.35, 0, _t, elapsed, false, TRV_SLOT_FILLED);

        trv_draw_text_centred(_cx + _cell * 0.5, _oy + _cell + 22, trv_rarity(_r).n, 13,
                              trv_rarity(_r).c, _e);
        _ns = trv_text_fit_size(_notes[_r], 9, _cell);
        trv_draw_text_centred(_cx + _cell * 0.5, _oy + _cell + 44, _notes[_r], _ns, _th.textDim, _e * 0.8);
    }

    _by = _oy + _cell + 84;
    trv_draw_text_centred(_W * 0.5, _by,
        "EVERY TIER COLOUR IS DERIVED FROM THE ACTIVE THEME'S ACCENT AT A FIXED HUE,",
        12, _th.text, 0.9);
    trv_draw_text_centred(_W * 0.5, _by + 22,
        "SO THE LADDER STAYS RECOGNISABLE WHILE STILL BELONGING TO YOUR PALETTE. PRESS T.",
        11, _th.textDim, 0.8);

    // The same tiers as loot toasts — rarity drives two surfaces, and one frame should show both.
    _ty = _by + 58;
    for (_r = 0; _r < 3; _r++) {
        _it = new TrvItem(_demoForms[_r + 3] + " OF " + _demoMats[_r + 3],
                          _demoForms[_r + 3], _demoMats[_r + 3], _r + 3);
        _cell = 300;
        _gapY = _cell * 0.235;
        _cx = (_W - (_cell * 3 + 40)) * 0.5 + _r * (_cell + 20);
        if (trv_rarity(_r + 3).glow > 0) {
            trv_draw_glow(_cx, _ty, _cell, _gapY, _gapY * 0.28, trv_rarity(_r + 3).c,
                          trv_rarity(_r + 3).glow * 0.06, 5, 2);
        }
        trv_draw_round_rect(_cx, _ty, _cell, _gapY, _gapY * 0.28, _th.surface, _th.panelAlpha);
        trv_draw_round_rect_outline(_cx, _ty, _cell, _gapY, _gapY * 0.28, trv_rarity(_r + 3).c, 0.8, 2);
        _cy = _gapY * 0.66;
        trv_icon_draw(_it.icon, _cx + _gapY * 0.20, _ty + (_gapY - _cy) * 0.5, _cy, _it.palette(), 1);
        _ox = _cx + _gapY * 0.20 + _cy + _gapY * 0.20;
        _ns = trv_text_fit_size(_it.name, _gapY * 0.26, _cell - (_ox - _cx) - _gapY * 0.25);
        trv_draw_text(_ox, _ty + _gapY * 0.24, _it.name, _ns, _th.text, 1);
        trv_draw_text(_ox, _ty + _gapY * 0.60, trv_rarity(_r + 3).n, _gapY * 0.19, trv_rarity(_r + 3).c, 0.9);
    }

    // --- the scale strip -----------------------------------------------------------------
    // ONE FORM AT FIVE SIZES, sharing one geometry definition. This is the claim the whole
    // package rests on, and it is the only claim that a still photograph can actually prove:
    // there is no second, larger asset anywhere in the product. It also fills the lower third,
    // which the first capture of this page left empty.
    _ty += _gapY + 42;
    trv_draw_text_centred(_W * 0.5, _ty - 26,
        "AND EVERY SIZE IS THE SAME GEOMETRY - NO SECOND ASSET, NOTHING RESAMPLED",
        11, _th.textDim, 0.75);

    var _sizes = [20, 32, 50, 74, 100];
    _tw = 0;
    for (_i = 0; _i < array_length(_sizes); _i++) _tw += _sizes[_i] + 30;
    _ox = (_W - _tw + 30) * 0.5;
    _idx = trv_icon_find("SWORD");
    for (_i = 0; _i < array_length(_sizes); _i++) {
        _cell = _sizes[_i];
        trv_icon_draw(_idx, _ox, _ty + (100 - _cell), _cell,
                      trv_material_palette(trv_material_find("GOLD")), 1);
        trv_draw_text_centred(_ox + _cell * 0.5, _ty + 108, string(_cell) + "PX", 9, _th.textDim, 0.7);
        _ox += _cell + 30;
    }
    break;
}

}

// --- footer ---------------------------------------------------------------------------------
trv_draw_text(60, _H - 34,
              "TROVE - PROCEDURAL ITEM ICONS AND INVENTORY FOR GAMEMAKER", 10, _th.textDim, 0.55);
trv_draw_text_right(_W - 60, _H - 34,
                    "NO SPRITES - NO TEXTURE PAGES - NO FIXED RESOLUTION", 10, _th.accent, 0.55);
