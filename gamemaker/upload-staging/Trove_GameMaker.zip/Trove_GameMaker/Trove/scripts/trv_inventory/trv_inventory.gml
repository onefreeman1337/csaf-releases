/// @file    trv_inventory.gml
/// @package Trove for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary The presentation layer: slots, the grid, drag and drop, the detail panel, the filter
///          rail and loot toasts. Everything a player actually touches.
///
/// @remarks WHAT THIS OWNS AND WHAT IT DOES NOT.
///
///          It owns pixels and pointer state. It does NOT own your item database, your save
///          format, your equip rules or your crafting. Every entry point takes a plain array and
///          mutates only what it was handed. If you already have an inventory that works, Trove
///          sits on top of it: build TrvItem views of your data each frame, or once when the
///          screen opens, and hand them over.
///
///          WHY EVERY MOTION HERE IS A SPRING AND NOT A TWEEN. An inventory is the one screen a
///          player pokes at continuously — hover, hover, drag, drop, hover again — and a
///          fixed-duration tween has to be TORN DOWN AND RESTARTED every time the target changes
///          mid-flight. That restart is the visible hitch in almost every hand-rolled GameMaker
///          menu: move the cursor quickly across three slots and the highlight stutters instead of
///          flowing. A spring holds position and velocity and is simply retargeted, so a fast
///          sweep across a row produces one continuous motion. GameMaker's built-in Animation
///          Curves cannot express that; they are a schedule over a known duration, which is
///          exactly the thing that has to be restarted.
///
///          PER-SLOT SPRING COST. One spring is five numbers and one multiply-add per sub-step.
///          A 48-slot grid running three springs each is 144 springs, which is nothing — measured
///          in the demo room at 60 fps with room to spare on this machine. Do not be tempted to
///          share one spring across the grid: the whole point is that a slot the cursor has just
///          left keeps settling while the one it arrived at is still rising.

// --- slot visual states -------------------------------------------------------------------
#macro TRV_SLOT_EMPTY  0
#macro TRV_SLOT_FILLED 1
#macro TRV_SLOT_GHOST  2   // the item is being dragged out of here

/// @func   TrvGrid(_x, _y, _cols, _rows, _cell, _gap)
/// @desc   A grid of inventory slots with hover, selection, drag and drop, and a staggered reveal.
///
/// @param  {Real} _x     Left edge in pixels.
/// @param  {Real} _y     Top edge in pixels.
/// @param  {Real} _cols  Columns.
/// @param  {Real} _rows  Rows.
/// @param  {Real} _cell  Slot size in pixels.
/// @param  {Real} _gap   Gap between slots in pixels.
function TrvGrid(_x, _y, _cols, _rows, _cell, _gap = 10) constructor {
    gridX = _x;  gridY = _y;
    cols  = _cols;  rows = _rows;
    cell  = _cell;  gap  = _gap;

    capacity = cols * rows;
    items    = array_create(capacity, undefined);

    hover    = -1;
    selected = -1;
    dragFrom = -1;
    dragItem = undefined;

    elapsed  = 0;      // seconds since the grid was revealed, drives the stagger
    revealed = true;

    // One lift spring and one glow spring per slot. Stiff and well damped: an inventory should
    // feel responsive rather than floaty, so this is a quick rise with a small overshoot, not a
    // wobble.
    lift = array_create(capacity);
    glow = array_create(capacity);
    for (var _i = 0; _i < capacity; _i++) {
        lift[_i] = trv_spring_make(260, 22, 0);
        glow[_i] = trv_spring_make(180, 20, 0);
    }

    // The dragged item's position springs toward the pointer rather than snapping to it, which is
    // what gives the drag weight. Low stiffness on purpose — this is the one motion in the package
    // that is allowed to lag.
    dragSpringX = trv_spring_make(150, 18, 0);
    dragSpringY = trv_spring_make(150, 18, 0);

    /// @func   set(_index, _item)
    /// @desc   Places an item in a slot. Pass undefined to clear it.
    /// @param  {Real}   _index  Slot index.
    /// @param  {Struct} _item   A TrvItem, or undefined.
    /// @return {Struct} self.
    static set = function(_index, _item) {
        if (_index >= 0 && _index < capacity) items[_index] = _item;
        return self;
    };

    /// @func   add(_item)
    /// @desc   Places an item in the first free slot.
    /// @param  {Struct} _item  A TrvItem.
    /// @return {Real} The slot index used, or -1 if the grid is full.
    static add = function(_item) {
        for (var _i = 0; _i < capacity; _i++) {
            if (is_undefined(items[_i])) { items[_i] = _item; return _i; }
        }
        return -1;
    };

    /// @func   reveal()
    /// @desc   Restarts the staggered entrance. Call it when the inventory screen opens.
    /// @return {Struct} self.
    static reveal = function() { elapsed = 0; revealed = true; return self; };

    /// @func   slot_x(_index)
    /// @desc   The left edge of a slot in pixels.
    /// @param  {Real} _index  Slot index.
    /// @return {Real} x.
    static slot_x = function(_index) { return gridX + (_index mod cols) * (cell + gap); };

    /// @func   slot_y(_index)
    /// @desc   The top edge of a slot in pixels, ignoring hover lift.
    /// @param  {Real} _index  Slot index.
    /// @return {Real} y.
    static slot_y = function(_index) { return gridY + (_index div cols) * (cell + gap); };

    /// @func   index_at(_mx, _my)
    /// @desc   Which slot the pointer is over.
    /// @param  {Real} _mx  Pointer x.
    /// @param  {Real} _my  Pointer y.
    /// @return {Real} Slot index, or -1.
    static index_at = function(_mx, _my) {
        var _step = cell + gap;
        var _c = floor((_mx - gridX) / _step);
        var _r = floor((_my - gridY) / _step);
        if (_c < 0 || _c >= cols || _r < 0 || _r >= rows) return -1;
        // Reject the gap itself so the hover does not smear across the whole row.
        if ((_mx - gridX) - _c * _step > cell) return -1;
        if ((_my - gridY) - _r * _step > cell) return -1;
        return _r * cols + _c;
    };

    /// @func   update(_dt, _mx, _my, _pressed, _released)
    /// @desc   Advances every spring and resolves pointer interaction. Call once per step.
    ///
    /// @remarks Pointer state is PASSED IN rather than read from mouse_x / mouse_check_button.
    ///          Trove has no idea whether your inventory is drawn in the Draw GUI event, inside a
    ///          scaled viewport, on a surface, or driven by a gamepad — and a library that reads
    ///          the mouse directly is wrong in three of those four cases. Pass whatever coordinate
    ///          space you are drawing in.
    ///
    /// @param  {Real} _dt        Delta time in seconds.
    /// @param  {Real} _mx        Pointer x in the same space the grid is drawn in.
    /// @param  {Real} _my        Pointer y.
    /// @param  {Bool} _pressed   True on the frame the select button went down.
    /// @param  {Bool} _released  True on the frame it came up.
    /// @return {Real} The slot index under the pointer, or -1.
    static update = function(_dt, _mx, _my, _pressed = false, _released = false) {
        elapsed += _dt;
        hover = index_at(_mx, _my);

        // --- pick up / put down ----------------------------------------------------------
        if (_pressed && hover >= 0) {
            selected = hover;
            if (!is_undefined(items[hover])) {
                dragFrom = hover;
                dragItem = items[hover];
                dragSpringX.value = slot_x(hover);  dragSpringX.velocity = 0;
                dragSpringY.value = slot_y(hover);  dragSpringY.velocity = 0;
            }
        }
        if (_released && dragFrom >= 0) {
            // Dropping onto another slot SWAPS. Swapping rather than refusing is the behaviour
            // players expect from every inventory they have ever used, and refusing a drop is the
            // most common complaint about hand-rolled ones.
            if (hover >= 0 && hover != dragFrom) {
                var _tmp = items[hover];
                items[hover] = items[dragFrom];
                items[dragFrom] = _tmp;
                selected = hover;
            }
            dragFrom = -1;
            dragItem = undefined;
        }

        // --- retarget the springs ---------------------------------------------------------
        for (var _i = 0; _i < capacity; _i++) {
            var _want = (_i == hover && dragFrom < 0) ? 1 : 0;
            lift[_i].target = _want;
            glow[_i].target = (_i == selected) ? 1 : _want * 0.55;
            trv_spring_step(lift[_i], _dt);
            trv_spring_step(glow[_i], _dt);
        }

        if (dragFrom >= 0) {
            dragSpringX.target = _mx - cell * 0.5;
            dragSpringY.target = _my - cell * 0.5;
            trv_spring_step(dragSpringX, _dt);
            trv_spring_step(dragSpringY, _dt);
        }

        return hover;
    };

    /// @func   draw()
    /// @desc   Draws every slot, then the dragged item on top of all of them.
    /// @remarks The dragged item is drawn LAST, in a second pass, for the obvious reason and one
    ///          less obvious one: drawn in slot order it would pass BEHIND slots later in the grid
    ///          and in front of earlier ones, so dragging left would look correct and dragging
    ///          right would look broken.
    static draw = function() {
        for (var _i = 0; _i < capacity; _i++) {
            if (_i == dragFrom) continue;
            var _t = revealed ? trv_stagger(_i, capacity, elapsed, 0.34, 0.955) : 1;
            if (_t <= 0) continue;
            trv_draw_slot(slot_x(_i), slot_y(_i), cell, items[_i],
                          lift[_i].value, glow[_i].value, _t, elapsed,
                          _i == selected, TRV_SLOT_FILLED);
        }
        if (dragFrom >= 0) {
            // The vacated slot keeps a dim ghost so the player can see where the item came from.
            trv_draw_slot(slot_x(dragFrom), slot_y(dragFrom), cell, dragItem,
                          0, 0, 1, elapsed, false, TRV_SLOT_GHOST);
            trv_draw_slot(dragSpringX.value, dragSpringY.value, cell, dragItem,
                          1, 1, 1, elapsed, true, TRV_SLOT_FILLED);
        }
    };

    /// @func   item_at_hover()
    /// @desc   The item under the pointer, for driving a tooltip or detail panel.
    /// @return {Struct} A TrvItem, or undefined.
    static item_at_hover = function() {
        return (hover >= 0) ? items[hover] : undefined;
    };

    /// @func   item_selected()
    /// @desc   The currently selected item.
    /// @return {Struct} A TrvItem, or undefined.
    static item_selected = function() {
        return (selected >= 0 && selected < capacity) ? items[selected] : undefined;
    };
}

/// @func   trv_draw_slot(_x, _y, _size, _item, _lift, _glow, _reveal, _time, _is_selected, _state)
/// @desc   Draws one inventory slot, with its rarity treatment.
///
/// @remarks THE RARITY TREATMENT IS THE PRODUCT, so it is worth saying what each tier adds and
///          why it stops where it does:
///
///            COMMON     plain slot. No frame, no glow. It has to be plain or nothing else reads
///                       as special — a ladder where every rung is decorated has no ladder.
///            UNCOMMON   corner ticks only.
///            RARE       a full frame in the tier colour.
///            EPIC       frame plus a slow travelling highlight around it.
///            LEGENDARY  frame, outer glow, faster travel.
///            MYTHIC     all of it, at full intensity.
///
///          The travelling highlight is a light that WALKS THE PERIMETER rather than a flash of
///          the whole border. A flashing border pulses in time with every other flashing border on
///          screen and turns an inventory into a Christmas tree; a travelling light reads as one
///          object being special.
///
/// @param  {Real}   _x            Slot left edge.
/// @param  {Real}   _y            Slot top edge.
/// @param  {Real}   _size         Slot size in pixels.
/// @param  {Struct} _item         A TrvItem, or undefined for an empty slot.
/// @param  {Real}   _lift         Hover lift, 0 to 1 (may overshoot past 1 — that is the spring).
/// @param  {Real}   _glow         Glow intensity, 0 to 1.
/// @param  {Real}   _reveal       Entrance progress, 0 to 1.
/// @param  {Real}   _time         Seconds, for the travelling highlight.
/// @param  {Bool}   _is_selected  Draw the selection treatment.
/// @param  {Real}   _state        One of the TRV_SLOT_* constants.
function trv_draw_slot(_x, _y, _size, _item, _lift = 0, _glow = 0, _reveal = 1, _time = 0,
                       _is_selected = false, _state = TRV_SLOT_FILLED) {
    if (_reveal <= 0) return;

    var _th = trv_theme_get();

    // --- entrance ---------------------------------------------------------------------------
    // Rise and fade, eased out. The slide is deliberately small: a long slide on 48 slots reads
    // as a loading screen rather than as a UI opening.
    var _e   = trv_ease(_reveal, TRV_EASE_OUT_CUBIC);
    var _dy  = (1 - _e) * _size * 0.45;
    var _a   = _e * ((_state == TRV_SLOT_GHOST) ? 0.28 : 1);

    // --- hover lift -------------------------------------------------------------------------
    var _l   = _lift;
    var _sz  = _size * (1 + _l * 0.055);
    var _px  = _x - (_sz - _size) * 0.5;
    var _py  = _y - (_sz - _size) * 0.5 - _l * _size * 0.06 + _dy;
    var _rad = max(3, _size * 0.16);

    var _rarity = is_undefined(_item) ? trv_rarity(TRV_RARITY_COMMON) : trv_rarity(_item.rarity);
    var _has    = !is_undefined(_item);

    // --- rarity glow, behind everything -------------------------------------------------------
    if (_has && _rarity.glow > 0) {
        trv_draw_glow(_px, _py, _sz, _sz, _rad, _rarity.c,
                      _a * _rarity.glow * (0.055 + _glow * 0.05), 6, 2.4);
    }
    if (_glow > 0.01) {
        trv_draw_glow(_px, _py, _sz, _sz, _rad, _th.accent, _a * _glow * 0.05, 5, 1.9);
    }

    // --- body ----------------------------------------------------------------------------------
    var _top = trv_colour_mix(_th.surface, _th.surfaceHi, 0.35 + _l * 0.4);
    var _bot = _th.surfaceLo;
    trv_draw_round_rect(_px, _py, _sz, _sz, _rad, _bot, _a * 0.96);
    trv_draw_gradient_v(_px + 1, _py + 1, _sz - 2, _sz * 0.62, _top, _bot, _a * 0.55, 0);

    // An empty slot is INSET rather than absent: a hole in a grid reads as a rendering bug, and a
    // visible empty slot is also the thing that tells a player how much room they have left.
    if (!_has) {
        trv_draw_round_rect_outline(_px + 1, _py + 1, _sz - 2, _sz - 2, _rad,
                                    _th.surfaceLo, _a * 0.9, max(1, _size * 0.02));
        var _d = _size * 0.055;
        draw_set_alpha(_a * 0.30);
        draw_set_colour(_th.textDim);
        draw_circle(_px + _sz * 0.5, _py + _sz * 0.5, _d, false);
        draw_set_alpha(1);
        draw_set_colour(c_white);
        return;
    }

    // --- rarity frame ----------------------------------------------------------------------
    var _fw = max(1, _size * (0.018 + _rarity.frame * 0.010));
    if (_rarity.frame >= 2) {
        trv_draw_round_rect_outline(_px, _py, _sz, _sz, _rad, _rarity.c, _a * 0.92, _fw);
    } else {
        trv_draw_round_rect_outline(_px, _py, _sz, _sz, _rad, _th.edge, _a * _th.edgeAlpha, _fw);
    }
    if (_rarity.frame >= 1) {
        trv_draw_corner_ticks(_px, _py, _sz, _sz, _size * 0.20, _rarity.c, _a * 0.85,
                              max(1, _size * 0.022));
    }

    // --- the icon ---------------------------------------------------------------------------
    var _ib = _sz * 0.62;
    trv_icon_draw(_item.icon, _px + (_sz - _ib) * 0.5, _py + (_sz - _ib) * 0.5 - _sz * 0.03,
                  _ib, _item.palette(), _a);

    // --- travelling highlight, epic and above ------------------------------------------------
    if (_rarity.shimmer > 0) {
        trv_draw_slot_travel(_px, _py, _sz, _rad, _rarity.c,
                             _a * (0.30 + _rarity.shimmer * 0.55),
                             _time * (0.16 + _rarity.shimmer * 0.30));
    }

    // --- stack count -------------------------------------------------------------------------
    if (_item.count > 1) {
        var _cs = _size * 0.155;
        var _ct = string(_item.count);
        var _cw = trv_text_width(_ct, _cs) + _size * 0.10;
        trv_draw_round_rect(_px + _sz - _cw - _size * 0.05, _py + _sz - _cs - _size * 0.11,
                            _cw, _cs + _size * 0.09, _size * 0.045, _th.backdropTop, _a * 0.86);
        trv_draw_text_right(_px + _sz - _size * 0.10, _py + _sz - _cs - _size * 0.065,
                            _ct, _cs, _th.text, _a);
    }

    // --- selection --------------------------------------------------------------------------
    if (_is_selected) {
        trv_draw_round_rect_outline(_px - _size * 0.045, _py - _size * 0.045,
                                    _sz + _size * 0.09, _sz + _size * 0.09,
                                    _rad + _size * 0.03, _th.accent, _a * 0.95,
                                    max(1, _size * 0.028));
    }
}

/// @func   trv_draw_slot_travel(_x, _y, _size, _radius, _colour, _alpha, _phase)
/// @desc   A light that walks the perimeter of a slot. The legendary treatment.
///
/// @remarks Walks the same point list trv_draw_round_rect_outline strokes, so the light follows
///          the exact border geometry including the corner arcs — offsetting a separate path would
///          drift out of register at the corners, which is precisely where the eye is drawn.
///
///          The falloff is computed on PERIMETER DISTANCE, not on index, so the light does not
///          speed up through the corners where the points bunch together.
///
/// @param  {Real} _x       Slot left edge.
/// @param  {Real} _y       Slot top edge.
/// @param  {Real} _size    Slot size.
/// @param  {Real} _radius  Corner radius.
/// @param  {Real} _colour  Light colour.
/// @param  {Real} _alpha   Peak alpha.
/// @param  {Real} _phase   Position around the perimeter, in turns. Fractional part is used.
function trv_draw_slot_travel(_x, _y, _size, _radius, _colour, _alpha, _phase) {
    if (_alpha <= 0) return;

    var _pts = trv_round_rect_points(_x, _y, _size, _size, _radius);
    var _n   = array_length(_pts) div 2;

    // Cumulative perimeter distance at each vertex.
    var _cum = array_create(_n + 1, 0);
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n;
        _cum[_i + 1] = _cum[_i] + point_distance(_pts[_i * 2], _pts[_i * 2 + 1],
                                                 _pts[_j * 2], _pts[_j * 2 + 1]);
    }
    var _total = _cum[_n];
    if (_total <= 0) return;

    var _head = frac(abs(_phase)) * _total;
    var _tail = _total * 0.30;          // length of the lit arc
    var _w    = max(1, _size * 0.035);

    draw_set_colour(_colour);
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n;
        // Distance BACKWARD from the head to this segment, wrapped.
        var _d = _head - _cum[_i];
        if (_d < 0) _d += _total;
        if (_d > _tail) continue;
        var _f = 1 - (_d / _tail);
        draw_set_alpha(_alpha * _f * _f);
        draw_line_width(_pts[_i * 2], _pts[_i * 2 + 1], _pts[_j * 2], _pts[_j * 2 + 1], _w);
    }
    draw_set_alpha(1);
    draw_set_colour(c_white);
}

/// @func   trv_draw_detail(_x, _y, _w, _h, _item, _reveal, _time)
/// @desc   The detail panel: the selected item at a size where the icon geometry is worth looking
///         at, its rarity, its stats and its flavour line.
///
/// @remarks THIS PANEL IS THE ARGUMENT FOR DRAWING ICONS FROM GEOMETRY. It renders the same icon
///          the 64 px slot did, at 150 px, from the same nine polygons, with no second asset and
///          no resampling. With a spritesheet this panel is either blurry or needs a second,
///          larger, separately authored set of art for every item in the game.
///
/// @param  {Real}   _x       Panel left edge.
/// @param  {Real}   _y       Panel top edge.
/// @param  {Real}   _w       Panel width.
/// @param  {Real}   _h       Panel height.
/// @param  {Struct} _item    A TrvItem, or undefined for the empty state.
/// @param  {Real}   _reveal  Entrance progress, 0 to 1.
/// @param  {Real}   _time    Seconds, for the travelling highlight on the big icon's frame.
function trv_draw_detail(_x, _y, _w, _h, _item, _reveal = 1, _time = 0) {
    if (_reveal <= 0) return;
    var _th = trv_theme_get();
    var _e  = trv_ease(clamp(_reveal, 0, 1), TRV_EASE_OUT_CUBIC);
    var _a  = _e;
    var _dx = (1 - _e) * 26;

    trv_draw_panel(_x + _dx, _y, _w, _h, _a);

    var _pad = _w * 0.075;
    var _cx  = _x + _dx + _w * 0.5;

    if (is_undefined(_item)) {
        trv_draw_text_centred(_cx, _y + _h * 0.46, "NOTHING SELECTED", _w * 0.055,
                              _th.textDim, _a * 0.7);
        return;
    }

    var _rarity = trv_rarity(_item.rarity);

    // --- the big icon, in a framed well --------------------------------------------------------
    var _wellSize = min(_w - _pad * 2, _h * 0.34);
    var _wx = _cx - _wellSize * 0.5, _wy = _y + _pad;
    var _wr = _wellSize * 0.12;

    if (_rarity.glow > 0) {
        trv_draw_glow(_wx, _wy, _wellSize, _wellSize, _wr, _rarity.c, _a * _rarity.glow * 0.075, 7, 3);
    }
    trv_draw_round_rect(_wx, _wy, _wellSize, _wellSize, _wr, _th.surfaceLo, _a * 0.9);
    trv_draw_gradient_v(_wx + 1, _wy + 1, _wellSize - 2, _wellSize * 0.6,
                        trv_colour_mix(_th.surface, _th.surfaceHi, 0.5), _th.surfaceLo, _a * 0.5, 0);
    trv_draw_round_rect_outline(_wx, _wy, _wellSize, _wellSize, _wr, _rarity.c,
                                _a * 0.85, max(1, _wellSize * 0.014));

    var _ib = _wellSize * 0.70;
    trv_icon_draw(_item.icon, _wx + (_wellSize - _ib) * 0.5, _wy + (_wellSize - _ib) * 0.5,
                  _ib, _item.palette(), _a);

    if (_rarity.shimmer > 0) {
        trv_draw_slot_travel(_wx, _wy, _wellSize, _wr, _rarity.c,
                             _a * (0.28 + _rarity.shimmer * 0.5),
                             _time * (0.12 + _rarity.shimmer * 0.22));
    }

    // --- name, fitted to the panel --------------------------------------------------------------
    // trv_text_fit_size, not a fixed size: a caller-supplied item name longer than the panel was
    // designed for is the single most likely way this panel breaks in a real game.
    var _ty = _wy + _wellSize + _pad * 0.9;
    var _nameSize = trv_text_fit_size(_item.name, _w * 0.088, _w - _pad * 2);
    trv_draw_text_centred(_cx, _ty, _item.name, _nameSize, _th.text, _a);
    _ty += _nameSize * 1.5;

    // --- rarity and material line --------------------------------------------------------------
    var _sub = _rarity.n + "  ·  " + trv_material_name(_item.material);
    var _subSize = trv_text_fit_size(_sub, _w * 0.050, _w - _pad * 2);
    trv_draw_text_centred(_cx, _ty, _sub, _subSize, _rarity.c, _a * 0.95);
    _ty += _subSize * 2.4;

    // --- rule ---------------------------------------------------------------------------------
    draw_set_alpha(_a * 0.35);
    draw_set_colour(_th.edge);
    draw_line_width(_x + _dx + _pad, _ty, _x + _dx + _w - _pad, _ty, 1);
    draw_set_alpha(1);
    _ty += _pad * 0.7;

    // --- stats ---------------------------------------------------------------------------------
    var _statSize = _w * 0.048;
    for (var _i = 0; _i < array_length(_item.stats); _i++) {
        var _s = _item.stats[_i];
        trv_draw_text(_x + _dx + _pad, _ty, _s.k, _statSize, _th.textDim, _a * 0.9);
        trv_draw_text_right(_x + _dx + _w - _pad, _ty, string(_s.v), _statSize, _th.text, _a);
        _ty += _statSize * 1.85;
    }

    // --- flavour --------------------------------------------------------------------------------
    if (_item.blurb != "") {
        _ty += _pad * 0.35;
        var _bs = trv_text_fit_size(_item.blurb, _w * 0.042, _w - _pad * 2);
        trv_draw_text_centred(_cx, _ty, _item.blurb, _bs, _th.textDim, _a * 0.78);
    }

    // --- value footer ---------------------------------------------------------------------------
    if (_item.value > 0) {
        var _fy = _y + _h - _pad * 1.5;
        var _vs = _w * 0.052;
        trv_icon_draw(trv_icon_find("COIN"), _x + _dx + _pad, _fy - _vs * 0.25, _vs * 1.5,
                      trv_material_palette(trv_material_find("GOLD")), _a);
        trv_draw_text_right(_x + _dx + _w - _pad, _fy, string(_item.value), _vs, _th.text, _a);
    }
}

/// @func   TrvToasts(_x, _y, _w)
/// @desc   A queue of loot notifications that slide in, stack, and expire.
///
/// @remarks Included because "you picked something up" is the one inventory moment that happens
///          while the inventory is CLOSED, and it is almost always the ugliest part of a
///          hand-rolled implementation — usually a string drawn at a fixed position that flickers
///          when two items land in the same frame.
///
/// @param  {Real} _x  Right edge x, toasts are right-aligned to it.
/// @param  {Real} _y  Top edge y of the first toast.
/// @param  {Real} _w  Toast width.
function TrvToasts(_x, _y, _w) constructor {
    toastX = _x;  toastY = _y;  toastW = _w;
    lifetime = 3.4;
    live = [];

    /// @func   push(_item)
    /// @desc   Queues a notification for an item.
    /// @param  {Struct} _item  A TrvItem.
    /// @return {Struct} self.
    static push = function(_item) {
        array_push(live, {
            item : _item,
            age  : 0,
            slide: trv_spring_make(210, 21, 1),   // 1 = off-screen right, 0 = home
            rise : trv_spring_make(240, 24, 0)    // vertical position, in toast heights
        });
        return self;
    };

    /// @func   update(_dt)
    /// @desc   Ages every toast, retargets the stack, and reaps the expired.
    /// @param  {Real} _dt  Delta time in seconds.
    static update = function(_dt) {
        for (var _i = array_length(live) - 1; _i >= 0; _i--) {
            var _t = live[_i];
            _t.age += _dt;
            // Newest at the top: index 0 is the oldest, so it is pushed furthest DOWN. The stack
            // is retargeted every frame rather than positioned once, which is what lets a toast
            // expiring out of the middle close the gap smoothly instead of teleporting.
            _t.rise.target  = array_length(live) - 1 - _i;
            _t.slide.target = (_t.age > lifetime) ? 1 : 0;
            trv_spring_step(_t.slide, _dt);
            trv_spring_step(_t.rise, _dt);
            if (_t.age > lifetime && _t.slide.value > 0.985) array_delete(live, _i, 1);
        }
    };

    /// @func   draw()
    /// @desc   Draws the live toasts.
    static draw = function() {
        var _th = trv_theme_get();
        var _h  = toastW * 0.235;
        for (var _i = 0; _i < array_length(live); _i++) {
            var _t = live[_i];
            var _r = trv_rarity(_t.item.rarity);
            var _ox = toastX + _t.slide.value * (toastW + 40);
            var _oy = toastY + _t.rise.value * (_h + 10);
            var _a  = 1 - clamp(_t.slide.value, 0, 1);
            if (_a <= 0.01) continue;

            if (_r.glow > 0) trv_draw_glow(_ox, _oy, toastW, _h, _h * 0.28, _r.c, _a * _r.glow * 0.06, 5, 2);
            trv_draw_round_rect(_ox, _oy, toastW, _h, _h * 0.28, _th.surface, _a * _th.panelAlpha);
            trv_draw_round_rect_outline(_ox, _oy, toastW, _h, _h * 0.28, _r.c, _a * 0.8, 2);

            var _ib = _h * 0.66;
            trv_icon_draw(_t.item.icon, _ox + _h * 0.20, _oy + (_h - _ib) * 0.5, _ib,
                          _t.item.palette(), _a);

            var _tx = _ox + _h * 0.20 + _ib + _h * 0.20;
            var _ns = trv_text_fit_size(_t.item.name, _h * 0.28, toastW - (_tx - _ox) - _h * 0.25);
            trv_draw_text(_tx, _oy + _h * 0.24, _t.item.name, _ns, _th.text, _a);
            trv_draw_text(_tx, _oy + _h * 0.60, _r.n, _h * 0.19, _r.c, _a * 0.9);
        }
    };
}

/// @func   trv_draw_filter_rail(_x, _y, _w, _item_h, _active, _hover, _reveal)
/// @desc   The category rail down the side of an inventory. Draws six rows — ALL plus the five
///         icon categories — and returns nothing; hit-testing is trv_filter_index_at.
///
/// @param  {Real} _x       Left edge.
/// @param  {Real} _y       Top edge.
/// @param  {Real} _w       Width.
/// @param  {Real} _item_h  Row height.
/// @param  {Real} _active  Index of the active row, 0 = ALL.
/// @param  {Real} _hover   Index of the hovered row, or -1.
/// @param  {Real} _reveal  Entrance progress, 0 to 1.
function trv_draw_filter_rail(_x, _y, _w, _item_h, _active, _hover = -1, _reveal = 1) {
    var _th = trv_theme_get();
    var _labels = ["ALL", "WEAPONS", "ARMOUR", "SUPPLIES", "ARCANE", "MATERIALS"];
    for (var _i = 0; _i < array_length(_labels); _i++) {
        var _t = trv_stagger(_i, array_length(_labels), _reveal * 0.8, 0.28, 0.7);
        if (_t <= 0) continue;
        var _e = trv_ease(_t, TRV_EASE_OUT_CUBIC);
        var _ry = _y + _i * _item_h;
        var _rx = _x - (1 - _e) * 24;
        var _on = (_i == _active);
        var _hv = (_i == _hover);

        if (_on) {
            trv_draw_round_rect(_rx, _ry, _w, _item_h * 0.86, _item_h * 0.2,
                                trv_colour_mix(_th.surface, _th.accent, 0.28), _e * 0.9);
            draw_set_alpha(_e);
            draw_set_colour(_th.accent);
            draw_rectangle(_rx, _ry + _item_h * 0.12, _rx + max(2, _w * 0.022),
                           _ry + _item_h * 0.74, false);
            draw_set_alpha(1);
        } else if (_hv) {
            trv_draw_round_rect(_rx, _ry, _w, _item_h * 0.86, _item_h * 0.2, _th.hover, _e * 0.45);
        }

        trv_draw_text(_rx + _w * 0.13, _ry + _item_h * 0.30, _labels[_i], _item_h * 0.30,
                      _on ? _th.text : _th.textDim, _e * (_on ? 1 : 0.8));
    }
}

/// @func   trv_filter_index_at(_x, _y, _w, _item_h, _mx, _my)
/// @desc   Which filter row the pointer is over.
/// @param  {Real} _x       Rail left edge.
/// @param  {Real} _y       Rail top edge.
/// @param  {Real} _w       Rail width.
/// @param  {Real} _item_h  Row height.
/// @param  {Real} _mx      Pointer x.
/// @param  {Real} _my      Pointer y.
/// @return {Real} Row index 0..5, or -1.
function trv_filter_index_at(_x, _y, _w, _item_h, _mx, _my) {
    if (_mx < _x || _mx > _x + _w) return -1;
    var _i = floor((_my - _y) / _item_h);
    if (_i < 0 || _i > 5) return -1;
    if ((_my - _y) - _i * _item_h > _item_h * 0.86) return -1;
    return _i;
}
