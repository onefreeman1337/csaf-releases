{
  "$GMScript": "v1",
  "%Name": "trv_inventory",
  "isCompatibility": false,
  "isDnD": false,
  "name": "trv_inventory",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}