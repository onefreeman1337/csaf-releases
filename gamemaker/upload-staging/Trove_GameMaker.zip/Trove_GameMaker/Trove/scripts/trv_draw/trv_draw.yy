{
  "$GMScript": "v1",
  "%Name": "trv_draw",
  "isCompatibility": false,
  "isDnD": false,
  "name": "trv_draw",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}