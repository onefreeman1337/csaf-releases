/// @file    trv_icon.gml
/// @package Trove for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary The icon forge. Seventy-five item forms described as vector geometry and drawn with
///          primitives, over twelve material palettes derived by colour maths. No PNG, no atlas,
///          no texture page, no fixed resolution.
///
/// @remarks WHY THIS FILE EXISTS AT ALL.
///
///          Every inventory asset for GameMaker on the market ships the ARRANGEMENT and expects
///          you to bring the pictures. The most expensive one says so in its own store text. So a
///          developer building an RPG buys an inventory, and then buys an icon pack, and then
///          discovers the pack has 60 icons in one art style at one pixel size, and their game
///          needs a copper version, and a cursed version, and one at 64px for the detail panel.
///
///          Trove takes the other road. An icon here is not an image. It is a short list of
///          polygons, discs and strokes on a ten-by-ten grid, coloured by ROLE rather than by
///          value — blade, grip, accent, shade, light — and a material palette supplies the five
///          actual colours at draw time. That has four consequences that a spritesheet cannot
///          have:
///
///            1. SCALE. The same sword is exact at 18 px in a hotbar and at 512 px on a shop
///               banner. There is nothing to resample.
///            2. RECOLOUR. Seventy-five forms times twelve materials is 900 distinct icons, and a
///               thirteenth material is six numbers. An iron sword and a gold sword are the same
///               nine polygons.
///            3. NO TEXTURE PAGE. Dropping Trove into an existing project cannot disturb that
///               project's atlas packing, because it adds nothing to it.
///            4. RUNTIME AUTHORING. A cursed variant, a rarity tint, a damaged state or a
///               procedurally generated loot table can pick colours at runtime. A PNG cannot.
///
///          WHAT THIS IS NOT. It is not a pixel-art style and it does not pretend to be. It is a
///          clean geometric look, deliberately, because that is what survives arbitrary scaling.
///          If your game is 16x16 pixel art, use a pixel icon pack — Trove will not match it and
///          this file says so rather than letting you find out after paying.
///
///          COORDINATE SYSTEM. x and y both run 0 to 10, y downward, origin top-left of the icon
///          box. Shapes may exceed that box slightly; the renderer does not clip, so keep a
///          little air at the edges or icons will collide in a tight grid.

// --- shape kinds -------------------------------------------------------------------------------
#macro TRV_SHAPE_POLY 0   // filled polygon, p = flat x,y list, wound either way
#macro TRV_SHAPE_LINE 1   // stroked polyline, p = flat x,y list, w = weight in grid units
#macro TRV_SHAPE_DISC 2   // filled circle, p = [cx, cy, radius]
#macro TRV_SHAPE_RING 3   // stroked circle, p = [cx, cy, radius], w = weight
#macro TRV_SHAPE_RECT 4   // filled axis-aligned rectangle, p = [x, y, w, h]

// --- colour roles, indices into a material palette ----------------------------------------------
#macro TRV_ROLE_MAIN   0   // the body: blade steel, glass, parchment
#macro TRV_ROLE_GRIP   1   // what a hand touches: haft, leather, wood
#macro TRV_ROLE_ACCENT 2   // the eye-catch: gem, liquid, glow, gold trim
#macro TRV_ROLE_SHADE  3   // recesses and separations
#macro TRV_ROLE_LIGHT  4   // the lit edge

/// @func   trv_sp(_role, _points)
/// @desc   Filled polygon shape. Terse by design — the icon table below is data, and data reads
///         better without ceremony.
/// @param  {Real}  _role     One of the TRV_ROLE_* constants.
/// @param  {Array} _points   Flat x,y list on the 0..10 grid.
/// @return {Struct} A shape.
/// @pure
function trv_sp(_role, _points) { return { k: TRV_SHAPE_POLY, r: _role, p: _points, w: 0 }; }

/// @func   trv_sl(_role, _weight, _points)
/// @desc   Stroked polyline shape.
/// @param  {Real}  _role     One of the TRV_ROLE_* constants.
/// @param  {Real}  _weight   Stroke weight in grid units (1.0 = a tenth of the icon).
/// @param  {Array} _points   Flat x,y list.
/// @return {Struct} A shape.
/// @pure
function trv_sl(_role, _weight, _points) { return { k: TRV_SHAPE_LINE, r: _role, p: _points, w: _weight }; }

/// @func   trv_sd(_role, _cx, _cy, _radius)
/// @desc   Filled disc shape.
/// @return {Struct} A shape.
/// @pure
function trv_sd(_role, _cx, _cy, _radius) { return { k: TRV_SHAPE_DISC, r: _role, p: [_cx, _cy, _radius], w: 0 }; }

/// @func   trv_so(_role, _weight, _cx, _cy, _radius)
/// @desc   Stroked ring shape.
/// @return {Struct} A shape.
/// @pure
function trv_so(_role, _weight, _cx, _cy, _radius) { return { k: TRV_SHAPE_RING, r: _role, p: [_cx, _cy, _radius], w: _weight }; }

/// @func   trv_sr(_role, _x, _y, _w, _h)
/// @desc   Filled rectangle shape.
/// @return {Struct} A shape.
/// @pure
function trv_sr(_role, _x, _y, _w, _h) { return { k: TRV_SHAPE_RECT, r: _role, p: [_x, _y, _w, _h], w: 0 }; }

// =================================================================================================
// THE ICON TABLE
//
// Seventy-five forms. Ordered by category so the demo can page through them, and so a buyer reading
// the file can find the one they want to modify. Each entry is { n: name, c: category, s: shapes }.
//
// AUTHORING NOTES, learned by rendering these and looking at them:
//   · Silhouette first. An icon that is unreadable in one flat colour is unreadable at 20 px.
//   · Three to nine shapes. Past that the detail turns to mud below 48 px and costs draw calls.
//   · Put the ACCENT role on exactly one small area. Two competing accents read as clutter.
//   · Diagonals want to run corner to corner. A sword at 45 degrees fills the box; a vertical one
//     wastes a third of it and reads smaller than its neighbours at the same size.
// =================================================================================================

#macro TRV_CAT_WEAPON     0
#macro TRV_CAT_ARMOUR     1
#macro TRV_CAT_CONSUMABLE 2
#macro TRV_CAT_ARCANE     3
#macro TRV_CAT_MATERIAL   4

/// @func   trv_icon_build()
/// @desc   Builds the icon table. Called once, lazily, by trv_icon_get.
/// @return {Array} Array of { n, c, s } structs.
function trv_icon_build() {
    var _i = [];

    // ------------------------------------------------------------------ weapons ---------------
    array_push(_i, { n: "SWORD", c: TRV_CAT_WEAPON, s: [
        trv_sp(TRV_ROLE_MAIN,  [4.1,0.5, 5.9,0.5, 5.9,6.0, 5.0,7.1, 4.1,6.0]),
        trv_sl(TRV_ROLE_LIGHT, 0.35, [4.6,1.2, 4.6,5.8]),
        trv_sp(TRV_ROLE_ACCENT,[2.3,6.0, 7.7,6.0, 7.2,6.9, 2.8,6.9]),
        trv_sr(TRV_ROLE_GRIP,  4.45,6.9, 1.1, 2.1),
        trv_sd(TRV_ROLE_ACCENT,5.0, 9.3, 0.75) ]});

    array_push(_i, { n: "GREATSWORD", c: TRV_CAT_WEAPON, s: [
        trv_sp(TRV_ROLE_MAIN,  [3.6,0.4, 6.4,0.4, 6.4,5.6, 5.0,7.0, 3.6,5.6]),
        trv_sl(TRV_ROLE_SHADE, 0.3,  [5.0,0.9, 5.0,6.4]),
        trv_sp(TRV_ROLE_ACCENT,[1.5,5.6, 8.5,5.6, 8.5,6.6, 1.5,6.6]),
        trv_sr(TRV_ROLE_GRIP,  4.3, 6.6, 1.4, 2.4),
        trv_sp(TRV_ROLE_ACCENT,[3.9,9.0, 6.1,9.0, 5.0,10.0]) ]});

    array_push(_i, { n: "DAGGER", c: TRV_CAT_WEAPON, s: [
        trv_sp(TRV_ROLE_MAIN,  [4.3,1.4, 5.7,1.4, 5.7,5.6, 5.0,6.6, 4.3,5.6]),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [4.8,2.0, 4.8,5.4]),
        trv_sp(TRV_ROLE_ACCENT,[3.1,5.6, 6.9,5.6, 6.5,6.4, 3.5,6.4]),
        trv_sr(TRV_ROLE_GRIP,  4.5, 6.4, 1.0, 2.3),
        trv_sd(TRV_ROLE_ACCENT,5.0, 9.0, 0.6) ]});

    array_push(_i, { n: "KATANA", c: TRV_CAT_WEAPON, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.1,8.2, 7.4,1.0, 8.2,1.7, 2.0,8.9]),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [1.9,8.0, 7.4,2.0]),
        trv_so(TRV_ROLE_ACCENT,0.5,  1.35,8.55, 0.95),
        trv_sl(TRV_ROLE_GRIP,  1.0,  [1.0,8.9, -0.3,10.2]) ]});

    array_push(_i, { n: "AXE", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  1.0,  [6.6,1.2, 3.4,9.6]),
        trv_sp(TRV_ROLE_MAIN,  [6.2,1.0, 8.9,2.6, 8.4,5.4, 5.1,4.1]),
        trv_sl(TRV_ROLE_LIGHT, 0.35, [8.5,2.9, 8.0,5.0]),
        trv_sp(TRV_ROLE_ACCENT,[5.4,1.1, 6.9,1.7, 6.4,3.0, 5.0,2.4]) ]});

    array_push(_i, { n: "GREATAXE", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  1.1,  [5.0,0.8, 5.0,9.6]),
        trv_sp(TRV_ROLE_MAIN,  [5.0,1.0, 8.8,2.0, 8.8,5.2, 5.0,4.4]),
        trv_sp(TRV_ROLE_MAIN,  [5.0,1.0, 1.2,2.0, 1.2,5.2, 5.0,4.4]),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [8.4,2.5, 8.4,4.8]),
        trv_sd(TRV_ROLE_ACCENT,5.0, 2.7, 0.75) ]});

    array_push(_i, { n: "MACE", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  0.95, [5.0,4.4, 5.0,9.6]),
        trv_sd(TRV_ROLE_MAIN,  5.0, 3.0, 2.2),
        trv_sr(TRV_ROLE_MAIN,  4.3, 0.4, 1.4, 1.4),
        trv_sr(TRV_ROLE_MAIN,  1.0, 2.3, 1.5, 1.4),
        trv_sr(TRV_ROLE_MAIN,  7.5, 2.3, 1.5, 1.4),
        trv_sd(TRV_ROLE_ACCENT,4.4, 2.4, 0.65) ]});

    array_push(_i, { n: "WARHAMMER", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  1.0,  [5.0,3.2, 5.0,9.6]),
        trv_sp(TRV_ROLE_MAIN,  [1.4,1.0, 8.6,1.0, 8.0,3.6, 2.0,3.6]),
        trv_sl(TRV_ROLE_LIGHT, 0.35, [2.1,1.7, 7.9,1.7]),
        trv_sr(TRV_ROLE_ACCENT,4.2, 3.4, 1.6, 0.8) ]});

    array_push(_i, { n: "SPEAR", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  0.85, [6.9,2.6, 2.4,9.7]),
        trv_sp(TRV_ROLE_MAIN,  [8.6,0.5, 7.9,3.6, 5.6,3.1]),
        trv_sl(TRV_ROLE_ACCENT,0.7,  [6.2,3.0, 7.4,4.0]) ]});

    array_push(_i, { n: "HALBERD", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  0.9,  [4.6,1.6, 4.6,9.7]),
        trv_sp(TRV_ROLE_MAIN,  [4.6,0.3, 5.4,1.6, 4.6,2.2]),
        trv_sp(TRV_ROLE_MAIN,  [4.9,1.8, 8.6,2.2, 8.0,4.8, 4.9,4.2]),
        trv_sp(TRV_ROLE_ACCENT,[4.3,2.0, 2.0,2.9, 2.6,4.2, 4.3,3.8]) ]});

    array_push(_i, { n: "SCYTHE", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  0.9,  [7.0,1.6, 3.2,9.7]),
        trv_sp(TRV_ROLE_MAIN,  [7.1,1.4, 2.0,1.2, 0.6,3.4, 2.6,2.6, 6.6,2.9]),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [6.4,1.9, 2.4,1.8]) ]});

    array_push(_i, { n: "FLAIL", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  0.95, [2.4,4.6, 2.4,9.6]),
        trv_sl(TRV_ROLE_SHADE, 0.4,  [2.6,4.4, 4.6,2.6, 6.4,2.4]),
        trv_sd(TRV_ROLE_MAIN,  7.2, 2.6, 2.0),
        trv_sr(TRV_ROLE_MAIN,  6.6, 0.0, 1.2, 1.1),
        trv_sr(TRV_ROLE_MAIN,  9.0, 2.0, 1.0, 1.2),
        trv_sd(TRV_ROLE_ACCENT,6.6, 2.0, 0.6) ]});

    // The limb needs SEVEN points to read as a bow. With four it is two straight runs meeting at
    // an angle, and the icon reads as an arrow with a bracket behind it — measured by looking at
    // the catalogue page, where it was the least legible form of the seventy-five.
    array_push(_i, { n: "BOW", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  1.0,  [6.3,0.6, 7.9,1.9, 8.7,3.6, 8.9,5.0, 8.7,6.4, 7.9,8.1, 6.3,9.4]),
        trv_sl(TRV_ROLE_ACCENT,0.28, [6.3,0.6, 8.0,5.0, 6.3,9.4]),
        trv_sl(TRV_ROLE_MAIN,  0.42, [1.6,5.0, 7.9,5.0]),
        trv_sp(TRV_ROLE_MAIN,  [0.7,5.0, 2.6,4.1, 2.6,5.9]),
        trv_sp(TRV_ROLE_ACCENT,[7.9,5.0, 6.7,4.2, 6.7,5.8]) ]});

    array_push(_i, { n: "CROSSBOW", c: TRV_CAT_WEAPON, s: [
        trv_sp(TRV_ROLE_GRIP,  [4.2,1.8, 5.8,1.8, 5.8,6.4, 7.0,9.5, 4.6,9.5, 4.2,6.4]),
        trv_sl(TRV_ROLE_MAIN,  0.95, [0.8,4.4, 2.6,3.1, 5.0,2.8, 7.4,3.1, 9.2,4.4]),
        trv_sl(TRV_ROLE_ACCENT,0.3,  [0.8,4.4, 9.2,4.4]),
        trv_sp(TRV_ROLE_MAIN,  [5.0,0.4, 5.7,2.4, 4.3,2.4]),
        trv_sd(TRV_ROLE_ACCENT,5.0, 6.2, 0.6) ]});

    array_push(_i, { n: "ARROW", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  0.55, [2.0,8.4, 7.6,2.4]),
        trv_sp(TRV_ROLE_MAIN,  [8.9,1.0, 8.2,4.0, 5.9,3.3]),
        trv_sp(TRV_ROLE_ACCENT,[1.0,9.4, 3.4,8.6, 2.6,7.2, 1.4,7.8]) ]});

    array_push(_i, { n: "STAFF", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  0.9,  [5.4,3.0, 4.2,9.7]),
        trv_so(TRV_ROLE_MAIN,  0.75, 5.9, 2.2, 1.9),
        trv_sd(TRV_ROLE_ACCENT,5.9, 2.2, 1.05),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [4.8,1.2, 5.6,0.6]) ]});

    array_push(_i, { n: "WAND", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  0.75, [3.0,9.4, 6.8,3.4]),
        trv_sp(TRV_ROLE_ACCENT,[7.6,1.0, 8.8,2.6, 7.8,4.3, 6.0,3.9, 5.9,2.0]),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [6.8,2.1, 7.9,2.6]) ]});

    array_push(_i, { n: "CLAWS", c: TRV_CAT_WEAPON, s: [
        trv_sl(TRV_ROLE_GRIP,  1.0,  [1.6,6.8, 8.4,6.8]),
        trv_sp(TRV_ROLE_MAIN,  [2.0,6.4, 3.0,6.4, 2.9,1.4]),
        trv_sp(TRV_ROLE_MAIN,  [4.5,6.4, 5.5,6.4, 5.0,0.6]),
        trv_sp(TRV_ROLE_MAIN,  [7.0,6.4, 8.0,6.4, 7.1,1.4]),
        trv_sr(TRV_ROLE_ACCENT,1.6, 7.6, 6.8, 1.2) ]});

    // ------------------------------------------------------------------ armour ----------------
    array_push(_i, { n: "HELM", c: TRV_CAT_ARMOUR, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.6,6.6, 1.6,4.4, 3.2,1.6, 6.8,1.6, 8.4,4.4, 8.4,6.6, 6.6,6.6,
                                6.6,5.0, 3.4,5.0, 3.4,6.6]),
        trv_sp(TRV_ROLE_SHADE, [3.4,5.2, 6.6,5.2, 6.6,6.4, 3.4,6.4]),
        trv_sl(TRV_ROLE_ACCENT,0.5,  [5.0,1.6, 5.0,5.0]),
        trv_sp(TRV_ROLE_ACCENT,[4.4,0.4, 5.6,0.4, 5.6,1.6, 4.4,1.6]),
        trv_sr(TRV_ROLE_MAIN,  1.6, 6.8, 6.8, 1.6) ]});

    array_push(_i, { n: "GREATHELM", c: TRV_CAT_ARMOUR, s: [
        trv_sp(TRV_ROLE_MAIN,  [2.0,2.0, 8.0,2.0, 8.0,7.0, 5.0,9.4, 2.0,7.0]),
        trv_sp(TRV_ROLE_SHADE, [2.8,3.9, 4.3,3.9, 4.3,5.1, 2.8,5.1]),
        trv_sp(TRV_ROLE_SHADE, [5.7,3.9, 7.2,3.9, 7.2,5.1, 5.7,5.1]),
        trv_sl(TRV_ROLE_ACCENT,0.45, [5.0,5.8, 5.0,8.4]),
        trv_sr(TRV_ROLE_ACCENT,2.0, 1.2, 6.0, 0.9) ]});

    array_push(_i, { n: "CUIRASS", c: TRV_CAT_ARMOUR, s: [
        trv_sp(TRV_ROLE_MAIN,  [2.2,1.6, 4.0,1.6, 5.0,2.6, 6.0,1.6, 7.8,1.6, 8.6,3.6, 7.8,8.6,
                                2.2,8.6, 1.4,3.6]),
        trv_sl(TRV_ROLE_SHADE, 0.4,  [5.0,3.0, 5.0,8.4]),
        trv_sl(TRV_ROLE_ACCENT,0.4,  [2.0,5.2, 8.0,5.2]),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [2.6,2.4, 2.2,4.6]) ]});

    array_push(_i, { n: "ROBE", c: TRV_CAT_ARMOUR, s: [
        trv_sp(TRV_ROLE_MAIN,  [3.4,1.2, 6.6,1.2, 8.6,9.2, 1.4,9.2]),
        trv_sp(TRV_ROLE_SHADE, [4.2,1.2, 5.8,1.2, 5.8,4.4, 5.0,5.2, 4.2,4.4]),
        trv_sl(TRV_ROLE_ACCENT,0.5,  [1.7,8.4, 8.3,8.4]),
        trv_sd(TRV_ROLE_ACCENT,5.0, 5.9, 0.55) ]});

    array_push(_i, { n: "GAUNTLET", c: TRV_CAT_ARMOUR, s: [
        trv_sp(TRV_ROLE_MAIN,  [2.4,3.4, 7.6,3.4, 7.6,7.8, 6.2,9.4, 3.4,9.4, 2.4,7.8]),
        trv_sr(TRV_ROLE_MAIN,  2.9, 0.8, 1.1, 2.4),
        trv_sr(TRV_ROLE_MAIN,  4.45,0.4, 1.1, 2.8),
        trv_sr(TRV_ROLE_MAIN,  6.0, 0.8, 1.1, 2.4),
        trv_sl(TRV_ROLE_ACCENT,0.5,  [2.4,5.6, 7.6,5.6]),
        trv_sl(TRV_ROLE_SHADE, 0.35, [2.4,7.2, 7.6,7.2]) ]});

    array_push(_i, { n: "BOOTS", c: TRV_CAT_ARMOUR, s: [
        trv_sp(TRV_ROLE_MAIN,  [2.4,1.2, 5.0,1.2, 5.0,6.2, 8.8,6.2, 8.8,8.4, 2.4,8.4]),
        trv_sr(TRV_ROLE_SHADE, 2.4, 8.4, 6.4, 1.0),
        trv_sl(TRV_ROLE_ACCENT,0.45, [2.4,3.2, 5.0,3.2]),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [3.1,1.8, 3.1,5.8]) ]});

    array_push(_i, { n: "GREAVES", c: TRV_CAT_ARMOUR, s: [
        trv_sp(TRV_ROLE_MAIN,  [2.2,1.0, 4.6,1.0, 4.4,9.0, 2.6,9.0]),
        trv_sp(TRV_ROLE_MAIN,  [5.4,1.0, 7.8,1.0, 7.4,9.0, 5.6,9.0]),
        trv_sl(TRV_ROLE_ACCENT,0.4,  [2.3,3.0, 4.55,3.0]),
        trv_sl(TRV_ROLE_ACCENT,0.4,  [5.45,3.0, 7.7,3.0]),
        trv_sl(TRV_ROLE_SHADE, 0.3,  [3.4,4.0, 3.4,8.6]) ]});

    array_push(_i, { n: "SHIELD", c: TRV_CAT_ARMOUR, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.6,1.2, 8.4,1.2, 8.4,5.4, 5.0,9.6, 1.6,5.4]),
        trv_sl(TRV_ROLE_ACCENT,0.55, [5.0,2.0, 5.0,8.4]),
        trv_sl(TRV_ROLE_ACCENT,0.55, [2.4,4.2, 7.6,4.2]),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [2.3,1.9, 2.3,5.2]) ]});

    array_push(_i, { n: "BUCKLER", c: TRV_CAT_ARMOUR, s: [
        trv_sd(TRV_ROLE_MAIN,  5.0, 5.0, 4.2),
        trv_so(TRV_ROLE_SHADE, 0.5,  5.0, 5.0, 3.1),
        trv_sd(TRV_ROLE_ACCENT,5.0, 5.0, 1.5),
        trv_sl(TRV_ROLE_LIGHT, 0.35, [2.6,3.0, 3.7,2.0]) ]});

    array_push(_i, { n: "TOWERSHIELD", c: TRV_CAT_ARMOUR, s: [
        trv_sp(TRV_ROLE_MAIN,  [2.4,0.8, 7.6,0.8, 7.6,7.4, 5.0,9.6, 2.4,7.4]),
        trv_sp(TRV_ROLE_SHADE, [3.3,1.7, 6.7,1.7, 6.7,7.0, 5.0,8.5, 3.3,7.0]),
        trv_sp(TRV_ROLE_ACCENT,[5.0,2.6, 6.0,4.2, 5.0,6.4, 4.0,4.2]) ]});

    array_push(_i, { n: "CLOAK", c: TRV_CAT_ARMOUR, s: [
        trv_sp(TRV_ROLE_MAIN,  [5.0,0.6, 7.4,2.0, 8.8,9.2, 1.2,9.2, 2.6,2.0]),
        trv_sp(TRV_ROLE_SHADE, [5.0,0.6, 6.6,2.4, 5.0,4.0, 3.4,2.4]),
        trv_sl(TRV_ROLE_ACCENT,0.45, [2.7,2.2, 5.0,3.6, 7.3,2.2]) ]});

    array_push(_i, { n: "BELT", c: TRV_CAT_ARMOUR, s: [
        trv_sr(TRV_ROLE_GRIP,  0.6, 4.0, 8.8, 2.0),
        trv_sr(TRV_ROLE_ACCENT,3.6, 3.3, 2.8, 3.4),
        trv_sr(TRV_ROLE_MAIN,  4.4, 4.1, 1.2, 1.8),
        trv_sl(TRV_ROLE_SHADE, 0.3,  [0.8,5.6, 3.5,5.6]) ]});

    array_push(_i, { n: "RING", c: TRV_CAT_ARMOUR, s: [
        trv_so(TRV_ROLE_ACCENT,1.15, 5.0, 6.1, 3.0),
        trv_sp(TRV_ROLE_MAIN,  [5.0,0.6, 7.0,2.2, 6.2,4.4, 3.8,4.4, 3.0,2.2]),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [4.2,1.9, 5.2,1.4]) ]});

    array_push(_i, { n: "AMULET", c: TRV_CAT_ARMOUR, s: [
        trv_sl(TRV_ROLE_GRIP,  0.5,  [1.6,1.0, 5.0,4.4, 8.4,1.0]),
        trv_sp(TRV_ROLE_ACCENT,[5.0,3.6, 7.6,6.0, 5.0,9.4, 2.4,6.0]),
        trv_sp(TRV_ROLE_LIGHT, [5.0,5.0, 6.0,6.0, 5.0,7.0, 4.0,6.0]) ]});

    array_push(_i, { n: "CROWN", c: TRV_CAT_ARMOUR, s: [
        trv_sp(TRV_ROLE_ACCENT,[1.2,7.4, 1.2,2.2, 3.1,4.6, 5.0,1.4, 6.9,4.6, 8.8,2.2, 8.8,7.4]),
        trv_sr(TRV_ROLE_ACCENT,1.2, 7.6, 7.6, 1.4),
        trv_sd(TRV_ROLE_MAIN,  5.0, 6.2, 0.75),
        trv_sd(TRV_ROLE_MAIN,  2.4, 6.4, 0.55),
        trv_sd(TRV_ROLE_MAIN,  7.6, 6.4, 0.55) ]});

    array_push(_i, { n: "PAULDRON", c: TRV_CAT_ARMOUR, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.2,4.0, 3.0,1.4, 7.0,1.4, 8.8,4.0, 8.8,5.0, 1.2,5.0]),
        trv_sp(TRV_ROLE_MAIN,  [1.6,5.4, 8.4,5.4, 8.4,6.8, 1.6,6.8]),
        trv_sp(TRV_ROLE_SHADE, [2.4,7.2, 7.6,7.2, 7.6,8.6, 2.4,8.6]),
        trv_sd(TRV_ROLE_ACCENT,5.0, 3.2, 0.8) ]});

    // ------------------------------------------------------------------ consumables ------------
    array_push(_i, { n: "POTION", c: TRV_CAT_CONSUMABLE, s: [
        trv_sp(TRV_ROLE_MAIN,  [3.9,1.4, 6.1,1.4, 6.1,3.6, 8.0,6.4, 8.0,8.6, 2.0,8.6, 2.0,6.4,
                                3.9,3.6]),
        trv_sp(TRV_ROLE_ACCENT,[2.6,5.4, 7.4,5.4, 8.0,6.6, 8.0,8.6, 2.0,8.6, 2.0,6.6]),
        trv_sr(TRV_ROLE_GRIP,  3.5, 0.4, 3.0, 1.2),
        trv_sl(TRV_ROLE_LIGHT, 0.4,  [3.1,6.6, 3.1,7.9]) ]});

    array_push(_i, { n: "VIAL", c: TRV_CAT_CONSUMABLE, s: [
        trv_sp(TRV_ROLE_MAIN,  [3.6,2.0, 6.4,2.0, 6.4,7.6, 5.0,9.2, 3.6,7.6]),
        trv_sp(TRV_ROLE_ACCENT,[3.6,5.2, 6.4,5.2, 6.4,7.6, 5.0,9.2, 3.6,7.6]),
        trv_sr(TRV_ROLE_GRIP,  3.9, 0.6, 2.2, 1.5),
        trv_sl(TRV_ROLE_LIGHT, 0.35, [4.2,3.0, 4.2,4.8]) ]});

    array_push(_i, { n: "ELIXIR", c: TRV_CAT_CONSUMABLE, s: [
        trv_sd(TRV_ROLE_MAIN,  5.0, 6.4, 3.0),
        trv_sp(TRV_ROLE_ACCENT,[2.3,7.6, 7.7,7.6, 6.6,9.0, 3.4,9.0]),
        trv_sd(TRV_ROLE_ACCENT,5.0, 6.9, 2.4),
        trv_sr(TRV_ROLE_MAIN,  4.2, 2.0, 1.6, 2.0),
        trv_sr(TRV_ROLE_GRIP,  3.8, 0.9, 2.4, 1.2),
        trv_sl(TRV_ROLE_LIGHT, 0.35, [3.4,5.2, 4.0,4.2]) ]});

    array_push(_i, { n: "HERB", c: TRV_CAT_CONSUMABLE, s: [
        trv_sl(TRV_ROLE_GRIP,  0.5,  [5.0,9.4, 5.0,3.4]),
        trv_sp(TRV_ROLE_ACCENT,[5.0,4.4, 1.4,3.6, 2.2,6.6, 5.0,6.0]),
        trv_sp(TRV_ROLE_ACCENT,[5.0,3.0, 8.6,2.2, 7.8,5.2, 5.0,4.6]),
        trv_sd(TRV_ROLE_MAIN,  5.0, 1.6, 0.9) ]});

    array_push(_i, { n: "MUSHROOM", c: TRV_CAT_CONSUMABLE, s: [
        trv_sp(TRV_ROLE_ACCENT,[1.0,5.4, 2.2,2.2, 7.8,2.2, 9.0,5.4]),
        trv_sd(TRV_ROLE_LIGHT, 3.3, 3.9, 0.7),
        trv_sd(TRV_ROLE_LIGHT, 6.6, 4.2, 0.55),
        trv_sp(TRV_ROLE_MAIN,  [3.9,5.6, 6.1,5.6, 6.6,9.2, 3.4,9.2]) ]});

    array_push(_i, { n: "BREAD", c: TRV_CAT_CONSUMABLE, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.2,7.4, 1.6,3.6, 3.0,2.4, 7.0,2.4, 8.4,3.6, 8.8,7.4, 5.0,8.6]),
        trv_sl(TRV_ROLE_SHADE, 0.4,  [3.4,3.6, 4.2,5.4]),
        trv_sl(TRV_ROLE_SHADE, 0.4,  [5.2,3.4, 6.0,5.2]),
        trv_sl(TRV_ROLE_LIGHT, 0.35, [2.2,4.4, 2.0,6.6]) ]});

    array_push(_i, { n: "MEAT", c: TRV_CAT_CONSUMABLE, s: [
        trv_sp(TRV_ROLE_ACCENT,[2.0,7.4, 2.6,3.4, 5.6,1.6, 8.2,3.4, 8.0,6.4, 5.0,8.4]),
        trv_sl(TRV_ROLE_MAIN,  1.0,  [2.2,7.6, 0.6,9.4]),
        trv_sd(TRV_ROLE_MAIN,  0.9, 9.1, 0.85),
        trv_sl(TRV_ROLE_LIGHT, 0.35, [4.0,3.4, 6.2,2.8]) ]});

    array_push(_i, { n: "FISH", c: TRV_CAT_CONSUMABLE, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.4,5.0, 4.0,2.6, 7.0,2.8, 8.4,5.0, 7.0,7.2, 4.0,7.4]),
        trv_sp(TRV_ROLE_ACCENT,[8.4,5.0, 9.8,3.0, 9.8,7.0]),
        trv_sd(TRV_ROLE_SHADE, 3.2, 4.6, 0.5),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [4.6,3.6, 6.6,3.7]) ]});

    array_push(_i, { n: "APPLE", c: TRV_CAT_CONSUMABLE, s: [
        trv_sd(TRV_ROLE_ACCENT,3.7, 6.2, 2.8),
        trv_sd(TRV_ROLE_ACCENT,6.3, 6.2, 2.8),
        trv_sl(TRV_ROLE_GRIP,  0.45, [5.0,3.6, 5.4,1.2]),
        trv_sp(TRV_ROLE_MAIN,  [5.5,1.8, 8.0,0.8, 7.2,2.8]),
        trv_sl(TRV_ROLE_LIGHT, 0.4,  [2.4,5.0, 2.0,6.4]) ]});

    array_push(_i, { n: "CHEESE", c: TRV_CAT_CONSUMABLE, s: [
        trv_sp(TRV_ROLE_ACCENT,[1.0,8.2, 1.0,4.4, 9.0,2.6, 9.0,6.6]),
        trv_sp(TRV_ROLE_MAIN,  [1.0,4.4, 9.0,2.6, 7.2,1.8, 2.0,3.0]),
        trv_sd(TRV_ROLE_SHADE, 3.2, 6.2, 0.65),
        trv_sd(TRV_ROLE_SHADE, 6.4, 5.2, 0.5) ]});

    // ------------------------------------------------------------------ arcane / quest ---------
    array_push(_i, { n: "SCROLL", c: TRV_CAT_ARCANE, s: [
        trv_sp(TRV_ROLE_MAIN,  [2.4,1.6, 7.6,1.6, 7.6,8.4, 2.4,8.4]),
        trv_sl(TRV_ROLE_SHADE, 0.35, [3.4,3.4, 6.6,3.4]),
        trv_sl(TRV_ROLE_SHADE, 0.35, [3.4,5.0, 6.6,5.0]),
        trv_sl(TRV_ROLE_SHADE, 0.35, [3.4,6.6, 5.6,6.6]),
        trv_sr(TRV_ROLE_ACCENT,1.6, 0.6, 6.8, 1.2),
        trv_sr(TRV_ROLE_ACCENT,1.6, 8.2, 6.8, 1.2) ]});

    array_push(_i, { n: "TOME", c: TRV_CAT_ARCANE, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.6,1.4, 8.4,1.4, 8.4,8.6, 1.6,8.6]),
        trv_sr(TRV_ROLE_SHADE, 1.6, 1.4, 1.2, 7.2),
        trv_sp(TRV_ROLE_ACCENT,[5.6,3.2, 6.6,5.0, 5.6,6.8, 4.6,5.0]),
        trv_sl(TRV_ROLE_ACCENT,0.4,  [3.6,2.4, 3.6,7.6]),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [8.4,2.2, 8.4,7.8]) ]});

    array_push(_i, { n: "RUNESTONE", c: TRV_CAT_ARCANE, s: [
        trv_sp(TRV_ROLE_MAIN,  [2.2,2.6, 5.0,0.8, 7.8,2.6, 7.8,7.0, 5.0,9.2, 2.2,7.0]),
        trv_sl(TRV_ROLE_ACCENT,0.55, [5.0,2.6, 5.0,7.4]),
        trv_sl(TRV_ROLE_ACCENT,0.55, [5.0,4.2, 7.0,2.8]),
        trv_sl(TRV_ROLE_ACCENT,0.55, [5.0,5.6, 3.1,4.2]) ]});

    array_push(_i, { n: "CRYSTAL", c: TRV_CAT_ARCANE, s: [
        trv_sp(TRV_ROLE_ACCENT,[5.0,0.4, 7.8,3.6, 6.4,9.4, 3.6,9.4, 2.2,3.6]),
        trv_sp(TRV_ROLE_LIGHT, [5.0,0.4, 6.4,3.8, 5.0,9.4, 4.4,3.8]),
        trv_sl(TRV_ROLE_MAIN,  0.35, [2.4,4.0, 7.6,4.0]) ]});

    array_push(_i, { n: "ORB", c: TRV_CAT_ARCANE, s: [
        trv_sd(TRV_ROLE_MAIN,  5.0, 5.0, 4.0),
        trv_sd(TRV_ROLE_ACCENT,5.0, 5.0, 2.9),
        trv_sd(TRV_ROLE_LIGHT, 3.7, 3.7, 0.95),
        trv_so(TRV_ROLE_ACCENT,0.35, 5.0, 5.0, 4.4) ]});

    array_push(_i, { n: "GEM", c: TRV_CAT_ARCANE, s: [
        trv_sp(TRV_ROLE_ACCENT,[2.0,3.8, 3.4,1.4, 6.6,1.4, 8.0,3.8, 5.0,9.0]),
        trv_sp(TRV_ROLE_LIGHT, [3.4,1.4, 6.6,1.4, 5.8,3.8, 4.2,3.8]),
        trv_sl(TRV_ROLE_MAIN,  0.35, [2.0,3.8, 8.0,3.8]),
        trv_sl(TRV_ROLE_MAIN,  0.3,  [4.2,3.9, 5.0,8.8, 5.8,3.9]) ]});

    array_push(_i, { n: "KEY", c: TRV_CAT_ARCANE, s: [
        trv_so(TRV_ROLE_ACCENT,1.1,  3.2, 3.2, 2.1),
        trv_sl(TRV_ROLE_ACCENT,0.85, [4.4,4.6, 8.6,8.8]),
        trv_sl(TRV_ROLE_ACCENT,0.8,  [7.0,7.2, 6.0,8.2]),
        trv_sl(TRV_ROLE_ACCENT,0.8,  [8.0,8.2, 7.0,9.2]),
        trv_sd(TRV_ROLE_MAIN,  3.2, 3.2, 0.8) ]});

    array_push(_i, { n: "SKULL", c: TRV_CAT_ARCANE, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.6,4.8, 2.6,1.6, 7.4,1.6, 8.4,4.8, 7.4,7.0, 2.6,7.0]),
        trv_sd(TRV_ROLE_SHADE, 3.5, 4.4, 1.15),
        trv_sd(TRV_ROLE_SHADE, 6.5, 4.4, 1.15),
        trv_sp(TRV_ROLE_SHADE, [4.4,6.0, 5.6,6.0, 5.0,6.9]),
        trv_sr(TRV_ROLE_MAIN,  3.0, 7.2, 4.0, 1.6),
        trv_sl(TRV_ROLE_SHADE, 0.3,  [4.3,7.3, 4.3,8.7]),
        trv_sl(TRV_ROLE_SHADE, 0.3,  [5.7,7.3, 5.7,8.7]) ]});

    array_push(_i, { n: "CANDLE", c: TRV_CAT_ARCANE, s: [
        trv_sr(TRV_ROLE_MAIN,  3.9, 3.4, 2.2, 5.0),
        trv_sp(TRV_ROLE_GRIP,  [2.6,8.4, 7.4,8.4, 7.4,9.4, 2.6,9.4]),
        trv_sl(TRV_ROLE_SHADE, 0.35, [5.0,2.6, 5.0,3.6]),
        trv_sp(TRV_ROLE_ACCENT,[5.0,0.4, 6.4,2.0, 5.0,3.0, 3.6,2.0]),
        trv_sd(TRV_ROLE_LIGHT, 5.0, 2.0, 0.5) ]});

    array_push(_i, { n: "FEATHER", c: TRV_CAT_ARCANE, s: [
        trv_sp(TRV_ROLE_MAIN,  [8.6,0.8, 8.2,4.6, 5.0,7.6, 2.2,7.2, 4.8,3.4]),
        trv_sl(TRV_ROLE_SHADE, 0.4,  [8.6,0.8, 2.4,8.8]),
        trv_sl(TRV_ROLE_ACCENT,0.5,  [2.4,8.8, 1.0,9.6]) ]});

    // TWO TRIANGLES, NOT ONE BOWTIE. As a single six-point polygon this shape is
    // SELF-INTERSECTING, and ear clipping cannot triangulate a self-intersecting polygon — it
    // finds no ear, bails out, and renders half the glass. Split at the waist instead.
    array_push(_i, { n: "HOURGLASS", c: TRV_CAT_ARCANE, s: [
        trv_sr(TRV_ROLE_GRIP,  1.8, 0.8, 6.4, 1.1),
        trv_sr(TRV_ROLE_GRIP,  1.8, 8.1, 6.4, 1.1),
        trv_sp(TRV_ROLE_MAIN,  [2.6,1.9, 7.4,1.9, 5.0,5.0]),
        trv_sp(TRV_ROLE_MAIN,  [2.6,8.1, 5.0,5.0, 7.4,8.1]),
        trv_sp(TRV_ROLE_ACCENT,[3.5,6.9, 6.5,6.9, 6.9,8.1, 3.1,8.1]),
        trv_sd(TRV_ROLE_ACCENT,5.0, 4.5, 0.3) ]});

    array_push(_i, { n: "COMPASS", c: TRV_CAT_ARCANE, s: [
        trv_sd(TRV_ROLE_MAIN,  5.0, 5.0, 4.2),
        trv_so(TRV_ROLE_SHADE, 0.5,  5.0, 5.0, 3.2),
        trv_sp(TRV_ROLE_ACCENT,[5.0,2.2, 6.0,5.0, 5.0,7.8, 4.0,5.0]),
        trv_sd(TRV_ROLE_LIGHT, 5.0, 5.0, 0.5) ]});

    array_push(_i, { n: "MAP", c: TRV_CAT_ARCANE, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.0,2.2, 3.7,1.2, 6.3,2.4, 9.0,1.2, 9.0,7.8, 6.3,9.0, 3.7,7.8,
                                1.0,9.0]),
        trv_sl(TRV_ROLE_SHADE, 0.35, [3.7,1.4, 3.7,7.9]),
        trv_sl(TRV_ROLE_SHADE, 0.35, [6.3,2.4, 6.3,8.9]),
        trv_sl(TRV_ROLE_ACCENT,0.45, [2.2,6.4, 4.8,4.0, 7.6,5.4]),
        trv_sp(TRV_ROLE_ACCENT,[7.0,4.4, 8.2,4.4, 7.6,3.2]) ]});

    array_push(_i, { n: "LANTERN", c: TRV_CAT_ARCANE, s: [
        trv_sl(TRV_ROLE_GRIP,  0.45, [3.2,2.4, 5.0,0.6, 6.8,2.4]),
        trv_sr(TRV_ROLE_MAIN,  2.6, 2.4, 4.8, 0.9),
        trv_sp(TRV_ROLE_ACCENT,[3.2,3.4, 6.8,3.4, 7.2,7.8, 2.8,7.8]),
        trv_sr(TRV_ROLE_MAIN,  2.4, 7.8, 5.2, 1.2),
        trv_sl(TRV_ROLE_MAIN,  0.35, [5.0,3.5, 5.0,7.7]),
        trv_sd(TRV_ROLE_LIGHT, 5.0, 5.6, 0.75) ]});

    array_push(_i, { n: "TORCH", c: TRV_CAT_ARCANE, s: [
        trv_sl(TRV_ROLE_GRIP,  1.05, [5.0,4.6, 5.0,9.6]),
        trv_sr(TRV_ROLE_MAIN,  3.6, 3.6, 2.8, 1.2),
        trv_sp(TRV_ROLE_ACCENT,[5.0,0.2, 7.2,2.4, 6.4,3.7, 3.6,3.7, 2.8,2.4]),
        trv_sd(TRV_ROLE_LIGHT, 5.0, 2.6, 0.8) ]});

    array_push(_i, { n: "BELL", c: TRV_CAT_ARCANE, s: [
        trv_sp(TRV_ROLE_ACCENT,[2.0,7.6, 2.4,4.0, 5.0,1.4, 7.6,4.0, 8.0,7.6]),
        trv_sr(TRV_ROLE_ACCENT,1.6, 7.8, 6.8, 1.0),
        trv_sd(TRV_ROLE_MAIN,  5.0, 9.3, 0.7),
        trv_sd(TRV_ROLE_MAIN,  5.0, 0.9, 0.6),
        trv_sl(TRV_ROLE_LIGHT, 0.35, [3.4,6.8, 3.6,4.4]) ]});

    array_push(_i, { n: "TALISMAN", c: TRV_CAT_ARCANE, s: [
        trv_so(TRV_ROLE_MAIN,  0.7,  5.0, 5.2, 3.8),
        trv_sp(TRV_ROLE_ACCENT,[5.0,2.0, 7.6,5.2, 5.0,8.4, 2.4,5.2]),
        trv_sd(TRV_ROLE_MAIN,  5.0, 5.2, 1.1),
        trv_sd(TRV_ROLE_LIGHT, 5.0, 5.2, 0.5) ]});

    // ------------------------------------------------------------------ materials --------------
    array_push(_i, { n: "INGOT", c: TRV_CAT_MATERIAL, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.0,8.4, 2.4,5.6, 7.6,5.6, 9.0,8.4]),
        trv_sp(TRV_ROLE_LIGHT, [2.4,5.6, 3.4,3.4, 6.6,3.4, 7.6,5.6]),
        trv_sl(TRV_ROLE_SHADE, 0.3,  [2.4,5.7, 7.6,5.7]) ]});

    array_push(_i, { n: "ORE", c: TRV_CAT_MATERIAL, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.2,6.6, 2.6,2.8, 6.6,1.8, 8.8,4.6, 8.0,8.4, 3.4,8.8]),
        trv_sd(TRV_ROLE_ACCENT,4.0, 4.4, 0.95),
        trv_sd(TRV_ROLE_ACCENT,6.6, 6.4, 0.8),
        trv_sd(TRV_ROLE_ACCENT,6.2, 3.4, 0.6),
        trv_sl(TRV_ROLE_LIGHT, 0.35, [2.4,5.6, 3.2,3.2]) ]});

    array_push(_i, { n: "COIN", c: TRV_CAT_MATERIAL, s: [
        trv_sd(TRV_ROLE_ACCENT,5.0, 5.0, 4.0),
        trv_so(TRV_ROLE_SHADE, 0.45, 5.0, 5.0, 2.9),
        trv_sp(TRV_ROLE_MAIN,  [5.0,2.9, 6.0,5.0, 5.0,7.1, 4.0,5.0]),
        trv_sl(TRV_ROLE_LIGHT, 0.4,  [2.6,3.2, 3.6,2.2]) ]});

    array_push(_i, { n: "COINSTACK", c: TRV_CAT_MATERIAL, s: [
        trv_sd(TRV_ROLE_ACCENT,3.2, 7.2, 2.4),
        trv_sd(TRV_ROLE_ACCENT,7.0, 7.6, 2.1),
        trv_sd(TRV_ROLE_ACCENT,5.2, 4.0, 2.6),
        trv_so(TRV_ROLE_SHADE, 0.4,  5.2, 4.0, 1.6),
        trv_sl(TRV_ROLE_LIGHT, 0.35, [3.6,2.8, 4.6,2.2]) ]});

    // A HIDE, with four leg stubs. The previous nine-point blob had no silhouette at all and read
    // as a smear at 62 px — legs are the only thing that says "hide" rather than "shape".
    array_push(_i, { n: "LEATHER", c: TRV_CAT_MATERIAL, s: [
        trv_sp(TRV_ROLE_MAIN,  [3.2,1.0, 4.4,2.4, 5.6,2.4, 6.8,1.0, 8.0,2.4, 7.2,5.0, 8.6,7.4,
                                6.6,9.2, 3.4,9.2, 1.4,7.4, 2.8,5.0, 2.0,2.4]),
        trv_sl(TRV_ROLE_SHADE, 0.32, [3.6,4.2, 6.4,4.2]),
        trv_sl(TRV_ROLE_LIGHT, 0.28, [3.0,6.2, 7.0,6.2]) ]});

    // A BOLT with a rolled edge and a scalloped hem, so it cannot be confused with the plank —
    // as flat parallelograms the two were the same yellow rectangle at catalogue size.
    array_push(_i, { n: "CLOTH", c: TRV_CAT_MATERIAL, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.2,3.4, 8.8,1.8, 8.8,6.6, 7.3,7.6, 5.8,6.6, 4.3,7.6, 2.7,6.6,
                                1.2,7.6]),
        trv_sp(TRV_ROLE_ACCENT,[1.2,3.4, 8.8,1.8, 8.8,3.2, 1.2,4.8]),
        trv_so(TRV_ROLE_SHADE, 0.5,  8.3, 2.4, 0.85),
        trv_sl(TRV_ROLE_LIGHT, 0.26, [3.0,4.6, 3.0,6.9]) ]});

    // Two boards stacked with visible end grain and nails. Explicitly rectangular, against the
    // cloth's curves.
    array_push(_i, { n: "PLANK", c: TRV_CAT_MATERIAL, s: [
        trv_sr(TRV_ROLE_MAIN,  0.8, 2.2, 8.4, 2.6),
        trv_sr(TRV_ROLE_MAIN,  0.8, 5.4, 8.4, 2.6),
        trv_sl(TRV_ROLE_SHADE, 0.26, [1.6,3.1, 8.4,3.1]),
        trv_sl(TRV_ROLE_SHADE, 0.26, [1.6,6.3, 8.4,6.3]),
        trv_sd(TRV_ROLE_ACCENT,2.2, 3.5, 0.4),
        trv_sd(TRV_ROLE_ACCENT,7.8, 6.7, 0.4) ]});

    array_push(_i, { n: "ROPE", c: TRV_CAT_MATERIAL, s: [
        trv_so(TRV_ROLE_MAIN,  1.05, 5.0, 5.4, 3.4),
        trv_so(TRV_ROLE_MAIN,  0.85, 5.0, 5.4, 2.0),
        trv_sl(TRV_ROLE_ACCENT,0.5,  [7.4,3.0, 9.2,1.2]),
        trv_sl(TRV_ROLE_SHADE, 0.35, [2.4,4.2, 3.4,4.8]) ]});

    array_push(_i, { n: "GEAR", c: TRV_CAT_MATERIAL, s: [
        trv_sd(TRV_ROLE_MAIN,  5.0, 5.0, 3.3),
        trv_sr(TRV_ROLE_MAIN,  4.2, 0.6, 1.6, 1.8),
        trv_sr(TRV_ROLE_MAIN,  4.2, 7.6, 1.6, 1.8),
        trv_sr(TRV_ROLE_MAIN,  0.6, 4.2, 1.8, 1.6),
        trv_sr(TRV_ROLE_MAIN,  7.6, 4.2, 1.8, 1.6),
        trv_sd(TRV_ROLE_ACCENT,5.0, 5.0, 1.5),
        trv_sl(TRV_ROLE_LIGHT, 0.35, [2.9,3.2, 3.8,2.5]) ]});

    array_push(_i, { n: "SPOOL", c: TRV_CAT_MATERIAL, s: [
        trv_sr(TRV_ROLE_MAIN,  2.2, 1.2, 5.6, 1.1),
        trv_sr(TRV_ROLE_MAIN,  2.2, 7.7, 5.6, 1.1),
        trv_sr(TRV_ROLE_ACCENT,3.0, 2.3, 4.0, 5.4),
        trv_sl(TRV_ROLE_SHADE, 0.3,  [3.0,3.8, 7.0,3.8]),
        trv_sl(TRV_ROLE_SHADE, 0.3,  [3.0,6.0, 7.0,6.0]) ]});

    array_push(_i, { n: "BONE", c: TRV_CAT_MATERIAL, s: [
        trv_sl(TRV_ROLE_MAIN,  1.2,  [2.8,7.4, 7.2,2.6]),
        trv_sd(TRV_ROLE_MAIN,  2.2, 7.2, 1.25),
        trv_sd(TRV_ROLE_MAIN,  3.0, 8.2, 1.15),
        trv_sd(TRV_ROLE_MAIN,  7.8, 2.8, 1.25),
        trv_sd(TRV_ROLE_MAIN,  7.0, 1.8, 1.15),
        trv_sl(TRV_ROLE_LIGHT, 0.3,  [3.6,6.6, 6.6,3.4]) ]});

    array_push(_i, { n: "EGG", c: TRV_CAT_MATERIAL, s: [
        trv_sp(TRV_ROLE_MAIN,  [5.0,0.8, 7.6,3.4, 8.2,6.4, 6.4,9.0, 3.6,9.0, 1.8,6.4, 2.4,3.4]),
        trv_sd(TRV_ROLE_ACCENT,3.9, 6.0, 0.75),
        trv_sd(TRV_ROLE_ACCENT,6.2, 7.0, 0.6),
        trv_sl(TRV_ROLE_LIGHT, 0.4,  [3.4,3.6, 3.0,5.4]) ]});

    array_push(_i, { n: "POUCH", c: TRV_CAT_MATERIAL, s: [
        trv_sp(TRV_ROLE_MAIN,  [3.0,3.4, 7.0,3.4, 8.8,6.4, 7.4,9.2, 2.6,9.2, 1.2,6.4]),
        trv_sl(TRV_ROLE_ACCENT,0.6,  [3.0,3.4, 7.0,3.4]),
        trv_sl(TRV_ROLE_GRIP,  0.4,  [3.4,3.2, 4.2,1.4, 5.8,1.4, 6.6,3.2]),
        trv_sd(TRV_ROLE_ACCENT,5.0, 6.6, 0.9) ]});

    array_push(_i, { n: "CHEST", c: TRV_CAT_MATERIAL, s: [
        trv_sp(TRV_ROLE_MAIN,  [1.2,4.4, 2.6,2.0, 7.4,2.0, 8.8,4.4]),
        trv_sr(TRV_ROLE_MAIN,  1.2, 4.6, 7.6, 4.2),
        trv_sl(TRV_ROLE_ACCENT,0.5,  [1.2,4.5, 8.8,4.5]),
        trv_sr(TRV_ROLE_ACCENT,4.3, 3.8, 1.4, 2.2),
        trv_sd(TRV_ROLE_LIGHT, 5.0, 5.4, 0.4) ]});

    return _i;
}

/// @func   trv_icon_get()
/// @desc   Returns the icon table, building it on first use.
/// @remarks Lazily initialised, like the theme and the typeface: there is no setup call to forget,
///          and nothing is paid for until something is drawn.
/// @return {Array} The icon table.
function trv_icon_get() {
    if (!variable_global_exists("__trv_icons")) {
        global.__trv_icons = trv_icon_build();
    }
    return global.__trv_icons;
}

/// @func   trv_icon_count()
/// @desc   How many icon forms ship with Trove.
/// @return {Real} The count.
function trv_icon_count() { return array_length(trv_icon_get()); }

/// @func   trv_icon_name(_index)
/// @desc   The name of an icon form, for tooltips, debugging and the demo.
/// @param  {Real} _index  Icon index, wrapped into range.
/// @return {String} The name.
function trv_icon_name(_index) {
    var _t = trv_icon_get();
    return _t[(_index % array_length(_t) + array_length(_t)) % array_length(_t)].n;
}

/// @func   trv_icon_category(_index)
/// @desc   The category of an icon form. One of the TRV_CAT_* constants.
/// @param  {Real} _index  Icon index, wrapped into range.
/// @return {Real} The category.
function trv_icon_category(_index) {
    var _t = trv_icon_get();
    return _t[(_index % array_length(_t) + array_length(_t)) % array_length(_t)].c;
}

/// @func   trv_icon_find(_name)
/// @desc   Looks an icon form up by name, so item definitions can read as data rather than as
///         magic numbers. Linear, but the table is 64 entries and this is a setup-time call.
/// @param  {String} _name  Case-insensitive form name, e.g. "SWORD".
/// @return {Real} The index, or -1 if there is no such form.
function trv_icon_find(_name) {
    var _t = trv_icon_get(), _u = string_upper(_name);
    for (var _k = 0; _k < array_length(_t); _k++) if (_t[_k].n == _u) return _k;
    return -1;
}

// =================================================================================================
// MATERIALS
//
// A material is five colours in role order: main, grip, accent, shade, light. Twelve ship. They are
// built by trv_material_make from three seeds so that a buyer's thirteenth material is three
// numbers rather than five, and so that shade and light are always tonally consistent with the
// body — hand-picking all five is how palettes end up muddy.
// =================================================================================================

/// @func   trv_material_make(_body, _grip, _accent)
/// @desc   Builds a five-role material palette from three seed colours.
/// @remarks SHADE and LIGHT are derived rather than supplied. Shade is the body pushed dark and
///          slightly toward the accent, so recesses pick up the item's character instead of going
///          flat grey. Light is the body pushed bright and slightly toward white. That relationship
///          is what makes twelve materials look like one designed set rather than twelve guesses.
/// @param  {Real} _body    Main body colour.
/// @param  {Real} _grip    Handle / secondary colour.
/// @param  {Real} _accent  The eye-catch.
/// @return {Array} Five colours in TRV_ROLE order.
/// @pure
function trv_material_make(_body, _grip, _accent) {
    return [
        _body,
        _grip,
        _accent,
        trv_colour_shade(trv_colour_mix(_body, _accent, 0.18), -0.52),
        trv_colour_shade(_body, 0.46)
    ];
}

/// @func   trv_material_build()
/// @desc   Builds the material table. Called once, lazily.
/// @return {Array} Array of { n: name, p: palette } structs.
function trv_material_build() {
    return [
        { n: "STEEL",    p: trv_material_make(make_colour_rgb(176, 188, 204), make_colour_rgb( 86,  70,  58), make_colour_rgb(214, 226, 240)) },
        { n: "IRON",     p: trv_material_make(make_colour_rgb(122, 130, 142), make_colour_rgb( 64,  52,  44), make_colour_rgb(158, 168, 180)) },
        { n: "BRONZE",   p: trv_material_make(make_colour_rgb(190, 134,  74), make_colour_rgb( 78,  56,  40), make_colour_rgb(238, 190, 116)) },
        { n: "GOLD",     p: trv_material_make(make_colour_rgb(232, 186,  74), make_colour_rgb(104,  70,  36), make_colour_rgb(255, 232, 150)) },
        { n: "SILVER",   p: trv_material_make(make_colour_rgb(208, 214, 226), make_colour_rgb( 96, 100, 116), make_colour_rgb(246, 250, 255)) },
        { n: "WOOD",     p: trv_material_make(make_colour_rgb(150, 106,  66), make_colour_rgb(104,  72,  44), make_colour_rgb(196, 156,  98)) },
        { n: "BONE",     p: trv_material_make(make_colour_rgb(226, 218, 196), make_colour_rgb(150, 138, 116), make_colour_rgb(180, 166, 138)) },
        { n: "OBSIDIAN", p: trv_material_make(make_colour_rgb( 62,  58,  78), make_colour_rgb( 40,  36,  52), make_colour_rgb(158, 116, 232)) },
        { n: "EMBER",    p: trv_material_make(make_colour_rgb(196,  82,  56), make_colour_rgb( 74,  46,  40), make_colour_rgb(255, 168,  84)) },
        { n: "VERDANT",  p: trv_material_make(make_colour_rgb( 96, 168, 104), make_colour_rgb( 68,  74,  52), make_colour_rgb(178, 232, 132)) },
        { n: "TIDE",     p: trv_material_make(make_colour_rgb( 78, 148, 190), make_colour_rgb( 44,  62,  84), make_colour_rgb(140, 226, 248)) },
        { n: "ARCANE",   p: trv_material_make(make_colour_rgb(140, 108, 208), make_colour_rgb( 56,  44,  86), make_colour_rgb(232, 168, 255)) }
    ];
}

/// @func   trv_material_get()
/// @desc   Returns the material table, building it on first use.
/// @return {Array} The material table.
function trv_material_get() {
    if (!variable_global_exists("__trv_materials")) {
        global.__trv_materials = trv_material_build();
    }
    return global.__trv_materials;
}

/// @func   trv_material_count()
/// @desc   How many materials ship with Trove.
/// @return {Real} The count.
function trv_material_count() { return array_length(trv_material_get()); }

/// @func   trv_material_name(_index)
/// @desc   The name of a material.
/// @param  {Real} _index  Material index, wrapped into range.
/// @return {String} The name.
function trv_material_name(_index) {
    var _m = trv_material_get();
    return _m[(_index % array_length(_m) + array_length(_m)) % array_length(_m)].n;
}

/// @func   trv_material_palette(_index)
/// @desc   The five-colour palette of a material.
/// @param  {Real} _index  Material index, wrapped into range.
/// @return {Array} Five colours in TRV_ROLE order.
function trv_material_palette(_index) {
    var _m = trv_material_get();
    return _m[(_index % array_length(_m) + array_length(_m)) % array_length(_m)].p;
}

// =================================================================================================
// THE RENDERER
// =================================================================================================

/// @func   trv_icon_draw(_index, _x, _y, _size, _palette, _alpha, _tint, _tint_amount)
/// @desc   Draws one icon form in one material, in a square box.
///
/// @remarks WHY THERE IS A SHARED LIGHTING MODEL AND NOT JUST FLAT FILLS. Seventy-five separately
///          authored icons drawn flat look like seventy-five separate decisions. Every icon here is
///          drawn through the same three passes — a soft contact shadow beneath, the shapes, then
///          a single top-left rim light on the filled shapes only — so they read as one set. That
///          consistency is the difference between a clip-art dump and something a buyer is willing
///          to put in front of their players.
///
///          The rim light is deliberately drawn as a THIN OFFSET COPY of each filled shape rather
///          than as a gradient. A gradient needs the shape's bounding box and its normal, which
///          means either per-shape metadata nobody will maintain or a surface pass per icon. The
///          offset copy costs one extra polygon and is indistinguishable at icon sizes.
///
/// @param  {Real}  _index         Icon form index. Wrapped into range.
/// @param  {Real}  _x             Left edge of the icon box.
/// @param  {Real}  _y             Top edge of the icon box.
/// @param  {Real}  _size          Box size in pixels. The 0..10 grid maps onto it.
/// @param  {Array} _palette       Five colours in TRV_ROLE order. Defaults to STEEL.
/// @param  {Real}  _alpha         Overall alpha.
/// @param  {Real}  _tint          Optional colour to blend every role toward — rarity, curse,
///                                poison, frozen. Pass undefined for none.
/// @param  {Real}  _tint_amount   0 to 1.
function trv_icon_draw(_index, _x, _y, _size, _palette = undefined, _alpha = 1,
                       _tint = undefined, _tint_amount = 0) {
    if (_alpha <= 0 || _size <= 0) return;

    var _table = trv_icon_get();
    var _n = array_length(_table);
    var _icon = _table[(_index % _n + _n) % _n];
    var _pal = (_palette == undefined) ? trv_material_palette(0) : _palette;
    var _u = _size / 10;   // one grid unit in pixels

    // Apply the tint once, up front, rather than per shape.
    var _c = array_create(5);
    for (var _r = 0; _r < 5; _r++) {
        _c[_r] = (_tint == undefined || _tint_amount <= 0)
               ? _pal[_r]
               : trv_colour_mix(_pal[_r], _tint, clamp(_tint_amount, 0, 1));
    }

    var _shapes = _icon.s, _count = array_length(_shapes);

    // --- pass 1: contact shadow ------------------------------------------------------------
    // Filled shapes only, offset down, in flat black at low alpha. Strokes are skipped because a
    // shadowed hairline reads as a rendering error rather than as depth.
    var _sh = _u * 0.42;
    draw_set_colour(c_black);
    draw_set_alpha(_alpha * 0.30);
    for (var _i = 0; _i < _count; _i++) {
        var _s = _shapes[_i];
        if (_s.k == TRV_SHAPE_LINE || _s.k == TRV_SHAPE_RING) continue;
        trv_icon_shape(_s, _x, _y + _sh, _u, c_black, _alpha * 0.30, true);
    }

    // --- pass 2: the shapes ----------------------------------------------------------------
    for (var _i = 0; _i < _count; _i++) {
        var _s = _shapes[_i];
        trv_icon_shape(_s, _x, _y, _u, _c[_s.r], _alpha, false);
    }

    // --- pass 3: rim light -----------------------------------------------------------------
    // One offset copy of each filled shape, up and left, at low alpha in the LIGHT role.
    var _ro = _u * 0.16;
    for (var _i = 0; _i < _count; _i++) {
        var _s = _shapes[_i];
        if (_s.k == TRV_SHAPE_LINE || _s.k == TRV_SHAPE_RING) continue;
        if (_s.r == TRV_ROLE_LIGHT || _s.r == TRV_ROLE_SHADE) continue;
        trv_icon_shape(_s, _x - _ro, _y - _ro, _u, _c[TRV_ROLE_LIGHT], _alpha * 0.22, false, 0.86);
    }

    draw_set_alpha(1);
    draw_set_colour(c_white);
}

/// @func   trv_poly_triangulate(_points)
/// @desc   Ear-clipping triangulation of a simple polygon. Handles concave shapes; does not handle
///         self-intersecting ones, which no icon should be.
///
/// @remarks Written out rather than pulled in because GML ships no tessellator and the alternative
///          — "keep every icon convex" — is a rule a buyer authoring their own forms will break
///          within the hour, with no error to tell them why the result looks wrong.
///
///          Winding is normalised to counter-clockwise first, so the convexity test has a single
///          sign to check. The bail-out counter matters: a degenerate polygon (repeated vertices,
///          zero area) has no ear to find, and without the counter the loop never terminates and
///          the game hangs on a draw call, which is a far worse failure than a missing icon.
///
/// @param  {Array} _points  Flat x,y list, at least three vertices.
/// @return {Array} Flat x,y list, three vertices per triangle.
/// @pure
function trv_poly_triangulate(_points) {
    var _n = array_length(_points) div 2;
    if (_n < 3) return [];

    // Signed area, to normalise winding.
    var _area = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n;
        _area += _points[_i * 2] * _points[_j * 2 + 1] - _points[_j * 2] * _points[_i * 2 + 1];
    }

    var _idx = [];
    if (_area < 0) { for (var _i = _n - 1; _i >= 0; _i--) array_push(_idx, _i); }
    else           { for (var _i = 0; _i < _n; _i++)     array_push(_idx, _i); }

    var _out = [];
    var _guard = _n * _n + 8;   // see @remarks — bounds a degenerate polygon
    var _count = array_length(_idx);

    while (_count > 3 && _guard-- > 0) {
        var _clipped = false;
        for (var _k = 0; _k < _count; _k++) {
            var _ia = _idx[(_k + _count - 1) mod _count];
            var _ib = _idx[_k];
            var _ic = _idx[(_k + 1) mod _count];

            var _ax = _points[_ia * 2], _ay = _points[_ia * 2 + 1];
            var _bx2 = _points[_ib * 2], _by2 = _points[_ib * 2 + 1];
            var _cx2 = _points[_ic * 2], _cy2 = _points[_ic * 2 + 1];

            // Convex in CCW winding?
            var _cross = (_bx2 - _ax) * (_cy2 - _ay) - (_by2 - _ay) * (_cx2 - _ax);
            if (_cross <= 0) continue;

            // Does the candidate ear contain any other vertex?
            var _clear = true;
            for (var _m = 0; _m < _count; _m++) {
                var _ip = _idx[_m];
                if (_ip == _ia || _ip == _ib || _ip == _ic) continue;
                var _px2 = _points[_ip * 2], _py2 = _points[_ip * 2 + 1];
                var _d1 = (_bx2 - _ax) * (_py2 - _ay) - (_by2 - _ay) * (_px2 - _ax);
                var _d2 = (_cx2 - _bx2) * (_py2 - _by2) - (_cy2 - _by2) * (_px2 - _bx2);
                var _d3 = (_ax - _cx2) * (_py2 - _cy2) - (_ay - _cy2) * (_px2 - _cx2);
                if (_d1 >= 0 && _d2 >= 0 && _d3 >= 0) { _clear = false; break; }
            }
            if (!_clear) continue;

            array_push(_out, _ax, _ay, _bx2, _by2, _cx2, _cy2);
            array_delete(_idx, _k, 1);
            _count--;
            _clipped = true;
            break;
        }
        // No ear found: the polygon is self-intersecting or degenerate. Stop rather than spin.
        if (!_clipped) break;
    }

    if (_count == 3) {
        for (var _k = 0; _k < 3; _k++) {
            array_push(_out, _points[_idx[_k] * 2], _points[_idx[_k] * 2 + 1]);
        }
    }
    return _out;
}

/// @func   trv_icon_shape(_shape, _ox, _oy, _unit, _colour, _alpha, _flat, _scale)
/// @desc   Draws one shape of one icon. Internal to the renderer; exposed because a buyer building
///         a custom icon form will want to call it directly while iterating.
///
/// @param  {Struct} _shape   A shape from an icon's s array.
/// @param  {Real}   _ox      Box left edge in pixels.
/// @param  {Real}   _oy      Box top edge in pixels.
/// @param  {Real}   _unit    Pixels per grid unit.
/// @param  {Real}   _colour  Colour to draw in.
/// @param  {Real}   _alpha   Alpha.
/// @param  {Bool}   _flat    True to skip stroke shapes (used by the shadow pass).
/// @param  {Real}   _scale   Uniform scale about the box centre. 1 = none.
function trv_icon_shape(_shape, _ox, _oy, _unit, _colour, _alpha, _flat = false, _scale = 1) {
    if (_alpha <= 0) return;
    var _p = _shape.p, _k = _shape.k;

    // Scale about the centre of the 0..10 box so a rim-light copy shrinks inward rather than
    // sliding off one corner. Folded into a base offset and a scaled unit so the inner loops are
    // a multiply and an add — this runs once per shape per icon per frame, and an inventory
    // screen draws forty of them.
    var _u  = _unit * _scale;
    var _bx = _ox + 5 * _unit - 5 * _u;
    var _by = _oy + 5 * _unit - 5 * _u;

    draw_set_colour(_colour);
    draw_set_alpha(_alpha);

    switch (_k) {
        case TRV_SHAPE_POLY: {
            var _n = array_length(_p) div 2;
            if (_n < 3) break;

            // TRIANGULATED, NOT FANNED. A triangle fan from vertex 0 is only correct for a polygon
            // that is star-shaped about that vertex. This started life as a fan and three shipped
            // icons rendered wrong because of it — the cuirass lost its shoulders and became a box,
            // the helm lost its face gap, and the hourglass showed only its lower half. Every one
            // of them COMPILED PERFECTLY and the gate was clean through all three; the defect
            // existed only in pixels.
            //
            // It matters far more for a buyer than for us: the whole promise of this file is that
            // you can author your own forms, and a renderer that silently mangles concave polygons
            // is a footgun aimed at exactly the thing the product invites you to do.
            //
            // The triangulation is cached on the shape the first time it is drawn, so the ear
            // clipping runs once per form per run and never in a frame budget twice.
            if (!variable_struct_exists(_shape, "t")) _shape.t = trv_poly_triangulate(_p);
            var _tri = _shape.t, _tn = array_length(_tri) div 2;
            if (_tn < 3) break;
            draw_primitive_begin(pr_trianglelist);
            for (var _i = 0; _i < _tn; _i++) {
                draw_vertex(_bx + _tri[_i * 2] * _u, _by + _tri[_i * 2 + 1] * _u);
            }
            draw_primitive_end();
            break;
        }
        case TRV_SHAPE_LINE: {
            if (_flat) break;
            var _n = array_length(_p) div 2;
            var _w = max(1, _shape.w * _u);
            for (var _i = 0; _i < _n - 1; _i++) {
                draw_line_width(_bx + _p[_i * 2] * _u,       _by + _p[_i * 2 + 1] * _u,
                                _bx + _p[_i * 2 + 2] * _u,   _by + _p[_i * 2 + 3] * _u, _w);
            }
            // Round the joints. Without this a bent haft shows a notch on the outside of every
            // corner, which is very visible at 64 px and up.
            if (_n > 2 && _w > 2) {
                for (var _i = 1; _i < _n - 1; _i++) {
                    draw_circle(_bx + _p[_i * 2] * _u, _by + _p[_i * 2 + 1] * _u, _w * 0.5, false);
                }
            }
            break;
        }
        case TRV_SHAPE_DISC: {
            draw_circle(_bx + _p[0] * _u, _by + _p[1] * _u, _p[2] * _u, false);
            break;
        }
        case TRV_SHAPE_RING: {
            if (_flat) break;
            // Drawn as a filled ANNULUS from a triangle strip, not as a big disc with a smaller
            // one punched out of it: the punch-out would have to be painted in the background
            // colour, and Trove draws over gradients, so it would leave a visible plug. Getting
            // this wrong is the single most likely way a custom icon looks broken.
            var _w  = max(1, _shape.w * _u);
            var _rx = _bx + _p[0] * _u, _ry = _by + _p[1] * _u, _rr = _p[2] * _u;
            var _outer = _rr + _w * 0.5, _inner = max(0, _rr - _w * 0.5);
            draw_primitive_begin(pr_trianglestrip);
            var _seg = 40;
            for (var _i = 0; _i <= _seg; _i++) {
                var _a = _i / _seg * 2 * pi, _ca = cos(_a), _sa = sin(_a);
                draw_vertex(_rx + _ca * _outer, _ry + _sa * _outer);
                draw_vertex(_rx + _ca * _inner, _ry + _sa * _inner);
            }
            draw_primitive_end();
            break;
        }
        case TRV_SHAPE_RECT: {
            draw_rectangle(_bx + _p[0] * _u, _by + _p[1] * _u,
                           _bx + (_p[0] + _p[2]) * _u, _by + (_p[1] + _p[3]) * _u, false);
            break;
        }
    }

    draw_set_alpha(1);
}
