{
  "$GMScript": "v1",
  "%Name": "trv_theme",
  "isCompatibility": false,
  "isDnD": false,
  "name": "trv_theme",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}