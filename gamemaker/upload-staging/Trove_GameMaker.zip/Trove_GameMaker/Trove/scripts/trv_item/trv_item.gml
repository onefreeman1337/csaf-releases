/// @file    trv_item.gml
/// @package Trove for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary Items and rarity. What a thing IS, and how strongly the interface should shout about it.
///
/// @remarks Trove deliberately holds a very thin idea of an item: a form, a material, a rarity, a
///          stack count, and a free-form struct of your own data. It does not own your item
///          database, it does not want to, and it will not fight whatever you already have — if
///          you are using Magpie or your own struct-based inventory, keep it, and hand Trove a
///          TrvItem built from it at draw time.
///
///          THE ONE OPINION IN THIS FILE IS ABOUT RARITY, and it is a visual one. Rarity in most
///          games is a colour on a name. Here it is a whole treatment: the tier decides the frame,
///          the glow, whether the slot has corner marks, whether it shimmers, and how fast. That
///          is the difference between an inventory where the legendary is a different word and one
///          where the legendary is obviously the legendary from across the room.

// --- rarity tiers ---------------------------------------------------------------------------
#macro TRV_RARITY_COMMON    0
#macro TRV_RARITY_UNCOMMON  1
#macro TRV_RARITY_RARE      2
#macro TRV_RARITY_EPIC      3
#macro TRV_RARITY_LEGENDARY 4
#macro TRV_RARITY_MYTHIC    5

/// @func   trv_rarity_build()
/// @desc   Builds the rarity table. Called once, lazily, by trv_rarity_get.
///
/// @remarks THE COLOURS ARE DERIVED FROM THE ACTIVE THEME'S ACCENT, not hardcoded. Hardcoded
///          rarity colours are why so many inventories look bolted onto the game around them: a
///          cool violet UI with a lime-green "uncommon" in it reads as a different product. Every
///          colour here is built by trv_colour_status, which fixes the HUE per tier and borrows
///          the theme's SATURATION and VALUE — so the tiers stay instantly recognisable as the
///          familiar grey/green/blue/purple/orange/red ladder while still belonging to the palette
///          they are sitting in. Switch theme and the whole ladder moves with it.
///
///          Rebuilt on every call rather than cached, because it depends on the live theme and a
///          cached ladder would go stale the moment a buyer switched theme mid-game. It is six
///          structs; this is not a hot path.
///
/// @return {Array} Six tiers, each { n, c, glow, frame, shimmer }.
function trv_rarity_build() {
    var _t = trv_theme_get();
    return [
        { n: "COMMON",    c: _t.textDim,                        glow: 0.00, frame: 0, shimmer: 0.00 },
        { n: "UNCOMMON",  c: trv_colour_status(_t.accent,  92), glow: 0.16, frame: 1, shimmer: 0.00 },
        { n: "RARE",      c: trv_colour_status(_t.accent, 150), glow: 0.30, frame: 2, shimmer: 0.00 },
        { n: "EPIC",      c: trv_colour_status(_t.accent, 210), glow: 0.46, frame: 2, shimmer: 0.35 },
        { n: "LEGENDARY", c: trv_colour_status(_t.accent,  26), glow: 0.66, frame: 3, shimmer: 0.70 },
        { n: "MYTHIC",    c: trv_colour_status(_t.accent,   2), glow: 0.90, frame: 3, shimmer: 1.00 }
    ];
}

/// @func   trv_rarity(_tier)
/// @desc   The treatment for one rarity tier, against the live theme.
/// @param  {Real} _tier  One of the TRV_RARITY_* constants. Clamped into range.
/// @return {Struct} { n: name, c: colour, glow, frame, shimmer }.
function trv_rarity(_tier) {
    var _r = trv_rarity_build();
    return _r[clamp(_tier, 0, array_length(_r) - 1)];
}

/// @func   trv_rarity_count()
/// @desc   How many rarity tiers Trove ships.
/// @return {Real} Six.
function trv_rarity_count() { return 6; }

/// @func   TrvItem(_name, _icon, _material, _rarity, _count)
/// @desc   One item. A form, a material, a rarity, a stack count, and room for your own data.
///
/// @remarks _icon and _material accept EITHER an index OR a name string, because item tables read
///          far better as data when they say "SWORD" and "GOLD" than when they say 0 and 3 — and
///          because a numeric literal in an item table breaks silently the moment somebody inserts
///          an icon form above it. The lookup happens once, at construction.
///
/// @param  {String}       _name      Display name.
/// @param  {String|Real}  _icon      Icon form name or index.
/// @param  {String|Real}  _material  Material name or index.
/// @param  {Real}         _rarity    A TRV_RARITY_* constant.
/// @param  {Real}         _count     Stack count. 1 for a non-stacking item.
function TrvItem(_name, _icon, _material, _rarity = TRV_RARITY_COMMON, _count = 1) constructor {
    name     = _name;
    icon     = is_string(_icon) ? max(0, trv_icon_find(_icon)) : _icon;
    material = is_string(_material) ? max(0, trv_material_find(_material)) : _material;
    rarity   = _rarity;
    count    = _count;
    stack    = 99;          // maximum stack size; the slot draws a count when count > 1
    kind     = trv_icon_category(icon);
    stats    = [];          // array of { k: label, v: value } — drawn by the detail panel
    blurb    = "";          // one line of flavour, drawn under the stats
    value    = 0;           // your currency; drawn in the detail panel footer when non-zero
    data     = {};          // yours. Trove never reads this.

    /// @func   with_stats(_stats)
    /// @desc   Chainable. Attaches the stat lines the detail panel lists.
    /// @param  {Array} _stats  Array of { k, v } structs.
    /// @return {Struct} self.
    static with_stats = function(_stats) { stats = _stats; return self; };

    /// @func   with_blurb(_text)
    /// @desc   Chainable. Attaches one line of flavour text.
    /// @param  {String} _text  The line.
    /// @return {Struct} self.
    static with_blurb = function(_text) { blurb = _text; return self; };

    /// @func   with_value(_value)
    /// @desc   Chainable. Attaches a currency value.
    /// @param  {Real} _value  The value.
    /// @return {Struct} self.
    static with_value = function(_value) { value = _value; return self; };

    /// @func   palette()
    /// @desc   The five-colour material palette this item draws in.
    /// @return {Array} Five colours.
    static palette = function() { return trv_material_palette(material); };
}

/// @func   trv_material_find(_name)
/// @desc   Looks a material up by name so item tables can read as data.
/// @param  {String} _name  Case-insensitive material name, e.g. "GOLD".
/// @return {Real} The index, or -1 if there is no such material.
function trv_material_find(_name) {
    var _m = trv_material_get(), _u = string_upper(_name);
    for (var _k = 0; _k < array_length(_m); _k++) if (_m[_k].n == _u) return _k;
    return -1;
}

/// @func   trv_category_name(_category)
/// @desc   The display name of an icon category, for the filter rail.
/// @param  {Real} _category  A TRV_CAT_* constant.
/// @return {String} The name.
function trv_category_name(_category) {
    switch (_category) {
        case TRV_CAT_WEAPON:     return "WEAPONS";
        case TRV_CAT_ARMOUR:     return "ARMOUR";
        case TRV_CAT_CONSUMABLE: return "SUPPLIES";
        case TRV_CAT_ARCANE:     return "ARCANE";
        case TRV_CAT_MATERIAL:   return "MATERIALS";
    }
    return "ALL";
}
