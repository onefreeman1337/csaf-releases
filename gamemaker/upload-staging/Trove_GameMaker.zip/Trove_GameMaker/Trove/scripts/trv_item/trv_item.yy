{
  "$GMScript": "v1",
  "%Name": "trv_item",
  "isCompatibility": false,
  "isDnD": false,
  "name": "trv_item",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}