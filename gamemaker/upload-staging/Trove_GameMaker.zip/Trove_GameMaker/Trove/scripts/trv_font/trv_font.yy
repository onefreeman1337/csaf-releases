{
  "$GMScript": "v1",
  "%Name": "trv_font",
  "isCompatibility": false,
  "isDnD": false,
  "name": "trv_font",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}