{
  "$GMScript": "v1",
  "%Name": "trv_ease",
  "isCompatibility": false,
  "isDnD": false,
  "name": "trv_ease",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}