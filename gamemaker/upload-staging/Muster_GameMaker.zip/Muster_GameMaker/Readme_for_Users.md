# MUSTER — Battlefields That Draw Themselves

**Tactical terrain for GameMaker, composed from a seed and drawn in pure GML.**
52 terrain features · 8 biomes · 8 seasons · **no sprites** — every mark is geometry, so the package
has no `sprites/` folder at all. The only textures it ships are the two font resources it draws
labels with (`fnt_muster`, `fnt_muster_title`).

Version 1.0.0 · GameMaker Studio 2.3+ / GameMaker 2024.x · runtime `2024.14.4.268`

---

## What this is, and what it is not

**Keep your battle engine. This is the ground it is fought on.**

There are good paid tactics frameworks for GameMaker. They ship the *rules* of a fight — movement
costs, pathfinding, a weapon triangle, an AI — and then leave you to find or draw the terrain,
which is why the same storefront is full of tile packs. Muster is the other half. It composes a
whole battlefield from a seed and draws it, and the rules it does ship exist for one reason:

> **A feature's cover value is not kept in step with its picture. It is the same row.**

`mst_feature_spec()` returns a feature's materials, its geometry, its cover value, its line-of-sight
block, its height and its movement cost together. `mst_field` writes those numbers into the cell as
it *places* the thing, and `mst_tactics` reads them back. There is no second table and no
synchronisation step, so you cannot reach a state where a boulder is drawn and queries as open
ground — which is the bug every hand-built tile map eventually has.

If you already own a battle engine, use Muster for the ground and ask it what the ground is. If you
do not, there is enough here to prototype with.

---

## Quickstart

1. Import `Muster.yymps` (**Tools → Import Local Package**, select all).
2. Open `rm_mst_demo` and press Play. That room is the whole API in one screen.
3. In your own object:

```gml
// Create
field  = mst_field_make(12, 12, 1701, "downland", "harvest", 0.8);
pal    = mst_field_palette(field);
origin = mst_field_origin(field, 0, 0, room_width, room_height);

// Draw
mst_field_draw(field, pal, origin[0], origin[1]);
```

That is the entire integration. Everything below is optional.

### The demo's controls

| key | does |
| --- | --- |
| `Q` / `W` | previous / next biome |
| `A` / `S` | previous / next season |
| `Z` / `X` | season strength down / up |
| `SPACE` | reseed |
| `C` | cover overlay |
| `V` | movement overlay from the cursor |
| `B` | line-of-sight overlay from the cursor |
| `N` | scenario overlay — deployment zones, chokepoints, objectives |
| `G` | grid |
| arrows | move the cursor |

Press `C` over a finished battlefield. The cover marks land on the ground each wall protects, and
nowhere else, because both come out of the same row.

---

## Asking the ground questions

```gml
mst_cover_at(f, x, y)              // cover from the feature IN this cell (0 if nobody can stand there)
mst_cover_best(f, x, y)            // best cover available here, from this cell and its neighbours
mst_cover_from(f, dx, dy, ax, ay)  // DIRECTIONAL: what the defender gets from THIS attacker
mst_cost_at(f, x, y)               // movement cost to enter, or MST_IMPASSABLE
mst_step_cost(f, fx, fy, tx, ty)   // including the climb
mst_level_at(f, x, y)              // elevation, 0..3
mst_los(f, ax, ay, bx, by)         // line of sight, height-aware
mst_height_edge(f, ax, ay, dx, dy) // does the attacker hold the high ground
mst_move_range(f, x, y, budget)    // array of costs, MST_IMPASSABLE beyond the budget
mst_path(f, ax, ay, bx, by)        // cheapest route as [[x,y], ...]
mst_field_report(f)                // what kind of fight this map will produce
```

**Cover is directional.** A unit behind a wall is exposed from behind it, and a unit on high ground
sees over low cover. `mst_cover_from` is the one to use when resolving a specific shot;
`mst_cover_best` is the one to use for a map overlay.

---

## What the generator guarantees

1. **Every field is crossable.** There is a route from one deployment zone to the other. This is not
   hoped for, it is repaired: blocking features are cleared, and where the ground itself seals the
   map, cells are regraded to a passable material from the same biome. Both repairs are counted and
   reported (`report.cleared`, `report.regraded`), so a map that needed six regrades is one you can
   reject rather than one you never hear about.
2. **Every deployment cell is standable.** No unit ever starts inside a boulder or a pool.
3. **The picture and the rules agree.** See the top of this file.

`mst_field_report(f)` gives you `crossing` (the crossing distance in movement points), `goingRate`
(average cost per cell), the hard/soft/open cover split, `chokepoints`, `objectives`, and the repair
counts. Generating in bulk and rejecting on those numbers is the intended workflow.

---

## Seasons are not a tint

Each material carries a **susceptibility**. Turf is 1.00 and changes completely; granite is **0.00**
and does not move at all. A season is a pull toward a target weighted by that number, so a snowbound
field is a field under snow rather than a field that has been painted white — the boulders are still
granite.

**And the season changes the movement cost from the same table that changed the colour.** Snowbound
turns standing water into something walkable and slows mud; thaw turns worked loam into mud that
costs double; drought dries a river bed out. The river you could not cross in autumn is a road in
February, and you cannot get the picture and the cost out of step because there is nowhere else for
either to come from.

---

## Determinism

Nothing in this package calls `random()`. A field is a pure function of
`(width, height, seed, biome, season, strength)`. Two calls with the same arguments produce the same
battlefield, so **store the seed, not the map** — a save file, a replay or a multiplayer peer
rebuilds it exactly.

---

## Performance

A field is plain data: structs, numbers and arrays. Nothing here allocates a sprite, a surface, a
buffer or a `ds_*` structure, so there is nothing to free — generate a thousand fields in a loop and
drop them on the floor.

Drawing is immediate-mode primitives. If you are drawing a static field every frame and want it
cheaper, render it once to a surface and blit that; `mst_render_to_sprite` will bake a single
feature's part list into a sprite if you want one (you own the sprite it returns).

---

## Namespacing

Every function and macro in this package is prefixed `mst_` / `MST_`. GML's global namespace is
flat, so a collision in your project would be a compile error pointing at a file you did not write.
There are no unprefixed globals.

---

## What is in the box

```
scripts/
  mst_geom      primitives, curves, transforms, seeded hash and RNG
  mst_palette   Oklab -> sRGB, chroma ceiling, gamut reduction
  mst_relief    shade any outline by its own surface normal against one lamp
  mst_shape     outline treatments, turning, self-intersection, bevel caps
  mst_render    the only file that talks to the GPU
  mst_ground    28 materials, 8 seasons, and the movement costs
  mst_feature   the 52-feature spec table, materials, and the dispatcher
  mst_stone     8 builders   mst_built  17 builders
  mst_flora     15 builders  mst_hazard 12 builders
  mst_field     the generator: elevation, ground, scatter, connectivity, analysis
  mst_tactics   cover, line of sight, movement, paths, the report
  mst_draw      the isometric projection and the overlays
  mst_demo      what the demo room does
  mst_bake      the store sheets, rendered by the product
  mst_selftest  14,790 in-engine assertions
objects/  obj_mst_demo      rooms/  rm_mst_demo      fonts/  fnt_muster, fnt_muster_title
```

`sprites/` does not exist. That is the point.

---

## Verification, stated honestly

GML cannot be unit-tested outside the engine — there is no headless runner and no mocking. What this
package does instead:

- **14,790 in-engine assertions**, run by building through Igor and executing the result with
  `-selftest`. They cover the corpus counts, every material ramp, the season model's negative and
  positive controls, every feature building in every season, drawn height against declared height,
  field generation across all 64 biome/season pairs, the cover model, line-of-sight symmetry, path
  costs against the distance field, and determinism.
- Assertions that could pass vacuously are **paired with a guard** proving the fixture is in the
  state they need.
- **Every store image on the listing was rendered by this package**, by `mst_bake`, through the same
  drawing code you get.

What that does **not** prove: a suite that computes numbers cannot see a fill rule, a draw order or
a picture. Every sheet was also opened and looked at, and several defects were found that way and
only that way.

---

## Support

Comment on the itch page. Include the seed, biome, season and field size — that is enough to
reproduce any field exactly.

---

*Core Systems Asset Factory · AI-assisted: code yes, graphics yes, sounds no, text yes.*
