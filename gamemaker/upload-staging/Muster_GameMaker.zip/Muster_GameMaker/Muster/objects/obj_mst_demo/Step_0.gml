/// @description Step - the demo's controls

// ⚠️ EVERY KEY HERE IS ALSO PRINTED ON SCREEN BY THE DRAW EVENT. A demo whose controls are only in
// the Readme is a demo a buyer closes after ten seconds, and the demo room is this wing's
// quickstart, its GIF source and its only real smoke test all at once.

var _biomes = mst_biome_names();
var _seasons = mst_season_names();

// -- what field ---------------------------------------------------------------------------------
if (keyboard_check_pressed(ord("Q"))) {
    biome_i = (biome_i + array_length(_biomes) - 1) % array_length(_biomes);
    mst_demo_rebuild();
}
if (keyboard_check_pressed(ord("W"))) {
    biome_i = (biome_i + 1) % array_length(_biomes);
    mst_demo_rebuild();
}
if (keyboard_check_pressed(ord("A"))) {
    season_i = (season_i + array_length(_seasons) - 1) % array_length(_seasons);
    mst_demo_rebuild();
}
if (keyboard_check_pressed(ord("S"))) {
    season_i = (season_i + 1) % array_length(_seasons);
    mst_demo_rebuild();
}
if (keyboard_check_pressed(vk_space)) {
    seed += 1;
    mst_demo_rebuild();
}

// Season STRENGTH. ⭐ This is the control worth putting in a GIF: holding one seed and one biome
// and sliding the season from 0 to 1 recolours the whole field AND re-costs the mud and the water,
// which is the product's central claim happening in front of the buyer.
if (keyboard_check_pressed(ord("Z"))) {
    season_t = max(0, season_t - 0.25);
    mst_demo_rebuild();
}
if (keyboard_check_pressed(ord("X"))) {
    season_t = min(1, season_t + 0.25);
    mst_demo_rebuild();
}

// -- what to show -------------------------------------------------------------------------------
if (keyboard_check_pressed(ord("C"))) overlay = (overlay == 1) ? 0 : 1;
if (keyboard_check_pressed(ord("V"))) overlay = (overlay == 2) ? 0 : 2;
if (keyboard_check_pressed(ord("B"))) overlay = (overlay == 3) ? 0 : 3;
if (keyboard_check_pressed(ord("N"))) overlay = (overlay == 4) ? 0 : 4;
if (keyboard_check_pressed(ord("G"))) grid_on = !grid_on;

// -- the cursor, which is what the movement and sight overlays are measured FROM ----------------
if (!is_undefined(field)) {
    if (keyboard_check_pressed(vk_left))  cursor_x = max(0, cursor_x - 1);
    if (keyboard_check_pressed(vk_right)) cursor_x = min(field.w - 1, cursor_x + 1);
    if (keyboard_check_pressed(vk_up))    cursor_y = max(0, cursor_y - 1);
    if (keyboard_check_pressed(vk_down))  cursor_y = min(field.h - 1, cursor_y + 1);
}
