/// @description Draw GUI - the field, an overlay, and the numbers behind it

if (is_undefined(field) || is_undefined(pal)) exit;

var _gw = display_get_gui_width();
var _gh = display_get_gui_height();

// The page. A designed ground rather than a default black: the wing's Gate 1 is that a product must
// not look like the engine, and window_colour is the first thing a buyer sees.
draw_clear(mst_oklch(0.155, 0.010, 250));

var _ox = origin[0], _oy = origin[1];

mst_field_draw(field, pal, _ox, _oy);
if (grid_on) mst_draw_grid(field, pal, _ox, _oy);

switch (overlay) {
    case 1: mst_draw_cover(field, pal, _ox, _oy); break;
    case 2: {
        var _d = mst_move_range(field, cursor_x, cursor_y, 7);
        mst_draw_range(field, pal, _d, _ox, _oy);
    } break;
    case 3: mst_draw_los(field, pal, cursor_x, cursor_y, _ox, _oy); break;
    case 4: mst_draw_plan(field, pal, _ox, _oy); break;
}

// The cursor sits on top of every overlay, because it is what the overlays are measured from.
if (overlay == 2 || overlay == 3) {
    mst_draw_cell_outline(field, cursor_x, cursor_y, _ox, _oy, pal.ov_obj, 3);
}

// -- the readout ---------------------------------------------------------------------------------
// ⚠️ EVERY NUMBER HERE COMES OUT OF mst_field_report, WHICH READS THE FIELD. None of it is a
// remembered value from generation time, so a discrepancy between the picture and this panel is a
// real defect and not a stale cache.
draw_set_font(fnt_muster);
var _ink = mst_oklch(0.90, 0.012, 84);
var _dim = mst_oklch(0.62, 0.014, 84);

var _x = 18, _y = 16, _lh = 17;
mst_text_line("MUSTER  " + MST_VERSION, _x, _y, 420, 15, _ink, true); _y += _lh + 4;
mst_text_line(string_upper(field.biome) + "   " + string_upper(field.season)
              + "  x" + string_format(field.season_t, 1, 2)
              + "   seed " + string(field.seed), _x, _y, 460, 13, _ink, false); _y += _lh;
if (!is_undefined(report)) {
    mst_text_line("crossing " + string(report.crossing) + " mp"
                  + "    going " + string_format(report.goingRate, 1, 2)
                  + "    chokes " + string(report.chokepoints), _x, _y, 460, 12, _dim, false);
    _y += _lh;
    mst_text_line("hard " + string(report.hardCover) + "   soft " + string(report.softCover)
                  + "   open " + string(report.openGround) + "   blocked " + string(report.blocked)
                  + "   cleared " + string(report.cleared), _x, _y, 460, 12, _dim, false);
    _y += _lh;
}

var _c = mst_cell(field, cursor_x, cursor_y);
if (!is_undefined(_c)) {
    var _fn = (_c.feat == "") ? "-" : _c.feat;
    // The cover a unit standing here would ACTUALLY get, which is mst_cover_best - not the
    // cell's own provide-value, which is zero for open ground beside a wall and nonzero for the
    // wall itself. See mst_cover_at for why those are different questions.
    var _cb = mst_cover_best(field, cursor_x, cursor_y);
    var _cn = (_cb == MST_COVER_HARD) ? "HARD" : ((_cb == MST_COVER_SOFT) ? "soft" : "open");
    var _cost = (_c.cost >= MST_IMPASSABLE) ? "X" : string(_c.cost);
    mst_text_line("cell " + string(cursor_x) + "," + string(cursor_y)
                  + "   " + _c.ground + "   level " + string(_c.level)
                  + "   " + _fn + "   cover " + _cn + "   cost " + _cost,
                  _x, _y, 560, 12, _ink, false);
    _y += _lh;
}

var _names = ["", "COVER", "MOVEMENT", "LINE OF SIGHT", "SCENARIO"];
if (overlay > 0) {
    mst_text_line("overlay: " + _names[overlay], _x, _y, 420, 12, pal.ov_obj, true);
    _y += _lh;
}

// Controls, bottom left. On screen because a demo whose keys are only in the Readme is a demo a
// buyer closes without pressing anything.
var _cy2 = _gh - 74;
mst_text_line("Q/W biome    A/S season    Z/X season strength    SPACE reseed",
              _x, _cy2, 640, 12, _dim, false);
mst_text_line("C cover    V movement    B sight    N scenario    G grid    ARROWS cursor",
              _x, _cy2 + 17, 640, 12, _dim, false);
mst_text_line("every mark an overlay draws is read from the same cell the terrain was drawn from",
              _x, _cy2 + 38, 640, 11, mst_oklch(0.50, 0.012, 84), false);
