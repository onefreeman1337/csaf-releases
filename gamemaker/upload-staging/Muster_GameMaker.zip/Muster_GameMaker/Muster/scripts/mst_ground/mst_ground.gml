/// MUSTER - mst_ground. What a battlefield is MADE of, as five-stop relief ramps, what the
/// SEASON does to it, and what it costs to walk across.
///
/// Every colour in this product is COMPUTED. There is no table of hex values in this package,
/// because a hex table is a thing a buyer cannot steer: ask it for "the same valley in February"
/// and a table has no answer, while a ramp does.
///
/// -- WHAT A RAMP IS --------------------------------------------------------------------------
/// mst_relief shades a surface by how squarely it faces the lamp and returns one of five role
/// names, "m0" (facing away) through "m4" (facing the lamp). A MATERIAL is therefore five
/// colours, and mst_ground_ramp() produces them. Hand the same turf two different seasons and you
/// get two ramps that are recognisably the same field at two times of year.
///
/// ⛔ THE STOPS ARE SPACED IN OKLAB LIGHTNESS, NOT IN RGB. That is the whole reason mst_palette
/// exists. Five RGB-spaced stops on warm loam and five on cold basalt have visibly different
/// contrast, and in this product those two materials sit IN ADJACENT CELLS, lit by one lamp.
/// Perceptual spacing is what lets one lamp light the whole field correctly.
///
/// -- SPAN IS WHAT SEPARATES A WET ROCK FROM A DRY MEADOW ---------------------------------------
/// A battlefield is a harder case than a single object, because one screen carries a mirror-flat
/// sheet of water, a matte fibrous stand of corn, a hard faceted scree slope and a soft snowfield
/// at the same time, and the player is looking at all four at once. SPAN does that work: water and
/// bracken at the same span read as the same stuff in two colours, which is the palette-swap
/// failure this product exists to avoid. Snow has almost no span because snow scatters light in
/// every direction; still water has nearly four times as much as anything growing.
///
/// -- ⭐ AND THIS FILE IS WHERE THE PRODUCT'S CENTRAL CLAIM IS ACTUALLY IMPLEMENTED --------------
/// "The picture and the rules are the same object." That is not a slogan about architecture, it
/// is this file: MST_GROUND names a material's colour ramp AND its movement cost AND what a season
/// turns it into, in ONE table. A buyer cannot end up with a field that LOOKS frozen and COSTS
/// what mud costs, because the freeze and the cost come out of the same row. Every incumbent
/// measured on this shelf ships the cost and leaves the buyer to find the picture.
/// ============================================================================================

// ⚠️ MST_RAMP_N IS DEFINED IN mst_relief, NOT HERE, AND IT IS DELIBERATELY NOT REPEATED.
// It belongs to the relief engine because it is the relief engine that decides how many stops a
// surface has - this file just fills them in. Declaring it in both places is what the first gate
// run of a sibling product died on ("macro MST_RAMP_N is already defined"), and the fix is not to
// rename one of them: a constant with two homes is a constant that will hold two values.

/// The number of named ground materials. Asserted against mst_ground_names() by the suite, so the
/// list below and the names function can never drift apart silently.
#macro MST_GROUND_N 28

/// The number of seasons. Asserted the same way, for the same reason.
#macro MST_SEASON_N 8

/// Movement cost of a cell nothing can cross. Not "very expensive" - a distinct value, so that a
/// pathfinder testing `cost >= MST_IMPASSABLE` cannot be fooled by a merely costly cell, and so
/// that a sum of costs along a path can never quietly step through a cliff.
#macro MST_IMPASSABLE 999

/// ============================================================================================
/// THE MATERIALS
///
/// Each is a base lightness, a chroma, a hue in degrees, how far the ramp spans in lightness,
/// what it costs to cross, and HOW HARD THE SEASON MOVES IT. That last column is the product.
///
/// ⛔ `susc` (susceptibility, 0..1) IS THE TERM A NAIVE MODEL LEAVES OUT AND IT IS THE ONE THAT
/// MATTERS. A season is not a filter over the whole picture. Turf in February is white and turf in
/// August is straw - it changes completely, susc 1.00. GRANITE IN FEBRUARY IS GRANITE, susc 0.00.
/// A model that tints everything equally produces a field where the boulders are made of snow,
/// which is the single loudest tell of a colour-graded screenshot rather than a generated world.
///
/// ⭐ granite/basalt at susc 0.00 are the NEGATIVE CONTROL, exactly as gold-does-not-corrode was in
/// the donor: at ANY season and ANY strength their ramp must come back UNCHANGED. A multiplicative
/// or global-tint model cannot express that; a susceptibility-weighted pull gets it for free, and
/// the suite asserts it, so the day someone "simplifies" this into a screen tint it goes red.
///
/// ⚠️ CHROMA IS LOW ACROSS THIS WHOLE TABLE ON PURPOSE, and the numbers were pulled DOWN twice.
/// The wing's standing correction (Armoury's ash haft, Hearth's earth-plaster wall): chroma has to
/// come down over a large flat area, and on this product EVERY material is a large flat area - a
/// cell of turf is the biggest single surface in the package. Real turf is a grey-green; the
/// warmth belongs in the ramp's hue, not in its saturation. Anything above about C 0.06 here reads
/// as a children's board game.
/// ============================================================================================

/// Each material's five numbers plus its cost and its susceptibility to the season.
function mst_ground_spec(_mat) {
    switch (_mat) {
        // name          L      C      hue   span   cost  susc      the surface being described
        // -- LIVING GROUND: what the season owns completely ------------------------------------
        case "turf":     return { L: 0.430, C: 0.042, h: 132, span: 0.20, cost: 1, susc: 1.00 }; // cropped pasture
        case "meadow":   return { L: 0.520, C: 0.046, h: 118, span: 0.24, cost: 1, susc: 1.00 }; // long grass, paler
        case "heath":    return { L: 0.375, C: 0.038, h: 348, span: 0.22, cost: 2, susc: 0.85 }; // heather and ling
        case "moss":     return { L: 0.355, C: 0.048, h: 142, span: 0.16, cost: 1, susc: 0.70 }; // damp, holds its colour
        case "bracken":  return { L: 0.400, C: 0.052, h:  86, span: 0.24, cost: 2, susc: 1.00 }; // fern, waist high
        case "reed":     return { L: 0.545, C: 0.044, h:  92, span: 0.26, cost: 2, susc: 0.80 }; // marsh margin
        case "corn":     return { L: 0.615, C: 0.058, h:  84, span: 0.28, cost: 2, susc: 1.00 }; // standing crop
        case "bramble":  return { L: 0.330, C: 0.040, h: 122, span: 0.22, cost: 3, susc: 0.90 }; // thorn, near impassable
        case "leaf":     return { L: 0.415, C: 0.050, h: 126, span: 0.26, cost: 1, susc: 1.00 }; // broadleaf canopy
        case "needle":   return { L: 0.290, C: 0.036, h: 156, span: 0.22, cost: 1, susc: 0.35 }; // conifer, evergreen
        case "bark":     return { L: 0.330, C: 0.026, h:  58, span: 0.30, cost: 1, susc: 0.25 }; // trunk and limb
        // -- BARE GROUND: the season moves it, but less ----------------------------------------
        case "loam":     return { L: 0.335, C: 0.030, h:  56, span: 0.20, cost: 1, susc: 0.55 }; // ploughed, workable
        case "mud":      return { L: 0.285, C: 0.024, h:  62, span: 0.26, cost: 2, susc: 0.60 }; // churned, holds a boot
        case "clay":     return { L: 0.400, C: 0.048, h:  42, span: 0.22, cost: 2, susc: 0.45 }; // heavy, red-brown
        case "sand":     return { L: 0.680, C: 0.040, h:  78, span: 0.24, cost: 2, susc: 0.30 }; // dune and riverbank
        case "shingle":  return { L: 0.560, C: 0.014, h:  66, span: 0.34, cost: 2, susc: 0.25 }; // river gravel
        case "scree":    return { L: 0.470, C: 0.012, h:  70, span: 0.38, cost: 2, susc: 0.20 }; // broken slope
        // ⚠️ RAISED FROM L 0.185 AFTER LOOKING AT A BAKED SHEET. Burnt ground is a dark GREY,
        // not black, and at 0.185 a whole basin of it read as a hole in the world rather than as a
        // surface - the largest single failure on the scenario sheet. A material's lightness has to
        // survive being the biggest area on the screen, which is not how it looks in a swatch.
        case "cinder":   return { L: 0.300, C: 0.012, h:  48, span: 0.28, cost: 1, susc: 0.20 }; // burnt over
        // -- ROCK: the negative control ---------------------------------------------------------
        case "granite":  return { L: 0.475, C: 0.008, h: 268, span: 0.36, cost: MST_IMPASSABLE, susc: 0.00 }; // pale, crystalline
        case "basalt":   return { L: 0.245, C: 0.006, h: 258, span: 0.34, cost: MST_IMPASSABLE, susc: 0.00 }; // dark, columnar
        case "limestone":return { L: 0.640, C: 0.014, h:  76, span: 0.32, cost: MST_IMPASSABLE, susc: 0.10 }; // pale, weathers
        case "sandstone":return { L: 0.545, C: 0.046, h:  54, span: 0.30, cost: MST_IMPASSABLE, susc: 0.10 }; // warm, beds
        // -- BUILT: made by people, and it shows -----------------------------------------------
        case "brick":    return { L: 0.375, C: 0.062, h:  36, span: 0.28, cost: MST_IMPASSABLE, susc: 0.10 }; // fired earth
        case "mortar":   return { L: 0.585, C: 0.010, h:  80, span: 0.24, cost: MST_IMPASSABLE, susc: 0.15 }; // lime, rubble core
        case "daub":     return { L: 0.640, C: 0.026, h:  72, span: 0.20, cost: MST_IMPASSABLE, susc: 0.20 }; // wattle and daub
        case "timber":   return { L: 0.420, C: 0.024, h:  62, span: 0.28, cost: MST_IMPASSABLE, susc: 0.30 }; // weathered structural
        case "thatch":   return { L: 0.500, C: 0.048, h:  74, span: 0.26, cost: MST_IMPASSABLE, susc: 0.45 }; // reed and straw
        case "iron":     return { L: 0.345, C: 0.011, h: 252, span: 0.42, cost: MST_IMPASSABLE, susc: 0.15 }; // fittings, blades, bands
    }
    return { L: 0.500, C: 0.020, h: 70, span: 0.26, cost: 1, susc: 0.50 };
}

/// The material names, in corpus order. Used by the self-test and the store sheets so that
/// neither can drift from the switch above without going red.
function mst_ground_names() {
    return ["turf", "meadow", "heath", "moss", "bracken", "reed", "corn", "bramble",
            "leaf", "needle", "bark",
            "loam", "mud", "clay", "sand", "shingle", "scree", "cinder",
            "granite", "basalt", "limestone", "sandstone",
            "brick", "mortar", "daub", "timber", "thatch", "iron"];
}

/// ============================================================================================
/// THE SEASON - THE ONE PIECE OF COLOUR MATHS IN THIS PACKAGE THAT HAD TO BE GOT RIGHT
///
/// ⛔⛔ A TRANSFORM THAT MANUFACTURES ITS OWN COLOUR MUST PULL TOWARD A TARGET, NEVER SCALE WHAT
/// WAS THERE. This is the wing's Repast law, and a snowfall is the clearest case of it there is:
///
///   - AS AN ADDITION it is wrong. "+40 lightness" on limestone (0.640) gives a blown-out white,
///     and the same +40 on basalt (0.245) gives a grey that is not snow either. Snow is not
///     "brighter rock", it is a DIFFERENT SUBSTANCE lying on top of one.
///   - AS A MULTIPLICATION it is worse. Turf's chroma is 0.042 and snow's is near zero; no
///     multiplier turns a green into a blue-white, so a freezing meadow would run green -> DARK
///     GREEN and never reach winter at all. That is exactly the failure the donor recorded for a
///     loaf of bread going cream -> GREY instead of browning.
///
/// So every season names a TARGET (L, C, h, span) and a strength, and the material travels toward
/// it. Turf under snow arrives at snow's colour because snow's colour is where it is going, not
/// because its own numbers were nudged.
///
/// ⭐ AND SPAN IS PULLED TOO, WHICH THE DONOR'S DECAY MODEL ONLY DID AS A MULTIPLIER. A season
/// does not merely recolour a surface, it changes how that surface CATCHES LIGHT: fresh snow is
/// the flattest thing in this package (it scatters in every direction, span 0.10) and a frozen
/// puddle is one of the hardest (span 0.52). A season that only moved hue would give a snowfield
/// with a rock's shading, which reads as white-painted rock.
/// ============================================================================================

/// Where a material ends up under a season, and how hard the season pulls.
function mst_season_spec(_season) {
    switch (_season) {
        //                            L      C      hue   span   k     what it is
        case "verdant":   return { L: 0.455, C: 0.058, h: 138, span: 0.24, k: 0.30 }; // late spring, everything growing
        case "highsummer":return { L: 0.560, C: 0.050, h: 100, span: 0.24, k: 0.42 }; // dry, standing hay
        case "harvest":   return { L: 0.530, C: 0.072, h:  62, span: 0.26, k: 0.58 }; // turning, amber and rust
        case "fallow":    return { L: 0.380, C: 0.018, h:  70, span: 0.22, k: 0.55 }; // bare, wet, low light
        case "thaw":      return { L: 0.320, C: 0.020, h:  64, span: 0.28, k: 0.62 }; // mud season, everything churned
        case "snowbound": return { L: 0.885, C: 0.008, h: 246, span: 0.10, k: 0.88 }; // lying snow, flat light
        case "drought":   return { L: 0.660, C: 0.030, h:  84, span: 0.22, k: 0.66 }; // bleached, cracked, dusty
        case "blighted":  return { L: 0.290, C: 0.014, h: 300, span: 0.18, k: 0.72 }; // the fantasy one: grey-violet, dead
    }
    return undefined; // unknown season - and every caller must handle it, which is the point.
}

/// The season names, in corpus order.
function mst_season_names() {
    return ["verdant", "highsummer", "harvest", "fallow", "thaw", "snowbound", "drought", "blighted"];
}

/// ⛔ HUE IS AN ANGLE AND MUST BE INTERPOLATED THE SHORT WAY ROUND. Carried from the donor, where
/// it was found by working out that two hues were 206 degrees apart BEFORE baking a sheet.
///
/// It matters at least as much here. Turf sits at hue 132 and blighted at 300, which is 168 apart:
/// a straight lerp from 132 travels 132 -> 216 -> 300, i.e. a dying meadow goes through CYAN. The
/// short way round is the same direction here, but heath sits at 348 and drought at 84, where a
/// straight lerp runs 348 -> 216 -> 84 (through cyan and green, the long way, backwards) and the
/// short way runs 348 -> 360/0 -> 84 through red and orange, which is what dying heather does.
function mst_hue_lerp(_h0, _h1, _t) {
    var _d = _h1 - _h0;
    while (_d > 180) _d -= 360;
    while (_d < -180) _d += 360;
    var _h = _h0 + _d * _t;
    while (_h < 0) _h += 360;
    while (_h >= 360) _h -= 360;
    return _h;
}

/// A material's spec under a season at strength _t (0..1). Returns the same shape as
/// mst_ground_spec so everything downstream is unchanged.
function mst_ground_seasoned(_mat, _season, _t) {
    var _s = mst_ground_spec(_mat);
    var _tg = mst_season_spec(_season);
    var _u = clamp(_t, 0, 1);
    if (is_undefined(_tg) || _u <= 0 || _s.susc <= 0) return _s;

    // THE SUSCEPTIBILITY TERM. See the table header: this is what stops the season from turning
    // the boulders into snow. Granite's susc is 0, so _k is 0, so the early return above already
    // caught it - but the multiply is written out anyway because a material at susc 0.10 must be
    // moved a LITTLE and the early return cannot express that.
    var _k = _u * _tg.k * _s.susc;

    // ⛔⛔ HUE IS INTERPOLATED BY CHROMA WEIGHT, NOT BY _k. Carried from the donor, where six of
    // twelve swords on the central sheet rusted through LILAC before this was understood.
    //
    // ⭐ THE ERROR IS DEEPER THAN THE DIRECTION AND IT IS WORTH RESTATING FOR THIS SUBJECT:
    // INTERPOLATING THE HUE OF A COLOUR THAT HAS NO CHROMA IS MEANINGLESS. Snow's chroma is 0.008.
    // Snow does not HAVE a hue in any sense a viewer can see; the 246 in its spec is the direction
    // its shadows lean, not a colour. Sweeping turf's 132 toward it as if 246 were an appearance
    // takes a freezing meadow through TEAL at every middle step, and every one of those middle
    // steps is what a half-thawed field is.
    //
    // Mixing two pigments, the resulting hue is dominated by whichever brings more chroma. So the
    // hue weight is the target's CHROMA CONTRIBUTION, not the season's progress: turf under snow
    // simply loses its green and gets paler, while heath under harvest - where both terms are real
    // colours - genuinely blends purple into amber.
    var _cs = _s.C * (1 - _k);
    var _ct = _tg.C * _k;
    var _hw = (_cs + _ct > 0.00001) ? (_ct / (_cs + _ct)) : _k;

    return {
        L: lerp(_s.L, _tg.L, _k),
        C: lerp(_s.C, _tg.C, _k),
        h: mst_hue_lerp(_s.h, _tg.h, _hw),
        // SPAN IS PULLED, NOT SCALED. See the season header. A snowfield must arrive at snow's
        // flatness and a frozen pool at ice's hardness; a multiplier can only ever go one way.
        span: lerp(_s.span, _tg.span, _k),
        cost: _s.cost,
        susc: _s.susc,
    };
}

/// ============================================================================================
/// COST - AND THIS IS THE HALF THAT MAKES THE PICTURE AND THE RULES ONE OBJECT
/// ============================================================================================

/// What it costs to enter a cell of this material in this season.
///
/// ⭐ THE SEASON CHANGES THE COST, FROM THE SAME TABLE THAT CHANGED THE COLOUR. That sentence is
/// the product. A field that LOOKS frozen IS frozen: snowbound turns standing water into ice a
/// unit can walk on, and thaw turns worked loam into mud that costs double. A buyer cannot get
/// these out of step, because there is nowhere else for either of them to come from.
///
/// ⚠️ THE MODIFIERS ARE DELIBERATELY FEW. Every one of them is a rule a player has to hold in
/// their head during a fight, and a tactics game with fourteen terrain exceptions is a tactics
/// game nobody finishes a turn in. Three seasons change cost and five do not.
function mst_ground_cost(_mat, _season, _t) {
    var _base = mst_ground_spec(_mat).cost;
    if (_base >= MST_IMPASSABLE) return MST_IMPASSABLE;
    var _u = clamp(_t, 0, 1);
    // A weak season does not change the going. Half strength is the threshold everywhere here so
    // that a buyer dialling season strength gets ONE transition per material, not a slide.
    if (_u < 0.5) return _base;

    switch (_season) {
        case "thaw":
            // Everything soft gets softer. Rock and built surfaces are already impassable above.
            if (_mat == "loam" || _mat == "turf" || _mat == "meadow" || _mat == "moss") return _base + 1;
            if (_mat == "mud" || _mat == "clay") return _base + 1;
            break;
        case "snowbound":
            // ⭐ Snow SLOWS soft ground and SPEEDS water, because a frozen pool is a floor. This is
            // the one modifier in the file that makes a cell cheaper, and it is the one a player
            // will plan a whole turn around.
            if (_mat == "mud" || _mat == "clay" || _mat == "bracken" || _mat == "corn") return _base + 1;
            break;
        case "drought":
            // A dried river bed and cracked clay are easier going than the wet versions.
            if (_mat == "mud" || _mat == "clay") return max(1, _base - 1);
            break;
    }
    return _base;
}

/// ============================================================================================
/// THE RAMP
/// ============================================================================================

/// Five stops for one material in one season.
///
/// ⛔ THE RAMP SLIDES TO FIT. IT IS NEVER CLAMPED AT ITS ENDS. The wing paid for this on Hearth's
/// limewash, whose top two stops both landed above the ceiling, were clamped to the same value,
/// and produced a bevel whose two brightest walls were IDENTICAL - which reads as a flat fill with
/// a line round it, not as a dome. SNOWBOUND IS THAT CASE AGAIN AND WORSE: its target lightness is
/// 0.885, so any material it pulls hard lands its top stops above the 0.975 ceiling, and a
/// snowfield whose lit and half-lit faces are the same colour has no drifts in it at all.
function mst_ground_ramp(_mat, _season, _t, _hue_shift) {
    var _s = mst_ground_seasoned(_mat, _season, _t);
    var _hs = is_undefined(_hue_shift) ? 0 : _hue_shift;

    var _floor = 0.055, _ceil = 0.975;
    var _span = min(_s.span, _ceil - _floor);
    var _lo = _s.L - _span * 0.5;
    var _hi = _s.L + _span * 0.5;
    if (_hi > _ceil) { _lo -= (_hi - _ceil); _hi = _ceil; }
    if (_lo < _floor) { _hi += (_floor - _lo); _lo = _floor; }
    // After both slides _hi can only exceed the ceiling if the span did not fit, which the min
    // above has already ruled out. Belt and braces, and cheap.
    _hi = min(_hi, _ceil);

    var _out = array_create(MST_RAMP_N);
    for (var _i = 0; _i < MST_RAMP_N; _i++) {
        var _u = _i / (MST_RAMP_N - 1);
        var _Li = _lo + (_hi - _lo) * _u;
        // Chroma falls in the shadows, as it does in life: the shadowed side of a bracken clump is
        // browner than its lit side, never a more saturated green.
        var _Ci = _s.C * (0.82 + 0.36 * _u);
        _out[_i] = mst_oklch(_Li, max(0, _Ci), _s.h + _hs);
    }
    return _out;
}

/// The role map that points mst_relief's m0..m4 at a named ramp in the palette.
///
/// Returned as a fresh struct every call rather than cached, because mst_map_roles reads it once
/// and a shared mutable map is the kind of thing that works until two features are built in the
/// same frame.
function mst_ground_map(_prefix) {
    return {
        m0: _prefix + "0", m1: _prefix + "1", m2: _prefix + "2",
        m3: _prefix + "3", m4: _prefix + "4",
    };
}

/// Write one material's five stops into a palette struct under a prefix.
function mst_ground_into(_pal, _prefix, _mat, _season, _t, _hue_shift) {
    var _r = mst_ground_ramp(_mat, _season, _t, _hue_shift);
    for (var _i = 0; _i < MST_RAMP_N; _i++) {
        variable_struct_set(_pal, _prefix + string(_i), _r[_i]);
    }
    return _pal;
}

/// ⛔ THE THING YOU WRITE ON A SURFACE IS NOT THE SURFACE'S DARKEST STOP.
///
/// The wing's Lexicon law, and it bites hard here because this corpus contains SNOW-COVERED TURF
/// at L 0.885 and BASALT at L 0.245 and marks both. A cell label set in m0 on snow is "merely less
/// pale" and vanishes; the same label in m0 on basalt is invisible for the opposite reason. An ink
/// is defined RELATIVE to its own ground and goes the other way from it, with an asserted floor on
/// the distance.
function mst_ground_ink(_mat, _season, _t) {
    var _s = mst_ground_seasoned(_mat, _season, _t);
    var _sep = 0.34;
    var _L = (_s.L > 0.5) ? max(0.045, _s.L - _sep) : min(0.965, _s.L + _sep);
    return mst_oklch(_L, _s.C * 0.55, _s.h);
}

/// How far a material's ink sits from its own mid stop, in Oklab lightness. Exists so the suite
/// can assert the separation instead of trusting the arithmetic above, and so a future material
/// added at an awkward lightness fires BY NAME.
function mst_ground_ink_sep(_mat, _season, _t) {
    var _s = mst_ground_seasoned(_mat, _season, _t);
    var _L = (_s.L > 0.5) ? max(0.045, _s.L - 0.34) : min(0.965, _s.L + 0.34);
    return abs(_L - _s.L);
}
