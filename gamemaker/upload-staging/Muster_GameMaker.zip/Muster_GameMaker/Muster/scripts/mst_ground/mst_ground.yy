{
  "$GMScript": "v1",
  "%Name": "mst_ground",
  "name": "mst_ground",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}