{
  "$GMScript": "v1",
  "%Name": "mst_geom",
  "name": "mst_geom",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}