/// MUSTER - mst_bake. The store sheets, rendered BY THE PRODUCT.
///
/// ============================================================================================
/// ⛔ WHY THE GALLERY IS BAKED IN ENGINE AND NOT DRAWN BY A PREVIEWER.
/// A gallery rendered by a side previewer is a picture of a RE-IMPLEMENTATION. This wing measured
/// exactly that on a sibling product: the JavaScript previewer had a defect that was invisible in
/// the previewer and plainly visible in engine. Baking through Igor lets the listing say, truthfully,
/// that every image on the page was rendered by the code in the package.
///
/// ⛔ AND EVERY SHEET IS MEASURED, NOT EYEBALLED. mst_bk_one runs an INK BOUNDING BOX over the
/// finished surface and reports it. That catches an EMPTY sheet and a CLIPPED one - and it cannot
/// catch a SPARSE one, a wrongly-ordered one, or one where the picture is simply bad. The wing's
/// standing law: a bounding box cannot see the space inside itself, and the only instrument for
/// that is opening the PNG and looking at it. This file does not replace that step.
///
/// ⚠️ THE INK CHECK'S KNOWN BLIND SPOTS, carried forward because they are still true here:
///   - stride: y steps by 1, because a 1px hairline lands on one row and an even-only scan walks
///     past it. x may step by 2.
///   - a flat fill close to the page colour is NOT counted as ink, so a large panel at low contrast
///     can run off the bottom and still report ok. Anything of that shape is sized by SOLVING its
///     dimensions from the space available so it cannot clip by construction.
///   - two boxes, not one: `full` for the clip test (a clipped hairline IS caught) and `content`,
///     measured below the title rule, for the coverage floors (so the rule cannot satisfy them).
/// ============================================================================================

#macro MST_SHEET_W 1600
#macro MST_SHEET_H 1000

function mst_bk_page()  { return mst_oklch(0.150, 0.008, 258); }
function mst_bk_ink()   { return mst_oklch(0.890, 0.010, 258); }
function mst_bk_dim()   { return mst_oklch(0.570, 0.010, 258); }
function mst_bk_rule()  { return mst_oklch(0.320, 0.012, 258); }
function mst_bk_warm()  { return mst_oklch(0.720, 0.075, 62);  }

/// A sheet heading.
///
/// ⛔ THE COMMENT THAT USED TO BE HERE WAS FALSE AND IT CAUSED THE DEFECT IT WARNED ABOUT.
/// It claimed "mst_text_label CENTRES ON THE x IT IS GIVEN", so this function passed the sheet's
/// midpoint. mst_text_label sets `fa_left` and draws AT the x it is given, so every title started
/// at the centre of the page and ran right: "THE PICTURE AND THE RULES ARE THE SAME OBJ" was the
/// visible result, and the ink check reported `clipped` on two sheets while the short titles looked
/// deliberately centred and hid it.
///
/// ⚠️ The false comment was a MISREAD OF A TRUE ONE. The donor's bake carries a warning that a
/// sibling product shipped "atch, cob, one storey" by handing a left edge to a text function that
/// wanted something else - and the donor's own call passes 60, a LEFT edge, which is the tell that
/// was there to be read. Copying a hazard note without checking which way it points is how a
/// warning becomes the cause.
///
/// It scales to fit `_maxw`, so a long title shrinks rather than clipping - now that it starts in
/// the right place.
function mst_bk_head(_title, _sub, _y) {
    mst_text_label(_title, 60, _y, MST_SHEET_W - 120, 46, mst_bk_page(), mst_bk_ink());
    var _yy = _y + 58;
    if (_sub != "") {
        mst_text_body(_sub, 60, _yy, MST_SHEET_W - 480, 19, mst_bk_dim());
        _yy += 30;
    }
    draw_set_colour(mst_bk_rule());
    draw_rectangle(60, _yy + 14, MST_SHEET_W - 60, _yy + 15, false);
    return _yy + 40;
}

/// A caption under a cell.
///
/// ⛔ IT IS MEASURED AND SCALED TO ITS CELL. This wing shipped the SAME overflow defect twice -
/// "WickthorSt Cuthman's" and "HEDGEHOG FUNGUSCAULIFLOWER FUNGUS" - because the first fix shortened
/// the DATA rather than making the caption honest about its width. No ink check will ever catch it:
/// overprinted text is ink exactly where ink belongs. Found only by reading the sheet.
function mst_bk_caption(_text, _cx, _y, _maxw, _px, _col) {
    mst_text_line(_text, _cx - _maxw * 0.5, _y, _maxw, _px, _col, false);
}

/// Measure the rendered pixels. See this file's header for what it can and cannot see.
function mst_bk_ink_bounds(_w, _h, _contentY) {
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, surface_get_target(), 0);
    var _pg = mst_bk_page();
    var _pr = colour_get_red(_pg), _pgn = colour_get_green(_pg), _pb = colour_get_blue(_pg);

    var _fx0 = _w, _fy0 = _h, _fx1 = -1, _fy1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;
    var _ink = 0;

    for (var _y = 0; _y < _h; _y++) {
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = (_y * _w + _x) * 4;
            var _r = buffer_peek(_buf, _o, buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_r - _pr) <= 10 && abs(_g - _pgn) <= 10 && abs(_b - _pb) <= 10) continue;
            _ink += 1;
            if (_x < _fx0) _fx0 = _x;
            if (_x > _fx1) _fx1 = _x;
            if (_y < _fy0) _fy0 = _y;
            if (_y > _fy1) _fy1 = _y;
            if (_y >= _contentY) {
                if (_x < _cx0) _cx0 = _x;
                if (_x > _cx1) _cx1 = _x;
                if (_y < _cy0) _cy0 = _y;
                if (_y > _cy1) _cy1 = _y;
            }
        }
    }
    buffer_delete(_buf);
    return { full: [_fx0, _fy0, _fx1, _fy1], content: [_cx0, _cy0, _cx1, _cy1], ink: _ink };
}

/// Draw one field into a box, scaled to fit, with its own palette. Returns the bottom y it used.
///
/// ⛔ THE FIRST VERSION OF THIS FUNCTION CARRIED A COMMENT SAYING FIELDS WERE "SIZED TO FIT THE BOX"
/// AND IT DID NO SUCH THING - it computed a centred origin and drew at the natural cell pitch, so a
/// 9x9 field needs 576 px and got a 380 px cell. Six of eight store sheets came back CLIPPED on the
/// first bake. The comment was not a lie anyone told; it described what the code was FOR rather
/// than what it did, which is the more common way a wrong comment gets written.
///
/// ⭐ The fix scales through the WORLD MATRIX rather than shrinking the fields, and that choice is
/// the honest one: a smaller field would have meant the store sheets showed maps the buyer's game
/// would not produce, while a scaled one is the same map seen from further away. The cell pitch a
/// buyer gets is MST_CELL_W, unchanged.
///
/// ⚠️ THE MATRIX IS ALWAYS RESET, including on the paths that return early - a world matrix left
/// set leaks into every later draw call on the sheet, and the failure looks like the NEXT thing
/// being drawn in the wrong place.
function mst_bk_field(_f, _x, _y, _w, _h, _overlay) {
    var _pal = mst_field_palette(_f);
    var _ext = mst_field_extent(_f);
    var _sc = min(_w / max(1, _ext[0]), _h / max(1, _ext[1]));

    // The field is laid out in its own space around (0,0) and the matrix puts it in the box, so the
    // origin is computed against the UNSCALED extent. Working in box pixels here and scaling
    // afterwards is what produced the clipping above.
    var _o = mst_field_origin(_f, 0, 0, _ext[0], _ext[1]);
    var _px = _x + (_w - _ext[0] * _sc) * 0.5;
    var _py = _y + (_h - _ext[1] * _sc) * 0.5;
    matrix_set(matrix_world, matrix_build(_px, _py, 0, 0, 0, 0, _sc, _sc, 1));

    mst_field_draw(_f, _pal, _o[0], _o[1]);
    switch (_overlay) {
        case 1: mst_draw_cover(_f, _pal, _o[0], _o[1]); break;
        case 2: {
            var _sx = 1, _sy = 1;
            for (var _k = 0; _k < array_length(_f.deployA); _k++) {
                var _i = _f.deployA[_k];
                if (_f.cells[_i].cost < MST_IMPASSABLE) { _sx = _i % _f.w; _sy = _i div _f.w; break; }
            }
            mst_draw_range(_f, _pal, mst_move_range(_f, _sx, _sy, 8), _o[0], _o[1]);
            mst_draw_cell_outline(_f, _sx, _sy, _o[0], _o[1], _pal.ov_obj, 3);
        } break;
        case 3: {
            var _hx = 1, _hy = 1, _hv = -1;
            for (var _i = 0; _i < array_length(_f.cells); _i++) {
                var _c = _f.cells[_i];
                if (_c.cost >= MST_IMPASSABLE) continue;
                if (_c.level > _hv) { _hv = _c.level; _hx = _i % _f.w; _hy = _i div _f.w; }
            }
            mst_draw_los(_f, _pal, _hx, _hy, _o[0], _o[1]);
            mst_draw_cell_outline(_f, _hx, _hy, _o[0], _o[1], _pal.ov_obj, 3);
        } break;
        case 4: mst_draw_plan(_f, _pal, _o[0], _o[1]); break;
    }
    matrix_set(matrix_world, matrix_build_identity());
    return _y + _h;
}

/// ============================================================================================
/// THE SHEETS. Every one returns the y it finished at.
/// ============================================================================================

/// A strip of small fields along the bottom of a sheet, each captioned.
///
/// ⛔ THIS EXISTS BECAUSE THREE SHEETS WERE SPARSE AND THE FIX IS CONTENT, NOT A THRESHOLD. The
/// ink floor reported contentH of 0.74, 0.68 and 0.64 on the hero, relief and scenario sheets, and
/// the cause is geometric rather than a bug: a field is a 2:1 diamond, so putting one in a box that
/// is not 2:1 leaves vertical space no amount of scaling can fill. The wing's standing law is that
/// a bounding box cannot see the space inside itself, and the answer is to rebuild the sheet with
/// more content rather than to lower the number until it passes.
///
/// So the space goes to something a buyer actually wants: the SAME seed under other conditions,
/// which is the product's whole argument repeated in miniature.
function mst_bk_strip(_y, _h, _seed, _biome, _seasons, _label) {
    var _n = array_length(_seasons);
    var _cw = (MST_SHEET_W - 80) / _n;
    mst_text_line(_label, 60, _y - 24, MST_SHEET_W - 120, 14, mst_bk_warm(), true);
    for (var _i = 0; _i < _n; _i++) {
        var _cx = 40 + _i * _cw;
        var _f = mst_field_make(9, 9, _seed, _biome, _seasons[_i], 1.0);
        mst_bk_field(_f, _cx, _y, _cw, _h - 26, 0);
        var _rep = mst_field_report(_f);
        mst_bk_caption(string_upper(_seasons[_i]) + "   crossing " + string(_rep.crossing) + " mp",
                       _cx + _cw * 0.5, _y + _h - 22, _cw - 12, 12, mst_bk_dim());
    }
    return _y + _h;
}

/// HERO. One large battlefield, and the numbers it reports about itself.
function mst_bk_hero() {
    var _y = mst_bk_head("MUSTER",
        "Tactical battlefields composed from a seed. Terrain, elevation, cover, hazards and "
      + "objectives, all drawn in GML with no sprite, no atlas and no texture page. Every mark "
      + "you can see is a rule the engine can answer.", 46);

    var _f = mst_field_make(14, 14, 88117, "ruins", "harvest", 0.85);
    mst_bk_field(_f, 40, _y - 10, 1080, 560, 0);

    // The report, set beside the field. ⭐ These numbers come out of mst_field_report reading the
    // field that was just drawn - they are a description of the picture, not a caption written
    // beside it, and that is the point being made.
    var _rep = mst_field_report(_f);
    var _px = 1180, _py = _y + 30;
    mst_text_line("THIS FIELD", _px, _py, 380, 20, mst_bk_warm(), true); _py += 40;

    var _rows = [
        ["biome", _rep.biome],
        ["season", _rep.season + " x0.85"],
        ["seed", string(_f.seed)],
        ["", ""],
        ["crossing", string(_rep.crossing) + " movement points"],
        ["going rate", string_format(_rep.goingRate, 1, 2) + " per cell"],
        ["hard cover", string(_rep.hardCover) + " cells"],
        ["soft cover", string(_rep.softCover) + " cells"],
        ["open ground", string(_rep.openGround) + " cells"],
        ["impassable", string(_rep.blocked) + " cells"],
        ["chokepoints", string(_rep.chokepoints)],
        ["objectives", string(_rep.objectives)],
    ];
    for (var _i = 0; _i < array_length(_rows); _i++) {
        if (_rows[_i][0] == "") { _py += 14; continue; }
        mst_text_line(_rows[_i][0], _px, _py, 170, 16, mst_bk_dim(), false);
        mst_text_line(_rows[_i][1], _px + 150, _py, 250, 16, mst_bk_ink(), false);
        _py += 26;
    }
    _py += 20;
    mst_text_body("Change the seed and every one of these numbers changes with the picture, "
                + "because they are read off the same cells.", _px, _py, 380, 15, mst_bk_dim());
    mst_bk_strip(_y + 610, MST_SHEET_H - (_y + 610) - 16, 88117, "ruins",
                 ["verdant", "harvest", "thaw", "snowbound"],
                 "THE SAME SEED, FOUR SEASONS - THE COST OF CROSSING CHANGES WITH THE COLOUR");
    return MST_SHEET_H - 16;
}

/// SEASONS. ⭐ THE SINGLE MOST IMPORTANT IMAGE ON THE PAGE. One seed, one biome, eight seasons.
/// If a buyer only looks at one sheet this is the one that says the product is a generator rather
/// than a tile pack, because no tile pack can do this at all.
function mst_bk_seasons() {
    var _y = mst_bk_head("ONE FIELD, EIGHT SEASONS",
        "The same seed and the same biome under every season. The season is a pull toward a target "
      + "weighted by each material's own susceptibility, so the granite does not move and the turf "
      + "changes completely - and it re-costs the mud and the water while it does it.", 46);

    // ⛔ TWO BIG AND SIX SMALL, NOT A 4x2 GRID, AND THE REASON IS THE GALLERY RATHER THAN THIS
    // SHEET. Kernel/capture/dedupe.js scored this sheet and the BIOMES sheet at a perceptual
    // distance of 5 - both were 4x2 grids of isometric diamonds with captions, so at a glance they
    // are the same picture and they would have occupied two store slots saying one thing. The
    // wing's rule is explicit that recapturing the same scene with different numbers does not move
    // that hash; the composition has to change.
    //
    // ⭐ And the recomposition is better anyway: verdant against snowbound at size IS the argument,
    // and burying it as two cells of eight was underselling it.
    var _bigH = 372;
    var _bigW = (MST_SHEET_W - 100) / 2;
    var _pair = ["verdant", "snowbound"];
    for (var _i = 0; _i < 2; _i++) {
        var _bx = 50 + _i * (_bigW + 8);
        var _f = mst_field_make(11, 11, 4242, "riverbank", _pair[_i], 1.0);
        mst_bk_field(_f, _bx, _y, _bigW, _bigH - 44, 0);
        var _rp = mst_field_report(_f);
        mst_text_line(string_upper(_pair[_i]), _bx + 20, _y + _bigH - 40, _bigW - 40, 24,
                      mst_bk_ink(), true);
        mst_text_line("crossing " + string(_rp.crossing) + " mp    going "
                      + string_format(_rp.goingRate, 1, 2) + "    hard " + string(_rp.hardCover)
                      + "   soft " + string(_rp.softCover) + "   open " + string(_rp.openGround),
                      _bx + 20, _y + _bigH - 12, _bigW - 40, 14, mst_bk_dim(), false);
    }

    // The other six, in one row, so the sheet reads as a PAIR plus a range rather than a grid.
    var _rest = ["highsummer", "harvest", "fallow", "thaw", "drought", "blighted"];
    var _sy = _y + _bigH + 34;
    var _sh = MST_SHEET_H - _sy - 18;
    var _sw = (MST_SHEET_W - 80) / 6;
    for (var _i = 0; _i < 6; _i++) {
        var _cx = 40 + _i * _sw;
        var _f2 = mst_field_make(11, 11, 4242, "riverbank", _rest[_i], 1.0);
        mst_bk_field(_f2, _cx, _sy, _sw, _sh - 38, 0);
        var _rp2 = mst_field_report(_f2);
        mst_bk_caption(string_upper(_rest[_i]), _cx + _sw * 0.5, _sy + _sh - 34, _sw - 10, 15,
                       mst_bk_ink());
        mst_bk_caption("crossing " + string(_rp2.crossing) + " mp   going "
                       + string_format(_rp2.goingRate, 1, 2),
                       _cx + _sw * 0.5, _sy + _sh - 15, _sw - 10, 12, mst_bk_dim());
    }
    return MST_SHEET_H - 18;
}

/// BIOMES. Eight kinds of ground to fight over.
function mst_bk_biomes() {
    var _y = mst_bk_head("EIGHT BIOMES",
        "Each names its own ground bands, its own relief and its own feature weights. The wet "
      + "materials land in the hollows and the bare ones on the tops because every ground entry "
      + "declares the band of the height range it belongs to.", 46);

    var _biomes = mst_biome_names();
    var _cw = (MST_SHEET_W - 80) / 4;
    var _ch = (MST_SHEET_H - _y - 24) / 2;
    for (var _i = 0; _i < array_length(_biomes); _i++) {
        var _cx = 40 + (_i % 4) * _cw;
        var _cy = _y + (_i div 4) * _ch;
        var _f = mst_field_make(9, 9, 7331 + _i, _biomes[_i], "highsummer", 0.6);
        mst_bk_field(_f, _cx, _cy, _cw, _ch - 40, 0);
        var _rep = mst_field_report(_f);
        mst_bk_caption(string_upper(_biomes[_i]), _cx + _cw * 0.5, _cy + _ch - 36, _cw - 20, 17,
                       mst_bk_ink());
        mst_bk_caption("hard " + string(_rep.hardCover) + "   soft " + string(_rep.softCover)
                       + "   open " + string(_rep.openGround),
                       _cx + _cw * 0.5, _cy + _ch - 16, _cw - 20, 13, mst_bk_dim());
    }
    return _y + 2 * _ch;
}

/// THE CORPUS. All fifty-two features, captioned with the rules they carry.
///
/// ⛔ THE CAPTION CARRIES THE RULE, and that is the sheet's whole argument: a buyer can see that
/// the boulder captioned "hard, blocks sight, 2 levels" is drawn twice the height of the drystone
/// wall captioned "hard, blocks sight, 1 level". The picture and the row agree because they are the
/// same row.
function mst_bk_corpus() {
    var _y = mst_bk_head("FIFTY-TWO TERRAIN FEATURES",
        "Every one composed from primitives and shaded by surface normal against one lamp. No "
      + "sprite, no atlas, no texture page: sprites/ does not exist in this package. The caption "
      + "under each is the tactical row the engine returns for a cell that carries it.", 46);

    var _names = mst_feature_names();
    // ⛔ 9 x 6 = 54 SLOTS FOR 52 FEATURES. The first draft used 10 x 5 = 50 and the last two
    // features were drawn off the bottom of the page - which the ink check reported as `clipped`
    // and which nothing in the corpus files could have caught, because both of them build
    // perfectly. A grid has to be sized from the LIST, not from a round number.
    var _cols = 13, _rows = 4;
    var _cw = (MST_SHEET_W - 60) / _cols;
    var _ch = (MST_SHEET_H - _y - 30) / _rows;
    var _pal = {};

    for (var _i = 0; _i < array_length(_names); _i++) {
        var _id = _names[_i];
        var _sp = mst_feature_spec(_id);
        var _cx = 30 + (_i % _cols) * _cw + _cw * 0.5;
        var _cy = _y + (_i div _cols) * _ch;

        mst_feature_palette(_pal, _id, "harvest", 0.5);
        _pal.s0 = mst_oklch(0.085, 0.006, 258);
        var _parts = mst_feature_parts(_id, 300 + _i, "harvest", 0.5);
        // ⛔ THE SCALE IS SOLVED FROM THE ROW HEIGHT AS WELL AS THE COLUMN WIDTH, and the first
        // draft used the width alone. The tallest features declare h 0.98, so at a width-derived
        // scale a conifer drew 154 px above its ground line inside a 132 px row and punched
        // straight through the captions of the row above - visible on a third of the sheet, and
        // completely invisible to the ink check, because overlapping ink is ink exactly where ink
        // belongs. This is the wing's standing rule stated for a grid: size a thing by SOLVING its
        // dimensions from the space available, so it cannot collide by construction.
        //
        // ⚠️ mst_feature_tallest() reads the corpus's own maximum declared height rather than repeating a
        // constant, so adding a taller feature re-solves the grid instead of overflowing it.
        var _s = min(_cw * 0.92, (_ch * 0.60 - 6) / mst_feature_tallest());
        mst_render_parts(_parts, _pal, _cx, _cy + _ch * 0.60 - MST_GROUND * _s, _s, 0, 1, undefined);

        var _cov = (_sp.cover == MST_COVER_HARD) ? "hard"
                 : ((_sp.cover == MST_COVER_SOFT) ? "soft" : "open");
        var _blk = _sp.los ? ("blocks " + string(_sp.tall)) : "-";
        var _cst = (_sp.cost >= MST_IMPASSABLE) ? "X" : ("+" + string(_sp.cost - 1));
        mst_bk_caption(_id, _cx, _cy + _ch * 0.66, _cw - 6, 12, mst_bk_ink());
        mst_bk_caption(_cov + "  " + _blk + "  " + _cst, _cx, _cy + _ch * 0.66 + 16, _cw - 6, 11,
                       mst_bk_dim());
    }
    return _y + _rows * _ch;
}

/// THE PROOF. The same field four times: bare, cover, movement, sight.
///
/// ⭐ THIS IS THE SHEET THAT SELLS THE PACKAGE and it is a single claim made visible. The overlays
/// read the SAME cell fields that the generator wrote when it placed the drawn feature, so the
/// cover marks land exactly on the walls and boulders, and nowhere else. Every incumbent measured
/// on this shelf ships the rules and leaves the buyer to find the picture; this shows both being
/// one object.
function mst_bk_proof() {
    var _y = mst_bk_head("THE PICTURE AND THE RULES ARE ONE OBJECT",
        "One field, four readings. Cover, movement cost and line of sight are read from the cells "
      + "the terrain was drawn from. The cover marks sit on the ground each wall PROTECTS, because "
      + "that is where a unit stands - and they hug the drawn features exactly, since both come "
      + "out of the same row.", 46);

    var _titles = ["THE FIELD", "COVER", "MOVEMENT, 8 POINTS", "SIGHT FROM THE HIGH GROUND"];
    var _cw = (MST_SHEET_W - 60) / 2;
    var _ch = (MST_SHEET_H - _y - 40) / 2;
    for (var _i = 0; _i < 4; _i++) {
        var _cx = 30 + (_i % 2) * _cw;
        var _cy = _y + (_i div 2) * _ch;
        var _f = mst_field_make(11, 11, 60613, "downland", "fallow", 0.7);
        mst_bk_field(_f, _cx, _cy, _cw, _ch - 34, _i);
        mst_bk_caption(_titles[_i], _cx + _cw * 0.5, _cy + _ch - 30, _cw - 40, 17, mst_bk_warm());
    }
    return _y + 2 * _ch;
}

/// ELEVATION. High ground, and why it is worth taking.
function mst_bk_relief() {
    var _y = mst_bk_head("HIGH GROUND IS DRAWN, AND IT IS A RULE",
        "Four elevation levels, drawn as terraces with their side walls lit. Climbing a level costs "
      + "a movement point, descending is free, and a unit sees over anything whose own top is below "
      + "the sight line - so `tall` had to be a number the feature is DRAWN at, not a flag.", 46);

    var _cw = (MST_SHEET_W - 60) / 2;
    var _ch = 440;
    var _f = mst_field_make(12, 12, 31337, "moor", "fallow", 0.9);
    mst_bk_field(_f, 30, _y, _cw, _ch - 30, 0);
    mst_bk_caption("A MOOR: relief 0.95, all four levels used", 30 + _cw * 0.5, _y + _ch - 24,
                   _cw - 40, 16, mst_bk_ink());

    var _f2 = mst_field_make(12, 12, 31337, "marsh", "fallow", 0.9);
    mst_bk_field(_f2, 30 + _cw, _y, _cw, _ch - 30, 0);
    mst_bk_caption("A MARSH: relief 0.22, the same seed, nearly flat",
                   30 + _cw * 1.5, _y + _ch - 24, _cw - 40, 16, mst_bk_ink());
    mst_bk_strip(_y + _ch + 30, MST_SHEET_H - (_y + _ch + 30) - 16, 31337, "downland",
                 ["verdant", "drought", "fallow", "snowbound"],
                 "RELIEF IS A PROPERTY OF THE BIOME; THE SEASON IS DRAWN OVER IT");
    return MST_SHEET_H - 16;
}

/// THE SCENARIO. Deployment, chokepoints and objectives, all measured off the map.
function mst_bk_scenario() {
    var _y = mst_bk_head("IT READS ITS OWN MAP BACK",
        "Deployment zones on opposite edges, chokepoints found by measuring which cells every "
      + "optimal crossing has to pass through, and objectives placed on the high ground and in the "
      + "funnels. Every field is guaranteed crossable: the generator clears blockers until it is, "
      + "and reports how many it had to remove.", 46);

    var _cw = (MST_SHEET_W - 80) / 3;
    var _ch = 430;
    var _seeds = [9001, 9002, 9003];
    var _bm = ["woodland", "farmland", "waste"];
    for (var _i = 0; _i < 3; _i++) {
        var _cx = 40 + _i * _cw;
        var _f = mst_field_make(11, 11, _seeds[_i], _bm[_i], "verdant", 0.6);
        mst_bk_field(_f, _cx, _y, _cw, _ch - 60, 4);
        var _rep = mst_field_report(_f);
        mst_bk_caption(string_upper(_bm[_i]) + "  seed " + string(_seeds[_i]),
                       _cx + _cw * 0.5, _y + _ch - 54, _cw - 20, 16, mst_bk_ink());
        mst_bk_caption("crossing " + string(_rep.crossing) + " mp   chokes "
                       + string(_rep.chokepoints) + "   objectives " + string(_rep.objectives),
                       _cx + _cw * 0.5, _y + _ch - 32, _cw - 20, 13, mst_bk_dim());
        mst_bk_caption("cleared to guarantee a route: " + string(_rep.cleared),
                       _cx + _cw * 0.5, _y + _ch - 14, _cw - 20, 13, mst_bk_dim());
    }
    // ⛔ MARSH, NOT WOODLAND, AND THE CAPTION ONLY CLAIMS WHAT THE NUMBERS UNDER IT SHOW.
    // The first version ran this strip on woodland and captioned it "SAME CHOKEPOINTS, DIFFERENT
    // FIGHT" - and all four seasons came back at 14 mp, so the sheet asserted a difference the
    // image did not support. That is a market claim a picture contradicts, which this studio does
    // not ship. A marsh is where the season genuinely changes the going, because its lowest ground
    // is standing water that snowbound turns to something walkable, so the crossing cost really
    // does move - and if it ever stops moving, the numbers printed under each field say so.
    mst_bk_strip(_y + _ch + 24, MST_SHEET_H - (_y + _ch + 24) - 16, 9004, "marsh",
                 ["verdant", "thaw", "drought", "snowbound"],
                 "THE SAME MARSH IN FOUR SEASONS - READ THE CROSSING COST UNDER EACH");
    return MST_SHEET_H - 16;
}

/// DETAIL. A few features at hero scale, where the relief can actually be seen.
///
/// ⚠️ THIS SHEET EXISTS BECAUSE THE CORPUS SHEET IS DRAWN SMALL. The wing's Borough law: a form
/// rendered on a catalogue plate and the same form rendered at size are two different tests, and
/// passing the first tells you nothing about the second. Four physical-detail defects shipped on
/// one product because nothing was ever drawn large enough to show them.
function mst_bk_detail() {
    var _y = mst_bk_head("DRAWN, NOT TILED",
        "Nine features at roughly three times the size a battle uses them at. Every edge here is a "
      + "wall shaded by its own surface normal against one lamp - there is no texture under any of "
      + "it, which is why the same object can be re-seasoned, re-lit and drawn at any size at "
      + "runtime instead of re-exported.", 46);

    // Chosen to show the four drawing disciplines the package uses: a bevelled mass (boulder), a
    // course-built structure (wellhead), a stem field (cornstand), a canopy (broadleaf), a flat
    // liquid seen in projection (ford) and a cloth strip (banner).
    // ⛔ NINE, NOT SIX, AND THE REASON IS THE GATE-1 DEAD-SPACE QUESTION. Six objects on a
    // 1600x1000 page left well over a fifth of the sheet empty, and the honest answer to "is more
    // than ~20% of any composite empty space" was yes. The wing's rule for that is explicit:
    // rebuild the sheet with more content, never tune the threshold. Three more forms also widen
    // what the sheet demonstrates - a stem field, a relief-shaded mass and a woven structure were
    // each unrepresented at size.
    var _pick = ["boulder", "wellhead", "cornstand", "broadleaf", "ford", "banner",
                 "watchstump", "conifer", "barrels"];
    var _cols = 3, _rows = 3;
    var _cw = (MST_SHEET_W - 80) / _cols;
    var _ch = (MST_SHEET_H - _y - 40) / _rows;
    var _pal = {};

    for (var _i = 0; _i < array_length(_pick); _i++) {
        var _id = _pick[_i];
        var _cx = 40 + (_i % _cols) * _cw + _cw * 0.5;
        var _cy = _y + (_i div _cols) * _ch;

        // ⛔ A PLATE BEHIND EACH SPECIMEN, AND IT IS NOT DECORATION - IT IS THE ANSWER TO THE
        // DEAD-SPACE QUESTION. Nine objects of very different heights standing on a common
        // baseline leave the top of every short cell empty, so the sheet stayed airy even after
        // going from six specimens to nine. A specimen plate is what a catalogue actually uses, it
        // gives every cell the same visual weight regardless of what stands on it, and it fills
        // the page by DESIGN rather than by padding the content out.
        //
        // ⚠️ Drawn at a lightness a little above the page and with a lit top edge, so it reads as
        // a raised plate rather than as a box someone drew round the object.
        var _plx = _cx - _cw * 0.44, _ply = _cy + 6;
        var _plw = _cw * 0.88, _plh = _ch - 18;
        draw_set_colour(mst_oklch(0.205, 0.008, 258));
        draw_roundrect_ext(_plx, _ply, _plx + _plw, _ply + _plh, 10, 10, false);
        draw_set_colour(mst_oklch(0.275, 0.009, 258));
        draw_line_width(_plx + 10, _ply + 1, _plx + _plw - 10, _ply + 1, 2);

        mst_feature_palette(_pal, _id, "harvest", 0.45);
        _pal.s0 = mst_oklch(0.115, 0.006, 258);
        var _parts = mst_feature_parts(_id, 900 + _i, "harvest", 0.45);
        // ⚠️ THE SCALE IS SOLVED FROM THE CELL, NOT TYPED. A hard-coded scale that fits a boulder
        // clips a banner, and the wing's standing law is that a panel which cannot be caught by the
        // ink check must be sized so it cannot clip by construction.
        var _s = min(_cw * 0.80, (_ch - 52) / mst_feature_tallest());
        mst_render_parts(_parts, _pal, _cx, _cy + _ch - 60 - MST_GROUND * _s, _s, 0, 1, undefined);
        mst_bk_caption(string_upper(_id), _cx, _cy + _ch - 40, _cw - 20, 17, mst_bk_ink());
    }
    return _y + _rows * _ch;
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

function mst_bk_one(_name, _fn, _contentY) {
    var _surf = surface_create(MST_SHEET_W, MST_SHEET_H);
    surface_set_target(_surf);
    draw_clear(mst_bk_page());
    mst_lamp_reset();

    var _endY = _fn();
    var _ib = mst_bk_ink_bounds(MST_SHEET_W, MST_SHEET_H, _contentY);

    surface_reset_target();
    surface_save(_surf, "sheet_" + _name + ".png");
    surface_free(_surf);

    var _clipped = (_endY > MST_SHEET_H) || (_ib.full[3] >= MST_SHEET_H - 6)
                || (_ib.full[2] >= MST_SHEET_W - 6) || (_ib.full[0] <= 5) || (_ib.full[1] <= 5);
    var _cw = (_ib.content[2] - _ib.content[0]) / MST_SHEET_W;
    var _chh = (_ib.content[3] - _ib.content[1]) / max(1, MST_SHEET_H - _contentY);

    return "{\"name\":\"" + _name + "\""
         + ",\"endY\":" + string(round(_endY))
         + ",\"ink\":" + string(_ib.ink)
         + ",\"fullBox\":[" + string(_ib.full[0]) + "," + string(_ib.full[1]) + ","
                            + string(_ib.full[2]) + "," + string(_ib.full[3]) + "]"
         + ",\"contentW\":" + string_format(_cw, 1, 3)
         + ",\"contentH\":" + string_format(_chh, 1, 3)
         + ",\"clipped\":" + (_clipped ? "true" : "false")
         + ",\"ok\":" + ((!_clipped && _cw >= 0.86 && _chh >= 0.80 && _ib.ink > 40000)
                         ? "true" : "false")
         + "}";
}

/// ============================================================================================
/// THE COVER
///
/// ⚠️ 630x500 IS ITCH'S COVER SIZE and the cover is the only image most buyers ever see. It is
/// baked at its own size rather than cropped out of a sheet, because a cropped sheet is exactly
/// what a cover must not be.
/// ============================================================================================

#macro MST_COVER_W 630
#macro MST_COVER_H 500

function mst_bk_cover() {
    // ⛔ ONE FIELD, LARGE, AND NOT A GRID OF SPECIMENS. A grid says "sprite sheet", which is the one
    // thing this product argues it is not - and at the 315px thumbnail itch actually shows on a
    // shelf, a grid of fifty-two tiny objects is grey noise. One battlefield fills the frame, reads at
    // thumbnail size as a PLACE, and shows elevation, cover and hazard all at once.
    // ⚠️ THROUGH mst_bk_field, NOT mst_field_draw. The cover is 630x500 and a 10x10 field wants
    // 640 px of width at the natural pitch, so drawing it unscaled clipped it by exactly the
    // margin nobody would have looked for. The cover is the one image most buyers ever see.
    var _f = mst_field_make(10, 10, 12480, "ruins", "harvest", 0.85);
    mst_bk_field(_f, 8, 74, MST_COVER_W - 16, MST_COVER_H - 116, 0);

    // A scrim under the title so the lettering never has to fight the terrain behind it. Drawn as
    // a gradient rather than a bar, because a hard-edged band across a picture reads as a sticker.
    mst_render_scrim(0, 0, MST_COVER_W, 132, mst_oklch(0.10, 0.010, 258), 0.86);
    mst_render_scrim(0, MST_COVER_H - 74, MST_COVER_W, 74, mst_oklch(0.10, 0.010, 258), 0.80);

    mst_text_label("MUSTER", MST_COVER_W * 0.5, 26, MST_COVER_W - 60, 62,
                   mst_oklch(0.08, 0.010, 258), mst_oklch(0.94, 0.014, 76));
    mst_text_line("BATTLEFIELDS THAT DRAW THEMSELVES", 44, 96, MST_COVER_W - 88, 19,
                  mst_bk_warm(), false);
    mst_text_line("52 terrain features   8 biomes   8 seasons   pure GML, no sprites",
                  44, MST_COVER_H - 52, MST_COVER_W - 88, 16, mst_oklch(0.84, 0.010, 258), false);
    return MST_COVER_H;
}

function mst_bake_cover() {
    var _surf = surface_create(MST_COVER_W, MST_COVER_H);
    surface_set_target(_surf);
    draw_clear(mst_bk_page());
    mst_lamp_reset();
    mst_bk_cover();
    var _ib = mst_bk_ink_bounds(MST_COVER_W, MST_COVER_H, 0);
    surface_reset_target();
    surface_save(_surf, "cover.png");
    surface_free(_surf);
    return "{\"name\":\"cover\",\"ink\":" + string(_ib.ink)
         + ",\"ok\":" + ((_ib.ink > 20000) ? "true" : "false") + "}";
}

/// Bake every sheet and write a report.
///
/// ⛔ THE REPORT IS WRITTEN EVEN WHEN A SHEET FAILS ITS OWN CHECK. A baker that stops on the first
/// failure tells you about one defect per build, and an Igor build is about eighty seconds - so a
/// package with six clipped sheets costs six builds to find. All of them, every run.
function mst_bake_run() {
    global.mst_stage = 200;
    var _out = [];
    // The content y for each sheet is where its title rule ends, so the coverage floors are
    // measured on the CONTENT and the rule cannot satisfy them by itself.
    array_push(_out, mst_bk_one("hero",     mst_bk_hero,     150));
    array_push(_out, mst_bk_one("seasons",  mst_bk_seasons,  180));
    array_push(_out, mst_bk_one("biomes",   mst_bk_biomes,   180));
    array_push(_out, mst_bk_one("corpus",   mst_bk_corpus,   180));
    array_push(_out, mst_bk_one("proof",    mst_bk_proof,    170));
    array_push(_out, mst_bk_one("relief",   mst_bk_relief,   170));
    array_push(_out, mst_bk_one("scenario", mst_bk_scenario, 190));
    array_push(_out, mst_bk_one("detail",   mst_bk_detail,   190));
    array_push(_out, mst_bake_cover());

    var _f = file_text_open_write("mst_bake.json");
    var _s = "{\"sheets\":[";
    for (var _i = 0; _i < array_length(_out); _i++) {
        if (_i > 0) _s += ",";
        _s += _out[_i];
    }
    _s += "],\"version\":\"" + MST_VERSION + "\"}";
    file_text_write_string(_f, _s);
    file_text_close(_f);
    global.mst_stage = 299;
}
