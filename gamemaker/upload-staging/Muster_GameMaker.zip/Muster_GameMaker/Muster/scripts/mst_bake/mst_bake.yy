{
  "$GMScript": "v1",
  "%Name": "mst_bake",
  "name": "mst_bake",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}