/// MUSTER - mst_built. The seventeen features people leave on a field.
///
/// ruinwall, drystone, palisade, gabion, rampart, cheval, hurdle, cart, crates, barrels, haybale,
/// logpile, wellhead, shrine, tomb, watchstump, gatepost.
///
/// -- THESE ARE THE FEATURES THAT DECIDE A FIGHT -----------------------------------------------
/// A boulder is where it is. A wall is where somebody PUT it, which means a built feature is the
/// one a level designer reaches for when they want a chokepoint, a firing line or a courtyard. So
/// this file carries most of the corpus's HARD COVER, and every one of those is drawn tall enough
/// that a player can see it is hard cover without being told.
///
/// ⛔ AND THE HEIGHTS HERE ARE LOAD-BEARING, NOT DECORATIVE. A drystone wall is `tall: 1` and is
/// drawn to about a third of the cell; a palisade is `tall: 2` and is drawn to two thirds. If those
/// two were drawn the same height the RULES would still differ and the picture would be lying, so
/// mst_selftest asserts drawn height against the spec's `tall` for all fifty-two features rather than
/// trusting the builders to have been careful.
/// ============================================================================================

/// One course of dressed masonry: blocks of varied length with the joints staggered against the
/// course below.
///
/// ⚠️ THE STAGGER IS THE WHOLE POINT AND IT IS WHY THIS TAKES A PHASE. Aligned joints read as a
/// grid drawn on a rectangle - the single loudest tell of a wall built with a for-loop. Real
/// masonry breaks its joints because an aligned joint is a crack waiting to happen, and a buyer
/// who has ever looked at a wall knows this without being able to say why the picture is wrong.
function mst_course(_x0, _x1, _y0, _y1, _phase, _blocks, _rng) {
    var _out = [];
    var _n = max(2, _blocks);
    var _w = (_x1 - _x0) / _n;
    var _joint = min(_w, _y1 - _y0) * 0.10;
    var _cx = _x0 - _w * frac(abs(_phase));
    while (_cx < _x1) {
        var _bw = _w * (0.72 + mst_rng_next(_rng) * 0.56);
        var _l = max(_x0, _cx + _joint * 0.5);
        var _r = min(_x1, _cx + _bw - _joint * 0.5);
        if (_r - _l > _joint) {
            var _blk = [[_l, _y0 + _joint * 0.5], [_r, _y0 + _joint * 0.5],
                        [_r, _y1 - _joint * 0.5], [_l, _y1 - _joint * 0.5]];
            mst_append(_out, mst_raise(_blk, mst_bevel_cap(_blk, _joint * 1.6), 2, "m2"));
        }
        _cx += _bw;
    }
    return _out;
}

/// A squared timber: a post, a beam, a plank, a stake. Bevelled on its own outline so the four
/// arrises catch the lamp.
function mst_timber(_x0, _y0, _x1, _y1, _rng) {
    var _pts = [[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]];
    var _out = mst_raise(_pts, mst_bevel_cap(_pts, min(abs(_x1 - _x0), abs(_y1 - _y0)) * 0.22), 2, "m2");
    // Grain. Two or three lines along the LONG axis, never across it - grain across a beam is a
    // tell that the shape was drawn before anyone asked which way the tree grew.
    var _vert = abs(_y1 - _y0) > abs(_x1 - _x0);
    var _n = 2;
    for (var _i = 0; _i < _n; _i++) {
        var _u = 0.32 + _i * 0.34 + mst_rng_next(_rng) * 0.10;
        if (_vert) {
            var _gx = lerp(_x0, _x1, _u);
            mst_append(_out, mst_incise([[_gx, _y0 + (_y1 - _y0) * 0.10],
                                         [_gx, _y0 + (_y1 - _y0) * 0.90]],
                                        false, abs(_x1 - _x0) * 0.09));
        } else {
            var _gy = lerp(_y0, _y1, _u);
            mst_append(_out, mst_incise([[_x0 + (_x1 - _x0) * 0.10, _gy],
                                         [_x0 + (_x1 - _x0) * 0.90, _gy]],
                                        false, abs(_y1 - _y0) * 0.09));
        }
    }
    return _out;
}

/// An iron band or strap across a timber: a raised line with a rivet at each end.
function mst_strap(_x0, _y, _x1, _w) {
    var _out = mst_ridge([[_x0, _y], [_x1, _y]], false, _w);
    mst_append(_out, mst_boss(_x0 + _w * 0.9, _y, _w * 0.62, 8));
    mst_append(_out, mst_boss(_x1 - _w * 0.9, _y, _w * 0.62, 8));
    return _out;
}

function mst_built_parts(_id, _sp, _rng, _season, _t) {
    var _out = [];
    var _g = MST_GROUND;
    var _x0 = -_sp.w * 0.5, _x1 = _sp.w * 0.5;
    var _top = _g - _sp.h;

    switch (_id) {
        case "ruinwall": {
            // The subject of a ruin is the BREAK, not the wall. A rectangle with a bite out of it
            // reads as damage; a wall whose top edge steps down course by course reads as one that
            // fell over a century. So the height profile is authored per column.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.52));
            var _cols = 7;
            var _prof = array_create(_cols);
            var _peak = 0.30 + mst_rng_next(_rng) * 0.34;
            for (var _i = 0; _i < _cols; _i++) {
                var _u = _i / (_cols - 1);
                // A ruin is tallest where it was buttressed. One peak, falling off both ways, with
                // a jagged tooth on top so no two columns end level.
                var _fall = 1 - abs(_u - _peak) * (1.35 + mst_rng_next(_rng) * 0.5);
                _prof[_i] = clamp(_fall, 0.22, 1) * (0.86 + mst_rng_next(_rng) * 0.14);
            }
            var _courses = 5;
            var _body = [];
            for (var _c = 0; _c < _courses; _c++) {
                var _cy1 = _g - _sp.h * (_c / _courses);
                var _cy0 = _g - _sp.h * ((_c + 1) / _courses);
                // Each course only exists where the profile still reaches it.
                for (var _i = 0; _i < _cols; _i++) {
                    if (_prof[_i] * _courses <= _c) continue;
                    var _cl = lerp(_x0, _x1, _i / _cols);
                    var _cr = lerp(_x0, _x1, (_i + 1) / _cols);
                    mst_append(_body, mst_course(_cl, _cr, _cy0, _cy1, _c * 0.5 + _i * 0.31, 2, _rng));
                }
            }
            mst_append(_out, mst_map_roles(_body, mst_ground_map("a")));
            // The rubble core shows through where the facing has gone.
            var _core = [];
            for (var _i = 0; _i < 8; _i++) {
                var _px = lerp(_x0, _x1, mst_rng_next(_rng));
                var _pr = _sp.w * (0.020 + mst_rng_next(_rng) * 0.024);
                mst_append(_core, mst_ring_fill(
                    mst_pool_pts(_px, _g - _sp.h * (0.10 + mst_rng_next(_rng) * 0.55),
                                 _pr, _pr * 0.8, 8, 0.28, _rng), "m2", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_core, mst_ground_map("b")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(0, _g - _sp.h * 0.16, _sp.w * 0.44, _sp.h * 0.14, 4, _rng),
                mst_ground_map("c")));
        } break;

        case "drystone": {
            // No mortar, so the stones are ROUNDED field stone and the joints are wide and
            // irregular. Drawing this with the dressed-block helper would give a Roman wall.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.52));
            var _body = [];
            var _rows = 4;
            for (var _r = 0; _r < _rows; _r++) {
                var _u = _r / _rows;
                var _ry = _sp.h * 0.5 / _rows;
                var _cy = _g - _sp.h * _u - _ry;
                // A drystone wall BATTERS: it narrows as it rises, which is how it stands up.
                var _inset = _sp.w * 0.06 * _u;
                var _cx = _x0 + _inset;
                while (_cx < _x1 - _inset) {
                    var _sw = _sp.w * (0.075 + mst_rng_next(_rng) * 0.075);
                    var _sr = min(_cx + _sw, _x1 - _inset);
                    mst_append(_body, mst_raise(
                        mst_lump_pts((_cx + _sr) * 0.5, _cy, (_sr - _cx) * 0.46, _ry * 0.86,
                                     9, 0.13, 0.20, _rng),
                        _ry * 0.34, 2, "m2"));
                    _cx = _sr;
                }
            }
            // A course of through-stones on top, set on edge. Every real drystone wall has them and
            // they are the detail that says "built", not "piled".
            var _cap = [];
            var _capn = 9;
            for (var _i = 0; _i < _capn; _i++) {
                var _cl = lerp(_x0 + _sp.w * 0.05, _x1 - _sp.w * 0.05, _i / _capn);
                var _cr = lerp(_x0 + _sp.w * 0.05, _x1 - _sp.w * 0.05, (_i + 0.86) / _capn);
                var _hh = _sp.h * (0.16 + mst_rng_next(_rng) * 0.06);
                var _cy2 = _g - _sp.h * 0.5;
                var _blk = [[_cl, _cy2 - _hh], [_cr, _cy2 - _hh * 0.86], [_cr, _cy2], [_cl, _cy2]];
                mst_append(_cap, mst_raise(_blk, mst_bevel_cap(_blk, _hh * 0.26), 2, "m2"));
            }
            mst_append(_out, mst_map_roles(_body, mst_ground_map("a")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(0, _g - _sp.h * 0.16, _sp.w * 0.46, _sp.h * 0.16, 5, _rng),
                mst_ground_map("b")));
            mst_append(_out, mst_map_roles(_cap, mst_ground_map("c")));
        } break;

        case "palisade": {
            // Split stakes, points up, driven into a bank and lashed with a rail. The POINTS are
            // what make it read as defensive rather than as a fence.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.52));
            var _bank = mst_bank_pts(_x0, _x1, _g, _sp.h * 0.16, 1.0, 10, _rng);
            mst_append(_out, mst_map_roles(
                mst_raise(_bank, _sp.h * 0.05, 2, "m2"), mst_ground_map("c")));
            var _stakes = [];
            var _n = 9;
            for (var _i = 0; _i < _n; _i++) {
                var _sx = lerp(_x0 + _sp.w * 0.05, _x1 - _sp.w * 0.05, _i / (_n - 1));
                var _sw = _sp.w * 0.072;
                var _sh = _sp.h * (0.80 + mst_rng_next(_rng) * 0.20);
                var _sy = _g - _sh;
                // ⛔ THE POINT IS A CLOSURE ON THE WIDTH, NOT A SWEEP ACROSS THE OUTLINE. The wing
                // paid for the other version on six of eighteen blades, which grew a needle
                // standing off the tip. Here the shaft simply narrows to a small flat.
                var _pts = mst_shaft_pts(_sx, _g - _sp.h * 0.10, _sy, _sw, _sw * 0.16,
                                         (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.012, 4);
                mst_append(_stakes, mst_raise(_pts, mst_bevel_cap(_pts, _sw * 0.30), 2, "m2"));
            }
            mst_append(_out, mst_map_roles(_stakes, mst_ground_map("a")));
            // The lashing rail, behind the stakes' tops.
            var _ry2 = _g - _sp.h * 0.58;
            mst_append(_out, mst_map_roles(
                mst_strap(_x0 + _sp.w * 0.05, _ry2, _x1 - _sp.w * 0.05, _sp.h * 0.035),
                mst_ground_map("b")));
        } break;

        case "gabion": {
            // A wicker basket packed with earth. The WEAVE is the subject: a cylinder with a
            // crosshatch on it reads as a barrel, so the horizontal withies must visibly BOW around
            // the body.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.50));
            var _bw = _sp.w * 0.5, _bh = _sp.h;
            var _body = mst_shaft_pts(0, _g, _top, _sp.w * 0.94, _sp.w * 1.0, 0, 3);
            mst_append(_out, mst_map_roles(
                mst_raise(_body, mst_bevel_cap(_body, _bw * 0.18), 3, "m2"), mst_ground_map("a")));
            var _weave = [];
            var _rows = 5;
            for (var _r = 0; _r < _rows; _r++) {
                var _wy = _g - _bh * ((_r + 0.5) / _rows);
                var _pts = [];
                for (var _k = 0; _k <= 8; _k++) {
                    var _u = _k / 8;
                    // The bow: a withy on the near face of a cylinder sags toward the viewer.
                    _pts[_k] = [lerp(-_bw * 0.96, _bw * 0.96, _u),
                                _wy + sin(pi * _u) * _bh * 0.030];
                }
                mst_append(_weave, mst_ridge(_pts, false, _bh * 0.036));
            }
            // Uprights, fewer and thinner, showing between the courses.
            for (var _k = 0; _k < 4; _k++) {
                var _ux = lerp(-_bw * 0.70, _bw * 0.70, _k / 3);
                mst_append(_weave, mst_incise([[_ux, _g - _bh * 0.94], [_ux, _g - _bh * 0.06]],
                                              false, _bh * 0.028));
            }
            mst_append(_out, mst_map_roles(_weave, mst_ground_map("a")));
            // Earth heaped proud of the rim.
            var _fill = mst_lump_pts(0, _top + _sp.h * 0.06, _bw * 0.92, _sp.h * 0.11, 11, 0.16, 0, _rng);
            mst_append(_out, mst_map_roles(
                mst_raise(_fill, _sp.h * 0.035, 2, "m2"), mst_ground_map("b")));
        } break;

        case "rampart": {
            // Earth thrown up into a bank, turfed on the weather side and revetted with hurdle at
            // the top. Soft cover you can stand ON rather than behind, which is why its cost is 2
            // and not impassable.
            var _bank = mst_bank_pts(_x0, _x1, _g, _sp.h, 1.15, 14, _rng);
            mst_append(_out, mst_map_roles(
                mst_raise(_bank, mst_bevel_cap(_bank, _sp.h * 0.28), 3, "m2"), mst_ground_map("a")));
            // Turf laid in courses up the face. Each course is a shallow lens, not a stripe.
            var _turf = [];
            for (var _r = 0; _r < 3; _r++) {
                var _u = (_r + 1) / 4;
                var _pts = [];
                for (var _k = 0; _k <= 10; _k++) {
                    var _uu = _k / 10;
                    var _p = clamp(sin(pi * _uu) * 1.15, 0, 1);
                    _pts[_k] = [lerp(_x0, _x1, _uu), _g - _sp.h * _p * _u];
                }
                mst_append(_turf, mst_incise(_pts, false, _sp.h * 0.045));
            }
            mst_append(_out, mst_map_roles(_turf, mst_ground_map("b")));
            // Revetment stakes along the crest.
            var _rev = [];
            for (var _k = 0; _k < 6; _k++) {
                var _u = 0.20 + _k * 0.12;
                var _p = clamp(sin(pi * _u) * 1.15, 0, 1);
                var _ry3 = _g - _sp.h * _p;
                var _rx3 = lerp(_x0, _x1, _u);
                mst_append(_rev, mst_timber(_rx3 - _sp.w * 0.012, _ry3 - _sp.h * 0.30,
                                            _rx3 + _sp.w * 0.012, _ry3, _rng));
            }
            mst_append(_out, mst_map_roles(_rev, mst_ground_map("c")));
        } break;

        case "cheval": {
            // Crossed stakes lashed at the middle. Reads instantly as "you may not walk here",
            // which is why it is the only soft-cover feature in this file that is impassable.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.46));
            var _body = [];
            var _n = 3;
            for (var _i = 0; _i < _n; _i++) {
                var _cx = lerp(_x0 + _sp.w * 0.16, _x1 - _sp.w * 0.16, _i / (_n - 1));
                var _sw = _sp.w * 0.042;
                var _sp2 = _sp.w * 0.19;
                for (var _d = 0; _d < 2; _d++) {
                    var _dx = (_d == 0) ? _sp2 : -_sp2;
                    var _pts = [[_cx - _dx - _sw, _g], [_cx - _dx + _sw, _g],
                                [_cx + _dx + _sw * 0.4, _g - _sp.h],
                                [_cx + _dx - _sw * 0.4, _g - _sp.h]];
                    mst_append(_body, mst_raise(_pts, mst_bevel_cap(_pts, _sw * 0.55), 2, "m2"));
                }
            }
            mst_append(_out, mst_map_roles(_body, mst_ground_map("a")));
            // A single rail through all three crossings, which is what stops it being three Xs.
            var _ry4 = _g - _sp.h * 0.52;
            mst_append(_out, mst_map_roles(
                mst_strap(_x0 + _sp.w * 0.08, _ry4, _x1 - _sp.w * 0.08, _sp.h * 0.036),
                mst_ground_map("b")));
        } break;

        case "hurdle": {
            // Woven hazel panel between two posts. Field boundary, not defence: low, light, and it
            // does not block sight.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.48));
            var _pw = _sp.w * 0.045;
            var _posts = [];
            mst_append(_posts, mst_timber(_x0, _top, _x0 + _pw, _g, _rng));
            mst_append(_posts, mst_timber(_x1 - _pw, _top, _x1, _g, _rng));
            mst_append(_out, mst_map_roles(_posts, mst_ground_map("a")));
            var _weave = [];
            var _rows = 5;
            for (var _r = 0; _r < _rows; _r++) {
                var _wy = _top + _sp.h * ((_r + 0.5) / _rows);
                var _pts = [];
                for (var _k = 0; _k <= 12; _k++) {
                    var _u = _k / 12;
                    // The withy passes in front of one upright and behind the next, so it waves.
                    _pts[_k] = [lerp(_x0 + _pw, _x1 - _pw, _u),
                                _wy + sin(_u * pi * 3) * _sp.h * 0.035];
                }
                mst_append(_weave, mst_ridge(_pts, false, _sp.h * 0.045));
            }
            for (var _k = 1; _k < 4; _k++) {
                var _ux = lerp(_x0 + _pw, _x1 - _pw, _k / 4);
                mst_append(_weave, mst_incise([[_ux, _top + _sp.h * 0.06], [_ux, _g - _sp.h * 0.04]],
                                              false, _sp.h * 0.030));
            }
            mst_append(_out, mst_map_roles(_weave, mst_ground_map("b")));
        } break;

        case "cart": {
            // A broken wagon: one wheel off, the bed tipped. An upright intact cart reads as
            // scenery; a tipped one reads as an event that happened here.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.50));
            // ⛔ THE BED AND THE WHEEL WERE BOTH TOO LOW AND THE SUITE CAUGHT IT: the cart drew to
            // 0.36 against a declared 0.56. The tell was that the tallest thing on it is the WHEEL,
            // whose top sits at 2 * _wr above the ground - so the declared height is a statement
            // about the wheel, and the wheel radius is what has to satisfy it. Raising the bed
            // alone would have left the silhouette unchanged.
            var _tilt = 0.20;
            var _bedh = _sp.h * 0.26;
            var _by = _g - _sp.h * 0.56;
            var _bed = [[_x0 + _sp.w * 0.04, _by + _sp.w * _tilt * 0.5],
                        [_x1 - _sp.w * 0.10, _by - _sp.w * _tilt * 0.5],
                        [_x1 - _sp.w * 0.10, _by - _sp.w * _tilt * 0.5 + _bedh],
                        [_x0 + _sp.w * 0.04, _by + _sp.w * _tilt * 0.5 + _bedh]];
            var _wood = mst_raise(_bed, mst_bevel_cap(_bed, _bedh * 0.20), 2, "m2");
            // Planks along the bed, following the tilt.
            for (var _k = 1; _k < 3; _k++) {
                var _u = _k / 3;
                mst_append(_wood, mst_incise([
                    [_x0 + _sp.w * 0.06, _by + _sp.w * _tilt * 0.5 + _bedh * _u],
                    [_x1 - _sp.w * 0.12, _by - _sp.w * _tilt * 0.5 + _bedh * _u]],
                    false, _bedh * 0.10));
            }
            // The shaft, dropped to the ground at the near end.
            mst_append(_wood, mst_timber(_x0 - _sp.w * 0.02, _g - _sp.h * 0.06,
                                         _x0 + _sp.w * 0.22, _g - _sp.h * 0.02, _rng));
            mst_append(_out, mst_map_roles(_wood, mst_ground_map("a")));
            // One wheel standing, one lying flat behind. The flat one is an ELLIPSE.
            var _iron = [];
            var _wr = _sp.h * 0.45;   // top of the wheel = 2 * _wr = the declared height
            var _wx = _x1 - _sp.w * 0.22;
            var _rim = mst_pool_pts(_wx, _g - _wr, _wr, _wr, 20, 0, undefined);
            mst_append(_iron, mst_ridge(_rim, true, _wr * 0.16));
            for (var _k = 0; _k < 6; _k++) {
                var _a = (_k / 6) * MST_TAU;
                mst_append(_iron, mst_ridge([[_wx, _g - _wr],
                                             [_wx + cos(_a) * _wr * 0.86, _g - _wr + sin(_a) * _wr * 0.86]],
                                            false, _wr * 0.10));
            }
            mst_append(_iron, mst_boss(_wx, _g - _wr, _wr * 0.20, 10));
            var _lying = mst_pool_pts(_x0 + _sp.w * 0.30, _g - _sp.h * 0.05, _wr * 0.92, _wr * 0.30, 18, 0, undefined);
            mst_append(_iron, mst_ridge(_lying, true, _wr * 0.13));
            mst_append(_out, mst_map_roles(_iron, mst_ground_map("b")));
            // A spilled sack.
            var _sack = mst_lump_pts(_x0 + _sp.w * 0.14, _g - _sp.h * 0.12,
                                     _sp.w * 0.11, _sp.h * 0.12, 10, 0.18, 0.60, _rng);
            mst_append(_out, mst_map_roles(mst_raise(_sack, _sp.h * 0.035, 2, "m2"),
                                           mst_ground_map("c")));
        } break;

        case "crates": {
            // Three boxes, stacked off-square. A neat stack reads as a placed prop.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.48));
            var _body = [];
            var _iron2 = [];
            var _boxes = [[0.00, 0.00, 1.00], [-0.20, 0.54, 0.68], [0.26, 0.50, 0.60]];
            for (var _i = 0; _i < 3; _i++) {
                var _b = _boxes[_i];
                var _bw2 = _sp.w * 0.42 * _b[2];
                var _bh2 = _sp.h * 0.46 * _b[2];
                var _bx = _sp.w * _b[0];
                var _byy = _g - _sp.h * _b[1] - _bh2;
                var _pts = [[_bx - _bw2, _byy], [_bx + _bw2, _byy],
                            [_bx + _bw2, _byy + _bh2], [_bx - _bw2, _byy + _bh2]];
                mst_append(_body, mst_raise(_pts, mst_bevel_cap(_pts, min(_bw2, _bh2) * 0.16), 2, "m2"));
                // Boards across the face, and a diagonal brace, which is what makes a rectangle a
                // CRATE rather than a block.
                for (var _k = 1; _k < 3; _k++) {
                    var _gy2 = _byy + _bh2 * (_k / 3);
                    mst_append(_body, mst_incise([[_bx - _bw2 * 0.94, _gy2], [_bx + _bw2 * 0.94, _gy2]],
                                                 false, _bh2 * 0.075));
                }
                mst_append(_body, mst_incise([[_bx - _bw2 * 0.90, _byy + _bh2 * 0.94],
                                              [_bx + _bw2 * 0.90, _byy + _bh2 * 0.06]],
                                             false, _bh2 * 0.065));
                mst_append(_iron2, mst_boss(_bx - _bw2 * 0.82, _byy + _bh2 * 0.14, _bw2 * 0.10, 8));
                mst_append(_iron2, mst_boss(_bx + _bw2 * 0.82, _byy + _bh2 * 0.86, _bw2 * 0.10, 8));
            }
            mst_append(_out, mst_map_roles(_body, mst_ground_map("a")));
            mst_append(_out, mst_map_roles(_iron2, mst_ground_map("b")));
        } break;

        case "barrels": {
            // Two upright and one on its side. A barrel is a BULGE - straight sides read as a bin.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.48));
            var _body = [];
            var _hoops = [];
            var _stand = [[-0.20, 1.00], [0.18, 0.86]];
            for (var _i = 0; _i < 2; _i++) {
                var _bx = _sp.w * _stand[_i][0];
                var _bh3 = _sp.h * 0.82 * _stand[_i][1];
                var _bw3 = _sp.w * 0.19 * _stand[_i][1];
                var _n = 8;
                var _lf = [], _rt = [];
                for (var _k = 0; _k <= _n; _k++) {
                    var _u = _k / _n;
                    // The bulge: widest at the middle, by construction, so it cannot be flat.
                    var _sw2 = _bw3 * (0.78 + sin(pi * _u) * 0.30);
                    var _yy = _g - _bh3 * _u;
                    _lf[_k] = [_bx - _sw2, _yy];
                    _rt[_k] = [_bx + _sw2, _yy];
                }
                var _pts = [];
                for (var _k = 0; _k <= _n; _k++) array_push(_pts, _lf[_k]);
                for (var _k = _n; _k >= 0; _k--) array_push(_pts, _rt[_k]);
                mst_append(_body, mst_raise(_pts, mst_bevel_cap(_pts, _bw3 * 0.24), 3, "m2"));
                // Staves.
                for (var _k = 1; _k < 4; _k++) {
                    var _u2 = _k / 4;
                    var _gx2 = _bx + (_u2 - 0.5) * _bw3 * 1.7;
                    mst_append(_body, mst_incise([[_gx2, _g - _bh3 * 0.92], [_gx2, _g - _bh3 * 0.08]],
                                                 false, _bw3 * 0.10));
                }
                // Hoops, bowed downward across the near face.
                for (var _k = 0; _k < 3; _k++) {
                    var _hy = _g - _bh3 * (0.16 + _k * 0.34);
                    var _hw2 = _bw3 * (0.80 + sin(pi * (0.16 + _k * 0.34)) * 0.30);
                    var _hp = [];
                    for (var _m = 0; _m <= 6; _m++) {
                        var _u3 = _m / 6;
                        _hp[_m] = [_bx + (_u3 - 0.5) * _hw2 * 2, _hy + sin(pi * _u3) * _bh3 * 0.022];
                    }
                    mst_append(_hoops, mst_ridge(_hp, false, _bh3 * 0.032));
                }
            }
            // One lying on its side, drawn as a squat bulged form on its own axis.
            var _lx = _sp.w * 0.05, _ly = _g - _sp.h * 0.13;
            var _lp = mst_pool_pts(_lx, _ly, _sp.w * 0.24, _sp.h * 0.13, 16, 0, undefined);
            mst_append(_body, mst_raise(_lp, mst_bevel_cap(_lp, _sp.h * 0.045), 2, "m2"));
            mst_append(_out, mst_map_roles(_body, mst_ground_map("a")));
            mst_append(_out, mst_map_roles(_hoops, mst_ground_map("b")));
        } break;

        case "haybale": {
            // A round bale: a squat cylinder seen end-on, so the SPIRAL of the wrap is the tell.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.50));
            var _cy4 = _g - _sp.h * 0.50;
            var _rx4 = _sp.w * 0.5, _ry4b = _sp.h * 0.5;
            var _pts = mst_lump_pts(0, _cy4, _rx4, _ry4b, 18, 0.045, 0.22, _rng);
            mst_append(_out, mst_map_roles(
                mst_raise(_pts, mst_bevel_cap(_pts, min(_rx4, _ry4b) * 0.30), 3, "m2"),
                mst_ground_map("a")));
            // The spiral. Nested ellipses would read as a target; an offset spiral reads as rolled.
            var _sp3 = [];
            for (var _k = 0; _k < 4; _k++) {
                var _kk = (_k + 1) / 5;
                mst_append(_sp3, mst_incise(
                    mst_pool_pts(_rx4 * 0.10 * _kk, _cy4 + _ry4b * 0.06 * _kk,
                                 _rx4 * (1 - _kk) * 0.92, _ry4b * (1 - _kk) * 0.92, 16, 0, undefined),
                    true, _ry4b * 0.055));
            }
            mst_append(_out, mst_map_roles(_sp3, mst_ground_map("a")));
            // Two bands of cord round the girth.
            var _cord = [];
            for (var _k = 0; _k < 2; _k++) {
                var _bx2 = (_k == 0) ? -_rx4 * 0.34 : _rx4 * 0.36;
                mst_append(_cord, mst_ridge([[_bx2, _cy4 - _ry4b * 0.94], [_bx2, _cy4 + _ry4b * 0.94]],
                                            false, _ry4b * 0.05));
            }
            mst_append(_out, mst_map_roles(_cord, mst_ground_map("b")));
        } break;

        case "logpile": {
            // Cut cordwood stacked between two stakes: a wall of END GRAIN, which is a completely
            // different picture from a heap of branches and the reason this is its own feature.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.52));
            var _ends = [];
            var _rings = [];
            var _rows = 3;
            for (var _r = 0; _r < _rows; _r++) {
                var _ry5 = _sp.h * 0.5 / _rows;
                var _cy5 = _g - _sp.h * (_r / _rows) - _ry5;
                var _off = (_r % 2) * _ry5 * 0.9;
                var _cx2 = _x0 + _sp.w * 0.06 + _off;
                while (_cx2 < _x1 - _sp.w * 0.06) {
                    var _lr = _ry5 * (0.72 + mst_rng_next(_rng) * 0.30);
                    var _lp2 = mst_lump_pts(_cx2 + _lr, _cy5, _lr, _lr, 11, 0.06, 0, _rng);
                    mst_append(_ends, mst_raise(_lp2, _lr * 0.26, 2, "m2"));
                    // Growth rings and a split, which is what makes an end grain read as timber.
                    mst_append(_rings, mst_incise(
                        mst_pool_pts(_cx2 + _lr, _cy5, _lr * 0.50, _lr * 0.50, 12, 0, undefined),
                        true, _lr * 0.14));
                    mst_append(_rings, mst_incise([[_cx2 + _lr, _cy5 - _lr * 0.82],
                                                   [_cx2 + _lr, _cy5 + _lr * 0.30]],
                                                  false, _lr * 0.14));
                    _cx2 += _lr * 2.05;
                }
            }
            mst_append(_out, mst_map_roles(_ends, mst_ground_map("a")));
            mst_append(_out, mst_map_roles(_rings, mst_ground_map("b")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(0, _g - _sp.h * 0.10, _sp.w * 0.42, _sp.h * 0.10, 3, _rng),
                mst_ground_map("c")));
        } break;

        case "wellhead": {
            // Masonry drum, timber frame, iron windlass. The frame is what makes it read at a
            // glance - a bare drum is a planter.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.50));
            var _dh = _sp.h * 0.34;
            var _drum = mst_shaft_pts(0, _g, _g - _dh, _sp.w * 0.92, _sp.w * 0.86, 0, 3);
            var _stonew = mst_raise(_drum, mst_bevel_cap(_drum, _sp.w * 0.10), 3, "m2");
            mst_append(_stonew, mst_course(-_sp.w * 0.44, _sp.w * 0.44, _g - _dh * 0.62, _g - _dh * 0.30, 0.2, 3, _rng));
            mst_append(_stonew, mst_course(-_sp.w * 0.44, _sp.w * 0.44, _g - _dh * 0.30, _g, 0.7, 3, _rng));
            // The coping, and the dark mouth inside it.
            var _cop = mst_pool_pts(0, _g - _dh, _sp.w * 0.46, _sp.h * 0.075, 18, 0, undefined);
            mst_append(_stonew, mst_raise(_cop, _sp.h * 0.028, 2, "m3"));
            var _mouth = mst_pool_pts(0, _g - _dh, _sp.w * 0.33, _sp.h * 0.052, 16, 0, undefined);
            mst_append(_stonew, mst_sink(_mouth, _sp.h * 0.022, 2, "m0"));
            mst_append(_out, mst_map_roles(_stonew, mst_ground_map("a")));
            // Frame: two uprights and a ridge.
            var _wood2 = [];
            var _pw2 = _sp.w * 0.055;
            mst_append(_wood2, mst_timber(-_sp.w * 0.40 - _pw2, _top + _sp.h * 0.06,
                                          -_sp.w * 0.40 + _pw2, _g - _dh * 0.82, _rng));
            mst_append(_wood2, mst_timber(_sp.w * 0.40 - _pw2, _top + _sp.h * 0.06,
                                          _sp.w * 0.40 + _pw2, _g - _dh * 0.82, _rng));
            var _rf = [[-_sp.w * 0.48, _top + _sp.h * 0.10], [0, _top],
                       [_sp.w * 0.48, _top + _sp.h * 0.10], [_sp.w * 0.48, _top + _sp.h * 0.17],
                       [0, _top + _sp.h * 0.07], [-_sp.w * 0.48, _top + _sp.h * 0.17]];
            mst_append(_wood2, mst_raise(_rf, mst_bevel_cap(_rf, _sp.h * 0.022), 2, "m2"));
            mst_append(_out, mst_map_roles(_wood2, mst_ground_map("b")));
            // Windlass and chain.
            var _ir = [];
            var _wy2 = _g - _dh - _sp.h * 0.18;
            mst_append(_ir, mst_ridge([[-_sp.w * 0.36, _wy2], [_sp.w * 0.36, _wy2]], false, _sp.h * 0.036));
            mst_append(_ir, mst_boss(-_sp.w * 0.40, _wy2, _sp.h * 0.030, 8));
            mst_append(_ir, mst_boss(_sp.w * 0.40, _wy2, _sp.h * 0.030, 8));
            mst_append(_ir, mst_incise([[_sp.w * 0.06, _wy2], [_sp.w * 0.06, _g - _dh - _sp.h * 0.02]],
                                       false, _sp.h * 0.020));
            mst_append(_out, mst_map_roles(_ir, mst_ground_map("c")));
        } break;

        case "shrine": {
            // A wayside marker: a tapering pillar on a stepped base with a sunken niche. The NICHE
            // is what makes it sacred rather than structural.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.56));
            var _stone2 = [];
            for (var _s = 0; _s < 2; _s++) {
                var _sw3 = _sp.w * (1.0 - _s * 0.22);
                var _sy2 = _g - _sp.h * 0.055 * _s;
                var _blk = [[-_sw3 * 0.5, _sy2 - _sp.h * 0.055], [_sw3 * 0.5, _sy2 - _sp.h * 0.055],
                            [_sw3 * 0.5, _sy2], [-_sw3 * 0.5, _sy2]];
                mst_append(_stone2, mst_raise(_blk, mst_bevel_cap(_blk, _sp.h * 0.016), 2, "m2"));
            }
            var _pb = _g - _sp.h * 0.11;
            var _pil = mst_shaft_pts(0, _pb, _top + _sp.h * 0.12, _sp.w * 0.56, _sp.w * 0.42, 0, 4);
            mst_append(_stone2, mst_raise(_pil, mst_bevel_cap(_pil, _sp.w * 0.08), 3, "m2"));
            // The niche.
            var _nw = _sp.w * 0.20, _nh = _sp.h * 0.20;
            var _ncy = _pb - _sp.h * 0.42;
            var _npts = [[-_nw, _ncy], [-_nw, _ncy - _nh * 0.6]];
            var _ar = mst_arc_pts(0, _ncy - _nh * 0.6, _nw, pi, MST_TAU, 8);
            for (var _k = 0; _k < array_length(_ar); _k++) array_push(_npts, _ar[_k]);
            array_push(_npts, [_nw, _ncy]);
            mst_append(_stone2, mst_sink(_npts, _nw * 0.30, 2, "m0"));
            // A cap gable.
            var _gb = [[-_sp.w * 0.32, _top + _sp.h * 0.14], [0, _top],
                       [_sp.w * 0.32, _top + _sp.h * 0.14],
                       [_sp.w * 0.26, _top + _sp.h * 0.17], [0, _top + _sp.h * 0.05],
                       [-_sp.w * 0.26, _top + _sp.h * 0.17]];
            mst_append(_stone2, mst_raise(_gb, mst_bevel_cap(_gb, _sp.h * 0.020), 2, "m2"));
            mst_append(_out, mst_map_roles(_stone2, mst_ground_map("a")));
            // A votive offering: a small bundle at the foot.
            var _vb = mst_lump_pts(_sp.w * 0.22, _g - _sp.h * 0.075, _sp.w * 0.10, _sp.h * 0.048,
                                   9, 0.20, 0.5, _rng);
            mst_append(_out, mst_map_roles(mst_raise(_vb, _sp.h * 0.016, 2, "m2"),
                                           mst_ground_map("b")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(0, _g - _sp.h * 0.14, _sp.w * 0.28, _sp.h * 0.10, 3, _rng),
                mst_ground_map("c")));
        } break;

        case "tomb": {
            // A table tomb: a slab on short piers, weathered, lettering long gone. Low, so it is
            // soft cover, and it does not block sight.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.52));
            var _st2 = [];
            var _pierh = _sp.h * 0.44;
            for (var _k = 0; _k < 2; _k++) {
                var _px2 = (_k == 0) ? -_sp.w * 0.30 : _sp.w * 0.30;
                var _blk = [[_px2 - _sp.w * 0.08, _g - _pierh], [_px2 + _sp.w * 0.08, _g - _pierh],
                            [_px2 + _sp.w * 0.08, _g], [_px2 - _sp.w * 0.08, _g]];
                mst_append(_st2, mst_raise(_blk, mst_bevel_cap(_blk, _sp.w * 0.018), 2, "m1"));
            }
            // The slab sits slightly askew, which is what four hundred years of frost does.
            var _sk = _sp.h * 0.055;
            var _slab = [[_x0, _g - _pierh - _sp.h * 0.30 + _sk], [_x1, _g - _pierh - _sp.h * 0.30],
                         [_x1, _g - _pierh + _sp.h * 0.02], [_x0, _g - _pierh + _sp.h * 0.02 + _sk]];
            mst_append(_st2, mst_raise(_slab, mst_bevel_cap(_slab, _sp.h * 0.055), 3, "m3"));
            mst_append(_out, mst_map_roles(_st2, mst_ground_map("a")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(0, _g - _pierh - _sp.h * 0.12, _sp.w * 0.42, _sp.h * 0.10, 5, _rng),
                mst_ground_map("b")));
            // An iron ring set in the slab.
            mst_append(_out, mst_map_roles(
                mst_ridge(mst_pool_pts(_sp.w * 0.06, _g - _pierh - _sp.h * 0.16,
                                       _sp.w * 0.07, _sp.h * 0.030, 12, 0, undefined),
                          true, _sp.h * 0.022),
                mst_ground_map("c")));
        } break;

        case "watchstump": {
            // The base of a fallen tower. Tallest thing in the corpus at tall:3, and its top must
            // read as BROKEN rather than as a flat roof or it becomes a chimney.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.52));
            var _drum2 = mst_shaft_pts(0, _g, _top + _sp.h * 0.10, _sp.w, _sp.w * 0.86, 0, 5);
            var _body2 = mst_raise(_drum2, mst_bevel_cap(_drum2, _sp.w * 0.14), 3, "m2");
            var _courses2 = 7;
            for (var _c = 0; _c < _courses2; _c++) {
                var _u = _c / _courses2;
                var _cw = _sp.w * (0.5 - 0.07 * _u);
                mst_append(_body2, mst_course(-_cw, _cw, _g - _sp.h * ((_c + 1) / _courses2),
                                              _g - _sp.h * (_c / _courses2), _c * 0.41, 4, _rng));
            }
            // The broken crown: a jagged top edge, drawn as a mass so it bevels with the wall.
            var _crown = [];
            var _cn = 7;
            for (var _k = 0; _k <= _cn; _k++) {
                var _u = _k / _cn;
                var _cwx = lerp(-_sp.w * 0.44, _sp.w * 0.44, _u);
                var _jag = (_k % 2 == 0) ? _sp.h * 0.10 : _sp.h * 0.02;
                _crown[_k] = [_cwx, _top + _sp.h * 0.10 - _jag - mst_rng_next(_rng) * _sp.h * 0.03];
            }
            array_push(_crown, [_sp.w * 0.44, _top + _sp.h * 0.20]);
            array_push(_crown, [-_sp.w * 0.44, _top + _sp.h * 0.20]);
            mst_append(_body2, mst_raise(_crown, mst_bevel_cap(_crown, _sp.h * 0.028), 2, "m2"));
            mst_append(_out, mst_map_roles(_body2, mst_ground_map("a")));
            // An arrow loop: a tall sunken slot, which reads as a tower and nothing else.
            var _lw = _sp.w * 0.055, _lh = _sp.h * 0.20;
            var _lcy = _g - _sp.h * 0.48;
            var _loop = [[-_lw, _lcy + _lh * 0.5], [-_lw, _lcy - _lh * 0.4], [0, _lcy - _lh * 0.5],
                         [_lw, _lcy - _lh * 0.4], [_lw, _lcy + _lh * 0.5]];
            mst_append(_out, mst_map_roles(mst_sink(_loop, _lw * 0.45, 2, "m0"),
                                           mst_ground_map("b")));
            var _sill = [];
            mst_append(_sill, mst_ridge([[-_lw * 2.2, _lcy + _lh * 0.56], [_lw * 2.2, _lcy + _lh * 0.56]],
                                        false, _sp.h * 0.020));
            mst_append(_out, mst_map_roles(_sill, mst_ground_map("c")));
        } break;

        default: { // gatepost
            // One post of a gate whose gate is gone: a squared pillar with a hanging pintle. The
            // PINTLE is the whole story - it says a gate hung here.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.90));
            var _pil2 = mst_shaft_pts(0, _g, _top + _sp.h * 0.10, _sp.w, _sp.w * 0.82, 0, 4);
            var _bodyp = mst_raise(_pil2, mst_bevel_cap(_pil2, _sp.w * 0.20), 3, "m2");
            // A pyramid cap.
            var _cap2 = [[-_sp.w * 0.52, _top + _sp.h * 0.13], [0, _top],
                         [_sp.w * 0.52, _top + _sp.h * 0.13],
                         [_sp.w * 0.46, _top + _sp.h * 0.16], [0, _top + _sp.h * 0.055],
                         [-_sp.w * 0.46, _top + _sp.h * 0.16]];
            mst_append(_bodyp, mst_raise(_cap2, mst_bevel_cap(_cap2, _sp.h * 0.018), 2, "m3"));
            mst_append(_out, mst_map_roles(_bodyp, mst_ground_map("a")));
            var _ir2 = [];
            for (var _k = 0; _k < 2; _k++) {
                var _hy2 = _g - _sp.h * (0.30 + _k * 0.34);
                mst_append(_ir2, mst_ridge([[_sp.w * 0.10, _hy2], [_sp.w * 0.46, _hy2]],
                                           false, _sp.h * 0.026));
                mst_append(_ir2, mst_boss(_sp.w * 0.46, _hy2 - _sp.h * 0.026, _sp.h * 0.024, 8));
            }
            mst_append(_out, mst_map_roles(_ir2, mst_ground_map("b")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(0, _g - _sp.h * 0.14, _sp.w * 0.40, _sp.h * 0.12, 3, _rng),
                mst_ground_map("c")));
        } break;
    }
    return _out;
}
