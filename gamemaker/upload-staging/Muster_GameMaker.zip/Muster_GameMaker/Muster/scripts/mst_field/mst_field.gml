/// MUSTER - mst_field. The generator: a whole battlefield composed from a seed, a biome and a
/// season, with the tactical rules written into every cell AS IT IS PLACED.
///
/// -- WHAT THIS FILE GUARANTEES ----------------------------------------------------------------
/// A generator that produces a beautiful map you cannot fight on is worthless, so mst_field makes
/// three promises and mst_selftest asserts all three over hundreds of generated fields:
///
///   1. EVERY FIELD IS CONNECTED. There is a path from one deployment zone to the other. This is
///      not hoped for, it is REPAIRED: mst_field_connect clears blocking features, and where the
///      GROUND itself seals the map it regrades cells to a passable material from the same biome.
///      Both repairs are COUNTED (`cleared`, `regraded`) and reported, because a map that needed
///      six regrades is one a scenario writer may want to reject.
///   2. EVERY DEPLOYMENT CELL IS STANDABLE. No unit is ever placed inside a boulder or a pool.
///   3. THE PICTURE AND THE RULES AGREE. `cover`, `los`, `tall` and `cost` are copied out of
///      mst_feature_spec at the moment the feature is placed, so there is no second table to keep
///      in step and no way for a drawn boulder to query as open ground.
///
/// -- THE BIOME IS THE SECOND VOLUME AXIS ------------------------------------------------------
/// Eight biomes multiply the eight seasons: a marsh in `snowbound` and a marsh in `thaw` are
/// different maps to fight on, not the same map in two tints, because the season changes the
/// MOVEMENT COST of mud and water as well as their colour. Eight biomes, eight seasons and a free
/// seed is the combinatorial claim this product is sold on, and it is arithmetic rather than a
/// promise: 64 named combinations, each with an unbounded seed space.
///
/// ⛔ NOTHING HERE CALLS random(). The whole field is a pure function of (seed, biome, season,
/// strength, size). Two calls with the same arguments produce the same battlefield, which is what
/// makes a generated map SAVEABLE - a buyer stores the seed, not the map, and a replay or a
/// multiplayer peer rebuilds it exactly.
/// ============================================================================================

#macro MST_BIOME_N 8

/// The four elevation levels. More than four and a player cannot tell them apart at a glance;
/// fewer and high ground stops being a decision.
#macro MST_LEVELS 4

/// ============================================================================================
/// BIOMES
///
/// A biome is a ground mix, a relief style, and what grows or stands on it. The `ground` array is
/// sampled by an elevation-weighted pick, so the wet materials land in the hollows and the bare
/// ones on the tops WITHOUT a special case: each entry names the band of the height range it
/// belongs to.
/// ============================================================================================

/// _lo/_hi are the normalised elevation band the material occupies (0 = lowest ground in the
/// field, 1 = highest). Bands may overlap, and where they do the pick is by seeded weight.
function mst_biome_spec(_biome) {
    switch (_biome) {
        case "downland": return {
            relief: 0.85, roughness: 0.45, density: 0.20,
            ground: [["mud", 0.00, 0.18], ["turf", 0.05, 0.72], ["meadow", 0.30, 0.90],
                     ["scree", 0.74, 1.00], ["limestone", 0.88, 1.00]],
            feats:  [["drystone", 3], ["boulder", 2], ["scrub", 3], ["haybale", 1],
                     ["hurdle", 2], ["broadleaf", 2], ["stump", 1], ["cairn", 1],
                     ["heathpatch", 2], ["furrow", 1]],
        };
        case "marsh": return {
            relief: 0.22, roughness: 0.30, density: 0.30,
            ground: [["waterlike", 0.00, 0.22], ["mud", 0.00, 0.55], ["reed", 0.18, 0.68],
                     ["moss", 0.40, 0.85], ["turf", 0.62, 1.00]],
            feats:  [["mire", 4], ["reedbed", 4], ["pool", 3], ["ford", 2], ["deadfall", 2],
                     ["snag", 2], ["logpile", 1], ["cache", 1], ["brackenc", 2]],
        };
        case "woodland": return {
            relief: 0.55, roughness: 0.60, density: 0.42,
            ground: [["mud", 0.00, 0.20], ["moss", 0.10, 0.60], ["loam", 0.25, 0.75],
                     ["turf", 0.50, 0.92], ["scree", 0.86, 1.00]],
            feats:  [["broadleaf", 5], ["conifer", 3], ["scrub", 3], ["brambles", 3],
                     ["deadfall", 2], ["stump", 2], ["snag", 1], ["mossrock", 2],
                     ["boulder", 1], ["brackenc", 2]],
        };
        case "moor": return {
            relief: 0.95, roughness: 0.72, density: 0.22,
            ground: [["mud", 0.00, 0.16], ["heath", 0.06, 0.72], ["bracken", 0.20, 0.60],
                     ["scree", 0.66, 1.00], ["granite", 0.86, 1.00]],
            feats:  [["outcrop", 3], ["menhir", 2], ["cairn", 3], ["boulder", 3],
                     ["heathpatch", 4], ["screeslope", 2], ["thorntree", 2], ["fissure", 1],
                     ["brackenc", 2]],
        };
        case "ruins": return {
            relief: 0.60, roughness: 0.50, density: 0.46,
            ground: [["mud", 0.00, 0.22], ["loam", 0.10, 0.55], ["turf", 0.32, 0.80],
                     ["rubblelike", 0.55, 1.00], ["mortar", 0.84, 1.00]],
            feats:  [["ruinwall", 5], ["rubble", 4], ["gatepost", 2], ["tomb", 2],
                     ["watchstump", 1], ["shrine", 1], ["altar", 1], ["brambles", 3],
                     ["scrub", 2], ["crates", 1]],
        };
        case "farmland": return {
            relief: 0.35, roughness: 0.30, density: 0.30,
            ground: [["mud", 0.00, 0.22], ["loam", 0.06, 0.62], ["turf", 0.35, 0.85],
                     ["meadow", 0.55, 1.00], ["clay", 0.80, 1.00]],
            feats:  [["furrow", 4], ["cornstand", 4], ["hurdle", 3], ["haybale", 2],
                     ["cart", 2], ["wellhead", 1], ["barrels", 1], ["crates", 1],
                     ["pollard", 2], ["drystone", 2], ["tent", 1]],
        };
        case "riverbank": return {
            relief: 0.40, roughness: 0.42, density: 0.32,
            ground: [["waterlike", 0.00, 0.20], ["shingle", 0.10, 0.48], ["mud", 0.05, 0.40],
                     ["reed", 0.30, 0.62], ["turf", 0.52, 1.00]],
            feats:  [["ford", 4], ["pool", 3], ["reedbed", 3], ["pollard", 3], ["deadfall", 2],
                     ["boulder", 2], ["logpile", 1], ["cairn", 1], ["scrub", 2], ["mire", 2]],
        };
        default: return { // waste
            relief: 0.70, roughness: 0.80, density: 0.28,
            // ⚠️ cinder's band was 0.00-0.45 and it dominated the whole biome, so a waste field
            // was mostly one dark material. Narrowed so clay and sand carry the middle.
            ground: [["cinder", 0.00, 0.28], ["clay", 0.12, 0.58], ["scree", 0.40, 0.85],
                     ["sand", 0.24, 0.72], ["basalt", 0.86, 1.00]],
            feats:  [["snag", 3], ["screeslope", 3], ["tarpit", 2], ["fissure", 2],
                     ["outcrop", 2], ["rubble", 2], ["brazier", 1], ["sinkhole", 2],
                     ["cheval", 1], ["beacon", 1]],
        };
    }
}

function mst_biome_names() {
    return ["downland", "marsh", "woodland", "moor", "ruins", "farmland", "riverbank", "waste"];
}

/// Two ground names in the biome tables above are ALIASES resolved by season, not materials.
///
/// ⭐ THIS IS THE SEASON REACHING INTO THE TERRAIN ITSELF AND IT IS THE BEST IDEA IN THE FILE. A
/// marsh's lowest ground is standing water in autumn and ICE in February - a different material,
/// a different colour AND a different movement cost, from one alias. Without this, a snowbound
/// marsh would be a marsh that had been painted white, which is precisely the failure mst_ground's
/// susceptibility column exists to prevent, arriving one level up.
function mst_ground_alias(_name, _season, _t) {
    if (_name == "waterlike") {
        if (_season == "snowbound" && _t >= 0.5) return "shingle"; // frozen hard, walkable
        if (_season == "drought" && _t >= 0.5) return "clay";      // dried out and cracked
        return "mud";
    }
    if (_name == "rubblelike") return "shingle";
    return _name;
}

/// ============================================================================================
/// THE HEIGHT FIELD
///
/// Value noise on a coarse lattice, bilinear between the corners, two octaves. Deterministic from
/// the seed, no engine calls, and cheap enough to run in a buyer's Create event.
///
/// ⚠️ TWO OCTAVES AND NOT FIVE. A five-octave field looks better as a picture and plays worse as a
/// battlefield: it produces single-cell pinnacles a unit cannot climb and one-cell dips that read
/// as noise rather than as ground. Terrain a player must reason about needs BROAD forms.
/// ============================================================================================

function mst_lattice(_seed, _gx, _gy) {
    // FNV over the two coordinates so the lattice is stable under a change of field size: a
    // corner's value depends on WHERE it is, never on how big the array happens to be.
    var _h = mst_hash32(string(_seed) + ":" + string(_gx) + ":" + string(_gy));
    return (_h & 0xFFFFFF) / 16777215;
}

function mst_noise2(_seed, _x, _y, _scale) {
    var _fx = _x / _scale, _fy = _y / _scale;
    var _ix = floor(_fx), _iy = floor(_fy);
    var _tx = _fx - _ix, _ty = _fy - _iy;
    // Smoothstep, so the lattice lines do not show as creases.
    _tx = _tx * _tx * (3 - 2 * _tx);
    _ty = _ty * _ty * (3 - 2 * _ty);
    var _a = mst_lattice(_seed, _ix, _iy);
    var _b = mst_lattice(_seed, _ix + 1, _iy);
    var _c = mst_lattice(_seed, _ix, _iy + 1);
    var _d = mst_lattice(_seed, _ix + 1, _iy + 1);
    return lerp(lerp(_a, _b, _tx), lerp(_c, _d, _tx), _ty);
}

/// ============================================================================================
/// THE FIELD
/// ============================================================================================

/// Index helper. One place, so an off-by-one cannot exist in two forms.
function mst_idx(_f, _x, _y) {
    return _y * _f.w + _x;
}

function mst_in_bounds(_f, _x, _y) {
    return (_x >= 0 && _y >= 0 && _x < _f.w && _y < _f.h);
}

function mst_cell(_f, _x, _y) {
    if (!mst_in_bounds(_f, _x, _y)) return undefined;
    return _f.cells[mst_idx(_f, _x, _y)];
}

/// Build a battlefield.
///
/// _w, _h      size in cells
/// _seed       any number; the whole field is a pure function of it
/// _biome      one of mst_biome_names()
/// _season     one of mst_season_names()
/// _t          season strength 0..1
function mst_field_make(_w, _h, _seed, _biome, _season, _t) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_real(_w) || !is_real(_h) || !is_string(_biome) || !is_string(_season)) return undefined;
    var _bs = mst_biome_spec(_biome);
    var _rng = mst_rng(mst_hash32("field/" + string(_seed) + "/" + _biome));

    var _f = {
        w: max(4, _w), h: max(4, _h),
        seed: _seed, biome: _biome, season: _season, season_t: clamp(_t, 0, 1),
        cells: [], deployA: [], deployB: [], objectives: [],
        // Diagnostics, filled by the steps below. A generator that cannot say what it had to
        // repair is a generator you cannot trust; these are printed by the demo and asserted by
        // the suite.
        cleared: 0, regraded: 0, chokepoints: [], pathCost: -1,
    };
    var _n = _f.w * _f.h;

    // -- 1. ELEVATION --------------------------------------------------------------------------
    var _raw = array_create(_n);
    var _lo = 999, _hi = -999;
    var _sc = max(2.2, _f.w * 0.34);
    for (var _y = 0; _y < _f.h; _y++) {
        for (var _x = 0; _x < _f.w; _x++) {
            var _v = mst_noise2(_seed, _x, _y, _sc)
                   + mst_noise2(_seed + 7919, _x, _y, _sc * 0.5) * _bs.roughness * 0.5;
            _raw[mst_idx(_f, _x, _y)] = _v;
            _lo = min(_lo, _v); _hi = max(_hi, _v);
        }
    }
    if (_hi - _lo < 0.0001) _hi = _lo + 1; // a flat noise field must not divide by zero

    // -- 2. CELLS ------------------------------------------------------------------------------
    for (var _i = 0; _i < _n; _i++) {
        var _u = (_raw[_i] - _lo) / (_hi - _lo);
        // `relief` decides how much of the level range the biome actually uses. A marsh at 0.22
        // is nearly flat; a moor at 0.95 uses all four levels.
        var _lv = clamp(floor(_u * MST_LEVELS * _bs.relief), 0, MST_LEVELS - 1);

        // Ground: pick among the entries whose band contains this cell's normalised height.
        var _cands = [];
        for (var _k = 0; _k < array_length(_bs.ground); _k++) {
            var _gd = _bs.ground[_k];
            if (_u >= _gd[1] && _u <= _gd[2]) array_push(_cands, _gd[0]);
        }
        var _mat = "turf";
        if (array_length(_cands) > 0) {
            _mat = _cands[floor(mst_rng_next(_rng) * array_length(_cands)) % array_length(_cands)];
        }
        _mat = mst_ground_alias(_mat, _season, _f.season_t);

        array_push(_f.cells, {
            ground: _mat,
            level: _lv,
            height: _u,
            feat: "",
            featSeed: 0,
            // The tactical row. Written here from the GROUND only; mst_field_place adds the
            // feature's contribution. Nothing else in the package writes these.
            cover: MST_COVER_NONE,
            los: false,
            tall: 0,
            cost: mst_ground_cost(_mat, _season, _f.season_t),
        });
    }

    // -- 3. DEPLOYMENT ZONES ------------------------------------------------------------------
    // Opposite edges, chosen by the seed so a buyer does not always fight west-to-east.
    var _vertical = (mst_rng_next(_rng) < 0.5);
    var _band = max(1, floor(min(_f.w, _f.h) * 0.18));
    for (var _y = 0; _y < _f.h; _y++) {
        for (var _x = 0; _x < _f.w; _x++) {
            var _inA = _vertical ? (_y < _band) : (_x < _band);
            var _inB = _vertical ? (_y >= _f.h - _band) : (_x >= _f.w - _band);
            if (_inA) array_push(_f.deployA, mst_idx(_f, _x, _y));
            if (_inB) array_push(_f.deployB, mst_idx(_f, _x, _y));
        }
    }
    _f.vertical = _vertical;

    // ⛔ A DEPLOYMENT CELL MUST BE STANDABLE, AND THE GROUND ALONE CAN ALREADY BREAK THAT. A
    // riverbank's lowest band is water, and water at the map edge would put a unit in a river
    // before a single feature had been placed. Fixing it here rather than in the placement step is
    // deliberate: the two failures have different causes and a single repair would hide one.
    var _dz = array_concat(_f.deployA, _f.deployB);
    for (var _k = 0; _k < array_length(_dz); _k++) {
        var _c = _f.cells[_dz[_k]];
        if (_c.cost >= MST_IMPASSABLE) {
            _c.ground = "loam";
            _c.cost = mst_ground_cost("loam", _season, _f.season_t);
        }
    }

    // -- 4. FEATURES ---------------------------------------------------------------------------
    mst_field_scatter(_f, _bs, _rng);

    // -- 5. GUARANTEE IT CAN BE FOUGHT ON ------------------------------------------------------
    mst_field_connect(_f, _bs);

    // -- 6. READ THE SHAPE OF THE MAP BACK OFF IT ----------------------------------------------
    mst_field_analyse(_f, _rng);

    return _f;
}

/// Place a feature into a cell AND copy its rules in. The only function that writes `feat`.
///
/// ⭐ THIS FUNCTION IS THE PRODUCT'S CENTRAL CLAIM IN SIX LINES. The cover value, the sight block,
/// the height and the cost all come out of mst_feature_spec - the same struct the builder draws
/// from. There is no path through this package by which a cell can be drawn with a boulder in it
/// and report open ground, because the drawing and the rules are read from one row at one moment.
function mst_field_place(_f, _x, _y, _id, _seed) {
    var _c = mst_cell(_f, _x, _y);
    if (is_undefined(_c)) return false;
    var _sp = mst_feature_spec(_id);
    if (is_undefined(_sp)) return false;

    _c.feat = _id;
    _c.featSeed = _seed;
    _c.cover = _sp.cover;
    _c.los = _sp.los;
    _c.tall = _sp.tall;
    var _base = mst_ground_cost(_c.ground, _f.season, _f.season_t);
    _c.cost = (_sp.cost >= MST_IMPASSABLE || _base >= MST_IMPASSABLE)
            ? MST_IMPASSABLE : (_base + _sp.cost - 1);
    return true;
}

/// Take a feature back out, restoring the cell to bare ground.
function mst_field_clear(_f, _x, _y) {
    var _c = mst_cell(_f, _x, _y);
    if (is_undefined(_c) || _c.feat == "") return false;
    _c.feat = "";
    _c.cover = MST_COVER_NONE;
    _c.los = false;
    _c.tall = 0;
    _c.cost = mst_ground_cost(_c.ground, _f.season, _f.season_t);
    return true;
}

/// Scatter the biome's features across the field.
///
/// ⚠️ FEATURES CLUMP. An even scatter reads as a chessboard and plays as one - no cover to run
/// between, no open ground to be caught in. So placement runs a second noise field and only sows
/// where it is above a threshold, which gives copses, walls that run, and open lanes between them.
/// That is the difference between a map and a texture.
function mst_field_scatter(_f, _bs, _rng) {
    var _total = 0;
    for (var _k = 0; _k < array_length(_bs.feats); _k++) _total += _bs.feats[_k][1];
    if (_total <= 0) return;

    var _dep = {};
    for (var _k = 0; _k < array_length(_f.deployA); _k++) {
        variable_struct_set(_dep, string(_f.deployA[_k]), true);
    }
    for (var _k = 0; _k < array_length(_f.deployB); _k++) {
        variable_struct_set(_dep, string(_f.deployB[_k]), true);
    }

    var _clump = max(1.8, _f.w * 0.22);
    for (var _y = 0; _y < _f.h; _y++) {
        for (var _x = 0; _x < _f.w; _x++) {
            var _i = mst_idx(_f, _x, _y);
            var _inDeploy = variable_struct_exists(_dep, string(_i));

            var _c = _f.cells[_i];
            var _cl = mst_noise2(_f.seed + 104729, _x, _y, _clump);
            // Density is the biome's, modulated by the clump field. The exponent sharpens the
            // clumps without changing the mean much.
            var _p = _bs.density * (0.25 + _cl * _cl * 1.9);
            if (mst_rng_next(_rng) > _p) continue;
            // Impassable ground carries nothing: a boulder does not stand in a river.
            if (_c.cost >= MST_IMPASSABLE) continue;

            var _pick = mst_rng_next(_rng) * _total;
            var _acc = 0;
            var _id = _bs.feats[0][0];
            for (var _k = 0; _k < array_length(_bs.feats); _k++) {
                _acc += _bs.feats[_k][1];
                if (_pick <= _acc) { _id = _bs.feats[_k][0]; break; }
            }

            // ⛔ A DEPLOYMENT ZONE TAKES SCENERY BUT NEVER A BLOCKER. The first version refused to
            // sow into a deployment zone at all, and it was the right instinct applied too widely:
            // a unit that starts inside a wall is the most obvious way a generated map can be
            // unplayable, so an IMPASSABLE feature must never land there. But forbidding everything
            // left two bands of about 29% of the board completely bare, which the hero store sheet
            // showed as a pair of enormous featureless slabs - and a deployment zone with nothing
            // in it is also bad TACTICS, because the first turn of the fight has no cover in it.
            //
            // Passable features only, and no hard cover, so a starting position is never a fortress
            // and never a cage.
            var _sp = mst_feature_spec(_id);
            if (_inDeploy && (is_undefined(_sp) || _sp.cost >= MST_IMPASSABLE
                              || _sp.cover == MST_COVER_HARD)) continue;

            mst_field_place(_f, _x, _y, _id, floor(mst_rng_next(_rng) * 100000));
        }
    }
}

/// ============================================================================================
/// PASSABILITY - Dijkstra, because the costs are not all 1
///
/// ⛔ A BREADTH-FIRST SEARCH WOULD BE WRONG HERE AND WOULD LOOK RIGHT. BFS finds the path with the
/// fewest CELLS; with mud at 2, bramble at 3 and turf at 1 the cheapest path is frequently not the
/// shortest one, and a "shortest path" overlay that disagrees with the movement a unit can actually
/// afford is worse than no overlay. The costs exist, so the search has to respect them.
/// ============================================================================================

/// Cost-to-reach every cell from a set of sources. Returns an array of costs, MST_IMPASSABLE where
/// unreachable.
function mst_field_dist(_f, _sources) {
    var _n = _f.w * _f.h;
    var _d = array_create(_n, MST_IMPASSABLE);
    var _done = array_create(_n, false);
    var _open = 0;
    for (var _k = 0; _k < array_length(_sources); _k++) {
        var _s = _sources[_k];
        if (_s < 0 || _s >= _n) continue;
        if (_f.cells[_s].cost >= MST_IMPASSABLE) continue;
        _d[_s] = 0;
        _open += 1;
    }
    if (_open == 0) return _d;

    // Linear-scan frontier. The grids this product generates are at most a few hundred cells, so
    // an O(n^2) scan is a few tens of thousands of comparisons - far cheaper than the allocation a
    // priority queue would cost in GML, and with no data structure to get wrong.
    while (true) {
        var _best = -1, _bv = MST_IMPASSABLE;
        for (var _i = 0; _i < _n; _i++) {
            if (!_done[_i] && _d[_i] < _bv) { _bv = _d[_i]; _best = _i; }
        }
        if (_best < 0) break;
        _done[_best] = true;
        var _bx = _best % _f.w, _by = _best div _f.w;
        // Four-way. Eight-way movement would make "adjacent" ambiguous for cover and facing, and
        // every incumbent read on this shelf is four- or six-way for the same reason.
        var _dx = [1, -1, 0, 0], _dy = [0, 0, 1, -1];
        for (var _k = 0; _k < 4; _k++) {
            var _nx = _bx + _dx[_k], _ny = _by + _dy[_k];
            if (!mst_in_bounds(_f, _nx, _ny)) continue;
            var _ni = mst_idx(_f, _nx, _ny);
            if (_done[_ni]) continue;
            // ⛔ THE STEP COST COMES FROM mst_step_cost AND IS NOT RECOMPUTED HERE. It was written
            // out inline in the first draft - the same arithmetic, in two places - and that is the
            // shape this factory keeps paying for: a movement overlay and a pathfinder that agree
            // until somebody changes one of them. Climbing costs, descending is free, and there is
            // exactly one copy of that sentence in this package.
            var _alt = _bv + mst_step_cost(_f, _bx, _by, _nx, _ny);
            if (_alt >= MST_IMPASSABLE) continue;
            if (_alt < _d[_ni]) _d[_ni] = _alt;
        }
    }
    return _d;
}

/// Guarantee a route from one deployment zone to the other, clearing features until there is one.
///
/// ⭐ THE REPAIR IS THE FEATURE. A generator that sometimes produces a sealed map and says nothing
/// is a generator a buyer has to write their own validator for - which is most of the work they
/// bought this to avoid. This one clears the CHEAPEST blocking feature nearest the straight line
/// between the two zones, re-tests, and records how many it removed in `field.cleared` so the
/// number is visible rather than hidden.
///
/// ⚠️ AND IT CANNOT LOOP FOREVER. The bound is twice the cell count: every pass either finds a path,
/// removes a feature or regrades a cell, and there are finitely many of both. The `for` bound is
/// written out rather than left as a `while (true)` so a future edit cannot turn a repair into a
/// hang in a buyer's Create event.
///
/// ⛔⛔ THE SECOND REPAIR - REGRADING GROUND - WAS MISSING AND THE IN-ENGINE SUITE FOUND IT.
/// MEASURED on the first headless run: `waste/thaw` and `waste/blighted` came back NOT CROSSABLE,
/// two fields out of sixty-four. The cause is structural rather than a tuning problem. The waste
/// biome puts `basalt` - which is IMPASSABLE GROUND, not a feature - in the top band of its height
/// range, so when the noise happens to run a basalt ridge from edge to edge there is no feature
/// anywhere whose removal opens a route, and a repair that only clears FEATURES correctly runs out
/// of candidates and gives up.
///
/// ⭐ The general shape is worth stating because it is not specific to this product: A REPAIR LOOP
/// CAN ONLY FIX THE CLASS OF THING IT KNOWS HOW TO EDIT, and the first draft here knew about one of
/// the two ways a map can be sealed. It was honest about failing - `pathCost` went to -1 and the
/// suite read it - which is the only reason this is a fixed defect rather than a shipped one.
///
/// So there are now two repairs, cheapest first: clear a feature if one would help, and only if
/// none would, REGRADE an impassable ground cell to a passable material FROM THE SAME BIOME. Both
/// are counted separately in the field, because a map that needed six regrades is a map a scenario
/// writer may want to reject.
function mst_field_connect(_f, _bs) {
    var _n = _f.w * _f.h;
    // The passable ground materials this biome actually uses. Regrading to something from another
    // biome would open the route and put a stripe of foreign ground across the picture.
    var _fallback = [];
    for (var _k = 0; _k < array_length(_bs.ground); _k++) {
        var _gm = mst_ground_alias(_bs.ground[_k][0], _f.season, _f.season_t);
        if (mst_ground_cost(_gm, _f.season, _f.season_t) < MST_IMPASSABLE) array_push(_fallback, _gm);
    }
    if (array_length(_fallback) == 0) array_push(_fallback, "loam");

    for (var _pass = 0; _pass < 2 * _n + 2; _pass++) {
        var _d = mst_field_dist(_f, _f.deployA);
        var _best = MST_IMPASSABLE;
        for (var _k = 0; _k < array_length(_f.deployB); _k++) {
            _best = min(_best, _d[_f.deployB[_k]]);
        }
        if (_best < MST_IMPASSABLE) { _f.pathCost = _best; return _f.cleared; }

        var _cx = (_f.w - 1) * 0.5, _cy = (_f.h - 1) * 0.5;

        // -- REPAIR 1: clear the blocking FEATURE closest to the centre line, which is where a wall
        // is most likely to be the thing sealing the map.
        var _pick = -1, _pd = 999999;
        for (var _i = 0; _i < _n; _i++) {
            var _c = _f.cells[_i];
            if (_c.feat == "" || _c.cost < MST_IMPASSABLE) continue;
            // A cell whose GROUND is impassable cannot be fixed by clearing its feature, so it is
            // not a candidate here - clearing it would burn a pass and change nothing.
            if (mst_ground_cost(_c.ground, _f.season, _f.season_t) >= MST_IMPASSABLE) continue;
            var _x = _i % _f.w, _y = _i div _f.w;
            var _dd = abs(_x - _cx) + abs(_y - _cy);
            if (_dd < _pd) { _pd = _dd; _pick = _i; }
        }
        if (_pick >= 0) {
            mst_field_clear(_f, _pick % _f.w, _pick div _f.w);
            _f.cleared += 1;
            continue;
        }

        // -- REPAIR 2: no feature would help, so the GROUND is what seals it. Regrade the
        // impassable ground cell nearest the centre line to a passable material from this biome,
        // and take any feature standing on it with it.
        var _gpick = -1, _gd = 999999;
        for (var _i = 0; _i < _n; _i++) {
            var _c2 = _f.cells[_i];
            if (mst_ground_cost(_c2.ground, _f.season, _f.season_t) < MST_IMPASSABLE) continue;
            var _x2 = _i % _f.w, _y2 = _i div _f.w;
            var _dd2 = abs(_x2 - _cx) + abs(_y2 - _cy);
            if (_dd2 < _gd) { _gd = _dd2; _gpick = _i; }
        }
        if (_gpick < 0) break; // genuinely nothing left to edit
        var _gc = _f.cells[_gpick];
        // Deterministic choice, so the repair does not break the seed guarantee.
        _gc.ground = _fallback[_gpick % array_length(_fallback)];
        _gc.feat = "";
        _gc.cover = MST_COVER_NONE;
        _gc.los = false;
        _gc.tall = 0;
        _gc.cost = mst_ground_cost(_gc.ground, _f.season, _f.season_t);
        _f.regraded += 1;
    }
    _f.pathCost = -1;
    return _f.cleared;
}

/// ============================================================================================
/// READING THE MAP BACK OFF ITSELF
/// ============================================================================================

/// Chokepoints, and this is a MEASUREMENT rather than a label.
///
/// A cell is on a shortest route when the cost to reach it from one deployment zone plus the cost
/// to reach it from the other equals the cost of the whole crossing. Group those cells by their
/// distance from side A, and a rank holding only one or two of them is a place the whole battle
/// has to funnel through. That is what a chokepoint IS, and it falls out of two distance fields
/// that were going to be computed anyway.
///
/// ⚠️ IT IS AN APPROXIMATION AND THE HEADER SAYS SO RATHER THAN THE LISTING. A true articulation
/// point needs a connectivity test per cell; this finds narrow points on OPTIMAL routes, which is
/// what a tactics player actually cares about and is O(n) instead of O(n squared).
function mst_field_analyse(_f, _rng) {
    var _n = _f.w * _f.h;
    var _da = mst_field_dist(_f, _f.deployA);
    var _db = mst_field_dist(_f, _f.deployB);
    if (_f.pathCost < 0) return;

    var _total = _f.pathCost;
    var _rank = array_create(_total + 2, 0);
    var _member = array_create(_total + 2, -1);
    for (var _i = 0; _i < _n; _i++) {
        if (_da[_i] >= MST_IMPASSABLE || _db[_i] >= MST_IMPASSABLE) continue;
        // A tolerance of one step, because four-way costs are integers and an exact equality would
        // reject cells one cheap sidestep off the optimum - which are still part of the same funnel.
        if (_da[_i] + _db[_i] > _total + 1) continue;
        var _r = _da[_i];
        if (_r < 0 || _r > _total + 1) continue;
        _rank[_r] += 1;
        _member[_r] = _i;
    }
    for (var _r = 1; _r < _total; _r++) {
        if (_rank[_r] > 0 && _rank[_r] <= 2 && _member[_r] >= 0) {
            array_push(_f.chokepoints, _member[_r]);
        }
    }

    // Objectives: one on the highest standable ground, and up to two on chokepoints. A tactics map
    // wants a reason to leave cover, and high ground plus a funnel is the oldest one there is.
    var _hi = -1, _hv = -1;
    for (var _i = 0; _i < _n; _i++) {
        var _c = _f.cells[_i];
        if (_c.cost >= MST_IMPASSABLE) continue;
        if (_da[_i] >= MST_IMPASSABLE) continue;
        if (_c.level > _hv) { _hv = _c.level; _hi = _i; }
    }
    if (_hi >= 0) array_push(_f.objectives, { at: _hi, kind: "height" });
    var _cn = min(2, array_length(_f.chokepoints));
    for (var _k = 0; _k < _cn; _k++) {
        var _pick = _f.chokepoints[floor((_k + 0.5) * array_length(_f.chokepoints) / max(1, _cn))];
        array_push(_f.objectives, { at: _pick, kind: "choke" });
    }
}
