/// MUSTER - mst_tactics. The queries a battle asks the ground.
///
/// -- ⛔ READ THIS BEFORE JUDGING THE SIZE OF THIS FILE -----------------------------------------
/// It is deliberately SMALL, and it is small for a commercial reason rather than a technical one.
///
/// Three paid tactics systems were read in full on this shelf before this package was designed. One
/// of them - a $20 Fire-Emblem-style framework - already ships twenty-one feature-flagged modules
/// including "grid tactics with movement costs, terrain effects and optimized pathfinding", a
/// weapon triangle, a support system, permadeath and a five-chapter demo campaign. Competing with
/// that on RULES would mean writing a thinner version of a product that exists and is maintained,
/// which is the head-on clone this studio does not do.
///
/// ⭐ SO THIS FILE EXISTS FOR EXACTLY ONE REASON: TO MAKE THE PICTURE ANSWERABLE. Every function
/// here reads a value that mst_field wrote at the moment it PLACED the thing that is drawn in that
/// cell. Nothing here holds a rule of its own; there is no table to fall out of step with the art,
/// which is the failure every hand-built tile map eventually has. A buyer who already owns a battle
/// engine keeps it and asks this package what the ground is. A buyer who does not gets enough to
/// prototype with.
///
/// Positioning, and it is honest in both directions: KEEP YOUR BATTLE ENGINE. THIS IS THE GROUND IT
/// IS FOUGHT ON.
/// ============================================================================================

/// What a unit standing in this cell gets from the cell ITSELF.
///
/// ⛔⛔ READ THIS BEFORE USING IT, BECAUSE THE OBVIOUS READING IS WRONG AND IT SHIPPED ONTO A STORE
/// SHEET BEFORE ANYONE NOTICED. `cell.cover` is the cover a feature PROVIDES, and most hard cover
/// is IMPASSABLE - you do not stand in a boulder, you stand behind it. So this function returns
/// NONE for a cell nobody can occupy, and the cover a boulder actually gives is answered by
/// mst_cover_from for the cells AROUND it.
///
/// ⭐ The defect this replaces is worth recording because nothing mechanical could see it. The hero
/// store sheet printed "hard cover 0 cells" over a battlefield visibly full of ruin walls, because
/// mst_field_report classified every impassable cell as `blocked` and moved on BEFORE it looked at
/// cover - and since hard cover is impassable by construction, the hard-cover count could only ever
/// be zero. Every assertion passed: the number was internally consistent, it just described
/// something nobody wanted to know. It was found by reading a rendered figure and disbelieving it.
function mst_cover_at(_f, _x, _y) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return 0;
    var _c = mst_cell(_f, _x, _y);
    if (is_undefined(_c)) return MST_COVER_NONE;
    // Nobody stands here, so nobody is covered here.
    if (_c.cost >= MST_IMPASSABLE) return MST_COVER_NONE;
    return _c.cover;
}

/// The best cover available to a unit standing here, from this cell and its four neighbours.
///
/// This is the number a player reads off a map at a glance - "can I be safe there" - and it is what
/// the cover overlay and the report both count. Direction is not considered; mst_cover_from is the
/// one that answers a specific shot.
function mst_cover_best(_f, _x, _y) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return 0;
    var _c = mst_cell(_f, _x, _y);
    if (is_undefined(_c) || _c.cost >= MST_IMPASSABLE) return MST_COVER_NONE;
    var _best = _c.cover;
    var _dxs = [1, -1, 0, 0], _dys = [0, 0, 1, -1];
    for (var _k = 0; _k < 4; _k++) {
        var _n = mst_cell(_f, _x + _dxs[_k], _y + _dys[_k]);
        if (is_undefined(_n)) continue;
        _best = max(_best, _n.cover);
    }
    return _best;
}

/// What it costs to enter this cell, ignoring where you came from. MST_IMPASSABLE means never.
function mst_cost_at(_f, _x, _y) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return MST_IMPASSABLE;
    var _c = mst_cell(_f, _x, _y);
    if (is_undefined(_c)) return MST_IMPASSABLE;
    return _c.cost;
}

/// Elevation level, 0..MST_LEVELS-1.
function mst_level_at(_f, _x, _y) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return 0;
    var _c = mst_cell(_f, _x, _y);
    if (is_undefined(_c)) return 0;
    return _c.level;
}

/// The full cost of the step from one cell to an adjacent one, including the climb.
///
/// ⚠️ CLIMBING COSTS AND DESCENDING DOES NOT, which is the rule every tactics game a buyer has
/// played uses, and it is the same arithmetic mst_field_dist uses when it guarantees the map is
/// crossable. Writing it twice is how a movement overlay and a pathfinder come to disagree, so
/// mst_field_dist calls THIS - there is one copy.
function mst_step_cost(_f, _fx, _fy, _tx, _ty) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return MST_IMPASSABLE;
    var _to = mst_cell(_f, _tx, _ty);
    var _from = mst_cell(_f, _fx, _fy);
    if (is_undefined(_to) || is_undefined(_from)) return MST_IMPASSABLE;
    if (_to.cost >= MST_IMPASSABLE) return MST_IMPASSABLE;
    return _to.cost + max(0, _to.level - _from.level);
}

/// ============================================================================================
/// LINE OF SIGHT
///
/// A supercover walk from cell centre to cell centre: every cell the line passes through is
/// tested, not just the ones a Bresenham line would step on.
///
/// ⛔ THE DIFFERENCE MATTERS AND IT IS THE COMMONEST BUG IN A HAND-ROLLED TACTICS LOS. A plain
/// Bresenham line cuts a corner diagonally between two walls and reports a clear shot THROUGH the
/// join - so a unit can be shot through the corner of a building. Sampling along the segment at a
/// fine step catches both cells at that corner, which is what a player expects and what the drawn
/// picture says.
///
/// -- HEIGHT ------------------------------------------------------------------------------------
/// A blocker stops sight when its own top is at or above the line between the two eyes. Its top is
/// its cell's LEVEL plus the feature's `tall`, and both of those are the numbers the feature is
/// DRAWN at. So a unit on a level-3 ridge really can see over a level-0 hedge, and cannot see over
/// a level-2 tower, and the picture agrees because the picture is where those numbers came from.
/// ============================================================================================

/// True if _ax,_ay can see _bx,_by. Eyes sit one level above the ground they stand on.
function mst_los(_f, _ax, _ay, _bx, _by) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return false;
    if (!mst_in_bounds(_f, _ax, _ay) || !mst_in_bounds(_f, _bx, _by)) return false;
    if (_ax == _bx && _ay == _by) return true;

    var _ca = mst_cell(_f, _ax, _ay);
    var _cb = mst_cell(_f, _bx, _by);
    var _ha = _ca.level + 1;
    var _hb = _cb.level + 1;

    var _dx = _bx - _ax, _dy = _by - _ay;
    var _len = max(abs(_dx), abs(_dy));
    // Four samples per cell. Fewer lets a thin corner slip between samples; more costs time for a
    // result that cannot change, because a cell is the smallest thing on the board.
    var _steps = max(2, _len * 4);

    for (var _i = 1; _i < _steps; _i++) {
        var _u = _i / _steps;
        var _px = _ax + _dx * _u;
        var _py = _ay + _dy * _u;
        var _cx = round(_px);
        var _cy = round(_py);
        if (_cx == _ax && _cy == _ay) continue;
        if (_cx == _bx && _cy == _by) continue;
        var _c = mst_cell(_f, _cx, _cy);
        if (is_undefined(_c)) continue;
        if (!_c.los && _c.tall == 0) continue;

        // The height of the sight line where it crosses this cell.
        var _lineH = lerp(_ha, _hb, _u);
        // What stands here. A cell with no feature still blocks if the GROUND is higher than the
        // line - a ridge between two valleys is a blocker and carries no feature at all.
        var _blockH = _c.level + (_c.los ? _c.tall : 0);
        if (_blockH >= _lineH) return false;
    }
    // Terrain itself, checked the same way for cells that carry nothing.
    for (var _i = 1; _i < _steps; _i++) {
        var _u = _i / _steps;
        var _cx = round(_ax + _dx * _u);
        var _cy = round(_ay + _dy * _u);
        var _c = mst_cell(_f, _cx, _cy);
        if (is_undefined(_c)) continue;
        if (_c.level >= lerp(_ha, _hb, _u)) return false;
    }
    return true;
}

/// How much cover the DEFENDER gets from this attacker.
///
/// ⚠️ COVER IS DIRECTIONAL, and a system that returns a cell's cover value regardless of where the
/// shot comes from is giving a player a number they will stop trusting in the second fight. A
/// defender behind a wall is exposed from behind it. So the cover that counts is what stands in the
/// cell BETWEEN the two, adjacent to the defender, on the attacker's side.
///
/// ⭐ AND A HIGHER ATTACKER SEES OVER LOW COVER. A unit on a level-2 outcrop shooting down at a
/// unit behind a level-0 drystone wall gets a clear shot, which is the whole reason high ground is
/// worth taking and the reason `tall` had to be a drawn number rather than a flag.
function mst_cover_from(_f, _dx_, _dy_, _ax, _ay) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return 0;
    var _def = mst_cell(_f, _dx_, _dy_);
    if (is_undefined(_def)) return MST_COVER_NONE;
    var _att = mst_cell(_f, _ax, _ay);
    if (is_undefined(_att)) return _def.cover;

    var _vx = _ax - _dx_, _vy = _ay - _dy_;
    if (_vx == 0 && _vy == 0) return MST_COVER_NONE;
    // The one cell step from the defender toward the attacker.
    var _sx = (abs(_vx) >= abs(_vy)) ? sign(_vx) : 0;
    var _sy = (abs(_vy) >  abs(_vx)) ? sign(_vy) : 0;
    var _sh = mst_cell(_f, _dx_ + _sx, _dy_ + _sy);
    if (is_undefined(_sh)) return MST_COVER_NONE;

    var _cov = _sh.cover;
    if (_cov == MST_COVER_NONE) return MST_COVER_NONE;

    // Height: if the attacker's eye is above the top of the shielding cell, the cover drops a step.
    var _eye = _att.level + 1;
    var _topOf = _sh.level + _sh.tall;
    if (_eye > _topOf) _cov = max(MST_COVER_NONE, _cov - 1);
    return _cov;
}

/// True if the attacker has the height advantage over the defender.
function mst_height_edge(_f, _ax, _ay, _dx_, _dy_) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return false;
    return (mst_level_at(_f, _ax, _ay) > mst_level_at(_f, _dx_, _dy_));
}

/// ============================================================================================
/// MOVEMENT
/// ============================================================================================

/// Every cell reachable from (_x,_y) within _budget movement points. Returns an array of costs,
/// MST_IMPASSABLE where out of range or unreachable.
///
/// This is mst_field_dist from one source with a budget, which is exactly what a movement overlay
/// is. It is a separate entry point rather than a flag because a buyer will call it every time a
/// unit is selected and the name should say what it is for.
function mst_move_range(_f, _x, _y, _budget) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return [];
    var _d = mst_field_dist(_f, [mst_idx(_f, _x, _y)]);
    for (var _i = 0; _i < array_length(_d); _i++) {
        if (_d[_i] > _budget) _d[_i] = MST_IMPASSABLE;
    }
    return _d;
}

/// The cheapest route between two cells as an array of [x,y], or an empty array if there is none.
///
/// ⚠️ IT WALKS BACK DOWN THE DISTANCE FIELD RATHER THAN STORING PARENTS, which is correct here
/// because the field is a true shortest-cost field: any neighbour whose cost plus the step back
/// equals this cell's cost is on an optimal route. Storing parents would be faster and would also
/// be a second structure that can disagree with the first.
function mst_path(_f, _ax, _ay, _bx, _by) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return [];
    var _d = mst_field_dist(_f, [mst_idx(_f, _ax, _ay)]);
    var _bi = mst_idx(_f, _bx, _by);
    if (_d[_bi] >= MST_IMPASSABLE) return [];

    var _out = [[_bx, _by]];
    var _cx = _bx, _cy = _by;
    var _guard = _f.w * _f.h + 2;
    while ((_cx != _ax || _cy != _ay) && _guard > 0) {
        _guard -= 1;
        var _here = _d[mst_idx(_f, _cx, _cy)];
        var _dxs = [1, -1, 0, 0], _dys = [0, 0, 1, -1];
        var _moved = false;
        for (var _k = 0; _k < 4; _k++) {
            var _nx = _cx + _dxs[_k], _ny = _cy + _dys[_k];
            if (!mst_in_bounds(_f, _nx, _ny)) continue;
            var _nd = _d[mst_idx(_f, _nx, _ny)];
            if (_nd >= MST_IMPASSABLE) continue;
            if (_nd + mst_step_cost(_f, _nx, _ny, _cx, _cy) == _here) {
                _cx = _nx; _cy = _ny;
                array_insert(_out, 0, [_cx, _cy]);
                _moved = true;
                break;
            }
        }
        // ⛔ A FAILED STEP RETURNS EMPTY RATHER THAN LOOPING. If no neighbour explains this cell's
        // cost the field and the step function disagree, which is a defect in this package rather
        // than in the buyer's call - and a partial path handed back silently would be acted on.
        if (!_moved) return [];
    }
    return _out;
}

/// ============================================================================================
/// A SUMMARY A SCENARIO WRITER CAN READ
/// ============================================================================================

/// One struct describing what kind of fight this field will produce. Not decoration: a buyer
/// generating maps in bulk needs to reject the ones that do not suit the encounter, and these are
/// the four numbers that decide it.
function mst_field_report(_f) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return undefined;
    var _n = _f.w * _f.h;
    var _hard = 0, _soft = 0, _blocked = 0, _open = 0, _sumCost = 0, _passable = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _c = _f.cells[_i];
        if (_c.cost >= MST_IMPASSABLE) { _blocked += 1; continue; }
        _passable += 1;
        _sumCost += _c.cost;
        // ⛔ COUNTS CELLS A UNIT CAN STAND IN AND BE COVERED, NOT CELLS THAT CONTAIN COVER. The
        // first version counted `_c.cover` on the cell itself, which is the cover a feature
        // PROVIDES - and since every hard-cover feature is impassable, the loop had already
        // `continue`d past all of them. It printed "hard cover 0" onto the hero store sheet over a
        // field of ruin walls. See mst_cover_at for the full account.
        var _cov = mst_cover_best(_f, _i % _f.w, _i div _f.w);
        if (_cov == MST_COVER_HARD) _hard += 1;
        else if (_cov == MST_COVER_SOFT) _soft += 1;
        else _open += 1;
    }
    return {
        cells: _n,
        passable: _passable,
        blocked: _blocked,
        hardCover: _hard,
        softCover: _soft,
        openGround: _open,
        // The average cost of standing somewhere. A high number is a slow, grinding map.
        goingRate: (_passable > 0) ? (_sumCost / _passable) : 0,
        // How far the crossing is in movement points. This is what tells a writer whether a fight
        // will be decided in three turns or twelve.
        crossing: _f.pathCost,
        chokepoints: array_length(_f.chokepoints),
        objectives: array_length(_f.objectives),
        // What the generator had to change to guarantee the map is crossable. Surfaced rather than
        // hidden: a generator that quietly repairs its own output is one a buyer cannot audit.
        cleared: _f.cleared,
        regraded: _f.regraded,
        biome: _f.biome,
        season: _f.season,
    };
}
