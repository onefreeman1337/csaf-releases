{
  "$GMScript": "v1",
  "%Name": "mst_tactics",
  "name": "mst_tactics",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}