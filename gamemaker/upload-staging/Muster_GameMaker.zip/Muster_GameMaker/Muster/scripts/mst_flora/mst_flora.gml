/// MUSTER - mst_flora. The fifteen growing features: ten of ground cover and five trees.
///
/// scrub, brackenc, reedbed, cornstand, brambles, furrow, stump, deadfall, mossrock, heathpatch,
/// broadleaf, conifer, snag, pollard, thorntree.
///
/// -- ⭐ THIS IS THE FILE THE SEASON EXISTS FOR ------------------------------------------------
/// Rock has `susc: 0.00` and is the same in February and August, which is correct and is why
/// mst_stone is the season's negative control. EVERYTHING HERE IS THE POSITIVE CONTROL. Turf,
/// meadow, bracken, corn and leaf all carry `susc: 1.00`: a broadleaf tree in `snowbound` is a bare
/// grey armature with white on its limbs, and the same tree in `verdant` is a green mass. If those
/// two look like the same picture in two tints, the product has failed and no amount of listing
/// copy will hide it, because a buyer will bake both and put them side by side.
///
/// ⛔ AND THE FOLIAGE IS NOT DRAWN AS A CIRCLE OF DOTS. Every canopy here is ONE lobed mass with
/// relief on it and a few clumps breaking its silhouette, because a mass reads as a tree at 40 px
/// and a cloud of dots reads as noise. The wing's Charter law - "a note is a constraint on a shape,
/// not a specification of it" - applies with force: "a circle on a stick" is also a lollipop.
/// ============================================================================================

/// A canopy: one lobed mass whose silhouette is broken by three or four sub-lobes rather than by
/// jitter.
///
/// ⚠️ THE LOBES ARE PART OF THE SAME OUTLINE, not separate masses appended after it. Appending
/// them bevels each on its OWN outline and every join grows a lit rim - the wing's "a chain of
/// masses reads as a chain" law, which turned a war horn into three chevrons. Here the radius
/// function itself carries the lobes, so the bevel runs once round the finished silhouette.
/// ⛔⛔ 56 SAMPLES AND A SOFTENED SECOND HARMONIC, AND BOTH NUMBERS WERE PAID FOR AT HERO SCALE.
/// The first version used 30 samples with the second harmonic at 0.34 of the first, and on the
/// corpus sheet at 100 px it read as foliage. On the detail sheet at four times that size the
/// broadleaf came out as a hard-edged ANGULAR STAR - a maple-leaf silhouette with visible straight
/// segments between cusps, which is the one thing a tree canopy must not be.
///
/// Two separate causes, and it is worth separating them because they have different fixes:
///   - TOO FEW SAMPLES. A 30-point ring has 12 degrees between points, so every "curve" is a
///     visible chord at any size above about 120 px. That is a RESOLUTION problem and the fix is
///     more points; they cost nothing, since a canopy is built once and cached by the caller.
///   - THE HARMONIC WAS TOO STRONG. At 0.34 the second wave puts a cusp between every pair of
///     lobes, which is what turned a round mass into a star. At 0.16 it breaks the silhouette
///     without cutting into it.
///
/// ⭐ The general lesson is the wing's Borough law again: a form drawn on a catalogue plate and the
/// same form drawn at size are two different tests. This corpus is used at 60-160 px in a game and
/// at 500 px on a store sheet, so both have to be looked at.
function mst_canopy_pts(_cx, _cy, _rx, _ry, _lobes, _depth, _rng) {
    var _n = 56;
    var _out = array_create(_n);
    var _phase = mst_rng_next(_rng) * MST_TAU;
    var _lb = max(2, _lobes);
    for (var _i = 0; _i < _n; _i++) {
        var _a = (_i / _n) * MST_TAU;
        // One slow lobe wave plus a faster, weaker one. Two frequencies is what stops a canopy
        // reading as a flower; keeping the second one weak is what stops it reading as a star.
        var _k = 1
               + cos(_a * _lb + _phase) * _depth
               + cos(_a * (_lb * 2 + 1) - _phase) * _depth * 0.16;
        _out[_i] = [_cx + cos(_a) * _rx * _k, _cy + sin(_a) * _ry * _k];
    }
    return _out;
}

/// A stand of upright stems: reeds, corn, bracken fronds. Each stem is a tapered ribbon that
/// leans, and the leans are correlated because wind is.
///
/// ⚠️ THE CORRELATION IS THE DETAIL THAT MAKES IT A FIELD RATHER THAN A LOOP. Independently random
/// leans read as static; a shared bias with a small individual variation reads as a crop with the
/// wind across it.
function mst_stems(_x0, _x1, _ybase, _hgt, _count, _lean, _wobble, _wid, _rng) {
    var _out = [];
    var _n = max(2, _count);
    for (var _i = 0; _i < _n; _i++) {
        var _u = (_i + 0.5) / _n;
        var _sx = lerp(_x0, _x1, _u) + (mst_rng_next(_rng) * 2 - 1) * (_x1 - _x0) * 0.35 / _n;
        var _sh = _hgt * (0.68 + mst_rng_next(_rng) * 0.42);
        var _ln = _lean + (mst_rng_next(_rng) * 2 - 1) * _wobble;
        var _pts = array_create(5);
        for (var _k = 0; _k < 5; _k++) {
            var _v = _k / 4;
            // The bend accelerates toward the tip, which is how a stem loaded at one end behaves.
            _pts[_k] = [_sx + _ln * _sh * _v * _v, _ybase - _sh * _v];
        }
        mst_append(_out, mst_taper_ribbon(_pts, _wid, _wid * 0.22, "m2"));
    }
    return _out;
}

/// A trunk with limbs. Returns the trunk outline and the limb spines separately, because the
/// canopy has to be drawn between them.
function mst_trunk_parts(_x, _ybase, _ytop, _wbot, _lean, _rng) {
    var _pts = mst_shaft_pts(_x, _ybase, _ytop, _wbot, _wbot * 0.30, _lean, 6);
    var _out = mst_raise(_pts, mst_bevel_cap(_pts, _wbot * 0.26), 3, "m2");
    // Bark: vertical incisions that FOLLOW the lean, never straight down a leaning trunk.
    for (var _k = 0; _k < 3; _k++) {
        var _u = 0.26 + _k * 0.24;
        var _bp = array_create(4);
        for (var _m = 0; _m < 4; _m++) {
            var _v = 0.10 + (_m / 3) * 0.76;
            _bp[_m] = [_x + _lean * _v * _v + (_u - 0.5) * _wbot * (1 - _v * 0.6),
                       lerp(_ybase, _ytop, _v)];
        }
        mst_append(_out, mst_incise(_bp, false, _wbot * 0.10));
    }
    // A root flare, which is what stops a trunk reading as a pipe stuck in the ground.
    var _fl = [[_x - _wbot * 0.95, _ybase], [_x - _wbot * 0.40, _ybase - _wbot * 0.55],
               [_x + _wbot * 0.40, _ybase - _wbot * 0.55], [_x + _wbot * 0.95, _ybase]];
    mst_append(_out, mst_raise(_fl, _wbot * 0.16, 2, "m2"));
    return _out;
}

function mst_flora_parts(_id, _sp, _rng, _season, _t) {
    var _out = [];
    var _g = MST_GROUND;
    var _x0 = -_sp.w * 0.5, _x1 = _sp.w * 0.5;
    var _top = _g - _sp.h;

    switch (_id) {
        case "scrub": {
            // A woody bush: two or three canopy lobes over a visible tangle of stems, so it reads
            // as a plant and not as a green rock.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.48));
            var _stems = [];
            for (var _k = 0; _k < 5; _k++) {
                var _sx = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.22;
                mst_append(_stems, mst_taper_ribbon(
                    [[_sx * 0.3, _g], [_sx * 0.8, _g - _sp.h * 0.30], [_sx, _g - _sp.h * 0.55]],
                    _sp.w * 0.020, _sp.w * 0.010, "m1"));
            }
            mst_append(_out, mst_map_roles(_stems, mst_ground_map("b")));
            var _leaves = [];
            var _lob = [[0.00, 0.62, 1.00], [-0.26, 0.42, 0.62], [0.28, 0.40, 0.58]];
            for (var _i = 0; _i < 3; _i++) {
                var _b = _lob[_i];
                var _cpts = mst_canopy_pts(_sp.w * _b[0], _g - _sp.h * _b[1],
                                           _sp.w * 0.30 * _b[2], _sp.h * 0.32 * _b[2],
                                           4, 0.16, _rng);
                mst_append(_leaves, mst_raise(_cpts, mst_bevel_cap(_cpts, _sp.h * 0.06), 3, "m2"));
            }
            mst_append(_out, mst_map_roles(_leaves, mst_ground_map("a")));
        } break;

        case "brackenc": {
            // Fern. The subject is the FROND SHAPE - an arch that droops - and a clump of arches is
            // instantly bracken where a clump of blobs is instantly nothing.
            var _fr = [];
            var _n = 11;
            for (var _i = 0; _i < _n; _i++) {
                var _u = (_i + 0.5) / _n;
                var _sx = lerp(_x0 * 0.90, _x1 * 0.90, _u);
                var _dir = (_u < 0.5) ? -1 : 1;
                var _sh = _sp.h * (0.66 + mst_rng_next(_rng) * 0.40);
                var _pts = array_create(6);
                for (var _k = 0; _k < 6; _k++) {
                    var _v = _k / 5;
                    // Up, then over: the arch is in the y term easing off while x keeps going.
                    _pts[_k] = [_sx + _dir * _sh * 0.62 * _v * _v,
                                _g - _sh * sin(_v * 1.32)];
                }
                mst_append(_fr, mst_taper_ribbon(_pts, _sp.w * 0.026, _sp.w * 0.004, "m2"));
                // Pinnae: short ticks along the outer half of the arch.
                for (var _k = 2; _k < 6; _k++) {
                    var _p = _pts[_k];
                    var _len = _sp.w * 0.048 * (1 - (_k - 2) / 5);
                    mst_append(_fr, mst_poly([[_p[0], _p[1]], [_p[0] - _dir * _len * 0.4, _p[1] + _len]],
                                             false, _sp.w * 0.012, "m1"));
                    mst_append(_fr, mst_poly([[_p[0], _p[1]], [_p[0] - _dir * _len * 0.4, _p[1] - _len]],
                                             false, _sp.w * 0.012, "m3"));
                }
            }
            mst_append(_out, mst_map_roles(_fr, mst_ground_map("a")));
            var _lit = [];
            for (var _i = 0; _i < 4; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.40;
                var _pr = _sp.w * (0.030 + mst_rng_next(_rng) * 0.026);
                mst_append(_lit, mst_ring_fill(mst_pool_pts(_px, _g - _sp.h * 0.03, _pr, _pr * 0.5,
                                                            8, 0.28, _rng), "m1", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_lit, mst_ground_map("b")));
        } break;

        case "reedbed": {
            // Reeds standing in water. The WATER at the foot is what makes it a reed bed rather
            // than long grass, and it is drawn first so the stems stand in it.
            var _wat = mst_pool_pts(0, _g - _sp.h * 0.035, _sp.w * 0.50, _sp.h * 0.075, 18, 0.12, _rng);
            mst_append(_out, mst_map_roles(mst_ring_fill(_wat, "m1", undefined, undefined),
                                           mst_ground_map("c")));
            var _mud = [];
            for (var _i = 0; _i < 4; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.40;
                var _pr = _sp.w * (0.035 + mst_rng_next(_rng) * 0.030);
                mst_append(_mud, mst_ring_fill(mst_pool_pts(_px, _g - _sp.h * 0.02, _pr, _pr * 0.42,
                                                            8, 0.24, _rng), "m2", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_mud, mst_ground_map("b")));
            var _rd = mst_stems(_x0 * 0.94, _x1 * 0.94, _g - _sp.h * 0.02, _sp.h * 0.94,
                                16, 0.10, 0.08, _sp.w * 0.014, _rng);
            // Seed heads: a small dark lens at the tip of about a third of the stems.
            for (var _i = 0; _i < 6; _i++) {
                var _hx = lerp(_x0 * 0.85, _x1 * 0.85, mst_rng_next(_rng));
                var _hy = _g - _sp.h * (0.70 + mst_rng_next(_rng) * 0.24);
                mst_append(_rd, mst_ring_fill(mst_pool_pts(_hx, _hy, _sp.w * 0.020, _sp.h * 0.048,
                                                           9, 0.10, _rng), "m1", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_rd, mst_ground_map("a")));
        } break;

        case "cornstand": {
            // Standing crop: dense vertical stems with a heavy head, and a visible ROW structure,
            // because a field is planted in rows and that is what distinguishes it from meadow.
            var _cn = [];
            var _rows = 3;
            for (var _r = 0; _r < _rows; _r++) {
                var _ry = _g - _sp.h * 0.03 * _r;
                var _hh = _sp.h * (0.78 + _r * 0.08);
                mst_append(_cn, mst_stems(_x0 * 0.94, _x1 * 0.94, _ry, _hh,
                                          7, 0.07, 0.05, _sp.w * 0.017, _rng));
            }
            mst_append(_out, mst_map_roles(_cn, mst_ground_map("a")));
            var _ears = [];
            for (var _i = 0; _i < 11; _i++) {
                var _hx = lerp(_x0 * 0.88, _x1 * 0.88, (_i + 0.5) / 11)
                        + (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.03;
                var _hy = _g - _sp.h * (0.66 + mst_rng_next(_rng) * 0.28);
                var _ep = mst_pool_pts(_hx, _hy, _sp.w * 0.026, _sp.h * 0.075, 10, 0.08, _rng);
                mst_append(_ears, mst_raise(_ep, _sp.w * 0.010, 2, "m3"));
                // The awn: a fine line off the top of the ear.
                mst_append(_ears, mst_poly([[_hx, _hy - _sp.h * 0.075],
                                            [_hx + _sp.w * 0.02, _hy - _sp.h * 0.15]],
                                           false, _sp.w * 0.008, "m4"));
            }
            mst_append(_out, mst_map_roles(_ears, mst_ground_map("a")));
            var _soil = [];
            for (var _i = 0; _i < 3; _i++) {
                var _yy = _g - _sp.h * 0.012 * _i;
                mst_append(_soil, mst_incise([[_x0 * 0.96, _yy], [_x1 * 0.96, _yy]],
                                             false, _sp.h * 0.022));
            }
            mst_append(_out, mst_map_roles(_soil, mst_ground_map("b")));
        } break;

        case "brambles": {
            // A thicket: long arching canes that cross. The CROSSINGS are the picture - parallel
            // arcs read as a hedge, crossed ones read as impassable.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.46));
            var _cane = [];
            var _n2 = 9;
            for (var _i = 0; _i < _n2; _i++) {
                var _sx = lerp(_x0 * 0.90, _x1 * 0.90, mst_rng_next(_rng));
                var _dir = (mst_rng_next(_rng) < 0.5) ? -1 : 1;
                var _sh = _sp.h * (0.62 + mst_rng_next(_rng) * 0.46);
                var _rch = _sp.w * (0.24 + mst_rng_next(_rng) * 0.26) * _dir;
                var _pts = array_create(7);
                for (var _k = 0; _k < 7; _k++) {
                    var _v = _k / 6;
                    // Up and over: the classic bramble arch, tip returning toward the ground.
                    _pts[_k] = [_sx + _rch * _v, _g - _sh * sin(_v * 2.5)];
                }
                mst_append(_cane, mst_taper_ribbon(_pts, _sp.w * 0.019, _sp.w * 0.006, "m2"));
            }
            mst_append(_out, mst_map_roles(_cane, mst_ground_map("b")));
            var _lf = [];
            for (var _i = 0; _i < 14; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.44;
                var _py = _g - _sp.h * (0.12 + mst_rng_next(_rng) * 0.72);
                var _pr = _sp.w * (0.030 + mst_rng_next(_rng) * 0.026);
                var _lp = mst_canopy_pts(_px, _py, _pr, _pr * 0.86, 3, 0.24, _rng);
                mst_append(_lf, mst_ring_fill(_lp, "m2", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_lf, mst_ground_map("c")));
            // Thorns: short ticks on the canes, the reason this costs 3 to enter.
            var _th = [];
            for (var _i = 0; _i < 16; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.44;
                var _py = _g - _sp.h * (0.14 + mst_rng_next(_rng) * 0.70);
                var _a = mst_rng_next(_rng) * MST_TAU;
                mst_append(_th, mst_poly([[_px, _py],
                                          [_px + cos(_a) * _sp.w * 0.026,
                                           _py + sin(_a) * _sp.w * 0.026]],
                                         false, _sp.w * 0.009, "m0"));
            }
            mst_append(_out, mst_map_roles(_th, mst_ground_map("a")));
        } break;

        case "furrow": {
            // Ploughed ground. Lying flat, no contact shadow. The ridges are BANKS, which is what
            // makes them catch the lamp on one side and read as earth rather than as stripes.
            var _rd2 = [];
            var _n3 = 6;
            for (var _i = 0; _i < _n3; _i++) {
                var _u = (_i + 0.5) / _n3;
                var _yy = _g - _sp.h * (1 - _u) * 0.92;
                var _hh = _sp.h * (0.16 + _u * 0.10);
                var _bp = mst_bank_pts(_x0 * 0.98, _x1 * 0.98, _yy, _hh, 1.0, 10, _rng);
                mst_append(_rd2, mst_raise(_bp, _hh * 0.44, 2, "m2"));
            }
            mst_append(_out, mst_map_roles(_rd2, mst_ground_map("a")));
            // Stubble and clods in the bottoms.
            var _cl = [];
            for (var _i = 0; _i < 9; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.44;
                var _py = _g - _sp.h * mst_rng_next(_rng) * 0.86;
                var _pr = _sp.w * (0.014 + mst_rng_next(_rng) * 0.016);
                mst_append(_cl, mst_ring_fill(mst_pool_pts(_px, _py, _pr, _pr * 0.6, 7, 0.30, _rng),
                                              "m1", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_cl, mst_ground_map("c")));
        } break;

        case "stump": {
            // A cut stump. The RING pattern on the cut face is the subject and it is an ELLIPSE
            // because you are looking down at it; concentric circles would read as a target.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.62));
            var _body = mst_shaft_pts(0, _g, _g - _sp.h * 0.80, _sp.w, _sp.w * 0.86, 0, 3);
            var _bk = mst_raise(_body, mst_bevel_cap(_body, _sp.w * 0.14), 3, "m2");
            for (var _k = 0; _k < 4; _k++) {
                var _bx = lerp(-_sp.w * 0.40, _sp.w * 0.40, _k / 3);
                mst_append(_bk, mst_incise([[_bx, _g - _sp.h * 0.06], [_bx, _g - _sp.h * 0.72]],
                                           false, _sp.w * 0.048));
            }
            mst_append(_out, mst_map_roles(_bk, mst_ground_map("a")));
            var _face = mst_pool_pts(0, _g - _sp.h * 0.80, _sp.w * 0.43, _sp.h * 0.16, 18, 0.05, _rng);
            var _cut = mst_raise(_face, _sp.h * 0.030, 2, "m3");
            for (var _k = 1; _k <= 3; _k++) {
                var _kk = _k / 4;
                mst_append(_cut, mst_incise(
                    mst_pool_pts(_sp.w * 0.02 * _kk, _g - _sp.h * 0.80 + _sp.h * 0.01 * _kk,
                                 _sp.w * 0.43 * (1 - _kk * 0.82), _sp.h * 0.16 * (1 - _kk * 0.82),
                                 14, 0, undefined),
                    true, _sp.h * 0.018));
            }
            // The split a felling axe leaves.
            mst_append(_cut, mst_incise([[-_sp.w * 0.36, _g - _sp.h * 0.82],
                                         [_sp.w * 0.20, _g - _sp.h * 0.78]],
                                        false, _sp.h * 0.024));
            mst_append(_out, mst_map_roles(_cut, mst_ground_map("b")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(0, _g - _sp.h * 0.26, _sp.w * 0.40, _sp.h * 0.20, 3, _rng),
                mst_ground_map("c")));
        } break;

        case "deadfall": {
            // A fallen trunk lying across the cell. It TAPERS along its length and its root plate
            // is at one end, which is what says "fell" rather than "was cut and left".
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.50));
            var _sp4 = array_create(8);
            for (var _k = 0; _k < 8; _k++) {
                var _u = _k / 7;
                _sp4[_k] = [lerp(_x0 * 0.98, _x1 * 0.98, _u),
                            _g - _sp.h * 0.44 + sin(_u * 2.4) * _sp.h * 0.10];
            }
            var _log = mst_taper_ribbon(_sp4, _sp.h * 0.30, _sp.h * 0.15, "m2");
            var _trunk = [_log];
            // Relief on a strip is not automatic, so the highlight and shadow are two more strips
            // offset along the lamp. Three parallel strips is the composite stroke this wing warns
            // about on TIGHT curves; a fallen trunk is a slack curve and it is safe here.
            var _hi = array_create(8), _lo = array_create(8);
            for (var _k = 0; _k < 8; _k++) {
                _hi[_k] = [_sp4[_k][0], _sp4[_k][1] - _sp.h * 0.14];
                _lo[_k] = [_sp4[_k][0], _sp4[_k][1] + _sp.h * 0.16];
            }
            mst_append(_trunk, mst_taper_ribbon(_hi, _sp.h * 0.075, _sp.h * 0.035, "m4"));
            mst_append(_trunk, mst_taper_ribbon(_lo, _sp.h * 0.065, _sp.h * 0.030, "m0"));
            // Snapped limbs.
            for (var _k = 0; _k < 3; _k++) {
                var _u = 0.30 + _k * 0.22;
                var _bi = floor(_u * 7);
                var _p = _sp4[_bi];
                mst_append(_trunk, mst_taper_ribbon(
                    [[_p[0], _p[1]], [_p[0] + _sp.w * 0.06, _p[1] - _sp.h * 0.26],
                     [_p[0] + _sp.w * 0.13, _p[1] - _sp.h * 0.40]],
                    _sp.h * 0.055, _sp.h * 0.014, "m2"));
            }
            mst_append(_out, mst_map_roles(_trunk, mst_ground_map("a")));
            // The root plate: a ragged disc standing on end at the left.
            var _rp = mst_canopy_pts(_x0 * 0.92, _g - _sp.h * 0.48, _sp.w * 0.12, _sp.h * 0.46,
                                     5, 0.24, _rng);
            mst_append(_out, mst_map_roles(mst_raise(_rp, _sp.h * 0.05, 2, "m1"),
                                           mst_ground_map("c")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(_sp.w * 0.10, _g - _sp.h * 0.42, _sp.w * 0.34, _sp.h * 0.16, 4, _rng),
                mst_ground_map("b")));
        } break;

        case "mossrock": {
            // A stone the moss has taken. Same body as a boulder, but the growth is the SUBJECT -
            // it covers the top, which is where rain sits, rather than the shaded side.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.50));
            var _cy = _g - _sp.h * 0.50;
            mst_append(_out, mst_map_roles(
                mst_rock_body(0, _cy, _sp.w * 0.5, _sp.h * 0.5, 11, 0.14, _rng),
                mst_ground_map("b")));
            // A cap of moss over the crown, following the rock's own curve.
            var _cap = [];
            var _n4 = 14;
            for (var _k = 0; _k <= _n4; _k++) {
                var _u = _k / _n4;
                var _a = pi + mst_half_turn(_u);
                _cap[_k] = [cos(_a) * _sp.w * 0.47, _cy + sin(_a) * _sp.h * 0.47];
            }
            for (var _k = _n4; _k >= 0; _k--) {
                var _u2 = _k / _n4;
                var _a2 = pi + mst_half_turn(_u2);
                var _sag = 0.62 + sin(pi * _u2) * 0.30;
                _cap[array_length(_cap)] = [cos(_a2) * _sp.w * 0.47 * _sag,
                                            _cy + sin(_a2) * _sp.h * 0.47 * _sag + _sp.h * 0.10];
            }
            mst_append(_out, mst_map_roles(mst_raise(_cap, _sp.h * 0.045, 2, "m2"),
                                           mst_ground_map("a")));
            var _spr = [];
            for (var _i = 0; _i < 6; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.40;
                var _py = _cy + _sp.h * (0.04 + mst_rng_next(_rng) * 0.34);
                var _pr = _sp.w * (0.024 + mst_rng_next(_rng) * 0.020);
                mst_append(_spr, mst_ring_fill(mst_pool_pts(_px, _py, _pr, _pr * 0.7, 8, 0.30, _rng),
                                               "m3", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_spr, mst_ground_map("c")));
        } break;

        default: { // heathpatch
            // Low woody scrub lying across the ground: many tiny mounds, not one mass. Cost 2 with
            // no cover, which is the "slows you and hides nobody" cell a tactics map needs.
            var _tuft = [];
            var _n5 = 16;
            for (var _i = 0; _i < _n5; _i++) {
                var _px = lerp(_x0 * 0.94, _x1 * 0.94, (_i + 0.5) / _n5)
                        + (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.03;
                var _v = mst_rng_next(_rng);
                var _py = _g - _sp.h * (1 - _v * _v) * 0.80;
                var _pr = _sp.w * (0.032 + mst_rng_next(_rng) * 0.026);
                var _tp = mst_canopy_pts(_px, _py, _pr, _pr * 0.62, 4, 0.22, _rng);
                mst_append(_tuft, mst_raise(_tp, _pr * 0.30, 2, "m2"));
            }
            mst_append(_out, mst_map_roles(_tuft, mst_ground_map("a")));
            var _bare = [];
            for (var _i = 0; _i < 6; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.44;
                var _pr = _sp.w * (0.026 + mst_rng_next(_rng) * 0.024);
                mst_append(_bare, mst_ring_fill(
                    mst_pool_pts(_px, _g - _sp.h * mst_rng_next(_rng) * 0.74, _pr, _pr * 0.5, 8, 0.30, _rng),
                    "m1", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_bare, mst_ground_map("b")));
        } break;
    }
    return _out;
}

/// Half a turn, used by the moss cap above. Named rather than inlined because writing the sweep
/// twice at two call sites is how the two halves of a cap silently stop matching.
///
/// ⛔ IT CARRIES THE PRODUCT PREFIX AND THAT IS NOT STYLE. GML's global namespace is FLAT: a
/// function called `u_pi_span` in a package a buyer imports will collide with any function of that
/// name already in their project, and the failure is a compile error in THEIR code pointing at a
/// file they did not write - a support ticket that cannot be debugged remotely. This one was
/// written unprefixed on the first pass and caught by the namespace sweep, which is why the sweep
/// runs before every gate rather than at the end.
function mst_half_turn(_u) {
    return _u * pi;
}

/// ============================================================================================
/// TREES
///
/// ⛔ THE FIVE TREES MUST BE DISTINGUISHABLE IN SILHOUETTE ALONE, because on a battlefield they
/// are seen small, against ground, and often overlapping. That is why the differences here are in
/// the OUTLINE - a broadleaf is wider than tall above the crown, a conifer is a triangle, a snag
/// has no canopy at all, a pollard is a fist of shoots on a stub, a thorn is asymmetric and swept.
/// The wing's Forage law states the reason: a difference drawn INSIDE a filled shape is not a
/// difference in the shape, and at game size nobody counts leaves.
/// ============================================================================================

function mst_tree_parts(_id, _sp, _rng, _season, _t) {
    var _out = [];
    var _g = MST_GROUND;
    var _top = _g - _sp.h;

    switch (_id) {
        case "broadleaf": {
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.44));
            var _lean = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.06;
            mst_append(_out, mst_map_roles(
                mst_trunk_parts(0, _g, _g - _sp.h * 0.52, _sp.w * 0.11, _lean, _rng),
                mst_ground_map("b")));
            // Limbs, drawn before the canopy so the canopy sits on them.
            var _limb = [];
            for (var _k = 0; _k < 4; _k++) {
                var _dir = (_k % 2 == 0) ? -1 : 1;
                var _u = 0.40 + (_k div 2) * 0.14;
                var _bx = _lean * _u * _u;
                var _by = _g - _sp.h * _u;
                mst_append(_limb, mst_taper_ribbon(
                    [[_bx, _by], [_bx + _dir * _sp.w * 0.14, _by - _sp.h * 0.10],
                     [_bx + _dir * _sp.w * 0.26, _by - _sp.h * 0.16]],
                    _sp.w * 0.030, _sp.w * 0.008, "m2"));
            }
            mst_append(_out, mst_map_roles(_limb, mst_ground_map("b")));
            // The crown: WIDER THAN TALL, which is the whole silhouette difference from a conifer.
            var _cy = _g - _sp.h * 0.70;
            var _cpts = mst_canopy_pts(_lean * 0.5, _cy, _sp.w * 0.48, _sp.h * 0.30, 5, 0.19, _rng);
            var _crown = mst_raise(_cpts, mst_bevel_cap(_cpts, _sp.h * 0.05), 3, "m2");
            // ⛔ THE UNDERSIDE IS ONE SHADOW LENS, NOT TWO DARK PATCHES. The first version put two
            // small dark blobs inside the crown to suggest depth, and at hero scale they read as
            // HOLES in the foliage - two isolated dark spots with lit mass all round them, which is
            // what a hole looks like and not what shade looks like. A canopy is shadowed on its
            // UNDERSIDE, in one continuous region, because that is the part the sky does not reach.
            // Drawn as a wide shallow lens sitting low in the mass and inset from the silhouette, so
            // the lit rim survives all the way round.
            var _shp = mst_canopy_pts(_lean * 0.5, _cy + _sp.h * 0.13,
                                      _sp.w * 0.36, _sp.h * 0.11, 4, 0.14, _rng);
            mst_append(_crown, mst_ring_fill(_shp, "m1", undefined, undefined));
            mst_append(_out, mst_map_roles(_crown, mst_ground_map("a")));
        } break;

        case "conifer": {
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.42));
            mst_append(_out, mst_map_roles(
                mst_trunk_parts(0, _g, _g - _sp.h * 0.30, _sp.w * 0.10, 0, _rng),
                mst_ground_map("b")));
            // Whorls of branches, narrowing to a spire. Each whorl is a SEPARATE mass here on
            // purpose - a conifer really is a stack of tiers and the steps in the silhouette are
            // the identifying feature, so the "chain of masses" caution does not apply.
            var _fol = [];
            var _tiers = 6;
            for (var _k = 0; _k < _tiers; _k++) {
                var _u = _k / (_tiers - 1);
                var _ty = _g - _sp.h * (0.22 + _u * 0.74);
                var _tw = _sp.w * 0.5 * (1 - _u * 0.86);
                var _th = _sp.h * 0.16 * (1 - _u * 0.36);
                var _sag = _th * 0.55;
                var _pts = [[-_tw, _ty], [-_tw * 0.45, _ty - _th * 0.55], [0, _ty - _th],
                            [_tw * 0.45, _ty - _th * 0.55], [_tw, _ty],
                            [_tw * 0.42, _ty + _sag * 0.5], [0, _ty + _sag],
                            [-_tw * 0.42, _ty + _sag * 0.5]];
                mst_append(_fol, mst_raise(_pts, mst_bevel_cap(_pts, _th * 0.24), 2, "m2"));
            }
            // The leader: a spike above the top whorl, which is what finishes a conifer.
            var _lp = [[-_sp.w * 0.045, _top + _sp.h * 0.10], [0, _top],
                       [_sp.w * 0.045, _top + _sp.h * 0.10]];
            mst_append(_fol, mst_raise(_lp, _sp.w * 0.014, 2, "m3"));
            mst_append(_out, mst_map_roles(_fol, mst_ground_map("a")));
        } break;

        case "snag": {
            // Dead standing timber: NO canopy at all, which is the whole silhouette. Bare limbs
            // that are broken at different lengths, because a dead tree loses its tips first.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.40));
            var _lean2 = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.10;
            var _bd = mst_trunk_parts(0, _g, _top + _sp.h * 0.16, _sp.w * 0.13, _lean2, _rng);
            // A broken crown, not a point.
            var _tx = _lean2;
            var _brk = [[_tx - _sp.w * 0.05, _top + _sp.h * 0.16],
                        [_tx - _sp.w * 0.01, _top + _sp.h * 0.04],
                        [_tx + _sp.w * 0.03, _top + _sp.h * 0.12],
                        [_tx + _sp.w * 0.05, _top + _sp.h * 0.19]];
            mst_append(_bd, mst_poly(_brk, false, _sp.w * 0.022, "m1"));
            for (var _k = 0; _k < 5; _k++) {
                var _dir = (_k % 2 == 0) ? -1 : 1;
                var _u = 0.34 + _k * 0.12;
                var _bx = _lean2 * _u * _u;
                var _by = _g - _sp.h * _u;
                var _rch = _sp.w * (0.16 + mst_rng_next(_rng) * 0.24) * _dir;
                mst_append(_bd, mst_taper_ribbon(
                    [[_bx, _by], [_bx + _rch * 0.6, _by - _sp.h * 0.09],
                     [_bx + _rch, _by - _sp.h * 0.13]],
                    _sp.w * 0.026, _sp.w * 0.005, "m2"));
            }
            mst_append(_out, mst_map_roles(_bd, mst_ground_map("a")));
            var _rot = [];
            for (var _i = 0; _i < 5; _i++) {
                var _py = _g - _sp.h * (0.10 + mst_rng_next(_rng) * 0.60);
                var _px = _lean2 * 0.4 + (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.05;
                var _pr = _sp.w * (0.018 + mst_rng_next(_rng) * 0.016);
                mst_append(_rot, mst_sink(mst_pool_pts(_px, _py, _pr, _pr * 1.3, 8, 0.20, _rng),
                                          _pr * 0.34, 2, "m0"));
            }
            mst_append(_out, mst_map_roles(_rot, mst_ground_map("b")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(0, _g - _sp.h * 0.20, _sp.w * 0.20, _sp.h * 0.16, 3, _rng),
                mst_ground_map("c")));
        } break;

        case "pollard": {
            // A tree cut back to its trunk every few years: a thick knuckled stub with a FIST of
            // straight shoots on top. Unmistakable, and completely different in outline from
            // anything else in the corpus.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.46));
            var _stub = mst_shaft_pts(0, _g, _g - _sp.h * 0.52, _sp.w * 0.24, _sp.w * 0.30, 0, 4);
            var _bd2 = mst_raise(_stub, mst_bevel_cap(_stub, _sp.w * 0.07), 3, "m2");
            // The knuckle: a swollen head where it has been cut year after year.
            var _kn = mst_canopy_pts(0, _g - _sp.h * 0.54, _sp.w * 0.21, _sp.h * 0.09, 5, 0.20, _rng);
            mst_append(_bd2, mst_raise(_kn, _sp.w * 0.045, 3, "m3"));
            mst_append(_out, mst_map_roles(_bd2, mst_ground_map("b")));
            var _shoot = [];
            var _n6 = 9;
            for (var _i = 0; _i < _n6; _i++) {
                var _u = (_i + 0.5) / _n6;
                var _sx = lerp(-_sp.w * 0.17, _sp.w * 0.17, _u);
                var _sh = _sp.h * (0.20 + mst_rng_next(_rng) * 0.16);
                var _fan = (_u - 0.5) * _sp.w * 0.30;
                mst_append(_shoot, mst_taper_ribbon(
                    [[_sx, _g - _sp.h * 0.56], [_sx + _fan * 0.5, _g - _sp.h * 0.56 - _sh * 0.6],
                     [_sx + _fan, _g - _sp.h * 0.56 - _sh]],
                    _sp.w * 0.018, _sp.w * 0.005, "m2"));
            }
            mst_append(_out, mst_map_roles(_shoot, mst_ground_map("b")));
            var _lv = [];
            for (var _i = 0; _i < 8; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.28;
                var _py = _g - _sp.h * (0.62 + mst_rng_next(_rng) * 0.28);
                var _pr = _sp.w * (0.038 + mst_rng_next(_rng) * 0.028);
                mst_append(_lv, mst_ring_fill(mst_canopy_pts(_px, _py, _pr, _pr * 0.78, 4, 0.22, _rng),
                                              "m2", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_lv, mst_ground_map("a")));
        } break;

        default: { // thorntree
            // Wind-swept: the canopy is offset hard to one side and flat on top, the trunk leans
            // into it. Asymmetry is the silhouette.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.40));
            var _sw = (mst_rng_next(_rng) < 0.5) ? -1 : 1;
            var _lean3 = _sw * _sp.w * 0.16;
            mst_append(_out, mst_map_roles(
                mst_trunk_parts(-_lean3 * 0.5, _g, _g - _sp.h * 0.48, _sp.w * 0.10, _lean3, _rng),
                mst_ground_map("b")));
            var _limb2 = [];
            for (var _k = 0; _k < 4; _k++) {
                var _u = 0.34 + _k * 0.11;
                var _bx = -_lean3 * 0.5 + _lean3 * _u * _u;
                var _by = _g - _sp.h * _u;
                mst_append(_limb2, mst_taper_ribbon(
                    [[_bx, _by], [_bx + _sw * _sp.w * 0.12, _by - _sp.h * 0.08],
                     [_bx + _sw * _sp.w * 0.24, _by - _sp.h * 0.10]],
                    _sp.w * 0.024, _sp.w * 0.006, "m2"));
            }
            mst_append(_out, mst_map_roles(_limb2, mst_ground_map("b")));
            // A flat-topped crown pushed downwind. The FLAT TOP is what a prevailing wind does and
            // it is the difference a player reads at 40 px.
            var _cx2 = _sw * _sp.w * 0.16;
            var _cy2 = _g - _sp.h * 0.66;
            var _n7 = 24;
            var _cp = array_create(_n7);
            for (var _i = 0; _i < _n7; _i++) {
                var _a = (_i / _n7) * MST_TAU;
                var _rx = _sp.w * 0.34 * (1 + cos(_a * 3) * 0.14);
                var _ry = _sp.h * 0.19;
                var _yy = _cy2 + sin(_a) * _ry;
                // Clamp the TOP of the crown flat; the underside keeps its curve.
                if (sin(_a) < 0) _yy = max(_yy, _cy2 - _ry * 0.55);
                _cp[_i] = [_cx2 + cos(_a) * _rx, _yy];
            }
            var _crown2 = mst_raise(_cp, mst_bevel_cap(_cp, _sp.h * 0.035), 3, "m2");
            mst_append(_out, mst_map_roles(_crown2, mst_ground_map("a")));
            // Thorns along the windward limbs.
            var _th2 = [];
            for (var _i = 0; _i < 9; _i++) {
                var _px = _cx2 + (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.30;
                var _py = _cy2 + (mst_rng_next(_rng) * 2 - 1) * _sp.h * 0.16;
                var _a2 = mst_rng_next(_rng) * MST_TAU;
                mst_append(_th2, mst_poly([[_px, _py],
                                           [_px + cos(_a2) * _sp.w * 0.030,
                                            _py + sin(_a2) * _sp.w * 0.030]],
                                          false, _sp.w * 0.008, "m0"));
            }
            mst_append(_out, mst_map_roles(_th2, mst_ground_map("c")));
        } break;
    }
    return _out;
}
