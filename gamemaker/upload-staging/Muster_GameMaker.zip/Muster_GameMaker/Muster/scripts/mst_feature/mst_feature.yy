{
  "$GMScript": "v1",
  "%Name": "mst_feature",
  "name": "mst_feature",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}