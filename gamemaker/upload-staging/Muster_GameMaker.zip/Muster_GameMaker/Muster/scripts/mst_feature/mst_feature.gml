/// MUSTER - mst_feature. THE CORPUS. Fifty-two things that can stand on a battlefield, each one a
/// drawn object AND a row of tactical rules, in the same struct.
///
/// ⭐⭐ THIS FILE IS THE PRODUCT'S ENTIRE ARGUMENT, SO IT IS WORTH BEING EXACT ABOUT WHAT IT
/// CLAIMS. Three paid tactics systems were read in full on this shelf before a line of this was
/// written (a $50 isometric battle system, a $29.99 hex battle engine, a $20 Fire-Emblem-style
/// framework). Every one of them ships the RULES of a fight and leaves the developer to find the
/// GROUND: two of them include a fixed tile atlas drawn by a person, one says "basic graphic
/// assets included". None of them composes terrain.
///
/// So this package does not sell rules. Rules exist here only because of the sentence below.
///
/// > ⛔ A FEATURE'S COVER VALUE IS NOT KEPT IN STEP WITH ITS PICTURE. IT IS THE SAME ROW.
/// > mst_feature_spec() returns the geometry hints, the materials, the cover value, the line of
/// > sight block, the height and the movement cost together. mst_field writes those numbers into
/// > the cell AS IT PLACES THE THING, and mst_tactics reads them back. There is no second table
/// > and no synchronisation step, so a buyer cannot reach a state where a boulder is drawn and
/// > queries as open ground - which is exactly the bug every hand-built tile map has.
///
/// -- WHAT A FEATURE IS ------------------------------------------------------------------------
/// A part list in UNIT-BOX SPACE ([-0.5, 0.5], y DOWN, MST_GROUND is the floor line it stands on),
/// built from mst_geom primitives and shaded by mst_relief against one lamp. There is NO sprite,
/// NO spritesheet, NO atlas and NO texture page in this package: `sprites/` does not exist. A
/// boulder in a buyer's game is therefore the same boulder in every season, at every size, in
/// every palette, without one exported PNG.
///
/// -- THE ROLE CONVENTION ----------------------------------------------------------------------
/// mst_relief hands back "m0".."m4". A feature made of ONE material would be fine with that, and
/// almost none of them are: a palisade is timber lashed with rope on an earth bank, a wellhead is
/// masonry with an iron winch and a timber frame. So every feature declares up to three material
/// SLOTS - a, b, c - and its parts carry roles "a0".."a4", "b0".."b4", "c0".."c4". A builder writes
/// relief in m-roles and the composer remaps it into its slot with mst_map_roles.
///
/// ⚠️ THAT REMAP IS WHY A BUILDER MUST NEVER HARD-CODE A SLOT ROLE INSIDE A RELIEF CALL. Passing
/// "a2" as a face colour to mst_raise works, and then the remap turns the walls into slot roles and
/// leaves the face as literal "a2" - which is the same colour by luck and stops being so the moment
/// a caller uses that builder in slot b. Build in m-roles; remap once, at the top.
/// ============================================================================================

/// The number of features in the corpus. Asserted against mst_feature_names() by the suite, so the
/// spec switch and the names list can never drift apart silently.
#macro MST_FEATURE_N 52

/// Cover values. Deliberately three, not a percentage: a tactics player has to be able to look at
/// a cell and know which of these it is without reading a tooltip.
#macro MST_COVER_NONE 0
#macro MST_COVER_SOFT 1
#macro MST_COVER_HARD 2

/// ============================================================================================
/// THE SPEC TABLE
///
/// Columns, and every one of them is read by BOTH the drawing and the rules:
///
///   kind    "stone" | "built" | "flora" | "tree" | "hazard" | "mark"  - which builder file owns it
///   cover   MST_COVER_*  - what a unit standing here gets
///   los     true if it blocks line of sight THROUGH the cell
///   tall    how many elevation levels of sight it blocks (a wall blocks 1, a tree blocks 3);
///           this is what makes high ground worth taking, and it is drawn at the same height
///   cost    extra movement cost ON TOP of the ground material, or MST_IMPASSABLE
///   a,b,c   material slots
///   w,h     the feature's drawn extent in unit-box units, DECLARED and asserted
///
/// ⛔ `tall` IS NOT DECORATION AND IT IS THE ONE COLUMN A BUYER WILL CHECK. If a tree is drawn
/// three levels high and blocks sight for one, the picture is lying about the rules, and a tactics
/// player will find that in the first fight. mst_selftest asserts that every feature's DRAWN height
/// above the ground line is consistent with its `tall`, so the two cannot drift.
/// ============================================================================================

function mst_feature_spec(_id) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_string(_id)) return undefined;
    switch (_id) {
        // ---- STONE: what the ground itself throws up -----------------------------------------
        case "boulder":   return { kind:"stone", cover:MST_COVER_HARD, los:true,  tall:2, cost:MST_IMPASSABLE, a:"granite",  b:"moss",     c:"lichen",   w:0.72, h:0.52 };
        case "menhir":    return { kind:"stone", cover:MST_COVER_HARD, los:true,  tall:3, cost:MST_IMPASSABLE, a:"granite",  b:"moss",     c:"lichen",   w:0.34, h:0.86 };
        case "cairn":     return { kind:"stone", cover:MST_COVER_SOFT, los:false, tall:1, cost:2,              a:"limestone",b:"moss",     c:"granite",  w:0.56, h:0.46 };
        case "outcrop":   return { kind:"stone", cover:MST_COVER_HARD, los:true,  tall:1, cost:MST_IMPASSABLE, a:"basalt",   b:"moss",     c:"scree",    w:0.88, h:0.40 };
        case "rubble":    return { kind:"stone", cover:MST_COVER_SOFT, los:false, tall:1, cost:2,              a:"mortar",   b:"brick",    c:"scree",    w:0.80, h:0.30 };
        case "screeslope":return { kind:"stone", cover:MST_COVER_NONE, los:false, tall:0, cost:2,              a:"scree",    b:"granite",  c:"shingle",  w:0.92, h:0.26 };
        case "fissure":   return { kind:"stone", cover:MST_COVER_SOFT, los:false, tall:0, cost:MST_IMPASSABLE, a:"basalt",   b:"scree",    c:"granite",  w:0.86, h:0.22 };
        case "sinkhole":  return { kind:"stone", cover:MST_COVER_NONE, los:false, tall:0, cost:MST_IMPASSABLE, a:"loam",     b:"basalt",   c:"scree",    w:0.72, h:0.30 };

        // ---- BUILT: what people leave on a field ----------------------------------------------
        case "ruinwall":  return { kind:"built", cover:MST_COVER_HARD, los:true,  tall:2, cost:MST_IMPASSABLE, a:"mortar",   b:"brick",    c:"moss",     w:0.90, h:0.62 };
        case "drystone":  return { kind:"built", cover:MST_COVER_HARD, los:true,  tall:1, cost:MST_IMPASSABLE, a:"limestone",b:"moss",     c:"granite",  w:0.96, h:0.38 };
        case "palisade":  return { kind:"built", cover:MST_COVER_HARD, los:true,  tall:2, cost:MST_IMPASSABLE, a:"timber",   b:"iron",     c:"loam",     w:0.94, h:0.72 };
        case "gabion":    return { kind:"built", cover:MST_COVER_HARD, los:true,  tall:1, cost:MST_IMPASSABLE, a:"timber",   b:"loam",     c:"iron",     w:0.62, h:0.46 };
        case "rampart":   return { kind:"built", cover:MST_COVER_HARD, los:false, tall:1, cost:2,              a:"loam",     b:"turf",     c:"timber",   w:0.98, h:0.42 };
        case "cheval":    return { kind:"built", cover:MST_COVER_SOFT, los:false, tall:1, cost:MST_IMPASSABLE, a:"timber",   b:"iron",     c:"mortar",   w:0.86, h:0.48 };
        case "hurdle":    return { kind:"built", cover:MST_COVER_SOFT, los:false, tall:1, cost:2,              a:"timber",   b:"bark",     c:"loam",     w:0.94, h:0.44 };
        case "cart":      return { kind:"built", cover:MST_COVER_HARD, los:true,  tall:1, cost:MST_IMPASSABLE, a:"timber",   b:"iron",     c:"canvasx",  w:0.88, h:0.56 };
        case "crates":    return { kind:"built", cover:MST_COVER_HARD, los:true,  tall:1, cost:MST_IMPASSABLE, a:"timber",   b:"iron",     c:"bark",     w:0.68, h:0.54 };
        case "barrels":   return { kind:"built", cover:MST_COVER_HARD, los:true,  tall:1, cost:MST_IMPASSABLE, a:"timber",   b:"iron",     c:"bark",     w:0.66, h:0.52 };
        case "haybale":   return { kind:"built", cover:MST_COVER_SOFT, los:true,  tall:1, cost:MST_IMPASSABLE, a:"thatch",   b:"cord",     c:"timber",   w:0.70, h:0.48 };
        case "logpile":   return { kind:"built", cover:MST_COVER_SOFT, los:false, tall:1, cost:MST_IMPASSABLE, a:"bark",     b:"timber",   c:"moss",     w:0.78, h:0.40 };
        case "wellhead":  return { kind:"built", cover:MST_COVER_HARD, los:true,  tall:2, cost:MST_IMPASSABLE, a:"limestone",b:"timber",   c:"iron",     w:0.62, h:0.74 };
        case "shrine":    return { kind:"built", cover:MST_COVER_HARD, los:true,  tall:2, cost:MST_IMPASSABLE, a:"sandstone",b:"timber",   c:"iron",     w:0.54, h:0.80 };
        case "tomb":      return { kind:"built", cover:MST_COVER_SOFT, los:false, tall:1, cost:MST_IMPASSABLE, a:"limestone",b:"moss",     c:"iron",     w:0.82, h:0.34 };
        case "watchstump":return { kind:"built", cover:MST_COVER_HARD, los:true,  tall:3, cost:MST_IMPASSABLE, a:"mortar",   b:"brick",    c:"timber",   w:0.72, h:0.92 };
        case "gatepost":  return { kind:"built", cover:MST_COVER_HARD, los:true,  tall:2, cost:MST_IMPASSABLE, a:"granite",  b:"iron",     c:"timber",   w:0.36, h:0.78 };

        // ---- FLORA: soft cover that a season changes completely --------------------------------
        case "scrub":     return { kind:"flora", cover:MST_COVER_SOFT, los:false, tall:1, cost:2,              a:"leaf",     b:"bark",     c:"turf",     w:0.68, h:0.46 };
        case "brackenc":  return { kind:"flora", cover:MST_COVER_SOFT, los:false, tall:1, cost:2,              a:"bracken",  b:"loam",     c:"leaf",     w:0.74, h:0.42 };
        case "reedbed":   return { kind:"flora", cover:MST_COVER_SOFT, los:true,  tall:1, cost:2,              a:"reed",     b:"mud",      c:"waterx",   w:0.86, h:0.62 };
        case "cornstand": return { kind:"flora", cover:MST_COVER_SOFT, los:true,  tall:2, cost:2,              a:"corn",     b:"loam",     c:"bracken",  w:0.88, h:0.70 };
        case "brambles":  return { kind:"flora", cover:MST_COVER_SOFT, los:false, tall:1, cost:3,              a:"bramble",  b:"bark",     c:"leaf",     w:0.80, h:0.44 };
        case "furrow":    return { kind:"flora", cover:MST_COVER_NONE, los:false, tall:0, cost:1,              a:"loam",     b:"turf",     c:"clay",     w:0.96, h:0.20 };
        case "stump":     return { kind:"flora", cover:MST_COVER_SOFT, los:false, tall:1, cost:2,              a:"bark",     b:"timber",   c:"moss",     w:0.44, h:0.30 };
        case "deadfall":  return { kind:"flora", cover:MST_COVER_SOFT, los:false, tall:1, cost:2,              a:"bark",     b:"moss",     c:"timber",   w:0.94, h:0.34 };
        case "mossrock":  return { kind:"flora", cover:MST_COVER_SOFT, los:false, tall:1, cost:2,              a:"moss",     b:"granite",  c:"leaf",     w:0.58, h:0.34 };
        case "heathpatch":return { kind:"flora", cover:MST_COVER_NONE, los:false, tall:0, cost:2,              a:"heath",    b:"loam",     c:"bracken",  w:0.90, h:0.24 };

        // ---- TREES: the tall blockers ----------------------------------------------------------
        case "broadleaf": return { kind:"tree",  cover:MST_COVER_SOFT, los:true,  tall:3, cost:2,              a:"leaf",     b:"bark",     c:"moss",     w:0.86, h:0.96 };
        case "conifer":   return { kind:"tree",  cover:MST_COVER_SOFT, los:true,  tall:3, cost:2,              a:"needle",   b:"bark",     c:"moss",     w:0.64, h:0.98 };
        case "snag":      return { kind:"tree",  cover:MST_COVER_SOFT, los:true,  tall:2, cost:2,              a:"bark",     b:"timber",   c:"moss",     w:0.56, h:0.84 };
        case "pollard":   return { kind:"tree",  cover:MST_COVER_SOFT, los:true,  tall:2, cost:2,              a:"leaf",     b:"bark",     c:"moss",     w:0.70, h:0.76 };
        case "thorntree": return { kind:"tree",  cover:MST_COVER_SOFT, los:true,  tall:2, cost:2,              a:"leaf",     b:"bark",     c:"bramble",  w:0.78, h:0.80 };

        // ---- HAZARD: what the ground does to you ------------------------------------------------
        case "mire":      return { kind:"hazard",cover:MST_COVER_NONE, los:false, tall:0, cost:3,              a:"mud",      b:"reed",     c:"waterx",   w:0.90, h:0.26 };
        case "ford":      return { kind:"hazard",cover:MST_COVER_NONE, los:false, tall:0, cost:2,              a:"waterx",   b:"shingle",  c:"reed",     w:0.96, h:0.24 };
        case "pool":      return { kind:"hazard",cover:MST_COVER_NONE, los:false, tall:0, cost:MST_IMPASSABLE, a:"waterx",   b:"mud",      c:"reed",     w:0.92, h:0.28 };
        case "icesheet":  return { kind:"hazard",cover:MST_COVER_NONE, los:false, tall:0, cost:1,              a:"icex",     b:"waterx",   c:"snowx",    w:0.92, h:0.26 };
        case "tarpit":    return { kind:"hazard",cover:MST_COVER_NONE, los:false, tall:0, cost:MST_IMPASSABLE, a:"cinder",   b:"mud",      c:"basalt",   w:0.84, h:0.26 };
        case "brazier":   return { kind:"hazard",cover:MST_COVER_NONE, los:false, tall:1, cost:MST_IMPASSABLE, a:"iron",     b:"cinder",   c:"timber",   w:0.44, h:0.64 };

        // ---- MARK: what the fight is ABOUT --------------------------------------------------
        case "banner":    return { kind:"mark",  cover:MST_COVER_NONE, los:false, tall:2, cost:1,              a:"canvasx",  b:"timber",   c:"iron",     w:0.46, h:0.94 };
        case "cache":     return { kind:"mark",  cover:MST_COVER_SOFT, los:false, tall:1, cost:2,              a:"canvasx",  b:"timber",   c:"cord",     w:0.66, h:0.44 };
        case "altar":     return { kind:"mark",  cover:MST_COVER_SOFT, los:false, tall:1, cost:MST_IMPASSABLE, a:"sandstone",b:"iron",     c:"moss",     w:0.72, h:0.42 };
        case "beacon":    return { kind:"mark",  cover:MST_COVER_NONE, los:false, tall:3, cost:MST_IMPASSABLE, a:"timber",   b:"iron",     c:"cinder",   w:0.50, h:0.94 };
        case "tent":      return { kind:"mark",  cover:MST_COVER_HARD, los:true,  tall:2, cost:MST_IMPASSABLE, a:"canvasx",  b:"timber",   c:"cord",     w:0.92, h:0.66 };
        case "ladder":    return { kind:"mark",  cover:MST_COVER_SOFT, los:false, tall:2, cost:2,              a:"timber",   b:"cord",     c:"iron",     w:0.44, h:0.90 };
    }
    return undefined;
}

/// The corpus, in sheet order. The suite asserts every name here resolves to a spec and that the
/// count matches MST_FEATURE_N, so neither list can lose a member quietly.
function mst_feature_names() {
    return [
        "boulder", "menhir", "cairn", "outcrop", "rubble", "screeslope", "fissure", "sinkhole",
        "ruinwall", "drystone", "palisade", "gabion", "rampart", "cheval", "hurdle", "cart",
        "crates", "barrels", "haybale", "logpile", "wellhead", "shrine", "tomb", "watchstump",
        "gatepost",
        "scrub", "brackenc", "reedbed", "cornstand", "brambles", "furrow", "stump", "deadfall",
        "mossrock", "heathpatch",
        "broadleaf", "conifer", "snag", "pollard", "thorntree",
        "mire", "ford", "pool", "icesheet", "tarpit", "brazier",
        "banner", "cache", "altar", "beacon", "tent", "ladder",
    ];
}

/// The tallest declared height in the corpus.
///
/// ⛔ DERIVED, NEVER TYPED. A grid that lays out the corpus has to leave room for the tallest thing
/// in it, and a constant repeating today's maximum is a constant that goes stale the first time a
/// feature is added - silently, by drawing the new one through the row above. The store sheet had
/// exactly that defect on its first bake. Scanning 52 specs costs nothing at bake time.
function mst_feature_tallest() {
    var _names = mst_feature_names();
    var _m = 0;
    for (var _i = 0; _i < array_length(_names); _i++) {
        var _sp = mst_feature_spec(_names[_i]);
        if (!is_undefined(_sp)) _m = max(_m, _sp.h);
    }
    return max(0.1, _m);
}

/// ============================================================================================
/// FOUR MATERIALS THAT ARE NOT GROUND
///
/// ⚠️ mst_ground's table describes SURFACES A FIELD IS MADE OF, and four things a feature needs
/// are not that: still water, ice, lying snow and cloth. They are declared here rather than being
/// pushed into the ground table, because the ground table's `cost` and `susc` columns are read by
/// the field generator for every cell, and a cell can never be "made of canvas".
///
/// They carry the `x` suffix in the spec table above so a reader can see at a glance that a slot
/// is not a ground material. The suite asserts that every `*x` name resolves HERE and every other
/// slot name resolves in mst_ground - which is what stops a typo becoming a silent grey default.
/// ============================================================================================
function mst_extra_spec(_mat) {
    switch (_mat) {
        //                       L      C      hue   span   what it is
        case "waterx":  return { L: 0.360, C: 0.032, h: 232, span: 0.52, cost: 2, susc: 0.60 }; // still water, hard specular
        case "icex":    return { L: 0.760, C: 0.020, h: 226, span: 0.48, cost: 1, susc: 0.10 }; // frozen, still hard
        case "snowx":   return { L: 0.905, C: 0.006, h: 246, span: 0.10, cost: 2, susc: 0.05 }; // lying snow, flat
        case "canvasx": return { L: 0.620, C: 0.030, h:  72, span: 0.18, cost: 1, susc: 0.35 }; // tent, sack, banner cloth
        case "lichen":  return { L: 0.640, C: 0.030, h: 108, span: 0.14, cost: 1, susc: 0.30 }; // crust on stone
        case "cord":    return { L: 0.620, C: 0.040, h:  78, span: 0.12, cost: 1, susc: 0.40 }; // lashing, rope
    }
    return undefined;
}

/// Resolve ANY slot name - ground or extra - to a spec. One entry point, so a builder never has to
/// know which table its material came from.
///
/// ⛔ IT RETURNS undefined FOR AN UNKNOWN NAME RATHER THAN A GREY DEFAULT, and that is deliberate.
/// mst_ground_spec falls back to a mid-grey, which is correct for it (a buyer naming their own
/// ground gets something sane). Here a fallback would swallow a typo in the spec table above and
/// paint a wall the colour of nothing, so the suite can assert non-undefined across all 50 features
/// and catch it at build time instead.
function mst_slot_spec(_mat) {
    var _x = mst_extra_spec(_mat);
    if (!is_undefined(_x)) return _x;
    var _names = mst_ground_names();
    for (var _i = 0; _i < array_length(_names); _i++) {
        if (_names[_i] == _mat) return mst_ground_spec(_mat);
    }
    return undefined;
}

/// A slot material's five stops under a season. Ground materials go through the season pull;
/// extras carry their own susceptibility and use the same maths, so a canvas tent greys off under
/// blight and a pool freezes under snow without either being special-cased at a call site.
function mst_slot_ramp(_mat, _season, _t, _hue_shift) {
    var _s = mst_slot_spec(_mat);
    if (is_undefined(_s)) return mst_ground_ramp("loam", _season, _t, _hue_shift);
    var _tg = mst_season_spec(_season);
    var _u = clamp(_t, 0, 1);
    var _hs = is_undefined(_hue_shift) ? 0 : _hue_shift;

    var _L = _s.L, _C = _s.C, _h = _s.h, _span = _s.span;
    if (!is_undefined(_tg) && _u > 0 && _s.susc > 0) {
        var _k = _u * _tg.k * _s.susc;
        var _cs = _s.C * (1 - _k);
        var _ct = _tg.C * _k;
        var _hw = (_cs + _ct > 0.00001) ? (_ct / (_cs + _ct)) : _k;
        _L = lerp(_s.L, _tg.L, _k);
        _C = lerp(_s.C, _tg.C, _k);
        _h = mst_hue_lerp(_s.h, _tg.h, _hw);
        _span = lerp(_s.span, _tg.span, _k);
    }

    var _floor = 0.055, _ceil = 0.975;
    var _sp = min(_span, _ceil - _floor);
    var _lo = _L - _sp * 0.5;
    var _hi = _L + _sp * 0.5;
    if (_hi > _ceil) { _lo -= (_hi - _ceil); _hi = _ceil; }
    if (_lo < _floor) { _hi += (_floor - _lo); _lo = _floor; }
    _hi = min(_hi, _ceil);

    var _out = array_create(MST_RAMP_N);
    for (var _i = 0; _i < MST_RAMP_N; _i++) {
        var _uu = _i / (MST_RAMP_N - 1);
        _out[_i] = mst_oklch(_lo + (_hi - _lo) * _uu, max(0, _C * (0.82 + 0.36 * _uu)), _h + _hs);
    }
    return _out;
}

/// Build the palette a feature needs: its three slots written under prefixes a, b and c.
function mst_feature_palette(_pal, _id, _season, _t) {
    var _sp = mst_feature_spec(_id);
    if (is_undefined(_sp)) return _pal;
    var _slots = ["a", "b", "c"];
    var _mats = [_sp.a, _sp.b, _sp.c];
    for (var _i = 0; _i < 3; _i++) {
        var _r = mst_slot_ramp(_mats[_i], _season, _t, 0);
        for (var _k = 0; _k < MST_RAMP_N; _k++) {
            variable_struct_set(_pal, _slots[_i] + string(_k), _r[_k]);
        }
    }
    return _pal;
}

/// ============================================================================================
/// SHARED MASSES - the shapes every builder is assembled from
///
/// ⛔ THESE EXIST BECAUSE OF THE WING'S "A CHAIN OF MASSES READS AS A CHAIN" LAW. Faking one
/// continuous form out of three tapers bevels each on its OWN outline, so every join grows a lit
/// edge running across the object and a war horn reads as three chevrons. Where a real thing is
/// continuous - a boulder, a trunk, a bank of earth - it is authored here as ONE outline and
/// bevelled once.
/// ============================================================================================

/// An irregular closed lump: the shape of a rock, a bush's silhouette, a heap of anything.
///
/// _lobes  how many radial samples (8 reads as a pebble, 16 as a weathered boulder)
/// _rough  0..1, how far each radius may vary from the mean
/// _flat   0..1, how hard the BOTTOM is pushed onto the ground line
///
/// ⚠️ THE FLATTENING IS NOT COSMETIC. A lump with a round bottom floats, and the fix a first draft
/// always reaches for - moving it down until the curve is under the ground line - buries a third of
/// the shape and makes it smaller instead of grounded. Pulling the low samples UP onto the line
/// keeps the full silhouette and gives the contact edge a real object's flat.
function mst_lump_pts(_cx, _cy, _rx, _ry, _lobes, _rough, _flat, _rng) {
    var _n = max(5, _lobes);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = (_i / _n) * MST_TAU;
        var _k = 1 + (mst_rng_next(_rng) * 2 - 1) * _rough;
        var _x = _cx + cos(_a) * _rx * _k;
        var _y = _cy + sin(_a) * _ry * _k;
        // sin(_a) > 0 is the LOWER half on screen (y grows down). Pull it toward the base line.
        if (sin(_a) > 0 && _flat > 0) {
            var _base = _cy + _ry;
            _y = lerp(_y, _base, _flat * sin(_a));
        }
        _out[_i] = [_x, _y];
    }
    return _out;
}

/// A tapered upright: a trunk, a post, a stake, a standing stone.
///
/// Returns a CLOSED outline, up the left side and down the right, so the taper is in the outline
/// rather than in a special case - the wing's Armoury law about points ("a point is a closure on
/// the width, not a sweep across the outline") stated for the simpler case.
function mst_shaft_pts(_x, _ybot, _ytop, _wbot, _wtop, _lean, _segs) {
    var _n = max(2, _segs);
    var _left = array_create(_n + 1);
    var _right = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _u = _i / _n;
        var _y = lerp(_ybot, _ytop, _u);
        var _hw = lerp(_wbot, _wtop, _u) * 0.5;
        var _cx = _x + _lean * _u * _u;
        _left[_i] = [_cx - _hw, _y];
        _right[_i] = [_cx + _hw, _y];
    }
    var _out = [];
    for (var _i = 0; _i <= _n; _i++) array_push(_out, _left[_i]);
    for (var _i = _n; _i >= 0; _i--) array_push(_out, _right[_i]);
    return _out;
}

/// A horizontal bank: ground swelling up and back down, meeting the floor line at both ends.
///
/// ⛔ THE ENDS ARE ON THE BASE LINE BY CONSTRUCTION, not by a tuned constant. This is the wing's
/// Welkin cloud law - "the union rail is trimmed to its covered span, so equal discs give a
/// vertical end wall", which rendered five of fourteen cloud genera as grey concrete boxes. Driving
/// the height from sin(pi*u) is zero at both ends however hard the profile is pushed, so a rampart
/// can never grow a vertical wall at its shoulder.
function mst_bank_pts(_x0, _x1, _ybase, _hgt, _plateau, _segs, _rng) {
    var _n = max(4, _segs);
    var _top = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _u = _i / _n;
        var _p = clamp(sin(pi * _u) * _plateau, 0, 1);
        var _j = is_undefined(_rng) ? 1 : (0.92 + mst_rng_next(_rng) * 0.16);
        _top[_i] = [lerp(_x0, _x1, _u), _ybase - _hgt * _p * _j];
    }
    var _out = [];
    for (var _i = 0; _i <= _n; _i++) array_push(_out, _top[_i]);
    array_push(_out, [_x1, _ybase]);
    array_push(_out, [_x0, _ybase]);
    return _out;
}

/// A flat pool of liquid lying ON the ground: an ellipse squashed hard in y, because a horizontal
/// surface seen from a battle camera is an ELLIPSE, never a circle.
///
/// ⚠️ mst_arc_pts takes ONE radius and is therefore CIRCULAR. Everything drawn flat on the floor in
/// this package - every puddle, ford, tar pit, scorched patch and shadow - is elliptical in
/// projection, and reaching for the circular helper draws a silently wrong curve that agrees only
/// when the two radii happen to match. This is the Repast plate-rim trap on a battlefield.
function mst_pool_pts(_cx, _cy, _rx, _ry, _segs, _rough, _rng) {
    var _n = max(8, _segs);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = (_i / _n) * MST_TAU;
        var _k = (_rough > 0 && !is_undefined(_rng)) ? (1 + (mst_rng_next(_rng) * 2 - 1) * _rough) : 1;
        _out[_i] = [_cx + cos(_a) * _rx * _k, _cy + sin(_a) * _ry * _k];
    }
    return _out;
}

/// The contact shadow a standing thing throws where it meets the ground.
///
/// ⛔ IT IS DRAWN FIRST AND IT IS AN ELLIPSE, and both halves of that matter. Drawn last it sits ON
/// TOP of the object's own base - the wing's Vestige law that a flash goes UNDER the thing it
/// illuminates, arriving from the other side. Drawn as a circle it reads as a hole rather than a
/// shadow, because nothing else on the field is circular in projection.
function mst_contact_shadow(_cx, _rx) {
    return [mst_ring_fill(mst_pool_pts(_cx, MST_GROUND + 0.012, _rx, _rx * 0.28, 18, 0, undefined),
                          "s0", undefined, undefined)];
}

/// ============================================================================================
/// THE DISPATCHER
/// ============================================================================================

/// Build one feature's part list in unit-box space, remapped into its material slots.
///
/// ⛔ THE SEED IS THE FEATURE'S NAME PLUS THE CALLER'S NUMBER, never random(). Nothing in this
/// product is random at draw time: a boulder that re-jitters every frame is the one bug a buyer
/// notices immediately and cannot work around, and on a battlefield it would also mean the drawn
/// cover moved while the RULES about it did not.
function mst_feature_parts(_id, _seed, _season, _t) {
    var _sp = mst_feature_spec(_id);
    if (is_undefined(_sp)) return [];
    var _rng = mst_rng(mst_hash32(_id + "/" + string(_seed)));
    var _parts = [];

    switch (_sp.kind) {
        case "stone":  _parts = mst_stone_parts(_id, _sp, _rng, _season, _t); break;
        case "built":  _parts = mst_built_parts(_id, _sp, _rng, _season, _t); break;
        case "flora":  _parts = mst_flora_parts(_id, _sp, _rng, _season, _t); break;
        case "tree":   _parts = mst_tree_parts(_id, _sp, _rng, _season, _t); break;
        case "hazard": _parts = mst_hazard_parts(_id, _sp, _rng, _season, _t); break;
        default:       _parts = mst_mark_parts(_id, _sp, _rng, _season, _t); break;
    }
    return _parts;
}

/// The height a feature actually reaches above the ground line, measured from its own geometry.
///
/// ⭐ THIS IS THE FUNCTION THAT KEEPS THE PICTURE HONEST ABOUT THE RULES, and it exists because a
/// declared number and a drawn number are two different things. mst_selftest asserts that a
/// feature whose spec says `tall: 3` really is drawn about three times as high as one that says
/// `tall: 1`, so a builder cannot quietly shrink a tree and leave it blocking sight for three
/// levels. The wing has paid for the opposite of this twice: a declared extent the builder reads
/// as its own scale, where editing the number proves nothing.
function mst_feature_height(_id, _seed) {
    var _p = mst_feature_parts(_id, _seed, "verdant", 0);
    if (array_length(_p) == 0) return 0;
    var _b = mst_render_bounds(_p);
    return max(0, MST_GROUND - _b[1]);
}
