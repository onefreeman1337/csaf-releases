/// MUSTER - mst_hazard. Six hazards and six marks.
///
/// mire, ford, pool, icesheet, tarpit, brazier - and banner, cache, altar, beacon, tent, ladder.
///
/// -- HAZARDS LIE FLAT, AND THAT IS WHY THEY ARE HARD ------------------------------------------
/// Everything in mst_stone, mst_built and mst_flora STANDS UP: it has a silhouette against the
/// ground, and a silhouette is easy to read. A hazard is a horizontal surface seen from a battle
/// camera, so it has no silhouette at all and must be told apart from the cell it lies on by
/// texture, value and edge treatment alone.
///
/// ⛔ WHICH MAKES ONE RULE ABSOLUTE HERE: EVERY FLAT THING IS AN ELLIPSE, NEVER A CIRCLE.
/// mst_arc_pts takes a SINGLE radius and is therefore circular; a puddle, a ford, a tar pit, an ice
/// sheet and a scorch mark are all ellipses in projection, and the circular helper draws a silently
/// wrong curve that agrees only when the two radii happen to match. The wing paid for exactly this
/// on a plate rim, where one ring drawn last straddled the food on every rimmed plate the product
/// could produce.
///
/// -- ⭐ AND THE SEASON REACHES FURTHEST HERE ---------------------------------------------------
/// A pool is `waterx` (susc 0.60) and is impassable. Under `snowbound` its ramp arrives at ice's
/// pale hard values AND mst_ground_cost turns the cell walkable, from the same table. That is the
/// one modifier in the product that makes a cell CHEAPER, and it is the one a player will plan a
/// whole turn around: the river you could not cross in autumn is a road in February.
/// ============================================================================================

/// The lit edge of a liquid: a bright line along the far rim and a dark one along the near rim,
/// which is what makes a flat patch read as a SURFACE rather than as a stain.
///
/// ⚠️ THE SPLIT IS BY DEPTH AND NOT BY LIGHT DIRECTION. y grows downward, so `sin(a) < 0` is the
/// FAR half of an ellipse on screen. The far rim of standing water catches the sky and is the
/// brightest thing in the cell; the near rim is in the bank's own shadow. Lighting this from the
/// lamp instead would put the highlight on the left and the picture would read as wet stone.
function mst_water_rim(_cx, _cy, _rx, _ry, _w) {
    var _far = mst_ellipse_arc_pts(_cx, _cy, _rx, _ry, pi, MST_TAU, 14);
    var _near = mst_ellipse_arc_pts(_cx, _cy, _rx, _ry, 0, pi, 14);
    return [
        mst_poly(_far, false, _w, "m4"),
        mst_poly(_near, false, _w * 0.8, "m0"),
    ];
}

/// Ripples on a liquid: nested ellipses that are NOT concentric, drifting downwind.
///
/// ⚠️ CONCENTRIC RINGS READ AS A TARGET. Every one of these is offset a little further than the
/// last, which is what a breeze does to a pond and what stops the picture looking like a logo.
function mst_water_ripples(_cx, _cy, _rx, _ry, _n, _drift, _rng) {
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _k = (_i + 1) / (_n + 1);
        var _dx = _drift * _k * _k;
        mst_append(_out, mst_poly(
            mst_ellipse_pts(_cx + _dx, _cy + _ry * 0.10 * _k, _rx * (1 - _k * 0.72),
                            _ry * (1 - _k * 0.72), 16),
            true, _ry * 0.10, (_i % 2 == 0) ? "m3" : "m1"));
    }
    return _out;
}

function mst_hazard_parts(_id, _sp, _rng, _season, _t) {
    var _out = [];
    var _g = MST_GROUND;
    var _x0 = -_sp.w * 0.5, _x1 = _sp.w * 0.5;
    var _cy = _g - _sp.h * 0.42;

    switch (_id) {
        case "mire": {
            // Bog. The subject is that it is NOT WATER AND NOT GROUND: a dull skin with tussocks
            // standing in it. Drawn as clean water it would read as a pool and a player would plan
            // around the wrong rule.
            var _pit = mst_pool_pts(0, _cy, _sp.w * 0.50, _sp.h * 0.66, 22, 0.13, _rng);
            mst_append(_out, mst_map_roles(
                mst_sink(_pit, mst_bevel_cap(_pit, _sp.h * 0.14), 2, "m0"), mst_ground_map("a")));
            // Standing water in the low spots: two or three small lenses, not one sheet.
            var _wet = [];
            for (var _i = 0; _i < 3; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.30;
                var _py = _cy + (mst_rng_next(_rng) * 2 - 1) * _sp.h * 0.24;
                var _pr = _sp.w * (0.07 + mst_rng_next(_rng) * 0.06);
                mst_append(_wet, mst_ring_fill(
                    mst_pool_pts(_px, _py, _pr, _pr * 0.36, 12, 0.16, _rng), "m3", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_wet, mst_ground_map("c")));
            // Tussocks: the only thing standing up, and the only way a player reads "you can try".
            var _tus = [];
            for (var _i = 0; _i < 6; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.42;
                var _py = _cy + (mst_rng_next(_rng) * 2 - 1) * _sp.h * 0.36;
                var _pr = _sp.w * (0.035 + mst_rng_next(_rng) * 0.026);
                var _tp = mst_lump_pts(_px, _py - _pr * 0.4, _pr, _pr * 0.62, 9, 0.20, 0.4, _rng);
                mst_append(_tus, mst_raise(_tp, _pr * 0.30, 2, "m2"));
            }
            mst_append(_out, mst_map_roles(_tus, mst_ground_map("b")));
        } break;

        case "ford": {
            // A crossing. The STONES BREAKING THE SURFACE are the whole message - they say "you
            // may walk here" without a caption, which is exactly what cost 2 rather than impassable
            // needs to communicate.
            var _wat = mst_pool_pts(0, _cy, _sp.w * 0.50, _sp.h * 0.62, 22, 0.07, _rng);
            mst_append(_out, mst_map_roles(mst_ring_fill(_wat, "m2", undefined, undefined),
                                           mst_ground_map("a")));
            mst_append(_out, mst_map_roles(
                mst_water_rim(0, _cy, _sp.w * 0.50, _sp.h * 0.62, _sp.h * 0.055),
                mst_ground_map("a")));
            var _st = [];
            var _wk = [];
            for (var _i = 0; _i < 9; _i++) {
                var _px = lerp(_x0 * 0.86, _x1 * 0.86, (_i + 0.5) / 9)
                        + (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.04;
                var _py = _cy + (mst_rng_next(_rng) * 2 - 1) * _sp.h * 0.34;
                var _pr = _sp.w * (0.030 + mst_rng_next(_rng) * 0.026);
                var _sp5 = mst_lump_pts(_px, _py, _pr, _pr * 0.56, 9, 0.15, 0.3, _rng);
                mst_append(_st, mst_raise(_sp5, _pr * 0.30, 2, "m2"));
                // The wake a stone makes: a short bright arc on its upstream side.
                mst_append(_wk, mst_poly(
                    mst_ellipse_arc_pts(_px, _py, _pr * 1.5, _pr * 0.8, pi + 0.5, MST_TAU - 0.5, 7),
                    false, _pr * 0.20, "m4"));
            }
            mst_append(_out, mst_map_roles(_st, mst_ground_map("b")));
            mst_append(_out, mst_map_roles(_wk, mst_ground_map("a")));
        } break;

        case "pool": {
            // Deep still water. Impassable, so nothing must break the surface - the ABSENCE of
            // stepping stones is what distinguishes it from a ford, and it is the difference a
            // player has to read in half a second.
            var _wat2 = mst_pool_pts(0, _cy, _sp.w * 0.50, _sp.h * 0.66, 24, 0.06, _rng);
            mst_append(_out, mst_map_roles(mst_ring_fill(_wat2, "m1", undefined, undefined),
                                           mst_ground_map("a")));
            // A reflected sky band across the far half, which is what makes deep water read deep.
            var _refl = mst_ellipse_arc_pts(0, _cy, _sp.w * 0.42, _sp.h * 0.50, pi + 0.35, MST_TAU - 0.35, 12);
            mst_append(_out, mst_map_roles(
                mst_poly(_refl, false, _sp.h * 0.10, "m4"), mst_ground_map("a")));
            mst_append(_out, mst_map_roles(
                mst_water_ripples(0, _cy, _sp.w * 0.44, _sp.h * 0.56, 3, _sp.w * 0.05, _rng),
                mst_ground_map("a")));
            mst_append(_out, mst_map_roles(
                mst_water_rim(0, _cy, _sp.w * 0.50, _sp.h * 0.66, _sp.h * 0.06),
                mst_ground_map("a")));
            // Mud margin, drawn OVER the rim so the water sits inside a bank.
            var _mg = [];
            for (var _i = 0; _i < 7; _i++) {
                var _a = mst_rng_next(_rng) * MST_TAU;
                var _px = cos(_a) * _sp.w * 0.50;
                var _py = _cy + sin(_a) * _sp.h * 0.66;
                var _pr = _sp.w * (0.028 + mst_rng_next(_rng) * 0.024);
                mst_append(_mg, mst_ring_fill(mst_pool_pts(_px, _py, _pr, _pr * 0.5, 8, 0.30, _rng),
                                              "m2", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_mg, mst_ground_map("b")));
            // Reeds at one edge only. Ringing the pool would read as a decorative border.
            var _rd = mst_stems(_x0 * 0.60, _x0 * 0.10, _cy + _sp.h * 0.30, _sp.h * 0.72,
                                7, 0.10, 0.09, _sp.w * 0.012, _rng);
            mst_append(_out, mst_map_roles(_rd, mst_ground_map("c")));
        } break;

        case "icesheet": {
            // Frozen. The subject is the CRACK PATTERN, which is the only thing that says ice
            // rather than pale water - and a crack that stops in open ice is wrong, so every one
            // of these runs from edge to edge or meets another crack.
            var _ice = mst_pool_pts(0, _cy, _sp.w * 0.50, _sp.h * 0.64, 22, 0.08, _rng);
            mst_append(_out, mst_map_roles(mst_ring_fill(_ice, "m3", undefined, undefined),
                                           mst_ground_map("a")));
            var _cr = [];
            var _hub = [(mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.14,
                        _cy + (mst_rng_next(_rng) * 2 - 1) * _sp.h * 0.18];
            var _n = 6;
            for (var _i = 0; _i < _n; _i++) {
                var _a = (_i / _n) * MST_TAU + mst_rng_next(_rng) * 0.4;
                // Run to the rim, then a little past it, so the crack cannot end in open ice.
                var _ex = _hub[0] + cos(_a) * _sp.w * 0.58;
                var _ey = _hub[1] + sin(_a) * _sp.h * 0.74;
                var _mx = lerp(_hub[0], _ex, 0.5) + (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.05;
                var _my = lerp(_hub[1], _ey, 0.5) + (mst_rng_next(_rng) * 2 - 1) * _sp.h * 0.07;
                mst_append(_cr, mst_incise([[_hub[0], _hub[1]], [_mx, _my], [_ex, _ey]],
                                           false, _sp.h * 0.038));
            }
            mst_append(_out, mst_map_roles(_cr, mst_ground_map("b")));
            // Wind-blown snow caught in the lee of the cracks.
            var _sn = [];
            for (var _i = 0; _i < 5; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.38;
                var _py = _cy + (mst_rng_next(_rng) * 2 - 1) * _sp.h * 0.42;
                var _pr = _sp.w * (0.040 + mst_rng_next(_rng) * 0.034);
                mst_append(_sn, mst_ring_fill(mst_pool_pts(_px, _py, _pr, _pr * 0.34, 10, 0.24, _rng),
                                              "m4", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_sn, mst_ground_map("c")));
            mst_append(_out, mst_map_roles(
                mst_water_rim(0, _cy, _sp.w * 0.50, _sp.h * 0.64, _sp.h * 0.05),
                mst_ground_map("a")));
        } break;

        case "tarpit": {
            // Bitumen. The tell is that it is DARKER THAN ITS OWN SHADOW and that its surface is
            // convex - tar stands proud in a dome rather than lying flat like water, and drawing it
            // flat is what would make it read as a hole.
            var _pt = mst_pool_pts(0, _cy, _sp.w * 0.50, _sp.h * 0.60, 20, 0.10, _rng);
            mst_append(_out, mst_map_roles(mst_raise(_pt, mst_bevel_cap(_pt, _sp.h * 0.16), 3, "m0"),
                                           mst_ground_map("a")));
            // Bubbles: raised domes, a few of them burst.
            var _bb = [];
            for (var _i = 0; _i < 6; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.34;
                var _py = _cy + (mst_rng_next(_rng) * 2 - 1) * _sp.h * 0.32;
                var _pr = _sp.w * (0.022 + mst_rng_next(_rng) * 0.030);
                if (mst_rng_next(_rng) < 0.35) {
                    mst_append(_bb, mst_sink(mst_pool_pts(_px, _py, _pr, _pr * 0.6, 10, 0.10, _rng),
                                             _pr * 0.32, 2, "m0"));
                } else {
                    mst_append(_bb, mst_boss(_px, _py, _pr, 10));
                }
            }
            mst_append(_out, mst_map_roles(_bb, mst_ground_map("a")));
            // A dry crust at the margin where it has cooled.
            var _crust = [];
            for (var _i = 0; _i < 8; _i++) {
                var _a = mst_rng_next(_rng) * MST_TAU;
                var _px = cos(_a) * _sp.w * 0.50;
                var _py = _cy + sin(_a) * _sp.h * 0.60;
                var _pr = _sp.w * (0.024 + mst_rng_next(_rng) * 0.024);
                mst_append(_crust, mst_ring_fill(mst_pool_pts(_px, _py, _pr, _pr * 0.5, 7, 0.34, _rng),
                                                 "m2", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_crust, mst_ground_map("b")));
            // Bones. One clear silhouette says more than ten scattered marks.
            var _bn = [];
            mst_append(_bn, mst_taper_ribbon([[_sp.w * 0.10, _cy + _sp.h * 0.10],
                                              [_sp.w * 0.22, _cy - _sp.h * 0.16],
                                              [_sp.w * 0.26, _cy - _sp.h * 0.34]],
                                             _sp.h * 0.030, _sp.h * 0.014, "m4"));
            mst_append(_bn, mst_boss(_sp.w * 0.27, _cy - _sp.h * 0.36, _sp.h * 0.034, 8));
            mst_append(_out, mst_map_roles(_bn, mst_ground_map("c")));
        } break;

        default: { // brazier
            // The only hazard that stands up. An iron fire basket on legs: impassable, harms what
            // touches it, and a real light source in a night fight.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.44));
            var _bh = _sp.h * 0.34;
            var _by = _g - _bh;
            var _legs = [];
            for (var _k = 0; _k < 3; _k++) {
                var _lx = (_k - 1) * _sp.w * 0.24;
                mst_append(_legs, mst_taper_ribbon([[_lx * 1.6, _g], [_lx, _by]],
                                                   _sp.w * 0.022, _sp.w * 0.014, "m2"));
            }
            // The basket: a truncated cone, wider at the top.
            var _bw = _sp.w * 0.46;
            var _bkt = [[-_bw * 0.52, _by], [_bw * 0.52, _by],
                        [_bw, _by - _sp.h * 0.26], [-_bw, _by - _sp.h * 0.26]];
            mst_append(_legs, mst_raise(_bkt, mst_bevel_cap(_bkt, _sp.w * 0.05), 3, "m2"));
            // Bars, which is what makes it a basket rather than a bucket.
            for (var _k = 0; _k < 5; _k++) {
                var _u = _k / 4;
                mst_append(_legs, mst_incise([[lerp(-_bw * 0.52, _bw * 0.52, _u), _by],
                                              [lerp(-_bw, _bw, _u), _by - _sp.h * 0.26]],
                                             false, _sp.w * 0.024));
            }
            mst_append(_legs, mst_ridge([[-_bw, _by - _sp.h * 0.26], [_bw, _by - _sp.h * 0.26]],
                                        false, _sp.w * 0.030));
            mst_append(_out, mst_map_roles(_legs, mst_ground_map("a")));
            // Embers, then flame. ⛔ PAINTER'S ORDER IS THE GRADIENT, not a detail: the wing's
            // Vestige law says a glow drawn smallest-disc-first has every dim outer disc painted
            // over the bright core and flattens to a uniform donut. Largest and dimmest FIRST.
            var _fire = [];
            var _fy = _by - _sp.h * 0.26;
            for (var _k = 3; _k >= 0; _k--) {
                var _kk = (_k + 1) / 4;
                var _fw = _bw * 0.86 * _kk;
                var _fh = _sp.h * 0.32 * _kk;
                var _fp = [[-_fw, _fy], [-_fw * 0.42, _fy - _fh * 0.62],
                           [-_fw * 0.10, _fy - _fh], [_fw * 0.28, _fy - _fh * 0.70],
                           [_fw, _fy]];
                mst_append(_fire, mst_ring_fill(_fp, (_k >= 2) ? "m1" : "m4", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_fire, mst_ground_map("b")));
            var _ash = [];
            for (var _i = 0; _i < 4; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.34;
                var _pr = _sp.w * (0.018 + mst_rng_next(_rng) * 0.016);
                mst_append(_ash, mst_ring_fill(mst_pool_pts(_px, _g - _sp.h * 0.02, _pr, _pr * 0.42,
                                                            7, 0.30, _rng), "m2", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_ash, mst_ground_map("c")));
        } break;
    }
    return _out;
}

/// ============================================================================================
/// MARKS - what the fight is ABOUT
///
/// A tactics map without objectives is a killing field. These six are the things a scenario writer
/// puts on a map to give the fight a shape other than "kill everyone": a banner to hold, a cache to
/// reach, an altar to protect, a beacon to light, a tent to burn, a ladder to climb.
///
/// ⛔ THEY MUST READ AS DELIBERATE. Everything else in the corpus is weather and geology; these are
/// the only features a player is supposed to interpret as PLACED BY SOMEBODY, so every one of them
/// carries a straight line, a right angle or a symmetry that nothing natural in this package has.
/// That contrast is doing the work, not a marker icon floating above the cell.
/// ============================================================================================

function mst_mark_parts(_id, _sp, _rng, _season, _t) {
    var _out = [];
    var _g = MST_GROUND;
    var _x0 = -_sp.w * 0.5, _x1 = _sp.w * 0.5;
    var _top = _g - _sp.h;

    switch (_id) {
        case "banner": {
            // A standard driven into the ground. The FLY of the cloth is the picture; a flat
            // rectangle on a stick reads as a sign.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.34));
            var _pw = _sp.w * 0.035;
            var _pole = mst_shaft_pts(0, _g, _top, _pw * 2, _pw * 1.4, 0, 3);
            var _wood = mst_raise(_pole, mst_bevel_cap(_pole, _pw * 0.5), 2, "m2");
            mst_append(_out, mst_map_roles(_wood, mst_ground_map("b")));
            // The cloth: a strip whose two rails are the SAME wave at different amplitudes, so it
            // reads as one piece of fabric turning rather than two edges that disagree.
            var _n = 12;
            var _hoist = array_create(_n + 1), _fly = array_create(_n + 1);
            var _fl = _sp.w * 0.42, _dp = _sp.h * 0.34;
            for (var _k = 0; _k <= _n; _k++) {
                var _u = _k / _n;
                var _wv = sin(_u * 4.2 + 0.6);
                _hoist[_k] = [_pw + _fl * _u, _top + _sp.h * 0.06 + _wv * _sp.h * 0.030];
                _fly[_k] = [_pw + _fl * _u, _top + _sp.h * 0.06 + _dp + _wv * _sp.h * 0.055];
            }
            // The swallow tail: the fly end cuts back, which is what makes it a war banner.
            _fly[_n] = [_pw + _fl * 0.82, _fly[_n][1]];
            _hoist[_n] = [_pw + _fl * 0.82, _hoist[_n][1]];
            var _cloth = [mst_strip(_hoist, _fly, "m2")];
            // Fold shading: two strips inside the cloth, following the same wave.
            var _f1 = array_create(_n + 1), _f2 = array_create(_n + 1);
            for (var _k = 0; _k <= _n; _k++) {
                _f1[_k] = [_hoist[_k][0], lerp(_hoist[_k][1], _fly[_k][1], 0.30)];
                _f2[_k] = [_hoist[_k][0], lerp(_hoist[_k][1], _fly[_k][1], 0.44)];
            }
            mst_append(_cloth, mst_strip(_f1, _f2, "m4"));
            var _f3 = array_create(_n + 1), _f4 = array_create(_n + 1);
            for (var _k = 0; _k <= _n; _k++) {
                _f3[_k] = [_hoist[_k][0], lerp(_hoist[_k][1], _fly[_k][1], 0.68)];
                _f4[_k] = [_hoist[_k][0], lerp(_hoist[_k][1], _fly[_k][1], 0.86)];
            }
            mst_append(_cloth, mst_strip(_f3, _f4, "m0"));
            mst_append(_out, mst_map_roles(_cloth, mst_ground_map("a")));
            // A spearhead finial and the tie rings.
            var _ir = [];
            mst_append(_ir, mst_raise([[-_pw * 1.1, _top + _sp.h * 0.055], [0, _top - _sp.h * 0.055],
                                       [_pw * 1.1, _top + _sp.h * 0.055]], _pw * 0.4, 2, "m3"));
            for (var _k = 0; _k < 2; _k++) {
                mst_append(_ir, mst_boss(_pw * 0.4, _top + _sp.h * (0.09 + _k * 0.30), _pw * 0.8, 8));
            }
            mst_append(_out, mst_map_roles(_ir, mst_ground_map("c")));
        } break;

        case "cache": {
            // Sacks and a chest under a sheet. The SHEET is what says "hidden", and its corner
            // lifting is what says "and somebody knows".
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.50));
            // ⛔ THE SHEET IS THE TALLEST THING HERE AND IT IS DRAWN AT 1.24 * _bh, so the chest
            // height is what the declared extent is really a statement about. The suite caught this
            // at 0.23 against a declared 0.44 - barely half - which would have shipped a "supply
            // cache" that reads as a discarded bag. Solved rather than nudged: _bh is set so that
            // the sheet's own peak lands on the declared height.
            var _box = [];
            var _bw = _sp.w * 0.24, _bh = _sp.h * 0.78;
            var _bx = -_sp.w * 0.14;
            var _cb = [[_bx - _bw, _g - _bh], [_bx + _bw, _g - _bh],
                       [_bx + _bw, _g], [_bx - _bw, _g]];
            mst_append(_box, mst_raise(_cb, mst_bevel_cap(_cb, _bw * 0.18), 2, "m2"));
            mst_append(_out, mst_map_roles(_box, mst_ground_map("b")));
            // Two sacks: lumps with a tied neck, which is the only detail that makes them sacks.
            var _sk = [];
            for (var _k = 0; _k < 2; _k++) {
                var _sx = _sp.w * (0.16 + _k * 0.20);
                var _sr = _sp.w * (0.13 - _k * 0.025);
                var _sy = _g - _sr * 0.9;
                var _lp = mst_lump_pts(_sx, _sy, _sr, _sr * 0.92, 11, 0.14, 0.5, _rng);
                mst_append(_sk, mst_raise(_lp, _sr * 0.28, 3, "m2"));
                mst_append(_sk, mst_ridge([[_sx - _sr * 0.34, _sy - _sr * 0.78],
                                           [_sx + _sr * 0.34, _sy - _sr * 0.78]],
                                          false, _sr * 0.13));
            }
            mst_append(_out, mst_map_roles(_sk, mst_ground_map("a")));
            // The sheet over the chest, one corner turned back.
            var _sh2 = [[_bx - _bw * 1.30, _g - _bh * 0.10], [_bx - _bw * 1.10, _g - _bh * 1.16],
                        [_bx + _bw * 0.30, _g - _bh * 1.24], [_bx + _bw * 1.20, _g - _bh * 0.92],
                        [_bx + _bw * 1.34, _g - _bh * 0.05]];
            mst_append(_out, mst_map_roles(
                mst_raise(_sh2, mst_bevel_cap(_sh2, _bw * 0.16), 3, "m3"), mst_ground_map("a")));
            var _rope = [];
            mst_append(_rope, mst_ridge([[_bx - _bw * 1.2, _g - _bh * 0.62],
                                         [_bx + _bw * 1.26, _g - _bh * 0.54]],
                                        false, _sp.h * 0.024));
            mst_append(_out, mst_map_roles(_rope, mst_ground_map("c")));
        } break;

        case "altar": {
            // A dressed block on a plinth with a channel cut in its top. The CHANNEL is why it is
            // an altar and not a table.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.56));
            var _st2 = [];
            var _pl = [[-_sp.w * 0.5, _g - _sp.h * 0.16], [_sp.w * 0.5, _g - _sp.h * 0.16],
                       [_sp.w * 0.5, _g], [-_sp.w * 0.5, _g]];
            mst_append(_st2, mst_raise(_pl, mst_bevel_cap(_pl, _sp.h * 0.030), 2, "m1"));
            var _bkw = _sp.w * 0.38;
            var _blk = [[-_bkw, _g - _sp.h * 0.86], [_bkw, _g - _sp.h * 0.86],
                        [_bkw, _g - _sp.h * 0.16], [-_bkw, _g - _sp.h * 0.16]];
            mst_append(_st2, mst_raise(_blk, mst_bevel_cap(_blk, _sp.h * 0.05), 3, "m2"));
            // The mensa: a slab overhanging on both sides, which is the classic altar silhouette.
            var _ms = [[-_sp.w * 0.46, _g - _sp.h * 1.0], [_sp.w * 0.46, _g - _sp.h * 1.0],
                       [_sp.w * 0.46, _g - _sp.h * 0.86], [-_sp.w * 0.46, _g - _sp.h * 0.86]];
            mst_append(_st2, mst_raise(_ms, mst_bevel_cap(_ms, _sp.h * 0.035), 3, "m3"));
            // The channel and the drain hole.
            mst_append(_st2, mst_sink(
                mst_pool_pts(0, _g - _sp.h * 0.98, _sp.w * 0.30, _sp.h * 0.038, 16, 0, undefined),
                _sp.h * 0.016, 2, "m0"));
            mst_append(_out, mst_map_roles(_st2, mst_ground_map("a")));
            var _ir2 = [];
            mst_append(_ir2, mst_incise([[-_sp.w * 0.24, _g - _sp.h * 0.58],
                                         [_sp.w * 0.24, _g - _sp.h * 0.58]], false, _sp.h * 0.030));
            mst_append(_ir2, mst_incise([[0, _g - _sp.h * 0.74], [0, _g - _sp.h * 0.42]],
                                        false, _sp.h * 0.030));
            mst_append(_out, mst_map_roles(_ir2, mst_ground_map("b")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(0, _g - _sp.h * 0.24, _sp.w * 0.34, _sp.h * 0.14, 3, _rng),
                mst_ground_map("c")));
        } break;

        case "beacon": {
            // A signal fire on a tripod: unlit brushwood on a frame. Tallest mark in the corpus,
            // and its job is to be visible from the far corner of the map.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.46));
            var _wd = [];
            for (var _k = 0; _k < 3; _k++) {
                var _lx = (_k - 1) * _sp.w * 0.34;
                mst_append(_wd, mst_taper_ribbon([[_lx, _g], [_lx * 0.30, _top + _sp.h * 0.10]],
                                                 _sp.w * 0.028, _sp.w * 0.016, "m2"));
            }
            // The lashing where the three legs cross.
            mst_append(_wd, mst_ridge([[-_sp.w * 0.09, _top + _sp.h * 0.16],
                                       [_sp.w * 0.09, _top + _sp.h * 0.16]], false, _sp.w * 0.030));
            mst_append(_out, mst_map_roles(_wd, mst_ground_map("a")));
            // The basket of brushwood: a lump with sticks breaking its outline, so it reads as
            // loose fuel and not as a solid drum.
            var _bkt2 = mst_canopy_pts(0, _g - _sp.h * 0.60, _sp.w * 0.24, _sp.h * 0.20, 5, 0.20, _rng);
            var _fuel = mst_raise(_bkt2, mst_bevel_cap(_bkt2, _sp.h * 0.035), 3, "m2");
            for (var _k = 0; _k < 7; _k++) {
                var _a = 3.6 + (_k / 6) * 2.5;
                var _sx2 = cos(_a) * _sp.w * 0.24;
                var _sy2 = _g - _sp.h * 0.60 + sin(_a) * _sp.h * 0.20;
                mst_append(_fuel, mst_poly([[_sx2 * 0.4, _g - _sp.h * 0.60],
                                            [_sx2 * 1.55, _sy2 - _sp.h * 0.08]],
                                           false, _sp.w * 0.014, "m1"));
            }
            mst_append(_out, mst_map_roles(_fuel, mst_ground_map("c")));
            var _ir3 = [];
            for (var _k = 0; _k < 2; _k++) {
                mst_append(_ir3, mst_ridge(
                    mst_pool_pts(0, _g - _sp.h * (0.52 + _k * 0.14), _sp.w * 0.25, _sp.h * 0.045,
                                 14, 0, undefined), true, _sp.w * 0.018));
            }
            mst_append(_out, mst_map_roles(_ir3, mst_ground_map("b")));
        } break;

        case "tent": {
            // A ridge tent, guyed. The GUY LINES are what make it read as pitched rather than as a
            // triangle, and the door flap is what makes it a tent rather than a tarpaulin.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.52));
            var _rh = _g - _sp.h;
            var _bw2 = _sp.w * 0.40;
            var _cloth2 = [];
            var _body = [[-_bw2, _g], [-_bw2 * 0.30, _rh], [_bw2 * 0.30, _rh], [_bw2, _g]];
            mst_append(_cloth2, mst_raise(_body, mst_bevel_cap(_body, _sp.h * 0.05), 3, "m2"));
            // The end wall, a darker plane, which is what gives the tent depth.
            var _endw = [[_bw2 * 0.30, _rh], [_bw2, _g], [_bw2 * 1.02, _g],
                         [_bw2 * 0.42, _rh - _sp.h * 0.02]];
            mst_append(_cloth2, mst_ring_fill(_endw, "m0", undefined, undefined));
            // The door: a slit with one flap turned back.
            var _dx = -_bw2 * 0.05;
            mst_append(_cloth2, mst_sink([[_dx - _sp.w * 0.055, _g], [_dx - _sp.w * 0.020, _rh + _sp.h * 0.34],
                                          [_dx + _sp.w * 0.020, _rh + _sp.h * 0.34],
                                          [_dx + _sp.w * 0.055, _g]], _sp.w * 0.020, 2, "m0"));
            mst_append(_cloth2, mst_ring_fill([[_dx + _sp.w * 0.045, _g],
                                               [_dx + _sp.w * 0.020, _rh + _sp.h * 0.34],
                                               [_dx + _sp.w * 0.150, _rh + _sp.h * 0.46],
                                               [_dx + _sp.w * 0.170, _g]], "m3", undefined, undefined));
            mst_append(_out, mst_map_roles(_cloth2, mst_ground_map("a")));
            // Ridge pole ends, and guys running to pegs.
            var _wd2 = [];
            mst_append(_wd2, mst_taper_ribbon([[0, _rh + _sp.h * 0.06], [0, _rh - _sp.h * 0.10]],
                                              _sp.w * 0.016, _sp.w * 0.010, "m2"));
            mst_append(_out, mst_map_roles(_wd2, mst_ground_map("b")));
            var _guy = [];
            for (var _k = 0; _k < 4; _k++) {
                var _side = (_k < 2) ? -1 : 1;
                var _sp6 = _side * _sp.w * (0.46 + (_k % 2) * 0.04);
                var _ay = _g - _sp.h * (0.30 + (_k % 2) * 0.34);
                mst_append(_guy, mst_poly([[_side * _bw2 * (0.32 + (_k % 2) * 0.5), _ay],
                                           [_sp6, _g]], false, _sp.w * 0.010, "m2"));
                mst_append(_guy, mst_poly([[_sp6, _g], [_sp6 + _side * _sp.w * 0.015, _g - _sp.h * 0.05]],
                                          false, _sp.w * 0.014, "m1"));
            }
            mst_append(_out, mst_map_roles(_guy, mst_ground_map("c")));
        } break;

        default: { // ladder
            // A siege ladder leaning against nothing yet. The LEAN is what says it is for a wall
            // that is elsewhere on the map, which is a piece of scenario writing in one object.
            mst_append(_out, mst_contact_shadow(-_sp.w * 0.12, _sp.w * 0.30));
            var _lean = _sp.w * 0.26;
            var _rw = _sp.w * 0.030;
            var _sep = _sp.w * 0.14;
            var _wd3 = [];
            for (var _k = 0; _k < 2; _k++) {
                var _off = (_k == 0) ? -_sep : _sep;
                var _pts = [[_off - _rw, _g], [_off + _rw, _g],
                            [_off + _rw + _lean, _top], [_off - _rw + _lean, _top]];
                mst_append(_wd3, mst_raise(_pts, mst_bevel_cap(_pts, _rw * 0.5), 2, "m2"));
            }
            // Rungs. Their spacing is EVEN, which is the deliberate-object signal this file's
            // header describes; nothing natural in the corpus has an even period.
            var _n2 = 7;
            for (var _k = 0; _k < _n2; _k++) {
                var _u = (_k + 0.5) / _n2;
                var _ry = lerp(_g, _top, _u);
                var _rx = _lean * _u;
                mst_append(_wd3, mst_taper_ribbon([[_rx - _sep, _ry], [_rx + _sep, _ry]],
                                                  _rw * 0.60, _rw * 0.60, "m3"));
            }
            mst_append(_out, mst_map_roles(_wd3, mst_ground_map("a")));
            // Lashings at the rung ends.
            var _lash = [];
            for (var _k = 0; _k < _n2; _k += 2) {
                var _u = (_k + 0.5) / _n2;
                var _ry = lerp(_g, _top, _u);
                var _rx = _lean * _u;
                mst_append(_lash, mst_ridge([[_rx - _sep - _rw, _ry], [_rx - _sep + _rw, _ry]],
                                            false, _rw * 0.5));
                mst_append(_lash, mst_ridge([[_rx + _sep - _rw, _ry], [_rx + _sep + _rw, _ry]],
                                            false, _rw * 0.5));
            }
            mst_append(_out, mst_map_roles(_lash, mst_ground_map("b")));
            // An iron hook at the head, which is what a siege ladder has and a farm one does not.
            var _ir4 = [];
            mst_append(_ir4, mst_ridge(
                mst_arc_pts(_lean - _sep, _top + _sp.h * 0.02, _sp.w * 0.05, pi * 0.2, pi * 1.5, 8),
                false, _rw * 0.7));
            mst_append(_out, mst_map_roles(_ir4, mst_ground_map("c")));
        } break;
    }
    return _out;
}
