{
  "$GMScript": "v1",
  "%Name": "mst_hazard",
  "name": "mst_hazard",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}