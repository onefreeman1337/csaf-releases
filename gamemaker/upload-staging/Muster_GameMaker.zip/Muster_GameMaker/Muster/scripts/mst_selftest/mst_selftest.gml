/// MUSTER - mst_selftest. The in-engine suite.
///
/// ============================================================================================
/// ⛔ GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE. There is no headless runner, no mock, no
/// assertion library. This wing's answer is to build the product through Igor, run the executable
/// with `-selftest`, and have it write a JSON result file - which is the ONE route that survives a
/// release build (show_debug_message is dead in one, and game_end's argument is not propagated).
///
/// ⛔ AND A SUITE FULL OF GREEN ASSERTIONS PROVES NOTHING UNTIL ONE OF THEM HAS BEEN MADE TO FAIL.
/// Two of this wing's worst incidents were suites that could never have gone red: a duplicate check
/// written with a tolerance below GML's default epsilon passed VACUOUSLY for every input, and a
/// containment assertion passed on all 216 letters of a corpus while most of them were being
/// silently shrunk. Where an assertion here could be vacuous, it is PAIRED with one that proves the
/// fixture is in the state the first one needs - and those pairs are marked VACUITY GUARD.
///
/// ⛔ THE DEFAULT EPSILON. math_get_epsilon() returns 0.00001 on this runtime and it PARTICIPATES
/// IN COMPARISONS, so `abs(a - b) < 0.0000001` is FALSE for every pair of values including equal
/// ones, and `abs(a - b) < 0.00001` is RED for two values that are the same object. Never write a
/// tolerance below or at ~1e-5. MST_ST_EPS is the one this file uses.
///
/// ⛔ AND GML HAS NO EXPONENT-LITERAL SYNTAX. `1e-4` is a lexer error that reads like a bracket
/// bug. Every tolerance in this package is written out in full.
///
/// ⚠️ WHAT THIS SUITE CANNOT SEE, STATED HERE RATHER THAN LEFT FOR A BUYER TO DISCOVER: it computes
/// POINTS and NUMBERS. It cannot see a FILL RULE, a DRAW ORDER or a PICTURE. This wing has shipped
/// a crescent moon rendered as a quarter, a rainbow that never drew at all and a gilt rim across
/// twelve plates, all with the geometry suite fully green. The instrument for those is opening the
/// baked sheet and looking at it, and that step is not optional because this file exists.
/// ============================================================================================

#macro MST_ST_EPS 0.0001

function mst_st_new() {
    return { pass: 0, fail: 0, notes: [] };
}

function mst_st_ok(_r, _cond, _what) {
    if (_cond) { _r.pass += 1; return; }
    _r.fail += 1;
    // Cap the note list. A systemic failure can fire thousands of times and a result file that
    // cannot be written is a result file nobody reads.
    if (array_length(_r.notes) < 60) array_push(_r.notes, _what);
}

/// ============================================================================================
/// THE SUITE
/// ============================================================================================

function mst_selftest_run() {
    var _r = mst_st_new();

    // -- STAGE 0: the runtime still behaves the way this package assumes -----------------------
    global.mst_stage = 0;
    var _e = math_get_epsilon();
    // ⛔ TWO CLAUSES, AND THE SECOND IS `!(_e > 0)` ON PURPOSE. The natural single expression
    // `_e > 0 && _e < TOL` goes RED on its first clause forever: the difference between the epsilon
    // and zero IS the epsilon, so GML calls them equal, and equal is not greater-than. Written this
    // way it is a POSITIVE test that the runtime still applies an epsilon, and it goes red the day
    // a release stops - which is a thing this package would need to know.
    mst_st_ok(_r, !(_e > 0), "epsilon: expected _e > 0 to be FALSE (the epsilon trap is gone)");
    mst_st_ok(_r, _e < 0.001, "epsilon: larger than this package's tolerances");

    // -- STAGE 1: the corpus is the size it says it is -------------------------------------------
    global.mst_stage = 1;
    var _feats = mst_feature_names();
    var _mats = mst_ground_names();
    var _seasons = mst_season_names();
    var _biomes = mst_biome_names();
    mst_st_ok(_r, array_length(_feats) == MST_FEATURE_N, "feature count != MST_FEATURE_N: "
              + string(array_length(_feats)));
    mst_st_ok(_r, array_length(_mats) == MST_GROUND_N, "material count != MST_GROUND_N: "
              + string(array_length(_mats)));
    mst_st_ok(_r, array_length(_seasons) == MST_SEASON_N, "season count != MST_SEASON_N");
    mst_st_ok(_r, array_length(_biomes) == MST_BIOME_N, "biome count != MST_BIOME_N");

    // ⭐ THE VOLUME CLAIM, ASSERTED. The store page says fifty-two authored terrain features across
    // eight seasons and eight biomes, and a marketing number that nothing checks is a number that
    // drifts. If a feature is dropped, the LISTING goes wrong and this goes red on the same day.
    mst_st_ok(_r, array_length(_feats) >= 40,
              "authored feature count fell below the 40 the listing claims: " + string(array_length(_feats)));

    // Names must be unique. A duplicated name silently makes the corpus smaller than it counts.
    for (var _i = 0; _i < array_length(_feats); _i++) {
        for (var _j = _i + 1; _j < array_length(_feats); _j++) {
            mst_st_ok(_r, _feats[_i] != _feats[_j], "duplicate feature name: " + _feats[_i]);
        }
    }

    // -- STAGE 2: every material resolves, ramps do not collapse, ink is legible ----------------
    global.mst_stage = 2;
    for (var _i = 0; _i < array_length(_mats); _i++) {
        var _m = _mats[_i];
        var _ramp = mst_ground_ramp(_m, "verdant", 0, 0);
        mst_st_ok(_r, array_length(_ramp) == MST_RAMP_N, "ramp wrong length: " + _m);
        // ⛔ NO TWO ADJACENT STOPS MAY COLLAPSE. The Hearth limewash defect: a ramp whose top stops
        // both clamp to the ceiling makes a bevel whose two brightest walls are the same colour,
        // which reads as a flat fill with a line round it. mst_ground_ramp SLIDES rather than
        // clamping, and this is what proves it still does.
        for (var _k = 0; _k < MST_RAMP_N - 1; _k++) {
            mst_st_ok(_r, _ramp[_k] != _ramp[_k + 1],
                      "ramp stops " + string(_k) + "/" + string(_k + 1) + " collapsed: " + _m);
        }
        mst_st_ok(_r, mst_ground_ink_sep(_m, "verdant", 0) > 0.20,
                  "ink too close to its own ground: " + _m);
    }

    // -- STAGE 3: THE SEASON MODEL. Negative control, positive control, and the span pull ---------
    global.mst_stage = 3;
    // ⛔ THE NEGATIVE CONTROL. granite and basalt carry susc 0.00, so at FULL strength in EVERY
    // season their ramp must be byte-identical to the unseasoned one. A global screen tint - which
    // is what a naive implementation of "seasons" is - cannot satisfy this, so the day someone
    // simplifies mst_ground_seasoned into a multiply this goes red.
    var _rockRef = mst_ground_ramp("granite", "verdant", 0, 0);
    for (var _s = 0; _s < array_length(_seasons); _s++) {
        var _rk = mst_ground_ramp("granite", _seasons[_s], 1.0, 0);
        for (var _k = 0; _k < MST_RAMP_N; _k++) {
            mst_st_ok(_r, _rk[_k] == _rockRef[_k],
                      "granite MOVED under " + _seasons[_s] + " at stop " + string(_k)
                      + " - the season is being applied as a tint");
        }
    }

    // ⭐ THE POSITIVE CONTROL, AND IT IS THE VACUITY GUARD FOR THE ONE ABOVE. Without it, a
    // mst_ground_seasoned that returned its input unchanged for EVERYTHING would pass the negative
    // control perfectly. turf carries susc 1.00 and must genuinely move in every season that pulls.
    var _turfRef = mst_ground_ramp("turf", "verdant", 0, 0);
    var _moved = 0;
    for (var _s = 0; _s < array_length(_seasons); _s++) {
        var _tk = mst_ground_ramp("turf", _seasons[_s], 1.0, 0);
        var _diff = false;
        for (var _k = 0; _k < MST_RAMP_N; _k++) if (_tk[_k] != _turfRef[_k]) _diff = true;
        if (_diff) _moved += 1;
    }
    mst_st_ok(_r, _moved >= 7, "VACUITY GUARD: turf moved in only " + string(_moved)
              + " of 8 seasons - the season model is doing nothing and the negative control above "
              + "is therefore meaningless");

    // ⛔ SPAN IS PULLED, NOT SCALED, and this pair is the only thing in the file that can tell the
    // two models apart. A multiplier can ONLY make a span smaller, so one case of a span going UP
    // refutes it outright.
    //
    // ⚠️ THE FIRST VERSION OF THIS ASSERTION WAS WRITTEN AGAINST THE WRONG FIXTURE AND WENT RED ON
    // ITS FIRST IN-ENGINE RUN, which is the assertion working. It claimed snowbound (target span
    // 0.10) would pull cord's 0.12 UPWARD - but 0.10 is BELOW 0.12, so snow pulls cord DOWN, and no
    // material in the table has a span under 0.10 for snow to raise. It was also testing the
    // FIXTURE ("is this material's span below the target?") rather than the BEHAVIOUR, so even
    // green it would have proved nothing about the model. Both halves are fixed here, and what is
    // asserted is that the span ACTUALLY MOVED - a statement about mst_ground_seasoned, not about
    // the table.
    //
    // ⛔ AND BOTH FIXTURES ARE GROUND MATERIALS, WHICH THE SECOND DRAFT GOT WRONG TOO. `cord` and
    // `waterx` live in mst_extra_spec, not in the ground table, and mst_ground_spec falls back to a
    // mid-grey default for anything it does not know - so a "cord" fixture would have silently
    // measured the span of the DEFAULT and reported on a material that was never involved. That is
    // the vacuous shape this file exists to prevent, one level down: an assertion running happily
    // over an input nobody supplied. moss (span 0.16) is below verdant's 0.24 target and shingle
    // (0.34) is above snowbound's 0.10, and both are in mst_ground_names().
    var _mossUp = mst_ground_seasoned("moss", "verdant", 1.0);
    var _mossFlat = mst_ground_spec("moss");
    mst_st_ok(_r, _mossUp.span > _mossFlat.span + 0.0001,
              "span was not pulled UPWARD for moss under verdant (" + string(_mossFlat.span)
              + " -> " + string(_mossUp.span) + ") - the season is SCALING span, not pulling it");
    // And the other direction, so the assertion above cannot be satisfied by a model that only
    // ever increases span.
    var _shingDown = mst_ground_seasoned("shingle", "snowbound", 1.0);
    var _shingFlat = mst_ground_spec("shingle");
    mst_st_ok(_r, _shingDown.span < _shingFlat.span - 0.0001,
              "span was not pulled DOWNWARD for shingle under snowbound (" + string(_shingFlat.span)
              + " -> " + string(_shingDown.span) + ")");

    // -- STAGE 4: every feature spec resolves, and every material slot resolves -------------------
    global.mst_stage = 4;
    var _slotChecked = 0;
    for (var _i = 0; _i < array_length(_feats); _i++) {
        var _id = _feats[_i];
        var _sp = mst_feature_spec(_id);
        mst_st_ok(_r, !is_undefined(_sp), "no spec for named feature: " + _id);
        if (is_undefined(_sp)) continue;
        // ⛔ A SLOT NAME THAT RESOLVES TO NOTHING PAINTS A FEATURE THE COLOUR OF A DEFAULT. This is
        // the assertion that catches a typo in the spec table, which is otherwise invisible: the
        // feature still draws, just in the wrong material, and nobody notices for six seasons.
        var _slots = [_sp.a, _sp.b, _sp.c];
        for (var _k = 0; _k < 3; _k++) {
            mst_st_ok(_r, !is_undefined(mst_slot_spec(_slots[_k])),
                      "feature " + _id + " slot " + string(_k) + " names an unknown material: "
                      + string(_slots[_k]));
            _slotChecked += 1;
        }
        mst_st_ok(_r, _sp.w > 0.10 && _sp.w <= 1.0, "feature " + _id + " has a silly declared width");
        mst_st_ok(_r, _sp.h > 0.10 && _sp.h <= 1.0, "feature " + _id + " has a silly declared height");
        mst_st_ok(_r, _sp.tall >= 0 && _sp.tall <= 3, "feature " + _id + " tall out of range");
        // A feature that blocks sight must be drawn tall enough to plausibly do so.
        if (_sp.los) mst_st_ok(_r, _sp.tall >= 1, "feature " + _id + " blocks LOS at tall 0");
    }
    // VACUITY GUARD for the slot loop.
    mst_st_ok(_r, _slotChecked == MST_FEATURE_N * 3,
              "VACUITY GUARD: slot check ran over " + string(_slotChecked) + " slots, expected "
              + string(MST_FEATURE_N * 3));

    // -- STAGE 5: every feature builds, in every season, and its geometry is finite ---------------
    global.mst_stage = 5;
    var _built = 0;
    for (var _i = 0; _i < array_length(_feats); _i++) {
        var _id2 = _feats[_i];
        for (var _s = 0; _s < array_length(_seasons); _s++) {
            var _p = mst_feature_parts(_id2, 40 + _i * 13 + _s, _seasons[_s], 1.0);
            mst_st_ok(_r, array_length(_p) > 0, "feature built NOTHING: " + _id2 + "/" + _seasons[_s]);
            if (array_length(_p) == 0) continue;
            _built += 1;
            var _b = mst_render_bounds(_p);
            // ⛔ NOT `is_real` - EVERY GML NUMBER IS REAL, INCLUDING A NaN. The test that actually
            // catches a NaN is that it is not equal to itself, because NaN compares false to
            // everything including itself. A NaN in a vertex draws nothing and reports no error.
            mst_st_ok(_r, _b[0] == _b[0] && _b[1] == _b[1] && _b[2] == _b[2] && _b[3] == _b[3],
                      "NaN in bounds: " + _id2 + "/" + _seasons[_s]);
            // The unit box plus a margin for the contact shadow, which is allowed below the floor.
            mst_st_ok(_r, _b[0] >= -1.2 && _b[2] <= 1.2 && _b[1] >= -1.2 && _b[3] <= 1.2,
                      "feature escapes the unit box: " + _id2 + "/" + _seasons[_s]
                      + " bounds " + string(_b[0]) + "," + string(_b[1]) + " to "
                      + string(_b[2]) + "," + string(_b[3]));
        }
    }
    mst_st_ok(_r, _built == MST_FEATURE_N * MST_SEASON_N,
              "VACUITY GUARD: built " + string(_built) + " forms, expected "
              + string(MST_FEATURE_N * MST_SEASON_N));

    // -- STAGE 6: THE PICTURE IS HONEST ABOUT THE RULES -------------------------------------------
    global.mst_stage = 6;
    // ⭐ THIS IS THE ASSERTION THE WHOLE PRODUCT RESTS ON, so it is worth saying exactly what it
    // does and does not prove.
    //
    // (a) A feature must be DRAWN to about the height it DECLARES. This is NOT the vacuous shape
    //     the wing recorded on Hearth ("a declared extent the builder reads as its own scale, so
    //     editing the number proves nothing"): each builder here independently decides what
    //     FRACTION of its declared _sp.h it actually uses, so a builder that draws to 60% of its
    //     declaration fires here by name. The band is deliberately loose because a canopy that
    //     bulges past its nominal radius is correct and a shrub that stops short of it is too.
    // (b) A feature that blocks two more levels of sight than another must be drawn TALLER than it.
    //     Adjacent bands are allowed to overlap - a tall gatepost and a short tower are both
    //     reasonable - but a two-band inversion means the picture is lying to the player about a
    //     rule they can see.
    var _measured = 0;
    for (var _i = 0; _i < array_length(_feats); _i++) {
        var _id3 = _feats[_i];
        var _sp3 = mst_feature_spec(_id3);
        var _hh = mst_feature_height(_id3, 77 + _i);
        _measured += 1;
        mst_st_ok(_r, _hh >= _sp3.h * 0.70,
                  "drawn much SHORTER than declared: " + _id3 + " drew " + string(_hh)
                  + " against a declared " + string(_sp3.h));
        mst_st_ok(_r, _hh <= _sp3.h * 1.30,
                  "drawn much TALLER than declared: " + _id3 + " drew " + string(_hh)
                  + " against a declared " + string(_sp3.h));
    }
    mst_st_ok(_r, _measured == MST_FEATURE_N, "VACUITY GUARD: measured " + string(_measured)
              + " feature heights, expected " + string(MST_FEATURE_N));

    var _pairs = 0;
    for (var _i = 0; _i < array_length(_feats); _i++) {
        var _a1 = mst_feature_spec(_feats[_i]);
        for (var _j = 0; _j < array_length(_feats); _j++) {
            var _b1 = mst_feature_spec(_feats[_j]);
            if (_a1.tall < _b1.tall + 2) continue;
            _pairs += 1;
            mst_st_ok(_r, _a1.h > _b1.h,
                      "height inversion: " + _feats[_i] + " (tall " + string(_a1.tall)
                      + ", h " + string(_a1.h) + ") is not drawn taller than " + _feats[_j]
                      + " (tall " + string(_b1.tall) + ", h " + string(_b1.h) + ")");
        }
    }
    // VACUITY GUARD: the loop above skips almost every pair, so it must be shown to have run.
    mst_st_ok(_r, _pairs > 100, "VACUITY GUARD: the tall-band ordering check compared only "
              + string(_pairs) + " pairs");

    // -- STAGE 7: FIELDS. Generated, connected, standable, and the rules match the picture --------
    global.mst_stage = 7;
    var _fields = 0, _feated = 0, _rulesChecked = 0;
    for (var _bi = 0; _bi < array_length(_biomes); _bi++) {
        for (var _si = 0; _si < array_length(_seasons); _si++) {
            var _fd = mst_field_make(11, 11, 1000 + _bi * 31 + _si * 7, _biomes[_bi],
                                     _seasons[_si], 1.0);
            _fields += 1;

            // PROMISE 1: crossable. mst_field_connect repairs until it is, so a -1 here means it
            // ran out of features to clear and the GROUND itself seals the map - which would be a
            // real defect in a biome's ground bands.
            mst_st_ok(_r, _fd.pathCost >= 0,
                      "field is NOT crossable: " + _biomes[_bi] + "/" + _seasons[_si]);

            // PROMISE 2: every deployment cell is standable.
            for (var _k = 0; _k < array_length(_fd.deployA); _k++) {
                mst_st_ok(_r, _fd.cells[_fd.deployA[_k]].cost < MST_IMPASSABLE,
                          "impassable deployment cell (A) in " + _biomes[_bi] + "/" + _seasons[_si]);
            }
            for (var _k = 0; _k < array_length(_fd.deployB); _k++) {
                mst_st_ok(_r, _fd.cells[_fd.deployB[_k]].cost < MST_IMPASSABLE,
                          "impassable deployment cell (B) in " + _biomes[_bi] + "/" + _seasons[_si]);
            }

            // ⭐ PROMISE 3, AND IT IS THE PRODUCT: for every cell that carries a feature, the
            // tactical row in the cell must be the feature spec's own row. If this ever goes red,
            // a buyer has a battlefield where a drawn boulder queries as open ground - the exact
            // failure this package exists to make impossible.
            for (var _ci = 0; _ci < array_length(_fd.cells); _ci++) {
                var _c2 = _fd.cells[_ci];
                if (_c2.feat == "") continue;
                _feated += 1;
                var _fs = mst_feature_spec(_c2.feat);
                mst_st_ok(_r, !is_undefined(_fs), "cell carries an unknown feature: " + _c2.feat);
                if (is_undefined(_fs)) continue;
                _rulesChecked += 1;
                mst_st_ok(_r, _c2.cover == _fs.cover, "cover drifted from the spec: " + _c2.feat);
                mst_st_ok(_r, _c2.los == _fs.los, "los drifted from the spec: " + _c2.feat);
                mst_st_ok(_r, _c2.tall == _fs.tall, "tall drifted from the spec: " + _c2.feat);
                // An impassable feature must make its cell impassable, and only an impassable
                // feature (or impassable ground) may.
                if (_fs.cost >= MST_IMPASSABLE) {
                    mst_st_ok(_r, _c2.cost >= MST_IMPASSABLE,
                              "impassable feature on a passable cell: " + _c2.feat);
                }
                mst_st_ok(_r, _c2.cost > 0, "non-positive cost on a featured cell: " + _c2.feat);
            }
        }
    }
    mst_st_ok(_r, _fields == MST_BIOME_N * MST_SEASON_N,
              "VACUITY GUARD: generated " + string(_fields) + " fields");
    // ⛔ THE GUARD THAT MATTERS MOST IN THIS FILE. Every assertion in the PROMISE 3 block is inside
    // `if (_c2.feat == "") continue;`, so a scatter step that placed NOTHING would sail through the
    // whole block with a perfect score. This is the Hearth firelight lesson: an assertion that
    // depends on a fixture being in a particular state needs a second assertion that it is.
    mst_st_ok(_r, _feated > 200, "VACUITY GUARD: only " + string(_feated)
              + " cells carried a feature across 64 fields - the rule checks above ran over almost "
              + "nothing and prove almost nothing");
    mst_st_ok(_r, _rulesChecked == _feated, "some featured cells were skipped by the rule check");

    // -- STAGE 8: TACTICS ------------------------------------------------------------------------
    global.mst_stage = 8;
    var _tf = mst_field_make(12, 12, 424242, "ruins", "harvest", 0.8);
    // Line of sight must be SYMMETRIC. If A can see B then B can see A: the sight line is the same
    // segment and the eye heights are the same two numbers whichever end you start from. An
    // asymmetric result means the sampling or the height interpolation has a direction bug, which
    // is the classic way a hand-rolled tactical LOS goes wrong.
    var _losPairs = 0, _losSeen = 0;
    for (var _y = 0; _y < _tf.h; _y += 2) {
        for (var _x = 0; _x < _tf.w; _x += 2) {
            for (var _y2 = 0; _y2 < _tf.h; _y2 += 3) {
                for (var _x2 = 0; _x2 < _tf.w; _x2 += 3) {
                    var _ab = mst_los(_tf, _x, _y, _x2, _y2);
                    var _ba = mst_los(_tf, _x2, _y2, _x, _y);
                    _losPairs += 1;
                    if (_ab) _losSeen += 1;
                    mst_st_ok(_r, _ab == _ba, "LOS is asymmetric between " + string(_x) + ","
                              + string(_y) + " and " + string(_x2) + "," + string(_y2));
                }
            }
        }
    }
    mst_st_ok(_r, _losPairs > 200, "VACUITY GUARD: LOS symmetry ran over " + string(_losPairs) + " pairs");
    // ⛔ AND SYMMETRY ALONE IS SATISFIED BY "NOBODY CAN SEE ANYTHING". Two guards, both directions:
    // a field where nothing is visible and a field where everything is would each pass the
    // symmetry test perfectly while being useless as a battlefield.
    mst_st_ok(_r, _losSeen > _losPairs * 0.10,
              "VACUITY GUARD: almost nothing is visible on this field - LOS may be blocking always");
    mst_st_ok(_r, _losSeen < _losPairs * 0.98,
              "VACUITY GUARD: almost everything is visible - LOS may never block, and a ruins field "
              + "full of walls should block plenty");

    // A path's step costs must sum to the distance field's answer. This is what proves mst_path and
    // mst_field_dist are reading the same rules - and since mst_field_dist now calls mst_step_cost,
    // it also proves that single copy is the one both of them use.
    var _dist = mst_field_dist(_tf, [mst_idx(_tf, 0, 0)]);
    var _paths = 0;
    for (var _k = 0; _k < 24; _k++) {
        var _tx = (_k * 5) % _tf.w, _ty = (_k * 7) % _tf.h;
        var _pth = mst_path(_tf, 0, 0, _tx, _ty);
        var _want = _dist[mst_idx(_tf, _tx, _ty)];
        if (_want >= MST_IMPASSABLE) {
            mst_st_ok(_r, array_length(_pth) == 0,
                      "a path was returned to an unreachable cell " + string(_tx) + "," + string(_ty));
            continue;
        }
        mst_st_ok(_r, array_length(_pth) > 0, "no path to a reachable cell " + string(_tx) + ","
                  + string(_ty));
        if (array_length(_pth) == 0) continue;
        _paths += 1;
        var _sum = 0;
        for (var _s2 = 0; _s2 < array_length(_pth) - 1; _s2++) {
            _sum += mst_step_cost(_tf, _pth[_s2][0], _pth[_s2][1],
                                  _pth[_s2 + 1][0], _pth[_s2 + 1][1]);
        }
        mst_st_ok(_r, _sum == _want, "path cost " + string(_sum) + " disagrees with the distance "
                  + "field's " + string(_want) + " for " + string(_tx) + "," + string(_ty));
        // The path must start and end where it was asked to.
        mst_st_ok(_r, _pth[0][0] == 0 && _pth[0][1] == 0, "path does not start at the source");
        var _lastp = _pth[array_length(_pth) - 1];
        mst_st_ok(_r, _lastp[0] == _tx && _lastp[1] == _ty, "path does not end at the target");
    }
    mst_st_ok(_r, _paths >= 8, "VACUITY GUARD: only " + string(_paths) + " paths were checked");

    // A movement range must be a subset of the full distance field, cut at the budget.
    var _rng6 = mst_move_range(_tf, 0, 0, 6);
    var _inRange = 0;
    for (var _i = 0; _i < array_length(_rng6); _i++) {
        if (_rng6[_i] < MST_IMPASSABLE) {
            _inRange += 1;
            mst_st_ok(_r, _rng6[_i] <= 6, "a cell beyond the budget is inside the move range");
            mst_st_ok(_r, _rng6[_i] == _dist[_i], "move range disagrees with the distance field");
        }
    }
    mst_st_ok(_r, _inRange > 4, "VACUITY GUARD: the move range held " + string(_inRange) + " cells");

    // Directional cover must never exceed the cell's own cover, and must be a legal value.
    var _covChecked = 0;
    for (var _y = 1; _y < _tf.h - 1; _y += 2) {
        for (var _x = 1; _x < _tf.w - 1; _x += 2) {
            var _cf = mst_cover_from(_tf, _x, _y, _x + 1, _y);
            _covChecked += 1;
            mst_st_ok(_r, _cf >= MST_COVER_NONE && _cf <= MST_COVER_HARD,
                      "cover_from returned an illegal value: " + string(_cf));
        }
    }
    mst_st_ok(_r, _covChecked > 8, "VACUITY GUARD: cover_from ran over " + string(_covChecked) + " cells");

    // ⛔ THE COVER MODEL, ASSERTED AFTER IT SHIPPED WRONG ONTO A STORE SHEET. `cell.cover` is what a
    // feature PROVIDES; what a unit standing somewhere GETS is mst_cover_best over that cell and its
    // neighbours; and nobody standing in an impassable cell gets anything, because nobody stands
    // there. The hero sheet printed "hard cover 0 cells" over a field of ruin walls before this
    // distinction existed. Three properties, and the third is the vacuity guard.
    var _impSeen = 0, _bestSeen = 0, _hardSeen = 0;
    for (var _y = 0; _y < _tf.h; _y++) {
        for (var _x = 0; _x < _tf.w; _x++) {
            var _cc = mst_cell(_tf, _x, _y);
            if (_cc.cost >= MST_IMPASSABLE) {
                _impSeen += 1;
                mst_st_ok(_r, mst_cover_at(_tf, _x, _y) == MST_COVER_NONE,
                          "cover_at returned cover for a cell nobody can stand in");
                mst_st_ok(_r, mst_cover_best(_tf, _x, _y) == MST_COVER_NONE,
                          "cover_best returned cover for a cell nobody can stand in");
                continue;
            }
            var _bb = mst_cover_best(_tf, _x, _y);
            mst_st_ok(_r, _bb >= mst_cover_at(_tf, _x, _y),
                      "cover_best is below the cell's own cover");
            if (_bb > MST_COVER_NONE) _bestSeen += 1;
            if (_bb == MST_COVER_HARD) _hardSeen += 1;
        }
    }
    mst_st_ok(_r, _impSeen > 2, "VACUITY GUARD: only " + string(_impSeen)
              + " impassable cells - the cover_at/cover_best impassable rule barely ran");
    mst_st_ok(_r, _bestSeen > 4, "VACUITY GUARD: only " + string(_bestSeen)
              + " cells had any cover at all on a ruins field");
    // ⭐ AND THE ONE THAT WOULD HAVE CAUGHT THE ORIGINAL DEFECT BY NAME. A ruins field is made of
    // walls, so a report claiming zero cells are behind hard cover is wrong on its face.
    mst_st_ok(_r, _hardSeen > 0,
              "no cell on a RUINS field is behind hard cover - the cover model is counting cells "
              + "that CONTAIN cover rather than cells that are BEHIND it");

    // The report has to agree with the field it describes.
    var _rep = mst_field_report(_tf);
    mst_st_ok(_r, _rep.cells == _tf.w * _tf.h, "report cell count wrong");
    mst_st_ok(_r, _rep.passable + _rep.blocked == _rep.cells, "report passable + blocked != cells");
    mst_st_ok(_r, _rep.hardCover + _rep.softCover + _rep.openGround == _rep.passable,
              "report cover classes do not partition the passable cells");
    mst_st_ok(_r, _rep.goingRate >= 1, "report going rate below 1");

    // -- STAGE 9: DETERMINISM. The same arguments must give the same battlefield -----------------
    global.mst_stage = 9;
    // ⭐ THIS IS WHAT MAKES A GENERATED MAP SAVEABLE, so it is asserted rather than assumed: a
    // buyer stores the seed instead of the map, and a replay or a multiplayer peer rebuilds it
    // exactly. Anything that reached for random() instead of the seeded generator breaks this and
    // nothing else in the suite would notice.
    var _d1 = mst_field_make(9, 9, 5150, "woodland", "fallow", 0.7);
    var _d2 = mst_field_make(9, 9, 5150, "woodland", "fallow", 0.7);
    var _same = 0, _cellsCompared = 0;
    for (var _i = 0; _i < array_length(_d1.cells); _i++) {
        var _x1 = _d1.cells[_i], _x2 = _d2.cells[_i];
        _cellsCompared += 1;
        if (_x1.ground == _x2.ground && _x1.level == _x2.level && _x1.feat == _x2.feat
            && _x1.cost == _x2.cost) _same += 1;
    }
    mst_st_ok(_r, _cellsCompared == 81, "VACUITY GUARD: determinism compared "
              + string(_cellsCompared) + " cells");
    mst_st_ok(_r, _same == _cellsCompared, "the same seed produced a DIFFERENT field: "
              + string(_cellsCompared - _same) + " cells differ");
    // And a different seed must produce a different field, or the seed is being ignored.
    var _d3 = mst_field_make(9, 9, 5151, "woodland", "fallow", 0.7);
    var _diff2 = 0;
    for (var _i = 0; _i < array_length(_d1.cells); _i++) {
        if (_d1.cells[_i].feat != _d3.cells[_i].feat
            || _d1.cells[_i].level != _d3.cells[_i].level) _diff2 += 1;
    }
    mst_st_ok(_r, _diff2 > 4, "VACUITY GUARD: two different seeds produced nearly the same field ("
              + string(_diff2) + " cells differ) - the seed may be ignored");

    // -- STAGE 10: TEXT IS ASCII -----------------------------------------------------------------
    global.mst_stage = 10;
    // ⛔ THE SHIPPED FONTS DECLARE 32..127 AND A MISSING GLYPH DRAWS NOTHING AT ALL - no error, no
    // warning, no missing-glyph box, just absence, which reads as a deliberate space. This wing
    // shipped a COVER reading "40 THEMES  DRAWN IN GML" because a middle dot is U+00B7. Every
    // string this package can generate is checked here, and Internal_Ops/ascii_check.js checks the
    // literals offline before the build.
    var _texts = [];
    for (var _i = 0; _i < array_length(_feats); _i++) array_push(_texts, _feats[_i]);
    for (var _i = 0; _i < array_length(_mats); _i++) array_push(_texts, _mats[_i]);
    for (var _i = 0; _i < array_length(_seasons); _i++) array_push(_texts, _seasons[_i]);
    for (var _i = 0; _i < array_length(_biomes); _i++) array_push(_texts, _biomes[_i]);
    var _scanned = 0;
    for (var _i = 0; _i < array_length(_texts); _i++) {
        var _txt = _texts[_i];
        _scanned += string_length(_txt);
        var _bad = -1;
        for (var _c3 = 1; _c3 <= string_length(_txt); _c3++) {
            var _o = ord(string_char_at(_txt, _c3));
            if (_o < 32 || _o > 126) { _bad = _o; break; }
        }
        mst_st_ok(_r, _bad == -1, "non-ASCII character " + string(_bad) + " in corpus name: " + _txt);
    }
    mst_st_ok(_r, _scanned > 300, "VACUITY GUARD: the ASCII scan read " + string(_scanned)
              + " characters");

    // ⛔ STAGE 99 MEANS "THE SUITE REACHED THE END". Every stage above sets global.mst_stage on the
    // way past, and the crash handler writes whatever it was last set to - so a suite that dies in
    // stage 7 records 7. Without a terminal marker, a run that crashed after its last assertion
    // would write a result file full of passes and no failures, which is indistinguishable from
    // success by every number in it. The runner REQUIRES 99 and fails the run otherwise.
    global.mst_stage = 99;
    return _r;
}

/// ============================================================================================
/// THE RESULT FILE
///
/// ⛔ file_text_open_write IS THE ONLY ROUTE THAT SURVIVES A RELEASE BUILD. Measured by this wing:
/// show_debug_message with -debugoutput yields a file holding only engine boot lines, and
/// game_end(n)'s argument is NOT propagated to the process exit code. This writes to
/// %LOCALAPPDATA%/Muster/ and needs no runner flag at all.
/// ============================================================================================

function mst_selftest_write(_r) {
    var _f = file_text_open_write("mst_selftest.json");
    var _notes = "";
    for (var _i = 0; _i < array_length(_r.notes); _i++) {
        if (_i > 0) _notes += " | ";
        _notes += string_replace_all(string(_r.notes[_i]), "\"", "'");
    }
    file_text_write_string(_f,
        "{\"pass\":" + string(_r.pass)
        + ",\"fail\":" + string(_r.fail)
        + ",\"stage\":" + string(global.mst_stage)
        + ",\"epsilon\":" + string_format(math_get_epsilon(), 1, 12)
        + ",\"version\":\"" + MST_VERSION + "\""
        + ",\"notes\":\"" + _notes + "\"}");
    file_text_close(_f);
}
