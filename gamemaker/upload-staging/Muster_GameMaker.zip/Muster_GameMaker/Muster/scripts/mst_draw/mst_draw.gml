/// MUSTER - mst_draw. Putting a field on the screen.
///
/// -- THE PROJECTION ---------------------------------------------------------------------------
/// Two-to-one isometric: a cell is a diamond twice as wide as it is tall, and a level of elevation
/// raises it by MST_RISE pixels and exposes the two side walls beneath it. This is the projection
/// the highest-priced product on this shelf uses, and it is not a coincidence: it is the only
/// common one in which ELEVATION IS VISIBLE AT ALL. In a flat top-down view a level-3 ridge and a
/// level-0 hollow are the same picture with different colours, and every rule in mst_tactics that
/// depends on height becomes something a player has to be told rather than something they can see.
///
/// -- DRAW ORDER IS THE WHOLE FILE -------------------------------------------------------------
/// ⛔ THE PAINTER'S ORDER IS BY (x + y), AND WITHIN A CELL IT IS WALLS, THEN TOP, THEN FEATURE.
/// Get any part of that wrong and the failure is not subtle: a wall drawn after its own top face
/// paints over the cell in front of it, and a feature drawn before the top face is buried in the
/// ground it stands on. The wing has the general form of this written down twice - a flash goes
/// UNDER the thing it illuminates, and a rim appended last straddles the food on the plate.
///
/// -- ⭐ AND THE OVERLAYS ARE THE PRODUCT'S PROOF, NOT A CONVENIENCE ----------------------------
/// mst_draw_cover, mst_draw_range and mst_draw_los read the SAME cell fields that mst_field wrote
/// when it placed the drawn feature. Switching the cover overlay on over a finished battlefield and
/// seeing the marks land exactly on the walls, boulders and hedges is the demonstration that the
/// picture and the rules are one object - which is the entire claim this package is sold on, and
/// the reason the demo room binds it to a key.
/// ============================================================================================

#macro MST_CELL_W 64
#macro MST_CELL_H 32
#macro MST_RISE   14

/// Where the CENTRE of a cell's top face lands on screen.
function mst_cell_sx(_f, _x, _y, _ox) {
    return _ox + (_x - _y) * (MST_CELL_W * 0.5);
}

function mst_cell_sy(_f, _x, _y, _oy) {
    var _c = mst_cell(_f, _x, _y);
    var _lv = is_undefined(_c) ? 0 : _c.level;
    return _oy + (_x + _y) * (MST_CELL_H * 0.5) - _lv * MST_RISE;
}

/// The four corners of a cell's top face, in screen space, clockwise from the north corner.
function mst_cell_diamond(_f, _x, _y, _ox, _oy) {
    var _sx = mst_cell_sx(_f, _x, _y, _ox);
    var _sy = mst_cell_sy(_f, _x, _y, _oy);
    var _hw = MST_CELL_W * 0.5, _hh = MST_CELL_H * 0.5;
    return [[_sx, _sy - _hh], [_sx + _hw, _sy], [_sx, _sy + _hh], [_sx - _hw, _sy]];
}

/// How many pixels a whole field occupies at the natural cell pitch. Returns [w, h].
///
/// ⛔ ONE PLACE, BECAUSE TWO CALLERS NEED IT AND THEY MUST NOT DISAGREE. mst_field_origin centres a
/// field using these numbers and mst_bk_field SCALES one using them; the first version of the bake
/// worked the extent out for itself, got it wrong, and put a clipped field on six of eight store
/// sheets - which the ink check caught and named. Derive it here, use it there.
function mst_field_extent(_f) {
    var _hw = MST_CELL_W * 0.5, _hh = MST_CELL_H * 0.5;
    return [(_f.w + _f.h) * _hw,
            (_f.w + _f.h) * _hh + (MST_LEVELS - 1) * MST_RISE];
}

/// Suggested origin so a whole field lands centred in a rect. Returns [ox, oy].
///
/// ⚠️ THE ARITHMETIC IS WRITTEN OUT RATHER THAN TUNED, because an origin fudged until one field
/// looked centred is an origin that is wrong for every other field size - and this package's whole
/// point is that the size, the biome and the seed all vary. Derived, not adjusted:
///
///   x: sx = ox + (x - y) * HW, so (x - y) runs over [-(h-1), (w-1)] and the drawn centre sits at
///      ox + (w - h) * HW / 2. Setting that equal to the rect's centre gives ox.
///   y: sy = oy + (x + y) * HH - level * RISE, so the TOP of the drawing is oy - (LEVELS-1) * RISE
///      - HH (a cell's own half-height above its centre) and the BOTTOM is oy + (w + h - 2) * HH
///      + HH. The span between those is the height to centre.
function mst_field_origin(_f, _x, _y, _w, _h) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return [0, 0];
    var _hw = MST_CELL_W * 0.5, _hh = MST_CELL_H * 0.5;
    var _ox = _x + _w * 0.5 - (_f.w - _f.h) * _hw * 0.5;

    var _riseTop = (MST_LEVELS - 1) * MST_RISE;
    var _spanH = (_f.w + _f.h - 2) * _hh + _hh * 2 + _riseTop;
    // The topmost ink sits at oy - _riseTop - _hh, so putting that at the rect's top margin gives:
    var _oy = _y + (_h - _spanH) * 0.5 + _riseTop + _hh;
    return [_ox, _oy];
}

/// Fill a palette with everything a field needs: one ramp per ground material present, the shadow
/// role, and the overlay inks.
///
/// ⚠️ IT ONLY BUILDS THE MATERIALS THE FIELD ACTUALLY USES. A field of downland touches five of
/// twenty-eight, and building all twenty-eight every frame would be twenty-three wasted Oklab
/// conversions per material per stop. The seen-set is a struct because GML has no set type and a
/// linear scan over a growing array is the thing that would make this show up in a profiler.
function mst_field_palette(_f) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return undefined;
    var _pal = {};
    var _seen = {};
    for (var _i = 0; _i < array_length(_f.cells); _i++) {
        var _m = _f.cells[_i].ground;
        if (variable_struct_exists(_seen, _m)) continue;
        variable_struct_set(_seen, _m, true);
        var _r = mst_ground_ramp(_m, _f.season, _f.season_t, 0);
        for (var _k = 0; _k < MST_RAMP_N; _k++) {
            variable_struct_set(_pal, "g_" + _m + string(_k), _r[_k]);
        }
    }
    // The contact-shadow role every feature uses, keyed off the season so a snowbound field's
    // shadows are the cold blue-grey of shadow on snow rather than the brown of shadow on earth.
    var _sp = mst_season_spec(_f.season);
    var _sh = is_undefined(_sp) ? { L: 0.30, C: 0.010, h: 70 } : _sp;
    _pal.s0 = mst_oklch(max(0.045, _sh.L * 0.42), _sh.C * 0.5, _sh.h);
    // Overlay inks. Deliberately not derived from the season: an overlay is INTERFACE, and an
    // interface that changes legibility with the weather is one a player stops trusting.
    _pal.ov_hard = mst_oklch(0.62, 0.115, 28);
    _pal.ov_soft = mst_oklch(0.70, 0.100, 88);
    _pal.ov_move = mst_oklch(0.66, 0.090, 232);
    _pal.ov_los  = mst_oklch(0.80, 0.080, 96);
    _pal.ov_edge = mst_oklch(0.14, 0.010, 250);
    _pal.ov_obj  = mst_oklch(0.74, 0.120, 320);
    return _pal;
}

/// Draw the ground: side walls and top faces, back to front.
function mst_draw_ground(_f, _pal, _ox, _oy) {
    for (var _d = 0; _d <= (_f.w - 1) + (_f.h - 1); _d++) {
        for (var _x = 0; _x < _f.w; _x++) {
            var _y = _d - _x;
            if (_y < 0 || _y >= _f.h) continue;
            var _c = _f.cells[mst_idx(_f, _x, _y)];
            var _dm = mst_cell_diamond(_f, _x, _y, _ox, _oy);
            var _base = "g_" + _c.ground;

            // -- SIDE WALLS. The two faces a viewer can see are the south-west and south-east
            // ones, and each is only as deep as the drop to the neighbour BEYOND it. Drawing both
            // walls full depth to the ground would paint over the cell in front on flat terrain.
            var _south = mst_cell(_f, _x, _y + 1);
            var _east = mst_cell(_f, _x + 1, _y);
            var _dropW = _c.level - (is_undefined(_south) ? -1 : _south.level);
            var _dropE = _c.level - (is_undefined(_east) ? -1 : _east.level);

            // ⛔ THE TOP-FACE STOP IS MAPPED ACROSS THE LEVEL RANGE, NOT ADDED TO A BASE. The first
            // version wrote `clamp(2 + level + mottle, 1, 4)`, which SATURATES: at level 2 the sum
            // is already 4 and at level 3 it is 5, so both clamp to the same stop and the mottle is
            // arithmetically discarded - on exactly the high plateaux where a large flat region
            // most needs breaking up. The scenario sheet showed the waste biome's basalt plateau as
            // one enormous grey slab, and it stayed a slab AFTER the mottle was added, because the
            // clamp was eating it. Found by cropping that region and enlarging it.
            //
            // ⭐ The general form is worth keeping: a term added to a value that is then clamped is
            // a term that silently does nothing at the top of the range, which is where it is
            // usually needed most. Map into the range instead of adding and clamping.
            //
            // ⚠️ THE MOTTLE IS A NOISE FIELD, NOT PER-CELL RANDOMNESS. Independent jitter reads as
            // static; sampling a smooth field at a small scale gives patches a few cells across,
            // which is what ground actually looks like. Seeded from the field, so it never flickers.
            var _mot = mst_noise2(_f.seed + 555, _x, _y, 2.6);
            var _bump = (_mot < 0.38) ? -1 : ((_mot > 0.72) ? 1 : 0);
            // ⛔ AND THE LEVEL RANGE DOES NOT REACH THE BOTTOM OF THE RAMP. Mapping level 0 to
            // stop 1 put large areas of LOW ground on a dark material at the ramp's darkest stops,
            // where a whole basin of cinder rendered as a black void with no cell divisions in it
            // - the same slab defect as before, arriving from the opposite end of the range. Low
            // ground is in SHADOW, not absent; it needs to stay a readable surface.
            var _lvlStop = 1.6 + (_c.level / max(1, MST_LEVELS - 1)) * 1.6;
            var _stop = clamp(round(_lvlStop + _bump), 0, MST_RAMP_N - 1);
            // Walls are keyed to the TOP FACE rather than to fixed stops, so the relationship
            // survives whatever the mottle did and whatever material this is. The east wall is
            // turned further from the lamp than the west one, so it is one stop darker again.
            var _wallW = string(clamp(_stop - 1, 0, MST_RAMP_N - 1));
            var _wallE = string(clamp(_stop - 2, 0, MST_RAMP_N - 1));

            if (_dropW > 0) {
                var _dep = _dropW * MST_RISE;
                draw_set_colour(variable_struct_get(_pal, _base + _wallW));
                draw_primitive_begin(pr_trianglefan);
                draw_vertex(_dm[3][0], _dm[3][1]);
                draw_vertex(_dm[2][0], _dm[2][1]);
                draw_vertex(_dm[2][0], _dm[2][1] + _dep);
                draw_vertex(_dm[3][0], _dm[3][1] + _dep);
                draw_primitive_end();
            }
            if (_dropE > 0) {
                var _dep2 = _dropE * MST_RISE;
                // The east wall is turned FURTHER from the lamp than the west one, so it is one
                // stop darker. Two walls at the same value read as a flat hexagon, which is the
                // single commonest way an isometric terrace fails to read as solid.
                draw_set_colour(variable_struct_get(_pal, _base + _wallE));
                draw_primitive_begin(pr_trianglefan);
                draw_vertex(_dm[2][0], _dm[2][1]);
                draw_vertex(_dm[1][0], _dm[1][1]);
                draw_vertex(_dm[1][0], _dm[1][1] + _dep2);
                draw_vertex(_dm[2][0], _dm[2][1] + _dep2);
                draw_primitive_end();
            }

            // -- TOP FACE. Level shading: higher ground catches more light, which is what makes a
            // terrace read as height rather than as a pattern. The stop was computed above, with
            // the walls, so all three faces of a cell agree.
            //
            // ⛔ PLUS A MOTTLE, AND IT IS NOT DECORATION - IT FIXES A DEFECT THAT REACHED A STORE
            // SHEET. A large region of one material at one elevation has no internal edges at all:
            // every top face is the same colour and there are no side walls between equal-level
            // neighbours, so it renders as a single flat rectangle. On the scenario sheet the waste
            // biome's basalt plateau came out as an enormous grey slab with a border, which is the
            // one thing generated terrain must never look like. Nothing mechanical saw it - the ink
            // check counts a slab as ink, and the ground was perfectly correct as DATA.
            //
            // ⚠️ IT IS A NOISE FIELD, NOT PER-CELL RANDOMNESS. Independent jitter reads as static;
            // sampling a smooth field at a small scale gives patches a few cells across, which is
            // what ground actually looks like. Seeded from the field, so it never flickers.
            draw_set_colour(variable_struct_get(_pal, _base + string(_stop)));
            draw_primitive_begin(pr_trianglefan);
            for (var _k = 0; _k < 4; _k++) draw_vertex(_dm[_k][0], _dm[_k][1]);
            draw_primitive_end();

            // ⛔⛔ EVERY CELL GETS A FAINT EDGE, UNCONDITIONALLY, AND THIS IS THE FIX THAT ACTUALLY
            // WORKED. The mottle above was the second attempt at the flat-slab defect and it only
            // half-worked: it is a three-band quantisation of a smooth noise field, so wherever that
            // field sits in the middle band across a whole region, every cell gets the same stop and
            // the region is flat again. The waste biome's basin did exactly that TWICE, and the
            // instinct each time was to retune the noise scale or the thresholds.
            //
            // ⭐ That is the trap this factory keeps paying for: tuning a threshold until one case
            // passes leaves every case you did not look at. A cell edge is not a probability - a
            // region of one material at one level now has structure BY CONSTRUCTION, whatever the
            // noise did, because the thing that makes an isometric field readable is that you can
            // see where the cells are. It is also what a tactics map genuinely looks like.
            //
            // ⚠️ Drawn in the cell's own darker stop rather than a fixed colour, so it stays a
            // shading edge on pale snow and on dark basalt alike; a fixed dark line would read as a
            // drawn grid on snow and vanish on cinder.
            draw_set_alpha(0.30);
            draw_set_colour(variable_struct_get(_pal, _base + _wallE));
            for (var _k = 0; _k < 4; _k++) {
                var _e0 = _dm[_k], _e1 = _dm[(_k + 1) % 4];
                draw_line(_e0[0], _e0[1], _e1[0], _e1[1]);
            }
            draw_set_alpha(1);
        }
    }
}

/// Draw a single cell's feature, standing on the cell's top face.
///
/// ⛔ THE FEATURE IS PLACED BY ITS GROUND LINE, NOT FITTED TO A RECT. mst_render_in_rect_tight
/// would scale each form to fill its cell, which destroys the one thing the corpus was authored to
/// preserve: a menhir is drawn nearly three times the height of a drystone wall BECAUSE its spec
/// says tall:3 against tall:1. Fitting them to the same box would make the picture disagree with
/// the rules on every cell, silently, and the height assertions in mst_selftest would still pass
/// because they measure the CORPUS rather than the screen.
function mst_draw_feature(_f, _x, _y, _pal, _ox, _oy) {
    var _c = mst_cell(_f, _x, _y);
    if (is_undefined(_c) || _c.feat == "") return;
    var _parts = mst_feature_parts(_c.feat, _c.featSeed, _f.season, _f.season_t);
    if (array_length(_parts) == 0) return;

    mst_feature_palette(_pal, _c.feat, _f.season, _f.season_t);
    var _s = MST_CELL_W * 0.92;
    var _gx = mst_cell_sx(_f, _x, _y, _ox);
    var _gy = mst_cell_sy(_f, _x, _y, _oy);
    // Unit-box GROUND sits at MST_GROUND, so this is the offset that puts the floor line on the
    // cell centre. One expression, one place.
    var _cy = _gy - MST_GROUND * _s;
    mst_render_parts(_parts, _pal, _gx, _cy, _s, 0, _s / MST_CELL_W, undefined);
}

/// The whole field: ground, then features, both back to front.
///
/// ⚠️ FEATURES ARE A SECOND PASS RATHER THAN BEING DRAWN INSIDE THE GROUND LOOP, and that is not
/// tidiness. A tall feature on a near cell must cover the ground of the cells behind it, but a
/// feature drawn inside the ground loop is painted over by every later cell's top face - so a
/// palisade would have its top half sliced off by the field behind it. Two passes, both in the same
/// order.
function mst_field_draw(_f, _pal, _ox, _oy) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_f)) return;
    mst_draw_ground(_f, _pal, _ox, _oy);
    for (var _d = 0; _d <= (_f.w - 1) + (_f.h - 1); _d++) {
        for (var _x = 0; _x < _f.w; _x++) {
            var _y = _d - _x;
            if (_y < 0 || _y >= _f.h) continue;
            mst_draw_feature(_f, _x, _y, _pal, _ox, _oy);
        }
    }
}

/// ============================================================================================
/// OVERLAYS - the proof
/// ============================================================================================

/// Outline one cell's top face.
function mst_draw_cell_outline(_f, _x, _y, _ox, _oy, _col, _w) {
    var _dm = mst_cell_diamond(_f, _x, _y, _ox, _oy);
    draw_set_colour(_col);
    for (var _k = 0; _k < 4; _k++) {
        var _a = _dm[_k], _b = _dm[(_k + 1) % 4];
        draw_line_width(_a[0], _a[1], _b[0], _b[1], _w);
    }
}

/// Tint one cell's top face.
function mst_draw_cell_tint(_f, _x, _y, _ox, _oy, _col, _alpha) {
    var _dm = mst_cell_diamond(_f, _x, _y, _ox, _oy);
    draw_set_colour(_col);
    draw_set_alpha(_alpha);
    draw_primitive_begin(pr_trianglefan);
    for (var _k = 0; _k < 4; _k++) draw_vertex(_dm[_k][0], _dm[_k][1]);
    draw_primitive_end();
    draw_set_alpha(1);
}

/// Where a unit can stand and be covered.
///
/// ⛔ IT TINTS THE CELLS AROUND A WALL, NOT THE WALL. The first version tinted whatever cell held a
/// cover feature, which paints a boulder red and tells a player nothing - you cannot stand in a
/// boulder. What a tactics player needs to see is the GROUND that boulder protects, so this reads
/// mst_cover_best, which is the same question the report answers and the same one mst_cover_from
/// answers for a specific shot. The marks still hug the drawn features, which is the point the
/// store sheet is making; they now hug them from the outside, which is where a unit goes.
function mst_draw_cover(_f, _pal, _ox, _oy) {
    for (var _y = 0; _y < _f.h; _y++) {
        for (var _x = 0; _x < _f.w; _x++) {
            var _cov = mst_cover_best(_f, _x, _y);
            if (_cov == MST_COVER_HARD) {
                mst_draw_cell_tint(_f, _x, _y, _ox, _oy, _pal.ov_hard, 0.42);
            } else if (_cov == MST_COVER_SOFT) {
                mst_draw_cell_tint(_f, _x, _y, _ox, _oy, _pal.ov_soft, 0.32);
            }
        }
    }
}

/// A movement range, from mst_move_range.
function mst_draw_range(_f, _pal, _d, _ox, _oy) {
    for (var _y = 0; _y < _f.h; _y++) {
        for (var _x = 0; _x < _f.w; _x++) {
            if (_d[mst_idx(_f, _x, _y)] >= MST_IMPASSABLE) continue;
            mst_draw_cell_tint(_f, _x, _y, _ox, _oy, _pal.ov_move, 0.34);
        }
    }
}

/// Everything one cell can see.
function mst_draw_los(_f, _pal, _ax, _ay, _ox, _oy) {
    for (var _y = 0; _y < _f.h; _y++) {
        for (var _x = 0; _x < _f.w; _x++) {
            if (!mst_los(_f, _ax, _ay, _x, _y)) continue;
            mst_draw_cell_tint(_f, _x, _y, _ox, _oy, _pal.ov_los, 0.24);
        }
    }
}

/// Deployment zones, chokepoints and objectives - what a scenario writer put on the map.
function mst_draw_plan(_f, _pal, _ox, _oy) {
    for (var _k = 0; _k < array_length(_f.deployA); _k++) {
        var _i = _f.deployA[_k];
        mst_draw_cell_outline(_f, _i % _f.w, _i div _f.w, _ox, _oy, _pal.ov_move, 2);
    }
    for (var _k = 0; _k < array_length(_f.deployB); _k++) {
        var _i2 = _f.deployB[_k];
        mst_draw_cell_outline(_f, _i2 % _f.w, _i2 div _f.w, _ox, _oy, _pal.ov_hard, 2);
    }
    for (var _k = 0; _k < array_length(_f.chokepoints); _k++) {
        var _i3 = _f.chokepoints[_k];
        mst_draw_cell_tint(_f, _i3 % _f.w, _i3 div _f.w, _ox, _oy, _pal.ov_obj, 0.30);
    }
    for (var _k = 0; _k < array_length(_f.objectives); _k++) {
        var _o = _f.objectives[_k];
        var _ox2 = _o.at % _f.w, _oy2 = _o.at div _f.w;
        mst_draw_cell_outline(_f, _ox2, _oy2, _ox, _oy, _pal.ov_obj, 3);
    }
}

/// The grid, drawn faintly. Off by default: a tactics map wants it while a unit is selected and not
/// otherwise, and a permanently gridded field looks like a spreadsheet.
function mst_draw_grid(_f, _pal, _ox, _oy) {
    draw_set_alpha(0.20);
    for (var _y = 0; _y < _f.h; _y++) {
        for (var _x = 0; _x < _f.w; _x++) {
            mst_draw_cell_outline(_f, _x, _y, _ox, _oy, _pal.ov_edge, 1);
        }
    }
    draw_set_alpha(1);
}

/// A path from mst_path, as a line through the cell centres.
function mst_draw_path(_f, _pal, _path, _ox, _oy) {
    if (array_length(_path) < 2) return;
    draw_set_colour(_pal.ov_move);
    for (var _k = 0; _k < array_length(_path) - 1; _k++) {
        var _a = _path[_k], _b = _path[_k + 1];
        draw_line_width(mst_cell_sx(_f, _a[0], _a[1], _ox), mst_cell_sy(_f, _a[0], _a[1], _oy),
                        mst_cell_sx(_f, _b[0], _b[1], _ox), mst_cell_sy(_f, _b[0], _b[1], _oy), 3);
    }
}
