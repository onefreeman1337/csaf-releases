/// MUSTER - mst_stone. The eight features the ground itself throws up.
///
/// boulder, menhir, cairn, outcrop, rubble, screeslope, fissure, sinkhole.
///
/// -- WHY STONE IS THE FILE TO GET RIGHT FIRST -------------------------------------------------
/// Rock is the negative control for the whole season model. Granite and basalt carry `susc: 0.00`
/// in mst_ground, which means a snowbound field must show the SAME boulder as a high-summer one -
/// and if it does not, the season is being applied as a screen tint and every claim this product
/// makes about generated terrain is false. So these eight are the features to look at first on any
/// re-baked sheet, and the ones whose sameness across eight seasons is asserted rather than
/// eyeballed.
///
/// ⚠️ THE ONE THING THAT DOES CHANGE ON A ROCK IS WHAT IS GROWING ON IT. Moss (susc 0.70) and
/// lichen (susc 0.30) are slot b and slot c on almost every feature here, so a boulder in blight
/// is a granite boulder with dead grey crust on it rather than a grey boulder. That is the correct
/// physical answer and it is also the more interesting picture.
/// ============================================================================================

/// A faceted rock body: one lump, bevelled once, with two or three cleavage planes incised across
/// it.
///
/// ⛔ THE FACETS ARE INCISED LINES AND NOT SEPARATE MASSES, which is the wing's "a chain of masses
/// reads as a chain" law applied before it could bite. Building a boulder from four overlapping
/// lumps bevels each on its OWN outline, so every join grows a lit rim and the rock reads as a pile
/// of buns. One mass with grooves cut across it reads as one rock that has split.
function mst_rock_body(_cx, _cy, _rx, _ry, _lobes, _rough, _rng) {
    var _pts = mst_lump_pts(_cx, _cy, _rx, _ry, _lobes, _rough, 0.72, _rng);
    var _bev = mst_bevel_cap(_pts, min(_rx, _ry) * 0.42);
    var _out = mst_raise(_pts, _bev, 3, "m2");

    // Cleavage. A plane runs right across the mass - a short scratch reads as damage, a plane reads
    // as geology.
    //
    // ⛔⛔ CLIPPED TO THE OUTLINE'S SPAN AT EACH y, NOT TO ITS BOUNDING BOX. The first version used
    // the bounding box, and it is wrong for every shape that is not a rectangle: a lump is only as
    // wide as its box at ONE height, so a cleavage line drawn at any other height overhangs the rock
    // on both sides. On the corpus sheet at 100 px that reads as a faint edge artefact; on the
    // detail sheet at four times the size the boulder has two lines sticking out of it like whiskers.
    //
    // ⭐ This is the wing's Borough law arriving again - a form rendered on a catalogue plate and the
    // same form rendered at size are two different tests - and the instrument was the same one:
    // making a sheet that draws things LARGE, and looking at it. Nothing mechanical can see this,
    // because a line outside a shape is still valid geometry inside the unit box.
    var _n = 1 + floor(mst_rng_next(_rng) * 2.99);
    for (var _i = 0; _i < _n; _i++) {
        var _u = 0.28 + mst_rng_next(_rng) * 0.44;
        var _bb = mst_pts_bounds(_pts);
        var _y = lerp(_bb[1], _bb[3], _u);
        var _tilt = (mst_rng_next(_rng) * 2 - 1) * (_ry * 0.24);
        var _sp0 = mst_span_at_y(_pts, _y - _tilt);
        var _sp1 = mst_span_at_y(_pts, _y + _tilt);
        if (is_undefined(_sp0) || is_undefined(_sp1)) continue;
        // Inset a little from the silhouette at both ends: a cleavage that touches the outline
        // reads as a crack THROUGH the rock rather than a plane within it.
        var _x0 = max(_sp0[0], _sp1[0]) + _rx * 0.06;
        var _x1 = min(_sp0[1], _sp1[1]) - _rx * 0.06;
        if (_x1 <= _x0) continue;
        mst_append(_out, mst_incise([[_x0, _y - _tilt * 0.5], [_x1, _y + _tilt * 0.5]],
                                    false, min(_rx, _ry) * 0.075));
    }
    return _out;
}

/// The horizontal span of a closed outline at a given y, as [x0, x1], or undefined if the line
/// misses the shape.
///
/// ⚠️ IT TAKES THE OUTERMOST CROSSINGS, which is right for the convex-ish lumps this corpus uses
/// and would be wrong for a C-shape (it would bridge the opening). Nothing in mst_stone is
/// C-shaped; anything that becomes so needs the crossings sorted and paired instead.
function mst_span_at_y(_pts, _y) {
    var _n = array_length(_pts);
    var _lo = 999, _hi = -999, _hits = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i], _b = _pts[(_i + 1) % _n];
        // Half-open test so a vertex exactly on the line is counted once, not twice.
        if ((_a[1] <= _y && _b[1] > _y) || (_b[1] <= _y && _a[1] > _y)) {
            var _dy = _b[1] - _a[1];
            if (_dy == 0) continue;
            var _x = _a[0] + (_b[0] - _a[0]) * ((_y - _a[1]) / _dy);
            _lo = min(_lo, _x); _hi = max(_hi, _x);
            _hits += 1;
        }
    }
    if (_hits < 2) return undefined;
    return [_lo, _hi];
}

/// Moss and lichen on a stone.
///
/// ⚠️ IT GOES ON THE SIDE AWAY FROM THE LAMP, and that is a physical fact rather than a
/// composition preference: the lamp in mst_relief sits up and to the LEFT (MST_LX, MST_LY are both
/// negative), so the damp, shaded, moss-growing side of any rock in this package is the lower
/// right. Scattering growth evenly over a rock is the tell that it was placed by a loop rather
/// than by weather.
function mst_stone_growth(_cx, _cy, _rx, _ry, _count, _rng) {
    var _out = [];
    var _n = max(0, _count);
    for (var _i = 0; _i < _n; _i++) {
        // Bias into the lower-right quadrant: angle sampled around +45 degrees in y-down space.
        var _a = 0.35 + mst_rng_next(_rng) * 1.9;
        var _rr = 0.52 + mst_rng_next(_rng) * 0.42;
        var _px = _cx + cos(_a) * _rx * _rr;
        var _py = _cy + sin(_a) * _ry * _rr;
        var _pr = min(_rx, _ry) * (0.13 + mst_rng_next(_rng) * 0.15);
        var _pat = mst_pool_pts(_px, _py, _pr * 1.25, _pr * 0.78, 10, 0.30, _rng);
        mst_append(_out, mst_ring_fill(_pat, "m3", undefined, undefined));
    }
    return _out;
}

function mst_stone_parts(_id, _sp, _rng, _season, _t) {
    var _out = [];
    var _g = MST_GROUND;

    switch (_id) {
        case "boulder": {
            var _cy = _g - _sp.h * 0.50;
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.52));
            mst_append(_out, mst_map_roles(
                mst_rock_body(0, _cy, _sp.w * 0.5, _sp.h * 0.5, 13, 0.16, _rng),
                mst_ground_map("a")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(0, _cy, _sp.w * 0.42, _sp.h * 0.42, 3, _rng),
                mst_ground_map("b")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(0, _cy, _sp.w * 0.38, _sp.h * 0.38, 2, _rng),
                mst_ground_map("c")));
        } break;

        case "menhir": {
            // A standing stone leans. A perfectly upright one reads as a placed prop; every real
            // menhir in a field has been pushed by four hundred winters of frost.
            var _lean = (mst_rng_next(_rng) * 2 - 1) * 0.055;
            var _top = _g - _sp.h;
            var _pts = mst_shaft_pts(0, _g, _top, _sp.w, _sp.w * 0.62, _lean, 5);
            // ⚠️ The head of a standing stone is IRREGULAR, and squaring it is what makes a menhir
            // read as a fence post. Two of the top samples are pulled in and down.
            _pts[5] = [_pts[5][0] + _sp.w * 0.10, _pts[5][1] + _sp.h * 0.045];
            _pts[6] = [_pts[6][0] - _sp.w * 0.06, _pts[6][1] + _sp.h * 0.020];
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.80));
            var _body = mst_raise(_pts, mst_bevel_cap(_pts, _sp.w * 0.26), 3, "m2");
            var _bb = mst_pts_bounds(_pts);
            for (var _i = 0; _i < 3; _i++) {
                var _y = lerp(_bb[1], _bb[3], 0.22 + _i * 0.26);
                var _seg = mst_clip_seg(_bb[0], _y, _bb[2], _y + _sp.h * 0.03,
                                        _bb[0], _bb[1], _bb[2], _bb[3]);
                if (!is_undefined(_seg)) {
                    mst_append(_body, mst_incise([_seg[0], _seg[1]], false, _sp.w * 0.055));
                }
            }
            mst_append(_out, mst_map_roles(_body, mst_ground_map("a")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(_lean * 0.4, _g - _sp.h * 0.30, _sp.w * 0.36, _sp.h * 0.24, 3, _rng),
                mst_ground_map("b")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(_lean * 0.4, _g - _sp.h * 0.55, _sp.w * 0.30, _sp.h * 0.22, 2, _rng),
                mst_ground_map("c")));
        } break;

        case "cairn": {
            // Stacked stones, largest at the base, each one narrower and shorter than the last.
            // The stack LEANS as it rises because a cairn is built by hand and nobody builds a
            // plumb one out of field stone.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.56));
            var _levels = 4;
            var _y = _g;
            var _drift = 0;
            var _body = [];
            for (var _i = 0; _i < _levels; _i++) {
                var _u = _i / (_levels - 1);
                var _rx = _sp.w * 0.5 * (1 - _u * 0.52);
                var _ry = _sp.h * 0.5 * 0.30 * (1 - _u * 0.30);
                _drift += (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.07;
                var _cy = _y - _ry;
                mst_append(_body, mst_raise(
                    mst_lump_pts(_drift, _cy, _rx, _ry, 9, 0.14, 0.55, _rng),
                    _ry * 0.44, 2, "m2"));
                _y = _cy - _ry * 0.72;
            }
            mst_append(_out, mst_map_roles(_body, mst_ground_map("a")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(0, _g - _sp.h * 0.18, _sp.w * 0.40, _sp.h * 0.16, 3, _rng),
                mst_ground_map("b")));
        } break;

        case "outcrop": {
            // Bedrock breaking the surface: a wide low mass with a stepped top, not a lump. The
            // step is what says "this is the same rock the hill is made of" rather than "a big
            // pebble was put here".
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.54));
            var _x0 = -_sp.w * 0.5, _x1 = _sp.w * 0.5;
            var _top = _g - _sp.h;
            var _pts = [
                [_x0, _g],
                [_x0 + _sp.w * 0.10, _top + _sp.h * 0.30],
                [_x0 + _sp.w * 0.34, _top + _sp.h * 0.34],
                [_x0 + _sp.w * 0.40, _top],
                [_x0 + _sp.w * 0.72, _top + _sp.h * 0.08],
                [_x1 - _sp.w * 0.06, _top + _sp.h * 0.46],
                [_x1, _g],
            ];
            var _body = mst_raise(_pts, mst_bevel_cap(_pts, _sp.h * 0.30), 3, "m2");
            // Bedding planes run along the strike, i.e. across the mass, near-horizontal.
            for (var _i = 0; _i < 3; _i++) {
                var _yy = _top + _sp.h * (0.42 + _i * 0.19);
                mst_append(_body, mst_incise([[_x0 + _sp.w * 0.06, _yy],
                                              [_x1 - _sp.w * 0.06, _yy + _sp.h * 0.03]],
                                             false, _sp.h * 0.05));
            }
            mst_append(_out, mst_map_roles(_body, mst_ground_map("a")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(_sp.w * 0.16, _g - _sp.h * 0.30, _sp.w * 0.32, _sp.h * 0.24, 4, _rng),
                mst_ground_map("b")));
            mst_append(_out, mst_map_roles(
                mst_stone_growth(-_sp.w * 0.20, _g - _sp.h * 0.22, _sp.w * 0.22, _sp.h * 0.18, 2, _rng),
                mst_ground_map("c")));
        } break;

        case "rubble": {
            // A collapse: dressed blocks, so the shapes are ANGULAR and of two or three sizes.
            // Rounded lumps here would read as a pile of boulders and lose the "something stood
            // here" that makes rubble worth putting on a map.
            mst_append(_out, mst_contact_shadow(0, _sp.w * 0.56));
            var _blocks = [];
            var _dust = [];
            var _n = 9;
            for (var _i = 0; _i < _n; _i++) {
                var _u = _i / (_n - 1);
                var _bx = lerp(-_sp.w * 0.42, _sp.w * 0.42, _u)
                        + (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.06;
                // Height falls off from the middle: a heap, not a row.
                var _pile = sin(pi * _u);
                var _bw = _sp.w * (0.13 + mst_rng_next(_rng) * 0.09);
                // ⛔ THESE THREE COEFFICIENTS WERE TOO SMALL AND THE SUITE CAUGHT IT: rubble drew
                // to 0.14 against a declared 0.30, i.e. under HALF the height of the thing it says
                // it is. A heap that low reads as gravel, and a player told it is soft cover would
                // not believe the picture. The block heights and the pile lift are both raised so
                // the crown of the heap reaches its declared extent; the ROTATION is why it cannot
                // simply be h/2 - a tilted block presents less vertical extent than its own height.
                var _bh = _sp.h * (0.40 + mst_rng_next(_rng) * 0.30) * (0.52 + _pile * 0.48);
                var _by = _g - _bh * (0.5 + _pile * 0.72);
                var _rot = (mst_rng_next(_rng) * 2 - 1) * 0.42;
                var _blk = mst_pts_chamfer(-_bw * 0.5, -_bh * 0.5, _bw * 0.5, _bh * 0.5, _bw * 0.18);
                var _pl = [];
                for (var _k = 0; _k < array_length(_blk); _k++) {
                    var _px = _blk[_k][0], _py = _blk[_k][1];
                    var _cc = cos(_rot), _ss = sin(_rot);
                    _pl[_k] = [_bx + _px * _cc - _py * _ss, _by + _px * _ss + _py * _cc];
                }
                mst_append(_blocks, mst_raise(_pl, mst_bevel_cap(_pl, min(_bw, _bh) * 0.24), 2, "m2"));
            }
            // Broken brick shows in the core of a collapse, under the dressed facing.
            for (var _i = 0; _i < 5; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.30;
                var _pr = _sp.w * (0.035 + mst_rng_next(_rng) * 0.035);
                mst_append(_dust, mst_ring_fill(
                    mst_pool_pts(_px, _g - _sp.h * (0.10 + mst_rng_next(_rng) * 0.28),
                                 _pr, _pr * 0.8, 8, 0.24, _rng), "m2", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_blocks, mst_ground_map("a")));
            mst_append(_out, mst_map_roles(_dust, mst_ground_map("b")));
        } break;

        case "screeslope": {
            // Lying flat on the ground: no contact shadow, because nothing stands up.
            var _stones = [];
            var _big = [];
            var _n = 26;
            for (var _i = 0; _i < _n; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.48;
                // Scree fans DOWNHILL, so density rises toward the near (lower) edge.
                var _v = mst_rng_next(_rng);
                var _py = _g - _sp.h * (1 - _v * _v) * 0.92;
                var _pr = _sp.w * (0.022 + mst_rng_next(_rng) * 0.034);
                var _sh = mst_pool_pts(_px, _py, _pr, _pr * 0.62, 7, 0.34, _rng);
                if (mst_rng_next(_rng) < 0.24) {
                    mst_append(_big, mst_raise(_sh, _pr * 0.34, 2, "m2"));
                } else {
                    mst_append(_stones, mst_ring_fill(_sh, "m2", undefined, undefined));
                }
            }
            mst_append(_out, mst_map_roles(_stones, mst_ground_map("a")));
            mst_append(_out, mst_map_roles(_big, mst_ground_map("b")));
        } break;

        case "fissure": {
            // A crack. The dark THROAT is the subject and the lipped edges are what make it read as
            // a hole rather than as a painted stripe - so the throat is SUNK, with its walls lit
            // from the opposite side, which is exactly what mst_sink is for.
            var _n = 12;
            var _spine = array_create(_n + 1);
            for (var _i = 0; _i <= _n; _i++) {
                var _u = _i / _n;
                _spine[_i] = [lerp(-_sp.w * 0.48, _sp.w * 0.48, _u),
                              _g - _sp.h * 0.34 + sin(_u * 5.2) * _sp.h * 0.22];
            }
            var _wid = array_create(_n + 1);
            for (var _i = 0; _i <= _n; _i++) {
                var _u = _i / _n;
                // Zero width at both ends BY CONSTRUCTION - a crack that stops with a blunt end is
                // the vertical-end-wall defect this wing paid for on cloud rails.
                _wid[_i] = sin(pi * _u) * _sp.h * (0.16 + mst_rng_next(_rng) * 0.06);
            }
            var _lip = [];
            for (var _i = 0; _i <= _n; _i++) {
                _lip[_i] = [_spine[_i][0], _spine[_i][1] - _wid[_i]];
            }
            for (var _i = _n; _i >= 0; _i--) {
                array_push(_lip, [_spine[_i][0], _spine[_i][1] + _wid[_i]]);
            }
            mst_append(_out, mst_map_roles(
                mst_sink(_lip, mst_bevel_cap(_lip, _sp.h * 0.09), 2, "m0"),
                mst_ground_map("a")));
            // Spoil thrown up along the upper lip.
            var _spoil = [];
            for (var _i = 0; _i < 7; _i++) {
                var _u = 0.12 + mst_rng_next(_rng) * 0.76;
                var _k = floor(_u * _n);
                var _pr = _sp.w * (0.020 + mst_rng_next(_rng) * 0.026);
                mst_append(_spoil, mst_ring_fill(
                    mst_pool_pts(_spine[_k][0], _spine[_k][1] - _wid[_k] - _pr * 0.5,
                                 _pr, _pr * 0.62, 7, 0.30, _rng), "m2", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_spoil, mst_ground_map("b")));
        } break;

        default: { // sinkhole
            // A collapse in the turf: a sunken ellipse whose FAR wall is lit and whose near wall is
            // in shadow, plus a darker throat that is not concentric with the rim, because a
            // sinkhole undercuts on one side.
            var _rim = mst_pool_pts(0, _g - _sp.h * 0.30, _sp.w * 0.50, _sp.h * 0.62, 20, 0.10, _rng);
            mst_append(_out, mst_map_roles(
                mst_sink(_rim, mst_bevel_cap(_rim, _sp.h * 0.24), 3, "m1"),
                mst_ground_map("a")));
            var _throat = mst_pool_pts(_sp.w * 0.05, _g - _sp.h * 0.22,
                                       _sp.w * 0.24, _sp.h * 0.30, 16, 0.14, _rng);
            mst_append(_out, mst_map_roles(
                mst_sink(_throat, mst_bevel_cap(_throat, _sp.h * 0.10), 2, "m0"),
                mst_ground_map("b")));
            var _fall = [];
            for (var _i = 0; _i < 5; _i++) {
                var _px = (mst_rng_next(_rng) * 2 - 1) * _sp.w * 0.34;
                var _pr = _sp.w * (0.024 + mst_rng_next(_rng) * 0.028);
                mst_append(_fall, mst_ring_fill(
                    mst_pool_pts(_px, _g - _sp.h * (0.02 + mst_rng_next(_rng) * 0.16),
                                 _pr, _pr * 0.66, 7, 0.26, _rng), "m2", undefined, undefined));
            }
            mst_append(_out, mst_map_roles(_fall, mst_ground_map("c")));
        } break;
    }
    return _out;
}
