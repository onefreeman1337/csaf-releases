/// MUSTER - mst_demo. What the demo room does when you change something.
///
/// ⚠️ THIS FILE IS PART OF THE PRODUCT AND IS MEANT TO BE READ. A buyer's first question is "how do
/// I put this in my game", and the honest answer is the four lines of mst_demo_rebuild: make a
/// field, build its palette, work out where to draw it, ask it for a report. Everything else in the
/// demo is presentation. Keeping that visible is worth more than any amount of Readme.
///
/// ⛔ A RUNNABLE DEMO ROOM IS MANDATORY IN THIS WING and it is not a courtesy. GML cannot be
/// unit-tested outside the engine, so the demo room is simultaneously the buyer's quickstart, the
/// source of the store GIF, and the only smoke test that exercises the drawing layer at all - the
/// self-test computes numbers and can never see a picture.
/// ============================================================================================

/// Rebuild the demo's field from the current controls. Called from Create and from every control
/// in Step, so there is exactly one place that knows how a field is made.
function mst_demo_rebuild() {
    var _biomes = mst_biome_names();
    var _seasons = mst_season_names();

    // -- THE FOUR LINES A BUYER ACTUALLY NEEDS ------------------------------------------------
    field = mst_field_make(12, 12, seed, _biomes[biome_i], _seasons[season_i], season_t);
    pal = mst_field_palette(field);
    origin = mst_field_origin(field, 0, 40, display_get_gui_width(),
                              display_get_gui_height() - 150);
    report = mst_field_report(field);
    // -----------------------------------------------------------------------------------------

    // Keep the cursor on the board when the field is remade. A cursor left outside its field is
    // how the movement overlay would come back empty and look like a broken pathfinder.
    cursor_x = clamp(cursor_x, 0, field.w - 1);
    cursor_y = clamp(cursor_y, 0, field.h - 1);

    // ⚠️ AND PUT IT SOMEWHERE A UNIT COULD ACTUALLY STAND. The movement and sight overlays are
    // measured FROM the cursor, and a cursor sitting in a pool returns an empty range - which is
    // correct behaviour that looks exactly like a defect. Nudging it to the nearest standable cell
    // is the difference between a demo that shows the product working and one that shows a blank.
    if (mst_cost_at(field, cursor_x, cursor_y) >= MST_IMPASSABLE) {
        var _found = false;
        for (var _rad = 1; _rad < max(field.w, field.h) && !_found; _rad++) {
            for (var _dy = -_rad; _dy <= _rad && !_found; _dy++) {
                for (var _dx = -_rad; _dx <= _rad && !_found; _dx++) {
                    var _nx = cursor_x + _dx, _ny = cursor_y + _dy;
                    if (!mst_in_bounds(field, _nx, _ny)) continue;
                    if (mst_cost_at(field, _nx, _ny) >= MST_IMPASSABLE) continue;
                    cursor_x = _nx; cursor_y = _ny; _found = true;
                }
            }
        }
    }
}
