# Vestige — Every Award Strikes Its Own Medal

**GameMaker 2024.14+ · pure GML · no sprites.**

Every planchet, rim, device, legend and ribbon in this package is struck at run time from the
award's own properties and one hash. There is no `sprites/` directory, because there is nothing to
put in one. The only textures it ships are the two font resources it draws legends with
(`fnt_vestige`, `fnt_vestige_title`).

```gml
vst_init();
vst_define("first_blood", { name: "First Blood", category: "valour", tier: 1, points: 10,
                            desc: "Win your first fight." });

vst_grant("first_blood");                       // it unlocks, and the strike animation queues
vst_toast_update(delta_time / 1000000);         // in Step
vst_toast_draw(display_get_gui_width() - 24, 24, 520, "walnut");   // in Draw GUI
```

That is the whole integration. Three calls.

---

## What you are buying

An achievement system, and the medals it strikes.

The system is the part you wire in: definitions, counters, tiered chains, prerequisites, secret
awards, points, per-category completion, save and load. It is about six hundred lines and it does
what you would write yourself.

**The medals are the part you would not write.** Every award is struck from five authored axes —

| axis | count | what it is |
| --- | --- | --- |
| **device** | **42** | the charge sunk into the field. Hand-drawn, six in each of seven categories. |
| **planchet** | **12** | the blank: round, scallop, cross, star, shield, hex, octagon, quatrefoil, sunburst, rosette, cameo, cog. |
| **rim** | **6** | plain, beaded, reeded, cable, laurel, dentil. Every bead and leaf struck separately. |
| **alloy** | **7** | iron, bronze, silver, gold, electrum, obsidian, adamant — the tier ladder. |
| **ribbon** | **8** | plain, pales3, pales5, bend, chevron, saltire, quartered, barry, in your category's dyes. |

— and all five are chosen from a hash of the award's own id, so the same award strikes the same
medal in every session on every machine, and any of them can be overridden by hand.

### Why it looks like metal

**There is one lamp, up and to the left, and every closed outline in the package is bevelled against
it.** A device is not a silhouette: it is the top of a raised shape, and the little wall between the
top and the field around it points a different way on every side. Light that wall from a fixed lamp
and colour it from the alloy's five-stop ramp, and the shape stops being a sticker.

That is the whole idea, it is in `vst_relief`, and it is about a hundred lines. Everything else —
the rims, the planchets, the trophy case, the reveal toast, the drop shadows — is that one function
pointed at something.

---

## Import

1. **Tools ▸ Import Local Package**, choose `Vestige.yymps`, **Add All**.
2. Open `rm_vestige_demo` and press Play.

The demo room is three pages: the **trophy case** (browse, filter by category, award things and
watch them strike), **the mint** (every axis on a number key — this is the one that shows you what
you bought), and **three sizes** (the same medal at hero, card and inventory scale, with its part
count).

Nothing in the demo reaches into an internal. It is built entirely out of the calls below.

---

## The API

### Defining

```gml
vst_init();                                     // once, before anything else

vst_define(id, {
    name:     "First Blood",                    // the legend struck around the rim
    desc:     "Win your first fight.",          // one line for the trophy case
    category: "valour",                         // one of the seven, chooses the device set and dyes
    tier:     1,                                // 0..6, chooses the alloy
    points:   10,
    target:   1,                                // >1 makes it a counter
    secret:   false,
    requires: "some_other_id",                  // or an array of ids
    // any of: device, planchet, rim, ribbon, alloy, condition, suspended
});

vst_define_chain("slay", { name: "Slayer", category: "valour", tier: 1, points: 15 },
                 [10, 100, 1000]);              // three linked awards, one shared counter
```

⛔ **An id may not contain `|`, `;`, `=` or `:`.** Those are the save format's separators and
`vst_define` refuses the id at define time — on your first run, rather than in a player's save file
six months later.

### Awarding

```gml
vst_grant(id);                     // a one-shot. returns true if this call unlocked it
vst_progress(id, n);               // add to a counter; unlocks itself at its target
vst_set_progress(id, n);           // set it absolutely - right when your game already tracks the stat
vst_chain_progress("slay", n);     // advance every link of a chain at once
vst_reset();                       // forget all progress; definitions stay
```

Every one of these re-settles the whole registry, so an award that was waiting on a prerequisite
unlocks the moment that prerequisite does, however deep the chain.

### Asking

```gml
vst_unlocked(id)          vst_progress_of(id)        vst_fraction(id)     // 0..1
vst_visibility(id)        // "shown" | "blank" | "hidden"  - secret awards have three states
vst_score()               // { unlocked, total, points, earned, percent }
vst_category_awards(cat)  vst_recent(n)              vst_ids()
```

### Saving

```gml
var _blob = vst_save();            // one string. put it in your save file however you like
var _rep  = vst_load(_blob);       // { ok, restored, unknown, unlocked }
```

`unknown` counts ids in the save that this build no longer defines. They are **skipped, not
refused**: a player who loads a save from before you renamed an award keeps the rest of their
progress. Loading never fires the toast for awards earned last session.

### Showing

```gml
vst_toast_init();
vst_toast_update(delta_time / 1000000);                    // SECONDS. delta_time is microseconds.
vst_toast_draw(gui_w - 24, 24, 520, "walnut");             // anchored to its TOP RIGHT

var _state = vst_case_state("walnut");                     // yours to keep and mutate
vst_case_draw(_state, 24, 24, gui_w - 48, gui_h - 48);
```

### Drawing one medal anywhere

```gml
var _m  = vst_award_medal(id);                  // or vst_medal({...}) with no registry at all
var _s  = vst_medal_surface(_m, "walnut");
vst_medal_shadow(_m, _s, x, y, 128, 1);
vst_medal_draw(_m, _s, x, y, 128, 1);           // last argument is detail: 0 / 1 / 2
```

---

## Performance, honestly

A hero medal is roughly two thousand primitives. Thirty of those per frame, from geometry, will
show up in your profiler — so **the cache ships with the product** rather than leaving you to
discover the cost:

```gml
// in Create - NOT in a Draw event, see below
badge = vst_render_to_sprite(vst_medal_parts(_m, 1), _sur, 128, 128, 4);

// in Clean Up
sprite_delete(badge);
```

⚠️ **You own every sprite it returns and you must delete it.** The demo object does exactly this.

⚠️ **Never call it from a Draw event.** `surface_set_target` inside a draw event nests render
targets and on some drivers silently hands back an empty sprite rather than an error.

**Detail follows pixel size, and you should let it.** Below about 190px the legend is dropped;
below about 78px the incised lines go too. Both are deliberate: `draw_line_width` floors every
stroke at one pixel, so a groove and its two walls land on the same three pixels at inventory size
and the device fills up with grey mush. A medal that keeps its silhouette reads; one that keeps its
detail does not.

---

## Colour

Every alloy is five stops authored in **Oklch**, not HSV, and the package asserts two floors on
them at run time in its own self-test:

- **the ramp floor** — consecutive stops of one alloy differ by at least 0.12 in lightness, or the
  bevel loses a band and the medal goes flat;
- **the tier floor** — any two alloys are separable by face alone, by lightness or by hue, so a
  player can tell bronze from gold at inventory size with the name covered up.

Six **case papers** (walnut, ebony, slate, ivory, oxblood, verdigris) and eight **ribbon dyes** come
with it. A locked award's empty well is derived from the paper it is cut into rather than authored
once, so it reads as a hole in the felt on all six.

---

## What this package does not do

- **It does not talk to Steam, itch, GOG or any platform's achievement service.** It is a display
  and tracking layer for YOUR game. Call your platform's API alongside `vst_grant`.
- **It does not persist by itself.** `vst_save()` hands you a string; where it goes is your
  business.
- **It ships no sound.** The strike is silent; play your own on `vst_toast_show`.
- **It does not read the keyboard.** The trophy case draws; navigating it is your menu's job. The
  demo shows one way.

---

## Files

```
scripts/vst_geom       five drawing primitives, curve sampling, seeded hash
scripts/vst_palette    Oklab -> sRGB, gamma, chroma ceiling
scripts/vst_alloy      7 alloys, 6 case papers, 8 dyes, and the floors on them
scripts/vst_relief     THE ONE THAT MATTERS: shade any outline by its own surface normal
scripts/vst_planchet   12 blank forms as polar radius functions, 6 rim treatments
scripts/vst_device     42 devices, seven categories
scripts/vst_ribbon     8 ribbon patterns, the drape, the bar and the suspension ring
scripts/vst_medal      award -> medal, and how to draw one
scripts/vst_award      the system: registry, counters, chains, prerequisites, save/load
scripts/vst_toast      the strike-and-reveal, as a pure function of time
scripts/vst_case       the trophy case: layout as numbers, drawing as a separate pass
scripts/vst_render     the only file that talks to the GPU
scripts/vst_bake       renders the store gallery from this same code (not needed at run time)
scripts/vst_selftest   760 in-engine assertions (not needed at run time)
objects/obj_vestige_demo   the demo
rooms/rm_vestige_demo      the demo room
fonts/fnt_vestige, fnt_vestige_title       Open Sans, Apache-2.0 - see fonts/THIRD-PARTY-NOTICES.txt
```

`vst_bake` and `vst_selftest` are shipped on purpose and cost you nothing at run time: they are the
proof that every image on the store page was drawn by the code in your hands, and that the floors
this Readme claims are actually asserted. Delete them if you like.

---

## Verified

- Built through **Igor** on runtime `2024.14.4.268`: exit 0, **0 errors, 0 warnings**, 411
  resources compiled.
- **760 assertions** run in-engine against that build, 0 failures.
- All **nine store sheets** rendered by `vst_bake` through the shipped draw path, all passing the
  ink-coverage and clip checks.

⚠️ **What is NOT verified:** GameMaker's import dialog cannot be driven headlessly, so the `.yymps`
payload is verified by extracting it and compiling the extracted project with Igor — which proves it
is a complete, compilable project, and does not prove the IDE's importer likes the manifest. If it
does not import cleanly, say so and it will be fixed.

---

## Licence

One seat, unlimited commercial games, no redistribution of the source as an asset. Full terms in
`LICENSE.txt`. Fonts are Apache-2.0 and their notice travels in `fonts/`.

**AI disclosure:** this package was written with AI assistance. Code: yes. Graphics: yes (generated
by the code itself). Sounds: none. Text: yes.

© 2026 Core Systems Asset Factory.
