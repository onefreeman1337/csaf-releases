/// @description Draw GUI - the demo, drawn only through the package's public calls

var _gw = display_get_gui_width();
var _gh = display_get_gui_height();
var _paper = papers[paper_i];
var _sur = vst_surface("gold", _paper, "crimson", "bone");

draw_set_colour(_sur.ground);
draw_rectangle(0, 0, _gw, _gh, false);

switch (page) {

// ---- 1. THE TROPHY CASE ---------------------------------------------------------------------
case 0: {
    vst_case_draw(case_state, 24, 24, _gw - 48, _gh - 196);

    var _ids = vst_case_visible(case_state);
    if (array_length(_ids) > 0) {
        var _sel = _ids[clamp(case_state.sel, 0, array_length(_ids) - 1)];
        var _d = vst_def_of(_sel);
        var _vis = vst_visibility(_sel);
        vst_text_line((_vis == "blank") ? "A SECRET AWARD" : string_upper(_d.name),
                      28, _gh - 162, _gw * 0.55, 34, _sur.line, true);
        vst_text_line((_vis == "blank") ? "Earn what comes before it to find out what this is."
                                        : _d.desc,
                      28, _gh - 122, _gw * 0.55, 24, _sur.dim, false);
        vst_text_line(vst_category_label(_d.category) + "    TIER " + string(_d.tier)
                      + "    " + string(_d.points) + " PTS"
                      + (vst_unlocked(_sel) ? "    EARNED" : "    LOCKED"),
                      28, _gh - 90, _gw * 0.55, 24, _sur.accent, false);
    }
} break;

// ---- 2. THE MINT ------------------------------------------------------------------------------
case 1: {
    var _m = vst_medal({
        id: "mint_" + string(mint_i[0]) + "_" + string(mint_i[2]),
        name: "THE MINT", exergue: "STRUCK IN GML",
        category: vst_device_category(mint_devices[mint_i[2]]),
        planchet: mint_planchets[mint_i[0]], rim: mint_rims[mint_i[1]],
        device: mint_devices[mint_i[2]], alloy: mint_alloys[mint_i[3]],
        ribbon: mint_ribbons[mint_i[4]], condition: mint_cond, suspended: mint_susp
    });
    var _ms = vst_medal_surface(_m, _paper);

    vst_render_parts_raw(vst_ui_panel(24, 24, _gw - 24, _gh - 156, 18, 9, "panel"), _sur);
    var _size = min(_gw * 0.44, _gh - 240);
    var _mx = 40 + _size * 0.5, _my = 40 + (_gh - 236) * 0.5;
    vst_render_parts_raw(vst_ui_well(40, 40, 40 + _size, 40 + (_gh - 236), 18, 9, "felt"), _sur);
    vst_medal_shadow(_m, _ms, _mx, _my, _size * 0.82, 2);
    vst_medal_draw(_m, _ms, _mx, _my, _size * 0.82, 2);

    var _tx = 80 + _size;
    var _tw = _gw - _tx - 56;
    vst_text_line("THE MINT", _tx, 64, _tw, 44, _sur.line, true);
    vst_text_line("Every axis is a key. Nothing here is a sprite.", _tx, 116, _tw, 24,
                  _sur.dim, false);

    var _rows = [
        ["1  BLANK",     string_upper(mint_planchets[mint_i[0]]),
                         string(array_length(mint_planchets)) + " forms"],
        ["2  RIM",       string_upper(mint_rims[mint_i[1]]),
                         string(array_length(mint_rims)) + " treatments"],
        ["3  DEVICE",    vst_device(mint_devices[mint_i[2]]).label,
                         string(array_length(mint_devices)) + " drawn by hand"],
        ["4  ALLOY",     string_upper(mint_alloys[mint_i[3]]),
                         "tier " + string(mint_i[3])],
        ["5  RIBBON",    string_upper(mint_ribbons[mint_i[4]]),
                         vst_category_label(_m.category)],
        ["6  CONDITION", (mint_cond >= 0.99) ? "MINT" : (string(round(mint_cond * 100)) + "%"),
                         (mint_cond >= 0.75) ? "no wear" : "worn, patinated"],
        ["7  SUSPENDED", mint_susp ? "ON A RIBBON" : "BARE PLANCHET", ""]
    ];
    for (var _i = 0; _i < array_length(_rows); _i++) {
        var _y = 168 + _i * 52;
        vst_text_line(_rows[_i][0], _tx, _y, _tw * 0.34, 26, _sur.dim, false);
        vst_text_line(_rows[_i][1], _tx + _tw * 0.36, _y, _tw * 0.36, 28, _sur.line, true);
        vst_text_line(_rows[_i][2], _tx + _tw * 0.74, _y + 4, _tw * 0.26, 22, _sur.accent, false);
    }
    vst_text_line("SHIFT steps backwards.   SPACE rolls every axis.",
                  _tx, 168 + array_length(_rows) * 52 + 14, _tw, 24, _sur.dim, false);
} break;

// ---- 3. THREE SIZES ---------------------------------------------------------------------------
default: {
    var _m2 = vst_medal({
        id: "scales_" + string(mint_i[2]), name: "THREE SIZES", exergue: "ONE MEDAL",
        category: vst_device_category(mint_devices[mint_i[2]]),
        planchet: mint_planchets[mint_i[0]], rim: mint_rims[mint_i[1]],
        device: mint_devices[mint_i[2]], alloy: mint_alloys[mint_i[3]],
        ribbon: mint_ribbons[mint_i[4]], condition: mint_cond, suspended: mint_susp
    });
    var _ms2 = vst_medal_surface(_m2, _paper);
    vst_render_parts_raw(vst_ui_panel(24, 24, _gw - 24, _gh - 156, 18, 9, "panel"), _sur);

    vst_text_line("THE SAME MEDAL AT THE THREE SIZES IT IS USED AT", 56, 56, _gw - 112, 34,
                  _sur.line, true);
    vst_text_line("Detail follows the pixel size. The legend and the incision drop out before "
                + "they can turn to mush.", 56, 98, _gw - 112, 22, _sur.dim, false);

    var _sizes = [min(_gh - 330, 380), 176, 88];
    var _labels = ["HERO", "CARD", "INVENTORY"];
    var _dets = [2, 1, 0];
    var _slot = (_gw - 160) / 3;
    for (var _i = 0; _i < 3; _i++) {
        var _cx = 80 + _slot * (_i + 0.5);
        var _cy = 160 + _sizes[0] * 0.5;
        vst_medal_shadow(_m2, _ms2, _cx, _cy, _sizes[_i], _dets[_i]);
        vst_medal_draw(_m2, _ms2, _cx, _cy, _sizes[_i], _dets[_i]);
        vst_text_fit(_labels[_i] + "   " + string(_sizes[_i]) + " PX", _cx,
                     160 + _sizes[0] + 34, _slot - 40, 26, _sur.panel, _sur.accent);
        vst_text_fit(string(array_length(vst_medal_parts(_m2, _dets[_i]))) + " PARTS", _cx,
                     160 + _sizes[0] + 68, _slot - 40, 22, _sur.panel, _sur.dim);
    }

    // The cached sprite, drawn beside the live ones. Same medal, one draw call.
    draw_sprite_ext(cached_sprite, 0, _gw - 130, _gh - 240, 1, 1, 0, c_white, 1);
    vst_text_fit("CACHED TO A SPRITE", _gw - 130, _gh - 168, 220, 22, _sur.panel, _sur.dim);
} break;

}

// ---- the footer, on every page ---------------------------------------------------------------
vst_render_parts_raw(vst_ui_panel(24, _gh - 76, _gw - 24, _gh - 24, 12, 7, "edge"), _sur);
var _sc = vst_score();
vst_text_line("VESTIGE  " + VST_VERSION + "     " + pages[page]
            + "     " + string(_sc.unlocked) + " / " + string(_sc.total) + " EARNED"
            + "     " + string(_sc.earned) + " PTS", 46, _gh - 64, _gw * 0.45, 24,
            _sur.line, true);
var _help = (page == 0)
    ? "TAB page    ARROWS select    SPACE award it    ENTER add progress    C category    P paper    R reset"
    : ((page == 1)
       ? "TAB page    1-7 change an axis    SHIFT+key backwards    SPACE roll    P paper"
       : "TAB page    SPACE next device    P paper");
vst_text_line(_help, 46, _gh - 40, _gw - 92, 20, _sur.dim, false);

// The toast draws last, over everything, anchored to the top right.
vst_toast_draw(_gw - 28, 30, min(560, _gw * 0.44), _paper);
