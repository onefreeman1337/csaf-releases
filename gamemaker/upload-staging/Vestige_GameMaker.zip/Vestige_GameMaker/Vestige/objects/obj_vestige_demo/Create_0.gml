/// @description Create - the demo room, and the two headless entry points

// Scanned from 0 to parameter_count() INCLUSIVE. GameMaker has never been consistent about
// whether index 0 is the program name or the first argument, an out-of-range read returns "",
// and every product in this wing that ships a headless mode does it this way.
global.vst_stage = 0;
global.vst_mode  = "demo";
var _pc = parameter_count();
for (var _i = 0; _i <= _pc; _i++) {
    var _p = string_lower(parameter_string(_i));
    if (_p == "-selftest") global.vst_mode = "selftest";
    if (_p == "-bake")     global.vst_mode = "bake";
    if (_p == "-gif")      global.vst_mode = "gif";
}

if (global.vst_mode != "demo") {
    // ⛔ A GML RUNTIME ERROR OPENS A MODAL DIALOG, and headless there is nobody to dismiss it, so
    // the process never exits and the runner reports a meaningless timeout. Installing this
    // handler is what turns an opaque 240 second hang into a stage number and a message.
    exception_unhandled_handler(function(_ex) {
        var _name = "vst_selftest.json";
        if (global.vst_mode == "bake") _name = "vst_bake.json";
        if (global.vst_mode == "gif")  _name = "vst_gif.json";
        var _msg = string(_ex.message) + "  [" + string(_ex.script) + ":" + string(_ex.line) + "]";
        var _f = file_text_open_write(_name);
        file_text_write_string(_f,
            "{\"crash\":true,\"stage\":" + string(global.vst_stage)
            + ",\"message\":\"" + string_replace_all(_msg, "\"", "'") + "\"}");
        file_text_close(_f);
        game_end();
    });

    if (global.vst_mode == "bake")     vst_bake_run();
    else if (global.vst_mode == "gif") vst_gif_run();
    else                               vst_selftest_run();
    game_end();
    exit;
}

// ---- the interactive demo --------------------------------------------------------------------
//
// A runnable demo room is mandatory in this wing, and not as a courtesy: GML cannot be tested
// outside the engine, so this room is simultaneously the buyer's quickstart, the source of the
// store GIF, and the only hands-on smoke test that exists. It is deliberately built out of the same
// public calls the Readme documents - nothing here reaches into an internal.
//
// ⚠️ THREE PAGES, AND THE MIDDLE ONE IS THE REASON THE OTHER TWO ARE WORTH LOOKING AT. A trophy
// case alone shows a system and hides the generator; a medal designer with every axis on a key
// shows in ten seconds that the art is being MADE rather than looked up, which is the whole claim
// the product is sold on.

page  = 0;
pages = ["TROPHY CASE", "THE MINT", "THREE SIZES"];

papers  = vst_case_ids();
paper_i = 0;

// --- the system, with a believable part-earned save --------------------------------------------
vst_sample_awards();
vst_sample_progress();
vst_toast_init();

case_state = vst_case_state(papers[paper_i]);

// --- page 2, the mint --------------------------------------------------------------------------
mint_planchets = vst_planchet_ids();
mint_rims      = vst_rim_ids();
mint_devices   = vst_device_ids();
mint_alloys    = vst_alloy_ids();
mint_ribbons   = vst_ribbon_ids();
mint_i  = [0, 1, 0, 3, 0];      // planchet, rim, device, alloy, ribbon
mint_cond = 1.0;
mint_susp = true;

// --- the sprite cache, demonstrated once -------------------------------------------------------
//
// ⚠️ BUILT IN CREATE AND DELETED IN CLEAN UP, and both halves matter. surface_set_target inside a
// DRAW event nests render targets and on some drivers silently hands back an empty sprite rather
// than an error; and a generator that hands out sprites with no stated ownership is a leak with a
// nice API on top. This is the exact pattern the Readme documents, running.
var _cached_medal = vst_medal({ id: "first_forge", category: "craft", tier: 2,
                                device: "hammer", planchet: "hex", rim: "dentil" });
cached_sprite = vst_render_to_sprite(vst_medal_parts(_cached_medal, 1),
                                     vst_medal_surface(_cached_medal, papers[paper_i]),
                                     128, 128, 4);
