/// @description Clean Up

// ⚠️ THE CALLER OWNS EVERY SPRITE vst_render_to_sprite HANDS BACK, and this is the demo honouring
// its own documentation. A generator that returns sprites with no stated ownership is a leak with a
// nice API on top; the Readme says the caller must delete them, and so does the function's own
// header, and this is the line that proves it is a real instruction rather than a disclaimer.
if (variable_instance_exists(id, "cached_sprite") && sprite_exists(cached_sprite)) {
    sprite_delete(cached_sprite);
}
