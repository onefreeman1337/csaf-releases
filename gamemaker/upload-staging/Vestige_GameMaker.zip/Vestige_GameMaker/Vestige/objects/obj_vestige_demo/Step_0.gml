/// @description Step - input, and the toast clock

// ⛔ SECONDS, NOT FRAMES, AND delta_time IS IN MICROSECONDS. Dividing by 1,000,000 is the whole
// fix, and getting it wrong turns a 0.16 second strike into a 160,000 second one - which on screen
// looks exactly like the animation not running, and sends you looking at the animation.
vst_toast_update(delta_time / 1000000);

if (keyboard_check_pressed(vk_tab)) page = (page + 1) % array_length(pages);
if (keyboard_check_pressed(ord("P"))) {
    paper_i = (paper_i + 1) % array_length(papers);
    case_state.paper = papers[paper_i];
}

var _shift = keyboard_check(vk_shift);
var _step = _shift ? -1 : 1;

switch (page) {

case 0: {
    var _ids = vst_case_visible(case_state);
    var _n = array_length(_ids);
    if (_n > 0) {
        var _L = vst_case_layout(24, 24, display_get_gui_width() - 48,
                                 display_get_gui_height() - 196, _n);
        if (keyboard_check_pressed(vk_right)) case_state.sel = (case_state.sel + 1) % _n;
        if (keyboard_check_pressed(vk_left))  case_state.sel = (case_state.sel + _n - 1) % _n;
        if (keyboard_check_pressed(vk_down))  case_state.sel = min(_n - 1, case_state.sel + _L.cols);
        if (keyboard_check_pressed(vk_up))    case_state.sel = max(0, case_state.sel - _L.cols);
        case_state.page = case_state.sel div _L.perPage;

        if (keyboard_check_pressed(vk_space)) {
            var _id = _ids[case_state.sel];
            // vst_grant is the whole API for a one-shot award. Everything else - the settle pass
            // that unlocks whatever was waiting on it, the queue, the toast - follows from it.
            vst_grant(_id);
        }
        if (keyboard_check_pressed(vk_enter)) {
            var _id2 = _ids[case_state.sel];
            var _d = vst_def_of(_id2);
            if (!is_undefined(_d) && _d.target > 1) vst_progress(_id2, max(1, _d.target div 8));
        }
    }
    if (keyboard_check_pressed(ord("C"))) {
        var _cats = vst_category_ids();
        var _k = -1;
        for (var _i = 0; _i < array_length(_cats); _i++) if (_cats[_i] == case_state.cat) _k = _i;
        _k += 1;
        case_state.cat = (_k >= array_length(_cats)) ? "" : _cats[_k];
        case_state.sel = 0;
        case_state.page = 0;
    }
    if (keyboard_check_pressed(ord("R"))) {
        vst_reset();
        vst_sample_progress();
    }
} break;

case 1: {
    if (keyboard_check_pressed(ord("1"))) {
        mint_i[0] = (mint_i[0] + _step + array_length(mint_planchets)) % array_length(mint_planchets);
    }
    if (keyboard_check_pressed(ord("2"))) {
        mint_i[1] = (mint_i[1] + _step + array_length(mint_rims)) % array_length(mint_rims);
    }
    if (keyboard_check_pressed(ord("3"))) {
        mint_i[2] = (mint_i[2] + _step + array_length(mint_devices)) % array_length(mint_devices);
    }
    if (keyboard_check_pressed(ord("4"))) {
        mint_i[3] = (mint_i[3] + _step + array_length(mint_alloys)) % array_length(mint_alloys);
    }
    if (keyboard_check_pressed(ord("5"))) {
        mint_i[4] = (mint_i[4] + _step + array_length(mint_ribbons)) % array_length(mint_ribbons);
    }
    if (keyboard_check_pressed(ord("6"))) mint_cond = (mint_cond <= 0.05) ? 1.0 : (mint_cond - 0.25);
    if (keyboard_check_pressed(ord("7"))) mint_susp = !mint_susp;
    if (keyboard_check_pressed(vk_space)) {
        // A "roll" is not random: it walks every axis by a different prime, so the sequence is
        // reproducible and a buyer showing the demo twice sees the same medals in the same order.
        mint_i[0] = (mint_i[0] + 5) % array_length(mint_planchets);
        mint_i[1] = (mint_i[1] + 1) % array_length(mint_rims);
        mint_i[2] = (mint_i[2] + 11) % array_length(mint_devices);
        mint_i[3] = (mint_i[3] + 3) % array_length(mint_alloys);
        mint_i[4] = (mint_i[4] + 7) % array_length(mint_ribbons);
    }
} break;

default: {
    if (keyboard_check_pressed(vk_space)) {
        mint_i[2] = (mint_i[2] + 11) % array_length(mint_devices);
    }
} break;

}
