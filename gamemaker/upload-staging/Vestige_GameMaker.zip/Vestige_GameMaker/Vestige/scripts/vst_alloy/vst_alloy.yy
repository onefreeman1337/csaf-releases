{
  "$GMScript": "v1",
  "%Name": "vst_alloy",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_alloy",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}