/// VESTIGE - vst_alloy. The seven alloys, six case papers and eight ribbon dyes.
///
/// ⛔ AN ALLOY IS A RAMP, NOT A COLOUR, AND THAT IS THE WHOLE REASON THIS PRODUCT LOOKS LIKE METAL.
///
/// A flat gold disc is a yellow circle. What makes a struck medal read as struck is that the same
/// piece of metal shows five DIFFERENT values at once - the black of a groove that the light never
/// reaches, the mid face of the field, and the near-white glint on the top of a rim bead - and that
/// which value you see is decided by which way the surface is pointing. vst_relief decides the
/// direction; this file decides what the five values ARE.
///
/// So every alloy is authored as five stops m0..m4 in Oklch, from deepest shadow to specular
/// highlight, and the whole set is asserted on two separate floors:
///
///   1. THE RAMP FLOOR - consecutive stops of one alloy must differ by VST_RAMP_FLOOR in
///      lightness. If two stops collapse, the bevel loses a band and the medal goes flat: the
///      failure looks like "the shading stopped working" and is actually a palette that ran out of
///      room. Silver and adamant are the two that fight it, because both start pale.
///
///   2. THE TIER FLOOR - any two alloys must be separable BY FACE ALONE, either by
///      VST_TIER_L in lightness or by VST_TIER_H degrees of hue. This one is not cosmetic: the
///      tier ladder is how a player reads "this is the bronze one and that is the gold one" at
///      inventory size with no text, and two alloys that collapse would make the tier system a
///      lie. Gold and electrum failed it on the first authoring at 0.02 lightness and 12 degrees
///      apart, which is exactly the pair a player most needs to tell apart, and electrum's whole
///      ramp was lifted rather than its hue turned - a pale gold alloy that is not paler than gold
///      is not electrum.
///
/// Both floors REPORT their tightest margin rather than only passing. A check that says only pass
/// or fail cannot tell you the margin is shrinking, and this table will be edited.
///
/// ⛔ GML HAS NO EXPONENT-LITERAL SYNTAX. `1e-4` is read as the number 1 followed by an identifier
/// `e` and reports "got 'e' expected ',' or ')'", which reads like a missing bracket and sends you
/// counting parentheses. Every tolerance in this package is written out in full.
/// ============================================================================================

/// Consecutive stops of one alloy must differ by this much in Oklab lightness.
#macro VST_RAMP_FLOOR 0.12

/// Two alloys must differ by this much in FACE lightness, or by VST_TIER_H in hue.
#macro VST_TIER_L 0.06
#macro VST_TIER_H 25

/// A medal must stay legible against the case it sits in.
#macro VST_GROUND_FLOOR 0.14

/// ============================================================================================
/// THE ALLOYS
/// ============================================================================================

/// The tier ladder, lowest to highest. Index IS the tier number a caller passes to vst_define.
function vst_alloy_ids() {
    return ["iron", "bronze", "silver", "gold", "electrum", "obsidian", "adamant"];
}

/// The authored table: five [L, C, hue] stops from deepest shadow to specular, then the patina.
///
/// ⛔ CHROMA PEAKS IN THE MIDDLE OF EVERY RAMP AND FALLS AWAY AT BOTH ENDS. That is not decoration.
/// Real metal desaturates into its own shadow and into its own highlight - a gold shadow is brown,
/// a gold glint is white - and a ramp authored at constant chroma renders the specular stop as
/// saturated yellow, which reads as plastic. The chroma ceiling in vst_palette pushes in the same
/// direction near the ends; this table does the rest, deliberately, so the effect survives even
/// where the ceiling has no work to do.
///
/// ⚠️ HUE DRIFTS WARM INTO SHADOW ON THE WARM ALLOYS AND COOL INTO SHADOW ON THE COLD ONES, by a
/// few degrees. It is a small thing and it is the difference between "five greys tinted yellow"
/// and gold.
function vst_alloy_spec(_id) {
    switch (_id) {
        //                     m0 deep shadow      m1 shade            m2 FACE
        //                     m3 light            m4 specular         patina
        case "iron":     return [[0.17,0.006,250],[0.30,0.008,252],[0.46,0.009,254],
                                 [0.62,0.007,256],[0.79,0.004,258],[0.42,0.090, 42]];
        case "bronze":   return [[0.16,0.045, 54],[0.30,0.070, 58],[0.46,0.090, 62],
                                 [0.63,0.072, 66],[0.80,0.040, 70],[0.55,0.060,165]];
        case "silver":   return [[0.20,0.004,248],[0.36,0.006,250],[0.55,0.007,252],
                                 [0.74,0.005,256],[0.92,0.003,260],[0.34,0.020,300]];
        case "gold":     return [[0.22,0.050, 76],[0.38,0.085, 82],[0.57,0.115, 88],
                                 [0.76,0.090, 92],[0.93,0.045, 96],[0.46,0.060, 40]];
        // LIFTED, NOT RE-HUED. See the header: at L 0.59 this alloy sat 0.02 from gold and 12
        // degrees from it, and a pale gold that is not paler than gold is not electrum.
        case "electrum": return [[0.28,0.026, 92],[0.46,0.045, 98],[0.66,0.060,104],
                                 [0.82,0.045,108],[0.96,0.020,112],[0.52,0.038,150]];
        case "obsidian": return [[0.06,0.003,288],[0.19,0.005,286],[0.32,0.010,284],
                                 [0.47,0.017,282],[0.66,0.021,280],[0.26,0.030,320]];
        default:         return [[0.26,0.018,302],[0.44,0.032,300],[0.62,0.042,298],
                                 [0.80,0.030,296],[0.97,0.012,294],[0.50,0.028,206]];
    }
}

/// Resolve an alloy to the five roles vst_render consumes, plus its authored lightnesses.
///
/// The `L` sub-struct is STORED rather than recovered from the resolved colour, because vst_oklch
/// performs gamut reduction: reading the lightness back out of the returned colour would measure
/// what sRGB could represent, not what was authored, and the assertion would then be testing the
/// gamut rather than the ramp.
function vst_alloy(_id) {
    var _s = vst_alloy_spec(_id);
    return {
        m0: vst_oklch(_s[0][0], _s[0][1], _s[0][2]),
        m1: vst_oklch(_s[1][0], _s[1][1], _s[1][2]),
        m2: vst_oklch(_s[2][0], _s[2][1], _s[2][2]),
        m3: vst_oklch(_s[3][0], _s[3][1], _s[3][2]),
        m4: vst_oklch(_s[4][0], _s[4][1], _s[4][2]),
        patina: vst_oklch(_s[5][0], _s[5][1], _s[5][2]),
        id: _id,
        L: { m0: _s[0][0], m1: _s[1][0], m2: _s[2][0], m3: _s[3][0], m4: _s[4][0] },
        H: _s[2][2],
        C: _s[2][1]
    };
}

/// Tier index of an alloy id, or -1. The ladder is the array order, so there is exactly one
/// definition of "higher tier" in the package.
function vst_alloy_tier(_id) {
    var _ids = vst_alloy_ids();
    for (var _i = 0; _i < array_length(_ids); _i++) if (_ids[_i] == _id) return _i;
    return -1;
}

/// The alloy a tier number strikes in. Out-of-range tiers CLAMP rather than wrap, because a buyer
/// who defines a tier 9 award has made a mistake and an award that silently strikes in iron is a
/// much harder mistake to see than one that strikes in the top alloy.
function vst_alloy_for_tier(_tier) {
    var _ids = vst_alloy_ids();
    return _ids[clamp(_tier, 0, array_length(_ids) - 1)];
}

/// The tightest consecutive-stop separation across all seven, as [value, "alloy m1/m2"].
function vst_alloy_tightest_ramp() {
    var _ids = vst_alloy_ids();
    var _worst = 999, _who = "";
    var _names = ["m0", "m1", "m2", "m3", "m4"];
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _a = vst_alloy(_ids[_i]);
        var _l = [_a.L.m0, _a.L.m1, _a.L.m2, _a.L.m3, _a.L.m4];
        for (var _k = 0; _k < 4; _k++) {
            var _d = abs(_l[_k + 1] - _l[_k]);
            if (_d < _worst) { _worst = _d; _who = _ids[_i] + " " + _names[_k] + "/" + _names[_k + 1]; }
        }
    }
    return [_worst, _who];
}

/// Hue difference in degrees, taking the short way round the circle.
///
/// ⚠️ WITHOUT THE WRAP, 350 AND 10 READ AS 340 DEGREES APART and every pair straddling zero passes
/// the tier floor for free. None of the seven alloys straddles zero today, which is exactly why
/// this would have been a check that could never fail on the current table and would silently stop
/// working the first time someone authored a red one.
function vst_hue_gap(_a, _b) {
    var _d = abs(_a - _b) % 360;
    return min(_d, 360 - _d);
}

/// How separable the two closest alloys are, as [score, "a vs b"], where score is the better of
/// their lightness gap and their hue gap expressed in lightness-equivalent terms.
///
/// The two axes are combined rather than checked independently because "tellable apart" is one
/// question with two possible answers - iron and bronze sit at exactly the same face lightness and
/// are in no danger of being confused, because one is blue-grey and the other is brown.
function vst_alloy_tightest_tier() {
    var _ids = vst_alloy_ids();
    var _worst = 999, _who = "";
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _a = vst_alloy(_ids[_i]);
        for (var _k = _i + 1; _k < array_length(_ids); _k++) {
            var _b = vst_alloy(_ids[_k]);
            var _dl = abs(_a.L.m2 - _b.L.m2);
            var _dh = vst_hue_gap(_a.H, _b.H);
            // Normalised: a full VST_TIER_L of lightness and a full VST_TIER_H of hue both
            // score 1.0, so the better of the two is the one that carries the pair.
            var _score = max(_dl / VST_TIER_L, _dh / VST_TIER_H);
            if (_score < _worst) { _worst = _score; _who = _ids[_i] + " vs " + _ids[_k]; }
        }
    }
    return [_worst, _who];
}

/// ============================================================================================
/// THE CASE PAPERS - what a medal is displayed AGAINST
/// ============================================================================================

function vst_case_ids() {
    return ["walnut", "ebony", "slate", "ivory", "oxblood", "verdigris"];
}

/// [ground, panel, edge, line, dim, accent, felt].
///
/// `ground` is the room behind the case, `panel` the case interior, `edge` its moulding, `felt`
/// the lining a medal actually rests on, `line` the type, `dim` secondary type, `accent` the one
/// warm rule the layout is allowed.
///
/// ⛔ `ivory` IS THE DANGEROUS ONE and it is here on purpose. Six of the seven alloys are darker
/// than a pale page and read fine on it; adamant at L 0.62 face and 0.97 specular does not, and a
/// product whose top tier vanishes on one of its own papers is selling a tier that cannot be seen.
/// The fix is the same one a real display case uses - the medal does not sit on the paper, it sits
/// on the FELT, and ivory's felt is the darkest thing in its row.
function vst_case_spec(_id) {
    switch (_id) {
        //                     ground             panel              edge
        //                     line               dim                accent             felt
        // ⚠️ THE FELT IS 0.215 AND IT WAS 0.19. MEASURED 2026-08-25: at 0.19 obsidian scored 0.13
        // against a floor of 0.14 on BOTH routes - its face was a tenth from the felt and its
        // deepest stop, at 0.06, was only 0.13 below it, so the medal had no dark side to be dark
        // against. Twenty-five thousandths of lightness on the background fixed it without moving
        // a single alloy, which is the right place to spend it: the papers exist to serve the
        // metal, not the other way round.
        case "walnut":   return [[0.14,0.020, 52],[0.24,0.032, 48],[0.36,0.040, 46],
                                 [0.90,0.012, 70],[0.62,0.016, 60],[0.72,0.090, 78],[0.215,0.026, 40]];
        case "ebony":    return [[0.08,0.006,280],[0.16,0.008,278],[0.27,0.010,276],
                                 [0.92,0.004,270],[0.60,0.006,272],[0.74,0.080, 92],[0.12,0.008,282]];
        case "slate":    return [[0.17,0.012,244],[0.27,0.016,242],[0.39,0.020,240],
                                 [0.91,0.006,240],[0.63,0.010,240],[0.70,0.070,214],[0.22,0.014,246]];
        // The pale paper. Its felt is deliberately the darkest cell in the row - see the header.
        case "ivory":    return [[0.93,0.010, 84],[0.87,0.014, 80],[0.72,0.020, 76],
                                 [0.18,0.010, 60],[0.46,0.012, 64],[0.52,0.100, 52],[0.28,0.030, 48]];
        // Felt 0.16, down from 0.18 - obsidian landed EXACTLY on the floor there, and a value that
        // passes by nothing is a value that fails the next time anything moves.
        case "oxblood":  return [[0.13,0.030, 24],[0.22,0.048, 22],[0.34,0.060, 20],
                                 [0.90,0.014, 40],[0.61,0.020, 30],[0.74,0.085, 66],[0.16,0.040, 18]];
        default:         return [[0.15,0.018,168],[0.25,0.028,166],[0.37,0.034,164],
                                 [0.91,0.008,150],[0.62,0.012,158],[0.73,0.075, 96],[0.20,0.024,170]];
    }
}

function vst_case_paper(_id) {
    var _s = vst_case_spec(_id);
    return {
        ground: vst_oklch(_s[0][0], _s[0][1], _s[0][2]),
        panel:  vst_oklch(_s[1][0], _s[1][1], _s[1][2]),
        edge:   vst_oklch(_s[2][0], _s[2][1], _s[2][2]),
        line:   vst_oklch(_s[3][0], _s[3][1], _s[3][2]),
        dim:    vst_oklch(_s[4][0], _s[4][1], _s[4][2]),
        accent: vst_oklch(_s[5][0], _s[5][1], _s[5][2]),
        felt:   vst_oklch(_s[6][0], _s[6][1], _s[6][2]),
        id: _id,
        L: { ground: _s[0][0], panel: _s[1][0], edge: _s[2][0], line: _s[3][0],
             dim: _s[4][0], accent: _s[5][0], felt: _s[6][0] }
    };
}

/// How visible one alloy is on one paper's felt.
///
/// ⛔ THE FIRST VERSION OF THIS MEASURED THE FACE ALONE AND THE FLOOR IT FED WAS UNSATISFIABLE.
/// MEASURED 2026-08-25: obsidian's face sits at L 0.32 and ivory's felt at 0.28, four hundredths
/// apart, and the suite correctly refused it. The instinct was to move the felt - and that is
/// where the measurement earns its keep, because there is NO value that works. The seven faces
/// span 0.32 to 0.66; a felt in the middle of that range is a tenth from iron and bronze, and a
/// felt outside it collapses against one end or the other. A single-number floor on the face was
/// asking for a background that clears seven foregrounds spread across a third of the lightness
/// axis, which no background does.
///
/// The measure was wrong, not the palette, and the reason is that a MEDAL IS NOT A FLAT SHAPE.
/// There are two independent ways for one to be unmistakable against its felt:
///
///   (a) ITS FACE CLEARS THE FELT. The value covering most of its area is plainly lighter or
///       darker than the background. This is how gold on ebony works.
///   (b) ITS RAMP BRACKETS THE FELT. The face may match the background exactly and the medal is
///       still unmistakable, because its shadowed walls are darker than the felt and its lit ones
///       are brighter - so its outline is drawn twice over, in both directions, by the relief
///       engine. This is how obsidian on a pale case works, and it is the more robust of the two:
///       it survives the felt being re-authored.
///
/// The score is the better of the two, so an alloy passes on whichever it actually uses. An alloy
/// that has NEITHER is genuinely invisible and there is nothing arbitrary about refusing it.
function vst_alloy_visibility(_alloy_id, _case_id) {
    var _a = vst_alloy(_alloy_id);
    var _c = vst_case_paper(_case_id);
    var _face = abs(_a.L.m2 - _c.L.felt);
    var _bracket = 0;
    if (_a.L.m0 < _c.L.felt && _a.L.m4 > _c.L.felt) {
        _bracket = min(_c.L.felt - _a.L.m0, _a.L.m4 - _c.L.felt);
    }
    return max(_face, _bracket);
}

/// The least visible alloy-and-paper pairing in the whole product, as [value, where].
function vst_alloy_tightest_ground() {
    var _as = vst_alloy_ids(), _cs = vst_case_ids();
    var _worst = 999, _who = "";
    for (var _i = 0; _i < array_length(_as); _i++) {
        for (var _k = 0; _k < array_length(_cs); _k++) {
            var _d = vst_alloy_visibility(_as[_i], _cs[_k]);
            if (_d < _worst) { _worst = _d; _who = _as[_i] + " on " + _cs[_k]; }
        }
    }
    return [_worst, _who];
}

/// ============================================================================================
/// THE RIBBON DYES
/// ============================================================================================

function vst_dye_ids() {
    return ["crimson", "azure", "ink", "bone", "moss", "plum", "amber", "umber"];
}

/// Three stops per dye: [lit fold, base, shadowed fold]. Cloth, not metal - so the ramp is
/// shorter, flatter and much lower in contrast than an alloy's. A ribbon shaded on a metal ramp
/// looks like painted tin, which was the first thing this file got wrong.
function vst_dye_spec(_id) {
    switch (_id) {
        case "crimson": return [[0.52,0.145, 26],[0.40,0.150, 24],[0.28,0.110, 22]];
        case "azure":   return [[0.52,0.100,250],[0.40,0.105,248],[0.28,0.080,246]];
        case "ink":     return [[0.34,0.014,268],[0.24,0.014,266],[0.15,0.010,264]];
        case "bone":    return [[0.90,0.012, 84],[0.80,0.016, 80],[0.66,0.018, 76]];
        case "moss":    return [[0.50,0.070,142],[0.38,0.074,140],[0.27,0.056,138]];
        case "plum":    return [[0.46,0.090,318],[0.35,0.095,316],[0.24,0.072,314]];
        case "amber":   return [[0.76,0.115, 76],[0.64,0.125, 72],[0.48,0.100, 68]];
        default:        return [[0.46,0.055, 58],[0.35,0.058, 56],[0.24,0.046, 54]];
    }
}

/// ============================================================================================
/// THE SURFACE - one struct with every role the renderer will be asked for
///
/// ⚠️ MERGED RATHER THAN LAYERED, AND THE REASON IS THE RENDERER'S FALLBACK. vst_render resolves a
/// role by name against ONE struct and falls back to `line` when it misses - loudly wrong rather
/// than invisible, which is the right behaviour for an authoring typo and the wrong behaviour for
/// a lookup that was supposed to consult a second struct. Handing the renderer one flat surface
/// means a missing role is always a typo and never a plumbing question.
/// ============================================================================================

function vst_surface(_alloy_id, _case_id, _dye_a, _dye_b) {
    var _a = vst_alloy(_alloy_id);
    var _c = vst_case_paper(_case_id);
    var _da = vst_dye_spec(_dye_a);
    var _db = vst_dye_spec(_dye_b);
    var _cs = vst_case_spec(_case_id);
    // The shadow a medal casts onto its own felt: the felt, taken down. Derived from the paper
    // rather than authored, for the same reason the locked cavity is - one authored grey shadow
    // is right on one paper out of six and reads as a smear on the other five.
    var _sh = vst_oklch(max(0.020, _cs[6][0] - 0.095), _cs[6][1] * 0.70, _cs[6][2]);
    return {
        shadow: _sh,
        m0: _a.m0, m1: _a.m1, m2: _a.m2, m3: _a.m3, m4: _a.m4, patina: _a.patina,
        ground: _c.ground, panel: _c.panel, edge: _c.edge,
        line: _c.line, dim: _c.dim, accent: _c.accent, felt: _c.felt,
        ra0: vst_oklch(_da[0][0], _da[0][1], _da[0][2]),
        ra1: vst_oklch(_da[1][0], _da[1][1], _da[1][2]),
        ra2: vst_oklch(_da[2][0], _da[2][1], _da[2][2]),
        rb0: vst_oklch(_db[0][0], _db[0][1], _db[0][2]),
        rb1: vst_oklch(_db[1][0], _db[1][1], _db[1][2]),
        rb2: vst_oklch(_db[2][0], _db[2][1], _db[2][2]),
        alloyId: _alloy_id, caseId: _case_id, dyeA: _dye_a, dyeB: _dye_b,
        L: { m2: _a.L.m2, m4: _a.L.m4, felt: _c.L.felt, ground: _c.L.ground, line: _c.L.line }
    };
}

/// The surface a LOCKED award is drawn on: the same case, and the alloy replaced by a cold dead
/// ramp so an unearned cavity can never be mistaken for a struck medal at a glance.
///
/// ⚠️ IT IS DERIVED FROM THE CASE, NOT AUTHORED. A locked cavity is a hole in the felt, so its
/// values have to be the felt's values - authoring one grey for all six papers put a slate-grey
/// hole in an ivory case, which read as a medal rather than as an absence.
function vst_surface_locked(_case_id) {
    var _c = vst_case_paper(_case_id);
    var _s = vst_case_spec(_case_id);
    var _fl = _s[6][0], _fc = _s[6][1], _fh = _s[6][2];
    // Five stops hugging the felt: a cavity is lit by the same lamp, but it is a hole and its
    // walls never catch more than a fraction of what a raised face does.
    var _lo = clamp(_fl - 0.10, 0.02, 0.94);
    var _hi = clamp(_fl + 0.14, 0.06, 0.98);
    var _sur = vst_surface("iron", _case_id, "ink", "ink");
    _sur.m0 = vst_oklch(_lo, _fc * 0.6, _fh);
    _sur.m1 = vst_oklch(lerp(_lo, _hi, 0.28), _fc * 0.7, _fh);
    _sur.m2 = vst_oklch(lerp(_lo, _hi, 0.52), _fc * 0.8, _fh);
    _sur.m3 = vst_oklch(lerp(_lo, _hi, 0.76), _fc * 0.7, _fh);
    _sur.m4 = vst_oklch(_hi, _fc * 0.5, _fh);
    _sur.alloyId = "cavity";
    return _sur;
}
