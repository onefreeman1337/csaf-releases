{
  "$GMScript": "v1",
  "%Name": "vst_ribbon",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_ribbon",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}