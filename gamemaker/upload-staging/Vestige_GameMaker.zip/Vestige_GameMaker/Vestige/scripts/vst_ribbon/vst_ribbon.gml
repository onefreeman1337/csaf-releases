/// VESTIGE - vst_ribbon. Eight ribbon patterns, the drape, the bar and the suspension ring.
///
/// The ribbon is the second generated object on every suspended medal, and it earns its place for
/// a reason that has nothing to do with decoration: it is the only part of the medal that carries
/// the award's CATEGORY in colour. Two gold medals of the same tier are the same metal; the ribbon
/// is what says one was for valour and the other for lore, and it says it from across the room,
/// before the device is legible at all.
///
/// ⛔ THE PATTERN IS EVALUATED PER QUAD, NOT CLIPPED. There is no scissor rectangle here and there
/// should not be: GML's clipping is a surface and viewport operation that does not survive being
/// called from inside a buyer's own draw event, which is the whole point of this package. So the
/// drape is subdivided into a grid and each cell asks the pattern function which dye it is. That
/// makes every pattern - including the diagonal ones - fall inside the cloth by construction, with
/// no geometry to intersect and nothing to leak outside the shape.
///
/// ⚠️ AND THE DRAPE TAPERS, WHICH IS WHY THE GRID IS BUILT ROW BY ROW rather than as a rectangle.
/// A ribbon of constant width reads as a strip of tape. The taper starts below the fold so the
/// upper part still reads as a proper ribbon bar.
///
/// ⚠️ CLOTH IS NOT METAL. The dye ramps in vst_alloy are three stops and low contrast, and the
/// fold shading below picks between them from a cosine across the width rather than from a surface
/// normal. Shading a ribbon on the metal ramp - which the first version did, because the machinery
/// was already there - produced something that looked like painted tin.
/// ============================================================================================

/// Where the taper begins, as a fraction of the drape's height.
///
/// ⚠️ 0.68 AND 0.20, AND THEY WERE 0.58 AND 0.42. MEASURED BY LOOKING at the ribbons sheet: a drape
/// that loses two fifths of its width over its lower half is a FUNNEL, and eight of them in a row
/// read as caps sitting on top of the medals rather than as ribbons the medals hang from. A real
/// medal ribbon is very nearly parallel-sided and gathers only at the very bottom where it enters
/// the suspension. The taper also distorted the diagonal patterns: `saltire` came out as a Z,
/// because the arms of an X drawn on a funnel are not an X.
#macro VST_RIB_FOLD 0.68

/// How much narrower the drape is at its bottom edge.
#macro VST_RIB_TAPER 0.20

function vst_ribbon_ids() {
    return ["plain", "pales3", "pales5", "bend", "chevron", "saltire", "quartered", "barry"];
}

/// Which dye a point on the cloth carries. _u across the width 0..1, _v down the drape 0..1.
/// Returns 0 for dye A, 1 for dye B.
function vst_ribbon_dye(_id, _u, _v) {
    switch (_id) {
        case "plain":     return 0;
        case "pales3":    return (_u > 0.333 && _u < 0.667) ? 1 : 0;
        case "pales5":    return (floor(_u * 5) % 2 == 1) ? 1 : 0;
        case "bend":      return (floor((_u * 1.0 + _v * 1.35) * 3) % 2 == 1) ? 1 : 0;
        case "chevron":   return (floor(_v * 3.2 + abs(_u - 0.5) * 3.2) % 2 == 1) ? 1 : 0;
        // A saltire needs BOTH diagonals or it is a bend. The 0.20 is the arm width as a fraction
        // of the cloth, measured rather than chosen: below about 0.15 the arms disappear at
        // inventory size, above 0.26 they merge into a solid block at the crossing.
        case "saltire":   return (abs(_u - _v) < 0.20 || abs(_u + _v - 1) < 0.20) ? 1 : 0;
        case "quartered": return ((_u < 0.5) == (_v < 0.5)) ? 0 : 1;
        default:          return (floor(_v * 5) % 2 == 1) ? 1 : 0;
    }
}

/// The fold shading: which of a dye's three stops a column shows.
///
/// One soft crease, lit from the same lamp as everything else. Returns 0 (lit), 1 (base) or 2
/// (shadowed). It is a function of _u alone - the drape hangs vertically, so there is nothing
/// along its length for the light to model.
function vst_ribbon_fold(_u) {
    var _lit = cos((_u - 0.32) * 3.4);
    if (_lit > 0.86) return 0;
    if (_lit > 0.30) return 1;
    return 2;
}

/// Half-width of the drape at depth _v, as a fraction of its nominal half-width.
function vst_ribbon_halfw(_v) {
    if (_v <= VST_RIB_FOLD) return 1.0;
    return 1.0 - VST_RIB_TAPER * ((_v - VST_RIB_FOLD) / (1 - VST_RIB_FOLD));
}

/// How finely the drape is subdivided at each level of detail, as [cols, rows].
/// ⚠️ THE ROW COUNTS WERE TOO LOW AND THE DIAGONAL PATTERNS PAID FOR IT. At six rows a chevron has
/// three bands to draw two chevrons in, so it renders as a checkerboard, and a bend renders as a
/// zigzag. The cells are evaluated at their own centres, so a pattern finer than the grid does not
/// alias gracefully - it becomes a different pattern. Twelve rows at hero detail puts each cell at
/// about eight pixels on a 340px medal, which is small enough for every one of the eight.
function vst_ribbon_grid(_detail) {
    if (_detail <= 0) return [7, 5];
    if (_detail == 1) return [12, 8];
    return [18, 12];
}

/// The cloth, as coloured quads.
///
/// _cx is the centre line, _y0 the top, _hw the nominal half-width, _h the drape height.
function vst_ribbon_cloth(_id, _cx, _y0, _hw, _h, _detail) {
    var _g = vst_ribbon_grid(_detail);
    var _cols = _g[0], _rows = _g[1];
    var _out = [];
    var _stopA = ["ra0", "ra1", "ra2"];
    var _stopB = ["rb0", "rb1", "rb2"];

    for (var _r = 0; _r < _rows; _r++) {
        var _v0 = _r / _rows, _v1 = (_r + 1) / _rows;
        var _w0 = _hw * vst_ribbon_halfw(_v0), _w1 = _hw * vst_ribbon_halfw(_v1);
        var _yy0 = _y0 + _h * _v0, _yy1 = _y0 + _h * _v1;
        for (var _c = 0; _c < _cols; _c++) {
            var _u0 = _c / _cols, _u1 = (_c + 1) / _cols;
            var _um = (_u0 + _u1) * 0.5, _vm = (_v0 + _v1) * 0.5;
            var _dye = vst_ribbon_dye(_id, _um, _vm);
            var _stop = vst_ribbon_fold(_um);
            var _role = (_dye == 0) ? _stopA[_stop] : _stopB[_stop];
            array_push(_out, vst_fill([
                [_cx + (_u0 * 2 - 1) * _w0, _yy0], [_cx + (_u1 * 2 - 1) * _w0, _yy0],
                [_cx + (_u1 * 2 - 1) * _w1, _yy1], [_cx + (_u0 * 2 - 1) * _w1, _yy1]
            ], _role));
        }
    }
    return _out;
}

/// The whole suspension: the mount bar across the top, the cloth, and the ring the medal hangs
/// from. Everything except the cloth is metal and goes through the relief engine.
///
/// ⚠️ THE RING IS AN ANNULUS BUILT AS A SUNKEN DISC INSIDE A RAISED ONE, which is how every ring
/// in this package is made. There is no hole primitive and there does not need to be: a pit whose
/// floor is the deepest stop of the alloy reads as a hole at every size this product draws at, and
/// unlike a real hole it still works when the medal is drawn over a lit background.
function vst_ribbon_parts(_id, _cx, _y0, _hw, _h, _detail) {
    var _out = vst_ribbon_cloth(_id, _cx, _y0 + 0.030, _hw, _h - 0.030, _detail);

    // The mount bar. Wider than the cloth so the cloth reads as hanging FROM it.
    var _bw = _hw * 1.14;
    vst_append(_out, vst_raise(vst_dv_rect(_cx - _bw, _y0 - 0.020, _cx + _bw, _y0 + 0.036),
                               0.020, (_detail <= 0) ? 1 : 2, "m3"));

    // The suspension ring, sitting on the bottom edge of the cloth.
    var _ry = _y0 + _h + 0.006;
    var _rr = _hw * 0.30;
    var _segs = (_detail <= 0) ? 10 : 16;
    vst_append(_out, vst_raise(vst_dv_disc(_cx, _ry, _rr, _segs), _rr * 0.42,
                               (_detail <= 0) ? 1 : 2, "m3"));
    vst_append(_out, vst_pit(_cx, _ry, _rr * 0.46, _segs));
    return _out;
}

/// The two dyes a category's ribbon is woven from, as [dyeA, dyeB].
///
/// ⛔ NO TWO CATEGORIES SHARE A PAIR, and vst_selftest asserts it. The ribbon is the category
/// signal; two categories with the same two dyes in the same order would be indistinguishable
/// under six of the eight patterns, which would silently delete a whole axis of the product.
function vst_category_dyes(_cat) {
    switch (_cat) {
        case "valour":    return ["crimson", "bone"];
        case "wayfaring": return ["azure", "bone"];
        case "craft":     return ["umber", "amber"];
        case "lore":      return ["plum", "bone"];
        case "bond":      return ["moss", "amber"];
        case "endurance": return ["ink", "crimson"];
        default:          return ["amber", "ink"];
    }
}
