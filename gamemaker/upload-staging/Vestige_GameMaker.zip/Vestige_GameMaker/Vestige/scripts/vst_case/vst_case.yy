{
  "$GMScript": "v1",
  "%Name": "vst_case",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_case",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}