/// VESTIGE - vst_case. The trophy case.
///
/// A cabinet, not a list. Medals sit in wells cut into felt, behind a moulded frame, lit by the
/// same lamp as everything else - and the ones that have not been earned are visibly EMPTY WELLS
/// with the shape of the award sunk into them, so a player can see what is missing and roughly
/// what it will look like. That is the whole design argument for this screen: a grid of greyed-out
/// icons tells a player they have failed, and a case with gaps in it tells them what to collect.
///
/// ⛔ LAYOUT IS A PURE FUNCTION AND DRAWING IS A SEPARATE ONE. vst_case_layout returns numbers and
/// touches nothing; vst_case_draw consumes them. That split is what lets vst_selftest assert - with
/// no engine, no window and no screenshot - that no cell ever escapes the frame, that the columns
/// always divide the width exactly, and that a page of 1 medal and a page of 40 both land inside
/// their own box. Those are the failures that actually ship, and this wing has shipped them: a
/// caption running off the right edge cut mid-word, and a panel running 38 pixels off the bottom
/// while every mechanical check reported ok.
///
/// ⚠️ THE STATE STRUCT IS THE CALLER'S. This file does not read the keyboard and does not own a
/// singleton. A trophy case is a screen in the buyer's game, they will want it in their own menu
/// stack, and a package that hides its state in a global is a package that can only ever have one.
/// ============================================================================================

/// Make a state struct for a case screen.
///
/// cat   "" for every category, or one of vst_category_ids()
/// page  0-based
/// sel   index into the current filtered list, or -1
function vst_case_state(_paper) {
    return { cat: "", page: 0, sel: 0, paper: is_undefined(_paper) ? "walnut" : _paper };
}

/// The award ids this state is showing, after category filtering and after dropping the awards
/// that are still fully hidden.
function vst_case_visible(_state) {
    if (!vst_ready()) return [];
    var _out = [];
    var _all = vst_ids();
    for (var _i = 0; _i < array_length(_all); _i++) {
        var _id = _all[_i];
        var _d = vst_def_of(_id);
        if (_state.cat != "" && _d.category != _state.cat) continue;
        if (vst_visibility(_id) == "hidden") continue;
        array_push(_out, _id);
    }
    return _out;
}

/// ============================================================================================
/// LAYOUT
/// ============================================================================================

/// Everything the drawing pass needs, as numbers.
///
/// ⚠️ THE COLUMN COUNT IS DERIVED FROM THE WIDTH AND THEN THE CELL WIDTH IS DERIVED BACK FROM THE
/// COLUMN COUNT, and the second half is the one that matters. Choosing a fixed cell size and
/// fitting as many as go in leaves a ragged strip of unused case down the right-hand side, which is
/// the "35% of the surface is bare page" failure this wing's own ink-coverage floor exists to
/// catch. Cells stretch to fill; only their number is quantised.
function vst_case_layout(_x, _y, _w, _h, _n) {
    var _pad = _w * 0.030;
    var _headH = _h * 0.150;
    var _tabH = _h * 0.086;
    var _gx = _x + _pad;
    var _gy = _y + _headH + _tabH + _pad * 0.5;
    var _gw = _w - _pad * 2;
    var _gh = _h - (_headH + _tabH + _pad * 1.5);

    // A cell is taller than it is wide because a suspended medal is taller than it is wide, and
    // because the caption lives under it.
    var _cols = max(1, min(8, round(_gw / (_h * 0.230))));
    var _cellW = _gw / _cols;
    var _cellH = _cellW * 1.34;
    var _rows = max(1, floor(_gh / _cellH));
    var _perPage = _cols * _rows;
    var _pages = max(1, ceil(max(1, _n) / _perPage));

    // ⚠️ THE GRID IS CENTRED IN WHATEVER IS LEFT OVER, and it was top-aligned. MEASURED BY LOOKING
    // at the trophy case sheet: seven columns of 277px cells in a 677px grid leaves 123px, and
    // top-aligned that is a dead band across the bottom of the cabinet that reads as the case being
    // CUT OFF rather than as air. The rows cannot be stretched to fill it - a cell's proportions
    // are what hold the medal, the caption and the progress bar in relation to each other - so the
    // leftover is split above and below, where it reads as margin.
    //
    // ⛔ AND THE GRID RECTANGLE SHRINKS TO THE CELLS, WHICH THE FIRST VERSION OF THIS FORGOT. It
    // moved gridY down by half the leftover and left gridH at the FULL available height, so the
    // reported grid ran off the bottom of the case by that same half - on a 420x700 case, by 126
    // pixels. Eight layout assertions went red in one run and named the two window shapes it
    // happened on. That is the containment check doing exactly what it was written for, on a change
    // made an hour after it was written.
    _gy += (_gh - _rows * _cellH) * 0.5;
    _gh = _rows * _cellH;

    return {
        x: _x, y: _y, w: _w, h: _h, pad: _pad,
        headH: _headH, tabH: _tabH,
        gridX: _gx, gridY: _gy, gridW: _gw, gridH: _gh,
        cols: _cols, rows: _rows, cellW: _cellW, cellH: _cellH,
        perPage: _perPage, pages: _pages
    };
}

/// The rectangle of the _i-th cell ON THE CURRENT PAGE, as [x, y, w, h].
function vst_case_cell(_L, _i) {
    var _c = _i % _L.cols, _r = _i div _L.cols;
    return [_L.gridX + _c * _L.cellW, _L.gridY + _r * _L.cellH, _L.cellW, _L.cellH];
}

/// The rectangle of the _i-th category tab, as [x, y, w, h]. Tab 0 is ALL.
function vst_case_tab(_L, _i) {
    var _n = array_length(vst_category_ids()) + 1;
    var _tw = _L.gridW / _n;
    return [_L.gridX + _i * _tw, _L.y + _L.headH, _tw, _L.tabH];
}

/// ============================================================================================
/// DRAWING
/// ============================================================================================

/// One cell: the well, the medal, the caption and - when the award has a counter - its bar.
function vst_case_draw_cell(_id, _sur, _cx, _cy, _cw, _ch, _selected) {
    var _d = vst_def_of(_id);
    if (is_undefined(_d)) return;
    var _m = vst_award_medal(_id);
    var _vis = vst_visibility(_id);
    var _msur = vst_medal_surface(_m, _sur.caseId);

    var _inset = _cw * 0.055;
    vst_render_parts_raw(vst_ui_well(_cx + _inset, _cy + _inset,
                                     _cx + _cw - _inset, _cy + _ch * 0.760,
                                     _cw * 0.10, _cw * 0.030, "felt"), _sur);
    if (_selected) {
        vst_render_parts_raw(vst_bevel(vst_round_rect_pts(_cx + _inset * 0.4, _cy + _inset * 0.4,
            _cx + _cw - _inset * 0.4, _cy + _ch * 0.760 + _inset * 0.6, _cw * 0.11, 4),
            _cw * 0.022, 2, false), _sur);
    }

    // ⚠️ DETAIL FOLLOWS THE CELL SIZE IN PIXELS, not the caller's intent. A case drawn into a
    // 1600px sheet gets hero medals; the same code drawn into a 480px window gets card medals and
    // a phone-sized one gets inventory medals, automatically. Passing a fixed detail here is how a
    // product ends up rendering three thousand primitives into a forty pixel box.
    var _size = min(_cw * 0.74, _ch * 0.640);
    var _detail = (_size >= 190) ? 2 : ((_size >= 78) ? 1 : 0);
    var _mx = _cx + _cw * 0.5, _my = _cy + _ch * 0.400;

    if (!_m.locked) vst_medal_shadow(_m, _msur, _mx, _my, _size, _detail);
    vst_medal_draw(_m, _msur, _mx, _my, _size, _detail);

    var _label = (_vis == "blank") ? "? ? ?" : string_upper(_d.name);
    var _capw = _cw * 0.90;
    vst_text_fit(_label, _mx, _cy + _ch * 0.830, _capw, _ch * 0.082,
                 _sur.panel, vst_unlocked(_id) ? _sur.line : _sur.dim);

    if (_vis == "blank") return;

    if (_d.target > 1 && !vst_unlocked(_id)) {
        var _bx0 = _mx - _capw * 0.5, _bx1 = _mx + _capw * 0.5;
        var _by = _cy + _ch * 0.905, _bh = _ch * 0.038;
        vst_render_parts_raw(vst_ui_well(_bx0, _by, _bx1, _by + _bh, _bh * 0.5,
                                         _bh * 0.30, "felt"), _sur);
        var _fr = vst_fraction(_id);
        if (_fr > 0.02) {
            vst_render_parts_raw(vst_raise(vst_round_rect_pts(_bx0, _by,
                lerp(_bx0, _bx1, _fr), _by + _bh, _bh * 0.5, 3), _bh * 0.30, 2, "accent"), _sur);
        }
        vst_text_fit(string(min(vst_progress_of(_id), _d.target)) + " / " + string(_d.target),
                     _mx, _cy + _ch * 0.968, _capw, _ch * 0.062, _sur.panel, _sur.dim);
    } else {
        vst_text_fit(string(_d.points) + " PTS", _mx, _cy + _ch * 0.925, _capw, _ch * 0.066,
                     _sur.panel, vst_unlocked(_id) ? _sur.accent : _sur.dim);
    }
}

/// The whole case.
function vst_case_draw(_state, _x, _y, _w, _h) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_state)) return;
    if (!vst_ready()) return;
    var _sur = vst_surface("gold", _state.paper, "crimson", "bone");
    _sur.caseId = _state.paper;

    var _ids = vst_case_visible(_state);
    var _L = vst_case_layout(_x, _y, _w, _h, array_length(_ids));

    // The cabinet: a raised carcass, then the felt-lined interior sunk into it.
    vst_render_parts_raw(vst_ui_panel(_x, _y, _x + _w, _y + _h, _w * 0.016,
                                      _w * 0.011, "edge"), _sur);
    vst_render_parts_raw(vst_ui_well(_x + _L.pad * 0.45, _y + _L.headH * 0.94,
                                     _x + _w - _L.pad * 0.45, _y + _h - _L.pad * 0.45,
                                     _w * 0.012, _w * 0.006, "panel"), _sur);

    // Header: title, then the completion bar with its numbers.
    var _sc = vst_score();
    vst_text_line("TROPHY CASE", _L.gridX, _y + _L.headH * 0.20, _L.gridW * 0.5,
                  _L.headH * 0.40, _sur.line, true);
    var _pcttxt = string(_sc.unlocked) + " / " + string(_sc.total) + "   "
                + string(round(_sc.percent * 100)) + "%   " + string(_sc.earned) + " PTS";
    vst_text_fit(_pcttxt, _x + _w - _L.pad - _L.gridW * 0.22, _y + _L.headH * 0.34,
                 _L.gridW * 0.42, _L.headH * 0.26, _sur.panel, _sur.accent);

    var _bx0 = _L.gridX, _bx1 = _L.gridX + _L.gridW;
    var _by = _y + _L.headH * 0.66, _bh = _L.headH * 0.16;
    vst_render_parts_raw(vst_ui_well(_bx0, _by, _bx1, _by + _bh, _bh * 0.5, _bh * 0.26,
                                     "felt"), _sur);
    if (_sc.percent > 0.004) {
        vst_render_parts_raw(vst_raise(vst_round_rect_pts(_bx0, _by,
            lerp(_bx0, _bx1, _sc.percent), _by + _bh, _bh * 0.5, 3), _bh * 0.30, 2,
            "accent"), _sur);
    }

    // Tabs.
    var _cats = vst_category_ids();
    for (var _i = 0; _i <= array_length(_cats); _i++) {
        var _t = vst_case_tab(_L, _i);
        var _cid = (_i == 0) ? "" : _cats[_i - 1];
        var _on = (_state.cat == _cid);
        if (_on) {
            vst_render_parts_raw(vst_ui_panel(_t[0] + 2, _t[1], _t[0] + _t[2] - 2,
                _t[1] + _t[3], _t[3] * 0.24, _t[3] * 0.10, "edge"), _sur);
        }
        vst_text_fit((_i == 0) ? "ALL" : vst_category_label(_cid),
                     _t[0] + _t[2] * 0.5, _t[1] + _t[3] * 0.52, _t[2] * 0.88, _t[3] * 0.40,
                     _sur.panel, _on ? _sur.line : _sur.dim);
    }

    // Cells.
    var _page = clamp(_state.page, 0, _L.pages - 1);
    var _first = _page * _L.perPage;
    for (var _i = 0; _i < _L.perPage; _i++) {
        var _k = _first + _i;
        if (_k >= array_length(_ids)) break;
        var _r = vst_case_cell(_L, _i);
        vst_case_draw_cell(_ids[_k], _sur, _r[0], _r[1], _r[2], _r[3], (_k == _state.sel));
    }

    if (_L.pages > 1) {
        vst_text_fit("PAGE " + string(_page + 1) + " / " + string(_L.pages),
                     _x + _w * 0.5, _y + _h - _L.pad * 0.34, _w * 0.30, _L.pad * 0.46,
                     _sur.panel, _sur.dim);
    }
}
