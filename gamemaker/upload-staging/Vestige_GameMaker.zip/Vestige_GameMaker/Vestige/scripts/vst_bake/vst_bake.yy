{
  "$GMScript": "v1",
  "%Name": "vst_bake",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_bake",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}