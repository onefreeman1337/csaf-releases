/// VESTIGE - vst_bake. The store sheets, rendered by the product itself.
///
/// NEVER SHIPS ITS OUTPUT TO THE BUYER - the sheets are store assets. The script itself ships,
/// because it is the honest proof of the listing's central claim: every image on the page was drawn
/// by the same GML the buyer is downloading, through the same public draw path, with the product's
/// own alloys, its own relief engine and its own fonts.
///
/// ⛔ WHY NOT A SIDE PREVIEWER. A sibling product in this wing shipped a JavaScript previewer for
/// authoring and it had a defect that was plainly visible in the engine and INVISIBLE in the
/// previewer - a triangle strip whose two rails were 29 and 25 points long. A store page built from
/// that previewer would have been selling pixels the shipped GML does not produce. Rendering the
/// gallery through the product closes that gap by construction.
///
/// ⛔ AND THE CHECK IS THE INK, NOT A RETURNED Y. An earlier generation of this wing had each sheet
/// return the y it finished drawing at and compared that against the surface height. That number
/// answers exactly one question - did the LAST thing drawn fall off the BOTTOM - and it is blind to
/// horizontal overflow and to emptiness. Both blind spots shipped: one sheet ran two lines of body
/// copy off the right edge cut mid-word, another left 35% of the surface as bare page, and the
/// extent check called both of them ok. So this file measures the RENDERED PIXELS.
///
/// ⚠️ TWO BOXES, NOT ONE, and the reason is that fixing the first blind spot opens a second. Once
/// the scan can see a 1px hairline, a full-width rule under a title satisfies a width floor
/// single-handed. So `full` is measured over the whole surface and is what the CLIP test uses - a
/// clipped hairline IS caught - while `content` is measured below the title rule and is what the
/// COVERAGE floors use, where the rule cannot reach it.
///
/// ⚠️ AND THE PAPERS ARE VARIED ACROSS THE SHEETS DELIBERATELY. A previous product in this wing
/// baked seven diagram sheets on one palette and Kernel/capture/dedupe.js - which hashes what a
/// buyer actually sees - measured three of them as THE SAME PICTURE. It was right: a perceptual
/// hash reads layout and overall tone, and a grid of metal shapes under a title rule is that same
/// thing however different the shapes are. Raising the threshold is banned outright by the master
/// constitution. Varying the paper fixes the collision AND demonstrates that this package ships six
/// authored case palettes, which the store page would otherwise never show.
///
/// ⚠️ AND NONE OF IT CAN TELL YOU WHETHER A PLATE IS GOOD. It makes specific named failure modes
/// unshippable. Every sheet still gets opened and looked at.
/// ============================================================================================

#macro VST_BK_W       1600
#macro VST_BK_TOL       10   // per-channel difference from the page that counts as ink
#macro VST_BK_EDGE       6   // px: ink this close to any border is a clip
#macro VST_BK_WFLOOR  0.72   // content box must span this much of the content width
#macro VST_BK_HFLOOR  0.72   // ...and this much of its height

/// ============================================================================================
/// INK MEASUREMENT
/// ============================================================================================

/// The exact bytes the hardware stores for a colour, obtained by rendering it.
///
/// Deliberately NOT colour_get_red/green/blue. Surface byte order is a platform and driver detail -
/// BGRA on some, RGBA on others - and a scan that decodes it wrongly compares red against blue and
/// reports a page full of ink. Probing through the same path the sheet takes means the comparison
/// never has to know which order it got.
function vst_bk_probe(_col) {
    var _s = surface_create(1, 1);
    surface_set_target(_s);
    draw_clear_alpha(_col, 1);
    surface_reset_target();
    var _b = buffer_create(4, buffer_fixed, 1);
    buffer_get_surface(_b, _s, 0);
    var _v = buffer_peek(_b, 0, buffer_u32);
    buffer_delete(_b);
    surface_free(_s);
    return _v;
}

/// The bounding box of everything on _surf that is not the page colour.
///
/// Returns { full, content } - each either [x0,y0,x1,y1] or undefined when nothing was found.
/// `_ctop` is the y below which content is measured.
///
/// ⛔ y STEPS BY 1. An earlier version stepped both axes by 2 and its own comment claimed it
/// "cannot miss anything wider than a pixel". Both halves of that were false: the hairline rule
/// under every title is drawn one pixel tall, and on that product it landed on an ODD row, so the
/// even-only scan walked straight past the exact feature the edge test exists to catch. x may still
/// step by 2 - nothing here draws a one-pixel-wide VERTICAL feature, and being wrong about that
/// costs an x extent off by one rather than a missed rule.
function vst_bk_ink_bounds(_surf, _ground, _ctop) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf);
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _surf, 0);

    var _g0 =  _ground        & 255;
    var _g1 = (_ground >>  8) & 255;
    var _g2 = (_ground >> 16) & 255;
    var _g3 = (_ground >> 24) & 255;

    var _fx0 = _w, _fy0 = _h, _fx1 = -1, _fy1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;

    for (var _y = 0; _y < _h; _y++) {
        var _row = _y * _w * 4;
        for (var _x = 0; _x < _w; _x += 2) {
            var _v = buffer_peek(_buf, _row + _x * 4, buffer_u32);
            if (_v == _ground) continue;
            if (abs(( _v        & 255) - _g0) <= VST_BK_TOL
             && abs(((_v >>  8) & 255) - _g1) <= VST_BK_TOL
             && abs(((_v >> 16) & 255) - _g2) <= VST_BK_TOL
             && abs(((_v >> 24) & 255) - _g3) <= VST_BK_TOL) continue;
            if (_x < _fx0) _fx0 = _x;
            if (_x > _fx1) _fx1 = _x;
            if (_y < _fy0) _fy0 = _y;
            if (_y > _fy1) _fy1 = _y;
            if (_y >= _ctop) {
                if (_x < _cx0) _cx0 = _x;
                if (_x > _cx1) _cx1 = _x;
                if (_y < _cy0) _cy0 = _y;
                if (_y > _cy1) _cy1 = _y;
            }
        }
    }
    buffer_delete(_buf);
    return {
        full:    (_fx1 < 0) ? undefined : [_fx0, _fy0, _fx1, _fy1],
        content: (_cx1 < 0) ? undefined : [_cx0, _cy0, _cx1, _cy1]
    };
}

/// Judge a finished sheet. Clip from the full box, coverage from the content box.
function vst_bk_judge(_name, _surf, _ground, _ctop) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf);
    var _bb = vst_bk_ink_bounds(_surf, _ground, _ctop);
    var _res = { sheet: _name, ok: false, reason: "", full: _bb.full, content: _bb.content };

    if (is_undefined(_bb.full)) { _res.reason = "the sheet is EMPTY - no ink at all"; return _res; }
    if (is_undefined(_bb.content)) {
        _res.reason = "nothing below the title rule - the sheet is a header and no content";
        return _res;
    }
    var _f = _bb.full;
    if (_f[0] < VST_BK_EDGE || _f[1] < VST_BK_EDGE
     || _f[2] > _w - 1 - VST_BK_EDGE || _f[3] > _h - 1 - VST_BK_EDGE) {
        _res.reason = _name + " has ink at x=" + string(_f[0]) + ".." + string(_f[2])
                    + " y=" + string(_f[1]) + ".." + string(_f[3])
                    + " on a " + string(_w) + "x" + string(_h) + " surface - CLIPPED";
        return _res;
    }
    var _c = _bb.content;
    var _cw = (_c[2] - _c[0]) / _w;
    var _ch = (_c[3] - _c[1]) / max(1, _h - _ctop);
    if (_cw < VST_BK_WFLOOR) {
        _res.reason = "content spans only " + string(round(_cw * 100)) + "% of the width";
        return _res;
    }
    if (_ch < VST_BK_HFLOOR) {
        _res.reason = "content spans only " + string(round(_ch * 100)) + "% of the content height";
        return _res;
    }
    _res.ok = true;
    _res.reason = "w=" + string(round(_cw * 100)) + "% h=" + string(round(_ch * 100)) + "%";
    return _res;
}

/// ============================================================================================
/// TYPOGRAPHY
/// ============================================================================================

/// A sheet title with its rule. Returns the y the content may start at.
function vst_bk_title(_sur, _x, _y, _w, _text, _sub) {
    draw_set_colour(_sur.line);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_font(fnt_vestige_title);
    draw_text_transformed(_x, _y, _text, 2.05, 2.05, 0);
    draw_set_font(fnt_vestige);
    draw_set_colour(_sur.dim);
    draw_text_transformed(_x, _y + 62, _sub, 1.18, 1.18, 0);
    draw_set_colour(_sur.accent);
    draw_line_width(_x, _y + 104, _x + _w, _y + 104, 1);
    return _y + 132;
}

/// A centred caption under a cell, SHRUNK TO FIT.
///
/// ⛔ THIS WING HAS SHIPPED THE OVERFLOW DEFECT TWICE - "WickthorSt Cuthman's" on one product and
/// "HEDGEHOG FUNGUSCAULIFLOWER FUNGUS" on the next - because the first fix shortened the DATA
/// rather than making the caption honest about its width. Data changes; a caption that cannot
/// overflow cannot regress. The ink-bounds check cannot see this and never will: overprinted text
/// is ink in exactly the place ink is supposed to be. It is found by reading the sheet.
/// ⚠️ THE BASE SCALE IS A PARAMETER, AND IT WAS A CONSTANT. Shrink-to-fit alone gives every caption
/// on a sheet a DIFFERENT size - the long ones shrink and the short ones do not - so the device
/// sheet came out with "GAUNTLET" set half again as large as "CROSSED BLADES" two cells away, and
/// two of the wide ones almost touching. A sheet picks one base small enough that none of its
/// captions has to shrink, and the shrink stays as the guard against data nobody has seen yet.
function vst_bk_caption(_sur, _cx, _y, _text, _sub, _maxw, _scale) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_top);
    draw_set_font(fnt_vestige_title);
    draw_set_colour(_sur.line);
    var _sc = is_undefined(_scale) ? 1.14 : _scale;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    draw_text_transformed(_cx, _y, _text, _sc, _sc, 0);

    if (_sub != "") {
        draw_set_font(fnt_vestige);
        draw_set_colour(_sur.dim);
        var _ss = 0.96;
        var _sw = string_width(_sub) * _ss;
        if (_sw > _maxw && _sw > 0) _ss *= _maxw / _sw;
        draw_text_transformed(_cx, _y + 34, _sub, _ss, _ss, 0);
    }
    draw_set_halign(fa_left);
}

/// Open a sheet surface on a paper.
///
/// ⚠️ _bg IS AN ARGUMENT BECAUSE ONE SHEET NEEDED A DIFFERENT ONE AND SHIPPED INVISIBLE WITHOUT IT.
/// The strike sheet draws the reveal PANEL, whose role is `panel` - onto a page that was also
/// cleared to `panel`. Same colour, so the panel was a rectangle of page and every medal appeared
/// to float in a void. The ink check could not see it either: a panel drawn in the page colour is
/// not ink. Found by opening the PNG.
function vst_bk_open(_sur, _h, _bg) {
    var _c = is_undefined(_bg) ? _sur.panel : _bg;
    var _surf = surface_create(VST_BK_W, _h);
    surface_set_target(_surf);
    draw_clear_alpha(_c, 1);
    return _surf;
}

/// ============================================================================================
/// THE SHEETS
/// ============================================================================================

/// SHEET 1 - THE CORPUS. All forty-two devices, six to a category, seven categories.
///
/// This is the sheet the product is sold on. Everything else demonstrates a system; this one shows
/// how much was drawn by hand, which is the part that cannot be reproduced in an afternoon.
function vst_bk_sheet_devices() {
    var _sur = vst_surface("gold", "slate", "crimson", "bone");
    var _cols = 6, _cw = 226, _chh = 214, _rowh = 236;
    var _labw = 128;
    var _h = 190 + 7 * _rowh + 34;
    var _surf = vst_bk_open(_sur, _h);

    var _ctop = vst_bk_title(_sur, 76, 54, VST_BK_W - 152,
        "FORTY-TWO DEVICES",
        "Every charge below is drawn from data and lit by one lamp. No sprite, no atlas, no texture page.");

    var _cats = vst_category_ids();
    var _x0 = 76 + _labw;
    for (var _r = 0; _r < array_length(_cats); _r++) {
        var _cy = _ctop + 10 + _r * _rowh;
        var _ds = vst_category_devices(_cats[_r]);

        draw_set_font(fnt_vestige_title);
        draw_set_halign(fa_left);
        draw_set_valign(fa_middle);
        draw_set_colour(_sur.accent);
        draw_text_transformed(76, _cy + _chh * 0.42, vst_category_label(_cats[_r]), 0.98, 0.98, 0);
        draw_set_valign(fa_top);

        for (var _c = 0; _c < _cols; _c++) {
            var _cx = _x0 + _c * _cw;
            var _dev = vst_device(_ds[_c]);
            vst_render_in_rect(vst_device_parts(_ds[_c], 2), _sur,
                               _cx + 14, _cy, _cw - 28, _chh - 70, 0, undefined);
            vst_bk_caption(_sur, _cx + _cw * 0.5, _cy + _chh - 62, _dev.label, "", _cw - 16, 0.78);
        }
    }

    surface_reset_target();
    var _res = vst_bk_judge("sheet_1_devices", _surf, vst_bk_probe(_sur.panel), _ctop);
    surface_save(_surf, "sheet_1_devices.png");
    surface_free(_surf);
    return _res;
}

/// SHEET 2 - the twelve blank forms, all struck in one alloy with one rim, so only the silhouette
/// varies. A sheet that changed the metal at the same time would let a viewer tell the cells apart
/// without the forms doing any work, which is how a whole axis ships looking finished and carrying
/// nothing.
/// ⛔ OXBLOOD AND SIX COLUMNS, AND IT WAS EBONY AND FOUR. MEASURED by Kernel/capture/dedupe.js,
/// which hashes what a buyer actually sees: on ebony at 4x3 this sheet and the ribbons sheet came
/// back as THE SAME PICTURE at Hamming distance 7 against a threshold of 8. The hash is right - a
/// perceptual hash reads layout and overall tone, and two dark grids of metal shapes under a title
/// rule are that same thing however different the shapes are.
///
/// ⚠️ RAISING THE THRESHOLD IS BANNED OUTRIGHT by the master constitution, and it would be the
/// wrong answer anyway: the gallery had a real problem, which is that a viewer skimming nine
/// thumbnails could not tell two of them apart. Changing BOTH the paper and the grid shape fixes
/// the collision and shows off a second of the six case palettes in the same stroke.
function vst_bk_sheet_planchets() {
    var _sur = vst_surface("silver", "oxblood", "azure", "bone");
    var _cols = 6, _cw = 226, _chh = 262, _gap = 18;
    var _h = 190 + 2 * (_chh + 26) + 34;
    var _surf = vst_bk_open(_sur, _h);

    var _ctop = vst_bk_title(_sur, 76, 54, VST_BK_W - 152,
        "TWELVE BLANK FORMS",
        "Each blank is a polar radius function, so its rim furniture and its field follow the shape for free.");

    var _ids = vst_planchet_ids();
    var _x0 = (VST_BK_W - (_cols * _cw + (_cols - 1) * _gap)) * 0.5;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _c = _i % _cols, _r = _i div _cols;
        var _cx = _x0 + _c * (_cw + _gap);
        var _cy = _ctop + 6 + _r * (_chh + 26);
        var _m = vst_medal({ id: "form_" + _ids[_i], planchet: _ids[_i], rim: "plain",
                             device: "compass", alloy: "silver", suspended: false, name: "" });
        vst_medal_draw(_m, _sur, _cx + _cw * 0.5, _cy + (_chh - 58) * 0.5,
                       min(_cw, _chh - 58) * 0.98, 2);
        vst_bk_caption(_sur, _cx + _cw * 0.5, _cy + _chh - 50,
                       string_upper(_ids[_i]), "", _cw - 14, 0.80);
    }

    surface_reset_target();
    var _res = vst_bk_judge("sheet_2_planchets", _surf, vst_bk_probe(_sur.panel), _ctop);
    surface_save(_surf, "sheet_2_planchets.png");
    surface_free(_surf);
    return _res;
}

/// SHEET 3 - the six rim treatments, large enough to see the individual pieces of furniture, all
/// on the same round blank for the same reason sheet 2 fixes its alloy.
function vst_bk_sheet_rims() {
    var _sur = vst_surface("bronze", "walnut", "umber", "amber");
    var _cols = 3, _cw = 470, _chh = 452, _gap = 30;
    var _h = 190 + 2 * (_chh + 26) + 28;
    var _surf = vst_bk_open(_sur, _h);

    var _ctop = vst_bk_title(_sur, 76, 54, VST_BK_W - 152,
        "SIX RIM TREATMENTS",
        "Beads, milling, cable, laurel and dentils - every piece struck and lit separately, on any blank.");

    var _ids = vst_rim_ids();
    var _x0 = (VST_BK_W - (_cols * _cw + (_cols - 1) * _gap)) * 0.5;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _c = _i % _cols, _r = _i div _cols;
        var _cx = _x0 + _c * (_cw + _gap);
        var _cy = _ctop + 2 + _r * (_chh + 26);
        var _m = vst_medal({ id: "rim_" + _ids[_i], planchet: "round", rim: _ids[_i],
                             device: "sun", alloy: "bronze", suspended: false, name: "" });
        vst_medal_draw(_m, _sur, _cx + _cw * 0.5, _cy + (_chh - 64) * 0.5,
                       min(_cw, _chh - 64) * 0.98, 2);
        vst_bk_caption(_sur, _cx + _cw * 0.5, _cy + _chh - 58,
                       string_upper(_ids[_i]), "", _cw - 24);
    }

    surface_reset_target();
    var _res = vst_bk_judge("sheet_3_rims", _surf, vst_bk_probe(_sur.panel), _ctop);
    surface_save(_surf, "sheet_3_rims.png");
    surface_free(_surf);
    return _res;
}

/// SHEET 4 - THE TIER LADDER. The same award struck in all seven alloys, plus the empty cavity a
/// locked award leaves. Rendered on the pale paper, because that is the one where a pale alloy has
/// the least room and is therefore the honest place to show them.
function vst_bk_sheet_alloys() {
    var _paper = "ivory";
    var _sur = vst_surface("gold", _paper, "plum", "bone");
    var _cols = 4, _cw = 356, _chh = 372, _gap = 20;
    var _h = 190 + 2 * (_chh + 28) + 28;
    var _surf = vst_bk_open(_sur, _h);

    var _ctop = vst_bk_title(_sur, 76, 54, VST_BK_W - 152,
        "SEVEN ALLOYS AND AN EMPTY WELL",
        "Each alloy is five stops spaced in Oklch. A tier is legible with the name covered up, which is the test that matters.");

    var _ids = vst_alloy_ids();
    var _x0 = (VST_BK_W - (_cols * _cw + (_cols - 1) * _gap)) * 0.5;
    for (var _i = 0; _i < 8; _i++) {
        var _c = _i % _cols, _r = _i div _cols;
        var _cx = _x0 + _c * (_cw + _gap);
        var _cy = _ctop + 2 + _r * (_chh + 28);
        var _locked = (_i == 7);
        var _m = vst_medal({ id: "tier_demo", planchet: "octagon", rim: "beaded",
                             device: "blades", alloy: _locked ? "iron" : _ids[_i],
                             suspended: false, locked: _locked, name: "" });
        var _ms = vst_medal_surface(_m, _paper);
        if (!_locked) vst_medal_shadow(_m, _ms, _cx + _cw * 0.5, _cy + (_chh - 62) * 0.5,
                                       min(_cw, _chh - 62) * 0.92, 1);
        vst_medal_draw(_m, _ms, _cx + _cw * 0.5, _cy + (_chh - 62) * 0.5,
                       min(_cw, _chh - 62) * 0.92, 2);
        vst_bk_caption(_sur, _cx + _cw * 0.5, _cy + _chh - 56,
                       _locked ? "NOT YET EARNED" : string_upper(_ids[_i]),
                       _locked ? "the well keeps the shape" : ("TIER " + string(_i)), _cw - 20);
    }

    surface_reset_target();
    var _res = vst_bk_judge("sheet_4_alloys", _surf, vst_bk_probe(_sur.panel), _ctop);
    surface_save(_surf, "sheet_4_alloys.png");
    surface_free(_surf);
    return _res;
}

/// SHEET 5 - the eight ribbon patterns, suspended, each in its own category's dyes. The category
/// is the reason the ribbon exists: two gold medals are the same metal, and the ribbon is what says
/// one was for valour and the other for lore.
function vst_bk_sheet_ribbons() {
    // Ebony, and it was oxblood - see the note on the blank-forms sheet. The two of them plus the
    // hero plate were all sitting on dark warm papers, and the perceptual hash could not separate
    // them. Spreading the nine sheets across five of the six case palettes is what fixed it.
    var _paper = "ebony";
    var _sur = vst_surface("gold", _paper, "crimson", "bone");
    var _cols = 4, _cw = 356, _chh = 420, _gap = 20;
    var _h = 190 + 2 * (_chh + 26) + 28;
    var _surf = vst_bk_open(_sur, _h);

    var _ctop = vst_bk_title(_sur, 76, 54, VST_BK_W - 152,
        "EIGHT RIBBONS, SEVEN CATEGORIES",
        "The pattern is evaluated per cell of the drape, so it falls inside the cloth with nothing to clip.");

    var _ids = vst_ribbon_ids();
    var _cats = vst_category_ids();
    var _x0 = (VST_BK_W - (_cols * _cw + (_cols - 1) * _gap)) * 0.5;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _c = _i % _cols, _r = _i div _cols;
        var _cx = _x0 + _c * (_cw + _gap);
        var _cy = _ctop + 2 + _r * (_chh + 26);
        var _cat = _cats[_i % array_length(_cats)];
        var _m = vst_medal({ id: "ribbon_" + _ids[_i], category: _cat, ribbon: _ids[_i],
                             planchet: "round", rim: "cable", tier: 3 + (_i % 3), name: "" });
        var _ms = vst_medal_surface(_m, _paper);
        vst_medal_draw(_m, _ms, _cx + _cw * 0.5, _cy + (_chh - 68) * 0.5,
                       min(_cw, _chh - 68) * 0.96, 2);
        vst_bk_caption(_sur, _cx + _cw * 0.5, _cy + _chh - 62,
                       string_upper(_ids[_i]), vst_category_label(_cat), _cw - 20);
    }

    surface_reset_target();
    var _res = vst_bk_judge("sheet_5_ribbons", _surf, vst_bk_probe(_sur.panel), _ctop);
    surface_save(_surf, "sheet_5_ribbons.png");
    surface_free(_surf);
    return _res;
}

/// SHEET 6 - THE TROPHY CASE, drawn full-bleed by the same function a buyer calls. Empty wells,
/// progress bars, category tabs, points and the completion rule, on a real part-earned save.
function vst_bk_sheet_case() {
    var _sur = vst_surface("gold", "walnut", "crimson", "bone");
    var _h = 1000;
    var _surf = vst_bk_open(_sur, _h);

    vst_sample_awards();
    vst_sample_progress();
    var _st = vst_case_state("walnut");
    // ⚠️ INSET BY 14, NOT FULL BLEED. The first bake drew the cabinet from (0,0) to the surface
    // edge and the ink check called it CLIPPED - correctly, because a cabinet whose moulding is cut
    // off by the frame is exactly what a clipped sheet looks like, and the check has no way to tell
    // "deliberately full bleed" from "ran off the edge". Neither has a buyer.
    vst_case_draw(_st, 14, 14, VST_BK_W - 28, _h - 28);

    surface_reset_target();
    var _res = vst_bk_judge("sheet_6_case", _surf, vst_bk_probe(_sur.panel), 0);
    surface_save(_surf, "sheet_6_case.png");
    surface_free(_surf);
    return _res;
}

/// SHEET 7 - THE STRIKE, six frames of it. The one moment a player sees every time they earn
/// something, and the one thing a still store page normally cannot show at all.
/// ⛔ THREE COLUMNS OF TWO, AND IT TOOK THREE LAYOUTS TO GET THERE. Every one of them was rejected
/// by the ink check or by looking at the render, and each failure named a different real thing:
///
///   1. ONE COLUMN OF SIX at 640px wide. Content box 50% of the sheet width - half the page bare,
///      which is the exact "35% of the surface is empty" failure this wing's ink floors exist to
///      catch - and the last row ran 63px off the bottom.
///   2. TWO COLUMNS OF THREE at 600px. Still clipped, and the reason was NOT the layout: the first
///      frame of the strike draws the medal at 1.85 times its settled size, and the shock ring
///      reaches almost a full medal-width out from the impact. At that toast size the ring's left
///      edge landed at x=0. On a real screen that is correct and invisible - the toast sits in the
///      top right of a 1280px window and the ring has a whole screen to expand into - but a store
///      sheet is exactly as wide as its content.
///   3. THREE COLUMNS OF TWO at 440px. The medal at full drop is 240px tall and the ring reaches
///      130px, both of which fit inside a 300px row with the toast inset 60 from its top.
///
/// The general lesson is worth more than the layout: a UI component sized by its own container
/// still has to be given room for the parts of its ANIMATION that leave that container.
function vst_bk_sheet_toast() {
    var _sur = vst_surface("gold", "ebony", "crimson", "bone");
    var _bg = _sur.ground;
    var _tw = 440;
    var _rowh = 300;
    var _h = 190 + 2 * _rowh + 60;
    var _surf = vst_bk_open(_sur, _h, _bg);

    var _ctop = vst_bk_title(_sur, 76, 54, VST_BK_W - 152,
        "THE STRIKE",
        "The die falls, the metal flashes, a shock ring runs out of the impact and the panel comes out from behind.");

    vst_sample_awards();
    vst_toast_init();
    vst_toast_show("masterwork");

    var _ts = [0.02, 0.13, 0.19, 0.30, 0.58, 3.56];
    var _names = ["STRIKE", "SETTLE", "HOLD", "EXIT"];
    var _anchors = [516, 1020, VST_BK_W - 76];
    for (var _i = 0; _i < 6; _i++) {
        var _c = _i % 3, _r = _i div 3;
        global.vst_toast.t = _ts[_i];
        var _y = _ctop + 60 + _r * _rowh;
        vst_toast_draw(_anchors[_c], _y, _tw, "ebony");

        var _lx = _anchors[_c] - _tw;
        var _ly = _y + 196;
        draw_set_font(fnt_vestige_title);
        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
        draw_set_colour(_sur.accent);
        var _stage = vst_toast_frame(_ts[_i]).stage;
        draw_text_transformed(_lx, _ly, _names[_stage - 1], 0.92, 0.92, 0);
        draw_set_font(fnt_vestige);
        draw_set_colour(_sur.dim);
        draw_text_transformed(_lx + 150, _ly + 4,
            "t = " + string_format(_ts[_i], 1, 2) + " s", 1.00, 1.00, 0);
    }

    surface_reset_target();
    var _res = vst_bk_judge("sheet_7_strike", _surf, vst_bk_probe(_bg), _ctop);
    surface_save(_surf, "sheet_7_strike.png");
    surface_free(_surf);
    return _res;
}

/// SHEET 8 - THE SAME MEDAL AT THE THREE SIZES IT IS ACTUALLY USED AT.
///
/// ⛔ THIS SHEET EXISTS BECAUSE OF A MEASURED FAILURE, not for completeness. A sibling product's
/// label-clipping defect was invisible on its 1600px sheets and obvious the moment a 900px GIF
/// rendered, because margins that are generous at one size are not at another. A medal that only
/// composes correctly at store-sheet size is a medal that fails in the buyer's HUD, and the only
/// way to see it is to draw the same thing smaller.
function vst_bk_sheet_scales() {
    var _paper = "verdigris";
    var _sur = vst_surface("electrum", _paper, "moss", "amber");
    // ⛔ THIS SHEET WAS THREE MEDALS ON A 1600px PAGE AND IT PASSED THE INK CHECK AT 77% AND 92%.
    // The check measures a BOUNDING BOX, so three widely-spaced objects score the same as a filled
    // page - which is a real and permanent blind spot in it, not a bug to be tuned away. Opening
    // the PNG showed most of a store sheet as bare paper.
    //
    // The fix is more content rather than tighter spacing, and it makes the sheet argue its point
    // better anyway: one hero medal, FOUR at card size and SIXTEEN at inventory size, all of them
    // different awards. Twenty-one medals, and the claim it is making - that the same code composes
    // at all three sizes - is now demonstrated rather than asserted.
    var _h = 800;
    var _surf = vst_bk_open(_sur, _h);

    var _ctop = vst_bk_title(_sur, 76, 44, VST_BK_W - 152,
        "HERO, CARD AND INVENTORY",
        "The detail level follows the pixel size, so the legend and the incision drop out before they can turn to mush.");

    var _devs = vst_device_ids();
    var _cats = vst_category_ids();

    // The hero.
    var _hero = vst_medal({ id: "masterwork", category: "craft", tier: 4, planchet: "star",
                            rim: "reeded", device: "anvil", name: "MASTERWORK", exergue: "70 PTS" });
    var _hs = vst_medal_surface(_hero, _paper);
    vst_medal_shadow(_hero, _hs, 298, _ctop + 240, 420, 2);
    vst_medal_draw(_hero, _hs, 298, _ctop + 240, 420, 2);

    // Four at card size.
    for (var _i = 0; _i < 4; _i++) {
        var _c = _i % 2, _r = _i div 2;
        var _m1 = vst_medal({ id: "card_" + string(_i), category: _cats[_i],
                              tier: 6 - _i * 2, device: _devs[_i * 7 + 3] });
        var _s1 = vst_medal_surface(_m1, _paper);
        var _x1 = 552 + _c * 236 + 118, _y1 = _ctop + 16 + _r * 248 + 124;
        vst_medal_shadow(_m1, _s1, _x1, _y1, 196, 1);
        vst_medal_draw(_m1, _s1, _x1, _y1, 196, 1);
    }

    // Sixteen at inventory size.
    for (var _i = 0; _i < 16; _i++) {
        var _c = _i % 4, _r = _i div 4;
        var _m2 = vst_medal({ id: "inv_" + string(_i), category: _cats[_i % 7],
                              tier: _i % 7, device: _devs[(_i * 5 + 2) % 42] });
        var _s2 = vst_medal_surface(_m2, _paper);
        var _x2 = 1056 + _c * 117 + 58, _y2 = _ctop + 16 + _r * 124 + 62;
        vst_medal_draw(_m2, _s2, _x2, _y2, 96, 0);
    }

    var _labels = ["430 px  HERO", "196 px  CARD", "96 px  INVENTORY"];
    var _bandx = [298, 788, 1290];
    for (var _i = 0; _i < 3; _i++) {
        vst_bk_caption(_sur, _bandx[_i], _ctop + 530, _labels[_i], "", 420);
    }

    surface_reset_target();
    var _res = vst_bk_judge("sheet_8_scales", _surf, vst_bk_probe(_sur.panel), _ctop);
    surface_save(_surf, "sheet_8_scales.png");
    surface_free(_surf);
    return _res;
}

/// SHEET 9 - one medal, large, with its legend struck around the rim. The hero plate.
function vst_bk_sheet_hero() {
    var _paper = "oxblood";
    var _sur = vst_surface("gold", _paper, "crimson", "bone");
    var _h = 900;
    var _surf = vst_bk_open(_sur, _h);

    // A shallow well the hero medal lies in, so the plate has a stage rather than a backdrop.
    vst_render_parts_raw(vst_ui_well(60, 56, VST_BK_W - 60, _h - 56, 26, 14, "felt"), _sur);

    var _hero = vst_medal({ id: "the_watching", category: "lore", tier: 6, planchet: "sunburst",
                            rim: "laurel", device: "watcher", name: "THE WATCHING",
                            exergue: "120 PTS" });
    var _hs = vst_medal_surface(_hero, _paper);
    vst_medal_shadow(_hero, _hs, 470, 470, 700, 2);
    vst_medal_draw(_hero, _hs, 470, 470, 700, 2);

    vst_text_line("VESTIGE", 900, 190, 600, 96, _sur.line, true);
    vst_text_line("Every award strikes its own medal.", 900, 306, 620, 40, _sur.accent, false);
    vst_text_body("Forty-two hand-drawn devices, twelve blank forms, six rim treatments, seven "
        + "alloys and eight ribbons, all struck in GML and lit by one lamp. Tracking, tiered "
        + "chains, prerequisites, secret awards, points, save and load, an animated strike and a "
        + "trophy case are underneath it.",
        900, 372, 620, 32, _sur.dim);

    var _cats = vst_category_ids();
    for (var _i = 0; _i < 4; _i++) {
        var _m = vst_medal({ id: "hero_" + string(_i), category: _cats[_i + 1],
                             tier: 5 - _i, suspended: false });
        var _ms = vst_medal_surface(_m, _paper);
        vst_medal_shadow(_m, _ms, 986 + _i * 168, 700, 148, 1);
        vst_medal_draw(_m, _ms, 986 + _i * 168, 700, 148, 1);
    }

    surface_reset_target();
    var _res = vst_bk_judge("sheet_9_hero", _surf, vst_bk_probe(_sur.panel), 0);
    surface_save(_surf, "sheet_9_hero.png");
    surface_free(_surf);
    return _res;
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

/// ============================================================================================
/// THE ANIMATION STRIP
///
/// The store GIF, rendered frame by frame by the product rather than screen-captured off a running
/// window. Two reasons, and the second is the one that matters:
///
///   1. A capture is at the mercy of whatever the compositor and the recorder do to it. These
///      frames are the exact pixels vst_toast_draw produces.
///   2. It is DETERMINISTIC. `vst_toast_frame` is a pure function of time, so the strip is a
///      sampling of that function at fixed intervals - the same GIF, every run, on any machine,
///      with no dropped frames and no timing jitter to explain away.
///
/// ⚠️ THE FRAME IS SIZED SO THE ANIMATION FITS, not so the panel fits. The medal is drawn at 1.85
/// times its settled size on the first frame and the shock ring reaches most of a medal-width out
/// from the impact; both leave the toast's own rectangle, and both have to land inside the frame or
/// the GIF clips exactly at its loudest moment.
/// ============================================================================================

/// ⚠️ 660x340 WITH THE TOAST AT y=80, AND IT WAS 620x300 AT y=60. MEASURED BY LOOKING at the first
/// frames: the medal drops in at 1.85 times its settled size, which puts the ribbon's mount bar
/// seven pixels from the top edge on frame zero, and left a dead band across the bottom for the
/// rest of the loop. The frame is now sized around the ANIMATION's extent rather than the panel's,
/// with the panel centred in what is left.
#macro VST_GIF_W  660
#macro VST_GIF_H  340
#macro VST_GIF_N   60

function vst_gif_run() {
    vst_sample_awards();
    vst_grant("keen_edge");
    vst_toast_init();
    vst_toast_show("masterwork");

    var _sur = vst_surface("gold", "ebony", "crimson", "bone");
    var _written = 0;
    for (var _i = 0; _i < VST_GIF_N; _i++) {
        global.vst_stage = 100 + _i;
        global.vst_toast.t = (_i / VST_GIF_N) * (VST_T_EXIT + 0.06);

        var _surf = surface_create(VST_GIF_W, VST_GIF_H);
        surface_set_target(_surf);
        draw_clear_alpha(_sur.ground, 1);
        vst_toast_draw(640, 80, 500, "ebony");
        surface_reset_target();

        var _n = string(_i);
        while (string_length(_n) < 3) _n = "0" + _n;
        surface_save(_surf, "gif_" + _n + ".png");
        surface_free(_surf);
        _written++;
    }

    var _f = file_text_open_write("vst_gif.json");
    file_text_write_string(_f, "{\"crash\":false,\"product\":\"Vestige\",\"frames\":"
        + string(_written) + ",\"w\":" + string(VST_GIF_W) + ",\"h\":" + string(VST_GIF_H) + "}");
    file_text_close(_f);
}

function vst_bake_run() {
    var _sheets = [];
    global.vst_stage = 1; array_push(_sheets, vst_bk_sheet_devices());
    global.vst_stage = 2; array_push(_sheets, vst_bk_sheet_planchets());
    global.vst_stage = 3; array_push(_sheets, vst_bk_sheet_rims());
    global.vst_stage = 4; array_push(_sheets, vst_bk_sheet_alloys());
    global.vst_stage = 5; array_push(_sheets, vst_bk_sheet_ribbons());
    global.vst_stage = 6; array_push(_sheets, vst_bk_sheet_case());
    global.vst_stage = 7; array_push(_sheets, vst_bk_sheet_toast());
    global.vst_stage = 8; array_push(_sheets, vst_bk_sheet_scales());
    global.vst_stage = 9; array_push(_sheets, vst_bk_sheet_hero());

    var _bad = 0;
    var _s = "{\"crash\":false,\"product\":\"Vestige\",\"sheets\":[";
    for (var _i = 0; _i < array_length(_sheets); _i++) {
        var _r = _sheets[_i];
        if (!_r.ok) _bad++;
        if (_i > 0) _s += ",";
        _s += "{\"sheet\":\"" + _r.sheet + "\",\"ok\":" + (_r.ok ? "true" : "false")
            + ",\"reason\":\"" + string_replace_all(_r.reason, "\"", "'") + "\",\"content\":"
            + (is_undefined(_r.content) ? "null"
               : ("[" + string(_r.content[0]) + "," + string(_r.content[1]) + ","
                      + string(_r.content[2]) + "," + string(_r.content[3]) + "]"))
            + "}";
    }
    _s += "],\"rejected\":" + string(_bad) + "}";

    var _f = file_text_open_write("vst_bake.json");
    file_text_write_string(_f, _s);
    file_text_close(_f);
}
