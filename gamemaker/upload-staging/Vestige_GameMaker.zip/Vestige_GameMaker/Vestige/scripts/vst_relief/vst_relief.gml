/// VESTIGE - vst_relief. Shade any outline by its own surface normal. This file IS the product.
///
/// ⛔ EVERY OTHER PRODUCT IN THIS STUDIO'S GAMEMAKER CATALOGUE DRAWS FLAT MASSES. This one draws
/// RELIEF, and the difference is one idea: a closed outline is not a silhouette, it is the top of a
/// raised shape, and the little wall between the top and the field around it points a different way
/// on every side. Light that wall from a single fixed lamp and the shape stops being a sticker.
///
/// THE ONE FIXED LIGHT. Up and to the left, always, in every part of this package - the medal, the
/// rim, the device, the ribbon buckle, the trophy case moulding and the reveal toast. It is a
/// constant and not a parameter, and that is deliberate: a struck medal is a physical object and
/// the whole illusion is that the same lamp is shining on all of it. A per-call light angle is the
/// first thing a caller would reach for and the first thing that would break the picture, so it is
/// not offered.
///
/// -- HOW A BEVEL IS BUILT --------------------------------------------------------------------
/// Given a closed outline, walk it edge by edge. Each edge has an outward normal; the wall under
/// that edge is a quad running from the outline inward. Colour the quad from the alloy's five-stop
/// ramp by how squarely its normal faces the lamp, and the shape now has a lit side and a shadowed
/// side. Nest two or three of those walls at decreasing tilt and the edge stops being a chamfer and
/// becomes a dome.
///
/// ⚠️ THE INNER RING USES VERTEX NORMALS AND THE COLOUR USES EDGE NORMALS, and mixing those up is
/// the whole difficulty. Offsetting each edge independently by its own normal is the obvious
/// implementation and it tears the shape open at every convex corner - on a hexagon or an
/// eight-point star the gaps are wider than the bevel. Offsetting by the AVERAGED normal at each
/// vertex keeps the inner ring closed, and the colour still has to come from the edge, because a
/// vertex normal at a sharp corner points diagonally and would light both walls the same.
///
/// ⚠️ AND THE OFFSET HELPER IN THE PRIMITIVE LAYER CANNOT BE USED FOR THIS. vst_offset_pts clamps
/// at the array ends instead of wrapping, which is right for an open polyline and puts a visible
/// kink in the seam of every closed ring. vst_inset below wraps.
///
/// ⛔ TILT IS WHY THIS READS AS METAL AND NOT AS A CARTOON OUTLINE. The outermost wall of a dome is
/// nearly vertical, so it swings across the entire five-stop ramp; the innermost is nearly flat, so
/// it barely leaves the face value. Shading every nested ring at full contrast produces concentric
/// coloured hoops - which was the first version of this file, and it looked like a target.
/// ============================================================================================

/// The lamp, as a unit vector pointing TOWARD the light, in the package's y-DOWN coordinates.
/// (-0.707, -0.707) is up and to the left. Written out rather than derived from an angle so there
/// is exactly one place to read it and no chance of a degree/radian mistake.
#macro VST_LX -0.7071067811865476
#macro VST_LY -0.7071067811865476

/// The five ramp roles, in order. Named here so nothing else in the package has to know that the
/// alloy ramp is five stops long.
#macro VST_RAMP_N 5

/// ============================================================================================
/// OUTLINE GEOMETRY
/// ============================================================================================

/// Twice the signed area of a closed polygon. Sign tells us the winding, which tells us which of
/// the two perpendiculars points OUT.
///
/// ⚠️ THE PACKAGE DOES NOT REQUIRE A WINDING CONVENTION FROM ITS AUTHORS, AND THAT IS DELIBERATE.
/// Forty-two devices are authored by hand; a rule that says "always list your points clockwise"
/// is a rule that will be broken silently, and the failure mode - a device lit from the wrong side
/// while everything around it is lit correctly - is subtle enough to ship. Measuring the winding
/// costs one loop and makes the rule unnecessary.
function vst_area2(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return 0;
    var _s = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i], _b = _pts[(_i + 1) % _n];
        _s += _a[0] * _b[1] - _b[0] * _a[1];
    }
    return _s;
}

/// The outward unit normal of the edge leaving vertex _i of a closed polygon.
function vst_edge_normal(_pts, _i, _sign) {
    var _n = array_length(_pts);
    var _a = _pts[_i], _b = _pts[(_i + 1) % _n];
    var _dx = _b[0] - _a[0], _dy = _b[1] - _a[1];
    var _len = point_distance(0, 0, _dx, _dy);
    if (_len == 0) return [0, 0];
    return [(_dy / _len) * _sign, (-_dx / _len) * _sign];
}

/// Move every vertex of a CLOSED polygon inward by _d along its averaged vertex normal.
///
/// Wraps at both ends, unlike the primitive layer's open-polyline offset. A ring whose first and
/// last vertices were offset one-sidedly develops a notch exactly where the seam is, and on a
/// circle - which is most of this product - the seam is at three o'clock, in plain view.
function vst_inset(_pts, _d, _sign) {
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[(_i + _n - 1) % _n], _q = _pts[(_i + 1) % _n];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) { _out[_i] = [_pts[_i][0], _pts[_i][1]]; continue; }
        var _nx = (_dy / _len) * _sign, _ny = (-_dx / _len) * _sign;
        _out[_i] = [_pts[_i][0] - _nx * _d, _pts[_i][1] - _ny * _d];
    }
    return _out;
}

/// The winding sign to pass to vst_edge_normal / vst_inset so that "normal" means OUTWARD.
function vst_out_sign(_pts) {
    return (vst_area2(_pts) > 0) ? 1 : -1;
}

/// Scale a closed outline about its own centroid. Used for nesting rings and for the recessed
/// field inside a planchet.
function vst_scale_pts(_pts, _k) {
    var _n = array_length(_pts);
    var _cx = 0, _cy = 0;
    for (var _i = 0; _i < _n; _i++) { _cx += _pts[_i][0]; _cy += _pts[_i][1]; }
    _cx /= _n; _cy /= _n;
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        _out[_i] = [_cx + (_pts[_i][0] - _cx) * _k, _cy + (_pts[_i][1] - _cy) * _k];
    }
    return _out;
}

/// Translate a closed outline.
function vst_move_pts(_pts, _dx, _dy) {
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _out[_i] = [_pts[_i][0] + _dx, _pts[_i][1] + _dy];
    return _out;
}

/// ============================================================================================
/// THE RAMP LOOKUP
/// ============================================================================================

/// Which of the five alloy stops a wall with this outward normal shows.
///
/// _tilt is how far the wall leans away from the face: 1.0 is a vertical wall that swings across
/// the whole ramp, 0.0 is flat and always shows the face value. See the header for why nesting
/// rings at constant tilt draws a target.
///
/// ⚠️ THE BANDS ARE HARD, NOT INTERPOLATED, AND THAT IS THE CORRECT CHOICE HERE rather than a
/// limitation. Five discrete values around a rim is what a struck coin photographs like, and it is
/// what makes the alloy readable - a continuous gradient would need hundreds of colours and would
/// average out to a flat disc at inventory size, which is precisely where the tier has to read.
function vst_relief_role(_nx, _ny, _tilt) {
    var _d = _nx * VST_LX + _ny * VST_LY;
    var _t = 0.5 + 0.5 * _d * _tilt;
    if (_t < 0.190) return "m0";
    if (_t < 0.385) return "m1";
    if (_t < 0.615) return "m2";
    if (_t < 0.810) return "m3";
    return "m4";
}

/// ============================================================================================
/// THE BEVEL
/// ============================================================================================

/// A domed wall running inward from a closed outline, as normal-shaded quads.
///
/// _b      how far in the wall reaches, in unit-box units
/// _steps  how many nested rings (1 = a flat chamfer, 3 = a convincing dome)
/// _invert true for a SUNKEN shape, where the wall faces inward and the lit side swaps
///
/// Each quad is [outer_i, outer_i+1, inner_i+1, inner_i] - convex, so the fan primitive draws it
/// correctly with no special casing.
function vst_bevel(_pts, _b, _steps, _invert) {
    var _n = array_length(_pts);
    var _out = [];
    if (_n < 3 || _b <= 0) return _out;
    var _st = max(1, _steps);
    var _sign = vst_out_sign(_pts) * (_invert ? -1 : 1);
    var _geo = vst_out_sign(_pts);

    var _rings = array_create(_st + 1);
    for (var _s = 0; _s <= _st; _s++) _rings[_s] = vst_inset(_pts, _b * (_s / _st), _geo);

    for (var _s = 0; _s < _st; _s++) {
        // Outer walls are steep, inner walls are nearly flat. 0.30 rather than 0 at the innermost
        // ring because a wall that shows exactly the face value is a wall you cannot see, and the
        // dome then ends in a visible step instead of easing into the field.
        var _tilt = lerp(1.0, 0.30, (_s + 0.5) / _st);
        var _a = _rings[_s], _c = _rings[_s + 1];
        for (var _i = 0; _i < _n; _i++) {
            var _k = (_i + 1) % _n;
            var _nm = vst_edge_normal(_pts, _i, _sign);
            array_push(_out, vst_fill([_a[_i], _a[_k], _c[_k], _c[_i]],
                                      vst_relief_role(_nm[0], _nm[1], _tilt)));
        }
    }
    return _out;
}

/// ============================================================================================
/// THE TWO COMPOSITES EVERYTHING ELSE IS BUILT FROM
/// ============================================================================================

/// A RAISED shape: a flat top at _face, walled all round by a lit dome.
///
/// ⛔ THE FACE IS DRAWN FIRST AND THE WALL SECOND, AND SWAPPING THEM COSTS THE WHOLE EFFECT. The
/// wall's inner ring and the face overlap by design - the fan that fills the face is star-shaped
/// about its centroid and cannot be trusted to land exactly on the wall's inner edge on a
/// concave outline, so the wall is painted over the face rather than butted against it. Drawn the
/// other way round, every concave device grows a hairline of face colour outside its own bevel.
function vst_raise(_pts, _b, _steps, _face) {
    var _out = [vst_ring_fill(_pts, is_undefined(_face) ? "m2" : _face, undefined, undefined)];
    return vst_append(_out, vst_bevel(_pts, _b, _steps, false));
}

/// A SUNKEN shape: a recessed floor, walled by a dome lit from the opposite side.
function vst_sink(_pts, _b, _steps, _face) {
    var _out = [vst_ring_fill(_pts, is_undefined(_face) ? "m1" : _face, undefined, undefined)];
    return vst_append(_out, vst_bevel(_pts, _b, _steps, true));
}

/// ============================================================================================
/// STROKES - a line that is a groove, and a line that is a wire
/// ============================================================================================

/// An INCISED line: a groove cut into the metal.
///
/// Physically there are two walls. The one on the far side of the groove from the lamp faces the
/// lamp and is lit; the one on the near side is turned away and is dark. Offsetting one copy of
/// the stroke toward the lamp and darkening it, and one away and lightening it, is the whole trick
/// - and the order matters, because getting it backwards produces a line that reads as RAISED,
/// which is a real and useful effect and the wrong one here.
///
/// ⚠️ THE OFFSET IS A FRACTION OF THE STROKE WIDTH AND HAS A FLOOR IN THE RENDERER. vst_render
/// floors every stroke at 1 px, so at inventory size the three strokes of a groove collapse onto
/// each other and the groove becomes a plain line. That is correct behaviour and not a defect: a
/// groove 0.4 px wide is not visible on any monitor, and the alternative - scaling the offset up so
/// it survives - would draw a groove three pixels wide on a medal twenty pixels across.
function vst_incise(_pts, _closed, _w) {
    var _o = _w * 0.55;
    return [
        vst_poly(vst_shift(_pts, VST_LX * _o, VST_LY * _o), _closed, _w, "m0"),
        vst_poly(vst_shift(_pts, -VST_LX * _o, -VST_LY * _o), _closed, _w, "m3"),
        vst_poly(_pts, _closed, _w * 0.8, "m1")
    ];
}

/// A RAISED line: a wire laid on the field. The same three strokes with the two walls swapped.
function vst_ridge(_pts, _closed, _w) {
    var _o = _w * 0.55;
    return [
        vst_poly(vst_shift(_pts, -VST_LX * _o, -VST_LY * _o), _closed, _w, "m0"),
        vst_poly(vst_shift(_pts, VST_LX * _o, VST_LY * _o), _closed, _w, "m4"),
        vst_poly(_pts, _closed, _w * 0.8, "m3")
    ];
}

/// Translate a polyline. Separate from vst_move_pts only so that reading a call site tells you
/// whether the thing being moved is an outline or a stroke path.
function vst_shift(_pts, _dx, _dy) {
    return vst_move_pts(_pts, _dx, _dy);
}

/// ============================================================================================
/// SMALL RAISED FURNITURE
/// ============================================================================================

/// A raised dome - a rivet, a rim bead, a stud on a shield.
///
/// Sampled at 12 points at the size these are used, which is 3 to 10 px on screen; a smoother
/// circle is invisible and this product draws a lot of them (a beaded rim is 48 of these, and a
/// trophy case can hold thirty medals).
function vst_boss(_cx, _cy, _r, _segs) {
    var _n = is_undefined(_segs) ? 12 : _segs;
    var _pts = vst_ellipse_pts(_cx, _cy, _r, _r, _n);
    return vst_raise(_pts, _r * 0.62, 2, "m3");
}

/// A sunken pit - a punch mark, a countersink.
function vst_pit(_cx, _cy, _r, _segs) {
    var _n = is_undefined(_segs) ? 12 : _segs;
    var _pts = vst_ellipse_pts(_cx, _cy, _r, _r, _n);
    return vst_sink(_pts, _r * 0.62, 2, "m1");
}

/// ============================================================================================
/// UI FURNITURE - the same relief engine, pointed at a rectangle
///
/// The trophy case and the reveal toast are made of the same metal and wood as the medals, and
/// they are bevelled by the same function against the same lamp. That is the whole reason the
/// product's interface does not look like a GameMaker default: there is no windowskin here and no
/// nine-slice, only a rounded outline handed to vst_bevel.
/// ============================================================================================

/// A rounded rectangle as a closed outline. _seg is the points per corner.
///
/// ⛔ THE CORNERS ARE WALKED TOP-RIGHT, BOTTOM-RIGHT, BOTTOM-LEFT, TOP-LEFT, AND THE FIRST VERSION
/// WALKED THEM TR, TL, BL, BR. MEASURED 2026-08-25 by opening the trophy case sheet and looking at
/// it: every panel, well and progress bar in the product had little hooks at its corners, a bright
/// bar across it, and no proper fill.
///
/// The order is not cosmetic. Each corner arc ENDS pointing at where the next one must BEGIN - the
/// top-right arc finishes on the right edge, so the next corner has to be the bottom-right. Walked
/// TR then TL, the outline jumps back across the top of the rectangle, the polygon self-intersects
/// into a bowtie, and two things go wrong at once: the fan fill covers the wrong region, and
/// vst_inset - which offsets along vertex normals - throws points a long way outside the shape,
/// which is why the ink check reported the sheet clipped at x=0 when nothing was drawn there.
///
/// ⚠️ AND NOTHING MECHANICAL CAUGHT IT. The gate compiled, 711 assertions passed, the containment
/// checks passed because they test the medal corpus rather than the UI furniture, and the ink check
/// reported "clipped" - true, but pointing at a symptom two steps downstream. It was found by
/// opening the PNG, which remains the only way.
function vst_round_rect_pts(_x0, _y0, _x1, _y1, _r, _seg) {
    var _s = max(1, is_undefined(_seg) ? 4 : _seg);
    var _rr = min(_r, min(abs(_x1 - _x0), abs(_y1 - _y0)) * 0.5);
    var _out = [];
    var _cx = [_x1 - _rr, _x1 - _rr, _x0 + _rr, _x0 + _rr];
    var _cy = [_y0 + _rr, _y1 - _rr, _y1 - _rr, _y0 + _rr];
    var _a0 = [-VST_TAU * 0.25, 0, VST_TAU * 0.25, VST_TAU * 0.5];
    for (var _c = 0; _c < 4; _c++) {
        for (var _i = 0; _i <= _s; _i++) {
            var _a = _a0[_c] + (_i / _s) * (VST_TAU * 0.25);
            array_push(_out, [_cx[_c] + cos(_a) * _rr, _cy[_c] + sin(_a) * _rr]);
        }
    }
    return _out;
}

/// A raised panel: a rounded rectangle with a lit dome all round it.
function vst_ui_panel(_x0, _y0, _x1, _y1, _r, _b, _face) {
    return vst_raise(vst_round_rect_pts(_x0, _y0, _x1, _y1, _r, 4), _b, 3,
                     is_undefined(_face) ? "panel" : _face);
}

/// A sunken well - a recess a medal sits in, or a progress track.
function vst_ui_well(_x0, _y0, _x1, _y1, _r, _b, _face) {
    return vst_sink(vst_round_rect_pts(_x0, _y0, _x1, _y1, _r, 4), _b, 2,
                    is_undefined(_face) ? "felt" : _face);
}

/// ============================================================================================
/// PART-LIST UTILITIES
/// ============================================================================================

/// Translate a whole part list. Used by the toast's strike flash and by the drop shadow a medal
/// casts onto the case felt.
function vst_offset_parts(_parts, _dx, _dy) {
    var _n = array_length(_parts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case VST_DOT: _out[_i] = vst_dot(_p.cx + _dx, _p.cy + _dy, _p.r, _p.role); break;
            case VST_ARC: _out[_i] = vst_arc(_p.cx + _dx, _p.cy + _dy, _p.r, _p.a0, _p.a1,
                                             _p.w, _p.role); break;
            case VST_STRIP: {
                _out[_i] = vst_strip(vst_move_pts(_p.a, _dx, _dy),
                                     vst_move_pts(_p.b, _dx, _dy), _p.role);
            } break;
            case VST_FILL: _out[_i] = vst_fill(vst_move_pts(_p.pts, _dx, _dy), _p.role); break;
            default: _out[_i] = vst_poly(vst_move_pts(_p.pts, _dx, _dy), _p.closed,
                                         _p.w, _p.role); break;
        }
    }
    return _out;
}

/// Rewrite every role in a part list through a lookup struct, permanently.
///
/// ⚠️ NOT THE SAME AS THE RENDERER'S role map, and both exist on purpose. The renderer's map is
/// applied at DRAW time and is right for "draw this device in the locked palette just this once".
/// This one produces a new part list and is right for building a thing whose roles are decided at
/// construction - a ribbon, whose two dyes are chosen per award category and then never change.
function vst_map_roles(_parts, _map) {
    var _n = array_length(_parts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        var _r = variable_struct_exists(_map, _p.role) ? variable_struct_get(_map, _p.role) : _p.role;
        switch (_p.kind) {
            case VST_DOT: _out[_i] = vst_dot(_p.cx, _p.cy, _p.r, _r); break;
            case VST_ARC: _out[_i] = vst_arc(_p.cx, _p.cy, _p.r, _p.a0, _p.a1, _p.w, _r); break;
            case VST_STRIP: _out[_i] = vst_strip(_p.a, _p.b, _r); break;
            case VST_FILL: _out[_i] = vst_fill(_p.pts, _r); break;
            default: _out[_i] = vst_poly(_p.pts, _p.closed, _p.w, _r); break;
        }
    }
    return _out;
}

/// Every distinct role a part list asks for, as an array of strings.
///
/// Exists for vst_selftest, which asserts that no part in the whole product ever asks for a role
/// the surface does not carry. The renderer falls back to `line` on a miss - loudly wrong rather
/// than invisible - and that fallback is a diagnostic, not a licence to leave one in.
function vst_roles_used(_parts) {
    var _seen = {};
    var _out = [];
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _r = _parts[_i].role;
        if (!variable_struct_exists(_seen, _r)) {
            variable_struct_set(_seen, _r, true);
            array_push(_out, _r);
        }
    }
    return _out;
}
