{
  "$GMScript": "v1",
  "%Name": "vst_relief",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_relief",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}