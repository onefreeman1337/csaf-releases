{
  "$GMScript": "v1",
  "%Name": "vst_toast",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_toast",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}