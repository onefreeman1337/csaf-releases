/// VESTIGE - vst_toast. The strike-and-reveal.
///
/// A medal does not fade in. It is STRUCK: the die comes down, the metal flashes, a shock ring
/// runs out of the impact, the medal settles with two diminishing bounces, and only then does the
/// panel slide out from behind it carrying the name. The whole thing is under four seconds and it
/// is the single most-watched moment this product produces, because it is the one the player sees
/// every time they earn something.
///
/// ⛔ THE ANIMATION IS A PURE FUNCTION OF TIME AND NOTHING ELSE. vst_toast_frame(t) takes a number
/// of seconds and returns a struct of numbers; it touches no global, calls nothing in the engine,
/// and draws nothing. Wings/GameMaker/CLAUDE.md's standing constraint on this wing is that GML
/// cannot be unit-tested outside the engine, and the honest response is to make as much of the
/// product as possible answerable WITHOUT the engine. Every claim this file makes about its own
/// timing - that the scale is continuous at every stage boundary, that it never overshoots after
/// the settle, that alpha reaches zero exactly when the toast dies - is asserted by vst_selftest
/// against this function, not against a screenshot.
///
/// ⚠️ THE ONE CLAIM THAT CANNOT BE ASSERTED IS WHETHER IT LOOKS GOOD. That was found by rendering
/// it and looking, and the store sheet shows six frames of it for exactly that reason.
///
/// ⚠️ DELTA TIME IN SECONDS, NOT FRAMES. A buyer running at 30 or 144 must get the same animation,
/// and delta_time in GML is MICROseconds - the units trap that turns a 0.16 second strike into a
/// 160,000 second one and looks, on screen, like nothing happening at all.
/// ============================================================================================

#macro VST_T_STRIKE 0.16
#macro VST_T_SETTLE 0.78
#macro VST_T_HOLD   3.30
#macro VST_T_EXIT   3.86

/// How high above its final size the die starts.
#macro VST_T_DROP 1.85

/// The animation, as pure numbers.
///
/// Returns:
///   alive    false once the toast is finished
///   stage    1 strike, 2 settle, 3 hold, 4 exit
///   scale    multiplier on the medal's size
///   flash    0..1 strength of the impact flash
///   ring     0..1 how far the shock ring has expanded (0 when there is none)
///   ringA    0..1 the ring's alpha
///   slide    0..1 how far the panel has come out from behind the medal
///   alpha    0..1 overall
function vst_toast_frame(_t) {
    var _f = { alive: true, stage: 1, scale: 1, flash: 0, ring: 0, ringA: 0, slide: 0, alpha: 1 };
    if (_t < 0) _t = 0;

    if (_t < VST_T_STRIKE) {
        // The die falling. power(u, 3) so almost all of the travel happens in the last third,
        // which is what makes it read as a strike rather than as a zoom.
        var _u = _t / VST_T_STRIKE;
        _f.stage = 1;
        _f.scale = lerp(VST_T_DROP, 1.0, power(_u, 3));
        _f.flash = power(_u, 6);
        _f.slide = 0;
    } else if (_t < VST_T_SETTLE) {
        // Two damped bounces off the strike, and the flash decaying out of it.
        //
        // ⛔ sin, NOT cos, AND IT WAS cos ON THE FIRST RUN. MEASURED 2026-08-25: cos(0) is 1, so
        // the settle began at 1.085 while the strike had just ended at 1.000 - an eight per cent
        // jump in scale at the stage boundary, which on screen is a visible pop at the exact
        // moment the player is looking hardest. The continuity assertion caught it. sin(0) is 0,
        // so the bounce starts at the size the strike left the medal at.
        //
        // ⚠️ AND IT IS NEGATIVE, so the metal COMPRESSES first and then overshoots. A strike that
        // grows first is a zoom; a strike that squashes first is an impact.
        var _u = (_t - VST_T_STRIKE) / (VST_T_SETTLE - VST_T_STRIKE);
        _f.stage = 2;
        _f.scale = 1 - 0.085 * sin(_u * VST_TAU * 2.0) * (1 - _u) * (1 - _u);
        _f.flash = (1 - _u) * (1 - _u);
        _f.ring = _u;
        // Cubed rather than squared: the ring is a shock front and it should be gone well before
        // the panel finishes sliding out. At a square it was still a visible hoop a third of a
        // second after the impact, a medal and a half wide, with nothing left to explain it.
        _f.ringA = power(1 - _u, 3);
        // The panel comes out during the settle, not before it: the medal has to have landed
        // before anything can be written about it.
        _f.slide = clamp((_u - 0.18) / 0.62, 0, 1);
        _f.slide = 1 - power(1 - _f.slide, 3);
    } else if (_t < VST_T_HOLD) {
        _f.stage = 3;
        _f.scale = 1;
        _f.slide = 1;
    } else if (_t < VST_T_EXIT) {
        var _u = (_t - VST_T_HOLD) / (VST_T_EXIT - VST_T_HOLD);
        _f.stage = 4;
        _f.scale = 1;
        _f.slide = 1 - power(_u, 2);
        _f.alpha = 1 - _u;
    } else {
        _f.alive = false;
        _f.stage = 4;
        _f.scale = 1;
        _f.slide = 0;
        _f.alpha = 0;
    }
    return _f;
}

/// ============================================================================================
/// THE QUEUE
/// ============================================================================================

function vst_toast_init() {
    global.vst_toast = { id: "", t: 0, active: false };
}

function vst_toast_ready() {
    if (!variable_global_exists("vst_toast")) vst_toast_init();
}

/// Show a specific award now, interrupting whatever was showing.
function vst_toast_show(_id) {
    vst_toast_ready();
    global.vst_toast.id = _id;
    global.vst_toast.t = 0;
    global.vst_toast.active = true;
}

function vst_toast_active() {
    vst_toast_ready();
    return global.vst_toast.active;
}

/// Advance the toast by _dt SECONDS, pulling the next unlock off the award queue when idle.
///
/// ⚠️ ONE AWARD AT A TIME, AND THE REST WAIT. Unlocking three things in one frame - which happens
/// constantly, because a chain settles all at once - must not draw three overlapping toasts. The
/// queue in vst_award is what makes that a non-event here: this pulls one, plays it, and pulls the
/// next when it finishes.
function vst_toast_update(_dt) {
    vst_toast_ready();
    if (global.vst_toast.active) {
        global.vst_toast.t += _dt;
        if (!vst_toast_frame(global.vst_toast.t).alive) {
            global.vst_toast.active = false;
            global.vst_toast.id = "";
        }
        return;
    }
    if (vst_ready() && vst_pending() > 0) {
        var _next = vst_next_unlock();
        if (!is_undefined(_next)) vst_toast_show(_next);
    }
}

/// ============================================================================================
/// DRAWING
/// ============================================================================================

/// The toast's laid-out geometry, as pure numbers, so a caller can position other things around it
/// and so the self-test can assert that the panel never runs off its own right edge.
///
/// _x,_y is the TOP-RIGHT corner of the toast's reserved space.
function vst_toast_layout(_x, _y, _w) {
    var _h = _w * 0.320;
    var _mw = _h * 0.92;
    return {
        x: _x - _w, y: _y, w: _w, h: _h,
        medalX: _x - _w + _mw * 0.56,
        medalY: _y + _h * 0.5,
        medalSize: _mw,
        textX: _x - _w + _mw * 1.10,
        textW: _w - _mw * 1.10 - _h * 0.20
    };
}

/// Draw the current toast. Does nothing when there is none.
///
/// _x,_y is the TOP-RIGHT corner, so the natural call is
/// vst_toast_draw(display_get_gui_width() - 24, 24, 520, "walnut").
function vst_toast_draw(_x, _y, _w, _case_id) {
    vst_toast_ready();
    if (!global.vst_toast.active) return;
    var _id = global.vst_toast.id;
    var _d = vst_ready() ? vst_def_of(_id) : undefined;
    if (is_undefined(_d)) return;

    var _f = vst_toast_frame(global.vst_toast.t);
    var _L = vst_toast_layout(_x, _y, _w);
    var _m = vst_award_medal(_id);

    // ⛔ THE TOAST ALWAYS STRIKES THE MEDAL AS EARNED, WHATEVER THE REGISTRY SAYS. MEASURED BY
    // LOOKING at the strike sheet: every frame showed a black cavity being ceremonially presented
    // to the player, because vst_award_medal reads the CURRENT state and the sheet was rendering an
    // award the sample save has not unlocked.
    //
    // ⚠️ AND IT IS A PRODUCT BUG, NOT A SHEET BUG. A toast fires BECAUSE something unlocked, so the
    // locked form can never be the right thing to show - and a developer calling vst_toast_show()
    // by hand to preview an award would have hit exactly the same black rectangle. Fixing it in the
    // bake would have hidden it.
    _m.locked = false;
    _m.secret = false;
    var _sur = vst_medal_surface(_m, _case_id);

    // The panel slides out from BEHIND the medal, so its left edge is pinned and its right edge
    // travels. A panel that slides in as a rigid block reads as a notification; one that grows out
    // from under the medal reads as the medal presenting itself.
    var _px0 = _L.medalX;
    var _px1 = lerp(_L.medalX, _x, _f.slide);
    var _oldA = draw_get_alpha();
    draw_set_alpha(_f.alpha);

    if (_f.slide > 0.02) {
        vst_render_parts_raw(vst_ui_panel(_px0, _L.y, _px1, _L.y + _L.h, _L.h * 0.16,
                                          _L.h * 0.055, "panel"), _sur);
        if (_f.slide > 0.55) {
            var _tw = max(8, (_px1 - _L.textX));
            vst_text_line(string_upper(_d.name), _L.textX, _L.y + _L.h * 0.20,
                          _tw, _L.h * 0.22, _sur.line, true);
            vst_text_line(vst_category_label(_d.category) + "   " + string(_d.points) + " PTS",
                          _L.textX, _L.y + _L.h * 0.47, _tw, _L.h * 0.135, _sur.accent, false);
            if (_d.desc != "") {
                vst_text_line(_d.desc, _L.textX, _L.y + _L.h * 0.66, _tw, _L.h * 0.135,
                              _sur.dim, false);
            }
        }
    }

    if (_f.ringA > 0) {
        vst_render_ring(_L.medalX, _L.medalY, _L.medalSize * (0.42 + _f.ring * 1.30),
                        max(1, _L.medalSize * 0.030 * (1 - _f.ring)), _sur.m4,
                        _f.ringA * _f.alpha);
    }

    // ⛔ THE FLASH GOES UNDER THE MEDAL, AND IT USED TO GO OVER IT. MEASURED BY LOOKING at the
    // strike sheet: six nested discs at a third alpha each, painted on top, turned the medal into a
    // featureless grey blob for the whole first half second - which is to say, for the entire part
    // of the animation the flash exists to draw attention to. An impact does not obscure the thing
    // it happens to; it HALOES it. One line moved, and the difference is the whole shot.
    if (_f.flash > 0) {
        vst_render_flash(_L.medalX, _L.medalY, _L.medalSize * (0.62 + _f.flash * 0.42),
                         _sur.m4, _f.flash * _f.alpha);
    }

    // ⚠️ DETAIL FROM THE PIXEL SIZE, exactly as the trophy case does it, and the toast used to pass
    // a hard 2. At a 520px toast the medal is 153px across and its legend is seven pixels tall - so
    // hero detail was spending a thousand primitives on lettering nobody can read, on the one
    // animation in the product that has to hit sixty frames a second.
    var _md = (_L.medalSize >= 190) ? 2 : ((_L.medalSize >= 78) ? 1 : 0);
    vst_medal_draw(_m, _sur, _L.medalX, _L.medalY, _L.medalSize * _f.scale, _md);
    draw_set_alpha(_oldA);
}
