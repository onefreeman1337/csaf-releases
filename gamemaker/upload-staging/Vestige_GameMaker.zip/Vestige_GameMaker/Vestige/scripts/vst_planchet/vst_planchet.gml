/// VESTIGE - vst_planchet. Twelve blank forms and six rim treatments.
///
/// A planchet is the blank a medal is struck from - the shape of the metal before any device is
/// sunk into it. It is the silhouette a player sees first and from furthest away, so this file
/// carries more of the product's readability than the device corpus does.
///
/// ⛔ EVERY FORM IS DEFINED AS A POLAR RADIUS R(angle), NOT AS A LIST OF POINTS, AND THAT DECISION
/// PAYS FOR ITSELF FOUR TIMES:
///
///   1. A polar form is STAR-SHAPED ABOUT THE ORIGIN by construction, which is exactly the
///      precondition the primitive layer's fan fill requires. A hand-listed outline can violate it
///      silently and draws a shape with a wedge missing.
///   2. THE RIM TREATMENTS COME FREE. A bead has to sit just inside the edge whatever the edge is
///      doing; with R(angle) available that is one multiply, and the beaded rim works on a cog and
///      a shield without either of them knowing about it.
///   3. LEVEL OF DETAIL IS ONE ARGUMENT. The same form samples at 96 points for a hero image and
///      at 28 for an inventory icon.
///   4. THE DISTINCTNESS ASSERTION BECOMES MEANINGFUL. vst_selftest compares two forms by sampling
///      both radius functions at the same 96 angles, which is a genuine silhouette comparison
///      rather than a comparison of however many points each happened to be authored with.
///
/// ⚠️ THE COST IS THAT NOT EVERY SHAPE IS NATURALLY POLAR. The shield is the one that fought it -
/// see its case below, which is the only form built from two blended pieces.
/// ============================================================================================

/// The nominal outer radius. Forms reach it at their widest and none exceeds VST_ST_BOX.
#macro VST_R 0.470

/// Where the recessed field starts, as a fraction of the outer radius. The device lives inside it.
///
/// ⚠️ 0.78, AND IT WAS 0.735. MEASURED BY LOOKING at the first trophy case sheet: at 0.735 the
/// device occupied about half the medal's diameter and the blank read as a big empty dish with a
/// small mark in the middle. A struck medal puts its charge across most of its field - that is what
/// a field IS - and the extra four hundredths of radius here, with the device allowance below
/// raised at the same time, took the charge from 54% of the diameter to 73%.
#macro VST_FIELD_K 0.780

/// Where rim furniture is centred, as a fraction of the outer radius: between the field wall and
/// the start of the outer dome, which is the only place on a real medal there is room for it.
#macro VST_RIM_K 0.848

/// How far the outer dome reaches inward, in unit-box units.
#macro VST_DOME 0.055

function vst_planchet_ids() {
    return ["round", "scallop", "cross", "star", "shield", "hex",
            "octagon", "quatrefoil", "sunburst", "rosette", "cameo", "cog"];
}

/// Circumradius-to-radius for a regular _n-gon at angle _a, phase _ph.
function vst_ngon_r(_a, _n, _R, _ph) {
    var _seg = VST_TAU / _n;
    var _t = ((_a - _ph) % _seg + _seg) % _seg;
    return _R * cos(_seg * 0.5) / max(0.0001, cos(_t - _seg * 0.5));
}

/// A triangle wave in 0..1 with _n periods around the circle, peaking on the +x axis.
function vst_tri_wave(_a, _n) {
    var _seg = VST_TAU / _n;
    var _t = ((_a % _seg) + _seg) % _seg;
    return 1 - abs(2 * (_t / _seg) - 1);
}

/// THE FORM TABLE: outer radius at angle _a, y-DOWN, angle 0 = +x, pi/2 = straight down.
///
/// ⚠️ THE TWO SHALLOW-WAVE FORMS ARE AUTHORED APART ON PURPOSE. `scallop` is sixteen shallow lobes
/// and `rosette` is ten deep ones. Authored at similar depth they measured as the same silhouette
/// and looked like it: the distinctness floor in vst_selftest is what forced the separation, and
/// it is reported rather than merely passed so the next edit can see how much room is left.
function vst_planchet_r(_id, _a) {
    var _c = cos(_a), _s = sin(_a);
    switch (_id) {
        case "round":  return VST_R;

        // ⚠️ FOURTEEN LOBES AT 0.042, AND IT WAS SIXTEEN AT 0.030. MEASURED 2026-08-25: at the
        // shallower setting this form and `octagon` differed by 0.017 averaged over 96 radii,
        // under the distinctness floor, and the suite refused the set. It was right - a shallow
        // sixteen-lobe scallop IS an octagon with soft corners at anything below hero size. Fewer,
        // deeper lobes is the fix, and it is the fix the header already predicted.
        case "scallop": return 0.428 + 0.042 * cos(14 * _a);

        // ⛔ A UNION OF TWO BARS, NOT A WAVE. The first authoring raised a triangle wave to a power
        // to fake a cross, and it produced four POINTED arms with concave sides - a four-pointed
        // star, which the corpus already has an eight-pointed version of. A cross has FLAT arm
        // ends, and no power of a wave has a flat anything.
        //
        // Taking the max of two perpendicular bars in polar gives a true Greek cross for four lines
        // of arithmetic: each bar is min(halfLength/|cos|, halfWidth/|sin|), which is the exact
        // distance to a rectangle's boundary, and the union of the two is the cross.
        case "cross": {
            var _ac = max(0.0001, abs(_c)), _as = max(0.0001, abs(_s));
            return max(min(0.470 / _ac, 0.155 / _as), min(0.470 / _as, 0.155 / _ac));
        }

        case "star": {
            var _t = vst_tri_wave(_a + VST_TAU / 16, 8);
            return 0.200 + 0.270 * power(_t, 1.05);
        }

        // ⛔ THE ONE FORM THAT IS NOT A SINGLE EXPRESSION, and the header says so rather than
        // hiding it. A heater shield is a squared-off top blended into a taper that closes to a
        // point at the bottom, and those are two different rules. The upper half is a superellipse
        // (exponent 3.2, so the shoulders are square without being a rectangle); the lower half is
        // a half-width that falls away as the angle swings down, intersected with the distance to
        // the point. `_hw` is shared by both so the two halves meet at the same width on the
        // horizon and there is no step at three o'clock.
        // ⛔ TWO SUPERELLIPSES, AND THE LOWER ONE USED TO BE AN INTERSECTION OF A TAPER AND A CAP.
        // MEASURED BY LOOKING at the blank-forms sheet: that construction grew a THIN SPIKE out of
        // the bottom of the shield. The taper's half-width collapses to almost nothing near
        // straight-down, so the distance-to-a-line term ran away, the distance-to-the-tip term took
        // over inside a window about 0.06 radians wide, and the radius jumped from 0.34 to 0.48 and
        // back inside three sample points.
        //
        // Both halves are now superellipses about the same half-width, so they meet at the horizon
        // with no step: exponent 3.2 above, which squares off the shoulders, and 0.85 below, which
        // is UNDER one and therefore draws concave sides closing to a point. One expression each,
        // no clamps, and nothing that can run away.
        case "shield": {
            var _hw = 0.405;
            if (_s <= 0) {
                var _u = power(abs(_c) / _hw, 3.2) + power(abs(_s) / 0.435, 3.2);
                return power(max(0.0001, _u), -1 / 3.2);
            }
            // ⚠️ EXPONENT 1.0 EXACTLY, which is the degenerate case of a superellipse and is a
            // STRAIGHT LINE from the shoulder to the point - a heater shield. 0.85 was tried first
            // and drew concave sides closing to a needle, which reads as a drip hanging off the
            // bottom of the blank rather than as a shield.
            var _v = abs(_c) / _hw + _s / 0.482;
            return 1 / max(0.0001, _v);
        }

        case "hex":     return vst_ngon_r(_a, 6, VST_R, VST_TAU / 12);
        // ⛔ 0.90 OF THE NOMINAL RADIUS, AND THE MEASUREMENT MADE A DESIGN DECISION HERE RATHER THAN
        // A NUMERICAL ONE. At full size the octagon sat 0.020 from `round` against a floor of 0.018,
        // which passes by eleven per cent and is not a margin. Shrinking it to 0.955 fixed that pair
        // and immediately put it 0.017 from `hex` - because a hexagon and an octagon of the same
        // size ARE the same silhouette at any size a player actually sees, and no amount of moving
        // it a few thousandths was going to change that.
        //
        // The floor was telling the truth: two regular polygons that differ only in side count need
        // to differ in SIZE, which is what a real medal set does. At 0.90 it is the small blank of
        // the set, clears every other form comfortably, and is instantly tellable from the hexagon.
        case "octagon": return vst_ngon_r(_a, 8, VST_R * 0.900, VST_TAU / 16);

        // Four lobes meeting in cusps. The exponent under 1 is what makes the lobes bulge instead
        // of reading as a rounded square.
        case "quatrefoil": return 0.240 + 0.230 * power(abs(cos(2 * _a)), 0.62);

        // ⚠️ SIXTEEN RAYS, AND IT WAS TWENTY-FOUR. At 24 the rays are 15 degrees apart and about
        // 0.06 wide at the base, which is barely wider than the dome that has to be bevelled into
        // them - see vst_planchet_dome - and at hero size the blank read as a burst of shards
        // rather than as a radiant medal. Sixteen rays are individually legible and hold their own
        // bevel.
        case "sunburst": return 0.300 + 0.170 * vst_tri_wave(_a, 16);

        case "rosette":  return VST_R * 0.800 + 0.088 * cos(10 * _a);

        // A vertical oval. Narrow enough that it can never be mistaken for `round` at any size,
        // which is the whole reason it is in the set.
        case "cameo": {
            var _u = power(_c / 0.340, 2) + power(_s / 0.482, 2);
            return power(max(0.0001, _u), -0.5);
        }

        // Ten teeth with FLAT tops and flat valleys, not a wave: a cog whose teeth are rounded is
        // a rosette. The ramp is 18% of each flank so the tooth has a visible side rather than a
        // vertical cliff that the sampler would alias into a staircase.
        default: {
            var _t = vst_tri_wave(_a, 10);
            var _k = clamp((_t - 0.34) / 0.18, 0, 1);
            return 0.372 + 0.098 * _k;
        }
    }
}

/// Sample a form into a closed outline. _n points, first point NOT repeated.
function vst_planchet_outline(_id, _n, _k) {
    var _kk = is_undefined(_k) ? 1.0 : _k;
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = (_i / _n) * VST_TAU;
        var _r = vst_planchet_r(_id, _a) * _kk;
        _out[_i] = [cos(_a) * _r, sin(_a) * _r];
    }
    return _out;
}

/// How many points a form is sampled at, at each level of detail.
///
/// ⛔ DETAIL IS NOT A PERFORMANCE KNOB, IT IS A DESIGN REQUIREMENT. Wings/GameMaker/CLAUDE.md
/// records a sibling product whose label-clipping defect was invisible on a 1600px store sheet and
/// obvious in a 900px GIF: a product that only composes at hero size fails in the buyer's game,
/// where a medal is 32 pixels in a HUD. So the three levels are the three sizes the product is
/// actually used at, they are all rendered on a store sheet side by side, and the low level is
/// tuned to look RIGHT rather than to look cheap.
function vst_detail_segs(_detail) {
    if (_detail <= 0) return 28;
    if (_detail == 1) return 52;
    return 96;
}

/// ============================================================================================
/// RIM TREATMENTS
/// ============================================================================================

function vst_rim_ids() {
    return ["plain", "beaded", "reeded", "cable", "laurel", "dentil"];
}

/// How many pieces of rim furniture a treatment gets at each detail level.
///
/// ⚠️ THE COUNTS FALL FASTER THAN THE SAMPLE COUNT DOES, and that is not laziness. Forty beads
/// around a 32px medal are 40 marks in a 100px circumference: they merge into a grey fringe, which
/// is worse than no rim at all because it eats the alloy's own value. Sixteen beads at that size
/// still read as beads.
function vst_rim_count(_id, _detail) {
    var _lo = (_detail <= 0);
    switch (_id) {
        case "beaded": return _lo ? 16 : (_detail == 1 ? 28 : 40);
        case "reeded": return _lo ? 24 : (_detail == 1 ? 40 : 60);
        case "cable":  return _lo ? 12 : (_detail == 1 ? 20 : 30);
        case "laurel": return _lo ?  8 : (_detail == 1 ? 14 : 22);
        case "dentil": return _lo ? 14 : (_detail == 1 ? 22 : 32);
        default:       return 0;
    }
}

/// The rim furniture for a form, as parts in the same unit box as the planchet.
function vst_rim_parts(_rim, _form, _detail) {
    var _out = [];
    if (!vst_planchet_takes_rim(_form)) return _out;
    var _n = vst_rim_count(_rim, _detail);
    if (_n <= 0) return _out;
    var _segs = (_detail <= 0) ? 8 : 12;

    for (var _i = 0; _i < _n; _i++) {
        var _a = (_i / _n) * VST_TAU;
        var _R = vst_planchet_r(_form, _a);
        var _rr = _R * VST_RIM_K;
        var _px = cos(_a) * _rr, _py = sin(_a) * _rr;

        switch (_rim) {
            case "beaded": {
                vst_append(_out, vst_boss(_px, _py, _R * 0.062, _segs));
            } break;

            // A milled edge: short raised flutes running radially.
            case "reeded": {
                var _r0 = _R * 0.775, _r1 = _R * 0.945;
                var _w = _R * 0.030;
                var _cx = cos(_a), _cy = sin(_a);
                var _nx = -_cy * _w, _ny = _cx * _w;
                vst_append(_out, vst_raise([
                    [_cx * _r0 - _nx, _cy * _r0 - _ny], [_cx * _r1 - _nx, _cy * _r1 - _ny],
                    [_cx * _r1 + _nx, _cy * _r1 + _ny], [_cx * _r0 + _nx, _cy * _r0 + _ny]
                ], _R * 0.028, 2, "m3"));
            } break;

            // Cable, sometimes called roping: lozenges laid at a slant so the rim reads as a
            // twisted cord. The slant is a constant 34 degrees off radial - alternating it makes a
            // herringbone, which is a different (and much busier) treatment.
            case "cable": {
                var _sl = _a + 0.5934;
                var _lx = cos(_sl), _ly = sin(_sl);
                var _tx = -_ly, _ty = _lx;
                var _L = _R * 0.115, _W = _R * 0.052;
                vst_append(_out, vst_raise([
                    [_px + _lx * _L, _py + _ly * _L],
                    [_px + _tx * _W, _py + _ty * _W],
                    [_px - _lx * _L, _py - _ly * _L],
                    [_px - _tx * _W, _py - _ty * _W]
                ], _R * 0.030, 2, "m3"));
            } break;

            // A laurel wreath: paired leaves, each a pointed almond tilted away from the stem.
            case "laurel": {
                for (var _side = -1; _side <= 1; _side += 2) {
                    var _tilt = _a + _side * 0.62;
                    var _lx2 = cos(_tilt), _ly2 = sin(_tilt);
                    var _tx2 = -_ly2, _ty2 = _lx2;
                    var _L2 = _R * 0.105, _W2 = _R * 0.040;
                    var _ox = _px + (-sin(_a)) * _side * _R * 0.030;
                    var _oy = _py + ( cos(_a)) * _side * _R * 0.030;
                    vst_append(_out, vst_raise([
                        [_ox + _lx2 * _L2, _oy + _ly2 * _L2],
                        [_ox + _tx2 * _W2 * 0.75 + _lx2 * _L2 * 0.25,
                         _oy + _ty2 * _W2 * 0.75 + _ly2 * _L2 * 0.25],
                        [_ox + _tx2 * _W2, _oy + _ty2 * _W2],
                        [_ox - _lx2 * _L2, _oy - _ly2 * _L2],
                        [_ox - _tx2 * _W2, _oy - _ty2 * _W2],
                        [_ox - _tx2 * _W2 * 0.75 + _lx2 * _L2 * 0.25,
                         _oy - _ty2 * _W2 * 0.75 + _ly2 * _L2 * 0.25]
                    ], _R * 0.026, 2, "m3"));
                }
            } break;

            // Dentils: square blocks, the architectural moulding. Square to the RADIUS, not to the
            // world axes - blocks that all point the same way read as a pile of bricks.
            default: {
                var _cx3 = cos(_a), _cy3 = sin(_a);
                var _tx3 = -_cy3, _ty3 = _cx3;
                var _H = _R * 0.062, _W3 = _R * 0.042;
                vst_append(_out, vst_raise([
                    [_px + _cx3 * _H + _tx3 * _W3, _py + _cy3 * _H + _ty3 * _W3],
                    [_px + _cx3 * _H - _tx3 * _W3, _py + _cy3 * _H - _ty3 * _W3],
                    [_px - _cx3 * _H - _tx3 * _W3, _py - _cy3 * _H - _ty3 * _W3],
                    [_px - _cx3 * _H + _tx3 * _W3, _py - _cy3 * _H + _ty3 * _W3]
                ], _R * 0.028, 2, "m3"));
            } break;
        }
    }
    return _out;
}

/// ============================================================================================
/// THE BLANK
/// ============================================================================================

/// A struck blank: the metal, its domed edge, its rim furniture and its recessed field.
///
/// The field is SUNKEN rather than merely outlined, because that is what puts the device on a
/// stage: a raised device inside a recessed field has two walls between it and the rim, and the
/// eye reads the depth instantly. A device sitting on a flat blank reads as a printed sticker
/// however well the device itself is bevelled - which is what the first build of this looked like.
/// How far the outer dome reaches inward on a given form.
///
/// ⛔ A BEVEL WIDER THAN THE FEATURE IT IS BEVELLING TURNS THAT FEATURE INSIDE OUT. MEASURED BY
/// LOOKING at the first hero plate: the standard 0.055 dome, applied to a radiant blank whose rays
/// are about 0.06 wide at the base, insets each ray's two walls past each other. The inner ring
/// crosses itself, the quads flip, and every ray renders as a pair of shards with a gap down the
/// middle. Nothing mechanical catches it - the outline is fine, the winding is fine, the ink is
/// fine, and the picture is wrong.
///
/// The general rule is the interesting part, and it applies to any bevel in any product: the dome
/// is a property of the EDGE, and an edge with fine features can only carry a fine dome. The list
/// below is the same one as vst_planchet_takes_rim and for the same underlying reason - those five
/// blanks already spend their edge on a repeating feature.
/// ⚠️ SEVEN OF THE TWELVE FORMS NEED A FINER DOME, not the five that decline rim furniture, and the
/// first version of this used the shorter list. `scallop` has fourteen lobes only 0.042 deep and
/// `rosette` ten at 0.088; the standard dome is as wide as the feature in both cases and both
/// rendered as fringes of white shards. The rule is the same one either way: a dome is a property
/// of the EDGE, and an edge that already spends itself on a repeating feature can only carry a
/// fine one.
function vst_planchet_dome(_form) {
    switch (_form) {
        case "cross": case "star": case "sunburst": return VST_DOME * 0.45;
        case "scallop":                             return VST_DOME * 0.46;
        case "rosette": case "cog":                 return VST_DOME * 0.56;
        case "quatrefoil":                          return VST_DOME * 0.66;
        default:                                    return VST_DOME;
    }
}

function vst_planchet_parts(_form, _rim, _detail) {
    var _segs = vst_detail_segs(_detail);
    var _steps = (_detail <= 0) ? 2 : 3;
    var _dome = vst_planchet_dome(_form);
    var _outline = vst_planchet_outline(_form, _segs, 1.0);

    var _out = vst_raise(_outline, _dome, _steps, "m2");
    vst_append(_out, vst_rim_parts(_rim, _form, _detail));

    // The field: one circle, see vst_planchet_field_ring_r.
    var _fr = vst_planchet_field_ring_r(_form);
    var _field = vst_ellipse_pts(0, 0, _fr, _fr, max(20, _segs div 2));
    vst_append(_out, vst_sink(_field, VST_DOME * 0.52, max(1, _steps - 1), "m2"));
    return _out;
}

/// The radius the device may occupy on this form.
///
/// ⛔ THE MEAN RADIUS, NOT THE NOMINAL ONE AND NOT THE MINIMUM. All three were tried:
///
///   nominal (VST_R)  - correct on `round` and puts a device straight through the waist of a cross
///                      patty, whose metal is 0.15 wide between the arms and 0.47 along them.
///   minimum          - safe everywhere and absurd on the pierced forms: it sizes the cross's
///                      device to the notch, giving a mark a fifth the width of the medal, which
///                      is unreadable at any size below hero and looks like a mistake at hero.
///   MEAN             - what a real cross-shaped or star-shaped medal actually does. The central
///                      device spans the waist and runs a little way onto the arms, which is why
///                      those forms have arms at all.
///
/// The 0.86 is the air between the device and the field wall. Without it a device touches the wall
/// and the two bevels merge into one thick smear, which is the exact failure the sunken field
/// exists to prevent.
/// The average radius of a form over a full turn.
///
/// Everything the medal puts INSIDE the blank is sized from this rather than from VST_R, and all of
/// it broke when it was sized from the nominal radius: on a radiant or pierced blank the nominal
/// radius is where the RAY TIPS are, and almost none of the metal is out there.
function vst_planchet_mean_r(_form) {
    var _sum = 0;
    for (var _i = 0; _i < 72; _i++) _sum += vst_planchet_r(_form, (_i / 72) * VST_TAU);
    return _sum / 72;
}

/// The narrowest the form ever gets. Nothing drawn on the face may exceed it.
function vst_planchet_min_r(_form) {
    var _worst = 999;
    for (var _i = 0; _i < 144; _i++) {
        var _r = vst_planchet_r(_form, (_i / 144) * VST_TAU);
        if (_r < _worst) _worst = _r;
    }
    return _worst;
}

/// ⛔ THE RECESSED FIELD IS A CIRCLE ON EVERY BLANK, AND IT USED TO BE A SCALED COPY OF THE OUTLINE.
///
/// MEASURED BY LOOKING at the blank-forms sheet. Scaled, the field on a scalloped blank is a
/// scalloped ring, on a rosette a ten-lobed ring and on a cog a toothed ring - a second spiky
/// outline concentric with the first, bevelled, catching light from a different set of angles.
/// Six of the twelve blanks read as chaos, and the reason each one looked wrong was different,
/// which is the tell that the RULE was wrong rather than the numbers.
///
/// A real die sinks its field with a round punch whatever shape the blank is, and a round field
/// inside a cross is exactly what a cross-shaped medal looks like. One circle, all twelve blanks.
///
/// ⚠️ AND IT IS BOUNDED BY THE MINIMUM RADIUS, NOT THE MEAN. A circle at 0.78 of a Greek cross's
/// MEAN radius pokes out through the waist between the arms - the field would be cut by the four
/// notches and the sunken wall would open onto nothing.
function vst_planchet_field_ring_r(_form) {
    return min(vst_planchet_mean_r(_form) * VST_FIELD_K, vst_planchet_min_r(_form) * 0.880);
}

/// The radius the device may occupy. The 0.94 is the air between the device and the field wall:
/// at 1.0 the two bevels merge into one thick smear, which is the failure the recessed field
/// exists to prevent.
function vst_planchet_field_r(_form) {
    return vst_planchet_field_ring_r(_form) * 0.94;
}

/// The radius the legend is struck at: halfway between the field wall and the narrowest point of
/// the blank, which is the only band that is guaranteed to be solid metal all the way round on all
/// twelve forms. On a cross that band is narrow and on a plain disc it is wide; both work.
function vst_planchet_legend_r(_form) {
    return (vst_planchet_field_ring_r(_form) + vst_planchet_min_r(_form)) * 0.5;
}

/// ⛔ DOES THIS BLANK TAKE RIM FURNITURE AT ALL?
///
/// MEASURED BY LOOKING at the first hero plate: a laurel rim on a `sunburst` blank put twenty-two
/// pairs of leaves at 0.848 of the LOCAL radius, which on a radiant form means alternately on a ray
/// tip and down in a valley - and the medal read as an explosion of shards rather than as an
/// object. The same is true of every blank whose edge is already a repeating feature.
///
/// The fix is not to move the furniture. It is that a radiant, toothed or pointed blank IS its own
/// rim treatment, and a real medal struck on one does not carry beading as well. So those forms
/// report false here and vst_medal strikes them plain, whatever was asked for.
function vst_planchet_takes_rim(_form) {
    switch (_form) {
        case "sunburst": case "star": case "cross": case "cog": case "quatrefoil": return false;
        default: return true;
    }
}
