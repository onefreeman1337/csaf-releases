{
  "$GMScript": "v1",
  "%Name": "vst_palette",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_palette",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}