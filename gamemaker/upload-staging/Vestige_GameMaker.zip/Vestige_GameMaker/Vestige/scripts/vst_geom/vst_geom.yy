{
  "$GMScript": "v1",
  "%Name": "vst_geom",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_geom",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}