/// VESTIGE - vst_geom. Part of the shared primitive layer.
///
/// This file is the studio's cross-product drawing/colour foundation, carried forward with
/// more than 1,400 in-engine assertions behind it - including the GML default-epsilon fix
/// described below, which had produced a suite of assertions that could never go red.
///
/// ⛔ GML APPLIES A DEFAULT EPSILON TO NUMERIC COMPARISONS, and it is 0.00001 on this runtime
/// - MEASURED by vst_selftest, which prints math_get_epsilon() into its own result file at
/// twelve decimals. Any tolerance at or below about 0.00001 can NEVER fire, in either
/// direction, so a distinctness assertion written that way passes vacuously forever and an
/// equality assertion written that way goes red on two values that are the same object.
/// Never write one here. And GML has no exponent-literal syntax at all: `1e-5` is a lexer
/// error that reads like a bracket bug.
///
/// The five drawing primitives and the helpers that build them.
///
/// Vestige strikes every medal - planchet, rim, device, legend and ribbon - from data. There
/// is NO sprite, NO atlas and NO texture page in this package: `sprites/` does not exist.
/// That is the product's headline claim and it is literally true.
///
/// This file produces GEOMETRY and knows nothing about drawing. vst_render turns geometry
/// into draw calls and knows nothing about what a `planchet`, a `reeded rim` or a `saltire
/// ribbon` means. Keeping that split clean is what lets the whole corpus be checked before
/// any of it runs in-engine.
///
/// COORDINATES. Every device is authored in a unit box, [-0.5, 0.5] on both axes, y DOWN,
/// origin at the centre of the planchet - the one landmark every medal in the corpus has, and
/// anchoring there is what lets a device and a rim authored independently line up without a
/// per-award fudge. Nothing in this package flips an axis, so a form reads the same in the
/// design corpus and on screen.
///
/// ⛔ AND THE ONE RULE THIS PRODUCT ADDS TO THE PRIMITIVE LAYER: VESTIGE DRAWS RELIEF, NOT
/// FLAT SHAPES. There is a single fixed light, up and to the left, and every closed outline
/// in the package is bevelled against it by vst_relief - so a struck device has a lit face
/// and a shadowed one and reads as metal rather than as a silhouette. A part list that goes
/// to the renderer without passing through vst_relief will draw correctly and look like a
/// sticker, which is the one failure mode this product cannot afford.
/// ============================================================================================
#macro VST_VERSION "1.0.0"

#macro VST_DOT   0
#macro VST_ARC   1
#macro VST_POLY  2
#macro VST_FILL  3
#macro VST_STRIP 4

#macro VST_TAU    6.283185307179586

/// ============================================================================================
/// PART CONSTRUCTORS
/// ============================================================================================

/// A filled circle.
function vst_dot(_cx, _cy, _r, _role) {
    return { kind: VST_DOT, cx: _cx, cy: _cy, r: _r, role: _role };
}

/// A sampled, stroked arc. Angles in radians, y-down (angle 0 = +x, pi/2 = down).
function vst_arc(_cx, _cy, _r, _a0, _a1, _w, _role) {
    return { kind: VST_ARC, cx: _cx, cy: _cy, r: _r, a0: _a0, a1: _a1, w: _w, role: _role };
}

/// A stroked polyline. _pts is an array of [x,y].
function vst_poly(_pts, _closed, _w, _role) {
    return { kind: VST_POLY, pts: _pts, closed: _closed, w: _w, role: _role };
}

/// A triangle FAN. See the header: the outline must be star-shaped about pts[0].
function vst_fill(_pts, _role) {
    return { kind: VST_FILL, pts: _pts, role: _role };
}

/// A triangle STRIP between two polylines of equal length.
function vst_strip(_a, _b, _role) {
    return { kind: VST_STRIP, a: _a, b: _b, role: _role };
}

/// A full stroked circle. An arc, not a primitive of its own - GML's draw_circle outline ignores
/// line width, and width carries meaning across this whole corpus.
function vst_ring(_cx, _cy, _r, _w, _role) {
    return vst_arc(_cx, _cy, _r, 0, VST_TAU, _w, _role);
}

/// An axis-aligned rectangle as a fan. Convex, so star-shaped about any corner.
function vst_rect_fill(_x0, _y0, _x1, _y1, _role) {
    return vst_fill([[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]], _role);
}

/// An axis-aligned rectangle as a stroked outline.
function vst_rect_poly(_x0, _y0, _x1, _y1, _w, _role) {
    return vst_poly([[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]], true, _w, _role);
}

/// Fill a CLOSED ring of points as a fan from an interior point.
///
/// USE THIS AND NEVER HAND-ROLL IT. A fan walks centre -> p0 -> p1 -> ... -> pN and closes from
/// pN straight back to the centre, so the edge from pN back to p0 is never walked and a wedge of
/// the shape is silently missing. The ring's first point is repeated at the end here. That is the
/// whole fix, and it is why every rounded planchet outline in this product is closed.
function vst_ring_fill(_pts, _role, _cx, _cy) {
    var _n = array_length(_pts);
    var _ax = _cx, _ay = _cy;
    if (is_undefined(_ax)) {
        _ax = 0; _ay = 0;
        for (var _i = 0; _i < _n; _i++) { _ax += _pts[_i][0]; _ay += _pts[_i][1]; }
        _ax /= _n; _ay /= _n;
    }
    var _out = array_create(_n + 2);
    _out[0] = [_ax, _ay];
    for (var _i = 0; _i < _n; _i++) _out[_i + 1] = _pts[_i];
    _out[_n + 1] = _pts[0];
    return vst_fill(_out, _role);
}

/// ============================================================================================
/// ARRAY HELPERS
/// ============================================================================================

/// Append every element of _src onto _dst, in place. Returns _dst.
/// Used everywhere instead of array_concat so the allocation pattern is one array per medal
/// rather than one per composition step - a full medal rebuilt every frame is real garbage.
function vst_append(_dst, _src) {
    var _n = array_length(_src);
    for (var _i = 0; _i < _n; _i++) array_push(_dst, _src[_i]);
    return _dst;
}

/// ============================================================================================
/// CURVE SAMPLING - everything curved in this corpus is a sampled polyline, because that is the
/// only curved thing GML draws with an honoured line width.
/// ============================================================================================

/// Quadratic bezier, _n segments, inclusive of both ends.
function vst_qbez(_p0, _p1, _p2, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        _out[_i] = [
            _u * _u * _p0[0] + 2 * _u * _t * _p1[0] + _t * _t * _p2[0],
            _u * _u * _p0[1] + 2 * _u * _t * _p1[1] + _t * _t * _p2[1]
        ];
    }
    return _out;
}

/// Points along a circle, inclusive of both ends.
function vst_arc_pts(_cx, _cy, _r, _a0, _a1, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _a = _a0 + (_a1 - _a0) * (_i / _n);
        _out[_i] = [_cx + cos(_a) * _r, _cy + sin(_a) * _r];
    }
    return _out;
}

/// Points along an ellipse, closed (first point NOT repeated).
function vst_ellipse_pts(_cx, _cy, _rx, _ry, _n) {
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = (_i / _n) * VST_TAU;
        _out[_i] = [_cx + cos(_a) * _rx, _cy + sin(_a) * _ry];
    }
    return _out;
}

/// Regular polygon / star point ring.
function vst_star_pts(_cx, _cy, _r, _n, _phase) {
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = _phase + (_i / _n) * VST_TAU;
        _out[_i] = [_cx + cos(_a) * _r, _cy + sin(_a) * _r];
    }
    return _out;
}

/// Offset a polyline sideways by _d, using per-vertex normals.
function vst_offset_pts(_pts, _d) {
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        _out[_i] = [_pts[_i][0] - _dy * _d, _pts[_i][1] + _dx * _d];
    }
    return _out;
}

/// A polyline given real thickness, as a triangle strip. Correct for shapes a fan cannot do.
function vst_ribbon(_pts, _half, _role) {
    return vst_strip(vst_offset_pts(_pts, _half), vst_offset_pts(_pts, -_half), _role);
}

/// A ribbon whose half-width is given PER POINT rather than interpolated between two ends.
///
/// ⛔ THIS IS THE PRIMITIVE THAT MAKES ENGRAVED TONE POSSIBLE, AND ITS ABSENCE IS WHY FOUR ROUNDS
/// OF PARAMETER TUNING FAILED TO FIX THE SHADING. See vst_relief for the argument in
/// full; the short version is that an engraver ramps tone by SWELLING A LINE, not by filling a
/// region and drawing lines of constant weight on top of it. A constant-width stroke can only ever
/// participate in a pattern; a swelling one participates in a gradient. vst_taper_ribbon below is
/// the two-endpoint special case of this and stays because a ribbon tail genuinely does taper
/// monotonically - but tone does not, so it needs the array.
///
/// _w is a half-width per point and must be the same length as _pts. A shorter array is a DEFECT
/// rather than something to pad: it means the caller's two loops disagree, and silently reusing the
/// last width would draw a plausible wrong picture. Asserted rather than tolerated.
function vst_var_ribbon(_pts, _w, _role) {
    var _n = array_length(_pts);
    if (_n < 2 || array_length(_w) != _n) return vst_strip([], [], _role);
    var _a = array_create(_n), _b = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        var _d = _w[_i];
        _a[_i] = [_pts[_i][0] - _dy * _d, _pts[_i][1] + _dx * _d];
        _b[_i] = [_pts[_i][0] + _dy * _d, _pts[_i][1] - _dx * _d];
    }
    return vst_strip(_a, _b, _role);
}

/// A ribbon whose thickness varies along its length, taper from _w0 at the start to _w1 at the
/// end with an optional exponent. A tapered ribbon tail reads as CUT; one of constant width reads
/// as extruded, which is the loudest tell of programmer art.
function vst_taper_ribbon(_pts, _w0, _w1, _role) {
    var _n = array_length(_pts);
    var _a = array_create(_n), _b = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        var _d = lerp(_w0, _w1, _i / max(1, _n - 1));
        _a[_i] = [_pts[_i][0] - _dy * _d, _pts[_i][1] + _dx * _d];
        _b[_i] = [_pts[_i][0] + _dy * _d, _pts[_i][1] - _dx * _d];
    }
    return vst_strip(_a, _b, _role);
}

/// ============================================================================================
/// CLIPPING
///
/// Liang-Barsky: clip a segment to an axis-aligned rectangle. Returns [[x0,y0],[x1,y1]] or
/// undefined. Analytic rather than a scissor rect, because GML's clipping is a surface/viewport
/// operation that does not survive being called from inside a buyer's own draw event - and
/// every bevel quad, incised stroke and ribbon fold must stop at the
/// planchet outline.
/// ============================================================================================

function vst_clip_seg(_x0, _y0, _x1, _y1, _rx0, _ry0, _rx1, _ry1) {
    var _t0 = 0, _t1 = 1;
    var _dx = _x1 - _x0, _dy = _y1 - _y0;
    var _p, _q, _r;
    for (var _e = 0; _e < 4; _e++) {
        switch (_e) {
            case 0: _p = -_dx; _q = _x0 - _rx0; break;
            case 1: _p =  _dx; _q = _rx1 - _x0; break;
            case 2: _p = -_dy; _q = _y0 - _ry0; break;
            default: _p = _dy; _q = _ry1 - _y0; break;
        }
        if (_p == 0) {
            if (_q < 0) return undefined;
        } else {
            _r = _q / _p;
            if (_p < 0) {
                if (_r > _t1) return undefined;
                if (_r > _t0) _t0 = _r;
            } else {
                if (_r < _t0) return undefined;
                if (_r < _t1) _t1 = _r;
            }
        }
    }
    return [[_x0 + _t0 * _dx, _y0 + _t0 * _dy], [_x0 + _t1 * _dx, _y0 + _t1 * _dy]];
}

/// ============================================================================================
/// TRANSFORMS
/// ============================================================================================

/// Map one point from unit-box space to form space.
function vst_map_pt(_p, _cx, _cy, _s, _rot) {
    var _x = _p[0] * _s, _y = _p[1] * _s;
    if (_rot != 0) {
        var _c = cos(_rot), _sn = sin(_rot);
        var _nx = _x * _c - _y * _sn;
        _y = _x * _sn + _y * _c;
        _x = _nx;
    }
    return [_cx + _x, _cy + _y];
}

/// Resolve a role through an optional remap struct.
function vst_role(_role, _map) {
    if (is_undefined(_map)) return _role;
    if (variable_struct_exists(_map, _role)) return variable_struct_get(_map, _role);
    return _role;
}

/// Place a unit-box part list at (_cx,_cy) at scale _s.
///
/// STROKE WIDTHS SCALE, WITH A FLOOR IN THE RENDERER. The design corpus originally said the
/// weight was "held constant in screen space rather than scaled" - implemented literally, that
/// makes a card-scale form's strokes 32% of its own width while a hero-scale one's are 6%, so
/// small forms rendered as solid blobs. Constant PROPORTION plus vst_render's 1.0px floor is
/// what the rule was actually reaching for.
function vst_place(_parts, _cx, _cy, _s, _rot, _wscale, _map) {
    var _n = array_length(_parts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        var _r = vst_role(_p.role, _map);
        switch (_p.kind) {
            case VST_DOT: {
                var _q = vst_map_pt([_p.cx, _p.cy], _cx, _cy, _s, _rot);
                _out[_i] = vst_dot(_q[0], _q[1], _p.r * _s, _r);
            } break;
            case VST_ARC: {
                var _q = vst_map_pt([_p.cx, _p.cy], _cx, _cy, _s, _rot);
                _out[_i] = vst_arc(_q[0], _q[1], _p.r * _s, _p.a0 + _rot, _p.a1 + _rot,
                                   _p.w * _wscale, _r);
            } break;
            case VST_STRIP: {
                var _na = array_length(_p.a), _nb = array_length(_p.b);
                var _a = array_create(_na), _b = array_create(_nb);
                for (var _k = 0; _k < _na; _k++) _a[_k] = vst_map_pt(_p.a[_k], _cx, _cy, _s, _rot);
                for (var _k = 0; _k < _nb; _k++) _b[_k] = vst_map_pt(_p.b[_k], _cx, _cy, _s, _rot);
                _out[_i] = vst_strip(_a, _b, _r);
            } break;
            case VST_FILL: {
                var _np = array_length(_p.pts);
                var _pts = array_create(_np);
                for (var _k = 0; _k < _np; _k++) _pts[_k] = vst_map_pt(_p.pts[_k], _cx, _cy, _s, _rot);
                _out[_i] = vst_fill(_pts, _r);
            } break;
            default: {
                var _np = array_length(_p.pts);
                var _pts = array_create(_np);
                for (var _k = 0; _k < _np; _k++) _pts[_k] = vst_map_pt(_p.pts[_k], _cx, _cy, _s, _rot);
                _out[_i] = vst_poly(_pts, _p.closed, _p.w * _wscale, _r);
            } break;
        }
    }
    return _out;
}

/// ============================================================================================
/// SEEDED HASH
///
/// Nothing in this product is random at draw time. The only randomness is a seeded hash of the
/// form's id, so two forms that differ in any property look different and the SAME form never
/// flickers between looks. Never call random() anywhere in this package - a jittered edge that
/// re-jitters every frame is the one bug a buyer will notice immediately and cannot work around.
/// ============================================================================================

/// Exact 32-bit unsigned multiply, done in 16-bit halves.
///
/// GML numbers are doubles. A direct h * 16777619 with h near 2^32 reaches 7.2e16, past the 2^53
/// point where doubles stop being exact - so the hash would silently lose its low bits and two
/// different form ids could collide. Splitting the multiply keeps every intermediate under 2^33.
function vst_mul32(_a, _b) {
    var _al = _a & 0xFFFF;
    var _ah = (_a >> 16) & 0xFFFF;
    var _bl = _b & 0xFFFF;
    var _bh = (_b >> 16) & 0xFFFF;
    var _lo = _al * _bl;
    var _mid = ((_al * _bh) + (_ah * _bl)) & 0xFFFF;
    return (_lo + (_mid << 16)) & 0xFFFFFFFF;
}

/// FNV-1a, 32-bit. Same construction as the authoring-side previewer, so a form looks the same
/// in the engine as it did on the corpus sheet.
function vst_hash32(_s) {
    var _h = 2166136261;
    var _n = string_length(_s);
    for (var _i = 1; _i <= _n; _i++) {
        _h = _h ^ ord(string_char_at(_s, _i));
        _h = vst_mul32(_h, 16777619);
    }
    return _h;
}

/// A deterministic 0..1 generator (Lehmer / MINSTD). The state is a ONE-ELEMENT ARRAY, and that
/// is the whole design: arrays are references in GML, so `vst_rng_next` mutates the caller's
/// state and nothing else, with no binding rules involved.
///
/// ⛔ IT WAS A STRUCT WITH A next() METHOD FIRST, AND THAT BROKE THE PRODUCT'S CENTRAL PROMISE.
/// The in-engine self-test came back with three failures of the form "geometry differs between
/// identical calls" plus an rng sequence that did not match the reference values computed in the
/// authoring previewer. Writing `s = ...` and then `self.s = ...` inside a struct-literal method
/// BOTH failed the same way: generator state was not staying with the generator, so two freshly
/// seeded rngs did not agree on their first draw. A jittered form would have re-jittered itself
/// differently every time anything else drew - which is exactly the bug this file's determinism
/// rule exists to prevent.
///
/// Nothing in the JavaScript preview could have caught it: JS closures capture correctly and have
/// no `self` to get wrong. This is the class of defect that ONLY an in-engine test finds, and it
/// is the reason this wing ships one.
function vst_rng(_seed) {
    var _s = _seed % 2147483647;
    if (_s <= 0) _s = 1;
    return [_s];
}

/// The next value in 0..1 from a generator made by vst_rng. Every intermediate stays under 2^47,
/// so no precision guard is needed here.
function vst_rng_next(_st) {
    _st[0] = (_st[0] * 48271) % 2147483647;
    return (_st[0] - 1) / 2147483646;
}
