{
  "$GMScript": "v1",
  "%Name": "vst_selftest",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_selftest",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}