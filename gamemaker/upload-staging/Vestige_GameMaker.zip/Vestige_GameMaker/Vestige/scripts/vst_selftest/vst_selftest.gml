/// VESTIGE - vst_selftest. The assertions, run in-engine against a real Igor-built executable.
///
/// GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE. That is a standing fact about this wing and it is
/// not being papered over here. What does not follow is that the engine cannot test ITSELF
/// unattended: Internal_Ops/run_engine.ps1 builds through gm_gate.ps1, unzips the package, runs the
/// executable with -selftest and reads the result file. Everything below runs on the shipping
/// build, not on a re-implementation of it.
///
/// ⛔ AND THE THING THESE ASSERTIONS CANNOT DO IS JUDGE A PICTURE. A sibling product in this wing
/// passed 369 in-engine assertions, an extent check and an ink-bounds check, and shipped a gallery
/// with seven defects - a compass rose that read as devil horns, two place names overprinted into a
/// word that is not a place, forty-four marks its own headline called identifiable at 14px which
/// were grey dust at 1600px. Every one was found by opening the PNG and looking at it. These make
/// NAMED failure modes unshippable. They are not the review.
///
/// ⛔ NEVER WRITE A TOLERANCE AT OR BELOW ABOUT 0.00001 HERE. math_get_epsilon returns 0.00001 on
/// this runtime - MEASURED by this suite, which prints it into its own result file at twelve
/// decimals - and it participates in every comparison, so `abs(a - b) < 0.0000001` is FALSE for
/// every pair of values including equal ones. That produced a suite in a sibling product where
/// every distinctness assertion passed vacuously: green forever, unable to go red in either
/// direction. The rule is two-sided - a tolerance AT the epsilon goes RED on two values that are
/// the same array object - so the equality tolerance here is an order of magnitude clear of it in
/// both directions. And there is no exponent-literal syntax in GML at all: `1e-5` is a lexer error
/// that reads like a bracket bug.
///
/// ⚠️ A TEST THAT HAS ONLY EVER PASSED IS NOT A TEST. Several blocks below state what it would take
/// to make them fail, so the next author can break them on purpose and watch them go red. Three
/// were broken on purpose during authoring and all three went red: the winding-independence check
/// (by deleting vst_out_sign's measurement and hard-coding a sign), the lit-versus-shadow check (by
/// flipping the lamp), and the case-layout containment check (by adding a column without changing
/// the cell width).
/// ============================================================================================

/// The equality tolerance. An order of magnitude clear of math_get_epsilon in both directions.
#macro VST_ST_EPS 0.0001

/// How far outside the unit box anything may reach. Not zero: a stroke has half-width, and a rim
/// bead whose outer edge sits exactly on the box edge is correct.
#macro VST_ST_BOX 0.520

/// The floor two blank forms must differ by, averaged over 96 radii in unit-box units.
#macro VST_ST_FORM_FLOOR 0.018

/// The floor two devices must differ by, as a Jaccard distance between their ink grids.
#macro VST_ST_DEVICE_FLOOR 0.30

/// The least ink a device may put down, as a fraction of its grid.
#macro VST_ST_INK_FLOOR 0.16

/// The grid a device's ink is measured on.
#macro VST_ST_GRID 32

function vst_st_new() {
    return { pass: 0, fail: 0, failures: [] };
}

function vst_st_ok(_r, _cond, _what) {
    if (_cond) { _r.pass++; return true; }
    _r.fail++;
    array_push(_r.failures, _what);
    return false;
}

/// ============================================================================================
/// 1. THE PRIMITIVE LAYER AND THE EPSILON
/// ============================================================================================

function vst_st_primitives(_r) {
    // ⛔ THE FIRST VERSION OF THIS BLOCK WAS `_e > 0 && _e < VST_ST_EPS`, AND IT WENT RED ON A
    // CORRECT RUNTIME. MEASURED 2026-08-25, first execution of this suite.
    //
    // `math_get_epsilon()` returns 0.00001 here. The clause that failed was `_e > 0`: the
    // difference between the epsilon and zero IS the epsilon, GML therefore calls them EQUAL, and
    // equal is not greater-than. The trap this whole file's tolerances are built to avoid fired on
    // the assertion that was checking for it - which is the most useful possible place for it to
    // fire, and the reason it is split into two assertions rather than repaired into one.
    var _e = math_get_epsilon();
    vst_st_ok(_r, _e < VST_ST_EPS,
        "math_get_epsilon is " + string(_e) + " which is not below the suite tolerance "
        + string(VST_ST_EPS) + " - every tolerance in this file needs re-deriving");
    // And this one PROVES the trap is real on this runtime rather than asserting around it. It
    // goes red the day a GameMaker release stops applying an epsilon to comparisons - at which
    // point every tolerance in this package can be tightened and this comment is the note saying so.
    vst_st_ok(_r, !(_e > 0),
        "math_get_epsilon() compared strictly greater than zero, so this runtime no longer applies "
        + "a default epsilon to comparisons - the tolerances in this package were chosen for one "
        + "that does");

    // The seeded generator. Two generators from the same seed must agree, and the state must stay
    // with the generator - this is the struct-versus-array finding the primitive layer records,
    // and it is the class of defect that ONLY an in-engine test finds.
    var _a = vst_rng(12345), _b = vst_rng(12345);
    var _same = true;
    for (var _i = 0; _i < 8; _i++) if (abs(vst_rng_next(_a) - vst_rng_next(_b)) > VST_ST_EPS) _same = false;
    vst_st_ok(_r, _same, "two generators seeded identically diverged");

    var _c = vst_rng(12345), _d = vst_rng(999983);
    vst_st_ok(_r, abs(vst_rng_next(_c) - vst_rng_next(_d)) > VST_ST_EPS,
        "two generators seeded differently produced the same first draw");

    // The 32-bit hash. Different strings must not collide across the corpus, and the multiply must
    // stay exact - a direct h * 16777619 reaches past 2^53 and silently loses its low bits.
    vst_st_ok(_r, vst_hash32("a") != vst_hash32("b"), "hash32 collided on \"a\" and \"b\"");
    vst_st_ok(_r, vst_mul32(0xFFFFFFFF, 16777619) == vst_mul32(0xFFFFFFFF, 16777619),
        "mul32 is not deterministic");
    vst_st_ok(_r, vst_mul32(0xFFFFFFFF, 16777619) <= 0xFFFFFFFF,
        "mul32 returned a value outside 32 bits");

    // The fan helper closes its own final wedge. The two repeated points are the SAME ARRAY OBJECT
    // by construction, which is precisely the pair that went red under a tolerance written at the
    // epsilon rather than clear of it.
    var _ring = vst_ellipse_pts(0, 0, 0.3, 0.3, 12);
    var _fan = vst_ring_fill(_ring, "m2", undefined, undefined);
    vst_st_ok(_r, array_length(_fan.pts) == 14, "ring fill produced " + string(array_length(_fan.pts))
        + " points for a 12-point ring, expected 14");
    vst_st_ok(_r, abs(_fan.pts[1][0] - _fan.pts[13][0]) < VST_ST_EPS
              && abs(_fan.pts[1][1] - _fan.pts[13][1]) < VST_ST_EPS,
        "ring fill did not repeat its first point at the end - a wedge is missing");
}

/// ============================================================================================
/// 2. THE RELIEF ENGINE
/// ============================================================================================

function vst_st_relief(_r) {
    // A wall facing straight into the lamp shows the specular stop; one facing away shows the
    // deepest. TO BREAK THIS: flip the sign of VST_LX/VST_LY.
    vst_st_ok(_r, vst_relief_role(VST_LX, VST_LY, 1.0) == "m4",
        "a wall facing the lamp did not resolve to the specular stop");
    vst_st_ok(_r, vst_relief_role(-VST_LX, -VST_LY, 1.0) == "m0",
        "a wall facing away from the lamp did not resolve to the deepest stop");
    vst_st_ok(_r, vst_relief_role(VST_LX, VST_LY, 0.0) == "m2",
        "a flat wall did not resolve to the face stop");
    // A wall at a right angle to the lamp is the face value whichever way it is turned.
    vst_st_ok(_r, vst_relief_role(-VST_LY, VST_LX, 1.0) == "m2",
        "a wall side-on to the lamp did not resolve to the face stop");

    // Winding independence. The same circle listed clockwise and anticlockwise must light the same
    // way. TO BREAK THIS: replace vst_out_sign's measurement with a constant.
    var _cw = vst_ellipse_pts(0, 0, 0.4, 0.4, 24);
    var _ccw = array_create(24);
    for (var _i = 0; _i < 24; _i++) _ccw[_i] = _cw[23 - _i];
    vst_st_ok(_r, vst_out_sign(_cw) == -vst_out_sign(_ccw),
        "reversing a ring did not reverse its measured winding");
    var _ba = vst_bevel(_cw, 0.05, 1, false);
    var _bb = vst_bevel(_ccw, 0.05, 1, false);
    vst_st_ok(_r, array_length(_ba) == 24 && array_length(_bb) == 24,
        "a 24-point ring bevelled at 1 step did not produce 24 quads");
    // Edge i of the clockwise list is the same piece of geometry as edge (23-i-1) of the reversed
    // one, so their roles must match.
    var _wind_ok = true;
    for (var _i = 0; _i < 24; _i++) {
        if (_ba[_i].role != _bb[(23 - _i - 1 + 24) % 24].role) _wind_ok = false;
    }
    vst_st_ok(_r, _wind_ok, "the same edge lit differently depending on the point order");

    // The ramp is actually swept. A full circle must show every one of the five stops somewhere,
    // or the bevel is drawing a flat hoop and the whole look is gone.
    var _seen = vst_roles_used(vst_bevel(vst_ellipse_pts(0, 0, 0.4, 0.4, 64), 0.06, 1, false));
    vst_st_ok(_r, array_length(_seen) == VST_RAMP_N,
        "a bevelled circle used " + string(array_length(_seen)) + " of " + string(VST_RAMP_N)
        + " ramp stops - the relief is flat");

    // Inverting swaps the lit side. TO BREAK THIS: drop the _invert argument in vst_bevel.
    var _up = vst_bevel(_cw, 0.05, 1, false);
    var _dn = vst_bevel(_cw, 0.05, 1, true);
    var _diff = 0;
    for (var _i = 0; _i < 24; _i++) if (_up[_i].role != _dn[_i].role) _diff++;
    vst_st_ok(_r, _diff >= 18,
        "a sunken bevel differed from a raised one on only " + string(_diff)
        + " of 24 edges - inversion is not working");

    // Nesting. Three steps produce three rings of quads.
    vst_st_ok(_r, array_length(vst_bevel(_cw, 0.05, 3, false)) == 72,
        "a 3-step bevel did not produce three rings of quads");

    // The inset ring stays closed. The seam between the last and first vertex is where an
    // open-polyline offset helper puts a notch, and on a circle that seam is at three o'clock in
    // plain view.
    var _in = vst_inset(_cw, 0.05, vst_out_sign(_cw));
    var _seam = point_distance(_in[23][0], _in[23][1], _in[0][0], _in[0][1]);
    var _typ = point_distance(_in[10][0], _in[10][1], _in[11][0], _in[11][1]);
    vst_st_ok(_r, abs(_seam - _typ) < 0.004,
        "the inset ring has a notch at its seam: seam edge " + string(_seam)
        + " against a typical edge of " + string(_typ));

    // A degenerate call must produce nothing rather than a malformed part.
    vst_st_ok(_r, array_length(vst_bevel([[0, 0], [1, 0]], 0.05, 2, false)) == 0,
        "bevelling a two-point outline produced parts");
    vst_st_ok(_r, array_length(vst_bevel(_cw, 0, 2, false)) == 0,
        "bevelling at zero width produced parts");

    // ⛔ THE UI FURNITURE, AND THIS BLOCK EXISTS BECAUSE OF A DEFECT THAT SHIPPED PAST EVERY OTHER
    // CHECK IN THIS FILE. vst_round_rect_pts walked its four corners in the wrong order, producing
    // a self-intersecting bowtie; the gate compiled it, 711 assertions passed, and every panel and
    // well in the product drew with hooks at its corners. It was caught by opening a PNG.
    //
    // The property that separates a correct rounded rectangle from that bowtie is its TOTAL
    // TURNING: a simple closed polygon turns through exactly one revolution, and a figure-of-eight
    // turns through zero. TO BREAK THIS: swap any two corners in vst_round_rect_pts.
    var _rr = vst_round_rect_pts(-0.4, -0.3, 0.4, 0.3, 0.1, 4);
    vst_st_ok(_r, abs(abs(vst_st_turning(_rr)) - VST_TAU) < 0.05,
        "a rounded rectangle turns through " + string(vst_st_turning(_rr))
        + " radians instead of one revolution - the outline crosses itself");

    // And the consequence check, which is the one that would have named the symptom: the panel's
    // parts must stay inside the rectangle they were asked for.
    var _pb = vst_render_bounds(vst_ui_panel(-0.4, -0.3, 0.4, 0.3, 0.1, 0.04, "panel"));
    vst_st_ok(_r, _pb[0] >= -0.41 && _pb[1] >= -0.31 && _pb[2] <= 0.41 && _pb[3] <= 0.31,
        "a UI panel drew outside the rectangle it was given: [" + string(_pb[0]) + ","
        + string(_pb[1]) + "," + string(_pb[2]) + "," + string(_pb[3]) + "]");
    var _wb = vst_render_bounds(vst_ui_well(-0.4, -0.3, 0.4, 0.3, 0.1, 0.04, "felt"));
    vst_st_ok(_r, _wb[0] >= -0.41 && _wb[1] >= -0.31 && _wb[2] <= 0.41 && _wb[3] <= 0.31,
        "a UI well drew outside the rectangle it was given");
    // A rounded rectangle with a radius larger than the box is a pill, not an error.
    vst_st_ok(_r, array_length(vst_round_rect_pts(0, 0, 10, 4, 999, 3)) == 16,
        "an over-large corner radius changed the point count");
}

/// The total signed turning of a closed polygon, in radians. One revolution for a simple polygon,
/// zero for a figure-of-eight. Used only by the suite.
function vst_st_turning(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return 0;
    var _total = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i], _b = _pts[(_i + 1) % _n], _c = _pts[(_i + 2) % _n];
        var _ux = _b[0] - _a[0], _uy = _b[1] - _a[1];
        var _vx = _c[0] - _b[0], _vy = _c[1] - _b[1];
        var _cross = _ux * _vy - _uy * _vx;
        var _dot = _ux * _vx + _uy * _vy;
        if (_cross == 0 && _dot == 0) continue;
        _total += arctan2(_cross, _dot);
    }
    return _total;
}

/// ============================================================================================
/// 3. THE ALLOYS
/// ============================================================================================

function vst_st_alloys(_r) {
    var _ids = vst_alloy_ids();
    vst_st_ok(_r, array_length(_ids) == 7, "the alloy ladder is not seven long");

    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _a = vst_alloy(_ids[_i]);
        var _l = [_a.L.m0, _a.L.m1, _a.L.m2, _a.L.m3, _a.L.m4];
        var _mono = true;
        for (var _k = 0; _k < 4; _k++) if (_l[_k + 1] <= _l[_k]) _mono = false;
        vst_st_ok(_r, _mono, _ids[_i] + " ramp is not monotonically lighter");
        vst_st_ok(_r, vst_alloy_tier(_ids[_i]) == _i,
            _ids[_i] + " does not report its own index as its tier");
    }

    var _ramp = vst_alloy_tightest_ramp();
    vst_st_ok(_r, _ramp[0] >= VST_RAMP_FLOOR,
        "the tightest alloy ramp step is " + string(_ramp[0]) + " on " + _ramp[1]
        + ", below the floor of " + string(VST_RAMP_FLOOR));

    var _tier = vst_alloy_tightest_tier();
    vst_st_ok(_r, _tier[0] >= 1.0,
        "the two least separable alloys are " + _tier[1] + " scoring " + string(_tier[0])
        + " against a floor of 1.0 - a player cannot tell those two tiers apart");

    var _gnd = vst_alloy_tightest_ground();
    vst_st_ok(_r, _gnd[0] >= VST_GROUND_FLOOR,
        "the least visible alloy on its felt is " + _gnd[1] + " at " + string(_gnd[0])
        + ", below the floor of " + string(VST_GROUND_FLOOR));

    // Tier clamping. An out-of-range tier must land on the top alloy, loudly, rather than wrapping
    // round to iron - which would make a buyer's mistake invisible.
    vst_st_ok(_r, vst_alloy_for_tier(99) == "adamant", "an out-of-range tier did not clamp upward");
    vst_st_ok(_r, vst_alloy_for_tier(-5) == "iron", "a negative tier did not clamp downward");

    // Hue gap takes the short way round the circle. Without this, a red alloy would pass the tier
    // floor for free against everything. TO BREAK THIS: remove the wrap.
    vst_st_ok(_r, abs(vst_hue_gap(350, 10) - 20) < VST_ST_EPS,
        "hue gap across zero measured " + string(vst_hue_gap(350, 10)) + " instead of 20");
    vst_st_ok(_r, abs(vst_hue_gap(10, 350) - 20) < VST_ST_EPS, "hue gap is not symmetric");

    // Every case paper resolves every role, and the locked cavity is derived from the paper it is
    // cut into rather than authored once.
    var _ps = vst_case_ids();
    vst_st_ok(_r, array_length(_ps) == 6, "there are not six case papers");
    var _distinct = true;
    for (var _i = 0; _i < array_length(_ps); _i++) {
        var _p = vst_case_paper(_ps[_i]);
        vst_st_ok(_r, abs(_p.L.line - _p.L.panel) > 0.30,
            _ps[_i] + " type is only " + string(abs(_p.L.line - _p.L.panel))
            + " from its own panel - the case would be unreadable");
        var _lk = vst_surface_locked(_ps[_i]);
        if (_lk.m2 == vst_surface_locked(_ps[(_i + 1) % array_length(_ps)]).m2) _distinct = false;
    }
    vst_st_ok(_r, _distinct,
        "two case papers produced the same locked cavity colour - the cavity is not derived");
}

/// ============================================================================================
/// 4. THE BLANK FORMS
/// ============================================================================================

/// A form's radius sampled at 96 evenly spaced angles.
function vst_st_profile(_id) {
    var _out = array_create(96);
    for (var _i = 0; _i < 96; _i++) _out[_i] = vst_planchet_r(_id, (_i / 96) * VST_TAU);
    return _out;
}

function vst_st_forms(_r) {
    var _ids = vst_planchet_ids();
    vst_st_ok(_r, array_length(_ids) == 12, "there are not twelve blank forms");

    var _profiles = array_create(array_length(_ids));
    for (var _i = 0; _i < array_length(_ids); _i++) {
        _profiles[_i] = vst_st_profile(_ids[_i]);
        var _lo = 999, _hi = -999;
        for (var _k = 0; _k < 96; _k++) {
            _lo = min(_lo, _profiles[_i][_k]);
            _hi = max(_hi, _profiles[_i][_k]);
        }
        // A radius that reaches zero or goes negative is a form that cannot be filled as a fan.
        vst_st_ok(_r, _lo > 0.060, _ids[_i] + " narrows to " + string(_lo)
            + " - too thin to strike and too thin to fill");
        vst_st_ok(_r, _hi <= VST_ST_BOX, _ids[_i] + " reaches " + string(_hi)
            + ", outside the unit box");
        vst_st_ok(_r, _hi >= 0.40, _ids[_i] + " only reaches " + string(_hi)
            + " - it would sit small beside every other blank on the same grid");

        // The device fits inside its own field on every form.
        var _fr = vst_planchet_field_r(_ids[_i]);
        vst_st_ok(_r, _fr > 0.10 && _fr < _hi * VST_FIELD_K,
            _ids[_i] + " field radius " + string(_fr) + " is not inside its own field wall");
    }

    var _worst = 999, _who = "";
    for (var _i = 0; _i < array_length(_ids); _i++) {
        for (var _k = _i + 1; _k < array_length(_ids); _k++) {
            var _s = 0;
            for (var _j = 0; _j < 96; _j++) _s += abs(_profiles[_i][_j] - _profiles[_k][_j]);
            _s /= 96;
            if (_s < _worst) { _worst = _s; _who = _ids[_i] + "/" + _ids[_k]; }
        }
    }
    vst_st_ok(_r, _worst >= VST_ST_FORM_FLOOR,
        "the two closest blank forms are " + _who + " at " + string(_worst)
        + ", below the floor of " + string(VST_ST_FORM_FLOOR));
    global.vst_st_form_worst = _worst;
    global.vst_st_form_who = _who;

    // Sampling is monotone in detail, and the low level is not so coarse that a circle becomes a
    // polygon a player would notice.
    vst_st_ok(_r, vst_detail_segs(0) < vst_detail_segs(1)
              && vst_detail_segs(1) < vst_detail_segs(2), "detail levels do not increase");
    vst_st_ok(_r, vst_detail_segs(0) >= 24, "the inventory sampling is coarser than 24 segments");

    // Rim treatments produce furniture, except `plain`, which produces none on purpose.
    var _rims = vst_rim_ids();
    vst_st_ok(_r, array_length(_rims) == 6, "there are not six rim treatments");
    for (var _i = 0; _i < array_length(_rims); _i++) {
        var _p = vst_rim_parts(_rims[_i], "round", 2);
        if (_rims[_i] == "plain") {
            vst_st_ok(_r, array_length(_p) == 0, "the plain rim produced furniture");
        } else {
            vst_st_ok(_r, array_length(_p) > 0, _rims[_i] + " produced no rim furniture");
            vst_st_ok(_r, vst_rim_count(_rims[_i], 0) < vst_rim_count(_rims[_i], 2),
                _rims[_i] + " does not thin out at inventory size - it would read as a grey fringe");
            var _bb = vst_render_bounds(_p);
            vst_st_ok(_r, _bb[0] >= -VST_ST_BOX && _bb[2] <= VST_ST_BOX
                      && _bb[1] >= -VST_ST_BOX && _bb[3] <= VST_ST_BOX,
                _rims[_i] + " rim furniture reaches outside the unit box");
        }
    }
}

/// ============================================================================================
/// 5. THE DEVICE CORPUS
/// ============================================================================================

function vst_st_devices(_r) {
    var _cats = vst_category_ids();
    vst_st_ok(_r, array_length(_cats) == 7, "there are not seven categories");

    var _ids = vst_device_ids();
    vst_st_ok(_r, array_length(_ids) == 42,
        "the corpus holds " + string(array_length(_ids)) + " devices, not 42");

    // No duplicates, and every device knows its own category.
    var _seen = {};
    var _dupes = 0;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        if (variable_struct_exists(_seen, _ids[_i])) _dupes++;
        variable_struct_set(_seen, _ids[_i], true);
    }
    vst_st_ok(_r, _dupes == 0, string(_dupes) + " device ids are duplicated in the corpus");

    for (var _i = 0; _i < array_length(_cats); _i++) {
        vst_st_ok(_r, array_length(vst_category_devices(_cats[_i])) == 6,
            _cats[_i] + " does not carry six devices");
    }

    var _grids = array_create(array_length(_ids));
    var _minink = 1, _minwho = "", _under = 0, _inksum = 0, _underwho = "";
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _id = _ids[_i];
        var _d = vst_device(_id);
        vst_st_ok(_r, _d.category == vst_device_category(_id) && _d.category != "",
            _id + " does not resolve to a category");
        vst_st_ok(_r, _d.label != "", _id + " has no label for the trophy case");
        vst_st_ok(_r, array_length(_d.solids) > 0, _id + " has no raised mass at all");

        // Every authored outline must be a real polygon with a measurable area, or the fan draws
        // nothing and the device silently loses a piece. This is the check that caught the quill's
        // nib - three points 0.00005 apart from collinear, which would have drawn as a pen with no
        // point on it and reported no error of any kind.
        var _bad = 0;
        for (var _k = 0; _k < array_length(_d.solids); _k++) {
            if (array_length(_d.solids[_k]) < 3) _bad++;
            else if (abs(vst_area2(_d.solids[_k])) < 0.0006) _bad++;
        }
        for (var _k = 0; _k < array_length(_d.sunk); _k++) {
            if (array_length(_d.sunk[_k]) < 3) _bad++;
            else if (abs(vst_area2(_d.sunk[_k])) < 0.0006) _bad++;
        }
        vst_st_ok(_r, _bad == 0, _id + " has " + string(_bad)
            + " outline(s) that are degenerate or have no area");

        // ⛔ AND EVERY OUTLINE MUST BE SIMPLE, NOT SELF-CROSSING. A bowtie fills the wrong region
        // and throws its inset points a long way outside itself - which is exactly how the trophy
        // case's panels shipped with hooks at their corners, and nothing except looking at a PNG
        // caught it there. Total turning is one revolution for a simple polygon and zero for a
        // figure-of-eight, so it separates the two without needing a segment-intersection test.
        var _crossed = "";
        for (var _k = 0; _k < array_length(_d.solids); _k++) {
            if (abs(abs(vst_st_turning(_d.solids[_k])) - VST_TAU) > 0.35) {
                _crossed = "solid " + string(_k);
            }
        }
        for (var _k = 0; _k < array_length(_d.sunk); _k++) {
            if (abs(abs(vst_st_turning(_d.sunk[_k])) - VST_TAU) > 0.35) {
                _crossed = "sunk " + string(_k);
            }
        }
        vst_st_ok(_r, _crossed == "",
            _id + " has an outline that crosses itself or doubles back: " + _crossed);

        var _parts = vst_device_parts(_id, 2);
        vst_st_ok(_r, array_length(_parts) > 0, _id + " produced no parts");
        var _bb = vst_render_bounds(_parts);
        vst_st_ok(_r, _bb[0] >= -VST_ST_BOX && _bb[2] <= VST_ST_BOX
                  && _bb[1] >= -VST_ST_BOX && _bb[3] <= VST_ST_BOX,
            _id + " reaches outside the unit box: [" + string(_bb[0]) + "," + string(_bb[1])
            + "," + string(_bb[2]) + "," + string(_bb[3]) + "]");

        // At inventory detail the incisions are dropped on purpose, so the part count must fall.
        vst_st_ok(_r, array_length(vst_device_parts(_id, 0)) < array_length(_parts),
            _id + " does not simplify at inventory detail");

        _grids[_i] = vst_device_grid(_id, VST_ST_GRID);
        var _fill = vst_grid_fill(_grids[_i]);
        if (_fill < _minink) { _minink = _fill; _minwho = _id; }
        if (_fill < VST_ST_INK_FLOOR) {
            _under++;
            _underwho += (_underwho == "") ? "" : ", ";
            _underwho += _id + " " + string_format(_fill, 1, 3);
        }
        _inksum += _fill;
    }
    // ⚠️ THE COUNT UNDER THE FLOOR AND THE MEAN ARE REPORTED, NOT JUST THE WORST, AND THAT IS A
    // LESSON FROM FIXING FOUR OF THESE IN A ROW. A check that names only the single emptiest device
    // tells you nothing about whether you are fixing a tail of one or a tail of ten - so each fix
    // is followed by a full rebuild to discover the next name, and after four rounds of that it is
    // no longer obvious whether the corpus is wrong or the floor is. With the count and the mean in
    // the result file, one run answers it.
    vst_st_ok(_r, _minink >= VST_ST_INK_FLOOR,
        "the emptiest device is " + _minwho + " filling " + string(_minink)
        + " of its grid, below the floor of " + string(VST_ST_INK_FLOOR) + "; "
        + string(_under) + " of " + string(array_length(_ids)) + " are under it, mean fill "
        + string_format(_inksum / array_length(_ids), 1, 3) + "; all of them: " + _underwho);
    global.vst_st_ink_min = _minink;
    global.vst_st_ink_who = _minwho;
    global.vst_st_ink_under = _under;
    global.vst_st_ink_mean = _inksum / array_length(_ids);

    var _worst = 1, _who = "";
    for (var _i = 0; _i < array_length(_ids); _i++) {
        for (var _k = _i + 1; _k < array_length(_ids); _k++) {
            var _dd = vst_grid_distance(_grids[_i], _grids[_k]);
            if (_dd < _worst) { _worst = _dd; _who = _ids[_i] + "/" + _ids[_k]; }
        }
    }
    vst_st_ok(_r, _worst >= VST_ST_DEVICE_FLOOR,
        "the two closest devices are " + _who + " at Jaccard " + string(_worst)
        + ", below the floor of " + string(VST_ST_DEVICE_FLOOR));
    global.vst_st_dev_worst = _worst;
    global.vst_st_dev_who = _who;

    // ⚠️ AND THE ASSERTION THAT MAKES THE ONE ABOVE MEAN SOMETHING. A grid comparison that returns
    // a large number for two identical inputs is measuring noise, not shape. Comparing a device
    // with itself must return exactly zero.
    vst_st_ok(_r, vst_grid_distance(_grids[0], _grids[0]) == 0,
        "a device did not measure as identical to itself - the grid comparison is measuring noise");
}

/// ============================================================================================
/// 6. THE RIBBONS
/// ============================================================================================

function vst_st_ribbons(_r) {
    var _ids = vst_ribbon_ids();
    vst_st_ok(_r, array_length(_ids) == 8, "there are not eight ribbon patterns");

    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _a = 0, _b = 0;
        for (var _u = 0; _u < 16; _u++) {
            for (var _v = 0; _v < 16; _v++) {
                if (vst_ribbon_dye(_ids[_i], (_u + 0.5) / 16, (_v + 0.5) / 16) == 0) _a++; else _b++;
            }
        }
        if (_ids[_i] == "plain") {
            vst_st_ok(_r, _b == 0, "the plain ribbon used its second dye");
        } else {
            // A pattern that uses one dye for less than 8% of the cloth is not a pattern, it is a
            // fleck. TO BREAK THIS: widen the saltire arms until they cover everything.
            vst_st_ok(_r, _a > 20 && _b > 20,
                _ids[_i] + " splits its cloth " + string(_a) + "/" + string(_b)
                + " - one dye is barely present");
        }
    }

    // The drape tapers, and it tapers BELOW the fold rather than from the top.
    //
    // ⛔ THIS BLOCK USED TO ASSERT `vst_ribbon_halfw(1) < 0.75` AND IT WENT RED ON A DELIBERATE
    // DESIGN CHANGE. MEASURED 2026-08-25: the taper was reduced from 0.42 to 0.20 because at 0.42
    // the drape read as a funnel, and this assertion - which was written when 0.42 was the value -
    // then refused the improvement. It was testing the CONSTANT, not the code.
    //
    // The fix is the general one: assert the FUNCTION against the constant, so an implementation
    // bug still fires, and bound the CONSTANT separately, so a design mistake still fires. Neither
    // assertion has to be rewritten the next time the number moves, and the second one states the
    // range in which a drape reads as cloth rather than restating today's value.
    vst_st_ok(_r, abs(vst_ribbon_halfw(0) - 1) < VST_ST_EPS, "the drape is not full width at the top");
    vst_st_ok(_r, abs(vst_ribbon_halfw(VST_RIB_FOLD * 0.5) - 1) < VST_ST_EPS,
        "the drape narrows above its own fold");
    vst_st_ok(_r, abs(vst_ribbon_halfw(1) - (1 - VST_RIB_TAPER)) < VST_ST_EPS,
        "the drape does not reach its declared taper at the bottom: "
        + string(vst_ribbon_halfw(1)) + " against " + string(1 - VST_RIB_TAPER));
    vst_st_ok(_r, VST_RIB_TAPER >= 0.10 && VST_RIB_TAPER <= 0.32,
        "the drape taper is " + string(VST_RIB_TAPER) + ", outside the range that reads as cloth - "
        + "below 0.10 it is a strip of tape and above 0.32 it is a funnel");

    // The fold shading picks all three stops somewhere across the width.
    var _stops = {};
    for (var _u = 0; _u < 32; _u++) variable_struct_set(_stops, string(vst_ribbon_fold(_u / 31)), true);
    vst_st_ok(_r, variable_struct_names_count(_stops) == 3,
        "the ribbon fold uses " + string(variable_struct_names_count(_stops))
        + " of 3 stops - the cloth is flat");

    // ⛔ NO TWO CATEGORIES SHARE A DYE PAIR. The ribbon is the category signal; two categories with
    // the same two dyes would be indistinguishable under six of the eight patterns.
    var _cats = vst_category_ids();
    var _clash = "";
    for (var _i = 0; _i < array_length(_cats); _i++) {
        var _x = vst_category_dyes(_cats[_i]);
        for (var _k = _i + 1; _k < array_length(_cats); _k++) {
            var _y = vst_category_dyes(_cats[_k]);
            if (_x[0] == _y[0] && _x[1] == _y[1]) _clash = _cats[_i] + "/" + _cats[_k];
        }
    }
    vst_st_ok(_r, _clash == "", "two categories share a ribbon dye pair: " + _clash);

    // Every named dye resolves to three stops that actually differ.
    var _dyes = vst_dye_ids();
    for (var _i = 0; _i < array_length(_dyes); _i++) {
        var _s = vst_dye_spec(_dyes[_i]);
        vst_st_ok(_r, _s[0][0] - _s[1][0] > 0.06 && _s[1][0] - _s[2][0] > 0.06,
            _dyes[_i] + " has stops too close together to model a fold");
    }
}

/// ============================================================================================
/// 7. THE MEDAL
/// ============================================================================================

function vst_st_medals(_r) {
    // Determinism. The same id must strike the same medal, every time.
    var _a = vst_medal({ id: "test_award", category: "craft", tier: 2 });
    var _b = vst_medal({ id: "test_award", category: "craft", tier: 2 });
    vst_st_ok(_r, _a.planchet == _b.planchet && _a.rim == _b.rim && _a.device == _b.device
              && _a.ribbon == _b.ribbon && _a.alloy == _b.alloy,
        "the same award struck two different medals");

    // Independence of the axes. Deriving five axes by dividing one hash correlates them; hashing
    // the axis name with the id does not. Over the whole corpus of ids, at least three quarters of
    // consecutive pairs must differ on the planchet.
    var _ids = vst_device_ids();
    var _diff = 0;
    for (var _i = 1; _i < array_length(_ids); _i++) {
        if (vst_medal({ id: _ids[_i] }).planchet != vst_medal({ id: _ids[_i - 1] }).planchet) _diff++;
    }
    vst_st_ok(_r, _diff >= 30,
        "only " + string(_diff) + " of 41 neighbouring ids drew a different blank - the axes are "
        + "correlated and a category's medals will look like near duplicates");

    // Overrides win.
    var _o = vst_medal({ id: "test_award", category: "craft", device: "anvil",
                         planchet: "shield", rim: "laurel", ribbon: "saltire", alloy: "obsidian" });
    vst_st_ok(_r, _o.device == "anvil" && _o.planchet == "shield" && _o.rim == "laurel"
              && _o.ribbon == "saltire" && _o.alloy == "obsidian",
        "an explicit override was ignored");

    // An unknown category falls back rather than producing a medal with no ribbon dyes.
    vst_st_ok(_r, vst_medal({ id: "x", category: "not_a_category" }).category == "valour",
        "an unknown category did not fall back");

    // The tier chooses the alloy when no alloy is given.
    for (var _t = 0; _t < 7; _t++) {
        vst_st_ok(_r, vst_medal({ id: "t" + string(_t), tier: _t }).alloy == vst_alloy_for_tier(_t),
            "tier " + string(_t) + " did not strike in its own alloy");
    }

    // Containment: a whole medal, suspended and not, stays inside the unit box.
    var _sus = vst_medal({ id: "containment", category: "lore", tier: 4, suspended: true });
    var _bare = vst_medal({ id: "containment", category: "lore", tier: 4, suspended: false });
    var _bb1 = vst_render_bounds(vst_medal_parts(_sus, 2));
    var _bb2 = vst_render_bounds(vst_medal_parts(_bare, 2));
    vst_st_ok(_r, _bb1[0] >= -VST_ST_BOX && _bb1[2] <= VST_ST_BOX
              && _bb1[1] >= -VST_ST_BOX && _bb1[3] <= VST_ST_BOX,
        "a suspended medal reaches outside the unit box: [" + string(_bb1[0]) + ","
        + string(_bb1[1]) + "," + string(_bb1[2]) + "," + string(_bb1[3]) + "]");
    vst_st_ok(_r, _bb2[0] >= -VST_ST_BOX && _bb2[2] <= VST_ST_BOX
              && _bb2[1] >= -VST_ST_BOX && _bb2[3] <= VST_ST_BOX,
        "a bare medal reaches outside the unit box");
    // A suspended medal must use MORE of the box vertically than a bare one, or the ribbon is not
    // actually there.
    vst_st_ok(_r, (_bb1[3] - _bb1[1]) > (_bb2[3] - _bb2[1]) * 0.90,
        "a suspended medal is no taller than a bare one - the ribbon is missing");

    // ⛔ NO PART OF ANY MEDAL MAY ASK FOR A ROLE THE SURFACE DOES NOT CARRY. The renderer falls
    // back to `line` on a miss, loudly wrong rather than invisible, and this is what keeps that a
    // diagnostic rather than a crutch. Checked across every alloy and every paper for the roles
    // that vary, and once over the whole corpus for the ones that do not.
    var _sur = vst_surface("gold", "walnut", "crimson", "bone");
    var _missing = "";
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _m = vst_medal({ id: _ids[_i], category: vst_device_category(_ids[_i]),
                             tier: _i % 7, condition: (_i % 5) * 0.25 });
        var _used = vst_roles_used(vst_medal_parts(_m, 2));
        for (var _k = 0; _k < array_length(_used); _k++) {
            if (!variable_struct_exists(_sur, _used[_k])) _missing = _ids[_i] + " -> " + _used[_k];
        }
    }
    vst_st_ok(_r, _missing == "",
        "a medal asked for a role the surface does not carry: " + _missing);

    // Wear. A mint medal keeps its specular; a worn one gives it up; a ruined one loses two stops.
    vst_st_ok(_r, variable_struct_names_count(vst_medal_wear_map(1.0)) == 0,
        "a mint medal is being remapped");
    vst_st_ok(_r, variable_struct_names_count(vst_medal_wear_map(0.60)) == 1,
        "a worn medal did not lose exactly its specular");
    vst_st_ok(_r, variable_struct_names_count(vst_medal_wear_map(0.20)) == 3,
        "a ruined medal did not collapse three stops");
    vst_st_ok(_r, array_length(vst_medal_patina(vst_medal({ id: "p", condition: 1 }), 2)) == 0,
        "a mint medal grew patina");
    vst_st_ok(_r, array_length(vst_medal_patina(vst_medal({ id: "p", condition: 0.1 }), 2)) > 6,
        "a ruined medal grew almost no patina");
    vst_st_ok(_r, array_length(vst_medal_patina(vst_medal({ id: "p", condition: 0.1 }), 0)) == 0,
        "patina was drawn at inventory size, where it is sub-pixel noise");

    // A locked medal is struck on the cavity surface, and a secret one has no device at all.
    var _lock = vst_medal({ id: "l", locked: true });
    vst_st_ok(_r, vst_medal_surface(_lock, "ebony").alloyId == "cavity",
        "a locked medal was not struck on the cavity surface");
    var _blank = vst_medal({ id: "s", locked: true, secret: true });
    var _np = array_length(vst_medal_parts(_blank, 2));
    var _sp = array_length(vst_medal_parts(vst_medal({ id: "s", locked: true }), 2));
    vst_st_ok(_r, _np < _sp,
        "a secret blank is no simpler than a locked medal - the device is still being struck");
}

/// ============================================================================================
/// 8. THE AWARD SYSTEM
/// ============================================================================================

function vst_st_system(_r) {
    vst_init();

    // A banned character in an id is refused at DEFINE time, where the developer sees it, not at
    // save time in front of a player.
    vst_st_ok(_r, !vst_define("bad:id", {}), "an id containing a save separator was accepted");
    vst_st_ok(_r, !vst_define("bad|id", {}), "an id containing a pipe was accepted");
    vst_st_ok(_r, array_length(vst_ids()) == 0, "a refused definition still entered the registry");

    vst_define("first_blood", { name: "First Blood", category: "valour", tier: 1, points: 10 });
    vst_define("far_walker", { name: "Far Walker", category: "wayfaring", tier: 2, points: 25,
                               target: 100 });
    vst_define("the_deep", { name: "The Deep", category: "lore", tier: 3, points: 50,
                             secret: true, requires: "first_blood" });
    vst_st_ok(_r, array_length(vst_ids()) == 3, "the registry did not take three definitions");

    // Defaults.
    vst_define("bare", {});
    var _d = vst_def_of("bare");
    vst_st_ok(_r, _d.name == "bare" && _d.points == 10 && _d.target == 1 && _d.tier == 0
              && _d.category == "valour" && !_d.secret, "the definition defaults moved");

    // Secret visibility has three states, and they are the point of the feature.
    vst_st_ok(_r, vst_visibility("the_deep") == "hidden",
        "a secret award with an unmet prerequisite is not hidden");
    vst_st_ok(_r, vst_visibility("first_blood") == "shown", "an ordinary locked award is not shown");

    // A one-shot.
    vst_st_ok(_r, !vst_unlocked("first_blood"), "an award started unlocked");
    vst_st_ok(_r, vst_grant("first_blood"), "granting an award did not unlock it");
    vst_st_ok(_r, vst_unlocked("first_blood"), "a granted award is not unlocked");
    vst_st_ok(_r, !vst_grant("first_blood"), "granting an already-unlocked award reported a new unlock");

    // Now the secret is revealed but not earned: a blank in the case.
    vst_st_ok(_r, vst_visibility("the_deep") == "blank",
        "a secret award with a met prerequisite is not showing as a blank");

    // A counter unlocks itself at its target and not before.
    vst_progress("far_walker", 40);
    vst_st_ok(_r, !vst_unlocked("far_walker"), "a counter unlocked before reaching its target");
    vst_st_ok(_r, abs(vst_fraction("far_walker") - 0.4) < VST_ST_EPS,
        "the progress fraction is wrong: " + string(vst_fraction("far_walker")));
    vst_progress("far_walker", 59);
    vst_st_ok(_r, !vst_unlocked("far_walker"), "a counter unlocked one short of its target");
    vst_progress("far_walker", 1);
    vst_st_ok(_r, vst_unlocked("far_walker"), "a counter did not unlock on reaching its target");
    vst_st_ok(_r, abs(vst_fraction("far_walker") - 1) < VST_ST_EPS,
        "a completed counter does not read as full");
    vst_set_progress("far_walker", 5000);
    vst_st_ok(_r, abs(vst_fraction("far_walker") - 1) < VST_ST_EPS,
        "an over-full counter reads above 1");

    // Prerequisites gate an award even when its own counter is complete.
    vst_define("gated", { name: "Gated", requires: "never_earned" });
    vst_define("never_earned", { name: "Never" });
    vst_grant("gated");
    vst_st_ok(_r, !vst_unlocked("gated"), "an award unlocked with an unmet prerequisite");
    vst_grant("never_earned");
    vst_st_ok(_r, vst_unlocked("gated"),
        "an award did not settle when its prerequisite was satisfied later");

    // An array of prerequisites needs all of them.
    vst_define("both", { requires: ["first_blood", "the_deep"] });
    vst_grant("both");
    vst_st_ok(_r, !vst_unlocked("both"), "an award unlocked with one of two prerequisites met");
    vst_grant("the_deep");
    vst_st_ok(_r, vst_unlocked("both"), "an award did not settle once both prerequisites were met");
    vst_st_ok(_r, vst_visibility("the_deep") == "shown",
        "an unlocked secret award is still hidden");

    // A chain: one call defines the ladder, one call advances every link, and the links unlock in
    // order as the shared counter passes each target.
    vst_init();
    vst_define_chain("slay", { name: "Slayer", category: "valour", tier: 1, points: 10 },
                     [10, 100, 1000]);
    vst_st_ok(_r, array_length(vst_ids()) == 3, "a three-link chain did not define three awards");
    var _l0 = vst_def_of("slay_10"), _l1 = vst_def_of("slay_100"), _l2 = vst_def_of("slay_1000");
    vst_st_ok(_r, !is_undefined(_l0) && !is_undefined(_l1) && !is_undefined(_l2),
        "a chain link is missing from the registry");
    vst_st_ok(_r, _l0.tier == 1 && _l1.tier == 2 && _l2.tier == 3,
        "a chain does not climb the alloy ladder");
    vst_st_ok(_r, _l0.points < _l1.points && _l1.points < _l2.points,
        "a chain does not increase its points");
    vst_st_ok(_r, vst_award_medal("slay_10").device == vst_award_medal("slay_1000").device,
        "the links of a chain struck different devices - the ladder reads as three unrelated awards");
    vst_chain_progress("slay", 10);
    vst_st_ok(_r, vst_unlocked("slay_10") && !vst_unlocked("slay_100"),
        "a chain did not unlock exactly its first link at 10");
    vst_chain_progress("slay", 90);
    vst_st_ok(_r, vst_unlocked("slay_100") && !vst_unlocked("slay_1000"),
        "a chain did not unlock its second link at 100");
    vst_chain_progress("slay", 900);
    vst_st_ok(_r, vst_unlocked("slay_1000"), "a chain did not unlock its last link");

    // A cycle a buyer could build must not hang the game.
    vst_init();
    vst_define("a_needs_b", { requires: "b_needs_a" });
    vst_define("b_needs_a", { requires: "a_needs_b" });
    vst_grant("a_needs_b"); vst_grant("b_needs_a");
    vst_st_ok(_r, !vst_unlocked("a_needs_b") && !vst_unlocked("b_needs_a"),
        "a prerequisite cycle resolved itself, which means the check is not running");
    vst_st_ok(_r, vst_settle() < 64, "settling a cycle ran to the guard limit");

    // Score, queue and save/load.
    vst_init();
    vst_define("one", { points: 10 });
    vst_define("two", { points: 30 });
    vst_define("three", { points: 60, target: 4 });
    var _s0 = vst_score();
    vst_st_ok(_r, _s0.total == 3 && _s0.points == 100 && _s0.unlocked == 0 && _s0.earned == 0,
        "the empty score is wrong");
    vst_grant("one");
    vst_progress("three", 2);
    var _s1 = vst_score();
    vst_st_ok(_r, _s1.unlocked == 1 && _s1.earned == 10
              && abs(_s1.percent - (1 / 3)) < VST_ST_EPS, "the score after one unlock is wrong");

    vst_st_ok(_r, vst_pending() == 1, "the unlock queue does not hold the one unlock");
    vst_st_ok(_r, vst_next_unlock() == "one", "the queue returned the wrong award");
    vst_st_ok(_r, vst_pending() == 0, "the queue did not shrink when drained");
    vst_st_ok(_r, is_undefined(vst_next_unlock()), "an empty queue returned something");

    var _blob = vst_save();
    vst_grant("two");
    vst_progress("three", 2);
    vst_st_ok(_r, vst_unlocked("two") && vst_unlocked("three"),
        "the state to be overwritten was not set up");
    var _rep = vst_load(_blob);
    vst_st_ok(_r, _rep.ok && _rep.restored == 3 && _rep.unknown == 0,
        "the save did not round-trip: restored " + string(_rep.restored)
        + ", unknown " + string(_rep.unknown));
    vst_st_ok(_r, vst_unlocked("one") && !vst_unlocked("two"), "load did not restore unlock flags");
    vst_st_ok(_r, vst_progress_of("three") == 2, "load did not restore a counter");
    // ⛔ LOADING MUST NOT FIRE A TOAST FOR EVERY AWARD EARNED LAST SESSION.
    vst_st_ok(_r, vst_pending() == 0, "loading a save filled the toast queue");

    // A save from a game that has since renamed an award keeps the rest of the progress.
    var _rep2 = vst_load(_blob + "|deleted_award=1:1:9");
    vst_st_ok(_r, _rep2.ok && _rep2.unknown == 1 && _rep2.restored == 3,
        "an unknown id in a save was not counted and skipped");
    vst_st_ok(_r, vst_load("").ok == false, "an empty save string was accepted");
    vst_st_ok(_r, vst_load("NOPE|one=1:1:1").ok == false, "a save with the wrong tag was accepted");

    // Recency ordering.
    vst_reset();
    vst_grant("two"); vst_grant("one");
    var _rec = vst_recent(5);
    vst_st_ok(_r, array_length(_rec) == 2 && _rec[0] == "one" && _rec[1] == "two",
        "the recent list is not newest first");
    vst_st_ok(_r, array_length(vst_recent(1)) == 1, "the recent list ignored its limit");
    vst_reset();
    vst_st_ok(_r, vst_score().unlocked == 0 && vst_pending() == 0, "reset did not clear progress");
}

/// ============================================================================================
/// 9. THE TOAST
/// ============================================================================================

function vst_st_toast(_r) {
    // Boundaries. The animation must be continuous at every stage change - a jump in scale or
    // slide reads as a stutter, and it is exactly the defect that is invisible in a still frame.
    // ⛔ THE WINDOW IS 0.0002 SECONDS AND IT WAS 0.0015, AND THAT MATTERED. At the wider window
    // this check went red on a CORRECT function: the strike covers 0.85 units of scale in its last
    // few milliseconds by design, so a three-millisecond window sees a 0.025 change and calls it a
    // jump. It is measuring SPEED, not continuity.
    //
    // A discontinuity does not shrink with the window and a fast continuous motion does, so the fix
    // is to shrink the window rather than to loosen the tolerance. At a fifth of a millisecond the
    // strike moves 0.003 and the cos-versus-sin defect this check actually caught still shows up at
    // its full 0.085. Both were MEASURED on 2026-08-25, in that order.
    var _bounds = [VST_T_STRIKE, VST_T_SETTLE, VST_T_HOLD];
    for (var _i = 0; _i < array_length(_bounds); _i++) {
        var _before = vst_toast_frame(_bounds[_i] - 0.0002);
        var _after = vst_toast_frame(_bounds[_i] + 0.0002);
        vst_st_ok(_r, abs(_before.scale - _after.scale) < 0.02,
            "the toast scale jumps at t=" + string(_bounds[_i]) + ": "
            + string(_before.scale) + " to " + string(_after.scale));
        vst_st_ok(_r, abs(_before.slide - _after.slide) < 0.02,
            "the toast panel jumps at t=" + string(_bounds[_i]));
        vst_st_ok(_r, abs(_before.alpha - _after.alpha) < 0.02,
            "the toast alpha jumps at t=" + string(_bounds[_i]));
    }

    var _f0 = vst_toast_frame(0);
    vst_st_ok(_r, abs(_f0.scale - VST_T_DROP) < VST_ST_EPS, "the die does not start above the medal");
    vst_st_ok(_r, _f0.slide == 0, "the panel is out before the medal has landed");
    vst_st_ok(_r, vst_toast_frame(-1).scale == _f0.scale, "a negative time is not clamped");

    var _land = vst_toast_frame(VST_T_STRIKE);
    vst_st_ok(_r, abs(_land.scale - 1) < 0.09, "the medal did not land at its own size");

    vst_st_ok(_r, vst_toast_frame(VST_T_EXIT + 0.01).alive == false,
        "the toast is still alive after its exit");
    vst_st_ok(_r, vst_toast_frame(VST_T_EXIT + 0.01).alpha == 0,
        "a dead toast is not fully transparent");
    vst_st_ok(_r, vst_toast_frame(VST_T_HOLD - 0.1).alive, "the toast died during its hold");

    // Nothing overshoots after the landing, and nothing exceeds the drop before it. TO BREAK THIS:
    // raise the settle bounce amplitude above 0.085.
    // ⚠️ FOUR HUNDRED SAMPLES, ONE ASSERTION. Calling vst_st_ok inside this loop would add 401 to
    // the pass count for testing a single property, and a suite whose headline number is inflated
    // by its loop bounds is a suite nobody can read. The loop finds the worst case; the assertion
    // reports it. CLAUDE.md's rule is to count the WORK, not the verdict, and the work here is one
    // range check over one function.
    var _maxs = 0, _mins = 99, _over = 0, _range_bad = "";
    for (var _i = 0; _i <= 400; _i++) {
        var _t = (_i / 400) * (VST_T_EXIT + 0.2);
        var _f = vst_toast_frame(_t);
        _maxs = max(_maxs, _f.scale);
        _mins = min(_mins, _f.scale);
        if (_t > VST_T_STRIKE && _f.scale > 1.12) _over++;
        if (_range_bad == "" && (_f.alpha < 0 || _f.alpha > 1 || _f.slide < 0 || _f.slide > 1
            || _f.flash < 0 || _f.flash > 1 || _f.ringA < 0 || _f.ringA > 1)) {
            _range_bad = "t=" + string(_t) + " alpha " + string(_f.alpha) + " slide "
                       + string(_f.slide) + " flash " + string(_f.flash) + " ring "
                       + string(_f.ringA);
        }
    }
    vst_st_ok(_r, _range_bad == "", "a toast field left 0..1 at " + _range_bad);
    vst_st_ok(_r, _maxs <= VST_T_DROP + VST_ST_EPS,
        "the toast scaled to " + string(_maxs) + ", above the drop height");
    vst_st_ok(_r, _mins > 0.85, "the toast scaled down to " + string(_mins));
    vst_st_ok(_r, _over == 0, string(_over) + " frames overshot after the strike");

    // Alpha only ever falls once the exit begins.
    var _mono = true, _prev = 1;
    for (var _i = 0; _i <= 100; _i++) {
        var _t = VST_T_HOLD + (_i / 100) * (VST_T_EXIT - VST_T_HOLD);
        var _a = vst_toast_frame(_t).alpha;
        if (_a > _prev + VST_ST_EPS) _mono = false;
        _prev = _a;
    }
    vst_st_ok(_r, _mono, "the toast brightened again during its exit");

    // Layout: the panel never runs off the right edge it was anchored to.
    var _L = vst_toast_layout(1280, 24, 520);
    vst_st_ok(_r, abs((_L.x + _L.w) - 1280) < VST_ST_EPS, "the toast is not anchored to its right edge");
    vst_st_ok(_r, _L.textX > _L.x && _L.textX < _L.x + _L.w, "the toast text starts outside its panel");
    vst_st_ok(_r, _L.textW > 0, "the toast has no room for text");
    vst_st_ok(_r, _L.textX + _L.textW <= _L.x + _L.w + VST_ST_EPS,
        "the toast text column runs off the panel");
    vst_st_ok(_r, _L.medalX - _L.medalSize * 0.5 >= _L.x - VST_ST_EPS,
        "the toast medal hangs off the left of its panel");
}

/// ============================================================================================
/// 10. THE TROPHY CASE LAYOUT
/// ============================================================================================

function vst_st_case(_r) {
    // Several shapes of case, including the degenerate ones. TO BREAK THIS: add a column in
    // vst_case_layout without recomputing the cell width from it.
    var _sizes = [[1600, 900], [1280, 720], [640, 480], [420, 700], [300, 300]];
    var _counts = [1, 7, 42, 300];
    for (var _s = 0; _s < array_length(_sizes); _s++) {
        for (var _c = 0; _c < array_length(_counts); _c++) {
            var _w = _sizes[_s][0], _h = _sizes[_s][1], _n = _counts[_c];
            var _L = vst_case_layout(40, 30, _w, _h, _n);
            var _tag = string(_w) + "x" + string(_h) + " n=" + string(_n);

            vst_st_ok(_r, _L.cols >= 1 && _L.rows >= 1, _tag + ": the grid has no cells");
            vst_st_ok(_r, abs(_L.cols * _L.cellW - _L.gridW) < VST_ST_EPS,
                _tag + ": the columns do not fill the grid exactly");
            vst_st_ok(_r, _L.perPage * _L.pages >= _n, _tag + ": the pages cannot hold every award");
            vst_st_ok(_r, _L.gridY + _L.gridH <= 30 + _h + VST_ST_EPS,
                _tag + ": the grid runs off the bottom of the case");

            var _last = vst_case_cell(_L, _L.perPage - 1);
            vst_st_ok(_r, _last[0] + _last[2] <= _L.gridX + _L.gridW + VST_ST_EPS,
                _tag + ": the last cell of a page runs off the right of the grid");
            vst_st_ok(_r, _last[1] + _last[3] <= _L.gridY + _L.gridH + _L.cellH * 0.001 + 0.5,
                _tag + ": the last row runs off the bottom of the grid");

            var _t0 = vst_case_tab(_L, 0);
            var _t7 = vst_case_tab(_L, array_length(vst_category_ids()));
            vst_st_ok(_r, abs(_t0[0] - _L.gridX) < VST_ST_EPS, _tag + ": the first tab is misplaced");
            vst_st_ok(_r, abs((_t7[0] + _t7[2]) - (_L.gridX + _L.gridW)) < VST_ST_EPS,
                _tag + ": the tabs do not tile the grid width");
        }
    }

    // The state struct and its filter.
    vst_init();
    vst_define("v1", { category: "valour" });
    vst_define("l1", { category: "lore" });
    vst_define("s1", { category: "lore", secret: true, requires: "l1" });
    var _st = vst_case_state("ebony");
    vst_st_ok(_r, _st.cat == "" && _st.page == 0 && _st.paper == "ebony",
        "the case state defaults moved");
    vst_st_ok(_r, array_length(vst_case_visible(_st)) == 2,
        "a hidden secret award is showing in the case");
    _st.cat = "lore";
    vst_st_ok(_r, array_length(vst_case_visible(_st)) == 1, "the category filter is not filtering");
    vst_grant("l1");
    vst_st_ok(_r, array_length(vst_case_visible(_st)) == 2,
        "a revealed secret award did not appear as a blank");
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

function vst_selftest_run() {
    var _r = vst_st_new();

    global.vst_stage = 1; vst_st_primitives(_r);
    global.vst_stage = 2; vst_st_relief(_r);
    global.vst_stage = 3; vst_st_alloys(_r);
    global.vst_stage = 4; vst_st_forms(_r);
    global.vst_stage = 5; vst_st_devices(_r);
    global.vst_stage = 6; vst_st_ribbons(_r);
    global.vst_stage = 7; vst_st_medals(_r);
    global.vst_stage = 8; vst_st_system(_r);
    global.vst_stage = 9; vst_st_toast(_r);
    global.vst_stage = 10; vst_st_case(_r);

    var _ramp = vst_alloy_tightest_ramp();
    var _tier = vst_alloy_tightest_tier();
    var _gnd = vst_alloy_tightest_ground();

    var _s = "{\"crash\":false,\"product\":\"Vestige\"";
    _s += ",\"pass\":" + string(_r.pass) + ",\"fail\":" + string(_r.fail);
    // Twelve decimals, so the epsilon is EVIDENCE in the result file rather than a claim in a
    // comment. The figure in this wing's constitution was wrong by ten times until a run printed it.
    _s += ",\"epsilon\":\"" + string_format(math_get_epsilon(), 1, 12) + "\"";
    _s += ",\"tightestRamp\":" + string(_ramp[0]) + ",\"tightestRampAt\":\"" + _ramp[1] + "\"";
    _s += ",\"tightestTier\":" + string(_tier[0]) + ",\"tightestTierAt\":\"" + _tier[1] + "\"";
    _s += ",\"tightestGround\":" + string(_gnd[0]) + ",\"tightestGroundAt\":\"" + _gnd[1] + "\"";
    _s += ",\"minFormDistance\":" + string(global.vst_st_form_worst)
        + ",\"minFormAt\":\"" + global.vst_st_form_who + "\"";
    _s += ",\"minDeviceDistance\":" + string(global.vst_st_dev_worst)
        + ",\"minDeviceAt\":\"" + global.vst_st_dev_who + "\"";
    _s += ",\"minDeviceInk\":" + string(global.vst_st_ink_min)
        + ",\"minDeviceInkAt\":\"" + global.vst_st_ink_who + "\""
        + ",\"devicesBelowInkFloor\":" + string(global.vst_st_ink_under)
        + ",\"meanDeviceInk\":" + string(global.vst_st_ink_mean);
    _s += ",\"failures\":[";
    for (var _i = 0; _i < array_length(_r.failures); _i++) {
        if (_i > 0) _s += ",";
        _s += "\"" + string_replace_all(_r.failures[_i], "\"", "'") + "\"";
    }
    _s += "]}";

    var _f = file_text_open_write("vst_selftest.json");
    file_text_write_string(_f, _s);
    file_text_close(_f);
    return _r;
}
