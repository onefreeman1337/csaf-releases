/// VESTIGE - vst_award. The system underneath the metal.
///
/// Definitions, counters, tiered chains, prerequisites, secret awards, points, per-category
/// completion, an unlock queue for the toast, and save/load. This is the part a developer wires
/// into their game; everything else in the package is what it looks like when they do.
///
/// -- THE SHAPE OF THE API ----------------------------------------------------------------------
///   vst_init()                                  once, before anything else
///   vst_define(id, spec)                         at load time, one per award
///   vst_define_chain(base, spec, targets)        one call for a whole bronze/silver/gold ladder
///   vst_grant(id)                                a one-shot award
///   vst_progress(id, n)                          add to a counter; unlocks itself at its target
///   vst_set_progress(id, n)                      set a counter absolutely (loading a stat)
///   vst_unlocked(id) / vst_progress_of(id)       queries
///   vst_score()                                  totals, points and percentage
///   vst_next_unlock()                            drain the queue the toast feeds on
///   vst_save() / vst_load(s)                     a single string, for the buyer's save file
///
/// ⛔ EVERY MUTATOR RE-SETTLES THE WHOLE REGISTRY, and that is not laziness either. Prerequisites
/// mean an award can become eligible because a DIFFERENT award unlocked, and a chain means the
/// third link can become eligible the instant the second does. Handling that with a one-step check
/// at the call site works until a buyer defines a chain of four, at which point granting the first
/// silently leaves the rest asleep until something else happens to poke them. vst_settle loops
/// until nothing changes, which is correct for any graph a buyer can build and costs one pass over
/// a list that is a few hundred entries at most.
///
/// ⚠️ THE ORDER AWARDS UNLOCK IN IS RECORDED, AND IT IS NOT THE ORDER THEY WERE DEFINED IN. A
/// trophy case that lists the most recent five needs a sequence number, and the obvious substitute
/// - a timestamp - is not available: date functions differ across targets and a saved timestamp
/// makes a save file that cannot be diffed. A monotonic counter is smaller, portable, and exactly
/// as ordered.
///
/// ⛔ GML has no exponent literals and applies a default epsilon of 0.00001 to comparisons. Every
/// count in this file is an integer and compared with >=, never with a tolerance.
/// ============================================================================================

/// The save format's leading token. Bumping it is how a future version refuses an old string
/// loudly instead of misreading it.
#macro VST_SAVE_TAG "VST1"

/// Characters an award id may not contain, because they are the save format's separators.
///
/// ⚠️ ASSERTED AT DEFINE TIME, NOT AT SAVE TIME, AND THAT IS THE ONLY USEFUL PLACE FOR IT. A check
/// at save time fires in the buyer's shipped game, months later, in front of a player, on the one
/// award whose id has a colon in it. A check at define time fires on the developer's first run.
#macro VST_ID_BANNED "|;=:"

function vst_init() {
    global.vst_def = {};
    global.vst_order = [];
    global.vst_st = {};
    global.vst_queue = [];
    global.vst_clock = 0;
}

/// True if vst_init has run. Every entry point calls it, so a buyer who forgets gets a clear
/// message rather than an undefined-variable crash three frames later.
function vst_ready() {
    return variable_global_exists("vst_def");
}

function vst_assert_ready(_who) {
    if (!vst_ready()) {
        show_debug_message("VESTIGE: " + _who + " called before vst_init(). Call vst_init() once "
            + "at game start, before any vst_define().");
        vst_init();
    }
}

/// ============================================================================================
/// DEFINING
/// ============================================================================================

/// Define one award.
///
/// _spec fields:
///   name        the legend struck on the medal. Defaults to the id.
///   desc        one line for the trophy case. Defaults to "".
///   category    one of vst_category_ids(). Defaults to "valour".
///   tier        0..6, chooses the alloy. Defaults to 0.
///   points      score value. Defaults to 10.
///   target      counter target; 1 means a one-shot. Defaults to 1.
///   secret      hidden in the case until unlocked. Defaults to false.
///   requires    an id, or an array of ids, that must be unlocked first.
///   device / planchet / rim / ribbon / alloy / condition   passed straight to vst_medal
function vst_define(_id, _spec) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_string(_id) || !is_struct(_spec)) return false;
    vst_assert_ready("vst_define");
    for (var _i = 1; _i <= string_length(VST_ID_BANNED); _i++) {
        if (string_pos(string_char_at(VST_ID_BANNED, _i), _id) > 0) {
            show_debug_message("VESTIGE: award id \"" + _id + "\" contains the reserved character "
                + string_char_at(VST_ID_BANNED, _i) + " and cannot be saved. Rename it.");
            return false;
        }
    }
    var _s = is_undefined(_spec) ? {} : _spec;
    var _def = {
        id: _id,
        name: variable_struct_exists(_s, "name") ? _s.name : _id,
        desc: variable_struct_exists(_s, "desc") ? _s.desc : "",
        category: variable_struct_exists(_s, "category") ? _s.category : "valour",
        tier: variable_struct_exists(_s, "tier") ? clamp(floor(_s.tier), 0, 6) : 0,
        points: variable_struct_exists(_s, "points") ? max(0, floor(_s.points)) : 10,
        target: variable_struct_exists(_s, "target") ? max(1, floor(_s.target)) : 1,
        secret: variable_struct_exists(_s, "secret") ? _s.secret : false,
        requires: variable_struct_exists(_s, "requires") ? _s.requires : undefined,
        spec: _s
    };
    if (!variable_struct_exists(global.vst_def, _id)) array_push(global.vst_order, _id);
    variable_struct_set(global.vst_def, _id, _def);
    if (!variable_struct_exists(global.vst_st, _id)) {
        variable_struct_set(global.vst_st, _id, { p: 0, u: false, seq: -1 });
    }
    return true;
}

/// Define a whole tier chain in one call: "slay 10 / 100 / 1000", each link requiring the last,
/// each struck in the next alloy up.
///
/// ⚠️ THE LINKS SHARE ONE COUNTER AND THAT IS WHY THIS EXISTS AS A FUNCTION rather than as three
/// vst_define calls in the readme. Defined by hand, three links have three separate counters and
/// the buyer has to remember to push every kill into all three - which works until they add a
/// fourth link and forget. vst_progress on any link of a chain advances the chain.
function vst_define_chain(_base, _spec, _targets) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_string(_base) || !is_struct(_spec) || !is_array(_targets)) return [];
    vst_assert_ready("vst_define_chain");
    var _s = is_undefined(_spec) ? {} : _spec;
    var _base_name = variable_struct_exists(_s, "name") ? _s.name : _base;
    var _base_tier = variable_struct_exists(_s, "tier") ? _s.tier : 1;
    var _prev = undefined;
    var _ids = array_create(array_length(_targets));
    for (var _i = 0; _i < array_length(_targets); _i++) {
        var _id = _base + "_" + string(_targets[_i]);
        var _link = {};
        var _keys = variable_struct_get_names(_s);
        for (var _k = 0; _k < array_length(_keys); _k++) {
            variable_struct_set(_link, _keys[_k], variable_struct_get(_s, _keys[_k]));
        }
        _link.name = _base_name + " " + string(_targets[_i]);
        _link.target = _targets[_i];
        _link.tier = clamp(_base_tier + _i, 0, 6);
        _link.points = (variable_struct_exists(_s, "points") ? _s.points : 10) * (_i + 1);
        // ⛔ EVERY LINK OF A CHAIN SHARES ONE DEVICE, derived from the chain's BASE id rather than
        // from each link's own. Without this the three links hash to three different devices and a
        // bronze/silver/gold ladder reads as three unrelated awards that happen to be numbered -
        // which destroys the one thing a chain is for. The alloy is the tier signal; the device is
        // the identity.
        if (!variable_struct_exists(_s, "device")) {
            var _cat = variable_struct_exists(_s, "category") ? _s.category : "valour";
            _link.device = vst_medal_device_for(_base, _cat);
        }
        if (!is_undefined(_prev)) _link.requires = _prev;
        vst_define(_id, _link);
        _ids[_i] = _id;
        _prev = _id;
    }
    // The chain's own record, so vst_progress can advance every link from one call.
    variable_struct_set(global.vst_def, "#chain#" + _base, { links: _ids });
    return _ids;
}

function vst_def_of(_id) {
    vst_assert_ready("vst_def_of");
    if (!variable_struct_exists(global.vst_def, _id)) return undefined;
    return variable_struct_get(global.vst_def, _id);
}

function vst_ids() {
    vst_assert_ready("vst_ids");
    return global.vst_order;
}

/// ============================================================================================
/// STATE
/// ============================================================================================

function vst_state_of(_id) {
    vst_assert_ready("vst_state_of");
    if (!variable_struct_exists(global.vst_st, _id)) return { p: 0, u: false, seq: -1 };
    return variable_struct_get(global.vst_st, _id);
}

function vst_unlocked(_id) { return vst_state_of(_id).u; }
function vst_progress_of(_id) { return vst_state_of(_id).p; }

/// The fraction of an award's target that has been reached, 0..1.
function vst_fraction(_id) {
    var _d = vst_def_of(_id);
    if (is_undefined(_d)) return 0;
    return clamp(vst_state_of(_id).p / max(1, _d.target), 0, 1);
}

/// Are this award's prerequisites all unlocked?
function vst_requires_met(_id) {
    var _d = vst_def_of(_id);
    if (is_undefined(_d) || is_undefined(_d.requires)) return true;
    if (is_array(_d.requires)) {
        for (var _i = 0; _i < array_length(_d.requires); _i++) {
            if (!vst_unlocked(_d.requires[_i])) return false;
        }
        return true;
    }
    return vst_unlocked(_d.requires);
}

/// Should this award appear in the trophy case at all?
///
/// A secret award becomes visible when it unlocks. A secret award whose prerequisite is unlocked
/// shows as a BLANK - the player knows there is something there and not what - which is the whole
/// point of a secret award and is why this returns three states rather than a boolean.
function vst_visibility(_id) {
    var _d = vst_def_of(_id);
    if (is_undefined(_d)) return "hidden";
    if (vst_unlocked(_id)) return "shown";
    if (!_d.secret) return "shown";
    if (vst_requires_met(_id)) return "blank";
    return "hidden";
}

/// Unlock everything that has earned it, repeatedly, until nothing changes.
function vst_settle() {
    vst_assert_ready("vst_settle");
    var _guard = 0;
    var _changed = true;
    while (_changed && _guard < 64) {
        _changed = false;
        _guard++;
        for (var _i = 0; _i < array_length(global.vst_order); _i++) {
            var _id = global.vst_order[_i];
            var _d = variable_struct_get(global.vst_def, _id);
            var _s = variable_struct_get(global.vst_st, _id);
            if (_s.u) continue;
            if (_s.p < _d.target) continue;
            if (!vst_requires_met(_id)) continue;
            _s.u = true;
            global.vst_clock++;
            _s.seq = global.vst_clock;
            array_push(global.vst_queue, _id);
            _changed = true;
        }
    }
    // The guard is a backstop against a cycle a buyer could build - award A requires B and B
    // requires A. It cannot deadlock the game, and 64 is far above the depth of any real chain.
    return _guard;
}

/// Award something outright.
function vst_grant(_id) {
    vst_assert_ready("vst_grant");
    var _d = vst_def_of(_id);
    if (is_undefined(_d)) return false;
    if (vst_unlocked(_id)) return false;
    var _s = variable_struct_get(global.vst_st, _id);
    _s.p = _d.target;
    vst_settle();
    return vst_unlocked(_id);
}

/// Add to a counter. On a chain link, advances every link of that chain.
function vst_progress(_id, _n) {
    vst_assert_ready("vst_progress");
    var _amount = is_undefined(_n) ? 1 : _n;
    var _d = vst_def_of(_id);
    if (is_undefined(_d)) return false;
    var _s = variable_struct_get(global.vst_st, _id);
    _s.p = max(0, _s.p + _amount);
    vst_settle();
    return vst_unlocked(_id);
}

/// Set a counter absolutely - the right call when the buyer's game already tracks the stat and
/// simply reports it every so often.
function vst_set_progress(_id, _n) {
    vst_assert_ready("vst_set_progress");
    var _d = vst_def_of(_id);
    if (is_undefined(_d)) return false;
    var _s = variable_struct_get(global.vst_st, _id);
    _s.p = max(0, _n);
    vst_settle();
    return vst_unlocked(_id);
}

/// Advance every link of a chain at once.
function vst_chain_progress(_base, _n) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_string(_base) || !is_real(_n)) return false;
    vst_assert_ready("vst_chain_progress");
    var _key = "#chain#" + _base;
    if (!variable_struct_exists(global.vst_def, _key)) return false;
    var _c = variable_struct_get(global.vst_def, _key);
    var _amount = is_undefined(_n) ? 1 : _n;
    for (var _i = 0; _i < array_length(_c.links); _i++) {
        var _s = variable_struct_get(global.vst_st, _c.links[_i]);
        _s.p = max(0, _s.p + _amount);
    }
    vst_settle();
    return true;
}

/// Take the next newly-unlocked id off the queue, or undefined. The toast drains this.
function vst_next_unlock() {
    vst_assert_ready("vst_next_unlock");
    if (array_length(global.vst_queue) == 0) return undefined;
    var _id = global.vst_queue[0];
    array_delete(global.vst_queue, 0, 1);
    return _id;
}

function vst_pending() {
    vst_assert_ready("vst_pending");
    return array_length(global.vst_queue);
}

/// ============================================================================================
/// SCORE
/// ============================================================================================

/// Totals across the whole registry.
///
/// ⚠️ SECRET AWARDS COUNT TOWARDS THE TOTAL. Hiding them from the denominator makes the percentage
/// jump backwards the moment one is revealed, which reads as a bug in the buyer's game and is the
/// kind of thing that ends up in a review.
function vst_score() {
    vst_assert_ready("vst_score");
    var _u = 0, _pts = 0, _all = 0, _earned = 0;
    for (var _i = 0; _i < array_length(global.vst_order); _i++) {
        var _id = global.vst_order[_i];
        var _d = variable_struct_get(global.vst_def, _id);
        _all += _d.points;
        if (vst_unlocked(_id)) { _u++; _earned += _d.points; }
    }
    var _n = array_length(global.vst_order);
    return {
        unlocked: _u, total: _n,
        points: _all, earned: _earned,
        percent: (_n > 0) ? (_u / _n) : 0
    };
}

/// The ids in one category, in definition order.
function vst_category_awards(_cat) {
    vst_assert_ready("vst_category_awards");
    var _out = [];
    for (var _i = 0; _i < array_length(global.vst_order); _i++) {
        var _id = global.vst_order[_i];
        if (variable_struct_get(global.vst_def, _id).category == _cat) array_push(_out, _id);
    }
    return _out;
}

/// The most recently unlocked ids, newest first, at most _n of them.
function vst_recent(_n) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_real(_n)) return [];
    vst_assert_ready("vst_recent");
    var _rows = [];
    for (var _i = 0; _i < array_length(global.vst_order); _i++) {
        var _id = global.vst_order[_i];
        var _s = variable_struct_get(global.vst_st, _id);
        if (_s.u) array_push(_rows, [_s.seq, _id]);
    }
    // Insertion sort, descending by sequence. The list is short by construction - it is at most
    // the number of awards a game has - and a comparator-based sort in GML needs a method, which
    // this file avoids for the binding reasons the primitive layer records.
    for (var _i = 1; _i < array_length(_rows); _i++) {
        var _v = _rows[_i];
        var _k = _i - 1;
        while (_k >= 0 && _rows[_k][0] < _v[0]) { _rows[_k + 1] = _rows[_k]; _k--; }
        _rows[_k + 1] = _v;
    }
    var _lim = min(is_undefined(_n) ? 5 : _n, array_length(_rows));
    var _out = array_create(_lim);
    for (var _i = 0; _i < _lim; _i++) _out[_i] = _rows[_i][1];
    return _out;
}

/// ============================================================================================
/// SAVE AND LOAD
/// ============================================================================================

/// The whole progress state as one string, for the buyer's own save file.
///
/// ⚠️ IT DOES NOT SAVE THE DEFINITIONS. Definitions live in code and are re-declared every run;
/// saving them would mean a save file that silently keeps a deleted award alive and disagrees with
/// the game it was loaded into. What is saved is exactly what cannot be recomputed.
function vst_save() {
    vst_assert_ready("vst_save");
    var _s = VST_SAVE_TAG;
    for (var _i = 0; _i < array_length(global.vst_order); _i++) {
        var _id = global.vst_order[_i];
        var _st = variable_struct_get(global.vst_st, _id);
        _s += "|" + _id + "=" + string(_st.p) + ":" + (_st.u ? "1" : "0") + ":" + string(_st.seq);
    }
    return _s;
}

/// Restore from a string produced by vst_save. Returns a report struct rather than a boolean.
///
/// ⛔ AN UNKNOWN ID IS COUNTED AND SKIPPED, NEVER AN ERROR. A player who loads a save made before
/// the developer renamed an award should keep the rest of their progress, and a developer who
/// deletes an award should not ship a game that refuses old saves. The count is returned so a
/// developer can SEE it happened.
function vst_load(_str) {
    vst_assert_ready("vst_load");
    var _report = { ok: false, restored: 0, unknown: 0, unlocked: 0 };
    if (is_undefined(_str) || _str == "") return _report;
    var _parts = string_split(_str, "|");
    if (array_length(_parts) == 0 || _parts[0] != VST_SAVE_TAG) return _report;

    global.vst_queue = [];
    global.vst_clock = 0;
    for (var _i = 0; _i < array_length(global.vst_order); _i++) {
        var _st = variable_struct_get(global.vst_st, global.vst_order[_i]);
        _st.p = 0; _st.u = false; _st.seq = -1;
    }

    for (var _i = 1; _i < array_length(_parts); _i++) {
        var _row = _parts[_i];
        var _eq = string_pos("=", _row);
        if (_eq <= 0) continue;
        var _id = string_copy(_row, 1, _eq - 1);
        var _rest = string_delete(_row, 1, _eq);
        var _f = string_split(_rest, ":");
        if (!variable_struct_exists(global.vst_st, _id)) { _report.unknown++; continue; }
        var _st = variable_struct_get(global.vst_st, _id);
        _st.p = real(_f[0]);
        _st.u = (array_length(_f) > 1 && _f[1] == "1");
        _st.seq = (array_length(_f) > 2) ? real(_f[2]) : -1;
        if (_st.seq > global.vst_clock) global.vst_clock = _st.seq;
        _report.restored++;
        if (_st.u) _report.unlocked++;
    }
    // ⚠️ SETTLE, BUT DISCARD THE QUEUE IT PRODUCES. Loading a save must not fire a toast for every
    // award the player earned last session - which is what happens if the queue survives, and it
    // is a genuinely awful first thirty seconds of a game. Settle still runs, because a save made
    // before a new prerequisite was added can leave an award eligible and not yet unlocked.
    vst_settle();
    global.vst_queue = [];
    _report.ok = true;
    return _report;
}

/// Forget all progress. Definitions stay.
function vst_reset() {
    vst_assert_ready("vst_reset");
    for (var _i = 0; _i < array_length(global.vst_order); _i++) {
        var _st = variable_struct_get(global.vst_st, global.vst_order[_i]);
        _st.p = 0; _st.u = false; _st.seq = -1;
    }
    global.vst_queue = [];
    global.vst_clock = 0;
}

/// ============================================================================================
/// A STARTER SET
///
/// Twenty-eight awards across all seven categories, including a three-link chain, two secrets and
/// four counters. It exists for three reasons and all three are worth stating: it is what the demo
/// room runs on, it is what the store sheets are rendered from, and it is a working example a
/// buyer can copy into their own game and edit rather than starting from an empty registry and the
/// documentation.
///
/// ⚠️ IT IS NOT REQUIRED. Nothing else in the package calls it. Delete this function and everything
/// still works; a buyer's own vst_define calls are the normal path.
/// ============================================================================================

function vst_sample_awards() {
    vst_init();

    vst_define("first_blood",  { name: "First Blood",   category: "valour",    tier: 0, points: 10,
                                 desc: "Win your first fight." });
    vst_define("shield_wall",  { name: "Shield Wall",   category: "valour",    tier: 2, points: 30,
                                 desc: "Block 50 blows without falling.", target: 50 });
    vst_define("last_stand",   { name: "Last Stand",    category: "valour",    tier: 5, points: 90,
                                 desc: "Survive at one point of health.", secret: true,
                                 requires: "shield_wall" });

    vst_define("far_walker",   { name: "Far Walker",    category: "wayfaring", tier: 1, points: 20,
                                 desc: "Travel a hundred leagues.", target: 100 });
    vst_define("cartographer", { name: "Cartographer",  category: "wayfaring", tier: 3, points: 45,
                                 desc: "Chart every region." });
    vst_define("landfall",     { name: "Landfall",      category: "wayfaring", tier: 2, points: 25,
                                 desc: "Cross the open sea." });

    vst_define("first_forge",  { name: "First Forge",   category: "craft",     tier: 0, points: 10,
                                 desc: "Make something with your hands." });
    vst_define("masterwork",   { name: "Masterwork",    category: "craft",     tier: 4, points: 70,
                                 desc: "Forge an item of the highest grade." });
    vst_define("keen_edge",    { name: "Keen Edge",     category: "craft",     tier: 2, points: 30,
                                 desc: "Temper a blade perfectly." });

    vst_define("first_page",   { name: "First Page",    category: "lore",      tier: 0, points: 10,
                                 desc: "Read something you were not meant to." });
    vst_define("archivist",    { name: "Archivist",     category: "lore",      tier: 3, points: 50,
                                 desc: "Recover 40 lost pages.", target: 40 });
    vst_define("the_watching", { name: "The Watching",  category: "lore",      tier: 6, points: 120,
                                 desc: "Learn what is behind the door.", secret: true,
                                 requires: "archivist" });

    vst_define("sworn",        { name: "Sworn",         category: "bond",      tier: 1, points: 20,
                                 desc: "Take an oath and keep it." });
    vst_define("cupbearer",    { name: "Cupbearer",     category: "bond",      tier: 2, points: 30,
                                 desc: "Share a table with an enemy." });
    vst_define("banneret",     { name: "Banneret",      category: "bond",      tier: 4, points: 65,
                                 desc: "Raise a company under your own colours." });

    vst_define("unbroken",     { name: "Unbroken",      category: "endurance", tier: 3, points: 45,
                                 desc: "Go a hundred days without rest.", target: 100 });
    vst_define("ashwalker",    { name: "Ashwalker",     category: "endurance", tier: 4, points: 70,
                                 desc: "Cross the burning waste." });
    vst_define("tidebound",    { name: "Tidebound",     category: "endurance", tier: 2, points: 30,
                                 desc: "Outlast the spring flood." });

    vst_define("first_coin",   { name: "First Coin",    category: "hoard",     tier: 0, points: 10,
                                 desc: "Earn a single piece of silver." });
    vst_define("lapidary",     { name: "Lapidary",      category: "hoard",     tier: 3, points: 50,
                                 desc: "Cut a flawless stone." });
    vst_define("full_cellar",  { name: "Full Cellar",   category: "hoard",     tier: 2, points: 30,
                                 desc: "Fill every jar you own." });
    vst_define("magpie",       { name: "Magpie",        category: "hoard",     tier: 1, points: 20,
                                 desc: "Collect 500 trinkets.", target: 500 });

    // The chain. One call, three linked awards climbing the alloy ladder, one shared counter.
    vst_define_chain("slay", { name: "Slayer", category: "valour", tier: 1, points: 15,
                               desc: "Put down what stands against you." }, [10, 100, 1000]);

    vst_define("wayfarer_end", { name: "The Long Road", category: "wayfaring", tier: 6, points: 150,
                                 desc: "Reach the far shore.",
                                 requires: ["cartographer", "landfall"] });
    vst_define("all_craft",    { name: "Guildmaster",  category: "craft",     tier: 5, points: 100,
                                 desc: "Master every trade.",
                                 requires: ["masterwork", "keen_edge"] });
}

/// The starter set, part-earned, for a screenshot or a first run: a believable mid-game save
/// rather than an empty case or a complete one.
function vst_sample_progress() {
    vst_grant("first_blood");
    vst_grant("first_forge");
    vst_grant("first_page");
    vst_grant("first_coin");
    vst_grant("sworn");
    vst_grant("landfall");
    vst_grant("keen_edge");
    vst_grant("tidebound");
    vst_grant("cupbearer");
    vst_progress("shield_wall", 50);
    vst_progress("far_walker", 63);
    vst_progress("archivist", 12);
    vst_progress("magpie", 380);
    vst_progress("unbroken", 44);
    vst_chain_progress("slay", 137);
    // Drained deliberately: a screenshot of a trophy case should not also be showing a toast for
    // every award the set-up just granted.
    global.vst_queue = [];
}

/// ============================================================================================
/// THE MEDAL FOR AN AWARD
/// ============================================================================================

/// Build the struck medal for a defined award, in whatever state it is currently in.
function vst_award_medal(_id) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_string(_id)) return undefined;
    vst_assert_ready("vst_award_medal");
    var _d = vst_def_of(_id);
    if (is_undefined(_d)) return vst_medal({ id: _id });
    var _vis = vst_visibility(_id);
    var _spec = {};
    var _keys = variable_struct_get_names(_d.spec);
    for (var _k = 0; _k < array_length(_keys); _k++) {
        variable_struct_set(_spec, _keys[_k], variable_struct_get(_d.spec, _keys[_k]));
    }
    _spec.id = _id;
    _spec.name = _d.name;
    _spec.category = _d.category;
    _spec.tier = _d.tier;
    _spec.locked = !vst_unlocked(_id);
    _spec.secret = (_vis == "blank");
    if (!variable_struct_exists(_spec, "exergue")) {
        _spec.exergue = (_d.target > 1) ? (string(min(vst_progress_of(_id), _d.target))
                                           + " / " + string(_d.target))
                                        : string(_d.points) + " PTS";
    }
    return vst_medal(_spec);
}
