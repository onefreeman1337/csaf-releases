{
  "$GMScript": "v1",
  "%Name": "vst_award",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_award",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}