/// VESTIGE - vst_medal. Where an award becomes an object.
///
/// This file takes a specification - an id, a name, a category and a tier - and produces a struck
/// medal: which blank it was struck on, which rim it carries, which device is sunk into its field,
/// which alloy it is, which ribbon it hangs from, and how worn it is. Everything is DERIVED, and
/// everything is OVERRIDABLE.
///
/// ⛔ DERIVED, NOT RANDOM. Nothing here calls random(). Every choice comes from a hash of the
/// award's own id, so the same award strikes the same medal in every session, on every machine,
/// forever - and two awards that differ in any way get different medals. A jittered mark that
/// re-jitters every frame is the one bug a buyer notices immediately and cannot work around, and a
/// medal that changes between save and load is the same bug with a longer fuse.
///
/// ⚠️ AND OVERRIDABLE MATTERS AS MUCH. A developer WILL want their capstone award to carry the
/// crossed blades rather than whatever the hash chose, and a product that makes that impossible is
/// a toy. Every axis - device, planchet, rim, ribbon, alloy - takes an explicit value on the
/// definition and falls back to the derivation only when none was given.
///
/// -- THE ARITHMETIC OF THE COMBINATION SPACE -------------------------------------------------
/// 12 planchets x 6 rims x 42 devices x 7 alloys x 8 ribbons is 169,344 distinct medals, and that
/// number is worth exactly nothing on its own: a product that multiplies five axes together and
/// quotes the product is selling a lookup table. What matters is that all five axes are AUTHORED -
/// forty-two devices drawn by hand, twelve blank forms solved as polar functions, seven alloys
/// spaced in a perceptual colour space against two measured floors - and that any single medal
/// pulled out of the space is one somebody could have designed on purpose.
/// ============================================================================================

/// How much of the field the legend arc occupies, in radians, centred on the top of the medal.
#macro VST_LEGEND_SWEEP 2.60

/// ============================================================================================
/// DERIVATION
/// ============================================================================================

/// A stable 0..(_n-1) draw from an award id and a named axis.
///
/// ⚠️ THE AXIS NAME IS PART OF THE HASH INPUT, not a shift of one hash. Deriving five axes by
/// dividing one 32-bit hash by five different constants correlates them: two awards whose ids
/// differ in one character land in adjacent hash buckets and then agree on three axes out of five,
/// so a category's six medals come out looking like a set of near-duplicates. Hashing id + ":" +
/// axis gives five independent draws for the cost of five short hashes.
function vst_pick(_id, _axis, _n) {
    if (_n <= 0) return 0;
    return vst_hash32(_id + ":" + _axis) % _n;
}

/// The default device for an award: one of its own category's six.
function vst_medal_device_for(_id, _cat) {
    var _ds = vst_category_devices(_cat);
    return _ds[vst_pick(_id, "device", array_length(_ds))];
}

/// ============================================================================================
/// THE MEDAL
/// ============================================================================================

/// Build a medal from a specification struct.
///
/// _spec fields, all optional except id:
///   id         string, the stable key everything is derived from
///   name       the legend struck around the rim
///   exergue    the short line struck across the bottom (tier, date, count)
///   category   one of vst_category_ids(); defaults to "valour"
///   tier       0..6, chooses the alloy; ignored if `alloy` is given
///   device / planchet / rim / ribbon / alloy   explicit overrides
///   condition  0..1, mint to worn; defaults to 1
///   suspended  true to hang it from a ribbon; defaults to true
///   locked     true to strike it as an empty cavity
///   secret     true to strike a blank - a locked award nobody may see yet
function vst_medal(_spec) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_spec)) return undefined;
    var _id  = variable_struct_exists(_spec, "id") ? _spec.id : "award";
    var _cat = variable_struct_exists(_spec, "category") ? _spec.category : "valour";
    var _cs  = vst_category_ids();
    var _ok  = false;
    for (var _i = 0; _i < array_length(_cs); _i++) if (_cs[_i] == _cat) _ok = true;
    if (!_ok) _cat = "valour";

    var _tier = variable_struct_exists(_spec, "tier") ? _spec.tier : 0;
    var _dyes = vst_category_dyes(_cat);
    var _pls = vst_planchet_ids(), _rms = vst_rim_ids(), _rbs = vst_ribbon_ids();

    var _m = {
        id: _id,
        name: variable_struct_exists(_spec, "name") ? _spec.name : _id,
        exergue: variable_struct_exists(_spec, "exergue") ? _spec.exergue : "",
        category: _cat,
        tier: _tier,
        planchet: variable_struct_exists(_spec, "planchet") ? _spec.planchet
                  : _pls[vst_pick(_id, "planchet", array_length(_pls))],
        rim: variable_struct_exists(_spec, "rim") ? _spec.rim
             : _rms[vst_pick(_id, "rim", array_length(_rms))],
        device: variable_struct_exists(_spec, "device") ? _spec.device
                : vst_medal_device_for(_id, _cat),
        ribbon: variable_struct_exists(_spec, "ribbon") ? _spec.ribbon
                : _rbs[vst_pick(_id, "ribbon", array_length(_rbs))],
        alloy: variable_struct_exists(_spec, "alloy") ? _spec.alloy : vst_alloy_for_tier(_tier),
        dyeA: _dyes[0],
        dyeB: _dyes[1],
        condition: variable_struct_exists(_spec, "condition") ? clamp(_spec.condition, 0, 1) : 1,
        suspended: variable_struct_exists(_spec, "suspended") ? _spec.suspended : true,
        locked: variable_struct_exists(_spec, "locked") ? _spec.locked : false,
        secret: variable_struct_exists(_spec, "secret") ? _spec.secret : false
    };
    return _m;
}

/// Wear, as a role remap applied to the finished part list.
///
/// ⛔ A REMAP RATHER THAN A SECOND SET OF PALETTES, and the difference is the whole reason wear is
/// affordable here. Authoring a worn variant of all seven alloys would be seven more rows in a
/// table nobody can keep coherent; collapsing the top of the ramp says exactly the true thing -
/// a worn medal has lost its polish, so the highlights it used to throw now sit at the value below.
/// At the lowest condition the ramp collapses twice and the medal goes genuinely dull, which is
/// visible at a glance beside a mint one.
function vst_medal_wear_map(_condition) {
    if (_condition >= 0.75) return {};
    if (_condition >= 0.45) return { m4: "m3" };
    return { m4: "m3", m3: "m2", m0: "m1" };
}

/// Patina: flecks of corrosion in the recessed parts of a worn medal.
///
/// Placed from the id hash so a given medal always corrodes in the same places. Skipped entirely
/// below detail 1 - at inventory size these are sub-pixel and all they would do is speckle the
/// face, which reads as noise rather than as age.
function vst_medal_patina(_m, _detail) {
    var _out = [];
    if (_m.condition >= 0.72 || _detail <= 0) return _out;
    var _n = round(lerp(22, 4, _m.condition / 0.72));
    var _rng = vst_rng(vst_hash32(_m.id + ":patina"));
    var _fr = vst_planchet_field_r(_m.planchet);
    for (var _i = 0; _i < _n; _i++) {
        var _a = vst_rng_next(_rng) * VST_TAU;
        var _r = sqrt(vst_rng_next(_rng)) * _fr * 1.30;
        var _sz = lerp(0.008, 0.024, vst_rng_next(_rng));
        array_push(_out, vst_dot(cos(_a) * _r, sin(_a) * _r, _sz, "patina"));
    }
    return _out;
}

/// The struck face: blank, rim furniture, recessed field, device, patina. Unit box, no ribbon.
function vst_medal_face_parts(_m, _detail) {
    var _out = vst_planchet_parts(_m.planchet, _m.rim, _detail);

    if (_m.secret && _m.locked) {
        // A blank. Nothing has been struck into this die yet, and the product says so by showing
        // an empty field with a single sunken lozenge where the device will go - rather than by
        // showing a question mark, which is a UI convention and not an object.
        var _fr0 = vst_planchet_field_r(_m.planchet);
        vst_append(_out, vst_sink(vst_dv_ngon(0, 0, _fr0 * 0.52, 4, VST_TAU / 8),
                                  _fr0 * 0.16, max(1, _detail), "m1"));
    } else {
        var _fr = vst_planchet_field_r(_m.planchet);
        vst_append(_out, vst_place(vst_device_parts(_m.device, _detail),
                                   0, 0, _fr * 2, 0, _fr * 2, undefined));
    }

    vst_append(_out, vst_medal_patina(_m, _detail));
    var _map = vst_medal_wear_map(_m.condition);
    if (variable_struct_names_count(_map) > 0) return vst_map_roles(_out, _map);
    return _out;
}

/// Where the face sits inside the medal's unit box.
///
/// ⚠️ THE BOX IS THE SAME WHETHER THE MEDAL IS SUSPENDED OR NOT, and that is what lets a trophy
/// case lay out ribboned and unribboned medals on one grid without a special case. A suspended
/// medal's planchet is smaller because it is sharing the box with its ribbon; the alternative -
/// letting the box grow upward - breaks the coordinate contract the whole package is built on and
/// makes every layout in the product carry a conditional.
function vst_medal_face_scale(_m) {
    return _m.suspended ? 0.660 : 1.0;
}

function vst_medal_face_cy(_m) {
    return _m.suspended ? 0.168 : 0.0;
}

/// The whole medal, in its own unit box.
function vst_medal_parts(_m, _detail) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_m)) return [];
    var _out = [];
    if (_m.suspended) {
        // ⚠️ HALF-WIDTH 0.190 AND HEIGHT 0.300, AND IT WAS 0.152 BY 0.330. MEASURED BY LOOKING at
        // the first trophy case: a narrow tall drape reads as a TAB stuck on top of the medal
        // rather than as a ribbon the medal hangs from, and it wasted vertical space the planchet
        // needed. Real medal ribbons are close to as wide as the medal is.
        vst_append(_out, vst_ribbon_parts(_m.ribbon, 0, -0.482, 0.190, 0.300, _detail));
    }
    var _s = vst_medal_face_scale(_m);
    vst_append(_out, vst_place(vst_medal_face_parts(_m, _detail),
                               0, vst_medal_face_cy(_m), _s, 0, _s, undefined));
    return _out;
}

/// The surface a medal is drawn with, on a given case paper.
function vst_medal_surface(_m, _case_id) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_m)) return undefined;
    if (_m.locked) return vst_surface_locked(_case_id);
    return vst_surface(_m.alloy, _case_id, _m.dyeA, _m.dyeB);
}

/// ============================================================================================
/// DRAWING
/// ============================================================================================

/// Draw a medal centred at (_x,_y) at _size pixels across, on a case paper.
///
/// ⛔ THE LEGEND IS DROPPED BELOW HERO DETAIL AND THAT IS NOT A COMPROMISE. A legend struck around
/// a rim is 20 or so characters in a circumference; at a 160px card that is about 5px per glyph
/// and at a 40px inventory icon it is under two. Wings/GameMaker/CLAUDE.md records a sibling
/// product whose store sheet headlined "identifiable at 14 pixels" over 44 marks of grey dust.
/// Text that cannot be read is not a feature that survives being shrunk, it is ink in the way of
/// the thing that does survive - the silhouette and the alloy.
function vst_medal_draw(_m, _sur, _x, _y, _size, _detail) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_m)) return;
    var _d = is_undefined(_detail) ? 2 : _detail;
    vst_render_parts(vst_medal_parts(_m, _d), _sur, _x, _y, _size, 0, _size, undefined);

    if (_d < 2 || _m.locked) return;
    var _fs = vst_medal_face_scale(_m);
    var _cy = _y + vst_medal_face_cy(_m) * _size;

    // ⛔ THE LEGEND RADIUS COMES FROM THE FORM, NOT FROM VST_R. MEASURED BY LOOKING at the first
    // hero plate: struck at 0.845 of the NOMINAL radius, the legend on a radiant blank ran straight
    // across the ray tips, where there is no metal for most of its length. vst_planchet_legend_r
    // returns the annulus between the field wall and the rim, which is the only band that is
    // reliably solid on all twelve blanks - and is where a real medal puts its lettering anyway.
    var _ar = _size * _fs * vst_planchet_legend_r(_m.planchet);

    if (_m.name != "") {
        vst_text_arc(_m.name, _x, _cy, _ar, -VST_TAU * 0.25, VST_LEGEND_SWEEP,
                     _size * 0.052, _sur.m0, _sur.m4);
    }
    if (_m.exergue != "") {
        // ⚠️ ON ITS OWN SUNKEN PLATE, and it needed one. Straight text laid over the lower field
        // fought whatever the device was doing there - on the hero plate it landed among the rays
        // and was unreadable. An exergue on a real medal sits in a panel below the device for
        // exactly this reason, and the panel is geometry, so it works on every blank.
        var _ew = _ar * 1.24, _eh = _size * _fs * 0.088;
        vst_render_parts_raw(vst_place(
            vst_sink(vst_round_rect_pts(-_ew * 0.5, -_eh * 0.5, _ew * 0.5, _eh * 0.5,
                                        _eh * 0.34, 3), _eh * 0.20, 2, "m1"),
            _x, _cy + _ar, 1, 0, 1, undefined), _sur);
        vst_text_fit(_m.exergue, _x, _cy + _ar, _ew * 0.86, _eh * 0.62, _sur.m0, _sur.m4);
    }
}

/// Draw the shadow a medal casts onto the felt it is lying on.
///
/// One offset silhouette in the case's own darkest value, away from the lamp. It is two lines of
/// code and it is the difference between a medal sitting IN a case and a medal printed ON one.
function vst_medal_shadow(_m, _sur, _x, _y, _size, _detail) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_struct(_m)) return;
    var _off = _size * 0.030;
    var _parts = vst_medal_parts(_m, min(1, _detail));
    var _flat = {};
    var _rs = ["m0", "m1", "m2", "m3", "m4", "patina",
               "ra0", "ra1", "ra2", "rb0", "rb1", "rb2"];
    for (var _i = 0; _i < array_length(_rs); _i++) variable_struct_set(_flat, _rs[_i], "shadow");
    vst_render_parts(vst_map_roles(_parts, _flat), _sur,
                     _x - VST_LX * _off, _y - VST_LY * _off, _size, 0, _size, undefined);
}
