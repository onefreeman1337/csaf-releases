{
  "$GMScript": "v1",
  "%Name": "vst_medal",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_medal",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}