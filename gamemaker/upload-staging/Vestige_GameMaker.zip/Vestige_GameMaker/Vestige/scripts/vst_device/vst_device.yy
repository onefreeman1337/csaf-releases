{
  "$GMScript": "v1",
  "%Name": "vst_device",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_device",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}