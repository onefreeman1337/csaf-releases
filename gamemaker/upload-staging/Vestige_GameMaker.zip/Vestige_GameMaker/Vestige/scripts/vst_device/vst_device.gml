/// VESTIGE - vst_device. THE CORPUS. Forty-two devices, six in each of seven award categories.
///
/// A device is the charge struck into the field of a medal. It is the thing a player looks at, and
/// forty-two of them, authored by hand and coherent with each other, is the part of this product
/// that cannot be produced cheaply. Logic is not a moat - a language model writes achievement rules
/// in an afternoon. A corpus is.
///
/// -- HOW A DEVICE IS AUTHORED ------------------------------------------------------------------
/// Every device is a struct of four lists, all in the unit box [-0.5, 0.5], y DOWN:
///
///   solids  closed outlines. Each becomes a raised mass with its own lit dome (vst_relief).
///   lines   open or closed paths. Each becomes an INCISED groove.
///   bosses  [x, y, r] raised domes - rivets, eyes, studs, pommels.
///   pits    [x, y, r] sunken pockets - eye sockets, punch marks, drilled holes.
///
/// ⛔ EVERY SOLID IS CONVEX OR VERY NEARLY SO, AND COMPLEX DEVICES ARE ASSEMBLIES OF SEVERAL. That
/// is a hard rule with two reasons behind it, one mechanical and one about how the product looks.
///
///   MECHANICAL: the primitive layer fills a closed outline as a triangle fan from an interior
///   anchor, which requires the outline to be star-shaped about that anchor. An anvil drawn as one
///   outline is not - its horn hides behind its own waist from most interior points - and the fill
///   silently loses a wedge. This wing has shipped that defect before, on a crescent.
///
///   VISUAL, and it is the more important half: a struck device IS an assembly of planes. An anvil
///   built as a body, a horn, a waist and a base has four separate domes catching the light at four
///   angles, which is what makes it look forged. The same anvil as one silhouette with one bevel
///   round the outside looks like a sticker of an anvil, however clean the outline is. The rule
///   that keeps the fan correct is the same rule that makes the metal read.
///
/// ⚠️ A NOTE IS A CONSTRAINT ON A SHAPE, NOT A SPECIFICATION OF IT. Wings/GameMaker/CLAUDE.md
/// records a sibling product where "a circle with a tail" was authored and shipped reading as a
/// saucepan, and a default compass rose that read as devil horns. Every device in this file is
/// rendered onto a store sheet at three sizes and LOOKED AT. The comments below say what each one
/// is meant to be; they are not evidence that it is.
/// ============================================================================================

/// ============================================================================================
/// AUTHORING HELPERS - the vocabulary the corpus is written in
/// ============================================================================================

/// An axis-aligned rectangle.
function vst_dv_rect(_x0, _y0, _x1, _y1) {
    return [[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]];
}

/// A circle.
function vst_dv_disc(_cx, _cy, _r, _n) {
    return vst_ellipse_pts(_cx, _cy, _r, _r, is_undefined(_n) ? 18 : _n);
}

/// An ellipse.
function vst_dv_ell(_cx, _cy, _rx, _ry, _n) {
    return vst_ellipse_pts(_cx, _cy, _rx, _ry, is_undefined(_n) ? 18 : _n);
}

/// A triangle.
function vst_dv_tri(_ax, _ay, _bx, _by, _cx, _cy) {
    return [[_ax, _ay], [_bx, _by], [_cx, _cy]];
}

/// A regular polygon.
function vst_dv_ngon(_cx, _cy, _r, _n, _ph) {
    return vst_star_pts(_cx, _cy, _r, _n, is_undefined(_ph) ? 0 : _ph);
}

/// A thick straight bar between two points - the workhorse of this corpus. Shafts, hafts, blades,
/// mast, spokes and rails are all this.
function vst_dv_bar(_x0, _y0, _x1, _y1, _hw) {
    var _dx = _x1 - _x0, _dy = _y1 - _y0;
    var _L = point_distance(0, 0, _dx, _dy);
    if (_L == 0) _L = 1;
    var _nx = -_dy / _L * _hw, _ny = _dx / _L * _hw;
    return [[_x0 + _nx, _y0 + _ny], [_x1 + _nx, _y1 + _ny],
            [_x1 - _nx, _y1 - _ny], [_x0 - _nx, _y0 - _ny]];
}

/// A bar whose half-width differs at the two ends. A haft that tapers reads as turned wood; one of
/// constant width reads as extruded, which is the loudest tell of programmer art.
function vst_dv_taper(_x0, _y0, _x1, _y1, _hw0, _hw1) {
    var _dx = _x1 - _x0, _dy = _y1 - _y0;
    var _L = point_distance(0, 0, _dx, _dy);
    if (_L == 0) _L = 1;
    var _ux = -_dy / _L, _uy = _dx / _L;
    return [[_x0 + _ux * _hw0, _y0 + _uy * _hw0], [_x1 + _ux * _hw1, _y1 + _uy * _hw1],
            [_x1 - _ux * _hw1, _y1 - _uy * _hw1], [_x0 - _ux * _hw0, _y0 - _uy * _hw0]];
}

/// A symmetric trapezoid: width _w0 at _y0, width _w1 at _y1.
function vst_dv_trap(_cx, _y0, _w0, _y1, _w1) {
    return [[_cx - _w0, _y0], [_cx + _w0, _y0], [_cx + _w1, _y1], [_cx - _w1, _y1]];
}

/// A pointed almond - a leaf, a petal, a blade tip, a sail. Six points: two tips and two shoulders
/// each side, which is enough curve to read and few enough points to bevel cheaply.
function vst_dv_leaf(_cx, _cy, _L, _W, _ang) {
    var _c = cos(_ang), _s = sin(_ang);
    var _p = [[_L, 0], [_L * 0.35, _W], [-_L * 0.35, _W * 0.86],
              [-_L, 0], [-_L * 0.35, -_W * 0.86], [_L * 0.35, -_W]];
    var _out = array_create(6);
    for (var _i = 0; _i < 6; _i++) {
        _out[_i] = [_cx + _p[_i][0] * _c - _p[_i][1] * _s,
                    _cy + _p[_i][0] * _s + _p[_i][1] * _c];
    }
    return _out;
}

/// Rotate an outline about a point.
function vst_dv_rot(_pts, _ang, _cx, _cy) {
    var _c = cos(_ang), _s = sin(_ang);
    var _ox = is_undefined(_cx) ? 0 : _cx, _oy = is_undefined(_cy) ? 0 : _cy;
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _x = _pts[_i][0] - _ox, _y = _pts[_i][1] - _oy;
        _out[_i] = [_ox + _x * _c - _y * _s, _oy + _x * _s + _y * _c];
    }
    return _out;
}

/// Mirror an outline in the vertical axis, reversing the point order so the winding is preserved.
///
/// ⚠️ WITHOUT THE REVERSAL the mirrored copy winds the other way, its outward normals point inward,
/// and the bevel lights it from the wrong side - so a pair of symmetric wings ends up with one lit
/// and one in shadow. vst_bevel measures the winding rather than assuming it, so this would not
/// crash or vanish: it would quietly draw the wrong picture, which is worse.
function vst_dv_mirror(_pts) {
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _out[_i] = [-_pts[_n - 1 - _i][0], _pts[_n - 1 - _i][1]];
    return _out;
}

/// A blank device struct to fill in.
///
/// ⚠️ `sunk` WAS ADDED AFTER THE FIRST CORPUS WAS DRAWN AND LOOKED AT. Four devices needed a
/// recessed AREA rather than a recessed circle or an incised line - a flame's inner tongue, a
/// gem's table, a signet's seal, a shuttle's cavity - and every one of them had been authored as
/// an incised outline instead, which at any size below hero collapses into a scribble inside the
/// mass. A pit is a drilled hole and a line is a scratch; a sunk is a machined pocket, and it is
/// the one that reads.
function vst_dv_new(_id, _cat, _label) {
    return { id: _id, category: _cat, label: _label,
             solids: [], sunk: [], lines: [], bosses: [], pits: [] };
}

/// ============================================================================================
/// THE CATEGORIES
/// ============================================================================================

function vst_category_ids() {
    return ["valour", "wayfaring", "craft", "lore", "bond", "endurance", "hoard"];
}

function vst_category_label(_c) {
    switch (_c) {
        case "valour":    return "VALOUR";
        case "wayfaring": return "WAYFARING";
        case "craft":     return "CRAFT";
        case "lore":      return "LORE";
        case "bond":      return "BOND";
        case "endurance": return "ENDURANCE";
        default:          return "HOARD";
    }
}

/// The six devices of one category, in authored order.
function vst_category_devices(_c) {
    switch (_c) {
        case "valour":    return ["blades", "gauntlet", "bulwark", "reliquary", "barb", "warhorn"];
        case "wayfaring": return ["compass", "peaks", "sail", "spoor", "lantern", "waymark"];
        case "craft":     return ["anvil", "hammer", "crucible", "cogwheel", "shuttle", "chisel"];
        case "lore":      return ["tome", "quill", "key", "owl", "watcher", "scroll"];
        case "bond":      return ["handclasp", "chalice", "visor", "signet", "banner", "harp"];
        case "endurance": return ["hourglass", "heart", "flame", "surge", "thorn", "sun"];
        default:          return ["strongbox", "coins", "gems", "amphora", "sack", "comb"];
    }
}

/// Every device id in the corpus, category by category.
function vst_device_ids() {
    var _cs = vst_category_ids();
    var _out = [];
    for (var _i = 0; _i < array_length(_cs); _i++) {
        vst_append(_out, vst_category_devices(_cs[_i]));
    }
    return _out;
}

/// Which category a device belongs to, or "" if the id is unknown.
function vst_device_category(_id) {
    var _cs = vst_category_ids();
    for (var _i = 0; _i < array_length(_cs); _i++) {
        var _ds = vst_category_devices(_cs[_i]);
        for (var _k = 0; _k < array_length(_ds); _k++) if (_ds[_k] == _id) return _cs[_i];
    }
    return "";
}

/// ============================================================================================
/// THE CORPUS
/// ============================================================================================

function vst_device(_id) {
    var _d = vst_dv_new(_id, vst_device_category(_id), string_upper(_id));

    switch (_id) {

    /* -- VALOUR ------------------------------------------------------------------------------ */

    // Two swords crossed in saltire. Each blade is a taper so it comes to a point; the crossguards
    // and the two pommels are what stop it reading as a plain X.
    // ⛔ THICKER THAN IT WAS, AND THE INK FLOOR IS WHY. MEASURED 2026-08-25: the first authoring
    // filled 0.13 of its grid against a floor of 0.16 - two hairlines and two studs, adrift in a
    // field the other forty-one devices fill. Two blades on a medal are a heraldic charge, not a
    // technical drawing of two swords: they carry the field.
    case "blades":
        _d.label = "CROSSED BLADES";
        _d.solids = [
            // ⚠️ THE TIP HALF-WIDTH IS 0.040 AND IT WAS 0.014. A blade that tapers to almost nothing
            // is anatomically right and reads as a NEEDLE on a struck medal, because the taper
            // spends four fifths of the blade's length below the renderer's one-pixel floor at any
            // size under about 400px. Heraldic swords are drawn nearly parallel-sided for exactly
            // this reason.
            vst_dv_taper(-0.30, 0.34, 0.31, -0.38, 0.082, 0.040),
            vst_dv_taper( 0.30, 0.34, -0.31, -0.38, 0.082, 0.040),
            vst_dv_bar(-0.38, 0.145, -0.055, 0.145, 0.042),
            vst_dv_bar( 0.055, 0.145,  0.38, 0.145, 0.042)
        ];
        _d.bosses = [[-0.305, 0.335, 0.076], [0.305, 0.335, 0.076]];
        _d.lines = [{ pts: [[-0.235, 0.245], [0.255, -0.315]], closed: false, w: 0.016 },
                    { pts: [[ 0.235, 0.245], [-0.255, -0.315]], closed: false, w: 0.016 }];
        break;

    // ⛔ REDRAWN AFTER LOOKING AT IT. The first authoring - a palm trapezoid, a separate knuckle
    // rectangle above it and a thumb taper off to one side - rendered as a striped box with a flag
    // stuck on. Every piece was where the note said, and the note was a constraint on a shape
    // rather than a specification of one.
    //
    // What makes a fist read at a hundred pixels is not the outline: it is FOUR KNUCKLE DOMES
    // ALONG ONE EDGE of a single mass, with the grooves between them, and a cuff below the wrist.
    // So the hand is now one octagonal mass with the knuckles overlapping its top edge, and the
    // thumb crosses in FRONT of it rather than sticking out of the side.
    case "gauntlet":
        _d.label = "GAUNTLET";
        _d.solids = [
            [[-0.275, -0.185], [-0.200, -0.275], [0.200, -0.275], [0.275, -0.185],
             [0.275, 0.150], [0.200, 0.235], [-0.200, 0.235], [-0.275, 0.150]],
            vst_dv_trap(0, 0.235, 0.300, 0.440, 0.235),
            vst_dv_taper(-0.300, 0.055, 0.105, -0.030, 0.088, 0.068)
        ];
        _d.bosses = [[-0.190, -0.250, 0.076], [-0.064, -0.272, 0.080],
                     [ 0.064, -0.272, 0.080], [ 0.190, -0.250, 0.076]];
        _d.lines = [{ pts: [[-0.127, -0.190], [-0.127, 0.090]], closed: false, w: 0.022 },
                    { pts: [[ 0.000, -0.205], [ 0.000, 0.090]], closed: false, w: 0.022 },
                    { pts: [[ 0.127, -0.190], [ 0.127, 0.090]], closed: false, w: 0.022 },
                    { pts: [[-0.285, 0.320], [0.285, 0.320]], closed: false, w: 0.024 }];
        break;

    // A tower shield: tall, flat-topped, with a vertical rib and a central boss. The rib is a
    // separate raised mass rather than an incised line so it catches the light down one side.
    case "bulwark":
        _d.label = "TOWER SHIELD";
        _d.solids = [
            [[-0.245, -0.400], [0.245, -0.400], [0.265, -0.120], [0.190, 0.250],
             [0.000, 0.430], [-0.190, 0.250], [-0.265, -0.120]],
            vst_dv_bar(0, -0.360, 0, 0.360, 0.055)
        ];
        _d.bosses = [[0, 0.00, 0.105]];
        _d.pits = [[-0.150, -0.250, 0.038], [0.150, -0.250, 0.038]];
        _d.lines = [{ pts: [[-0.235, -0.330], [0.235, -0.330]], closed: false, w: 0.018 }];
        break;

    // A skull. Deliberately blunt and frontal - a three-quarter skull needs shading this corpus
    // does not have, and a frontal one is legible at 20 pixels, which is where it has to work.
    case "reliquary":
        _d.label = "SKULL";
        _d.solids = [
            vst_dv_ell(0, -0.100, 0.290, 0.280, 20),
            vst_dv_trap(0, 0.130, 0.185, 0.330, 0.145),
            vst_dv_bar(-0.185, 0.150, 0.185, 0.150, 0.040)
        ];
        _d.pits = [[-0.128, -0.120, 0.088], [0.128, -0.120, 0.088], [0, 0.020, 0.048]];
        _d.lines = [{ pts: [[-0.110, 0.245], [-0.110, 0.325]], closed: false, w: 0.020 },
                    { pts: [[ 0.000, 0.245], [ 0.000, 0.330]], closed: false, w: 0.020 },
                    { pts: [[ 0.110, 0.245], [ 0.110, 0.325]], closed: false, w: 0.020 }];
        break;

    // A broadhead on its shaft, fletched. The barbs are separate solids so their inner edges are
    // lit independently of the head - a single seven-point outline reads as a paper dart.
    //
    // ⛔ IT WAS THINNER AND THE SUITE REFUSED IT. MEASURED 2026-08-25: the first authoring filled
    // 0.11 of its ink grid against a floor of 0.16 - the emptiest device in the corpus by a wide
    // margin, and it looked it, a hairline arrow adrift in a field the other forty-one fill. The
    // fix is not a bigger arrow, it is a COMPLETE one: the head widened to the field, the shaft
    // given real thickness, and two fletching vanes added at the nock. A device on a medal is a
    // heraldic charge and it is supposed to fill its field; the floor is what catches an author
    // drawing an illustration instead.
    case "barb":
        _d.label = "BROADHEAD";
        _d.solids = [
            vst_dv_tri(0, -0.440, 0.250, 0.020, -0.250, 0.020),
            vst_dv_tri(-0.250, 0.020, -0.088, -0.020, -0.175, 0.235),
            vst_dv_tri( 0.250, 0.020,  0.088, -0.020,  0.175, 0.235),
            vst_dv_bar(0, -0.020, 0, 0.430, 0.062),
            vst_dv_leaf(-0.155, 0.300, 0.175, 0.078, -1.16),
            vst_dv_leaf( 0.155, 0.300, 0.175, 0.078,  1.16)
        ];
        _d.lines = [{ pts: [[0, -0.390], [0, -0.010]], closed: false, w: 0.018 },
                    { pts: [[-0.115, 0.235], [0.115, 0.235]], closed: false, w: 0.018 }];
        _d.bosses = [[0, 0.405, 0.058]];
        break;

    // ⛔ REDRAWN AFTER LOOKING AT IT. The first authoring chained three tapers end to end to fake a
    // curve. Each taper is bevelled on its OWN outline, so every join between them got a lit edge
    // and a shadowed one running straight across the horn - and the result read as three
    // disconnected chevrons rather than as one object. That is a general rule this corpus now
    // follows: a chain of masses reads as a chain. Where the shape must be continuous, it is ONE
    // mass, and the assembly rule applies only where the real object genuinely has separate planes.
    //
    // So the horn is one straight tapered body plus one flared bell, which is what a war horn
    // actually is, and the two masses meet at a real edge rather than a fake one.
    case "warhorn":
        _d.label = "WAR HORN";
        // ⛔ THE THIRD ATTEMPT, AND THE SECOND ONE FAILED FOR THE OPPOSITE REASON TO THE FIRST.
        // Attempt one chained three straight tapers to fake a curve and read as three chevrons,
        // because every join got its own bevel. Attempt two removed the joins by making the horn
        // straight - and a straight tapered thing with a flare on the end is a WEDGE. The curve was
        // never decoration: it is the only thing separating a horn from a doorstop.
        //
        // So the body is now ONE outline built from a sampled bezier spine with a width that grows
        // along it - one mass, one bevel, no internal joins, and genuinely curved. That is what the
        // primitive layer's curve sampler is for, and it should have been the first answer.
        var _hsp = vst_qbez([-0.360, 0.185], [-0.030, 0.395], [0.270, -0.010], 7);
        var _hn = array_length(_hsp);
        var _hout = array_create(_hn * 2);
        for (var _hi = 0; _hi < _hn; _hi++) {
            var _hp = _hsp[max(0, _hi - 1)], _hq = _hsp[min(_hn - 1, _hi + 1)];
            var _hdx = _hq[0] - _hp[0], _hdy = _hq[1] - _hp[1];
            var _hl = point_distance(0, 0, _hdx, _hdy);
            if (_hl == 0) _hl = 1;
            var _hnx = -_hdy / _hl, _hny = _hdx / _hl;
            var _hw = lerp(0.052, 0.175, _hi / (_hn - 1));
            _hout[_hi] = [_hsp[_hi][0] + _hnx * _hw, _hsp[_hi][1] + _hny * _hw];
            _hout[_hn * 2 - 1 - _hi] = [_hsp[_hi][0] - _hnx * _hw, _hsp[_hi][1] - _hny * _hw];
        }
        _d.solids = [
            _hout,
            vst_dv_taper(0.270, -0.010, 0.330, -0.090, 0.175, 0.210),
            vst_dv_disc(-0.375, 0.195, 0.085, 14)
        ];
        _d.lines = [{ pts: [[-0.155, 0.365], [-0.120, 0.190]], closed: false, w: 0.026 },
                    { pts: [[ 0.045, 0.290], [ 0.055, 0.100]], closed: false, w: 0.028 }];
        break;

    /* -- WAYFARING --------------------------------------------------------------------------- */

    // A compass rose. FOUR long points and four short ones, and the short set is what keeps it
    // from reading as a pair of horns - a sibling product in this wing shipped exactly that.
    case "compass":
        _d.label = "COMPASS ROSE";
        _d.solids = [
            vst_dv_tri(0, -0.440, 0.075, 0, -0.075, 0),
            vst_dv_tri(0,  0.440, 0.075, 0, -0.075, 0),
            vst_dv_tri(-0.440, 0, 0, 0.075, 0, -0.075),
            vst_dv_tri( 0.440, 0, 0, 0.075, 0, -0.075),
            vst_dv_rot(vst_dv_tri(0, -0.245, 0.048, 0, -0.048, 0), VST_TAU / 8),
            vst_dv_rot(vst_dv_tri(0, -0.245, 0.048, 0, -0.048, 0), VST_TAU * 3 / 8),
            vst_dv_rot(vst_dv_tri(0, -0.245, 0.048, 0, -0.048, 0), VST_TAU * 5 / 8),
            vst_dv_rot(vst_dv_tri(0, -0.245, 0.048, 0, -0.048, 0), VST_TAU * 7 / 8)
        ];
        _d.bosses = [[0, 0, 0.070]];
        _d.lines = [{ pts: vst_dv_disc(0, 0, 0.300, 28), closed: true, w: 0.016 }];
        break;

    // Three summits standing on a mount, with a snowline. The snow is an incised line following the
    // ridge, so the peak above it stays proud and the line reads as a boundary rather than a
    // scratch.
    //
    // ⛔ THE MOUNT IS A SOLID MASS AND IT USED TO BE A DRAWN LINE. MEASURED 2026-08-25: with a line
    // for a base this device filled 0.15 of its grid, under the floor. It is the fourth device the
    // ink floor has caught and all four were the same mistake - drawing the SUBJECT and leaving the
    // rest of the field as air. A charge on a medal stands on something.
    case "peaks":
        _d.label = "SUMMITS";
        _d.solids = [
            vst_dv_tri(-0.100, -0.400, 0.230, 0.260, -0.430, 0.260),
            vst_dv_tri( 0.250, -0.230, 0.460, 0.260,  0.040, 0.260),
            vst_dv_tri(-0.370, -0.090, -0.180, 0.260, -0.460, 0.260),
            vst_dv_rect(-0.460, 0.255, 0.460, 0.420)
        ];
        _d.lines = [{ pts: [[-0.215, -0.165], [-0.100, -0.300], [-0.030, -0.190],
                            [ 0.030, -0.260], [ 0.105, -0.115]], closed: false, w: 0.026 },
                    { pts: [[ 0.170, -0.100], [ 0.250, -0.185], [ 0.330, -0.100]],
                      closed: false, w: 0.024 },
                    { pts: [[-0.440, 0.340], [ 0.440, 0.340]], closed: false, w: 0.022 }];
        break;

    // A ship under sail. The hull is a shallow trapezoid, not a crescent, so it fills correctly and
    // so the waterline can be incised straight across it.
    case "sail":
        _d.label = "UNDER SAIL";
        _d.solids = [
            vst_dv_trap(0, 0.190, 0.400, 0.360, 0.230),
            vst_dv_bar(0.010, -0.400, 0.010, 0.190, 0.030),
            [[-0.030, -0.360], [-0.030, 0.120], [-0.330, 0.120]],
            [[ 0.055, -0.290], [ 0.055, 0.120], [ 0.290, 0.120]]
        ];
        _d.lines = [{ pts: [[-0.400, 0.240], [0.400, 0.240]], closed: false, w: 0.022 },
                    { pts: [[-0.300, 0.070], [-0.030, 0.070]], closed: false, w: 0.016 }];
        _d.bosses = [[0.010, -0.415, 0.042]];
        break;

    // Two footprints, staggered. The toes are bosses because at inventory size the print outline
    // alone is an oval and could be anything.
    case "spoor":
        _d.label = "SPOOR";
        _d.solids = [
            vst_dv_rot(vst_dv_ell(-0.170, -0.100, 0.115, 0.190, 16), 0.16, -0.170, -0.100),
            vst_dv_rot(vst_dv_ell( 0.175,  0.140, 0.115, 0.190, 16), -0.16, 0.175, 0.140)
        ];
        _d.bosses = [[-0.235, -0.290, 0.041], [-0.150, -0.320, 0.044], [-0.065, -0.300, 0.038],
                     [ 0.115, -0.050, 0.038], [ 0.200, -0.075, 0.044], [ 0.278, -0.045, 0.041]];
        _d.pits = [[-0.170, -0.060, 0.055], [0.175, 0.180, 0.055]];
        break;

    // A storm lantern. The flame inside is a separate raised mass sitting on a sunken pane, which
    // is what makes the glass read as glass.
    case "lantern":
        _d.label = "LANTERN";
        _d.solids = [
            vst_dv_trap(0, -0.230, 0.210, -0.150, 0.165),
            vst_dv_trap(0, -0.150, 0.165, 0.230, 0.195),
            vst_dv_trap(0, 0.230, 0.235, 0.330, 0.195),
            vst_dv_bar(-0.155, -0.395, 0.155, -0.395, 0.032),
            [[0, -0.010], [0.060, 0.070], [0, 0.170], [-0.060, 0.070]]
        ];
        _d.lines = [{ pts: vst_dv_rect(-0.130, -0.110, 0.130, 0.185), closed: true, w: 0.020 },
                    { pts: [[-0.135, -0.395], [-0.135, -0.240]], closed: false, w: 0.018 },
                    { pts: [[ 0.135, -0.395], [ 0.135, -0.240]], closed: false, w: 0.018 }];
        _d.bosses = [[0, -0.290, 0.048]];
        break;

    // A waymarker stone with a cut arrow. The cap is a separate mass so the stone has a top plane
    // catching the light, which is the whole difference between a standing stone and a rectangle.
    case "waymark":
        _d.label = "WAYMARK";
        _d.solids = [
            vst_dv_trap(0, -0.290, 0.190, 0.330, 0.245),
            vst_dv_trap(0, -0.380, 0.150, -0.290, 0.205),
            vst_dv_bar(-0.330, 0.365, 0.330, 0.365, 0.048)
        ];
        _d.lines = [{ pts: [[-0.075, 0.075], [0.105, 0.075]], closed: false, w: 0.034 },
                    { pts: [[ 0.020, -0.010], [0.130, 0.075], [0.020, 0.160]],
                      closed: false, w: 0.030 },
                    { pts: [[-0.145, -0.150], [0.145, -0.150]], closed: false, w: 0.020 }];
        break;

    /* -- CRAFT ------------------------------------------------------------------------------- */

    // An anvil, as four masses: horn, body, waist, base. See the header - this is the device that
    // the convexity rule was written for.
    case "anvil":
        _d.label = "ANVIL";
        _d.solids = [
            vst_dv_rect(-0.230, -0.290, 0.310, -0.110),
            vst_dv_tri(-0.230, -0.285, -0.230, -0.135, -0.455, -0.190),
            vst_dv_trap(0.045, -0.110, 0.145, 0.140, 0.105),
            vst_dv_trap(0.045, 0.140, 0.105, 0.330, 0.290),
            vst_dv_rect(-0.290, 0.330, 0.380, 0.415)
        ];
        _d.lines = [{ pts: [[-0.215, -0.245], [0.295, -0.245]], closed: false, w: 0.020 }];
        _d.pits = [[0.230, -0.200, 0.048]];
        break;

    // ⛔ THICKENED AFTER LOOKING AT IT. The first authoring had a head only 0.205 deep and a haft
    // 0.124 wide, and the whole thing read as a SIGNPOST - a flat plate with an arrow on the right,
    // on a pole. A smith's hammer is mostly head by mass and the haft is a thing you can grip; both
    // numbers were drawn from the silhouette of a diagram rather than the proportions of a tool.
    case "hammer":
        _d.label = "SMITH'S HAMMER";
        _d.solids = [
            vst_dv_rect(-0.340, -0.360, 0.185, -0.070),
            vst_dv_tri(0.185, -0.340, 0.405, -0.215, 0.185, -0.090),
            vst_dv_taper(-0.100, -0.075, -0.030, 0.400, 0.082, 0.062),
            vst_dv_bar(-0.190, 0.400, 0.130, 0.400, 0.062)
        ];
        _d.sunk = [vst_dv_rect(-0.135, -0.300, -0.030, -0.130)];
        _d.lines = [{ pts: [[-0.320, -0.320], [-0.320, -0.110]], closed: false, w: 0.024 },
                    { pts: [[-0.088, 0.060], [-0.060, 0.320]], closed: false, w: 0.018 }];
        break;

    // A crucible over flame. The pour lip is a small separate mass and it is the single detail
    // that separates this from a plant pot.
    case "crucible":
        _d.label = "CRUCIBLE";
        _d.solids = [
            vst_dv_trap(0, -0.280, 0.265, 0.130, 0.165),
            vst_dv_bar(-0.300, -0.280, 0.300, -0.280, 0.052),
            vst_dv_tri(0.265, -0.330, 0.400, -0.240, 0.255, -0.215),
            // ⚠️ ONE FLAME BAND WITH THREE PEAKS, NOT THREE SEPARATE TONGUES. Authored as three
            // detached lozenges it read as three diamonds under a bucket - and it was the same
            // failure as the war horn from the other direction: a real fire under a crucible is
            // one body of flame, so drawing it as three objects makes three objects.
            // ⚠️ THE PEAKS REACH ABOVE THE POT'S BASE, and in the first version they did not - so
            // the flame sat entirely below the crucible and read as two triangles on a shelf. Fire
            // under a vessel LICKS UP THE SIDES; that overlap is the whole reason it reads as heat
            // rather than as a stand.
            [[-0.330, 0.440], [-0.240, 0.135], [-0.120, 0.320], [0.000, 0.055],
             [0.120, 0.320], [0.240, 0.135], [0.330, 0.440]]
        ];
        _d.lines = [{ pts: [[-0.230, -0.190], [0.230, -0.190]], closed: false, w: 0.020 }];
        break;

    // A cogwheel: a ten-tooth polygon, a hub and three spokes. The hub is sunk and the spokes are
    // raised, so the wheel has a front plane and a back one.
    case "cogwheel":
        _d.label = "COGWHEEL";
        _d.solids = [
            vst_dv_ngon(0, 0, 0.415, 20, 0),
            vst_dv_disc(0, 0, 0.130, 16)
        ];
        for (var _i = 0; _i < 10; _i++) {
            var _a = (_i / 10) * VST_TAU;
            var _cx = cos(_a) * 0.400, _cy = sin(_a) * 0.400;
            array_push(_d.solids, vst_dv_rot(vst_dv_rect(_cx - 0.058, _cy - 0.058,
                                                         _cx + 0.058, _cy + 0.058), _a, _cx, _cy));
        }
        for (var _i = 0; _i < 3; _i++) {
            var _a = (_i / 3) * VST_TAU - VST_TAU * 0.25;
            array_push(_d.solids, vst_dv_bar(0, 0, cos(_a) * 0.330, sin(_a) * 0.330, 0.052));
        }
        _d.pits = [[0, 0, 0.085]];
        break;

    // ⛔ REDRAWN AFTER LOOKING AT IT. The first authoring was a tilted almond with a thin bar
    // across it and a thread line floating above, and it read as a flat lens - an eye, next to a
    // device that IS an eye two rows down. A shuttle is recognised by its CAVITY: a boat-shaped
    // body with a machined pocket, and a bobbin sitting in the pocket. The pocket is why `sunk`
    // exists.
    case "shuttle":
        _d.label = "SHUTTLE";
        // ⚠️ ONE LARGE POCKET, NOT TWO SMALL ONES. Split either side of the bobbin they rendered as
        // two dots and the device went back to reading as a lens. A shuttle's cavity is a single
        // slot running most of its length with the spindle lying across it, and that is what makes
        // the silhouette a boat rather than an eye.
        _d.solids = [
            vst_dv_leaf(0, 0, 0.450, 0.200, 0),
            vst_dv_bar(-0.175, 0, 0.175, 0, 0.072)
        ];
        _d.sunk = [vst_dv_rect(-0.250, -0.108, 0.250, 0.108)];
        _d.bosses = [[-0.175, 0, 0.082], [0.175, 0, 0.082]];
        _d.lines = [{ pts: [[-0.390, -0.048], [-0.250, -0.018]], closed: false, w: 0.020 },
                    { pts: [[ 0.390, -0.048], [ 0.250, -0.018]], closed: false, w: 0.020 },
                    { pts: [[-0.105, -0.038], [0.105, -0.038]], closed: false, w: 0.018 },
                    { pts: [[-0.105,  0.038], [0.105,  0.038]], closed: false, w: 0.018 }];
        break;

    // A chisel biting into stone, with the chip it has raised. The chip is the whole point: a
    // chisel on its own is a wedge, and a chisel with a chip is a chisel WORKING.
    //
    // ⛔ THICKENED, AND GIVEN THE MUSHROOMED HEAD IT WAS MISSING. MEASURED 2026-08-25: the first
    // authoring filled 0.14 of its grid against a floor of 0.16 - the emptiest device once the
    // crossed blades were fixed, and empty for the same reason: it was drawn at the proportions of
    // a real tool rather than of a charge on a medal. The head is also the detail that says the
    // thing has been STRUCK, which is a good joke on a product about striking.
    case "chisel":
        _d.label = "CHISEL";
        _d.solids = [
            vst_dv_taper(0.235, -0.400, 0.150, -0.245, 0.130, 0.100),
            vst_dv_taper(0.185, -0.270, -0.020, 0.150, 0.115, 0.072),
            vst_dv_tri(-0.020, 0.150, 0.080, 0.105, -0.120, 0.270),
            vst_dv_rect(-0.460, 0.270, 0.460, 0.440),
            vst_dv_tri(-0.265, 0.270, -0.085, 0.270, -0.180, 0.115)
        ];
        _d.lines = [{ pts: [[0.130, -0.210], [-0.010, 0.075]], closed: false, w: 0.020 },
                    { pts: [[-0.440, 0.355], [0.440, 0.355]], closed: false, w: 0.022 }];
        break;

    /* -- LORE -------------------------------------------------------------------------------- */

    // An open book. Two page masses angled apart, a spine between them, and four incised text
    // lines per page. The text lines are what stop it reading as a paper aeroplane.
    case "tome":
        _d.label = "OPEN BOOK";
        _d.solids = [
            [[-0.430, -0.150], [-0.030, -0.235], [-0.030, 0.245], [-0.430, 0.310]],
            [[ 0.430, -0.150], [ 0.030, -0.235], [ 0.030, 0.245], [ 0.430, 0.310]],
            vst_dv_bar(0, -0.240, 0, 0.255, 0.038)
        ];
        _d.lines = [];
        for (var _i = 0; _i < 4; _i++) {
            var _y = -0.115 + _i * 0.100;
            array_push(_d.lines, { pts: [[-0.375, _y + 0.048], [-0.085, _y]], closed: false, w: 0.024 });
            array_push(_d.lines, { pts: [[ 0.085, _y], [ 0.375, _y + 0.048]], closed: false, w: 0.024 });
        }
        break;

    // A quill. The vane is a leaf, the shaft a taper, the nib a small triangle - three masses, so
    // the pen has a spine down it rather than being a flat feather shape.
    case "quill":
        _d.label = "QUILL";
        // ⛔ THE NIB WAS THREE NEARLY-COLLINEAR POINTS AND THE SUITE CAUGHT IT. MEASURED
        // 2026-08-25: the authored triangle (-0.230,0.330) (-0.185,0.290) (-0.330,0.420) has a
        // signed area of 0.00005 - a sliver about a twentieth of a pixel wide at hero size. It
        // would have drawn as nothing at all, and nothing at all is exactly what the fan primitive
        // draws for a degenerate outline: no error, no warning, just a quill with no point on it.
        // The area assertion exists for this and it fired on the first run.
        // ⚠️ THE VANE IS ALIGNED TO THE SHAFT, AND IT WAS NOT. The first authoring set the leaf's
        // long axis at 0.90 radians while the shaft runs at 2.09, so the feather crossed its own
        // quill at sixty degrees - which read acceptably at hero size and is simply wrong. It is
        // now centred on the shaft's midpoint and turned to match it, and enlarged, which also
        // takes this device off the ink floor it was under.
        // ⛔ NARROWER THAN THE LAST ATTEMPT, AND THE BARBS RUN ONE WAY. Widening the vane to clear
        // the ink floor turned it into a PINECONE: a fat symmetric lens with strokes crossing it
        // end to end reads as a lattice, not as a feather. Barbs on a real feather leave the shaft
        // at an angle and stop at the edge; drawn as full-width chords they are just hatching, and
        // hatching inside an oval is a pattern rather than a thing.
        _d.solids = [
            vst_dv_leaf(-0.020, -0.035, 0.395, 0.132, 2.093),
            vst_dv_taper(0.190, -0.400, -0.230, 0.330, 0.042, 0.070),
            vst_dv_tri(-0.230, 0.330, -0.150, 0.352, -0.335, 0.432)
        ];
        _d.lines = [];
        for (var _i = 0; _i < 7; _i++) {
            // Barbs leaving the shaft on ONE side, swept back toward the nib. Derived from the
            // shaft's own parameter so they stay attached to it if either is moved.
            var _t = 0.14 + (_i / 6) * 0.70;
            var _sx = lerp(0.190, -0.230, _t), _sy = lerp(-0.400, 0.330, _t);
            var _o = (1 - abs(_t - 0.48) * 1.6) * 0.125;
            array_push(_d.lines, { pts: [[_sx, _sy],
                                          [_sx - 0.940 * _o - 0.110, _sy - 0.342 * _o + 0.062]],
                                    closed: false, w: 0.018 });
        }
        break;

    // A key. Bow, shank, two wards. Wards on ONE side only - a key with symmetric wards is a
    // ratchet, and the asymmetry is what makes it read instantly.
    case "key":
        _d.label = "KEY";
        _d.solids = [
            vst_dv_ngon(-0.250, 0, 0.185, 6, VST_TAU / 12),
            vst_dv_bar(-0.090, 0, 0.415, 0, 0.055),
            vst_dv_rect(0.155, 0.055, 0.225, 0.245),
            vst_dv_rect(0.310, 0.055, 0.375, 0.190)
        ];
        _d.pits = [[-0.250, 0, 0.088]];
        _d.lines = [{ pts: [[-0.055, -0.030], [0.395, -0.030]], closed: false, w: 0.016 }];
        break;

    // An owl, frontal. Two large eye discs, a beak, two ear tufts. The eyes are bosses INSIDE
    // sunken sockets, which is the only way a 20px owl still looks at you.
    case "owl":
        _d.label = "OWL";
        _d.solids = [
            vst_dv_ell(0, 0.040, 0.310, 0.370, 20),
            vst_dv_tri(-0.310, -0.185, -0.130, -0.245, -0.205, -0.395),
            vst_dv_tri( 0.310, -0.185,  0.130, -0.245,  0.205, -0.395),
            vst_dv_tri(0, 0.030, 0.070, -0.075, -0.070, -0.075)
        ];
        _d.pits = [[-0.140, -0.120, 0.125], [0.140, -0.120, 0.125]];
        _d.bosses = [[-0.140, -0.120, 0.062], [0.140, -0.120, 0.062]];
        _d.lines = [{ pts: [[-0.235, 0.185], [0, 0.130], [0.235, 0.185]], closed: false, w: 0.024 },
                    { pts: [[-0.205, 0.300], [0, 0.245], [0.205, 0.300]], closed: false, w: 0.024 }];
        break;

    // An eye in a lens, with rays. Two arcs meeting at the corners, an iris and a drilled pupil.
    case "watcher":
        _d.label = "THE WATCHER";
        _d.solids = [
            [[-0.400, 0], [-0.185, -0.215], [0, -0.255], [0.185, -0.215], [0.400, 0],
             [0.185, 0.215], [0, 0.255], [-0.185, 0.215]],
            vst_dv_disc(0, 0, 0.145, 18)
        ];
        _d.pits = [[0, 0, 0.070]];
        _d.lines = [];
        for (var _i = 0; _i < 6; _i++) {
            var _a = -VST_TAU * 0.25 + (_i - 2.5) * 0.30;
            array_push(_d.lines, { pts: [[cos(_a) * 0.310, sin(_a) * 0.310],
                                          [cos(_a) * 0.440, sin(_a) * 0.440]],
                                    closed: false, w: 0.022 });
        }
        break;

    // A scroll, part unrolled. The two curls are separate discs with their own domes, so the
    // parchment reads as having been rolled rather than as a rectangle with circles glued on.
    case "scroll":
        _d.label = "SCROLL";
        _d.solids = [
            vst_dv_rect(-0.300, -0.290, 0.300, 0.290),
            vst_dv_ell(-0.330, -0.290, 0.105, 0.075, 14),
            vst_dv_ell( 0.330,  0.290, 0.105, 0.075, 14)
        ];
        _d.lines = [];
        for (var _i = 0; _i < 5; _i++) {
            var _y = -0.185 + _i * 0.093;
            array_push(_d.lines, { pts: [[-0.225, _y], [0.225 - (_i == 4 ? 0.140 : 0), _y]],
                                    closed: false, w: 0.026 });
        }
        _d.bosses = [[-0.330, -0.290, 0.038], [0.330, 0.290, 0.038]];
        break;

    /* -- BOND -------------------------------------------------------------------------------- */

    // ⛔ REDRAWN AFTER LOOKING AT IT. Two symmetric tapers meeting at an ellipse read as one bent
    // tube - a plumbing elbow. The symmetry was the problem: two arms arriving at the same height
    // from opposite sides have no depth order, so nothing says one is gripping the other.
    //
    // A clasp is DIAGONAL. One arm comes up from the lower left and one down from the upper right,
    // they meet off-centre, and the grip between them is a distinct block with finger grooves
    // running across it at the same angle. That is what a handshake looks like from the side and
    // it is what makes the two masses read as two hands rather than one pipe.
    case "handclasp":
        _d.label = "CLASPED HANDS";
        // ⛔ THE THIRD ATTEMPT. Attempt one was symmetric and read as a bent pipe. Attempt two made
        // it diagonal, which was the right idea and not enough: the central grip was the SAME WIDTH
        // as the two arms, so all three masses merged into one continuous bar and the finger
        // grooves became bands around a tube.
        //
        // The rule this finally taught: two masses read as two masses when their SILHOUETTE steps,
        // not when their fill changes. So there are now two separate FISTS, each wider than the arm
        // behind it and offset from the other across the diagonal, so the outline visibly bulges
        // twice. That is what a handshake looks like and it is the only version of this that has
        // survived being looked at.
        _d.solids = [
            vst_dv_taper(-0.440, 0.400, -0.115, 0.115, 0.098, 0.078),
            vst_dv_taper( 0.440, -0.400, 0.115, -0.115, 0.098, 0.078),
            vst_dv_rot(vst_dv_ngon(-0.072, 0.072, 0.190, 8, VST_TAU / 16), -0.785),
            vst_dv_rot(vst_dv_ngon( 0.072, -0.072, 0.190, 8, VST_TAU / 16), -0.785),
            vst_dv_bar(-0.430, 0.310, -0.300, 0.440, 0.100),
            vst_dv_bar( 0.430, -0.310,  0.300, -0.440, 0.100)
        ];
        _d.lines = [{ pts: [[-0.210, 0.010], [-0.010, 0.210]], closed: false, w: 0.026 },
                    { pts: [[-0.140, -0.060], [ 0.060, 0.140]], closed: false, w: 0.026 },
                    { pts: [[ 0.010, -0.210], [ 0.210, -0.010]], closed: false, w: 0.026 },
                    { pts: [[ 0.080, -0.280], [ 0.280, -0.080]], closed: false, w: 0.026 }];
        break;

    // A two-handled cup. Bowl, stem, foot and two handle bars: four masses, and the stem is the
    // one that has to be narrow or the whole thing reads as an egg cup.
    case "chalice":
        _d.label = "CHALICE";
        _d.solids = [
            vst_dv_trap(0, -0.290, 0.265, 0.055, 0.130),
            vst_dv_bar(0, 0.055, 0, 0.275, 0.050),
            vst_dv_trap(0, 0.275, 0.100, 0.395, 0.265),
            vst_dv_bar(-0.265, -0.245, -0.395, -0.055, 0.048),
            vst_dv_bar( 0.265, -0.245,  0.395, -0.055, 0.048)
        ];
        _d.lines = [{ pts: [[-0.245, -0.205], [0.245, -0.205]], closed: false, w: 0.024 }];
        _d.bosses = [[0, 0.165, 0.062]];
        break;

    // A visor mask: a face plate with two eye slots and a mouth slit. Slots rather than round
    // eyes on purpose - round eye holes make it a carnival mask and this is a helm.
    case "visor":
        _d.label = "VISOR";
        _d.solids = [
            [[-0.290, -0.330], [0.290, -0.330], [0.310, -0.030], [0.185, 0.290],
             [0, 0.415], [-0.185, 0.290], [-0.310, -0.030]],
            vst_dv_bar(0, -0.310, 0, 0.380, 0.038)
        ];
        _d.lines = [{ pts: vst_dv_rect(-0.245, -0.185, -0.070, -0.100), closed: true, w: 0.022 },
                    { pts: vst_dv_rect( 0.070, -0.185,  0.245, -0.100), closed: true, w: 0.022 },
                    { pts: [[-0.130, 0.170], [0.130, 0.170]], closed: false, w: 0.030 },
                    { pts: [[-0.100, 0.245], [0.100, 0.245]], closed: false, w: 0.026 }];
        break;

    // ⛔ REDRAWN AFTER LOOKING AT IT. The first authoring put a 0.215 pit inside a 0.345 disc and a
    // shield-shaped bezel over the top of both, and the three overlapped into a circle with a blob
    // on it. The band was too thin to read as a band and the bezel too large to read as a bezel.
    //
    // A signet ring reads when the BAND is a clear annulus and the BEZEL is a distinct oval sitting
    // above it with a seal cut INTO it - a sunken pocket, not an incised outline, because an
    // outline inside a small oval is a scribble at anything below hero size.
    case "signet":
        _d.label = "SIGNET";
        // ⛔ THE THIRD ATTEMPT, AND THE SECOND ONE READ AS A SNOWMAN. A 0.325 disc under a 0.250 by
        // 0.200 oval, touching at a waist, is two circles of similar size stacked - which is a
        // figure of eight whatever is drawn inside them. Two fixes together: the bezel is now
        // clearly WIDER THAN TALL so it cannot be mistaken for a second circle, and two shoulders
        // fill the waist so the outline never pinches between them.
        _d.solids = [
            vst_dv_disc(0, 0.155, 0.315, 24),
            vst_dv_taper(-0.240, -0.180, -0.185, 0.060, 0.078, 0.090),
            vst_dv_taper( 0.240, -0.180,  0.185, 0.060, 0.078, 0.090),
            vst_dv_ell(0, -0.240, 0.290, 0.160, 20)
        ];
        _d.pits = [[0, 0.155, 0.222]];
        _d.sunk = [vst_dv_ngon(0, -0.240, 0.112, 4, VST_TAU / 8)];
        break;

    // A banner on its staff, with a swallow tail. The tail is cut into the cloth outline rather
    // than added, because a rectangle with a notch is a banner and a rectangle is a sign.
    case "banner":
        _d.label = "BANNER";
        _d.solids = [
            [[-0.205, -0.350], [0.430, -0.420], [0.430, 0.190], [0.200, 0.055],
             [-0.030, 0.230], [-0.205, 0.135]],
            vst_dv_bar(-0.270, -0.430, -0.270, 0.440, 0.062)
        ];
        _d.bosses = [[-0.270, -0.445, 0.062]];
        _d.lines = [{ pts: [[-0.150, -0.300], [0.370, -0.360]], closed: false, w: 0.024 },
                    { pts: [[-0.150, -0.140], [0.370, -0.196]], closed: false, w: 0.024 },
                    { pts: [[-0.150,  0.020], [0.370, -0.032]], closed: false, w: 0.024 }];
        break;

    // A harp. The pillar, the neck and the soundboard are three masses; the strings are incised
    // and they are the reason this is not a letter A.
    case "harp":
        _d.label = "HARP";
        _d.solids = [
            vst_dv_taper(-0.290, 0.400, -0.130, -0.380, 0.075, 0.048),
            vst_dv_taper(-0.130, -0.380, 0.290, -0.140, 0.048, 0.062),
            vst_dv_taper(-0.290, 0.400, 0.310, 0.130, 0.098, 0.062)
        ];
        _d.lines = [];
        for (var _i = 0; _i < 6; _i++) {
            var _t = (_i + 1) / 7;
            array_push(_d.lines, { pts: [[lerp(-0.140, 0.270, _t), lerp(-0.350, -0.150, _t)],
                                          [lerp(-0.245, 0.265, _t), lerp( 0.330, 0.150, _t)]],
                                    closed: false, w: 0.018 });
        }
        _d.bosses = [[-0.290, 0.400, 0.070]];
        break;

    /* -- ENDURANCE --------------------------------------------------------------------------- */

    // An hourglass. Two triangles, two rails, and a pit of sand in the lower bulb. The sand is
    // what tells the two chambers apart; empty, it is a bow tie.
    case "hourglass":
        _d.label = "HOURGLASS";
        // ⛔ THE TWO SIDE POSTS ARE NOT DECORATION. MEASURED BY LOOKING at the ribbons sheet: two
        // triangles meeting at a point, between two rails, read as a Z at medal size - the eye
        // joins the top rail, the pinch and the bottom rail into one stroke. An hourglass is
        // recognised by its FRAME: two posts closing the shape into a rectangle with the glass
        // inside it. Without them it is a bowtie between two lines.
        //
        // ⛔ AND THE GLASS HAD TO SHRINK OR THE FIX MADE IT WORSE. At half-width 0.265 inside posts
        // at 0.300 the two touched, and the device went from reading as a Z to reading as a framed
        // X - a picture frame with a cross in it. The frame only reads as a STAND when there is
        // visible air between it and the glass, which is also what a real hourglass looks like.
        // ⛔ THE BULBS ARE CURVED, AND TWO STRAIGHT TRIANGLES WERE TRIED FIRST AND FAILED TWICE.
        // Between two rails they read as a Z; with the side posts added they read as a picture
        // frame with a cross in it. Straight-sided triangles meeting at a point ARE an X, and no
        // amount of framing stops the eye completing that X - it is the cheapest reading available.
        //
        // A real hourglass has BULBS: convex sides swelling out from a narrow neck. Curving them is
        // what stops the two halves being read as one crossing pair, and it is the only version of
        // this device that has survived being looked at.
        _d.solids = [
            [[-0.215, -0.285], [0.215, -0.285], [0.175, -0.140], [0.055, -0.035],
             [0, -0.008], [-0.055, -0.035], [-0.175, -0.140]],
            [[-0.215,  0.285], [0.215,  0.285], [0.175,  0.140], [0.055,  0.035],
             [0,  0.008], [-0.055,  0.035], [-0.175,  0.140]],
            vst_dv_bar(-0.330, -0.345, 0.330, -0.345, 0.052),
            vst_dv_bar(-0.330,  0.345, 0.330,  0.345, 0.052),
            vst_dv_bar(-0.310, -0.345, -0.310, 0.345, 0.038),
            vst_dv_bar( 0.310, -0.345,  0.310, 0.345, 0.038)
        ];
        // The sand that has already run through, as a pocket in the lower bulb. It is the detail
        // that says which way up the thing is, which is the whole point of an hourglass.
        _d.sunk = [[[-0.148, 0.240], [0.148, 0.240], [0.080, 0.130], [-0.080, 0.130]]];
        _d.bosses = [[-0.310, -0.345, 0.046], [0.310, -0.345, 0.046],
                     [-0.310,  0.345, 0.046], [0.310,  0.345, 0.046]];
        break;

    // A heart, as one outline. One of the four organic shapes in the corpus that is a single mass
    // rather than an assembly - it is star-shaped about its own centre, so the fan is safe.
    case "heart":
        _d.label = "HEART";
        _d.solids = [[
            [0, -0.185], [0.130, -0.345], [0.310, -0.345], [0.415, -0.215], [0.415, -0.030],
            [0.245, 0.185], [0, 0.415], [-0.245, 0.185], [-0.415, -0.030], [-0.415, -0.215],
            [-0.310, -0.345], [-0.130, -0.345]
        ]];
        _d.lines = [{ pts: [[-0.245, -0.235], [-0.310, -0.130], [-0.290, -0.010]],
                      closed: false, w: 0.026 }];
        break;

    // ⛔ ASYMMETRIC, AND THE FIRST ONE WAS NOT. A symmetric tongue with an incised outline inside it
    // read as a LEAF - and it sat two cells from a device that is a leaf-shaped almond, which made
    // it worse. Fire is never symmetric: the tip leans, one shoulder is higher than the other, and
    // the inner tongue is a MACHINED POCKET rather than a scratched outline, so it survives being
    // shrunk.
    case "flame":
        _d.label = "FLAME";
        _d.solids = [[
            [0.070, -0.455], [0.185, -0.215], [0.235, -0.290], [0.295, -0.040],
            [0.265, 0.190], [0.100, 0.370], [-0.100, 0.375], [-0.270, 0.215],
            [-0.295, -0.020], [-0.215, -0.230], [-0.135, -0.130], [-0.045, -0.330]
        ]];
        _d.sunk = [[
            [0.045, -0.200], [0.145, -0.005], [0.115, 0.185], [-0.020, 0.265],
            [-0.150, 0.155], [-0.135, -0.035], [-0.040, -0.120]
        ]];
        _d.bosses = [[-0.010, 0.100, 0.070]];
        break;

    // ⛔ REDRAWN AFTER LOOKING AT IT. The first authoring read as a ROCK, and it sat three rows
    // from a device that is literally three mountains. The tell it was missing is not detail, it
    // is CURVATURE: a mountain's top edge is straight lines meeting at points, and a wave's is a
    // single convex swell. So the crest is now a rounded hump, the curl is a lip flicking back
    // over it, there is spray above it and a flat waterline under it, and none of those four things
    // is true of a mountain.
    case "surge":
        _d.label = "SURGE";
        // ⛔ THE THIRD ATTEMPT. Attempt one read as a rock. Attempt two rounded the crest, which was
        // right, and then stuck two pointed leaves on it as a curl and a foam lip - so it read as a
        // lump with antennae, which is worse. The lesson: a detail that does not READ as the thing
        // it depicts is worse than no detail, because the eye reads it as a different thing.
        //
        // What says WATER without any detail at all is a WAVY HORIZONTAL BAND, and nothing else in
        // the corpus has one. So the foreground is now a foam band with a rolling top edge, the
        // crest above it is a single convex swell, one leaf remains as a curling lip where a real
        // wave breaks, and the spray sits above all of it.
        _d.solids = [[
            [-0.455, 0.230], [-0.410, 0.050], [-0.290, -0.110], [-0.090, -0.220],
            [0.130, -0.225], [0.300, -0.120], [0.360, 0.040], [0.350, 0.230]
        ]];
        array_push(_d.solids, vst_dv_leaf(0.195, -0.195, 0.200, 0.082, 3.05));
        array_push(_d.solids, [
            [-0.460, 0.250], [-0.310, 0.180], [-0.140, 0.255], [0.030, 0.180],
            [0.200, 0.255], [0.370, 0.180], [0.460, 0.250], [0.460, 0.430], [-0.460, 0.430]
        ]);
        _d.lines = [{ pts: [[-0.330, 0.140], [-0.280, -0.010], [-0.165, -0.125]],
                      closed: false, w: 0.026 },
                    { pts: [[-0.130, 0.150], [-0.060, 0.005], [0.060, -0.070]],
                      closed: false, w: 0.024 }];
        _d.bosses = [[0.320, -0.330, 0.058], [0.140, -0.375, 0.046], [-0.055, -0.330, 0.036]];
        break;

    // A briar. One curved stem as a chain of tapers, with three thorns. The thorns alternate
    // sides, because three on one side reads as a comb.
    case "thorn":
        _d.label = "BRIAR";
        _d.solids = [
            vst_dv_taper(-0.400, 0.410, -0.185, 0.130, 0.085, 0.068),
            vst_dv_taper(-0.185, 0.130, 0.075, -0.030, 0.068, 0.055),
            vst_dv_taper( 0.075, -0.030, 0.365, -0.370, 0.055, 0.036),
            vst_dv_tri(-0.255, 0.235, -0.185, 0.130, -0.430, 0.040),
            vst_dv_tri( 0.005, 0.060,  0.075, -0.030, 0.320, 0.150),
            vst_dv_tri( 0.185, -0.190,  0.250, -0.255, 0.010, -0.330),
            // Two leaves. A briar is a thorny stem WITH leaves; a bare stem with three spikes is a
            // barbed wire, and it also sat under the ink floor.
            vst_dv_leaf(-0.290, 0.235, 0.150, 0.078, 2.40),
            vst_dv_leaf( 0.195, -0.115, 0.145, 0.074, 1.90)
        ];
        _d.lines = [{ pts: [[-0.345, 0.335], [-0.145, 0.070], [0.130, -0.105], [0.335, -0.330]],
                      closed: false, w: 0.018 }];
        break;

    // A sun with eight rays. The rays alternate long and short so the disc keeps its weight -
    // eight equal rays around a circle read as a cog, which is another device in this corpus.
    case "sun":
        _d.label = "SUN";
        _d.solids = [vst_dv_disc(0, 0, 0.235, 24)];
        for (var _i = 0; _i < 8; _i++) {
            var _a = (_i / 8) * VST_TAU;
            var _L = (_i % 2 == 0) ? 0.440 : 0.345;
            array_push(_d.solids, vst_dv_tri(cos(_a) * _L, sin(_a) * _L,
                cos(_a + 0.22) * 0.230, sin(_a + 0.22) * 0.230,
                cos(_a - 0.22) * 0.230, sin(_a - 0.22) * 0.230));
        }
        _d.pits = [[0, 0, 0.098]];
        break;

    /* -- HOARD ------------------------------------------------------------------------------- */

    // A banded chest with a domed lid. The lid is its own mass so it catches light separately from
    // the body - a chest drawn as one rectangle is a crate.
    case "strongbox":
        _d.label = "STRONGBOX";
        _d.solids = [
            vst_dv_rect(-0.400, -0.030, 0.400, 0.330),
            [[-0.400, -0.030], [-0.330, -0.245], [0.330, -0.245], [0.400, -0.030]],
            vst_dv_rect(-0.075, -0.130, 0.075, 0.150),
            vst_dv_bar(-0.430, 0.345, 0.430, 0.345, 0.048)
        ];
        _d.pits = [[0, 0.055, 0.048]];
        _d.lines = [{ pts: [[-0.265, -0.245], [-0.265, 0.330]], closed: false, w: 0.024 },
                    { pts: [[ 0.265, -0.245], [ 0.265, 0.330]], closed: false, w: 0.024 },
                    { pts: [[-0.395, -0.010], [ 0.395, -0.010]], closed: false, w: 0.020 }];
        break;

    // A stack of coins with one leaning against it. The lean is the detail: a straight stack of
    // ellipses is a barrel.
    case "coins":
        _d.label = "COIN STACK";
        _d.solids = [
            vst_dv_ell(-0.075, 0.290, 0.290, 0.105, 20),
            vst_dv_ell(-0.075, 0.155, 0.290, 0.105, 20),
            vst_dv_ell(-0.075, 0.020, 0.290, 0.105, 20),
            vst_dv_rot(vst_dv_ell(0.245, -0.100, 0.245, 0.245, 20), 0.35, 0.245, -0.100)
        ];
        _d.pits = [[0.245, -0.100, 0.098]];
        _d.lines = [{ pts: [[-0.360, 0.020], [-0.360, 0.290]], closed: false, w: 0.018 },
                    { pts: [[ 0.210, 0.020], [ 0.210, 0.290]], closed: false, w: 0.018 }];
        break;

    // ⛔ REGROUPED AFTER LOOKING AT IT. Three stones at three sizes, spread apart, read as scattered
    // debris rather than as a cluster - and the main stone's table, drawn as an incised outline,
    // vanished into it. Overlapping the two small stones INTO the big one is what makes three
    // objects into one hoard, and the table is a machined pocket so it survives being shrunk.
    case "gems":
        _d.label = "CUT STONES";
        // ⚠️ THE TWO SMALL STONES ARE DRAWN FIRST AND THE BIG ONE LAST, and the order is the fix.
        // Listed the other way round, each small stone's bevel was painted OVER the main stone's
        // face, so the cluster read as one shape shattering rather than as three stones with a
        // hierarchy. Parts are drawn in list order; overlapping masses have a depth order and it is
        // the author's job to say which.
        _d.solids = [
            [[-0.285, 0.060], [-0.155, 0.180], [-0.220, 0.395], [-0.395, 0.275]],
            [[ 0.285, 0.060], [ 0.395, 0.195], [ 0.290, 0.400], [ 0.140, 0.255]],
            [[0, -0.450], [0.300, -0.150], [0.175, 0.265], [-0.175, 0.265], [-0.300, -0.150]]
        ];
        _d.sunk = [[[-0.145, -0.215], [0.145, -0.215], [0.085, 0.045], [-0.085, 0.045]]];
        _d.lines = [{ pts: [[0, -0.450], [0, -0.215]], closed: false, w: 0.018 },
                    { pts: [[-0.290, -0.150], [-0.145, -0.215]], closed: false, w: 0.018 },
                    { pts: [[ 0.290, -0.150], [ 0.145, -0.215]], closed: false, w: 0.018 },
                    { pts: [[-0.165, 0.250], [-0.085, 0.045]], closed: false, w: 0.018 },
                    { pts: [[ 0.165, 0.250], [ 0.085, 0.045]], closed: false, w: 0.018 }];
        break;

    // An amphora. Body, neck, foot and two handles. The handles are the tell and they are bars
    // rather than arcs, because an arc drawn at 20px is a dash.
    case "amphora":
        _d.label = "AMPHORA";
        _d.solids = [
            vst_dv_ell(0, 0.075, 0.265, 0.310, 20),
            vst_dv_trap(0, -0.395, 0.130, -0.155, 0.098),
            vst_dv_trap(0, 0.345, 0.075, 0.430, 0.155),
            vst_dv_bar(-0.130, -0.330, -0.265, -0.075, 0.045),
            vst_dv_bar( 0.130, -0.330,  0.265, -0.075, 0.045)
        ];
        _d.lines = [{ pts: [[-0.155, -0.375], [0.155, -0.375]], closed: false, w: 0.022 },
                    { pts: [[-0.235, 0.075], [0.235, 0.075]], closed: false, w: 0.020 }];
        break;

    // A tied sack. The neck gather is a separate small mass and the two folds are incised; a
    // bulging outline alone is a cloud.
    case "sack":
        _d.label = "SACK";
        _d.solids = [
            [[-0.360, 0.130], [-0.245, -0.185], [-0.075, -0.290], [0.075, -0.290],
             [0.245, -0.185], [0.360, 0.130], [0.310, 0.395], [-0.310, 0.395]],
            vst_dv_bar(-0.155, -0.245, 0.155, -0.245, 0.062),
            vst_dv_tri(-0.155, -0.290, -0.030, -0.310, -0.245, -0.415),
            vst_dv_tri( 0.155, -0.290,  0.030, -0.310,  0.245, -0.415)
        ];
        _d.lines = [{ pts: [[-0.185, 0.030], [-0.130, 0.330]], closed: false, w: 0.024 },
                    { pts: [[ 0.075, -0.030], [0.130, 0.330]], closed: false, w: 0.024 },
                    { pts: [[-0.290, 0.310], [0.290, 0.310]], closed: false, w: 0.020 }];
        break;

    // A honeycomb of seven cells. The centre cell is SUNK and the six around it raised, so the
    // comb has depth rather than being a tiling pattern.
    default:
        _d.label = "HONEYCOMB";
        _d.solids = [];
        for (var _i = 0; _i < 6; _i++) {
            var _a = (_i / 6) * VST_TAU + VST_TAU / 12;
            array_push(_d.solids, vst_dv_ngon(cos(_a) * 0.265, sin(_a) * 0.265, 0.155, 6, 0));
        }
        _d.pits = [];
        _d.lines = [{ pts: vst_dv_ngon(0, 0, 0.155, 6, 0), closed: true, w: 0.030 }];
        _d.bosses = [[0, 0, 0.062]];
        break;

    }
    return _d;
}

/// ============================================================================================
/// COMPOSITION
/// ============================================================================================

/// A device as struck relief, in its own unit box.
///
/// ⚠️ THE ORDER IS SOLIDS, SUNK POCKETS, PITS, BOSSES, THEN INCISED LINES, and it is not arbitrary.
/// A pocket machined before its mass exists is painted over; an incised line cut before the boss it
/// runs around is buried. The order is the order a die-sinker actually works in, which is a good
/// sign it is the right one.
function vst_device_parts(_id, _detail) {
    var _d = vst_device(_id);
    var _steps = (_detail <= 0) ? 1 : ((_detail == 1) ? 2 : 3);
    var _b = (_detail <= 0) ? 0.022 : 0.032;
    var _segs = (_detail <= 0) ? 8 : 12;
    var _out = [];

    for (var _i = 0; _i < array_length(_d.solids); _i++) {
        vst_append(_out, vst_raise(_d.solids[_i], _b, _steps, "m2"));
    }
    for (var _i = 0; _i < array_length(_d.sunk); _i++) {
        vst_append(_out, vst_sink(_d.sunk[_i], _b * 0.72, max(1, _steps - 1), "m1"));
    }
    for (var _i = 0; _i < array_length(_d.pits); _i++) {
        var _p = _d.pits[_i];
        vst_append(_out, vst_pit(_p[0], _p[1], _p[2], _segs));
    }
    for (var _i = 0; _i < array_length(_d.bosses); _i++) {
        var _p = _d.bosses[_i];
        vst_append(_out, vst_boss(_p[0], _p[1], _p[2], _segs));
    }
    // ⛔ INCISED LINES ARE SKIPPED ENTIRELY AT INVENTORY DETAIL, and that is a design decision
    // rather than a saving. vst_render floors every stroke at one pixel, so at 32px a groove and
    // its two walls land on the same three pixels and the device fills up with grey mush - the
    // exact "44 marks of grey dust" failure this wing has already shipped once. A device that
    // drops its incision at small size keeps its silhouette, which is all that reads there anyway.
    if (_detail > 0) {
        for (var _i = 0; _i < array_length(_d.lines); _i++) {
            var _l = _d.lines[_i];
            vst_append(_out, vst_incise(_l.pts, _l.closed, _l.w));
        }
    }
    return _out;
}

/// How much ink a device puts down, as the fraction of a coarse grid its parts touch.
///
/// Used by vst_selftest to catch a device that is authored but nearly empty, and to compare two
/// devices for collapse. It is an AREA PROXY and not a rasteriser: a fan is filled by its own
/// spokes, a strip by its rungs, a polyline by its segments. Stroke width is ignored, which is the
/// right call - the renderer floors every stroke at 1px anyway, so a width difference this grid
/// cannot see is a width difference the screen cannot show.
/// Mark the grid cell a unit-box point falls in.
///
/// ⚠️ A TOP-LEVEL FUNCTION RATHER THAN A LOCAL LITERAL, DELIBERATELY. The primitive layer's own
/// header records what happened the last time this wing put mutable behaviour inside a struct or a
/// closure in GML: generator state did not stay with the generator and three assertions failed in
/// ways that only appeared in-engine. A plain function taking the array as an argument has no
/// binding rules to get wrong, and arrays are references so the mutation lands.
function vst_grid_mark(_g, _n, _x, _y) {
    var _i = clamp(floor((_x + 0.5) * _n), 0, _n - 1);
    var _k = clamp(floor((_y + 0.5) * _n), 0, _n - 1);
    _g[_k * _n + _i] = 1;
}

function vst_device_grid(_id, _n) {
    var _parts = vst_device_parts(_id, 2);
    var _g = array_create(_n * _n, 0);
    for (var _p = 0; _p < array_length(_parts); _p++) {
        var _q = _parts[_p];
        switch (_q.kind) {
            case VST_DOT: {
                for (var _a = 0; _a < 12; _a++) {
                    for (var _r = 0; _r <= 3; _r++) {
                        var _an = (_a / 12) * VST_TAU, _rr = _q.r * (_r / 3);
                        vst_grid_mark(_g, _n, _q.cx + cos(_an) * _rr, _q.cy + sin(_an) * _rr);
                    }
                }
            } break;
            case VST_ARC: {
                for (var _a = 0; _a <= 24; _a++) {
                    var _an = _q.a0 + (_q.a1 - _q.a0) * (_a / 24);
                    vst_grid_mark(_g, _n, _q.cx + cos(_an) * _q.r, _q.cy + sin(_an) * _q.r);
                }
            } break;
            case VST_STRIP: {
                var _na = min(array_length(_q.a), array_length(_q.b));
                for (var _a = 0; _a < _na; _a++) {
                    for (var _t = 0; _t <= 4; _t++) {
                        vst_grid_mark(_g, _n, lerp(_q.a[_a][0], _q.b[_a][0], _t / 4),
                                      lerp(_q.a[_a][1], _q.b[_a][1], _t / 4));
                    }
                }
            } break;
            case VST_FILL: {
                var _np = array_length(_q.pts);
                for (var _a = 1; _a < _np; _a++) {
                    for (var _t = 0; _t <= 6; _t++) {
                        vst_grid_mark(_g, _n, lerp(_q.pts[0][0], _q.pts[_a][0], _t / 6),
                                      lerp(_q.pts[0][1], _q.pts[_a][1], _t / 6));
                    }
                }
            } break;
            default: {
                var _np = array_length(_q.pts);
                for (var _a = 0; _a < _np - 1; _a++) {
                    for (var _t = 0; _t <= 4; _t++) {
                        vst_grid_mark(_g, _n, lerp(_q.pts[_a][0], _q.pts[_a + 1][0], _t / 4),
                                      lerp(_q.pts[_a][1], _q.pts[_a + 1][1], _t / 4));
                    }
                }
            } break;
        }
    }
    return _g;
}

/// Jaccard distance between two device grids: 0 identical, 1 disjoint.
function vst_grid_distance(_a, _b) {
    var _n = min(array_length(_a), array_length(_b));
    var _inter = 0, _uni = 0;
    for (var _i = 0; _i < _n; _i++) {
        if (_a[_i] > 0 || _b[_i] > 0) _uni++;
        if (_a[_i] > 0 && _b[_i] > 0) _inter++;
    }
    if (_uni == 0) return 0;
    return 1 - (_inter / _uni);
}

/// The fraction of a grid that carries ink.
function vst_grid_fill(_g) {
    var _n = array_length(_g), _c = 0;
    for (var _i = 0; _i < _n; _i++) if (_g[_i] > 0) _c++;
    return _c / max(1, _n);
}
