{
  "$GMScript": "v1",
  "%Name": "vst_render",
  "isCompatibility": false,
  "isDnD": false,
  "name": "vst_render",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}