/// VESTIGE - vst_render. The one draw path everything in this package goes through.
///
/// This file turns GEOMETRY into DRAW CALLS and knows nothing about medals. It has never heard of
/// a planchet, a device or a tier. vst_relief, vst_planchet, vst_device and vst_ribbon produce
/// parts; this draws them. Keeping that split clean is what lets the whole corpus be checked as
/// data before any of it is rasterised.
///
/// ⛔ THE STROKE FLOOR IS 1.0 PIXELS AND THAT NUMBER IS A RASTERISER FACT, NOT A TASTE CALL.
/// draw_line_width lays down a quad of the requested width with no antialiasing in the default
/// configuration, so a 0.55px quad rasterises to a row of pixels on some scanlines and nothing on
/// others, and a field of tone strokes turns into a field of dashes. The design's sub-pixel widths
/// survive as ORDERING - a 0.016 incision is still thinner than a 0.034 one at every scale where
/// either is above the floor.
///
/// ⚠️ A ROLE THAT IS NOT IN THE SURFACE FALLS BACK TO `line`, LOUDLY WRONG RATHER THAN INVISIBLE.
/// The alternative - falling back to the ground colour, or skipping the part - hides an authoring
/// typo by drawing it in the background colour, and this wing has already recorded what happens
/// when a missing thing renders as a plausible nothing. vst_selftest asserts that no part in the
/// product ever reaches this fallback, so it stays a diagnostic rather than becoming a crutch.
///
/// GML NOTES, from Wings/GameMaker/CLAUDE.md §3: no exponent literals (`1e-4` is a lexer error),
/// `end` is a reserved word and cannot be a struct key, and any tolerance under about 0.00001 can
/// never fire because math_get_epsilon participates in comparisons.
/// ============================================================================================

/// The rasteriser floor, in pixels. See the header.
#macro VST_MIN_STROKE 1.0

/// How many segments an arc is sampled at per full turn.
#macro VST_ARC_SEGS 48

/// ============================================================================================
/// SURFACE LOOKUP
/// ============================================================================================

function vst_render_colour(_pal, _role) {
    if (variable_struct_exists(_pal, _role)) return variable_struct_get(_pal, _role);
    return _pal.line;
}

/// ============================================================================================
/// FITTING
/// ============================================================================================

/// Where to put the unit box so it fits (_x,_y,_w,_h) without distortion.
///
/// UNIFORM SCALE, ALWAYS. Mapping x by width and y by height independently would fill an oblong
/// slot exactly and turn every circle in the package into an ellipse - which on a product whose
/// twelve blank forms are told apart by their outlines is not a cosmetic problem. A medal that
/// does not fill its slot is correct; a stretched one is a defect.
function vst_render_fit(_x, _y, _w, _h) {
    var _s = min(_w, _h);
    return { cx: _x + _w * 0.5, cy: _y + _h * 0.5, s: _s };
}

/// ============================================================================================
/// THE FIVE PRIMITIVES
/// ============================================================================================

function vst_render_poly(_pts, _closed, _w) {
    var _n = array_length(_pts);
    if (_n < 2) return;
    var _ww = max(VST_MIN_STROKE, _w);
    for (var _i = 0; _i < _n - 1; _i++) {
        draw_line_width(_pts[_i][0], _pts[_i][1], _pts[_i + 1][0], _pts[_i + 1][1], _ww);
    }
    if (_closed) draw_line_width(_pts[_n - 1][0], _pts[_n - 1][1], _pts[0][0], _pts[0][1], _ww);
}

/// Fill a triangle fan. The caller is responsible for the outline being star-shaped about pts[0];
/// vst_ring_fill is the helper that guarantees it and closes the final wedge.
function vst_render_fill(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return;
    draw_primitive_begin(pr_trianglefan);
    for (var _i = 0; _i < _n; _i++) draw_vertex(_pts[_i][0], _pts[_i][1]);
    draw_primitive_end();
}

/// Fill a triangle strip between two rails. A rail-length mismatch draws NOTHING rather than the
/// overlapping part: a strip whose rails disagree means the producer's two loops disagree, and
/// drawing the common prefix would render a plausible half-shape and hide the defect.
function vst_render_strip(_a, _b) {
    var _n = array_length(_a);
    if (_n < 2 || array_length(_b) != _n) return;
    draw_primitive_begin(pr_trianglestrip);
    for (var _i = 0; _i < _n; _i++) {
        draw_vertex(_a[_i][0], _a[_i][1]);
        draw_vertex(_b[_i][0], _b[_i][1]);
    }
    draw_primitive_end();
}

function vst_render_arc(_cx, _cy, _r, _a0, _a1, _w) {
    var _sweep = abs(_a1 - _a0);
    var _segs = max(3, ceil(VST_ARC_SEGS * _sweep / VST_TAU));
    var _ww = max(VST_MIN_STROKE, _w);
    var _px = _cx + cos(_a0) * _r, _py = _cy + sin(_a0) * _r;
    for (var _i = 1; _i <= _segs; _i++) {
        var _a = _a0 + (_a1 - _a0) * (_i / _segs);
        var _qx = _cx + cos(_a) * _r, _qy = _cy + sin(_a) * _r;
        draw_line_width(_px, _py, _qx, _qy, _ww);
        _px = _qx; _py = _qy;
    }
}

/// ============================================================================================
/// THE DRAW LOOP
/// ============================================================================================

function vst_render_part(_p, _pal) {
    draw_set_colour(vst_render_colour(_pal, _p.role));
    switch (_p.kind) {
        case VST_DOT:   draw_circle(_p.cx, _p.cy, max(0.5, _p.r), false);       break;
        case VST_ARC:   vst_render_arc(_p.cx, _p.cy, _p.r, _p.a0, _p.a1, _p.w); break;
        case VST_FILL:  vst_render_fill(_p.pts);                                break;
        case VST_STRIP: vst_render_strip(_p.a, _p.b);                           break;
        default:        vst_render_poly(_p.pts, _p.closed, _p.w);               break;
    }
}

function vst_render_parts_raw(_parts, _pal) {
    var _n = array_length(_parts);
    for (var _i = 0; _i < _n; _i++) vst_render_part(_parts[_i], _pal);
}

/// Place a unit-box part list at (_cx,_cy) at scale _s and draw it.
///
/// _rot, _wscale and _map are optional. _wscale defaults to _s, which is the constant-PROPORTION
/// rule the primitive layer's header argues for: holding stroke weight constant in screen space
/// instead made a card-scale medal's incisions 32% of its own width while a hero-scale one's were
/// 6%, so small medals rendered as solid blobs.
function vst_render_parts(_parts, _pal, _cx, _cy, _s, _rot, _wscale, _map) {
    var _r  = is_undefined(_rot)    ? 0  : _rot;
    var _ws = is_undefined(_wscale) ? _s : _wscale;
    vst_render_parts_raw(vst_place(_parts, _cx, _cy, _s, _r, _ws, _map), _pal);
}

function vst_render_in_rect(_parts, _pal, _x, _y, _w, _h, _rot, _map) {
    var _fit = vst_render_fit(_x, _y, _w, _h);
    vst_render_parts(_parts, _pal, _fit.cx, _fit.cy, _fit.s, _rot, _fit.s, _map);
}

/// ============================================================================================
/// MEASUREMENT - what the self-test asserts against
/// ============================================================================================

/// The bounding box of a part list in unit-box space, as [x0, y0, x1, y1].
///
/// It walks the ACTUAL VERTICES rather than a form's declared extents, and that is the point: a
/// declared extent is a claim and the vertices are evidence. Containment failures in this wing have
/// twice been a builder whose stated half width was right and whose geometry had drifted.
function vst_render_bounds(_parts) {
    var _n = array_length(_parts);
    var _x0 = 999, _y0 = 999, _x1 = -999, _y1 = -999;
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case VST_DOT: {
                _x0 = min(_x0, _p.cx - _p.r); _x1 = max(_x1, _p.cx + _p.r);
                _y0 = min(_y0, _p.cy - _p.r); _y1 = max(_y1, _p.cy + _p.r);
            } break;
            case VST_ARC: {
                _x0 = min(_x0, _p.cx - _p.r - _p.w); _x1 = max(_x1, _p.cx + _p.r + _p.w);
                _y0 = min(_y0, _p.cy - _p.r - _p.w); _y1 = max(_y1, _p.cy + _p.r + _p.w);
            } break;
            case VST_STRIP: {
                for (var _k = 0; _k < array_length(_p.a); _k++) {
                    _x0 = min(_x0, _p.a[_k][0]); _x1 = max(_x1, _p.a[_k][0]);
                    _y0 = min(_y0, _p.a[_k][1]); _y1 = max(_y1, _p.a[_k][1]);
                }
                for (var _k = 0; _k < array_length(_p.b); _k++) {
                    _x0 = min(_x0, _p.b[_k][0]); _x1 = max(_x1, _p.b[_k][0]);
                    _y0 = min(_y0, _p.b[_k][1]); _y1 = max(_y1, _p.b[_k][1]);
                }
            } break;
            case VST_FILL: {
                for (var _k = 0; _k < array_length(_p.pts); _k++) {
                    _x0 = min(_x0, _p.pts[_k][0]); _x1 = max(_x1, _p.pts[_k][0]);
                    _y0 = min(_y0, _p.pts[_k][1]); _y1 = max(_y1, _p.pts[_k][1]);
                }
            } break;
            default: {
                var _hw = _p.w * 0.5;
                for (var _k = 0; _k < array_length(_p.pts); _k++) {
                    _x0 = min(_x0, _p.pts[_k][0] - _hw); _x1 = max(_x1, _p.pts[_k][0] + _hw);
                    _y0 = min(_y0, _p.pts[_k][1] - _hw); _y1 = max(_y1, _p.pts[_k][1] + _hw);
                }
            } break;
        }
    }
    return [_x0, _y0, _x1, _y1];
}

/// Fit a part list's ACTUAL CONTENT into a rectangle rather than fitting the unit box.
///
/// ⚠️ USE IT FOR A DETACHED PIECE - a bare device, a rim sample, a ribbon swatch. A WHOLE MEDAL
/// should go through vst_render_in_rect, because the unit box is the frame the corpus is authored
/// in and tight-fitting a whole medal makes a suspended one and a bare planchet the same size on
/// screen, which destroys the one proportion that says "this one hangs from a ribbon".
function vst_render_fit_parts(_parts, _x, _y, _w, _h) {
    var _bb = vst_render_bounds(_parts);
    var _bw = max(0.0001, _bb[2] - _bb[0]);
    var _bh = max(0.0001, _bb[3] - _bb[1]);
    var _s = min(_w / _bw, _h / _bh);
    var _mx = (_bb[0] + _bb[2]) * 0.5;
    var _my = (_bb[1] + _bb[3]) * 0.5;
    return { cx: _x + _w * 0.5 - _mx * _s, cy: _y + _h * 0.5 - _my * _s, s: _s };
}

function vst_render_in_rect_tight(_parts, _pal, _x, _y, _w, _h, _map) {
    var _f = vst_render_fit_parts(_parts, _x, _y, _w, _h);
    vst_render_parts(_parts, _pal, _f.cx, _f.cy, _f.s, 0, _f.s, _map);
}

/// ============================================================================================
/// STRUCK LETTERING
///
/// ⛔ TEXT IS THE ONE THING IN THIS PACKAGE THAT IS NOT GEOMETRY, and it still has to look struck.
/// The trick is the same two-pass emboss the relief engine uses on a groove: draw the string once
/// offset AWAY from the lamp in the alloy's deepest stop, then again in place in its brightest.
/// Two draw calls, and the legend reads as metal rather than as a caption laid over a picture of
/// metal.
///
/// ⚠️ EVERY STRING IN THIS FILE IS MEASURED AND SCALED TO ITS SPACE. Wings/GameMaker/CLAUDE.md
/// records this wing shipping the SAME overflow defect twice - "WickthorSt Cuthman's" on one
/// product and "HEDGEHOG FUNGUSCAULIFLOWER FUNGUS" on the next - because the first fix shortened
/// the DATA instead of making the caption honest about its width. Award names come from the
/// BUYER's game and cannot be shortened by us at all, so nothing here is allowed to assume a
/// length. No ink check will ever catch an overflow: overprinted text is ink exactly where ink
/// belongs.
/// ============================================================================================

/// The emboss offset for lettering, in pixels, at a given nominal size.
function vst_text_relief(_px) {
    return max(1, round(_px * 0.085));
}

/// One line of struck text, centred at (_x,_y), scaled DOWN if it will not fit _maxw.
///
/// Returns the scale actually used, so a caller that cares can notice it was shrunk.
function vst_text_fit(_text, _x, _y, _maxw, _px, _col_shadow, _col_face) {
    draw_set_font(fnt_vestige_title);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    var _o = vst_text_relief(_px);
    draw_set_colour(_col_shadow);
    draw_text_transformed(_x - VST_LX * _o, _y - VST_LY * _o, _text, _sc, _sc, 0);
    draw_set_colour(_col_face);
    draw_text_transformed(_x, _y, _text, _sc, _sc, 0);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    return _sc;
}

/// A legend struck around an arc, one glyph at a time.
///
/// _a_mid is the angle the middle of the string sits at (-VST_TAU/4 is the top of the medal) and
/// _sweep is how much of the circle the whole string may occupy. The string is laid out by ADVANCE
/// so that letter spacing is even in ARC LENGTH - spacing the glyphs evenly in ANGLE instead
/// bunches the narrow letters and was the first thing this looked wrong doing.
///
/// ⚠️ THE ROTATION IS DERIVED, NOT GUESSED. GML's draw_text_transformed takes DEGREES and rotates
/// counter-clockwise on a y-DOWN screen, so a glyph's own x-axis lands at (cos t, -sin t). The
/// tangent to the circle at angle a is (-sin a, cos a). Solving the two gives
/// t = atan2(-cos a, -sin a), which is checkable in one place: at the top of the medal a is
/// -TAU/4, the tangent is (1,0), and t comes out 0.
function vst_text_arc(_text, _cx, _cy, _r, _a_mid, _sweep, _px, _col_shadow, _col_face) {
    var _n = string_length(_text);
    if (_n <= 0 || _r <= 0) return 0;
    draw_set_font(fnt_vestige_title);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _total = 0;
    for (var _i = 1; _i <= _n; _i++) _total += string_width(string_char_at(_text, _i)) * _sc;
    var _arc = _r * _sweep;
    if (_total > _arc && _total > 0) {
        _sc *= _arc / _total;
        _total = _arc;
    }

    var _o = vst_text_relief(_px);
    var _run = 0;
    for (var _i = 1; _i <= _n; _i++) {
        var _ch = string_char_at(_text, _i);
        var _cw = string_width(_ch) * _sc;
        // Centre of this glyph along the run, converted to an angle about the medal's centre.
        var _a = _a_mid + ((_run + _cw * 0.5) - _total * 0.5) / _r;
        var _t = radtodeg(arctan2(-cos(_a), -sin(_a)));
        var _px2 = _cx + cos(_a) * _r, _py2 = _cy + sin(_a) * _r;
        draw_set_colour(_col_shadow);
        draw_text_transformed(_px2 - VST_LX * _o, _py2 - VST_LY * _o, _ch, _sc, _sc, _t);
        draw_set_colour(_col_face);
        draw_text_transformed(_px2, _py2, _ch, _sc, _sc, _t);
        _run += _cw;
    }
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    return _sc;
}

/// A wrapped block of body copy, in the plain face, left aligned. No emboss: paragraph text struck
/// in relief is unreadable, and the panels this appears on are paper, not metal.
function vst_text_body(_text, _x, _y, _w, _px, _col) {
    draw_set_font(fnt_vestige);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_colour(_col);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    draw_text_ext_transformed(_x, _y, _text, _base * 1.34, _w / _sc, _sc, _sc, 0);
    return string_height_ext(_text, _base * 1.34, _w / _sc) * _sc;
}

/// One line of plain text, left aligned, scaled to fit.
function vst_text_line(_text, _x, _y, _maxw, _px, _col, _bold) {
    draw_set_font(_bold ? fnt_vestige_title : fnt_vestige);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_colour(_col);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    draw_text_transformed(_x, _y, _text, _sc, _sc, 0);
    return _sc;
}

/// ============================================================================================
/// SCREEN EFFECTS - the only alpha-blended draws in the package, and they live here
///
/// ⚠️ THE PART PATH DELIBERATELY HAS NO ALPHA. A role resolves to a colour, and that is the whole
/// contract - it is what lets the relief engine reason about five discrete values and what stops a
/// buyer's own blend mode changing what a medal looks like. The strike flash and the shock ring
/// genuinely need blending, so they are written here as two named functions that set alpha and put
/// it back, rather than as loose draw calls in the toast where the next edit would forget the
/// second half.
/// ============================================================================================

/// A soft radial flash, drawn as a few nested discs of falling alpha.
///
/// Nested discs rather than a gradient sprite, because this package ships no sprite of any kind
/// and a genuine radial gradient in GML needs a texture or a shader. Six rings is enough that the
/// banding is invisible at the sizes this is used, and it is checked by looking.
/// ⛔ LARGEST DISC FIRST, SMALLEST LAST, AND THE FIRST VERSION HAD IT BACKWARDS. MEASURED BY LOOKING
/// at the strike sheet: drawn smallest-first, every dim outer disc is painted straight over the
/// bright core, so the whole thing flattens into a uniform grey donut - the exact opposite of a
/// flash. Painter's order is not a detail when the layers are translucent; it IS the gradient.
/// ⚠️ TWELVE DISCS, AND SIX LEFT VISIBLE BANDING. On a near-black page each step in the stack shows
/// as a concentric ring, and six of them read as a target rather than as a glow. Doubling the count
/// and halving the per-disc alpha costs nothing measurable and the banding goes. It is still a step
/// function - a true radial gradient needs a texture or a shader, and this package ships neither -
/// but at twelve steps the step is under two per cent of the range and invisible at any size the
/// flash is drawn at.
function vst_render_flash(_cx, _cy, _r, _col, _alpha) {
    if (_alpha <= 0 || _r <= 0) return;
    var _old = draw_get_alpha();
    draw_set_colour(_col);
    for (var _i = 11; _i >= 0; _i--) {
        var _t = _i / 11;
        draw_set_alpha(_alpha * (1 - _t) * 0.155);
        draw_circle(_cx, _cy, _r * (0.22 + _t * 0.78), false);
    }
    draw_set_alpha(_old);
}

/// An expanding shock ring.
function vst_render_ring(_cx, _cy, _r, _w, _col, _alpha) {
    if (_alpha <= 0 || _r <= 0) return;
    var _old = draw_get_alpha();
    draw_set_alpha(_alpha);
    draw_set_colour(_col);
    vst_render_arc(_cx, _cy, _r, 0, VST_TAU, _w);
    draw_set_alpha(_old);
}

/// A flat filled rectangle at an alpha - the scrim behind a modal trophy case.
function vst_render_scrim(_x, _y, _w, _h, _col, _alpha) {
    if (_alpha <= 0) return;
    var _old = draw_get_alpha();
    draw_set_alpha(_alpha);
    draw_set_colour(_col);
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);
    draw_set_alpha(_old);
}

/// ============================================================================================
/// CACHING - the path a buyer's game should actually use
/// ============================================================================================

/// Render a part list once into a sprite and hand it back.
///
/// A hero medal is a few thousand primitives. Drawing thirty of them per frame from geometry is
/// tens of thousands of draw calls per frame and it WILL show up in a buyer's profiler, so the
/// honest thing is to ship the cache rather than let them discover the cost and write their own.
///
/// ⚠️ THE CALLER OWNS THE SPRITE AND MUST sprite_delete IT. A generator that hands out sprites with
/// no stated ownership is a leak with a nice API on top; the demo object's Clean Up event deletes
/// every sprite it made, and the Readme says this in the same words.
///
/// ⚠️ AND IT MUST NOT BE CALLED FROM A DRAW EVENT. surface_set_target inside a draw event nests
/// render targets, and on some drivers that silently produces an empty sprite rather than an error
/// - the exact shape of failure this wing keeps recording. Build in Create, draw in Draw.
function vst_render_to_sprite(_parts, _pal, _w, _h, _pad) {
  // Guard: a public entry point must REFUSE a bad handle, never throw (2026-09-07).
    if (!is_array(_parts) || !is_real(_w) || !is_real(_h) || _w < 1 || _h < 1) return -1;
    var _pd = is_undefined(_pad) ? 0 : _pad;
    var _surf = surface_create(_w, _h);
    surface_set_target(_surf);
    draw_clear_alpha(_pal.ground, 0);
    vst_render_in_rect(_parts, _pal, _pd, _pd, _w - _pd * 2, _h - _pd * 2, 0, undefined);
    surface_reset_target();
    var _spr = sprite_create_from_surface(_surf, 0, 0, _w, _h, false, false, _w * 0.5, _h * 0.5);
    surface_free(_surf);
    return _spr;
}
