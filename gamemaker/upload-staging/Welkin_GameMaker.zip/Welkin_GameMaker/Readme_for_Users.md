# Welkin — Skies and weather that draw themselves

**For GameMaker 2024.11 and newer. Pure GML. No sprites, no shaders, no extensions.**

Welkin draws the sky behind your game: the gradient that belongs to the hour, the cloud deck,
the horizon behind it, the sun and the moon, the weather falling through it, and the light state
your own scene can read so everything else in the frame agrees with the sky.

Everything on the store page was rendered by this package. There is not one image file in it.

---

## Install

1. In the IDE: **Tools ▸ Import Local Package**, choose `Welkin.yymps`.
2. Import **all** resources when the dialog asks.
3. Open **`rm_welkin_demo`** and press **Run**.

That room is the quickstart and it is also the smoke test — if it runs, the package imported
cleanly. Scrub time, change the weather, step through the year, and watch the readout.

### What you get

| | |
| --- | --- |
| `scripts/wlk_*` | 12 scripts, raw readable GML, header-documented |
| `objects/obj_welkin_demo` | the demo driver — read it, it is the shortest possible usage example |
| `rooms/rm_welkin_demo` | the runnable demo room |
| `fonts/fnt_welkin*` | Open Sans, used **only** by the demo readout (see *Fonts* below) |

---

## The whole thing in one call

```gml
// Create
sky = wlk_sky_create(52, 7);      // latitude 52 N, seed 7

// Step
wlk_sky_step(sky, delta_time / 1000000);

// Draw — the sky, the deck, the land and the light, inside this rectangle
wlk_sky_draw(sky, 0, 0, room_width, room_height);
```

That is the entire minimum integration. Three calls.

### Driving it

```gml
wlk_sky_set_time(sky, 18.5);                       // 18:30
wlk_sky_set_day(sky, 172);                         // day of year — drives the sun's declination
wlk_sky_force_weather(sky, WLK_WX_DOWNPOUR, 1.0);  // snap, no transition
wlk_sky_next_front(sky);                           // or let a front roll in over several seconds
```

### Reading the light back

The point of a sky system is that the rest of the scene agrees with it. `wlk_sky_light` gives you
the state to tint sprites, colour your own shadows, or decide whether the streetlamps are on:

```gml
var _L = wlk_sky_light(sky);
//  _L.alt      sun altitude in degrees, negative at night
//  _L.az       where the sun is across the frame, -1 left .. +1 right
//  _L.direct   how much direct sunlight there is, 0 at night or under storm cloud
//  _L.ambient  fill light — never reaches zero, so a night scene is dim and not black
//  _L.warmth   0 cold/blue .. 1 warm/orange
//  _L.flash    lightning, 0 except during a strike
//  _L.lx,_L.ly a unit vector pointing at the sun, for your own shading
```

---

## What is in the corpus

**43 authored forms**, each one drawn from data rather than blitted from an atlas:

- **14 cloud genera** — cumulus humilis, mediocris and congestus, cumulonimbus, stratocumulus,
  stratus, nimbostratus, altocumulus, altostratus, cirrus, cirrostratus, cirrocumulus,
  lenticular, mammatus. They differ in **silhouette**, which is what you can actually tell apart
  in a sky, and the self-test asserts that no two collapse into each other.
- **10 horizon profiles**, each in three depth ranks — open sea, plains, rolling downs, conifer
  ridge, broadleaf woodland, foothills, mountains, alpine peaks, mesa country, city skyline.
- **11 drawn weathers** — drizzle, rain, downpour, snow, blizzard, sleet, hail, mist, fog,
  lightning, rainbow. (`WLK_WX_CLEAR` is a twelfth *state*; it draws nothing, so it is not counted
  as a form.)
- **8 moon phases**, with a terminator that is a half ellipse — so a crescent is a crescent and
  not a quarter with a smaller disc bitten out of it.

### The colour is the product

The sky is a **five-stop Oklch ramp** whose lightness, chroma *and* hue each travel independently,
keyed at seven real astronomical altitudes. Clouds take their material **from that ramp**: the lit
face is sunlight, the shadow face is the sky beside them. Nothing is authored per hour — a sunset
cloud is orange on top and violet underneath because the sky above it is orange and the sky beside
it is violet.

The seasons are not presets. They fall out of the solar position equation, so latitude 68 in June
genuinely has a different day from latitude 8, and midwinter at 52 is genuinely dark at 17:00.

---

## Honest limits — please read before buying

- **This is a BACKDROP.** It draws the sky, the cloud deck and the land silhouette behind your
  scene. It is **not** a 2D lighting engine: it does not light your sprites, cast shadows from
  them, or touch your normal maps. It hands you a light state (`wlk_sky_light`) and what you do
  with it is yours. If you want per-sprite lighting, buy a lighting extension — they are good, and
  this is not one.
- **It draws into the rectangle you give it** and does not manage your rooms, layers or cameras.
- **Verification is honest about what it covers.** The package ships an in-engine self-test —
  **284 assertions, 0 failures** on a real Igor-built executable — covering geometry, the solar
  equation, the colour ramp and the corpus. That proves the maths and the shapes. It cannot prove
  a picture is *attractive*; that part was reviewed by looking at it.
- **GML cannot be unit-tested outside the engine.** Everything above was measured by running the
  compiled product, not by a mock.

## Performance

The sky is redrawn each frame from geometry. On a 1080p frame with a full storm deck this is a few
hundred primitives — cheap, but it is not free and it is not a static background. If you would
rather render it once and reuse it, bake it into a sprite:

```gml
// Create — YOU own the sprite; sprite_delete it in Clean Up.
spr = wlk_sky_bake(sky, 960, 540);

// Draw
draw_sprite(spr, 0, 0, 0);
```

⚠️ **A baked sky is a still.** The sky animates — clouds drift, fronts roll in, lightning strikes —
so a bake is for a fixed moment (a menu backdrop, a loading screen, a paused scene), not a drop-in
replacement for `wlk_sky_draw` in a running game. Re-bake after changing the time or the weather.
It returns `-1` rather than a blank sprite if handed something that is not a sky, and must not be
called from a Draw event: nesting render targets can silently produce an empty sprite.

## Bad input is refused, not fatal

Nothing in this package throws at your code. The setters and `wlk_sky_next_front` return `undefined`
if handed something that is not a sky — check with `is_struct()`. `wlk_sky_draw` draws nothing and
returns. `wlk_sky_bake` returns `-1`, which `sprite_exists()` reports as false.

**`wlk_sky_light` is the deliberate exception and returns a neutral night state**, never `undefined`.
You are told to read seven fields off it and tint your scene with them, so handing back `undefined`
would only move the crash into your draw event, further from the cause. A dim, sunless, un-flashing
state is the honest answer to "I do not know what this sky is", and it keeps the promise above that
ambient never reaches zero.

`wlk_sky_force_weather` also refuses a weather id outside `WLK_WX_CLEAR .. WLK_WX_RAINBOW`, because
an out-of-range id would set a state nothing can draw — a silently empty sky rather than an error.

## Namespacing

Every script, macro and global in this package is prefixed `wlk_` / `WLK_`. GML's global namespace
is flat, and a collision in your project is a support ticket nobody can debug remotely.

## Fonts

`fnt_welkin` and `fnt_welkin_title` are **Open Sans** (Apache-2.0 — see
`fonts/THIRD-PARTY-NOTICES.txt` and `fonts/Apache-2.0.txt`). They are used **only by the demo
room's readout**. The sky itself draws no text, so if you delete them you lose the demo readout
and nothing else.

## Licence

One seat, unlimited commercial games, no redistribution of the source as an asset. Full terms in
`LICENSE.txt`.

---

*Welkin — Core Systems Asset Factory.*
*Built with AI assistance; disclosed on the store listing.*
