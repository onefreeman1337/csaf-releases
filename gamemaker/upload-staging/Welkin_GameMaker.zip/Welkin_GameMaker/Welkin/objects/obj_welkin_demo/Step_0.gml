/// @description Step - the clock, and the demo's controls

// delta_time is MICROseconds. Dividing by 1000 gives milliseconds and a clock sixty times too
// fast, which is the kind of error that looks like a design choice.
var _dt = delta_time / 1000000;

if (!paused) {
    wlk_sky_step(sky, _dt);
    // The hour grid is frozen by design: it is a comparison, and twelve cells all animating is
    // twelve things moving and nothing being compared.
}

if (keyboard_check_pressed(vk_right) || keyboard_check_pressed(ord("D"))) {
    page = (page + 1) % array_length(pages);
}
if (keyboard_check_pressed(vk_left) || keyboard_check_pressed(ord("A"))) {
    page = (page + array_length(pages) - 1) % array_length(pages);
}
if (keyboard_check_pressed(vk_space)) paused = !paused;
if (keyboard_check_pressed(ord("R"))) show_readout = !show_readout;

// Scrub the clock by hand. This is the control a buyer reaches for first, because the question
// they arrive with is "what does dusk look like".
if (keyboard_check(vk_up))   wlk_sky_set_time(sky, sky.hour + _dt * 3.0);
if (keyboard_check(vk_down)) wlk_sky_set_time(sky, sky.hour - _dt * 3.0 + 24.0);

// Step through the year, which is what makes the season model visible: the same hour in January
// and in June is a different sky at latitude 52.
if (keyboard_check(ord("Q"))) wlk_sky_set_day(sky, max(1, sky.day - 1));
if (keyboard_check(ord("E"))) wlk_sky_set_day(sky, min(365, sky.day + 1));

// Cycle the weather on the live page, and the weather grid page independently.
if (keyboard_check_pressed(ord("W"))) {
    if (page == 3) {
        wx_page = (wx_page + 1) % WLK_WEATHER_N;
    } else {
        var _next = (wlk_sky_weather_now(sky) + 1) % WLK_WEATHER_N;
        wlk_sky_set_weather(sky, _next, 1.0);
    }
}

// Hand the weather back to the system.
if (keyboard_check_pressed(ord("F"))) sky.auto_weather = true;
