/// @description Draw GUI - the four demo pages

var _w = display_get_gui_width();
var _h = display_get_gui_height();

switch (page) {

    // ---- 1. THE LIVE SKY. One call. That is the whole point of the page. -------------------
    case 0: {
        wlk_sky_draw(sky, 0, 0, _w, _h);
    } break;

    // ---- 2. TWELVE HOURS side by side ------------------------------------------------------
    // The page that answers the only question that matters about a day/night system: is this a
    // real progression, or is it one picture with a colour multiplied over it?
    case 1: {
        var _cols = 4, _rows = 3;
        var _cw = _w / _cols, _ch = _h / _rows;
        for (var _i = 0; _i < 12; _i++) {
            var _cx = (_i % _cols) * _cw;
            var _cy = floor(_i / _cols) * _ch;
            wlk_sky_draw(hour_skies[_i], _cx, _cy, _cw, _ch);
            var _pal = wlk_sky_palette(hour_skies[_i], wlk_sky_light(hour_skies[_i]));
            wlk_text_line(string(_i * 2) + ":00", _cx + 10, _cy + 8, _cw - 20, 15, _pal.s0, true);
        }
    } break;

    // ---- 3. THE FOURTEEN CLOUD GENERA ------------------------------------------------------
    case 2: {
        var _light = wlk_sky_light(grid_sky);
        var _pal = wlk_sky_palette(grid_sky, _light);
        wlk_lamp_set(_light.lx, _light.ly);
        var _cols = array_create(WLK_STOPS);
        for (var _s = 0; _s < WLK_STOPS; _s++) _cols[_s] = variable_struct_get(_pal, "s" + string(_s));
        wlk_render_ramp(0, 0, _w, _h, _cols, [0.36, 0.27, 0.21, 0.16]);

        var _cc = 5, _rr = 3;
        var _cw = _w / _cc, _ch = (_h - 40) / _rr;
        for (var _i = 0; _i < WLK_CLOUD_N; _i++) {
            var _cx = (_i % _cc) * _cw + _cw * 0.5;
            var _cy = floor(_i / _cc) * _ch + _ch * 0.5 + 20;
            // Each genus gets its OWN material, so a cirrus wisp and a cumulonimbus do not share a
            // ramp - which is what makes the thin ones read as thin.
            var _cpal = wlk_air_cloud_ramp(_pal.stops, _light, wlk_cloud_thick(_i));
            var _s = 0; repeat (WLK_STOPS) {
                variable_struct_set(_cpal, "s" + string(_s), _cols[_s]); _s++;
            }
            _cpal.line = _pal.line;
            wlk_render_parts(wlk_cloud_build(_i, 3), _cpal, _cx, _cy, _cw * 0.86, 0, 1, undefined);
            wlk_text_line(wlk_cloud_name(_i), _cx - _cw * 0.46, _cy + _ch * 0.32, _cw * 0.92,
                          12, _pal.s0, false);
        }
        wlk_lamp_reset();
    } break;

    // ---- 4. THE TWELVE WEATHERS ------------------------------------------------------------
    // One at a time and full frame, because precipitation is a density and a density cannot be
    // judged in a thumbnail.
    default: {
        var _s = wlk_sky_create(52, 7);
        wlk_sky_set_time(_s, 15.0);
        wlk_sky_force_weather(_s, wx_page, 1.0);
        _s.t = sky.t;
        _s.strike = sky.strike;
        _s.strike_i = sky.strike_i;
        wlk_sky_draw(_s, 0, 0, _w, _h);

        var _pal = wlk_sky_palette(_s, wlk_sky_light(_s));
        wlk_text_line(string(wx_page + 1) + " / " + string(WLK_WEATHER_N) + "   "
                    + string_upper(wlk_weather_name(wx_page)),
                      24, _h - 46, _w - 48, 20, _pal.s0, true);
    } break;
}

// ---- the readout ---------------------------------------------------------------------------
if (show_readout) {
    var _pal = wlk_sky_palette(sky, wlk_sky_light(sky));
    var _L = wlk_sky_light(sky);
    var _hh = floor(sky.hour);
    var _mm = floor(frac(sky.hour) * 60);
    var _t = "WELKIN  " + pages[page]
           + "     " + string(_hh) + ":" + (_mm < 10 ? "0" : "") + string(_mm)
           + "   day " + string(sky.day)
           + "   sun " + string_format(_L.alt, 1, 1) + " deg"
           + "   " + wlk_weather_name(wlk_sky_weather_now(sky));
    wlk_text_line(_t, 18, 14, _w - 36, 15, _pal.s0, true);
    wlk_text_line("ARROWS page / scrub time   Q E day   W weather   F auto   SPACE pause   R readout",
                  18, 34, _w - 36, 11, _pal.s1, false);
}
