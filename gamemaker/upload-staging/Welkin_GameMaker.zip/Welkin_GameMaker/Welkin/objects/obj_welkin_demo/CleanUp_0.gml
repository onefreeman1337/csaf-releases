/// @description Clean Up

// This demo draws every frame from geometry and owns no sprites, so there is nothing to free here.
//
// THE EVENT EXISTS ANYWAY, AND SO DOES THIS COMMENT, because the caching path a buyer's game
// SHOULD use does hand out sprites: wlk_render_to_sprite returns a sprite the CALLER owns and must
// sprite_delete. A generator that hands out sprites with no stated ownership is a leak with a nice
// API on top, and the one place a reader looks for the matching free is the Clean Up event.
//
// If you copy this object as the starting point for your own, and you switch to the cached path,
// this is where the sprite_delete calls belong.
