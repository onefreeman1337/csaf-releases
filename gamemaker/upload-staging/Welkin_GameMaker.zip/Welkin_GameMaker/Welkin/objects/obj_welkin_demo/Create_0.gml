/// @description Create - the demo room, and the two headless entry points

// Scanned from 0 to parameter_count() INCLUSIVE. GameMaker has never been consistent about
// whether index 0 is the program name or the first argument, an out-of-range read returns "",
// and every product in this wing that ships a headless mode does it this way.
global.wlk_stage = 0;
global.wlk_mode  = "demo";
var _pc = parameter_count();
for (var _i = 0; _i <= _pc; _i++) {
    var _p = string_lower(parameter_string(_i));
    if (_p == "-selftest") global.wlk_mode = "selftest";
    if (_p == "-bake")     global.wlk_mode = "bake";
}

if (global.wlk_mode != "demo") {
    // A GML RUNTIME ERROR OPENS A MODAL DIALOG, and headless there is nobody to dismiss it, so the
    // process never exits and the runner reports a meaningless timeout. Installing this handler is
    // what turns an opaque four minute hang into a stage number and a message.
    exception_unhandled_handler(function(_ex) {
        var _name = (global.wlk_mode == "bake") ? "wlk_bake.json" : "wlk_selftest.json";
        var _msg = string(_ex.message) + "  [" + string(_ex.script) + ":" + string(_ex.line) + "]";
        var _f = file_text_open_write(_name);
        file_text_write_string(_f,
            "{\"crash\":true,\"stage\":" + string(global.wlk_stage)
            + ",\"message\":\"" + string_replace_all(_msg, "\"", "'") + "\"}");
        file_text_close(_f);
        game_end();
    });

    if (global.wlk_mode == "bake") wlk_bake_run(); else wlk_selftest_run();
    game_end();
    exit;
}

// ---- the interactive demo --------------------------------------------------------------------
//
// A runnable demo room is mandatory in this wing, and not as a courtesy: GML cannot be tested
// outside the engine, so this room is simultaneously the buyer's quickstart, the source of the
// store GIF, and the only hands-on smoke test that exists. It is built out of the same public
// calls the Readme documents - nothing here reaches into an internal.
//
// FOUR PAGES, because a live sky alone demonstrates one of the four things being sold. The hour
// grid is what proves the sky is not one gradient with a hue slider; the corpus pages are what
// prove the volume.

sky = wlk_sky_create(52, 7);
wlk_sky_set_time(sky, 6.4);
wlk_sky_force_weather(sky, WLK_WX_CLEAR, 0);

page  = 0;
pages = ["LIVE SKY", "TWELVE HOURS", "FOURTEEN CLOUDS", "TWELVE WEATHERS"];
paused = false;
show_readout = true;

// Page 2 builds twelve skies, one every two hours, and draws them as a grid. They are separate
// sky structs rather than one struct re-timed each cell, so the page is a genuine side-by-side of
// twelve independent states rather than a flicker book.
hour_skies = array_create(12);
for (var _i = 0; _i < 12; _i++) {
    var _s = wlk_sky_create(52, 7);
    wlk_sky_set_time(_s, _i * 2);
    wlk_sky_force_weather(_s, WLK_WX_CLEAR, 0);
    hour_skies[_i] = _s;
}

// Pages 3 and 4 need a palette that is not the live one, or every cloud in the grid would be lit
// by whatever the clock happens to be doing and half of them would be silhouettes. A fixed
// mid-morning light shows the forms.
grid_sky = wlk_sky_create(52, 7);
wlk_sky_set_time(grid_sky, 10.0);
wlk_sky_force_weather(grid_sky, WLK_WX_CLEAR, 0);

wx_page = 0;

// The demo owns no sprites, so Clean Up has nothing to free - but the event exists and says so,
// because the caching path a buyer's game should use DOES hand out sprites it must delete.
