{
  "$GMScript": "v1",
  "%Name": "wlk_cloud",
  "isCompatibility": false,
  "isDnD": false,
  "name": "wlk_cloud",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}