/// WELKIN - wlk_cloud. THE CORPUS, PART I: fourteen cloud forms.
///
/// Fourteen clouds, ten horizons, eleven drawn weathers and eight moon phases: forty-three forms,
/// every one authored by hand as data and drawn from that data. There is no sprite in this package.
///
/// ⚠️ ELEVEN, NOT TWELVE, AND THE DIFFERENCE IS DELIBERATE. WLK_WEATHER_N is 12 because CLEAR is a
/// weather STATE the sky can be in - but it draws nothing (wlk_weather_build returns an empty part
/// list for it), so it is not a FORM and wlk_selftest counts WLK_WEATHER_N - 1. This line said
/// "twelve weathers ... forty-three forms" until 2026-08-28, which does not add up, and the store
/// copy must use the counted number the suite prints, never the one in a comment.
///
/// ⛔ THE FOURTEEN ARE THE REAL CLOUD GENERA, AND THAT IS A DESIGN DECISION, NOT A FLOURISH. The
/// cheap way to claim variety is one blob with a randomised lobe count, and it produces fourteen
/// pictures of the same cloud. Real clouds are classified by ALTITUDE and by whether they are
/// convective or layered, and those two axes are precisely what changes a SILHOUETTE: a cumulus is
/// a heap with a flat bottom, a cirrus is a stroke with no bottom at all, a lenticular is a lens, a
/// mammatus hangs downward. Authoring the genera gets silhouette variety for free and gets it
/// correct, and a buyer who knows what an altocumulus looks like sees one.
///
/// ⛔ AND THE WING HAS PAID FOR THE OPPOSITE APPROACH. Wings/GameMaker/CLAUDE.md records it twice:
/// "A DIFFERENCE DRAWN INSIDE A FILLED SHAPE IS NOT A DIFFERENCE IN THE SHAPE" - two forms that
/// differ only in internal detail measured at a distinctness of exactly zero, because at the size
/// anything actually renders, the interior is one mass. A tell must change AREA, SPACING or
/// SILHOUETTE. Every one of the fourteen below differs from every other in outline, and
/// wlk_selftest measures that rather than trusting it.
///
/// -- HOW A CLOUD IS BUILT ---------------------------------------------------------------------
/// A convective cloud is the UNION of a few discs, sampled as a height profile over x. That
/// matters and is not an implementation detail:
///
/// ⛔ DRAWING THREE OVERLAPPING DISCS AND BEVELLING EACH ONE IS THE FAILURE THIS WING ALREADY
/// SHIPPED AND FIXED ON ANOTHER PRODUCT - "A CHAIN OF MASSES READS AS A CHAIN": every disc gets
/// its own lit rim, so the joins between them draw bright arcs THROUGH the middle of the cloud and
/// the result reads as a bunch of balloons. Sampling the union gives ONE outline with ONE rim, so
/// the lobes read as the same body of vapour - which is what they are.
///
/// -- COORDINATES ------------------------------------------------------------------------------
/// Unit box [-0.5, 0.5], y DOWN. WLK_CLOUD_BASE = 0.30 is the flat underside every convective form
/// sits on, so a cumulus and a stratocumulus authored a week apart share one cloud deck with no
/// per-form fudge. Forms with no flat base (cirrus, mammatus, lenticular) say so in their own
/// builder and are the exceptions that prove the anchor is worth having.
///
/// ⚠️ THIS FILE NEVER CALLS wlk_incise OR wlk_ridge. Both resolve their lit side from the FIXED
/// WLK_LX/WLK_LY macros rather than from the movable lamp, which is correct for the package's
/// interface furniture and wrong for anything in the sky - a groove in a cloud would stay lit from
/// the upper left while the cloud around it followed the sun. Sky forms use wlk_bevel only.
/// ============================================================================================

#macro WLK_CLOUD_N 14

/// The flat underside of a convective cloud, in unit-box y.
#macro WLK_CLOUD_BASE 0.30

/// How finely a cloud outline is sampled. 44 is measured, not chosen: below about 30 the lobe
/// valleys go visibly angular, and above about 60 the extra points cost bevel time every frame and
/// change nothing on screen at 720p.
#macro WLK_CLOUD_SEGS 44

/// ============================================================================================
/// NAMES AND MATERIAL
/// ============================================================================================

function wlk_cloud_name(_i) {
    switch (_i) {
        case  0: return "Cumulus humilis";
        case  1: return "Cumulus mediocris";
        case  2: return "Cumulus congestus";
        case  3: return "Cumulonimbus";
        case  4: return "Stratocumulus";
        case  5: return "Stratus";
        case  6: return "Nimbostratus";
        case  7: return "Altocumulus";
        case  8: return "Altostratus";
        case  9: return "Cirrus";
        case 10: return "Cirrostratus";
        case 11: return "Cirrocumulus";
        case 12: return "Lenticular";
        default: return "Mammatus";
    }
}

/// Optical thickness, 0..1. Drives wlk_air_cloud_ramp: a cirrus wisp barely shades at all, a
/// cumulonimbus is deep enough that its underside goes almost as dark as the sky can make it.
/// ⚠️ THIS IS WHY A STORM READS AS A STORM without a single authored storm colour.
function wlk_cloud_thick(_i) {
    switch (_i) {
        case  0: return 0.42;
        case  1: return 0.55;
        case  2: return 0.72;
        case  3: return 0.95;
        case  4: return 0.50;
        case  5: return 0.40;
        case  6: return 0.88;
        case  7: return 0.34;
        case  8: return 0.26;
        case  9: return 0.12;
        case 10: return 0.10;
        case 11: return 0.16;
        case 12: return 0.58;
        default: return 0.78;
    }
}

/// How high in the frame this genus belongs, 0 (skimming the horizon) .. 1 (high cirrus).
/// Used by wlk_sky to stack a deck correctly: low cloud must never draw above high cloud.
function wlk_cloud_level(_i) {
    switch (_i) {
        case  0: return 0.30; case  1: return 0.34; case  2: return 0.42; case  3: return 0.50;
        case  4: return 0.22; case  5: return 0.14; case  6: return 0.20; case  7: return 0.62;
        case  8: return 0.58; case  9: return 0.86; case 10: return 0.82; case 11: return 0.90;
        case 12: return 0.46; default: return 0.26;
    }
}

/// ============================================================================================
/// THE UNION PROFILE
/// ============================================================================================

/// The top of the union of a set of discs, sampled as a rail of points.
///
/// _lobes is an array of [cx, cy, r]. For each sample x, the top is the HIGHEST point any disc
/// reaches there - which in y-down coordinates is the SMALLEST y. Samples no disc covers fall back
/// to the base, and the rail is trimmed to the covered span so a form never carries a run of
/// zero-height quads at its ends.
function wlk_cloud_top_rail(_lobes, _base, _segs) {
    var _nl = array_length(_lobes);
    var _x0 = 999, _x1 = -999;
    for (var _i = 0; _i < _nl; _i++) {
        _x0 = min(_x0, _lobes[_i][0] - _lobes[_i][2]);
        _x1 = max(_x1, _lobes[_i][0] + _lobes[_i][2]);
    }
    var _rail = array_create(_segs + 1);
    for (var _s = 0; _s <= _segs; _s++) {
        var _x = lerp(_x0, _x1, _s / _segs);
        var _top = _base;
        for (var _i = 0; _i < _nl; _i++) {
            var _cx = _lobes[_i][0], _cy = _lobes[_i][1], _r = _lobes[_i][2];
            var _dx = _x - _cx;
            if (abs(_dx) >= _r) continue;
            var _y = _cy - sqrt(_r * _r - _dx * _dx);
            if (_y < _top) _top = _y;
        }
        _rail[_s] = [_x, min(_top, _base)];
    }
    return _rail;
}

/// A flat base rail matching a top rail sample for sample.
function wlk_cloud_flat_base(_top, _base) {
    var _n = array_length(_top);
    var _rail = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _rail[_i] = [_top[_i][0], _base];
    return _rail;
}

/// A RAGGED base - the torn underside of a raining layer cloud.
///
/// ⚠️ THE RAGGEDNESS IS SEEDED FROM THE SAMPLE INDEX, NOT RANDOM. A base that re-rolls every frame
/// boils, and boiling is the single most obvious tell that a thing was generated rather than drawn.
/// Everything in this package that looks irregular is a deterministic function of position.
function wlk_cloud_ragged_base(_top, _base, _amp, _seed) {
    var _n = array_length(_top);
    var _rail = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _t = _i / (_n - 1);
        var _a = sin((_t * 7.3 + _seed) * WLK_TAU) * 0.6
               + sin((_t * 17.1 + _seed * 2.7) * WLK_TAU) * 0.3
               + sin((_t * 31.7 + _seed * 5.1) * WLK_TAU) * 0.1;
        _rail[_i] = [_top[_i][0], _base + _amp * (0.55 + 0.45 * _a)];
    }
    return _rail;
}

/// Close a top rail and a base rail into one simple outline, top left-to-right then base back.
///
/// ⛔ THE BASE IS WALKED IN REVERSE AND THAT IS THE WHOLE REASON THIS IS A FUNCTION. Walking both
/// rails forwards produces a figure-of-eight: the outline crosses itself in the middle, the fill
/// covers the wrong region, and wlk_inset throws its points far outside the shape so the bevel
/// explodes into hooks. The wing's constitution records this exact defect on another product,
/// where it surfaced two steps downstream as a false "clipped at x=0" from the ink check.
/// wlk_selftest asserts total turning on every form for this reason.
function wlk_cloud_outline(_top, _base) {
    var _n = array_length(_top);
    var _out = array_create(_n * 2);
    for (var _i = 0; _i < _n; _i++) _out[_i] = _top[_i];
    for (var _i = 0; _i < _n; _i++) _out[_n + _i] = _base[_n - 1 - _i];
    return _out;
}

/// Fill a rail pair and dome its edge. The strip fill is exact for a rail pair, where a triangle
/// fan is not: a fan from an interior point cannot see into the valley between two tall lobes, and
/// the missing wedge renders as a notch cut out of the cloud.
///
/// _b is the bevel reach. ⛔ IT IS A FRACTION OF THE SMALLEST LOBE, NOT A CONSTANT. The wing's
/// bevel law: a bevel wider than the feature it bevels turns that feature inside out - the inset
/// rings self-cross and the lobe renders as two shards with a gap. A cirrocumulus lobe is 0.02
/// across and a cumulonimbus lobe is 0.30; one constant cannot serve both.
function wlk_cloud_body(_top, _base, _b, _steps) {
    var _parts = [wlk_strip(_top, _base, "m2")];
    var _outline = wlk_cloud_outline(_top, _base);
    return wlk_append(_parts, wlk_bevel(_outline, _b, _steps, false));
}

/// The bevel reach for a lobe set: 35% of the smallest lobe radius, floored so a very fine form
/// still shows an edge and capped so a very coarse one does not turn into a dome with no face.
function wlk_cloud_bevel_for(_lobes) {
    var _r = 999;
    for (var _i = 0; _i < array_length(_lobes); _i++) _r = min(_r, _lobes[_i][2]);
    return clamp(_r * 0.35, 0.006, 0.055);
}

/// A LAYER-CLOUD LOBE SET THAT LANDS ON ITS OWN BASE AT BOTH ENDS.
///
/// ⛔ WHY THIS EXISTS, ADDED 2026-08-28 AFTER OPENING THE STORE SHEETS. Every layer cloud was
/// authored as a row of EQUAL discs at ONE height. wlk_cloud_top_rail trims the rail to the covered
/// span, so at the first and last covered column the top drops VERTICALLY from the disc's centre
/// height to the base - a wall exactly as tall as the cloud is thick. Four of the fourteen genera
/// rendered as grey CONCRETE BOXES with hard vertical sides, and it was worst on the two forms a
/// buyer sees most often, because nimbostratus and stratocumulus are what a rain sky is made of.
///
/// Nothing mechanical could see it: the outline was simple, closed, inside the box, deterministic
/// and distinct from the other thirteen. The sheet showed it in one look. Same law as the
/// cumulonimbus above, arriving from a different direction.
///
/// THE GEOMETRY. A disc whose centre sits ON the base line meets that base exactly at its own left
/// and right extreme, so its column of the union rail needs no wall at all. Taper the END discs
/// onto the base and the profile leaves the base smoothly, like real cloud thinning out at its
/// edge. Half-thickness follows sin(pi*u), which is zero at both ends by construction rather than
/// by a tuned constant.
///
/// _roll varies the RADIUS, not the height: that is what gives stratocumulus its lumpy rolled top
/// while leaving the thin veils smooth, and because radius is already near zero at the ends, a
/// strong roll cannot re-open the wall it was added to avoid.
/// _plateau (optional, default 1) FLATTENS THE MIDDLE. Both the height and the radius are driven by
/// _lift, so with _lift = sin(pi*u) the top rail is a smooth dome - right for a cloud bank and wrong
/// for an anvil, which is planed flat across its span and only rounds off at the ends. Multiplying
/// the lift and clamping gives a rail that is flat wherever sin(pi*u) >= 1/_plateau and tapers
/// outside it: at 2.4 the top is flat across the middle 70% and lands on the base at both ends.
function wlk_cloud_bank(_x0, _x1, _n, _base, _drop, _rmin, _rmax, _roll, _seed, _plateau) {
    var _pl = is_undefined(_plateau) ? 1.0 : _plateau;
    var _l = array_create(_n);
    for (var _k = 0; _k < _n; _k++) {
        var _u = _k / (_n - 1);
        var _lift = clamp(sin(pi * _u) * _pl, 0, 1);
        var _r = _rmin + (_rmax - _rmin) * _lift;
        _l[_k] = [lerp(_x0, _x1, _u),
                  _base - _drop * _lift,
                  _r * (1.0 + _roll * sin((_k * 1.9 + _seed) * 2.1))];
    }
    return _l;
}

/// ============================================================================================
/// THE FOURTEEN
///
/// Each returns a part list in the unit box. The lobe tables are the authored content of this
/// file - they are what a buyer is paying for, and they are readable and editable in place.
/// ============================================================================================

function wlk_cloud_build(_i, _seed) {
    var _sd = is_undefined(_seed) ? 0 : _seed;
    switch (_i) {

        // ---- 0. CUMULUS HUMILIS. Fair weather. Wider than it is tall - the defining proportion,
        // and the thing that separates it from every other cumulus at a glance.
        // ⚠️ THE TWO OUTER LOBES ARE CENTRED ON THE BASE LINE, ADDED 2026-08-28. The convective forms
        // had a milder version of the layer clouds' end wall - the outermost lobe sat 0.055 above the
        // base, so the rail dropped vertically by that much at the form's edge. Invisible on the
        // corpus card and plainly visible on the 1600px hero, where a cumulus is drawn 650px wide and
        // 0.055 is a 36px hard vertical cut down the side of the main cloud in the picture. A lobe
        // centred ON the base meets it exactly at its own extreme, so the silhouette curves down to
        // the flat bottom instead of falling off it. The flat BASE is correct and stays - a cumulus
        // really does have a flat underside; it is the SIDES that were wrong.
        case 0: {
            var _l = [[-0.33, 0.298, 0.064], [-0.22, 0.20, 0.115], [-0.02, 0.155, 0.145],
                      [0.19, 0.205, 0.105], [0.33, 0.245, 0.062], [0.40, 0.298, 0.056]];
            var _t = wlk_cloud_top_rail(_l, WLK_CLOUD_BASE, WLK_CLOUD_SEGS);
            var _b = wlk_cloud_flat_base(_t, WLK_CLOUD_BASE);
            return wlk_cloud_body(_t, _b, wlk_cloud_bevel_for(_l), 3);
        }

        // ---- 1. CUMULUS MEDIOCRIS. As tall as it is wide, and starting to build upward.
        case 1: {
            var _l = [[-0.36, 0.298, 0.070], [-0.26, 0.175, 0.098], [-0.09, 0.055, 0.155],
                      [0.10, 0.105, 0.135], [0.28, 0.195, 0.088], [0.00, 0.20, 0.145],
                      [0.38, 0.298, 0.062]];
            var _t = wlk_cloud_top_rail(_l, WLK_CLOUD_BASE, WLK_CLOUD_SEGS);
            var _b = wlk_cloud_flat_base(_t, WLK_CLOUD_BASE);
            return wlk_cloud_body(_t, _b, wlk_cloud_bevel_for(_l), 3);
        }

        // ---- 2. CUMULUS CONGESTUS. Taller than it is wide, cauliflower crown. The upper lobes
        // are SMALLER than the lower ones: a tower whose lobes stay one size reads as a column,
        // and the size gradient is what makes it read as boiling upward.
        // ⛔ THE LOBES MUST NEST, AND THE FIRST AUTHORING DID NOT. Scattering seven lobes across a
        // range of x with no containment rule left columns where a NARROW upper lobe was the only
        // cover, so the union profile dropped vertically to the base beside it and the form
        // rendered as a rectangular tower with a notch cut out of one corner - a chess rook. Every
        // check passed; the corpus sheet showed it immediately.
        //
        // A convective tower tapers, so each lobe's x span must sit INSIDE the span of the lobe
        // below it. Then the union has a continuously narrowing profile and no vertical walls.
        case 2: {
            var _l = [[-0.135, 0.296, 0.052], [ 0.135, 0.296, 0.052],
                      [ 0.000, 0.225, 0.130], [ 0.010, 0.120, 0.115], [-0.020, 0.020, 0.098],
                      [ 0.020, -0.070, 0.082], [-0.010, -0.145, 0.065], [ 0.030, -0.200, 0.048]];
            var _t = wlk_cloud_top_rail(_l, WLK_CLOUD_BASE, WLK_CLOUD_SEGS);
            var _b = wlk_cloud_flat_base(_t, WLK_CLOUD_BASE);
            return wlk_cloud_body(_t, _b, wlk_cloud_bevel_for(_l), 3);
        }

        // ---- 3. CUMULONIMBUS. The storm. ⭐ THE ANVIL IS THE ENTIRE SILHOUETTE and it is why this
        // form is instantly readable at any size: the tower hits the tropopause, cannot rise, and
        // spreads SIDEWAYS into a flat wide cap that overhangs downwind. Two wide shallow lobes
        // high up produce that overhang; the tower below is deliberately narrow so the cap reads
        // as wider than the thing holding it up.
        //
        // ⛔ AND IT IS THE ONE FORM IN THE CORPUS THE UNION-PROFILE REPRESENTATION CANNOT DRAW
        // WITHOUT HELP, WHICH IS WORTH STATING PLAINLY BECAUSE IT IS A LIMIT OF THE WHOLE METHOD.
        //
        // "Top profile over a flat base" has no way to express an OVERHANG. The anvil spreads out
        // sideways beyond the tower that holds it up, so at those columns the top is the anvil and
        // the base is still 0.30 - and the strip dutifully fills the entire column from the anvil
        // down to the ground. The cloud rendered as a wide slab with a ragged bottom. It read as a
        // tombstone, and 248 assertions had nothing to say about it: the outline was simple, the
        // form was inside its box, deterministic, and distinct from the other thirteen.
        //
        // The fix is a BASE THAT VARIES WITH x: 0.30 under the tower, and the anvil's own underside
        // everywhere else. The hard step between the two is not an artefact - it IS the edge of the
        // overhang, and drawing it is what makes the anvil read as an anvil.
        // ⭐ THE ONLY FORM IN THE CORPUS BUILT AS TWO BODIES, AND THE ONLY ONE THAT SHOULD BE.
        //
        // Two earlier attempts failed and both are worth recording, because they bracket the rule:
        //
        //   v1: ONE union profile over a flat base. "Top profile over flat base" has no way to
        //       express an OVERHANG, so every column under the anvil filled solid to the ground and
        //       the cloud rendered as a TOMBSTONE.
        //   v2: one profile over a base that jumped between the ground and the anvil's underside.
        //       Correct in principle; in practice it rendered as a TABLE WITH LEGS, and the point
        //       is that a shape whose picture disagrees with your model of it is a shape you do not
        //       control. Being clever there bought a defect that would have shipped.
        //
        // ⛔ THE WING'S "A CHAIN OF MASSES READS AS A CHAIN" LAW SAYS TO AUTHOR ONE MASS - and it
        // says so ONLY "where the real object genuinely has separate planes" is FALSE. A
        // cumulonimbus is the case where it is TRUE: a tower of convection with an ice anvil
        // spreading off the top of it against the tropopause really is two masses, seen as two.
        // Each is a clean union profile over its own flat base, they overlap where they meet, and
        // the anvil is drawn LAST so it sits in front of the tower it caps.
        // ⛔ v3, 2026-08-28. v2 SHIPPED INTO THE STORE SHEETS AND READ AS A NUCLEAR MUSHROOM CLOUD
        // in six cells across two sheets. The comment above it already said the goal was "an anvil
        // rather than a mushroom", every assertion was green, and the picture disagreed with all of
        // it - this wing's standing law that only the rendered sheet can settle a silhouette.
        //
        // THE TWO THINGS THAT MAKE A MUSHROOM, AND v2 HAD BOTH:
        //   1. A DOMED CAP. Four big discs at different heights give a rounded crown. A real incus
        //      hits the tropopause and CANNOT RISE - it is planed FLAT along its top. The fix is the
        //      stratus trick from case 5: many discs at ONE cy and ONE radius, closely spaced, whose
        //      union has a scallop of r - sqrt(r^2 - (spacing/2)^2) = 0.007 here. Flat.
        //   2. A TAPERING STEM. v2's tower radius SHRANK with height (0.100 -> 0.076), which is a
        //      stalk. A convective tower does the opposite: it FLARES as it rises, so the silhouette
        //      widens continuously into the cap instead of meeting it at a neck. Radius now grows
        //      0.098 -> 0.145, and the tower's crown is authored to land exactly at the anvil's top
        //      so the two masses merge rather than stack.
        // The anvil still spreads further right than left - that asymmetry is the downwind overhang
        // and it is the second reason the form cannot read as a mushroom, which is symmetric.
        // ⛔ AND v3's FIRST CUT REPRODUCED v2 EXACTLY - "A TABLE WITH LEGS", the failure the comment
        // above already recorded. Nine EQUAL discs on one line do give a planed top, and they also
        // give hard VERTICAL ENDS, because the rail is trimmed to the covered span and every disc is
        // the same height right up to the last one. A flat slab with square ends on a narrow tower
        // is a table. The anvil needs a flat top AND rounded ends, which is what _plateau is for:
        // flat across the middle 70%, tapering onto its own underside at both ends. The tower is
        // also wider now (0.115 -> 0.168 rather than 0.098 -> 0.145), because a cap this wide over a
        // narrow tower reads as furniture however well the cap is drawn.
        case 3: {
            // ⛔ AND THE TOWER WAS WIDENED AGAIN AFTER LOOKING AT THE WEATHER SHEET, WHERE EACH SKY
            // IS A QUARTER THE WIDTH OF THE CORPUS CARD. At corpus size the anvil-on-tower read
            // correctly; at cell size the same form read as a dark T, because a 0.33-wide tower
            // under a 0.74-wide cap IS a T once the relief detail falls below a pixel. This wing's
            // law: DRAW THE SAME THING SMALLER TO FIND THE LAYOUT BUGS - a form that only composes
            // at store-sheet size fails in the buyer's game, and the buyer's sky is small.
            // The cap:tower ratio is now 1.65 rather than 2.2, which is a storm mass with an anvil
            // on it rather than a bar on a post.
            var _tower = [[-0.06, 0.255, 0.165], [0.00, 0.185, 0.190],
                          [-0.03, 0.120, 0.215], [0.02, 0.062, 0.235],
                          [0.00, 0.055, 0.245]];
            // Span -0.322..0.422: inside the unit box, and centred right of the tower, which is the
            // downwind overhang - the second reason this cannot read as a (symmetric) mushroom.
            // ⚠️ THE OVERHANG CAME DOWN AGAIN AFTER THE THIRD SHEET. Cap:tower was 1.65 and STILL
            // read as a mushroom on the front sheet, where a storm head is ~80px wide - and this is
            // the third time this one form has had to be measured at the size it actually ships at
            // rather than at corpus size. A dramatic anvil overhang is what you see standing under a
            // thunderhead; what you see from across a valley, which is where a game camera is, is a
            // broad blocky mass with a flat top and a modest flare. At 1.21 it reads as weather at
            // 80px AND still resolves into a proper incus on the corpus card at 300px.
            var _anvil = wlk_cloud_bank(-0.24, 0.32, 13, -0.015, 0.085, 0.022, 0.098, 0.04, _sd, 2.4);

            var _tt = wlk_cloud_top_rail(_tower, WLK_CLOUD_BASE, WLK_CLOUD_SEGS);
            var _tb = wlk_cloud_ragged_base(_tt, WLK_CLOUD_BASE, 0.030, _sd + 0.31);
            var _parts = wlk_cloud_body(_tt, _tb, wlk_cloud_bevel_for(_tower), 3);

            // The anvil's own flat underside, drawn LAST so it caps the tower it sits on. Its base
            // is above the tower's widest point, so the overhang shows on both sides.
            var _at = wlk_cloud_top_rail(_anvil, -0.015, WLK_CLOUD_SEGS);
            var _ab = wlk_cloud_flat_base(_at, -0.015);
            return wlk_append(_parts, wlk_cloud_body(_at, _ab, wlk_cloud_bevel_for(_anvil), 3));
        }

        // ---- 4. STRATOCUMULUS. A low lumpy sheet: many small lobes, all the same height, filling
        // the full width. Reads as a ceiling rather than as an object.
        // ⚠️ THE LUMP AMPLITUDE WAS RAISED AFTER A MEASUREMENT, not after a look. At the first
        // authoring this and Stratus were both flat slabs about 0.13 high and the self-test put
        // them 0.0088 apart - inside the distinctness floor. They are meteorologically different
        // clouds and were being drawn as the same one. The fix is the REAL difference between
        // them: stratocumulus has ROLLS, so its top must visibly undulate.
        // ⚠️ 2026-08-28: re-laid on wlk_cloud_bank. The roll amplitude that makes this read as rolls
        // rather than as a slab is preserved - it moved from the HEIGHT of each lobe to its RADIUS,
        // which undulates the top just as visibly and cannot re-open the end wall.
        case 4: {
            var _l = wlk_cloud_bank(-0.44, 0.44, 11, WLK_CLOUD_BASE, 0.090, 0.042, 0.110, 0.26, _sd);
            var _t = wlk_cloud_top_rail(_l, WLK_CLOUD_BASE, WLK_CLOUD_SEGS);
            var _b = wlk_cloud_flat_base(_t, WLK_CLOUD_BASE);
            return wlk_cloud_body(_t, _b, wlk_cloud_bevel_for(_l), 2);
        }

        // ---- 5. STRATUS. Fog lifted off the ground. Almost no relief at all - and that is the
        // form, not a shortcut. A stratus with lobes is a stratocumulus.
        // ⭐ SEVENTEEN CLOSELY SPACED LOBES, NOT SEVEN WIDE ONES, AND THE REASON IS ARITHMETIC.
        // The scallop left between two overlapping discs is r - sqrt(r^2 - (spacing/2)^2). At
        // r = 0.10 and spacing 0.055 that is 0.004 - a top flat enough to read as a featureless
        // sheet, which IS this genus. Widening the discs instead would flatten it too, but the
        // union's x extent is min(cx-r) to max(cx+r), so a 0.30 radius pushes the form to 0.77
        // wide and straight out of the unit box - which the containment assertion would have
        // caught, one step after the wrong fix.
        //
        // The centres sit BELOW the base line on purpose: only the tops of the caps are inside the
        // body, which is what makes the slab thin.
        // ⚠️ 2026-08-28: the seventeen-lobe arithmetic above solved the FLATNESS of the top and had
        // nothing to say about the ENDS, where the slab still met the base as a vertical wall. The
        // bank keeps the flat top - a 0.03 roll is almost none - and lands it on the base.
        case 5: {
            var _l = wlk_cloud_bank(-0.44, 0.44, 15, WLK_CLOUD_BASE, 0.030, 0.035, 0.055, 0.03, _sd);
            var _t = wlk_cloud_top_rail(_l, WLK_CLOUD_BASE, WLK_CLOUD_SEGS);
            var _b = wlk_cloud_flat_base(_t, WLK_CLOUD_BASE);
            return wlk_cloud_body(_t, _b, 0.010, 2);
        }

        // ---- 6. NIMBOSTRATUS. The rain sheet: thick, featureless on top, TORN along the bottom.
        // The ragged base is the whole tell and it is the only cloud in the corpus whose underside
        // carries the identity.
        // ⚠️ 2026-08-28: this was the worst of the four boxes, because it is the thickest - a 0.135
        // radius at a constant height put a 0.25-tall vertical wall at each end, and nimbostratus
        // appears in five of the twelve weather cells. The torn base is untouched: it is still the
        // tell, and it now hangs off a bank that thins to nothing at both ends instead of off a
        // rectangle.
        case 6: {
            var _l = wlk_cloud_bank(-0.42, 0.42, 11, WLK_CLOUD_BASE, 0.115, 0.050, 0.140, 0.08, _sd);
            var _t = wlk_cloud_top_rail(_l, WLK_CLOUD_BASE, WLK_CLOUD_SEGS);
            var _b = wlk_cloud_ragged_base(_t, WLK_CLOUD_BASE, 0.075, _sd + 0.71);
            return wlk_cloud_body(_t, _b, 0.014, 2);
        }

        // ---- 7. ALTOCUMULUS. A mackerel sky: SEPARATE rolls with sky between them. ⚠️ These are
        // deliberately separate outlines rather than one union - the gaps ARE the form, and the
        // "author one mass" rule applies to shapes that must read as continuous, which this must
        // not. Each roll is bevelled on its own outline because each roll IS its own cloud.
        case 7: {
            var _parts = [];
            for (var _k = 0; _k < 7; _k++) {
                var _x = lerp(-0.42, 0.42, _k / 6);
                var _rr = 0.052 + 0.012 * sin(_k * 2.7 + _sd);
                var _cy = 0.16 + 0.055 * sin(_k * 1.13 + _sd * 1.9);
                var _l = [[_x - _rr * 0.55, _cy, _rr], [_x + _rr * 0.55, _cy, _rr * 0.88]];
                var _t = wlk_cloud_top_rail(_l, _cy + _rr * 0.72, 16);
                var _b = wlk_cloud_flat_base(_t, _cy + _rr * 0.72);
                wlk_append(_parts, wlk_cloud_body(_t, _b, _rr * 0.32, 2));
            }
            return _parts;
        }

        // ---- 8. ALTOSTRATUS. A featureless mid-level veil. Wide, thin, and the sun shows through
        // it as a bright patch rather than a disc - which wlk_celestial reads off the thickness.
        // ⚠️ 2026-08-28: laid on the bank like the other three veils. Six equal discs spanning
        // -0.595..0.595 also put this form well OUTSIDE the unit box at both ends, which the trim
        // hid by cutting it off square - so the wall and the overflow were the same defect.
        case 8: {
            var _l = wlk_cloud_bank(-0.44, 0.44, 13, 0.285, 0.050, 0.030, 0.070, 0.03, _sd);
            var _t = wlk_cloud_top_rail(_l, 0.285, WLK_CLOUD_SEGS);
            var _b = wlk_cloud_flat_base(_t, 0.285);
            return wlk_cloud_body(_t, _b, 0.008, 1);
        }

        // ---- 9. CIRRUS. Ice, five miles up, blown into strokes. ⛔ NO BASE, NO BEVEL, NO CLOSED
        // BODY - a cirrus bevelled like a cumulus reads as a white worm. It is drawn as tapered
        // ribbons along curved spines, which is also the ONLY form in the corpus whose gradient is
        // carried by ribbon WIDTH rather than by relief, because there is no volume to shade.
        // ⚠️ The hooked head (the "mare's tail") is the tell; a straight streak is a contrail.
        // ⛔ THE FIRST VERSION OF THIS FORM WAS THE WORST THING IN THE PRODUCT, AND ONLY OPENING
        // THE RENDERED SHEET FOUND IT. Five strands at a 0.030 half-width, spanning three quarters
        // of the box, with a hook drawn one ramp stop darker: at sunset that renders as a row of
        // thick saturated orange bands with dark red barbs on the end. It read as claw marks.
        // Every assertion passed - the form was deterministic, inside the box, and distinct from
        // the other thirteen. Distinct and WRONG.
        //
        // Cirrus is ICE at forty thousand feet, blown into filaments. What makes it read is that
        // it is THIN, PALE, NUMEROUS and RAGGED - eleven fine strands, not five fat ones. The
        // half-width came down by a factor of three and the count went up, which is the same law
        // this package applies to rain: carry the impression in COUNT, never in width.
        // ⛔ THIS FORM HAS BEEN WRONG TWICE AND BOTH TIMES ONLY THE RENDERED SHEET SAID SO.
        //   v1: five fat strands with a dark barb  -> read as CLAW MARKS.
        //   v2: eleven thinner strands, same barb  -> read as a row of FISHHOOKS, because a short
        //       curl of the same width as the stroke it hangs off IS a hook, whatever it is called.
        //
        // ⭐ THE THIRD VERSION DROPS THE HOOK ENTIRELY AND MAKES THE STRAND FIBROUS, which is the
        // actual structure of the thing. Cirrus is not a stroke. It is a BUNDLE of ice filaments
        // falling out of a shear layer, and what the eye reads is many fine near-parallel lines of
        // slightly different length lying along a common drift - the same reason a horse's tail
        // reads as a tail rather than as a shape. So each strand is now four to six filaments,
        // each a third of a pixel-width apart, each ending at its own point, with the whole bundle
        // curving gently along one spine. No barb, no curl, nothing that can close into a hook.
        //
        // This is the same law the rest of the package keeps re-learning from the other direction:
        // an impression is carried by COUNT, not by the width of one mark.
        case 9: {
            var _parts = [];
            // ⛔ v5, 2026-08-28: DENSER BUNDLES, NOT WIDER ONES. v4 fixed the sub-pixel dashes and
            // then read as an ORANGE BARCODE on the 1600px hero - which is the failure the comment
            // above already names, and v4 walked straight into it by WIDENING the filament spacing
            // to 0.0098. At hero scale the deck draws a cirrus at ~700px, so a 5-filament bundle
            // spaced 0.0098 apart is five separate lines 7px apart, and nine of those are a comb.
            //
            // The law this package keeps re-learning is COUNT, and v4 applied it to the wrong axis:
            // it kept nine strands and spread each one out. Twelve strands of eight-to-eleven
            // filaments at 0.0042 spacing merge into a soft fibrous streak at every size that
            // matters, because the filaments are close enough to read as ONE thing with structure
            // instead of as several things in a row.
            for (var _k = 0; _k < 12; _k++) {
                var _y = -0.19 + _k * 0.040 + 0.016 * sin(_k * 2.1 + _sd);
                var _x0 = -0.44 + 0.26 * wlk_frac01(sin(_k * 5.31 + _sd * 3.7) * 137.51);
                var _len = 0.34 + 0.36 * wlk_frac01(sin(_k * 2.77 + _sd * 1.9) * 219.13);
                var _fib = 8 + floor(wlk_frac01(sin(_k * 7.13 + _sd) * 91.7) * 4);
                for (var _f = 0; _f < _fib; _f++) {
                    // ⛔ EVERY ONE OF THESE FOUR LINES EXISTS TO BREAK A REGULARITY, because the
                    // version that spaced filaments evenly, ran them parallel and drew them all in
                    // one tone rendered as an ORANGE COMB - a hatched rectangle, not a wisp. That
                    // is this wing's recorded "barcode" failure arriving from a new direction: it
                    // is not caused by stroke width here, it is caused by EVENNESS.
                    //
                    // Irregular spacing, per-filament splay, per-filament length and - the one
                    // that does the most work - per-filament TONE. Filaments at three different
                    // ramp stops read as depth within the bundle; filaments at one stop read as a
                    // printed pattern however finely they are drawn.
                    var _j = wlk_frac01(sin(_k * 13.7 + _f * 29.3 + _sd) * 311.7);
                    var _off = (_f - (_fib - 1) * 0.5) * 0.0042 + (_j - 0.5) * 0.0075;
                    var _splay = (_j - 0.5) * 0.028;
                    var _s0 = _f * 0.020 * _len * _j;
                    var _s1 = _len * (0.62 + 0.38 * wlk_frac01(sin(_k * 3.1 + _f * 11.7) * 57.3));
                    // ⛔ v4, 2026-08-28: THE BRIGHT STOP IS NOW RARE. v3 split the bundle evenly
                    // across m2/m3/m4, so a third of every filament bundle was drawn at the LIT
                    // stop - which at sunset is a near-white warm value against a violet upper sky.
                    // Thirty of those at high contrast is not a wisp, it is a scratch field. A few
                    // bright filaments in a mostly mid-tone bundle still read as depth, and that is
                    // all the bright stop was ever doing.
                    var _role = (_j < 0.46) ? "m2" : ((_j < 0.86) ? "m3" : "m4");
                    var _spine = wlk_qbez([_x0 + _s0, _y + _off + 0.014],
                                          [_x0 + _s1 * 0.45, _y + _off - 0.016 + _splay * 0.5],
                                          [_x0 + _s1, _y + _off - 0.002 + _splay], 18);
                    // ⛔ AND THE TAIL NO LONGER GOES SUB-PIXEL. This is the actual cause of the
                    // "digital static" read, and it is a rasterisation defect, not a design one:
                    // this wing's constitution records that GML floors a stroke at 1.0px with no
                    // antialiasing, so A SUB-PIXEL QUAD RASTERISES TO DASHES. A tail half-width of
                    // 0.0004 is 0.6px even on the 1600px hero sheet, so every filament ended in a
                    // dotted line - forty-five dotted lines per sky, which is exactly what TV static
                    // is. The taper now stops at 0.0012 (1.9px on the hero, still above 1px in a
                    // 400px gallery cell), so the filament thins and then ENDS instead of
                    // disintegrating. v1 read as claw marks, v2 as fishhooks, v3 as static.
                    wlk_append(_parts, wlk_taper_ribbon(_spine, 0.0026, 0.0012, _role));
                }
            }
            return _parts;
        }

        // ---- 10. CIRROSTRATUS. The halo veil: a single vast thin sheet with no edge you can
        // point at. Drawn as one very wide, very shallow strip so it reads as a wash.
        case 10: {
            var _segs = 40;
            var _t = array_create(_segs + 1), _b = array_create(_segs + 1);
            for (var _s = 0; _s <= _segs; _s++) {
                var _x = lerp(-0.50, 0.50, _s / _segs);
                var _f = 1.0 - (_x * _x) * 2.6;          // fades out at both ends
                _t[_s] = [_x, 0.045 - 0.030 * max(_f, 0)];
                _b[_s] = [_x, 0.185 + 0.030 * max(_f, 0)];
            }
            return [wlk_strip(_t, _b, "m3")];
        }

        // ---- 11. CIRROCUMULUS. A fine grain of tiny high cells. The smallest lobes in the corpus,
        // and the reason wlk_cloud_bevel_for computes its reach from the smallest lobe rather than
        // using a constant: a 0.055 bevel on a 0.018 cell inverts it.
        case 11: {
            var _parts = [];
            for (var _row = 0; _row < 4; _row++) {
                for (var _k = 0; _k < 11; _k++) {
                    var _x = lerp(-0.44, 0.44, _k / 10) + 0.018 * sin((_row * 3.1 + _k) * 1.7);
                    var _y = -0.05 + _row * 0.075;
                    var _rr = 0.019 + 0.006 * sin((_k * 2.3 + _row * 1.9 + _sd) * 1.3);
                    var _l = [[_x, _y, _rr]];
                    // ⚠️ 0.18, NOT 0.62. A flat base 62% of a radius BELOW the centre leaves a wall
                    // 0.62r tall at each cell's left and right extreme, so every one of the 44 cells
                    // rendered as a tiny flat-bottomed TOMBSTONE and the sheet read as a graveyard.
                    // Cutting the chord close to the top of the disc leaves the arc doing almost all
                    // the outline, which is what makes a cirrocumulus cell read as a round puff.
                    var _t = wlk_cloud_top_rail(_l, _y + _rr * 0.18, 10);
                    var _b = wlk_cloud_flat_base(_t, _y + _rr * 0.18);
                    wlk_append(_parts, wlk_cloud_body(_t, _b, _rr * 0.30, 1));
                }
            }
            return _parts;
        }

        // ---- 12. LENTICULAR. A standing wave over a mountain - a smooth lens, stacked. ⛔ NO
        // LOBES AT ALL: the surface is unbroken, and any lumpiness destroys it. Two stacked lenses
        // rather than one, because the stack is what makes it read as lenticular rather than as a
        // flying saucer.
        case 12: {
            var _parts = [];
            for (var _k = 0; _k < 3; _k++) {
                var _w = 0.44 - _k * 0.075;
                var _h = 0.052 - _k * 0.010;
                var _cy = 0.13 - _k * 0.105;
                var _segs = 32;
                var _t = array_create(_segs + 1), _b = array_create(_segs + 1);
                for (var _s = 0; _s <= _segs; _s++) {
                    var _u = -1.0 + 2.0 * (_s / _segs);
                    var _e = sqrt(max(0, 1.0 - _u * _u));
                    _t[_s] = [_u * _w, _cy - _h * _e];
                    // the underside is FLATTER than the top: a symmetric lens is an eye, not a cloud
                    _b[_s] = [_u * _w, _cy + _h * 0.52 * _e];
                }
                var _o = wlk_cloud_outline(_t, _b);
                array_push(_parts, wlk_strip(_t, _b, "m2"));
                wlk_append(_parts, wlk_bevel(_o, _h * 0.42, 3, false));
            }
            return _parts;
        }

        // ---- 13. MAMMATUS. Pouches hanging BENEATH a storm base - the only form in the corpus
        // that grows downward, which is exactly why it earns a slot. Drawn as a slab whose base
        // rail is a row of half-discs.
        // ⚠️ 2026-08-28: THE TOP RAIL WAS THE CONSTANT 0.055 ACROSS THE WHOLE SPAN, so this form was
        // a literal rectangle with a scalloped bottom - the last of the five box-shaped genera the
        // store sheet exposed. The pouches were always right; the slab holding them was not. The
        // same plateau envelope wlk_cloud_bank uses now drives the top, the thickness AND the pouch
        // depth, so the sheet tapers to nothing at both ends instead of ending in a wall, and the
        // pouches fade out with it rather than being sliced off mid-bulge.
        default: {
            var _segs = 60;
            var _t = array_create(_segs + 1), _b = array_create(_segs + 1);
            for (var _s = 0; _s <= _segs; _s++) {
                var _x = lerp(-0.48, 0.48, _s / _segs);
                var _env = clamp(sin(pi * ((_x + 0.48) / 0.96)) * 2.6, 0, 1);
                _t[_s] = [_x, 0.115 - 0.060 * _env];
                // six pouches: the fractional part of a scaled x drives a half-circle bulge
                var _u = (_x + 0.48) / 0.16;
                var _cell = wlk_frac01(_u) * 2.0 - 1.0;
                var _bulge = sqrt(max(0, 1.0 - _cell * _cell));
                var _amp = 0.055 + 0.016 * sin(floor(_u) * 2.1 + _sd);
                _b[_s] = [_x, 0.135 + 0.080 * _env + _amp * _bulge * _env];
            }
            var _o = wlk_cloud_outline(_t, _b);
            var _parts = [wlk_strip(_t, _b, "m2")];
            return wlk_append(_parts, wlk_bevel(_o, 0.016, 3, false));
        }
    }
}
