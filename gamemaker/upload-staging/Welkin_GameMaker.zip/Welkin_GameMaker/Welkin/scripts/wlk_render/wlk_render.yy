{
  "$GMScript": "v1",
  "%Name": "wlk_render",
  "isCompatibility": false,
  "isDnD": false,
  "name": "wlk_render",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}