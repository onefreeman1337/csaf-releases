/// WELKIN - wlk_weather. THE CORPUS, PART III: twelve weather forms.
///
/// ⛔ EVERY ONE OF THESE IS DRAWN, NOT BLITTED, AND THAT IS THE PRODUCT'S SECOND HEADLINE CLAIM.
/// The ordinary way to ship rain is a looping PNG strip scrolled down the screen, and it has three
/// failures a buyer feels immediately: it repeats visibly, it is one colour whatever the sky is
/// doing, and it cannot change intensity without changing sprite. Drawn rain has none of those.
/// Its colour comes from the same palette as the sky, so rain at sunset is orange rain; its
/// intensity is a count, so it can ramp continuously from the first spot to a downpour; and it
/// never repeats, because there is no strip to repeat.
///
/// -- THE STROKE FLOOR DECIDES HOW RAIN IS DRAWN -----------------------------------------------
/// ⛔ draw_line_width LAYS DOWN AN UNANTIALIASED QUAD WITH A HARD FLOOR OF ONE PIXEL. The wing has
/// paid for this twice on other products: an authored width range below a pixel rasterises to
/// dashes on some scanlines and nothing on others, and a field of tone becomes "a barcode stuck on
/// a grey blob". So NOTHING HERE RAMPS BY WIDTH. Drizzle is not thin rain, it is SHORT and
/// NUMEROUS rain; a downpour is not fat rain, it is LONG and DENSE rain. Every intensity gradient
/// in this file is carried by COUNT and by LENGTH.
///
/// -- DETERMINISM ------------------------------------------------------------------------------
/// ⚠️ NOT ONE FUNCTION HERE CALLS random(). Every drop's position is a hash of its own index plus
/// a phase driven by the clock, so the same moment always draws the same weather. Random particles
/// cannot be screenshotted twice, cannot be tested, and - the reason that actually matters - they
/// SHIMMER, because a drop that re-rolls its x every frame is a drop that teleports.
///
/// -- COORDINATES ------------------------------------------------------------------------------
/// Unit box [-0.5, 0.5], y DOWN, rendered by wlk_sky at the frame's LARGER dimension so the box
/// covers the whole viewport. _t is a free-running time in seconds. _amt is 0..1 intensity.
/// ============================================================================================

#macro WLK_WEATHER_N 12

#macro WLK_WX_CLEAR     0
#macro WLK_WX_DRIZZLE   1
#macro WLK_WX_RAIN      2
#macro WLK_WX_DOWNPOUR  3
#macro WLK_WX_SNOW      4
#macro WLK_WX_BLIZZARD  5
#macro WLK_WX_SLEET     6
#macro WLK_WX_HAIL      7
#macro WLK_WX_MIST      8
#macro WLK_WX_FOG       9
#macro WLK_WX_LIGHTNING 10
#macro WLK_WX_RAINBOW   11

function wlk_weather_name(_i) {
    switch (_i) {
        case  0: return "Clear";
        case  1: return "Drizzle";
        case  2: return "Rain";
        case  3: return "Downpour";
        case  4: return "Snow";
        case  5: return "Blizzard";
        case  6: return "Sleet";
        case  7: return "Hail";
        case  8: return "Mist";
        case  9: return "Fog";
        case 10: return "Lightning";
        default: return "Rainbow";
    }
}

/// The sky conditions each weather implies, as the struct wlk_air_weather consumes. This is what
/// makes selecting "Downpour" change the SKY and not just add particles - the single most common
/// omission in the category, where rain is drawn over an unchanged blue sky.
function wlk_weather_sky(_i, _amt) {
    var _a = clamp(_amt, 0, 1);
    switch (_i) {
        case WLK_WX_CLEAR:     return { overcast: 0.00,          storm: 0.00,          haze: 0.05 };
        case WLK_WX_DRIZZLE:   return { overcast: 0.62 * _a,     storm: 0.10 * _a,     haze: 0.35 * _a };
        case WLK_WX_RAIN:      return { overcast: 0.80 * _a,     storm: 0.28 * _a,     haze: 0.25 * _a };
        case WLK_WX_DOWNPOUR:  return { overcast: 0.95 * _a,     storm: 0.62 * _a,     haze: 0.18 * _a };
        case WLK_WX_SNOW:      return { overcast: 0.78 * _a,     storm: 0.12 * _a,     haze: 0.45 * _a };
        case WLK_WX_BLIZZARD:  return { overcast: 0.96 * _a,     storm: 0.40 * _a,     haze: 0.72 * _a };
        case WLK_WX_SLEET:     return { overcast: 0.86 * _a,     storm: 0.34 * _a,     haze: 0.30 * _a };
        case WLK_WX_HAIL:      return { overcast: 0.90 * _a,     storm: 0.70 * _a,     haze: 0.12 * _a };
        case WLK_WX_MIST:      return { overcast: 0.30 * _a,     storm: 0.00,          haze: 0.80 * _a };
        case WLK_WX_FOG:       return { overcast: 0.55 * _a,     storm: 0.00,          haze: 1.00 * _a };
        case WLK_WX_LIGHTNING: return { overcast: 0.92 * _a,     storm: 0.85 * _a,     haze: 0.10 * _a };
        default:               return { overcast: 0.30 * _a,     storm: 0.05,          haze: 0.40 * _a };
    }
}

/// Which cloud genus belongs with this weather. A downpour under a fair-weather cumulus is the
/// kind of detail that makes a generated scene feel assembled rather than observed.
function wlk_weather_cloud(_i) {
    switch (_i) {
        case WLK_WX_CLEAR:     return 0;   // cumulus humilis
        case WLK_WX_DRIZZLE:   return 5;   // stratus
        case WLK_WX_RAIN:      return 6;   // nimbostratus
        case WLK_WX_DOWNPOUR:  return 3;   // cumulonimbus
        case WLK_WX_SNOW:      return 6;   // nimbostratus
        case WLK_WX_BLIZZARD:  return 6;
        case WLK_WX_SLEET:     return 6;
        case WLK_WX_HAIL:      return 3;   // cumulonimbus
        case WLK_WX_MIST:      return 8;   // altostratus
        case WLK_WX_FOG:       return 5;   // stratus
        case WLK_WX_LIGHTNING: return 3;   // cumulonimbus
        default:               return 1;   // cumulus mediocris - a rainbow needs broken cloud
    }
}

/// ============================================================================================
/// THE PARTICLE HASH
///
/// One deterministic value in [0,1) per particle index and channel. Cheap, stable, and - the
/// property that matters - INDEPENDENT across channels, so a drop's x does not correlate with its
/// speed. Correlated channels are what make generated particles fall in visible diagonal ranks.
/// ============================================================================================
/// ⛔ wlk_frac01, NOT frac. GML's frac() truncates TOWARD ZERO, so it returns a NEGATIVE value for
/// a negative input - and sin() is negative half the time, so half of every hash in this package
/// was returning a negative "0..1" number. MEASURED 2026-08-26 by this product's own self-test.
/// The consequences reached everywhere hashes are used: particle x positions pushed off frame,
/// radii computed negative, and wlk_star_mag calling power() on a negative base, which is NaN -
/// and a NaN coordinate does not throw, it silently draws nothing for that vertex.
/// See wlk_frac01's own header in wlk_horizon for the full finding.
function wlk_wx_hash(_i, _chan) {
    return wlk_frac01(sin(_i * 127.1 + _chan * 311.7 + 0.5) * 43758.5453123);
}

/// A falling particle's position. Returns [x, y] with y wrapped into the box.
///
/// ⚠️ THE WRAP USES frac() ON A PHASE, NOT A COUNTER THAT RESETS. A counter that resets makes every
/// particle in a band restart together, and the eye reads the resulting seam as a horizontal line
/// travelling down the screen. Per-particle phase offsets remove the seam entirely.
function wlk_wx_fall(_i, _t, _speed, _slant) {
    var _x0 = wlk_wx_hash(_i, 0) - 0.5;
    var _ph = wlk_wx_hash(_i, 1);
    var _sp = _speed * (0.72 + 0.56 * wlk_wx_hash(_i, 2));
    var _u = wlk_frac01(_ph + _t * _sp);
    var _y = -0.55 + _u * 1.10;
    var _x = _x0 + _slant * (_u - 0.5) * 0.35;
    while (_x > 0.55) _x -= 1.10;
    while (_x < -0.55) _x += 1.10;
    return [_x, _y];
}

/// ============================================================================================
/// THE TWELVE
/// ============================================================================================

function wlk_weather_build(_i, _t, _amt, _wind) {
    var _a = clamp(_amt, 0, 1);
    var _w = is_undefined(_wind) ? 0.35 : _wind;
    if (_a <= 0.001) return [];

    switch (_i) {

        case WLK_WX_CLEAR: return [];

        // ---- DRIZZLE. Many, SHORT, nearly vertical, and slow. The identity is that you cannot
        // see individual drops fall - you see a texture. Length carries the difference from rain.
        case WLK_WX_DRIZZLE: {
            var _n = round(110 * _a);
            var _out = array_create(_n);
            for (var _k = 0; _k < _n; _k++) {
                var _p = wlk_wx_fall(_k, _t, 0.55, _w);
                _out[_k] = wlk_poly([[_p[0], _p[1]], [_p[0] + _w * 0.012, _p[1] + 0.016]],
                                    false, 0.0016, "m3");
            }
            return _out;
        }

        // ---- RAIN. Fewer than drizzle per unit of texture but far longer, and faster.
        case WLK_WX_RAIN: {
            var _n = round(150 * _a);
            var _out = array_create(_n);
            for (var _k = 0; _k < _n; _k++) {
                var _p = wlk_wx_fall(_k, _t, 1.15, _w);
                var _ln = 0.045 + 0.020 * wlk_wx_hash(_k, 3);
                _out[_k] = wlk_poly([[_p[0], _p[1]], [_p[0] + _w * _ln * 0.7, _p[1] + _ln]],
                                    false, 0.0018, "m3");
            }
            return _out;
        }

        // ---- DOWNPOUR. Dense and long. ⚠️ THE COUNT IS THE INTENSITY - this is the same drawing
        // code as rain with a bigger number and a longer streak, which is exactly the point: a
        // sprite-strip product needs a second sprite here and this needs a parameter.
        case WLK_WX_DOWNPOUR: {
            var _n = round(340 * _a);
            var _out = array_create(_n);
            for (var _k = 0; _k < _n; _k++) {
                var _p = wlk_wx_fall(_k, _t, 1.85, _w * 1.3);
                var _ln = 0.085 + 0.045 * wlk_wx_hash(_k, 3);
                _out[_k] = wlk_poly([[_p[0], _p[1]], [_p[0] + _w * _ln * 0.8, _p[1] + _ln]],
                                    false, 0.0022, "m4");
            }
            return _out;
        }

        // ---- SNOW. ⭐ THE SWAY IS THE WHOLE FORM. Snow does not fall, it drifts: each flake
        // wanders horizontally on its own period. Drawn as falling dots it reads as static, and
        // that single omission is what makes most generated snow look like dust.
        case WLK_WX_SNOW: {
            var _n = round(150 * _a);
            var _out = array_create(_n);
            for (var _k = 0; _k < _n; _k++) {
                var _p = wlk_wx_fall(_k, _t, 0.22, _w * 0.4);
                var _sw = sin((_t * (0.5 + wlk_wx_hash(_k, 4)) + wlk_wx_hash(_k, 5) * 6.283)) * 0.035;
                var _r = 0.0035 + 0.0030 * wlk_wx_hash(_k, 6);
                _out[_k] = wlk_dot(_p[0] + _sw, _p[1], _r, "m4");
            }
            return _out;
        }

        // ---- BLIZZARD. Snow that has stopped drifting because the wind has taken over: the sway
        // is gone, the count is up, and horizontal wind streaks are added. The absence of sway is
        // as much the tell as the density.
        case WLK_WX_BLIZZARD: {
            var _out = [];
            var _n = round(320 * _a);
            for (var _k = 0; _k < _n; _k++) {
                var _p = wlk_wx_fall(_k, _t, 0.85, _w * 2.6);
                var _r = 0.0030 + 0.0028 * wlk_wx_hash(_k, 6);
                array_push(_out, wlk_dot(_p[0], _p[1], _r, "m4"));
            }
            var _m = round(46 * _a);
            for (var _k = 0; _k < _m; _k++) {
                var _p = wlk_wx_fall(_k + 900, _t, 1.35, _w * 3.4);
                array_push(_out, wlk_poly([[_p[0], _p[1]], [_p[0] + 0.085, _p[1] + 0.012]],
                                          false, 0.0020, "m4"));
            }
            return _out;
        }

        // ---- SLEET. Half and half, and the mixture is the identity: short hard streaks with
        // round pellets among them. Neither alone reads as sleet.
        case WLK_WX_SLEET: {
            var _out = [];
            var _n = round(130 * _a);
            for (var _k = 0; _k < _n; _k++) {
                var _p = wlk_wx_fall(_k, _t, 1.30, _w * 1.1);
                if (wlk_wx_hash(_k, 7) > 0.45) {
                    array_push(_out, wlk_poly([[_p[0], _p[1]], [_p[0] + _w * 0.020, _p[1] + 0.030]],
                                              false, 0.0018, "m3"));
                } else {
                    array_push(_out, wlk_dot(_p[0], _p[1], 0.0032, "m4"));
                }
            }
            return _out;
        }

        // ---- HAIL. Few, LARGE, FAST and nearly vertical - hail does not blow sideways the way
        // rain does, because it is heavy. Each stone gets a lit side, which is the only
        // precipitation in the corpus solid enough to earn one.
        case WLK_WX_HAIL: {
            var _out = [];
            var _n = round(58 * _a);
            for (var _k = 0; _k < _n; _k++) {
                var _p = wlk_wx_fall(_k, _t, 2.30, _w * 0.25);
                var _r = 0.0060 + 0.0045 * wlk_wx_hash(_k, 8);
                array_push(_out, wlk_dot(_p[0], _p[1], _r, "m2"));
                // the lit limb, offset toward the lamp. A stone with no lit side is a grey dot.
                array_push(_out, wlk_dot(_p[0] + global.wlk_lx * _r * 0.34,
                                         _p[1] + global.wlk_ly * _r * 0.34, _r * 0.52, "m4"));
            }
            return _out;
        }

        // ---- MIST. Horizontal bands, low in the frame, drifting sideways. ⛔ NOT A FLAT SCRIM
        // OVER THE WHOLE PICTURE - that is the tint approach this product exists to replace. Mist
        // is banded, it sits LOW, and you can see over it.
        case WLK_WX_MIST: {
            var _out = [];
            var _n = 7;
            for (var _k = 0; _k < _n; _k++) {
                var _y = 0.150 + _k * 0.042;
                var _dx = wlk_frac01(_t * 0.020 * (0.5 + wlk_wx_hash(_k, 9)) + wlk_wx_hash(_k, 10)) - 0.5;
                var _hh = (0.012 + 0.010 * wlk_wx_hash(_k, 11)) * _a;
                var _segs = 26;
                var _top = array_create(_segs + 1), _bot = array_create(_segs + 1);
                for (var _s = 0; _s <= _segs; _s++) {
                    var _u = _s / _segs;
                    var _x = lerp(-0.55, 0.55, _u);
                    // taper to nothing at both ends so a band never shows a cut edge
                    var _f = sin(_u * pi);
                    var _wob = 0.006 * sin((_u * 5.3 + _dx * 4.0 + _k) * WLK_TAU);
                    _top[_s] = [_x, _y + _wob - _hh * _f];
                    _bot[_s] = [_x, _y + _wob + _hh * _f];
                }
                array_push(_out, wlk_strip(_top, _bot, "m3"));
            }
            return _out;
        }

        // ---- FOG. Mist that has won: more bands, taller, higher up the frame, and overlapping
        // enough to close. Same generator, different numbers - which is how a real fog forms.
        case WLK_WX_FOG: {
            var _out = [];
            var _n = 13;
            for (var _k = 0; _k < _n; _k++) {
                var _y = 0.020 + _k * 0.034;
                var _dx = wlk_frac01(_t * 0.014 * (0.5 + wlk_wx_hash(_k, 9)) + wlk_wx_hash(_k, 10)) - 0.5;
                var _hh = (0.026 + 0.016 * wlk_wx_hash(_k, 11)) * _a;
                var _segs = 26;
                var _top = array_create(_segs + 1), _bot = array_create(_segs + 1);
                for (var _s = 0; _s <= _segs; _s++) {
                    var _u = _s / _segs;
                    var _x = lerp(-0.58, 0.58, _u);
                    var _f = sin(_u * pi);
                    var _wob = 0.010 * sin((_u * 3.7 + _dx * 3.0 + _k) * WLK_TAU);
                    _top[_s] = [_x, _y + _wob - _hh * _f];
                    _bot[_s] = [_x, _y + _wob + _hh * _f];
                }
                array_push(_out, wlk_strip(_top, _bot, "m3"));
            }
            return _out;
        }

        // ---- LIGHTNING. A branching bolt. ⭐ THE BRANCHES ARE WHAT MAKE IT READ AS LIGHTNING -
        // a single zigzag reads as a crack in the screen. Each segment can spawn a shorter, dimmer
        // fork that does not reach the ground.
        //
        // ⚠️ THE BOLT IS A FUNCTION OF A STRIKE INDEX, NOT OF CONTINUOUS TIME. wlk_sky decides WHEN
        // a strike happens and passes its index in _t; the same index always draws the same bolt,
        // so a strike does not writhe during the few frames it is visible.
        case WLK_WX_LIGHTNING: {
            var _strike = floor(_t);
            var _out = [];
            var _x = (wlk_wx_hash(_strike, 20) - 0.5) * 0.7;
            var _y = -0.42;
            var _main = [[_x, _y]];
            var _steps = 14;
            for (var _s = 1; _s <= _steps; _s++) {
                _x += (wlk_wx_hash(_strike * 31 + _s, 21) - 0.5) * 0.085;
                _y += 0.055 + 0.020 * wlk_wx_hash(_strike * 31 + _s, 22);
                array_push(_main, [_x, _y]);
            }
            // painter's order: the wide dim halo FIRST, the hot core LAST. Drawn the other way the
            // halo paints over the core and the bolt flattens to a uniform grey stripe - the wing
            // has this recorded as a measured defect on another product's glow.
            array_push(_out, wlk_poly(_main, false, 0.010, "m2"));
            array_push(_out, wlk_poly(_main, false, 0.005, "m3"));
            array_push(_out, wlk_poly(_main, false, 0.002, "m4"));

            var _nb = array_length(_main);
            for (var _s = 3; _s < _nb - 2; _s++) {
                if (wlk_wx_hash(_strike * 17 + _s, 23) < 0.62) continue;
                var _bx = _main[_s][0], _by = _main[_s][1];
                var _dir = (wlk_wx_hash(_strike * 17 + _s, 24) > 0.5) ? 1 : -1;
                var _fork = [[_bx, _by]];
                var _fn = 3 + floor(wlk_wx_hash(_strike * 17 + _s, 25) * 3);
                for (var _f = 1; _f <= _fn; _f++) {
                    _bx += _dir * (0.020 + 0.030 * wlk_wx_hash(_strike * 17 + _s * 7 + _f, 26));
                    _by += 0.028 + 0.018 * wlk_wx_hash(_strike * 17 + _s * 7 + _f, 27);
                    array_push(_fork, [_bx, _by]);
                }
                array_push(_out, wlk_poly(_fork, false, 0.0035, "m2"));
                array_push(_out, wlk_poly(_fork, false, 0.0015, "m3"));
            }
            return _out;
        }

        // ---- RAINBOW. ⭐ THE ONE FORM IN THE PACKAGE WHOSE COLOUR IS NOT THE SKY'S. Everything
        // else takes its colour from wlk_air; a rainbow is refracted sunlight and has its own
        // fixed spectrum, so wlk_weather_bow_palette supplies seven roles for it.
        //
        // The geometry is real: the bow is a circle 42 degrees from the ANTISOLAR point, which is
        // directly opposite the sun. So a low sun gives a tall bow and a high sun gives none at
        // all - above about 42 degrees the whole arc is below the horizon. wlk_sky enforces that,
        // and it is the sort of correctness a buyer never notices until it is missing.
        default: {
            var _out = [];
            var _cx = 0.0, _cy = 0.62;   // the antisolar point, placed by wlk_sky
            var _r0 = 0.52;
            // ⛔ DEGREES INTO A RADIANS FUNCTION - FIXED 2026-08-28, AND IT HAD MADE THE RAINBOW
            // INVISIBLE ON EVERY SKY THIS PRODUCT HAS EVER DRAWN. wlk_arc_pts calls cos/sin on its
            // arguments directly, so it takes RADIANS; this was the only call site in the package
            // and it passed 185 and 355 as if they were degrees. Reduced mod 2*pi those are 159.7
            // and 180.0 degrees - so instead of the upper half of the circle the bow swept a 20
            // degree sliver lying ON the horizon, which step 8 of wlk_sky_draw then painted over
            // with the land. The store sheet had a cell captioned RAINBOW containing no rainbow.
            //
            // ⚠️ WHY 248 ASSERTIONS DID NOT CATCH IT, which is the reusable half: the suite checked
            // that the bow has seven bands and that band 0 is the outermost (red outside violet).
            // Both are true no matter what arc you sweep. The angles were the one thing not
            // asserted, so that is what broke - and only opening the rendered sheet found it.
            // The apex assertion in wlk_selftest stage 13 now covers exactly this.
            //
            // 185..355 was the correct INTENT: y is down, so sin is negative across that range and
            // the arc stands ABOVE its centre. Only the units were wrong.
            for (var _band = 0; _band < 7; _band++) {
                var _r = _r0 - _band * 0.016;
                var _pts = wlk_arc_pts(_cx, _cy, _r, degtorad(185), degtorad(355), 40);
                array_push(_out, wlk_poly(_pts, false, 0.017 * _a, "bow" + string(_band)));
            }
            return _out;
        }
    }
}

/// The seven spectral roles a rainbow needs, added to a palette in place.
///
/// ⚠️ RED IS THE OUTSIDE OF A PRIMARY BOW AND VIOLET THE INSIDE. Getting that backwards is the
/// single most common error in drawn rainbows and it is instantly wrong to anyone who has looked
/// at one. Band 0 is the outermost and largest radius, so band 0 is red.
///
/// The chroma is deliberately modest and the alpha is carried by the caller: a rainbow at full
/// saturation reads as a cartoon decal laid on the sky rather than as light in the air.
function wlk_weather_bow_palette(_pal, _light) {
    var _hues = [29, 62, 95, 145, 220, 264, 305];   // red orange yellow green blue indigo violet
    var _k = 0.55 + 0.45 * clamp(_light.direct, 0, 1);
    for (var _b = 0; _b < 7; _b++) {
        variable_struct_set(_pal, "bow" + string(_b), wlk_oklch(0.80, 0.105 * _k, _hues[_b]));
    }
    return _pal;
}
