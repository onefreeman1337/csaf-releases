{
  "$GMScript": "v1",
  "%Name": "wlk_weather",
  "isCompatibility": false,
  "isDnD": false,
  "name": "wlk_weather",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}