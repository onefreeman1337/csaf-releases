/// WELKIN - wlk_selftest. The assertions, run in-engine against a real Igor-built executable.
///
/// GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE. That is a standing fact about this wing and it is
/// not being papered over. What does NOT follow is that the engine cannot test itself unattended:
/// Internal_Ops/run_engine.ps1 builds through gm_gate.ps1, unzips the package, runs the executable
/// with -selftest and reads the result file. Everything below runs on the shipping build.
///
/// ⛔ AND THE THING THESE ASSERTIONS CANNOT DO IS JUDGE A PICTURE. A sibling product in this wing
/// passed 369 in-engine assertions, an extent check AND an ink-bounds check, and shipped a gallery
/// with seven defects - every one found by opening the PNG and looking at it. These make NAMED
/// failure modes unshippable. They are not the review.
///
/// ⚠️ A TEST THAT HAS ONLY EVER PASSED IS NOT A TEST. Each block states what would make it fail.
/// ============================================================================================

/// ⛔ 0.0001, NOT 0.00001, AND THE DIFFERENCE IS MEASURED RATHER THAN STYLISTIC.
/// math_get_epsilon() returns 0.00001 on this runtime and PARTICIPATES IN COMPARISONS, so a
/// tolerance at or below it can never fire in the `<` direction - a sibling product's suite had
/// every distinctness assertion passing vacuously, green forever and unable to go red. Writing the
/// tolerance exactly AT the epsilon fails the other way: a difference of ZERO compares as "equal"
/// and equal is not less-than, producing a false RED on two points that are the same array object.
/// Stay an order of magnitude clear in BOTH directions. And GML has no exponent-literal syntax at
/// all - `1e-4` is a lexer error that reads like a bracket bug.
#macro WLK_ST_EPS 0.0001

/// How far outside the unit box a form may reach. Not zero: a stroke has half-width.
#macro WLK_ST_BOX 0.62

/// The mean Oklab separation two skies must exceed to be counted as visibly distinct.
/// ⚠️ REPORTED BESIDE ITS MEASUREMENT in the result file, so the number can be re-derived and
/// argued with rather than trusted. 0.040 is a conservative reading of a just-noticeable
/// difference for large flat areas, which is exactly what a sky is.
#macro WLK_ST_SKY_FLOOR 0.040

/// The mean silhouette separation two forms in one corpus must exceed.
#macro WLK_ST_FORM_FLOOR 0.020

function wlk_st_new() { return { pass: 0, fail: 0, failures: [] }; }

function wlk_st_ok(_r, _cond, _what) {
    if (_cond) { _r.pass++; return true; }
    _r.fail++;
    array_push(_r.failures, _what);
    return false;
}

/// ============================================================================================
/// GEOMETRY HELPERS
/// ============================================================================================

/// Total turning of a closed polygon, in revolutions.
///
/// ⛔ THIS IS THE CHEAP TEST FOR A SELF-CROSSING OUTLINE and this wing has paid for not having it.
/// A simple closed polygon turns through exactly one revolution; a figure-of-eight turns through
/// zero. The failure it catches is vicious: a bowtie outline fills the wrong region AND throws its
/// inset points far outside the shape, so the bevel grows hooks and the ink check reports a
/// clipping error two steps downstream of the actual cause.
/// ⛔ DUPLICATE POINTS ARE REMOVED FIRST, AND SKIPPING THEM INSTEAD IS A FALSE RED THAT COST THIS
/// SESSION A DIAGNOSIS. The first version of this function hit a zero-length edge and `continue`d,
/// which does not skip a degenerate point - it DISCARDS THE TURN THAT HAPPENS AT IT. Every form in
/// this package that comes to a point has two coincident vertices there by construction (a cloud's
/// top and base rails meet at both ends; the moon's limb and terminator share both horns), so the
/// two cusp turns - very nearly a half revolution each - were being thrown away. Twelve correct
/// outlines reported a turning of 0.47 and were called self-crossing.
///
/// A false red costs exactly what a false green does, and this one would have sent the next
/// session rewriting geometry that was right. Deduplicate, THEN measure.
function wlk_st_dedupe(_pts) {
    var _n = array_length(_pts);
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[_i];
        if (array_length(_out) > 0) {
            var _q = _out[array_length(_out) - 1];
            if (abs(_p[0] - _q[0]) < WLK_ST_EPS && abs(_p[1] - _q[1]) < WLK_ST_EPS) continue;
        }
        array_push(_out, _p);
    }
    // and the wrap-around pair
    while (array_length(_out) > 1) {
        var _a = _out[0], _b = _out[array_length(_out) - 1];
        if (abs(_a[0] - _b[0]) < WLK_ST_EPS && abs(_a[1] - _b[1]) < WLK_ST_EPS) {
            array_pop(_out);
        } else break;
    }
    return _out;
}

function wlk_st_turning(_pts) {
    var _p = wlk_st_dedupe(_pts);
    var _n = array_length(_p);
    if (_n < 3) return 0;
    var _sum = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _p[_i], _b = _p[(_i + 1) % _n], _c = _p[(_i + 2) % _n];
        var _ux = _b[0] - _a[0], _uy = _b[1] - _a[1];
        var _vx = _c[0] - _b[0], _vy = _c[1] - _b[1];
        var _lu = sqrt(_ux * _ux + _uy * _uy), _lv = sqrt(_vx * _vx + _vy * _vy);
        if (_lu < WLK_ST_EPS || _lv < WLK_ST_EPS) continue;
        var _cross = (_ux * _vy - _uy * _vx) / (_lu * _lv);
        var _dot = (_ux * _vx + _uy * _vy) / (_lu * _lv);
        _sum += arctan2(clamp(_cross, -1, 1), clamp(_dot, -1, 1));
    }
    return _sum / WLK_TAU;
}

/// Every point in a part list, flattened. Used for containment and for the silhouette signature.
function wlk_st_points(_parts) {
    var _out = [];
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case WLK_DOT:
                array_push(_out, [_p.cx - _p.r, _p.cy], [_p.cx + _p.r, _p.cy],
                                 [_p.cx, _p.cy - _p.r], [_p.cx, _p.cy + _p.r]);
                break;
            case WLK_ARC:
                array_push(_out, [_p.cx - _p.r, _p.cy], [_p.cx + _p.r, _p.cy],
                                 [_p.cx, _p.cy - _p.r], [_p.cx, _p.cy + _p.r]);
                break;
            case WLK_POLY: case WLK_FILL:
                for (var _k = 0; _k < array_length(_p.pts); _k++) array_push(_out, _p.pts[_k]);
                break;
            case WLK_STRIP:
                for (var _k = 0; _k < array_length(_p.a); _k++) array_push(_out, _p.a[_k]);
                for (var _k = 0; _k < array_length(_p.b); _k++) array_push(_out, _p.b[_k]);
                break;
        }
    }
    return _out;
}

/// A SILHOUETTE ENVELOPE: for each of 32 columns across the unit box, the highest and lowest point
/// any part reaches there.
///
/// ⛔ IT MEASURES THE OUTLINE AND NOTHING INSIDE IT, WHICH IS THE ONLY HONEST WAY TO DO THIS. The
/// wing's constitution records a pair of forms that differed only in internal detail and measured
/// at a distance of exactly zero, because the fertile surface they differed on was drawn as a
/// filled band and every difference was a mark inside an area that was already solid. A tell must
/// change AREA, SPACING or SILHOUETTE, so the test looks at the silhouette.
function wlk_st_envelope(_parts) {
    var _bins = 32;
    var _top = array_create(_bins, 999), _bot = array_create(_bins, -999);
    var _pts = wlk_st_points(_parts);
    for (var _i = 0; _i < array_length(_pts); _i++) {
        var _x = _pts[_i][0], _y = _pts[_i][1];
        var _b = clamp(floor((_x + 0.5) * _bins), 0, _bins - 1);
        if (_y < _top[_b]) _top[_b] = _y;
        if (_y > _bot[_b]) _bot[_b] = _y;
    }
    return { top: _top, bot: _bot, bins: _bins };
}

/// Mean silhouette distance between two envelopes. Columns neither form occupies are skipped;
/// columns only ONE occupies count as a full-height difference, because "there is cloud here and
/// none there" is the strongest difference two forms can have.
function wlk_st_env_dist(_a, _b) {
    var _sum = 0, _n = 0;
    for (var _i = 0; _i < _a.bins; _i++) {
        var _ao = (_a.top[_i] < 998), _bo = (_b.top[_i] < 998);
        if (!_ao && !_bo) continue;
        _n++;
        if (_ao != _bo) { _sum += 0.30; continue; }
        _sum += (abs(_a.top[_i] - _b.top[_i]) + abs(_a.bot[_i] - _b.bot[_i])) * 0.5;
    }
    return (_n == 0) ? 0 : _sum / _n;
}

/// ============================================================================================
/// THE SUITE
/// ============================================================================================

function wlk_selftest_run() {
    var _r = wlk_st_new();
    var _out = {};

    // ---- STAGE 1. TOP-LEVEL SCRIPT CODE RAN --------------------------------------------------
    // ⚠️ THIS IS AN ASSUMPTION ABOUT GML THAT THE PRODUCT TESTS RATHER THAN TRUSTS. The lamp
    // globals are initialised at the top level of wlk_relief, which relies on GML executing
    // top-level script code once at game start. If a runtime ever stops doing that, every relief
    // call in the package reads an unset global and a buyer's FIRST FRAME crashes. This assertion
    // makes that a red line in a result file instead.
    // TO MAKE IT FAIL: delete the two global.wlk_lx/ly lines from the lamp block in scaffold.js.
    global.wlk_stage = 1;
    wlk_st_ok(_r, variable_global_exists("wlk_lx") && variable_global_exists("wlk_ly"),
        "lamp globals missing - top-level script code did not run at game start");

    // ---- STAGE 2. THE EPSILON ----------------------------------------------------------------
    // ⛔ SPLIT INTO TWO CLAUSES ON PURPOSE, AND THE FIRST ONE IS THE TRAP ITSELF. The natural way
    // to write this is `_e > 0 && _e < TOL`, and the FIRST clause goes red: the difference between
    // the epsilon and zero IS the epsilon, GML therefore calls them equal, and equal is not
    // greater-than. Written as !(_e > 0) it becomes a POSITIVE test that the runtime still applies
    // an epsilon, and goes red the day a release stops. Do not repair this into one clause.
    global.wlk_stage = 2;
    var _eps = math_get_epsilon();
    wlk_st_ok(_r, !(_eps > 0.001), "math_get_epsilon unexpectedly large: " + string(_eps));
    wlk_st_ok(_r, !(_eps > 0), "epsilon no longer participates in comparisons - re-read every tolerance");
    _out.epsilon = _eps;

    // ---- STAGE 3. THE SKY RAMP ---------------------------------------------------------------
    // TO MAKE IT FAIL: swap the zenith and haze lightness in any keyframe row of wlk_air_keyframe.
    global.wlk_stage = 3;
    for (var _k = 0; _k < 7; _k++) {
        var _f = wlk_air_keyframe(_k);
        wlk_st_ok(_r, array_length(_f) == WLK_STOPS,
            "keyframe " + string(_k) + " does not have " + string(WLK_STOPS) + " stops");
        // ⛔ A REAL SKY IS DARKEST OVERHEAD AT EVERY HOUR, INCLUDING AT NIGHT. This is the single
        // most common error in the category - "bright day" suggests a bright top - and it is the
        // one thing that makes a generated sky read as upside down.
        for (var _s = 1; _s < WLK_STOPS; _s++) {
            wlk_st_ok(_r, _f[_s][0] > _f[_s - 1][0],
                "keyframe " + string(_k) + " stop " + string(_s) + " is not lighter than the one above it");
            wlk_st_ok(_r, _f[_s][0] > 0.01 && _f[_s][0] < 0.99,
                "keyframe " + string(_k) + " stop " + string(_s) + " lightness out of range");
            wlk_st_ok(_r, _f[_s][2] >= 0 && _f[_s][2] < 360,
                "keyframe " + string(_k) + " stop " + string(_s) + " hue out of range");
        }
    }

    // ---- STAGE 4. HUE TAKES THE SHORT WAY ----------------------------------------------------
    // TO MAKE IT FAIL: replace wlk_air_mix_h's body with a plain lerp. It returns 185 - cyan - in
    // the middle of every sunset, for about twenty minutes of each simulated evening.
    global.wlk_stage = 4;
    var _mid = wlk_air_mix_h(350, 20, 0.5);
    wlk_st_ok(_r, _mid < 30 || _mid > 340,
        "hue mixing went the long way round: 350 -> 20 at t=0.5 gave " + string(_mid));
    wlk_st_ok(_r, abs(wlk_air_mix_h(10, 40, 0.5) - 25) < 0.01, "hue mixing wrong on a simple pair");

    // ---- STAGE 5. THE SKIES ARE ACTUALLY DIFFERENT -------------------------------------------
    // ⭐ THIS IS THE PRODUCT'S HEADLINE CLAIM AND IT IS MEASURED HERE RATHER THAN ASSERTED IN THE
    // LISTING COPY. A grid of hours and weathers is turned into five-stop Oklab signatures, and a
    // sky joins the distinct set only if it differs from every sky already in it by more than the
    // floor. The count that comes out is what the store page is allowed to say.
    //
    // ⚠️ THE CHROMA CEILING IS APPLIED FIRST. Two stops authored above what sRGB can show at their
    // lightness are numerically different and visually IDENTICAL, and counting those would be
    // exactly the overclaim this suite exists to prevent.
    //
    // ⚠️ THE SAMPLED SPACE INCLUDES THE SEASON, AND THAT ADDITION IS ARGUED RATHER THAN QUIET.
    // The first run of this stage sampled hours and weathers at ONE day of the year and counted
    // 20 - below the claim. The floor was NOT moved, because tuning a threshold until a claim
    // passes is the exact failure this suite exists to prevent. What was wrong was the SAMPLE:
    // the day of the year is a first-class input to this product, it changes the sun's declination
    // and therefore every stop of the ramp, and an entire store sheet is devoted to showing it.
    // Measuring a three-axis product on two axes understates it. If the count still fell short
    // after sampling the real space, the CLAIM would have had to come down.
    global.wlk_stage = 5;
    var _states = [];
    var _wxset = [WLK_WX_CLEAR, WLK_WX_DRIZZLE, WLK_WX_RAIN, WLK_WX_DOWNPOUR, WLK_WX_FOG, WLK_WX_SNOW];
    var _dayset = [81, 172, 355];   // equinox, midsummer, midwinter
    for (var _di = 0; _di < array_length(_dayset); _di++) {
    for (var _hh = 0; _hh < 24; _hh += 2) {
        for (var _wi = 0; _wi < array_length(_wxset); _wi++) {
            var _sky = wlk_sky_create(52, 1);
            wlk_sky_set_day(_sky, _dayset[_di]);
            wlk_sky_set_time(_sky, _hh);
            wlk_sky_force_weather(_sky, _wxset[_wi], 1.0);
            var _alt = wlk_sky_sun_alt(_sky);
            var _st = wlk_air_weather(wlk_air_stops(_alt), wlk_sky_conditions(_sky));
            var _sig = array_create(WLK_STOPS * 3);
            for (var _s = 0; _s < WLK_STOPS; _s++) {
                var _L = _st[_s][0];
                var _C = wlk_chroma_ceiling(_L, _st[_s][1]);
                var _h = degtorad(_st[_s][2]);
                _sig[_s * 3]     = _L;
                _sig[_s * 3 + 1] = _C * cos(_h);
                _sig[_s * 3 + 2] = _C * sin(_h);
            }
            array_push(_states, _sig);
        }
    }
    }
    var _distinct = [];
    var _minSep = 999;
    for (var _i = 0; _i < array_length(_states); _i++) {
        var _keep = true;
        for (var _j = 0; _j < array_length(_distinct); _j++) {
            var _sum = 0;
            for (var _s = 0; _s < WLK_STOPS; _s++) {
                var _dL = _states[_i][_s * 3]     - _distinct[_j][_s * 3];
                var _da = _states[_i][_s * 3 + 1] - _distinct[_j][_s * 3 + 1];
                var _db = _states[_i][_s * 3 + 2] - _distinct[_j][_s * 3 + 2];
                _sum += sqrt(_dL * _dL + _da * _da + _db * _db);
            }
            var _d = _sum / WLK_STOPS;
            if (_d < _minSep) _minSep = _d;
            if (_d < WLK_ST_SKY_FLOOR) { _keep = false; break; }
        }
        if (_keep) array_push(_distinct, _states[_i]);
    }
    _out.skyStates = array_length(_states);
    _out.distinctSkies = array_length(_distinct);
    _out.skyFloor = WLK_ST_SKY_FLOOR;

    // ⛔ 25, AND THE HISTORY OF THIS NUMBER IS THE POINT OF WRITING IT DOWN.
    //
    // This assertion was first written as ">= 40", because the candidate record for this product
    // promised "40+ visibly distinct skies". It measured 20. Two things were then done and only
    // one of them was legitimate:
    //
    //   1. The SAMPLE was widened from two axes to three, because the day of the year is a real
    //      input to this product and measuring a three-axis system on two axes understates it.
    //      20 -> 27. Legitimate.
    //   2. A genuine modelling defect was found and fixed - overcast was draining 80% of the sky's
    //      chroma, which collapsed every heavily-clouded state onto one grey and is wrong as
    //      physics, since cloud scatters light rather than filtering its colour out. 27 -> 29.
    //      Legitimate, and it would have been the right change even if it had moved nothing.
    //
    // ⛔ WHAT WAS NOT DONE: THE FLOOR WAS NEVER TOUCHED. WLK_ST_SKY_FLOOR is still 0.040, which is
    // a CONSERVATIVE reading of a just-noticeable difference - the literature would support
    // something nearer 0.02 for areas this large, and halving it would have "achieved" the 40
    // instantly. Tuning a threshold until a claim passes is the precise failure this suite exists
    // to prevent, and doing it here would have made every other number in this file worthless.
    //
    // So the CLAIM came down to the measurement instead. The listing says what this reports, the
    // product's volume claim rests on the 43 authored FORMS (which is measured in stage 14 and is
    // comfortably true), and this assertion is now a REGRESSION FLOOR a few below the measured 29
    // rather than an aspiration. If a future change drops it under 25, that is a real regression.
    wlk_st_ok(_r, array_length(_distinct) >= 25,
        "only " + string(array_length(_distinct)) + " visibly distinct skies of "
        + string(array_length(_states)) + " sampled - regression below the measured floor");

    // ---- STAGE 6. THE CLOUD CORPUS -----------------------------------------------------------
    global.wlk_stage = 6;
    var _cenv = array_create(WLK_CLOUD_N);
    for (var _c = 0; _c < WLK_CLOUD_N; _c++) {
        var _parts = wlk_cloud_build(_c, 0);
        wlk_st_ok(_r, array_length(_parts) > 0, "cloud " + wlk_cloud_name(_c) + " built nothing");

        var _pts = wlk_st_points(_parts);
        wlk_st_ok(_r, array_length(_pts) > 0, "cloud " + wlk_cloud_name(_c) + " has no geometry");
        for (var _p = 0; _p < array_length(_pts); _p++) {
            if (abs(_pts[_p][0]) > WLK_ST_BOX || abs(_pts[_p][1]) > WLK_ST_BOX) {
                wlk_st_ok(_r, false, "cloud " + wlk_cloud_name(_c) + " reaches outside the unit box");
                break;
            }
        }
        _cenv[_c] = wlk_st_envelope(_parts);

        // Determinism: the same seed must build the same cloud, forever.
        // TO MAKE IT FAIL: put a random() anywhere in wlk_cloud_build.
        var _again = wlk_st_envelope(wlk_cloud_build(_c, 0));
        wlk_st_ok(_r, wlk_st_env_dist(_cenv[_c], _again) < WLK_ST_EPS,
            "cloud " + wlk_cloud_name(_c) + " is not deterministic");
    }

    // Every convective outline must be a simple closed polygon.
    // TO MAKE IT FAIL: walk the base rail forwards in wlk_cloud_outline instead of in reverse.
    for (var _c = 0; _c < 7; _c++) {
        var _l = [[-0.1, 0.15, 0.12], [0.1, 0.18, 0.10]];
        var _t = wlk_cloud_top_rail(_l, WLK_CLOUD_BASE, 20);
        var _b = wlk_cloud_flat_base(_t, WLK_CLOUD_BASE);
        var _o = wlk_cloud_outline(_t, _b);
        wlk_st_ok(_r, abs(abs(wlk_st_turning(_o)) - 1.0) < 0.10,
            "cloud outline is not a simple polygon - turning " + string(wlk_st_turning(_o)));
    }

    // Pairwise silhouette distinctness across the whole corpus.
    var _cmin = 999; var _cminAt = "";
    for (var _i = 0; _i < WLK_CLOUD_N; _i++) {
        for (var _j = _i + 1; _j < WLK_CLOUD_N; _j++) {
            var _d = wlk_st_env_dist(_cenv[_i], _cenv[_j]);
            if (_d < _cmin) { _cmin = _d; _cminAt = wlk_cloud_name(_i) + " vs " + wlk_cloud_name(_j); }
        }
    }
    _out.cloudMinDist = _cmin;
    _out.cloudMinAt = _cminAt;
    wlk_st_ok(_r, _cmin > WLK_ST_FORM_FLOOR,
        "two clouds are too alike in silhouette: " + _cminAt + " at " + string_format(_cmin, 1, 4));

    // ⛔ THE BEVEL LAW, ASSERTED. A bevel wider than the feature it bevels turns that feature
    // inside out - the inset rings self-cross and the lobe renders as two shards with a gap, and
    // NOTHING mechanical downstream sees it: outline fine, winding fine, ink fine, picture wrong.
    // TO MAKE IT FAIL: return a constant from wlk_cloud_bevel_for.
    var _lobeTest = [[[0, 0.2, 0.018]], [[0, 0.2, 0.30]], [[-0.1, 0.2, 0.05], [0.1, 0.2, 0.12]]];
    for (var _i = 0; _i < array_length(_lobeTest); _i++) {
        var _rmin = 999;
        for (var _k = 0; _k < array_length(_lobeTest[_i]); _k++) {
            _rmin = min(_rmin, _lobeTest[_i][_k][2]);
        }
        wlk_st_ok(_r, wlk_cloud_bevel_for(_lobeTest[_i]) < _rmin,
            "bevel reach is not smaller than the smallest lobe it bevels");
    }

    // ---- STAGE 7. THE HORIZON CORPUS ---------------------------------------------------------
    global.wlk_stage = 7;
    var _henv = array_create(WLK_HORIZON_N);
    for (var _i = 0; _i < WLK_HORIZON_N; _i++) {
        var _rail = wlk_horizon_rail(_i, WLK_RANK_NEAR, 0.5);
        wlk_st_ok(_r, array_length(_rail) == WLK_HORIZON_SEGS + 1,
            "horizon " + wlk_horizon_name(_i) + " rail is the wrong length");
        // The skyline must never rise above the top of the frame or dip below its own baseline.
        var _base = wlk_horizon_baseline(WLK_RANK_NEAR);
        var _bad = false;
        for (var _s = 0; _s < array_length(_rail); _s++) {
            if (_rail[_s][1] > _base + WLK_ST_EPS || _rail[_s][1] < -WLK_ST_BOX) _bad = true;
        }
        wlk_st_ok(_r, !_bad, "horizon " + wlk_horizon_name(_i) + " leaves its allowed band");
        _henv[_i] = wlk_st_envelope(wlk_horizon_build(_i, WLK_RANK_NEAR, 0.5));
    }
    var _hmin = 999; var _hminAt = "";
    for (var _i = 0; _i < WLK_HORIZON_N; _i++) {
        for (var _j = _i + 1; _j < WLK_HORIZON_N; _j++) {
            var _d = wlk_st_env_dist(_henv[_i], _henv[_j]);
            if (_d < _hmin) { _hmin = _d; _hminAt = wlk_horizon_name(_i) + " vs " + wlk_horizon_name(_j); }
        }
    }
    _out.horizonMinDist = _hmin;
    _out.horizonMinAt = _hminAt;
    wlk_st_ok(_r, _hmin > 0.004,
        "two horizons are too alike: " + _hminAt + " at " + string_format(_hmin, 1, 4));

    // The sea must be exactly flat. It is the only profile with a literal requirement.
    var _sea = wlk_horizon_rail(0, WLK_RANK_FAR, 0.5);
    var _flat = true;
    for (var _s = 1; _s < array_length(_sea); _s++) {
        if (abs(_sea[_s][1] - _sea[0][1]) > WLK_ST_EPS) _flat = false;
    }
    wlk_st_ok(_r, _flat, "the sea horizon is not flat");

    // ---- STAGE 8. THE WEATHER CORPUS ---------------------------------------------------------
    global.wlk_stage = 8;
    for (var _i = 1; _i < WLK_WEATHER_N; _i++) {
        var _p = wlk_weather_build(_i, 3.0, 1.0, 0.35);
        wlk_st_ok(_r, array_length(_p) > 0, "weather " + wlk_weather_name(_i) + " drew nothing at full intensity");
        var _p0 = wlk_weather_build(_i, 3.0, 0.0, 0.35);
        wlk_st_ok(_r, array_length(_p0) == 0, "weather " + wlk_weather_name(_i) + " drew something at zero intensity");
    }
    wlk_st_ok(_r, array_length(wlk_weather_build(WLK_WX_CLEAR, 3.0, 1.0, 0.35)) == 0,
        "clear weather drew something");

    // ⛔ INTENSITY IS CARRIED BY COUNT AND LENGTH, NEVER BY STROKE WIDTH. draw_line_width floors
    // every stroke at one pixel, so a product that ramps rain by width produces a barcode at
    // gallery scale and nothing at all at game scale. This asserts the DESIGN, not the drawing:
    // light rain and heavy rain must use the same stroke width and differ in how many there are.
    // TO MAKE IT FAIL: multiply the width argument in the RAIN case by _a.
    var _light = wlk_weather_build(WLK_WX_RAIN, 3.0, 0.25, 0.35);
    var _heavy = wlk_weather_build(WLK_WX_RAIN, 3.0, 1.00, 0.35);
    wlk_st_ok(_r, array_length(_heavy) > array_length(_light) * 2,
        "heavier rain is not substantially more numerous than light rain");
    wlk_st_ok(_r, abs(_light[0].w - _heavy[0].w) < WLK_ST_EPS,
        "rain intensity is being carried by stroke width - it must be carried by count and length");

    // Determinism at a fixed time.
    var _a1 = wlk_weather_build(WLK_WX_SNOW, 7.25, 1.0, 0.35);
    var _a2 = wlk_weather_build(WLK_WX_SNOW, 7.25, 1.0, 0.35);
    var _same = (array_length(_a1) == array_length(_a2));
    if (_same) {
        for (var _k = 0; _k < array_length(_a1); _k++) {
            if (abs(_a1[_k].cx - _a2[_k].cx) > WLK_ST_EPS) { _same = false; break; }
        }
    }
    wlk_st_ok(_r, _same, "weather is not deterministic at a fixed time");

    // ---- STAGE 9. THE MOON -------------------------------------------------------------------
    // ⭐ THE PHASE GEOMETRY. The illuminated fraction must be exactly (1 - k) / 2, because the
    // terminator is a half ellipse whose width is k times the radius. TO MAKE IT FAIL: build the
    // crescent by subtracting an offset circle, the construction this file exists to avoid.
    global.wlk_stage = 9;
    for (var _i = 0; _i < WLK_PHASE_N; _i++) {
        var _k = wlk_moon_k(_i);
        wlk_st_ok(_r, abs(wlk_moon_lit(_i) - (1.0 - _k) * 0.5) < WLK_ST_EPS,
            "moon phase " + wlk_moon_phase_name(_i) + " lit fraction disagrees with its terminator");
        wlk_st_ok(_r, _k >= -1.0 - WLK_ST_EPS && _k <= 1.0 + WLK_ST_EPS,
            "moon phase " + wlk_moon_phase_name(_i) + " terminator parameter out of range");
        // ⚠️ THE NEW MOON IS SKIPPED, AND NOT TO DODGE A FAILURE. At k = 1 the terminator lies
        // exactly on the limb, so the lit region has zero area and its outline is every point
        // duplicated - a shape with no turning to measure. wlk_moon_build does not draw it either
        // (lit is 0), so there is no geometry in the product for this assertion to be about.
        // Asserting on it would be asserting about a shape that never reaches a buyer's screen.
        if (wlk_moon_lit(_i) > 0.001) {
            var _o = wlk_moon_outline(0.5, _k, wlk_moon_side(_i), 24);
            wlk_st_ok(_r, abs(abs(wlk_st_turning(_o)) - 1.0) < 0.14,
                "moon phase " + wlk_moon_phase_name(_i) + " outline is not a simple polygon"
                + " (turning " + string_format(wlk_st_turning(_o), 1, 3) + ")");
        }
    }
    wlk_st_ok(_r, abs(wlk_moon_lit(0)) < WLK_ST_EPS, "the new moon is not dark");
    wlk_st_ok(_r, abs(wlk_moon_lit(4) - 1.0) < WLK_ST_EPS, "the full moon is not fully lit");
    wlk_st_ok(_r, abs(wlk_moon_lit(2) - 0.5) < WLK_ST_EPS, "the first quarter is not half lit");
    // ⚠️ WAXING AND WANING ARE MIRROR IMAGES, NOT THE SAME PICTURE. Drawing both the same way
    // halves the corpus without appearing to.
    wlk_st_ok(_r, wlk_moon_side(1) != wlk_moon_side(7),
        "waxing and waning crescents are lit on the same side");
    wlk_st_ok(_r, wlk_moon_side(2) != wlk_moon_side(6),
        "first and last quarter are lit on the same side");

    // ⛔ NO PHASE MAY EMIT A **FILL**, AND THIS IS THE ASSERTION THAT WOULD HAVE CAUGHT THE WORST
    // DEFECT IN THIS PRODUCT'S CORPUS. Until 2026-08-28 wlk_moon_build handed the lit region to
    // wlk_fill, which wlk_render_fill draws as a TRIANGLE FAN - and a fan can only draw a shape
    // that is star-shaped about its first point. The lit region of a crescent is a LUNE, which is
    // concave, so the fan spanned the concavity and filled the entire half disc: every crescent
    // rendered as a quarter, on a sheet whose caption is "THE TERMINATOR IS A HALF ELLIPSE".
    //
    // ⚠️ NOTE WHAT THIS TESTS AND WHAT IT CANNOT. Stage 9 already proved the OUTLINE is a simple
    // polygon with correct turning, and that assertion passed honestly the whole time - the
    // geometry was right and the RASTERISER could not draw it. A suite that computes points can
    // never see a fill rule. What it CAN do is assert the precondition the fan documents, which is
    // what this does: the part kind itself is the evidence.
    for (var _i = 0; _i < WLK_PHASE_N; _i++) {
        var _mp = wlk_moon_build(_i, 0.5);
        var _sawStrip = false;
        for (var _pi = 0; _pi < array_length(_mp); _pi++) {
            wlk_st_ok(_r, _mp[_pi].kind != WLK_FILL,
                "moon phase " + wlk_moon_phase_name(_i)
                + " emits a FILL - a fan cannot draw a concave lune, so a crescent would render "
                + "as a quarter");
            if (_mp[_pi].kind == WLK_STRIP) _sawStrip = true;
        }
        // A partially lit phase must actually contribute lit geometry, or "no fill" would be
        // satisfied trivially by drawing nothing at all.
        if (wlk_moon_lit(_i) > 0.001) {
            wlk_st_ok(_r, _sawStrip,
                "moon phase " + wlk_moon_phase_name(_i) + " draws no lit region at all");
        }
    }

    // ---- STAGE 10. THE ASTRONOMY -------------------------------------------------------------
    // ⭐ THE SEASONS ARE NOT AUTHORED - THEY FALL OUT OF THE SOLAR POSITION EQUATION. These
    // assertions are what prove that claim rather than restating it.
    // TO MAKE IT FAIL: drive the sun from a plain sine of the hour.
    global.wlk_stage = 10;
    var _summer = wlk_sky_create(52, 1); wlk_sky_set_day(_summer, 172); wlk_sky_set_time(_summer, 12);
    var _winter = wlk_sky_create(52, 1); wlk_sky_set_day(_winter, 355); wlk_sky_set_time(_winter, 12);
    var _sAlt = wlk_sky_sun_alt(_summer), _wAlt = wlk_sky_sun_alt(_winter);
    _out.noonAltJune = _sAlt;
    _out.noonAltDecember = _wAlt;
    wlk_st_ok(_r, _sAlt > _wAlt + 20,
        "the June sun is not meaningfully higher than the December sun at latitude 52");

    // Day length: count the hours the sun is up, in both seasons.
    var _upS = 0, _upW = 0;
    for (var _hh = 0; _hh < 24; _hh++) {
        wlk_sky_set_time(_summer, _hh); if (wlk_sky_sun_alt(_summer) > 0) _upS++;
        wlk_sky_set_time(_winter, _hh); if (wlk_sky_sun_alt(_winter) > 0) _upW++;
    }
    _out.dayHoursJune = _upS;
    _out.dayHoursDecember = _upW;
    wlk_st_ok(_r, _upS > _upW + 4, "summer days are not longer than winter days");

    // At the equator every day is about twelve hours, all year. A latitude that does nothing is
    // the tell that the equation has been faked.
    var _eq = wlk_sky_create(0, 1); wlk_sky_set_day(_eq, 172);
    var _upE = 0;
    for (var _hh = 0; _hh < 24; _hh++) { wlk_sky_set_time(_eq, _hh); if (wlk_sky_sun_alt(_eq) > 0) _upE++; }
    _out.dayHoursEquator = _upE;
    wlk_st_ok(_r, _upE >= 11 && _upE <= 13, "the equator does not have a twelve hour day");

    // The sun must rise on the left and set on the right.
    var _m = wlk_sky_create(52, 1); wlk_sky_set_time(_m, 7);
    var _e = wlk_sky_create(52, 1); wlk_sky_set_time(_e, 17);
    wlk_st_ok(_r, wlk_sky_sun_az(_m) < 0, "the morning sun is not on the left");
    wlk_st_ok(_r, wlk_sky_sun_az(_e) > 0, "the evening sun is not on the right");

    // ---- STAGE 11. THE LIGHT STATE -----------------------------------------------------------
    // TO MAKE IT FAIL: let ambient reach zero at night - a scene tinted by it goes pure black and
    // a player cannot read the screen.
    global.wlk_stage = 11;
    var _clear = { overcast: 0, storm: 0, haze: 0 };
    var _noon = wlk_air_light(60, 0, _clear);
    var _night = wlk_air_light(-30, 0, _clear);
    wlk_st_ok(_r, _noon.direct > 0.9, "the noon sun casts no direct light");
    wlk_st_ok(_r, _night.direct < WLK_ST_EPS, "the sun below the horizon still casts direct light");
    wlk_st_ok(_r, _night.ambient > 0.05, "night ambient reached zero - the scene would be unreadable");
    wlk_st_ok(_r, _noon.night < 0.05 && _night.night > 0.9, "the night factor is inverted or flat");
    // Warmth peaks at the horizon, not at noon. Getting this backwards makes midday orange.
    wlk_st_ok(_r, wlk_air_light(0, 0, _clear).warmth > _noon.warmth,
        "sunlight is not warmer at the horizon than at noon");

    // Overcast must reduce direct light and RAISE ambient - cloud spreads light as it dims the sun.
    var _oc = wlk_air_light(45, 0, { overcast: 0.95, storm: 0, haze: 0 });
    wlk_st_ok(_r, _oc.direct < wlk_air_light(45, 0, _clear).direct * 0.4,
        "heavy overcast does not dim the direct sun");

    // ---- STAGE 12. WEATHER CHANGES THE SKY, NOT JUST THE PARTICLES ---------------------------
    // ⛔ THE SINGLE MOST COMMON OMISSION IN THE CATEGORY: rain drawn over an unchanged blue sky.
    // TO MAKE IT FAIL: return a zeroed struct from wlk_weather_sky.
    global.wlk_stage = 12;
    var _clearStops = wlk_air_weather(wlk_air_stops(40), wlk_weather_sky(WLK_WX_CLEAR, 1));
    var _stormStops = wlk_air_weather(wlk_air_stops(40), wlk_weather_sky(WLK_WX_DOWNPOUR, 1));
    var _dark = _clearStops[WLK_ZENITH][0] - _stormStops[WLK_ZENITH][0];
    var _drain = _clearStops[WLK_MID][1] - _stormStops[WLK_MID][1];
    _out.stormDarkening = _dark;
    _out.stormChromaDrain = _drain;
    wlk_st_ok(_r, _dark > 0.05, "a downpour does not darken the sky");
    wlk_st_ok(_r, _drain > 0.02, "a downpour does not drain the sky's colour");
    // And overcast must COMPRESS the ramp, not merely tint it.
    var _clearSpread = _clearStops[WLK_HAZE][0] - _clearStops[WLK_ZENITH][0];
    var _ocStops = wlk_air_weather(wlk_air_stops(40), { overcast: 1.0, storm: 0, haze: 0 });
    var _ocSpread = _ocStops[WLK_HAZE][0] - _ocStops[WLK_ZENITH][0];
    _out.clearSpread = _clearSpread;
    _out.overcastSpread = _ocSpread;
    wlk_st_ok(_r, _ocSpread < _clearSpread * 0.5,
        "overcast does not flatten the sky's top-to-bottom range - it is being tinted, not compressed");

    // ---- STAGE 13. THE RAINBOW ---------------------------------------------------------------
    // ⚠️ RED IS THE OUTSIDE OF A PRIMARY BOW. Getting it backwards is instantly wrong to anyone
    // who has looked at one.
    global.wlk_stage = 13;
    var _bow = wlk_weather_build(WLK_WX_RAINBOW, 0, 1.0, 0.35);
    wlk_st_ok(_r, array_length(_bow) == 7, "the rainbow does not have seven bands");
    var _r0 = point_distance(0, 0.62, _bow[0].pts[0][0], _bow[0].pts[0][1]);
    var _r6 = point_distance(0, 0.62, _bow[6].pts[0][0], _bow[6].pts[0][1]);
    wlk_st_ok(_r, _r0 > _r6, "the rainbow's first band is not the outermost - red must be outside");

    // ⛔ THE BOW MUST ACTUALLY STAND ABOVE ITS OWN CENTRE, AND UNTIL 2026-08-28 IT DID NOT.
    // The two assertions above are true of ANY arc: they check how many bands there are and which
    // is widest, and say nothing about WHERE the arc was swept. wlk_weather passed 185 and 355 to
    // wlk_arc_pts, which takes RADIANS - mod 2*pi that is a 20 degree sliver lying flat on the
    // horizon instead of the upper half of the circle, so the land drew straight over it and the
    // product's rainbow was invisible in every sky it ever rendered. Green suite, empty sky.
    //
    // y is DOWN, so "above the centre" means a SMALLER y than the centre's 0.62. Checking the apex
    // is the cheapest thing that could have caught it, and it stays true only while the sweep is
    // right - a units mistake in either direction fires it immediately.
    var _apex = 999;
    for (var _bp = 0; _bp < array_length(_bow[0].pts); _bp++) {
        _apex = min(_apex, _bow[0].pts[_bp][1]);
    }
    wlk_st_ok(_r, _apex < 0.62 - _r0 * 0.9,
        "the rainbow does not arc ABOVE its antisolar centre - the land will cover it");
    // And it must be a real half-circle, not a sliver: the swept width has to approach the diameter.
    var _bx0 = 999, _bx1 = -999;
    for (var _bp = 0; _bp < array_length(_bow[0].pts); _bp++) {
        _bx0 = min(_bx0, _bow[0].pts[_bp][0]);
        _bx1 = max(_bx1, _bow[0].pts[_bp][0]);
    }
    wlk_st_ok(_r, (_bx1 - _bx0) > _r0 * 1.8,
        "the rainbow sweeps a sliver rather than an arc - check the angle units");

    // ---- STAGE 14. THE CORPUS COUNT ----------------------------------------------------------
    // The volume claim, counted rather than remembered.
    global.wlk_stage = 14;
    var _forms = WLK_CLOUD_N + WLK_HORIZON_N + (WLK_WEATHER_N - 1) + WLK_PHASE_N;
    _out.formCount = _forms;
    _out.cloudForms = WLK_CLOUD_N;
    _out.horizonForms = WLK_HORIZON_N;
    _out.weatherForms = WLK_WEATHER_N - 1;
    _out.moonForms = WLK_PHASE_N;
    wlk_st_ok(_r, _forms >= 40, "the corpus is below the 40 form floor: " + string(_forms));

    // ---- STAGE 15. THE FRONT -----------------------------------------------------------------
    // A front must take time. TO MAKE IT FAIL: set front = 1 in wlk_sky_next_front.
    global.wlk_stage = 15;
    var _fs = wlk_sky_create(52, 3);
    wlk_sky_next_front(_fs);
    wlk_st_ok(_r, _fs.front < 1.0, "a new front started already complete - the sky would snap");
    var _steps = 0;
    while (_fs.front < 1.0 && _steps < 4000) { wlk_sky_step(_fs, 0.05); _steps++; }
    _out.frontSeconds = _steps * 0.05;
    wlk_st_ok(_r, _steps * 0.05 > 4.0, "a front passed in under four seconds - too fast to read");
    wlk_st_ok(_r, _steps < 4000, "a front never completed");

    // The clock must roll over cleanly.
    var _cs = wlk_sky_create(52, 1);
    wlk_sky_set_time(_cs, 23.5);
    var _d0 = _cs.day;
    for (var _i = 0; _i < 400; _i++) wlk_sky_step(_cs, 0.05);
    wlk_st_ok(_r, _cs.hour >= 0 && _cs.hour < 24, "the clock left the 0-24 range");
    wlk_st_ok(_r, _cs.day == _d0 + 1, "the day did not advance across midnight");

    // ---- WRITE THE RESULT --------------------------------------------------------------------
    global.wlk_stage = 99;
    var _s = "{\"pass\":" + string(_r.pass)
           + ",\"fail\":" + string(_r.fail)
           + ",\"formCount\":" + string(_out.formCount)
           + ",\"cloudForms\":" + string(_out.cloudForms)
           + ",\"horizonForms\":" + string(_out.horizonForms)
           + ",\"weatherForms\":" + string(_out.weatherForms)
           + ",\"moonForms\":" + string(_out.moonForms)
           + ",\"skyStates\":" + string(_out.skyStates)
           + ",\"distinctSkies\":" + string(_out.distinctSkies)
           + ",\"skyFloor\":" + string_format(_out.skyFloor, 1, 4)
           + ",\"cloudMinDist\":" + string_format(_out.cloudMinDist, 1, 4)
           + ",\"cloudMinAt\":\"" + _out.cloudMinAt + "\""
           + ",\"horizonMinDist\":" + string_format(_out.horizonMinDist, 1, 4)
           + ",\"horizonMinAt\":\"" + _out.horizonMinAt + "\""
           + ",\"noonAltJune\":" + string_format(_out.noonAltJune, 1, 2)
           + ",\"noonAltDecember\":" + string_format(_out.noonAltDecember, 1, 2)
           + ",\"dayHoursJune\":" + string(_out.dayHoursJune)
           + ",\"dayHoursDecember\":" + string(_out.dayHoursDecember)
           + ",\"dayHoursEquator\":" + string(_out.dayHoursEquator)
           + ",\"stormDarkening\":" + string_format(_out.stormDarkening, 1, 3)
           + ",\"stormChromaDrain\":" + string_format(_out.stormChromaDrain, 1, 3)
           + ",\"clearSpread\":" + string_format(_out.clearSpread, 1, 3)
           + ",\"overcastSpread\":" + string_format(_out.overcastSpread, 1, 3)
           + ",\"frontSeconds\":" + string_format(_out.frontSeconds, 1, 2)
           // Reported, not assumed. WLK_ST_EPS's header is an argument about this number, and an
           // argument about a number nobody printed is a story.
           + ",\"epsilon\":" + string_format(_out.epsilon, 1, 12)
           + ",\"failures\":[";
    for (var _i = 0; _i < array_length(_r.failures); _i++) {
        if (_i > 0) _s += ",";
        _s += "\"" + string_replace_all(_r.failures[_i], "\"", "'") + "\"";
    }
    _s += "]}";

    var _f = file_text_open_write("wlk_selftest.json");
    file_text_write_string(_f, _s);
    file_text_close(_f);
    return _r;
}
