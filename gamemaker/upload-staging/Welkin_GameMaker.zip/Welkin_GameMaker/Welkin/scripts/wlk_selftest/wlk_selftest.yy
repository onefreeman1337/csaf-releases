{
  "$GMScript": "v1",
  "%Name": "wlk_selftest",
  "isCompatibility": false,
  "isDnD": false,
  "name": "wlk_selftest",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}