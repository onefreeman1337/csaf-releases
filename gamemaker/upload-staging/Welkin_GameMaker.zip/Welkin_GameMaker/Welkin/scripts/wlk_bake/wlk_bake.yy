{
  "$GMScript": "v1",
  "%Name": "wlk_bake",
  "isCompatibility": false,
  "isDnD": false,
  "name": "wlk_bake",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}