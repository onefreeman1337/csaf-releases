/// WELKIN - wlk_bake. The store gallery, rendered by the product itself.
///
/// NOT SHIPPED CONTENT IN THE SENSE THAT A BUYER CALLS IT - but it IS shipped, deliberately, so
/// that the claim on the store page is checkable: every image on that page was rendered by the
/// code in this package, at the sizes shown, by running `Welkin.exe -bake`.
///
/// ⛔ A GALLERY RENDERED BY A SIDE PREVIEWER IS A PICTURE OF A RE-IMPLEMENTATION. This wing has
/// the receipt: a sibling product's JavaScript previewer had a defect that was invisible in the
/// previewer and plainly visible in engine, and the gallery would have shipped the previewer's
/// version of the truth. Baking from the shipping executable removes the whole class.
///
/// -- THE INK CHECK HERE IS NOT THE ONE THE OTHER PRODUCTS USE, AND THE DIFFERENCE IS REAL -------
/// Every previous product in this wing measures ink against a FLAT PAGE GROUND: scan for pixels
/// that differ from the background, and the bounding box of those pixels answers "is this sheet
/// empty" and "is it clipped".
///
/// ⛔ THAT CHECK IS MEANINGLESS ON THIS PRODUCT, and adopting it unexamined would have produced a
/// suite of green numbers that could not fail. A Welkin sheet has no flat ground: the entire image
/// IS a gradient, so EVERY pixel differs from any single reference colour and the ink box is
/// always the whole sheet, always "ok", always blind.
///
/// ⭐ WHAT ACTUALLY DISCRIMINATES ON A GRADIENT IS HORIZONTAL VARIATION. A pure vertical gradient
/// has exactly ONE colour per row, by construction. A cloud, a mountain, a star, the sun, a
/// caption - anything at all that is not the bare sky - puts a SECOND colour in the rows it
/// touches. So the measure is: how many rows contain more than one colour, and where do those rows
/// sit. That catches an empty sheet (a beautiful gradient with nothing on it) which the standard
/// check would pass at 100%.
///
/// ⚠️ AND ITS HONEST LIMIT, STATED RATHER THAN DISCOVERED LATER: it cannot see a full-width band of
/// uniform colour, because such a band is one colour per row like the gradient itself. The land
/// ranks are close to that, so the land contributes to this measure mainly through its SKYLINE,
/// where the profile varies. That is a weaker claim than "it sees everything" and it is the true
/// one. The instrument for everything else is opening the PNG.
/// ============================================================================================

/// Rows must be this fraction non-uniform for a sheet to pass.
/// ⚠️ REPORTED BESIDE ITS MEASUREMENT so it can be argued with rather than trusted.
#macro WLK_BK_CONTENT_FLOOR 0.55

/// How far a channel may drift before two pixels count as different colours. 6 of 255 is below
/// what an eye resolves on a smooth ramp and well above dither noise.
#macro WLK_BK_TOL 6

/// The measure described in the header.
///
/// ⛔ y STEPS BY 1, NOT BY 2. This wing measured the cost of an even-only scan on another product:
/// a one-pixel title rule sitting on an ODD row was walked past entirely, and a clipped hairline is
/// precisely the shape that lands on one row. x may step by 2 - nothing in this package draws a
/// one-pixel-wide VERTICAL feature.
function wlk_bk_content(_surf, _w, _h) {
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _surf, 0);

    var _rows = 0;
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1;

    for (var _y = 0; _y < _h; _y++) {
        var _base = _y * _w * 4;
        var _r0 = buffer_peek(_buf, _base, buffer_u8);
        var _g0 = buffer_peek(_buf, _base + 1, buffer_u8);
        var _b0 = buffer_peek(_buf, _base + 2, buffer_u8);
        var _hit = false;
        for (var _x = 2; _x < _w; _x += 2) {
            var _o = _base + _x * 4;
            var _rr = buffer_peek(_buf, _o, buffer_u8);
            var _gg = buffer_peek(_buf, _o + 1, buffer_u8);
            var _bb = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_rr - _r0) > WLK_BK_TOL || abs(_gg - _g0) > WLK_BK_TOL
             || abs(_bb - _b0) > WLK_BK_TOL) {
                _hit = true;
                if (_x < _x0) _x0 = _x;
                if (_x > _x1) _x1 = _x;
                if (_y < _y0) _y0 = _y;
                if (_y > _y1) _y1 = _y;
            }
        }
        if (_hit) _rows++;
    }
    buffer_delete(_buf);

    return {
        rows: _rows,
        frac: (_h > 0) ? (_rows / _h) : 0,
        x0: _x0, y0: _y0, x1: _x1, y1: _y1,
    };
}

/// Render one sheet, save it, measure it, and report.
function wlk_bk_sheet(_name, _w, _h, _fn) {
    var _surf = surface_create(_w, _h);
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 1);

    _fn(_w, _h);

    surface_reset_target();

    var _c = wlk_bk_content(_surf, _w, _h);
    surface_save(_surf, _name + ".png");
    surface_free(_surf);

    var _ok = (_c.frac >= WLK_BK_CONTENT_FLOOR) && (_c.x1 > 0);
    var _reason = _ok ? "ok"
        : ("only " + string_format(_c.frac * 100, 1, 1) + "% of rows carry anything but bare sky");

    return { sheet: _name, ok: _ok, frac: _c.frac, rows: _c.rows,
             content: [_c.x0, _c.y0, _c.x1, _c.y1], reason: _reason };
}

/// A caption bar. Sized from the MEASURED string, never from an assumed length.
///
/// ⛔ THIS WING HAS SHIPPED AN OVERPRINTED CAPTION TWICE - two place names collided into a word
/// that is not a place, and a fix that shortened the DATA rather than the LAYOUT let it come back
/// on the next product. wlk_text_line takes a max width and scales to it, so renaming a cloud can
/// never re-open it. NO INK CHECK WILL EVER CATCH THIS: overprinted text is ink exactly where ink
/// belongs. It is found by reading the sheet.
function wlk_bk_caption(_text, _x, _y, _maxw, _px, _col) {
    wlk_text_line(_text, _x, _y, _maxw, _px, _col, true);
}

/// ============================================================================================
/// THE SHEETS
/// ============================================================================================

function wlk_bake_run() {
    var _sheets = [];
    var _W = 1600, _H = 1000;

    // ---- 0. THE HERO. One sky, drawn by one call, at the hour the product is best at. --------
    global.wlk_stage = 0;
    array_push(_sheets, wlk_bk_sheet("sheet_0_hero", _W, 900, function(_w, _h) {
        var _s = wlk_sky_create(48, 7);
        wlk_sky_set_time(_s, 19.35);
        wlk_sky_set_day(_s, 210);
        wlk_sky_force_weather(_s, WLK_WX_CLEAR, 0);
        _s.horizon_far = 6; _s.horizon_mid = 5; _s.horizon_near = 3;
        _s.t = 40;
        var _pal = wlk_sky_draw(_s, 0, 0, _w, _h);
        wlk_bk_caption("ONE CALL. THE SKY, THE CLOUD DECK, THE LAND AND THE LIGHT.",
                       48, _h - 74, _w - 96, 30, _pal.s0);
    }));

    // ---- 1. TWELVE HOURS. The page that answers "is this one gradient with a slider on it". --
    global.wlk_stage = 1;
    array_push(_sheets, wlk_bk_sheet("sheet_1_hours", _W, _H, function(_w, _h) {
        var _cols = 4, _rows = 3;
        var _cw = _w / _cols, _ch = (_h - 60) / _rows;
        for (var _i = 0; _i < 12; _i++) {
            var _s = wlk_sky_create(52, 7);
            wlk_sky_set_time(_s, _i * 2);
            wlk_sky_set_day(_s, 172);
            wlk_sky_force_weather(_s, WLK_WX_CLEAR, 0);
            _s.t = 40;
            var _cx = (_i % _cols) * _cw;
            var _cy = floor(_i / _cols) * _ch + 60;
            var _pal = wlk_sky_draw(_s, _cx, _cy, _cw, _ch);
            wlk_text_line(string(_i * 2) + ":00", _cx + 14, _cy + 10, _cw - 28, 20, _pal.s0, true);
        }
        wlk_bk_caption("TWELVE HOURS. FIVE STOPS, EACH WITH ITS OWN LIGHTNESS, CHROMA AND HUE.",
                       48, 16, _w - 96, 28, c_white);
    }));

    // ---- 2. THE FOURTEEN CLOUD GENERA --------------------------------------------------------
    global.wlk_stage = 2;
    // ⚠️ 830 TALL, NOT 880, AND THE FORMS FILL 76% OF A ROW RATHER THAN 62%. The content check
    // rejected this sheet twice (53.0%, then 53.5% after the genera were redrawn) and the fix is
    // never to lower the floor: a corpus page that is half bare sky is a page arguing the corpus is
    // thin. Both numbers here add content instead - less dead height per row, and each form drawn
    // bigger inside the row it has.
    array_push(_sheets, wlk_bk_sheet("sheet_2_clouds", _W, 830, function(_w, _h) {
        var _g = wlk_sky_create(52, 7);
        wlk_sky_set_time(_g, 10.0);
        wlk_sky_force_weather(_g, WLK_WX_CLEAR, 0);
        var _light = wlk_sky_light(_g);
        var _pal = wlk_sky_palette(_g, _light);
        wlk_lamp_set(_light.lx, _light.ly);
        var _cols = array_create(WLK_STOPS);
        for (var _s = 0; _s < WLK_STOPS; _s++) _cols[_s] = variable_struct_get(_pal, "s" + string(_s));
        wlk_render_ramp(0, 0, _w, _h, _cols, [0.36, 0.27, 0.21, 0.16]);

        var _cc = 5, _rr = 3;
        var _cw = _w / _cc, _ch = (_h - 90) / _rr;
        for (var _i = 0; _i < WLK_CLOUD_N; _i++) {
            var _cx = (_i % _cc) * _cw + _cw * 0.5;
            var _cy = floor(_i / _cc) * _ch + _ch * 0.5 + 80;
            var _cpal = wlk_air_cloud_ramp(_pal.stops, _light, wlk_cloud_thick(_i));
            for (var _s = 0; _s < WLK_STOPS; _s++) {
                variable_struct_set(_cpal, "s" + string(_s), _cols[_s]);
            }
            _cpal.line = _pal.line;
            // ⛔ FIT TO THE FORM'S OWN BOUNDS, NOT TO ITS UNIT BOX. A cumulus occupies about half
            // the height of its box and a cirrus far less, so placing every form at one scale
            // draws the whole corpus small and adrift in its cell - the sheet measured 50% bare
            // and was rejected by the content check. wlk_render_in_rect_tight measures each form
            // and fills the cell with it, so a wisp and a storm head both arrive at a usable size.
            wlk_render_in_rect_tight(wlk_cloud_build(_i, 3), _cpal,
                                     _cx - _cw * 0.47, _cy - _ch * 0.42,
                                     _cw * 0.94, _ch * 0.76, undefined);
            wlk_text_line(wlk_cloud_name(_i), _cx - _cw * 0.46, _cy + _ch * 0.38, _cw * 0.92,
                          18, _pal.ground, true);
        }
        wlk_lamp_reset();
        wlk_bk_caption("FOURTEEN CLOUD GENERA, DRAWN FROM DATA. NO SPRITE IN THIS PACKAGE.",
                       48, 22, _w - 96, 30, _pal.ground);
    }));

    // ---- 3. THE TWELVE WEATHERS --------------------------------------------------------------
    global.wlk_stage = 3;
    array_push(_sheets, wlk_bk_sheet("sheet_3_weather", _W, _H, function(_w, _h) {
        var _cc = 4, _rr = 3;
        var _cw = _w / _cc, _ch = (_h - 60) / _rr;
        for (var _i = 0; _i < WLK_WEATHER_N; _i++) {
            var _s = wlk_sky_create(52, 7);
            wlk_sky_set_time(_s, 15.0);
            // ⛔ THE RAINBOW CELL NEEDS A LOW SUN OR IT IS AN EMPTY PROMISE. A primary bow is a
            // circle 42 degrees from the antisolar point, so above a 42 degree sun the whole arc is
            // under the horizon and wlk_sky correctly draws nothing. At latitude 52 in midsummer the
            // sun is still near 45 degrees at 15:00, so this sheet shipped a cell captioned RAINBOW
            // containing no rainbow - the PRODUCT was right and the STORE IMAGE was wrong, which is
            // the harder of the two to notice. 18:20 puts the sun near 20 degrees, inside the window.
            if (_i == WLK_WX_RAINBOW) wlk_sky_set_time(_s, 18.33);
            wlk_sky_force_weather(_s, _i, 1.0);
            // A different time offset per cell so twelve panels are not twelve frames of one
            // instant - the precipitation would rank up into visible diagonal ranks otherwise.
            _s.t = 30 + _i * 3.7;
            if (_i == WLK_WX_LIGHTNING) { _s.strike = _s.t - 0.05; _s.strike_i = 3; }
            var _cx = (_i % _cc) * _cw;
            var _cy = floor(_i / _cc) * _ch + 60;
            var _pal = wlk_sky_draw(_s, _cx, _cy, _cw, _ch);
            wlk_text_line(string_upper(wlk_weather_name(_i)), _cx + 14, _cy + _ch - 34,
                          _cw - 28, 18, _pal.s0, true);
        }
        wlk_bk_caption("TWELVE WEATHERS. EVERY ONE DRAWN, NOT BLITTED - AND EACH CHANGES THE SKY.",
                       48, 16, _w - 96, 28, c_white);
    }));

    // ---- 4. THE TEN HORIZONS -----------------------------------------------------------------
    global.wlk_stage = 4;
    // ⚠️ 760 TALL RATHER THAN 1000, AND THE REASON IS THE MEASURE, NOT THE LOOK. Each cell here is
    // a whole sky, and a whole sky is mostly gradient - so a taller cell is a cell with MORE bare
    // sky in it, and the sheet fell under the content floor. Shortening the panels raises the
    // fraction of each one occupied by the thing the sheet is actually about, which is the land.
    array_push(_sheets, wlk_bk_sheet("sheet_4_horizons", _W, 760, function(_w, _h) {
        var _cc = 5, _rr = 2;
        var _cw = _w / _cc, _ch = (_h - 60) / _rr;
        for (var _i = 0; _i < WLK_HORIZON_N; _i++) {
            var _s = wlk_sky_create(52, 4);
            wlk_sky_set_time(_s, 17.4);
            wlk_sky_force_weather(_s, WLK_WX_CLEAR, 0);
            _s.t = 40;
            _s.horizon_far = _i; _s.horizon_mid = _i; _s.horizon_near = _i;
            var _cx = (_i % _cc) * _cw;
            var _cy = floor(_i / _cc) * _ch + 60;
            var _pal = wlk_sky_draw(_s, _cx, _cy, _cw, _ch);
            wlk_text_line(wlk_horizon_name(_i), _cx + 12, _cy + _ch - 32, _cw - 24, 17, _pal.s0, true);
        }
        wlk_bk_caption("TEN HORIZONS, EACH IN THREE DEPTH RANKS THAT TAKE THEIR COLOUR FROM THE SKY.",
                       48, 16, _w - 96, 28, c_white);
    }));

    // ---- 5. THE EIGHT MOON PHASES ------------------------------------------------------------
    global.wlk_stage = 5;
    array_push(_sheets, wlk_bk_sheet("sheet_5_moon", _W, 760, function(_w, _h) {
        var _s = wlk_sky_create(52, 7);
        wlk_sky_set_time(_s, 1.0);
        wlk_sky_force_weather(_s, WLK_WX_CLEAR, 0);
        var _light = wlk_sky_light(_s);
        var _pal = wlk_sky_palette(_s, _light);
        var _cols = array_create(WLK_STOPS);
        for (var _k = 0; _k < WLK_STOPS; _k++) _cols[_k] = variable_struct_get(_pal, "s" + string(_k));
        wlk_render_ramp(0, 0, _w, _h, _cols, [0.36, 0.27, 0.21, 0.16]);
        wlk_render_parts(wlk_star_build(1.0, 7, 0.42), _pal, _w * 0.5, _h * 0.5, _w, 0, 1, undefined);

        var _cc = 4, _rr = 2;
        var _cw = _w / _cc, _ch = (_h - 110) / _rr;
        for (var _i = 0; _i < WLK_PHASE_N; _i++) {
            var _cx = (_i % _cc) * _cw + _cw * 0.5;
            var _cy = floor(_i / _cc) * _ch + _ch * 0.5 + 96;
            wlk_render_parts(wlk_moon_build(_i, 0.5), _pal, _cx, _cy, _ch * 0.52, 0, 1, undefined);
            wlk_text_line(wlk_moon_phase_name(_i), _cx - _cw * 0.44, _cy + _ch * 0.30,
                          _cw * 0.88, 17, _pal.s4, false);
        }
        wlk_bk_caption("EIGHT PHASES. THE TERMINATOR IS A HALF ELLIPSE, NOT AN OFFSET CIRCLE.",
                       48, 26, _w - 96, 28, _pal.s4);
    }));

    // ---- 6. SEASON AND LATITUDE --------------------------------------------------------------
    // The sheet that shows the astronomy is real: the SAME HOUR, four places and times of year.
    global.wlk_stage = 6;
    array_push(_sheets, wlk_bk_sheet("sheet_6_season", _W, 700, function(_w, _h) {
        var _set = [[52, 172, "LAT 52  MIDSUMMER"], [52, 355, "LAT 52  MIDWINTER"],
                    [8, 172, "LAT 8  JUNE"], [68, 172, "LAT 68  JUNE"]];
        var _cw = _w / 4;
        for (var _i = 0; _i < 4; _i++) {
            var _s = wlk_sky_create(_set[_i][0], 7);
            wlk_sky_set_day(_s, _set[_i][1]);
            wlk_sky_set_time(_s, 17.0);
            wlk_sky_force_weather(_s, WLK_WX_CLEAR, 0);
            _s.t = 40;
            var _pal = wlk_sky_draw(_s, _i * _cw, 60, _cw, _h - 60);
            var _alt = wlk_sky_sun_alt(_s);
            wlk_text_line(_set[_i][2], _i * _cw + 14, _h - 62, _cw - 28, 17, _pal.s0, true);
            wlk_text_line("sun " + string_format(_alt, 1, 1) + " deg at 17:00",
                          _i * _cw + 14, _h - 38, _cw - 28, 15, _pal.s1, false);
        }
        wlk_bk_caption("SAME CLOCK, FOUR PLACES. THE SEASONS ARE THE SOLAR EQUATION, NOT PRESETS.",
                       48, 16, _w - 96, 28, c_white);
    }));

    // ---- 7. A FRONT ARRIVING -----------------------------------------------------------------
    // Four panels along one continuous transition, which is the thing a still gallery is worst at
    // showing and the thing the product is best at.
    global.wlk_stage = 7;
    array_push(_sheets, wlk_bk_sheet("sheet_7_front", _W, 700, function(_w, _h) {
        var _cw = _w / 4;
        var _labels = ["CLEAR", "THE FRONT ARRIVES", "OVERCAST", "DOWNPOUR"];
        var _fr = [0.0, 0.34, 0.72, 1.0];
        for (var _i = 0; _i < 4; _i++) {
            var _s = wlk_sky_create(52, 7);
            wlk_sky_set_time(_s, 14.0);
            wlk_sky_force_weather(_s, WLK_WX_CLEAR, 0);
            _s.wx = WLK_WX_CLEAR; _s.wx_amt = 0;
            _s.wx_next = WLK_WX_DOWNPOUR; _s.wx_amt_next = 1.0;
            _s.front = _fr[_i];
            _s.t = 30 + _i * 2.3;
            var _pal = wlk_sky_draw(_s, _i * _cw, 60, _cw, _h - 60);
            wlk_text_line(_labels[_i], _i * _cw + 14, _h - 44, _cw - 28, 18, _pal.s0, true);
        }
        wlk_bk_caption("A FRONT IS A TRANSITION, NOT A SWITCH. THE DECK FILLS IN CLOUD BY CLOUD.",
                       48, 16, _w - 96, 28, c_white);
    }));

    // ---- report ------------------------------------------------------------------------------
    global.wlk_stage = 99;
    var _bad = 0;
    var _s = "{\"sheets\":[";
    for (var _i = 0; _i < array_length(_sheets); _i++) {
        var _sh = _sheets[_i];
        if (!_sh.ok) _bad++;
        if (_i > 0) _s += ",";
        _s += "{\"sheet\":\"" + _sh.sheet + "\""
            + ",\"ok\":" + (_sh.ok ? "true" : "false")
            + ",\"frac\":" + string_format(_sh.frac, 1, 3)
            + ",\"rows\":" + string(_sh.rows)
            + ",\"content\":[" + string(_sh.content[0]) + "," + string(_sh.content[1]) + ","
                              + string(_sh.content[2]) + "," + string(_sh.content[3]) + "]"
            + ",\"reason\":\"" + _sh.reason + "\"}";
    }
    _s += "],\"rejected\":" + string(_bad)
        + ",\"contentFloor\":" + string_format(WLK_BK_CONTENT_FLOOR, 1, 2) + "}";

    var _f = file_text_open_write("wlk_bake.json");
    file_text_write_string(_f, _s);
    file_text_close(_f);
    return _sheets;
}
