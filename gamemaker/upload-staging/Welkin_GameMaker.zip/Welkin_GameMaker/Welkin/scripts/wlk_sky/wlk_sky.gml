/// WELKIN - wlk_sky. THE SYSTEM.
///
/// This is the file a buyer actually calls. Everything else in the package is a corpus or a
/// drawing layer; this is the clock, the calendar, the weather fronts, the light state and the one
/// draw call that composes all of it in the right order.
///
/// -- THE WHOLE API, IN FIVE LINES -------------------------------------------------------------
///
///     sky = wlk_sky_create(52, 1);            // latitude, seed          -- Create event
///     wlk_sky_step(sky, delta_time / 1000000);                           -- Step event
///     wlk_sky_draw(sky, 0, 0, room_width, room_height);                  -- Draw event
///     var L = wlk_sky_light(sky);             // tint YOUR scene with it
///     wlk_sky_set_weather(sky, WLK_WX_DOWNPOUR, 1.0);
///
/// -- THE SUN'S POSITION IS REAL ASTRONOMY, AND IT IS THREE LINES ------------------------------
/// ⭐ THE STANDARD SOLAR POSITION EQUATION COSTS NOTHING AND BUYS THE ENTIRE SEASON SYSTEM. Fake
/// it - drive the sun with a sine of the hour - and every day of the year is the same length, the
/// sun reaches the same height in December as in June, and there is no such thing as a latitude.
/// Use the real equation and all three fall out for free:
///
///     sin(altitude) = sin(declination) sin(latitude) + cos(declination) cos(latitude) cos(H)
///
/// where H is the hour angle, 15 degrees per hour from noon, and the declination is where the sun
/// sits relative to the equator on that day of the year. So a January day at latitude 60 really is
/// short and the sun really does stay low and the light really is warm all day - because the
/// geometry says so, not because someone authored a "winter" preset.
///
/// ⚠️ THIS IS THE PRODUCT'S GATE 2 CLAIM MADE CONCRETE. The measured incumbent applies "different
/// colour" and transparency over the developer's scene. This computes where the sun IS and draws
/// what the sky consequently LOOKS like.
///
/// -- DRAW ORDER IS NOT A DETAIL ---------------------------------------------------------------
/// The frame is composed strictly back to front, and two orderings in it are load-bearing and are
/// commented where they happen: the lightning FLASH goes UNDER the clouds it illuminates, and the
/// sun's glow rings go LARGEST FIRST. Both are recorded in this wing's constitution as defects
/// measured on other products.
/// ============================================================================================

/// Where the horizon sits in the frame, as a fraction of frame height.
/// ⚠️ 0.68 RATHER THAN 0.5: a horizon on the centre line splits the picture in half and reads as a
/// diagram. Putting it low gives the sky the two thirds it needs to be the subject - which is the
/// whole point of the product, and was the thing the first rendered hero sheet got wrong.
#macro WLK_SKY_HORIZON 0.68

/// Seconds of real time per in-game hour, at speed 1.
#macro WLK_SKY_HOUR_SECONDS 6.0

/// The synodic month - new moon to new moon - in days.
#macro WLK_SKY_SYNODIC 29.53

/// ============================================================================================
/// CREATE
/// ============================================================================================

/// _lat  latitude in degrees. 0 equator, 52 northern Europe, 68 inside the Arctic circle.
/// _seed any integer. Two skies with the same seed are identical forever; two with different seeds
///       get different cloud placements, different horizons and different weather sequences.
function wlk_sky_create(_lat, _seed) {
    return {
        lat:      is_undefined(_lat) ? 52 : _lat,
        seed:     is_undefined(_seed) ? 1 : _seed,

        hour:     9.0,          // 0..24
        day:      172,          // day of year; 172 is the June solstice
        speed:    1.0,          // 0 freezes the clock, which is what a screenshot wants

        wx:       WLK_WX_CLEAR, // the weather now
        wx_amt:   0.0,
        wx_next:  WLK_WX_CLEAR, // the weather the front is bringing
        wx_amt_next: 0.0,
        front:    1.0,          // 0 = fully the old weather, 1 = fully the new
        front_speed: 0.0,
        dwell:    18.0,         // seconds until the next front is chosen
        front_i:  0,            // which front this is, for deterministic choices

        horizon_far:  6,        // mountains
        horizon_mid:  5,        // foothills
        horizon_near: 3,        // conifer ridge

        wind:     0.35,
        t:        0.0,          // free-running seconds, drives precipitation

        strike:   -99.0,        // when the last lightning strike began
        strike_i: 0,

        auto_weather: true,     // false = the game drives the weather itself
    };
}

/// ============================================================================================
/// ASTRONOMY
/// ============================================================================================

/// The sun's declination on a day of the year, in degrees.
/// 81 is the March equinox; 23.44 is the tilt of the Earth's axis.
function wlk_sky_declination(_day) {
    return 23.44 * sin(WLK_TAU * (_day - 81) / 365.0);
}

/// The sun's altitude above the horizon, in degrees.
function wlk_sky_sun_alt(_sky) {
    var _dec = degtorad(wlk_sky_declination(_sky.day));
    var _lat = degtorad(_sky.lat);
    var _H = degtorad((_sky.hour - 12.0) * 15.0);
    var _s = sin(_dec) * sin(_lat) + cos(_dec) * cos(_lat) * cos(_H);
    return radtodeg(arcsin(clamp(_s, -1, 1)));
}

/// Where the sun sits across the frame, -1 (left) .. +1 (right).
///
/// ⚠️ THE VIEW FACES THE EQUATOR, so the sun rises on the LEFT and sets on the RIGHT. That is not
/// arbitrary: facing south in the northern hemisphere puts east on your left, and it is the view
/// nearly every side-on game presents. sin(H) is exactly that mapping and needs no correction.
function wlk_sky_sun_az(_sky) {
    return clamp(sin(degtorad((_sky.hour - 12.0) * 15.0)) * 1.25, -1, 1);
}

/// The moon's phase as a fraction, 0 new .. 0.5 full .. 1 new again.
function wlk_sky_moon_frac(_sky) {
    return wlk_frac01(_sky.day / WLK_SKY_SYNODIC);
}

/// The moon's phase as one of the eight authored forms.
function wlk_sky_moon_phase(_sky) {
    return round(wlk_sky_moon_frac(_sky) * WLK_PHASE_N) % WLK_PHASE_N;
}

/// The moon's altitude. The moon lags the sun by its phase: at new it rises with the sun, at full
/// it rises as the sun sets - which is why a full moon is the only one you see all night.
function wlk_sky_moon_alt(_sky) {
    var _lag = wlk_sky_moon_frac(_sky) * 24.0;
    var _h = wlk_frac01((_sky.hour - _lag + 24.0) / 24.0) * 24.0;
    var _dec = degtorad(wlk_sky_declination(_sky.day) * -0.6);   // the moon's own path, flattened
    var _lat = degtorad(_sky.lat);
    var _H = degtorad((_h - 12.0) * 15.0);
    var _s = sin(_dec) * sin(_lat) + cos(_dec) * cos(_lat) * cos(_H);
    return radtodeg(arcsin(clamp(_s, -1, 1)));
}

function wlk_sky_moon_az(_sky) {
    var _lag = wlk_sky_moon_frac(_sky) * 24.0;
    var _h = wlk_frac01((_sky.hour - _lag + 24.0) / 24.0) * 24.0;
    return clamp(sin(degtorad((_h - 12.0) * 15.0)) * 1.25, -1, 1);
}

/// ============================================================================================
/// THE CLOCK AND THE FRONTS
/// ============================================================================================

/// Advance the sky by _dt real seconds.
/// ⛔ Guard pass 2026-09-08. Refuses silently: this advances state and returns nothing a caller
/// branches on.
function wlk_sky_step(_sky, _dt) {
    if (!is_struct(_sky) || !is_numeric(_dt)) return;
    var _d = max(0, _dt);
    _sky.t += _d;

    _sky.hour += (_d / WLK_SKY_HOUR_SECONDS) * _sky.speed;
    while (_sky.hour >= 24.0) { _sky.hour -= 24.0; _sky.day += 1; }
    while (_sky.day > 365) _sky.day -= 365;

    // A front in progress advances; a settled sky counts down to the next one.
    if (_sky.front < 1.0) {
        _sky.front = min(1.0, _sky.front + _d * _sky.front_speed);
        if (_sky.front >= 1.0) {
            _sky.wx = _sky.wx_next;
            _sky.wx_amt = _sky.wx_amt_next;
            _sky.dwell = 14.0 + wlk_wx_hash(_sky.front_i, 60) * 30.0;
        }
    } else if (_sky.auto_weather) {
        _sky.dwell -= _d;
        if (_sky.dwell <= 0) wlk_sky_next_front(_sky);
    }

    // Lightning. A strike is an EVENT with a lifetime, not a continuous effect: it fires, it is
    // visible for a fifth of a second, and it is gone. Anything longer reads as a light bulb.
    var _stormy = (wlk_sky_weather_now(_sky) == WLK_WX_LIGHTNING);
    if (_stormy && (_sky.t - _sky.strike) > 1.2) {
        if (wlk_wx_hash(floor(_sky.t * 3.0) + _sky.seed * 13, 61) > 0.90) {
            _sky.strike = _sky.t;
            _sky.strike_i += 1;
        }
    }
    return _sky;
}

/// Choose the next weather. Deterministic in the front index and the seed, so a replay of the same
/// seed produces the same weather in the same order - which is what makes a screenshot reproducible
/// and a bug report actionable.
///
/// ⚠️ THE TRANSITION IS NOT INSTANT AND MUST NOT BE. A sky that snaps from clear to downpour on one
/// frame is the single most obvious tell in the category. front_speed is set so a front takes
/// between eight and twenty seconds to pass, which at the default clock is a couple of in-game
/// hours - roughly what a real front takes.
function wlk_sky_next_front(_sky) {
    if (!is_struct(_sky)) return undefined;
    _sky.front_i += 1;
    var _r = wlk_wx_hash(_sky.front_i + _sky.seed * 97, 62);

    // Fair weather is more common than foul, which is both true and better play: the dramatic
    // weathers land harder when they are not constant.
    var _pick;
    if (_r < 0.34)      _pick = WLK_WX_CLEAR;
    else if (_r < 0.44) _pick = WLK_WX_MIST;
    else if (_r < 0.54) _pick = WLK_WX_DRIZZLE;
    else if (_r < 0.66) _pick = WLK_WX_RAIN;
    else if (_r < 0.73) _pick = WLK_WX_DOWNPOUR;
    else if (_r < 0.79) _pick = WLK_WX_LIGHTNING;
    else if (_r < 0.85) _pick = WLK_WX_FOG;
    else if (_r < 0.90) _pick = WLK_WX_SNOW;
    else if (_r < 0.94) _pick = WLK_WX_SLEET;
    else if (_r < 0.97) _pick = WLK_WX_HAIL;
    else                _pick = WLK_WX_BLIZZARD;

    // ⭐ SNOW ONLY WHERE AND WHEN IT COULD SNOW. A blizzard in July at the equator is the kind of
    // detail that costs three lines and would otherwise be the first thing a reviewer mentions.
    // The test is crude on purpose - it is a game, not a climate model - but it is never wrong in
    // the obvious direction.
    var _cold = (abs(_sky.lat) > 35) && (_sky.day < 80 || _sky.day > 300);
    if (!_cold && (_pick == WLK_WX_SNOW || _pick == WLK_WX_BLIZZARD || _pick == WLK_WX_SLEET)) {
        _pick = WLK_WX_RAIN;
    }

    // A rainbow is not chosen; it is EARNED. It appears when rain is clearing and the sun is low
    // enough for the arc to stand above the horizon - which is exactly when real ones appear.
    var _alt = wlk_sky_sun_alt(_sky);
    var _wasRain = (_sky.wx == WLK_WX_RAIN || _sky.wx == WLK_WX_DOWNPOUR || _sky.wx == WLK_WX_DRIZZLE);
    if (_pick == WLK_WX_CLEAR && _wasRain && _alt > 2 && _alt < 42) _pick = WLK_WX_RAINBOW;

    _sky.wx_next = _pick;
    _sky.wx_amt_next = (_pick == WLK_WX_CLEAR) ? 0.0
                     : (0.45 + 0.55 * wlk_wx_hash(_sky.front_i + _sky.seed * 31, 63));
    _sky.front = 0.0;
    _sky.front_speed = 1.0 / (8.0 + wlk_wx_hash(_sky.front_i, 64) * 12.0);
    return _sky;
}

/// The weather to draw right now - the one with the larger share of the front.
function wlk_sky_weather_now(_sky) {
    return (_sky.front < 0.5) ? _sky.wx : _sky.wx_next;
}

/// Set the weather directly, with a front rather than a snap. Turns auto weather off, because a
/// game that has asked for a specific sky does not want one chosen for it two seconds later.
function wlk_sky_set_weather(_sky, _wx, _amt) {
    _sky.auto_weather = false;
    _sky.wx_next = _wx;
    _sky.wx_amt_next = clamp(is_undefined(_amt) ? 1.0 : _amt, 0, 1);
    _sky.front = 0.0;
    _sky.front_speed = 1.0 / 6.0;
    return _sky;
}

/// Snap the weather with no transition. For a scene cut, a load, or a screenshot.
/// ⛔ REFUSES AN OUT-OF-RANGE WEATHER ID as well as a wrong type. The weathers are macros
/// WLK_WX_CLEAR..WLK_WX_RAINBOW (0..11); a buyer passing 12 or -1 would set a state nothing can
/// draw, which is a silently empty sky rather than an error.
function wlk_sky_force_weather(_sky, _wx, _amt) {
    if (!is_struct(_sky) || !is_numeric(_wx) || !is_numeric(_amt)) return undefined;
    if (_wx < WLK_WX_CLEAR || _wx > WLK_WX_RAINBOW) return undefined;
    _sky.auto_weather = false;
    _sky.wx = _wx; _sky.wx_next = _wx;
    _sky.wx_amt = clamp(is_undefined(_amt) ? 1.0 : _amt, 0, 1);
    _sky.wx_amt_next = _sky.wx_amt;
    _sky.front = 1.0;
    return _sky;
}

function wlk_sky_set_time(_sky, _hour) {
    if (!is_struct(_sky) || !is_numeric(_hour)) return undefined;
    _sky.hour = wlk_frac01(max(0, _hour) / 24.0) * 24.0;
    return _sky;
}

function wlk_sky_set_day(_sky, _day) {
    if (!is_struct(_sky) || !is_numeric(_day)) return undefined;
    _sky.day = clamp(round(_day), 1, 365);
    return _sky;
}

/// ============================================================================================
/// THE STATE A GAME READS
/// ============================================================================================

/// The blended weather struct for the sky's current moment.
function wlk_sky_conditions(_sky) {
    var _a = wlk_weather_sky(_sky.wx, _sky.wx_amt);
    var _b = wlk_weather_sky(_sky.wx_next, _sky.wx_amt_next);
    var _f = clamp(_sky.front, 0, 1);
    return {
        overcast: lerp(_a.overcast, _b.overcast, _f),
        storm:    lerp(_a.storm,    _b.storm,    _f),
        haze:     lerp(_a.haze,     _b.haze,     _f),
    };
}

/// ⭐ THE VALUE A BUYER'S GAME ACTUALLY CONSUMES. Multiply your sprites by `tint`, drive your
/// shadow direction from `lx`/`ly`, gate your torches on `night`. Because it is derived from the
/// same numbers the sky is drawn from, a scene tinted with it can never disagree with the sky
/// behind it - which is the failure mode of every system that keeps two sets of parameters.
/// ⛔ REFUSES WITH A NEUTRAL NIGHT STATE, NOT WITH undefined. Every other refusal in this package
/// hands back undefined, and doing that here would be wrong: the Readme tells the buyer to read
/// seven fields off this return value and tint their sprites with them, so `undefined` merely
/// moves the crash into their draw event, further from the cause. A dim, sunless, un-flashing
/// state is the honest answer to "I do not know what this sky is", and it keeps the documented
/// promise that ambient never reaches zero.
function wlk_sky_light(_sky) {
    if (!is_struct(_sky)) {
        return { alt: -30, az: 0, direct: 0, ambient: 0.12, warmth: 0, flash: 0, lx: 0, ly: -1 };
    }
    var _alt = wlk_sky_sun_alt(_sky);
    var _cond = wlk_sky_conditions(_sky);
    var _L = wlk_air_light(_alt, wlk_sky_sun_az(_sky), _cond);

    // A tint colour ready to multiply a sprite by.
    var _lum = clamp(_L.ambient + _L.direct * 0.55, 0.08, 1.0);
    var _hue = wlk_air_mix_h(248, 58, _L.warmth * 0.75 + _L.direct * 0.25);
    var _chr = 0.012 + 0.055 * _L.warmth * _L.direct + 0.020 * (1.0 - _L.day);
    _L.tint = wlk_oklch(_lum, _chr, _hue);

    // A lightning strike overrides everything for a fraction of a second.
    var _age = _sky.t - _sky.strike;
    _L.flash = (_age >= 0 && _age < 0.22) ? (1.0 - _age / 0.22) : 0.0;
    if (_L.flash > 0) _L.tint = wlk_oklch(clamp(_lum + 0.45 * _L.flash, 0, 0.99), _chr * 0.4, 250);

    return _L;
}

/// ============================================================================================
/// THE PALETTE FOR THIS MOMENT
/// ============================================================================================

function wlk_sky_palette(_sky, _light) {
    var _cond = wlk_sky_conditions(_sky);
    var _raw = wlk_air_stops(_light.alt);
    var _stops = wlk_air_weather(_raw, _cond);
    var _wxnow = wlk_sky_weather_now(_sky);
    var _pal = wlk_air_palette(_stops, _light, wlk_cloud_thick(wlk_weather_cloud(_wxnow)));
    wlk_sun_palette(_pal, _stops, _light);
    wlk_weather_bow_palette(_pal, _light);
    _pal.stops = _stops;
    return _pal;
}

/// ============================================================================================
/// THE DRAW
/// ============================================================================================

/// Draw the whole sky into a rectangle. This is the entire renderer as far as a buyer is
/// concerned, and it is one call.
/// ⛔ REFUSES A NON-SKY BY DRAWING NOTHING (guard pass 2026-09-08). This is a DRAW call, so there is
/// no return value a caller could check; drawing nothing is the honest refusal. GML resolves a field
/// access on a non-struct against the CALLING INSTANCE's scope, so an unchecked dereference here
/// surfaces to the buyer as "Variable obj_<theirs>.<our field> not set before reading it".
function wlk_sky_draw(_sky, _x, _y, _w, _h) {
    if (!is_struct(_sky)) return;
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_w) || !is_numeric(_h)) return;
    var _light = wlk_sky_light(_sky);
    var _pal = wlk_sky_palette(_sky, _light);
    var _stops = _pal.stops;
    var _cond = wlk_sky_conditions(_sky);
    var _wxnow = wlk_sky_weather_now(_sky);
    var _amtnow = (_sky.front < 0.5)
                ? lerp(_sky.wx_amt, 0, _sky.front * 2.0)
                : lerp(0, _sky.wx_amt_next, (_sky.front - 0.5) * 2.0);

    // ⭐ POINT THE LAMP AT THE SUN. This one line is why the relief engine was patched for this
    // product, and it is what makes a sunset cloud look lit from underneath instead of looking
    // like a sticker with a gradient on it. Everything drawn between here and wlk_lamp_reset is
    // shaded from the real position of the real sun.
    wlk_lamp_set(_light.lx, _light.ly);

    var _horizonY = _y + _h * WLK_SKY_HORIZON;

    // --- 1. THE SKY ITSELF ------------------------------------------------------------------
    // Four hardware-interpolated bands from five stops. The weights compress the lower stops into
    // the bottom of the frame, which is where a real sky puts them.
    var _cols = array_create(WLK_STOPS);
    for (var _s = 0; _s < WLK_STOPS; _s++) {
        _cols[_s] = variable_struct_get(_pal, "s" + string(_s));
    }
    wlk_render_ramp(_x, _y, _w, _horizonY - _y + 2, _cols, [0.36, 0.27, 0.21, 0.16]);
    // Below the skyline the haze stop continues, so land drawn over it sits on the right colour
    // even where a ridge dips below the horizon line.
    wlk_render_vgrad(_x, _horizonY, _w, _h - (_horizonY - _y), _cols[WLK_HAZE], _cols[WLK_HAZE]);

    // The mappings. x always spans the frame width; see wlk_star_build's header for why the sky
    // furniture and the land do not share a vertical scale.
    var _landS = _w;
    var _landCx = _x + _w * 0.5;
    var _landCy = _horizonY - wlk_horizon_baseline(WLK_RANK_FAR) * _landS;

    var _skyS = max(_w, _h);
    var _skyCx = _x + _w * 0.5;
    var _skyCy = _y + _h * 0.5;
    var _skyHorizonY = (_horizonY - _skyCy) / _skyS;   // the skyline in sky-furniture units

    // --- 2. STARS ---------------------------------------------------------------------------
    if (_light.night > 0.05) {
        var _stars = wlk_star_build(_light.night * (1.0 - _cond.overcast * 0.85),
                                    _sky.seed, _skyHorizonY);
        wlk_render_parts(_stars, _pal, _skyCx, _skyCy, _skyS, 0, 1, undefined);
    }

    // --- 3. THE MOON ------------------------------------------------------------------------
    var _malt = wlk_sky_moon_alt(_sky);
    if (_malt > -2 && _cond.overcast < 0.88) {
        var _mr = _w * 0.030;
        var _mx = _x + _w * 0.5 + wlk_sky_moon_az(_sky) * _w * 0.42;
        var _my = _horizonY - sin(degtorad(max(_malt, 0))) * (_horizonY - _y) * 0.92;
        var _moon = wlk_moon_build(wlk_sky_moon_phase(_sky), 0.5);
        wlk_render_parts(_moon, _pal, _mx, _my, _mr * 2.0, 0, 1, undefined);
    }

    // --- 4. THE SUN -------------------------------------------------------------------------
    if (_light.alt > -3.5) {
        var _sr = _w * 0.022;
        var _sx = _x + _w * 0.5 + _light.az * _w * 0.42;
        var _sy = _horizonY - sin(degtorad(max(_light.alt, 0))) * (_horizonY - _y) * 0.92;
        // Behind thick cloud the disc is gone but the glow is not - that pale patch is exactly how
        // you locate the sun on an overcast day, and drawing nothing loses it.
        var _sun = wlk_sun_build(0.5 * (1.0 - _cond.overcast * 0.75), _light);
        wlk_render_parts(_sun, _pal, _sx, _sy, _sr * 2.0, 0, 1, undefined);
    }

    // --- 5. THE LIGHTNING FLASH -------------------------------------------------------------
    // ⛔ THE FLASH GOES *UNDER* THE CLOUDS. This wing's constitution records the general law from
    // another product: "a flash goes UNDER the thing it illuminates - over it, it obscures the
    // subject for exactly the moment it exists to highlight". It is also what actually happens:
    // the discharge is inside the cloud, so the cloud is lit from within and silhouetted against
    // the glare. Drawn on top it looks like someone turned a torch on the camera.
    if (_light.flash > 0) {
        wlk_render_scrim(_x, _y, _w, _h * 0.86, _pal.s4, _light.flash * 0.55);
    }

    // --- 6. THE CLOUD DECKS -----------------------------------------------------------------
    // High cloud first, low cloud last, so a low storm base correctly covers the cirrus above it.
    wlk_sky_draw_deck(_sky, _pal, _light, _cond, _x, _y, _w, _h, _horizonY);

    // --- 7. THE RAINBOW ---------------------------------------------------------------------
    // Opposite the sun, and only while the arc would actually stand above the horizon.
    if (_wxnow == WLK_WX_RAINBOW && _light.alt > 2 && _light.alt < 42 && _amtnow > 0.02) {
        var _bow = wlk_weather_build(WLK_WX_RAINBOW, _sky.t, _amtnow, _sky.wind);
        // ⛔ THE BOW MUST STAY INSIDE THE RECT IT WAS GIVEN, AND UNTIL 2026-08-28 IT DID NOT. This
        // drew at full _w scale (arc radius 0.52 * _w) from an antisolar point pushed up to 0.42 * _w
        // off centre, so at a low sun the arc spanned -0.39 * _w to +0.65 * _w and painted well
        // OUTSIDE the rect. On the weather sheet it bled across a cell boundary into the panel
        // next door; in a buyer's game it would paint over whatever sits beside the sky, which is
        // worse, because wlk_sky_draw's whole contract is "the sky, inside this rectangle".
        //
        // ⚠️ THIS ONLY BECAME VISIBLE ONCE THE RAINBOW STARTED DRAWING AT ALL. It had been mute
        // since it was written (degrees into a radians function, see wlk_weather), so the overflow
        // shipped underneath a defect that hid it - fixing one bug is what exposed the other.
        //
        // The offset and the scale are now chosen so the arc fits for EVERY azimuth: radius
        // 0.52 * 0.68 = 0.354 of the width, centre no further than 0.13 from the middle, worst case
        // 0.016..0.724 of the rect. The height bound keeps the crown under the top edge on a wide
        // short rect, where the width alone would not.
        var _bs = min(_w * 0.68, (_horizonY - _y) * 1.80);
        var _bx = _x + _w * 0.5 - _light.az * _w * 0.13;    // the ANTIsolar point
        wlk_render_parts(_bow, _pal, _bx, _horizonY - 0.62 * _bs, _bs, 0, 1, undefined);
    }

    // --- 8. THE LAND ------------------------------------------------------------------------
    // Far, then mid, then near. The aerial perspective is entirely in the three roles.
    wlk_render_parts(wlk_horizon_build(_sky.horizon_far, WLK_RANK_FAR, _sky.seed + 0.11),
                     _pal, _landCx, _landCy, _landS, 0, 1, undefined);
    wlk_render_parts(wlk_horizon_build(_sky.horizon_mid, WLK_RANK_MID, _sky.seed + 0.37),
                     _pal, _landCx, _landCy, _landS, 0, 1, undefined);
    wlk_render_parts(wlk_horizon_build(_sky.horizon_near, WLK_RANK_NEAR, _sky.seed + 0.73),
                     _pal, _landCx, _landCy, _landS, 0, 1, undefined);

    // --- 9. THE RIM LIGHT -------------------------------------------------------------------
    var _rim = wlk_horizon_rim(_sky.horizon_near, _light, _sky.seed + 0.73);
    if (array_length(_rim) > 0) {
        wlk_render_parts(_rim, _pal, _landCx, _landCy, _landS, 0, 1, undefined);
    }

    // --- 10. PRECIPITATION ------------------------------------------------------------------
    // In front of everything, because it is between the player and the world.
    if (_wxnow != WLK_WX_RAINBOW && _amtnow > 0.005) {
        var _wxp = wlk_weather_build(_wxnow, _sky.t, _amtnow, _sky.wind);
        if (array_length(_wxp) > 0) {
            wlk_render_parts(_wxp, _pal, _skyCx, _skyCy, _skyS, 0, 1, undefined);
        }
    }

    // --- 11. THE BOLT -----------------------------------------------------------------------
    // Over the clouds, because a strike descends from the cloud BASE toward the ground and is seen
    // against the sky below it. Only the flash goes underneath.
    var _age = _sky.t - _sky.strike;
    if (_age >= 0 && _age < 0.22) {
        var _bolt = wlk_weather_build(WLK_WX_LIGHTNING, _sky.strike_i, 1.0, _sky.wind);
        wlk_render_parts(_bolt, _pal, _skyCx, _skyCy, _skyS, 0, 1, undefined);
    }

    // ⛔ PUT THE LAMP BACK. Every panel, gauge and readout the game draws after this call expects
    // the studio's fixed diagonal; leaving the lamp pointed at the sun lights the interface from
    // below at dusk, which looks like a rendering bug and is very hard to trace back to here.
    wlk_lamp_reset();
    return _pal;
}

/// Render the sky ONCE into a sprite and hand it back, for scenes that do not need it redrawn every
/// frame. The caller owns the sprite and must sprite_delete it.
///
/// ⛔⛔ THIS FUNCTION DID NOT EXIST AND THE README SAID IT WAS PROVIDED. Measured 2026-09-08: the
/// Performance section read "wlk_sky_bake is provided if you would rather render to a surface once
/// and reuse it", and `grep` over the whole Product_Release found the name in exactly one place -
/// that sentence. A buyer following the store page called a function that was never written.
/// ⚠️ AND `gmtest_docsmatch` PASSED THE PAGE at "all 14 documented claims resolve", because the name
/// appears in PROSE in backticks with no parentheses and the scoper only collects call-shaped
/// mentions. Coverage was a property of the document's typography, not of the API.
///
/// ⚠️ A BAKED SKY IS A STILL. The sky ANIMATES - clouds drift, fronts roll, lightning strikes - so
/// this is for a fixed moment (a menu backdrop, a loading screen, a paused scene), not a substitute
/// for wlk_sky_draw in a running game. Re-bake after wlk_sky_set_time or a weather change.
///
/// ⚠️ NOT FROM A DRAW EVENT: surface_set_target inside a draw event nests render targets and can
/// silently produce an empty sprite rather than an error.
function wlk_sky_bake(_sky, _w, _h) {
    if (!is_struct(_sky)) return -1;
    if (!is_numeric(_w) || !is_numeric(_h) || _w <= 0 || _h <= 0) return -1;
    var _surf = surface_create(_w, _h);
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 0);
    wlk_sky_draw(_sky, 0, 0, _w, _h);
    surface_reset_target();
    var _spr = sprite_create_from_surface(_surf, 0, 0, _w, _h, false, false, 0, 0);
    surface_free(_surf);
    return _spr;
}

/// The cloud deck for the current weather.
///
/// ⚠️ CLOUD COUNT IS DRIVEN BY OVERCAST, WHICH IS WHY A FRONT LOOKS LIKE A FRONT. As the front
/// advances, overcast rises, and the deck fills in cloud by cloud rather than fading a sheet up
/// from zero alpha. That difference is the whole reason this reads as weather arriving.
function wlk_sky_draw_deck(_sky, _pal, _light, _cond, _x, _y, _w, _h, _horizonY) {
    var _genus = wlk_weather_cloud(wlk_sky_weather_now(_sky));
    var _level = wlk_cloud_level(_genus);
    // ⚠️ THE FLOOR IS THREE, NOT TWO. A "clear" sky with two clouds in a 1600px frame reads as an
    // empty sky that happens to have two clouds in it. Three is the fewest that reads as a deck.
    var _n = 3 + round(_cond.overcast * 7);

    // A second, higher deck of cirrus on fair days. Two decks at different heights and speeds is
    // the cheapest possible depth cue in a sky and costs one loop.
    if (_cond.overcast < 0.45) {
        var _hi = wlk_cloud_build(9, _sky.seed * 0.7);
        for (var _k = 0; _k < 3; _k++) {
            var _drift = wlk_frac01(_sky.t * 0.006 + _k * 0.37 + _sky.seed * 0.11);
            var _cx = _x - _w * 0.3 + _drift * _w * 1.6;
            var _cy = _y + _h * 0.10 + _k * _h * 0.055;
            wlk_render_parts(_hi, _pal, _cx, _cy, _w * (0.34 + 0.10 * _k), 0, 1, undefined);
        }
    }

    var _parts = wlk_cloud_build(_genus, _sky.seed);
    for (var _k = 0; _k < _n; _k++) {
        // Deterministic placement, drifting with the wind. Each cloud has its own speed so the
        // deck does not translate as one rigid sheet - which is the tell that it is a texture.
        var _sp = 0.010 + 0.014 * wlk_wx_hash(_k + _sky.seed * 5, 70);
        var _drift = wlk_frac01(_sky.t * _sp * _sky.wind + wlk_wx_hash(_k + _sky.seed * 5, 71));
        var _cx = _x - _w * 0.18 + _drift * _w * 1.36;

        var _lv = _level + (wlk_wx_hash(_k + _sky.seed * 5, 72) - 0.5) * 0.14;

        // Higher clouds are drawn smaller: it is the only perspective cue available in a flat
        // backdrop and without it the deck reads as a row of equal blobs.
        var _sc = _w * (0.30 - 0.11 * clamp(_lv, 0, 1))
                * (0.72 + 0.40 * wlk_wx_hash(_k + _sky.seed * 5, 73));

        // ⛔ THE DECK IS ANCHORED BY THE CLOUD'S BASE, NOT BY THE CENTRE OF ITS UNIT BOX, AND
        // GETTING THIS WRONG HID THE ENTIRE CLOUD DECK BEHIND THE MOUNTAINS.
        //
        // A convective form occupies unit y from about -0.2 up to WLK_CLOUD_BASE at 0.30, so its
        // geometry sits well BELOW the box centre. Placing the box centre at the deck height
        // therefore drops the whole cloud by 0.30 of its own scale - which at a 650px cloud is
        // nearly 200px, far enough to put a fair-weather cumulus under the skyline. The hero sheet
        // rendered with no cumulus in it at all and every assertion still passed, because the
        // forms were all correct and only their PLACEMENT was wrong.
        //
        // Anchoring on the base is also the physically meaningful choice: cloud base altitude is
        // the quantity a meteorologist quotes, and it is what makes a deck sit on one level.
        var _deckY = _horizonY - clamp(_lv, 0.05, 0.95) * (_horizonY - _y) * 0.94;
        var _cy = _deckY - WLK_CLOUD_BASE * _sc;

        wlk_render_parts(_parts, _pal, _cx, _cy, _sc, 0, 1, undefined);
    }
}
