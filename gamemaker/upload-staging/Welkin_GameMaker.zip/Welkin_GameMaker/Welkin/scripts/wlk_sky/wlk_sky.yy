{
  "$GMScript": "v1",
  "%Name": "wlk_sky",
  "isCompatibility": false,
  "isDnD": false,
  "name": "wlk_sky",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}