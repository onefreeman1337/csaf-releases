/// WELKIN - wlk_air. The atmosphere.
///
/// This file answers one question: given where the sun is, what colour is the sky?
///
/// ⛔ IT IS THE REASON THIS PRODUCT IS NOT A HUE SLIDER, so it is worth being precise about what
/// it does differently. The ordinary way to build a day/night cycle is to pick one sky colour and
/// tint it around the clock - and the tell is that every hour looks like the same picture behind
/// coloured glass. A real sky does not do that. At noon it is a blue that is DARKEST overhead and
/// palest at the horizon. Forty minutes after sunset it is doing two unrelated things at once: a
/// deep blue-violet overhead and a band of orange along the skyline, with a magenta seam between
/// them that belongs to neither. No single hue with a lightness curve can produce that, because
/// the hue itself has to travel a different distance at the top of the frame than at the bottom.
///
/// So a Welkin sky is a RAMP OF FIVE STOPS, and each stop carries its own lightness, its own
/// chroma AND its own hue. The five travel independently as the sun moves. That is the whole
/// idea, and everything else in this file is bookkeeping around it.
///
/// -- WHY FIVE ---------------------------------------------------------------------------------
/// Three cannot hold a twilight: the warm band at the horizon and the cool one overhead need a
/// stop between them that is neither, or the seam reads as a hard join. Seven were authored first
/// and two were dropped, because at 720px the two extra stops fell inside the same rendered band
/// as their neighbours and only cost authoring time. Five is what survived being looked at.
///
/// -- THE KEYFRAMES ARE ASTRONOMY, NOT TASTE ---------------------------------------------------
/// The seven altitudes below are the real boundaries a sky changes at, and they are named as such:
/// +60 high sun, +25 mid, +8 golden hour, 0 the horizon crossing, -6 the end of civil twilight,
/// -14 the end of nautical twilight, -30 full night. Those numbers are the standard definitions,
/// and using them rather than "morning / evening / night" is why the transitions land where a
/// player's eye expects them. Interpolation between keyframes is in Oklch, so a hue that travels
/// from blue to orange goes the short way round the circle and does not swing through green.
///
/// ⚠️ HUE IS ANGULAR AND MUST BE INTERPOLATED AS AN ANGLE. Mixing h=350 and h=20 numerically gives
/// 185 - the exact opposite colour, cyan, in the middle of a sunset. wlk_air_mix_h below takes the
/// short way round. This was caught by the ramp-monotonicity assertion in wlk_selftest and not by
/// looking, because it only fires in the last twenty minutes of dusk.
/// ============================================================================================

/// Five stops, top of the frame to the skyline.
#macro WLK_STOPS 5

/// Stop indices, so nothing downstream has to remember the order.
#macro WLK_ZENITH  0
#macro WLK_UPPER   1
#macro WLK_MID     2
#macro WLK_BAND    3
#macro WLK_HAZE    4

/// The seven keyframe altitudes, in degrees above the horizon.
#macro WLK_ALT_HIGH     60
#macro WLK_ALT_MID      25
#macro WLK_ALT_GOLDEN    8
#macro WLK_ALT_SET       0
#macro WLK_ALT_CIVIL    -6
#macro WLK_ALT_NAUTICAL -14
#macro WLK_ALT_NIGHT    -30

/// ============================================================================================
/// THE KEYFRAME TABLE
///
/// Each row is five [L, C, hue] triples in Oklch, zenith first. Read down a column to see one
/// stop's journey through the day; read across a row to see one moment's sky.
///
/// ⚠️ THE CHROMA FIGURES LOOK LOW AND ARE CORRECT. Oklch chroma is not HSV saturation: 0.13 is a
/// thoroughly blue sky, and 0.20 is past what sRGB can show at that lightness, where
/// wlk_chroma_ceiling would clamp it anyway. Authoring above the ceiling produces stops that are
/// numerically different and visually identical - which is exactly the failure this product is
/// selling against, so the separation assertion in wlk_selftest measures in Oklab AFTER the
/// ceiling has been applied.
/// ============================================================================================
function wlk_air_keyframe(_i) {
    switch (_i) {
        // HIGH SUN. The defining feature is that it is DARKEST OVERHEAD - the one thing a naive
        // gradient always gets backwards, because "bright day" suggests a bright top.
        case 0: return [[0.620, 0.130, 245], [0.700, 0.110, 240], [0.780, 0.085, 235],
                        [0.860, 0.055, 228], [0.900, 0.035, 220]];

        // MID. Barely warmer, and it must stay barely: the whole middle of the day is one picture
        // and dramatising it steals the contrast that golden hour needs.
        case 1: return [[0.580, 0.135, 248], [0.660, 0.115, 242], [0.750, 0.090, 233],
                        [0.840, 0.060, 220], [0.890, 0.050, 205]];

        // GOLDEN HOUR. The first frame where the bottom of the sky leaves the blue family
        // altogether - band and haze cross into yellow while the zenith deepens.
        case 2: return [[0.460, 0.120, 262], [0.550, 0.110, 252], [0.660, 0.090, 235],
                        [0.780, 0.100, 75], [0.840, 0.130, 58]];

        // THE HORIZON CROSSING. Five stops in four different colour families - violet, violet,
        // pink, orange, orange. This row is the product's headline picture.
        case 3: return [[0.380, 0.110, 272], [0.450, 0.110, 285], [0.560, 0.120, 330],
                        [0.680, 0.160, 40], [0.740, 0.170, 55]];

        // CIVIL TWILIGHT. The sun is gone; the sky is not. Magenta through the middle is the
        // anti-twilight arch and it is what makes this read as "just after sunset" rather than
        // "dim day".
        case 4: return [[0.260, 0.090, 280], [0.310, 0.100, 292], [0.400, 0.110, 320],
                        [0.500, 0.130, 20], [0.560, 0.120, 40]];

        // NAUTICAL TWILIGHT. Colour is draining but has not gone. The horizon keeps a rose stain
        // long after the eye stops calling the scene "sunset".
        case 5: return [[0.160, 0.070, 272], [0.190, 0.075, 278], [0.240, 0.080, 290],
                        [0.300, 0.090, 310], [0.350, 0.090, 330]];

        // NIGHT. ⛔ NOT BLACK, AND THIS IS THE MOST COMMON MISTAKE IN THE CATEGORY. A moonless
        // country sky is a very dark desaturated BLUE, and the horizon is LIGHTER than the zenith,
        // not darker - airglow and scattered light pool along the skyline. Draw night as black and
        // the stars have nothing to sit in.
        default: return [[0.090, 0.045, 265], [0.100, 0.045, 265], [0.120, 0.045, 262],
                         [0.140, 0.050, 258], [0.170, 0.050, 252]];
    }
}

/// The altitude each keyframe sits at, in the same order.
function wlk_air_keyframe_alt(_i) {
    switch (_i) {
        case 0: return WLK_ALT_HIGH;
        case 1: return WLK_ALT_MID;
        case 2: return WLK_ALT_GOLDEN;
        case 3: return WLK_ALT_SET;
        case 4: return WLK_ALT_CIVIL;
        case 5: return WLK_ALT_NAUTICAL;
        default: return WLK_ALT_NIGHT;
    }
}

/// ============================================================================================
/// INTERPOLATION
/// ============================================================================================

/// Mix two hue ANGLES the short way round the circle.
///
/// ⛔ THE REASON THIS FUNCTION EXISTS: a plain lerp between 350 and 20 returns 185. That is cyan,
/// and it would appear for about twenty minutes of every simulated evening, between the pink stop
/// and the red one. Nothing else in the package would have looked wrong.
function wlk_air_mix_h(_h0, _h1, _t) {
    var _d = _h1 - _h0;
    while (_d > 180) _d -= 360;
    while (_d < -180) _d += 360;
    var _h = _h0 + _d * _t;
    while (_h < 0) _h += 360;
    while (_h >= 360) _h -= 360;
    return _h;
}

/// The five raw stops for a sun altitude, before weather touches them.
///
/// Returns an array of five [L, C, h]. Altitudes above the first keyframe and below the last
/// clamp rather than extrapolate - extrapolating lightness past night gives negative L, which
/// wlk_oklch would silently render as black and which would look like a bug in the clock.
function wlk_air_stops(_alt) {
    var _k0 = 0, _k1 = 0, _t = 0;

    if (_alt >= WLK_ALT_HIGH) { _k0 = 0; _k1 = 0; _t = 0; }
    else if (_alt <= WLK_ALT_NIGHT) { _k0 = 6; _k1 = 6; _t = 0; }
    else {
        for (var _i = 0; _i < 6; _i++) {
            var _a0 = wlk_air_keyframe_alt(_i), _a1 = wlk_air_keyframe_alt(_i + 1);
            if (_alt <= _a0 && _alt >= _a1) {
                _k0 = _i; _k1 = _i + 1;
                var _span = _a0 - _a1;
                _t = (_span == 0) ? 0 : (_a0 - _alt) / _span;
                break;
            }
        }
    }

    var _f0 = wlk_air_keyframe(_k0), _f1 = wlk_air_keyframe(_k1);
    var _out = array_create(WLK_STOPS);
    for (var _s = 0; _s < WLK_STOPS; _s++) {
        _out[_s] = [
            lerp(_f0[_s][0], _f1[_s][0], _t),
            lerp(_f0[_s][1], _f1[_s][1], _t),
            wlk_air_mix_h(_f0[_s][2], _f1[_s][2], _t),
        ];
    }
    return _out;
}

/// ============================================================================================
/// WEATHER'S EFFECT ON THE RAMP
///
/// ⛔ OVERCAST IS NOT A GREY TINT, AND TREATING IT AS ONE IS WHY MOST GENERATED SKIES LOOK WRONG
/// IN RAIN. Cloud cover does three separable things and they have to be applied separately:
///
///   1. It DRAINS CHROMA. Under full cover the sky has almost no hue left at all.
///   2. It COMPRESSES THE RAMP. A clear sky runs from L 0.62 overhead to L 0.90 at the skyline -
///      a spread of 0.28. Under thick cloud the whole frame is within about 0.06 of itself, and
///      that flatness IS what "overcast" looks like. Tinting alone keeps the spread and the
///      result reads as a coloured clear sky.
///   3. It DARKENS, but far less than people assume - an overcast noon is still bright. The
///      darkening is carried mostly by _storm, not by _overcast.
///
/// ⚠️ THE COMPRESSION PULLS TOWARDS THE MID STOP, NOT TOWARDS THE MEAN. Pulling to the mean
/// brightens the zenith and darkens the horizon by the same amount and the sky loses its
/// top-to-bottom direction entirely, which reads as fog rather than cloud.
/// ============================================================================================

/// Apply a weather struct to a raw ramp. _w is {overcast, storm, haze} each 0..1.
function wlk_air_weather(_stops, _w) {
    var _oc = clamp(_w.overcast, 0, 1);
    var _st = clamp(_w.storm, 0, 1);
    var _hz = clamp(_w.haze, 0, 1);

    var _midL = _stops[WLK_MID][0];
    var _out = array_create(WLK_STOPS);

    for (var _s = 0; _s < WLK_STOPS; _s++) {
        var _L = _stops[_s][0], _C = _stops[_s][1], _h = _stops[_s][2];

        // 2. compress towards the mid stop
        _L = lerp(_L, _midL, _oc * 0.72);

        // 1. drain chroma.
        //
        // ⚠️ 0.58 AND NOT 0.80, AND THE CORRECTION CAME FROM A MEASUREMENT THAT EMBARRASSED THE
        // FIRST VERSION. At a 0.80 drain the self-test counted only 27 visibly distinct skies
        // across 216 sampled states, and the reason was visible in the data rather than in the
        // picture: EVERY heavily-overcast state collapsed onto the same grey regardless of the
        // hour, so an overcast sunset and an overcast noon were the same sky.
        //
        // That is wrong as physics, not merely as variety. Cloud scatters light; it does not
        // filter its colour out. The light arriving under a thick deck at sunset has still
        // travelled a long path through the atmosphere and is still reddened - an overcast evening
        // is visibly warmer than an overcast midday, which is why "grey day" is not one colour.
        // Draining 80% of the chroma threw that away and made the sky a function of the weather
        // alone instead of the weather AND the hour.
        //
        // ⛔ THE FLOOR IN THE SELF-TEST WAS NOT TOUCHED. Moving a threshold until a claim passes is
        // the failure that check exists to catch. The model was wrong; the model was changed.
        _C = _C * (1.0 - _oc * 0.58);

        // 3. darken - storm carries this, overcast barely does
        _L = _L * (1.0 - _st * 0.42 - _oc * 0.06);

        // A storm sky is not neutral: it keeps a cold cast, so what chroma survives is pulled
        // toward blue. Pulled, not set - a storm at sunset is still a warm storm, and overriding
        // the hue outright would throw away the most dramatic sky the product can draw.
        _h = wlk_air_mix_h(_h, 250, _st * 0.45);
        _C = _C * (1.0 - _st * 0.30);

        // HAZE is the opposite operation to overcast and must not be folded into it: it lifts the
        // BOTTOM of the frame only, leaving the zenith alone. That vertical asymmetry is what
        // makes a hazy day read as distance rather than as dimness.
        var _low = _s / (WLK_STOPS - 1);
        _L = _L + _hz * 0.10 * _low;
        _C = _C * (1.0 - _hz * 0.35 * _low);

        _out[_s] = [clamp(_L, 0.02, 0.98), max(_C, 0), _h];
    }
    return _out;
}

/// ============================================================================================
/// THE LIGHT STATE
///
/// One struct describing what the sun is doing to everything that is not the sky. This is the
/// value a buyer reads to tint their own scene, and it is deliberately the LAST thing computed
/// rather than the first, so it can never disagree with the sky actually drawn.
/// ============================================================================================

/// _az is the sun's azimuth across the frame, -1 (left) .. +1 (right).
function wlk_air_light(_alt, _az, _w) {
    var _oc = clamp(_w.overcast, 0, 1);
    var _st = clamp(_w.storm, 0, 1);

    // Direct sunlight falls off with altitude and is gone below the horizon. The curve is steep
    // near 0 because that is what makes the last few minutes before sunset feel like they are
    // running out.
    var _direct = clamp(_alt / 22.0, 0, 1);
    _direct = _direct * _direct * (3.0 - 2.0 * _direct);
    _direct = _direct * (1.0 - _oc * 0.85) * (1.0 - _st * 0.55);

    // Ambient never reaches zero: a moonless night still has airglow, and a scene lit to pure
    // black is a scene a player cannot read.
    var _ambient = 0.10 + 0.55 * clamp((_alt + 14) / 40.0, 0, 1);
    _ambient = _ambient * (1.0 - _st * 0.35);
    _ambient = _ambient * (1.0 + _oc * 0.18);   // cloud SPREADS light even as it dims the sun

    // Warmth: how orange the direct light is. Peaks at the horizon crossing, not at noon.
    var _warm = clamp(1.0 - abs(_alt) / 18.0, 0, 1) * (1.0 - _oc * 0.6);

    // WHERE THE LAMP IS. The sun's screen position drives wlk_lamp_set, which is the whole reason
    // the relief engine was patched for this product: a cloud lit from the upper left at sunset is
    // a sticker. y is NEGATIVE for "above", matching the studio's y-down screen convention.
    var _lx = _az;
    var _ly = -sin(degtorad(clamp(_alt, -20, 90)));
    var _lm = sqrt(_lx * _lx + _ly * _ly);
    if (_lm < 0.0001) { _lx = 0; _ly = -1; _lm = 1; }

    return {
        alt: _alt,
        az: _az,
        direct: _direct,
        ambient: clamp(_ambient, 0.06, 1.0),
        warmth: _warm,
        lx: _lx / _lm,
        ly: _ly / _lm,
        day: clamp((_alt + 6) / 12.0, 0, 1),          // 0 fully night, 1 fully day
        // ⛔ STARS DO NOT COME OUT AT SUNSET, AND THE FIRST VERSION OF THIS LINE PUT THEM THERE.
        // It read 1 - clamp((alt + 12) / 18), which is 0.44 at an altitude of -2 degrees - so a
        // sky still orange along the horizon was carrying half a field of stars. Found by opening
        // the hero sheet; no assertion could have known.
        //
        // The real threshold is CIVIL TWILIGHT: the first stars appear when the sun is about 6
        // degrees down and the sky is not fully dark until around 18. That is exactly this curve,
        // and it is zero - not nearly zero - for every altitude above -6.
        night: clamp((-6.0 - _alt) / 12.0, 0, 1),
    };
}

/// ============================================================================================
/// THE CLOUD MATERIAL
///
/// ⭐ THIS IS THE FUNCTION THAT MAKES CLOUDS BELONG TO THEIR HOUR, and it is five lines of idea
/// followed by twenty of arithmetic. A cloud is not white. A cloud is lit on the side facing the
/// sun by SUNLIGHT, which is warm and gets warmer as the sun drops, and lit on every other side by
/// the SKY, which is blue. So a cloud's five relief stops are not a grey ramp - they run from
/// sky-coloured shadow to sun-coloured light, and both ends are read from the sky that was just
/// computed. Nothing is authored per hour; a sunset cloud is orange on top and violet underneath
/// because the sky above it is orange and the sky beside it is violet.
///
/// ⚠️ THE SHADOW STOP IS NOT "THE SKY COLOUR". It is the sky colour DARKENED. A cloud's underside
/// is in shadow from itself, so taking the ambient colour at full lightness makes the cloud vanish
/// into the sky - which is exactly what happened on the first render and read as a missing cloud
/// rather than as a wrong colour.
/// ============================================================================================

/// _thick 0..1: a wisp of cirrus is nearly transparent and barely shades at all; a storm head is
/// deep enough that its underside goes almost to the darkest value the sky can supply.
function wlk_air_cloud_ramp(_stops, _light, _thick) {
    var _th = clamp(_thick, 0, 1);

    // The ambient end: the sky beside and below the cloud, darkened by the cloud's own depth.
    var _aL = _stops[WLK_MID][0], _aC = _stops[WLK_MID][1], _aH = _stops[WLK_MID][2];
    // ⚠️ THE DEEP END WAS 0.34 AND IS NOW 0.52. At 0.34 a fair-weather cumulus at dusk rendered as
    // a near-black maroon mass - the shadow was darker than the land below it, which inverts the
    // whole depth read of the frame. Cloud is bright: even its shadow side is lit by half the sky.
    _aL = _aL * lerp(0.88, 0.52, _th);
    // ⚠️ THE SHADOW LOSES CHROMA AS IT DEEPENS - IT DOES NOT GAIN IT. The first version ran this
    // multiplier UP to 1.05 with thickness, on the reasoning that a deep cloud sits in more sky
    // light. What that produced at sunset was a cumulus whose shadow side was a saturated PINK,
    // and it read as a plastic toy rather than as vapour. Shadow is where colour goes to die: an
    // unlit surface is dimmer AND greyer, in cloud exactly as in everything else.
    _aC = _aC * lerp(0.62, 0.40, _th);

    // The lit end: sunlight. Warm, and warmer near the horizon. At night there is no sunlight, so
    // the lit end falls back to the brightest thing available - the sky itself - and the cloud
    // becomes a silhouette, which is correct.
    var _sL = lerp(_stops[WLK_HAZE][0] * 0.92, 0.97, _light.direct);
    var _sC = lerp(_stops[WLK_HAZE][1] * 0.85, 0.020 + 0.135 * _light.warmth, _light.direct);
    var _sH = wlk_air_mix_h(_stops[WLK_HAZE][2], 62, _light.warmth * _light.direct);

    // Under heavy cloud the lit face never gets bright - that is what makes a storm read as heavy
    // rather than as a dark-blue fair-weather sky.
    _sL = _sL * lerp(1.0, 0.66, _th * (1.0 - _light.direct * 0.5));

    var _out = {};
    for (var _i = 0; _i < WLK_RAMP_N; _i++) {
        var _t = _i / (WLK_RAMP_N - 1);
        // Eased rather than linear: real cloud has a lot of middle tone and a narrow bright rim,
        // and a linear ramp spends too much of its range on values that never appear.
        var _e = _t * _t * (3.0 - 2.0 * _t);
        var _L = lerp(_aL, _sL, _e);
        var _C = lerp(_aC, _sC, _e);
        var _h = wlk_air_mix_h(_aH, _sH, _e);
        variable_struct_set(_out, "m" + string(_i), wlk_oklch(_L, _C, _h));
    }
    return _out;
}

/// ============================================================================================
/// THE PALETTE
///
/// Everything the renderer needs for one moment, as one struct. Built once per frame by
/// wlk_sky_palette and handed to every draw call, so nothing downstream can compute a colour a
/// different way and drift out of agreement with the sky.
/// ============================================================================================
function wlk_air_palette(_stops, _light, _thick) {
    var _p = wlk_air_cloud_ramp(_stops, _light, _thick);

    for (var _s = 0; _s < WLK_STOPS; _s++) {
        variable_struct_set(_p, "s" + string(_s),
            wlk_oklch(_stops[_s][0], _stops[_s][1], _stops[_s][2]));
    }

    // GROUND. The land is not part of the sky and must never be lit like it: it is a dark
    // silhouette that picks up a little of the sky's own hue, which is what stops a black
    // cut-out reading as a hole in the picture.
    var _gL = _stops[WLK_HAZE][0] * 0.30 + 0.02;
    var _gH = _stops[WLK_HAZE][2];
    variable_struct_set(_p, "ground",   wlk_oklch(_gL, _stops[WLK_HAZE][1] * 0.55, _gH));
    variable_struct_set(_p, "ground_far", wlk_oklch(_gL * 1.9 + 0.06, _stops[WLK_HAZE][1] * 0.42, _gH));
    variable_struct_set(_p, "ground_mid", wlk_oklch(_gL * 1.35 + 0.02, _stops[WLK_HAZE][1] * 0.48, _gH));

    // The line role is what wlk_render_colour falls back to for an unknown role. Making it a
    // visible mid-grey rather than black means a role typo shows up as a wrong-coloured mark
    // instead of disappearing into the darkest part of the frame.
    variable_struct_set(_p, "line", wlk_oklch(0.55, 0.02, 250));

    variable_struct_set(_p, "sun",  wlk_oklch(0.97, 0.055 + 0.10 * _light.warmth,
                                              wlk_air_mix_h(88, 52, _light.warmth)));
    variable_struct_set(_p, "moon", wlk_oklch(0.93, 0.018, 250));
    variable_struct_set(_p, "star", wlk_oklch(0.95, 0.020, 250));
    // The halo under a bright star: the star's own colour, brought most of the way back down to
    // the sky it sits in. Never the sun's glow ramp - see wlk_star_build.
    variable_struct_set(_p, "star_halo",
        wlk_oklch(lerp(_stops[WLK_ZENITH][0], 0.95, 0.32), 0.016, 250));

    return _p;
}
