{
  "$GMScript": "v1",
  "%Name": "wlk_relief",
  "isCompatibility": false,
  "isDnD": false,
  "name": "wlk_relief",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}