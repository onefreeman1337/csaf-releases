{
  "$GMScript": "v1",
  "%Name": "wlk_celestial",
  "isCompatibility": false,
  "isDnD": false,
  "name": "wlk_celestial",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}