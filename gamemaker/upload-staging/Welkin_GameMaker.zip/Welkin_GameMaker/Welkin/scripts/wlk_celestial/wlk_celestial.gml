/// WELKIN - wlk_celestial. THE CORPUS, PART IV: the sun, the moon in eight phases, and the stars.
///
/// -- THE MOON PHASE IS THE ONE PIECE OF GEOMETRY IN THIS PACKAGE MOST PRODUCTS GET WRONG --------
///
/// ⛔ A CRESCENT IS NOT A CIRCLE WITH ANOTHER CIRCLE TAKEN OUT OF IT. That construction is
/// everywhere, it is easy, and it is wrong: it produces a crescent whose horns are too fat, whose
/// inner curve bulges the wrong way, and which cannot produce a gibbous moon at all without
/// special-casing.
///
/// What actually happens is that you are looking at a SPHERE half-lit by a distant sun, and the
/// boundary between the lit and unlit halves - the terminator - is a great circle on that sphere.
/// A circle on a sphere, seen in projection, is an ELLIPSE. So the edge of the lit region is half
/// of an ellipse whose height is the moon's radius and whose WIDTH varies with the phase angle,
/// from the full radius at new and full moon down to zero at the quarters.
///
/// That single substitution - a half ellipse where the easy version puts a displaced circle - is
/// the difference between a moon and a logo. It also gets the whole cycle for free: one parameter
/// k = cos(phase) sweeps continuously from full through gibbous, quarter and crescent to new, with
/// no branch anywhere.
///
///     k = -1   terminator lies on the far limb        -> FULL
///     k =  0   terminator is a straight line          -> QUARTER
///     k = +1   terminator lies on the near limb       -> NEW
///
/// and the illuminated fraction is exactly (1 - k) / 2, which is what wlk_moon_lit returns and
/// what wlk_selftest checks the eight authored phases against.
///
/// -- THE STARS --------------------------------------------------------------------------------
/// ⛔ THIS FILE DRAWS AN UNGROUPED SCATTER BY MAGNITUDE AND NOTHING MORE. Named asterisms, drawn
/// constellation lines, mythic figures and a star chart the player fills in are a DIFFERENT
/// PRODUCT - they are the scope of Firmament, and the boundary was ruled before this build began
/// and is recorded in this wing's state. A star scatter is a texture; a constellation is a reading
/// of it. Do not let this file acquire meaning above the horizon.
/// ============================================================================================

/// The eight named phases.
#macro WLK_PHASE_N 8

function wlk_moon_phase_name(_i) {
    switch (_i) {
        case 0: return "New";
        case 1: return "Waxing crescent";
        case 2: return "First quarter";
        case 3: return "Waxing gibbous";
        case 4: return "Full";
        case 5: return "Waning gibbous";
        case 6: return "Last quarter";
        default: return "Waning crescent";
    }
}

/// The terminator parameter for phase _i. Runs +1 (new) -> -1 (full) -> +1 (new).
function wlk_moon_k(_i) {
    switch (_i) {
        case 0: return  1.00;   // new
        case 1: return  0.70;   // waxing crescent
        case 2: return  0.00;   // first quarter
        case 3: return -0.70;   // waxing gibbous
        case 4: return -1.00;   // full
        case 5: return -0.70;   // waning gibbous
        case 6: return  0.00;   // last quarter
        default: return 0.70;   // waning crescent
    }
}

/// Which side is lit. +1 lit on the right (waxing), -1 lit on the left (waning).
/// ⚠️ THE WAXING/WANING PAIRS ARE MIRROR IMAGES, NOT THE SAME PICTURE. A first quarter moon is lit
/// on the right and a last quarter on the left; drawing both the same way is a real error that
/// halves the corpus without appearing to.
function wlk_moon_side(_i) {
    return (_i >= 1 && _i <= 3) ? 1 : ((_i >= 5 && _i <= 7) ? -1 : 1);
}

/// The illuminated fraction of the disc, 0 at new and 1 at full.
function wlk_moon_lit(_i) {
    return (1.0 - wlk_moon_k(_i)) * 0.5;
}

/// ============================================================================================
/// THE MOON
/// ============================================================================================

/// The lit region of the moon as one closed outline, in a unit box of radius _r about the origin.
///
/// The outline is built as two half-curves that share their two endpoints - the top and bottom
/// horns. The near limb runs down one side; the terminator runs back up. Both are sampled from the
/// SAME angle sweep, which is what guarantees the horns close exactly and the shape never
/// self-crosses. wlk_selftest asserts total turning on this outline like every other.
function wlk_moon_outline(_r, _k, _side, _segs) {
    var _n = max(8, _segs);
    var _pts = array_create((_n + 1) * 2);
    var _i = 0;

    // The illuminated limb: a true half circle, from the top horn down to the bottom horn.
    for (var _s = 0; _s <= _n; _s++) {
        var _th = -pi * 0.5 + pi * (_s / _n);
        _pts[_i++] = [_side * _r * cos(_th), _r * sin(_th)];
    }
    // The terminator: the same sweep back, with x scaled by k. This is the half ellipse.
    for (var _s = _n; _s >= 0; _s--) {
        var _th = -pi * 0.5 + pi * (_s / _n);
        _pts[_i++] = [_side * _r * _k * cos(_th), _r * sin(_th)];
    }
    return _pts;
}

/// The moon: the dark disc, then the lit region on top of it.
///
/// ⚠️ THE DARK DISC IS DRAWN EVEN AT NEW MOON AND THAT IS DELIBERATE - earthshine. A new moon is
/// not invisible, it is a very slightly luminous disc, and drawing nothing at all leaves a gap in
/// the sky where the player can see the moon was.
/// ⛔ THE LIT REGION IS A STRIP, NOT A FILL, AND THAT IS THE WHOLE CORRECTNESS OF THIS FORM.
/// FIXED 2026-08-28, and it had been shipping every crescent as a QUARTER.
///
/// wlk_render_fill is a TRIANGLE FAN, and its own header states the precondition: "the caller is
/// responsible for the outline being star-shaped about pts[0]". A crescent is a LUNE - the region
/// between a half circle and a narrower half ellipse on the same side - and a lune is CONCAVE, so
/// it is not star-shaped about any point on it. The fan therefore spanned straight across the
/// concavity and filled the whole half disc: "Waxing crescent" and "First quarter" rendered as the
/// SAME PICTURE, as did "Last quarter" and "Waning crescent", and the store sheet captioned
/// "THE TERMINATOR IS A HALF ELLIPSE, NOT AN OFFSET CIRCLE" showed eight straight vertical edges.
///
/// ⚠️ THE GEOMETRY WAS NEVER WRONG - wlk_moon_outline is correct and the suite's turning assertion
/// on it passed honestly. The defect was handing a correct concave outline to a rasteriser that
/// cannot draw one. This wing's constitution already records the same law from the cloud side:
/// "a fan from an interior point cannot see into the valley". A rail pair is exact where a fan is
/// not, and the two rails here are already sampled from one angle sweep, so the strip is free.
function wlk_moon_build(_i, _r) {
    var _k = wlk_moon_k(_i);
    var _side = wlk_moon_side(_i);
    var _out = [wlk_dot(0, 0, _r, "m0")];

    if (wlk_moon_lit(_i) > 0.001) {
        var _n = 30;
        var _limb = array_create(_n + 1);
        var _term = array_create(_n + 1);
        for (var _s = 0; _s <= _n; _s++) {
            var _th = -pi * 0.5 + pi * (_s / _n);
            // Both rails share y, so every quad of the strip is the gap between the illuminated
            // limb and the terminator at one latitude. Exact for a crescent AND for a gibbous,
            // where k goes negative and the terminator crosses to the other side of the disc.
            _limb[_s] = [_side * _r * cos(_th), _r * sin(_th)];
            _term[_s] = [_side * _r * _k * cos(_th), _r * sin(_th)];
        }
        array_push(_out, wlk_strip(_limb, _term, "moon"));
    }

    // The maria - the dark patches - drawn ONLY on a gibbous or full moon, because on a crescent
    // there is not enough lit surface for them to land on and they read as dirt on the lens.
    if (wlk_moon_lit(_i) > 0.62) {
        array_push(_out, wlk_dot(-_r * 0.28, -_r * 0.22, _r * 0.26, "m3"));
        array_push(_out, wlk_dot( _r * 0.16, -_r * 0.34, _r * 0.17, "m3"));
        array_push(_out, wlk_dot( _r * 0.05,  _r * 0.20, _r * 0.30, "m3"));
        array_push(_out, wlk_dot(-_r * 0.34,  _r * 0.30, _r * 0.15, "m3"));
    }
    return _out;
}

/// ============================================================================================
/// THE SUN
/// ============================================================================================

/// The sun and its glow.
///
/// ⛔ PAINTER'S ORDER. The wing's constitution records this as a measured defect on another
/// product: "a glow drawn smallest-disc-first has every dim outer disc painted over the bright
/// core and flattens to a uniform donut". The loop below therefore runs LARGEST AND DIMMEST FIRST
/// and puts the hot core down LAST. Reversing it costs the entire effect and produces something
/// that still looks deliberate, which is why it survived on the other product until someone
/// opened the file.
///
/// ⚠️ THE GLOW GROWS AS THE SUN SINKS, and that is not stylisation: near the horizon sunlight
/// travels through far more atmosphere, so it scatters far more widely. A sun with a fixed corona
/// reads as a sticker at every hour except the one it was tuned at.
function wlk_sun_build(_r, _light) {
    var _out = [];
    var _low = clamp(1.0 - _light.alt / 30.0, 0, 1);
    var _spread = 2.6 + 5.2 * _low;
    var _rings = 7;

    for (var _s = _rings; _s >= 1; _s--) {
        var _t = _s / _rings;
        array_push(_out, wlk_dot(0, 0, _r * (1.0 + _spread * _t), "glow" + string(_s)));
    }
    array_push(_out, wlk_dot(0, 0, _r, "sun"));
    return _out;
}

/// The glow roles for a given sky. Added to the palette in place, like the rainbow's.
///
/// Each ring is the sun's own colour at a lower lightness and chroma. They are drawn opaque rather
/// than blended because the package draws its whole frame back to front and an opaque nested
/// series is both cheaper and - measured on the first render - cleaner at the rim, where stacked
/// alpha produced a visible ridge at every ring boundary.
function wlk_sun_palette(_pal, _stops, _light) {
    var _base = _stops[WLK_HAZE];
    var _sunL = 0.97, _sunC = 0.055 + 0.10 * _light.warmth;
    var _sunH = wlk_air_mix_h(88, 52, _light.warmth);
    for (var _s = 1; _s <= 7; _s++) {
        var _t = _s / 7.0;
        // eased so the innermost rings stay near the sun's own colour and the outermost fall away
        // quickly into the sky - a linear fade leaves a visible pale disc with a hard edge
        var _e = power(_t, 0.62);
        var _L = lerp(_sunL, _base[0], _e);
        var _C = lerp(_sunC, _base[1], _e);
        var _h = wlk_air_mix_h(_sunH, _base[2], _e);
        variable_struct_set(_pal, "glow" + string(_s), wlk_oklch(_L, _C, _h));
    }
    return _pal;
}

/// ============================================================================================
/// THE STARS
/// ============================================================================================

/// How many stars the field holds at full darkness.
#macro WLK_STAR_N 220

/// A star's apparent magnitude, mapped to a drawn radius.
///
/// ⛔ REAL STAR FIELDS ARE NOT UNIFORM AND THIS IS THE DETAIL THAT SELLS THE SKY. There are a
/// handful of bright stars, a few dozen middling ones and hundreds you can barely see. A field of
/// equal dots reads as noise or as a texture; a field with a steep magnitude distribution reads as
/// a sky. The exponent below is what produces that distribution - a plain uniform random radius
/// was tried first and looked like static.
function wlk_star_mag(_i) {
    var _u = wlk_wx_hash(_i, 40);
    return power(_u, 3.1);
}

/// The star field. _night is 0..1 from the light state; below about 0.05 nothing is drawn at all,
/// because a star visible at noon is the sort of error that makes a whole product look unfinished.
///
/// ⚠️ STARS DO NOT REACH THE HORIZON. The field is cut off above the skyline and fades out as it
/// approaches it - real ones are extinguished by the thickness of air near the ground, and drawing
/// them all the way down puts stars inside the mountains.
///
/// ⛔ _horizonY IS A PARAMETER AND NOT A CONSTANT, AND THAT IS A REAL BUG THIS SIGNATURE PREVENTS.
/// The skyline's position in THIS corpus's coordinates depends on the frame's aspect ratio -
/// wlk_sky maps the land by the frame WIDTH and the star field by the frame's LARGER dimension, so
/// the two only coincide on a square window. A hard-coded cut-off was written first and put stars
/// inside the mountains on every wide frame, which is every frame a game actually ships at.
function wlk_star_build(_night, _seed, _horizonY) {
    if (_night < 0.05) return [];
    var _out = [];
    var _sd = is_undefined(_seed) ? 0 : _seed;
    var _hz = is_undefined(_horizonY) ? 0.08 : _horizonY;
    var _n = round(WLK_STAR_N * clamp(_night, 0, 1));

    for (var _i = 0; _i < _n; _i++) {
        var _x = (wlk_wx_hash(_i + _sd * 7, 41) - 0.5) * 1.02;
        var _y = -0.52 + wlk_wx_hash(_i + _sd * 7, 42) * 0.80;

        // extinction near the horizon
        var _low = clamp((_hz - _y) / 0.34, 0, 1);
        if (_low <= 0.02) continue;

        var _m = wlk_star_mag(_i + _sd * 7);
        // ⛔ THE RADII WERE MORE THAN HALVED AFTER LOOKING AT A RENDERED SHEET. At the frame's
        // larger dimension the old figures gave a brightest star of nine pixels across, which does
        // not read as a star at all - it reads as a dot someone drew.
        var _r = (0.0008 + 0.0022 * _m) * (0.45 + 0.55 * _low);

        // The brightest few get a second, wider, dimmer disc under them - the same painter's order
        // as the sun, at a much smaller scale. Only the top few per cent qualify, which is what
        // keeps them reading as bright stars rather than as blobs.
        //
        // ⛔ "star_halo" AND NOT "glow6". The first version reused the SUN's outermost glow ring
        // for this, which is a reasonable-looking mistake and a bad one: those rings are tinted
        // toward the sun's own colour, so at dusk every bright star acquired an ORANGE corona and
        // read as an insect on the lens. A star's halo is the star's own colour, dimmed.
        if (_m > 0.72) array_push(_out, wlk_dot(_x, _y, _r * 2.2, "star_halo"));
        array_push(_out, wlk_dot(_x, _y, _r, "star"));
    }
    return _out;
}
