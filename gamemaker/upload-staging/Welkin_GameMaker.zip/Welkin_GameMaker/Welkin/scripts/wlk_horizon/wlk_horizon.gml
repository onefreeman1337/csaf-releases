/// WELKIN - wlk_horizon. THE CORPUS, PART II: ten horizon profiles, in three depth ranks.
///
/// A sky with nothing under it is a gradient. The horizon is what turns it into a PLACE, and it is
/// also what makes the colour work read: the pale band along the skyline only looks like distance
/// when there is something sitting in front of it.
///
/// -- WHY THREE RANKS AND NOT ONE LAYER --------------------------------------------------------
/// ⭐ AERIAL PERSPECTIVE IS THE ENTIRE EFFECT, AND IT IS A COLOUR EFFECT, NOT A DRAWING ONE. Air
/// scatters light, so the further away a ridge is the more of the SKY's own colour it carries:
/// distant mountains are not dark grey, they are a pale wash of whatever the sky is doing at that
/// height. Stack three ranks with the far one nearly sky-coloured and the near one nearly black and
/// the frame acquires depth without a single extra shape. Stack three ranks in the SAME colour and
/// it reads as one lumpy cut-out, which is what a single silhouette layer always looks like.
///
/// The three roles come from wlk_air_palette and are derived from the sky's own horizon stop, so
/// the wash is correct at every hour for free - at sunset the far ridge goes orange because the sky
/// behind it is orange, and nothing here knows what time it is.
///
/// ⛔ AND THE LAND IS DRAWN FLAT, WITH NO RELIEF, ON PURPOSE. Every other corpus in this package is
/// shaded by surface normal; a distant ridge must not be. Real distant land has no visible form -
/// that is what distance DOES to it - and bevelling a mountain range produces a range of shiny
/// plastic mountains sitting in front of a photographic sky. The one exception is the rim light in
/// wlk_horizon_rim, which is a real optical event with a narrow condition attached.
///
/// -- COORDINATES ------------------------------------------------------------------------------
/// Rails run left to right across the full unit box. y is DOWN, so a SMALLER y is a HIGHER ridge.
/// y = 0.5 is the bottom of the box; a profile's own baseline is wherever its rank puts it.
/// ============================================================================================

#macro WLK_HORIZON_N 10

/// Depth ranks. Far sits highest in the frame and palest; near sits lowest and darkest.
#macro WLK_RANK_FAR  0
#macro WLK_RANK_MID  1
#macro WLK_RANK_NEAR 2

/// ⛔ A POSITIVE FRACTIONAL PART. USE THIS AND NEVER GML's frac() ON A VALUE THAT CAN BE NEGATIVE.
///
/// MEASURED 2026-08-26 by this product's own self-test, on a real Igor-built executable, and it is
/// the most valuable thing that suite has found. GML's frac() truncates TOWARD ZERO, so
/// frac(-0.15) is -0.15, not 0.85. Every repeating pattern in this package is built on a
/// fractional part, and x runs from -0.5, so half of every pattern was being fed a negative.
///
/// The damage was not cosmetic and it was not obvious:
///   - `1.0 - abs(frac(u) * 2 - 1)` is a triangle wave on [0,1] and goes NEGATIVE for negative u,
///     so mountain peaks inverted into pits that punched through the baseline.
///   - `power(t, 1.55)` with a negative t is NaN, and a NaN coordinate does not throw - it draws
///     nothing, silently, for that vertex only.
///   - `frac(sin(n) * 43758.5453)` is the standard cheap hash and sin is negative half the time,
///     so HALF of every hash in the package returned a negative "0..1" value.
///
/// None of that is visible in a screenshot of one frame at one seed. It was found because an
/// assertion asked whether a skyline ever leaves its own band.
function wlk_frac01(_v) {
    var _f = _v - floor(_v);
    return (_f < 0) ? _f + 1.0 : _f;
}

function wlk_horizon_name(_i) {
    switch (_i) {
        case 0: return "Open sea";
        case 1: return "Plains";
        case 2: return "Rolling downs";
        case 3: return "Conifer ridge";
        case 4: return "Broadleaf woodland";
        case 5: return "Foothills";
        case 6: return "Mountains";
        case 7: return "Alpine peaks";
        case 8: return "Mesa country";
        default: return "City skyline";
    }
}

/// The role a rank draws in, and the baseline it sits on.
function wlk_horizon_role(_rank) {
    switch (_rank) {
        case WLK_RANK_FAR: return "ground_far";
        case WLK_RANK_MID: return "ground_mid";
        default: return "ground";
    }
}

/// Where a rank's land meets the bottom of the frame. Near land starts higher up the frame than
/// far land, which is the other half of the depth cue: things closer to you occupy more of the
/// bottom of the picture.
function wlk_horizon_baseline(_rank) {
    switch (_rank) {
        case WLK_RANK_FAR: return 0.335;
        case WLK_RANK_MID: return 0.385;
        default: return 0.470;
    }
}

/// A rank's vertical scale. A far range is small in the frame however big it is in the world.
///
/// ⚠️ THE NEAR RANK IS 0.62, NOT THE 1.15 IT WAS AUTHORED AT, AND THE CHANGE CAME FROM LOOKING AT
/// THE HERO SHEET. At 1.15 the nearest ridge rose so high and its fill ran so far that the bottom
/// FORTY-FOUR PER CENT of the frame was one flat dark mass, and it competed with the mid range
/// instead of sitting in front of it. In a landscape backdrop the near band is a thin strip along
/// the bottom - it is there to close the composition, not to be the subject. The subject is the
/// sky. Nothing mechanical objected to the old value: a bounding box cannot see the space inside
/// itself, and a large dark area is ink as far as any coverage check is concerned.
function wlk_horizon_scale(_rank) {
    switch (_rank) {
        case WLK_RANK_FAR: return 0.30;
        case WLK_RANK_MID: return 0.52;
        default: return 0.62;
    }
}

/// ============================================================================================
/// THE TEN PROFILES
///
/// Each returns the skyline as a rail of [x, y] with y measured UPWARD from the baseline in
/// profile units - wlk_horizon_build converts. Keeping the profiles in their own units is what
/// lets one profile serve all three ranks without ten copies of a scale factor.
///
/// ⚠️ EVERY PROFILE IS A DETERMINISTIC FUNCTION OF x AND A SEED. Nothing here calls random(). A
/// horizon that re-rolls each frame does not read as wind, it reads as a fault.
/// ============================================================================================

function wlk_horizon_profile(_i, _x, _seed) {
    var _s = _seed;
    switch (_i) {

        // ---- 0. OPEN SEA. Dead flat, and it must be DEAD flat - a sea horizon with any wobble in
        // it reads as a mistake, because the real one is the straightest line most people ever see.
        case 0: return 0.0;

        // ---- 1. PLAINS. A long low swell, one wavelength across the whole frame.
        case 1: return 0.020 + 0.016 * sin((_x * 1.1 + _s) * WLK_TAU);

        // ---- 2. ROLLING DOWNS. Two frequencies: the big roll, and a smaller one riding it.
        case 2: return 0.055 + 0.038 * sin((_x * 1.7 + _s) * WLK_TAU)
                             + 0.014 * sin((_x * 4.3 + _s * 2.1) * WLK_TAU);

        // ---- 3. CONIFER RIDGE. ⭐ THE ONLY PROFILE WITH A HARD SAWTOOTH, and the sawtooth IS the
        // identity: a spruce line is a row of spikes, and smoothing it produces generic scrub. The
        // spikes ride on a slow ridge so the treeline follows the land, which is what stops it
        // reading as a comb laid on the horizon.
        case 3: {
            var _ridge = 0.048 + 0.030 * sin((_x * 1.3 + _s) * WLK_TAU);
            var _u = (_x + 0.5) * 46.0;
            var _tooth = abs(wlk_frac01(_u) * 2.0 - 1.0);
            var _hgt = 0.030 + 0.016 * sin(floor(_u) * 2.7 + _s * 3.1);
            return _ridge + _hgt * (1.0 - _tooth * _tooth);
        }

        // ---- 4. BROADLEAF WOODLAND. Round crowns instead of spikes - the same idea as the conifer
        // ridge with the tooth curve inverted, which is exactly the difference between the two
        // real treelines and is legible at thumbnail size.
        case 4: {
            var _ridge = 0.036 + 0.022 * sin((_x * 1.6 + _s * 1.4) * WLK_TAU);
            var _u = (_x + 0.5) * 21.0;
            var _cell = wlk_frac01(_u) * 2.0 - 1.0;
            var _crown = sqrt(max(0, 1.0 - _cell * _cell));
            var _hgt = 0.034 + 0.014 * sin(floor(_u) * 1.9 + _s * 2.3);
            return _ridge + _hgt * _crown;
        }

        // ---- 5. FOOTHILLS. Broad rounded masses, no peaks. The step between this and Mountains is
        // the presence of a sharp apex, not the height.
        //
        // ⚠️ THE CONSTANT IS 0.105 AND NOT 0.085 FOR A MEASURED REASON. Three summed sines have a
        // combined amplitude of 0.097, so a base of 0.085 lets the profile go NEGATIVE - the
        // skyline dips BELOW its own baseline, and the land strip then runs upward from a point
        // beneath where the fill starts. The self-test caught it by asserting that a skyline never
        // leaves its band; it is invisible at most seeds. When you sum waves, the base must clear
        // the SUM of the amplitudes, not the largest of them.
        case 5: return 0.105 + 0.055 * sin((_x * 2.1 + _s) * WLK_TAU)
                             + 0.030 * sin((_x * 3.7 + _s * 1.7) * WLK_TAU)
                             + 0.012 * sin((_x * 8.1 + _s * 2.9) * WLK_TAU);

        // ---- 6. MOUNTAINS. Sharp apexes. Built from an ABSOLUTE-VALUE fold rather than a sine,
        // because a sine has no corner in it and a mountain is nothing but corners.
        case 6: {
            var _a = 0.155 * (1.0 - abs(wlk_frac01(_x * 1.3 + _s) * 2.0 - 1.0));
            var _b = 0.090 * (1.0 - abs(wlk_frac01(_x * 2.7 + _s * 1.6) * 2.0 - 1.0));
            var _c = 0.038 * (1.0 - abs(wlk_frac01(_x * 5.9 + _s * 2.4) * 2.0 - 1.0));
            return 0.045 + _a + _b + _c;
        }

        // ---- 7. ALPINE PEAKS. The same fold, higher and sharper, with a POWER curve that pulls
        // the flanks in - real high peaks are concave, not straight-sided, and the concavity is
        // what separates alpine from ordinary mountains at a glance.
        case 7: {
            var _t1 = 1.0 - abs(wlk_frac01(_x * 1.1 + _s) * 2.0 - 1.0);
            var _t2 = 1.0 - abs(wlk_frac01(_x * 2.3 + _s * 1.9) * 2.0 - 1.0);
            var _t3 = 1.0 - abs(wlk_frac01(_x * 4.7 + _s * 3.3) * 2.0 - 1.0);
            return 0.050 + 0.215 * power(_t1, 1.55) + 0.105 * power(_t2, 1.7)
                         + 0.040 * power(_t3, 1.9);
        }

        // ---- 8. MESA COUNTRY. FLAT TOPS AND VERTICAL SIDES. The one landscape in the corpus with
        // no slope at all in its silhouette, and the reason it is here: it is the strongest
        // possible contrast with the two mountain profiles, so a buyer flipping through the ten
        // sees a genuinely different world rather than three sets of triangles.
        case 8: {
            var _u = _x * 3.1 + _s;
            var _cell = floor(_u);
            var _f = wlk_frac01(_u);
            var _hgt = 0.060 + 0.085 * wlk_frac01(sin(_cell * 12.9898 + _s * 78.233) * 43758.5453);
            // shoulders: a narrow ramp at each end of a cell so the wall is steep but not a
            // zero-width jump, which would alias badly at the rendered size
            var _edge = clamp(min(_f, 1.0 - _f) / 0.055, 0, 1);
            return 0.030 + _hgt * _edge;
        }

        // ---- 9. CITY SKYLINE. Blocks and towers. ⚠️ THE HEIGHTS ARE HASHED, NOT SINE-DRIVEN -
        // a skyline built from sines has a visible period and reads as a bar chart. A hash per
        // block gives the uncorrelated heights a real skyline has.
        default: {
            var _u = (_x + 0.5) * 26.0 + _s;
            var _cell = floor(_u);
            var _f = wlk_frac01(_u);
            var _h = wlk_frac01(sin(_cell * 91.7431 + _s * 41.113) * 27183.271);
            var _hgt = 0.030 + 0.150 * _h * _h;
            // a few blocks get a spire, which is what makes a skyline read as a city rather than
            // as a bar chart with rounded corners
            var _spire = (wlk_frac01(sin(_cell * 33.71 + 7.1) * 9137.5) > 0.86 && _f > 0.42 && _f < 0.58)
                       ? 0.055 : 0.0;
            var _edge = clamp(min(_f, 1.0 - _f) / 0.035, 0, 1);
            return 0.020 + _hgt * _edge + _spire;
        }
    }
}

/// ============================================================================================
/// BUILDING A RANK
/// ============================================================================================

/// How finely the skyline is sampled. The two hard-edged profiles (mesa, city) need considerably
/// more than the smooth ones or their vertical walls turn into slopes; sampling them all at the
/// higher rate costs a few hundred points once per front change and keeps this one number.
#macro WLK_HORIZON_SEGS 220

/// The skyline rail for one profile at one rank, in unit-box coordinates.
function wlk_horizon_rail(_i, _rank, _seed) {
    var _base = wlk_horizon_baseline(_rank);
    var _k = wlk_horizon_scale(_rank);
    var _sd = is_undefined(_seed) ? 0 : _seed;
    var _rail = array_create(WLK_HORIZON_SEGS + 1);
    for (var _s = 0; _s <= WLK_HORIZON_SEGS; _s++) {
        var _x = lerp(-0.5, 0.5, _s / WLK_HORIZON_SEGS);
        _rail[_s] = [_x, _base - wlk_horizon_profile(_i, _x, _sd) * _k];
    }
    return _rail;
}

/// How far below the box the land fill runs.
///
/// ⚠️ 0.75 IS DELIBERATELY PAST THE EDGE OF THE UNIT BOX AND IS NOT A TYPO. The land is placed by
/// wlk_sky at the frame's WIDTH, so on a wide window the bottom of the unit box lands well ABOVE
/// the bottom of the screen - a fill stopping at 0.5 leaves a band of raw background under the
/// mountains. Overshooting costs nothing: the strip is clipped by the viewport and never seen.
#macro WLK_HORIZON_FLOOR 0.75

/// One land rank as a filled strip from its skyline down past the bottom of the box.
function wlk_horizon_build(_i, _rank, _seed) {
    var _rail = wlk_horizon_rail(_i, _rank, _seed);
    var _n = array_length(_rail);
    var _floor = array_create(_n);
    for (var _s = 0; _s < _n; _s++) _floor[_s] = [_rail[_s][0], WLK_HORIZON_FLOOR];
    return [wlk_strip(_rail, _floor, wlk_horizon_role(_rank))];
}

/// ============================================================================================
/// THE RIM LIGHT
///
/// ⭐ THE ONE PLACE THE LAND IS ALLOWED TO CATCH LIGHT, and it is a real optical event rather than
/// a decoration: when the sun is within a few degrees of the horizon it grazes the top of the
/// nearest ridge and lights its top edge only. It is the single strongest cue that the sun is low.
///
/// ⛔ THE CONDITIONS ARE NARROW AND ARE ENFORCED HERE RATHER THAN LEFT TO THE CALLER. Drawn at
/// noon it is nonsense - at noon a ridge is lit all over, not along one edge - and drawn on the FAR
/// rank it contradicts the aerial perspective the whole file is built on, because a ridge twenty
/// miles away has no legible top edge at all. Near rank only, sun within 12 degrees of the horizon,
/// and only on the side of the frame the sun is actually on.
///
/// ⚠️ AND IT IS A STROKE, SO IT OBEYS THE 1.0px FLOOR. Its gradient is carried by how far along
/// the ridge it runs, never by how wide it is - the wing's constitution records the measurement
/// that made this a rule: at gallery scale an authored half-width range collapses to exactly one
/// pixel and reads as a barcode.
function wlk_horizon_rim(_i, _light, _seed) {
    if (_light.alt > 12 || _light.alt < -4) return [];
    if (_light.direct < 0.02) return [];

    var _rail = wlk_horizon_rail(_i, WLK_RANK_NEAR, _seed);
    var _n = array_length(_rail);
    var _out = [];

    // Only the stretch of ridge facing the sun lights up. az runs -1..+1 across the frame.
    var _sunx = clamp(_light.az, -1, 1) * 0.5;
    var _reach = 0.34;

    var _run = [];
    for (var _s = 0; _s < _n; _s++) {
        var _d = abs(_rail[_s][0] - _sunx);
        if (_d < _reach) {
            array_push(_run, [_rail[_s][0], _rail[_s][1] - 0.004]);
        } else if (array_length(_run) > 1) {
            array_push(_out, wlk_poly(_run, false, 0.006, "m4"));
            _run = [];
        }
    }
    if (array_length(_run) > 1) array_push(_out, wlk_poly(_run, false, 0.006, "m4"));
    return _out;
}
