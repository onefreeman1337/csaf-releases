{
  "$GMScript": "v1",
  "%Name": "wlk_horizon",
  "isCompatibility": false,
  "isDnD": false,
  "name": "wlk_horizon",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}