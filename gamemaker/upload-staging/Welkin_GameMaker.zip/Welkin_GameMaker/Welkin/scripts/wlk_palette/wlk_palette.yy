{
  "$GMScript": "v1",
  "%Name": "wlk_palette",
  "isCompatibility": false,
  "isDnD": false,
  "name": "wlk_palette",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}