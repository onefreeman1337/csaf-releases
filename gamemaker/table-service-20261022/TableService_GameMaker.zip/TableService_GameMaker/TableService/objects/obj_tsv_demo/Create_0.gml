/// @description THE DINING ROOM - Table Service's demo room: eight clothed tables, a kitchen pass and a door; serve the night.
/// Run with -selftest it is the headless test suite instead (writes tsv_selftest.json and exits).
/// ⛔ The crash handler is installed FIRST, and every variable a later event reads is declared ABOVE the early exits:
/// Clean Up always runs, even when Create leaves early.
exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("tsv_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.tsv_stage) + ": " + string(_ex.message) + " | " + string(_ex.stacktrace));
    file_text_close(_f);
    game_end();
});
global.tsv_stage = 0;
demo = undefined;
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";
if (string_pos("-selftest", _args) > 0) { global.tsv_stage = 1; tsv_selftest_write(tsv_selftest_run()); game_end(); exit; }
demo = tsv_demo_create("normal", 7);
