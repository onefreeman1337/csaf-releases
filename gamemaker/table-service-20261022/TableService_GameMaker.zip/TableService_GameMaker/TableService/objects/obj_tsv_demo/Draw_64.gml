/// @description Draw the dining room (the GUI is 960 x 640).
if (is_undefined(demo)) exit;
tsv_demo_draw(demo);
