/// @description Run the dining room.
if (is_undefined(demo)) exit;
tsv_demo_step(demo);
