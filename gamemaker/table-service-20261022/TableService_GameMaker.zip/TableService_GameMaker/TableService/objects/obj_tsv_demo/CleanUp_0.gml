/// @description Free what the dining room made (guarded: Clean Up runs even when Create left early for -selftest).
if (variable_instance_exists(id, "demo") && !is_undefined(demo)) { tsv_demo_free(demo); demo = undefined; }
