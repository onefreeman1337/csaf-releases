/// @description The Table Service kitchen pass: finished dishes wait here and the server picks them up within reach.
/// Place one in your room; tsv_floor_from_room reads it. Draws nothing itself.
visible = false;
