/// @description The Table Service door: customers come in and leave here. Place one in your room; tsv_floor_from_room
/// reads it. Draws nothing itself.
visible = false;
