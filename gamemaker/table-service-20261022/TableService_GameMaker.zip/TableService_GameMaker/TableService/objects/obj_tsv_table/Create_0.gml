/// @description A Table Service table. Place it in your room; tsv_floor_from_room reads it. Draws nothing itself (the
/// night draws the table, its chairs and its diners). Set these in the instance's Creation Code to change them:
seats = 1;   // 1 = one diner behind the table facing the camera; 2 = two diners either side, facing each other
cloth = 0;   // 0 linen, 1 gingham, 2 damask, 3 blue check
visible = false;
