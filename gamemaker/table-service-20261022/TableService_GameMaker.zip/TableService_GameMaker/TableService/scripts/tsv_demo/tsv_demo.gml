/// tsv_demo.gml - THE DINING ROOM, Table Service's demo: a drawn restaurant (plank floor, a red runner from the kitchen
/// pass to the door, the bar shelves, tonight's chalkboard, night windows, a fern), eight clothed tables, and a server
/// you drive. Every customer, dish, candle and ticket is the product's own drawing; nothing here loads an image file.
///
/// Table Service - A Restaurant Serving Minigame for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Keys: arrows or WASD walk; Space, Enter or E acts (take an order, serve, pick up at the pass); a left click walks
/// there and acts on arrival. 1 / 2 / 3 start an easy, normal or busy night; R restarts it; M shows every dish the
/// house serves; C shows forty customers; Esc closes a sheet. Read it as an example of the calls in the Readme.
/// Public functions: tsv_demo_create, tsv_demo_floor, tsv_demo_step, tsv_demo_draw, tsv_demo_free, tsv_demo_dish_names,
/// tsv_demo_bake_sheet.

#macro TSV_DEMO_W 960
#macro TSV_DEMO_H 640

/// @function tsv_demo_floor()
/// @description The demo's floor: eight tables (three with two seats, eleven seats in all), the pass under the kitchen
/// hatch, the door at the foot of the runner, and the bar and walls blocked for walkers.
/// @returns {Struct}
function tsv_demo_floor() {
    var _f = tsv_floor_create();
    tsv_floor_add_table(_f, 150, 236, 1, 0); tsv_floor_add_table(_f, 345, 240, 2, 1); tsv_floor_add_table(_f, 560, 232, 1, 3);
    tsv_floor_add_table(_f, 175, 400, 2, 2); tsv_floor_add_table(_f, 405, 392, 1, 0); tsv_floor_add_table(_f, 600, 410, 2, 1);
    tsv_floor_add_table(_f, 290, 548, 1, 3); tsv_floor_add_table(_f, 505, 552, 1, 2);
    tsv_floor_set_pass(_f, 770, 124); tsv_floor_set_door(_f, 770, 626);
    tsv_floor_block(_f, 0, 0, TSV_DEMO_W, 128); tsv_floor_block(_f, 0, 0, 40, TSV_DEMO_H); tsv_floor_block(_f, 52, 130, 100, 176);
    tsv_floor_finish(_f, TSV_DEMO_W, TSV_DEMO_H);
    return _f;
}

/// @function tsv_demo_dish_names()
/// @description The twenty dishes the M sheet shows: the house menu, then four that complete every form (noodles, an
/// egg, fruit, a tagged plated main). Pure.
/// @returns {Array}
function tsv_demo_dish_names() {
    var _o = [], _h = tsv_menu_house();
    for (var _i = 0; _i < array_length(_h); _i++) array_push(_o, _h[_i].name);
    array_push(_o, "Udon Noodles", "Fried Eggs", "Plum Basket", { name: "House Special", form: "plate", colour: "" });
    return _o;
}

/// @function tsv__demo_room(ctx)
/// @description Internal. The dining room behind everything, painted once (960 x 640).
function tsv__demo_room(_c) {
    var _i, _k, _W = TSV_DEMO_W, _H = TSV_DEMO_H;
    // the floor: planks with staggered ends, seams and grain
    var _rowH = 22;
    for (var _ry = 120; _ry < _H; _ry += _rowH) {
        var _row = floor((_ry - 120) / _rowH), _off = ((_row * 97) mod 160);
        for (var _px = -_off; _px < _W; _px += 160) {
            var _hsh = tsv_hash_string("plank" + string(_row) + ":" + string(_px)), _v = (_hsh mod 22) - 11;
            tsv__fill(_c, [146 + _v, 94 + floor(_v * 0.7), 56 + floor(_v * 0.4)]); tsv_cx_fill_rect(_c, _px, _ry, 160, _rowH);
            tsv__fill(_c, [255, 220, 170], 0.07); tsv_cx_fill_rect(_c, _px, _ry, 160, 3);
            tsv__fill(_c, [60, 30, 12], 0.16); for (_k = 0; _k < 3; _k++) tsv_cx_fill_rect(_c, _px + 8 + ((_hsh >> (_k * 5)) mod 140), _ry + 5 + _k * 5, 10 + ((_hsh >> (_k * 3)) mod 30), 1);
            tsv__fill(_c, [40, 20, 8], 0.55); tsv_cx_fill_rect(_c, _px, _ry, 1.5, _rowH);
        }
        tsv__fill(_c, [40, 20, 8], 0.6); tsv_cx_fill_rect(_c, 0, _ry + _rowH - 1.5, _W, 1.5);
    }
    // the runner from the pass to the door
    var _rx = 735, _rw = 70;
    tsv__fill(_c, [0, 0, 0], 0.25); tsv_cx_fill_rect(_c, _rx + 3, 128, _rw, _H - 128);
    tsv__fill(_c, "#8a2430"); tsv_cx_fill_rect(_c, _rx, 128, _rw, _H - 128);
    tsv__fill(_c, "#c9a24a"); tsv_cx_fill_rect(_c, _rx + 5, 128, 2, _H - 128); tsv_cx_fill_rect(_c, _rx + _rw - 7, 128, 2, _H - 128);
    for (var _dy = 160; _dy < _H; _dy += 54) { tsv__fill(_c, "#c9a24a", 0.9); tsv_cx_begin(_c); tsv_cx_move(_c, _rx + _rw / 2, _dy - 10); tsv_cx_line(_c, _rx + _rw / 2 + 9, _dy); tsv_cx_line(_c, _rx + _rw / 2, _dy + 10); tsv_cx_line(_c, _rx + _rw / 2 - 9, _dy); tsv_cx_close(_c); tsv_cx_fill(_c);
        tsv__fill(_c, "#6a1a24"); tsv__ell(_c, _rx + _rw / 2, _dy, 3, 3); tsv_cx_fill(_c); }
    // the left wall with two night windows
    tsv__fill(_c, "#2a1c14"); tsv_cx_fill_rect(_c, 0, 120, 40, _H - 120);
    tsv__fill(_c, [0, 0, 0], 0.35); tsv_cx_fill_rect(_c, 40, 120, 6, _H - 120);
    for (_i = 0; _i < 2; _i++) {
        var _wy = 190 + _i * 210;
        tsv__fill(_c, "#5a3a22"); tsv_cx_fill_rect(_c, 6, _wy - 4, 30, 118);
        var _g = tsv_cx_linear(_c, 0, _wy, 0, _wy + 110); tsv_cx_stop(_g, 0, [22, 34, 70]); tsv_cx_stop(_g, 1, [44, 66, 120]); _c.fill = _g; tsv_cx_fill_rect(_c, 10, _wy, 22, 110);
        tsv__fill(_c, [250, 240, 200]); tsv__ell(_c, 22, _wy + 24 + _i * 30, 4, 4); tsv_cx_fill(_c); tsv__fill(_c, [32, 50, 96]); tsv__ell(_c, 24, _wy + 23 + _i * 30, 3.4, 3.4); tsv_cx_fill(_c);
        tsv__fill(_c, [255, 255, 255], 0.7); for (_k = 0; _k < 4; _k++) tsv_cx_fill_rect(_c, 13 + ((_k * 7 + _i * 3) mod 16), _wy + 60 + _k * 11, 1, 1);
        tsv__fill(_c, "#5a3a22"); tsv_cx_fill_rect(_c, 10, _wy + 53, 22, 3); tsv_cx_fill_rect(_c, 19.5, _wy, 3, 110);
    }
    // the back wall: striped paper over a panelled dado
    for (var _sx = 0; _sx < _W; _sx += 24) { tsv__fill(_c, ((_sx / 24) mod 2) ? "#2b4536" : "#304c3c"); tsv_cx_fill_rect(_c, _sx, 0, 24, 96); }
    var _gw = tsv_cx_linear(_c, 0, 0, 0, 96); tsv_cx_stop(_gw, 0, [0, 0, 0], 0.35); tsv_cx_stop(_gw, 1, [0, 0, 0], 0); _c.fill = _gw; tsv_cx_fill_rect(_c, 0, 0, _W, 96);
    tsv__fill(_c, "#5a3620"); tsv_cx_fill_rect(_c, 0, 92, _W, 30); tsv__fill(_c, "#7a4c2c"); tsv_cx_fill_rect(_c, 0, 92, _W, 3);
    for (var _pp = 6; _pp < _W; _pp += 60) { tsv__stroke(_c, [30, 16, 8], 0.6, 1); tsv_cx_stroke_rect(_c, _pp, 98, 50, 18); }
    tsv__fill(_c, [0, 0, 0], 0.4); tsv_cx_fill_rect(_c, 0, 120, _W, 5);
    // the bar shelves with the house's drinks
    for (_k = 0; _k < 2; _k++) {
        var _sy = 40 + _k * 36;
        tsv__fill(_c, "#6a4224"); tsv_cx_fill_rect(_c, 52, _sy, 236, 5); tsv__fill(_c, [0, 0, 0], 0.3); tsv_cx_fill_rect(_c, 52, _sy + 5, 236, 3);
        var _drinks = (_k == 0) ? ["Pale Ale", "Mana Tonic", "Mulled Wine", "Blue Potion", "Stout", "Elixir", "Cider", "Green Draught"] : ["Mead", "Fire Remedy", "Plum Wine", "Pale Ale", "Night Tonic", "Lemonade", "Grog", "Rose Essence"];
        for (_i = 0; _i < 8; _i++) tsv_draw_dish(_c, 70 + _i * 29, _sy - 7, 10, _drinks[_i], false, false);
    }
    // tonight's chalkboard
    tsv__fill(_c, [0, 0, 0], 0.4); tsv_cx_fill_rect(_c, 336, 10, 220, 82);
    tsv__fill(_c, "#6a4224"); tsv_cx_fill_rect(_c, 330, 6, 220, 82); tsv__fill(_c, "#1c2620"); tsv_cx_fill_rect(_c, 336, 12, 208, 70);
    tsv__fill(_c, [255, 255, 255], 0.04); tsv_cx_fill_rect(_c, 340, 16, 120, 30);
    tsv__text(_c, "Tonight", 440, 22, 15, [236, 232, 214], 0.95, "center", TSV_FACE_DISPLAY);
    var _ton = ["Pumpkin Soup", "Grilled Trout", "Apple Pie"];
    for (_i = 0; _i < 3; _i++) { tsv_draw_dish(_c, 368, 40 + _i * 15, 6.5, _ton[_i], false, false); tsv__text(_c, _ton[_i], 380, 40 + _i * 15, 11, [230, 226, 206], 0.9, "left", TSV_FACE_BODY); }
    // the kitchen hatch over the pass: warm light, hanging copper pans, steam
    var _kg = tsv_cx_linear(_c, 0, 0, 0, 92); tsv_cx_stop(_kg, 0, [120, 60, 26]); tsv_cx_stop(_kg, 1, [214, 132, 58]); _c.fill = _kg; tsv_cx_fill_rect(_c, 630, 8, 290, 86);
    tsv__fill(_c, "#3a3a40"); tsv_cx_fill_rect(_c, 640, 62, 270, 22); tsv__fill(_c, "#55555c"); tsv_cx_fill_rect(_c, 640, 62, 270, 3);
    for (_i = 0; _i < 3; _i++) { tsv__fill(_c, "#2a2a2e"); tsv__ell(_c, 680 + _i * 90, 62, 26, 5); tsv_cx_fill(_c); tsv__fill(_c, [255, 120, 30], 0.45); tsv__ell(_c, 680 + _i * 90, 61, 18, 2.5); tsv_cx_fill(_c);
        tsv__fill(_c, "#8a8a92"); tsv_cx_fill_rect(_c, 662 + _i * 90, 40, 36, 20); tsv__fill(_c, "#b4b4bc"); tsv_cx_fill_rect(_c, 662 + _i * 90, 40, 36, 3);
        tsv__steam(_c, 680 + _i * 90, 38, 30, 3); }
    tsv__stroke(_c, "#6a4a2a", 1, 2); tsv__seg(_c, 636, 16, 914, 16);
    for (_i = 0; _i < 6; _i++) { var _px2 = 652 + _i * 46; tsv__stroke(_c, "#5a3a1a", 1, 1); tsv__seg(_c, _px2, 16, _px2, 24);
        var _cg = tsv_cx_radial(_c, _px2 - 4, 28, 1, _px2, 32, 10); tsv_cx_stop(_cg, 0, [250, 190, 140]); tsv_cx_stop(_cg, 1, [150, 70, 30]); _c.fill = _cg; tsv__ell(_c, _px2, 32, 9, 9); tsv_cx_fill(_c); }
    tsv__fill(_c, "#5a3620"); tsv_cx_fill_rect(_c, 624, 6, 8, 90); tsv_cx_fill_rect(_c, 918, 6, 8, 90); tsv_cx_fill_rect(_c, 624, 4, 302, 6);
    // the pass counter
    tsv__fill(_c, [0, 0, 0], 0.4); tsv_cx_fill_rect(_c, 640, 126, 270, 6);
    var _cg2 = tsv_cx_linear(_c, 0, 96, 0, 128); tsv_cx_stop(_cg2, 0, tsv__hex("#a8743e")); tsv_cx_stop(_cg2, 1, tsv__hex("#6a4224")); _c.fill = _cg2; tsv_cx_fill_rect(_c, 640, 96, 270, 30);
    tsv__fill(_c, "#d2a454"); tsv_cx_fill_rect(_c, 640, 96, 270, 3); tsv__fill(_c, "#e8c070"); tsv_cx_fill_rect(_c, 646, 118, 258, 2);
    tsv__text(_c, "THE PASS", 775, 110, 10, [250, 228, 180], 0.8, "center", TSV_FACE_DISPLAY);
    // the fern by the window
    tsv__fill(_c, "#8a4a2a"); tsv_cx_begin(_c); tsv_cx_move(_c, 62, 156); tsv_cx_line(_c, 90, 156); tsv_cx_line(_c, 86, 178); tsv_cx_line(_c, 66, 178); tsv_cx_close(_c); tsv_cx_fill(_c); tsv__outline(_c, 1);
    for (_i = 0; _i < 11; _i++) { var _fa = pi + 0.15 + _i * (pi - 0.3) / 10; tsv__fill(_c, (_i mod 2) ? "#3f7a2a" : "#4f8a34"); tsv__ell(_c, 76 + cos(_fa) * 15, 150 + sin(_fa) * 12, 13, 4, _fa); tsv_cx_fill(_c); }
    // the doormat and the door's opening at the foot of the runner
    tsv__fill(_c, "#1e140c"); tsv_cx_fill_rect(_c, 0, _H - 8, 728, 8); tsv_cx_fill_rect(_c, 812, _H - 8, _W - 812, 8);
    tsv__fill(_c, "#6a5a3a"); tsv_cx_fill_rect(_c, 742, _H - 34, 56, 22); tsv__stroke(_c, [40, 30, 16], 0.7, 1); tsv_cx_stroke_rect(_c, 744, _H - 32, 52, 18);
    // the warm light of the room
    var _vg = tsv_cx_radial(_c, 400, 360, 120, 420, 380, 640); tsv_cx_stop(_vg, 0, [255, 200, 120], 0); tsv_cx_stop(_vg, 1, [20, 8, 0], 0.4); _c.fill = _vg; tsv_cx_fill_rect(_c, 0, 0, _W, _H);
}

/// @function tsv_demo_bake_sheet(kind, [res])
/// @description Bake the M or C sheet as a sprite (960 x 640 x res): kind "dishes" = the twenty dishes on cloth with the
/// word each was read from; kind "diners" = forty seated customers at a table edge. -1 for an unknown kind.
/// @returns {Asset.GMSprite}
function tsv_demo_bake_sheet(_kind, _res = 1) {
    if (_kind == "dishes") return tsv_bake(TSV_DEMO_W, TSV_DEMO_H, 0, 0, function(_c, _a) {
        tsv__fill(_c, "#2e1c12"); tsv_cx_fill_rect(_c, 0, 0, TSV_DEMO_W, TSV_DEMO_H);
        for (var _y = 0; _y < TSV_DEMO_H; _y += 22) { tsv__fill(_c, [0, 0, 0], 0.18); tsv_cx_fill_rect(_c, 0, _y, TSV_DEMO_W, 1.5); }
        tsv__text(_c, "Every dish is drawn from its own name", 480, 34, 26, "#f2dfb0", 1, "center", TSV_FACE_DISPLAY);
        tsv__text(_c, "name a dish on your menu and this is what comes out of the kitchen", 480, 64, 17, "#d8c090", 0.9, "center", TSV_FACE_BODY);
        var _names = tsv_demo_dish_names();
        for (var _i = 0; _i < array_length(_names); _i++) {
            var _cx = 96 + (_i mod 5) * 192, _cy = 142 + floor(_i / 5) * 128, _L = tsv_dish_look(_names[_i]), _nm = is_struct(_names[_i]) ? _names[_i].name : _names[_i];
            tsv__fill(_c, [255, 240, 210], 0.06); tsv__ell(_c, _cx, _cy + 6, 58, 34); tsv_cx_fill(_c);
            tsv_draw_dish(_c, _cx, _cy, 30, _names[_i], true, false);
            tsv__text(_c, _nm, _cx, _cy + 44, tsv__fit(_nm, 180, 17, TSV_FACE_DISPLAY), "#f6e6c0", 1, "center", TSV_FACE_DISPLAY);
            var _why = ((_L.word == "tag") ? "tagged" : (is_string(_L.word) ? "read \"" + _L.word + "\"" : "no known word")) + "  :  " + _L.form;
            tsv__text(_c, _why, _cx, _cy + 62, 13, "#c8aa78", 0.9, "center", TSV_FACE_BODY);
        }
    }, 0, _res);
    if (_kind == "diners") return tsv_bake(TSV_DEMO_W, TSV_DEMO_H, 0, 0, function(_c, _a) {
        var _g = tsv_cx_linear(_c, 0, 0, 0, TSV_DEMO_H); tsv_cx_stop(_g, 0, [36, 52, 44]); tsv_cx_stop(_g, 1, [20, 30, 26]); _c.fill = _g; tsv_cx_fill_rect(_c, 0, 0, TSV_DEMO_W, TSV_DEMO_H);
        tsv__text(_c, "Every customer is generated", 480, 32, 26, "#f2dfb0", 1, "center", TSV_FACE_DISPLAY);
        tsv__text(_c, "face, skin, hair, hat, coat and one extra from a seed; seated facing their table", 480, 60, 17, "#d8c090", 0.9, "center", TSV_FACE_BODY);
        for (var _i = 0; _i < 40; _i++) {
            var _cx = 60 + (_i mod 8) * 120, _cy = 84 + floor(_i / 8) * 110;
            tsv_draw_chair(_c, _cx, _cy + 70, 64, 2);
            tsv_draw_figure(_c, _cx - 32, _cy + 26, 64, tsv_diner_look(_i * 7 + 3), 2, "seat");
            tsv__fill(_c, "#efe3c4"); tsv_cx_fill_rect(_c, _cx - 48, _cy + 84, 96, 9); tsv__fill(_c, "#a8303a"); tsv_cx_fill_rect(_c, _cx - 48, _cy + 93, 96, 3);
            for (var _k = 0; _k < 8; _k++) { tsv__fill(_c, "#a8303a"); tsv__ell(_c, _cx - 42 + _k * 12, _cy + 96, 3, 2); tsv_cx_fill(_c); }
        }
    }, 0, _res);
    return -1;
}

/// @function tsv_demo_create([difficulty], [seed])
/// @description The demo room's state: the floor, the backdrop, the server and the first night. Free with tsv_demo_free.
/// @returns {Struct}
function tsv_demo_create(_diff = "normal", _seed = 7) {
    display_set_gui_size(TSV_DEMO_W, TSV_DEMO_H);
    var _d = { floor: tsv_demo_floor(), night: undefined, difficulty: _diff, seed: _seed, mode: "play", sheet: -1, sheetKind: "",
        server: { x: 770, y: 170, dir: 2, dist: 0, path: -1, pi: 0, go: false, act: false }, look: tsv_server_look(), last: "", lastT: 0 };
    _d.room = tsv_bake(TSV_DEMO_W, TSV_DEMO_H, 0, 0, function(_c, _a) { tsv__demo_room(_c); }, 0);
    tsv__demo_new_night(_d);
    return _d;
}

/// @function tsv__demo_new_night(d)
/// @description Internal. Free the night (if any) and open the next one.
function tsv__demo_new_night(_d) {
    if (is_struct(_d.night)) tsv_night_free(_d.night);
    if (!_d.floor.finished) tsv_floor_finish(_d.floor, TSV_DEMO_W, TSV_DEMO_H);
    _d.night = tsv_night_start(_d.floor, { seed: _d.seed, difficulty: _d.difficulty, title: "The Gilded Ladle", currency: "coins" });
    _d.server.x = 770; _d.server.y = 170; _d.server.go = false;
}

/// @function tsv__demo_blocked(d, x, y)
/// @description Internal. Is (x, y) inside a table, a chair or off the floor for the server?
function tsv__demo_blocked(_d, _x, _y) {
    if (_x < 50 || _x > TSV_DEMO_W - 20 || _y < 140 || _y > TSV_DEMO_H - 14) return true;
    var _F = _d.floor;
    for (var _i = 0; _i < array_length(_F.tables); _i++) { var _T = _F.tables[_i], _ex = (_x - _T.x) / (_T.r + 8), _ey = (_y - (_T.y + 6)) / (_T.r * 0.55 + 12); if (_ex * _ex + _ey * _ey < 1) return true; }
    for (var _s = 0; _s < array_length(_F.seats); _s++) { var _S = _F.seats[_s]; if (point_distance(_x, _y, _S.x, _S.y) < 12) return true; }
    return false;
}

/// @function tsv_demo_step(d)
/// @description Run the demo for one frame: keys, clicks, the server's walk, the night.
function tsv_demo_step(_d) {
    if (!is_struct(_d)) return;
    if (keyboard_check_pressed(ord("M")) || keyboard_check_pressed(ord("C"))) {
        var _k = keyboard_check_pressed(ord("M")) ? "dishes" : "diners";
        if (_d.mode == "sheet" && _d.sheetKind == _k) _d.mode = "play";
        else { if (_d.sheet >= 0 && sprite_exists(_d.sheet)) sprite_delete(_d.sheet); _d.sheet = tsv_demo_bake_sheet(_k); _d.sheetKind = _k; _d.mode = "sheet"; }
    }
    if (keyboard_check_pressed(vk_escape) && _d.mode == "sheet") _d.mode = "play";
    if (_d.mode != "play") return;
    var _N = _d.night;
    if (keyboard_check_pressed(ord("1"))) { _d.difficulty = "easy"; tsv__demo_new_night(_d); return; }
    if (keyboard_check_pressed(ord("2"))) { _d.difficulty = "normal"; tsv__demo_new_night(_d); return; }
    if (keyboard_check_pressed(ord("3"))) { _d.difficulty = "busy"; tsv__demo_new_night(_d); return; }
    if (keyboard_check_pressed(ord("R"))) { tsv__demo_new_night(_d); return; }
    if (tsv_night_over(_N)) {
        tsv_night_update(_N);
        if (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space) || mouse_check_button_pressed(mb_left)) { _d.seed++; tsv__demo_new_night(_d); }
        return;
    }
    var _S = _d.server, _mx = (keyboard_check(vk_right) || keyboard_check(ord("D"))) - (keyboard_check(vk_left) || keyboard_check(ord("A"))), _my = (keyboard_check(vk_down) || keyboard_check(ord("S"))) - (keyboard_check(vk_up) || keyboard_check(ord("W")));
    if (_mx != 0 || _my != 0) {
        _S.go = false; var _l = sqrt(_mx * _mx + _my * _my), _sp = 2.6;
        var _nx = _S.x + _mx / _l * _sp, _ny = _S.y + _my / _l * _sp;
        if (!tsv__demo_blocked(_d, _nx, _S.y)) _S.x = _nx;
        if (!tsv__demo_blocked(_d, _S.x, _ny)) _S.y = _ny;
        _S.dist += _sp; _S.dir = (abs(_mx) >= abs(_my)) ? ((_mx > 0) ? 6 : 4) : ((_my > 0) ? 2 : 8);
    }
    if (mouse_check_button_pressed(mb_left)) {
        var _gx = device_mouse_x_to_gui(0), _gy = device_mouse_y_to_gui(0), _near = tsv_night_near(_N, _gx, _gy), _tx = _gx, _ty = _gy;
        if (_near.kind == "table") { var _T = _d.floor.tables[_near.table - 1]; _tx = _T.x + ((_S.x < _T.x) ? -1 : 1) * (_T.r + 22); _ty = _T.y + 22; }
        else if (_near.kind == "pass") { _tx = _d.floor.pass.x; _ty = _d.floor.pass.y + 34; }
        if (_S.path >= 0 && path_exists(_S.path)) path_delete(_S.path);
        _S.path = path_add();
        if (!mp_grid_path(_d.floor.grid, _S.path, _S.x, _S.y, _tx, _ty, true)) { path_clear_points(_S.path); path_add_point(_S.path, _S.x, _S.y, 100); path_add_point(_S.path, _tx, _ty, 100); }
        _S.pi = 1; _S.go = true; _S.act = (_near.kind != "");
    }
    if (_S.go) {
        var _n = path_get_number(_S.path), _moved = false;
        while (_S.pi < _n && !_moved) {
            var _px = path_get_point_x(_S.path, _S.pi), _py = path_get_point_y(_S.path, _S.pi), _dd = point_distance(_S.x, _S.y, _px, _py);
            if (_dd <= 2.6) { _S.x = _px; _S.y = _py; _S.pi++; continue; }
            var _ux = (_px - _S.x) / _dd, _uy = (_py - _S.y) / _dd; _S.x += _ux * 2.6; _S.y += _uy * 2.6; _S.dist += 2.6; _moved = true;
            _S.dir = (abs(_ux) > abs(_uy)) ? ((_ux > 0) ? 6 : 4) : ((_uy > 0) ? 2 : 8);
        }
        if (!_moved) { _S.go = false; if (_S.act) { _d.last = tsv_night_act(_N, _S.x, _S.y); _d.lastT = 50; } }
    }
    if (keyboard_check_pressed(vk_space) || keyboard_check_pressed(vk_enter) || keyboard_check_pressed(ord("E"))) { _d.last = tsv_night_act(_N, _S.x, _S.y); _d.lastT = 50; }
    if (_d.lastT > 0) _d.lastT--;
    tsv_night_update(_N);
}

/// @function tsv_demo_draw(d)
/// @description Draw the demo (call from Draw GUI; the GUI is set to 960 x 640).
function tsv_demo_draw(_d) {
    if (!is_struct(_d)) return;
    if (_d.mode == "sheet" && _d.sheet >= 0) { tsv_draw_premul(_d.sheet, 0, 0); return; }
    tsv_draw_premul(_d.room, 0, 0);
    var _S = _d.server, _pose = floor(_S.dist / 9) mod 4, _pn = (_pose == 1) ? "walk0" : ((_pose == 3) ? "walk2" : "walk1");
    var _actor = { y: _S.y, spr: tsv_diner_sprite(_d.look, _S.dir, _pn), x: _S.x, oy: 8 };
    tsv_night_draw(_d.night, [_actor]);
    // what Space would do here
    var _hint = tsv_night_hint(_d.night, _S.x, _S.y);
    if (_hint != "" && !tsv_night_over(_d.night)) {
        draw_set_font(fnt_tableservice_body_s); draw_set_halign(fa_center); draw_set_valign(fa_bottom);
        var _t = "Space: " + _hint, _w = string_width(_t) * 0.5 + 14;
        draw_set_alpha(0.75); draw_set_colour(make_colour_rgb(24, 14, 8)); draw_roundrect_ext(_S.x - _w / 2, _S.y - 74, _S.x + _w / 2, _S.y - 56, 8, 8, false);
        draw_set_alpha(1); draw_set_colour(make_colour_rgb(246, 226, 176)); draw_text_transformed(_S.x, _S.y - 57, _t, 0.5, 0.5, 0);
        draw_set_halign(fa_left); draw_set_valign(fa_top);
    }
    tsv_night_draw_hud(_d.night, 12, TSV_DEMO_H - 80);
    draw_set_font(fnt_tableservice_body_s); draw_set_halign(fa_right); draw_set_valign(fa_bottom); draw_set_colour(make_colour_rgb(232, 212, 168)); draw_set_alpha(0.85);
    // the key line sits between the tray and the runner (it ran over the rug at the right edge, seen in the first render)
    draw_text_transformed(722, TSV_DEMO_H - 12, "arrows walk, space acts, click to go, 1 2 3 a new night, M menu, C customers", 0.45, 0.45, 0);
    draw_set_alpha(1); draw_set_halign(fa_left); draw_set_valign(fa_top); draw_set_colour(c_white);
    tsv_night_draw_overlay(_d.night, TSV_DEMO_W, TSV_DEMO_H);
}

/// @function tsv_demo_free(d)
/// @description Free everything the demo made.
function tsv_demo_free(_d) {
    if (!is_struct(_d)) return;
    if (is_struct(_d.night)) tsv_night_free(_d.night);
    if (_d.server.path >= 0 && path_exists(_d.server.path)) path_delete(_d.server.path);
    if (_d.room >= 0 && sprite_exists(_d.room)) sprite_delete(_d.room);
    if (_d.sheet >= 0 && sprite_exists(_d.sheet)) sprite_delete(_d.sheet);
    if (is_struct(_d.floor) && variable_struct_exists(_d.floor, "grid") && _d.floor.grid >= 0) { mp_grid_destroy(_d.floor.grid); _d.floor.grid = -1; }
    tsv_cache_clear();
}
