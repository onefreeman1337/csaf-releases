/// tsv_scene.gml - the restaurant in YOUR room: a floor (tables with one or two seats, the kitchen pass, the door), a
/// night run on it (customers walk in from the door on a path round your tables, sit, order, wait, eat, pay or walk out),
/// the server's one context action, and the drawing of it all: chairs, clothed tables, seated diners, candles burning
/// down with patience, service bells, order tickets, dishes on the tables and at the pass, floating tags, the tray, the
/// opening banner and the closing ledger.
///
/// Table Service - A Restaurant Serving Minigame for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// How a game uses it (the Readme has the full quickstart):
///   floor = tsv_floor_from_room();                       // or tsv_floor_create + tsv_floor_add_table / set_pass / set_door
///   night = tsv_night_start(floor, { seed: 7, difficulty: "normal" });
///   Step:      tsv_night_update(night);  if (keyboard_check_pressed(vk_space)) tsv_night_act(night, player.x, player.y);
///   Draw:      tsv_night_draw(night);   Draw GUI: tsv_night_draw_hud(night, 12, 12); tsv_night_draw_overlay(night);
///   Clean Up:  tsv_night_free(night);
/// Your player moves however your game moves it: the night only needs its position when it acts. The night's diners
/// walk on a motion-planning grid built from the floor (mp_grid), never through a table.
/// Public functions (each documented below): tsv_menu_house, tsv_floor_create, tsv_floor_add_table, tsv_floor_set_pass,
/// tsv_floor_set_door, tsv_floor_block, tsv_floor_from_room, tsv_floor_finish, tsv_floor_seats, tsv_night_start,
/// tsv_night_update, tsv_night_act, tsv_night_near, tsv_night_draw, tsv_night_draw_hud, tsv_night_draw_overlay,
/// tsv_night_over, tsv_night_score, tsv_night_ledger_info, tsv_night_free.

#macro TSV_TABLE_R 26
#macro TSV_REACH 46
#macro TSV_WALK_SPEED 1.7
#macro TSV_GRID_CELL 16

// ---------------------------------------------------------------------------------------------------------------
// The menu
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv_menu_house()
/// @description The default house menu: 16 dishes with their prices (Roast Fowl 60, Pumpkin Soup 30, Honey Loaf 20,
/// Mushroom Stew 45, Grilled Trout 55, Apple Pie 35, Pale Ale 15, Mulled Wine 25, Herb Salad 25, Boar Steak 70, Cheese
/// Board 40, Berry Tart 35, Spiced Tea 12, Rice and Egg 30, Sausage Plate 45, Mana Tonic 50). Each entry is { name,
/// price }; a fresh array every call, so edit it freely. Pure.
/// @returns {Array<Struct>}
function tsv_menu_house() {
    var _src = [["Roast Fowl", 60], ["Pumpkin Soup", 30], ["Honey Loaf", 20], ["Mushroom Stew", 45], ["Grilled Trout", 55], ["Apple Pie", 35], ["Pale Ale", 15], ["Mulled Wine", 25],
        ["Herb Salad", 25], ["Boar Steak", 70], ["Cheese Board", 40], ["Berry Tart", 35], ["Spiced Tea", 12], ["Rice and Egg", 30], ["Sausage Plate", 45], ["Mana Tonic", 50]];
    var _o = [];
    for (var _i = 0; _i < array_length(_src); _i++) array_push(_o, { name: _src[_i][0], price: _src[_i][1] });
    return _o;
}

/// @function tsv__menu_ready(menu)
/// @description Internal. Your menu entries made into the core's shape: ids 1..n, a price (default 10), a cook time
/// (frames; default from the dish's form: a drink poured, a bowl ladled, a plate cooked), the dish struct to draw.
/// Entries that are not structs with a name are skipped. An empty result falls back to the house menu.
function tsv__menu_ready(_menu) {
    if (!is_array(_menu)) _menu = tsv_menu_house();
    var _o = [];
    for (var _i = 0; _i < array_length(_menu); _i++) {
        var _m = _menu[_i];
        if (is_string(_m)) _m = { name: _m };
        if (!is_struct(_m) || !is_string(_m[$ "name"]) || _m.name == "") continue;
        var _dish = { name: _m.name, form: is_string(_m[$ "form"]) ? _m.form : "", colour: is_string(_m[$ "colour"]) ? _m.colour : "" };
        var _look = tsv_dish_look(_dish), _price = tsv__fin(_m[$ "price"], 10), _cook = tsv__fin(_m[$ "cook"], 0);
        array_push(_o, { id: array_length(_o) + 1, name: _m.name, price: (_price > 0) ? _price : 10, cook: (_cook > 0) ? round(_cook) : tsv_dish_cook_frames(_look.form), dish: _dish });
    }
    if (array_length(_o) == 0 && is_array(_menu) && array_length(_menu) > 0) return tsv__menu_ready(undefined);
    return _o;
}

// ---------------------------------------------------------------------------------------------------------------
// The floor
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv_floor_create()
/// @description An empty floor. Add tables, then set the pass and the door. Returns a struct; free it with nothing (the
/// night owns the grid it builds).
/// @returns {Struct}
function tsv_floor_create() { return { tsv: "floor", tables: [], seats: [], pass: undefined, door: undefined, blocks: [], finished: false, w: room_width, h: room_height }; }

/// @function tsv__is_floor(f)
/// @description Internal. A floor made by tsv_floor_create.
function tsv__is_floor(_f) { return is_struct(_f) && _f[$ "tsv"] == "floor" && is_array(_f[$ "tables"]); }

/// @function tsv_floor_add_table(floor, x, y, [seats], [cloth])
/// @description Add a round clothed table centred on (x, y). seats 1 = one diner behind it facing you; 2 = two diners
/// either side, facing each other. cloth 0..3 = linen, gingham, damask, blue check. Returns the table's number (1, 2,
/// ...: the number written on its tickets), or 0 when refused (not a floor, not a position).
/// @returns {Real}
function tsv_floor_add_table(_f, _x, _y, _seats = 1, _cloth = 0) {
    if (!tsv__is_floor(_f) || !is_numeric(_x) || !is_numeric(_y) || is_nan(_x) || is_nan(_y)) return 0;
    _seats = (tsv__fin(_seats, 1) >= 2) ? 2 : 1;
    var _n = array_length(_f.tables) + 1, _T = { n: _n, x: _x, y: _y, r: TSV_TABLE_R, cloth: clamp(floor(tsv__fin(_cloth, 0)), 0, 3), seats: [] };
    var _ry = TSV_TABLE_R * 0.55;
    if (_seats == 1) {
        var _id = array_length(_f.seats) + 1;
        array_push(_f.seats, { id: _id, table: _n, x: _x, y: _y - _ry + 3, dir: 2, ax: _x, ay: _y - _ry - 26 });
        array_push(_T.seats, _id);
    } else {
        for (var _s = -1; _s <= 1; _s += 2) {
            var _id2 = array_length(_f.seats) + 1;
            array_push(_f.seats, { id: _id2, table: _n, x: _x + _s * (TSV_TABLE_R + 8), y: _y + 12, dir: (_s < 0) ? 6 : 4, ax: _x + _s * (TSV_TABLE_R + 30), ay: _y + 12 });
            array_push(_T.seats, _id2);
        }
    }
    array_push(_f.tables, _T);
    _f.finished = false;
    return _n;
}

/// @function tsv_floor_set_pass(floor, x, y)
/// @description Where the kitchen hands dishes out (the pass, a counter): finished dishes wait here and the server picks
/// them up within reach of it. Returns true when set.
/// @returns {Bool}
function tsv_floor_set_pass(_f, _x, _y) { if (!tsv__is_floor(_f) || !is_numeric(_x) || !is_numeric(_y)) return false; _f.pass = { x: _x, y: _y }; return true; }

/// @function tsv_floor_set_door(floor, x, y)
/// @description Where customers come in and leave. Returns true when set.
/// @returns {Bool}
function tsv_floor_set_door(_f, _x, _y) { if (!tsv__is_floor(_f) || !is_numeric(_x) || !is_numeric(_y)) return false; _f.door = { x: _x, y: _y }; _f.finished = false; return true; }

/// @function tsv_floor_block(floor, x1, y1, x2, y2)
/// @description Mark a rectangle customers must walk round (a counter, a wall, a pillar). Tables block themselves.
/// Returns true when added.
/// @returns {Bool}
function tsv_floor_block(_f, _x1, _y1, _x2, _y2) {
    if (!tsv__is_floor(_f) || !is_numeric(_x1) || !is_numeric(_y1) || !is_numeric(_x2) || !is_numeric(_y2)) return false;
    array_push(_f.blocks, [min(_x1, _x2), min(_y1, _y2), max(_x1, _x2), max(_y1, _y2)]); _f.finished = false; return true;
}

/// @function tsv_floor_from_room()
/// @description A floor read from the instances in the current room: every obj_tsv_table (its `seats` 1 or 2 and `cloth`
/// 0..3, set in the instance's Creation Code), the first obj_tsv_pass and the first obj_tsv_door. Tables are numbered in
/// reading order (top to bottom, then left to right). No pass or door -> the room's top centre and bottom centre.
/// @returns {Struct}
function tsv_floor_from_room() {
    var _f = tsv_floor_create(), _list = [];
    with (obj_tsv_table) array_push(_list, { x: x, y: y, seats: variable_instance_exists(id, "seats") ? seats : 1, cloth: variable_instance_exists(id, "cloth") ? cloth : 0 });
    array_sort(_list, function(_a, _b) { return (_a.y != _b.y) ? _a.y - _b.y : _a.x - _b.x; });
    for (var _i = 0; _i < array_length(_list); _i++) tsv_floor_add_table(_f, _list[_i].x, _list[_i].y, _list[_i].seats, _list[_i].cloth);
    var _p = instance_find(obj_tsv_pass, 0), _d = instance_find(obj_tsv_door, 0);
    if (instance_exists(_p)) tsv_floor_set_pass(_f, _p.x, _p.y); else tsv_floor_set_pass(_f, room_width / 2, 48);
    if (instance_exists(_d)) tsv_floor_set_door(_f, _d.x, _d.y); else tsv_floor_set_door(_f, room_width / 2, room_height - 24);
    return _f;
}

/// @function tsv_floor_seats(floor)
/// @description The floor's seats, each { id, table, x, y, dir (the way the diner faces), ax, ay (where a walker
/// arrives before sitting) }. Do not edit. An empty array for a non-floor.
/// @returns {Array<Struct>}
function tsv_floor_seats(_f) { return tsv__is_floor(_f) ? _f.seats : []; }

/// @function tsv_floor_finish(floor, [width], [height])
/// @description Build the walking grid (mp_grid, 16 px cells) over width x height (default the room): every table and
/// its chairs, and every block, is marked solid. Called for you by tsv_night_start; call it yourself after changing the
/// floor mid-night. Returns the number of solid cells.
/// @returns {Real}
function tsv_floor_finish(_f, _w = room_width, _h = room_height) {
    if (!tsv__is_floor(_f)) return 0;
    if (variable_struct_exists(_f, "grid") && _f.grid >= 0) { mp_grid_destroy(_f.grid); _f.grid = -1; }
    _w = max(64, tsv__fin(_w, room_width)); _h = max(64, tsv__fin(_h, room_height));
    var _cs = TSV_GRID_CELL, _gw = ceil(_w / _cs), _gh = ceil(_h / _cs);
    _f.grid = mp_grid_create(0, 0, _gw, _gh, _cs, _cs); _f.w = _w; _f.h = _h;
    for (var _i = 0; _i < array_length(_f.tables); _i++) {
        var _T = _f.tables[_i];
        mp_grid_add_rectangle(_f.grid, _T.x - _T.r - 4, _T.y - _T.r * 0.55 - 4, _T.x + _T.r + 4, _T.y + _T.r * 0.62 + 4);
        for (var _k = 0; _k < array_length(_T.seats); _k++) { var _S = _f.seats[_T.seats[_k] - 1]; mp_grid_add_rectangle(_f.grid, _S.x - 10, _S.y - 12, _S.x + 10, _S.y + 6); }
    }
    for (var _b = 0; _b < array_length(_f.blocks); _b++) { var _B = _f.blocks[_b]; mp_grid_add_rectangle(_f.grid, _B[0], _B[1], _B[2], _B[3]); }
    // the door and every arrival point stay open, whatever was marked over them
    if (is_struct(_f.door)) mp_grid_clear_rectangle(_f.grid, _f.door.x - 8, _f.door.y - 8, _f.door.x + 8, _f.door.y + 8);
    for (var _s = 0; _s < array_length(_f.seats); _s++) { var _A = _f.seats[_s]; mp_grid_clear_cell(_f.grid, floor(_A.ax / _cs), floor(_A.ay / _cs)); }
    _f.finished = true;
    var _solid = 0;
    for (var _gx = 0; _gx < _gw; _gx++) for (var _gy = 0; _gy < _gh; _gy++) if (mp_grid_get_cell(_f.grid, _gx, _gy) == -1) _solid++;
    return _solid;
}

// ---------------------------------------------------------------------------------------------------------------
// The night
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv__is_night(n)
/// @description Internal. A night made by tsv_night_start.
function tsv__is_night(_n) { return is_struct(_n) && _n[$ "tsv"] == "night" && is_struct(_n[$ "shift"]); }

/// @function tsv_night_start(floor, [options])
/// @description Open the restaurant for one night on a floor. options (all optional): { seed (default 1), difficulty
/// ("easy" | "normal" | "busy"), menu (an array of { name, price, cook (frames), form, colour } or plain names; default
/// tsv_menu_house), title (the banner and the ledger), currency (default "coins"), seed_looks (true: each night's
/// customers look different; false: the same seed always seats the same faces) }. Returns the night, or undefined for a
/// floor with no tables. Bakes the shared pictures now (a fraction of a second); customers are baked as they come.
/// @returns {Struct}
function tsv_night_start(_f, _opt = {}) {
    if (!tsv__is_floor(_f) || array_length(_f.tables) == 0) return undefined;
    if (!is_struct(_opt)) _opt = {};
    if (!_f.finished || !variable_struct_exists(_f, "grid") || _f.grid < 0) tsv_floor_finish(_f);
    if (!is_struct(_f.door)) tsv_floor_set_door(_f, room_width / 2, room_height - 24);
    if (!is_struct(_f.pass)) tsv_floor_set_pass(_f, room_width / 2, 48);
    var _seed = tsv__fin(_opt[$ "seed"], 1), _menu = tsv__menu_ready(_opt[$ "menu"]), _seats = [];
    for (var _i = 0; _i < array_length(_f.seats); _i++) array_push(_seats, { id: _f.seats[_i].id });
    var _coreMenu = [];
    for (var _m = 0; _m < array_length(_menu); _m++) array_push(_coreMenu, { id: _menu[_m].id, price: _menu[_m].price, cook: _menu[_m].cook });
    var _plan = tsv_plan({ seed: _seed, difficulty: _opt[$ "difficulty"], seats: _seats, menu: _coreMenu });
    var _N = { tsv: "night", floor: _f, menu: _menu, plan: _plan, shift: tsv_shift_new(_plan), seed: _seed,
        title: is_string(_opt[$ "title"]) && _opt.title != "" ? _opt.title : "The Evening Shift", currency: is_string(_opt[$ "currency"]) ? _opt.currency : "coins",
        walkers: [], fx: [], frame: 0, banner: 150, hud: -1, hudKey: "", passSpr: -1, passKey: "", ledger: -1, bannerSpr: -1, tickets: {}, own: [], queue: [], walks: 0 };
    _N.difficulty = _plan.difficulty;
    _N.lookSeed = (_opt[$ "seed_looks"] == false) ? 0 : _seed;
    // the shared marks, baked once (the cache keeps them across nights)
    _N.spr = {
        bell: tsv__cached("bell", 22, 22, 11, 5, function(_c, _a) { tsv_cx_translate(_c, -11, -5); tsv_draw_bell(_c, 22, 22); }, 0),
        wax: tsv__cached("wax", 8, 26, 0, 0, function(_c, _a) { tsv_draw_wax(_c, 8, 26); }, 0),
        flame: tsv__cached("flame", 10, 16, 5, 16, function(_c, _a) { tsv_cx_translate(_c, -5, -16); tsv_draw_flame(_c, 10, 16, false); }, 0),
        gutter: tsv__cached("gutter", 10, 16, 5, 16, function(_c, _a) { tsv_cx_translate(_c, -5, -16); tsv_draw_flame(_c, 10, 16, true); }, 0),
        holder: tsv__cached("holder", 16, 8, 0, 0, function(_c, _a) { tsv_draw_holder(_c, 16, 8); }, 0),
        puff: tsv__cached("puff", 14, 20, 0, 0, function(_c, _a) { tsv_draw_puff(_c, 14, 20); }, 0)
    };
    for (var _t = 0; _t < array_length(_f.tables); _t++) {
        var _T = _f.tables[_t];
        _T.spr = tsv__cached("table|" + string(_T.cloth), 70, 56, 35, 20, function(_c, _a) { tsv_draw_table(_c, 0, 0, TSV_TABLE_R, _a); }, _T.cloth);
        for (var _k = 0; _k < array_length(_T.seats); _k++) { var _S = _f.seats[_T.seats[_k] - 1]; _S.chair = tsv__cached("chair|" + string(_S.dir), 30, 42, 15, 30, function(_c, _a) { tsv_draw_chair(_c, 0, 0, 48, _a); }, _S.dir); }
    }
    // every customer's look, and the walking frames to bake ahead of their arrival, a few each frame
    for (var _p = 0; _p < array_length(_plan.parties); _p++) {
        var _look = tsv_diner_look(_N.lookSeed * 31 + _plan.parties[_p].id);
        _N.walkers[_p] = undefined;
        array_push(_N.queue, [_look, 2, "walk1"], [_look, 8, "walk1"], [_look, 2, "walk0"], [_look, 2, "walk2"], [_look, 8, "walk0"], [_look, 8, "walk2"],
            [_look, 4, "walk1"], [_look, 6, "walk1"], [_look, 4, "walk0"], [_look, 4, "walk2"], [_look, 6, "walk0"], [_look, 6, "walk2"]);
    }
    return _N;
}

/// @function tsv__look_of(night, party_id)
/// @description Internal. The diner look for a party (the same formula the bake queue used).
function tsv__look_of(_N, _pid) { return tsv_diner_look(_N.lookSeed * 31 + _pid); }

/// @function tsv__seat(night, id)
/// @description Internal. A seat struct by id.
function tsv__seat(_N, _id) { var _s = _N.floor.seats; return (_id >= 1 && _id <= array_length(_s)) ? _s[_id - 1] : undefined; }

/// @function tsv__tag(night, x, y, text, kind)
/// @description Internal. A floating tag over (x, y) for 70 frames.
function tsv__tag(_N, _x, _y, _text, _kind) {
    var _spr = tsv_bake(170, 28, 0, 0, function(_c, _a) { tsv_draw_tag(_c, 170, 28, _a.t, _a.k); }, { t: _text, k: _kind });
    if (_spr >= 0) array_push(_N.fx, { kind: "tag", x: _x, y: _y, life: 70, spr: _spr });
}

/// @function tsv__walker_go(night, w, tx, ty)
/// @description Internal. Send a walker toward (tx, ty) on the floor's grid (a straight line if no path is found).
function tsv__walker_go(_N, _w, _tx, _ty) {
    if (_w.path >= 0 && path_exists(_w.path)) path_delete(_w.path);
    _w.path = path_add(); path_set_kind(_w.path, 0); path_set_closed(_w.path, false);
    if (!mp_grid_path(_N.floor.grid, _w.path, _w.x, _w.y, _tx, _ty, true)) { path_clear_points(_w.path); path_add_point(_w.path, _w.x, _w.y, 100); path_add_point(_w.path, _tx, _ty, 100); }
    _w.pi = 1; _w.tx = _tx; _w.ty = _ty;
}

/// @function tsv__walker_step(night, w)
/// @description Internal. Move a walker one frame along its path; returns true on arrival.
function tsv__walker_step(_N, _w) {
    var _n = path_get_number(_w.path);
    while (_w.pi < _n) {
        var _px = path_get_point_x(_w.path, _w.pi), _py = path_get_point_y(_w.path, _w.pi), _d = point_distance(_w.x, _w.y, _px, _py);
        if (_d <= TSV_WALK_SPEED) { _w.x = _px; _w.y = _py; _w.pi++; continue; }
        var _dx = (_px - _w.x) / _d, _dy = (_py - _w.y) / _d;
        _w.x += _dx * TSV_WALK_SPEED; _w.y += _dy * TSV_WALK_SPEED; _w.dist += TSV_WALK_SPEED;
        _w.dir = (abs(_dx) > abs(_dy)) ? ((_dx > 0) ? 6 : 4) : ((_dy > 0) ? 2 : 8);
        return false;
    }
    return true;
}

/// @function tsv_night_update(night)
/// @description Run the night for one frame: the shift's rules, customers walking in and out, effects and the bake
/// queue. Call it once per Step. Returns the shift's events for this frame (see tsv_shift_tick); read them now.
/// @returns {Array<Struct>}
function tsv_night_update(_N) {
    if (!tsv__is_night(_N)) return [];
    _N.frame++;
    if (_N.banner > 0) _N.banner--;
    // bake ahead: a few walking frames each frame, within about 3 ms
    var _t0 = get_timer();
    while (array_length(_N.queue) > 0 && get_timer() - _t0 < 3000) { var _q = _N.queue[0]; array_delete(_N.queue, 0, 1); tsv_diner_sprite(_q[0], _q[1], _q[2]); }
    var _S = _N.shift;
    tsv_shift_tick(_S, 1);
    var _ev = _S.events, _out = [];
    for (var _i = 0; _i < array_length(_ev); _i++) {
        var _e = _ev[_i]; array_push(_out, _e);
        var _P = tsv_shift_party(_S, _e[$ "party"] ?? -1);
        switch (_e.type) {
            case "seated":
                var _seat = tsv__seat(_N, _e.seat), _d = _N.floor.door;
                var _w = { party: _e.party, seat: _e.seat, x: _d.x, y: _d.y, dir: 8, dist: 0, path: -1, pi: 0, tx: 0, ty: 0, state: "in", look: tsv__look_of(_N, _e.party), table: _seat.table };
                tsv__walker_go(_N, _w, _seat.ax, _seat.ay);
                _N.walkers[_e.party - 1] = _w;
                break;
            case "walked":
                var _ww = _N.walkers[_e.party - 1];
                if (is_struct(_ww)) { var _s1 = tsv__seat(_N, _ww.seat); array_push(_N.fx, { kind: "puff", x: _s1.x + 16, y: _s1.y + 6, life: 60 }); tsv__tag(_N, _ww.x, _ww.y - 56, "walked out", "bad"); if (_ww.state == "seated") { _ww.x = _s1.ax; _ww.y = _s1.ay; } _ww.state = "out"; tsv__walker_go(_N, _ww, _N.floor.door.x, _N.floor.door.y); }
                break;
            case "paid":
                var _wp = _N.walkers[_e.party - 1];
                if (is_struct(_wp)) { tsv__tag(_N, _wp.x, _wp.y - 56, "+" + string(_e.tip) + " " + _N.currency + " tip", "coin"); var _s2 = tsv__seat(_N, _wp.seat); if (_wp.state == "seated") { _wp.x = _s2.ax; _wp.y = _s2.ay; } _wp.state = "out"; tsv__walker_go(_N, _wp, _N.floor.door.x, _N.floor.door.y); }
                break;
        }
    }
    // walkers
    for (var _k = 0; _k < array_length(_N.walkers); _k++) {
        var _W = _N.walkers[_k];
        if (!is_struct(_W) || _W.state == "gone") continue;
        if (_W.state == "in") { if (tsv__walker_step(_N, _W)) { var _st = tsv__seat(_N, _W.seat); _W.x = _st.x; _W.y = _st.y; _W.dir = _st.dir; _W.state = "seated"; } }
        else if (_W.state == "out") { if (tsv__walker_step(_N, _W)) { _W.state = "gone"; if (_W.path >= 0 && path_exists(_W.path)) path_delete(_W.path); _W.path = -1; } }
    }
    // effects
    for (var _f = array_length(_N.fx) - 1; _f >= 0; _f--) {
        var _x = _N.fx[_f]; _x.life--;
        if (_x.life <= 0) { if (_x.kind == "tag" && sprite_exists(_x.spr)) sprite_delete(_x.spr); array_delete(_N.fx, _f, 1); }
    }
    return _out;
}

/// @function tsv_night_near(night, x, y)
/// @description What the server would act on from (x, y): { kind: "pass" | "table" | "", table (number), dist }. The
/// nearest within reach (TSV_REACH past the table's edge, or of the pass). Use it to show a prompt.
/// @returns {Struct}
function tsv_night_near(_N, _x, _y) {
    var _o = { kind: "", table: 0, dist: 100000 };
    if (!tsv__is_night(_N) || !is_numeric(_x) || !is_numeric(_y)) return _o;
    var _p = _N.floor.pass, _dp = point_distance(_x, _y, _p.x, _p.y);
    if (_dp <= TSV_REACH + 12) { _o.kind = "pass"; _o.dist = _dp; }
    for (var _i = 0; _i < array_length(_N.floor.tables); _i++) {
        var _T = _N.floor.tables[_i], _d = point_distance(_x, _y, _T.x, _T.y) - _T.r;
        if (_d <= TSV_REACH && _d < _o.dist) { _o.kind = "table"; _o.table = _T.n; _o.dist = _d; }
    }
    return _o;
}

/// @function tsv_night_act(night, x, y)
/// @description The server's ONE action, decided by where they stand: at a table, take a seated party's order, or hand
/// them what they ordered from your hands; at the pass, pick up the first finished dish (two hands), or with both hands
/// full put one down. Returns what happened: "order", "serve", "pickup", "putdown", "wrong" (nothing in hand for this
/// table) or "" (nothing in reach).
/// @returns {String}
function tsv_night_act(_N, _x, _y) {
    if (!tsv__is_night(_N) || _N.shift.over) return "";
    var _near = tsv_night_near(_N, _x, _y), _S = _N.shift;
    if (_near.kind == "pass") {
        if (array_length(_S.pass) > 0 && array_length(_S.hands) < TSV_HANDS) { tsv_shift_pick_up(_S, 0); return "pickup"; }
        if (array_length(_S.hands) >= TSV_HANDS) { tsv_shift_put_down(_S, 0); return "putdown"; }
        return "";
    }
    if (_near.kind != "table") return "";
    var _T = _N.floor.tables[_near.table - 1], _wrong = false;
    for (var _k = 0; _k < array_length(_T.seats); _k++) {
        var _sid = _T.seats[_k], _pid = _S.seats[$ string(_sid)];
        if (_pid == 0) continue;
        var _W = _N.walkers[_pid - 1], _P = tsv_shift_party(_S, _pid);
        if (!is_struct(_W) || _W.state != "seated" || !is_struct(_P)) continue;
        if (_P.phase == "waiting") { tsv_shift_take_order(_S, _pid); return "order"; }
        if (_P.phase == "ordered") {
            if (tsv_shift_deliver(_S, _pid) > 0) { if (_P.phase == "eating") tsv__tag(_N, _W.x, _W.y - 56, "served", "good"); return "serve"; }
            _wrong = true;
        }
    }
    if (_wrong) { tsv__tag(_N, _T.x, _T.y - 70, "not their order", "bad"); return "wrong"; }
    return "";
}

/// @function tsv_night_hint(night, x, y)
/// @description What tsv_night_act would do from (x, y), as a few words for a prompt: "take the order", "serve",
/// "pick up", "put a dish down", or "" (nothing to do here). Changes nothing.
/// @returns {String}
function tsv_night_hint(_N, _x, _y) {
    if (!tsv__is_night(_N) || _N.shift.over) return "";
    var _near = tsv_night_near(_N, _x, _y), _S = _N.shift;
    if (_near.kind == "pass") { if (array_length(_S.pass) > 0 && array_length(_S.hands) < TSV_HANDS) return "pick up"; if (array_length(_S.hands) >= TSV_HANDS) return "put a dish down"; return ""; }
    if (_near.kind != "table") return "";
    var _T = _N.floor.tables[_near.table - 1];
    for (var _k = 0; _k < array_length(_T.seats); _k++) {
        var _pid = _S.seats[$ string(_T.seats[_k])];
        if (_pid == 0) continue;
        var _W = _N.walkers[_pid - 1], _P = tsv_shift_party(_S, _pid);
        if (!is_struct(_W) || _W.state != "seated" || !is_struct(_P)) continue;
        if (_P.phase == "waiting") return "take the order";
        if (_P.phase == "ordered") for (var _h = 0; _h < array_length(_S.hands); _h++) if (_S.hands[_h].party == _pid) return "serve";
    }
    return "";
}

/// @function tsv_night_over(night)
/// @description True once the night has closed (every party has paid or walked out after closing time).
/// @returns {Bool}
function tsv_night_over(_N) { return tsv__is_night(_N) && _N.shift.over; }

/// @function tsv_night_score(night)
/// @description The ledger and the stars so far (tsv_shift_score). undefined for a non-night.
/// @returns {Struct}
function tsv_night_score(_N) { return tsv__is_night(_N) ? tsv_shift_score(_N.shift) : undefined; }

/// @function tsv_night_ledger_info(night)
/// @description The struct tsv_draw_ledger draws from: the score, a mark per party (true served, false walked out), the
/// night's favourite dish, the title and its subtitle. undefined for a non-night.
/// @returns {Struct}
function tsv_night_ledger_info(_N) {
    if (!tsv__is_night(_N)) return undefined;
    var _sc = tsv_shift_score(_N.shift), _marks = [], _counts = {}, _best = 0, _top = undefined;
    for (var _i = 0; _i < array_length(_N.shift.parties); _i++) {
        var _q = _N.shift.parties[_i];
        if (_q.phase == "gone" || _q.phase == "walked") array_push(_marks, _q.phase == "gone");
        if (_q.phase == "gone") for (var _k = 0; _k < array_length(_q.order); _k++) { var _key = string(_q.order[_k]); _counts[$ _key] = (_counts[$ _key] ?? 0) + 1; }
    }
    var _names = variable_struct_get_names(_counts);
    array_sort(_names, true);
    for (var _j = 0; _j < array_length(_names); _j++) if (_counts[$ _names[_j]] > _best) { _best = _counts[$ _names[_j]]; _top = _names[_j]; }
    var _dl = (_N.difficulty == "easy") ? "Easy" : ((_N.difficulty == "busy") ? "Busy" : "Normal");
    var _info = { title: _N.title, sub: _dl + " night, " + string(array_length(_N.shift.parties)) + " parties, " + string(array_length(_N.floor.tables)) + " tables", currency: _N.currency,
        served: _sc.served, parties: _sc.parties, covers: _sc.covers, takings: _sc.takings, tips: _sc.tips, walkouts: _sc.walkouts, longestWait: _sc.longestWait, bestStreak: _sc.bestStreak,
        marks: _marks, stars: _sc.stars, grade: _sc.grade, foot: "Press Enter or click to close the book.", top: undefined };
    if (!is_undefined(_top)) { var _m = _N.menu[real(_top) - 1]; _info.top = { dish: _m.dish, name: _m.name, count: _best }; }
    return _info;
}

// ---------------------------------------------------------------------------------------------------------------
// Drawing the night
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv__dish_of(night, item)
/// @description Internal. The menu entry's dish struct for a menu id.
function tsv__dish_of(_N, _item) { return (_item >= 1 && _item <= array_length(_N.menu)) ? _N.menu[_item - 1].dish : { name: "?" }; }

/// @function tsv__table_of_party(night, pid)
/// @description Internal. The table number a party sits at (0 if not seated).
function tsv__table_of_party(_N, _pid) { var _P = tsv_shift_party(_N.shift, _pid); if (!is_struct(_P) || _P.seat == 0) return 0; var _s = tsv__seat(_N, _P.seat); return is_struct(_s) ? _s.table : 0; }

/// @function tsv_night_draw(night, [actors])
/// @description Draw the dining room's live layer in ROOM coordinates (call it from a Draw event over your own floor
/// art): chairs and tables, walking and seated customers and your actors (sorted back to front by their feet), the dishes on the tables, candles
/// burning down with each party's patience, the service bells, the order tickets, the dishes waiting at the pass and the
/// floating tags. actors (optional) is an array of structs { y (the feet), draw (a method that draws it) } or { x, y,
/// spr (a premultiplied Table Service sprite), oy (feet offset) }: your player drawn in the right order round the
/// tables. Draws nothing for a non-night.
function tsv_night_draw(_N, _actors = []) {
    if (!tsv__is_night(_N)) return;
    var _F = _N.floor, _S = _N.shift, _i, _k, _list = [];
    for (_i = 0; _i < array_length(_F.tables); _i++) array_push(_list, { y: _F.tables[_i].y, kind: 0, ref: _F.tables[_i] });
    for (_i = 0; _i < array_length(_N.walkers); _i++) { var _w = _N.walkers[_i]; if (is_struct(_w) && (_w.state == "in" || _w.state == "out")) array_push(_list, { y: _w.y, kind: 1, ref: _w }); }
    if (is_array(_actors)) for (_i = 0; _i < array_length(_actors); _i++) if (is_struct(_actors[_i]) && is_numeric(_actors[_i][$ "y"])) array_push(_list, { y: _actors[_i].y, kind: 2, ref: _actors[_i] });
    array_sort(_list, function(_a, _b) { return _a.y - _b.y; });
    for (_i = 0; _i < array_length(_list); _i++) {
        var _it = _list[_i];
        if (_it.kind == 2) { var _A = _it.ref; if (is_method(_A[$ "draw"])) _A.draw(); else tsv_draw_premul(_A[$ "spr"] ?? -1, tsv__fin(_A[$ "x"], 0), _A.y + tsv__fin(_A[$ "oy"], 0)); continue; }
        if (_it.kind == 1) {
            var _W = _it.ref, _pose = (floor(_W.dist / 9) mod 4), _pn = (_pose == 1) ? "walk0" : ((_pose == 3) ? "walk2" : "walk1");
            var _spr = tsv_diner_sprite(_W.look, _W.dir, _pn);
            tsv_draw_premul(_spr, round(_W.x), round(_W.y) + 8);
            continue;
        }
        tsv__draw_table_set(_N, _it.ref);
    }
    // overlays on top of every table: bells and tickets
    for (_i = 0; _i < array_length(_F.tables); _i++) {
        var _T = _F.tables[_i];
        for (_k = 0; _k < array_length(_T.seats); _k++) {
            var _seat = tsv__seat(_N, _T.seats[_k]), _pid = _S.seats[$ string(_seat.id)];
            if (_pid == 0) continue;
            var _W2 = _N.walkers[_pid - 1], _P = tsv_shift_party(_S, _pid);
            if (!is_struct(_W2) || _W2.state != "seated" || !is_struct(_P)) continue;
            var _hx = _seat.x, _hy = _seat.y - 48;
            if (_P.phase == "waiting") { var _sw = sin((_N.frame + _pid * 17) * 0.18) * 14; tsv_draw_premul(_N.spr.bell, _hx, _hy - 16, 1, 1, _sw, 1); }
            if (_P.phase == "ordered") {
                var _key = string(_pid) + ":" + string(_P.got), _tk = _N.tickets[$ string(_pid)];
                if (!is_struct(_tk) || _tk.key != _key) {
                    if (is_struct(_tk) && sprite_exists(_tk.spr)) sprite_delete(_tk.spr);
                    var _rows = [];
                    for (var _o = 0; _o < array_length(_P.order); _o++) { var _dd = tsv__dish_of(_N, _P.order[_o]); array_push(_rows, { name: _dd.name, dish: _dd, done: _o < _P.got }); }
                    var _th = tsv_ticket_height(array_length(_rows));
                    _tk = { key: _key, spr: tsv_bake(TSV_TICKET_W, _th, 0, 0, function(_c, _a) { tsv_draw_ticket(_c, TSV_TICKET_W, _a.h, { table: _a.t, dishes: _a.rows }); }, { h: _th, t: _T.n, rows: _rows }), h: _th };
                    _N.tickets[$ string(_pid)] = _tk;
                }
                var _tx = _hx + ((_seat.dir == 6) ? -40 : ((_seat.dir == 4) ? 40 : 0)) - TSV_TICKET_W / 2;
                tsv_draw_premul(_tk.spr, round(_tx), round(_hy - _tk.h + 2));
            }
        }
    }
    // the pass
    var _key2 = "";
    for (_i = 0; _i < array_length(_S.pass); _i++) _key2 += string(_S.pass[_i].item) + "." + string(_S.pass[_i].party) + ",";
    if (_key2 != _N.passKey) {
        if (_N.passSpr >= 0 && sprite_exists(_N.passSpr)) sprite_delete(_N.passSpr);
        _N.passSpr = -1; _N.passKey = _key2;
        if (array_length(_S.pass) > 0) {
            var _ready = [];
            for (_i = 0; _i < array_length(_S.pass); _i++) array_push(_ready, { dish: tsv__dish_of(_N, _S.pass[_i].item), table: tsv__table_of_party(_N, _S.pass[_i].party) });
            _N.passSpr = tsv_bake(230, 76, 115, 76, function(_c, _a) { tsv_cx_translate(_c, -115, -76); tsv_draw_pass(_c, 230, 76, _a); }, _ready);
        }
    }
    if (_N.passSpr >= 0) tsv_draw_premul(_N.passSpr, _F.pass.x, _F.pass.y);
    // effects
    for (_i = 0; _i < array_length(_N.fx); _i++) {
        var _x = _N.fx[_i];
        if (_x.kind == "tag") { var _age = 70 - _x.life; tsv_draw_premul(_x.spr, round(_x.x - 85), round(_x.y - 28 - _age * 0.35), 1, 1, 0, min(1, _x.life / 20)); }
        else if (_x.kind == "puff") tsv_draw_premul(_N.spr.puff, _x.x - 7, _x.y - 30 - (60 - _x.life) * 0.25, 1, 1, 0, min(1, _x.life / 30));
    }
}

/// @function tsv__draw_table_set(night, T)
/// @description Internal. One table with its chairs, its seated diners, the dishes and the candle.
function tsv__draw_table_set(_N, _T) {
    var _S = _N.shift, _k, _seat, _pid, _W, _P;
    // chairs and the diner behind the table (facing down) first, then the table, then side diners, dishes and candle
    for (_k = 0; _k < array_length(_T.seats); _k++) { _seat = tsv__seat(_N, _T.seats[_k]); tsv_draw_premul(_seat.chair, _seat.x, _seat.y - ((_seat.dir == 2) ? 3 : 2)); }
    tsv_draw_premul(_T.spr, _T.x, _T.y);
    for (_k = 0; _k < array_length(_T.seats); _k++) {
        _seat = tsv__seat(_N, _T.seats[_k]); _pid = _S.seats[$ string(_seat.id)];
        if (_pid != 0) { _W = _N.walkers[_pid - 1]; if (is_struct(_W) && _W.state == "seated") tsv_draw_premul(tsv_diner_sprite(_W.look, _seat.dir, "seat"), _seat.x, _seat.y + 2); }
    }
    // the candle (its wax burns down with the patience of whoever waits here) and the dishes on the cloth
    var _cx = _T.x + ((array_length(_T.seats) == 1) ? 15 : 0), _cy = _T.y - ((array_length(_T.seats) == 1) ? 2 : 6), _frac = -1, _gut = false;
    for (_k = 0; _k < array_length(_T.seats); _k++) {
        _seat = tsv__seat(_N, _T.seats[_k]); _pid = _S.seats[$ string(_seat.id)];
        if (_pid == 0) continue;
        _P = tsv_shift_party(_S, _pid); _W = _N.walkers[_pid - 1];
        if (!is_struct(_P) || !is_struct(_W) || _W.state != "seated") continue;
        if (_P.phase == "waiting" || _P.phase == "ordered") { var _f = clamp(_P.left / _P.patience, 0, 1); if (_frac < 0 || _f < _frac) _frac = _f; }
        if (_P.phase == "eating" || (_P.phase == "ordered" && _P.got > 0)) {
            var _n = array_length(_P.order), _side = (_seat.dir == 2) ? 0 : ((_seat.dir == 6) ? -1 : 1);
            for (var _d = 0; _d < _n; _d++) {
                if (_P.phase == "ordered" && _d >= _P.got) continue;
                var _eaten = (_P.phase == "eating" && _P.eat < TSV_EAT * 0.45);
                var _ds = tsv_dish_sprite(tsv__dish_of(_N, _P.order[_d]), 11, !_eaten && _P.phase == "eating", _eaten);
                var _dx = _T.x + _side * 11 + ((_n > 1) ? ((_d == 0) ? -7 : 7) : 0) - ((_side == 0) ? 6 : 0), _dy = _T.y + ((_side == 0) ? 3 : 1) + ((_n > 1 && _side != 0) ? ((_d == 0) ? -3 : 3) : 0);
                tsv_draw_premul(_ds, _dx, _dy);
            }
        }
    }
    tsv_draw_premul(_N.spr.holder, _cx - 8, _cy - 4);
    var _wh = (_frac >= 0) ? max(3, round(26 * _frac)) : 26;
    if (_frac >= 0) _gut = (_frac < 0.25);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    draw_sprite_part(_N.spr.wax, 0, 0, 26 - _wh, 8, _wh, _cx - 4, _cy - _wh);
    gpu_pop_state();
    if (_frac >= 0) { var _fl = 1 + sin(_N.frame * 0.4 + _T.n) * 0.07; tsv_draw_premul(_gut ? _N.spr.gutter : _N.spr.flame, _cx, _cy - _wh + 2, _fl, _fl, sin(_N.frame * 0.13 + _T.n) * 4, 1); }
}

/// @function tsv_night_draw_hud(night, x, y)
/// @description Draw the server's tray in GUI coordinates (300 x 68 at x, y): the two hands and what each carries for
/// which table, tips so far, served and walked out, and the shift's clock. Re-drawn only when something on it changes.
function tsv_night_draw_hud(_N, _x, _y) {
    if (!tsv__is_night(_N) || !is_numeric(_x) || !is_numeric(_y)) return;
    var _S = _N.shift, _L = _S.ledger, _prog = min(1, _S.t / max(1, _S.plan.length)), _key = string(floor(_prog * 72)) + "|" + string(_L.tips) + "|" + string(_L.served) + "|" + string(_L.walkouts) + "|";
    for (var _i = 0; _i < array_length(_S.hands); _i++) _key += string(_S.hands[_i].item) + "." + string(_S.hands[_i].party) + ",";
    if (_key != _N.hudKey || _N.hud < 0) {
        if (_N.hud >= 0 && sprite_exists(_N.hud)) sprite_delete(_N.hud);
        var _hands = [];
        for (var _h = 0; _h < 2; _h++) array_push(_hands, (_h < array_length(_S.hands)) ? { dish: tsv__dish_of(_N, _S.hands[_h].item), table: tsv__table_of_party(_N, _S.hands[_h].party) } : undefined);
        _N.hud = tsv_bake(300, 68, 0, 0, function(_c, _a) { tsv_draw_hud(_c, 300, 68, _a); }, { hands: _hands, progress: floor(_prog * 72) / 72, tips: _L.tips, currency: _N.currency, served: _L.served, walkouts: _L.walkouts });
        _N.hudKey = _key;
    }
    tsv_draw_premul(_N.hud, _x, _y);
}

/// @function tsv_night_draw_overlay(night, [w], [h])
/// @description Draw the night's screen-wide pictures in GUI coordinates: the opening banner (its first 2.5 seconds)
/// and, once the night is over, the ledger page over the dimmed room. w x h default to the GUI size.
function tsv_night_draw_overlay(_N, _w = display_get_gui_width(), _h = display_get_gui_height()) {
    if (!tsv__is_night(_N)) return;
    _w = max(320, tsv__fin(_w, 960)); _h = max(240, tsv__fin(_h, 640));
    if (_N.banner > 0 && !_N.shift.over) {
        if (_N.bannerSpr < 0) {
            var _dl = (_N.difficulty == "easy") ? "Easy" : ((_N.difficulty == "busy") ? "Busy" : "Normal");
            _N.bannerSpr = tsv_bake(440, 96, 0, 0, function(_c, _a) { tsv_draw_banner(_c, 440, 96, _a.t, _a.s); }, { t: _N.title, s: _dl + " night, " + string(array_length(_N.shift.parties)) + " parties, " + string(array_length(_N.floor.tables)) + " tables" });
        }
        var _t = 150 - _N.banner, _by = (_t < 20) ? -96 + _t * 5.3 : ((_N.banner < 20) ? 10 - (20 - _N.banner) * 5.3 : 10);
        tsv_draw_premul(_N.bannerSpr, round(_w / 2 - 220), round(_by));
    }
    if (_N.shift.over) {
        if (_N.ledger < 0) _N.ledger = tsv_bake(_w, _h, 0, 0, function(_c, _a) { tsv_draw_ledger(_c, _a.w, _a.h, _a.info); }, { w: _w, h: _h, info: tsv_night_ledger_info(_N) });
        tsv_draw_premul(_N.ledger, 0, 0);
    }
}

/// @function tsv_night_free(night)
/// @description Free what the night made for itself: its tickets, tray, pass, banner, ledger and tags, the walkers'
/// paths and the floor's grid. The shared cache (dishes, diners, tables) stays for the next night: tsv_cache_clear frees
/// it. Safe to call twice.
function tsv_night_free(_N) {
    if (!tsv__is_night(_N)) return;
    var _del = function(_s) { if (is_numeric(_s) && _s >= 0 && sprite_exists(_s)) sprite_delete(_s); };
    _del(_N.hud); _del(_N.passSpr); _del(_N.ledger); _del(_N.bannerSpr); _N.hud = -1; _N.passSpr = -1; _N.ledger = -1; _N.bannerSpr = -1;
    var _tk = variable_struct_get_names(_N.tickets);
    for (var _i = 0; _i < array_length(_tk); _i++) _del(_N.tickets[$ _tk[_i]].spr);
    _N.tickets = {};
    for (var _f = 0; _f < array_length(_N.fx); _f++) if (_N.fx[_f].kind == "tag") _del(_N.fx[_f].spr);
    _N.fx = [];
    for (var _w = 0; _w < array_length(_N.walkers); _w++) { var _W = _N.walkers[_w]; if (is_struct(_W) && _W.path >= 0 && path_exists(_W.path)) path_delete(_W.path); if (is_struct(_W)) _W.path = -1; }
    if (variable_struct_exists(_N.floor, "grid") && _N.floor.grid >= 0) { mp_grid_destroy(_N.floor.grid); _N.floor.grid = -1; _N.floor.finished = false; }
    _N.tsv = "freed";
}
