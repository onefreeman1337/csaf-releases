/// tsv_selftest.gml - Table Service's in-engine test suite: the GML core held to the MZ edition's code run in Node
/// (tsv_oracle_core) - hashes, generator draws, plans, whole shifts played by a scripted server, dish looks read from names,
/// diner looks - then refusals on bad input, every dish and forty diners baked and inked and told apart, every mark drawn,
/// and a whole night on a real floor with walkers that never cross a table. Run the demo with -selftest; the result is
/// written as tsv_selftest.json in the game's save folder and the renders (tsv_render_*.png) beside it, to be LOOKED at.
///
/// Table Service - A Restaurant Serving Minigame for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function tsv_st_assert(state, condition, message)
/// @description Count one assertion; keep the first 60 failure messages.
function tsv_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 60) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function tsv_st_stage(state, n)
/// @description Record the stage reached (the crash handler reports it).
function tsv_st_stage(_st, _n) { _st.stage = _n; global.tsv_stage = _n; }

/// @function tsv__st_n(v)
/// @description Internal. A whole number as the oracle writes it.
function tsv__st_n(_v) { return string_trim(string_format(_v, 1, 0)); }
/// @function tsv__st_first_diff(a, b)
/// @description Internal. Where two encodings first differ.
function tsv__st_first_diff(_a, _b) {
    if (_a == _b) return "";
    var _n = min(string_length(_a), string_length(_b)), _i = 1;
    while (_i <= _n && string_char_at(_a, _i) == string_char_at(_b, _i)) _i++;
    return "at char " + string(_i) + ": want '" + string_copy(_a, max(1, _i - 12), 50) + "' got '" + string_copy(_b, max(1, _i - 12), 50) + "'";
}

/// @function tsv__st_enc_plan(p)
/// @description Internal. A plan encoded exactly as the oracle encodes it (encPlan in _oracle_core.js).
function tsv__st_enc_plan(_p) {
    var _q = "";
    for (var _i = 0; _i < array_length(_p.parties); _i++) {
        var _r = _p.parties[_i], _o = "";
        for (var _k = 0; _k < array_length(_r.order); _k++) _o += ((_k > 0) ? "." : "") + tsv__st_n(_r.order[_k]);
        _q += ((_i > 0) ? ";" : "") + tsv__st_n(_r.id) + "," + tsv__st_n(_r.at) + "," + _o + "," + tsv__st_n(_r.patience);
    }
    return tsv__st_n(_p.seed) + "|" + _p.difficulty + "|" + tsv__st_n(_p.length) + "|" + tsv__st_n(array_length(_p.parties)) + "|" + _q;
}

/// @function tsv__st_act(shift)
/// @description Internal. The scripted server (act() in _oracle_core.js): deliver the first carried dish whose party is
/// waiting for it, else pick up the first dish at the pass, else take the first seated party's order.
function tsv__st_act(_s) {
    for (var _i = 0; _i < array_length(_s.hands); _i++) { var _q = tsv_shift_party(_s, _s.hands[_i].party); if (is_struct(_q) && _q.phase == "ordered") { tsv_shift_deliver(_s, _q.id); return 1; } }
    if (array_length(_s.pass) > 0 && array_length(_s.hands) < TSV_HANDS) { tsv_shift_pick_up(_s, 0); return 2; }
    for (var _j = 0; _j < array_length(_s.parties); _j++) if (_s.parties[_j].phase == "waiting") { tsv_shift_take_order(_s, _s.parties[_j].id); return 3; }
    return 0;
}

/// @function tsv__st_play(plan, gap)
/// @description Internal. A whole shift played by the scripted server every `gap` frames, encoded as playShift does.
function tsv__st_play(_plan, _gap) {
    var _s = tsv_shift_new(_plan), _n = { seated: 0, ready: 0, walked: 0, paid: 0, close: 0 }, _f = 0, _acts = 0;
    while (!_s.over && _f < _plan.length * 2 + 10) {
        tsv_shift_tick(_s, 1); _f++;
        for (var _e = 0; _e < array_length(_s.events); _e++) _n[$ _s.events[_e].type] += 1;
        if ((_f mod _gap) == 0 && tsv__st_act(_s) != 0) _acts++;
    }
    var _L = _s.ledger, _sc = tsv_shift_score(_s), _ps = "";
    for (var _i = 0; _i < array_length(_s.parties); _i++) { var _q = _s.parties[_i]; _ps += ((_i > 0) ? ";" : "") + _q.phase + "," + tsv__st_n(_q.got) + "," + tsv__st_n(_q.tip) + "," + tsv__st_n(_q.seat) + "," + tsv__st_n(_q.left); }
    return string_join("|", tsv__st_n(_f), tsv__st_n(_acts), tsv__st_n(_n.seated), tsv__st_n(_n.ready), tsv__st_n(_n.walked), tsv__st_n(_n.paid), tsv__st_n(_n.close),
        tsv__st_n(_L.covers), tsv__st_n(_L.served), tsv__st_n(_L.walkouts), tsv__st_n(_L.takings), tsv__st_n(_L.tips), tsv__st_n(_L.dishes), tsv__st_n(_L.longestWait), tsv__st_n(_L.bestStreak),
        tsv__st_n(_sc.stars), tsv__st_n(tsv__jsround(_sc.tipShare * 100)), _sc.grade, _ps);
}

/// @function tsv__st_seats(n)
/// @description Internal. Seats 1..n as the core takes them.
function tsv__st_seats(_n) { var _o = []; for (var _i = 1; _i <= _n; _i++) array_push(_o, { id: _i }); return _o; }

/// @function tsv__st_menu(O, n)
/// @description Internal. The oracle's menu, the first n entries, in the core's shape.
function tsv__st_menu(_O, _n) { var _o = []; for (var _i = 0; _i < min(_n, array_length(_O.menu)); _i++) array_push(_o, { id: _O.menu[_i].id, price: _O.menu[_i].price, cook: _O.menu[_i].cook }); return _o; }

/// @function tsv__st_read(spr, w, h, ox, oy)
/// @description Internal. Draw a premultiplied sprite onto a cleared w x h surface at (ox, oy) and read it into a buffer.
/// Returns { buf, w, h } (delete the buffer).
function tsv__st_read(_spr, _w, _h, _ox, _oy) {
    var _s = surface_create(_w, _h); surface_set_target(_s); draw_clear_alpha(c_black, 0); tsv_draw_premul(_spr, _ox, _oy); surface_reset_target();
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1); buffer_get_surface(_b, _s, 0); surface_free(_s);
    return { buf: _b, w: _w, h: _h };
}
/// @function tsv__st_ink(r)
/// @description Internal. Pixels with alpha > 16 in a read surface.
function tsv__st_ink(_r) { var _n = 0; for (var _i = 0; _i < _r.w * _r.h; _i++) if (buffer_peek(_r.buf, _i * 4 + 3, buffer_u8) > 16) _n++; return _n; }
/// @function tsv__st_grid(r, n)
/// @description Internal. An n x n grid of mean [a, r, g, b] over a read surface (per channel: a luminance grid is colour blind).
function tsv__st_grid(_r, _n) {
    var _g = array_create(_n * _n * 4, 0), _cw = _r.w / _n, _ch = _r.h / _n;
    for (var _gy = 0; _gy < _n; _gy++) for (var _gx = 0; _gx < _n; _gx++) {
        var _sa = 0, _sr = 0, _sg = 0, _sb = 0, _k = 0;
        for (var _py = floor(_gy * _ch); _py < floor((_gy + 1) * _ch); _py += 2) for (var _px = floor(_gx * _cw); _px < floor((_gx + 1) * _cw); _px += 2) {
            var _o = (_py * _r.w + _px) * 4; _sr += buffer_peek(_r.buf, _o, buffer_u8); _sg += buffer_peek(_r.buf, _o + 1, buffer_u8); _sb += buffer_peek(_r.buf, _o + 2, buffer_u8); _sa += buffer_peek(_r.buf, _o + 3, buffer_u8); _k++;
        }
        var _i = (_gy * _n + _gx) * 4, _kk = max(1, _k); _g[_i] = _sa / _kk; _g[_i + 1] = _sr / _kk; _g[_i + 2] = _sg / _kk; _g[_i + 3] = _sb / _kk;
    }
    return _g;
}
/// @function tsv__st_grid_rect(r, x, y, w, h, n)
/// @description Internal. tsv__st_grid over one rectangle of a read surface.
function tsv__st_grid_rect(_r, _x0, _y0, _w, _h, _n) {
    var _g = array_create(_n * _n * 4, 0), _cw = _w / _n, _ch = _h / _n;
    for (var _gy = 0; _gy < _n; _gy++) for (var _gx = 0; _gx < _n; _gx++) {
        var _sa = 0, _sr = 0, _sg = 0, _sb = 0, _k = 0;
        for (var _py = floor(_y0 + _gy * _ch); _py < floor(_y0 + (_gy + 1) * _ch); _py++) for (var _px = floor(_x0 + _gx * _cw); _px < floor(_x0 + (_gx + 1) * _cw); _px++) {
            var _o = (_py * _r.w + _px) * 4; _sr += buffer_peek(_r.buf, _o, buffer_u8); _sg += buffer_peek(_r.buf, _o + 1, buffer_u8); _sb += buffer_peek(_r.buf, _o + 2, buffer_u8); _sa += buffer_peek(_r.buf, _o + 3, buffer_u8); _k++;
        }
        var _i = (_gy * _n + _gx) * 4, _kk = max(1, _k); _g[_i] = _sa / _kk; _g[_i + 1] = _sr / _kk; _g[_i + 2] = _sg / _kk; _g[_i + 3] = _sb / _kk;
    }
    return _g;
}
/// @function tsv__st_dist(a, b)
/// @description Internal. Mean over cells of the largest channel difference.
function tsv__st_dist(_a, _b) { var _s = 0, _n = array_length(_a) div 4; for (var _i = 0; _i < _n; _i++) { var _m = 0; for (var _c = 0; _c < 4; _c++) _m = max(_m, abs(_a[_i * 4 + _c] - _b[_i * 4 + _c])); _s += _m; } return _s / max(1, _n); }

/// @function tsv__st_save(spr, w, h, name, st)
/// @description Internal. Draw a premultiplied sprite on an opaque dark ground and save it as a render to be looked at.
function tsv__st_save(_spr, _w, _h, _name, _st) {
    var _s = surface_create(_w, _h); surface_set_target(_s); draw_clear(make_colour_rgb(30, 20, 14)); tsv_draw_premul(_spr, 0, 0); surface_reset_target();
    surface_save(_s, _name); surface_free(_s); array_push(_st.renders, _name);
}

/// @function tsv_selftest_run()
/// @description Run the whole suite and return its state { pass, fail, total, stage, failures, ... }.
function tsv_selftest_run() {
    var _st = { pass: 0, fail: 0, total: 0, stage: 0, failures: [], runtime: GM_runtime_version, epsilon: 0, timing: {}, renders: [], notes: [] };
    var _eps = math_get_epsilon(); math_set_epsilon(0); _st.epsilon = math_get_epsilon();
    var _O = tsv_oracle_core(), _i, _j, _k;

    // 1. the hash and the generator, exact
    tsv_st_stage(_st, 1);
    for (_i = 0; _i < array_length(_O.hashes); _i++) { var _hw = _O.hashes[_i], _hg = tsv_hash_string(_hw[0]); tsv_st_assert(_st, _hg == _hw[1], "hash '" + _hw[0] + "' want " + string(_hw[1]) + " got " + string(_hg)); }
    for (_i = 0; _i < array_length(_O.rng); _i++) {
        var _rw = _O.rng[_i], _g = tsv_rng(_rw[0]), _bad = "";
        for (_j = 0; _j < array_length(_rw[1]); _j++) { var _u = round(tsv_rand(_g) * 4294967296); if (_u != _rw[1][_j] && _bad == "") _bad = "draw " + string(_j) + " want " + tsv__st_n(_rw[1][_j]) + " got " + tsv__st_n(_u); }
        tsv_st_assert(_st, _bad == "", "rng seed " + string(_rw[0]) + ": " + _bad);
    }

    // 2. plans, exact (every party's arrival, order and patience)
    tsv_st_stage(_st, 2);
    for (_i = 0; _i < array_length(_O.plans); _i++) {
        var _pw = _O.plans[_i], _p = tsv_plan({ seed: _pw.seed, difficulty: _pw.difficulty, seats: tsv__st_seats(_pw.seats), menu: tsv__st_menu(_O, _pw.menuN) });
        var _enc = tsv__st_enc_plan(_p);
        tsv_st_assert(_st, _enc == _pw.enc, "plan seed " + string(_pw.seed) + " " + _pw.difficulty + " " + string(_pw.seats) + " seats: " + tsv__st_first_diff(_pw.enc, _enc));
    }

    // 3. whole shifts played by the scripted server, exact (ledger, score, every party's end state)
    tsv_st_stage(_st, 3);
    var _t0 = get_timer();
    for (_i = 0; _i < array_length(_O.shifts); _i++) {
        var _sw = _O.shifts[_i], _sp = tsv_plan({ seed: _sw.seed, difficulty: _sw.difficulty, seats: tsv__st_seats(_sw.seats), menu: tsv__st_menu(_O, 16) });
        var _se = tsv__st_play(_sp, _sw.gap);
        tsv_st_assert(_st, _se == _sw.enc, "shift seed " + string(_sw.seed) + " " + _sw.difficulty + " gap " + string(_sw.gap) + ": " + tsv__st_first_diff(_sw.enc, _se));
    }
    _st.timing.shifts27_ms = (get_timer() - _t0) / 1000;

    // 4. dish looks read from names, the tag overrides, diner looks: exact
    tsv_st_stage(_st, 4);
    for (_i = 0; _i < array_length(_O.dishes); _i++) {
        var _dw = _O.dishes[_i], _L = tsv_dish_look(_dw[0]);
        var _de = _L.form + "," + _L.colour + "," + tsv__st_n(_L.rimIndex) + "," + (_L.known ? "1" : "0") + "," + (is_string(_L.word) ? _L.word : "-") + "," + tsv__st_n(_L.shape) + "," + tsv__st_n(tsv_dish_cook_frames(_L.form)) + "," + (tsv_dish_is_drink(_L.form) ? "1" : "0");
        tsv_st_assert(_st, _de == _dw[1], "dish '" + _dw[0] + "': " + tsv__st_first_diff(_dw[1], _de));
    }
    for (_i = 0; _i < array_length(_O.tagged); _i++) {
        var _tw = _O.tagged[_i], _TL = tsv_dish_look({ name: _tw[0], form: _tw[1], colour: _tw[2] });
        var _te = _TL.form + "," + _TL.colour + "," + (_TL.known ? "1" : "0") + "," + (is_string(_TL.word) ? _TL.word : "-");
        tsv_st_assert(_st, _te == _tw[3], "tagged '" + _tw[0] + "': " + tsv__st_first_diff(_tw[3], _te));
    }
    var _T = tsv__look_tables();
    for (_i = 0; _i < array_length(_O.diners); _i++) {
        var _nw = _O.diners[_i], _DL = tsv_diner_look(_nw[0]);
        var _ne = string_join(",", tsv__st_n(array_get_index(_T.skin, _DL.skin)), tsv__st_n(array_get_index(_T.hair, _DL.hair)), _DL.style, _DL.hat, tsv__st_n(array_get_index(_T.coats, _DL.coat)),
            tsv__st_n(array_get_index(_T.shirts, _DL.shirt)), _DL.extra, tsv__st_n(array_get_index(_T.coats, _DL.hatColour)), tsv__st_n(array_get_index(_T.rims, _DL.trim)));
        tsv_st_assert(_st, _ne == _nw[1], "diner seed " + string(_nw[0]) + ": " + tsv__st_first_diff(_nw[1], _ne));
    }

    // 5. refusals: bad input is refused with a documented value, never thrown on
    tsv_st_stage(_st, 5);
    var _empty = tsv_plan(undefined);
    tsv_st_assert(_st, is_struct(_empty) && array_length(_empty.parties) == 0, "tsv_plan(undefined) -> an empty plan");
    tsv_st_assert(_st, is_undefined(tsv_shift_new("plan")), "tsv_shift_new(non-plan) -> undefined");
    tsv_st_assert(_st, tsv_shift_tick(undefined) == 0 && tsv_shift_take_order(12, 1) == false && tsv_shift_deliver({}, 1) == 0, "shift verbs refuse a non-shift");
    var _ps = tsv_shift_new(tsv_plan({ seed: 3, seats: tsv__st_seats(2), menu: tsv__st_menu(_O, 4) }));
    tsv_st_assert(_st, tsv_shift_pick_up(_ps, -1) == false && tsv_shift_pick_up(_ps, 0.5) == false && tsv_shift_pick_up(_ps, "0") == false, "pick_up refuses bad indices");
    tsv_st_assert(_st, tsv_shift_put_down(_ps, 0) == false, "put_down with empty hands refused");
    // put_down: a dish picked up and put back returns to the pass
    tsv_shift_tick(_ps, 2000);
    var _ord = -1; for (_i = 0; _i < array_length(_ps.parties); _i++) if (_ps.parties[_i].phase == "waiting") { _ord = _ps.parties[_i].id; break; }
    if (_ord > 0) { tsv_shift_take_order(_ps, _ord); tsv_shift_tick(_ps, 400); }
    var _np = array_length(_ps.pass);
    if (_np > 0) { tsv_shift_pick_up(_ps, 0); tsv_st_assert(_st, array_length(_ps.hands) == 1 && array_length(_ps.pass) == _np - 1, "pick_up moves a dish from the pass to a hand"); tsv_st_assert(_st, tsv_shift_put_down(_ps, 0) && array_length(_ps.hands) == 0 && array_length(_ps.pass) == _np, "put_down returns it to the pass"); }
    else tsv_st_assert(_st, false, "the put_down fixture reached no dish at the pass (fixture is not hard)");
    tsv_st_assert(_st, tsv_dish_look(undefined).form != "" && tsv_dish_look(42).form != "", "dish_look on a non-name still gives a dish");
    var _dl0 = tsv_draw_dish("ctx", 0, 0, 10, "Soup");
    tsv_st_assert(_st, _dl0.form == "soup", "draw_dish refuses a non-context, returns the look");
    tsv_st_assert(_st, tsv_diner_sprite({}, 2, "seat") == -1 && tsv_draw_figure(tsv_cx_create(1), 0, 0, 48, "look", 2, "seat") == 0, "a figure refuses a non-look");
    tsv_st_assert(_st, tsv_floor_add_table("floor", 1, 2) == 0 && tsv_floor_add_table(tsv_floor_create(), "x", 2) == 0, "add_table refuses");
    tsv_st_assert(_st, is_undefined(tsv_night_start(tsv_floor_create())), "a floor with no tables opens no night");
    tsv_st_assert(_st, tsv_night_act(undefined, 0, 0) == "" && tsv_night_hint(5, 0, 0) == "" && !tsv_night_over("x"), "night verbs refuse a non-night");
    tsv_st_assert(_st, tsv_bake(0, 10, 0, 0, function(_c, _a) {}, 0) == -1 && tsv_bake(10, 10, 0, 0, "fn", 0) == -1, "tsv_bake refuses a bad size or painter");

    // 6. dishes: every form baked, inked, and told apart (with a control)
    tsv_st_stage(_st, 6);
    var _ctl = tsv_bake(40, 40, 0, 0, function(_c, _a) { tsv__fill(_c, [200, 50, 50]); tsv_cx_fill_rect(_c, 10, 10, 10, 10); }, 0);
    var _cr = tsv__st_read(_ctl, 40, 40, 0, 0), _cink = tsv__st_ink(_cr); buffer_delete(_cr.buf); sprite_delete(_ctl);
    tsv_st_assert(_st, _cink >= 90 && _cink <= 130, "ink control: a 10 x 10 square reads " + string(_cink) + " (want ~100)");
    var _names = tsv_demo_dish_names(), _grids = [], _forms = [], _minInk = 100000, _t1 = get_timer();
    for (_i = 0; _i < array_length(_names); _i++) {
        var _ds = tsv_dish_sprite(_names[_i], 30, true, false), _rr = tsv__st_read(_ds, 114, 114, 57, 57), _in = tsv__st_ink(_rr);
        _minInk = min(_minInk, _in);
        var _drink = tsv_dish_is_drink(tsv_dish_look(_names[_i]).form), _floor = _drink ? 300 : 1200;   // a vessel has no plate: a glass at the MZ size inks ~380
        tsv_st_assert(_st, _in > _floor, "dish '" + (is_struct(_names[_i]) ? _names[_i].name : _names[_i]) + "' inks " + string(_in) + " px (floor " + string(_floor) + ")");
        // the grid reads the dish's own box (r 30 and its steam), not the shared cell
        array_push(_grids, tsv__st_grid_rect(_rr, 21, 13, 72, 72, 12)); array_push(_forms, tsv_dish_look(_names[_i]).form); buffer_delete(_rr.buf);
        var _es = tsv_dish_sprite(_names[_i], 30, false, true), _er = tsv__st_read(_es, 114, 114, 57, 57), _ein = tsv__st_ink(_er); buffer_delete(_er.buf);
        tsv_st_assert(_st, _ein > (_drink ? 250 : 400), "eaten '" + (is_struct(_names[_i]) ? _names[_i].name : _names[_i]) + "' inks " + string(_ein));
    }
    _st.timing.dishes40_ms = (get_timer() - _t1) / 1000;
    var _fset = {}; for (_i = 0; _i < array_length(_forms); _i++) _fset[$ _forms[_i]] = 1;
    tsv_st_assert(_st, array_length(variable_struct_get_names(_fset)) == 20, "the dish sheet covers all 20 forms (" + string(array_length(variable_struct_get_names(_fset))) + ")");
    var _minD = 1000, _minPair = "";
    for (_i = 0; _i < array_length(_grids); _i++) for (_j = _i + 1; _j < array_length(_grids); _j++) { var _dd = tsv__st_dist(_grids[_i], _grids[_j]); if (_dd < _minD) { _minD = _dd; _minPair = _forms[_i] + "/" + _forms[_j]; } }
    tsv_st_assert(_st, tsv__st_dist(_grids[0], _grids[0]) == 0, "distinctness control: a dish against itself reads 0");
    tsv_st_assert(_st, _minD > 4, "every pair of dishes differs (closest " + _minPair + " at " + string(_minD) + ")");
    array_push(_st.notes, "dishes: min ink " + string(_minInk) + ", closest pair " + _minPair + " " + string_format(_minD, 1, 2));

    // 7. diners: forty seated, every one inked, told apart; the four facings and three walking poses of one
    tsv_st_stage(_st, 7);
    var _dg = [], _t2 = get_timer(), _minDI = 100000;
    for (_i = 0; _i < 40; _i++) {
        var _fs = tsv_diner_sprite(tsv_diner_look(_i * 7 + 3), 2, "seat"), _fr = tsv__st_read(_fs, 56, 56, 28, 54), _fi = tsv__st_ink(_fr);
        _minDI = min(_minDI, _fi); tsv_st_assert(_st, _fi > 500, "diner " + string(_i) + " inks " + string(_fi));
        array_push(_dg, tsv__st_grid(_fr, 8)); buffer_delete(_fr.buf);
    }
    _st.timing.diners40_ms = (get_timer() - _t2) / 1000;
    var _same = 0, _minDD = 1000;
    for (_i = 0; _i < 40; _i++) for (_j = _i + 1; _j < 40; _j++) { var _d2 = tsv__st_dist(_dg[_i], _dg[_j]); _minDD = min(_minDD, _d2); if (_d2 < 1.5) _same++; }
    tsv_st_assert(_st, _same == 0, string(_same) + " pairs of the forty diners look the same (closest " + string(_minDD) + ")");
    var _lk = tsv_diner_look(11), _pg = [];
    var _poses = [[2, "walk0"], [2, "walk1"], [2, "walk2"], [4, "walk1"], [6, "walk1"], [8, "walk1"], [4, "seat"], [6, "seat"], [2, "seat"]];
    for (_i = 0; _i < array_length(_poses); _i++) { var _ws = tsv_diner_sprite(_lk, _poses[_i][0], _poses[_i][1]), _wr = tsv__st_read(_ws, 56, 56, 28, 54); tsv_st_assert(_st, tsv__st_ink(_wr) > 500, "pose " + string(_poses[_i][0]) + _poses[_i][1] + " inks"); array_push(_pg, tsv__st_grid(_wr, 8)); buffer_delete(_wr.buf); }
    tsv_st_assert(_st, tsv__st_dist(_pg[3], _pg[4]) > 2 && tsv__st_dist(_pg[1], _pg[5]) > 2, "left differs from right, front from back");
    tsv_st_assert(_st, tsv__st_dist(_pg[0], _pg[2]) > 0.3, "the two stride poses differ");
    // no box behind a figure: over an opaque grey ground the empty corners of the cell stay exactly grey
    var _bs = surface_create(56, 56); surface_set_target(_bs); draw_clear(make_colour_rgb(128, 128, 128)); tsv_draw_premul(tsv_diner_sprite(tsv_diner_look(5), 2, "seat"), 28, 54); surface_reset_target();
    var _bb = buffer_create(56 * 56 * 4, buffer_fixed, 1); buffer_get_surface(_bb, _bs, 0); surface_free(_bs);
    var _off = 0; for (var _cy = 0; _cy < 8; _cy++) for (var _cx = 0; _cx < 56; _cx++) { var _o = (_cy * 56 + _cx) * 4; if (abs(buffer_peek(_bb, _o, buffer_u8) - 128) + abs(buffer_peek(_bb, _o + 1, buffer_u8) - 128) + abs(buffer_peek(_bb, _o + 2, buffer_u8) - 128) > 3) _off++; }
    buffer_delete(_bb);
    tsv_st_assert(_st, _off == 0, "a figure leaves the top of its cell untouched over a grey ground (" + string(_off) + " pixels changed: a box)");
    // every hooded diner shows its face (skin inside the head box); the rest are the counter's positive control
    var _hoods = 0, _faceless = 0, _ctlFaces = 0, _ctlN = 0;
    for (_i = 0; _i < 160 && (_hoods < 8 || _ctlN < 8); _i++) {
        var _hl = tsv_diner_look(_i), _isHood = (_hl.hat == "hood");
        if (!_isHood && _ctlN >= 8) continue;
        var _skin = tsv__hex(_hl.skin), _hr = tsv__st_read(tsv_diner_sprite(_hl, 2, "seat"), 56, 56, 28, 54), _sk = 0;
        for (var _yy = 14; _yy < 30; _yy++) for (var _xx = 20; _xx < 36; _xx++) { var _q = (_yy * 56 + _xx) * 4, _a = buffer_peek(_hr.buf, _q + 3, buffer_u8); if (_a < 200) continue;
            var _cr = buffer_peek(_hr.buf, _q, buffer_u8) * 255 / _a, _cg = buffer_peek(_hr.buf, _q + 1, buffer_u8) * 255 / _a, _cb = buffer_peek(_hr.buf, _q + 2, buffer_u8) * 255 / _a;
            if (abs(_cr - _skin[0]) + abs(_cg - _skin[1]) + abs(_cb - _skin[2]) < 50) _sk++; }
        buffer_delete(_hr.buf);
        if (_isHood) { _hoods++; if (_sk < 15) _faceless++; } else { _ctlN++; if (_sk >= 15) _ctlFaces++; }
    }
    tsv_st_assert(_st, _ctlN == 8 && _ctlFaces == 8, "skin counter control: " + string(_ctlFaces) + " of " + string(_ctlN) + " bare-headed diners show a face");
    tsv_st_assert(_st, _hoods >= 4 && _faceless == 0, string(_faceless) + " of " + string(_hoods) + " hooded diners show no face");
    array_push(_st.notes, "diners: min ink " + string(_minDI) + ", closest pair " + string_format(_minDD, 1, 2));

    // 8. every mark, drawn and inked
    tsv_st_stage(_st, 8);
    var _marks = [
        ["ticket", 120, 72, function(_c, _a) { tsv_draw_ticket(_c, 120, 72, { table: 4, dishes: [{ name: "Pumpkin Soup", done: true }, { name: "Pale Ale", done: false }] }); }],
        ["bell", 22, 22, function(_c, _a) { tsv_draw_bell(_c, 22, 22); }], ["wax", 8, 26, function(_c, _a) { tsv_draw_wax(_c, 8, 26); }],
        ["flame", 10, 16, function(_c, _a) { tsv_draw_flame(_c, 10, 16, false); }], ["gutter", 10, 16, function(_c, _a) { tsv_draw_flame(_c, 10, 16, true); }],
        ["holder", 16, 8, function(_c, _a) { tsv_draw_holder(_c, 16, 8); }], ["puff", 14, 20, function(_c, _a) { tsv_draw_puff(_c, 14, 20); }],
        ["pass", 230, 76, function(_c, _a) { tsv_draw_pass(_c, 230, 76, [{ name: "Roast Fowl", table: 2 }, { name: "Mana Tonic", table: 5 }, { name: "Herb Salad", table: 1 }]); }],
        ["tag", 170, 28, function(_c, _a) { tsv_draw_tag(_c, 170, 28, "+12 coins tip", "coin"); }],
        ["hud", 300, 68, function(_c, _a) { tsv_draw_hud(_c, 300, 68, { hands: [{ name: "Boar Steak", table: 3 }, undefined], progress: 0.4, tips: 34, currency: "coins", served: 3, walkouts: 1 }); }],
        ["coins", 60, 60, function(_c, _a) { tsv_draw_coins(_c, 30, 50, 6, 30, true); }], ["star", 50, 50, function(_c, _a) { tsv_draw_star(_c, 25, 25, 20, true); }],
        ["banner", 440, 96, function(_c, _a) { tsv_draw_banner(_c, 440, 96, "The Gilded Ladle", "Normal night, 12 parties, 8 tables"); }],
        ["table", 70, 56, function(_c, _a) { tsv_draw_table(_c, 35, 20, 26, 2); }], ["chair", 30, 42, function(_c, _a) { tsv_draw_chair(_c, 15, 30, 48, 2); }]
    ];
    for (_i = 0; _i < array_length(_marks); _i++) {
        var _mk = _marks[_i], _ms = tsv_bake(_mk[1], _mk[2], 0, 0, _mk[3], 0), _mr = tsv__st_read(_ms, _mk[1], _mk[2], 0, 0), _mi = tsv__st_ink(_mr); buffer_delete(_mr.buf);
        tsv_st_assert(_st, _mi > _mk[1] * _mk[2] * 0.08, _mk[0] + " inks " + string(_mi) + " of " + string(_mk[1] * _mk[2]));
        if (_mk[0] == "ticket" || _mk[0] == "hud" || _mk[0] == "pass" || _mk[0] == "banner") tsv__st_save(_ms, _mk[1], _mk[2], "tsv_render_mark_" + _mk[0] + ".png", _st);
        sprite_delete(_ms);
    }

    // 9. a whole night on a real floor, served by a scripted server who walks to each table (teleporting): walkers reach
    // their seats and never cross a table; the night closes; the ledger and the tray bake
    tsv_st_stage(_st, 9);
    var _F = tsv_demo_floor(), _N = tsv_night_start(_F, { seed: 21, difficulty: "normal", title: "Test Night" });
    tsv_st_assert(_st, tsv__is_night(_N) && array_length(_N.plan.parties) == 12, "a normal night plans 12 parties");
    var _cross = 0, _seatedN = 0, _acts = { order: 0, serve: 0, pickup: 0, putdown: 0, wrong: 0 }, _fr2 = 0, _midShot = false, _t3 = get_timer(), _worst = 0;
    while (!tsv_night_over(_N) && _fr2 < 30000) {
        var _tf = get_timer(); tsv_night_update(_N); _worst = max(_worst, (get_timer() - _tf) / 1000); _fr2++;
        for (_k = 0; _k < array_length(_N.walkers); _k++) {
            var _W = _N.walkers[_k]; if (!is_struct(_W)) continue;
            if (_W.state == "in" || _W.state == "out") for (_j = 0; _j < array_length(_F.tables); _j++) { var _TT = _F.tables[_j], _ex = (_W.x - _TT.x) / _TT.r, _ey = (_W.y - _TT.y) / (_TT.r * 0.55); if (_ex * _ex + _ey * _ey < 0.8) _cross++; }
        }
        if ((_fr2 mod 15) == 0) {
            var _S = _N.shift, _done = false, _r;
            for (_k = 0; _k < array_length(_S.hands) && !_done; _k++) { var _tn = tsv__table_of_party(_N, _S.hands[_k].party), _q = tsv_shift_party(_S, _S.hands[_k].party), _wq = _N.walkers[_S.hands[_k].party - 1];
                if (_tn > 0 && is_struct(_q) && _q.phase == "ordered" && is_struct(_wq) && _wq.state == "seated") { var _TA = _F.tables[_tn - 1]; _r = tsv_night_act(_N, _TA.x, _TA.y + 30); _acts[$ _r] = (_acts[$ _r] ?? 0) + 1; _done = true; } }
            if (!_done && array_length(_S.pass) > 0 && array_length(_S.hands) < TSV_HANDS) { _r = tsv_night_act(_N, _F.pass.x, _F.pass.y + 30); _acts[$ _r] = (_acts[$ _r] ?? 0) + 1; _done = true; }
            for (_k = 0; _k < array_length(_N.walkers) && !_done; _k++) { var _wk = _N.walkers[_k], _qk = is_struct(_wk) ? tsv_shift_party(_S, _wk.party) : undefined;
                if (is_struct(_wk) && _wk.state == "seated" && is_struct(_qk) && _qk.phase == "waiting") { var _TB = _F.tables[_wk.table - 1]; _r = tsv_night_act(_N, _TB.x, _TB.y + 30); _acts[$ _r] = (_acts[$ _r] ?? 0) + 1; _done = true; } }
        }
        for (_k = 0; _k < array_length(_N.walkers); _k++) if (is_struct(_N.walkers[_k]) && _N.walkers[_k].state == "seated") _seatedN = max(_seatedN, _k + 1);
        if (!_midShot && _fr2 == 2400) {
            _midShot = true;
            var _ms2 = surface_create(TSV_DEMO_W, TSV_DEMO_H), _room = tsv_bake(TSV_DEMO_W, TSV_DEMO_H, 0, 0, function(_c, _a) { tsv__demo_room(_c); }, 0);
            surface_set_target(_ms2); draw_clear(c_black); tsv_draw_premul(_room, 0, 0); tsv_night_draw(_N); tsv_night_draw_hud(_N, 12, TSV_DEMO_H - 80); surface_reset_target();
            surface_save(_ms2, "tsv_render_floor_mid.png"); array_push(_st.renders, "tsv_render_floor_mid.png"); surface_free(_ms2); sprite_delete(_room);
        }
    }
    _st.timing.night_frames = _fr2; _st.timing.night_ms = (get_timer() - _t3) / 1000; _st.timing.worst_frame_ms = _worst;
    var _sc = tsv_night_score(_N);
    tsv_st_assert(_st, tsv_night_over(_N), "the night closed (" + string(_fr2) + " frames)");
    tsv_st_assert(_st, _cross == 0, "walkers crossed a table " + string(_cross) + " times");
    tsv_st_assert(_st, _acts.order > 0 && _acts.serve > 0 && _acts.pickup > 0, "the server took orders (" + string(_acts.order) + "), picked up (" + string(_acts.pickup) + ") and served (" + string(_acts.serve) + ")");
    tsv_st_assert(_st, is_struct(_sc) && _sc.served >= 8 && _sc.stars >= 1, "a quick server serves most of a normal night (" + string(_sc.served) + " of 12, " + string(_sc.stars) + " stars)");
    _st.night = _sc;
    var _li = tsv_night_ledger_info(_N);
    tsv_st_assert(_st, is_struct(_li) && array_length(_li.marks) == 12 && is_struct(_li.top), "the ledger marks every party and names a favourite");
    var _lg = surface_create(TSV_DEMO_W, TSV_DEMO_H); surface_set_target(_lg); draw_clear(make_colour_rgb(60, 40, 30)); tsv_night_draw_overlay(_N, TSV_DEMO_W, TSV_DEMO_H); surface_reset_target();
    surface_save(_lg, "tsv_render_ledger.png"); array_push(_st.renders, "tsv_render_ledger.png"); surface_free(_lg);
    tsv_st_assert(_st, _N.ledger >= 0 && sprite_exists(_N.ledger), "the ledger baked");
    tsv_night_free(_N);
    tsv_st_assert(_st, _N.tsv == "freed" && _N.hud == -1 && _N.ledger == -1, "night_free frees its sprites");

    // 10. the demo room and its two sheets
    tsv_st_stage(_st, 10);
    var _D = tsv_demo_create("busy", 3);
    for (_i = 0; _i < 600; _i++) tsv_demo_step(_D);
    var _ds2 = surface_create(TSV_DEMO_W, TSV_DEMO_H); surface_set_target(_ds2); draw_clear(c_black); tsv_demo_draw(_D); surface_reset_target();
    surface_save(_ds2, "tsv_render_demo.png"); array_push(_st.renders, "tsv_render_demo.png"); surface_free(_ds2);
    tsv_st_assert(_st, tsv__is_night(_D.night) && _D.night.frame >= 600, "the demo ran its night 600 frames (" + string(_D.night.frame) + ")");
    var _sh1 = tsv_demo_bake_sheet("dishes"), _sh2 = tsv_demo_bake_sheet("diners");
    tsv_st_assert(_st, _sh1 >= 0 && _sh2 >= 0 && tsv_demo_bake_sheet("nope") == -1, "both sheets bake; an unknown one refuses");
    tsv__st_save(_sh1, TSV_DEMO_W, TSV_DEMO_H, "tsv_render_sheet_dishes.png", _st); tsv__st_save(_sh2, TSV_DEMO_W, TSV_DEMO_H, "tsv_render_sheet_diners.png", _st);
    sprite_delete(_sh1); sprite_delete(_sh2);
    tsv_demo_free(_D);
    tsv_st_assert(_st, array_length(variable_struct_get_names(tsv__cache())) == 0, "demo_free empties the shared cache");

    tsv_st_stage(_st, 99);
    math_set_epsilon(_eps);
    return _st;
}

/// @function tsv_selftest_write(state)
/// @description Write the suite's result as tsv_selftest.json in the save folder.
function tsv_selftest_write(_st) {
    var _f = file_text_open_write("tsv_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
