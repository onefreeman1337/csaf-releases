/// tsv_core.gml - the rules of a serving shift: customers arrive through the night and take a free seat, the server takes
/// the order at the table, the kitchen cooks it, the dish waits at the pass, the server carries it (two hands) to the right
/// table. Every waiting customer has patience, which runs down while they wait for the server and for the food. Served
/// quickly they tip well; left too long they walk out. At the end of the shift the ledger counts covers, takings, tips and
/// walkouts, and gives the night up to three stars.
///
/// Table Service - A Restaurant Serving Minigame for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// Pure logic: nothing here draws, reads input or uses GameMaker's random functions. The same seed deals the same night.
/// This is the RPG Maker MZ edition's ServiceCore.js, ported line for line and held to it: the suite (tsv_selftest) compares
/// plans, whole shifts and scores against the MZ code run in Node, number for number.
/// ⛔ Every public entry runs under math_set_epsilon(0) and restores the caller's epsilon: GameMaker compares numbers with
/// a default tolerance of 0.00001, so a draw of 0.349996 would read as "not below 0.35" and deal a different night.
/// Public functions (each documented below): tsv_hash_string, tsv_rng, tsv_rand, tsv_difficulty, tsv_difficulties, tsv_plan,
/// tsv_shift_new, tsv_shift_party, tsv_shift_free_seat, tsv_shift_tick, tsv_shift_take_order, tsv_shift_pick_up,
/// tsv_shift_deliver, tsv_shift_put_down, tsv_shift_score, tsv_cook_time, tsv_price_of.

#macro TSV_HANDS 2
#macro TSV_EAT 600
#macro TSV_ORDER_TAKE 30

// ---------------------------------------------------------------------------------------------------------------
// Hash and generator (FNV-1a and mulberry32, bit for bit the MZ edition's)
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv__imul(a, b)
/// @description Internal. JavaScript's Math.imul on unsigned 32-bit values, as int64 halves.
function tsv__imul(_a, _b) {
    var _m = int64($FFFFFFFF);
    _a = int64(_a) & _m; _b = int64(_b) & _m;
    var _lo = (_a * (_b & int64($FFFF))) & _m;
    var _hi = ((_a * (_b >> 16)) & int64($FFFF)) << 16;
    return (_lo + _hi) & _m;
}

/// @function tsv__u32(v)
/// @description Internal. JavaScript's (v >>> 0) for a number: truncated toward zero, then modulo 2^32; not a number -> 0.
function tsv__u32(_v) {
    if (!is_numeric(_v) || is_nan(_v) || is_infinity(_v)) return int64(0);
    if (_v < 0) return (int64($100000000) - (int64(-_v) & int64($FFFFFFFF))) & int64($FFFFFFFF);
    return int64(_v) & int64($FFFFFFFF);
}

/// @function tsv__jsround(v)
/// @description Internal. JavaScript's Math.round: halves round UP (toward +infinity), never to even.
function tsv__jsround(_v) { return floor(_v + 0.5); }

/// @function tsv_hash_string(text)
/// @description The FNV-1a hash of a string (UTF-16 code units below U+FFFF). The same text always gives the same number,
/// so a dish name or a diner seed always draws the same picture. Pure.
/// @param {String} text   anything; a non-string is hashed as its string form
/// @returns {Real} 0 .. 4294967295
function tsv_hash_string(_s) {
    var _t = is_string(_s) ? _s : string(_s);
    var _h = int64(2166136261), _n = string_length(_t);
    for (var _i = 1; _i <= _n; _i++) { _h = _h ^ int64(ord(string_char_at(_t, _i)) & $FFFF); _h = tsv__imul(_h, 16777619); }
    return real(_h);
}

/// @function tsv_rng(seed)
/// @description A seeded generator (mulberry32). Draw from it with tsv_rand. Pure.
/// @param {Real} seed   any number (taken as unsigned 32-bit)
/// @returns {Struct}
function tsv_rng(_seed) { return { a: tsv__u32(_seed) }; }

/// @function tsv_rand(gen)
/// @description The next draw in [0, 1) from a generator made by tsv_rng. A non-generator -> 0.
/// @param {Struct} gen
/// @returns {Real}
function tsv_rand(_g) {
    if (!is_struct(_g) || !variable_struct_exists(_g, "a")) return 0;
    var _m = int64($FFFFFFFF);
    _g.a = (int64(_g.a) + int64($6D2B79F5)) & _m;
    var _t = _g.a;
    _t = tsv__imul(_t ^ (_t >> 15), _t | 1);
    var _x = tsv__imul(_t ^ (_t >> 7), _t | 61);
    _t = _t ^ ((_t + _x) & _m);
    return real((_t ^ (_t >> 14)) & _m) / 4294967296;
}

// ---------------------------------------------------------------------------------------------------------------
// Difficulty and the plan
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv_difficulties()
/// @description The three nights, easiest first: "easy", "normal", "busy". Pure; do not edit the returned array.
/// @returns {Array<String>}
function tsv_difficulties() { static _d = ["easy", "normal", "busy"]; return _d; }

/// @function tsv_difficulty(name)
/// @description A night's numbers: length (frames at 60 a second), parties, patience (frames) and ramp (how much the
/// arrival rate rises from the first minute to the last). An unknown name -> "normal". Measured, not guessed: the MZ
/// edition's balance probe played 60 shifts per cell on two floors (a 6-seat cafe beside the pass and an 8-seat hall with
/// longer walks); a skilled server earns two stars on normal, and longer walks cost a star. Pure.
/// @param {String} name   "easy", "normal" or "busy"
/// @returns {Struct}
function tsv_difficulty(_name) {
    static _D = {
        easy: { length: 5400, parties: 8, patience: 2400, ramp: 1.4 },
        normal: { length: 6300, parties: 12, patience: 2100, ramp: 1.8 },
        busy: { length: 7200, parties: 15, patience: 1850, ramp: 2.2 }
    };
    return (is_string(_name) && variable_struct_exists(_D, _name)) ? _D[$ _name] : _D.normal;
}

/// @function tsv__idnum(v)
/// @description Internal. A record's numeric id (a struct with id, or a number), else 0.
function tsv__idnum(_v) {
    if (is_struct(_v)) _v = _v[$ "id"];
    return (is_numeric(_v) && !is_nan(_v) && !is_infinity(_v)) ? real(_v) : 0;
}

/// @function tsv_plan(options)
/// @description A night's plan from a seed and your data. Every random choice is made here, once, so the same seed deals
/// the same night. Returns { seed, difficulty, length, parties, menu, seats }; parties are in arrival order, each
/// { id, at (arrival frame), order (menu ids, 1 or 2 dishes), patience (frames) }. No seats or no menu -> no parties.
/// @param {Struct} options   { seed, difficulty ("easy" | "normal" | "busy"), seats: [{ id }], menu: [{ id, price, cook }] }
/// @returns {Struct}
function tsv_plan(_opt) {
    var _e = math_get_epsilon(); math_set_epsilon(0);
    if (!is_struct(_opt)) _opt = {};
    var _seed = tsv__u32(_opt[$ "seed"] ?? 0);
    var _r = tsv_rng((_seed ^ int64($5EA7)) & int64($FFFFFFFF));
    var _dname = _opt[$ "difficulty"];
    if (!is_string(_dname) || array_get_index(tsv_difficulties(), _dname) < 0) _dname = "normal";
    var _D = tsv_difficulty(_dname);
    var _menu = [], _seats = [], _i, _src;
    _src = _opt[$ "menu"]; if (is_array(_src)) for (_i = 0; _i < array_length(_src); _i++) if (is_struct(_src[_i]) && tsv__idnum(_src[_i]) > 0) array_push(_menu, _src[_i]);
    _src = _opt[$ "seats"]; if (is_array(_src)) for (_i = 0; _i < array_length(_src); _i++) if (is_struct(_src[_i]) && tsv__idnum(_src[_i]) > 0) array_push(_seats, _src[_i]);
    var _parties = [], _n = _D.parties;
    var _out = { v: 1, seed: real(_seed), difficulty: _dname, length: _D.length, parties: _parties, menu: _menu, seats: _seats };
    if (array_length(_menu) == 0 || array_length(_seats) == 0) { math_set_epsilon(_e); return _out; }
    // arrival times: the gaps shrink across the shift by the ramp; the last party arrives with at least a patience to spare
    var _last = max(600, _D.length - _D.patience), _w = [], _total = 0;
    for (_i = 0; _i < _n; _i++) {
        var _wi = 1 / (1 + (_D.ramp - 1) * (_i / max(1, _n - 1))) * (0.7 + tsv_rand(_r) * 0.6);
        array_push(_w, _wi); _total += _wi;
    }
    var _t = 120, _ml = array_length(_menu);
    for (_i = 0; _i < _n; _i++) {
        var _dishes = (tsv_rand(_r) < 0.35) ? 2 : 1, _order = [];
        for (var _k = 0; _k < _dishes; _k++) array_push(_order, tsv__idnum(_menu[floor(tsv_rand(_r) * _ml) mod _ml]));
        var _pat = tsv__jsround(_D.patience * (0.85 + tsv_rand(_r) * 0.3));
        array_push(_parties, { id: _i + 1, at: tsv__jsround(_t), order: _order, patience: _pat });
        _t += _w[_i] / _total * (_last - 120);
    }
    math_set_epsilon(_e);
    return _out;
}

/// @function tsv__menu_item(plan, id)
/// @description Internal. The plan's menu entry with that id, else undefined.
function tsv__menu_item(_p, _id) {
    var _m = _p.menu;
    for (var _i = 0; _i < array_length(_m); _i++) if (tsv__idnum(_m[_i]) == _id) return _m[_i];
    return undefined;
}

/// @function tsv_cook_time(plan, id)
/// @description How long the kitchen takes over one dish (frames): the menu entry's cook, else 240. Pure.
/// @returns {Real}
function tsv_cook_time(_p, _id) {
    if (!is_struct(_p) || !is_array(_p[$ "menu"])) return 240;
    var _m = tsv__menu_item(_p, _id), _c = is_struct(_m) ? _m[$ "cook"] : undefined;
    return (is_numeric(_c) && _c > 0) ? _c : 240;
}

/// @function tsv_price_of(plan, id)
/// @description A dish's price from the plan's menu, else 0. Pure.
/// @returns {Real}
function tsv_price_of(_p, _id) {
    if (!is_struct(_p) || !is_array(_p[$ "menu"])) return 0;
    var _m = tsv__menu_item(_p, _id), _c = is_struct(_m) ? _m[$ "price"] : undefined;
    return (is_numeric(_c) && _c > 0) ? _c : 0;
}

// ---------------------------------------------------------------------------------------------------------------
// The shift
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv__is_shift(s)
/// @description Internal. True for a shift made by tsv_shift_new.
function tsv__is_shift(_s) { return is_struct(_s) && is_array(_s[$ "parties"]) && is_struct(_s[$ "plan"]) && is_struct(_s[$ "ledger"]) && is_array(_s[$ "hands"]); }

/// @function tsv_shift_new(plan)
/// @description A fresh shift from a plan. Nothing in it is shared with the plan, so a plan can be replayed. Each party is
/// { id, at, order, patience, left (patience remaining), seat (0 = none yet), phase, got (dishes brought), waited, tip,
/// eat }. phase is "arriving", "waiting" (seated, wants to order), "ordered", "eating", "gone" (paid) or "walked" (out).
/// A non-plan -> undefined.
/// @param {Struct} plan   from tsv_plan
/// @returns {Struct}
function tsv_shift_new(_p) {
    if (!is_struct(_p) || !is_array(_p[$ "parties"]) || !is_array(_p[$ "seats"]) || !is_array(_p[$ "menu"])) return undefined;
    var _s = { v: 1, t: 0, over: false, plan: _p, parties: [], seats: {}, pass: [], kitchen: [], hands: [], events: [],
        ledger: { covers: 0, served: 0, walkouts: 0, takings: 0, tips: 0, dishes: 0, longestWait: 0, streak: 0, bestStreak: 0 } };
    var _i;
    for (_i = 0; _i < array_length(_p.seats); _i++) _s.seats[$ string(tsv__idnum(_p.seats[_i]))] = 0;
    for (_i = 0; _i < array_length(_p.parties); _i++) {
        var _q = _p.parties[_i], _o = [];
        array_copy(_o, 0, _q.order, 0, array_length(_q.order));
        array_push(_s.parties, { id: _q.id, at: _q.at, order: _o, patience: _q.patience, left: _q.patience, seat: 0, phase: "arriving", got: 0, waited: 0, tip: 0, eat: 0 });
    }
    return _s;
}

/// @function tsv_shift_party(shift, id)
/// @description The party with that id, else undefined.
/// @returns {Struct}
function tsv_shift_party(_s, _id) {
    if (!tsv__is_shift(_s)) return undefined;
    for (var _i = 0; _i < array_length(_s.parties); _i++) if (_s.parties[_i].id == _id) return _s.parties[_i];
    return undefined;
}

/// @function tsv_shift_free_seat(shift)
/// @description The first free seat id in the plan's seat order, else 0.
/// @returns {Real}
function tsv_shift_free_seat(_s) {
    if (!tsv__is_shift(_s)) return 0;
    var _ids = _s.plan.seats;
    for (var _i = 0; _i < array_length(_ids); _i++) { var _id = tsv__idnum(_ids[_i]); if (_s.seats[$ string(_id)] == 0) return _id; }
    return 0;
}

/// @function tsv__everyone_done(s)
/// @description Internal. Every party has paid or walked out.
function tsv__everyone_done(_s) {
    for (var _i = 0; _i < array_length(_s.parties); _i++) { var _ph = _s.parties[_i].phase; if (_ph != "gone" && _ph != "walked") return false; }
    return true;
}

/// @function tsv__walk(s, q)
/// @description Internal. A party runs out of patience: it walks out, and every dish of theirs in the kitchen, at the
/// pass or in the server's hands is wasted.
function tsv__walk(_s, _q) {
    _q.phase = "walked"; if (_q.seat != 0) _s.seats[$ string(_q.seat)] = 0;
    _s.ledger.walkouts++; _s.ledger.streak = 0;
    var _i;
    for (_i = array_length(_s.kitchen) - 1; _i >= 0; _i--) if (_s.kitchen[_i].party == _q.id) array_delete(_s.kitchen, _i, 1);
    for (_i = array_length(_s.pass) - 1; _i >= 0; _i--) if (_s.pass[_i].party == _q.id) array_delete(_s.pass, _i, 1);
    for (_i = array_length(_s.hands) - 1; _i >= 0; _i--) if (_s.hands[_i].party == _q.id) array_delete(_s.hands, _i, 1);
    array_push(_s.events, { type: "walked", party: _q.id, seat: _q.seat });
}

/// @function tsv_shift_tick(shift, [frames])
/// @description Advance the shift by n frames (default 1). Arrivals take a free seat (a party with no seat waits at the
/// door, and its patience runs there too); patience runs down while a party waits for the server or the food (not while
/// eating); the kitchen finishes dishes onto the pass; a party out of patience walks out; one that has eaten leaves and
/// pays. The events of THIS call are left in shift.events (the array is reused: read it before the next tick): each is
/// { type: "seated" | "ready" | "walked" | "paid" | "close", party, seat, item, tip }. Returns the number of events.
/// @returns {Real}
function tsv_shift_tick(_s, _n = 1) {
    if (!tsv__is_shift(_s)) return 0;
    array_resize(_s.events, 0);
    if (_s.over) return 0;
    var _e = math_get_epsilon(); math_set_epsilon(0);
    _n = (is_numeric(_n) && !is_nan(_n) && !is_infinity(_n)) ? max(1, floor(_n)) : 1;
    _n = min(_n, 100000);
    for (var _f = 0; _f < _n; _f++) {
        _s.t++;
        var _P = _s.parties, _i;
        for (_i = 0; _i < array_length(_P); _i++) {
            var _q = _P[_i];
            if (_q.phase == "arriving" && _q.at <= _s.t) {
                if (_q.seat == 0) {
                    var _seat = tsv_shift_free_seat(_s);
                    if (_seat != 0) { _q.seat = _seat; _s.seats[$ string(_seat)] = _q.id; _q.phase = "waiting"; array_push(_s.events, { type: "seated", party: _q.id, seat: _seat }); }
                }
                if (_q.phase == "arriving") { _q.left--; _q.waited++; if (_q.left <= 0) tsv__walk(_s, _q); }
            } else if (_q.phase == "waiting" || _q.phase == "ordered") {
                _q.left--; _q.waited++; if (_q.waited > _s.ledger.longestWait) _s.ledger.longestWait = _q.waited;
                if (_q.left <= 0) tsv__walk(_s, _q);
            } else if (_q.phase == "eating") {
                _q.eat--;
                if (_q.eat <= 0) { _q.phase = "gone"; _s.seats[$ string(_q.seat)] = 0; array_push(_s.events, { type: "paid", party: _q.id, seat: _q.seat, tip: _q.tip }); }
            }
        }
        for (_i = 0; _i < array_length(_s.kitchen); _i++) {
            var _k = _s.kitchen[_i];
            if (_k.ready > 0) { _k.ready--; if (_k.ready == 0) { array_push(_s.pass, { item: _k.item, party: _k.party }); array_push(_s.events, { type: "ready", item: _k.item, party: _k.party }); } }
        }
        for (_i = array_length(_s.kitchen) - 1; _i >= 0; _i--) if (_s.kitchen[_i].ready == 0) array_delete(_s.kitchen, _i, 1);
        if (_s.t >= _s.plan.length && tsv__everyone_done(_s)) { _s.over = true; array_push(_s.events, { type: "close" }); break; }
        if (_s.t >= _s.plan.length * 2) { _s.over = true; array_push(_s.events, { type: "close" }); break; }   // hard stop: nobody waits forever
    }
    math_set_epsilon(_e);
    return array_length(_s.events);
}

/// @function tsv_shift_take_order(shift, party_id)
/// @description The server takes a seated party's order: it goes to the kitchen, one dish after another. Returns true when
/// taken (the party was seated and had not ordered).
/// @returns {Bool}
function tsv_shift_take_order(_s, _pid) {
    var _q = tsv_shift_party(_s, _pid);
    if (!is_struct(_q) || _q.phase != "waiting" || _s.over) return false;
    _q.phase = "ordered";
    var _cook = 0;
    for (var _i = 0; _i < array_length(_q.order); _i++) { _cook += tsv_cook_time(_s.plan, _q.order[_i]); array_push(_s.kitchen, { item: _q.order[_i], party: _q.id, ready: _cook + TSV_ORDER_TAKE }); }
    return true;
}

/// @function tsv_shift_pick_up(shift, pass_index)
/// @description The server picks a finished dish up from the pass (a free hand needed: TSV_HANDS is 2). pass_index is an
/// index into shift.pass. Returns true when picked up.
/// @returns {Bool}
function tsv_shift_pick_up(_s, _ix) {
    if (!tsv__is_shift(_s) || _s.over || array_length(_s.hands) >= TSV_HANDS) return false;
    if (!is_numeric(_ix) || is_nan(_ix) || _ix < 0 || _ix >= array_length(_s.pass) || _ix != floor(_ix)) return false;
    var _d = _s.pass[_ix];
    array_delete(_s.pass, _ix, 1); array_push(_s.hands, _d);
    return true;
}

/// @function tsv_shift_deliver(shift, party_id)
/// @description The server hands a party what they ordered. Only a dish on ITS OWN ticket counts (a dish for another
/// table stays in the server's hand). When the last of a party's dishes lands they eat, and pay when they leave: the
/// price of what they ate, and a tip for the patience they had left. Returns the dishes delivered (0 = nothing of theirs).
/// @returns {Real}
function tsv_shift_deliver(_s, _pid) {
    var _q = tsv_shift_party(_s, _pid);
    if (!is_struct(_q) || _q.phase != "ordered" || _s.over) return 0;
    var _e = math_get_epsilon(); math_set_epsilon(0);
    var _n = 0, _i;
    for (_i = array_length(_s.hands) - 1; _i >= 0; _i--) if (_s.hands[_i].party == _q.id) { array_delete(_s.hands, _i, 1); _q.got++; _n++; _s.ledger.dishes++; }
    if (_n > 0 && _q.got >= array_length(_q.order)) {
        var _bill = 0;
        for (var _k = 0; _k < array_length(_q.order); _k++) _bill += tsv_price_of(_s.plan, _q.order[_k]);
        var _frac = max(0, _q.left / _q.patience), _tip = floor(_bill * (0.05 + 0.35 * _frac));
        _q.tip = _tip; _q.phase = "eating"; _q.eat = TSV_EAT;
        _s.ledger.served++; _s.ledger.covers += array_length(_q.order); _s.ledger.takings += _bill; _s.ledger.tips += _tip;
        _s.ledger.streak++; if (_s.ledger.streak > _s.ledger.bestStreak) _s.ledger.bestStreak = _s.ledger.streak;
    }
    math_set_epsilon(_e);
    return _n;
}

/// @function tsv_shift_put_down(shift, hand_index)
/// @description Put a carried dish back on the pass (so the server can free a hand). Returns true when put down.
/// @returns {Bool}
function tsv_shift_put_down(_s, _ix) {
    if (!tsv__is_shift(_s) || _s.over) return false;
    if (!is_numeric(_ix) || is_nan(_ix) || _ix < 0 || _ix >= array_length(_s.hands) || _ix != floor(_ix)) return false;
    var _d = _s.hands[_ix];
    array_delete(_s.hands, _ix, 1); array_push(_s.pass, _d);
    return true;
}

/// @function tsv_shift_score(shift)
/// @description The ledger and a verdict: stars 0..3 from the share of parties served and the tips earned against the most
/// they could have been (every party served with full patience). Returns { served, walkouts, parties, covers, takings,
/// tips, tipShare, longestWait, bestStreak, stars, grade }. A non-shift -> undefined.
/// @returns {Struct}
function tsv_shift_score(_s) {
    if (!tsv__is_shift(_s)) return undefined;
    var _e = math_get_epsilon(); math_set_epsilon(0);
    var _L = _s.ledger, _n = array_length(_s.parties), _best = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _bill = 0, _o = _s.parties[_i].order;
        for (var _k = 0; _k < array_length(_o); _k++) _bill += tsv_price_of(_s.plan, _o[_k]);
        _best += floor(_bill * 0.4);
    }
    var _servedShare = (_n > 0) ? _L.served / _n : 0, _tipShare = (_best > 0) ? _L.tips / _best : 0;
    var _stars = (_servedShare >= 1 && _tipShare >= 0.6) ? 3 : ((_servedShare >= 0.8 && _tipShare >= 0.35) ? 2 : ((_servedShare >= 0.5) ? 1 : 0));
    static _grades = ["A rough night", "A fair night", "A good night", "A full house"];
    var _out = { served: _L.served, walkouts: _L.walkouts, parties: _n, covers: _L.covers, takings: _L.takings, tips: _L.tips,
        tipShare: tsv__jsround(_tipShare * 100) / 100, longestWait: _L.longestWait, bestStreak: _L.bestStreak, stars: _stars, grade: _grades[_stars] };
    math_set_epsilon(_e);
    return _out;
}
