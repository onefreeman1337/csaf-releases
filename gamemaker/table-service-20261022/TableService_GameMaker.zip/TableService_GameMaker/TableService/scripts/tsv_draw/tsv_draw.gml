/// tsv_draw.gml - every picture Table Service shows, drawn in code: dishes READ FROM THEIR NAMES (19 kinds of dish and
/// drink plus a plated fallback, coloured by the words in the name), generated diners (skin, hair, hat, coat, shirt and one
/// extra from a seed, seated or walking, facing four ways, outlined), the order ticket, the service bell, the patience
/// candle, the pass, floating tags, the server's tray, coins, stars, the ledger page, the opening banner, and the round
/// clothed tables and chairs the diners sit at. Loads no image file.
///
/// Table Service - A Restaurant Serving Minigame for GameMaker.
/// Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.
///
/// The RPG Maker MZ edition's ServiceDraw.js, ported through the canvas kit (tsv_canvas) call for call. Named additions
/// over the MZ edition: the tables and chairs (MZ drew those with the buyer's map tiles), four tablecloths, and the bake
/// layer at the foot of this file (every picture is drawn ONCE into a cached sprite; nothing here runs per frame).
/// Public functions (each documented below): tsv_dish_look, tsv_dish_is_drink, tsv_dish_cook_frames, tsv_dish_forms,
/// tsv_draw_dish, tsv_diner_look, tsv_server_look, tsv_draw_figure, tsv_ticket_height, tsv_draw_ticket, tsv_draw_bell,
/// tsv_draw_wax, tsv_draw_flame, tsv_draw_holder, tsv_draw_puff, tsv_draw_pass, tsv_draw_tag, tsv_draw_hud,
/// tsv_draw_coins, tsv_draw_star, tsv_draw_ledger, tsv_draw_banner, tsv_draw_table, tsv_draw_chair, tsv_bake,
/// tsv_draw_premul, tsv_dish_sprite, tsv_diner_sprite, tsv_cache_clear.

#macro TSV_TAU 6.283185307179586
#macro TSV_TICKET_W 120

// ---------------------------------------------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv__is_ctx(ctx)
/// @description Internal. True for a drawing context made by tsv_cx_create.
function tsv__is_ctx(_c) { return is_struct(_c) && is_array(_c[$ "m"]) && is_array(_c[$ "clips"]) && is_array(_c[$ "stack"]); }

/// @function tsv__fin(v, fallback)
/// @description Internal. v when it is a finite number, else the fallback.
function tsv__fin(_v, _d) { return (is_numeric(_v) && !is_nan(_v) && !is_infinity(_v)) ? _v : _d; }

/// @function tsv__flag(v)
/// @description Internal. A true / false argument: a bool or a number is read as one; anything else (a string, a struct,
/// undefined) is false rather than a crash ("unable to convert string to bool", found by the attack harness).
function tsv__flag(_v) { return (is_bool(_v) || is_numeric(_v)) ? (_v ? true : false) : false; }

/// @function tsv__hexdig(ch)
/// @description Internal. One hex digit's value (0 for anything else).
function tsv__hexdig(_ch) { var _o = ord(string_lower(_ch)); if (_o >= 48 && _o <= 57) return _o - 48; if (_o >= 97 && _o <= 102) return _o - 87; return 0; }

/// @function tsv__hex(text)
/// @description Internal. "#rrggbb" as [r, g, b]; an array passes through; anything else is black.
function tsv__hex(_s) {
    if (is_array(_s)) return _s;
    if (!is_string(_s) || string_length(_s) != 7) return [0, 0, 0];
    var _o = [0, 0, 0];
    for (var _i = 0; _i < 3; _i++) _o[_i] = tsv__hexdig(string_char_at(_s, 2 + _i * 2)) * 16 + tsv__hexdig(string_char_at(_s, 3 + _i * 2));
    return _o;
}

/// @function tsv__shade(rgb, k)
/// @description Internal. The MZ shade(): lighten (k > 0) or darken (k < 0) by an ABSOLUTE step per channel, so a light
/// colour and a dark one move by the same amount. Returns [r, g, b].
function tsv__shade(_c, _k) {
    _c = tsv__hex(_c);
    return [clamp(floor(_c[0] + _k + 0.5), 0, 255), clamp(floor(_c[1] + _k + 0.5), 0, 255), clamp(floor(_c[2] + _k + 0.5), 0, 255)];
}

/// @function tsv__fill(ctx, rgb, a)
/// @description Internal. Set a flat fill.
function tsv__fill(_c, _rgb, _a = 1) { _c.fill = tsv_cx_solid(tsv__hex(_rgb), _a); }

/// @function tsv__stroke(ctx, rgb, a, w)
/// @description Internal. Set a flat stroke and its width.
function tsv__stroke(_c, _rgb, _a, _w) { _c.stroke = tsv_cx_solid(tsv__hex(_rgb), _a); _c.lw = _w; }

/// @function tsv__ell(ctx, x, y, rx, ry, rot)
/// @description Internal. The MZ ell(): a new path holding one whole ellipse.
function tsv__ell(_c, _x, _y, _rx, _ry, _rot = 0) { tsv_cx_begin(_c); tsv_cx_ellipse(_c, _x, _y, max(0.1, _rx), max(0.1, _ry), _rot, 0, TSV_TAU); }

/// @function tsv__rr(ctx, x, y, w, h, r)
/// @description Internal. The MZ rr(): a new path holding one rounded rectangle.
function tsv__rr(_c, _x, _y, _w, _h, _r) { tsv_cx_begin(_c); tsv_cx_round_rect(_c, _x, _y, _w, _h, max(0, min(_r, _w / 2, _h / 2))); }

/// @function tsv__seg(ctx, x0, y0, x1, y1)
/// @description Internal. Stroke one segment with the current stroke.
function tsv__seg(_c, _x0, _y0, _x1, _y1) { tsv_cx_begin(_c); tsv_cx_move(_c, _x0, _y0); tsv_cx_line(_c, _x1, _y1); tsv_cx_stroke(_c); }

/// @function tsv__food(ctx, x, y, r, pal)
/// @description Internal. The MZ food(): a lit radial gradient over a [light, dark] pair.
function tsv__food(_c, _x, _y, _r, _pal) {
    var _g = tsv_cx_radial(_c, _x - _r * 0.3, _y - _r * 0.3, _r * 0.05, _x, _y, _r * 1.05);
    tsv_cx_stop(_g, 0, tsv__shade(_pal[0], 26)); tsv_cx_stop(_g, 0.55, tsv__hex(_pal[0])); tsv_cx_stop(_g, 1, tsv__hex(_pal[1]));
    return _g;
}

/// @function tsv__outline(ctx, w)
/// @description Internal. The MZ outline(): stroke the current path in a warm dark line.
function tsv__outline(_c, _w) { tsv__stroke(_c, [40, 20, 5], 0.55, max(0.8, _w)); tsv_cx_stroke(_c); }

/// @function tsv__steam(ctx, x, y, r, n)
/// @description Internal. n wisps of steam rising from (x, y).
function tsv__steam(_c, _x, _y, _r, _n) {
    tsv__stroke(_c, [255, 255, 255], 0.6, max(1, _r * 0.06)); _c.cap = 1;
    for (var _s = 0; _s < _n; _s++) {
        var _sx = _x - _r * 0.22 + _s * _r * 0.22;
        tsv_cx_begin(_c); tsv_cx_move(_c, _sx, _y); tsv_cx_bezier(_c, _sx - _r * 0.14, _y - _r * 0.22, _sx + _r * 0.14, _y - _r * 0.38, _sx, _y - _r * 0.6); tsv_cx_stroke(_c);
    }
    _c.cap = 0;
}

/// @function tsv__text(ctx, text, x, y, px, rgb, alpha, align, face)
/// @description Internal. One line of type with its MIDDLE on y (the canvas textBaseline "middle"), left-aligned at x,
/// centred on it ("center") or right-aligned to it ("right"). Returns the width.
function tsv__text(_c, _s, _x, _y, _px, _rgb, _a, _align, _face) {
    var _t = string(_s), _adv = tsv_text_advance(_face), _w = 0, _i, _o;
    for (_i = 1; _i <= string_length(_t); _i++) { _o = ord(string_char_at(_t, _i)); if (_o >= 32 && _o <= 126) _w += _adv[_o - 32] * _px; }
    var _pen = (_align == "center") ? _x - _w / 2 : ((_align == "right") ? _x - _w : _x), _base = _y + _px * 0.35;
    _c.fill = tsv_cx_solid(tsv__hex(_rgb), _a);
    for (_i = 1; _i <= string_length(_t); _i++) {
        var _ch = string_char_at(_t, _i); _o = ord(_ch);
        tsv_cx_glyph(_c, _ch, _pen, _base, _px, _face);
        if (_o >= 32 && _o <= 126) _pen += _adv[_o - 32] * _px;
    }
    return _w;
}

/// @function tsv__fit(text, maxw, px, face)
/// @description Internal. The MZ fitText(): the largest size <= px (down to 8) at which the line fits maxw.
function tsv__fit(_s, _maxw, _px, _face) {
    while (_px > 8 && tsv_text_width(_s, _px, _face) > _maxw) _px--;
    return _px;
}

/// @function tsv__text_outlined(ctx, text, x, y, px, rgb, ink, align, face)
/// @description Internal. Type with a dark ring (the MZ strokeText + fillText), for a figure laid over a busy ground.
function tsv__text_outlined(_c, _s, _x, _y, _px, _rgb, _ink, _align, _face) {
    for (var _k = 0; _k < 8; _k++) { var _a = _k * pi / 4; tsv__text(_c, _s, _x + cos(_a) * 1.4, _y + sin(_a) * 1.4, _px, _ink, 0.85, _align, _face); }
    return tsv__text(_c, _s, _x, _y, _px, _rgb, 1, _align, _face);
}

/// @function tsv__ink()
/// @description Internal. The MZ INK, a warm near-black.
function tsv__ink() { static _k = [43, 29, 18]; return _k; }

// ---------------------------------------------------------------------------------------------------------------
// Dishes, read from the name
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv__forms()
/// @description Internal. What a dish IS, from the words of its name: the first matching row wins, so drinks are tested
/// before foods ("Herbal Tea" is a cup, not a salad) and pies before fruit ("Apple Pie" is a pie). The MZ table.
function tsv__forms() {
    static _F = [
        ["bottle", ["potion", "elixir", "tonic", "draught", "remedy", "antidote", "serum", "philter", "essence", "vial", "drop", "phial", "cure"]],
        ["mug", ["ale", "beer", "mead", "cider", "stout", "lager", "grog", "porter", "bitter"]],
        ["cup", ["tea", "coffee", "cocoa", "milk", "latte", "chai", "infusion"]],
        ["glass", ["wine", "champagne", "sherry", "brandy", "cocktail", "nectar", "juice", "water", "lemonade", "punch", "spirit", "liqueur", "sake"]],
        ["soup", ["soup", "broth", "chowder", "bisque", "consomme", "gazpacho"]],
        ["stew", ["stew", "curry", "porridge", "gruel", "chili", "goulash", "hotpot", "pottage", "casserole", "oatmeal"]],
        ["pie", ["pie", "pasty", "quiche", "pot", "pie", "cobbler"]],
        ["cake", ["cake", "tart", "pudding", "cookie", "biscuit", "pastry", "scone", "muffin", "crepe", "pancake", "waffle", "dessert", "sweet", "candy", "custard", "eclair"]],
        ["bread", ["bread", "loaf", "bun", "roll", "baguette", "toast", "bagel", "sandwich", "croissant", "flatbread", "biscuit"]],
        ["fish", ["fish", "trout", "salmon", "cod", "eel", "carp", "bass", "herring", "sardine", "tuna", "mackerel", "perch", "pike", "snapper", "catch"]],
        ["roast", ["chicken", "roast", "turkey", "duck", "goose", "pheasant", "fowl", "drumstick", "wing", "quail", "hen"]],
        ["sausage", ["sausage", "wurst", "frank", "banger"]],
        ["steak", ["steak", "beef", "pork", "ham", "lamb", "mutton", "venison", "boar", "meat", "chop", "rib", "bacon", "jerky", "cutlet", "brisket"]],
        ["noodles", ["noodle", "pasta", "spaghetti", "ramen", "udon", "macaroni"]],
        ["rice", ["rice", "risotto", "pilaf", "onigiri", "sushi"]],
        ["egg", ["egg", "omelet", "omelette"]],
        ["cheese", ["cheese", "brie", "cheddar"]],
        ["salad", ["salad", "herb", "greens", "leaf", "leaves", "cabbage", "lettuce", "spinach", "weed", "sprout"]],
        ["fruit", ["apple", "berry", "berries", "grape", "pear", "peach", "plum", "fruit", "cherry", "orange", "banana", "melon", "fig"]]
    ];
    return _F;
}

/// @function tsv__colours()
/// @description Internal. The words that colour a dish, first row wins (the MZ table).
function tsv__colours() {
    static _C = [
        ["amber", ["honey", "golden", "gold", "mead", "ale", "beer", "amber", "caramel", "syrup"]],
        ["orange", ["pumpkin", "carrot", "orange", "squash", "curry", "apricot", "sweet", "potato"]],
        ["red", ["tomato", "red", "fire", "apple", "cherry", "strawberry", "beet", "chili", "rose", "flame", "blood", "raspberry"]],
        ["purple", ["berry", "grape", "plum", "wine", "purple", "blueberry", "violet", "lavender"]],
        ["green", ["mint", "herb", "green", "pea", "leaf", "salad", "cabbage", "spinach", "lime", "matcha", "forest", "moss"]],
        ["blue", ["blue", "ice", "frost", "magic", "mana", "sky", "water", "sea", "storm"]],
        ["brown", ["mushroom", "brown", "beef", "stew", "bread", "coffee", "cocoa", "chocolate", "nut", "walnut", "rye", "stout", "porter", "boar", "gravy"]],
        ["cream", ["cream", "milk", "rice", "white", "vanilla", "cheese", "egg", "potato", "porridge", "oat"]],
        ["yellow", ["lemon", "yellow", "banana", "corn", "butter", "saffron"]],
        ["dark", ["black", "dark", "shadow", "ink", "night"]],
        ["pink", ["pink", "peach", "salmon", "ham", "shrimp"]],
        ["gold", ["elixir", "royal", "golden"]]
    ];
    return _C;
}

/// @function tsv__palette(name)
/// @description Internal. A food colour pair [light, dark] by name (the MZ PALETTE), else undefined.
function tsv__palette(_n) {
    static _P = {
        amber: [[232, 176, 74], [154, 98, 20]], orange: [[236, 138, 58], [164, 80, 26]], red: [[210, 74, 54], [126, 30, 20]], purple: [[138, 74, 160], [74, 30, 94]],
        green: [[124, 180, 74], [62, 106, 28]], blue: [[90, 142, 216], [36, 64, 126]], brown: [[154, 100, 58], [86, 50, 26]], cream: [[240, 226, 188], [180, 158, 112]],
        yellow: [[240, 208, 74], [168, 136, 24]], dark: [[74, 58, 74], [30, 20, 30]], pink: [[236, 154, 154], [164, 84, 90]], gold: [[242, 204, 90], [160, 120, 24]],
        roast: [[204, 122, 54], [106, 48, 14]]
    };
    return (is_string(_n) && variable_struct_exists(_P, _n)) ? _P[$ _n] : undefined;
}

/// @function tsv__rims()
/// @description Internal. The five plate rims (the MZ RIMS).
function tsv__rims() { static _R = [[47, 95, 138], [138, 47, 58], [58, 122, 74], [168, 132, 42], [74, 74, 74]]; return _R; }

/// @function tsv__is_lower(ch)
/// @description Internal. One character a..z.
function tsv__is_lower(_ch) { if (_ch == "") return false; var _o = ord(_ch); return _o >= 97 && _o <= 122; }

/// @function tsv__match_word(name, words)
/// @description Internal. The first of words found in the (lower-case) name as a WHOLE word, a plural "s" or "es"
/// allowed; else undefined. A word-START match read "Cheese Board" as boar meat in the MZ edition, so the word must END
/// too.
function tsv__match_word(_n, _words) {
    var _L = string_length(_n);
    for (var _i = 0; _i < array_length(_words); _i++) {
        var _w = _words[_i], _wl = string_length(_w);
        for (var _at = 1; _at + _wl - 1 <= _L; _at++) {
            if (string_copy(_n, _at, _wl) != _w) continue;
            var _pre = (_at == 1) || !tsv__is_lower(string_char_at(_n, _at - 1));
            var _rest = string_copy(_n, _at + _wl, _L);
            var _r1 = string_char_at(_rest, 1), _r2 = string_char_at(_rest, 2), _r3 = string_char_at(_rest, 3);
            var _post = (_rest == "") || !tsv__is_lower(_r1) || (_r1 == "s" && !tsv__is_lower(_r2)) || (_r1 == "e" && _r2 == "s" && !tsv__is_lower(_r3));
            if (_pre && _post) return _w;
        }
    }
    return undefined;
}

/// @function tsv_dish_forms()
/// @description Every dish form, in the order they are tested, then the fallback "plate": bottle, mug, cup, glass, soup,
/// stew, pie, cake, bread, fish, roast, sausage, steak, noodles, rice, egg, cheese, salad, fruit, plate. Pure.
/// @returns {Array<String>}
function tsv_dish_forms() {
    static _ids = ["bottle", "mug", "cup", "glass", "soup", "stew", "pie", "cake", "bread", "fish", "roast", "sausage", "steak", "noodles", "rice", "egg", "cheese", "salad", "fruit", "plate"];
    return _ids;
}

/// @function tsv_dish_look(dish)
/// @description A dish's look from its NAME: its form (what it is and what it is served in), its colours, and the plate's
/// rim. "Pumpkin Soup" is a bowl the colour of pumpkin, "Pale Ale" a tankard with a head of foam, "Grilled Trout" a
/// whole fish. About 170 words are known; a name it does not know still gets a dish, the same one every time. A dish
/// may also be a struct { name, form, colour }: a form or colour given there wins over the words. Pure.
/// Returns { form, food: [[r,g,b] light, [r,g,b] dark], colour, rim: [r,g,b], rimIndex, known, word, shape (0..2) }.
/// @param {String|Struct} dish
/// @returns {Struct}
function tsv_dish_look(_dish) {
    var _name = is_struct(_dish) ? _dish[$ "name"] : _dish;
    if (is_undefined(_name)) _name = "";
    var _n = string_lower(is_string(_name) ? _name : string(_name)), _h = int64(tsv_hash_string(_n)), _form = undefined, _word = undefined, _i;
    if (is_struct(_dish)) { var _tf = _dish[$ "form"]; if (is_string(_tf) && array_get_index(tsv_dish_forms(), string_lower(_tf)) >= 0) { _form = string_lower(_tf); _word = "tag"; } }
    var _F = tsv__forms();
    for (_i = 0; _i < array_length(_F) && is_undefined(_form); _i++) { var _w = tsv__match_word(_n, _F[_i][1]); if (!is_undefined(_w)) { _form = _F[_i][0]; _word = _w; } }
    var _known = !is_undefined(_form);
    static _fallback = ["plate", "stew", "pie", "roast", "bread"];
    if (!_known) _form = _fallback[real(_h mod 5)];
    var _col = undefined, _given = false;
    if (is_struct(_dish)) { var _tc = _dish[$ "colour"]; if (is_string(_tc) && _tc != "") { _given = true; if (!is_undefined(tsv__palette(string_lower(_tc)))) _col = string_lower(_tc); } }
    var _C = tsv__colours();
    for (_i = 0; _i < array_length(_C) && is_undefined(_col); _i++) if (!is_undefined(tsv__match_word(_n, _C[_i][1]))) _col = _C[_i][0];
    var _fromWords = !is_undefined(_col);
    static _fdef = { bottle: "", mug: "amber", cup: "brown", glass: "red", soup: "orange", stew: "brown", pie: "red", cake: "pink", bread: "amber", fish: "cream", roast: "roast", sausage: "brown", steak: "brown", noodles: "cream", rice: "cream", egg: "yellow", cheese: "yellow", salad: "green", fruit: "red", plate: "orange" };
    static _five = ["red", "blue", "green", "purple", "amber"];
    static _seven = ["red", "blue", "green", "purple", "gold", "orange", "pink"];
    if (is_undefined(_col)) { var _d = _fdef[$ _form]; _col = (is_string(_d) && _d != "") ? _d : _five[real((_h >> 6) mod 5)]; }
    // a bottle nobody coloured takes its colour from the name; its SHAPE always does, so two potions of one colour differ
    if (_form == "bottle" && !_fromWords && !_given) _col = _seven[real((_h >> 6) mod 7)];
    var _ri = (_h >> 4) mod 5, _rims = tsv__rims();
    return { form: _form, food: tsv__palette(_col), colour: _col, rim: _rims[real(_ri)], rimIndex: real(_ri), known: _known, word: _word,
        shape: real(int64(tsv_hash_string("shape:" + _n)) mod 3) };
}

/// @function tsv_dish_is_drink(form)
/// @description Is this form served as a drink (a vessel on its own, no plate)? Pure.
/// @returns {Bool}
function tsv_dish_is_drink(_f) { return _f == "bottle" || _f == "mug" || _f == "cup" || _f == "glass"; }

/// @function tsv_dish_cook_frames(form)
/// @description Rough kitchen time for a form, in frames: a drink is poured (150), a bowl ladled (220), a plate cooked
/// (320). Pure.
/// @returns {Real}
function tsv_dish_cook_frames(_f) {
    if (tsv_dish_is_drink(_f)) return 150;
    return (_f == "soup" || _f == "stew" || _f == "salad" || _f == "bread" || _f == "fruit" || _f == "cheese") ? 220 : 320;
}

/// @function tsv__plate(ctx, x, y, r, rim)
/// @description Internal. A plate seen from above at a slant, with a coloured rim band.
function tsv__plate(_c, _x, _y, _r, _rim) {
    tsv__fill(_c, [0, 0, 0], 0.3); tsv__ell(_c, _x + _r * 0.07, _y + _r * 0.14, _r, _r * 0.6); tsv_cx_fill(_c);
    tsv__fill(_c, "#f7f2e6"); tsv__ell(_c, _x, _y, _r, _r * 0.6); tsv_cx_fill(_c);
    tsv__fill(_c, "#e6dcc6"); tsv__ell(_c, _x, _y + _r * 0.04, _r * 0.7, _r * 0.4); tsv_cx_fill(_c);
    tsv__stroke(_c, _rim, 1, max(1, _r * 0.08)); tsv__ell(_c, _x, _y, _r * 0.86, _r * 0.51); tsv_cx_stroke(_c);
    tsv__stroke(_c, [90, 70, 50], 0.55, 1); tsv__ell(_c, _x, _y, _r, _r * 0.6); tsv_cx_stroke(_c);
}

/// @function tsv_draw_dish(ctx, x, y, r, dish, hot, eaten)
/// @description Draw a dish as what its name says it is, centred on (x, y) at size r (a plate's radius), into a canvas-kit
/// context. hot = steam; eaten = what is left (crumbs and a fork, a bone, an empty bowl, a drained glass). Returns the
/// look (tsv_dish_look). Prefer tsv_dish_sprite, which bakes this once and caches it.
/// @returns {Struct}
function tsv_draw_dish(_c, _x, _y, _r, _dish, _hot = false, _eaten = false) {
    var _L = tsv_dish_look(_dish);
    if (!tsv__is_ctx(_c)) return _L;
    _hot = tsv__flag(_hot); _eaten = tsv__flag(_eaten);
    _x = tsv__fin(_x, 0); _y = tsv__fin(_y, 0); _r = clamp(tsv__fin(_r, 16), 1, 1024);
    var _p = _L.food, _lw = _r * 0.05;
    tsv_cx_save(_c);
    switch (_L.form) {
        case "bottle": tsv__bottle(_c, _x, _y, _r, _p, _eaten, _L.shape); break;
        case "mug": tsv__mug(_c, _x, _y, _r, _p, _eaten); break;
        case "cup": tsv__cup(_c, _x, _y, _r, _p, _eaten, _hot); break;
        case "glass": tsv__glass(_c, _x, _y, _r, _p, _eaten); break;
        case "soup": case "stew": tsv__bowl(_c, _x, _y, _r, _p, _L.rim, _eaten, _L.form == "stew", _hot); break;
        default:
            tsv__plate(_c, _x, _y, _r, _L.rim);
            if (_eaten) tsv__leftovers(_c, _x, _y, _r, _L.form, _p);
            else {
                tsv__on_plate(_c, _L.form, _x, _y, _r, _p, _lw);
                if (_hot && _L.form != "salad" && _L.form != "fruit" && _L.form != "cheese" && _L.form != "cake") tsv__steam(_c, _x, _y - _r * 0.35, _r, 3);
            }
    }
    tsv_cx_restore(_c);
    return _L;
}

/// @function tsv__leftovers(ctx, x, y, r, form, pal)
/// @description Internal. Crumbs, a bone for meat and fish, the fork left on the plate.
function tsv__leftovers(_c, _x, _y, _r, _form, _p) {
    tsv__fill(_c, _p[1]);
    for (var _i = 0; _i < 6; _i++) { var _a = _i * 1.9 + 0.4, _d = _r * (0.18 + (_i mod 3) * 0.14); tsv_cx_begin(_c); tsv_cx_arc(_c, _x + cos(_a) * _d, _y + sin(_a) * _d * 0.55, max(0.8, _r * 0.05), 0, TSV_TAU); tsv_cx_fill(_c); }
    if (_form == "roast" || _form == "fish" || _form == "steak") { tsv__stroke(_c, "#efe6d0", 1, max(1, _r * 0.08)); _c.cap = 1; tsv__seg(_c, _x - _r * 0.3, _y + _r * 0.05, _x + _r * 0.25, _y - _r * 0.08); _c.cap = 0; }
    tsv__stroke(_c, "#8a8a8a", 1, max(1, _r * 0.05)); tsv__seg(_c, _x + _r * 0.55, _y + _r * 0.3, _x + _r * 0.78, _y - _r * 0.18);
}

/// @function tsv__leaf(ctx, x, y, rx, ry, rot, rgb)
/// @description Internal. A small filled oval (a sprig, a pickle, a tomato).
function tsv__leaf(_c, _x, _y, _rx, _ry, _rot, _rgb) { tsv__fill(_c, _rgb); tsv__ell(_c, _x, _y, _rx, _ry, _rot); tsv_cx_fill(_c); }

/// @function tsv__on_plate(ctx, form, x, y, r, pal, lw)
/// @description Internal. The food on a plate, by form (the MZ DISHES table, call for call).
function tsv__on_plate(_c, _form, _x, _y, _r, _p, _lw) {
    static _holes = [[-0.2, -0.12, 0.06], [0.0, -0.18, 0.04], [-0.3, 0.06, 0.05], [0.05, 0.1, 0.04]];
    static _fp = [[-0.28, 0.05], [0.26, 0.08], [0, -0.16]];
    var _k, _s;
    switch (_form) {
        case "roast":   // a roast bird on its back: a glazed breast and two legs raised, white bone ends in paper frills
            for (_s = -1; _s <= 1; _s += 2) {
                _c.fill = tsv__food(_c, _x + _s * _r * 0.34, _y - _r * 0.3, _r * 0.22, _p); tsv__ell(_c, _x + _s * _r * 0.3, _y - _r * 0.26, _r * 0.2, _r * 0.13, _s * -0.9); tsv_cx_fill(_c); tsv__outline(_c, _lw);
                tsv__stroke(_c, "#f4ecd8", 1, max(1.2, _r * 0.08)); _c.cap = 1; tsv__seg(_c, _x + _s * _r * 0.42, _y - _r * 0.38, _x + _s * _r * 0.56, _y - _r * 0.56); _c.cap = 0;
                tsv__fill(_c, "#fbfaf2"); tsv__ell(_c, _x + _s * _r * 0.58, _y - _r * 0.6, _r * 0.08, _r * 0.07); tsv_cx_fill(_c); tsv__outline(_c, _lw * 0.6);
            }
            _c.fill = tsv__food(_c, _x, _y - _r * 0.05, _r * 0.5, _p); tsv__ell(_c, _x, _y - _r * 0.02, _r * 0.5, _r * 0.33); tsv_cx_fill(_c); tsv__outline(_c, _lw);
            tsv__stroke(_c, [90, 40, 10], 0.5, max(0.8, _r * 0.04)); tsv_cx_begin(_c); tsv_cx_move(_c, _x, _y - _r * 0.3); tsv_cx_quad(_c, _x + _r * 0.04, _y, _x, _y + _r * 0.26); tsv_cx_stroke(_c);
            tsv__stroke(_c, [255, 236, 190], 0.6, max(1, _r * 0.05)); tsv_cx_begin(_c); tsv_cx_arc(_c, _x - _r * 0.14, _y - _r * 0.08, _r * 0.2, 3.6, 4.7); tsv_cx_stroke(_c);
            tsv__leaf(_c, _x + _r * 0.42, _y + _r * 0.2, _r * 0.1, _r * 0.05, -0.4, "#4a8a2a"); tsv__leaf(_c, _x - _r * 0.46, _y + _r * 0.18, _r * 0.09, _r * 0.07, 0, "#e8a030");
            break;
        case "steak":   // a slab with grill bars and a fat edge
            tsv_cx_save(_c); tsv_cx_translate(_c, _x, _y - _r * 0.05); tsv_cx_rotate(_c, -0.18);
            _c.fill = tsv__food(_c, 0, 0, _r * 0.55, _p); tsv__rr(_c, -_r * 0.55, -_r * 0.28, _r * 1.05, _r * 0.52, _r * 0.22); tsv_cx_fill(_c); tsv__outline(_c, _lw);
            tsv__stroke(_c, "#f2e2c8", 1, max(1, _r * 0.06)); tsv_cx_begin(_c); tsv_cx_move(_c, -_r * 0.45, -_r * 0.3); tsv_cx_quad(_c, 0, -_r * 0.38, _r * 0.42, -_r * 0.3); tsv_cx_stroke(_c);
            tsv__stroke(_c, [30, 12, 4], 0.8, max(1, _r * 0.07)); for (_k = 0; _k < 3; _k++) tsv__seg(_c, -_r * 0.32 + _k * _r * 0.28, -_r * 0.18, -_r * 0.18 + _k * _r * 0.28, _r * 0.18);
            tsv_cx_restore(_c); tsv__leaf(_c, _x + _r * 0.55, _y + _r * 0.2, _r * 0.1, _r * 0.06, -0.5, "#5a9a3a");
            break;
        case "fish":   // a whole fish: body, forked tail, eye, fin, a lemon slice
            var _body = [[216, 208, 192], [138, 122, 100]]; if (_p != tsv__palette("cream")) _body = _p;
            _c.fill = tsv__food(_c, _x, _y, _r * 0.5, _body); tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r * 0.62, _y); tsv_cx_quad(_c, _x - _r * 0.2, _y - _r * 0.36, _x + _r * 0.35, _y - _r * 0.02);
            tsv_cx_line(_c, _x + _r * 0.72, _y - _r * 0.24); tsv_cx_line(_c, _x + _r * 0.62, _y + _r * 0.02); tsv_cx_line(_c, _x + _r * 0.72, _y + _r * 0.22); tsv_cx_line(_c, _x + _r * 0.35, _y + _r * 0.04);
            tsv_cx_quad(_c, _x - _r * 0.2, _y + _r * 0.34, _x - _r * 0.62, _y); tsv_cx_close(_c); tsv_cx_fill(_c); tsv__outline(_c, _lw);
            tsv__stroke(_c, [40, 20, 5], 0.45, max(0.8, _r * 0.04)); for (_k = 0; _k < 3; _k++) tsv__seg(_c, _x - _r * 0.12 + _k * _r * 0.14, _y - _r * 0.15, _x - _r * 0.04 + _k * _r * 0.14, _y + _r * 0.13);
            tsv__leaf(_c, _x - _r * 0.44, _y - _r * 0.04, _r * 0.05, _r * 0.05, 0, "#1e140a");
            tsv__fill(_c, "#f2d23a"); tsv_cx_begin(_c); tsv_cx_arc(_c, _x - _r * 0.1, _y + _r * 0.34, _r * 0.14, 3.3, 6.1); tsv_cx_close(_c); tsv_cx_fill(_c); tsv__outline(_c, _lw * 0.7);
            break;
        case "pie":   // a wedge cut from a pie: golden crust top, the filling showing at the cut face
            tsv__fill(_c, _p[1]); tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r * 0.5, _y + _r * 0.12); tsv_cx_line(_c, _x + _r * 0.34, _y + _r * 0.2); tsv_cx_line(_c, _x + _r * 0.34, _y + _r * 0.02); tsv_cx_line(_c, _x - _r * 0.5, _y - _r * 0.08); tsv_cx_close(_c); tsv_cx_fill(_c);
            tsv__fill(_c, _p[0]); tsv_cx_fill_rect(_c, _x - _r * 0.48, _y - _r * 0.03, _r * 0.8, _r * 0.1);
            var _gp = tsv_cx_linear(_c, _x, _y - _r * 0.5, _x, _y); tsv_cx_stop(_gp, 0, tsv__hex("#f2cc7a")); tsv_cx_stop(_gp, 1, tsv__hex("#b8782e")); _c.fill = _gp;
            tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r * 0.5, _y - _r * 0.08); tsv_cx_line(_c, _x + _r * 0.34, _y + _r * 0.02); tsv_cx_quad(_c, _x + _r * 0.55, _y - _r * 0.3, _x + _r * 0.3, _y - _r * 0.46); tsv_cx_close(_c); tsv_cx_fill(_c); tsv__outline(_c, _lw);
            tsv__stroke(_c, [120, 70, 20], 0.7, max(0.8, _r * 0.04)); tsv__seg(_c, _x + _r * 0.12, _y - _r * 0.22, _x + _r * 0.28, _y - _r * 0.12);
            tsv__leaf(_c, _x - _r * 0.52, _y + _r * 0.28, _r * 0.13, _r * 0.08, 0, "#fbf6ea");   // a spoon of cream
            break;
        case "cake":   // a layered slice with a berry on top
            var _top = tsv__shade(_p[0], 30);
            tsv__fill(_c, _p[1]); tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r * 0.45, _y + _r * 0.14); tsv_cx_line(_c, _x + _r * 0.35, _y + _r * 0.22); tsv_cx_line(_c, _x + _r * 0.35, _y - _r * 0.12); tsv_cx_line(_c, _x - _r * 0.45, _y - _r * 0.2); tsv_cx_close(_c); tsv_cx_fill(_c);
            tsv__fill(_c, "#fbf2e0"); tsv_cx_fill_rect(_c, _x - _r * 0.44, _y - _r * 0.09, _r * 0.78, _r * 0.07); tsv_cx_fill_rect(_c, _x - _r * 0.44, _y + _r * 0.04, _r * 0.78, _r * 0.06);
            tsv__fill(_c, _top); tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r * 0.45, _y - _r * 0.2); tsv_cx_line(_c, _x + _r * 0.35, _y - _r * 0.12); tsv_cx_line(_c, _x + _r * 0.2, _y - _r * 0.5); tsv_cx_close(_c); tsv_cx_fill(_c); tsv__outline(_c, _lw);
            tsv__leaf(_c, _x + _r * 0.06, _y - _r * 0.36, _r * 0.1, _r * 0.1, 0, "#c0182a"); tsv__fill(_c, [255, 255, 255], 0.7); tsv__ell(_c, _x + _r * 0.03, _y - _r * 0.39, _r * 0.03, _r * 0.03); tsv_cx_fill(_c);
            break;
        case "bread":   // a loaf with three scores, and a small roll
            _c.fill = tsv__food(_c, _x - _r * 0.05, _y - _r * 0.08, _r * 0.55, _p); tsv__ell(_c, _x - _r * 0.08, _y - _r * 0.06, _r * 0.55, _r * 0.3, -0.1); tsv_cx_fill(_c); tsv__outline(_c, _lw);
            tsv__stroke(_c, tsv__shade(_p[0], 40), 1, max(1, _r * 0.06)); _c.cap = 1; for (_k = 0; _k < 3; _k++) tsv__seg(_c, _x - _r * 0.34 + _k * _r * 0.24, _y - _r * 0.22, _x - _r * 0.22 + _k * _r * 0.24, _y + _r * 0.02); _c.cap = 0;
            _c.fill = tsv__food(_c, _x + _r * 0.5, _y + _r * 0.18, _r * 0.2, _p); tsv__ell(_c, _x + _r * 0.52, _y + _r * 0.18, _r * 0.2, _r * 0.15); tsv_cx_fill(_c); tsv__outline(_c, _lw);
            break;
        case "salad":   // a heap of leaves (each its own tone), tomato and a sliced radish
            var _tones = [_p[0], _p[1], tsv__shade(_p[0], 20), tsv__shade(_p[1], 16)];
            for (_k = 0; _k < 7; _k++) {
                var _a = _k * 0.9, _d = _r * (0.1 + (_k mod 3) * 0.12), _lx = _x + cos(_a) * _d, _ly = _y - _r * 0.08 + sin(_a) * _d * 0.5;
                tsv__fill(_c, _tones[_k mod 4]); tsv__ell(_c, _lx, _ly, _r * 0.26, _r * 0.13, _a); tsv_cx_fill(_c); tsv__outline(_c, _lw * 0.6);
                tsv__stroke(_c, [255, 255, 230], 0.5, 1); tsv__seg(_c, _lx - cos(_a) * _r * 0.18, _ly - sin(_a) * _r * 0.09, _lx + cos(_a) * _r * 0.18, _ly + sin(_a) * _r * 0.09);
            }
            tsv__leaf(_c, _x + _r * 0.24, _y - _r * 0.2, _r * 0.11, _r * 0.1, 0, "#d23a2a"); tsv__leaf(_c, _x - _r * 0.3, _y + _r * 0.06, _r * 0.09, _r * 0.08, 0, "#e8506a");
            break;
        case "cheese":   // a wedge with holes, a bunch of grapes beside
            tsv__fill(_c, _p[1]); tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r * 0.5, _y + _r * 0.14); tsv_cx_line(_c, _x + _r * 0.2, _y + _r * 0.22); tsv_cx_line(_c, _x + _r * 0.2, _y); tsv_cx_line(_c, _x - _r * 0.5, _y - _r * 0.1); tsv_cx_close(_c); tsv_cx_fill(_c);
            tsv__fill(_c, _p[0]); tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r * 0.5, _y - _r * 0.1); tsv_cx_line(_c, _x + _r * 0.2, _y); tsv_cx_line(_c, _x + _r * 0.1, _y - _r * 0.36); tsv_cx_close(_c); tsv_cx_fill(_c); tsv__outline(_c, _lw);
            tsv__fill(_c, _p[1]); for (_k = 0; _k < 4; _k++) { var _hh = _holes[_k]; tsv__ell(_c, _x + _hh[0] * _r, _y + _hh[1] * _r, _hh[2] * _r, _hh[2] * _r * 0.8); tsv_cx_fill(_c); }
            tsv__fill(_c, "#6a2a6a"); for (_k = 0; _k < 5; _k++) { tsv__ell(_c, _x + _r * (0.45 + (_k mod 2) * 0.12), _y + _r * (-0.12 + floor(_k / 2) * 0.12), _r * 0.08, _r * 0.08); tsv_cx_fill(_c); }
            break;
        case "egg":   // a fried egg on toast
            tsv__fill(_c, "#c8904a"); tsv__rr(_c, _x - _r * 0.5, _y - _r * 0.28, _r * 0.9, _r * 0.52, _r * 0.1); tsv_cx_fill(_c); tsv__outline(_c, _lw);
            tsv__fill(_c, "#fbfaf2"); tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r * 0.35, _y); tsv_cx_bezier(_c, _x - _r * 0.4, _y - _r * 0.3, _x + _r * 0.05, _y - _r * 0.35, _x + _r * 0.28, _y - _r * 0.12);
            tsv_cx_bezier(_c, _x + _r * 0.42, _y + _r * 0.1, _x - _r * 0.1, _y + _r * 0.26, _x - _r * 0.35, _y); tsv_cx_fill(_c); tsv__outline(_c, _lw * 0.6);
            _c.fill = tsv__food(_c, _x - _r * 0.04, _y - _r * 0.07, _r * 0.14, tsv__palette("yellow")); tsv__ell(_c, _x - _r * 0.04, _y - _r * 0.06, _r * 0.14, _r * 0.11); tsv_cx_fill(_c);
            break;
        case "noodles":   // a nest of noodles in sauce with a sprig
            tsv__fill(_c, tsv__palette("red")[1]); tsv__ell(_c, _x, _y, _r * 0.55, _r * 0.3); tsv_cx_fill(_c);
            tsv__stroke(_c, _p[0], 1, max(1, _r * 0.07));
            for (_k = 0; _k < 5; _k++) { tsv_cx_begin(_c); tsv_cx_ellipse(_c, _x + ((_k mod 2) ? 0.08 : -0.08) * _r, _y - _r * 0.04 + (_k - 2) * _r * 0.05, _r * (0.44 - _k * 0.05), _r * (0.2 - _k * 0.02), 0.2 * _k, 0.3, 5.9); tsv_cx_stroke(_c); }
            tsv__leaf(_c, _x + _r * 0.1, _y - _r * 0.2, _r * 0.1, _r * 0.05, -0.4, "#4a8a2a");
            break;
        case "rice":   // a dome of rice with a pickle and a leaf
            _c.fill = tsv__food(_c, _x, _y - _r * 0.15, _r * 0.45, [[251, 248, 238], [200, 192, 168]]);
            tsv_cx_begin(_c); tsv_cx_ellipse(_c, _x, _y - _r * 0.02, _r * 0.45, _r * 0.4, 0, 3.1416, TSV_TAU); tsv_cx_line(_c, _x + _r * 0.45, _y + _r * 0.02); tsv_cx_ellipse(_c, _x, _y + _r * 0.02, _r * 0.45, _r * 0.16, 0, 0, 3.1416); tsv_cx_fill(_c); tsv__outline(_c, _lw);
            tsv__fill(_c, [160, 150, 120], 0.6); for (_k = 0; _k < 8; _k++) tsv_cx_fill_rect(_c, _x - _r * 0.3 + ((_k * 13) mod 7) * _r * 0.09, _y - _r * 0.3 + ((_k * 5) mod 4) * _r * 0.08, max(1, _r * 0.05), max(1, _r * 0.03));
            tsv__leaf(_c, _x + _r * 0.5, _y + _r * 0.12, _r * 0.14, _r * 0.08, 0.3, (_p == tsv__palette("cream")) ? "#e8a830" : _p[0]); tsv__leaf(_c, _x - _r * 0.5, _y + _r * 0.12, _r * 0.14, _r * 0.06, -0.4, "#3a7a2a");
            break;
        case "fruit":   // three fruit with a stalk and a leaf
            for (_k = 0; _k < 3; _k++) {
                var _fx = _x + _fp[_k][0] * _r, _fy = _y + _fp[_k][1] * _r, _rad = _r * ((_k == 2) ? 0.24 : 0.26);
                _c.fill = tsv__food(_c, _fx, _fy, _rad, _p); tsv__ell(_c, _fx, _fy, _rad, _rad * 0.92); tsv_cx_fill(_c); tsv__outline(_c, _lw);
                tsv__fill(_c, [255, 255, 255], 0.55); tsv__ell(_c, _fx - _rad * 0.35, _fy - _rad * 0.35, _rad * 0.2, _rad * 0.13, -0.6); tsv_cx_fill(_c);
                tsv__stroke(_c, "#4a2a0a", 1, max(1, _r * 0.04)); tsv__seg(_c, _fx, _fy - _rad * 0.85, _fx + _rad * 0.15, _fy - _rad * 1.2);
            }
            tsv__leaf(_c, _x + _r * 0.12, _y - _r * 0.5, _r * 0.12, _r * 0.06, -0.6, "#4a8a2a");
            break;
        case "sausage":   // two curved sausages with mustard
            for (_k = 0; _k < 2; _k++) {
                var _oy = _y - _r * 0.14 + _k * _r * 0.26;
                _c.cap = 1; tsv__stroke(_c, _p[1], 1, _r * 0.26); tsv_cx_begin(_c); tsv_cx_arc(_c, _x, _oy + _r * 0.6, _r * 0.62, 4.2, 5.2); tsv_cx_stroke(_c);
                tsv__stroke(_c, _p[0], 1, _r * 0.17); tsv_cx_stroke(_c);
                tsv__stroke(_c, [255, 230, 190], 0.5, _r * 0.05); tsv_cx_begin(_c); tsv_cx_arc(_c, _x, _oy + _r * 0.56, _r * 0.62, 4.3, 5.1); tsv_cx_stroke(_c);
            }
            _c.cap = 0; tsv__leaf(_c, _x + _r * 0.5, _y + _r * 0.26, _r * 0.12, _r * 0.07, 0, "#e8c02a");
            break;
        default:   // "plate": a generic plated main - a mound, sauce and a sprig
            tsv__fill(_c, [140, 40, 20], 0.55); tsv__ell(_c, _x - _r * 0.1, _y + _r * 0.12, _r * 0.5, _r * 0.18); tsv_cx_fill(_c);
            _c.fill = tsv__food(_c, _x, _y - _r * 0.12, _r * 0.45, _p);
            tsv_cx_begin(_c); tsv_cx_ellipse(_c, _x, _y - _r * 0.02, _r * 0.42, _r * 0.34, 0, 3.1416, TSV_TAU); tsv_cx_line(_c, _x + _r * 0.42, _y + _r * 0.02); tsv_cx_ellipse(_c, _x, _y + _r * 0.02, _r * 0.42, _r * 0.14, 0, 0, 3.1416); tsv_cx_fill(_c); tsv__outline(_c, _lw);
            tsv__leaf(_c, _x + _r * 0.2, _y - _r * 0.32, _r * 0.1, _r * 0.05, -0.5, "#4a8a2a");
    }
}

/// @function tsv__bowl(ctx, x, y, r, pal, rim, eaten, chunky, hot)
/// @description Internal. A glazed bowl: body below, rim, the liquid surface inside (chunks in a stew), a spoon.
function tsv__bowl(_c, _x, _y, _r, _p, _rim, _eaten, _chunky, _hot) {
    static _ch = [[-0.35, -0.12], [0.1, -0.16], [0.3, -0.06], [-0.1, -0.02]];
    var _w = _r * 0.78;
    tsv__fill(_c, [0, 0, 0], 0.3); tsv__ell(_c, _x + _r * 0.06, _y + _r * 0.34, _w * 0.9, _r * 0.2); tsv_cx_fill(_c);
    var _g = tsv_cx_linear(_c, _x - _w, 0, _x + _w, 0); tsv_cx_stop(_g, 0, tsv__shade(_rim, -20)); tsv_cx_stop(_g, 0.35, tsv__shade(_rim, 40)); tsv_cx_stop(_g, 1, tsv__shade(_rim, -40));
    _c.fill = _g; tsv_cx_begin(_c); tsv_cx_move(_c, _x - _w, _y - _r * 0.12); tsv_cx_bezier(_c, _x - _w, _y + _r * 0.4, _x + _w, _y + _r * 0.4, _x + _w, _y - _r * 0.12); tsv_cx_close(_c); tsv_cx_fill(_c); tsv__outline(_c, _r * 0.04);
    tsv__fill(_c, "#f4ecdc"); tsv__ell(_c, _x, _y - _r * 0.12, _w, _r * 0.26); tsv_cx_fill(_c); tsv__outline(_c, _r * 0.04);
    if (!_eaten) {
        _c.fill = tsv__food(_c, _x, _y - _r * 0.14, _w * 0.85, _p); tsv__ell(_c, _x, _y - _r * 0.1, _w * 0.84, _r * 0.2); tsv_cx_fill(_c);
        if (_chunky) {
            tsv__fill(_c, _p[1]); for (var _k = 0; _k < 4; _k++) { tsv__ell(_c, _x + _ch[_k][0] * _r, _y + _ch[_k][1] * _r, _r * 0.1, _r * 0.06); tsv_cx_fill(_c); }
            tsv__leaf(_c, _x - _r * 0.2, _y - _r * 0.16, _r * 0.07, _r * 0.05, 0, "#e89a3a");
        } else { tsv__stroke(_c, [255, 250, 235], 0.85, max(1, _r * 0.05)); tsv_cx_begin(_c); tsv_cx_arc(_c, _x + _r * 0.05, _y - _r * 0.1, _r * 0.16, 0.3, 4.9); tsv_cx_stroke(_c); }
        tsv__leaf(_c, _x + _r * 0.3, _y - _r * 0.16, _r * 0.08, _r * 0.04, 0.4, "#3f7a2a");
        if (_hot) tsv__steam(_c, _x, _y - _r * 0.28, _r, 3);
    } else { tsv__fill(_c, _p[1], 0.5); tsv__ell(_c, _x, _y - _r * 0.08, _w * 0.5, _r * 0.08); tsv_cx_fill(_c); }
    tsv__stroke(_c, "#8a8a8a", 1, max(1, _r * 0.06)); _c.cap = 1; tsv__seg(_c, _x + _r * 0.45, _y - _r * 0.18, _x + _r * 0.78, _y - _r * 0.48); _c.cap = 0;
}

/// @function tsv__mug(ctx, x, y, r, pal, eaten)
/// @description Internal. A wooden tankard with iron hoops and a head of foam.
function tsv__mug(_c, _x, _y, _r, _p, _eaten) {
    var _w = _r * 0.42, _top = _y - _r * 0.55, _bot = _y + _r * 0.3, _k;
    tsv__fill(_c, [0, 0, 0], 0.3); tsv__ell(_c, _x + _r * 0.08, _bot + _r * 0.04, _w * 1.2, _r * 0.12); tsv_cx_fill(_c);
    tsv__stroke(_c, "#5a3a1a", 1, _r * 0.12); tsv_cx_begin(_c); tsv_cx_move(_c, _x + _w, _top + _r * 0.18); tsv_cx_bezier(_c, _x + _w + _r * 0.42, _top + _r * 0.14, _x + _w + _r * 0.42, _bot - _r * 0.2, _x + _w, _bot - _r * 0.16); tsv_cx_stroke(_c);
    var _g = tsv_cx_linear(_c, _x - _w, 0, _x + _w, 0); tsv_cx_stop(_g, 0, tsv__hex("#6a4020")); tsv_cx_stop(_g, 0.35, tsv__hex("#c08a50")); tsv_cx_stop(_g, 1, tsv__hex("#5a3418"));
    _c.fill = _g; tsv__rr(_c, _x - _w, _top, _w * 2, _bot - _top, _r * 0.06); tsv_cx_fill(_c); tsv__outline(_c, _r * 0.04);
    tsv__stroke(_c, [40, 20, 5], 0.4, 1); for (_k = 1; _k < 4; _k++) tsv__seg(_c, _x - _w + _k * _w * 0.5, _top + 2, _x - _w + _k * _w * 0.5, _bot - 2);
    tsv__fill(_c, "#4a4a50"); tsv_cx_fill_rect(_c, _x - _w, _top + (_bot - _top) * 0.22, _w * 2, _r * 0.07); tsv_cx_fill_rect(_c, _x - _w, _top + (_bot - _top) * 0.74, _w * 2, _r * 0.07);
    if (!_eaten) {
        tsv__fill(_c, "#fbf6ea"); tsv__ell(_c, _x, _top, _w * 1.08, _r * 0.14); tsv_cx_fill(_c); tsv__ell(_c, _x - _w * 0.5, _top - _r * 0.08, _w * 0.45, _r * 0.12); tsv_cx_fill(_c); tsv__ell(_c, _x + _w * 0.4, _top - _r * 0.06, _w * 0.5, _r * 0.1); tsv_cx_fill(_c);
        tsv__fill(_c, _p[1], 0.5); tsv__ell(_c, _x, _top + _r * 0.04, _w * 0.6, _r * 0.04); tsv_cx_fill(_c);
    } else { tsv__fill(_c, "#2a1a0a"); tsv__ell(_c, _x, _top, _w, _r * 0.1); tsv_cx_fill(_c); }
}

/// @function tsv__cup(ctx, x, y, r, pal, eaten, hot)
/// @description Internal. A cup on a saucer.
function tsv__cup(_c, _x, _y, _r, _p, _eaten, _hot) {
    tsv__fill(_c, [0, 0, 0], 0.28); tsv__ell(_c, _x + _r * 0.06, _y + _r * 0.2, _r * 0.7, _r * 0.26); tsv_cx_fill(_c);
    tsv__fill(_c, "#f7f2e6"); tsv__ell(_c, _x, _y + _r * 0.14, _r * 0.66, _r * 0.24); tsv_cx_fill(_c); tsv__outline(_c, _r * 0.04);
    tsv__stroke(_c, "#e8e0cc", 1, _r * 0.08); tsv_cx_begin(_c); tsv_cx_arc(_c, _x + _r * 0.4, _y - _r * 0.06, _r * 0.14, -1.4, 1.4); tsv_cx_stroke(_c);
    var _g = tsv_cx_linear(_c, _x - _r * 0.4, 0, _x + _r * 0.4, 0); tsv_cx_stop(_g, 0, tsv__hex("#d8d0bc")); tsv_cx_stop(_g, 0.4, tsv__hex("#fbf8f0")); tsv_cx_stop(_g, 1, tsv__hex("#bcb29a"));
    _c.fill = _g; tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r * 0.4, _y - _r * 0.26); tsv_cx_line(_c, _x + _r * 0.4, _y - _r * 0.26);
    tsv_cx_bezier(_c, _x + _r * 0.38, _y + _r * 0.1, _x + _r * 0.2, _y + _r * 0.16, _x, _y + _r * 0.16); tsv_cx_bezier(_c, _x - _r * 0.2, _y + _r * 0.16, _x - _r * 0.38, _y + _r * 0.1, _x - _r * 0.4, _y - _r * 0.26); tsv_cx_fill(_c); tsv__outline(_c, _r * 0.04);
    tsv__stroke(_c, "#3a6a9a", 1, max(1, _r * 0.05)); tsv__seg(_c, _x - _r * 0.36, _y - _r * 0.12, _x + _r * 0.36, _y - _r * 0.12);
    tsv__fill(_c, _eaten ? tsv__hex("#e6dcc6") : _p[1]); tsv__ell(_c, _x, _y - _r * 0.26, _r * 0.38, _r * 0.1); tsv_cx_fill(_c); tsv__outline(_c, _r * 0.03);
    if (!_eaten && _hot) tsv__steam(_c, _x, _y - _r * 0.36, _r * 0.8, 2);
}

/// @function tsv__glass(ctx, x, y, r, pal, eaten)
/// @description Internal. A stemmed glass: bowl, stem, foot, the drink, a glint.
function tsv__glass(_c, _x, _y, _r, _p, _eaten) {
    tsv__fill(_c, [0, 0, 0], 0.25); tsv__ell(_c, _x + _r * 0.06, _y + _r * 0.36, _r * 0.32, _r * 0.1); tsv_cx_fill(_c);
    tsv__fill(_c, [230, 240, 245], 0.9); tsv__ell(_c, _x, _y + _r * 0.34, _r * 0.26, _r * 0.08); tsv_cx_fill(_c); tsv_cx_fill_rect(_c, _x - _r * 0.03, _y + _r * 0.02, _r * 0.06, _r * 0.32);
    var _bowl = function(_c, _x, _y, _r) { tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r * 0.34, _y - _r * 0.6); tsv_cx_bezier(_c, _x - _r * 0.36, _y - _r * 0.05, _x + _r * 0.36, _y - _r * 0.05, _x + _r * 0.34, _y - _r * 0.6); tsv_cx_close(_c); };
    _bowl(_c, _x, _y, _r); tsv__fill(_c, [220, 235, 245], 0.35); tsv_cx_fill(_c); tsv__stroke(_c, [80, 100, 120], 0.8, max(0.8, _r * 0.035)); tsv_cx_stroke(_c);
    if (!_eaten) {
        tsv_cx_save(_c); _bowl(_c, _x, _y, _r); tsv_cx_clip(_c);
        _c.fill = tsv__food(_c, _x, _y - _r * 0.2, _r * 0.4, _p); tsv_cx_fill_rect(_c, _x - _r * 0.4, _y - _r * 0.4, _r * 0.8, _r * 0.45);
        tsv_cx_restore(_c);
        tsv__fill(_c, tsv__shade(_p[0], 30)); tsv__ell(_c, _x, _y - _r * 0.4, _r * 0.32, _r * 0.06); tsv_cx_fill(_c);
    }
    tsv__stroke(_c, [255, 255, 255], 0.85, max(1, _r * 0.05)); tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r * 0.22, _y - _r * 0.5); tsv_cx_quad(_c, _x - _r * 0.26, _y - _r * 0.25, _x - _r * 0.14, _y - _r * 0.14); tsv_cx_stroke(_c);
}

/// @function tsv__bottle_path(ctx, x, y, r, shape)
/// @description Internal. The glass outline of a bottle of one of three shapes: 0 a round flask, 1 a cone (wide foot), 2
/// a tall slim bottle. A new path.
function tsv__bottle_path(_c, _x, _y, _r, _shape) {
    tsv_cx_begin(_c);
    if (_shape == 0) { tsv_cx_arc(_c, _x, _y + _r * 0.02, _r * 0.38, -1.3, 4.44); tsv_cx_line(_c, _x - _r * 0.1, _y - _r * 0.62); tsv_cx_line(_c, _x + _r * 0.1, _y - _r * 0.62); tsv_cx_close(_c); }
    else if (_shape == 1) { tsv_cx_move(_c, _x - _r * 0.09, _y - _r * 0.62); tsv_cx_line(_c, _x + _r * 0.09, _y - _r * 0.62); tsv_cx_line(_c, _x + _r * 0.09, _y - _r * 0.3); tsv_cx_line(_c, _x + _r * 0.42, _y + _r * 0.32); tsv_cx_quad(_c, _x, _y + _r * 0.44, _x - _r * 0.42, _y + _r * 0.32); tsv_cx_line(_c, _x - _r * 0.09, _y - _r * 0.3); tsv_cx_close(_c); }
    else {
        tsv_cx_move(_c, _x - _r * 0.08, _y - _r * 0.66); tsv_cx_line(_c, _x + _r * 0.08, _y - _r * 0.66); tsv_cx_line(_c, _x + _r * 0.08, _y - _r * 0.44); tsv_cx_quad(_c, _x + _r * 0.24, _y - _r * 0.4, _x + _r * 0.24, _y - _r * 0.24);
        tsv_cx_line(_c, _x + _r * 0.24, _y + _r * 0.34); tsv_cx_line(_c, _x - _r * 0.24, _y + _r * 0.34); tsv_cx_line(_c, _x - _r * 0.24, _y - _r * 0.24); tsv_cx_quad(_c, _x - _r * 0.24, _y - _r * 0.4, _x - _r * 0.08, _y - _r * 0.44); tsv_cx_close(_c);
    }
}

/// @function tsv__bottle(ctx, x, y, r, pal, eaten, shape)
/// @description Internal. A glass bottle (three shapes) with a cork, the drink, a paper label and a glint.
function tsv__bottle(_c, _x, _y, _r, _p, _eaten, _shape) {
    tsv__fill(_c, [0, 0, 0], 0.28); tsv__ell(_c, _x + _r * 0.06, _y + _r * 0.36, _r * 0.46, _r * 0.12); tsv_cx_fill(_c);
    tsv__bottle_path(_c, _x, _y, _r, _shape); tsv__fill(_c, [225, 238, 245], 0.4); tsv_cx_fill(_c);
    if (!_eaten) {
        tsv_cx_save(_c); tsv__bottle_path(_c, _x, _y, _r * 0.95, _shape); tsv_cx_clip(_c);
        _c.fill = tsv__food(_c, _x - _r * 0.1, _y, _r * 0.4, _p); tsv_cx_fill_rect(_c, _x - _r * 0.45, _y - _r * 0.14, _r * 0.9, _r * 0.6);
        tsv__fill(_c, tsv__shade(_p[0], 34)); tsv_cx_fill_rect(_c, _x - _r * 0.45, _y - _r * 0.16, _r * 0.9, _r * 0.04);
        tsv_cx_restore(_c);
    }
    tsv__bottle_path(_c, _x, _y, _r, _shape); tsv__stroke(_c, [70, 90, 110], 0.85, max(0.8, _r * 0.04)); tsv_cx_stroke(_c);
    var _top = (_shape == 2) ? -0.8 : -0.76;
    tsv__fill(_c, "#b07a44"); tsv__rr(_c, _x - _r * 0.12, _y + _r * _top, _r * 0.24, _r * 0.17, _r * 0.04); tsv_cx_fill(_c); tsv__outline(_c, _r * 0.03);
    tsv__fill(_c, "#f2e6c4"); tsv_cx_fill_rect(_c, _x - _r * 0.16, _y + _r * 0.02, _r * 0.3, _r * 0.16); tsv__stroke(_c, [80, 50, 20], 0.6, 0.8); tsv_cx_stroke_rect(_c, _x - _r * 0.16, _y + _r * 0.02, _r * 0.3, _r * 0.16);
    tsv__stroke(_c, [255, 255, 255], 0.85, max(1, _r * 0.05)); tsv__seg(_c, _x - _r * ((_shape == 2) ? 0.16 : 0.24), _y - _r * 0.12, _x - _r * ((_shape == 2) ? 0.16 : 0.26), _y + _r * 0.14);
}

// ---------------------------------------------------------------------------------------------------------------
// Diners (and the demo's server), generated
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv__look_tables()
/// @description Internal. The diner tables (the MZ SKIN, HAIR, COATS, SHIRTS, HATS, STYLES, EXTRAS).
function tsv__look_tables() {
    static _T = {
        skin: ["#f6d7bc", "#eec39c", "#d9a57a", "#b67a50", "#8a5634", "#5e3a22"],
        hair: ["#2a1a10", "#4a2c16", "#7a4a22", "#b07a3a", "#e0b860", "#c8c0b0", "#8a2a1a", "#1e1e2e"],
        coats: ["#3a5a8a", "#8a3a3a", "#3a6a4a", "#6a4a8a", "#a8742a", "#4a4a52", "#2a6a7a", "#9a5a6a", "#5a6a2a", "#7a4a2a"],
        shirts: ["#f2ead8", "#d8e4ee", "#efd8c8", "#e4e8d0"],
        hats: ["none", "none", "none", "cap", "brim", "hood", "beret", "scarf"],
        styles: ["short", "bob", "long", "bun", "tail", "crop"],
        extras: ["none", "none", "scarf", "glasses", "beard", "earring"],
        rims: ["#2f5f8a", "#8a2f3a", "#3a7a4a", "#a8842a", "#4a4a4a"]
    };
    return _T;
}

/// @function tsv_diner_look(seed)
/// @description A diner's look from a seed: skin, hair colour and style, hat, coat, shirt and one extra (scarf, glasses,
/// beard, earring). The same seed is always the same diner; 6 x 8 x 6 x 8 x 10 x 4 x 6 = over a million combinations.
/// Returns { skin, hair, style, hat, coat, shirt, extra, hatColour, trim, apron } (colours as "#rrggbb"). Pure.
/// @param {Real} seed
/// @returns {Struct}
function tsv_diner_look(_seed) {
    var _T = tsv__look_tables(), _sd = is_numeric(_seed) ? string(_seed) : string(_seed);
    var _h = int64(tsv_hash_string("diner:" + _sd)), _h2 = int64(tsv_hash_string("d2:" + _sd));
    var _L = { skin: _T.skin[real(_h mod 6)], hair: _T.hair[real((_h >> 3) mod 8)], style: _T.styles[real((_h >> 7) mod 6)], hat: _T.hats[real((_h >> 11) mod 8)], coat: _T.coats[real((_h >> 15) mod 10)],
        shirt: _T.shirts[real(_h2 mod 4)], extra: _T.extras[real((_h2 >> 3) mod 6)], hatColour: _T.coats[real((_h2 >> 7) mod 10)], trim: _T.rims[real((_h2 >> 11) mod 5)], apron: false };
    if (_L.hat == "hood") _L.hatColour = _L.coat;
    if (_L.extra == "beard" && (_L.style == "long" || _L.style == "bun" || _L.style == "tail")) _L.extra = "none";
    return _L;
}

/// @function tsv_server_look()
/// @description The demo's server: a white apron over a dark waistcoat. Pure.
/// @returns {Struct}
function tsv_server_look() { return { skin: "#eec39c", hair: "#4a2c16", style: "crop", hat: "none", coat: "#2e2a30", shirt: "#f4efe4", extra: "none", hatColour: "#2e2a30", trim: "#a8842a", apron: true }; }

/// @function tsv__look_ok(look)
/// @description Internal. A look struct with every field a figure reads.
function tsv__look_ok(_L) {
    if (!is_struct(_L)) return false;
    static _need = ["skin", "hair", "style", "hat", "coat", "shirt", "extra", "hatColour", "trim"];
    for (var _i = 0; _i < array_length(_need); _i++) if (!is_string(_L[$ _need[_i]])) return false;
    return true;
}

/// @function tsv_draw_figure(ctx, ox, oy, s, look, dir, pose)
/// @description Draw one figure in an s x s cell whose top-left is (ox, oy): a big head over a small body, facing dir (2
/// down, 4 left, 6 right, 8 up). pose "seat" draws it seated with its hands forward on the table's edge; "walk0", "walk1",
/// "walk2" draw it standing (legs apart, together, apart the other way). A canvas-kit context; prefer tsv_diner_sprite,
/// which bakes this with an outline and caches it. Returns 1 when drawn.
/// @returns {Real}
function tsv_draw_figure(_c, _ox, _oy, _s, _look, _dir, _pose) {
    if (!tsv__is_ctx(_c) || !tsv__look_ok(_look)) return 0;
    _ox = tsv__fin(_ox, 0); _oy = tsv__fin(_oy, 0); _s = clamp(tsv__fin(_s, 48), 8, 1024);
    if (_dir != 2 && _dir != 4 && _dir != 6 && _dir != 8) _dir = 2;
    if (!is_string(_pose)) _pose = "walk1";
    var _u = _s / 48, _cx = _ox + _s / 2, _seat = (_pose == "seat"), _step = (_pose == "walk0") ? -1 : ((_pose == "walk2") ? 1 : 0);
    var _bob = _seat ? 0 : ((_step != 0) ? -1 : 0) * _u;
    var _headY = _oy + (_seat ? 18 : 15) * _u + _bob, _headR = 10.2 * _u, _bodyTop = _oy + (_seat ? 27 : 24) * _u + _bob, _bodyBot = _oy + (_seat ? 44 : 38) * _u + _bob;
    var _side = (_dir == 4) ? -1 : ((_dir == 6) ? 1 : 0), _back = (_dir == 8), _k;
    tsv_cx_save(_c);
    // long hair and the hood fall BEHIND the body
    if (_side == 0 && (_look.style == "long" || _look.hat == "hood")) { tsv__fill(_c, (_look.hat == "hood") ? tsv__shade(_look.hatColour, -18) : tsv__hex(_look.hair)); tsv__rr(_c, _cx - 11.5 * _u, _headY - 2 * _u, 23 * _u, (_back ? 22 : 18) * _u, 6 * _u); tsv_cx_fill(_c); }
    // legs (standing only)
    if (!_seat) {
        var _legC = tsv__shade(_look.coat, -30);
        for (var _l = -1; _l <= 1; _l += 2) {
            var _sw = (_side != 0) ? _step * _l * 3 * _u : 0, _lx = _cx + ((_side != 0) ? _sw : _l * 3.6 * _u + ((_dir == 2 || _back) ? _step * _l * 1.2 * _u : 0));
            var _ly = _oy + (38 + ((_side != 0) ? 0 : max(0, _step * _l) * 1.2)) * _u + _bob;
            tsv__fill(_c, _legC); tsv__rr(_c, _lx - 2.6 * _u, _ly - 2 * _u, 5.2 * _u, 8.6 * _u, 1.6 * _u); tsv_cx_fill(_c);
            tsv__fill(_c, "#2a1a10"); tsv__rr(_c, _lx - 3 * _u + _side * 1 * _u, _ly + 5.6 * _u, 6 * _u + ((_side != 0) ? 1.5 * _u : 0), 2.6 * _u, 1.2 * _u); tsv_cx_fill(_c);
        }
    }
    // the body: a coat lit from the upper left, a collar, buttons; the apron if the look has one
    var _bw = (_side != 0) ? 14 * _u : 20 * _u, _bx = _cx - _bw / 2;
    var _g = tsv_cx_linear(_c, _bx, _bodyTop, _bx + _bw, _bodyBot); tsv_cx_stop(_g, 0, tsv__shade(_look.coat, 30)); tsv_cx_stop(_g, 0.5, tsv__hex(_look.coat)); tsv_cx_stop(_g, 1, tsv__shade(_look.coat, -40));
    _c.fill = _g; tsv_cx_begin(_c); tsv_cx_move(_c, _bx + 3 * _u, _bodyTop); tsv_cx_line(_c, _bx + _bw - 3 * _u, _bodyTop); tsv_cx_quad(_c, _bx + _bw + 1 * _u, _bodyTop + 1 * _u, _bx + _bw, _bodyTop + 6 * _u);
    tsv_cx_line(_c, _bx + _bw - 1 * _u, _bodyBot); tsv_cx_line(_c, _bx + 1 * _u, _bodyBot); tsv_cx_line(_c, _bx, _bodyTop + 6 * _u); tsv_cx_quad(_c, _bx - 1 * _u, _bodyTop + 1 * _u, _bx + 3 * _u, _bodyTop); tsv_cx_close(_c); tsv_cx_fill(_c);
    tsv__stroke(_c, [20, 10, 5], 0.6, max(1, _u)); tsv_cx_stroke(_c);
    if (!_back && _side == 0) {
        tsv__fill(_c, _look.shirt); tsv_cx_begin(_c); tsv_cx_move(_c, _cx - 4 * _u, _bodyTop); tsv_cx_line(_c, _cx + 4 * _u, _bodyTop); tsv_cx_line(_c, _cx, _bodyTop + 6.5 * _u); tsv_cx_close(_c); tsv_cx_fill(_c);
        tsv__fill(_c, _look.trim); for (var _b = 0; _b < 2; _b++) { tsv__ell(_c, _cx, _bodyTop + (8.5 + _b * 3.6) * _u, 0.9 * _u, 0.9 * _u); tsv_cx_fill(_c); }
        if (_look[$ "apron"] == true) {
            tsv__fill(_c, "#f7f3ea"); tsv__rr(_c, _cx - 7 * _u, _bodyTop + 7 * _u, 14 * _u, _bodyBot - _bodyTop - 5 * _u, 2 * _u); tsv_cx_fill(_c); tsv__stroke(_c, [120, 100, 70], 0.6, max(0.8, 0.7 * _u)); tsv_cx_stroke(_c);
            tsv__stroke(_c, "#f7f3ea", 1, 1.2 * _u); tsv_cx_begin(_c); tsv_cx_move(_c, _cx - 6 * _u, _bodyTop + 7 * _u); tsv_cx_line(_c, _cx - 3 * _u, _bodyTop); tsv_cx_move(_c, _cx + 6 * _u, _bodyTop + 7 * _u); tsv_cx_line(_c, _cx + 3 * _u, _bodyTop); tsv_cx_stroke(_c);
        }
    }
    if (_side != 0 && _look[$ "apron"] == true) { tsv__fill(_c, "#f7f3ea"); tsv__rr(_c, _cx + _side * 1 * _u - ((_side > 0) ? 0 : 6 * _u), _bodyTop + 7 * _u, 6 * _u, _bodyBot - _bodyTop - 5 * _u, 1.5 * _u); tsv_cx_fill(_c); }
    if (_look.extra == "scarf" && !_back) {
        tsv__fill(_c, _look.hatColour); tsv__rr(_c, _cx - ((_side != 0) ? 5 : 7) * _u, _bodyTop - 1.5 * _u, ((_side != 0) ? 10 : 14) * _u, 4 * _u, 2 * _u); tsv_cx_fill(_c);
        if (_side == 0) { tsv__rr(_c, _cx + 2 * _u, _bodyTop + 1 * _u, 3.4 * _u, 8 * _u, 1.4 * _u); tsv_cx_fill(_c); }
    }
    // arms: sleeves down the sides; seated hands rest forward on the table's edge
    var _skin = _look.skin;
    if (_side != 0) {
        var _ax = _cx + _side * 2 * _u;
        tsv__stroke(_c, tsv__shade(_look.coat, -14), 1, 5 * _u); _c.cap = 1;
        tsv__seg(_c, _ax, _bodyTop + 3 * _u, _ax + _side * (_seat ? 7 : 2 + _step * _side * -2) * _u, _bodyTop + (_seat ? 11 : 10) * _u); _c.cap = 0;
        tsv__fill(_c, _skin); tsv__ell(_c, _ax + _side * (_seat ? 8.5 : 2.5 + _step * _side * -2) * _u, _bodyTop + 11.5 * _u, 2.2 * _u, 2.2 * _u); tsv_cx_fill(_c);
    } else {
        for (var _a = -1; _a <= 1; _a += 2) {
            var _sx = _cx + _a * (_bw / 2 - 0.5 * _u);
            tsv__stroke(_c, tsv__shade(_look.coat, (_a < 0) ? -6 : -26), 1, 5 * _u); _c.cap = 1;
            if (_seat) tsv__seg(_c, _sx, _bodyTop + 3 * _u, _sx - _a * 3 * _u, _bodyTop + 13 * _u);
            else tsv__seg(_c, _sx, _bodyTop + 3 * _u, _sx + _a * 0.8 * _u, _bodyTop + 11 * _u - (_back ? 0 : _a * _step * 1.2 * _u));
            _c.cap = 0;
            if (!_back) { tsv__fill(_c, _skin); tsv__ell(_c, _seat ? _sx - _a * 3.4 * _u : _sx + _a * 0.9 * _u, _bodyTop + (_seat ? 14.6 : 12.6) * _u, 2.3 * _u, 2.1 * _u); tsv_cx_fill(_c); }
        }
    }
    // the head: skin with a lit cheek, ears, face; then hair; then hat
    var _hx = _cx + _side * 1 * _u;
    var _hg = tsv_cx_radial(_c, _hx - 3 * _u, _headY - 3 * _u, 1, _hx, _headY, _headR * 1.1); tsv_cx_stop(_hg, 0, tsv__shade(_skin, 18)); tsv_cx_stop(_hg, 1, tsv__shade(_skin, -22));
    _c.fill = _hg; tsv__ell(_c, _hx, _headY, _headR, _headR * 0.96); tsv_cx_fill(_c); tsv__stroke(_c, [60, 30, 15], 0.55, max(0.8, 0.8 * _u)); tsv_cx_stroke(_c);
    if (!_back) {
        if (_side != 0) {
            tsv__fill(_c, _skin); tsv_cx_begin(_c); tsv_cx_move(_c, _hx + _side * (_headR - 1 * _u), _headY - 1 * _u); tsv_cx_line(_c, _hx + _side * (_headR + 2 * _u), _headY + 2 * _u); tsv_cx_line(_c, _hx + _side * (_headR - 0.5 * _u), _headY + 3 * _u); tsv_cx_fill(_c);   // the nose
            tsv__fill(_c, "#1e140c"); tsv__rr(_c, _hx + _side * 5 * _u - 1 * _u, _headY - 1.5 * _u, 2.2 * _u, 3.4 * _u, 1 * _u); tsv_cx_fill(_c);
            tsv__fill(_c, [230, 110, 100], 0.35); tsv__ell(_c, _hx + _side * 4.5 * _u, _headY + 3.2 * _u, 2.2 * _u, 1.3 * _u); tsv_cx_fill(_c);
            tsv__fill(_c, tsv__shade(_skin, -14)); tsv__ell(_c, _hx - _side * 1.5 * _u, _headY + 1 * _u, 1.8 * _u, 2.4 * _u); tsv_cx_fill(_c);   // the ear
        } else {
            for (var _e = -1; _e <= 1; _e += 2) {
                tsv__fill(_c, "#1e140c"); tsv__rr(_c, _hx + _e * 4.2 * _u - 1.1 * _u, _headY - 0.8 * _u, 2.2 * _u, 3.6 * _u, 1 * _u); tsv_cx_fill(_c);
                tsv__fill(_c, [255, 255, 255], 0.8); tsv_cx_fill_rect(_c, _hx + _e * 4.2 * _u - 0.6 * _u, _headY - 0.4 * _u, 0.8 * _u, 0.9 * _u);
                tsv__fill(_c, [230, 110, 100], 0.32); tsv__ell(_c, _hx + _e * 5.6 * _u, _headY + 3.4 * _u, 2 * _u, 1.2 * _u); tsv_cx_fill(_c);
            }
            tsv__stroke(_c, [90, 40, 25], 0.8, max(0.8, 0.8 * _u)); tsv_cx_begin(_c); tsv_cx_arc(_c, _hx, _headY + 3.4 * _u, 1.6 * _u, 0.4, 2.7); tsv_cx_stroke(_c);
        }
        if (_look.extra == "glasses") {
            tsv__stroke(_c, "#2a2a2a", 1, max(0.8, 0.8 * _u));
            if (_side != 0) { tsv__ell(_c, _hx + _side * 5.4 * _u, _headY + 0.8 * _u, 2.4 * _u, 2.2 * _u); tsv_cx_stroke(_c); tsv__seg(_c, _hx + _side * 3 * _u, _headY + 0.4 * _u, _hx - _side * 1 * _u, _headY); }
            else { for (var _q = -1; _q <= 1; _q += 2) { tsv__ell(_c, _hx + _q * 4.2 * _u, _headY + 1 * _u, 2.6 * _u, 2.4 * _u); tsv_cx_stroke(_c); } tsv__seg(_c, _hx - 1.6 * _u, _headY + 0.6 * _u, _hx + 1.6 * _u, _headY + 0.6 * _u); }
        }
        if (_look.extra == "beard") {
            tsv__fill(_c, _look.hair); tsv_cx_begin(_c);
            if (_side != 0) { tsv_cx_move(_c, _hx - _side * 2 * _u, _headY + 2 * _u); tsv_cx_quad(_c, _hx + _side * 2 * _u, _headY + 12 * _u, _hx + _side * 8 * _u, _headY + 4.5 * _u); tsv_cx_line(_c, _hx + _side * 4 * _u, _headY + 5 * _u); }
            else { tsv_cx_move(_c, _hx - 8 * _u, _headY + 1 * _u); tsv_cx_quad(_c, _hx, _headY + 14 * _u, _hx + 8 * _u, _headY + 1 * _u); tsv_cx_quad(_c, _hx, _headY + 7 * _u, _hx - 8 * _u, _headY + 1 * _u); }
            tsv_cx_fill(_c);
        }
        if (_look.extra == "earring" && _side == 0) { tsv__fill(_c, "#f2cc5a"); tsv__ell(_c, _hx - 9.4 * _u, _headY + 3.4 * _u, 1.1 * _u, 1.1 * _u); tsv_cx_fill(_c); }
    }
    tsv__hair(_c, _hx, _headY, _headR, _u, _look, _side, _back);
    tsv__hat(_c, _hx, _headY, _headR, _u, _look, _side, _back);
    tsv_cx_restore(_c);
    return 1;
}

/// @function tsv__hair(ctx, hx, hy, R, u, look, side, back)
/// @description Internal. The hair: a cap over the crown with a fringe cut into it; a bun, a tail or long hair by style.
function tsv__hair(_c, _hx, _hy, _R, _u, _look, _side, _back) {
    if (_look.hat == "hood" || _look.hat == "scarf") return;
    var _col = _look.hair, _st = _look.style;
    var _setInk = function(_c, _col, _u) { tsv__fill(_c, _col); tsv__stroke(_c, tsv__shade(_col, -24), 1, max(0.8, 0.8 * _u)); };
    _setInk(_c, _col, _u);
    if (_back) {   // from behind the hair covers the head
        tsv_cx_begin(_c); tsv_cx_ellipse(_c, _hx, _hy - 0.5 * _u, _R + 0.8 * _u, _R * 0.98, 0, 0, TSV_TAU); tsv_cx_fill(_c); tsv_cx_stroke(_c);
        if (_st == "bun") { tsv__ell(_c, _hx, _hy - _R - 1 * _u, 4 * _u, 3.6 * _u); tsv_cx_fill(_c); tsv_cx_stroke(_c); }
        if (_st == "tail") { tsv__rr(_c, _hx - 2.2 * _u, _hy + 4 * _u, 4.4 * _u, 11 * _u, 2 * _u); tsv_cx_fill(_c); tsv_cx_stroke(_c); }
        if (_st == "long" || _st == "bob") { tsv__rr(_c, _hx - _R - 0.5 * _u, _hy - 1 * _u, 2 * _R + 1 * _u, ((_st == "long") ? 17 : 11) * _u, 4 * _u); tsv_cx_fill(_c); tsv_cx_stroke(_c); }
        tsv__stroke(_c, [255, 255, 255], 0.2, max(0.8, 0.8 * _u)); tsv_cx_begin(_c); tsv_cx_arc(_c, _hx - 2 * _u, _hy - 3 * _u, _R * 0.6, 3.6, 4.6); tsv_cx_stroke(_c);
        return;
    }
    tsv_cx_begin(_c);
    if (_side != 0) {
        tsv_cx_move(_c, _hx - _side * (_R + 1 * _u), _hy + ((_st == "crop") ? 0 : 5) * _u); tsv_cx_quad(_c, _hx - _side * (_R + 1.5 * _u), _hy - _R - 1.5 * _u, _hx + _side * 2 * _u, _hy - _R - 1 * _u);
        tsv_cx_quad(_c, _hx + _side * (_R + 1 * _u), _hy - _R * 0.7, _hx + _side * (_R - 0.5 * _u), _hy - 2.5 * _u); tsv_cx_line(_c, _hx + _side * 2 * _u, _hy - 3.5 * _u); tsv_cx_line(_c, _hx - _side * 1 * _u, _hy + 1 * _u);
        tsv_cx_line(_c, _hx - _side * 3 * _u, _hy + ((_st == "crop") ? 0 : 6) * _u); tsv_cx_close(_c);
    } else {
        var _fr = (_st == "crop") ? -4.2 : -2.6, _drop = (_st == "bob" || _st == "long") ? 7 : 1;
        tsv_cx_move(_c, _hx - _R - 0.8 * _u, _hy + _drop * _u); tsv_cx_quad(_c, _hx - _R - 1 * _u, _hy - _R - 2 * _u, _hx, _hy - _R - 1.4 * _u); tsv_cx_quad(_c, _hx + _R + 1 * _u, _hy - _R - 2 * _u, _hx + _R + 0.8 * _u, _hy + _drop * _u);
        tsv_cx_line(_c, _hx + _R - 1.5 * _u, _hy + 0.5 * _u); tsv_cx_line(_c, _hx + 5 * _u, _hy + _fr * _u); tsv_cx_line(_c, _hx + 2 * _u, _hy + (_fr + 1.6) * _u); tsv_cx_line(_c, _hx - 1.5 * _u, _hy + _fr * _u);
        tsv_cx_line(_c, _hx - 5 * _u, _hy + (_fr + 1.4) * _u); tsv_cx_line(_c, _hx - _R + 1.5 * _u, _hy + 0.5 * _u); tsv_cx_close(_c);
    }
    tsv_cx_fill(_c); tsv_cx_stroke(_c);
    if (_st == "bun") { tsv__ell(_c, _hx - _side * 3 * _u, _hy - _R - 1.5 * _u, 4 * _u, 3.6 * _u); tsv_cx_fill(_c); tsv_cx_stroke(_c); }
    if (_st == "tail" && _side != 0) { tsv_cx_begin(_c); tsv_cx_move(_c, _hx - _side * (_R - 1 * _u), _hy - 3 * _u); tsv_cx_quad(_c, _hx - _side * (_R + 6 * _u), _hy + 2 * _u, _hx - _side * (_R + 3 * _u), _hy + 10 * _u); tsv_cx_line(_c, _hx - _side * (_R + 0.5 * _u), _hy + 6 * _u); tsv_cx_close(_c); tsv_cx_fill(_c); tsv_cx_stroke(_c); }
    if (_st == "long" && _side != 0) { tsv__rr(_c, _hx - _side * _R - ((_side > 0) ? 3 * _u : 0), _hy - 2 * _u, 3.5 * _u, 15 * _u, 1.8 * _u); tsv_cx_fill(_c); }
    tsv__stroke(_c, [255, 255, 255], 0.28, max(0.8, 1 * _u)); tsv_cx_begin(_c); tsv_cx_arc(_c, _hx - 2 * _u, _hy - 2 * _u, _R * 0.72, 3.7, 4.5); tsv_cx_stroke(_c);
}

/// @function tsv__hat(ctx, hx, hy, R, u, look, side, back)
/// @description Internal. The hat: a flat cap, a brimmed hat, a beret, a hood or a headscarf (or none).
function tsv__hat(_c, _hx, _hy, _R, _u, _look, _side, _back) {
    var _col = _look.hatColour, _dk = tsv__shade(_col, -34), _ink = tsv__shade(_col, -60), _sd = (_side != 0) ? _side : 1;
    var _lw = max(0.8, 0.8 * _u);
    switch (_look.hat) {
        case "cap":   // a soft flat cap: a wide, low crown pulled forward over a short peak (not a round helmet)
            tsv__stroke(_c, _ink, 1, _lw);
            if (!_back) { tsv__fill(_c, _dk); tsv_cx_begin(_c); tsv_cx_ellipse(_c, _hx + _side * 5 * _u, _hy - _R * 0.36, (_side != 0) ? 7 * _u : _R * 0.95, 2.4 * _u, 0, 0, 3.1416); tsv_cx_close(_c); tsv_cx_fill(_c); tsv_cx_stroke(_c); }
            tsv__fill(_c, _col); tsv_cx_begin(_c); tsv_cx_ellipse(_c, _hx + _side * 1.5 * _u, _hy - _R * 0.62, _R + 2.6 * _u, _R * 0.5, _side * 0.12, 3.0, 6.43); tsv_cx_quad(_c, _hx, _hy - _R * 0.2, _hx - _R - 2 * _u, _hy - _R * 0.5); tsv_cx_close(_c); tsv_cx_fill(_c); tsv_cx_stroke(_c);
            tsv__stroke(_c, tsv__shade(_col, -46), 1, _lw); tsv_cx_begin(_c); tsv_cx_move(_c, _hx - 3 * _u, _hy - _R * 1.08); tsv_cx_quad(_c, _hx + 1 * _u, _hy - _R * 0.8, _hx + 4 * _u, _hy - _R * 0.5); tsv_cx_stroke(_c);
            break;
        case "brim":
            tsv__stroke(_c, _ink, 1, _lw);
            tsv__fill(_c, _dk); tsv__ell(_c, _hx, _hy - _R * 0.5, _R + 5 * _u, 3.4 * _u); tsv_cx_fill(_c); tsv_cx_stroke(_c);
            tsv__fill(_c, _col); tsv__rr(_c, _hx - _R * 0.7, _hy - _R * 1.35, _R * 1.4, _R * 0.9, 3 * _u); tsv_cx_fill(_c); tsv_cx_stroke(_c);
            tsv__fill(_c, _look.trim); tsv_cx_fill_rect(_c, _hx - _R * 0.7, _hy - _R * 0.72, _R * 1.4, 1.8 * _u);
            break;
        case "beret":
            tsv__stroke(_c, _ink, 1, _lw);
            tsv__fill(_c, _col); tsv_cx_begin(_c); tsv_cx_ellipse(_c, _hx - _sd * 2 * _u, _hy - _R * 0.72, _R + 1.4 * _u, _R * 0.45, -0.12 * _sd, 0, TSV_TAU); tsv_cx_fill(_c); tsv_cx_stroke(_c);
            tsv__fill(_c, _dk); tsv__ell(_c, _hx - _sd * 1 * _u, _hy - _R * 1.12, 1.2 * _u, 1.6 * _u); tsv_cx_fill(_c);
            break;
        case "hood":
            tsv__stroke(_c, _ink, 1, _lw);
            tsv__fill(_c, _col); tsv_cx_begin(_c); tsv_cx_ellipse(_c, _hx, _hy, _R + 2.2 * _u, _R + 1.8 * _u, 0, 0, TSV_TAU);
            if (!_back) { tsv_cx_move(_c, _hx + _side * 2 * _u + _R * ((_side != 0) ? 0.72 : 0.8), _hy + 1.5 * _u); tsv_cx_ellipse(_c, _hx + _side * 2 * _u, _hy + 1.5 * _u, _R * ((_side != 0) ? 0.72 : 0.8), _R * 0.72, 0, 0, -TSV_TAU, true); }   // the face cut out: 0 -> -TAU anticlockwise is a full turn in the kit AND in a browser (the MZ edition wrote 0 -> TAU, which Chrome turns into a full turn and the kit reads as zero)
            tsv_cx_fill_rule(_c, TSV_FILL_EVENODD); tsv_cx_stroke(_c);
            break;
        case "scarf":   // a headscarf tied at the nape: the cloth over the crown, a band of trim, the knot's two ends
            tsv__stroke(_c, _ink, 1, _lw);
            tsv__fill(_c, _col); tsv_cx_begin(_c); tsv_cx_ellipse(_c, _hx, _hy - 1.5 * _u, _R + 1.4 * _u, _R + 0.6 * _u, 0, 3.0, 6.43); tsv_cx_close(_c); tsv_cx_fill(_c); tsv_cx_stroke(_c);
            tsv__stroke(_c, _look.trim, 1, 1.4 * _u); tsv_cx_begin(_c); tsv_cx_ellipse(_c, _hx, _hy - 1.5 * _u, _R + 0.6 * _u, _R * 0.5, 0, 3.3, 6.12); tsv_cx_stroke(_c);
            var _kx = _back ? _hx : _hx - _sd * (_R + 1 * _u);
            tsv__fill(_c, tsv__shade(_col, -12)); tsv__stroke(_c, _ink, 1, _lw);
            tsv_cx_begin(_c); tsv_cx_move(_c, _kx, _hy + 1 * _u); tsv_cx_line(_c, _kx - _sd * 3 * _u, _hy + 7 * _u); tsv_cx_line(_c, _kx + ((_side != 0) ? 0 : 1) * 1 * _u, _hy + 6 * _u); tsv_cx_close(_c); tsv_cx_fill(_c); tsv_cx_stroke(_c);
            tsv_cx_begin(_c); tsv_cx_move(_c, _kx, _hy + 1 * _u); tsv_cx_line(_c, _kx + ((_side != 0) ? -_side * 0.5 : 2.5) * _u, _hy + 8 * _u); tsv_cx_line(_c, _kx + ((_side != 0) ? _side * 1.5 : 4) * _u, _hy + 6.5 * _u); tsv_cx_close(_c); tsv_cx_fill(_c); tsv_cx_stroke(_c);
            break;
    }
}

// ---------------------------------------------------------------------------------------------------------------
// The floor's marks: ticket, bell, candle, the pass, tags, the tray, coins, stars, the ledger, the banner
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv_ticket_height(dishes)
/// @description The height of an order ticket holding n dishes (32 + 20 a dish). Pure.
/// @returns {Real}
function tsv_ticket_height(_n) { return 32 + 20 * max(1, is_numeric(_n) ? floor(_n) : 1); }

/// @function tsv_draw_ticket(ctx, w, h, info)
/// @description The order ticket pinned above a party: a paper slip with a torn foot and a red pin, the table's number,
/// each dish drawn and named in the server's hand, struck through with a tick once it has been brought.
/// info = { table, dishes: [{ name, done }] }. w x h (h from tsv_ticket_height). Returns 1 when drawn.
/// @returns {Real}
function tsv_draw_ticket(_c, _w, _h, _info) {
    if (!tsv__is_ctx(_c) || !is_struct(_info)) return 0;
    var _x = 3, _y = 7, _tw = _w - 8, _th = _h - 11, _i, _ink = tsv__ink();
    tsv_cx_save(_c);
    tsv__fill(_c, [0, 0, 0], 0.35); tsv_cx_fill_rect(_c, _x + 3, _y + 3, _tw, _th);
    tsv_cx_begin(_c); tsv_cx_move(_c, _x, _y); tsv_cx_line(_c, _x + _tw, _y); tsv_cx_line(_c, _x + _tw, _y + _th - 4);
    for (_i = 0; _i <= 10; _i++) tsv_cx_line(_c, _x + _tw - _i * _tw / 10, _y + _th - ((_i mod 2) ? 0 : 4));   // the torn foot
    tsv_cx_close(_c);
    var _g = tsv_cx_linear(_c, 0, _y, 0, _y + _th); tsv_cx_stop(_g, 0, tsv__hex("#fbf5e3")); tsv_cx_stop(_g, 1, tsv__hex("#eee2c2")); _c.fill = _g; tsv_cx_fill(_c);
    tsv__stroke(_c, [120, 90, 50], 0.55, 1); tsv_cx_stroke(_c);
    tsv__stroke(_c, [180, 60, 50], 0.55, 1); tsv__seg(_c, _x + 5, _y + 19, _x + _tw - 5, _y + 19);
    tsv__fill(_c, "#9a2a1e"); tsv_cx_begin(_c); tsv_cx_arc(_c, _x + _tw - 12, _y + 1, 3.6, 0, TSV_TAU); tsv_cx_fill(_c); tsv__stroke(_c, [60, 10, 5], 0.7, 0.8); tsv_cx_stroke(_c);
    tsv__fill(_c, [255, 255, 255], 0.65); tsv_cx_begin(_c); tsv_cx_arc(_c, _x + _tw - 13, _y, 1.2, 0, TSV_TAU); tsv_cx_fill(_c);
    var _title = "Table " + string(_info[$ "table"] ?? "");
    tsv__text(_c, _title, _x + 5, _y + 10.5, tsv__fit(_title, _tw - 22, 11, TSV_FACE_DISPLAY), _ink, 1, "left", TSV_FACE_DISPLAY);
    var _rows = is_array(_info[$ "dishes"]) ? _info.dishes : [];
    for (_i = 0; _i < array_length(_rows); _i++) {
        var _row = _rows[_i]; if (!is_struct(_row)) continue;
        var _ry = _y + 31 + _i * 20, _nm = string(_row[$ "name"] ?? "?"), _done = (_row[$ "done"] == true);
        tsv_draw_dish(_c, _x + 12, _ry + 1, 8.5, is_struct(_row[$ "dish"]) ? _row.dish : _nm, false, false);
        var _px = tsv__fit(_nm, _tw - 38, 13, TSV_FACE_BODY);
        var _tw2 = tsv__text(_c, _nm, _x + 24, _ry, _px, _ink, _done ? 0.45 : 1, "left", TSV_FACE_BODY);
        if (_done) {
            tsv__stroke(_c, _ink, 0.55, 1); tsv__seg(_c, _x + 23, _ry, _x + 25 + _tw2, _ry);
            tsv__stroke(_c, [40, 110, 50], 0.95, 2); tsv_cx_begin(_c); tsv_cx_move(_c, _x + _tw - 14, _ry); tsv_cx_line(_c, _x + _tw - 10, _ry + 4); tsv_cx_line(_c, _x + _tw - 3, _ry - 6); tsv_cx_stroke(_c);
        }
    }
    tsv_cx_restore(_c);
    return 1;
}

/// @function tsv_draw_bell(ctx, w, h)
/// @description The brass service bell a seated party wants rung for their order (the scene sways it). w x h.
function tsv_draw_bell(_c, _w, _h) {
    if (!tsv__is_ctx(_c)) return 0;
    var _cx = _w / 2, _by = _h * 0.82;
    tsv_cx_save(_c);
    tsv__fill(_c, [0, 0, 0], 0.35); tsv__ell(_c, _cx + 2, _by + 3, _w * 0.42, _h * 0.08); tsv_cx_fill(_c);
    var _g = tsv_cx_linear(_c, _cx - _w * 0.4, 0, _cx + _w * 0.4, 0); tsv_cx_stop(_g, 0, tsv__hex("#8a5a14")); tsv_cx_stop(_g, 0.35, tsv__hex("#fbe7a4")); tsv_cx_stop(_g, 0.6, tsv__hex("#d9aa4a")); tsv_cx_stop(_g, 1, tsv__hex("#6a4410"));
    _c.fill = _g; tsv_cx_begin(_c); tsv_cx_move(_c, _cx - _w * 0.4, _by); tsv_cx_bezier(_c, _cx - _w * 0.36, _h * 0.3, _cx + _w * 0.36, _h * 0.3, _cx + _w * 0.4, _by); tsv_cx_close(_c); tsv_cx_fill(_c);
    tsv__stroke(_c, [60, 35, 5], 0.7, 1); tsv_cx_stroke(_c);
    tsv__fill(_c, "#5a3a0a"); tsv_cx_fill_rect(_c, _cx - _w * 0.44, _by - 1, _w * 0.88, 3);
    tsv__fill(_c, "#c99a42"); tsv_cx_begin(_c); tsv_cx_arc(_c, _cx, _h * 0.3, _w * 0.07, 0, TSV_TAU); tsv_cx_fill(_c); tsv__stroke(_c, "#3a2408", 1, 1); tsv_cx_stroke(_c);
    tsv_cx_restore(_c);
    return 1;
}

/// @function tsv_draw_wax(ctx, w, h)
/// @description A candle's wax, full height (the scene crops it as patience burns down). w x h.
function tsv_draw_wax(_c, _w, _h) {
    if (!tsv__is_ctx(_c)) return 0;
    var _g = tsv_cx_linear(_c, 0, 0, _w, 0); tsv_cx_stop(_g, 0, tsv__hex("#d8c9a4")); tsv_cx_stop(_g, 0.4, tsv__hex("#fbf3dc")); tsv_cx_stop(_g, 1, tsv__hex("#bca77a"));
    _c.fill = _g; tsv__rr(_c, 1, 0, _w - 2, _h, 2); tsv_cx_fill(_c);
    tsv__stroke(_c, [120, 100, 60], 0.5, 0.8); tsv_cx_stroke(_c);
    tsv__fill(_c, [255, 255, 255], 0.55); tsv_cx_fill_rect(_c, 3, 2, 1.4, _h - 4);
    tsv__fill(_c, [210, 190, 150], 0.95); tsv__ell(_c, _w * 0.74, 5, 1.7, 4.6); tsv_cx_fill(_c);   // a drip
    return 1;
}

/// @function tsv_draw_flame(ctx, w, h, gutter)
/// @description A candle flame with its halo and wick; gutter = the low, red-orange flame of a candle nearly out. w x h.
function tsv_draw_flame(_c, _w, _h, _gutter = false) {
    if (!tsv__is_ctx(_c)) return 0;
    _gutter = tsv__flag(_gutter);
    var _cx = _w / 2, _g = tsv_cx_radial(_c, _cx, _h * 0.62, 1, _cx, _h * 0.55, _h * 0.55);
    if (_gutter) { tsv_cx_stop(_g, 0, [255, 220, 160], 1); tsv_cx_stop(_g, 0.35, [240, 110, 40], 0.95); tsv_cx_stop(_g, 1, [200, 40, 10], 0); }
    else { tsv_cx_stop(_g, 0, [255, 250, 210], 1); tsv_cx_stop(_g, 0.35, [255, 200, 80], 0.95); tsv_cx_stop(_g, 1, [255, 120, 20], 0); }
    tsv__fill(_c, [255, 190, 90], 0.18); tsv__ell(_c, _cx, _h * 0.55, _w * 0.5, _h * 0.5); tsv_cx_fill(_c);   // the halo
    _c.fill = _g; tsv_cx_begin(_c); tsv_cx_move(_c, _cx, 0); tsv_cx_bezier(_c, _cx + _w * 0.4, _h * 0.45, _cx + _w * 0.28, _h, _cx, _h); tsv_cx_bezier(_c, _cx - _w * 0.28, _h, _cx - _w * 0.4, _h * 0.45, _cx, 0); tsv_cx_fill(_c);
    tsv__fill(_c, "#2a1a0a"); tsv_cx_fill_rect(_c, _cx - 0.5, _h - 4, 1, 4);   // the wick
    return 1;
}

/// @function tsv_draw_holder(ctx, w, h)
/// @description The candle's brass dish. w x h.
function tsv_draw_holder(_c, _w, _h) {
    if (!tsv__is_ctx(_c)) return 0;
    var _g = tsv_cx_linear(_c, 0, 0, _w, 0); tsv_cx_stop(_g, 0, tsv__hex("#8a5a14")); tsv_cx_stop(_g, 0.4, tsv__hex("#f2d890")); tsv_cx_stop(_g, 1, tsv__hex("#6a4410"));
    _c.fill = _g; tsv__ell(_c, _w / 2, _h / 2, _w / 2 - 1, _h / 2 - 1); tsv_cx_fill(_c);
    tsv__stroke(_c, [40, 20, 0], 0.6, 1); tsv_cx_stroke(_c);
    tsv__fill(_c, [60, 35, 5], 0.5); tsv__ell(_c, _w / 2, _h / 2 - 1, _w * 0.22, _h * 0.22); tsv_cx_fill(_c);
    return 1;
}

/// @function tsv_draw_puff(ctx, w, h)
/// @description Smoke from a snuffed candle (a party that walked out). w x h.
function tsv_draw_puff(_c, _w, _h) {
    if (!tsv__is_ctx(_c)) return 0;
    tsv__stroke(_c, [220, 220, 225], 0.75, 2); _c.cap = 1;
    tsv_cx_begin(_c); tsv_cx_move(_c, _w / 2, _h); tsv_cx_bezier(_c, _w * 0.2, _h * 0.7, _w * 0.8, _h * 0.45, _w * 0.45, _h * 0.2); tsv_cx_bezier(_c, _w * 0.3, _h * 0.05, _w * 0.6, 0, _w * 0.7, _h * 0.05); tsv_cx_stroke(_c);
    _c.cap = 0;
    return 1;
}

/// @function tsv_draw_pass(ctx, w, h, ready)
/// @description The pass: the dishes waiting on the kitchen's counter, steaming, each with a paper flag for its table.
/// ready = [{ name (or dish struct), table }]; up to four drawn, "+N" for the rest. w x h.
function tsv_draw_pass(_c, _w, _h, _ready) {
    if (!tsv__is_ctx(_c) || !is_array(_ready)) return 0;
    tsv_cx_save(_c);
    var _n = min(4, array_length(_ready)), _pitch = (_n > 1) ? min(46, (_w - 44) / (_n - 1)) : 0, _x0 = _w / 2 - _pitch * (_n - 1) / 2, _ink = tsv__ink();
    for (var _i = 0; _i < _n; _i++) {
        var _r = _ready[_i]; if (!is_struct(_r)) continue;
        var _dx = _x0 + _i * _pitch, _dy = _h - 18;
        tsv_draw_dish(_c, _dx, _dy, 17, is_struct(_r[$ "dish"]) ? _r.dish : string(_r[$ "name"] ?? ""), true, false);
        tsv__stroke(_c, "#6a4a2a", 1, 1.2); tsv__seg(_c, _dx + 13, _dy + 2, _dx + 13, _dy - 22);
        tsv__fill(_c, "#fbf5e3"); tsv_cx_begin(_c); tsv_cx_move(_c, _dx + 13, _dy - 22); tsv_cx_line(_c, _dx + 29, _dy - 19); tsv_cx_line(_c, _dx + 13, _dy - 14); tsv_cx_close(_c); tsv_cx_fill(_c); tsv__stroke(_c, [120, 90, 50], 0.7, 0.8); tsv_cx_stroke(_c);
        tsv__text(_c, string(_r[$ "table"] ?? ""), _dx + 19, _dy - 18.5, 8, _ink, 1, "center", TSV_FACE_DISPLAY);
    }
    if (array_length(_ready) > 4) tsv__text_outlined(_c, "+" + string(array_length(_ready) - 4), _w - 2, _h - 6, 13, "#fbf5e3", [20, 10, 5], "right", TSV_FACE_DISPLAY);
    tsv_cx_restore(_c);
    return 1;
}

/// @function tsv_draw_tag(ctx, w, h, text, kind)
/// @description A little paper tag that floats up from a table: kind "good" (green), "bad" (red), "coin" (gold, with
/// coins) or "" (plain). Returns its drawn width.
/// @returns {Real}
function tsv_draw_tag(_c, _w, _h, _text, _kind = "") {
    if (!tsv__is_ctx(_c)) return 0;
    _text = string(_text);
    tsv_cx_save(_c);
    var _tw = min(_w - 8, tsv_text_width(_text, 13, TSV_FACE_DISPLAY) + 18), _x = (_w - _tw) / 2, _y = 3, _th = _h - 7;
    tsv__fill(_c, [0, 0, 0], 0.35); tsv__rr(_c, _x + 2, _y + 3, _tw, _th, 5); tsv_cx_fill(_c);
    var _bg = (_kind == "bad") ? ["#f6dcd4", "#9a2a1e"] : ((_kind == "good") ? ["#e4f0d4", "#2e6a2a"] : ((_kind == "coin") ? ["#fbeab0", "#7a5410"] : ["#fbf5e3", tsv__ink()]));
    tsv__fill(_c, _bg[0]); tsv__rr(_c, _x, _y, _tw, _th, 5); tsv_cx_fill(_c); tsv__stroke(_c, _bg[1], 1, 1.2); tsv_cx_stroke(_c);
    if (_kind == "coin") tsv_draw_coins(_c, _x + 10, _y + _th / 2 + 2, 2, 10, true);
    var _px = tsv__fit(_text, _tw - ((_kind == "coin") ? 20 : 10), 12, TSV_FACE_DISPLAY);
    tsv__text(_c, _text, _x + _tw / 2 + ((_kind == "coin") ? 5 : 0), _y + _th / 2 + 0.5, _px, _bg[1], 1, "center", TSV_FACE_DISPLAY);
    tsv_cx_restore(_c);
    return _tw;
}

/// @function tsv_draw_hud(ctx, w, h, info)
/// @description What the server is carrying and how the night is going: two hands (a tray each, the dish on it and its
/// table), the tips so far, served and walked out, and the shift's clock (a brass dial whose wedge sweeps once across the
/// shift). info = { hands: [{ name, table } or undefined, ...], progress (0..1), tips, currency, served, walkouts }.
function tsv_draw_hud(_c, _w, _h, _info) {
    if (!tsv__is_ctx(_c) || !is_struct(_info)) return 0;
    tsv_cx_save(_c);
    tsv__fill(_c, [0, 0, 0], 0.35); tsv__rr(_c, 3, 4, _w - 4, _h - 4, 10); tsv_cx_fill(_c);
    var _g = tsv_cx_linear(_c, 0, 0, 0, _h); tsv_cx_stop(_g, 0, [46, 30, 18], 0.94); tsv_cx_stop(_g, 1, [24, 15, 8], 0.94); _c.fill = _g; tsv__rr(_c, 0, 0, _w - 4, _h - 4, 10); tsv_cx_fill(_c);
    tsv__stroke(_c, [201, 154, 66], 0.85, 1.5); tsv__rr(_c, 3, 3, _w - 10, _h - 10, 8); tsv_cx_stroke(_c);
    var _cy = (_h - 4) / 2, _hands = is_array(_info[$ "hands"]) ? _info.hands : [];
    for (var _i = 0; _i < 2; _i++) {
        var _cx = 32 + _i * 54; tsv__fill(_c, [255, 240, 210], 0.07); tsv__ell(_c, _cx, _cy, 21, 21); tsv_cx_fill(_c); tsv__stroke(_c, [241, 223, 180], 0.45, 1); tsv_cx_stroke(_c);
        var _hd = (_i < array_length(_hands)) ? _hands[_i] : undefined;
        if (is_struct(_hd)) {
            tsv_draw_dish(_c, _cx, _cy + 3, 15, is_struct(_hd[$ "dish"]) ? _hd.dish : string(_hd[$ "name"] ?? ""), true, false);
            tsv__fill(_c, "#9a2a1e"); tsv__ell(_c, _cx + 15, _cy - 14, 7.5, 7.5); tsv_cx_fill(_c);
            tsv__text(_c, string(_hd[$ "table"] ?? ""), _cx + 15, _cy - 13.5, 9, "#fbf5e3", 1, "center", TSV_FACE_DISPLAY);
        } else tsv__text(_c, "free", _cx, _cy, 11, [241, 223, 180], 0.4, "center", TSV_FACE_BODY);
    }
    var _kx = _w - 34, _tx0 = 116, _tx1 = _kx - 26, _tcx = (_tx0 + _tx1) / 2;
    var _cur = string(_info[$ "currency"] ?? ""), _l1 = string(_info[$ "tips"] ?? 0) + ((_cur != "") ? " " + _cur : "") + " in tips";
    tsv__text(_c, _l1, _tcx, _cy - 9, tsv__fit(_l1, _tx1 - _tx0, 13, TSV_FACE_DISPLAY), "#f1dfb4", 1, "center", TSV_FACE_DISPLAY);
    var _l2 = string(_info[$ "served"] ?? 0) + " served, " + string(_info[$ "walkouts"] ?? 0) + " walked out";
    tsv__text(_c, _l2, _tcx, _cy + 10, tsv__fit(_l2, _tx1 - _tx0, 12, TSV_FACE_BODY), "#c9b48a", 1, "center", TSV_FACE_BODY);
    // the clock
    var _ky = _cy; tsv__fill(_c, "#efe4c6"); tsv__ell(_c, _kx, _ky, 20, 20); tsv_cx_fill(_c); tsv__stroke(_c, "#c99a42", 1, 3); tsv_cx_stroke(_c);
    tsv__stroke(_c, tsv__ink(), 0.5, 1); for (var _t = 0; _t < 12; _t++) { var _ta = _t * TSV_TAU / 12; tsv__seg(_c, _kx + cos(_ta) * 15, _ky + sin(_ta) * 15, _kx + cos(_ta) * 18, _ky + sin(_ta) * 18); }
    var _p = clamp(tsv__fin(_info[$ "progress"], 0), 0, 1);
    if (_p > 0) { tsv__fill(_c, (_p >= 1) ? [160, 40, 30] : [180, 60, 40], (_p >= 1) ? 0.45 : 0.3); tsv_cx_begin(_c); tsv_cx_move(_c, _kx, _ky); tsv_cx_arc(_c, _kx, _ky, 16, -1.5708, -1.5708 + TSV_TAU * min(0.9999, _p)); tsv_cx_close(_c); tsv_cx_fill(_c); }
    var _a = -1.5708 + TSV_TAU * _p; tsv__stroke(_c, tsv__ink(), 1, 2); tsv__seg(_c, _kx, _ky, _kx + cos(_a) * 14, _ky + sin(_a) * 14);
    tsv__fill(_c, "#c99a42"); tsv__ell(_c, _kx, _ky, 2.2, 2.2); tsv_cx_fill(_c);
    tsv_cx_restore(_c);
    return 1;
}

/// @function tsv_draw_coins(ctx, x, baseY, n, w, gold)
/// @description A stack of n coins seen from the side, at (x, baseY), each w wide; gold or copper.
function tsv_draw_coins(_c, _x, _baseY, _n, _w, _gold) {
    if (!tsv__is_ctx(_c)) return 0;
    _gold = tsv__flag(_gold); _w = tsv__fin(_w, 10); _x = tsv__fin(_x, 0); _baseY = tsv__fin(_baseY, 0);
    _n = clamp(floor(tsv__fin(_n, 0)), 0, 200);
    for (var _i = 0; _i < _n; _i++) {
        var _y = _baseY - _i * (_w * 0.16), _g = tsv_cx_linear(_c, _x - _w / 2, 0, _x + _w / 2, 0);
        if (_gold) { tsv_cx_stop(_g, 0, tsv__hex("#8a5a14")); tsv_cx_stop(_g, 0.45, tsv__hex("#fbe7a4")); tsv_cx_stop(_g, 1, tsv__hex("#8a5a14")); }
        else { tsv_cx_stop(_g, 0, tsv__hex("#6a4a2a")); tsv_cx_stop(_g, 0.45, tsv__hex("#e0b484")); tsv_cx_stop(_g, 1, tsv__hex("#6a4a2a")); }
        _c.fill = _g; tsv__ell(_c, _x + (((_i * 7) mod 3) - 1), _y, _w / 2, _w * 0.14); tsv_cx_fill(_c); tsv__stroke(_c, [40, 20, 0], 0.55, 0.8); tsv_cx_stroke(_c);
    }
    return 1;
}

/// @function tsv_draw_star(ctx, x, y, r, filled)
/// @description A brass star (the night's rating), filled or hollow.
function tsv_draw_star(_c, _x, _y, _r, _filled) {
    if (!tsv__is_ctx(_c)) return 0;
    _filled = tsv__flag(_filled); _x = tsv__fin(_x, 0); _y = tsv__fin(_y, 0); _r = tsv__fin(_r, 10);
    tsv_cx_begin(_c);
    for (var _i = 0; _i < 10; _i++) { var _a = -1.5708 + _i * 0.6283, _rad = (_i mod 2) ? _r * 0.45 : _r; tsv_cx_line(_c, _x + cos(_a) * _rad, _y + sin(_a) * _rad); }
    tsv_cx_close(_c);
    if (_filled) { var _g = tsv_cx_linear(_c, _x - _r, _y - _r, _x + _r, _y + _r); tsv_cx_stop(_g, 0, tsv__hex("#fbe7a4")); tsv_cx_stop(_g, 1, tsv__hex("#9a6a1c")); _c.fill = _g; tsv_cx_fill(_c); }
    if (_filled) tsv__stroke(_c, "#5a3a08", 1, 1.5); else tsv__stroke(_c, [90, 70, 40], 0.6, 1.5);
    tsv_cx_stroke(_c);
    return 1;
}

/// @function tsv_draw_ledger(ctx, W, H, info)
/// @description The shift's ledger: a ruled page in the house book. The night's figures in the left column; takings and
/// tips as stacks of coins scaled together; every party a mark in the margin (a tick served, a cross walked out); the
/// night's favourite dish, drawn; the stars and the verdict. W x H (the whole screen, dimmed around the book).
/// info = { title, sub, served, parties, covers, takings, tips, currency, walkouts, longestWait, bestStreak, marks:
/// [true/false...], top: { dish, name, count } or undefined, stars, grade, foot }.
function tsv_draw_ledger(_c, _W, _H, _info) {
    if (!tsv__is_ctx(_c) || !is_struct(_info)) return 0;
    var _ink = tsv__ink(), _cur = string(_info[$ "currency"] ?? "");
    tsv__fill(_c, [10, 6, 3], 0.72); tsv_cx_fill_rect(_c, 0, 0, _W, _H);
    var _w = 520, _h = min(_H - 70, 440), _x = round(_W / 2 - _w / 2), _y = round((_H - _h) / 2) - 10;
    tsv_cx_save(_c);
    tsv__fill(_c, [0, 0, 0], 0.5); tsv__rr(_c, _x + 8, _y + 10, _w, _h, 6); tsv_cx_fill(_c);
    tsv__fill(_c, "#5a2a1a"); tsv__rr(_c, _x - 10, _y - 8, _w + 20, _h + 16, 8); tsv_cx_fill(_c);
    tsv__stroke(_c, "#c99a42", 1, 1.2); tsv__rr(_c, _x - 6, _y - 4, _w + 12, _h + 8, 6); tsv_cx_stroke(_c);
    var _g = tsv_cx_linear(_c, _x, 0, _x + _w, 0); tsv_cx_stop(_g, 0, tsv__hex("#e9dcb8")); tsv_cx_stop(_g, 0.08, tsv__hex("#f7eed6")); tsv_cx_stop(_g, 1, tsv__hex("#efe3c2")); _c.fill = _g; tsv__rr(_c, _x, _y, _w, _h, 4); tsv_cx_fill(_c);
    tsv__stroke(_c, [60, 110, 160], 0.25, 1); for (var _ly = _y + 78; _ly < _y + _h - 20; _ly += 26) tsv__seg(_c, _x + 18, _ly, _x + _w - 18, _ly);
    tsv__stroke(_c, [180, 60, 50], 0.45, 1); tsv__seg(_c, _x + 62, _y + 58, _x + 62, _y + _h - 16);
    var _title = string(_info[$ "title"] ?? "The evening shift");
    tsv__text(_c, _title, _x + _w / 2, _y + 28, tsv__fit(_title, _w - 40, 22, TSV_FACE_DISPLAY), _ink, 1, "center", TSV_FACE_DISPLAY);
    tsv__text(_c, string(_info[$ "sub"] ?? ""), _x + _w / 2, _y + 52, 14, _ink, 0.7, "center", TSV_FACE_BODY);
    var _rows = [["Parties served", string(_info[$ "served"] ?? 0) + " of " + string(_info[$ "parties"] ?? 0)], ["Dishes brought", string(_info[$ "covers"] ?? 0)],
        ["Takings", string(_info[$ "takings"] ?? 0) + ((_cur != "") ? " " + _cur : "")], ["Tips", string(_info[$ "tips"] ?? 0) + ((_cur != "") ? " " + _cur : "")],
        ["Walked out", string(_info[$ "walkouts"] ?? 0)], ["Longest wait", string(round(tsv__fin(_info[$ "longestWait"], 0) / 60)) + " s"], ["Best run", string(_info[$ "bestStreak"] ?? 0) + " in a row"]];
    for (var _i = 0; _i < array_length(_rows); _i++) {
        var _ry = _y + 91 + _i * 26;
        tsv__text(_c, _rows[_i][0], _x + 74, _ry, 16, _ink, 1, "left", TSV_FACE_BODY);
        tsv__text(_c, _rows[_i][1], _x + 318, _ry, 13, (_i == 4 && tsv__fin(_info[$ "walkouts"], 0) > 0) ? [154, 42, 30] : _ink, 1, "right", TSV_FACE_DISPLAY);
    }
    // every party a mark in the margin: a tick served, a cross walked out
    var _marks = is_array(_info[$ "marks"]) ? _info.marks : [];
    for (var _m = 0; _m < array_length(_marks) && _m < 18; _m++) {
        var _mx = _x + 22 + (_m mod 2) * 18, _my = _y + 84 + floor(_m / 2) * 20;
        if (_marks[_m] == true) { tsv__stroke(_c, [40, 110, 50], 0.9, 2); tsv_cx_begin(_c); tsv_cx_move(_c, _mx - 5, _my); tsv_cx_line(_c, _mx - 1, _my + 4); tsv_cx_line(_c, _mx + 6, _my - 6); tsv_cx_stroke(_c); }
        else { tsv__stroke(_c, [154, 42, 30], 0.9, 2); tsv_cx_begin(_c); tsv_cx_move(_c, _mx - 5, _my - 5); tsv_cx_line(_c, _mx + 5, _my + 5); tsv_cx_move(_c, _mx + 5, _my - 5); tsv_cx_line(_c, _mx - 5, _my + 5); tsv_cx_stroke(_c); }
    }
    // takings and tips as coin stacks, scaled together (tips can never look bigger than they were)
    var _takings = tsv__fin(_info[$ "takings"], 0), _tips = tsv__fin(_info[$ "tips"], 0), _unit = max(1, max(1, _takings) / 22), _baseY = _y + 272;
    tsv_draw_coins(_c, _x + 388, _baseY, max(1, round(_takings / _unit)), 36, false);
    tsv_draw_coins(_c, _x + 452, _baseY, (_tips > 0) ? max(1, round(_tips / _unit)) : 0, 36, true);
    tsv__text(_c, "takings", _x + 388, _baseY + 18, 13, _ink, 0.75, "center", TSV_FACE_BODY); tsv__text(_c, "tips", _x + 452, _baseY + 18, 13, _ink, 0.75, "center", TSV_FACE_BODY);
    // the night's favourite, drawn: the dish most ordered, and how many times
    var _top = _info[$ "top"];
    if (is_struct(_top)) {
        var _fy = _y + 294;
        tsv_draw_dish(_c, _x + 96, _fy, 20, _top[$ "dish"] ?? string(_top[$ "name"] ?? ""), true, false);
        tsv__text(_c, "The night's favourite", _x + 126, _fy - 9, 14, _ink, 0.7, "left", TSV_FACE_BODY);
        var _fav = string(_top[$ "name"] ?? "") + " x " + string(_top[$ "count"] ?? 0);
        tsv__text(_c, _fav, _x + 126, _fy + 10, tsv__fit(_fav, 200, 14, TSV_FACE_DISPLAY), _ink, 1, "left", TSV_FACE_DISPLAY);
    }
    var _st = clamp(floor(tsv__fin(_info[$ "stars"], 0)), 0, 3);
    for (var _s = 0; _s < 3; _s++) tsv_draw_star(_c, _x + _w / 2 - 54 + _s * 54, _y + _h - 72, 19, _s < _st);
    tsv__text(_c, string(_info[$ "grade"] ?? ""), _x + _w / 2, _y + _h - 34, 18, _ink, 1, "center", TSV_FACE_DISPLAY);
    tsv__text(_c, string(_info[$ "foot"] ?? ""), _W / 2, min(_H - 14, _y + _h + 26), 14, "#e8d4a8", 1, "center", TSV_FACE_BODY);
    tsv_cx_restore(_c);
    return 1;
}

/// @function tsv_draw_banner(ctx, w, h, title, sub)
/// @description The opening banner: a hanging painted sign with the shift's name and the night's size. w x h.
function tsv_draw_banner(_c, _w, _h, _title, _sub) {
    if (!tsv__is_ctx(_c)) return 0;
    _title = string(_title); _sub = string(_sub);
    tsv_cx_save(_c);
    tsv__stroke(_c, "#3a2a1a", 1, 2); tsv_cx_begin(_c); tsv_cx_move(_c, _w * 0.22, 0); tsv_cx_line(_c, _w * 0.26, 16); tsv_cx_move(_c, _w * 0.78, 0); tsv_cx_line(_c, _w * 0.74, 16); tsv_cx_stroke(_c);
    tsv__fill(_c, [0, 0, 0], 0.4); tsv__rr(_c, 14, 18, _w - 24, _h - 22, 10); tsv_cx_fill(_c);
    var _g = tsv_cx_linear(_c, 0, 14, 0, _h - 6); tsv_cx_stop(_g, 0, tsv__hex("#6a3a1e")); tsv_cx_stop(_g, 1, tsv__hex("#3a1e0e")); _c.fill = _g; tsv__rr(_c, 10, 14, _w - 24, _h - 22, 10); tsv_cx_fill(_c);
    tsv__stroke(_c, "#d9aa4a", 1, 2); tsv__rr(_c, 16, 20, _w - 36, _h - 34, 7); tsv_cx_stroke(_c);
    tsv__text(_c, _title, _w / 2 - 2, _h * 0.47, tsv__fit(_title, _w - 70, 24, TSV_FACE_DISPLAY), "#f6e2b0", 1, "center", TSV_FACE_DISPLAY);
    tsv__text(_c, _sub, _w / 2 - 2, _h * 0.75, tsv__fit(_sub, _w - 80, 14, TSV_FACE_BODY), "#d9c090", 1, "center", TSV_FACE_BODY);
    tsv_cx_restore(_c);
    return 1;
}

// ---------------------------------------------------------------------------------------------------------------
// The furniture (a GameMaker addition: the MZ edition used the buyer's map tiles)
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv__cloths()
/// @description Internal. The four tablecloths: linen with a red scalloped hem, sage gingham, a wine damask, a blue check.
function tsv__cloths() {
    static _K = [
        { name: "linen", base: "#f6f1e4", shade: "#ddd3bc", hem: "#a8303a", check: "" },
        { name: "gingham", base: "#eef2e4", shade: "#c8d4b6", hem: "#5a7a4a", check: "#8aa878" },
        { name: "damask", base: "#8a2a34", shade: "#5e1a22", hem: "#e2c06a", check: "" },
        { name: "bluecheck", base: "#eef1f6", shade: "#c4cede", hem: "#2f5f8a", check: "#6a8ab8" }
    ];
    return _K;
}

/// @function tsv_draw_table(ctx, x, y, r, cloth)
/// @description A round dining table seen from the front at a slant, centred on (x, y), top radius r: a clothed top with
/// a scalloped (or fringed) hem falling to the floor, a soft floor shadow, a small vase of flowers at the back. cloth 0..3
/// (linen, gingham, damask, blue check). Returns 1 when drawn.
/// @returns {Real}
function tsv_draw_table(_c, _x, _y, _r, _cloth = 0) {
    if (!tsv__is_ctx(_c)) return 0;
    _r = clamp(tsv__fin(_r, 26), 6, 512);
    var _K = tsv__cloths()[clamp(floor(tsv__fin(_cloth, 0)), 0, 3)], _ry = _r * 0.55, _drop = _r * 0.62, _i;
    tsv_cx_save(_c);
    tsv__fill(_c, [0, 0, 0], 0.3); tsv__ell(_c, _x + _r * 0.08, _y + _drop + _r * 0.1, _r * 1.1, _r * 0.32); tsv_cx_fill(_c);
    // the skirt: the cloth falling from the rim, shaded toward its sides, its hem scalloped
    var _g = tsv_cx_linear(_c, _x - _r, 0, _x + _r, 0); tsv_cx_stop(_g, 0, tsv__shade(_K.shade, -10)); tsv_cx_stop(_g, 0.4, tsv__hex(_K.base)); tsv_cx_stop(_g, 1, tsv__shade(_K.shade, -24));
    _c.fill = _g; tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r, _y);
    var _n = 10;
    tsv_cx_line(_c, _x - _r * 1.02, _y + _drop);
    for (_i = 0; _i < _n; _i++) { var _a0 = _x - _r * 1.02 + _i * _r * 2.04 / _n, _a1 = _a0 + _r * 2.04 / _n; tsv_cx_quad(_c, (_a0 + _a1) / 2, _y + _drop + _r * 0.14 * (1 - abs(((_a0 + _a1) / 2 - _x) / _r) * 0.5), _a1, _y + _drop); }
    tsv_cx_line(_c, _x + _r, _y); tsv_cx_close(_c); tsv_cx_fill(_c);
    // folds
    tsv__stroke(_c, _K.shade, 0.6, max(1, _r * 0.03));
    for (_i = -2; _i <= 2; _i++) tsv__seg(_c, _x + _i * _r * 0.36, _y + _ry * 0.6, _x + _i * _r * 0.4, _y + _drop - 2);
    // the hem band
    tsv__stroke(_c, _K.hem, 1, max(1.5, _r * 0.07)); tsv_cx_begin(_c); tsv_cx_move(_c, _x - _r * 1.02, _y + _drop - _r * 0.06);
    for (_i = 0; _i < _n; _i++) { var _b0 = _x - _r * 1.02 + _i * _r * 2.04 / _n, _b1 = _b0 + _r * 2.04 / _n; tsv_cx_quad(_c, (_b0 + _b1) / 2, _y + _drop + _r * 0.08, _b1, _y + _drop - _r * 0.06); }
    tsv_cx_stroke(_c);
    // the top
    var _gt = tsv_cx_radial(_c, _x - _r * 0.3, _y - _ry * 0.4, _r * 0.1, _x, _y, _r * 1.1); tsv_cx_stop(_gt, 0, tsv__shade(_K.base, 14)); tsv_cx_stop(_gt, 0.7, tsv__hex(_K.base)); tsv_cx_stop(_gt, 1, tsv__hex(_K.shade));
    _c.fill = _gt; tsv__ell(_c, _x, _y, _r, _ry); tsv_cx_fill(_c);
    if (_K.check != "") {
        tsv_cx_save(_c); tsv__ell(_c, _x, _y, _r, _ry); tsv_cx_clip(_c);
        tsv__fill(_c, _K.check, 0.35);
        var _cs = max(3, _r * 0.18);
        for (var _gx = _x - _r; _gx < _x + _r; _gx += _cs * 2) tsv_cx_fill_rect(_c, _gx, _y - _ry, _cs, _ry * 2);
        for (var _gy = _y - _ry; _gy < _y + _ry; _gy += _cs * 2 * 0.55) tsv_cx_fill_rect(_c, _x - _r, _gy, _r * 2, _cs * 0.55);
        tsv_cx_restore(_c);
    }
    tsv__stroke(_c, tsv__shade(_K.shade, -30), 0.7, max(0.8, _r * 0.025)); tsv__ell(_c, _x, _y, _r, _ry); tsv_cx_stroke(_c);
    tsv__stroke(_c, _K.hem, 0.8, max(1, _r * 0.035)); tsv__ell(_c, _x, _y, _r * 0.88, _ry * 0.86); tsv_cx_stroke(_c);
    // a little vase with three flowers at the back of the top
    var _vx = _x - _r * 0.55, _vy = _y - _ry * 0.35;
    tsv__fill(_c, "#3a6a9a"); tsv__rr(_c, _vx - _r * 0.07, _vy - _r * 0.16, _r * 0.14, _r * 0.18, _r * 0.05); tsv_cx_fill(_c); tsv__outline(_c, _r * 0.02);
    tsv__stroke(_c, "#3f7a2a", 1, max(0.8, _r * 0.025));
    static _fl = [[-0.08, -0.34, "#e8506a"], [0.0, -0.4, "#f2cc5a"], [0.08, -0.33, "#f6f1e4"]];
    for (_i = 0; _i < 3; _i++) { tsv__seg(_c, _vx, _vy - _r * 0.14, _vx + _fl[_i][0] * _r, _vy + _fl[_i][1] * _r); }
    for (_i = 0; _i < 3; _i++) { tsv__leaf(_c, _vx + _fl[_i][0] * _r, _vy + _fl[_i][1] * _r, _r * 0.05, _r * 0.05, 0, _fl[_i][2]); }
    tsv_cx_restore(_c);
    return 1;
}

/// @function tsv_draw_chair(ctx, x, y, s, dir)
/// @description A turned-wood dining chair seen from the front, its seat's centre at (x, y), s the figure cell (48):
/// dir is the way its sitter FACES (2 down: the back rises behind; 4 / 6: seen from the side; 8 up: the back in front).
/// Returns 1 when drawn.
/// @returns {Real}
function tsv_draw_chair(_c, _x, _y, _s, _dir) {
    if (!tsv__is_ctx(_c)) return 0;
    var _u = clamp(tsv__fin(_s, 48), 8, 1024) / 48, _wood = "#7a4a26", _dk = "#4a2a14", _lt = "#a8743e";
    tsv_cx_save(_c);
    tsv__fill(_c, [0, 0, 0], 0.25); tsv__ell(_c, _x + 1 * _u, _y + 9 * _u, 12 * _u, 3.4 * _u); tsv_cx_fill(_c);
    if (_dir == 4 || _dir == 6) {
        var _sd = (_dir == 6) ? -1 : 1;   // the back is on the side away from the table
        tsv__fill(_c, _dk); tsv_cx_fill_rect(_c, _x - 8 * _u, _y, 2.4 * _u, 9 * _u); tsv_cx_fill_rect(_c, _x + 6 * _u, _y, 2.4 * _u, 9 * _u);
        tsv__fill(_c, _wood); tsv__rr(_c, _x - 10 * _u, _y - 2 * _u, 20 * _u, 4 * _u, 1.5 * _u); tsv_cx_fill(_c); tsv__outline(_c, 0.8 * _u);
        tsv__fill(_c, _wood); tsv__rr(_c, _x + _sd * 8 * _u - 1.5 * _u, _y - 22 * _u, 3.4 * _u, 22 * _u, 1.4 * _u); tsv_cx_fill(_c); tsv__outline(_c, 0.8 * _u);
        tsv__fill(_c, _lt, 0.6); tsv_cx_fill_rect(_c, _x + _sd * 8 * _u - 0.8 * _u, _y - 20 * _u, 1 * _u, 18 * _u);
    } else {
        var _front = (_dir == 8);
        var _back = function(_c, _x, _y, _u, _wood, _dk, _lt) {
            tsv__fill(_c, _wood); tsv__rr(_c, _x - 10 * _u, _y - 24 * _u, 20 * _u, 5 * _u, 2 * _u); tsv_cx_fill(_c); tsv__outline(_c, 0.8 * _u);
            tsv__fill(_c, _dk); tsv_cx_fill_rect(_c, _x - 9 * _u, _y - 20 * _u, 2.6 * _u, 20 * _u); tsv_cx_fill_rect(_c, _x + 6.4 * _u, _y - 20 * _u, 2.6 * _u, 20 * _u);
            tsv__fill(_c, _wood); for (var _k = -1; _k <= 1; _k++) tsv_cx_fill_rect(_c, _x + _k * 4 * _u - 0.9 * _u, _y - 19 * _u, 1.8 * _u, 17 * _u);
            tsv__fill(_c, _lt, 0.7); tsv_cx_fill_rect(_c, _x - 8 * _u, _y - 23 * _u, 16 * _u, 1 * _u);
        };
        if (!_front) _back(_c, _x, _y, _u, _wood, _dk, _lt);
        tsv__fill(_c, _dk); tsv_cx_fill_rect(_c, _x - 9 * _u, _y, 2.4 * _u, 9 * _u); tsv_cx_fill_rect(_c, _x + 6.6 * _u, _y, 2.4 * _u, 9 * _u);
        tsv__fill(_c, _wood); tsv__rr(_c, _x - 11 * _u, _y - 3 * _u, 22 * _u, 5 * _u, 2 * _u); tsv_cx_fill(_c); tsv__outline(_c, 0.8 * _u);
        if (_front) _back(_c, _x, _y + 6 * _u, _u, _wood, _dk, _lt);
    }
    tsv_cx_restore(_c);
    return 1;
}

// ---------------------------------------------------------------------------------------------------------------
// The bake layer: every picture drawn ONCE into a sprite, cached
// ---------------------------------------------------------------------------------------------------------------

/// @function tsv_bake(w, h, ox, oy, painter, args, [res])
/// @description Bake a picture into a PREMULTIPLIED sprite w x h (origin ox, oy): painter(ctx, args) draws it through
/// the canvas kit at 2x and it is filtered down. res > 1 bakes a sharper sprite for a store image or a zoomed camera
/// (the sprite is res x the size; draw it at 1 / res). Costs a bake: keep the sprite, sprite_delete it when done, and
/// draw it with tsv_draw_premul. -1 for a bad size or painter.
/// @returns {Asset.GMSprite}
function tsv_bake(_w, _h, _ox, _oy, _painter, _args, _res = 1) {
    if (!is_numeric(_w) || !is_numeric(_h) || !(_w >= 1) || !(_h >= 1) || _w > 2048 || _h > 2048) return -1;
    if (!is_method(_painter)) return -1;
    _res = is_numeric(_res) ? clamp(_res, 0.25, 4) : 1;
    var _pw = max(1, ceil(_w * _res)), _ph = max(1, ceil(_h * _res));
    var _s2 = surface_create(_pw * 2, _ph * 2), _s1 = surface_create(_pw, _ph);
    var _pm = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    surface_set_target(_s2); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    var _c = tsv_cx_create(2); tsv_cx_scale(_c, _res, _res); tsv_cx_translate(_c, _ox, _oy);
    _painter(_c, _args);
    gpu_pop_state(); surface_reset_target();
    surface_set_target(_s1); draw_clear_alpha(c_black, 0);
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_zero); gpu_set_texfilter(true); draw_surface_ext(_s2, 0, 0, 0.5, 0.5, 0, c_white, 1); gpu_pop_state();
    surface_reset_target();
    var _spr = sprite_create_from_surface(_s1, 0, 0, _pw, _ph, false, false, _ox * _res, _oy * _res);
    surface_free(_s2); surface_free(_s1);
    matrix_set(matrix_world, _pm);
    return _spr;
}

/// @function tsv_draw_premul(sprite, x, y, [xscale], [yscale], [rot], [alpha])
/// @description Draw a PREMULTIPLIED sprite (every Table Service bake) correctly: bm_one / bm_inv_src_alpha, the colour
/// scaled by alpha. The caller's blend mode is restored. A sprite that does not exist is skipped.
function tsv_draw_premul(_spr, _x, _y, _xs = 1, _ys = 1, _rot = 0, _a = 1) {
    var _ok = false;
    try { _ok = sprite_exists(_spr); } catch (_e) { _ok = false; }
    if (!_ok || !is_numeric(_a) || !(_a > 0) || !is_numeric(_x) || !is_numeric(_y) || !is_numeric(_xs) || !is_numeric(_ys) || !is_numeric(_rot)) return;
    gpu_push_state(); gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    var _al = clamp(_a, 0, 1);
    draw_sprite_ext(_spr, 0, _x, _y, _xs, _ys, _rot, merge_colour(c_black, c_white, _al), _al);
    gpu_pop_state();
}

/// @function tsv__cache()
/// @description Internal. The shared sprite cache (a struct of key -> sprite).
function tsv__cache() { if (!variable_global_exists("tsv_sprite_cache") || !is_struct(global.tsv_sprite_cache)) global.tsv_sprite_cache = {}; return global.tsv_sprite_cache; }

/// @function tsv_cache_clear()
/// @description Delete every cached Table Service sprite (dishes, diners, furniture, marks). Call it when you leave the
/// restaurant for good; anything drawn again is simply re-baked. Returns how many sprites were freed.
/// @returns {Real}
function tsv_cache_clear() {
    var _C = tsv__cache(), _k = variable_struct_get_names(_C), _n = 0;
    for (var _i = 0; _i < array_length(_k); _i++) { var _s = _C[$ _k[_i]]; if (sprite_exists(_s)) { sprite_delete(_s); _n++; } }
    global.tsv_sprite_cache = {};
    return _n;
}

/// @function tsv__cached(key, w, h, ox, oy, painter, args, res)
/// @description Internal. A cached bake.
function tsv__cached(_key, _w, _h, _ox, _oy, _painter, _args, _res = 1) {
    var _C = tsv__cache(), _hit = _C[$ _key];
    if (!is_undefined(_hit) && sprite_exists(_hit)) return _hit;
    var _spr = tsv_bake(_w, _h, _ox, _oy, _painter, _args, _res);
    if (_spr >= 0) _C[$ _key] = _spr;
    return _spr;
}

/// @function tsv_dish_sprite(dish, r, [hot], [eaten], [res])
/// @description A dish as a cached premultiplied sprite, origin at the dish's centre, size r (a plate's radius): the
/// same name, size and state is baked once. dish is a name or { name, form, colour }. Draw with tsv_draw_premul.
/// @returns {Asset.GMSprite}
function tsv_dish_sprite(_dish, _r, _hot = false, _eaten = false, _res = 1) {
    _hot = tsv__flag(_hot); _eaten = tsv__flag(_eaten); _res = is_numeric(_res) ? clamp(_res, 0.25, 4) : 1;
    _r = clamp(floor(tsv__fin(_r, 17)), 4, 256);
    var _nm = is_struct(_dish) ? string(_dish[$ "name"] ?? "") + "|" + string(_dish[$ "form"] ?? "") + "|" + string(_dish[$ "colour"] ?? "") : string(_dish);
    var _key = "dish|" + _nm + "|" + string(_r) + "|" + string(_hot ? 1 : 0) + string(_eaten ? 1 : 0) + "|" + string(_res);
    var _box = ceil(_r * 1.9);
    return tsv__cached(_key, _box * 2, _box * 2, _box, _box, function(_c, _a) { tsv_draw_dish(_c, 0, 0, _a.r, _a.dish, _a.hot, _a.eaten); }, { r: _r, dish: _dish, hot: _hot, eaten: _eaten }, _res);
}

/// @function tsv_diner_sprite(look, dir, pose, [s], [res])
/// @description A figure as a cached premultiplied sprite with a dark one-pixel outline round its whole silhouette (the
/// way hand-drawn character art separates from any floor): an s x s cell (default 48), origin at the cell's bottom
/// centre. look from tsv_diner_look (or tsv_server_look); dir 2 / 4 / 6 / 8; pose "seat", "walk0", "walk1", "walk2".
/// @returns {Asset.GMSprite}
function tsv_diner_sprite(_look, _dir, _pose, _s = 48, _res = 1) {
    if (!tsv__look_ok(_look)) return -1;
    _s = clamp(floor(tsv__fin(_s, 48)), 16, 256);
    if (_dir != 2 && _dir != 4 && _dir != 6 && _dir != 8) _dir = 2;
    if (_pose != "seat" && _pose != "walk0" && _pose != "walk2") _pose = (_pose == "walk1") ? "walk1" : "seat";
    var _key = "fig|" + _look.skin + _look.hair + _look.style + _look.hat + _look.coat + _look.shirt + _look.extra + _look.hatColour + _look.trim + string(_look[$ "apron"] == true) + "|" + string(_dir) + _pose + "|" + string(_s) + "|" + string(_res);
    var _C = tsv__cache(), _hit = _C[$ _key];
    if (!is_undefined(_hit) && sprite_exists(_hit)) return _hit;
    var _pad = 2, _W = _s + _pad * 2;
    var _raw = tsv_bake(_W, _W, _pad, _pad, function(_c, _a) { tsv_draw_figure(_c, 0, 0, _a.s, _a.look, _a.dir, _a.pose); }, { s: _s, look: _look, dir: _dir, pose: _pose }, _res);
    if (_raw < 0) return -1;
    // the outline: the silhouette in a dark ink at four one-pixel offsets, then the figure over it
    var _pw = sprite_get_width(_raw), _ph = sprite_get_height(_raw), _k = max(1, round(_s / 48 * _res));
    var _surf = surface_create(_pw, _ph), _pm = matrix_get(matrix_world); matrix_set(matrix_world, matrix_build_identity());
    surface_set_target(_surf); draw_clear_alpha(c_black, 0);
    // ⛔ the silhouette is fog colour x ALPHA (premultiplied): under bm_one the fog colour landed on every pixel of the
    // cell, alpha 0 included, and drew an orange box behind every figure (seen in the first floor render, 2026-10-22)
    gpu_push_state(); gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    gpu_set_fog(true, make_colour_rgb(22, 12, 6), 0, 0);
    draw_sprite_ext(_raw, 0, _pad * _res - _k, _pad * _res, 1, 1, 0, c_white, 0.92); draw_sprite_ext(_raw, 0, _pad * _res + _k, _pad * _res, 1, 1, 0, c_white, 0.92);
    draw_sprite_ext(_raw, 0, _pad * _res, _pad * _res - _k, 1, 1, 0, c_white, 0.92); draw_sprite_ext(_raw, 0, _pad * _res, _pad * _res + _k, 1, 1, 0, c_white, 0.92);
    gpu_set_fog(false, c_black, 0, 0);
    gpu_set_blendmode_ext_sepalpha(bm_one, bm_inv_src_alpha, bm_one, bm_inv_src_alpha);
    draw_sprite_ext(_raw, 0, _pad * _res, _pad * _res, 1, 1, 0, c_white, 1);
    gpu_pop_state(); surface_reset_target();
    var _spr = sprite_create_from_surface(_surf, 0, 0, _pw, _ph, false, false, (_pad + _s / 2) * _res, (_pad + _s) * _res);
    surface_free(_surf); matrix_set(matrix_world, _pm);
    sprite_delete(_raw);
    _C[$ _key] = _spr;
    return _spr;
}
