{
  "$GMScript": "v1",
  "%Name": "tsv_oracle_core",
  "name": "tsv_oracle_core",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}