# Table Service - A Restaurant Serving Minigame for GameMaker

A serving shift for any GameMaker room: customers walk in from your door, sit at your tables, ring for service, order and
wait while their candle burns down; the player takes orders, carries dishes from the kitchen pass two at a time and serves
the right table before patience runs out. At closing time a ledger page counts the takings and tips and gives the night
up to three stars. Use it as a tavern job in an RPG, a cafe minigame in a life sim, or the base of a whole restaurant game.

- **Every customer is generated and drawn by the package:** face, skin, hair colour and style, a hat (flat cap, brimmed
  hat, beret, hood or headscarf), coat, shirt and one extra (scarf, glasses, beard, earring) from a seed - over a million
  combinations - seated facing their table or walking in four directions, outlined so they read on any floor.
- **Every dish is drawn FROM ITS NAME.** Name a dish on your menu and the package reads it: "Pumpkin Soup" is a bowl the
  colour of pumpkin, "Pale Ale" a tankard with a head of foam, "Grilled Trout" a whole fish with lemon, "Mana Tonic" a
  corked glass bottle. About 170 words across 19 kinds of dish and drink, coloured by words like honey, berry, mint or
  frost; a name it does not know still gets a plated dish, the same one every time. A menu entry can name its form and
  colour outright. Dish words are English.
- **The floor is drawn too:** round clothed tables in four cloths (linen with a red scalloped hem, gingham, damask, blue
  check) with a little vase of flowers, turned-wood chairs, paper order tickets with a red pin and the dishes drawn and
  ticked off as they land, a brass service bell that sways, a candle whose wax burns down with the party's patience and
  gutters red near the end, steaming dishes at the pass with a flag for their table, floating tags (served, a tip, walked
  out), the server's tray with a brass shift clock, an opening banner and the closing ledger page. No image file is loaded.
- **The rules are a pure, seeded core:** the same seed deals the same night. Three nights (easy, normal, busy) measured,
  not guessed: a quick server earns two stars on normal, and longer walks cost a star.
- **Customers walk round your tables**, on a motion-planning grid the package builds from your floor (mp_grid), never
  through one.

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `TableService.yymps`, and import everything.
2. Run the project with `rm_tsv_demo` first in the room order. The demo is THE DINING ROOM: eight tables (three with two
   seats), the kitchen pass under the hatch and the door at the foot of the runner. Arrows or WASD walk the server; SPACE,
   ENTER or E acts (take an order, serve, pick up at the pass); a left click walks there and acts on arrival. 1, 2 and 3
   start an easy, normal or busy night, R restarts it, M shows every dish on the house menu and C forty customers.

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML, no shader, no
extension; nothing here depends on GMRT.

## Quickstart

Place `obj_tsv_table` instances where your tables go (set `seats = 2;` or `cloth = 1;` in an instance's Creation Code),
one `obj_tsv_pass` at the kitchen counter and one `obj_tsv_door`. Then, in your player object (the night only needs the
player's position when they act):

```gml
// Create - read the floor from the room and open the restaurant
my_floor = tsv_floor_from_room();
my_night = tsv_night_start(my_floor, { seed: 7, difficulty: "normal", title: "The Gilded Ladle" });

// Step - run the night; the player's ONE action is decided by where they stand
tsv_night_update(my_night);
if (keyboard_check_pressed(vk_space)) {
    var my_result = tsv_night_act(my_night, x, y);   // "order", "serve", "pickup", "putdown", "wrong" or ""
}
if (tsv_night_over(my_night) && keyboard_check_pressed(vk_enter)) {
    var my_score = tsv_night_score(my_night);   // { served, walkouts, takings, tips, stars, grade, ... }
    show_debug_message(my_score.grade + ", " + string(my_score.stars) + " stars");
}

// Draw - the tables, customers, candles, tickets and the pass, in room coordinates over your own floor art
tsv_night_draw(my_night);

// Draw GUI - the server's tray, then the opening banner and (at closing time) the ledger page
tsv_night_draw_hud(my_night, 12, display_get_gui_height() - 80);
tsv_night_draw_overlay(my_night);

// Clean Up
tsv_night_free(my_night);
```

No room objects? Build the floor in code instead:

```gml
my_floor = tsv_floor_create();
tsv_floor_add_table(my_floor, 160, 240, 1, 0);     // x, y, seats (1 or 2), cloth (0..3); returns the table's number
tsv_floor_add_table(my_floor, 340, 240, 2, 1);
tsv_floor_set_pass(my_floor, 600, 120);
tsv_floor_set_door(my_floor, 600, 460);
tsv_floor_block(my_floor, 0, 0, 640, 110);         // a counter or wall customers must walk round
```

## Your menu

The default is the house menu, `tsv_menu_house()`: sixteen dishes from Roast Fowl to Mana Tonic. Give your own as an
array of names or of structs; price defaults to 10, cook time (frames) to what the dish is (a drink is poured, a bowl
ladled, a plate cooked):

```gml
var my_menu = [
    { name: "Frost Lager", price: 18 },
    { name: "Dragon Pepper Stew", price: 52, cook: 300 },
    { name: "Moon Bread", price: 20, form: "bread", colour: "blue" },   // a form or colour given outright wins
    "Honey Cake"
];
my_night = tsv_night_start(my_floor, { seed: 3, difficulty: "busy", menu: my_menu, currency: "gold" });
```

The 20 forms are `tsv_dish_forms()`: bottle, mug, cup, glass, soup, stew, pie, cake, bread, fish, roast, sausage, steak,
noodles, rice, egg, cheese, salad, fruit, plate. `tsv_dish_look(name)` tells you what a name will be drawn as
(`{ form, colour, known, word }`: `word` is the word it was read from).

## The rules (tell your players)

Customers arrive through the night, faster as it goes on, and take a free seat. A seated party rings its bell: walk to
the table and act to take the order. The kitchen cooks each dish in turn; finished dishes wait at the pass with a flag
for their table. Act at the pass to pick one up (two hands); act at the table to serve what is theirs (a dish for another
table stays in your hand; with both hands full, act at the pass to put one down). When a party has everything it eats,
then pays on leaving: the bill, plus a tip for the patience left on its candle. A candle that burns out is a party that
walks out, and anything of theirs in the kitchen, at the pass or in your hands is wasted.

Stars: three for every party served with at least 60% of the best possible tips; two for 80% served and 35% of the tips;
one for half served.

| Night | Parties | Patience | Length |
| --- | --- | --- | --- |
| easy | 8 | 40 s | 90 s |
| normal | 12 | 35 s | 105 s |
| busy | 15 | 31 s | 120 s |

## The night: start, run, act, draw

| Function | Does |
| --- | --- |
| `tsv_night_start(floor, options)` | opens one night; options `seed`, `difficulty`, `menu`, `title`, `currency`, `seed_looks` |
| `tsv_night_update(night)` | runs one frame; returns this frame's events (`seated`, `ready`, `walked`, `paid`, `close`) for your sounds |
| `tsv_night_act(night, x, y)` | the player's one action from where they stand |
| `tsv_night_hint(night, x, y)` | what that action would do, as words for a prompt ("take the order", "serve", "pick up") |
| `tsv_night_near(night, x, y)` | what is in reach: `{ kind: "pass" or "table", table, dist }` |
| `tsv_night_draw(night, actors)` | the live layer; `actors` sorts your player in among the tables by their feet |
| `tsv_night_draw_hud(night, x, y)` | the tray (300 x 68) |
| `tsv_night_draw_overlay(night, w, h)` | the banner and the ledger page |
| `tsv_night_over(night)`, `tsv_night_score(night)`, `tsv_night_ledger_info(night)` | the end and its figures |
| `tsv_night_free(night)` | frees the night's sprites, paths and grid |

`tsv_night_draw` takes your player so they pass behind and in front of tables correctly. Bind the draw function to the
player with `method(id, ...)`: a function written inside a struct literal belongs to the struct, and `draw_self` there has
no instance to draw.

```gml
tsv_night_draw(my_night, [{ y: y, draw: method(id, function() { draw_self(); }) }]);   // in the player's Draw event
```

## The rules core, on its own

The shift's rules are a pure core with no drawing, for your own presentation or a server AI: `tsv_plan`,
`tsv_shift_new`, `tsv_shift_tick`, `tsv_shift_take_order`, `tsv_shift_pick_up`, `tsv_shift_deliver`,
`tsv_shift_put_down`, `tsv_shift_score`, and `tsv_hash_string` / `tsv_rng` / `tsv_rand` for the seeded generator.

```gml
var my_plan = tsv_plan({ seed: 12, difficulty: "normal", seats: [{ id: 1 }, { id: 2 }], menu: [{ id: 1, price: 30, cook: 220 }] });
var my_shift = tsv_shift_new(my_plan);
tsv_shift_tick(my_shift, 600);                       // ten seconds
show_debug_message(string(array_length(my_shift.parties)) + " parties tonight");
```

The server's verbs on the core, each refusing (false or 0) when the moment is wrong, and the floor's two helpers:

```gml
var my_taken = tsv_shift_take_order(my_shift, 1);    // party 1 is seated: its order goes to the kitchen
tsv_shift_tick(my_shift, 900);
var my_picked = tsv_shift_pick_up(my_shift, 0);      // the first dish waiting at the pass, into a free hand
var my_back = tsv_shift_put_down(my_shift, 0);       // a carried dish back on the pass
tsv_shift_pick_up(my_shift, 0);
var my_landed = tsv_shift_deliver(my_shift, 1);      // dishes handed over (only party 1's own count)
var my_ledger = tsv_shift_score(my_shift);           // { served, walkouts, takings, tips, tipShare, stars, grade, ... }
var my_gen = tsv_rng(tsv_hash_string("table 4"));    // a seeded generator keyed to a word
var my_draw = tsv_rand(my_gen);                      // 0 .. 1
var my_seats = tsv_floor_seats(my_floor);            // every seat: { id, table, x, y, dir }
var my_solid = tsv_floor_finish(my_floor);           // rebuild the walking grid after changing the floor
```

## Drawing directly

Every picture is available on its own, baked into a cached sprite the first time it is drawn (draw cached sprites with
`tsv_draw_premul`; they are premultiplied):

```gml
var my_dish = tsv_dish_sprite("Pumpkin Soup", 24, true, false);        // name, size, steaming, eaten
tsv_draw_premul(my_dish, 200, 150);
var my_look = tsv_diner_look(42);                                      // the same seed is always the same customer
tsv_draw_premul(tsv_diner_sprite(my_look, 2, "seat"), 300, 180);       // facing 2 / 4 / 6 / 8; "seat", "walk0", "walk1", "walk2"
```

`tsv_cache_clear()` frees every cached sprite. For your own pictures the drawing functions take a canvas-kit context and
`tsv_bake(w, h, ox, oy, painter, args)` turns any of them into a sprite (the painter receives the context):

```gml
var my_card = tsv_bake(260, 140, 0, 0, function(my_ctx, my_args) {
    tsv_draw_chair(my_ctx, 190, 83, 48, 2);                                 // seat centre x, y, cell size, facing
    tsv_draw_table(my_ctx, 190, 100, 26, 2);                                // centre x, y, top radius, cloth 0..3
    tsv_draw_figure(my_ctx, 166, 40, 48, tsv_diner_look(9), 2, "seat");     // cell top-left, size, look, facing, pose
    tsv_draw_dish(my_ctx, 196, 103, 12, "Plum Cake", false, false);         // centre, size, name, steaming, eaten
    tsv_draw_ticket(my_ctx, 120, 72, { table: 3, dishes: [{ name: "Plum Cake", done: false }] });   // at the top left
}, 0);
tsv_draw_premul(my_card, 40, 300);
```

`tsv_draw_ledger`, `tsv_draw_hud`, `tsv_draw_pass`, `tsv_draw_bell`, `tsv_draw_wax`, `tsv_draw_flame`, `tsv_draw_tag`,
`tsv_draw_coins`, `tsv_draw_star` and `tsv_draw_banner` draw the night's other pictures the same way; each is
documented in its script header (`tsv_draw`).

## Licence

One commercial licence, unlimited games: see LICENSE.txt. The two typefaces are SIL Open Font License 1.1 (see
`fonts/THIRD-PARTY-NOTICES.txt`). Written with AI assistance.
