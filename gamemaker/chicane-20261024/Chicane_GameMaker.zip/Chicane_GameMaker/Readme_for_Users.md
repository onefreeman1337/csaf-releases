# Chicane - Top-Down Racing for GameMaker

A top-down racing system in pure GML. Every circuit is **generated from a seed and drawn by the package**, and the race
layer every GameMaker racing project hand-rolls is done: live positions, laps and sector times, checkpoint gates that
refuse a cut corner, a computed racing line with braking points, AI drivers of set skill that follow it, pull out of the
tow to overtake and cover the inside to defend, and a broadcast-style HUD. Use it for a whole racing game, a kart
minigame in an RPG, or a chase level.

- **Generated circuits, eight themes.** A circuit is a loop of straights and circular corners (hairpins at sharp corners,
  sweepers at open ones, a chicane pushed into some long straights), checked before you ever see it: no corner tighter than
  the theme's car can drive, and no two parts of the track closer than both tracks plus both run-offs. The same seed and
  theme always give the same circuit. Themes: Grand Prix, Street Circuit, Desert Rally, Snow Rally, Forest Circuit,
  Harbour Circuit, Night City and Kart Track - each with its own width, grip, road surface and scenery.
- **Every circuit is drawn, once, into one sprite:** grass with mowing stripes (or paving, sand dunes, snowfield), the road
  with aggregate grain, a darker rubbered racing line and braking streaks, white edge lines, red-and-white kerbs on the
  inside of every corner and the outside of its exit, gravel traps with tapered ends, painted tarmac run-off, armco with
  posts, stacked tyre walls, concrete walls with catch fencing on street circuits, a chequered start line and numbered
  grid boxes, a pit lane with its wall, apron, pit boxes and garages (grand prix and forest circuits whose start straight
  has room for one), grandstands packed with spectators, broadleaf trees,
  pines (snow-tipped on snow), palms and cacti, marshal posts, buildings with rooftop plant, a harbour with boats, street
  lamps whose light pools on the road at night, straw bales and marker poles on rally stages, and skid marks that build
  up as the race is run. No image file is loaded.
- **Cars are drawn too:** four bodies (formula, kart, rally, saloon) with generated liveries - sixteen team colours, six
  patterns (plain, twin stripes, side bands, chevron, halves, sash), a race number and a helmet colour - each with its own
  shadow. Or give a car your own sprite.
- **The race layer:** 24 checkpoint gates per lap; positions from credited gates (so a car cannot gain by cutting); gaps
  timed at the gates; lap and sector times with the purple / green / yellow code; a five-light start; events for laps,
  fastest laps, finishes, cuts, penalties and contacts.

## Install

1. In GameMaker, **Tools > Import Local Package**, choose `Chicane.yymps`, and import everything.
2. Run the project with `rm_chc_demo` first in the room order. The demo is THE GRAND PRIX: you start on the grid with
   seven AI drivers. Arrows or WASD drive, SPACE is the handbrake, X hands your car to the AI (autopilot), N generates a
   new circuit, T the next theme, B the next car body, C switches the camera between following and the whole circuit, H
   shows the race layer (the racing line in green where it accelerates and red where it brakes, and the gates), P switches
   the cut rule, R restarts.

Requires GameMaker 2024.14 or later. Built and tested on runtime 2024.14.4.268 (the VM, Windows). Pure GML, no shader, no
extension; nothing here depends on GMRT.

## Quickstart

The whole race in one object, drawn in Draw GUI:

```gml
// Create - a circuit, its picture, a race with you in car 0, and a camera on you
my_circuit = chc_circuit_create(12, "grandprix");
chc_circuit_bake(my_circuit);
my_race = chc_race_create(my_circuit, { cars: 8, laps: 5, player: 0 });
my_cam = chc_camera_create(my_race.cars[0].x, my_race.cars[0].y, 1, display_get_gui_width(), display_get_gui_height());

// Step - drive car 0, run the race, follow it
var my_dt = delta_time / 1000000;
var my_thr = keyboard_check(vk_up) ? 1 : 0;
var my_brk = keyboard_check(vk_down) ? 1 : 0;
var my_steer = keyboard_check(vk_right) - keyboard_check(vk_left);
chc_car_input(my_race, 0, my_thr, my_brk, my_steer);
var my_events = chc_race_step(my_race, my_dt);
chc_camera_follow(my_cam, my_race.cars[0], my_dt, my_circuit);

// Draw GUI - the circuit, the skid marks and cars, then the HUD
chc_circuit_draw(my_circuit, my_cam);
chc_race_draw(my_race, my_cam);
chc_hud_draw(my_race, 0, 0, display_get_gui_width(), display_get_gui_height(), 0);

// Clean Up
chc_race_free(my_race);
chc_circuit_free(my_circuit);
chc_draw_free();
```

`my_events` is an array of structs, each with a `type` and the `car` it concerns: `"lights"`, `"go"`, `"lap"` (with
`lap` and `time`), `"fastest"` (`time`), `"finish"` (`position`, `time`), `"cut"` (`gate`), `"penalty"` (`seconds`) and
`"contact"` (`other`). Play your sounds and show your messages from them.

## Circuits

`chc_circuit_create(seed, theme, [opts])` returns the circuit struct. `opts` may set `worldW` and `worldH` (the world box
in pixels, 2600 x 1800 by default, 1200..4096) and `width` (the road width; each theme has its own). Read from it:

| field | what it is |
| --- | --- |
| `px`, `py` | the centreline, one sample about every 8 px round the loop; sample 0 is the start line |
| `tx`, `ty`, `nx`, `ny` | the direction of travel and the left normal at each sample |
| `s`, `k`, `length` | arc position of each sample, its curvature, the lap length in px |
| `line`, `lx`, `ly` | the racing line as an offset from the centreline, and as points |
| `width`, `hw`, `runoff` | road width, half width, and how far the run-off reaches past the edge |
| `gates`, `grid` | the 24 gate positions (arc px) and the grid slots (`x`, `y`, `ang`) |
| `layout` | the scenery as data: `corners`, `kerbs`, `gravel`, `tyres`, `stands`, `pit`, `trees`, `buildings`, `boats`, `posts`, `lamps`, `dunes`, `rocks`, `water` |
| `attempts`, `rmin`, `clearance` | how many draws the generator needed, the tightest radius, the closest approach of two parts |

`chc_themes()` lists the eight theme names and `chc_theme(name)` returns a theme's settings (`title`, `width`, `runoff`,
`grip`, `road`, `body`). `chc_bodies()` lists the four bodies and `chc_body(name)` returns a body's size and performance.

`chc_track_query(circuit, x, y, [hint])` tells you where a room point is: `{ i, s, d, surface, onTrack }` - the nearest
sample, the arc position, the signed offset (+ is left of the direction of travel) and `"road"`, `"kerb"`, `"runoff"` or
`"barrier"`. Pass the last answer's `i` as `hint` to keep it a local search. `chc_track_point(circuit, s, [d])` goes the
other way: the room point and heading at arc position `s` and offset `d` - use it to place pickups, cameras or your own
props along the track.

`chc_rng(seed)`, `chc_rand(generator)` and `chc_range(generator, lo, hi)` are the seeded generator the package uses;
use them for anything you want to repeat with the circuit.

## The race

`chc_race_create(circuit, [opts])` puts cars on the grid. `opts`: `cars` (1..12, default 8), `laps` (default 3),
`seed`, `body` (one of the four; default the theme's), `player` (the car you drive, -1 for none), `cutRule`
(`"refuse"` or `"penalty"`), `penalty` (seconds, default 3), `lights` (the five-light start, default true), `skills`
(an array of AI skills, 0.8 to 1).

- **The cut rule.** Every gate must be crossed going forward. A gate crossed on the INSIDE of a corner beyond the kerb is a
  cut. Under `"refuse"` the gate is not credited until the car comes back and takes it properly, so the car stops gaining
  positions and the HUD says so; under `"penalty"` it is credited and the penalty is added to the car's finishing time.
  Running wide on the outside is never a cut, and the pit lane counts as track.
- **Positions** come from credited gates, then distance past the last one; finished cars rank by finishing time.
  `chc_race_standings(race)` returns the car indices in order, `chc_race_gap(race, car)` the gap to the leader in seconds
  and `chc_race_progress(race, car)` how far a car has come.
- **Each car** (`race.cars[k]`) carries `x`, `y`, `ang` (radians, room space), `speed`, `lap`, `position`, `laps` (its lap
  times), `lastLap`, `bestLap`, `sectors`, `finished`, `finishT`, `penalty`, `contacts`, `missedGate` (the gate it owes,
  or -1), `wrongWay`, `code` (its three-letter name), `livery` and `skill`. Set `sprite` to one of your own sprites to have
  `chc_race_draw` draw it instead of the generated body (at `image_angle = -radtodeg(car.ang)`).
- **Driving.** `chc_car_input(race, car, throttle, brake, steer)` drives a car yourself (throttle 0..1, negative reverses;
  brake 0..1; steer -1..1). `chc_car_set_ai(race, car, true)` hands it to the AI and `false` takes it back. The car model is
  arcade: the engine on a real torque curve, brakes, a tow behind another car, grip and drag by surface, a grip-capped
  turn rate and sliding that the grip catches - sliding and hard braking lay the skid marks.
- **The AI** follows the racing line by pure pursuit, brakes to a speed profile computed from the line's curvature, the
  body's grip and its brakes, pulls out to the side with room to pass a slower car, holds a lane beside a car, covers the
  inside when an attacker sits in its tow, and backs out of the wall if it ever ends up stuck there. Skill scales its pace.

`chc_race_sim(circuit, [opts])` runs a whole race headless with every car on AI - the tuning harness the package was
tested with. It returns `{ finished, cars, contacts, passes, walls, cuts, spread, bestLap, time, steps, ms, race }`.

## Drawing

- `chc_circuit_bake(circuit, [scale])` draws the circuit once into `circuit.sprite` (`scale` 0.25 to 2). It runs under its
  own transform and hands yours back, so it is safe in any event. `chc_circuit_free(circuit)` frees it.
- `chc_camera_create(x, y, zoom, w, h, [sx], [sy])` makes a view centred on a room point; `chc_camera_follow(camera, car,
  dt, [circuit])` eases it toward a point ahead of a car and keeps it inside the circuit.
- `chc_circuit_draw(circuit, camera)` draws the visible part of the baked circuit; `chc_race_draw(race, camera)` the skid
  marks and the cars on top.
- The HUD, whole or in parts: `chc_hud_draw(race, x, y, w, h, [player])`, or `chc_tower_draw(race, x, y, [rows], [player],
  [scale])`, `chc_timing_draw(race, car, x, y, [scale])` (right-aligned at x), `chc_minimap_draw(race, x, y, w, h,
  [player])` and `chc_lights_draw(race, centre_x, y, [scale])`.
- `chc_car_sprite(body, livery, [scale])` returns a car as a sprite (cached; premultiplied, so draw it with
  `chc_car_draw`) and `chc_car_draw(body, livery, x, y, ang, [scale], [alpha], [shadow])` draws one anywhere - a garage
  screen, a podium, a results table. `chc_livery_create(seed)` makes a livery: `{ primary, secondary, accent, helmet,
  pattern, number, seed }` - change any field before drawing. `chc_draw_free()` frees every cached car sprite.

## Measured

On runtime 2024.14.4.268 (the VM) on a shared Windows test machine, over two suite runs of this build: generating a
circuit (layout and racing line included) took 141 to 175 ms on average; baking one at half scale 260 to 440 ms; a
headless 3-lap race of 8 AI cars 4.2 to 7.4 s. Bake once, when the room starts, not every frame. The races are
deterministic: in every run, one 3-lap race on each of the eight themes finished all 64 AI cars, with 0 frames against a
barrier, 19 passes and 109 car-to-car contacts (a contact is a touch that begins with real closing speed). The
figures are written by the package's own suite; your machine will differ.

## Licence

One commercial licence per developer, unlimited games. See `LICENSE.txt`. The two typefaces (Oswald and Barlow Condensed,
SIL Open Font License 1.1) and their notices are in `Chicane/fonts/`.

This package was written with AI assistance.

Copyright (c) 2026 Core Systems Asset Factory.
