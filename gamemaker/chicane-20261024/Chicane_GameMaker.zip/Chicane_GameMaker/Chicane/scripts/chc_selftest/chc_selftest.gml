/// chc_selftest.gml - Chicane's in-engine test suite. Run the demo with -selftest: the result is written as
/// chc_selftest.json in the game's save folder and the renders (chc_render_*.png) beside it, to be LOOKED at.
/// Stages: the generator, circuits across every theme (validity, closure, spacing, radius, clearance, determinism), the
/// racing line and profile, the track query, the cut rule both ways and the pit lane, headless AI races on every theme
/// (finishes, contacts, walls, passes, spread), standings, refusals on bad input, then the bake of every theme, the car
/// bodies and liveries, and a race frame with the HUD - each inked, and saved.
///
/// Chicane - Top-Down Racing for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function chc_st_assert(state, condition, message)
/// @description Count one assertion; keep the first 80 failure messages.
function chc_st_assert(_st, _c, _m) { _st.total += 1; if (_c) { _st.pass += 1; return true; } _st.fail += 1; if (array_length(_st.failures) < 80) array_push(_st.failures, "[stage " + string(_st.stage) + "] " + _m); return false; }
/// @function chc_st_stage(state, n)
/// @description Record the stage reached (the crash handler reports it).
function chc_st_stage(_st, _n) { _st.stage = _n; global.chc_stage = _n; }

/// @function chc__st_read(surface)
/// @description Internal. A surface read into a buffer (RGBA bytes, wing s13).
function chc__st_read(_surf) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf);
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _surf, 0);
    return { buf: _b, w: _w, h: _h };
}
/// @function chc__st_ink(read, r, g, b, tol)
/// @description Internal. Pixels that differ from (r, g, b) by more than tol in any channel, stepping 2 x 1.
function chc__st_ink(_rd, _r, _g, _bb, _tol) {
    var _n = 0;
    for (var _y = 0; _y < _rd.h; _y++) for (var _x = 0; _x < _rd.w; _x += 2) {
        var _o = (_y * _rd.w + _x) * 4;
        var _pr = buffer_peek(_rd.buf, _o, buffer_u8), _pg = buffer_peek(_rd.buf, _o + 1, buffer_u8), _pb = buffer_peek(_rd.buf, _o + 2, buffer_u8);
        if (abs(_pr - _r) > _tol || abs(_pg - _g) > _tol || abs(_pb - _bb) > _tol) _n++;
    }
    return _n * 2;
}
/// @function chc__st_px(read, x, y)
/// @description Internal. [r, g, b, a] at a pixel.
function chc__st_px(_rd, _x, _y) {
    var _o = (clamp(floor(_y), 0, _rd.h - 1) * _rd.w + clamp(floor(_x), 0, _rd.w - 1)) * 4;
    return [buffer_peek(_rd.buf, _o, buffer_u8), buffer_peek(_rd.buf, _o + 1, buffer_u8), buffer_peek(_rd.buf, _o + 2, buffer_u8), buffer_peek(_rd.buf, _o + 3, buffer_u8)];
}
/// @function chc__st_alpha(read)
/// @description Internal. Pixels with alpha above 16.
function chc__st_alpha(_rd) {
    var _n = 0;
    for (var _i = 0; _i < _rd.w * _rd.h; _i++) if (buffer_peek(_rd.buf, _i * 4 + 3, buffer_u8) > 16) _n++;
    return _n;
}

/// @function chc_selftest_run()
/// @description Run every stage; returns the state written by chc_selftest_write.
function chc_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: {}, timings: {} };
    var _eps = math_get_epsilon();
    _st.notes.epsilon = string_format(_eps, 1, 12);

    // ------------------------------------------------------------ 10: the generator
    chc_st_stage(_st, 10);
    var _g1 = chc_rng(42), _g2 = chc_rng(42), _same = true;
    repeat (50) if (chc_rand(_g1) != chc_rand(_g2)) _same = false;
    chc_st_assert(_st, _same, "the same seed draws the same sequence");
    var _lo = 1, _hi = 0;
    for (var _s = 0; _s < 400; _s++) { var _v = chc_rand(chc_rng(1000 + _s)); _lo = min(_lo, _v); _hi = max(_hi, _v); }
    chc_st_assert(_st, _lo < 0.05 && _hi > 0.95, "first draws over 400 NEARBY seeds span [0,1) (warm-up; s6): " + string(_lo) + ".." + string(_hi));
    var _inr = true;
    var _g3 = chc_rng(7);
    repeat (2000) { var _v = chc_rand(_g3); if (_v < 0 || _v >= 1) _inr = false; }
    chc_st_assert(_st, _inr, "every draw lies in [0, 1)");
    chc_st_assert(_st, chc_rand(undefined) == 0 && chc_rand({}) == 0, "a non-generator draws 0 and does not throw");

    // ------------------------------------------------------------ 20: circuits on every theme
    chc_st_stage(_st, 20);
    var _themes = chc_themes(), _circuits = [];
    var _attTot = 0, _attMax = 0, _fall = 0, _made = 0, _gridMin = 12, _gridSum = 0, _gridHard = 0;
    var _t0 = get_timer();
    for (var _t = 0; _t < array_length(_themes); _t++) for (var _s = 1; _s <= 4; _s++) {
        var _c = chc_circuit_create(_s, _themes[_t]);
        _made++;
        _attTot += _c.attempts; _attMax = max(_attMax, _c.attempts); if (_c.fallback) _fall++;
        if (_s == 1) array_push(_circuits, _c);
        var _nm = _themes[_t] + " seed " + string(_s);
        chc_st_assert(_st, _c.valid && !_c.fallback, _nm + ": a valid generated circuit (no fallback oval)");
        chc_st_assert(_st, _c.length > 3000 && _c.length < 9000, _nm + ": length " + string(_c.length) + " px in 3000..9000");
        chc_st_assert(_st, abs(_c.n * _c.step - _c.length) < 0.01, _nm + ": samples x step = length");
        var _minR = _c.hw + max(10, _c.runoff * 0.35) + 14, _clear = 2 * (_c.hw + _c.runoff) + 24;
        chc_st_assert(_st, _c.rmin >= _minR, _nm + ": tightest radius " + string(_c.rmin) + " >= drivable " + string(_minR));
        chc_st_assert(_st, _c.clearance >= _clear, _nm + ": closest approach of two parts " + string(_c.clearance) + " >= " + string(_clear));
        // closure and spacing: every consecutive pair (the last to the first included) is one step apart
        var _wd = 0;
        for (var _i = 0; _i < _c.n; _i++) { var _j = (_i + 1) mod _c.n; _wd = max(_wd, abs(chc__hyp(_c.px[_j] - _c.px[_i], _c.py[_j] - _c.py[_i]) - _c.step)); }
        chc_st_assert(_st, _wd < _c.step * 0.25, _nm + ": the loop is closed and evenly spaced (worst deviation " + string(_wd) + " px)");
        // inside the world, with the barrier inside it too
        var _x0 = 100000, _y0 = 100000, _x1 = -100000, _y1 = -100000;
        for (var _i = 0; _i < _c.n; _i++) { _x0 = min(_x0, _c.px[_i]); _y0 = min(_y0, _c.py[_i]); _x1 = max(_x1, _c.px[_i]); _y1 = max(_y1, _c.py[_i]); }
        var _bd = _c.hw + _c.runoff;
        chc_st_assert(_st, _x0 - _bd > 0 && _y0 - _bd > 0 && _x1 + _bd < _c.worldW && _y1 + _bd < _c.worldH, _nm + ": track and barrier inside the world");
        // the start line on a straight, gates in order
        var _ks0 = chc__smooth(_c.k, 3);
        chc_st_assert(_st, abs(_ks0[0]) < 1 / (_c.width * 14), _nm + ": the start line sits on a straight");
        // the painted grid: every painted box on the start straight (none round the corner behind it), and at least the
        // eight front slots painted so the default 8-car race starts in boxes
        var _gp = 0, _goff = 0;
        for (var _q = 0; _q < array_length(_c.grid); _q++) if (_c.grid[_q].painted) { _gp++; if (abs(_ks0[_c.grid[_q].i]) >= 1 / (_c.width * 14)) _goff++; }
        chc_st_assert(_st, _goff == 0, _nm + ": every painted grid box sits on the start straight (" + string(_goff) + " of " + string(_gp) + " off it)");
        chc_st_assert(_st, _gp >= 8, _nm + ": at least 8 grid boxes painted (" + string(_gp) + ", pitch " + string(_c.gridPitch) + ")");
        _gridMin = min(_gridMin, _gp); _gridSum += _gp;
        // the hard case, counted so a corpus where every slot fits cannot pass this vacuously: unpainted slots that WOULD
        // have been painted round the corner
        for (var _q = 0; _q < array_length(_c.grid); _q++) if (!_c.grid[_q].painted && abs(_ks0[_c.grid[_q].i]) >= 1 / (_c.width * 14)) _gridHard++;
        chc_st_assert(_st, array_length(_c.gates) == CHC_GATES && _c.gates[0] == 0 && _c.gates[CHC_GATES - 1] < _c.length, _nm + ": 24 gates from the line");
        chc_st_assert(_st, array_length(_c.layout.corners) >= 3, _nm + ": at least 3 corners (" + string(array_length(_c.layout.corners)) + ")");
    }
    _st.timings.circuitCreateMs = (get_timer() - _t0) / 1000 / _made;
    _st.notes.attemptsMean = _attTot / _made; _st.notes.attemptsMax = _attMax;
    _st.notes.gridPainted = "min " + string(_gridMin) + " mean " + string(_gridSum / _made) + " of 12; " + string(_gridHard) + " slots round a corner left unpainted";
    chc_st_assert(_st, _fall == 0, "no circuit fell back to the oval (" + string(_fall) + " of " + string(_made) + ")");
    // determinism and distinctness
    var _ca = chc_circuit_create(5, "grandprix"), _cb = chc_circuit_create(5, "grandprix"), _cc = chc_circuit_create(6, "grandprix"), _cd = chc_circuit_create(5, "forest");
    var _eq = (_ca.n == _cb.n);
    if (_eq) for (var _i = 0; _i < _ca.n; _i++) if (_ca.px[_i] != _cb.px[_i] || _ca.py[_i] != _cb.py[_i]) { _eq = false; break; }
    chc_st_assert(_st, _eq, "the same seed and theme generate the same circuit, sample for sample");
    chc_st_assert(_st, abs(_ca.length - _cc.length) > 1 || _ca.px[10] != _cc.px[10], "another seed generates another circuit");
    chc_st_assert(_st, abs(_ca.length - _cd.length) > 1 || _ca.px[10] != _cd.px[10], "the same seed on another theme generates another circuit");

    // ------------------------------------------------------------ 30: racing line and profile
    chc_st_stage(_st, 30);
    for (var _q = 0; _q < array_length(_circuits); _q++) {
        var _c = _circuits[_q], _nm = _c.theme;
        var _lim = _c.hw - 9, _in = true, _span = 0;
        for (var _i = 0; _i < _c.n; _i++) { if (abs(_c.line[_i]) > _lim + 0.001) _in = false; _span = max(_span, abs(_c.line[_i])); }
        chc_st_assert(_st, _in, _nm + ": the racing line stays inside the road less its margin");
        chc_st_assert(_st, _span > _c.hw * 0.5, _nm + ": the racing line USES the road (widest offset " + string(_span) + " of " + string(_c.hw) + ")");
        chc_st_assert(_st, _c.lineWork > 5000 && _c.lineWork < 60000, _nm + ": racing-line work " + string(_c.lineWork));
        var _pr = chc__profile(_c, chc_body(_c.T.body)), _vmin = 100000, _vmax = 0, _nb = 0;
        for (var _i = 0; _i < _c.n; _i++) { _vmin = min(_vmin, _pr.v[_i]); _vmax = max(_vmax, _pr.v[_i]); if (_pr.brake[_i]) _nb++; }
        chc_st_assert(_st, _vmin > 60 && _vmax <= chc_body(_c.T.body).vTop, _nm + ": profile speeds " + string(_vmin) + ".." + string(_vmax));
        chc_st_assert(_st, _nb > 0, _nm + ": braking points exist (" + string(_nb) + ")");
    }

    // ------------------------------------------------------------ 40: the track query
    chc_st_stage(_st, 40);
    var _c0 = _circuits[0], _qerr = 0, _qn = 0;
    for (var _k = 0; _k < 60; _k++) {
        var _s = (_k + 0.37) / 60 * _c0.length, _d = ((_k mod 5) - 2) * _c0.hw * 0.4;
        var _p = chc_track_point(_c0, _s, _d);
        var _q = chc_track_query(_c0, _p.x, _p.y);
        var _ds = abs(_q.s - _s); if (_ds > _c0.length / 2) _ds = _c0.length - _ds;
        _qerr = max(_qerr, max(_ds, abs(_q.d - _d)));
        _qn++;
    }
    chc_st_assert(_st, _qerr < 2.5, "query inverts track_point at 60 points (worst error " + string(_qerr) + " px)");
    var _pp = chc_track_point(_c0, 100, 0);
    chc_st_assert(_st, chc_track_query(_c0, _pp.x, _pp.y).surface == "road", "the centreline is road");
    _pp = chc_track_point(_c0, 100, _c0.hw + 5);
    chc_st_assert(_st, chc_track_query(_c0, _pp.x, _pp.y).surface == "kerb", "5 px past the edge is kerb");
    _pp = chc_track_point(_c0, 100, -(_c0.hw + _c0.runoff * 0.6));
    chc_st_assert(_st, chc_track_query(_c0, _pp.x, _pp.y).surface == "runoff", "the middle of the run-off is run-off");
    _pp = chc_track_point(_c0, 100, _c0.hw + _c0.runoff + 12);
    chc_st_assert(_st, chc_track_query(_c0, _pp.x, _pp.y).surface == "barrier", "past the barrier is barrier");

    // ------------------------------------------------------------ 50: the cut rule, both ways, and the pit lane
    chc_st_stage(_st, 50);
    // find a gate on a corner, and stand a car just before it on the INSIDE beyond the kerb, then step it across
    var _cutGate = -1;
    for (var _g = 1; _g < CHC_GATES; _g++) { var _gi = floor(_c0.gates[_g] / _c0.step + 0.5) mod _c0.n; if (abs(_c0.k[_gi]) > 1 / (_c0.width * 6)) { _cutGate = _g; break; } }
    chc_st_assert(_st, _cutGate > 0, "a gate on a corner exists to test the cut rule on");
    if (_cutGate > 0) {
        for (var _rule = 0; _rule < 2; _rule++) {
            var _R = chc_race_create(_c0, { cars: 1, lights: false, cutRule: (_rule == 0) ? "refuse" : "penalty", penalty: 3 });
            var _car = _R.cars[0];
            var _gi = floor(_c0.gates[_cutGate] / _c0.step + 0.5) mod _c0.n, _ins = sign(_c0.k[_gi]);
            _car.nextGate = _cutGate; _car.credits = _cutGate; _car.lap = 1;
            var _p0 = chc_track_point(_c0, _c0.gates[_cutGate] - 6, _ins * (_c0.hw + 20));
            var _p1 = chc_track_point(_c0, _c0.gates[_cutGate] + 4, _ins * (_c0.hw + 20));
            chc__project(_c0, _p0.x, _p0.y, -1, _R.q); _car.idx = _R.q.i; _car.s = _R.q.s;
            var _prev = _car.s;
            chc__project(_c0, _p1.x, _p1.y, _car.idx, _R.q);
            chc__gate_check(_R, _car, _prev, _R.q);
            if (_rule == 0) chc_st_assert(_st, _car.nextGate == _cutGate && _car.credits == _cutGate && _car.missedGate == _cutGate, "REFUSE: a gate crossed on the inside beyond the kerb is not credited and is owed");
            else chc_st_assert(_st, _car.nextGate == _cutGate + 1 && _car.penalty == 3 && _car.cuts == 1, "PENALTY: the same cut is credited with +3 s");
            // the same crossing on the road is credited under either rule
            var _R2 = chc_race_create(_c0, { cars: 1, lights: false, cutRule: (_rule == 0) ? "refuse" : "penalty" });
            var _c2 = _R2.cars[0];
            _c2.nextGate = _cutGate; _c2.credits = _cutGate; _c2.lap = 1;
            var _q0 = chc_track_point(_c0, _c0.gates[_cutGate] - 6, 0), _q1 = chc_track_point(_c0, _c0.gates[_cutGate] + 4, 0);
            chc__project(_c0, _q0.x, _q0.y, -1, _R2.q); _c2.idx = _R2.q.i; _c2.s = _R2.q.s; var _pv = _c2.s;
            chc__project(_c0, _q1.x, _q1.y, _c2.idx, _R2.q);
            chc__gate_check(_R2, _c2, _pv, _R2.q);
            chc_st_assert(_st, _c2.nextGate == _cutGate + 1 && _c2.penalty == 0, "the same gate crossed on the road is credited (" + ((_rule == 0) ? "refuse" : "penalty") + ")");
            // running WIDE on the outside is not a cut
            var _R3 = chc_race_create(_c0, { cars: 1, lights: false });
            var _c3 = _R3.cars[0];
            _c3.nextGate = _cutGate; _c3.credits = _cutGate; _c3.lap = 1;
            var _w0 = chc_track_point(_c0, _c0.gates[_cutGate] - 6, -_ins * (_c0.hw + _c0.runoff * 0.7)), _w1 = chc_track_point(_c0, _c0.gates[_cutGate] + 4, -_ins * (_c0.hw + _c0.runoff * 0.7));
            chc__project(_c0, _w0.x, _w0.y, -1, _R3.q); _c3.idx = _R3.q.i; _c3.s = _R3.q.s; var _pw = _c3.s;
            chc__project(_c0, _w1.x, _w1.y, _c3.idx, _R3.q);
            chc__gate_check(_R3, _c3, _pw, _R3.q);
            chc_st_assert(_st, _c3.nextGate == _cutGate + 1, "running wide on the outside of the corner is credited, not a cut");
        }
    }
    // the pit lane: a car driven the length of the straight in the pit band credits every gate it passes
    var _cp = undefined;
    for (var _q = 0; _q < array_length(_circuits); _q++) if (!is_undefined(_circuits[_q].layout.pit)) { _cp = _circuits[_q]; break; }
    chc_st_assert(_st, !is_undefined(_cp), "some theme lays out a pit lane");
    if (!is_undefined(_cp)) {
        var _R4 = chc_race_create(_cp, { cars: 1, lights: false });
        var _c4 = _R4.cars[0], _pt = _cp.layout.pit;
        var _sA = _cp.s[_pt.i0], _band = _pt.side * (_cp.hw + 30);
        var _p4 = chc_track_point(_cp, _sA + 20, _band);
        chc__project(_cp, _p4.x, _p4.y, -1, _R4.q); _c4.idx = _R4.q.i; _c4.s = _R4.q.s; _c4.nextGate = 0; _c4.credits = 0;
        var _gatesInPit = 0;
        for (var _g = 0; _g < CHC_GATES; _g++) { var _gs = _cp.gates[_g], _rel = _gs - (_sA + 20); if (_rel < 0) _rel += _cp.length; if (_rel < _pt.len * _cp.step - 60) _gatesInPit++; }
        for (var _d = 20; _d < _pt.len * _cp.step - 40; _d += 6) {
            var _pq = chc_track_point(_cp, _sA + _d + 6, _band), _prv = _c4.s;
            chc__project(_cp, _pq.x, _pq.y, _c4.idx, _R4.q);
            _c4.idx = _R4.q.i; _c4.s = _R4.q.s; _c4.d = _R4.q.d;
            chc__gate_check(_R4, _c4, _prv, _R4.q);
        }
        chc_st_assert(_st, _c4.credits >= 1 && _c4.missed == 0, "the pit lane credits its gates (" + string(_c4.credits) + " credited, " + string(_c4.missed) + " missed)");
    }

    // ------------------------------------------------------------ 60: headless AI races on every theme
    chc_st_stage(_st, 60);
    var _tot = { fin: 0, cars: 0, contacts: 0, walls: 0, passes: 0, ms: 0, races: 0 }, _spreads = [];
    for (var _q = 0; _q < array_length(_circuits); _q++) {
        var _c = _circuits[_q];
        var _res = chc_race_sim(_c, { cars: 8, laps: 3, seed: 1 });
        _tot.fin += _res.finished; _tot.cars += _res.cars; _tot.contacts += _res.contacts; _tot.walls += _res.walls; _tot.passes += _res.passes; _tot.ms += _res.ms; _tot.races++;
        array_push(_spreads, _res.spread);
        chc_st_assert(_st, _res.finished == _res.cars, _c.theme + ": every AI car finishes 3 laps (" + string(_res.finished) + "/" + string(_res.cars) + ")");
        chc_st_assert(_st, _res.spread > 0.05 && _res.spread < 5, _c.theme + ": best-lap spread " + string(_res.spread) + " s (skill shows, no car lost)");
        chc_st_assert(_st, _res.contacts <= 80, _c.theme + ": contacts " + string(_res.contacts) + " <= 80 in a 3-lap 8-car race");
        // standings at the flag are the finishing order
        var _ord = chc_race_standings(_res.race), _sorted = true;
        for (var _p = 1; _p < array_length(_ord); _p++) if (_res.race.cars[_ord[_p]].finishT < _res.race.cars[_ord[_p - 1]].finishT) _sorted = false;
        chc_st_assert(_st, _sorted, _c.theme + ": the final standings are the finishing order");
        variable_struct_set(_st.notes, "race_" + _c.theme, "fin " + string(_res.finished) + " contacts " + string(_res.contacts) + " walls " + string(_res.walls) + " passes " + string(_res.passes) + " spread " + string_format(_res.spread, 1, 3) + " best " + string_format(_res.bestLap, 1, 3) + " ms " + string_format(_res.ms, 1, 0));
    }
    chc_st_assert(_st, _tot.passes > 0, "the AI overtakes somewhere across the themes (" + string(_tot.passes) + " passes)");
    _st.notes.raceTotals = _tot;

    // ------------------------------------------------------------ 70: refusals on bad input
    chc_st_stage(_st, 70);
    chc_st_assert(_st, is_undefined(chc_race_create(undefined)), "race_create(undefined) refuses");
    chc_st_assert(_st, is_undefined(chc_track_query({}, 0, 0)), "track_query on a non-circuit refuses");
    chc_st_assert(_st, chc_theme("nonsense").name == "grandprix" && chc_body("nonsense").name == "formula", "unknown theme and body fall back");
    var _cw = chc_circuit_create("seven", "harbour");
    chc_st_assert(_st, _cw.valid, "a non-numeric seed still makes a valid circuit");
    chc_st_assert(_st, array_length(chc_race_step(undefined, 1)) == 0 && chc_car_input(undefined, 0, 1, 0, 0) == false, "step and input refuse a non-race");

    // ------------------------------------------------------------ 80: bake every theme, look at it
    chc_st_stage(_st, 80);
    var _bakeMs = [];
    for (var _q = 0; _q < array_length(_circuits); _q++) {
        var _c = _circuits[_q];
        var _spr = chc_circuit_bake(_c, 0.5);
        array_push(_bakeMs, _c.bakeMs);
        chc_st_assert(_st, sprite_exists(_spr) && sprite_get_width(_spr) == 1300 && sprite_get_height(_spr) == 900, _c.theme + ": baked at half scale, 1300 x 900");
        var _sf = surface_create(1300, 900);
        surface_set_target(_sf); draw_clear_alpha(c_black, 1); draw_sprite(_spr, 0, 0, 0); surface_reset_target();
        var _rd = chc__st_read(_sf);
        var _bg = chc__st_px(_rd, 4, 4);
        var _ink = chc__st_ink(_rd, _bg[0], _bg[1], _bg[2], 12);
        chc_st_assert(_st, _ink > 1300 * 900 * 0.2, _c.theme + ": the bake is not flat ground (" + string(_ink) + " px differ from the corner)");
        // the road at the start line is the theme's road colour, not ground
        var _rp = chc__st_px(_rd, _c.px[3] * 0.5, _c.py[3] * 0.5);
        chc_st_assert(_st, _rp[3] == 255, _c.theme + ": the bake is opaque on the road");
        buffer_delete(_rd.buf);
        surface_save(_sf, "chc_render_bake_" + _c.theme + ".png");
        surface_free(_sf);
    }
    _st.timings.bakeHalfMs = _bakeMs;

    // a full-scale crop at the start line for each of two themes
    for (var _q = 0; _q < 2; _q++) {
        var _c = _circuits[(_q == 0) ? 0 : 6];
        chc_circuit_bake(_c, 1);
        var _cam = chc_camera_create(_c.px[0], _c.py[0], 1.5, 960, 640, 0, 0);
        var _R5 = chc_race_create(_c, { cars: 8, lights: false });
        repeat (240) chc_race_step(_R5, 1 / 60);
        var _sf = surface_create(960, 640);
        surface_set_target(_sf); draw_clear_alpha(c_black, 1);
        _cam.x = _R5.cars[_R5.order[3]].x; _cam.y = _R5.cars[_R5.order[3]].y;
        chc_circuit_draw(_c, _cam); chc_race_draw(_R5, _cam); chc_hud_draw(_R5, 0, 0, 960, 640, _R5.order[3]);
        surface_reset_target();
        surface_save(_sf, "chc_render_race_" + _c.theme + ".png");
        var _rd = chc__st_read(_sf);
        chc_st_assert(_st, chc__st_ink(_rd, 0, 0, 0, 8) > 960 * 640 * 0.9, _c.theme + ": a race frame fills the view");
        buffer_delete(_rd.buf);
        surface_free(_sf);
        chc_race_free(_R5);
    }

    // ------------------------------------------------------------ 90: cars
    chc_st_stage(_st, 90);
    var _bodies = chc_bodies();
    var _sf = surface_create(960, 640);
    surface_set_target(_sf); draw_clear_alpha(chc__rgb(66, 68, 74), 1);
    var _inks = [];
    for (var _b = 0; _b < 4; _b++) for (var _l = 0; _l < 6; _l++) {
        var _liv = chc_livery_create(_b * 10 + _l + 1);
        _liv.pattern = _l;
        chc_car_draw(_bodies[_b], _liv, 90 + _l * 156, 90 + _b * 150, -pi / 2 + 0.3 * (_l mod 2), 3.2);
        var _spr = chc_car_sprite(_bodies[_b], _liv, 1);
        array_push(_inks, sprite_exists(_spr));
    }
    surface_reset_target();
    surface_save(_sf, "chc_render_cars.png");
    var _rd = chc__st_read(_sf);
    chc_st_assert(_st, chc__st_ink(_rd, 66, 68, 74, 10) > 30000, "the car sheet has cars on it");
    buffer_delete(_rd.buf);
    surface_free(_sf);
    var _allspr = true; for (var _i = 0; _i < array_length(_inks); _i++) if (!_inks[_i]) _allspr = false;
    chc_st_assert(_st, _allspr, "every body x pattern makes a sprite");
    // a car sprite is INK, not an empty sprite of the right size (s2026-09-08)
    var _cs = chc_car_sprite("formula", chc_livery_create(3), 1);
    var _sf2 = surface_create(sprite_get_width(_cs), sprite_get_height(_cs));
    surface_set_target(_sf2); draw_clear_alpha(c_black, 0); gpu_set_blendmode_ext(bm_one, bm_zero); draw_sprite(_cs, 0, sprite_get_xoffset(_cs), sprite_get_yoffset(_cs)); gpu_set_blendmode(bm_normal); surface_reset_target();
    var _rd2 = chc__st_read(_sf2);
    var _al = chc__st_alpha(_rd2);
    chc_st_assert(_st, _al > sprite_get_width(_cs) * sprite_get_height(_cs) * 0.25, "a formula car sprite is at least a quarter ink (" + string(_al) + " px)");
    buffer_delete(_rd2.buf); surface_free(_sf2);

    for (var _q = 0; _q < array_length(_circuits); _q++) chc_circuit_free(_circuits[_q]);
    chc_draw_free();
    chc_st_stage(_st, 99);
    return _st;
}

/// @function chc_selftest_write(state)
/// @description Write the suite's result as chc_selftest.json in the save folder.
function chc_selftest_write(_st) {
    var _f = file_text_open_write("chc_selftest.json");
    file_text_write_string(_f, json_stringify(_st));
    file_text_close(_f);
}
