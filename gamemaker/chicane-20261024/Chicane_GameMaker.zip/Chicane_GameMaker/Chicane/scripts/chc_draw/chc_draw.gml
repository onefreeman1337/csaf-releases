/// chc_draw.gml - Chicane's drawing: the circuit baked once into a sprite (ground, run-off, gravel traps, the road with its
/// grain and rubbered racing line, braking streaks, edge lines, kerbs, the start/finish line and grid boxes, the pit lane,
/// barriers, tyre walls, grandstands with crowds, trees, buildings, water and boats, marshal posts, lamps), the four car
/// bodies with generated liveries (baked to cached sprites), the skid marks that build up through a race, and the HUD
/// (position tower, lap and sector timing, minimap, speed, start lights, messages). Everything is drawn from primitives:
/// the package ships no image files.
///
/// Public functions: chc_circuit_bake, chc_circuit_free, chc_camera_create, chc_camera_follow, chc_circuit_draw,
/// chc_car_sprite, chc_car_draw, chc_race_draw, chc_tower_draw, chc_timing_draw, chc_minimap_draw, chc_lights_draw,
/// chc_hud_draw, chc_draw_free.
///
/// Chicane - Top-Down Racing for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

#macro CHC_FLUSH 900

// ------------------------------------------------------------------------------------------------ colour helpers

/// @function chc__rgb(r, g, b)
/// @description Internal. make_colour_rgb.
function chc__rgb(_r, _g, _b) { return make_colour_rgb(clamp(_r, 0, 255), clamp(_g, 0, 255), clamp(_b, 0, 255)); }

/// @function chc__shade(col, f)
/// @description Internal. f < 1 toward black, f > 1 toward white.
function chc__shade(_c, _f) { if (_f < 1) return merge_colour(_c, c_black, clamp(1 - _f, 0, 1)); return merge_colour(_c, c_white, clamp(_f - 1, 0, 1)); }

/// @function chc__pal(theme)
/// @description Internal. A theme's palette.
function chc__pal(_name) {
    var _p = { ground: chc__rgb(86, 140, 64), ground2: chc__rgb(98, 154, 72), gs1: chc__rgb(70, 120, 52), gs2: chc__rgb(124, 172, 88),
               road: chc__rgb(66, 68, 74), rs1: chc__rgb(98, 100, 106), rs2: chc__rgb(46, 48, 52), rubber: chc__rgb(30, 31, 34),
               edge: chc__rgb(236, 236, 230), kerbA: chc__rgb(206, 40, 44), kerbB: chc__rgb(240, 240, 236),
               gravel: chc__rgb(214, 196, 150), gv1: chc__rgb(168, 148, 108), gv2: chc__rgb(238, 226, 190),
               runoff: -1, tarmac: chc__rgb(62, 66, 74), paintA: chc__rgb(36, 86, 176), paintB: chc__rgb(196, 44, 48),
               barrier: chc__rgb(196, 202, 210), wall: chc__rgb(206, 204, 196), tyre: chc__rgb(30, 30, 34),
               seat: chc__rgb(40, 84, 168), roof: chc__rgb(220, 222, 226), leaf: chc__rgb(46, 104, 46), leaf2: chc__rgb(96, 156, 70),
               shadow: chc__rgb(14, 22, 12), night: false, dirt: false, snow: false };
    switch (_name) {
        case "street":
            _p.ground = chc__rgb(132, 132, 134); _p.ground2 = chc__rgb(140, 140, 142); _p.gs1 = chc__rgb(112, 112, 116); _p.gs2 = chc__rgb(158, 158, 160);
            _p.road = chc__rgb(72, 74, 80); _p.runoff = chc__rgb(176, 172, 164); _p.shadow = chc__rgb(30, 30, 34); break;
        case "desert":
            _p.ground = chc__rgb(222, 184, 128); _p.ground2 = chc__rgb(232, 196, 142); _p.gs1 = chc__rgb(196, 156, 104); _p.gs2 = chc__rgb(242, 214, 166);
            _p.road = chc__rgb(176, 124, 80); _p.rs1 = chc__rgb(200, 150, 104); _p.rs2 = chc__rgb(140, 94, 58); _p.rubber = chc__rgb(128, 84, 52);
            _p.runoff = -1; _p.leaf = chc__rgb(70, 120, 60); _p.leaf2 = chc__rgb(120, 168, 84); _p.shadow = chc__rgb(120, 76, 40); _p.dirt = true; break;
        case "snow":
            _p.ground = chc__rgb(234, 240, 248); _p.ground2 = chc__rgb(222, 232, 244); _p.gs1 = chc__rgb(204, 216, 234); _p.gs2 = chc__rgb(250, 252, 255);
            // packed snow and ice is GREYER and darker than the snowfield, or the road vanishes into it (first bake: it did)
            _p.road = chc__rgb(150, 164, 188); _p.rs1 = chc__rgb(196, 208, 226); _p.rs2 = chc__rgb(112, 126, 152); _p.rubber = chc__rgb(84, 98, 128);
            _p.leaf = chc__rgb(28, 70, 56); _p.leaf2 = chc__rgb(56, 110, 84); _p.shadow = chc__rgb(110, 130, 170); _p.snow = true; break;
        case "forest":
            _p.ground = chc__rgb(66, 112, 52); _p.ground2 = chc__rgb(74, 122, 58); _p.gs1 = chc__rgb(52, 94, 42); _p.gs2 = chc__rgb(100, 146, 72);
            _p.leaf = chc__rgb(30, 82, 40); _p.leaf2 = chc__rgb(78, 136, 58); break;
        case "harbour":
            _p.ground = chc__rgb(156, 152, 142); _p.ground2 = chc__rgb(164, 160, 150); _p.gs1 = chc__rgb(136, 132, 124); _p.gs2 = chc__rgb(180, 176, 166);
            _p.runoff = chc__rgb(112, 112, 116); _p.leaf = chc__rgb(50, 120, 60); _p.leaf2 = chc__rgb(110, 170, 80); _p.shadow = chc__rgb(40, 40, 44); break;
        case "nightcity":
            _p.ground = chc__rgb(34, 36, 46); _p.ground2 = chc__rgb(38, 40, 52); _p.gs1 = chc__rgb(26, 28, 36); _p.gs2 = chc__rgb(52, 54, 66);
            _p.road = chc__rgb(36, 38, 46); _p.rs1 = chc__rgb(58, 60, 70); _p.rs2 = chc__rgb(24, 25, 30); _p.rubber = chc__rgb(16, 16, 20);
            _p.runoff = chc__rgb(54, 56, 68); _p.wall = chc__rgb(96, 100, 118); _p.edge = chc__rgb(210, 214, 226); _p.kerbB = chc__rgb(200, 204, 214);
            _p.leaf = chc__rgb(24, 50, 40); _p.leaf2 = chc__rgb(40, 78, 60); _p.shadow = chc__rgb(6, 6, 10); _p.night = true; break;
        case "kart":
            _p.ground = chc__rgb(96, 152, 74); _p.ground2 = chc__rgb(106, 164, 80); _p.road = chc__rgb(76, 78, 84); break;
    }
    return _p;
}

// ------------------------------------------------------------------------------------------------ primitive helpers

/// @function chc__band(c, i0, len, dA, dB, colA, colB, alpha)
/// @description Internal. A band between two constant lateral offsets along samples i0 .. i0+len (wrapping), as a
/// triangle strip flushed every CHC_FLUSH vertices (one batch silently drops vertices past its limit, wing s7b).
function chc__band(_c, _i0, _len, _dA, _dB, _cA, _cB, _al) {
    var _n = _c.n, _v = 0;
    _len = min(_len, _n);
    var _closed = (_len >= _n);
    var _last = _closed ? _n : _len;
    draw_primitive_begin(pr_trianglestrip);
    for (var _k = 0; _k <= _last; _k++) {
        var _i = (_i0 + _k) mod _n;
        draw_vertex_colour(_c.px[_i] + _c.nx[_i] * _dA, _c.py[_i] + _c.ny[_i] * _dA, _cA, _al);
        draw_vertex_colour(_c.px[_i] + _c.nx[_i] * _dB, _c.py[_i] + _c.ny[_i] * _dB, _cB, _al);
        _v += 2;
        if (_v >= CHC_FLUSH && _k < _last) {
            draw_primitive_end(); draw_primitive_begin(pr_trianglestrip);
            draw_vertex_colour(_c.px[_i] + _c.nx[_i] * _dA, _c.py[_i] + _c.ny[_i] * _dA, _cA, _al);
            draw_vertex_colour(_c.px[_i] + _c.nx[_i] * _dB, _c.py[_i] + _c.ny[_i] * _dB, _cB, _al);
            _v = 2;
        }
    }
    draw_primitive_end();
}

/// @function chc__band_line(c, w, col, alpha)
/// @description Internal. A band of half-width w centred on the racing line, the whole lap.
function chc__band_line(_c, _w, _col, _al) {
    var _n = _c.n, _v = 0;
    draw_primitive_begin(pr_trianglestrip);
    for (var _k = 0; _k <= _n; _k++) {
        var _i = _k mod _n;
        var _d = _c.line[_i];
        draw_vertex_colour(_c.px[_i] + _c.nx[_i] * (_d - _w), _c.py[_i] + _c.ny[_i] * (_d - _w), _col, _al);
        draw_vertex_colour(_c.px[_i] + _c.nx[_i] * (_d + _w), _c.py[_i] + _c.ny[_i] * (_d + _w), _col, _al);
        _v += 2;
        if (_v >= CHC_FLUSH && _k < _n) {
            draw_primitive_end(); draw_primitive_begin(pr_trianglestrip);
            draw_vertex_colour(_c.px[_i] + _c.nx[_i] * (_d - _w), _c.py[_i] + _c.ny[_i] * (_d - _w), _col, _al);
            draw_vertex_colour(_c.px[_i] + _c.nx[_i] * (_d + _w), _c.py[_i] + _c.ny[_i] * (_d + _w), _col, _al);
            _v = 2;
        }
    }
    draw_primitive_end();
}

/// @function chc__pts_begin() / chc__pt(...) / chc__pts_end()
/// @description Internal. A flushed point list for grain and specks.
function chc__pts_begin() { global.chc_pv = 0; draw_primitive_begin(pr_pointlist); }
function chc__pt(_x, _y, _col, _al) {
    draw_vertex_colour(_x, _y, _col, _al);
    global.chc_pv++;
    if (global.chc_pv >= CHC_FLUSH) { draw_primitive_end(); draw_primitive_begin(pr_pointlist); global.chc_pv = 0; }
}
function chc__pts_end() { draw_primitive_end(); }

/// @function chc__quad(x1,y1,x2,y2,x3,y3,x4,y4,col,alpha)
/// @description Internal. One filled quad (corners in order round it).
function chc__quad(_x1, _y1, _x2, _y2, _x3, _y3, _x4, _y4, _col, _al) {
    draw_primitive_begin(pr_trianglestrip);
    draw_vertex_colour(_x1, _y1, _col, _al); draw_vertex_colour(_x2, _y2, _col, _al);
    draw_vertex_colour(_x4, _y4, _col, _al); draw_vertex_colour(_x3, _y3, _col, _al);
    draw_primitive_end();
}

/// @function chc__orect(cx, cy, ang, len, dep, col, alpha)
/// @description Internal. A filled rectangle centred at (cx, cy), long axis at angle ang (radians, room space).
function chc__orect(_cx, _cy, _ang, _len, _dep, _col, _al) {
    var _ex = cos(_ang) * _len / 2, _ey = sin(_ang) * _len / 2, _qx = -sin(_ang) * _dep / 2, _qy = cos(_ang) * _dep / 2;
    chc__quad(_cx - _ex - _qx, _cy - _ey - _qy, _cx + _ex - _qx, _cy + _ey - _qy, _cx + _ex + _qx, _cy + _ey + _qy, _cx - _ex + _qx, _cy - _ey + _qy, _col, _al);
}

/// @function chc__disc(x, y, r, col, alpha, [segments])
/// @description Internal. A filled disc (a fan; precision follows the radius unless `segments` is given - a disc in CAR
/// space is tiny in units but is drawn up to 12x into a car sprite, so the roundels pass their own).
function chc__disc(_x, _y, _r, _col, _al, _segs = 0) {
    var _m = (is_numeric(_segs) && _segs > 0) ? _segs : clamp(floor(_r * 0.9) + 8, 8, 48);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_x, _y, _col, _al);
    for (var _k = 0; _k <= _m; _k++) { var _a = (_k / _m) * pi * 2; draw_vertex_colour(_x + cos(_a) * _r, _y + sin(_a) * _r, _col, _al); }
    draw_primitive_end();
}

/// @function chc__glow(x, y, r, col, alpha)
/// @description Internal. A radial glow (bright centre to transparent rim) - drawn ADDITIVELY by the caller.
function chc__glow(_x, _y, _r, _col, _al) {
    var _m = 28;
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_x, _y, _col, _al);
    for (var _k = 0; _k <= _m; _k++) { var _a = (_k / _m) * pi * 2; draw_vertex_colour(_x + cos(_a) * _r, _y + sin(_a) * _r, _col, 0); }
    draw_primitive_end();
}

/// @function chc__ellipse(x, y, rx, ry, ang, col, alpha)
/// @description Internal. A filled rotated ellipse.
function chc__ellipse(_x, _y, _rx, _ry, _ang, _col, _al) {
    var _m = clamp(floor(max(_rx, _ry) * 0.7) + 10, 10, 56), _ca = cos(_ang), _sa = sin(_ang);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex_colour(_x, _y, _col, _al);
    for (var _k = 0; _k <= _m; _k++) {
        var _a = (_k / _m) * pi * 2, _u = cos(_a) * _rx, _w = sin(_a) * _ry;
        draw_vertex_colour(_x + _u * _ca - _w * _sa, _y + _u * _sa + _w * _ca, _col, _al);
    }
    draw_primitive_end();
}

/// @function chc__poly(xs, ys, col, alpha)
/// @description Internal. A filled convex polygon (a fan from point 0).
function chc__poly(_xs, _ys, _col, _al) {
    draw_primitive_begin(pr_trianglefan);
    for (var _k = 0; _k < array_length(_xs); _k++) draw_vertex_colour(_xs[_k], _ys[_k], _col, _al);
    draw_primitive_end();
}

/// @function chc__over()
/// @description Internal. Colour blends normally, ALPHA blends as "over" - a translucent mark on an opaque surface keeps it
/// opaque (wing s15). Call inside gpu_push_state / gpu_pop_state.
function chc__over() { gpu_set_blendmode_ext_sepalpha(bm_src_alpha, bm_inv_src_alpha, bm_one, bm_inv_src_alpha); }

// ------------------------------------------------------------------------------------------------ the circuit bake

/// @function chc_circuit_bake(circuit, [scale])
/// @description Draw the whole circuit once into a sprite (worldW x worldH x scale pixels) and keep it on the circuit as
/// circuit.sprite. Draws under its own identity transform and hands the caller's world matrix and blend back; call it
/// from any event. Re-baking replaces the old sprite. Bake time is measured into circuit.bakeMs.
/// @param {Struct} circuit  from chc_circuit_create
/// @param {Real} [scale]  0.25 .. 2 (1)
/// @returns {Asset.GMSprite} the sprite, or -1 on a bad circuit
function chc_circuit_bake(_c, _scale = 1) {
    if (!is_struct(_c) || !variable_struct_exists(_c, "layout")) return -1;
    if (!is_numeric(_scale)) _scale = 1;
    _scale = clamp(_scale, 0.25, 2);
    var _t0 = get_timer();
    var _w = max(16, floor(_c.worldW * _scale)), _h = max(16, floor(_c.worldH * _scale));
    var _mw = matrix_get(matrix_world);
    var _surf = surface_create(_w, _h);
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 1);
    gpu_push_state();
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    chc__over();
    matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, _scale, _scale, 1));
    var _P = chc__pal(_c.theme), _g = chc_rng(_c.seed * 7 + 5);
    chc__paint_ground(_c, _P, _g);
    chc__paint_water(_c, _P, _g);
    chc__paint_buildings(_c, _P, _g, true);
    chc__paint_runoff(_c, _P, _g);
    chc__paint_road(_c, _P, _g);
    chc__paint_kerbs(_c, _P);
    chc__paint_grid(_c, _P);
    chc__paint_pit(_c, _P, _g);
    chc__paint_barriers(_c, _P, _g);
    chc__paint_stands(_c, _P, _g);
    chc__paint_buildings(_c, _P, _g, false);
    chc__paint_trees(_c, _P);
    chc__paint_props(_c, _P, _g);
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
    surface_reset_target();
    if (variable_struct_exists(_c, "sprite") && sprite_exists(_c.sprite)) sprite_delete(_c.sprite);
    _c.sprite = sprite_create_from_surface(_surf, 0, 0, _w, _h, false, false, 0, 0);
    _c.bakeScale = _scale;
    surface_free(_surf);
    _c.bakeMs = (get_timer() - _t0) / 1000;
    return _c.sprite;
}

/// @function chc_circuit_free(circuit)
/// @description Free the circuit's baked sprite. Safe to call twice.
function chc_circuit_free(_c) {
    if (!is_struct(_c)) return;
    if (variable_struct_exists(_c, "sprite") && sprite_exists(_c.sprite)) sprite_delete(_c.sprite);
    _c.sprite = -1;
}

/// @function chc__paint_ground(c, P, g)
/// @description Internal. The ground: base, mowing stripes or pavement joints or dune shading, then specks.
function chc__paint_ground(_c, _P, _g) {
    var _W = _c.worldW, _H = _c.worldH;
    draw_rectangle_colour(0, 0, _W, _H, _P.ground, _P.ground, chc__shade(_P.ground, 0.93), chc__shade(_P.ground, 0.93), false);
    var _t = _c.theme;
    if (_t == "grandprix" || _t == "forest" || _t == "kart") {
        // mowing stripes: wide diagonal bands, alternate ones a shade lighter
        var _bw = 70, _ang = -0.5, _ex = cos(_ang), _ey = sin(_ang);
        for (var _k = -40; _k < 60; _k += 2) {
            var _o = _k * _bw;
            var _cx = _W / 2 + (-_ey) * _o, _cy = _H / 2 + _ex * _o;
            chc__orect(_cx, _cy, _ang, 6000, _bw, _P.ground2, 0.55);
        }
    } else if (_t == "street" || _t == "harbour" || _t == "nightcity") {
        // paving joints every 48 px
        var _jc = chc__shade(_P.ground, (_t == "nightcity") ? 1.18 : 0.9);
        for (var _x = 0; _x < _W; _x += 48) chc__quad(_x, 0, _x + 1, 0, _x + 1, _H, _x, _H, _jc, 0.35);
        for (var _y = 0; _y < _H; _y += 48) chc__quad(0, _y, _W, _y, _W, _y + 1, 0, _y + 1, _jc, 0.35);
    } else if (_t == "snow") {
        repeat (40) chc__ellipse(chc_range(_g, 0, _W), chc_range(_g, 0, _H), chc_range(_g, 60, 220), chc_range(_g, 30, 110), chc_range(_g, 0, pi), _P.gs1, 0.35);
    }
    var _L = _c.layout;
    for (var _d = 0; _d < array_length(_L.dunes); _d++) {
        var _du = _L.dunes[_d];
        // a dune lit from the top left: a long dark lee slope, a bright crest
        chc__ellipse(_du.x + _du.r * 0.12, _du.y + _du.r * 0.1, _du.r, _du.r * 0.45, _du.ang, _P.gs1, 0.55);
        chc__ellipse(_du.x - _du.r * 0.06, _du.y - _du.r * 0.05, _du.r * 0.86, _du.r * 0.34, _du.ang, _P.ground2, 0.8);
        chc__ellipse(_du.x - _du.r * 0.18, _du.y - _du.r * 0.12, _du.r * 0.5, _du.r * 0.16, _du.ang, _P.gs2, 0.7);
        for (var _rr = 0; _rr < 5; _rr++) {
            var _off = (_rr - 2) * _du.r * 0.16;
            var _ca = cos(_du.ang), _sa = sin(_du.ang);
            draw_set_colour(_P.gs1); draw_set_alpha(0.35);
            draw_line_width(_du.x - _ca * _du.r * 0.55 - _sa * _off, _du.y - _sa * _du.r * 0.55 + _ca * _off, _du.x + _ca * _du.r * 0.55 - _sa * _off, _du.y + _sa * _du.r * 0.55 + _ca * _off, 1.5);
        }
        draw_set_alpha(1);
    }
    // specks
    var _nS = floor(_W * _H / 260);
    chc__pts_begin();
    for (var _k = 0; _k < _nS; _k++) {
        var _col = (chc_rand(_g) < 0.5) ? _P.gs1 : _P.gs2;
        chc__pt(chc_range(_g, 0, _W), chc_range(_g, 0, _H), _col, 0.7);
    }
    chc__pts_end();
}

/// @function chc__paint_water(c, P, g)
/// @description Internal. The harbour: deep water with ripples, a stone quay edge with bollards, boats with wakes.
function chc__paint_water(_c, _P, _g) {
    var _wa = _c.layout.water;
    if (is_undefined(_wa)) return;
    var _W = _c.worldW, _H = _c.worldH, _wy = _wa.y;
    draw_rectangle_colour(0, _wy, _W, _H, chc__rgb(38, 104, 150), chc__rgb(38, 104, 150), chc__rgb(20, 62, 108), chc__rgb(20, 62, 108), false);
    draw_set_alpha(0.28);
    repeat (700) {
        var _x = chc_range(_g, 0, _W), _y = chc_range(_g, _wy + 14, _H), _l = chc_range(_g, 6, 22);
        draw_set_colour((chc_rand(_g) < 0.6) ? chc__rgb(120, 180, 214) : chc__rgb(16, 50, 90));
        draw_line_width(_x, _y, _x + _l, _y - _l * 0.08, 1.2);
    }
    draw_set_alpha(1);
    // the quay: a stone coping with a dark drop to the water and bollards
    chc__quad(0, _wy - 10, _W, _wy - 10, _W, _wy + 6, 0, _wy + 6, chc__rgb(198, 192, 178), 1);
    chc__quad(0, _wy + 6, _W, _wy + 6, _W, _wy + 12, 0, _wy + 12, chc__rgb(40, 44, 50), 0.85);
    for (var _x = 30; _x < _W; _x += 90) { chc__disc(_x + 1, _wy - 1, 5, chc__rgb(20, 22, 26), 0.5); chc__disc(_x, _wy - 2, 4, chc__rgb(52, 56, 62), 1); }
    var _bc = [chc__rgb(240, 240, 236), chc__rgb(200, 40, 44), chc__rgb(30, 70, 150), chc__rgb(236, 200, 60), chc__rgb(40, 140, 110), chc__rgb(28, 28, 34)];
    for (var _b = 0; _b < array_length(_c.layout.boats); _b++) {
        var _bt = _c.layout.boats[_b];
        var _ca = cos(_bt.ang), _sa = sin(_bt.ang), _L2 = _bt.len / 2, _Wb = _bt.len * 0.19;
        // the wake, then the hull (a pointed bow), the deck, a cabin
        draw_set_alpha(0.35); draw_set_colour(chc__rgb(200, 230, 246));
        draw_line_width(_bt.x - _ca * _L2, _bt.y - _sa * _L2, _bt.x - _ca * (_L2 + 50) - _sa * 12, _bt.y - _sa * (_L2 + 50) + _ca * 12, 2);
        draw_line_width(_bt.x - _ca * _L2, _bt.y - _sa * _L2, _bt.x - _ca * (_L2 + 50) + _sa * 12, _bt.y - _sa * (_L2 + 50) - _ca * 12, 2);
        draw_set_alpha(1);
        var _xs = [], _ys = [];
        var _shape = [1, 0, 0.55, 1, -1, 1, -1, -1, 0.55, -1];
        for (var _k = 0; _k < 10; _k += 2) { var _u = _shape[_k] * _L2, _v = _shape[_k + 1] * _Wb; array_push(_xs, _bt.x + _u * _ca - _v * _sa + 4); array_push(_ys, _bt.y + _u * _sa + _v * _ca + 5); }
        chc__poly(_xs, _ys, chc__rgb(8, 30, 60), 0.4);
        for (var _k = 0; _k < 5; _k++) { _xs[_k] -= 4; _ys[_k] -= 5; }
        chc__poly(_xs, _ys, _bc[_bt.col], 1);
        var _dk = chc__shade(_bc[_bt.col], 1.25);
        chc__orect(_bt.x - _ca * _L2 * 0.1, _bt.y - _sa * _L2 * 0.1, _bt.ang, _bt.len * 0.62, _Wb * 1.3, (_bt.col == 0) ? chc__rgb(196, 170, 120) : _dk, 1);
        chc__orect(_bt.x - _ca * _L2 * 0.18, _bt.y - _sa * _L2 * 0.18, _bt.ang, _bt.len * 0.3, _Wb * 0.9, chc__rgb(236, 238, 240), 1);
        chc__orect(_bt.x - _ca * _L2 * 0.08, _bt.y - _sa * _L2 * 0.08, _bt.ang, _bt.len * 0.08, _Wb * 0.7, chc__rgb(40, 60, 90), 1);
    }
}

/// @function chc__paint_buildings(c, P, g, shadows)
/// @description Internal. City blocks seen from above: a cast shadow pass, then roofs with a parapet, rooftop plant, and
/// at night lit skylights and a neon edge on some.
function chc__paint_buildings(_c, _P, _g, _shadows) {
    var _B = _c.layout.buildings;
    if (array_length(_B) == 0) return;
    var _night = _P.night;
    for (var _k = 0; _k < array_length(_B); _k++) {
        var _b = _B[_k];
        var _x0 = _b.x - _b.w / 2, _y0 = _b.y - _b.h / 2, _x1 = _b.x + _b.w / 2, _y1 = _b.y + _b.h / 2;
        if (_shadows) { chc__quad(_x0 + 14, _y0 + 16, _x1 + 14, _y0 + 16, _x1 + 14, _y1 + 16, _x0 + 14, _y1 + 16, _P.shadow, _night ? 0.6 : 0.32); continue; }
        var _base;
        if (_night) _base = merge_colour(chc__rgb(52, 56, 74), chc__rgb(80, 70, 92), _b.tone);
        else if (_c.theme == "harbour") _base = merge_colour(chc__rgb(232, 226, 214), chc__rgb(206, 120, 90), _b.tone * 0.7);
        else _base = merge_colour(chc__rgb(150, 146, 140), chc__rgb(186, 120, 96), _b.tone * 0.8);
        // walls lit from the top left: the parapet's top and left edges light, bottom and right dark
        draw_rectangle_colour(_x0, _y0, _x1, _y1, _base, _base, _base, _base, false);
        chc__quad(_x0, _y0, _x1, _y0, _x1 - 5, _y0 + 5, _x0 + 5, _y0 + 5, chc__shade(_base, 1.28), 1);
        chc__quad(_x0, _y0, _x0 + 5, _y0 + 5, _x0 + 5, _y1 - 5, _x0, _y1, chc__shade(_base, 1.16), 1);
        chc__quad(_x0, _y1, _x0 + 5, _y1 - 5, _x1 - 5, _y1 - 5, _x1, _y1, chc__shade(_base, 0.7), 1);
        chc__quad(_x1, _y0, _x1, _y1, _x1 - 5, _y1 - 5, _x1 - 5, _y0 + 5, chc__shade(_base, 0.78), 1);
        var _in = chc__shade(_base, 0.92);
        draw_rectangle_colour(_x0 + 5, _y0 + 5, _x1 - 5, _y1 - 5, _in, _in, chc__shade(_in, 0.94), chc__shade(_in, 0.94), false);
        // rooftop plant: boxes with their own shadows, a vent ring
        var _n = 1 + floor(_b.w * _b.h / 9000);
        for (var _q = 0; _q < _n; _q++) {
            var _px = lerp(_x0 + 16, _x1 - 26, chc_rand(_g)), _py = lerp(_y0 + 16, _y1 - 22, chc_rand(_g));
            var _pw = chc_range(_g, 10, 22), _ph = chc_range(_g, 8, 16);
            draw_rectangle_colour(_px + 3, _py + 3, _px + _pw + 3, _py + _ph + 3, _P.shadow, _P.shadow, _P.shadow, _P.shadow, false);
            var _pc = chc__shade(_base, 1.1 + chc_rand(_g) * 0.1);
            draw_rectangle_colour(_px, _py, _px + _pw, _py + _ph, _pc, _pc, chc__shade(_pc, 0.85), chc__shade(_pc, 0.85), false);
        }
        if (_b.roof == 1) { chc__disc(_x0 + _b.w * 0.7, _y0 + _b.h * 0.3, min(_b.w, _b.h) * 0.12, chc__shade(_base, 0.6), 1); chc__disc(_x0 + _b.w * 0.7 - 1, _y0 + _b.h * 0.3 - 1, min(_b.w, _b.h) * 0.09, chc__shade(_base, 1.2), 1); }
        if (_night) {
            // lit skylights, and a neon trim on a third of the blocks
            gpu_set_blendmode(bm_add);
            var _sky = (_b.lit < 0.5) ? chc__rgb(255, 196, 110) : chc__rgb(140, 210, 255);
            for (var _q = 0; _q < 3 + floor(_b.w / 50); _q++) {
                var _sx = lerp(_x0 + 12, _x1 - 18, chc_rand(_g)), _sy = lerp(_y0 + 12, _y1 - 14, chc_rand(_g));
                draw_rectangle_colour(_sx, _sy, _sx + 6, _sy + 3, _sky, _sky, _sky, _sky, false);
                chc__glow(_sx + 3, _sy + 1.5, 14, _sky, 0.35);
            }
            if (_b.lit > 0.66) {
                var _neon = (_b.tone < 0.5) ? chc__rgb(40, 220, 255) : chc__rgb(255, 60, 190);
                draw_set_alpha(0.9); draw_set_colour(_neon);
                draw_line_width(_x0 + 2, _y0 + 2, _x1 - 2, _y0 + 2, 2); draw_line_width(_x0 + 2, _y0 + 2, _x0 + 2, _y1 - 2, 2);
                draw_set_alpha(0.25);
                draw_line_width(_x0 + 2, _y0 + 2, _x1 - 2, _y0 + 2, 8); draw_line_width(_x0 + 2, _y0 + 2, _x0 + 2, _y1 - 2, 8);
                draw_set_alpha(1);
            }
            chc__over();
        }
    }
}

/// @function chc__paint_runoff(c, P, g)
/// @description Internal. The run-off on both sides (pavement on street themes), gravel traps with their stones and soft
/// edges on the outside of corners, painted tarmac run-off on some grand prix corners, and rally marker poles.
function chc__paint_runoff(_c, _P, _g) {
    var _hw = _c.hw, _ro = _c.runoff, _n = _c.n, _L = _c.layout;
    if (_P.runoff >= 0) {
        chc__band(_c, 0, _n, _hw - 1, _hw + _ro + 2, _P.runoff, _P.runoff, 1);
        chc__band(_c, 0, _n, -_hw + 1, -_hw - _ro - 2, _P.runoff, _P.runoff, 1);
        // a pavement kerbstone line at the road edge and a darker strip at the wall foot
        var _ks = chc__shade(_P.runoff, 1.14), _wf = chc__shade(_P.runoff, 0.8);
        chc__band(_c, 0, _n, _hw, _hw + 4, _ks, _ks, 1); chc__band(_c, 0, _n, -_hw, -_hw - 4, _ks, _ks, 1);
        chc__band(_c, 0, _n, _hw + _ro - 6, _hw + _ro, _wf, _wf, 0.8); chc__band(_c, 0, _n, -_hw - _ro + 6, -_hw - _ro, _wf, _wf, 0.8);
    } else if (!_P.dirt && !_P.snow) {
        // grass run-off a touch brighter than the ground, so the corridor reads
        var _rc = chc__shade(_P.ground2, 1.04);
        chc__band(_c, 0, _n, _hw - 1, _hw + _ro, _rc, _rc, 0.7);
        chc__band(_c, 0, _n, -_hw + 1, -_hw - _ro, _rc, _rc, 0.7);
    }
    for (var _q = 0; _q < array_length(_L.gravel); _q++) {
        var _gv = _L.gravel[_q], _sd = _gv.side;
        if (_P.dirt || _P.snow) continue;
        var _d0 = (_hw + 10) * _sd, _d1 = (_hw + _ro * 0.9) * _sd;
        if (_gv.tarmac) {
            chc__band(_c, _gv.i0, _gv.len, _d0, _d1, _P.tarmac, _P.tarmac, 1);
            // painted stripes across the run-off, alternating blue and red
            for (var _k = 2; _k < _gv.len - 2; _k += 3) {
                var _i = (_gv.i0 + _k) mod _n, _j = (_i + 1) mod _n;
                var _col = ((_k div 3) mod 2 == 0) ? _P.paintA : _P.paintB;
                chc__quad(_c.px[_i] + _c.nx[_i] * _d0, _c.py[_i] + _c.ny[_i] * _d0, _c.px[_j] + _c.nx[_j] * _d0, _c.py[_j] + _c.ny[_j] * _d0,
                          _c.px[_j] + _c.nx[_j] * _d1, _c.py[_j] + _c.ny[_j] * _d1, _c.px[_i] + _c.nx[_i] * _d1, _c.py[_i] + _c.ny[_i] * _d1, _col, 0.85);
            }
        } else {
            // the trap tapers in at both ends, its stones are two tones, its edge raked
            var _taper = 5;
            for (var _k = 0; _k < _gv.len; _k++) {
                var _i = (_gv.i0 + _k) mod _n, _j = (_i + 1) mod _n;
                var _f0 = min(1, min(_k, _gv.len - _k) / _taper), _f1 = min(1, min(_k + 1, _gv.len - _k - 1) / _taper);
                var _e0 = _d0 + (_d1 - _d0) * max(0.05, _f0), _e1 = _d0 + (_d1 - _d0) * max(0.05, _f1);
                chc__quad(_c.px[_i] + _c.nx[_i] * _d0, _c.py[_i] + _c.ny[_i] * _d0, _c.px[_j] + _c.nx[_j] * _d0, _c.py[_j] + _c.ny[_j] * _d0,
                          _c.px[_j] + _c.nx[_j] * _e1, _c.py[_j] + _c.ny[_j] * _e1, _c.px[_i] + _c.nx[_i] * _e0, _c.py[_i] + _c.ny[_i] * _e0, _P.gravel, 1);
            }
            chc__pts_begin();
            for (var _k = 0; _k < _gv.len; _k++) {
                var _i = (_gv.i0 + _k) mod _n;
                var _f = min(1, min(_k, _gv.len - _k) / _taper);
                repeat (16) {
                    var _dd = lerp(_d0, _d0 + (_d1 - _d0) * max(0.05, _f), chc_rand(_g)), _ss = chc_range(_g, -4, 4);
                    chc__pt(_c.px[_i] + _c.nx[_i] * _dd + _c.tx[_i] * _ss, _c.py[_i] + _c.ny[_i] * _dd + _c.ty[_i] * _ss, (chc_rand(_g) < 0.55) ? _P.gv1 : _P.gv2, 0.9);
                }
            }
            chc__pts_end();
        }
    }
    if (_P.dirt || _P.snow) {
        // rally: red and white marker poles on every apex, soft verges either side of the road
        var _vc = _P.snow ? chc__rgb(250, 252, 255) : _P.gs1;
        chc__band(_c, 0, _n, _hw - 2, _hw + 9, _vc, _P.ground, 0.8);
        chc__band(_c, 0, _n, -_hw + 2, -_hw - 9, _vc, _P.ground, 0.8);
        for (var _q = 0; _q < array_length(_L.corners); _q++) {
            var _cn = _L.corners[_q];
            for (var _m = -1; _m <= 1; _m++) {
                var _i = chc__wrap(_cn.apex + _m * 6, _n);
                var _d = (_hw + 12) * _cn.side;
                var _x = _c.px[_i] + _c.nx[_i] * _d, _y = _c.py[_i] + _c.ny[_i] * _d;
                chc__disc(_x + 2, _y + 3, 3.5, _P.shadow, 0.35);
                chc__disc(_x, _y, 3, (_m == 0) ? chc__rgb(220, 40, 40) : chc__rgb(244, 244, 240), 1);
            }
        }
    }
}

/// @function chc__paint_road(c, P, g)
/// @description Internal. The road: base with resurfacing patches, aggregate grain, the rubbered racing line, braking
/// streaks, and white edge lines (ruts on dirt and snow instead).
function chc__paint_road(_c, _P, _g) {
    var _hw = _c.hw, _n = _c.n;
    chc__band(_c, 0, _n, -_hw, _hw, _P.road, _P.road, 1);
    // resurfacing patches: a few long rectangles of slightly different road
    repeat (10) {
        var _i0 = floor(chc_rand(_g) * _n), _len = 8 + floor(chc_rand(_g) * 30);
        var _dA = chc_range(_g, -_hw, 0), _dB = _dA + chc_range(_g, _hw * 0.4, _hw * 1.2);
        _dB = min(_dB, _hw);
        chc__band(_c, _i0, _len, _dA, _dB, chc__shade(_P.road, (chc_rand(_g) < 0.5) ? 0.94 : 1.05), chc__shade(_P.road, 1), 0.5);
    }
    if (_P.dirt || _P.snow) {
        // two ruts worn by every car before, and loose stones / snow crust between
        for (var _s = -1; _s <= 1; _s += 2) {
            var _rc = _c.line;
            var _v = 0;
            draw_primitive_begin(pr_trianglestrip);
            for (var _k = 0; _k <= _n; _k++) {
                var _i = _k mod _n, _d = clamp(_rc[_i] + _s * 9, -_hw + 4, _hw - 4);
                draw_vertex_colour(_c.px[_i] + _c.nx[_i] * (_d - 4), _c.py[_i] + _c.ny[_i] * (_d - 4), _P.rubber, 0.0);
                draw_vertex_colour(_c.px[_i] + _c.nx[_i] * _d, _c.py[_i] + _c.ny[_i] * _d, _P.rubber, 0.55);
                _v += 2;
                if (_v >= CHC_FLUSH && _k < _n) { draw_primitive_end(); draw_primitive_begin(pr_trianglestrip); draw_vertex_colour(_c.px[_i] + _c.nx[_i] * (_d - 4), _c.py[_i] + _c.ny[_i] * (_d - 4), _P.rubber, 0.0); draw_vertex_colour(_c.px[_i] + _c.nx[_i] * _d, _c.py[_i] + _c.ny[_i] * _d, _P.rubber, 0.55); _v = 2; }
            }
            draw_primitive_end();
            _v = 0;
            draw_primitive_begin(pr_trianglestrip);
            for (var _k = 0; _k <= _n; _k++) {
                var _i = _k mod _n, _d = clamp(_rc[_i] + _s * 9, -_hw + 4, _hw - 4);
                draw_vertex_colour(_c.px[_i] + _c.nx[_i] * _d, _c.py[_i] + _c.ny[_i] * _d, _P.rubber, 0.55);
                draw_vertex_colour(_c.px[_i] + _c.nx[_i] * (_d + 4), _c.py[_i] + _c.ny[_i] * (_d + 4), _P.rubber, 0.0);
                _v += 2;
                if (_v >= CHC_FLUSH && _k < _n) { draw_primitive_end(); draw_primitive_begin(pr_trianglestrip); draw_vertex_colour(_c.px[_i] + _c.nx[_i] * _d, _c.py[_i] + _c.ny[_i] * _d, _P.rubber, 0.55); draw_vertex_colour(_c.px[_i] + _c.nx[_i] * (_d + 4), _c.py[_i] + _c.ny[_i] * (_d + 4), _P.rubber, 0.0); _v = 2; }
            }
            draw_primitive_end();
        }
    } else {
        // the rubbered line: a soft wide band and a darker core where the tyres run
        chc__band_line(_c, 14, _P.rubber, 0.10);
        chc__band_line(_c, 8, _P.rubber, 0.16);
    }
    // grain: light and dark aggregate specks across the whole width
    chc__pts_begin();
    for (var _i = 0; _i < _n; _i++) {
        repeat (14) {
            var _d = chc_range(_g, -_hw + 1, _hw - 1), _ss = chc_range(_g, -4, 4);
            chc__pt(_c.px[_i] + _c.nx[_i] * _d + _c.tx[_i] * _ss, _c.py[_i] + _c.ny[_i] * _d + _c.ty[_i] * _ss, (chc_rand(_g) < 0.5) ? _P.rs1 : _P.rs2, 0.75);
        }
    }
    chc__pts_end();
    // braking streaks before every corner on the line: short dark marks in pairs
    var _B = chc_body(_c.T.body), _pr = chc__profile(_c, _B);
    draw_set_colour(_P.rubber);
    for (var _i = 0; _i < _n; _i++) {
        if (!_pr.brake[_i] || chc_rand(_g) > 0.22) continue;
        var _len = chc_range(_g, 3, 9), _j = (_i + floor(_len)) mod _n;
        var _d = _c.line[_i] + chc_range(_g, -5, 5);
        draw_set_alpha(chc_range(_g, 0.12, 0.28));
        for (var _w = -1; _w <= 1; _w += 2) {
            var _o = _d + _w * 5.5;
            draw_line_width(_c.px[_i] + _c.nx[_i] * _o, _c.py[_i] + _c.ny[_i] * _o, _c.px[_j] + _c.nx[_j] * _o, _c.py[_j] + _c.ny[_j] * _o, 2.2);
        }
    }
    draw_set_alpha(1);
    if (!_P.dirt && !_P.snow) {
        chc__band(_c, 0, _n, _hw - 5, _hw - 2, _P.edge, _P.edge, 0.95);
        chc__band(_c, 0, _n, -_hw + 5, -_hw + 2, _P.edge, _P.edge, 0.95);
    }
}

/// @function chc__paint_kerbs(c, P)
/// @description Internal. Red-and-white kerbs: 14 px blocks along the run, from just inside the edge line to 10 px out, a
/// dark outer lip and a lit inner rim so they read as raised.
function chc__paint_kerbs(_c, _P) {
    var _K = _c.layout.kerbs, _n = _c.n, _hw = _c.hw;
    for (var _q = 0; _q < array_length(_K); _q++) {
        var _kb = _K[_q], _sd = _kb.side;
        var _d0 = (_hw - 6) * _sd, _d1 = (_hw + 10) * _sd, _dl = (_hw + 12) * _sd;
        var _blk = max(1, floor(14 / _c.step + 0.5));
        for (var _k = 0; _k < _kb.len; _k++) {
            var _i = (_kb.i0 + _k) mod _n, _j = (_i + 1) mod _n;
            var _col = ((_k div _blk) mod 2 == 0) ? _P.kerbA : _P.kerbB;
            chc__quad(_c.px[_i] + _c.nx[_i] * _d0, _c.py[_i] + _c.ny[_i] * _d0, _c.px[_j] + _c.nx[_j] * _d0, _c.py[_j] + _c.ny[_j] * _d0,
                      _c.px[_j] + _c.nx[_j] * _d1, _c.py[_j] + _c.ny[_j] * _d1, _c.px[_i] + _c.nx[_i] * _d1, _c.py[_i] + _c.ny[_i] * _d1, _col, 1);
        }
        chc__band(_c, _kb.i0, _kb.len, _d1, _dl, chc__rgb(24, 24, 26), chc__rgb(24, 24, 26), 0.45);
        chc__band(_c, _kb.i0, _kb.len, _d0, _d0 + 2 * _sd, c_white, c_white, 0.28);
    }
}

/// @function chc__paint_grid(c, P)
/// @description Internal. The start/finish line (a two-row chequer across the road with a white line) and painted grid
/// boxes with their slot numbers.
function chc__paint_grid(_c, _P) {
    var _hw = _c.hw;
    var _cols = 8;
    var _sq = _c.width / _cols;
    for (var _r = 0; _r < 3; _r++) for (var _q = 0; _q < _cols; _q++) {
        var _col = ((_r + _q) mod 2 == 0) ? chc__rgb(244, 244, 240) : chc__rgb(20, 20, 22);
        var _a0 = -_hw + _q * _sq, _a1 = _a0 + _sq, _s0 = -_r * _sq - 2, _s1 = _s0 - _sq;
        var _i = 0;
        chc__quad(_c.px[_i] + _c.nx[_i] * _a0 + _c.tx[_i] * _s0, _c.py[_i] + _c.ny[_i] * _a0 + _c.ty[_i] * _s0,
                  _c.px[_i] + _c.nx[_i] * _a1 + _c.tx[_i] * _s0, _c.py[_i] + _c.ny[_i] * _a1 + _c.ty[_i] * _s0,
                  _c.px[_i] + _c.nx[_i] * _a1 + _c.tx[_i] * _s1, _c.py[_i] + _c.ny[_i] * _a1 + _c.ty[_i] * _s1,
                  _c.px[_i] + _c.nx[_i] * _a0 + _c.tx[_i] * _s1, _c.py[_i] + _c.ny[_i] * _a0 + _c.ty[_i] * _s1, _col, 0.95);
    }
    chc__orect(_c.px[0], _c.py[0], arctan2(_c.ny[0], _c.nx[0]), _c.width, 3, chc__rgb(244, 244, 240), 1);
    if (_P.dirt || _P.snow) return;
    draw_set_font(fnt_chicane_display_s);
    draw_set_halign(fa_center); draw_set_valign(fa_middle);
    var _tf = gpu_get_texfilter();
    gpu_set_texfilter(true);
    for (var _k = 0; _k < array_length(_c.grid); _k++) {
        var _gs = _c.grid[_k], _i = _gs.i;
        if (variable_struct_exists(_gs, "painted") && !_gs.painted) continue;   // a slot off the start straight gets no box
        var _fx = _c.tx[_i], _fy = _c.ty[_i], _nx = _c.nx[_i], _ny = _c.ny[_i];
        var _bx = _gs.x + _fx * 12, _by = _gs.y + _fy * 12, _hwb = 11;
        draw_set_colour(_P.edge); draw_set_alpha(0.9);
        draw_line_width(_bx + _nx * _hwb, _by + _ny * _hwb, _bx - _nx * _hwb, _by - _ny * _hwb, 2.2);
        draw_line_width(_bx + _nx * _hwb, _by + _ny * _hwb, _bx + _nx * _hwb - _fx * 12, _by + _ny * _hwb - _fy * 12, 2.2);
        draw_line_width(_bx - _nx * _hwb, _by - _ny * _hwb, _bx - _nx * _hwb - _fx * 12, _by - _ny * _hwb - _fy * 12, 2.2);
        draw_set_alpha(0.7);
        var _tx = _gs.x - _fx * 4 - _nx * sign(_gs.d) * 19, _ty = _gs.y - _fy * 4 - _ny * sign(_gs.d) * 19;
        draw_text_transformed(_tx, _ty, string(_k + 1), 0.34, 0.34, -radtodeg(_gs.ang + pi / 2));
    }
    draw_set_alpha(1);
    gpu_set_texfilter(_tf);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
}

/// @function chc__paint_pit(c, P, g)
/// @description Internal. The pit lane beside the start straight (tapered entry and exit), the pit wall with its painted
/// stripe, ten pit boxes in team colours, and the garage building with a control tower.
function chc__paint_pit(_c, _P, _g) {
    var _pt = _c.layout.pit;
    if (is_undefined(_pt)) return;
    var _n = _c.n, _sd = _pt.side, _hw = _c.hw;
    var _wall0 = (_hw + 8) * _sd, _wall1 = (_hw + 13) * _sd, _l0 = (_hw + 14) * _sd, _l1 = (_hw + 44) * _sd;
    var _tap = 14;
    for (var _k = 0; _k < _pt.len; _k++) {
        var _i = (_pt.i0 + _k) mod _n, _j = (_i + 1) mod _n;
        var _f0 = min(1, min(_k, _pt.len - _k) / _tap), _f1 = min(1, min(_k + 1, _pt.len - _k - 1) / _tap);
        var _a0 = lerp((_hw - 2) * _sd, _l0, min(1, _f0 * 3)), _a1 = lerp((_hw - 2) * _sd, _l0, min(1, _f1 * 3));
        var _b0 = lerp((_hw + 2) * _sd, _l1, _f0), _b1 = lerp((_hw + 2) * _sd, _l1, _f1);
        chc__quad(_c.px[_i] + _c.nx[_i] * _a0, _c.py[_i] + _c.ny[_i] * _a0, _c.px[_j] + _c.nx[_j] * _a1, _c.py[_j] + _c.ny[_j] * _a1,
                  _c.px[_j] + _c.nx[_j] * _b1, _c.py[_j] + _c.ny[_j] * _b1, _c.px[_i] + _c.nx[_i] * _b0, _c.py[_i] + _c.ny[_i] * _b0, chc__shade(_P.road, 1.06), 1);
    }
    var _wi0 = _pt.i0 + _tap, _wl = max(2, _pt.len - _tap * 2);
    chc__band(_c, _wi0, _wl, _wall0, _wall1, chc__rgb(214, 214, 210), chc__rgb(150, 150, 150), 1);
    chc__band(_c, _wi0, _wl, _wall0, _wall0 + 1.5 * _sd, chc__rgb(200, 40, 44), chc__rgb(200, 40, 44), 1);
    chc__band(_c, _wi0, _wl, (_hw + 29) * _sd, (_hw + 30) * _sd, _P.edge, _P.edge, 0.6);
    // the apron from the lane to the garages (concrete), and a pit box painted in front of each garage
    var _bl = _pt.building;
    var _halfB = floor(_bl.len / 2 / _c.step);
    var _apr = chc__rgb(150, 152, 156);
    chc__band(_c, chc__wrap(-_halfB, _n), _halfB * 2, (_hw + 44) * _sd, (_bl.off - _bl.dep / 2 + 1) * _sd, _apr, chc__shade(_apr, 0.92), 1);
    chc__band(_c, chc__wrap(-_halfB, _n), _halfB * 2, (_hw + 44) * _sd, (_hw + 45.5) * _sd, _P.edge, _P.edge, 0.7);
    var _pal = chc__team_colours();
    for (var _b = 0; _b < _pt.boxes; _b++) {
        var _u = ((_b + 0.5) / _pt.boxes - 0.5) * (_bl.len - 16);
        var _i = chc__wrap(floor(_u / _c.step + 0.5), _n);
        var _dm = (_hw + 44 + _bl.off - _bl.dep / 2) / 2;
        var _cx = _c.px[_i] + _c.nx[_i] * _dm * _sd, _cy = _c.py[_i] + _c.ny[_i] * _dm * _sd;
        var _ang = arctan2(_c.ty[_i], _c.tx[_i]);
        var _bw = (_bl.len - 16) / _pt.boxes - 8, _bd = (_bl.off - _bl.dep / 2) - (_hw + 44) - 10;
        chc__orect(_cx, _cy, _ang, _bw, max(6, _bd), _pal[_b mod array_length(_pal)], 0.9);
        chc__orect(_cx, _cy, _ang, _bw - 3, max(3, _bd - 3), _apr, 1);
    }
    chc__orect(_bl.x + 10, _bl.y + 12, _bl.ang, _bl.len, _bl.dep, _P.shadow, 0.35);
    chc__orect(_bl.x, _bl.y, _bl.ang, _bl.len, _bl.dep, chc__rgb(196, 198, 204), 1);
    chc__orect(_bl.x, _bl.y, _bl.ang, _bl.len - 8, _bl.dep - 8, chc__rgb(176, 180, 188), 1);
    var _ca = cos(_bl.ang), _sa = sin(_bl.ang), _q = -_sa * _sd, _qy = _ca * _sd;
    for (var _b = 0; _b < _pt.boxes; _b++) {
        var _u = ((_b + 0.5) / _pt.boxes - 0.5) * (_bl.len - 16);
        var _gx = _bl.x + _ca * _u - _q * (_bl.dep / 2 - 6), _gy = _bl.y + _sa * _u - _qy * (_bl.dep / 2 - 6);
        chc__orect(_gx, _gy, _bl.ang, (_bl.len - 16) / _pt.boxes - 4, 6, _pal[_b mod array_length(_pal)], 1);
    }
    var _tx = _bl.x + _ca * (_bl.len / 2 - 22), _ty = _bl.y + _sa * (_bl.len / 2 - 22);
    chc__orect(_tx + 6, _ty + 8, _bl.ang, 34, 34, _P.shadow, 0.35);
    chc__orect(_tx, _ty, _bl.ang, 34, 34, chc__rgb(226, 228, 232), 1);
    chc__orect(_tx, _ty, _bl.ang, 24, 24, chc__rgb(40, 60, 90), 1);
}

/// @function chc__paint_barriers(c, P, g)
/// @description Internal. Barriers at the edge of the run-off: concrete walls with a catch fence on street themes,
/// stacked tyre walls (banded tops) where the layout asks, armco with posts everywhere else, snow banks on snow.
function chc__paint_barriers(_c, _P, _g) {
    var _n = _c.n, _bd = _c.hw + _c.runoff, _L = _c.layout;
    if (_c.T.walls) {
        for (var _s = -1; _s <= 1; _s += 2) {
            chc__band(_c, 0, _n, (_bd + 2) * _s, (_bd + 12) * _s, _P.shadow, _P.shadow, 0.35);
            chc__band(_c, 0, _n, _bd * _s, (_bd + 7) * _s, _P.wall, chc__shade(_P.wall, 0.82), 1);
            chc__band(_c, 0, _n, _bd * _s, (_bd + 1.5) * _s, chc__shade(_P.wall, 1.2), chc__shade(_P.wall, 1.2), 1);
            chc__band(_c, 0, _n, (_bd + 7) * _s, (_bd + 8) * _s, chc__rgb(30, 32, 36), chc__rgb(30, 32, 36), 0.8);
            for (var _i = 0; _i < _n; _i += 5) chc__disc(_c.px[_i] + _c.nx[_i] * (_bd + 7.5) * _s, _c.py[_i] + _c.ny[_i] * (_bd + 7.5) * _s, 1.6, chc__rgb(60, 62, 68), 1);
        }
        return;
    }
    if (_P.snow) {
        for (var _s = -1; _s <= 1; _s += 2) {
            chc__band(_c, 0, _n, (_bd - 10) * _s, (_bd + 6) * _s, chc__rgb(250, 252, 255), chc__rgb(206, 218, 238), 1);
            chc__band(_c, 0, _n, (_bd + 6) * _s, (_bd + 14) * _s, _P.shadow, _P.shadow, 0.25);
        }
        return;
    }
    // where tyre walls sit (and the pit garages, which are the barrier along their own length)
    var _ty = array_create(_n * 2, false);
    var _pt = _L.pit;
    if (!is_undefined(_pt)) {
        var _halfB = floor(_pt.building.len / 2 / _c.step);
        for (var _k = -_halfB; _k <= _halfB; _k++) _ty[chc__wrap(_k, _n) * 2 + ((_pt.side > 0) ? 0 : 1)] = true;
    }
    for (var _q = 0; _q < array_length(_L.tyres); _q++) {
        var _tw = _L.tyres[_q];
        for (var _k = 0; _k < _tw.len; _k++) _ty[((_tw.i0 + _k) mod _n) * 2 + ((_tw.side > 0) ? 0 : 1)] = true;
    }
    if (!_P.dirt) {
        for (var _s = -1; _s <= 1; _s += 2) {
            var _side = (_s > 0) ? 0 : 1;
            // armco: shadow, two rails, posts every 16 px, skipped where tyres stand
            draw_set_alpha(1);
            for (var _i = 0; _i < _n; _i++) {
                if (_ty[_i * 2 + _side]) continue;
                var _j = (_i + 1) mod _n;
                var _d = _bd * _s;
                chc__quad(_c.px[_i] + _c.nx[_i] * (_d + 2 * _s), _c.py[_i] + _c.ny[_i] * (_d + 2 * _s), _c.px[_j] + _c.nx[_j] * (_d + 2 * _s), _c.py[_j] + _c.ny[_j] * (_d + 2 * _s),
                          _c.px[_j] + _c.nx[_j] * (_d + 7 * _s), _c.py[_j] + _c.ny[_j] * (_d + 7 * _s), _c.px[_i] + _c.nx[_i] * (_d + 7 * _s), _c.py[_i] + _c.ny[_i] * (_d + 7 * _s), _P.shadow, 0.3);
                chc__quad(_c.px[_i] + _c.nx[_i] * _d, _c.py[_i] + _c.ny[_i] * _d, _c.px[_j] + _c.nx[_j] * _d, _c.py[_j] + _c.ny[_j] * _d,
                          _c.px[_j] + _c.nx[_j] * (_d + 1.6 * _s), _c.py[_j] + _c.ny[_j] * (_d + 1.6 * _s), _c.px[_i] + _c.nx[_i] * (_d + 1.6 * _s), _c.py[_i] + _c.ny[_i] * (_d + 1.6 * _s), _P.barrier, 1);
                chc__quad(_c.px[_i] + _c.nx[_i] * (_d + 2.6 * _s), _c.py[_i] + _c.ny[_i] * (_d + 2.6 * _s), _c.px[_j] + _c.nx[_j] * (_d + 2.6 * _s), _c.py[_j] + _c.ny[_j] * (_d + 2.6 * _s),
                          _c.px[_j] + _c.nx[_j] * (_d + 4 * _s), _c.py[_j] + _c.ny[_j] * (_d + 4 * _s), _c.px[_i] + _c.nx[_i] * (_d + 4 * _s), _c.py[_i] + _c.ny[_i] * (_d + 4 * _s), chc__shade(_P.barrier, 0.8), 1);
                if (_i mod 2 == 0) chc__disc(_c.px[_i] + _c.nx[_i] * (_d + 5 * _s), _c.py[_i] + _c.ny[_i] * (_d + 5 * _s), 1.4, chc__rgb(70, 74, 82), 1);
            }
        }
    }
    // tyre walls: two staggered rows, every fourth tyre banded red or white on top
    var _tc = (_c.theme == "kart") ? [chc__rgb(210, 40, 44), chc__rgb(238, 238, 232), chc__rgb(36, 80, 180), chc__rgb(240, 200, 40)] : [chc__rgb(210, 40, 44), chc__rgb(238, 238, 232)];
    for (var _q = 0; _q < array_length(_L.tyres); _q++) {
        var _tw = _L.tyres[_q], _s = _tw.side;
        var _acc = 0;
        for (var _k = 0; _k < _tw.len; _k++) {
            var _i = (_tw.i0 + _k) mod _n;
            _acc += _c.step;
            if (_acc < 9) continue;
            _acc = 0;
            if (_P.dirt) {
                // rally: straw bales end to end instead of tyres
                var _db = (_bd + 6) * _s;
                var _bx = _c.px[_i] + _c.nx[_i] * _db, _by = _c.py[_i] + _c.ny[_i] * _db, _ba = arctan2(_c.ty[_i], _c.tx[_i]);
                chc__orect(_bx + 2, _by + 3, _ba, 10, 7, _P.shadow, 0.35);
                chc__orect(_bx, _by, _ba, 10, 7, chc__rgb(222, 186, 96), 1);
                chc__orect(_bx, _by, _ba, 10, 1.2, chc__rgb(176, 138, 60), 1);
                chc__orect(_bx - cos(_ba) * 2, _by - sin(_ba) * 2, _ba, 1, 7, chc__rgb(186, 148, 70), 1);
                continue;
            }
            for (var _row = 0; _row < 2; _row++) {
                var _d = (_bd + 4 + _row * 7.5) * _s, _sh = (_row == 1) ? 4.5 : 0;
                var _x = _c.px[_i] + _c.nx[_i] * _d + _c.tx[_i] * _sh, _y = _c.py[_i] + _c.ny[_i] * _d + _c.ty[_i] * _sh;
                chc__disc(_x + 1.5, _y + 2.5, 4.6, _P.shadow, 0.35);
                var _band = ((_k div 2 + _row) mod 4 == 0);
                chc__disc(_x, _y, 4.4, _band ? _tc[((_k div 8) + _row) mod array_length(_tc)] : _P.tyre, 1);
                chc__disc(_x, _y, 2.2, chc__rgb(14, 14, 16), 1);
                chc__disc(_x - 1.2, _y - 1.4, 1.1, chc__rgb(90, 90, 96), 0.7);
            }
        }
    }
}

/// @function chc__paint_stands(c, P, g)
/// @description Internal. Grandstands: a cast shadow, tiered rows of seats packed with spectators (coloured specks), a
/// roof canopy over the back of the main stand with its support masts.
function chc__paint_stands(_c, _P, _g) {
    var _S = _c.layout.stands;
    var _crowd = [chc__rgb(230, 60, 50), chc__rgb(250, 220, 60), chc__rgb(240, 240, 236), chc__rgb(40, 90, 200), chc__rgb(30, 30, 34), chc__rgb(60, 170, 90), chc__rgb(246, 140, 40), chc__rgb(220, 180, 150), chc__rgb(150, 100, 70)];
    for (var _k = 0; _k < array_length(_S); _k++) {
        var _st = _S[_k];
        var _ca = cos(_st.ang), _sa = sin(_st.ang);
        // the stand rises AWAY from the track: rows step back and up, front row nearest the barrier
        var _qx = _c.nx[0] * 0 - _sa * _st.side, _qy = _ca * _st.side;
        chc__orect(_st.x + 12, _st.y + 14, _st.ang, _st.len, _st.dep, _P.shadow, 0.4);
        chc__orect(_st.x, _st.y, _st.ang, _st.len + 6, _st.dep + 6, chc__rgb(90, 94, 104), 1);
        var _rows = floor(_st.dep / 9);
        for (var _r = 0; _r < _rows; _r++) {
            var _v = (-_st.dep / 2 + (_r + 0.5) * (_st.dep / _rows));
            var _cx = _st.x + _qx * _v, _cy = _st.y + _qy * _v;
            var _seat = merge_colour(_P.seat, chc__shade(_P.seat, 1.3), _r / max(1, _rows - 1));
            chc__orect(_cx, _cy, _st.ang, _st.len, _st.dep / _rows - 2, _seat, 1);
            chc__orect(_cx - _qx * (_st.dep / _rows / 2 - 1), _cy - _qy * (_st.dep / _rows / 2 - 1), _st.ang, _st.len, 1.2, chc__rgb(20, 22, 28), 0.6);
        }
        chc__pts_begin();
        var _nP = floor(_st.len * _st.dep / 7);
        for (var _p = 0; _p < _nP; _p++) {
            var _u = chc_range(_g, -_st.len / 2 + 2, _st.len / 2 - 2), _v = chc_range(_g, -_st.dep / 2 + 2, _st.dep / 2 - 2);
            if (_st.roof && _v * 1 > _st.dep * 0.18) continue;
            var _col = _crowd[floor(chc_rand(_g) * array_length(_crowd))];
            var _x = _st.x + _ca * _u + _qx * _v, _y = _st.y + _sa * _u + _qy * _v;
            chc__pt(_x, _y, _col, 1); chc__pt(_x + 1, _y, _col, 1); chc__pt(_x, _y + 1, chc__shade(_col, 0.7), 1);
        }
        chc__pts_end();
        if (_st.roof) {
            var _v0 = _st.dep * 0.2, _v1 = _st.dep / 2 + 6;
            var _rx = _st.x + _qx * (_v0 + _v1) / 2, _ry = _st.y + _qy * (_v0 + _v1) / 2;
            chc__orect(_rx + 8, _ry + 10, _st.ang, _st.len + 10, _v1 - _v0, _P.shadow, 0.25);
            chc__orect(_rx, _ry, _st.ang, _st.len + 10, _v1 - _v0, _P.roof, 0.96);
            for (var _m = 0; _m <= 6; _m++) {
                var _u = (_m / 6 - 0.5) * (_st.len + 4);
                chc__orect(_rx + _ca * _u, _ry + _sa * _u, _st.ang + pi / 2, _v1 - _v0, 2, chc__shade(_P.roof, 0.82), 1);
            }
            chc__orect(_st.x + _qx * _v0, _st.y + _qy * _v0, _st.ang, _st.len + 10, 2, chc__shade(_P.roof, 1.12), 1);
        }
    }
}

/// @function chc__paint_trees(c, P)
/// @description Internal. Trees lit from the top left, each with a cast shadow: broadleaf (overlapping crown lobes, then
/// lit lobes and highlight dabs), pine (stacked stars, snow-tipped on snow), palm (fronds round a crown), cactus.
function chc__paint_trees(_c, _P) {
    var _T = _c.layout.trees;
    for (var _k = 0; _k < array_length(_T); _k++) {
        var _t = _T[_k], _r = _t.r, _x = _t.x, _y = _t.y;
        var _g = chc_rng(_t.seed);
        var _lf = merge_colour(_P.leaf, chc__shade(_P.leaf, 1.25), _t.tone * 0.6);
        var _lt = merge_colour(_P.leaf2, chc__shade(_P.leaf2, 1.15), _t.tone);
        chc__ellipse(_x + _r * 0.45, _y + _r * 0.55, _r * 1.02, _r * 0.86, 0.4, _P.shadow, 0.32);
        switch (_t.kind) {
            case "pine":
                for (var _layer = 0; _layer < 3; _layer++) {
                    var _rr = _r * (1 - _layer * 0.28), _xs = [_x - _layer * 0.6], _ys = [_y - _layer * 0.8];
                    var _pts = 9;
                    for (var _m = 0; _m <= _pts * 2; _m++) {
                        var _a = (_m / (_pts * 2)) * pi * 2 + _layer * 0.35, _q = (_m mod 2 == 0) ? _rr : _rr * 0.62;
                        array_push(_xs, _x - _layer * 0.6 + cos(_a) * _q); array_push(_ys, _y - _layer * 0.8 + sin(_a) * _q);
                    }
                    chc__poly(_xs, _ys, merge_colour(_lf, _lt, _layer / 2), 1);
                }
                if (_P.snow) {
                    for (var _m = 0; _m < 9; _m++) { var _a = (_m / 9) * pi * 2 + 0.2; chc__disc(_x + cos(_a) * _r * 0.62 - 1, _y + sin(_a) * _r * 0.62 - 1, _r * 0.14, chc__rgb(248, 250, 255), 0.95); }
                    chc__disc(_x - 1, _y - 1.5, _r * 0.18, chc__rgb(250, 252, 255), 1);
                }
                break;
            case "palm":
                chc__disc(_x, _y, _r * 0.16, chc__rgb(120, 90, 60), 1);
                var _fr = 8;
                for (var _m = 0; _m < _fr; _m++) {
                    var _a = (_m / _fr) * pi * 2 + chc_range(_g, -0.15, 0.15), _l = _r * chc_range(_g, 0.9, 1.15);
                    var _ex = cos(_a), _ey = sin(_a), _px = -_ey, _py = _ex;
                    var _col = ((_ex * -0.7 + _ey * -0.7) > 0) ? _lt : _lf;
                    chc__poly([_x, _x + _ex * _l * 0.5 + _px * _r * 0.16, _x + _ex * _l, _x + _ex * _l * 0.5 - _px * _r * 0.16], [_y, _y + _ey * _l * 0.5 + _py * _r * 0.16, _y + _ey * _l, _y + _ey * _l * 0.5 - _py * _r * 0.16], _col, 1);
                    draw_set_colour(chc__shade(_lf, 0.7)); draw_set_alpha(0.7);
                    draw_line_width(_x, _y, _x + _ex * _l * 0.92, _y + _ey * _l * 0.92, 1);
                    draw_set_alpha(1);
                }
                chc__disc(_x, _y, _r * 0.18, chc__shade(_lf, 0.8), 1);
                break;
            case "cactus":
                var _cr = _r * 0.42;
                chc__disc(_x, _y, _cr, chc__rgb(70, 128, 72), 1);
                chc__disc(_x - _cr * 0.25, _y - _cr * 0.25, _cr * 0.6, chc__rgb(104, 160, 92), 1);
                for (var _m = 0; _m < 2; _m++) { var _a = chc_range(_g, 0, pi * 2); chc__disc(_x + cos(_a) * _cr * 1.5, _y + sin(_a) * _cr * 1.5, _cr * 0.5, chc__rgb(80, 138, 78), 1); }
                for (var _m = 0; _m < 8; _m++) { var _a = (_m / 8) * pi * 2; draw_set_colour(chc__rgb(46, 92, 52)); draw_line_width(_x, _y, _x + cos(_a) * _cr, _y + sin(_a) * _cr, 1); }
                break;
            default:
                // broadleaf: dark crown lobes, lit lobes toward the lamp (top left), highlight dabs
                for (var _m = 0; _m < 7; _m++) { var _a = (_m / 7) * pi * 2 + _t.tone * 3, _q = _r * 0.52; chc__disc(_x + cos(_a) * _q, _y + sin(_a) * _q, _r * chc_range(_g, 0.48, 0.62), _lf, 1); }
                chc__disc(_x, _y, _r * 0.7, _lf, 1);
                for (var _m = 0; _m < 5; _m++) { var _a = pi * 1.25 + chc_range(_g, -0.9, 0.9), _q = _r * chc_range(_g, 0.15, 0.5); chc__disc(_x + cos(_a) * _q, _y + sin(_a) * _q, _r * chc_range(_g, 0.28, 0.42), _lt, 1); }
                for (var _m = 0; _m < 4; _m++) { var _a = pi * 1.25 + chc_range(_g, -0.6, 0.6), _q = _r * chc_range(_g, 0.3, 0.6); chc__disc(_x + cos(_a) * _q, _y + sin(_a) * _q, _r * 0.12, chc__shade(_lt, 1.25), 0.9); }
                break;
        }
    }
}

/// @function chc__paint_props(c, P, g)
/// @description Internal. Marshal posts (an orange cabin, a flag), street lamps with their light pools at night, rocks.
function chc__paint_props(_c, _P, _g) {
    var _L = _c.layout;
    for (var _k = 0; _k < array_length(_L.rocks); _k++) {
        // a fan from the CENTRE (the outline is only star-shaped about it, wing s3)
        var _rk = _L.rocks[_k], _gg = chc_rng(_rk.seed), _xs = [_rk.x], _ys = [_rk.y];
        for (var _m = 0; _m < 7; _m++) { var _a = (_m / 7) * pi * 2, _q = _rk.r * chc_range(_gg, 0.7, 1.05); array_push(_xs, _rk.x + cos(_a) * _q); array_push(_ys, _rk.y + sin(_a) * _q * 0.8); }
        array_push(_xs, _xs[1]); array_push(_ys, _ys[1]);
        var _sx = [], _sy = [];
        for (var _m = 0; _m < array_length(_xs); _m++) { array_push(_sx, _xs[_m] + 3); array_push(_sy, _ys[_m] + 4); }
        chc__poly(_sx, _sy, _P.shadow, 0.35);
        chc__poly(_xs, _ys, chc__rgb(150, 112, 80), 1);
        chc__ellipse(_rk.x - _rk.r * 0.25, _rk.y - _rk.r * 0.25, _rk.r * 0.5, _rk.r * 0.32, -0.6, chc__rgb(196, 158, 118), 1);
    }
    for (var _k = 0; _k < array_length(_L.posts); _k++) {
        var _p = _L.posts[_k];
        chc__orect(_p.x + 3, _p.y + 4, _p.ang, 12, 10, _P.shadow, 0.35);
        chc__orect(_p.x, _p.y, _p.ang, 12, 10, chc__rgb(236, 120, 30), 1);
        chc__orect(_p.x, _p.y, _p.ang, 8, 6, chc__rgb(246, 246, 240), 1);
        chc__disc(_p.x + cos(_p.ang) * 7, _p.y + sin(_p.ang) * 7, 2, chc__rgb(250, 214, 40), 1);
    }
    if (array_length(_L.lamps) == 0) return;
    if (_P.night) {
        gpu_set_blendmode(bm_add);
        for (var _k = 0; _k < array_length(_L.lamps); _k++) {
            var _lp = _L.lamps[_k], _i = _lp.i;
            var _rx = _c.px[_i] + _c.nx[_i] * _lp.side * (_c.hw * 0.35), _ry = _c.py[_i] + _c.ny[_i] * _lp.side * (_c.hw * 0.35);
            chc__glow(lerp(_lp.x, _rx, 0.6), lerp(_lp.y, _ry, 0.6), _c.hw * 1.5, chc__rgb(255, 196, 120), 0.42);
            chc__glow(_lp.x, _lp.y, 10, chc__rgb(255, 230, 190), 0.8);
        }
        chc__over();
    }
    for (var _k = 0; _k < array_length(_L.lamps); _k++) {
        var _lp = _L.lamps[_k], _i = _lp.i;
        var _hx = _lp.x - _c.nx[_i] * _lp.side * 14, _hy = _lp.y - _c.ny[_i] * _lp.side * 14;
        draw_set_colour(_P.shadow); draw_set_alpha(0.35); draw_line_width(_lp.x + 3, _lp.y + 4, _hx + 3, _hy + 4, 2);
        draw_set_alpha(1); draw_set_colour(chc__rgb(70, 74, 84)); draw_line_width(_lp.x, _lp.y, _hx, _hy, 2);
        chc__disc(_lp.x, _lp.y, 2.4, chc__rgb(60, 62, 70), 1);
        chc__orect(_hx, _hy, arctan2(_c.ty[_i], _c.tx[_i]), 6, 4, _P.night ? chc__rgb(255, 236, 190) : chc__rgb(200, 204, 210), 1);
    }
}

// ------------------------------------------------------------------------------------------------ the camera

/// @function chc_camera_create(x, y, zoom, w, h, [sx], [sy])
/// @description A view onto the circuit: centred on room point (x, y), `zoom` screen pixels per room pixel, drawing a
/// w x h window whose top-left is (sx, sy) on the current target (GUI or room space - your choice).
function chc_camera_create(_x, _y, _zoom, _w, _h, _sx = 0, _sy = 0) {
    return { x: is_numeric(_x) ? _x : 0, y: is_numeric(_y) ? _y : 0, zoom: is_numeric(_zoom) ? clamp(_zoom, 0.05, 8) : 1,
             w: is_numeric(_w) ? max(1, _w) : 960, h: is_numeric(_h) ? max(1, _h) : 640, sx: is_numeric(_sx) ? _sx : 0, sy: is_numeric(_sy) ? _sy : 0 };
}

/// @function chc_camera_follow(camera, car, dt, [circuit])
/// @description Ease the camera toward a point a little ahead of the car (in its direction of travel), kept inside the
/// circuit's world when one is given.
function chc_camera_follow(_cam, _car, _dt, _c = undefined) {
    if (!is_struct(_cam) || !is_struct(_car)) return;
    if (!is_numeric(_dt)) _dt = 1 / 60;
    var _tx = _car.x + _car.vx * 0.32, _ty = _car.y + _car.vy * 0.32;
    var _f = 1 - exp(-_dt * 4);
    _cam.x += (_tx - _cam.x) * _f; _cam.y += (_ty - _cam.y) * _f;
    if (is_struct(_c) && variable_struct_exists(_c, "worldW")) {
        var _hw = _cam.w / (2 * _cam.zoom), _hh = _cam.h / (2 * _cam.zoom);
        _cam.x = (_c.worldW > _hw * 2) ? clamp(_cam.x, _hw, _c.worldW - _hw) : _c.worldW / 2;
        _cam.y = (_c.worldH > _hh * 2) ? clamp(_cam.y, _hh, _c.worldH - _hh) : _c.worldH / 2;
    }
}

/// @function chc__cam_xy(cam, x, y)
/// @description Internal. Room point -> target pixel, into global.chc_cx / global.chc_cy.
function chc__cam_xy(_cam, _x, _y) {
    global.chc_cx = _cam.sx + (_x - _cam.x) * _cam.zoom + _cam.w / 2;
    global.chc_cy = _cam.sy + (_y - _cam.y) * _cam.zoom + _cam.h / 2;
}

/// @function chc_circuit_draw(circuit, camera)
/// @description Draw the baked circuit through a camera (bakes it first if it has no sprite). Only the visible part of
/// the sprite is drawn.
function chc_circuit_draw(_c, _cam) {
    if (!is_struct(_c) || !is_struct(_cam)) return;
    if (!variable_struct_exists(_c, "sprite") || !sprite_exists(_c.sprite)) chc_circuit_bake(_c, 1);
    var _k = _c.bakeScale;
    var _vw = _cam.w / _cam.zoom, _vh = _cam.h / _cam.zoom;
    var _l = _cam.x - _vw / 2, _t = _cam.y - _vh / 2;
    var _l2 = max(0, _l), _t2 = max(0, _t), _r2 = min(_c.worldW, _l + _vw), _b2 = min(_c.worldH, _t + _vh);
    if (_r2 <= _l2 || _b2 <= _t2) return;
    var _tf = gpu_get_texfilter();
    gpu_set_texfilter(true);
    draw_sprite_part_ext(_c.sprite, 0, _l2 * _k, _t2 * _k, (_r2 - _l2) * _k, (_b2 - _t2) * _k,
        _cam.sx + (_l2 - _l) * _cam.zoom, _cam.sy + (_t2 - _t) * _cam.zoom, _cam.zoom / _k, _cam.zoom / _k, c_white, 1);
    gpu_set_texfilter(_tf);
}

// ------------------------------------------------------------------------------------------------ cars

/// @function chc__car_cache()
/// @description Internal. The shared car-sprite cache (one sprite per body x livery x size).
function chc__car_cache() { if (!variable_global_exists("chc_cars") || !is_struct(global.chc_cars)) global.chc_cars = {}; return global.chc_cars; }

/// @function chc_car_sprite(body, livery, [scale])
/// @description A car drawn from primitives, top-down, nose toward +x, baked at 2x and kept in a cache; origin at the
/// car's centre. Bodies: "formula" (open wheels, wings, halo, helmet, a number roundel), "kart" (tubular frame, side pods,
/// driver, a number plate), "rally" (hatchback, roof vent, number roundel, mud flaps, lamp pods), "saloon" (bonnet with a
/// number panel, screens, boot, spoiler).
/// @param {String} body  one of chc_bodies()
/// @param {Struct} livery  from chc_livery_create
/// @param {Real} [scale]  sprite pixels per car pixel (1, up to 6)
/// @returns {Asset.GMSprite} draw it with chc_car_draw (it is premultiplied)
function chc_car_sprite(_body, _liv, _scale = 1) {
    var _B = chc_body(_body);
    if (!is_struct(_liv) || !variable_struct_exists(_liv, "primary")) _liv = chc_livery_create(1);
    if (!is_numeric(_scale)) _scale = 1;
    _scale = clamp(_scale, 0.25, 6);
    var _key = _B.name + "_" + string(_liv.seed) + "_" + string(_liv.primary) + "_" + string(_liv.pattern) + "_" + string(floor(_scale * 100));
    var _cache = chc__car_cache();
    if (variable_struct_exists(_cache, _key) && sprite_exists(_cache[$ _key])) return _cache[$ _key];
    var _ss = _scale * 2;
    var _w = ceil((_B.len + 10) * _ss), _h = ceil((_B.wid + 10) * _ss);
    var _mw = matrix_get(matrix_world);
    var _surf = surface_create(_w, _h);
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 0);
    gpu_push_state();
    gpu_set_ztestenable(false); gpu_set_zwriteenable(false);
    chc__over();
    matrix_set(matrix_world, matrix_build(_w / 2, _h / 2, 0, 0, 0, 0, _ss, _ss, 1));
    chc__draw_body(_B, _liv);
    gpu_pop_state();
    matrix_set(matrix_world, _mw);
    surface_reset_target();
    var _spr = sprite_create_from_surface(_surf, 0, 0, _w, _h, false, false, _w / 2, _h / 2);
    surface_free(_surf);
    _cache[$ _key] = _spr;
    return _spr;
}

/// @function chc__rr(x0, y0, x1, y1, r, col, alpha)
/// @description Internal. A filled rounded rectangle in car space.
function chc__rr(_x0, _y0, _x1, _y1, _r, _col, _al) {
    _r = min(_r, (_x1 - _x0) / 2, (_y1 - _y0) / 2);
    var _xs = [], _ys = [];
    var _cx = [_x1 - _r, _x0 + _r, _x0 + _r, _x1 - _r], _cy = [_y0 + _r, _y0 + _r, _y1 - _r, _y1 - _r];
    array_push(_xs, (_x0 + _x1) / 2); array_push(_ys, (_y0 + _y1) / 2);
    for (var _q = 0; _q < 4; _q++) for (var _m = 0; _m <= 4; _m++) {
        var _a = -pi / 2 * _q - (_m / 4) * pi / 2;
        array_push(_xs, _cx[_q] + cos(_a) * _r); array_push(_ys, _cy[_q] + sin(_a) * _r);
    }
    array_push(_xs, _xs[1]); array_push(_ys, _ys[1]);
    chc__poly(_xs, _ys, _col, _al);
}

/// @function chc__pattern(B, liv, x0, x1, hw)
/// @description Internal. The livery pattern over the body's area, clipped to what is already painted ("source atop": the
/// pattern lands only where the body is).
function chc__pattern(_B, _liv, _x0, _x1, _hw) {
    gpu_set_blendmode_ext_sepalpha(bm_dest_alpha, bm_inv_src_alpha, bm_zero, bm_one);
    var _s = _liv.secondary, _a = _liv.accent;
    // every shape stays inside +-hw: the source-atop blend paints wherever anything is already opaque, wheels included
    switch (_liv.pattern) {
        case 1: chc__rr(_x0, -_hw * 0.42, _x1, -_hw * 0.18, 0.1, _s, 1); chc__rr(_x0, _hw * 0.18, _x1, _hw * 0.42, 0.1, _s, 1); break;
        case 2: chc__rr(_x0, -_hw, _x1, -_hw * 0.55, 0.1, _s, 1); chc__rr(_x0, _hw * 0.55, _x1, _hw, 0.1, _s, 1); break;
        case 3:
            for (var _k = 0; _k < 3; _k++) { var _o = _x1 - 3 - _k * 5; chc__poly([_o, _o - 3, _o - 7, _o - 4], [0, -_hw, -_hw, 0], _s, 1); chc__poly([_o, _o - 4, _o - 7, _o - 3], [0, 0, _hw, _hw], _s, 1); }
            break;
        case 4: chc__rr((_x0 + _x1) / 2, -_hw, _x1, _hw, 0.1, _s, 1); break;
        case 5: chc__poly([_x0 + (_x1 - _x0) * 0.35, _x0 + (_x1 - _x0) * 0.55, _x0 + (_x1 - _x0) * 0.75, _x0 + (_x1 - _x0) * 0.55], [-_hw, -_hw, _hw, _hw], _s, 1); break;
        default: chc__rr(_x1 - 6, -_hw, _x1, _hw, 0.1, _a, 1); break;
    }
    // the centreline highlight: the body is lit from above, brightest along its spine. This blend does NOT multiply the
    // colour by its alpha (dest alpha is the source factor), so the colour is premultiplied here: white at 0.22 is grey 56
    // at 0.22. Unpremultiplied it read as an opaque white stripe through every car and its number (store bake 2026-10-24).
    chc__rr(_x0 + 2, -0.7, _x1 - 2, 0.7, 0.1, chc__rgb(56, 56, 56), 0.22);
    chc__over();
}

/// @function chc__draw_body(B, liv)
/// @description Internal. One car body in car space (nose +x, 1 unit = 1 car pixel).
function chc__draw_body(_B, _liv) {
    var _L = _B.len, _W = _B.wid, _hl = _L / 2, _hw = _W / 2;
    var _p = _liv.primary, _dark = chc__rgb(22, 22, 26), _tyre = chc__rgb(30, 30, 34), _glass = chc__rgb(34, 52, 74);
    switch (_B.name) {
        case "formula":
            // the floor, the body (a convex tub and a separate pointed nose), its livery, THEN the wheels beside it, wings,
            // cockpit, helmet, halo (the pattern is clipped to what is painted, so it must go on before the wheels)
            chc__rr(-_hl + 1, -_hw * 0.32, _hl - 4, _hw * 0.32, 1.5, chc__shade(_p, 0.55), 1);
            chc__poly([_hl - 9, -_hl * 0.1, -_hl + 6, -_hl + 3, -_hl + 6, -_hl * 0.1, _hl - 9], [-1.6, -_hw * 0.58, -_hw * 0.36, 0, _hw * 0.36, _hw * 0.58, 1.6], _p, 1);
            chc__poly([_hl, _hl - 9, _hl - 9], [0, -1.6, 1.6], _p, 1);
            chc__pattern(_B, _liv, -_hl + 3, _hl, _hw * 0.6);
            chc__rr(-_hl + 3, -_hw, -_hl + 10, -_hw + 4.6, 1.2, _tyre, 1); chc__rr(-_hl + 3, _hw - 4.6, -_hl + 10, _hw, 1.2, _tyre, 1);
            chc__rr(_hl - 11, -_hw + 0.5, _hl - 6, -_hw + 4.2, 1.1, _tyre, 1); chc__rr(_hl - 11, _hw - 4.2, _hl - 6, _hw - 0.5, 1.1, _tyre, 1);
            chc__rr(-_hl + 4, -_hw + 0.6, -_hl + 9, -_hw + 1.4, 0.3, chc__rgb(70, 70, 76), 1); chc__rr(-_hl + 4, _hw - 1.4, -_hl + 9, _hw - 0.6, 0.3, chc__rgb(70, 70, 76), 1);
            chc__rr(-_hl, -_hw + 0.5, -_hl + 3.4, _hw - 0.5, 0.6, _liv.secondary, 1);
            chc__rr(-_hl, -_hw + 0.5, -_hl + 1, _hw - 0.5, 0.3, chc__shade(_liv.secondary, 0.6), 1);
            chc__rr(_hl - 3.2, -_hw + 0.3, _hl - 0.6, _hw - 0.3, 0.6, _liv.secondary, 1);
            chc__rr(_hl - 3.2, -_hw + 0.3, _hl - 0.6, -_hw + 1.6, 0.3, chc__shade(_liv.secondary, 0.65), 1);
            chc__rr(_hl - 3.2, _hw - 1.6, _hl - 0.6, _hw - 0.3, 0.3, chc__shade(_liv.secondary, 0.65), 1);
            chc__rr(-2.5, -2.3, 4.2, 2.3, 1.8, _dark, 1);
            chc__disc(0.6, 0, 2.2, _liv.helmet, 1);
            chc__rr(1.6, -1.3, 2.7, 1.3, 0.4, chc__rgb(20, 24, 30), 1);
            chc__disc(0.1, -0.7, 0.8, c_white, 0.35);
            draw_set_colour(chc__rgb(40, 42, 48)); draw_set_alpha(1);
            draw_line_width(4.6, 0, -2.8, -2.2, 0.7); draw_line_width(4.6, 0, -2.8, 2.2, 0.7);
            break;
        case "kart":
            // pods and nose fairing with their livery first, then the wheels and the tubular frame round them
            chc__rr(-_hl + 6.5, -_hw + 0.4, _hl - 8, -_hw + 3.0, 1.2, _p, 1); chc__rr(-_hl + 6.5, _hw - 3.0, _hl - 8, _hw - 0.4, 1.2, _p, 1);
            chc__rr(_hl - 4, -_hw * 0.62, _hl, _hw * 0.62, 1.5, _p, 1);
            chc__pattern(_B, _liv, -_hl + 6, _hl, _hw);
            chc__rr(-_hl + 1, -_hw, -_hl + 6, -_hw + 3.6, 1, _tyre, 1); chc__rr(-_hl + 1, _hw - 3.6, -_hl + 6, _hw, 1, _tyre, 1);
            chc__rr(_hl - 7, -_hw + 0.6, _hl - 3, -_hw + 3.4, 0.9, _tyre, 1); chc__rr(_hl - 7, _hw - 3.4, _hl - 3, _hw - 0.6, 0.9, _tyre, 1);
            draw_set_colour(chc__rgb(150, 154, 160)); draw_set_alpha(1);
            draw_line_width(-_hl + 3, -_hw + 3.4, _hl - 4, -_hw + 3.4, 0.7); draw_line_width(-_hl + 3, _hw - 3.4, _hl - 4, _hw - 3.4, 0.7);
            chc__rr(-_hl, -_hw * 0.6, -_hl + 1.6, _hw * 0.6, 0.6, _dark, 1);
            chc__ellipse(-1.4, 0, 3.6, 3.4, 0, _liv.secondary, 1);
            chc__disc(-0.4, 0, 2.3, _liv.helmet, 1);
            chc__rr(0.8, -1.2, 1.8, 1.2, 0.3, chc__rgb(20, 24, 30), 1);
            break;
        case "rally":
        case "saloon":
            var _sal = (_B.name == "saloon");
            chc__rr(-_hl + 4, -_hw - 0.6, -_hl + 9, _hw + 0.6, 1, _tyre, 1);
            chc__rr(_hl - 10, -_hw - 0.6, _hl - 5, _hw + 0.6, 1, _tyre, 1);
            chc__rr(-_hl, -_hw, _hl, _hw, _sal ? 3 : 3.6, _p, 1);
            chc__pattern(_B, _liv, -_hl, _hl, _hw);
            // the glasshouse: windscreen, roof, rear screen; lit from above so the roof is the brightest panel
            var _ws0 = _sal ? 3 : 2, _ws1 = _sal ? 7.5 : 6.5, _rs0 = _sal ? -10 : -7, _rs1 = _sal ? -7 : -4.6;
            chc__poly([_ws1, _ws1, _ws0, _ws0], [-_hw + 2.2, _hw - 2.2, _hw - 1.2, -_hw + 1.2], _glass, 1);
            chc__rr(_rs1, -_hw + 1.4, _ws0, _hw - 1.4, 1, chc__shade(_p, 1.08), 1);
            chc__poly([_rs0, _rs1, _rs1, _rs0], [-_hw + 2.4, -_hw + 1.4, _hw - 1.4, _hw - 2.4], _glass, 1);
            chc__rr(_ws1, -_hw + 1.6, _ws1 + 0.8, _hw - 1.6, 0.3, c_white, 0.25);
            if (_sal) {
                chc__rr(-_hl, -_hw + 0.6, -_hl + 1.8, _hw - 0.6, 0.6, chc__shade(_liv.secondary, 0.8), 1);
            } else {
                // the roof vent at the front of the roof (the number roundel takes the middle; drawn after the switch)
                chc__rr(0.9, -1.1, 1.9, 1.1, 0.3, chc__rgb(40, 40, 44), 1);
                chc__rr(_hl - 1.4, -_hw + 1.4, _hl - 0.2, -_hw + 4.4, 0.5, chc__rgb(255, 230, 120), 1);
                chc__rr(_hl - 1.4, _hw - 4.4, _hl - 0.2, _hw - 1.4, 0.5, chc__rgb(255, 230, 120), 1);
                chc__rr(-_hl - 0.4, -_hw + 0.6, -_hl + 0.8, -_hw + 3.4, 0.3, _dark, 1);
                chc__rr(-_hl - 0.4, _hw - 3.4, -_hl + 0.8, _hw - 0.6, 0.3, _dark, 1);
            }
            chc__rr(_ws0 - 1, -_hw - 1.2, _ws0 + 0.6, -_hw + 0.2, 0.4, chc__shade(_p, 0.7), 1);
            chc__rr(_ws0 - 1, _hw - 0.2, _ws0 + 0.6, _hw + 1.2, 0.4, chc__shade(_p, 0.7), 1);
            break;
    }
    // the race number, dark on a white panel sized to the digits (a dark rim keeps it off a white car): a roundel on the
    // engine cover of a formula car and the roof of a rally car, a plate on the nose of a kart and the bonnet of a saloon.
    // Bare digits read through the livery's stripes and off the edge of a formula nose (store bake 2026-10-24).
    var _nx = 0, _ns = 0.06, _round = true;
    switch (_B.name) {
        case "formula": _nx = -6.5; _ns = 0.055; break;
        case "kart": _nx = _hl - 2.4; _ns = 0.05; _round = false; break;
        case "rally": _nx = -1.6; _ns = 0.062; break;
        case "saloon": _nx = _hl - 4.8; _ns = 0.085; _round = false; break;
    }
    var _str = string(_liv.number);
    draw_set_font(fnt_chicane_display_l);
    // the digits of the shipped display face stand 0.485 of its line height tall, centred 0.058 of it below the line box's
    // middle; the text is turned so its top faces the nose (+x), so "below" is -x here
    var _lh = string_height("0");
    var _tw = string_width(_str) * _ns, _th = _lh * 0.485 * _ns;
    var _rim = chc__rgb(24, 24, 28), _panel = chc__rgb(244, 242, 236);
    if (_round) {
        var _r = max(_tw, _th) / 2 + 0.6;
        chc__disc(_nx, 0, _r + 0.35, _rim, 1, 40);
        chc__disc(_nx, 0, _r, _panel, 1, 40);
    } else {
        var _hx = _th / 2 + 0.6, _hy = max(_tw, _th) / 2 + 0.65;
        chc__rr(_nx - _hx - 0.35, -_hy - 0.35, _nx + _hx + 0.35, _hy + 0.35, 0.9, _rim, 1);
        chc__rr(_nx - _hx, -_hy, _nx + _hx, _hy, 0.7, _panel, 1);
    }
    draw_set_halign(fa_center); draw_set_valign(fa_middle);
    var _tf = gpu_get_texfilter();
    gpu_set_texfilter(true);
    draw_set_colour(chc__rgb(20, 20, 24)); draw_set_alpha(1);
    draw_text_transformed(_nx + _lh * 0.058 * _ns, 0, _str, _ns, _ns, -90);
    gpu_set_texfilter(_tf);
    draw_set_halign(fa_left); draw_set_valign(fa_top);
}

/// @function chc_car_draw(body, livery, x, y, ang, [scale], [alpha], [shadow])
/// @description Draw one car at (x, y) facing ang (radians, room space), `scale` screen pixels per car pixel, with its
/// shadow cast down-right. Uses the cached sprite (premultiplied, drawn with bm_one / bm_inv_src_alpha).
function chc_car_draw(_body, _liv, _x, _y, _ang, _scale = 1, _alpha = 1, _shadow = true) {
    if (!is_numeric(_x) || !is_numeric(_y) || !is_numeric(_ang)) return;
    if (!is_numeric(_scale)) _scale = 1;
    if (!is_numeric(_alpha)) _alpha = 1;
    var _q = clamp(_scale, 0.25, 6);
    var _spr = chc_car_sprite(_body, _liv, max(1, ceil(_q)));
    var _k = _q / (max(1, ceil(_q)) * 2);
    gpu_push_state();
    var _tf = gpu_get_texfilter();
    gpu_set_texfilter(true);
    if (_shadow) {
        gpu_set_blendmode_ext(bm_zero, bm_inv_src_alpha);
        draw_sprite_ext(_spr, 0, _x + 2.6 * _q, _y + 3.4 * _q, _k * 1.04, _k * 1.08, -radtodeg(_ang), c_white, 0.42 * _alpha);
    }
    // premultiplied: the colour carries the alpha too (c_white * alpha), or a faded car draws too bright
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    var _a255 = clamp(_alpha, 0, 1) * 255;
    draw_sprite_ext(_spr, 0, _x, _y, _k, _k, -radtodeg(_ang), make_colour_rgb(_a255, _a255, _a255), _alpha);
    gpu_set_texfilter(_tf);
    gpu_pop_state();
}

/// @function chc_race_draw(race, camera)
/// @description Draw the race through a camera: the skid marks laid so far (a world-sized surface that grows as cars
/// slide and brake; recreated empty if the GPU loses it), then every car (or the buyer's own sprite where car.sprite is
/// set, drawn at image_angle -radtodeg(car.ang)). Call after chc_circuit_draw with the same camera.
function chc_race_draw(_r, _cam) {
    if (!is_struct(_r) || !is_struct(_cam) || !variable_struct_exists(_r, "cars")) return;
    var _c = _r.c;
    if (!variable_struct_exists(_r, "skid") || !surface_exists(_r.skid)) {
        _r.skid = surface_create(max(16, floor(_c.worldW / 2)), max(16, floor(_c.worldH / 2)));
        surface_set_target(_r.skid); draw_clear_alpha(c_black, 0); surface_reset_target();
    }
    var _marks = [];
    for (var _k = 0; _k < array_length(_r.cars); _k++) { var _car = _r.cars[_k]; if (_car.skidOn && _car.lx != 0) array_push(_marks, _car); }
    if (array_length(_marks) > 0) {
        var _mw = matrix_get(matrix_world);
        surface_set_target(_r.skid);
        gpu_push_state(); chc__over();
        matrix_set(matrix_world, matrix_build(0, 0, 0, 0, 0, 0, 0.5, 0.5, 1));
        var _dirt = (_c.T.road != "asphalt");
        draw_set_colour(_dirt ? chc__rgb(90, 60, 36) : chc__rgb(10, 10, 12));
        for (var _m = 0; _m < array_length(_marks); _m++) {
            var _car = _marks[_m];
            var _px = -sin(_car.ang) * _car.B.wid * 0.36, _py = cos(_car.ang) * _car.B.wid * 0.36;
            draw_set_alpha(_dirt ? 0.12 : 0.16);
            draw_line_width(_car.lx + _px, _car.ly + _py, _car.rx + _px, _car.ry + _py, 3);
            draw_line_width(_car.lx - _px, _car.ly - _py, _car.rx - _px, _car.ry - _py, 3);
        }
        draw_set_alpha(1);
        gpu_pop_state();
        matrix_set(matrix_world, _mw);
        surface_reset_target();
    }
    var _vw = _cam.w / _cam.zoom, _vh = _cam.h / _cam.zoom;
    var _l = _cam.x - _vw / 2, _t = _cam.y - _vh / 2;
    gpu_push_state();
    gpu_set_blendmode_ext(bm_one, bm_inv_src_alpha);
    var _tf = gpu_get_texfilter(); gpu_set_texfilter(true);
    var _l2 = max(0, _l), _t2 = max(0, _t), _r2 = min(_c.worldW, _l + _vw), _b2 = min(_c.worldH, _t + _vh);
    if (_r2 > _l2 && _b2 > _t2) draw_surface_part_ext(_r.skid, _l2 / 2, _t2 / 2, (_r2 - _l2) / 2, (_b2 - _t2) / 2, _cam.sx + (_l2 - _l) * _cam.zoom, _cam.sy + (_t2 - _t) * _cam.zoom, _cam.zoom * 2, _cam.zoom * 2, c_white, 1);
    gpu_set_texfilter(_tf);
    gpu_pop_state();
    for (var _k = 0; _k < array_length(_r.cars); _k++) {
        var _car = _r.cars[_k];
        chc__cam_xy(_cam, _car.x, _car.y);
        var _x = global.chc_cx, _y = global.chc_cy;
        if (_x < _cam.sx - 60 || _y < _cam.sy - 60 || _x > _cam.sx + _cam.w + 60 || _y > _cam.sy + _cam.h + 60) continue;
        if (is_numeric(_car.sprite) && _car.sprite >= 0 && sprite_exists(_car.sprite)) draw_sprite_ext(_car.sprite, 0, _x, _y, _cam.zoom, _cam.zoom, -radtodeg(_car.ang), c_white, 1);
        else chc_car_draw(_car.body, _car.livery, _x, _y, _car.ang, _cam.zoom);
    }
}

// ------------------------------------------------------------------------------------------------ the HUD

/// @function chc__fmt(t)
/// @description Internal. Seconds as M:SS.mmm (or SS.mmm under a minute); "--" for none.
function chc__fmt(_t) {
    if (!is_numeric(_t) || _t < 0) return "--.---";
    var _m = floor(_t / 60), _s = _t - _m * 60;
    var _ss = string_format(_s, 2, 3);
    _ss = string_replace_all(_ss, " ", "0");
    if (_m > 0) return string(_m) + ":" + _ss;
    return string_trim(string_format(_s, 1, 3));
}

/// @function chc__text(x, y, str, font, scale, col, alpha, [halign])
/// @description Internal. Text through a filtered, restored texture state (a font drawn below 1.0 with point sampling loses
/// its 1 px strokes, wing s3).
function chc__text(_x, _y, _s, _font, _sc, _col, _al, _ha = fa_left) {
    draw_set_font(_font); draw_set_halign(_ha); draw_set_valign(fa_middle);
    var _tf = gpu_get_texfilter(); gpu_set_texfilter(true);
    draw_set_colour(_col); draw_set_alpha(_al);
    draw_text_transformed(_x, _y, _s, _sc, _sc, 0);
    gpu_set_texfilter(_tf);
    draw_set_alpha(1); draw_set_halign(fa_left); draw_set_valign(fa_top);
}

/// @function chc__panel(x0, y0, x1, y1, alpha)
/// @description Internal. A HUD panel: a slanted dark plate with a lit top edge.
function chc__panel(_x0, _y0, _x1, _y1, _al) {
    var _sl = min(14, (_y1 - _y0) * 0.35);
    chc__quad(_x0, _y0, _x1, _y0, _x1 - _sl, _y1, _x0, _y1, chc__rgb(12, 14, 20), 0.82 * _al);
    chc__quad(_x0, _y0, _x1, _y0, _x1 - 0.5, _y0 + 2, _x0, _y0 + 2, chc__rgb(230, 40, 50), _al);
}

/// @function chc_tower_draw(race, x, y, [rows], [player], [scale])
/// @description The position tower: LAP n/N above P1..Pn rows - a position box, the car's colour chip, its driver code and
/// its gap to the leader (the fastest-lap holder marked in purple, a car owing a gate marked CUT, a finisher FIN).
function chc_tower_draw(_r, _x, _y, _rows = 8, _player = -1, _sc = 1) {
    if (!is_struct(_r) || !variable_struct_exists(_r, "order")) return 0;
    if (!is_numeric(_rows)) _rows = 8;
    if (!is_numeric(_sc)) _sc = 1;
    var _n = min(_rows, array_length(_r.order)), _rh = 22 * _sc, _w = 172 * _sc;
    var _lead = _r.cars[_r.order[0]];
    chc__panel(_x, _y, _x + _w, _y + 30 * _sc, 1);
    var _lap = clamp(_lead.lap, 1, _r.laps);
    if (_lead.finished) chc__text(_x + 10 * _sc, _y + 16 * _sc, "FINISH", fnt_chicane_display_s, 0.62 * _sc, c_white, 1);
    else chc__text(_x + 10 * _sc, _y + 16 * _sc, "LAP " + string(_lap) + " / " + string(_r.laps), fnt_chicane_display_s, 0.62 * _sc, c_white, 1);
    for (var _p = 0; _p < _n; _p++) {
        var _car = _r.cars[_r.order[_p]];
        var _yy = _y + 34 * _sc + _p * _rh;
        var _me = (_car.id == _player);
        chc__quad(_x, _yy, _x + _w, _yy, _x + _w, _yy + _rh - 2 * _sc, _x, _yy + _rh - 2 * _sc, _me ? chc__rgb(40, 44, 62) : chc__rgb(14, 16, 22), 0.82);
        chc__quad(_x, _yy, _x + 24 * _sc, _yy, _x + 24 * _sc, _yy + _rh - 2 * _sc, _x, _yy + _rh - 2 * _sc, (_p == 0) ? chc__rgb(250, 210, 40) : chc__rgb(236, 236, 232), 1);
        chc__text(_x + 12 * _sc, _yy + _rh / 2 - 1, string(_p + 1), fnt_chicane_display_s, 0.48 * _sc, chc__rgb(16, 16, 20), 1, fa_center);
        chc__quad(_x + 28 * _sc, _yy + 3 * _sc, _x + 32 * _sc, _yy + 3 * _sc, _x + 32 * _sc, _yy + _rh - 5 * _sc, _x + 28 * _sc, _yy + _rh - 5 * _sc, _car.livery.primary, 1);
        chc__text(_x + 38 * _sc, _yy + _rh / 2 - 1, _car.code, fnt_chicane_body_s, 0.62 * _sc, c_white, 1);
        var _gap = "", _gc = chc__rgb(200, 204, 212);
        if (_car.finished) { _gap = "FIN"; _gc = chc__rgb(250, 210, 40); }
        else if (_car.missedGate >= 0) { _gap = "CUT"; _gc = chc__rgb(255, 90, 80); }
        else if (_p == 0) _gap = "LEADER";
        else { var _gp = chc_race_gap(_r, _car.id); _gap = (_gp < 0) ? "--" : ("+" + string_format(_gp, 1, 3)); }
        chc__text(_x + _w - 8 * _sc, _yy + _rh / 2 - 1, _gap, fnt_chicane_body_s, 0.56 * _sc, _gc, 1, fa_right);
        if (_r.bestLapCar == _car.id) chc__quad(_x + _w - 3 * _sc, _yy, _x + _w, _yy, _x + _w, _yy + _rh - 2 * _sc, _x + _w - 3 * _sc, _yy + _rh - 2 * _sc, chc__rgb(170, 60, 230), 1);
    }
    return _y + 34 * _sc + _n * _rh;
}

/// @function chc_timing_draw(race, car, x, y, [scale])
/// @description A car's timing panel (right-aligned at x): current lap, last lap, best lap, and the three sectors in the
/// broadcast colour code - purple for the race's best, green for the car's personal best, yellow for slower.
function chc_timing_draw(_r, _k, _x, _y, _sc = 1) {
    if (!is_struct(_r) || !variable_struct_exists(_r, "cars") || !is_numeric(_k) || _k < 0 || _k >= array_length(_r.cars)) return;
    if (!is_numeric(_sc)) _sc = 1;
    var _car = _r.cars[_k], _w = 210 * _sc;
    var _x0 = _x - _w;
    chc__panel(_x0, _y, _x, _y + 86 * _sc, 1);
    var _cur = (_r.state == "race" && _car.lap > 0 && !_car.finished) ? _r.raceT - _car.lapStart : -1;
    chc__text(_x0 + 10 * _sc, _y + 18 * _sc, "LAP", fnt_chicane_body_s, 0.56 * _sc, chc__rgb(170, 176, 188), 1);
    chc__text(_x - 12 * _sc, _y + 18 * _sc, chc__fmt(_cur), fnt_chicane_display_s, 0.64 * _sc, c_white, 1, fa_right);
    chc__text(_x0 + 10 * _sc, _y + 40 * _sc, "LAST", fnt_chicane_body_s, 0.5 * _sc, chc__rgb(170, 176, 188), 1);
    chc__text(_x0 + 70 * _sc, _y + 40 * _sc, chc__fmt(_car.lastLap), fnt_chicane_body_s, 0.56 * _sc, c_white, 1);
    chc__text(_x0 + 126 * _sc, _y + 40 * _sc, "BEST", fnt_chicane_body_s, 0.5 * _sc, chc__rgb(170, 176, 188), 1);
    chc__text(_x - 12 * _sc, _y + 40 * _sc, chc__fmt(_car.bestLap), fnt_chicane_body_s, 0.56 * _sc, (_car.bestLap > 0 && _car.bestLap == _r.bestLap) ? chc__rgb(190, 110, 255) : c_white, 1, fa_right);
    var _sw = (_w - 20 * _sc) / 3;
    for (var _s = 0; _s < 3; _s++) {
        var _t = (_car.sectors[_s] >= 0) ? _car.sectors[_s] : _car.lastSectors[_s];
        var _col = chc__rgb(60, 64, 74);
        if (_t >= 0) {
            if (abs(_t - _r.bestSector[_s]) < 0.0005) _col = chc__rgb(160, 70, 240);
            else if (abs(_t - _car.bestSectors[_s]) < 0.0005) _col = chc__rgb(40, 190, 90);
            else _col = chc__rgb(236, 196, 40);
        }
        var _sx = _x0 + 10 * _sc + _s * _sw;
        chc__quad(_sx, _y + 56 * _sc, _sx + _sw - 4 * _sc, _y + 56 * _sc, _sx + _sw - 4 * _sc, _y + 59 * _sc, _sx, _y + 59 * _sc, _col, 1);
        chc__text(_sx + (_sw - 4 * _sc) / 2, _y + 70 * _sc, (_t >= 0) ? string_format(_t, 1, 2) : ("S" + string(_s + 1)), fnt_chicane_body_s, 0.46 * _sc, (_t >= 0) ? c_white : chc__rgb(130, 136, 148), 1, fa_center);
    }
}

/// @function chc_minimap_draw(race, x, y, w, h, [player])
/// @description The circuit's minimap fitted into (x, y, w, h): the track as a dark band with a light core, the start
/// line, and every car as a dot in its livery colour (the player's ringed).
function chc_minimap_draw(_r, _x, _y, _w, _h, _player = -1) {
    if (!is_struct(_r) || !variable_struct_exists(_r, "c")) return;
    var _c = _r.c;
    var _x0 = 1000000, _y0 = 1000000, _x1 = -1000000, _y1 = -1000000;
    for (var _i = 0; _i < _c.n; _i += 4) { _x0 = min(_x0, _c.px[_i]); _y0 = min(_y0, _c.py[_i]); _x1 = max(_x1, _c.px[_i]); _y1 = max(_y1, _c.py[_i]); }
    var _k = min((_w - 16) / max(1, _x1 - _x0), (_h - 16) / max(1, _y1 - _y0));
    var _ox = _x + (_w - (_x1 - _x0) * _k) / 2 - _x0 * _k, _oy = _y + (_h - (_y1 - _y0) * _k) / 2 - _y0 * _k;
    chc__panel(_x, _y, _x + _w, _y + _h, 0.9);
    for (var _pass = 0; _pass < 2; _pass++) {
        var _hw = (_pass == 0) ? 3.4 : 1.4, _col = (_pass == 0) ? chc__rgb(6, 8, 12) : chc__rgb(206, 210, 220);
        var _v = 0;
        draw_primitive_begin(pr_trianglestrip);
        for (var _q = 0; _q <= _c.n; _q += 2) {
            var _i = _q mod _c.n;
            draw_vertex_colour(_ox + _c.px[_i] * _k + _c.nx[_i] * _hw, _oy + _c.py[_i] * _k + _c.ny[_i] * _hw, _col, 1);
            draw_vertex_colour(_ox + _c.px[_i] * _k - _c.nx[_i] * _hw, _oy + _c.py[_i] * _k - _c.ny[_i] * _hw, _col, 1);
            _v += 2;
            if (_v >= CHC_FLUSH) { draw_primitive_end(); draw_primitive_begin(pr_trianglestrip); draw_vertex_colour(_ox + _c.px[_i] * _k + _c.nx[_i] * _hw, _oy + _c.py[_i] * _k + _c.ny[_i] * _hw, _col, 1); draw_vertex_colour(_ox + _c.px[_i] * _k - _c.nx[_i] * _hw, _oy + _c.py[_i] * _k - _c.ny[_i] * _hw, _col, 1); _v = 2; }
        }
        draw_primitive_end();
    }
    draw_set_colour(chc__rgb(230, 40, 50));
    draw_line_width(_ox + (_c.px[0] + _c.nx[0] * 8 / _k) * _k, _oy + (_c.py[0] + _c.ny[0] * 8 / _k) * _k, _ox + (_c.px[0] - _c.nx[0] * 8 / _k) * _k, _oy + (_c.py[0] - _c.ny[0] * 8 / _k) * _k, 2);
    for (var _p = array_length(_r.order) - 1; _p >= 0; _p--) {
        var _car = _r.cars[_r.order[_p]];
        var _cx = _ox + _car.x * _k, _cy = _oy + _car.y * _k;
        if (_car.id == _player) { chc__disc(_cx, _cy, 6, c_white, 1); chc__disc(_cx, _cy, 4.4, chc__rgb(14, 16, 22), 1); }
        chc__disc(_cx, _cy, 3.4, chc__rgb(10, 10, 14), 1);
        chc__disc(_cx, _cy, 2.6, _car.livery.primary, 1);
    }
}

/// @function chc_lights_draw(race, cx, y, [scale])
/// @description The start lights centred on cx: five pods that light red one by one, then all go out (GO in green).
function chc_lights_draw(_r, _cx, _y, _sc = 1) {
    if (!is_struct(_r) || !variable_struct_exists(_r, "state")) return;
    if (!is_numeric(_sc)) _sc = 1;
    if (_r.state == "race" && _r.raceT > 1.4) return;
    var _lit = (_r.state == "lights") ? min(5, floor(_r.lightT / 0.5)) : 0;
    var _w = 5 * 34 * _sc + 16 * _sc;
    chc__panel(_cx - _w / 2, _y, _cx + _w / 2, _y + 44 * _sc, 1);
    for (var _k = 0; _k < 5; _k++) {
        var _x = _cx - _w / 2 + 8 * _sc + 17 * _sc + _k * 34 * _sc;
        chc__disc(_x, _y + 22 * _sc, 13 * _sc, chc__rgb(30, 32, 38), 1);
        var _on = (_k < _lit);
        chc__disc(_x, _y + 22 * _sc, 10 * _sc, _on ? chc__rgb(236, 30, 36) : chc__rgb(56, 20, 22), 1);
        if (_on) { gpu_set_blendmode(bm_add); chc__glow(_x, _y + 22 * _sc, 22 * _sc, chc__rgb(255, 60, 50), 0.5); gpu_set_blendmode(bm_normal); chc__disc(_x - 3 * _sc, _y + 18 * _sc, 3 * _sc, chc__rgb(255, 150, 140), 0.8); }
    }
    if (_r.state == "race") chc__text(_cx, _y + 64 * _sc, "GO", fnt_chicane_display_l, 0.8 * _sc, chc__rgb(80, 230, 110), 1, fa_center);
}

/// @function chc_hud_draw(race, x, y, w, h, [player])
/// @description The whole race HUD inside (x, y, w, h): the tower top-left, the player's timing top-right (the leader's
/// when there is no player), the minimap bottom-right, the player's speed bottom-centre, the start lights top-centre, and
/// the player's messages (CUT - go back for the gate, +3 s penalty, WRONG WAY, FINISHED P n).
function chc_hud_draw(_r, _x, _y, _w, _h, _player = -1) {
    if (!is_struct(_r) || !variable_struct_exists(_r, "cars")) return;
    if (!is_numeric(_player)) _player = -1;
    var _sc = clamp(_h / 640, 0.6, 2);
    chc_tower_draw(_r, _x + 12 * _sc, _y + 12 * _sc, 8, _player, _sc);
    var _tk = (_player >= 0 && _player < array_length(_r.cars)) ? _player : _r.order[0];
    chc_timing_draw(_r, _tk, _x + _w - 12 * _sc, _y + 12 * _sc, _sc);
    var _mw = 200 * _sc, _mh = 150 * _sc;
    chc_minimap_draw(_r, _x + _w - _mw - 12 * _sc, _y + _h - _mh - 12 * _sc, _mw, _mh, _player);
    chc_lights_draw(_r, _x + _w / 2, _y + 12 * _sc, _sc);
    if (_player >= 0 && _player < array_length(_r.cars)) {
        var _car = _r.cars[_player];
        var _kmh = floor(_car.speed * 0.72 + 0.5);
        chc__panel(_x + _w / 2 - 70 * _sc, _y + _h - 56 * _sc, _x + _w / 2 + 70 * _sc, _y + _h - 12 * _sc, 1);
        chc__text(_x + _w / 2 + 14 * _sc, _y + _h - 33 * _sc, string(_kmh), fnt_chicane_display_l, 0.5 * _sc, c_white, 1, fa_right);
        chc__text(_x + _w / 2 + 20 * _sc, _y + _h - 30 * _sc, "KM/H", fnt_chicane_body_s, 0.5 * _sc, chc__rgb(170, 176, 188), 1);
        chc__text(_x + _w / 2 + 20 * _sc, _y + _h - 46 * _sc, "P" + string(_car.position), fnt_chicane_body_s, 0.5 * _sc, chc__rgb(250, 210, 40), 1);
        var _msg = "", _mc = c_white;
        if (_car.finished) { _msg = "FINISHED  P" + string(_car.position); _mc = chc__rgb(250, 210, 40); }
        else if (_car.missedGate >= 0) { _msg = "CORNER CUT - GO BACK FOR THE CHECKPOINT"; _mc = chc__rgb(255, 96, 86); }
        else if (_car.cutWarn > 0) { _msg = "TRACK LIMITS  +" + string(_r.penaltyS) + "s"; _mc = chc__rgb(255, 160, 60); }
        else if (_car.wrongWay) { _msg = "WRONG WAY"; _mc = chc__rgb(255, 96, 86); }
        if (_msg != "") chc__text(_x + _w / 2, _y + _h * 0.3, _msg, fnt_chicane_display_s, 0.8 * _sc, _mc, 1, fa_center);
    }
}

/// @function chc_draw_free()
/// @description Free every cached car sprite (call when leaving the room that raced).
function chc_draw_free() {
    var _cache = chc__car_cache();
    var _keys = variable_struct_get_names(_cache);
    for (var _i = 0; _i < array_length(_keys); _i++) { var _s = _cache[$ _keys[_i]]; if (sprite_exists(_s)) sprite_delete(_s); }
    global.chc_cars = {};
}
