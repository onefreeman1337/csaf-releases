/// chc_core.gml - Chicane's race layer, in pure GML with NO drawing calls: the seeded circuit generator (a corner polygon
/// whose every corner is a circular fillet, an optional chicane, checked for a drivable radius and for clearance between
/// any two parts of the track), the racing line and the speed profile with braking points, the track query (where on the
/// circuit a point is, and what it is driving on), the race (grid, start lights, checkpoint gates that refuse a cut corner
/// or add a penalty, laps, sectors, live positions and gaps), the car model, the AI drivers, and a headless race for
/// tuning. The circuit's scenery (kerbs, gravel, barriers, stands, pit lane, trees, buildings, water, lamps) is laid out
/// here as DATA, so chc_draw only paints what was decided.
///
/// Public functions (each documented below): chc_rng, chc_rand, chc_range, chc_themes, chc_theme, chc_bodies, chc_body,
/// chc_circuit_create, chc_track_query, chc_track_point, chc_livery_create, chc_race_create, chc_race_step, chc_car_input,
/// chc_car_set_ai, chc_race_standings, chc_race_gap, chc_race_progress, chc_race_sim, chc_race_free.
///
/// Units: pixels and seconds. Angles in radians, measured in room space (y down): a heading of 0 faces +x.
///
/// Chicane - Top-Down Racing for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

#macro CHC_DS 8
#macro CHC_GATES 24

// ------------------------------------------------------------------------------------------------ the generator

/// @function chc__mask()
/// @description Internal. 0xFFFFFFFF as an int64.
function chc__mask() { return int64($FFFFFFFF); }

/// @function chc__mix32(value)
/// @description Internal. A 32-bit integer hash (two multiply-xorshift rounds).
function chc__mix32(_v) {
    var _m = chc__mask();
    var _s = int64(floor(_v)) & _m;
    _s = ((_s ^ (_s >> 16)) * int64($45D9F3B)) & _m;
    _s = ((_s ^ (_s >> 16)) * int64($45D9F3B)) & _m;
    _s = (_s ^ (_s >> 16)) & _m;
    return _s;
}

/// @function chc_rng(seed)
/// @description A seeded generator (xorshift32). The seed is hashed first and three draws are discarded, so nearby seeds
/// (base + index, the way every caller counts) do not give nearby first draws.
/// @param {Real} seed  any whole number
/// @returns {Struct} a generator for chc_rand / chc_range
function chc_rng(_seed) {
    if (!is_numeric(_seed)) _seed = 1;
    var _s = chc__mix32(floor(_seed) * 7919 + 104729);
    if (_s == 0) _s = int64(1);
    var _g = { s: _s };
    chc_rand(_g); chc_rand(_g); chc_rand(_g);
    return _g;
}

/// @function chc_rand(generator)
/// @description The next draw in [0, 1). A non-generator returns 0.
function chc_rand(_g) {
    if (!is_struct(_g) || !variable_struct_exists(_g, "s")) return 0;
    var _m = chc__mask();
    var _x = int64(_g.s) & _m;
    _x = _x ^ ((_x << 13) & _m);
    _x = _x ^ (_x >> 17);
    _x = _x ^ ((_x << 5) & _m);
    _x = _x & _m;
    _g.s = _x;
    return real(_x) / 4294967296;
}

/// @function chc_range(generator, lo, hi)
/// @description A draw in [lo, hi). A bound that is not a number reads as 0 (lo) or 1 (hi).
function chc_range(_g, _a, _b) {
    if (!is_numeric(_a)) _a = 0;
    if (!is_numeric(_b)) _b = 1;
    return _a + (_b - _a) * chc_rand(_g);
}

/// @function chc__wrap(i, n)
/// @description Internal. i modulo n, never negative.
function chc__wrap(_i, _n) { var _r = _i mod _n; if (_r < 0) _r += _n; return _r; }

/// @function chc__hyp(dx, dy)
/// @description Internal. sqrt(dx*dx + dy*dy) (point_distance is not a double-precision hypot - wing s23).
function chc__hyp(_x, _y) { return sqrt(_x * _x + _y * _y); }

// ------------------------------------------------------------------------------------------------ themes and bodies

/// @function chc_themes()
/// @description The eight circuit themes, in order.
/// @returns {Array<String>}
function chc_themes() { return ["grandprix", "street", "desert", "snow", "forest", "harbour", "nightcity", "kart"]; }

/// @function chc_theme(name)
/// @description A theme's race settings and its look: track width, run-off, grip, the road surface, kerbs, barriers,
/// scenery and the default car body. An unknown name returns the grand prix theme.
/// @param {String} name  one of chc_themes()
/// @returns {Struct}
function chc_theme(_name) {
    if (!is_string(_name)) _name = "grandprix";
    switch (_name) {
        case "street":    return { name: "street", title: "Street Circuit", ix: 2, width: 66, runoff: 0.3, grip: 0.97, road: "asphalt", kerbs: true, walls: true, pit: false, body: "saloon" };
        case "desert":    return { name: "desert", title: "Desert Rally", ix: 3, width: 72, runoff: 0.9, grip: 0.86, road: "dirt", kerbs: false, walls: false, pit: false, body: "rally" };
        case "snow":      return { name: "snow", title: "Snow Rally", ix: 4, width: 72, runoff: 0.9, grip: 0.74, road: "snow", kerbs: false, walls: false, pit: false, body: "rally" };
        case "forest":    return { name: "forest", title: "Forest Circuit", ix: 5, width: 70, runoff: 0.8, grip: 0.95, road: "asphalt", kerbs: true, walls: false, pit: true, body: "formula" };
        case "harbour":   return { name: "harbour", title: "Harbour Circuit", ix: 6, width: 70, runoff: 0.5, grip: 0.98, road: "asphalt", kerbs: true, walls: true, pit: false, body: "saloon" };
        case "nightcity": return { name: "nightcity", title: "Night City", ix: 7, width: 68, runoff: 0.3, grip: 0.96, road: "asphalt", kerbs: true, walls: true, pit: false, body: "saloon" };
        case "kart":      return { name: "kart", title: "Kart Track", ix: 8, width: 52, runoff: 0.7, grip: 1.0, road: "asphalt", kerbs: true, walls: false, pit: false, body: "kart" };
    }
    return { name: "grandprix", title: "Grand Prix", ix: 1, width: 76, runoff: 1.0, grip: 1.0, road: "asphalt", kerbs: true, walls: false, pit: true, body: "formula" };
}

/// @function chc_bodies()
/// @description The four car bodies the product draws.
function chc_bodies() { return ["formula", "kart", "rally", "saloon"]; }

/// @function chc_body(name)
/// @description A car body's size and performance (px, px/s, px/s/s). An unknown name returns the formula car.
function chc_body(_name) {
    if (!is_string(_name)) _name = "formula";
    switch (_name) {
        case "kart":   return { name: "kart", len: 24, wid: 14, vTop: 330, aEng: 380, aBrake: 720, aLat: 720 };
        case "rally":  return { name: "rally", len: 30, wid: 16, vTop: 440, aEng: 380, aBrake: 720, aLat: 640 };
        case "saloon": return { name: "saloon", len: 34, wid: 17, vTop: 460, aEng: 350, aBrake: 740, aLat: 640 };
    }
    return { name: "formula", len: 34, wid: 15, vTop: 520, aEng: 430, aBrake: 920, aLat: 840 };
}

// ------------------------------------------------------------------------------------------------ circuit geometry

/// @function chc__phi(xs, ys, k, m)
/// @description Internal. The interior angle at corner k of a closed polygon.
function chc__phi(_xs, _ys, _k, _m) {
    var _a = chc__wrap(_k - 1, _m), _b = chc__wrap(_k + 1, _m);
    var _ux = _xs[_a] - _xs[_k], _uy = _ys[_a] - _ys[_k], _vx = _xs[_b] - _xs[_k], _vy = _ys[_b] - _ys[_k];
    var _c = (_ux * _vx + _uy * _vy) / (chc__hyp(_ux, _uy) * chc__hyp(_vx, _vy));
    return arccos(clamp(_c, -1, 1));
}

/// @function chc__frames(c)
/// @description Internal. Tangents, left normals, arc positions and signed curvature for every sample.
function chc__frames(_c) {
    var _n = _c.n;
    _c.tx = array_create(_n, 0); _c.ty = array_create(_n, 0); _c.nx = array_create(_n, 0); _c.ny = array_create(_n, 0);
    _c.s = array_create(_n, 0); _c.k = array_create(_n, 0);
    for (var _i = 0; _i < _n; _i++) {
        var _a = chc__wrap(_i - 1, _n), _b = chc__wrap(_i + 1, _n);
        var _dx = _c.px[_b] - _c.px[_a], _dy = _c.py[_b] - _c.py[_a];
        var _l = chc__hyp(_dx, _dy); if (_l == 0) _l = 1;
        _dx /= _l; _dy /= _l;
        _c.tx[_i] = _dx; _c.ty[_i] = _dy; _c.nx[_i] = -_dy; _c.ny[_i] = _dx; _c.s[_i] = _i * _c.step;
    }
    for (var _i = 0; _i < _n; _i++) {
        var _a = chc__wrap(_i - 1, _n), _b = chc__wrap(_i + 1, _n);
        var _cr = _c.tx[_a] * _c.ty[_b] - _c.ty[_a] * _c.tx[_b];
        _c.k[_i] = _cr / (2 * _c.step);
    }
}

/// @function chc__smooth(arr, passes)
/// @description Internal. A closed [1 2 1] smoothing of an array, returned as a new array.
function chc__smooth(_k, _passes) {
    var _n = array_length(_k);
    var _a = array_create(_n, 0);
    array_copy(_a, 0, _k, 0, _n);
    repeat (_passes) {
        var _o = array_create(_n, 0);
        for (var _i = 0; _i < _n; _i++) _o[_i] = (_a[chc__wrap(_i - 1, _n)] + 2 * _a[_i] + _a[chc__wrap(_i + 1, _n)]) / 4;
        _a = _o;
    }
    return _a;
}

/// @function chc__rot(arr, at)
/// @description Internal. A closed array rotated so index `at` comes first.
function chc__rot(_a, _at) {
    var _n = array_length(_a), _o = array_create(_n, 0);
    for (var _i = 0; _i < _n; _i++) _o[_i] = _a[(_i + _at) mod _n];
    return _o;
}

/// @function chc__rev(arr)
/// @description Internal. A reversed copy.
function chc__rev(_a) {
    var _n = array_length(_a), _o = array_create(_n, 0);
    for (var _i = 0; _i < _n; _i++) _o[_i] = _a[_n - 1 - _i];
    return _o;
}

/// @function chc__fillet_loop(xs, ys, radii, ds)
/// @description Internal. The closed path of straights and circular fillets: dense points about ds / 2 apart.
function chc__fillet_loop(_xs, _ys, _radii, _ds) {
    var _n = array_length(_xs);
    var _ox = [], _oy = [];
    var _t1x = array_create(_n, 0), _t1y = array_create(_n, 0), _t2x = array_create(_n, 0), _t2y = array_create(_n, 0);
    var _cx = array_create(_n, 0), _cy = array_create(_n, 0);
    for (var _i = 0; _i < _n; _i++) {
        var _a = chc__wrap(_i - 1, _n), _b = chc__wrap(_i + 1, _n);
        var _ux = _xs[_a] - _xs[_i], _uy = _ys[_a] - _ys[_i]; var _lu = chc__hyp(_ux, _uy); _ux /= _lu; _uy /= _lu;
        var _vx = _xs[_b] - _xs[_i], _vy = _ys[_b] - _ys[_i]; var _lv = chc__hyp(_vx, _vy); _vx /= _lv; _vy /= _lv;
        var _phi = arccos(clamp(_ux * _vx + _uy * _vy, -1, 1));
        var _r = _radii[_i], _t = _r / tan(_phi / 2);
        var _bx = _ux + _vx, _by = _uy + _vy; var _lb = chc__hyp(_bx, _by); if (_lb == 0) _lb = 1; _bx /= _lb; _by /= _lb;
        var _h = _r / sin(_phi / 2);
        _cx[_i] = _xs[_i] + _bx * _h; _cy[_i] = _ys[_i] + _by * _h;
        _t1x[_i] = _xs[_i] + _ux * _t; _t1y[_i] = _ys[_i] + _uy * _t;
        _t2x[_i] = _xs[_i] + _vx * _t; _t2y[_i] = _ys[_i] + _vy * _t;
    }
    for (var _i = 0; _i < _n; _i++) {
        var _a0 = arctan2(_t1y[_i] - _cy[_i], _t1x[_i] - _cx[_i]);
        var _a1 = arctan2(_t2y[_i] - _cy[_i], _t2x[_i] - _cx[_i]);
        var _sw = _a1 - _a0;
        while (_sw > pi) _sw -= pi * 2;
        while (_sw < -pi) _sw += pi * 2;
        var _r = _radii[_i];
        var _m = max(2, ceil((abs(_sw) * _r) / (_ds * 0.5)));
        for (var _k = 0; _k < _m; _k++) {
            var _q = _a0 + (_sw * _k) / _m;
            array_push(_ox, _cx[_i] + cos(_q) * _r); array_push(_oy, _cy[_i] + sin(_q) * _r);
        }
        var _j = (_i + 1) mod _n;
        var _L = chc__hyp(_t1x[_j] - _t2x[_i], _t1y[_j] - _t2y[_i]);
        var _ms = max(1, ceil(_L / (_ds * 0.5)));
        for (var _k = 0; _k < _ms; _k++) {
            array_push(_ox, _t2x[_i] + ((_t1x[_j] - _t2x[_i]) * _k) / _ms);
            array_push(_oy, _t2y[_i] + ((_t1y[_j] - _t2y[_i]) * _k) / _ms);
        }
    }
    return { x: _ox, y: _oy };
}

/// @function chc__resample(dense, ds)
/// @description Internal. Resample a closed dense path at an even spacing near ds.
function chc__resample(_d, _ds) {
    var _m = array_length(_d.x);
    var _acc = array_create(_m + 1, 0), _tot = 0;
    for (var _i = 0; _i < _m; _i++) {
        var _b = (_i + 1) mod _m;
        _tot += chc__hyp(_d.x[_b] - _d.x[_i], _d.y[_b] - _d.y[_i]);
        _acc[_i + 1] = _tot;
    }
    var _n = max(24, floor(_tot / _ds + 0.5));
    var _step = _tot / _n;
    var _px = array_create(_n, 0), _py = array_create(_n, 0);
    var _j = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _s = _i * _step;
        while (_acc[_j + 1] < _s) _j++;
        var _b = (_j + 1) mod _m;
        var _f = (_s - _acc[_j]) / max(0.000000001, _acc[_j + 1] - _acc[_j]);
        _px[_i] = _d.x[_j] + (_d.x[_b] - _d.x[_j]) * _f;
        _py[_i] = _d.y[_j] + (_d.y[_b] - _d.y[_j]) * _f;
    }
    return { px: _px, py: _py, n: _n, step: _step, total: _tot };
}

/// @function chc__clearance(c, clear, gap)
/// @description Internal. The closest approach of any two samples more than `gap` apart along the loop.
function chc__clearance(_c, _clear, _gap) {
    var _n = _c.n, _gi = ceil(_gap / _c.step), _worst = 1000000000;
    for (var _i = 0; _i < _n; _i += 3) {
        for (var _j = _i + _gi; _j < _n; _j += 3) {
            if ((_n - _j) + _i < _gi) continue;
            var _dx = _c.px[_i] - _c.px[_j], _dy = _c.py[_i] - _c.py[_j];
            var _dd = sqrt(_dx * _dx + _dy * _dy);
            if (_dd < _worst) _worst = _dd;
        }
    }
    return _worst;
}

/// @function chc__start_line(c)
/// @description Internal. Re-index the loop so sample 0 is the start line: 62% of the way down the longest straight.
function chc__start_line(_c) {
    var _n = _c.n, _ks = chc__smooth(_c.k, 3), _kS = 1 / (_c.width * 14);
    var _best = -1, _bestLen = 0;
    for (var _i = 0; _i < _n; _i++) {
        if (abs(_ks[_i]) >= _kS || abs(_ks[chc__wrap(_i - 1, _n)]) < _kS) continue;
        var _len = 0;
        while (_len < _n && abs(_ks[(_i + _len) mod _n]) < _kS) _len++;
        if (_len > _bestLen) { _bestLen = _len; _best = _i; }
    }
    if (_best < 0) { _best = 0; _bestLen = floor(_n / 6); }
    // 62% of the way down, unless that leaves too little straight BEHIND the line for an 8-car grid at the closest
    // pitch (36 px): then as far down as that needs, keeping 12 samples of straight ahead of the line. The suite found
    // the hero's own circuit (grand prix seed 3) painting 7 boxes for its 8-car race (2026-10-24).
    var _need8 = ceil((26 + 7 * 36 + 20) / _c.step) + 1;
    var _back = max(floor(_bestLen * 0.62), min(_need8, _bestLen - 12));
    var _at = (_best + _back) mod _n;
    _c.px = chc__rot(_c.px, _at); _c.py = chc__rot(_c.py, _at);
    chc__frames(_c);
    _c.straightLen = _bestLen * _c.step;
    _c.straightBack = _back;
    _c.straightAhead = _bestLen - _c.straightBack;
}

/// @function chc__racing_line(c, margin)
/// @description Internal. The racing line as a lateral offset per sample, by coarse-to-fine relaxation (each point moves
/// toward the midpoint of its neighbours, held inside the track less `margin`): out-in-out through every corner. Its
/// curvature and segment lengths feed the speed profile. ~21,500 point moves on a typical circuit.
function chc__racing_line(_c, _margin) {
    var _n = _c.n, _lim = _c.hw - _margin;
    var _d = array_create(_n, 0);
    var _px = _c.px, _py = _c.py, _nx = _c.nx, _ny = _c.ny;
    var _plan = [16, 80, 8, 50, 4, 30, 2, 14, 1, 6];
    _c.lineWork = 0;
    for (var _p = 0; _p < 10; _p += 2) {
        var _h = _plan[_p], _it = _plan[_p + 1];
        repeat (_it) {
            for (var _i = 0; _i < _n; _i += _h) {
                _c.lineWork++;
                var _a = chc__wrap(_i - _h, _n), _b = (_i + _h) mod _n;
                var _mx = (_px[_a] + _nx[_a] * _d[_a] + _px[_b] + _nx[_b] * _d[_b]) / 2;
                var _my = (_py[_a] + _ny[_a] * _d[_a] + _py[_b] + _ny[_b] * _d[_b]) / 2;
                var _qx = _px[_i] + _nx[_i] * _d[_i], _qy = _py[_i] + _ny[_i] * _d[_i];
                var _mv = (_mx - _qx) * _nx[_i] + (_my - _qy) * _ny[_i];
                _d[_i] = clamp(_d[_i] + _mv * 0.6, -_lim, _lim);
            }
        }
        if (_h > 1) {
            for (var _i = 0; _i < _n; _i++) {
                var _r = _i mod _h;
                if (_r == 0) continue;
                var _a = _i - _r, _b = _a + _h, _span = _h;
                if (_b >= _n) { _b = 0; _span = _n - _a; }
                _d[_i] = _d[_a] + (_d[_b] - _d[_a]) * (_r / _span);
            }
        }
    }
    _c.line = _d;
    _c.lx = array_create(_n, 0); _c.ly = array_create(_n, 0); _c.lk = array_create(_n, 0); _c.lds = array_create(_n, 0);
    for (var _i = 0; _i < _n; _i++) { _c.lx[_i] = _px[_i] + _nx[_i] * _d[_i]; _c.ly[_i] = _py[_i] + _ny[_i] * _d[_i]; }
    for (var _i = 0; _i < _n; _i++) {
        var _a = chc__wrap(_i - 2, _n), _b = (_i + 2) mod _n;
        var _ax = _c.lx[_i] - _c.lx[_a], _ay = _c.ly[_i] - _c.ly[_a], _bx = _c.lx[_b] - _c.lx[_i], _by = _c.ly[_b] - _c.ly[_i];
        var _la = chc__hyp(_ax, _ay), _lb = chc__hyp(_bx, _by);
        if (_la == 0) _la = 1; if (_lb == 0) _lb = 1;
        _c.lk[_i] = ((_ax * _by - _ay * _bx) / (_la * _lb)) / ((_la + _lb) / 2);
        var _j = (_i + 1) mod _n;
        _c.lds[_i] = chc__hyp(_c.lx[_j] - _c.lx[_i], _c.ly[_j] - _c.ly[_i]);
    }
}

/// @function chc__profile(c, body)
/// @description Internal. The speed profile for one body on this circuit's racing line: the corner limit from the line's
/// curvature and the body's grip, then a backward pass for braking and a forward pass on the body's real engine curve.
/// Cached on the circuit per body name.
function chc__profile(_c, _B) {
    if (variable_struct_exists(_c.profiles, _B.name)) return _c.profiles[$ _B.name];
    var _n = _c.n, _v = array_create(_n, 0), _aLat = _B.aLat * 0.88 * _c.grip;
    for (var _i = 0; _i < _n; _i++) _v[_i] = min(_B.vTop * 0.985, sqrt(_aLat / max(0.00001, abs(_c.lk[_i]))));
    repeat (2) {
        for (var _i = _n - 1; _i >= 0; _i--) { var _b = (_i + 1) mod _n; _v[_i] = min(_v[_i], sqrt(_v[_b] * _v[_b] + 2 * _B.aBrake * 0.72 * _c.lds[_i])); }
        for (var _i = 0; _i < _n; _i++) {
            var _a = chc__wrap(_i - 1, _n);
            var _acc = _B.aEng * 0.92 * max(0.02, 1 - _v[_a] / _B.vTop);
            _v[_i] = min(_v[_i], sqrt(_v[_a] * _v[_a] + 2 * _acc * _c.lds[_a]));
        }
    }
    // braking points: where the profile starts falling by more than 12 px/s per sample
    var _brk = array_create(_n, false);
    for (var _i = 0; _i < _n; _i++) _brk[_i] = (_v[_i] - _v[(_i + 1) mod _n]) > 2.2;
    var _o = { v: _v, brake: _brk };
    _c.profiles[$ _B.name] = _o;
    return _o;
}

/// @function chc_circuit_create(seed, theme, [opts])
/// @description Generate a circuit. A corner polygon is drawn from the seed and fitted to the world box, an optional
/// chicane is pushed into the longest straight, and every corner becomes a circular fillet tangent to its two straights
/// (hairpins at sharp corners, sweepers at open ones). The loop is rejected and redrawn (up to 80 attempts, counted in
/// `attempts`) when its tightest corner is below a drivable radius for the theme's width, or when two parts of the track
/// come closer than both tracks plus both run-offs. Then the direction, the start line on the longest straight, the
/// racing line, the gates, the grid and the scenery layout.
/// @param {Real} seed   any whole number
/// @param {String} theme  one of chc_themes(); sets width, run-off, grip and the look
/// @param {Struct} [opts]  { worldW: 2600, worldH: 1800, width: <theme's> }
/// @returns {Struct} the circuit: px/py (centreline samples about 8 px apart), tx/ty, nx/ny (left normals), s (arc
///   position), k (curvature), length, width, hw, runoff, line (racing-line offset), lx/ly, gates, grid, layout, theme.
function chc_circuit_create(_seed, _theme, _opts = undefined) {
    var _eps = math_get_epsilon();
    math_set_epsilon(0);
    if (!is_numeric(_seed)) _seed = 1;
    _seed = floor(_seed);
    var _T = chc_theme(_theme);
    var _W = 2600, _H = 1800, _width = _T.width;
    if (is_struct(_opts)) {
        if (variable_struct_exists(_opts, "worldW") && is_numeric(_opts.worldW)) _W = clamp(_opts.worldW, 1200, 4096);
        if (variable_struct_exists(_opts, "worldH") && is_numeric(_opts.worldH)) _H = clamp(_opts.worldH, 900, 4096);
        if (variable_struct_exists(_opts, "width") && is_numeric(_opts.width)) _width = clamp(_opts.width, 36, 120);
    }
    var _hw = _width / 2, _runoff = max(8, _width * _T.runoff);
    var _margin = _hw + _runoff + 120;
    var _strip = (_T.name == "harbour") ? _H * 0.2 : 0;
    var _boxW = _W - _margin * 2, _boxH = _H - _margin * 2 - _strip;
    var _clear = 2 * (_hw + _runoff) + 24;
    var _minR = _hw + max(10, _runoff * 0.35) + 14;
    var _g0 = chc_rng(_seed * 17 + _T.ix);
    var _c = undefined, _why = [], _attempts = 0;
    for (_attempts = 1; _attempts <= 80; _attempts++) {
        var _g = chc_rng(_seed * 131 + _T.ix * 7717 + _attempts * 977 + 7);
        var _pn = 6 + floor(chc_rand(_g) * 6);
        var _xs = array_create(_pn, 0), _ys = array_create(_pn, 0);
        for (var _i = 0; _i < _pn; _i++) {
            var _jit = chc_range(_g, -0.3, 0.3);
            var _a = (pi * 2 * (_i + _jit)) / _pn;
            var _r = chc_range(_g, 0.58, 1.0);
            if (chc_rand(_g) < 0.26) _r *= chc_range(_g, 0.32, 0.58);
            _xs[_i] = cos(_a) * _r; _ys[_i] = sin(_a) * _r;
        }
        var _x0 = 1000000000, _y0 = 1000000000, _x1 = -1000000000, _y1 = -1000000000;
        for (var _i = 0; _i < _pn; _i++) { _x0 = min(_x0, _xs[_i]); _y0 = min(_y0, _ys[_i]); _x1 = max(_x1, _xs[_i]); _y1 = max(_y1, _ys[_i]); }
        var _sx = _boxW / (_x1 - _x0), _sy = _boxH / (_y1 - _y0);
        for (var _i = 0; _i < _pn; _i++) { _xs[_i] = _margin + (_xs[_i] - _x0) * _sx; _ys[_i] = _margin + (_ys[_i] - _y0) * _sy; }
        // the chicane: two points pushed either side of the longest straight
        var _chicane = false;
        if (chc_rand(_g) < 0.55) {
            var _li = 0, _ll = 0;
            for (var _i = 0; _i < _pn; _i++) {
                var _b = (_i + 1) mod _pn;
                var _l = chc__hyp(_xs[_b] - _xs[_i], _ys[_b] - _ys[_i]);
                if (_l > _ll) { _ll = _l; _li = _i; }
            }
            if (_ll > _width * 14) {
                var _bb = (_li + 1) mod _pn;
                var _ex = (_xs[_bb] - _xs[_li]) / _ll, _ey = (_ys[_bb] - _ys[_li]) / _ll;
                var _sd = (chc_rand(_g) < 0.5) ? 1 : -1;
                var _off = _width * chc_range(_g, 0.8, 1.15);
                var _f1 = chc_range(_g, 0.38, 0.5);
                var _f2 = _f1 + (_width * 3.2) / _ll;
                var _c1x = _xs[_li] + _ex * _ll * _f1 - _ey * _off * _sd, _c1y = _ys[_li] + _ey * _ll * _f1 + _ex * _off * _sd;
                var _c2x = _xs[_li] + _ex * _ll * _f2 + _ey * _off * _sd, _c2y = _ys[_li] + _ey * _ll * _f2 - _ex * _off * _sd;
                array_insert(_xs, _li + 1, _c1x, _c2x);
                array_insert(_ys, _li + 1, _c1y, _c2y);
                _chicane = true;
            }
        }
        var _m = array_length(_xs), _radii = array_create(_m, 0);
        for (var _i = 0; _i < _m; _i++) {
            var _phi = chc__phi(_xs, _ys, _i, _m);
            if (_phi < 1.2) _radii[_i] = _width * chc_range(_g, 1.05, 1.6);
            else _radii[_i] = _width * chc_range(_g, 1.4, 4.2);
        }
        repeat (6) {
            for (var _i = 0; _i < _m; _i++) {
                var _j = (_i + 1) mod _m;
                var _L = chc__hyp(_xs[_j] - _xs[_i], _ys[_j] - _ys[_i]);
                var _need = _radii[_i] / tan(chc__phi(_xs, _ys, _i, _m) / 2) + _radii[_j] / tan(chc__phi(_xs, _ys, _j, _m) / 2);
                if (_need > _L * 0.96) { var _f = (_L * 0.96) / _need; _radii[_i] *= _f; _radii[_j] *= _f; }
            }
        }
        var _fits = true;
        for (var _i = 0; _i < _m; _i++) if (_radii[_i] < _minR) _fits = false;
        if (!_fits) { array_push(_why, "fillet"); continue; }
        var _rs = chc__resample(chc__fillet_loop(_xs, _ys, _radii, CHC_DS), CHC_DS);
        _c = { seed: _seed, theme: _T.name, T: _T, width: _width, hw: _hw, runoff: _runoff, grip: _T.grip, worldW: _W, worldH: _H,
               px: _rs.px, py: _rs.py, n: _rs.n, step: _rs.step, length: _rs.total, corners: _m, chicane: _chicane, valid: false };
        chc__frames(_c);
        var _ks = chc__smooth(_c.k, 2), _kmax = 0;
        for (var _i = 0; _i < _c.n; _i++) _kmax = max(_kmax, abs(_ks[_i]));
        var _rmin = 1 / max(0.000001, _kmax);
        if (_rmin < _minR) { array_push(_why, "radius " + string_format(_rmin, 1, 1)); continue; }
        var _cl = chc__clearance(_c, _clear, _hw * 2 + _runoff * 2 + 60 + pi * (_hw + _runoff));
        if (_cl < _clear) { array_push(_why, "clear " + string_format(_cl, 1, 1)); continue; }
        _c.valid = true; _c.rmin = _rmin; _c.clearance = _cl;
        break;
    }
    if (is_undefined(_c) || !_c.valid) {
        // never reached on the measured corpus (see the suite); a buyer still gets a drivable oval and the reason
        _c = chc__fallback_oval(_seed, _T, _W, _H, _width, _hw, _runoff, _margin, _strip);
        _c.fallback = true;
    } else _c.fallback = false;
    _c.attempts = min(_attempts, 80);
    _c.why = _why;
    if (chc_rand(_g0) < 0.5) { _c.px = chc__rev(_c.px); _c.py = chc__rev(_c.py); chc__frames(_c); }
    chc__start_line(_c);
    _c.profiles = {};
    chc__racing_line(_c, 9);
    // gates every 1/24 of a lap; gate 0 is the start/finish line
    _c.gates = array_create(CHC_GATES, 0);
    for (var _k = 0; _k < CHC_GATES; _k++) _c.gates[_k] = (_c.length * _k) / CHC_GATES;
    // the total turning decides which side is the infield
    var _turn = 0;
    for (var _i = 0; _i < _c.n; _i++) _turn += _c.k[_i] * _c.step;
    _c.infield = (_turn >= 0) ? 1 : -1;
    chc__grid(_c, 12);
    chc__layout(_c);
    math_set_epsilon(_eps);
    return _c;
}

/// @function chc__fallback_oval(...)
/// @description Internal. A rounded oval that always fits (used only if 80 attempts all fail).
function chc__fallback_oval(_seed, _T, _W, _H, _width, _hw, _runoff, _margin, _strip) {
    var _cx = _W / 2, _cy = (_H - _strip) / 2, _rx = _W / 2 - _margin, _ry = (_H - _strip) / 2 - _margin;
    var _xs = [_cx - _rx, _cx + _rx, _cx + _rx, _cx - _rx], _ys = [_cy - _ry, _cy - _ry, _cy + _ry, _cy + _ry];
    var _rr = min(_rx, _ry) * 0.6, _radii = [_rr, _rr, _rr, _rr];
    var _rs = chc__resample(chc__fillet_loop(_xs, _ys, _radii, CHC_DS), CHC_DS);
    var _c = { seed: _seed, theme: _T.name, T: _T, width: _width, hw: _hw, runoff: _runoff, grip: _T.grip, worldW: _W, worldH: _H,
               px: _rs.px, py: _rs.py, n: _rs.n, step: _rs.step, length: _rs.total, corners: 4, chicane: false, valid: true, rmin: _rr, clearance: _ry * 2 };
    chc__frames(_c);
    return _c;
}

/// @function chc__grid(c, slots)
/// @description Internal. Grid slots behind the start line, staggered left and right. The pitch closes from 44 px toward
/// 36 px so that as many slots as possible sit on the start straight, and a slot is `painted` (its box drawn on the road)
/// only when it does: a grid painted round the corner behind the straight was seen on the store bake (2026-10-24).
function chc__grid(_c, _slots) {
    _c.grid = [];
    var _room = _c.straightBack * _c.step - 20;
    var _pitch = clamp((_room - 26) / max(1, _slots - 1), 36, 44);
    _c.gridPitch = _pitch;
    for (var _k = 0; _k < _slots; _k++) {
        var _back = 26 + _k * _pitch;
        var _s = _c.length - _back;
        var _i = floor(_s / _c.step) mod _c.n;
        var _side = ((_k mod 2 == 0) ? 1 : -1) * _c.hw * 0.42;
        array_push(_c.grid, { x: _c.px[_i] + _c.nx[_i] * _side, y: _c.py[_i] + _c.ny[_i] * _side, ang: arctan2(_c.ty[_i], _c.tx[_i]), i: _i, d: _side, s: _s, painted: (_back <= _room) });
    }
}

// ------------------------------------------------------------------------------------------------ the scenery, as data

/// @function chc__occ_new(c, cell)
/// @description Internal. An occupancy grid over the world: 0 free, 1 the track corridor, 2 an object, 3 water.
function chc__occ_new(_c, _cell) {
    var _cols = ceil(_c.worldW / _cell), _rows = ceil(_c.worldH / _cell);
    var _o = { cell: _cell, cols: _cols, rows: _rows, a: array_create(_cols * _rows, 0) };
    // a cell is CORRIDOR when any part of it can lie within the barrier + 12 px of a sample: a free cell is therefore
    // clear of the track by construction (a point-in-cell test needs no exact distance)
    var _R = _c.hw + _c.runoff + 12;
    var _rc = ceil(_R / _cell) + 1;
    for (var _i = 0; _i < _c.n; _i += 2) {
        var _gx = floor(_c.px[_i] / _cell), _gy = floor(_c.py[_i] / _cell);
        for (var _y = _gy - _rc; _y <= _gy + _rc; _y++) {
            if (_y < 0 || _y >= _rows) continue;
            for (var _x = _gx - _rc; _x <= _gx + _rc; _x++) {
                if (_x < 0 || _x >= _cols) continue;
                var _cx = (_x + 0.5) * _cell - _c.px[_i], _cy = (_y + 0.5) * _cell - _c.py[_i];
                if (_cx * _cx + _cy * _cy <= (_R + _cell * 0.71) * (_R + _cell * 0.71)) _o.a[_y * _cols + _x] = 1;
            }
        }
    }
    return _o;
}

/// @function chc__occ_get(o, x, y)
/// @description Internal. The cell code at a world point (outside the world reads as 2, occupied).
function chc__occ_get(_o, _x, _y) {
    var _gx = floor(_x / _o.cell), _gy = floor(_y / _o.cell);
    if (_gx < 0 || _gy < 0 || _gx >= _o.cols || _gy >= _o.rows) return 2;
    return _o.a[_gy * _o.cols + _gx];
}

/// @function chc__rect_pts(cx, cy, ang, len, dep)
/// @description Internal. A rotated rectangle's sample points (every ~24 px, edges included).
function chc__rect_pts(_cx, _cy, _ang, _len, _dep) {
    var _o = [], _ex = cos(_ang), _ey = sin(_ang), _qx = -_ey, _qy = _ex;
    var _nu = max(2, ceil(_len / 24)), _nv = max(2, ceil(_dep / 24));
    for (var _u = 0; _u <= _nu; _u++) for (var _v = 0; _v <= _nv; _v++) {
        var _a = (_u / _nu - 0.5) * _len, _b = (_v / _nv - 0.5) * _dep;
        array_push(_o, _cx + _ex * _a + _qx * _b, _cy + _ey * _a + _qy * _b);
    }
    return _o;
}

/// @function chc__occ_fits(o, pts, allowWater)
/// @description Internal. Every point lands on a free cell.
function chc__occ_fits(_o, _pts, _water = false) {
    for (var _i = 0; _i < array_length(_pts); _i += 2) {
        var _v = chc__occ_get(_o, _pts[_i], _pts[_i + 1]);
        if (_v == 0) continue;
        if (_water && _v == 3) continue;
        return false;
    }
    return true;
}

/// @function chc__occ_mark(o, pts, code)
/// @description Internal. Mark the cells under the points.
function chc__occ_mark(_o, _pts, _code) {
    for (var _i = 0; _i < array_length(_pts); _i += 2) {
        var _gx = floor(_pts[_i] / _o.cell), _gy = floor(_pts[_i + 1] / _o.cell);
        if (_gx < 0 || _gy < 0 || _gx >= _o.cols || _gy >= _o.rows) continue;
        _o.a[_gy * _o.cols + _gx] = _code;
    }
}

/// @function chc__place_along(o, c, i, side, len, dep)
/// @description Internal. A rectangle beside sample i on `side`, parallel to the track, as close as free cells allow
/// (stepping out 16 px at a time, five tries). Marks it and returns { x, y, ang, len, dep, off }, or undefined.
function chc__place_along(_o, _c, _i, _side, _len, _dep) {
    var _ang = arctan2(_c.ty[_i], _c.tx[_i]);
    for (var _t = 0; _t < 5; _t++) {
        var _off = _c.hw + _c.runoff + 24 + _t * 16 + _dep / 2;
        var _x = _c.px[_i] + _c.nx[_i] * _side * _off, _y = _c.py[_i] + _c.ny[_i] * _side * _off;
        var _pts = chc__rect_pts(_x, _y, _ang, _len, _dep);
        if (chc__occ_fits(_o, _pts)) { chc__occ_mark(_o, _pts, 2); return { x: _x, y: _y, ang: _ang, len: _len, dep: _dep, off: _off }; }
    }
    return undefined;
}

/// @function chc__layout(c)
/// @description Internal. Lay out the scenery as data (its own generator, so the track never moves when scenery
/// changes): corner runs, kerbs, gravel traps, tyre walls, the barrier kind, the pit lane, grandstands, trees, buildings,
/// water and boats, marshal posts, street lamps, dunes and rocks. chc_draw paints exactly this.
function chc__layout(_c) {
    var _T = _c.T, _n = _c.n, _g = chc_rng(_c.seed * 53 + _T.ix * 101 + 3);
    var _L = { corners: [], kerbs: [], gravel: [], tyres: [], stands: [], pit: undefined, trees: [], buildings: [], boats: [],
               posts: [], lamps: [], dunes: [], rocks: [], water: undefined };
    // corners: runs of samples with |k| above 1 / (5.5 width)
    var _kc = 1 / (_c.width * 5.5), _ks = chc__smooth(_c.k, 2);
    var _start = -1;
    for (var _i = 0; _i < _n; _i++) if (abs(_ks[_i]) < _kc) { _start = _i; break; }
    if (_start < 0) _start = 0;
    var _i = 0;
    while (_i < _n) {
        var _ii = (_start + _i) mod _n;
        if (abs(_ks[_ii]) >= _kc) {
            var _len = 0, _sg = sign(_ks[_ii]), _peak = 0, _apex = _ii;
            while (_i + _len < _n && abs(_ks[(_start + _i + _len) mod _n]) >= _kc && sign(_ks[(_start + _i + _len) mod _n]) == _sg) {
                var _jj = (_start + _i + _len) mod _n;
                if (abs(_ks[_jj]) > _peak) { _peak = abs(_ks[_jj]); _apex = _jj; }
                _len++;
            }
            array_push(_L.corners, { i0: _ii, len: _len, side: _sg, apex: _apex, k: _peak });
            _i += max(1, _len);
        } else _i++;
    }
    // kerbs (inside through the apex, outside on the exit), gravel and tyre walls on the outside
    for (var _q = 0; _q < array_length(_L.corners); _q++) {
        var _cn = _L.corners[_q];
        var _in0 = _cn.i0 + floor(_cn.len * 0.12), _inLen = max(4, floor(_cn.len * 0.76));
        if (_T.kerbs) {
            array_push(_L.kerbs, { i0: chc__wrap(_in0, _n), len: _inLen, side: _cn.side });
            array_push(_L.kerbs, { i0: chc__wrap(_cn.i0 + floor(_cn.len * 0.6), _n), len: max(4, floor(_cn.len * 0.4) + 6), side: -_cn.side });
        }
        var _tight = _cn.k > 1 / (_c.width * 2.4);
        if (!_T.walls) array_push(_L.gravel, { i0: chc__wrap(_cn.i0 - 6, _n), len: _cn.len + 18, side: -_cn.side, tarmac: (_T.name == "grandprix" && !_tight && chc_rand(_g) < 0.4) });
        if (!_T.walls && (_tight || _T.name == "kart")) array_push(_L.tyres, { i0: chc__wrap(_cn.i0 - 4, _n), len: _cn.len + 14, side: -_cn.side });
    }
    if (_T.name == "kart") { _L.tyres = []; array_push(_L.tyres, { i0: 0, len: _n, side: 1 }, { i0: 0, len: _n, side: -1 }); }
    var _o = chc__occ_new(_c, 32);
    // water: the bottom strip of a harbour world
    if (_T.name == "harbour") {
        var _wy = _c.worldH * 0.8;
        _L.water = { y: _wy };
        for (var _gy = floor(_wy / _o.cell) + 1; _gy < _o.rows; _gy++) for (var _gx = 0; _gx < _o.cols; _gx++) if (_o.a[_gy * _o.cols + _gx] == 0) _o.a[_gy * _o.cols + _gx] = 3;
        repeat (7 + floor(chc_rand(_g) * 5)) {
            var _bx = chc_range(_g, 80, _c.worldW - 80), _by = chc_range(_g, _wy + 70, _c.worldH - 40);
            var _ba = chc_range(_g, -0.3, 0.3) + ((chc_rand(_g) < 0.5) ? 0 : pi);
            var _bl = chc_range(_g, 60, 130);
            var _pts = chc__rect_pts(_bx, _by, _ba, _bl + 20, _bl * 0.38 + 16);
            var _ok = true;
            for (var _p = 0; _p < array_length(_pts); _p += 2) if (chc__occ_get(_o, _pts[_p], _pts[_p + 1]) != 3) _ok = false;
            if (!_ok) continue;
            chc__occ_mark(_o, _pts, 2);
            array_push(_L.boats, { x: _bx, y: _by, ang: _ba, len: _bl, kind: floor(chc_rand(_g) * 3), col: floor(chc_rand(_g) * 6) });
        }
    }
    // the pit lane and its garages on the infield side of the start straight (circuit themes with room for it)
    var _halfStraight = floor(min(_c.straightBack, _c.straightAhead) * 0.85);
    if (_T.pit && _halfStraight > 18) {
        var _ps = _c.infield;
        var _iA = chc__wrap(-_halfStraight, _n), _iB = _halfStraight;
        var _plen = (2 * _halfStraight) * _c.step;
        // the garages stand AT the barrier line (the pit apron runs from the lane to them, and they are the barrier there);
        // only their outer part is tested against the grid, because the inner part lies in this straight's own corridor
        var _dep = 56, _bang = arctan2(_c.ty[0], _c.tx[0]);
        var _boff = _c.hw + _c.runoff + 2 + _dep / 2;
        var _bx = _c.px[0] + _c.nx[0] * _ps * _boff, _by = _c.py[0] + _c.ny[0] * _ps * _boff;
        // corridor cells reach ~35 px past the barrier (12 px + a cell's half diagonal), so the tested strip is the one just
        // BEHIND the 56 px building (58..82 px past the barrier): free there means no other part of the track is near
        var _tst = chc__rect_pts(_c.px[0] + _c.nx[0] * _ps * (_c.hw + _c.runoff + 70), _c.py[0] + _c.ny[0] * _ps * (_c.hw + _c.runoff + 70), _bang, _plen * 0.7, 24);
        if (chc__occ_fits(_o, _tst)) {
            chc__occ_mark(_o, chc__rect_pts(_bx, _by, _bang, _plen * 0.7, _dep), 2);
            _L.pit = { i0: _iA, len: 2 * _halfStraight, side: _ps, d0: _c.hw + 14, d1: _c.hw + 44, building: { x: _bx, y: _by, ang: _bang, len: _plen * 0.7, dep: _dep, off: _boff }, boxes: 10 };
        }
    }
    // grandstands: the main stand opposite the pits at the line, then up to two at the tightest corners
    var _standSide = (is_undefined(_L.pit)) ? -_c.infield : -_L.pit.side;
    var _mainLen = clamp(_c.straightLen * 0.45, 160, 560);
    for (var _try = 0; _try < 4; _try++) {
        var _sideTry = (_try mod 2 == 0) ? _standSide : -_standSide;
        var _len2 = _mainLen * ((_try < 2) ? 1 : 0.6);
        var _st = chc__place_along(_o, _c, 0, _sideTry, _len2, 80);
        if (!is_undefined(_st)) { _st.side = _sideTry; _st.roof = true; array_push(_L.stands, _st); break; }
    }
    var _byK = [];
    for (var _q = 0; _q < array_length(_L.corners); _q++) array_push(_byK, { q: _q, k: _L.corners[_q].k });
    array_sort(_byK, function(_a, _b) { return (_b.k > _a.k) ? 1 : ((_b.k < _a.k) ? -1 : 0); });
    var _extra = 0;
    for (var _z = 0; _z < array_length(_byK) && _extra < 2; _z++) {
        var _cn = _L.corners[_byK[_z].q];
        var _st2 = chc__place_along(_o, _c, _cn.apex, -_cn.side, 180, 64);
        if (!is_undefined(_st2)) { _st2.side = -_cn.side; _st2.roof = false; array_push(_L.stands, _st2); _extra++; }
    }
    // marshal posts along the outside every ~420 px; street lamps every ~150 px on both sides at night
    var _every = max(8, floor(420 / _c.step));
    for (var _i2 = floor(_every / 2); _i2 < _n; _i2 += _every) {
        var _sd3 = ((_i2 div _every) mod 2 == 0) ? 1 : -1;
        var _off4 = _c.hw + _c.runoff + 16;
        var _mx = _c.px[_i2] + _c.nx[_i2] * _sd3 * _off4, _my = _c.py[_i2] + _c.ny[_i2] * _sd3 * _off4;
        // never on a building, a stand, the garages or the water, nor with one right behind it
        var _here = chc__occ_get(_o, _mx, _my), _far = chc__occ_get(_o, _mx + _c.nx[_i2] * _sd3 * 24, _my + _c.ny[_i2] * _sd3 * 24);
        if (_here >= 2 || _far >= 2) continue;
        array_push(_L.posts, { x: _mx, y: _my, ang: arctan2(_c.ty[_i2], _c.tx[_i2]), side: _sd3 });
    }
    if (_T.name == "nightcity" || _T.name == "street" || _T.name == "harbour") {
        var _le = max(6, floor(150 / _c.step));
        for (var _i3 = 0; _i3 < _n; _i3 += _le) {
            for (var _sd4 = -1; _sd4 <= 1; _sd4 += 2) {
                if ((_i3 div _le) mod 2 == 0 && _sd4 > 0) continue;
                if ((_i3 div _le) mod 2 == 1 && _sd4 < 0) continue;
                var _off5 = _c.hw + _c.runoff + 8;
                array_push(_L.lamps, { x: _c.px[_i3] + _c.nx[_i3] * _sd4 * _off5, y: _c.py[_i3] + _c.ny[_i3] * _sd4 * _off5, side: _sd4, i: _i3 });
            }
        }
    }
    // buildings (city themes): axis-aligned blocks on free cells
    if (_T.name == "street" || _T.name == "nightcity" || _T.name == "harbour") {
        var _want = (_T.name == "harbour") ? 40 : 90;
        for (var _t = 0; _t < _want * 6 && array_length(_L.buildings) < _want; _t++) {
            var _bw = chc_range(_g, 70, 230), _bh = chc_range(_g, 70, 200);
            var _bx2 = chc_range(_g, 0, _c.worldW), _by2 = chc_range(_g, 0, _c.worldH);
            var _bpts2 = chc__rect_pts(_bx2, _by2, 0, _bw + 24, _bh + 24);
            if (!chc__occ_fits(_o, _bpts2)) continue;
            chc__occ_mark(_o, chc__rect_pts(_bx2, _by2, 0, _bw, _bh), 2);
            array_push(_L.buildings, { x: _bx2, y: _by2, w: _bw, h: _bh, tone: chc_rand(_g), roof: floor(chc_rand(_g) * 4), lit: chc_rand(_g) });
        }
    }
    // dunes and rocks (desert), then trees for every theme by its own density and species
    if (_T.name == "desert") {
        repeat (26) {
            var _dx = chc_range(_g, 0, _c.worldW), _dy = chc_range(_g, 0, _c.worldH);
            if (chc__occ_get(_o, _dx, _dy) != 0) continue;
            array_push(_L.dunes, { x: _dx, y: _dy, r: chc_range(_g, 90, 240), ang: chc_range(_g, -0.4, 0.4) });
        }
        repeat (70) {
            var _rx = chc_range(_g, 0, _c.worldW), _ry = chc_range(_g, 0, _c.worldH);
            if (chc__occ_get(_o, _rx, _ry) == 0) array_push(_L.rocks, { x: _rx, y: _ry, r: chc_range(_g, 6, 22), seed: floor(chc_rand(_g) * 100000) });
        }
    }
    var _density = 140, _kind = "broadleaf";
    switch (_T.name) {
        case "forest": _density = 520; _kind = "broadleaf"; break;
        case "snow": _density = 300; _kind = "pine"; break;
        case "desert": _density = 46; _kind = "palm"; break;
        case "harbour": _density = 50; _kind = "palm"; break;
        case "street": _density = 60; _kind = "broadleaf"; break;
        case "nightcity": _density = 26; _kind = "broadleaf"; break;
        case "kart": _density = 90; _kind = "broadleaf"; break;
    }
    var _clusterN = max(3, floor(_density / 14));
    var _cxs = [], _cys = [];
    repeat (_clusterN) { array_push(_cxs, chc_range(_g, 0, _c.worldW)); array_push(_cys, chc_range(_g, 0, _c.worldH)); }
    for (var _t = 0; _t < _density * 5 && array_length(_L.trees) < _density; _t++) {
        var _tx, _ty;
        if (chc_rand(_g) < 0.7) { var _ci = floor(chc_rand(_g) * _clusterN); _tx = _cxs[_ci] + chc_range(_g, -180, 180); _ty = _cys[_ci] + chc_range(_g, -180, 180); }
        else { _tx = chc_range(_g, 0, _c.worldW); _ty = chc_range(_g, 0, _c.worldH); }
        var _tr = chc_range(_g, 14, 30) * ((_kind == "pine") ? 0.8 : 1);
        if (chc__occ_get(_o, _tx, _ty) != 0 || chc__occ_get(_o, _tx + _tr, _ty) != 0 || chc__occ_get(_o, _tx - _tr, _ty) != 0 || chc__occ_get(_o, _tx, _ty + _tr) != 0 || chc__occ_get(_o, _tx, _ty - _tr) != 0) continue;
        var _kd = _kind;
        if (_T.name == "desert" && chc_rand(_g) < 0.45) _kd = "cactus";
        if (_T.name == "forest" && chc_rand(_g) < 0.3) _kd = "pine";
        array_push(_L.trees, { x: _tx, y: _ty, r: _tr, kind: _kd, tone: chc_rand(_g), seed: floor(chc_rand(_g) * 100000) });
    }
    array_sort(_L.trees, function(_a, _b) { return (_a.y > _b.y) ? 1 : ((_a.y < _b.y) ? -1 : 0); });
    _L.occ = _o;
    _c.layout = _L;
}

// ------------------------------------------------------------------------------------------------ the track query

/// @function chc__project(c, x, y, hint, out)
/// @description Internal. Nearest centreline sample (a local search round `hint`, a coarse global search when that is
/// far), then the arc position and the signed lateral offset. Writes out.i, out.s, out.d.
function chc__project(_c, _x, _y, _hint, _out) {
    var _n = _c.n, _bi = -1, _bd = 1000000000000;
    if (is_numeric(_hint) && _hint >= 0) {
        for (var _o = -24; _o <= 24; _o++) {
            var _i = chc__wrap(_hint + _o, _n);
            var _dx = _x - _c.px[_i], _dy = _y - _c.py[_i];
            var _dd = _dx * _dx + _dy * _dy;
            if (_dd < _bd) { _bd = _dd; _bi = _i; }
        }
    }
    var _far = _c.hw + _c.runoff + 40;
    if (_bi < 0 || _bd > _far * _far) {
        var _gi = 0, _gd = 1000000000000;
        for (var _i = 0; _i < _n; _i += 4) {
            var _dx = _x - _c.px[_i], _dy = _y - _c.py[_i];
            var _dd = _dx * _dx + _dy * _dy;
            if (_dd < _gd) { _gd = _dd; _gi = _i; }
        }
        for (var _o = -4; _o <= 4; _o++) {
            var _i = chc__wrap(_gi + _o, _n);
            var _dx = _x - _c.px[_i], _dy = _y - _c.py[_i];
            var _dd = _dx * _dx + _dy * _dy;
            if (_dd < _bd || _bi < 0) { _bd = _dd; _bi = _i; }
        }
    }
    var _dx2 = _x - _c.px[_bi], _dy2 = _y - _c.py[_bi];
    var _s = _c.s[_bi] + _dx2 * _c.tx[_bi] + _dy2 * _c.ty[_bi];
    if (_s < 0) _s += _c.length;
    if (_s >= _c.length) _s -= _c.length;
    _out.i = _bi; _out.s = _s; _out.d = _dx2 * _c.nx[_bi] + _dy2 * _c.ny[_bi];
}

/// @function chc__surface_of(c, i, d)
/// @description Internal. 0 road, 1 kerb or edge, 2 run-off, 3 past the barrier.
function chc__surface_of(_c, _i, _d) {
    var _a = abs(_d);
    if (_a <= _c.hw) return 0;
    if (_a <= _c.hw + 10) return 1;
    if (_a <= _c.hw + _c.runoff) return 2;
    return 3;
}

/// @function chc_track_query(circuit, x, y, [hint])
/// @description Where a room point is on the circuit. Pass the previous answer's `i` as hint to make it a local search.
/// @returns {Struct} { i: nearest sample, s: arc position 0..length, d: signed offset from the centreline (+ is the left
///   of the direction of travel), surface: "road", "kerb", "runoff" or "barrier", onTrack: bool }. A non-circuit returns
///   undefined.
function chc_track_query(_c, _x, _y, _hint = -1) {
    if (!is_struct(_c) || !variable_struct_exists(_c, "px") || !is_numeric(_x) || !is_numeric(_y)) return undefined;
    var _q = { i: 0, s: 0, d: 0 };
    chc__project(_c, _x, _y, is_numeric(_hint) ? _hint : -1, _q);
    var _sf = chc__surface_of(_c, _q.i, _q.d);
    var _names = ["road", "kerb", "runoff", "barrier"];
    _q.surface = _names[_sf];
    _q.onTrack = _sf <= 1;
    return _q;
}

/// @function chc_track_point(circuit, s, [d])
/// @description The room point at arc position s and lateral offset d (+ left), and the heading there.
/// @returns {Struct} { x, y, ang, i }
function chc_track_point(_c, _s, _d = 0) {
    if (!is_struct(_c) || !variable_struct_exists(_c, "px") || !is_numeric(_s)) return { x: 0, y: 0, ang: 0, i: 0 };
    if (!is_numeric(_d)) _d = 0;
    var _ss = _s - floor(_s / _c.length) * _c.length;
    var _f = _ss / _c.step, _i = floor(_f) mod _c.n, _j = (_i + 1) mod _c.n, _t = _f - floor(_f);
    var _x = lerp(_c.px[_i], _c.px[_j], _t) + lerp(_c.nx[_i], _c.nx[_j], _t) * _d;
    var _y = lerp(_c.py[_i], _c.py[_j], _t) + lerp(_c.ny[_i], _c.ny[_j], _t) * _d;
    return { x: _x, y: _y, ang: arctan2(lerp(_c.ty[_i], _c.ty[_j], _t), lerp(_c.tx[_i], _c.tx[_j], _t)), i: _i };
}

// ------------------------------------------------------------------------------------------------ liveries

/// @function chc_livery_create(seed)
/// @description A generated livery: two team colours and an accent, one of six patterns (plain, twin stripes, side band,
/// chevron, halves, sash), a race number and a helmet colour.
/// @returns {Struct} { primary, secondary, accent, helmet (colours), pattern 0..5, number 1..99, seed }
function chc_livery_create(_seed) {
    if (!is_numeric(_seed)) _seed = 1;
    var _g = chc_rng(floor(_seed) * 271 + 91);
    var _pal = chc__team_colours();
    var _np = array_length(_pal);
    var _a = floor(chc_rand(_g) * _np);
    var _b = floor(chc_rand(_g) * (_np - 1));
    if (_b >= _a) _b++;
    // the secondary must stand off the primary in lightness, or the pattern reads as a smudge
    var _tries = 0;
    while (abs(colour_get_value(_pal[_a]) - colour_get_value(_pal[_b])) < 60 && _tries < 12) { _b = (_b + 1) mod _np; if (_b == _a) _b = (_b + 1) mod _np; _tries++; }
    var _c = floor(chc_rand(_g) * _np);
    var _pat = floor(chc_rand(_g) * 6);
    var _num = 1 + floor(chc_rand(_g) * 99);
    var _h = floor(chc_rand(_g) * _np);
    return { primary: _pal[_a], secondary: _pal[_b], accent: _pal[_c], helmet: _pal[_h], pattern: _pat, number: _num, seed: floor(_seed) };
}

/// @function chc__team_colours()
/// @description Internal. Sixteen team colours.
function chc__team_colours() {
    return [make_colour_rgb(214, 38, 42), make_colour_rgb(28, 78, 196), make_colour_rgb(250, 204, 38), make_colour_rgb(22, 150, 84),
            make_colour_rgb(246, 124, 26), make_colour_rgb(240, 240, 236), make_colour_rgb(26, 26, 30), make_colour_rgb(18, 168, 172),
            make_colour_rgb(124, 58, 196), make_colour_rgb(236, 92, 168), make_colour_rgb(170, 176, 186), make_colour_rgb(18, 34, 84),
            make_colour_rgb(150, 210, 40), make_colour_rgb(128, 22, 40), make_colour_rgb(98, 186, 238), make_colour_rgb(206, 160, 56)];
}

/// @function chc__codes()
/// @description Internal. Driver codes for the tower (invented; none is a real driver's).
function chc__codes() { return ["VAL", "KOR", "MEN", "SUN", "RIV", "HAL", "OKA", "BRE", "LUN", "DAX", "TOR", "NYX", "PAZ", "QUI", "WEX", "ZOL", "IBA", "CAS", "JUN", "MIR", "EST", "LEO", "RAK", "FIN"]; }

// ------------------------------------------------------------------------------------------------ the race

/// @function chc_race_create(circuit, [opts])
/// @description A race on a circuit: cars on the grid, the start lights, gates, laps, sectors, positions.
/// @param {Struct} circuit  from chc_circuit_create
/// @param {Struct} [opts]  { cars: 8 (1..12), laps: 3 (1..99), seed: 1, body: the theme's, player: -1 (a car index the
///   game drives through chc_car_input, or -1 for none), cutRule: "refuse" (a gate passed on the inside of a corner
///   beyond the kerb is not credited until it is passed properly) or "penalty" (credited, plus `penalty` seconds),
///   penalty: 3, lights: true (a five-light start; false starts at once), skills: an array of AI skills 0.8..1 }
/// @returns {Struct} the race; read cars[k].x/y/ang/speed/lap/position, and events after each chc_race_step.
function chc_race_create(_c, _opts = undefined) {
    if (!is_struct(_c) || !variable_struct_exists(_c, "gates")) return undefined;
    var _nc = 8, _laps = 3, _seed = 1, _body = _c.T.body, _player = -1, _rule = "refuse", _pen = 3, _lights = true, _skills = undefined;
    if (is_struct(_opts)) {
        if (variable_struct_exists(_opts, "cars") && is_numeric(_opts.cars)) _nc = clamp(floor(_opts.cars), 1, 12);
        if (variable_struct_exists(_opts, "laps") && is_numeric(_opts.laps)) _laps = clamp(floor(_opts.laps), 1, 99);
        if (variable_struct_exists(_opts, "seed") && is_numeric(_opts.seed)) _seed = floor(_opts.seed);
        if (variable_struct_exists(_opts, "body") && is_string(_opts.body)) _body = chc_body(_opts.body).name;
        if (variable_struct_exists(_opts, "player") && is_numeric(_opts.player)) _player = floor(_opts.player);
        if (variable_struct_exists(_opts, "cutRule") && _opts.cutRule == "penalty") _rule = "penalty";
        if (variable_struct_exists(_opts, "penalty") && is_numeric(_opts.penalty)) _pen = clamp(_opts.penalty, 0, 60);
        if (variable_struct_exists(_opts, "lights") && is_bool(_opts.lights)) _lights = _opts.lights;
        if (variable_struct_exists(_opts, "skills") && is_array(_opts.skills)) _skills = _opts.skills;
    }
    var _g = chc_rng(_seed * 31 + _c.seed);
    var _B = chc_body(_body);
    chc__profile(_c, _B);
    var _codes = chc__codes(), _cars = [];
    for (var _k = 0; _k < _nc; _k++) {
        var _gs = _c.grid[_k];
        var _sk = chc_range(_g, 0.9, 0.985);
        if (!is_undefined(_skills) && _k < array_length(_skills) && is_numeric(_skills[_k])) _sk = clamp(_skills[_k], 0.6, 1);
        var _wob = chc_range(_g, 0, 6.28);
        var _def = chc_rand(_g) < 0.45;
        var _liv = chc_livery_create(_seed * 97 + _k * 13 + _c.seed);
        array_push(_cars, { id: _k, body: _B.name, B: _B, x: _gs.x, y: _gs.y, vx: 0, vy: 0, ang: _gs.ang, idx: _gs.i, s: _gs.s, d: _gs.d,
            skill: _sk, lap: 0, credits: 0, nextGate: 0, finished: false, finishT: 0, lapStart: 0, laps: [], creditT: [],
            contacts: 0, cuts: 0, penalty: 0, missed: 0, missedGate: -1, cutWarn: 0, walls: 0, wrongWay: false,
            thr: 0, brk: 0, steer: 0, slip: 0, speed: 0, ai: (_k != _player), avoid: _gs.d, wob: _wob, defend: _def, passSide: 0,
            tow: false, stuck: 0, recover: 0, sectorStart: 0, sectors: [-1, -1, -1], lastSectors: [-1, -1, -1], bestSectors: [-1, -1, -1],
            bestLap: -1, lastLap: -1, livery: _liv, code: _codes[chc__wrap(_k + _seed * 5, array_length(_codes))], position: _k + 1,
            sprite: -1, rx: 0, ry: 0, lx: 0, ly: 0, skidOn: false });
    }
    var _r = { c: _c, cars: _cars, t: 0, laps: _laps, G: CHC_GATES, gates: _c.gates, contacts: 0, passes: 0, events: [], g: _g,
               cutRule: _rule, penaltyS: _pen, player: _player, state: (_lights ? "lights" : "race"), lightT: 0,
               lightsOut: (_lights ? chc_range(_g, 3.2, 3.9) : 0), raceT: 0, bestLap: -1, bestLapCar: -1,
               bestSector: [-1, -1, -1], touching: {}, finishedCount: 0, steps: 0, q: { i: 0, s: 0, d: 0 }, order: [] };
    _r.order = chc_race_standings(_r);
    return _r;
}

/// @function chc_car_input(race, car, throttle, brake, steer)
/// @description Drive one car yourself (turns its AI off): throttle 0..1 (negative = reverse), brake 0..1, steer -1..1
/// (+1 turns toward +y of the car's heading, i.e. clockwise on screen).
function chc_car_input(_r, _k, _thr, _brk, _steer) {
    if (!is_struct(_r) || !variable_struct_exists(_r, "cars") || !is_numeric(_k) || _k < 0 || _k >= array_length(_r.cars)) return false;
    var _car = _r.cars[_k];
    _car.ai = false;
    _car.thr = is_numeric(_thr) ? clamp(_thr, -1, 1) : 0;
    _car.brk = is_numeric(_brk) ? clamp(_brk, 0, 1) : 0;
    _car.steer = is_numeric(_steer) ? clamp(_steer, -1, 1) : 0;
    return true;
}

/// @function chc_car_set_ai(race, car, on)
/// @description Hand a car to the AI driver (true) or back to chc_car_input (false).
function chc_car_set_ai(_r, _k, _on) {
    if (!is_struct(_r) || !variable_struct_exists(_r, "cars") || !is_numeric(_k) || _k < 0 || _k >= array_length(_r.cars)) return false;
    _r.cars[_k].ai = is_bool(_on) ? _on : true;
    return true;
}

/// @function chc__ai(r, car, dt)
/// @description Internal. One AI driver: pure pursuit on the racing line (plus a skill wobble), a speed target from the
/// profile scaled by skill, pulling out to pass a slower car on the side with room, holding a lane beside a car, covering
/// the inside when an attacker sits in the tow, and backing out when stuck.
function chc__ai(_r, _car, _dt) {
    var _c = _r.c, _n = _c.n, _B = _car.B, _prof = chc__profile(_c, _B).v;
    var _v = chc__hyp(_car.vx, _car.vy);
    if (_r.state != "race") { _car.thr = 0; _car.brk = 1; _car.steer = 0; return; }
    if (_car.recover > 0) {
        _car.recover -= _dt;
        _car.thr = -0.7; _car.brk = 0; _car.steer = -_car.steer;
        if (_car.recover <= 0) _car.stuck = 0;
        return;
    }
    if (_v < 15 && _r.raceT > 4) { _car.stuck += _dt; if (_car.stuck > 2.5) { _car.recover = 1.1; _car.steer = (_car.d > 0) ? 1 : -1; return; } } else _car.stuck = 0;
    var _look = 30 + _v * 0.30;
    var _si = (_car.idx + floor(_look / _c.step + 0.5)) mod _n;
    var _want = _c.line[_si] + sin(_r.t * 0.7 + _car.wob) * (1 - _car.skill) * 18;
    var _vcap = 1000000000;
    var _hadSide = _car.passSide; _car.passSide = 0;
    var _L = _c.length;
    for (var _m = 0; _m < array_length(_r.cars); _m++) {
        var _o = _r.cars[_m];
        if (_o == _car) continue;
        var _ds = _o.s - _car.s;
        if (_ds < -_L / 2) _ds += _L;
        if (_ds > _L / 2) _ds -= _L;
        if (_ds <= -70 || _ds > 110) continue;
        var _dd = _o.d - _car.d;
        var _lane = (_B.wid + _o.B.wid) * 0.62;
        if (abs(_dd) > _lane * 1.05) continue;
        var _ov = chc__hyp(_o.vx, _o.vy);
        if (_r.raceT < 3) { if (_ds > 0 && abs(_dd) < _lane * 0.9 && _ds < _B.len * 2.6) _vcap = min(_vcap, _ov); continue; }
        if (_ds > 0) {
            var _roomL = _c.hw - (_o.d + _lane), _roomR = (_o.d - _lane) + _c.hw;
            var _side = _hadSide;
            if (_side == 0 || (_side > 0 && _roomL <= 2) || (_side < 0 && _roomR <= 2)) _side = (_roomL >= _roomR) ? 1 : -1;
            if ((_side > 0 && _roomL > 2) || (_side < 0 && _roomR > 2)) { _want = (_side > 0) ? _o.d + _lane : _o.d - _lane; _car.passSide = _side; }
            if (abs(_dd) < _lane * 0.95 && _ds < _B.len * 1.25) _vcap = min(_vcap, _ov);
        } else {
            if (_ds > -_B.len * 0.6) {
                var _tgt = (_dd > 0) ? _o.d - _lane : _o.d + _lane;
                if (abs(_tgt) <= _c.hw - _B.wid * 0.6) _want = _tgt; else _vcap = min(_vcap, _ov * 0.96);
            } else if (_car.defend && abs(_dd) < _lane * 0.5) {
                var _ki = (_car.idx + floor(220 / _c.step + 0.5)) mod _n;
                _want = _want + sign(_c.k[_ki]) * _lane * 0.4;
            }
        }
    }
    var _lim = _c.hw - _B.wid * 0.6;
    _want = clamp(_want, -_lim, _lim);
    _car.avoid += (_want - _car.avoid) * min(1, _dt * 5);
    var _tx = _c.px[_si] + _c.nx[_si] * _car.avoid, _ty = _c.py[_si] + _c.ny[_si] * _car.avoid;
    var _da = arctan2(_ty - _car.y, _tx - _car.x) - _car.ang;
    while (_da > pi) _da -= pi * 2;
    while (_da < -pi) _da += pi * 2;
    var _Ld = max(12, chc__hyp(_tx - _car.x, _ty - _car.y));
    _car.steer = clamp(((2 * sin(_da)) / _Ld) * (_B.len * 1.9), -1, 1);
    var _pi2 = (_car.idx + floor((6 + _v * 0.05) / _c.step + 0.5)) mod _n;
    var _target = min(_vcap, _prof[_pi2] * _car.skill);
    // a target near zero (a stopped car nose to tail ahead) means STOP: the coasting branch's 35% throttle crept forward
    // into a stalled car on the grid (found by the buyer harness: car 0 left on the grid was nudged by the car behind)
    if (_v < _target - 6) { _car.thr = 1; _car.brk = 0; }
    else if (_v > _target + 10 || (_target < 20 && _v > 1)) { _car.thr = 0; _car.brk = min(1, max(0.5, (_v - _target) / 60)); }
    else { _car.thr = (_target < 20) ? 0 : 0.35; _car.brk = 0; }
}

/// @function chc__car_step(r, car, dt)
/// @description Internal. The car model: engine on its real curve (with a tow behind another car), brakes, surface grip and
/// drag, a grip-capped yaw from the steering, lateral sliding resolved by grip (the slip drives the skid marks), the
/// barrier (pushed back, normal speed reflected), then the gates.
function chc__car_step(_r, _car, _dt) {
    var _c = _r.c, _B = _car.B, _q = _r.q, _L = _c.length;
    var _fx = cos(_car.ang), _fy = sin(_car.ang);
    chc__project(_c, _car.x, _car.y, _car.idx, _q);
    var _sf = chc__surface_of(_c, _q.i, _q.d);
    var _mu = 0.5, _drag = 1.6;
    if (_sf == 0) { _mu = 1.0; _drag = 0; } else if (_sf == 1) { _mu = 0.9; _drag = 0.25; }
    _mu *= _c.grip;
    var _vl = _car.vx * _fx + _car.vy * _fy, _vt = -_car.vx * _fy + _car.vy * _fx;
    var _tow = 1;
    for (var _m = 0; _m < array_length(_r.cars); _m++) {
        var _o = _r.cars[_m];
        if (_o == _car) continue;
        var _ds = _o.s - _car.s;
        if (_ds < -_L / 2) _ds += _L;
        if (_ds > _L / 2) _ds -= _L;
        if (_ds > 18 && _ds < 150 && abs(_o.d - _car.d) < 22) { _tow = 1.08; break; }
    }
    _car.tow = (_tow > 1);
    var _acc;
    if (_car.thr >= 0) _acc = _car.thr * _B.aEng * _tow * max(0, 1 - _vl / (_B.vTop * _tow)) - _drag * _vl;
    else _acc = (_vl > -80) ? _car.thr * _B.aEng * 0.4 : 0;
    if (_car.brk > 0) { var _dec = _car.brk * _B.aBrake * _dt; if (abs(_vl) <= _dec) _vl = 0; else _vl -= sign(_vl) * _dec; }
    _vl += _acc * _dt;
    var _yawCap = (_B.aLat * _mu * 1.25) / max(60, abs(_vl));
    var _yaw = clamp((_car.steer * _vl) / (_B.len * 1.9), -_yawCap, _yawCap);
    _car.ang += _yaw * _dt;
    var _vx = _fx * _vl - _fy * _vt, _vy = _fy * _vl + _fx * _vt;
    _fx = cos(_car.ang); _fy = sin(_car.ang);
    _vl = _vx * _fx + _vy * _fy; _vt = -_vx * _fy + _vy * _fx;
    var _cap = _B.aLat * _mu * _dt;
    _car.slip = abs(_vt);
    if (abs(_vt) <= _cap) _vt = 0; else _vt -= sign(_vt) * _cap;
    _car.vx = _fx * _vl - _fy * _vt; _car.vy = _fy * _vl + _fx * _vt;
    _car.x += _car.vx * _dt; _car.y += _car.vy * _dt;
    chc__project(_c, _car.x, _car.y, _q.i, _q);
    var _bar = _c.hw + _c.runoff - _B.wid * 0.5;
    if (abs(_q.d) > _bar) {
        var _sg = sign(_q.d), _push = abs(_q.d) - _bar;
        _car.x -= _c.nx[_q.i] * _sg * _push; _car.y -= _c.ny[_q.i] * _sg * _push;
        var _vn = _car.vx * _c.nx[_q.i] + _car.vy * _c.ny[_q.i];
        if (_vn * _sg > 0) { _car.vx -= _c.nx[_q.i] * _vn * 1.3; _car.vy -= _c.ny[_q.i] * _vn * 1.3; }
        _car.vx *= 0.92; _car.vy *= 0.92; _car.walls++;
    }
    var _prevS = _car.s;
    chc__project(_c, _car.x, _car.y, _q.i, _q);
    _car.idx = _q.i; _car.s = _q.s; _car.d = _q.d;
    _car.speed = chc__hyp(_car.vx, _car.vy);
    _car.wrongWay = (_car.speed > 40) && ((_car.vx * _c.tx[_q.i] + _car.vy * _c.ty[_q.i]) < -0.5 * _car.speed);
    // the rear axle, for skid marks
    _car.lx = _car.rx; _car.ly = _car.ry;
    _car.rx = _car.x - cos(_car.ang) * _B.len * 0.32; _car.ry = _car.y - sin(_car.ang) * _B.len * 0.32;
    _car.skidOn = _car.slip > 26 || (_car.brk > 0.7 && _car.speed > 120);
    chc__gate_check(_r, _car, _prevS, _q);
    if (_car.cutWarn > 0) _car.cutWarn -= _dt;
}

/// @function chc__gate_check(r, car, prevS, q)
/// @description Internal. Credit the car's next gate when it is crossed going forward. A crossing on the INSIDE of a
/// corner beyond the kerb, or a jump of more than 120 px along the line, is a CUT: under "refuse" the gate stays owed;
/// under "penalty" it is credited and the penalty added. Running wide is never a cut.
function chc__gate_check(_r, _car, _prevS, _q) {
    var _c = _r.c, _L = _c.length;
    var _delta = _q.s - _prevS;
    if (_delta < -_L / 2) _delta += _L;
    if (_delta > _L / 2) _delta -= _L;
    if (_delta <= 0) return;
    var _gs = _r.gates[_car.nextGate];
    var _rel = _gs - _prevS;
    if (_rel < 0) _rel += _L;
    if (_rel > _delta) return;
    var _gi = floor(_gs / _c.step + 0.5) mod _c.n, _kg = _c.k[_gi];
    var _inside = (abs(_kg) > 1 / (_c.width * 6)) ? sign(_kg) : 0;
    var _legal = _delta < 120 && abs(_q.d) <= _c.hw + _c.runoff + 4 && !(_inside != 0 && _q.d * _inside > _c.hw + 12);
    if (!_legal) {
        _car.missed++; _car.cutWarn = 2.5;
        if (_r.cutRule == "refuse") { _car.missedGate = _car.nextGate; array_push(_r.events, { type: "cut", car: _car.id, gate: _car.nextGate }); return; }
        _car.cuts++; _car.penalty += _r.penaltyS;
        array_push(_r.events, { type: "penalty", car: _car.id, gate: _car.nextGate, seconds: _r.penaltyS });
    }
    _car.missedGate = -1;
    _car.credits++;
    array_push(_car.creditT, _r.raceT);
    var _g = _car.nextGate, _third = _r.G div 3;
    if (_g == _third || _g == _third * 2 || _g == 0) {
        var _sec = (_g == 0) ? 2 : ((_g == _third) ? 0 : 1);
        if (_car.lap > 0) {
            var _st = _r.raceT - _car.sectorStart;
            _car.sectors[_sec] = _st;
            if (_car.bestSectors[_sec] < 0 || _st < _car.bestSectors[_sec]) _car.bestSectors[_sec] = _st;
            if (_r.bestSector[_sec] < 0 || _st < _r.bestSector[_sec]) _r.bestSector[_sec] = _st;
        }
        _car.sectorStart = _r.raceT;
    }
    if (_g == 0) {
        if (_car.lap > 0) {
            var _lt = _r.raceT - _car.lapStart;
            array_push(_car.laps, _lt);
            _car.lastLap = _lt;
            _car.lastSectors = [_car.sectors[0], _car.sectors[1], _car.sectors[2]];
            _car.sectors = [-1, -1, -1];
            if (_car.bestLap < 0 || _lt < _car.bestLap) _car.bestLap = _lt;
            if (_r.bestLap < 0 || _lt < _r.bestLap) { _r.bestLap = _lt; _r.bestLapCar = _car.id; array_push(_r.events, { type: "fastest", car: _car.id, time: _lt }); }
            array_push(_r.events, { type: "lap", car: _car.id, lap: _car.lap, time: _lt });
        }
        _car.lap++;
        _car.lapStart = _r.raceT;
        if (_car.lap > _r.laps && !_car.finished) {
            _car.finished = true; _car.finishT = _r.raceT + _car.penalty; _r.finishedCount++;
            array_push(_r.events, { type: "finish", car: _car.id, position: _r.finishedCount, time: _car.finishT });
        }
    }
    _car.nextGate = (_car.nextGate + 1) mod _r.G;
}

/// @function chc__collide(r)
/// @description Internal. Car-to-car: each car is two circles along its axis; overlaps are pushed apart and the closing
/// speed exchanged with restitution 0.35. A CONTACT is a touch that BEGINS this frame with real closing speed.
function chc__collide(_r) {
    var _cs = _r.cars, _nc = array_length(_cs);
    for (var _a = 0; _a < _nc; _a++) for (var _b = _a + 1; _b < _nc; _b++) {
        var _A = _cs[_a], _Bc = _cs[_b];
        var _dx0 = _Bc.x - _A.x, _dy0 = _Bc.y - _A.y;
        var _key = string(_a * 64 + _b);
        if (_dx0 * _dx0 + _dy0 * _dy0 > 3600) { _r.touching[$ _key] = false; continue; }
        var _hit = false, _touch = false;
        var _oa = _A.B.len * 0.27, _ob = _Bc.B.len * 0.27, _ra = _A.B.wid * 0.55, _rb = _Bc.B.wid * 0.55;
        for (var _p = -1; _p <= 1; _p += 2) for (var _qq = -1; _qq <= 1; _qq += 2) {
            var _ax = _A.x + cos(_A.ang) * _oa * _p, _ay = _A.y + sin(_A.ang) * _oa * _p;
            var _bx = _Bc.x + cos(_Bc.ang) * _ob * _qq, _by = _Bc.y + sin(_Bc.ang) * _ob * _qq;
            var _dx = _bx - _ax, _dy = _by - _ay, _dd = chc__hyp(_dx, _dy), _mm = _ra + _rb;
            if (_dd >= _mm || _dd < 0.000001) continue;
            _touch = true;
            var _nx = _dx / _dd, _ny = _dy / _dd, _pen = (_mm - _dd) / 2;
            _A.x -= _nx * _pen; _A.y -= _ny * _pen; _Bc.x += _nx * _pen; _Bc.y += _ny * _pen;
            var _rv = (_Bc.vx - _A.vx) * _nx + (_Bc.vy - _A.vy) * _ny;
            if (_rv < 0) { var _j = -_rv * 0.65; _A.vx -= _nx * _j; _A.vy -= _ny * _j; _Bc.vx += _nx * _j; _Bc.vy += _ny * _j; if (-_rv > 25) _hit = true; }
        }
        var _was = variable_struct_exists(_r.touching, _key) && _r.touching[$ _key];
        if (_hit && !_was) { _A.contacts++; _Bc.contacts++; _r.contacts++; array_push(_r.events, { type: "contact", car: _a, other: _b }); }
        _r.touching[$ _key] = _touch;
    }
}

/// @function chc_race_step(race, dt)
/// @description Advance the race by dt seconds (sub-stepped at 1/60 s or finer). Clears and refills race.events: "lights",
/// "go", "lap", "fastest", "finish", "cut", "penalty", "contact", each with the car index. Positions are updated.
/// @returns {Array} race.events
function chc_race_step(_r, _dt) {
    if (!is_struct(_r) || !variable_struct_exists(_r, "cars")) return [];
    _r.events = [];
    if (!is_numeric(_dt) || _dt <= 0) return _r.events;
    _dt = min(_dt, 0.1);
    var _subs = max(1, ceil(_dt / (1 / 60) - 0.0001)), _h = _dt / _subs;
    repeat (_subs) {
        _r.t += _h; _r.steps++;
        if (_r.state == "lights") {
            var _before = floor(_r.lightT / 0.5);
            _r.lightT += _h;
            if (floor(_r.lightT / 0.5) != _before && _r.lightT < 2.75) array_push(_r.events, { type: "lights", car: -1, lit: min(5, floor(_r.lightT / 0.5)) });
            if (_r.lightT >= _r.lightsOut) { _r.state = "race"; array_push(_r.events, { type: "go", car: -1 }); }
        } else _r.raceT += _h;
        for (var _k = 0; _k < array_length(_r.cars); _k++) { var _car = _r.cars[_k]; if (_car.ai) chc__ai(_r, _car, _h); else if (_r.state != "race") { _car.thr = 0; } }
        for (var _k = 0; _k < array_length(_r.cars); _k++) chc__car_step(_r, _r.cars[_k], _h);
        chc__collide(_r);
    }
    var _old = _r.order;
    _r.order = chc_race_standings(_r);
    for (var _p = 0; _p < array_length(_r.order); _p++) {
        var _car2 = _r.cars[_r.order[_p]];
        if (_r.raceT > 6 && _p + 1 < _car2.position) _r.passes += _car2.position - (_p + 1);
        _car2.position = _p + 1;
    }
    return _r.events;
}

/// @function chc_race_progress(race, car)
/// @description How far a car has come, in px of credited track (finished cars sort above everyone).
function chc_race_progress(_r, _k) {
    if (!is_struct(_r) || !variable_struct_exists(_r, "cars") || !is_numeric(_k) || _k < 0 || _k >= array_length(_r.cars)) return 0;
    var _car = _r.cars[_k], _c = _r.c, _gsp = _c.length / _r.G;
    if (_car.finished) return 1000000000 - _car.finishT;
    if (_car.credits == 0) { var _back = _c.length - _car.s; if (_back > _c.length / 2) _back = 0; return -_back; }
    var _lastS = _r.gates[chc__wrap(_car.nextGate - 1, _r.G)];
    var _fw = _car.s - _lastS;
    if (_fw < 0) _fw += _c.length;
    if (_fw > _gsp * 1.5) _fw = 0;
    return _car.credits * _gsp + _fw;
}

/// @function chc_race_standings(race)
/// @description Car indices in race order: finished cars by finishing time (penalties included), then everyone else by
/// credited progress. A car that owes a refused gate stops gaining until it takes it.
/// @returns {Array<Real>}
function chc_race_standings(_r) {
    if (!is_struct(_r) || !variable_struct_exists(_r, "cars")) return [];
    var _rows = [];
    for (var _k = 0; _k < array_length(_r.cars); _k++) array_push(_rows, { k: _k, p: chc_race_progress(_r, _k) });
    array_sort(_rows, function(_a, _b) { if (_a.p == _b.p) return _a.k - _b.k; return (_b.p > _a.p) ? 1 : -1; });
    var _o = [];
    for (var _i = 0; _i < array_length(_rows); _i++) array_push(_o, _rows[_i].k);
    return _o;
}

/// @function chc_race_gap(race, car)
/// @description The car's gap to the leader in seconds, timed at the last gate both have crossed (0 for the leader, -1
/// while unknown).
function chc_race_gap(_r, _k) {
    if (!is_struct(_r) || !variable_struct_exists(_r, "cars") || !is_numeric(_k) || _k < 0 || _k >= array_length(_r.cars)) return -1;
    if (array_length(_r.order) == 0) return -1;
    var _lead = _r.cars[_r.order[0]], _car = _r.cars[_k];
    if (_lead == _car) return 0;
    var _n = array_length(_car.creditT);
    if (_n == 0 || _n > array_length(_lead.creditT)) return -1;
    return _car.creditT[_n - 1] - _lead.creditT[_n - 1] + (_car.penalty - _lead.penalty);
}

/// @function chc_race_sim(circuit, [opts])
/// @description Run a whole race headless with every car on AI and no lights - the tuning harness. Same opts as
/// chc_race_create, plus tmax (seconds, 400).
/// @returns {Struct} { finished, cars, contacts, passes, walls, cuts, spread (best-lap spread, s), bestLap, time, steps, ms }
function chc_race_sim(_c, _opts = undefined) {
    var _o = is_struct(_opts) ? _opts : {};
    var _cfg = { cars: 8, laps: 3, seed: 1, lights: false, player: -1 };
    var _names = variable_struct_get_names(_o);
    for (var _i = 0; _i < array_length(_names); _i++) _cfg[$ _names[_i]] = _o[$ _names[_i]];
    _cfg.lights = false; _cfg.player = -1;
    var _tmax = (variable_struct_exists(_o, "tmax") && is_numeric(_o.tmax)) ? _o.tmax : 400;
    var _r = chc_race_create(_c, _cfg);
    if (is_undefined(_r)) return undefined;
    var _t0 = get_timer();
    while (_r.t < _tmax) {
        chc_race_step(_r, 1 / 60);
        if (_r.finishedCount >= array_length(_r.cars)) break;
    }
    var _best = 1000000, _worst = 0, _walls = 0, _cuts = 0;
    for (var _k = 0; _k < array_length(_r.cars); _k++) {
        var _car = _r.cars[_k];
        _walls += _car.walls; _cuts += _car.missed;
        if (_car.bestLap > 0) { _best = min(_best, _car.bestLap); _worst = max(_worst, _car.bestLap); }
    }
    return { finished: _r.finishedCount, cars: array_length(_r.cars), contacts: _r.contacts, passes: _r.passes, walls: _walls, cuts: _cuts,
             spread: _worst - _best, bestLap: _best, time: _r.t, steps: _r.steps, ms: (get_timer() - _t0) / 1000, race: _r };
}

/// @function chc_race_free(race)
/// @description Free what a race made (any skid surface chc_race_draw created). Safe to call twice.
function chc_race_free(_r) {
    if (!is_struct(_r)) return;
    if (variable_struct_exists(_r, "skid") && surface_exists(_r.skid)) surface_free(_r.skid);
    _r.skid = -1;
}
