/// chc_demo.gml - THE GRAND PRIX, Chicane's demo room: a generated circuit, seven AI drivers and you, with the full HUD.
/// Keys: arrows or WASD drive (Space is the handbrake) - X autopilot (the AI drives your car) - N a new circuit - T the
/// next theme - B the next car body - C the camera (follow / whole circuit) - H the race layer overlay (racing line,
/// braking points, gates) - R restart the race - P cut rule (refuse / penalty).
///
/// Chicane - Top-Down Racing for GameMaker. Copyright (c) 2026 Core Systems Asset Factory. Licence: see LICENSE.txt.

/// @function chc_demo_create(seed, theme)
/// @description Build the demo: circuit, bake, race, camera.
function chc_demo_create(_seed, _theme) {
    var _D = { seed: _seed, theme: _theme, body: "", overview: false, overlay: false, autopilot: false, cutRule: "refuse",
               c: undefined, r: undefined, cam: undefined, msg: "", msgT: 0, banner: 3.5 };
    chc_demo_rebuild(_D, true);
    return _D;
}

/// @function chc_demo_rebuild(demo, newCircuit)
/// @description (Re)generate the circuit when asked, then a fresh race on it.
function chc_demo_rebuild(_D, _newCircuit) {
    if (_newCircuit || is_undefined(_D.c)) {
        if (!is_undefined(_D.c)) chc_circuit_free(_D.c);
        _D.c = chc_circuit_create(_D.seed, _D.theme);
        chc_circuit_bake(_D.c, 1);
        if (_D.body == "" || !_newCircuit) _D.body = _D.c.T.body;
        _D.banner = 3.5;
    }
    if (!is_undefined(_D.r)) chc_race_free(_D.r);
    _D.r = chc_race_create(_D.c, { cars: 8, laps: 5, seed: _D.seed, body: _D.body, player: 0, cutRule: _D.cutRule });
    var _p = _D.r.cars[0];
    _D.cam = chc_camera_create(_p.x, _p.y, 1.1, 960, 640, 0, 0);
}

/// @function chc_demo_step(demo)
/// @description Read the keys, drive the race one frame, ease the camera.
function chc_demo_step(_D) {
    var _dt = clamp(delta_time / 1000000, 0, 0.05);
    if (keyboard_check_pressed(ord("N"))) { _D.seed += 1; chc_demo_rebuild(_D, true); }
    if (keyboard_check_pressed(ord("T"))) {
        var _th = chc_themes(), _ix = 0;
        for (var _i = 0; _i < array_length(_th); _i++) if (_th[_i] == _D.theme) _ix = _i;
        _D.theme = _th[(_ix + 1) mod array_length(_th)]; _D.body = "";
        chc_demo_rebuild(_D, true);
    }
    if (keyboard_check_pressed(ord("B"))) {
        var _bs = chc_bodies(), _ix = 0;
        for (var _i = 0; _i < array_length(_bs); _i++) if (_bs[_i] == _D.body) _ix = _i;
        _D.body = _bs[(_ix + 1) mod array_length(_bs)];
        chc_demo_rebuild(_D, false);
    }
    if (keyboard_check_pressed(ord("R"))) chc_demo_rebuild(_D, false);
    if (keyboard_check_pressed(ord("P"))) { _D.cutRule = (_D.cutRule == "refuse") ? "penalty" : "refuse"; chc_demo_rebuild(_D, false); _D.msg = "CUT RULE: " + string_upper(_D.cutRule); _D.msgT = 2; }
    if (keyboard_check_pressed(ord("C"))) _D.overview = !_D.overview;
    if (keyboard_check_pressed(ord("H"))) _D.overlay = !_D.overlay;
    if (keyboard_check_pressed(ord("X"))) { _D.autopilot = !_D.autopilot; chc_car_set_ai(_D.r, 0, _D.autopilot); }
    if (!_D.autopilot) {
        var _thr = (keyboard_check(vk_up) || keyboard_check(ord("W"))) ? 1 : 0;
        var _rev = (keyboard_check(vk_down) || keyboard_check(ord("S")));
        var _car = _D.r.cars[0];
        var _brk = 0;
        if (_rev) { if (_car.speed > 30 && (_car.vx * cos(_car.ang) + _car.vy * sin(_car.ang)) > 0) _brk = 1; else _thr = -1; }
        if (keyboard_check(vk_space)) _brk = 1;
        var _st = ((keyboard_check(vk_right) || keyboard_check(ord("D"))) ? 1 : 0) - ((keyboard_check(vk_left) || keyboard_check(ord("A"))) ? 1 : 0);
        chc_car_input(_D.r, 0, _thr, _brk, _st);
    }
    chc_race_step(_D.r, _dt);
    for (var _e = 0; _e < array_length(_D.r.events); _e++) {
        var _ev = _D.r.events[_e];
        if (_ev.type == "fastest") { _D.msg = "FASTEST LAP  " + _D.r.cars[_ev.car].code + "  " + chc__fmt(_ev.time); _D.msgT = 2.5; }
    }
    if (_D.msgT > 0) _D.msgT -= _dt;
    if (_D.banner > 0) _D.banner -= _dt;
    if (_D.overview) {
        var _c = _D.c, _z = min(960 / _c.worldW, 640 / _c.worldH);
        _D.cam.zoom += (_z - _D.cam.zoom) * min(1, _dt * 6);
        _D.cam.x += (_c.worldW / 2 - _D.cam.x) * min(1, _dt * 6); _D.cam.y += (_c.worldH / 2 - _D.cam.y) * min(1, _dt * 6);
    } else {
        _D.cam.zoom += (1.1 - _D.cam.zoom) * min(1, _dt * 6);
        chc_camera_follow(_D.cam, _D.r.cars[0], _dt, _D.c);
    }
}

/// @function chc_demo_overlay(demo)
/// @description The race layer made visible: the racing line (green where the profile accelerates, red where it brakes),
/// the 24 gates (the start/finish line in yellow), and each car's next gate.
function chc_demo_overlay(_D) {
    var _c = _D.c, _cam = _D.cam, _pr = chc__profile(_c, chc_body(_D.body));
    for (var _i = 0; _i < _c.n; _i += 2) {
        var _j = (_i + 2) mod _c.n;
        chc__cam_xy(_cam, _c.lx[_i], _c.ly[_i]); var _x0 = global.chc_cx, _y0 = global.chc_cy;
        chc__cam_xy(_cam, _c.lx[_j], _c.ly[_j]);
        draw_set_colour(_pr.brake[_i] ? chc__rgb(255, 70, 60) : chc__rgb(90, 240, 120)); draw_set_alpha(0.9);
        draw_line_width(_x0, _y0, global.chc_cx, global.chc_cy, 2.5);
    }
    for (var _g = 0; _g < CHC_GATES; _g++) {
        var _i = floor(_c.gates[_g] / _c.step) mod _c.n;
        chc__cam_xy(_cam, _c.px[_i] + _c.nx[_i] * (_c.hw + 12), _c.py[_i] + _c.ny[_i] * (_c.hw + 12)); var _ax = global.chc_cx, _ay = global.chc_cy;
        chc__cam_xy(_cam, _c.px[_i] - _c.nx[_i] * (_c.hw + 12), _c.py[_i] - _c.ny[_i] * (_c.hw + 12));
        draw_set_colour((_g == 0) ? chc__rgb(255, 220, 40) : chc__rgb(120, 200, 255)); draw_set_alpha(0.8);
        draw_line_width(_ax, _ay, global.chc_cx, global.chc_cy, 2);
    }
    draw_set_alpha(1);
}

/// @function chc_demo_draw(demo)
/// @description Draw the room: circuit, skid marks and cars through the camera, the overlay, the HUD, the banner and the
/// key line.
function chc_demo_draw(_D) {
    draw_clear(chc__rgb(10, 12, 16));
    chc_circuit_draw(_D.c, _D.cam);
    chc_race_draw(_D.r, _D.cam);
    if (_D.overlay) chc_demo_overlay(_D);
    chc_hud_draw(_D.r, 0, 0, 960, 640, _D.autopilot ? -1 : 0);
    if (_D.banner > 0) {
        var _a = clamp(_D.banner, 0, 1);
        chc__panel(300, 250, 660, 340, _a);
        chc__text(480, 282, string_upper(_D.c.T.title), fnt_chicane_display_l, 0.62, c_white, _a, fa_center);
        chc__text(480, 320, "CIRCUIT " + string(_D.seed) + "  -  " + string(floor(_D.c.length / 10) / 100) + " KM  -  " + string(array_length(_D.c.layout.corners)) + " CORNERS", fnt_chicane_body_s, 0.62, chc__rgb(200, 206, 216), _a, fa_center);
    }
    if (_D.msgT > 0) chc__text(480, 150, _D.msg, fnt_chicane_display_s, 0.8, chc__rgb(200, 120, 255), clamp(_D.msgT, 0, 1), fa_center);
    chc__text(12, 628, "ARROWS drive  SPACE handbrake  X autopilot  N circuit  T theme  B body  C camera  H race layer  P cut rule  R restart", fnt_chicane_body_s, 0.5, chc__rgb(200, 204, 214), 0.85);
}

/// @function chc_demo_free(demo)
/// @description Free what the demo made.
function chc_demo_free(_D) {
    if (!is_struct(_D)) return;
    if (!is_undefined(_D.r)) chc_race_free(_D.r);
    if (!is_undefined(_D.c)) chc_circuit_free(_D.c);
    chc_draw_free();
}
