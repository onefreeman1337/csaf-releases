/// @description Draw the race (the GUI is 960 x 640).
if (is_undefined(demo)) exit;
chc_demo_draw(demo);
