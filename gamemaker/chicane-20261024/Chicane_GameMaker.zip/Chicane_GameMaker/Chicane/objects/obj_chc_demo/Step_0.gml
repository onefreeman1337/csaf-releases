/// @description Run the race.
if (is_undefined(demo)) exit;
chc_demo_step(demo);
