//=============================================================================
// BracketRender.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Bracket [4/4] — the painting. Takes a sign's geometry and lands the oak, the paint, the gilt, the iron and the weather. Knows nothing about RPG Maker. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * BracketRender — where the pixels happen
 * ============================================================================
 * A painter, not a plugin. It patches nothing and adds no scene. Give it a 2D
 * context and a profile and it draws a sign; give it a list of profiles and it
 * draws the Signwright's Yard.
 *
 * Nothing here decides a position. Every one comes from BracketCompose, which
 * derives it from the board's own outline.
 * ============================================================================
 */

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};

CSAF.BracketRender = (function () {
  'use strict';

  var _K = null;
  /* ⛔ wing §8 trap 2: load order is the BUYER'S choice, and `mz_harness build`
   * loads the folder ALPHABETICALLY — so this file may be parsed before or
   * after BracketCompose. Siblings are resolved at FIRST USE, never at load. */
  function K() {
    if (!_K) _K = CSAF.BracketCompose;
    if (!_K) throw new Error('BracketRender: enable BracketCompose too.');
    return _K;
  }

  /* The two shipped faces. ⛔ wing §15a: MZ's own font is the loudest "this is
   * RPG Maker" signal there is, and `mainFontFace()` must appear nowhere in
   * this product. The fallbacks below are generic CSS families, never MZ's. */
  var FACE_DISPLAY = '"BracketDisplay", "Cinzel", Georgia, "Times New Roman", serif';
  var FACE_BODY = '"BracketBody", "Alegreya", Georgia, "Times New Roman", serif';

  /* ------------------------------------------------------------ primitives --*/

  /**
   * Trace a closed polygon.
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {number[][]} pts Points in pixels.
   * @param {boolean} [reverse] Wind the other way, for an even-odd hole.
   */
  function tracePoly(ctx, pts, reverse) {
    if (!pts.length) return;
    var list = reverse ? pts.slice().reverse() : pts;
    ctx.moveTo(list[0][0], list[0][1]);
    for (var i = 1; i < list.length; i++) ctx.lineTo(list[i][0], list[i][1]);
    ctx.closePath();
  }

  /**
   * The board's outline in pixels, at a given origin.
   * @param {object} g Geometry from BracketCompose.
   * @param {number} ox Left of the board. @param {number} oy Top of the board.
   * @returns {number[][]} Points in pixels.
   */
  function boardPixels(g, ox, oy) {
    var out = [];
    for (var i = 0; i < g.outline.length; i++) {
      out.push([ox + g.bx(g.outline[i][0]), oy + g.by(g.outline[i][1])]);
    }
    return out;
  }

  /* ---------------------------------------------------------------- device --*/

  /**
   * Draw one trade device as a single silhouette.
   *
   * ⛔ Icon_Doctrine §22d: there are two obvious ways to put a hole in a shape
   * and BOTH are wrong — `destination-out` erases through everything behind it,
   * and an even-odd path opened with the BOUNDING BOX fills the box minus the
   * holes. The hole is traced in the SAME path as the shape it bites, wound the
   * other way, and the whole thing is filled ONCE with `evenodd`.
   *
   * ⛔ Icon_Doctrine §22e: the ink is never hard-coded. It is chosen by
   * luminance against the ground the device sits on, and the caller is told
   * whether the choice actually cleared the bar.
   *
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {string} id A device id.
   * @param {number} cx Centre x. @param {number} cy Centre y.
   * @param {number} w Width in pixels. @param {number} h Height in pixels.
   * @param {string} ink The fill.
   * @param {string} counterInk The ink for cut-in lines that must read as a
   *   groove rather than a hole (facets, slashes, hoops).
   * @returns {number} How many primitives were drawn. Zero is a defect.
   */
  function drawDevice(ctx, id, cx, cy, w, h, ink, counterInk) {
    var C = K();
    var prims = C.DEVICE[id];
    if (!prims || !prims.length) return 0;
    var b = C.deviceBounds(id);
    var sx = w / (b.w || 1), sy = h / (b.h || 1);
    var bcx = (b.minX + b.maxX) / 2, bcy = (b.minY + b.maxY) / 2;
    function X(x) { return cx + (x - bcx) * sx; }
    function Y(y) { return cy + (y - bcy) * sy; }
    /* A bar's width is in device units on the SHORT axis, so a device squeezed
     * wide does not grow fat strokes. */
    var sBar = Math.min(sx, sy);

    var drawn = 0;
    /* Pass one: the mass and its holes, ONE path, filled ONCE (§22d). */
    ctx.save();
    ctx.fillStyle = ink;
    ctx.beginPath();
    for (var i = 0; i < prims.length; i++) {
      var p = prims[i];
      if (p.t === 'poly') {
        var pts = [];
        for (var k = 0; k < p.pts.length; k++) pts.push([X(p.pts[k][0]), Y(p.pts[k][1])]);
        tracePoly(ctx, pts); drawn++;
      } else if (p.t === 'circ') {
        ctx.moveTo(X(p.x) + p.r * sx, Y(p.y));
        ctx.ellipse(X(p.x), Y(p.y), p.r * sx, p.r * sy, 0, 0, Math.PI * 2);
        drawn++;
      } else if (p.t === 'bar' && p.ink !== 'counter') {
        barPath(ctx, X(p.a[0]), Y(p.a[1]), X(p.b[0]), Y(p.b[1]), p.w * sBar); drawn++;
      } else if (p.t === 'ring') {
        ringPath(ctx, X(p.x), Y(p.y), p.r * sx, p.r * sy, p.w * sBar, p.a0, p.a1); drawn++;
      } else if (p.t === 'cut') {
        /* Wound backwards so even-odd reads it as a hole in the SAME path. */
        if (p.circ) {
          ctx.moveTo(X(p.x) + p.r * sx, Y(p.y));
          ctx.ellipse(X(p.x), Y(p.y), p.r * sx, p.r * sy, 0, Math.PI * 2, 0, true);
        } else {
          var cpts = [];
          for (var m = 0; m < p.pts.length; m++) cpts.push([X(p.pts[m][0]), Y(p.pts[m][1])]);
          tracePoly(ctx, cpts, true);
        }
        drawn++;
      }
    }
    ctx.fill('evenodd');

    /* Pass two: the counters — grooves cut INTO the mass, in the counter ink.
     * ⛔ Icon_Doctrine §22a-2b rule 2: ornament laid ON a form detaches; cut it
     * INTO the form. These are clipped to the mass so nothing spills. */
    var counters = [];
    for (var c = 0; c < prims.length; c++) {
      if (prims[c].t === 'bar' && prims[c].ink === 'counter') counters.push(prims[c]);
    }
    if (counters.length) {
      /* ⛔ Icon_Doctrine §22b-5: A CORPUS NOTE IS NOT A DRAWING INSTRUCTION —
       * GREP THE PROSE AGAINST THE RENDERER. The comment above claimed these
       * were clipped to the mass and NOTHING CLIPPED THEM (found in the art
       * stage, 2026-09-14, while re-cutting the loaf's slashes onto its crust).
       * A counter that leaves the mass is not a groove, it is a stray stroke on
       * the board. The path from pass one is still current, so the clip is the
       * mass itself, holes and all. */
      ctx.clip('evenodd');
      ctx.fillStyle = counterInk;
      for (var q = 0; q < counters.length; q++) {
        var cb = counters[q];
        ctx.beginPath();
        barPath(ctx, X(cb.a[0]), Y(cb.a[1]), X(cb.b[0]), Y(cb.b[1]), cb.w * sBar);
        ctx.fill();
        drawn++;
      }
    }
    ctx.restore();
    return drawn;
  }

  /**
   * Trace a thick line as a quad with square ends.
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {number} x0 Start x. @param {number} y0 Start y.
   * @param {number} x1 End x. @param {number} y1 End y.
   * @param {number} w Width in pixels.
   */
  function barPath(ctx, x0, y0, x1, y1, w) {
    var dx = x1 - x0, dy = y1 - y0;
    var len = Math.sqrt(dx * dx + dy * dy) || 1;
    var nx = -dy / len * (w / 2), ny = dx / len * (w / 2);
    ctx.moveTo(x0 + nx, y0 + ny);
    ctx.lineTo(x1 + nx, y1 + ny);
    ctx.lineTo(x1 - nx, y1 - ny);
    ctx.lineTo(x0 - nx, y0 - ny);
    ctx.closePath();
  }

  /**
   * Trace an annulus sector — the horseshoe's stock.
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {number} cx Centre x. @param {number} cy Centre y.
   * @param {number} rx Radius x. @param {number} ry Radius y.
   * @param {number} w Stock width. @param {number} a0 Start angle. @param {number} a1 End angle.
   */
  function ringPath(ctx, cx, cy, rx, ry, w, a0, a1) {
    var n = 26, i, t;
    for (i = 0; i <= n; i++) {
      t = a0 + (a1 - a0) * (i / n);
      var x = cx + Math.cos(t) * (rx + w / 2), y = cy + Math.sin(t) * (ry + w / 2);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    for (i = n; i >= 0; i--) {
      t = a0 + (a1 - a0) * (i / n);
      ctx.lineTo(cx + Math.cos(t) * (rx - w / 2), cy + Math.sin(t) * (ry - w / 2));
    }
    ctx.closePath();
  }

  /* ----------------------------------------------------------------- board --*/

  /**
   * Paint the board: oak, then pigment, then grain over the pigment.
   *
   * ⛔ wing §26h: A SHARE-OF-PIXELS BAR CANNOT TELL PAINT FROM SPRAY. A smooth
   * colour field mixed straight onto the timber is an airbrush, and it scored
   * 48/48 on exactly the probe meant to catch it. Paint is a LAYER: the field
   * is THRESHOLDED, every band gets a lit lip toward the light and a dark one
   * away, a cast shadow falls on the bare oak beside it, and the GRAIN IS LAID
   * AFTER the pigment so the material shows through it rather than under it.
   *
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {object} g Geometry.
   * @param {object} p Profile.
   * @param {number} ox Board left. @param {number} oy Board top.
   * @returns {object} Counts, for the probes: `{grainStrokes, paintBands, wornCorners}`.
   */
  function paintBoard(ctx, g, p, ox, oy) {
    var C = K();
    var w = C.weather(p.weathering);
    var pts = boardPixels(g, ox, oy);
    var oakLit = C.rgbOf(C.PALETTE.oakLit);
    var oakDark = C.rgbOf(C.PALETTE.oakShadow);
    var counts = { grainStrokes: 0, paintBands: 0, wornCorners: 0 };

    ctx.save();
    /* Clip to the board so nothing a later pass draws can leave the timber. */
    ctx.beginPath(); tracePoly(ctx, pts); ctx.clip();

    /* --- the timber ------------------------------------------------------- */
    var grad = ctx.createLinearGradient(ox, oy, ox, oy + g.boardH);
    grad.addColorStop(0, C.toHex(C.relief(oakLit, +1, 16)));
    grad.addColorStop(0.62, C.PALETTE.oakLit);
    grad.addColorStop(1, C.toHex(C.relief(oakLit, -1, 22)));
    ctx.fillStyle = grad;
    ctx.fillRect(ox - 2, oy - 2, g.boardW + 4, g.boardH + 4);

    /* --- the pigment, as a LAYER ------------------------------------------ */
    var field = C.SCHEME_FIELD[p.scheme];
    var fieldRgb = C.rgbOf(field);
    if (fieldRgb) {
      /* The field is inset from the board's own outline by the amount the
       * weather has eaten back from the edges, so paint retreats from the
       * corners inward exactly as the brief asks. */
      /* ⛔ wing §11: ONE function decides how far the coat has retreated, and
       * the geometry subtracts the same amount from the room the lettering has.
       * This used to be `w.cornerWear * min(boardW, boardH)` computed here, and
       * the type-fitter did not know it existed — so worn signs struck their
       * names onto bare oak (2026-09-14, `_probe/letter_fit.js`). */
      var wear = C.paintInset(g.boardW, g.boardH, p.weathering);
      var inner = insetPolygon(pts, ox + g.boardW / 2, oy + g.boardH / 2, wear);

      /* The cast shadow FIRST, on the bare oak beside the paint. Without it the
       * paint is a tint rather than a coat. */
      ctx.save();
      ctx.beginPath(); tracePoly(ctx, offsetPolygon(inner, 1.5, 2.0));
      ctx.fillStyle = 'rgba(20,12,6,0.34)';
      ctx.fill();
      ctx.restore();

      ctx.save();
      ctx.beginPath(); tracePoly(ctx, inner); ctx.clip();
      ctx.fillStyle = field;
      ctx.fillRect(ox - 2, oy - 2, g.boardW + 4, g.boardH + 4);
      /* The lit lip, upper-left, and the shadowed one, lower-right — one light,
       * pack wide. These are what make a coat read as having thickness. */
      var lip = Math.max(1, Math.min(g.boardW, g.boardH) * 0.018);
      ctx.strokeStyle = C.toHex(C.relief(fieldRgb, +1, 34));
      ctx.lineWidth = lip;
      ctx.beginPath(); tracePoly(ctx, offsetPolygon(inner, -0.6, -0.8)); ctx.stroke();
      ctx.strokeStyle = C.toHex(C.relief(fieldRgb, -1, 30));
      ctx.beginPath(); tracePoly(ctx, offsetPolygon(inner, 0.6, 0.9)); ctx.stroke();
      ctx.restore();
      counts.paintBands = 1;
      counts.wornCorners = wear > 0.5 ? inner.length : 0;
    }

    /* --- the grain, LAID LAST so the timber shows THROUGH the paint --------
     * ⛔ wing §24d: a pitch is declared and the count derived from the real run;
     * nobody types how many streaks a board has. */
    var gr = g.grain;
    var through = fieldRgb ? w.grainThrough : 0.55;
    for (var i = 0; i < gr.count; i++) {
      var y = oy + i * gr.pitch + gr.pitch * 0.5;
      /* The streak follows the board's own outline: it runs the full width the
       * outline leaves at ITS height, not the board's bounding box. */
      var yb = g.yMin + ((y - oy) / g.boardH) * g.span;
      var run = C.runAt(g.outline, yb);
      if (run.width <= 0.01) continue;
      var x0 = ox + g.bx(run.left), x1 = ox + g.bx(run.right);
      var dark = (i % 3 === 0);
      ctx.strokeStyle = dark
        ? 'rgba(58,32,14,' + (0.34 * through + 0.10).toFixed(3) + ')'
        : 'rgba(196,146,92,' + (0.26 * through + 0.07).toFixed(3) + ')';
      ctx.lineWidth = g.grainInk * (dark ? 1.0 : 0.7);
      ctx.beginPath();
      /* A streak wanders: three segments, never a ruled line. */
      ctx.moveTo(x0, y);
      ctx.bezierCurveTo(
        x0 + (x1 - x0) * 0.33, y + g.grainInk * 0.9,
        x0 + (x1 - x0) * 0.66, y - g.grainInk * 1.1,
        x1, y + g.grainInk * 0.3
      );
      ctx.stroke();
      counts.grainStrokes++;
    }

    ctx.restore();

    /* --- the board's own edges, outside the clip so they read as thickness --*/
    var pen = C.penFor(g.boardW, g.boardH, 0.012);
    ctx.save();
    ctx.lineJoin = 'round';
    ctx.strokeStyle = C.toHex(C.relief(oakLit, +1, 40));
    ctx.lineWidth = Math.max(2, pen);
    ctx.beginPath(); tracePoly(ctx, offsetPolygon(pts, 0, -pen * 0.8)); ctx.stroke();
    ctx.strokeStyle = C.toHex(C.relief(oakDark, -1, 18));
    ctx.lineWidth = Math.max(3, pen * 1.5);
    ctx.beginPath(); tracePoly(ctx, offsetPolygon(pts, 0, pen * 1.1)); ctx.stroke();
    ctx.restore();

    /* --- the chalk keyline, on painted boards only ------------------------- */
    if (fieldRgb) {
      ctx.save();
      ctx.strokeStyle = 'rgba(239,230,210,' + (0.62 - w.level * 0.11).toFixed(2) + ')';
      ctx.lineWidth = Math.max(1, g.boardH * 0.006);
      var key = insetPolygon(pts, ox + g.boardW / 2, oy + g.boardH / 2, g.keylineInset);
      ctx.beginPath(); tracePoly(ctx, key); ctx.stroke();
      ctx.restore();
    }
    return counts;
  }

  /**
   * Shrink a polygon toward a centre by a number of pixels.
   * ⛔ wing §11a: THIS IS NO LONGER A SECOND COPY. The coat the painter fills
   * and the room the type-fitter measures must be the same shape, so the one
   * implementation lives in BracketCompose and this delegates. A second copy of
   * a constant does not drift — it WINS, and it presents as a stale build.
   * @param {number[][]} pts Points. @param {number} cx Centre x. @param {number} cy Centre y.
   * @param {number} px Pixels to pull in.
   * @returns {number[][]} A new polygon.
   */
  function insetPolygon(pts, cx, cy, px) {
    return K().insetPolygon(pts, cx, cy, px);
  }

  /** @param {number[][]} pts Points. @param {number} dx X shift. @param {number} dy Y shift.
   *  @returns {number[][]} A shifted copy. */
  function offsetPolygon(pts, dx, dy) {
    var out = [];
    for (var i = 0; i < pts.length; i++) out.push([pts[i][0] + dx, pts[i][1] + dy]);
    return out;
  }

  /* ------------------------------------------------------------- lettering --*/

  /**
   * Set a line of type to a measured width.
   * ⛔ Icon_Doctrine §22f: a fitter that can fail to fit must SAY SO — "SEVEN OF
   * WANDS" once shipped as "SEVEN OF WAND". This surrenders tracking first, then
   * squeezes, and RETURNS the squeeze so a caller can act on it.
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {string} text The line.
   * @param {number} size Point size.
   * @param {string} face The font stack.
   * @param {number} maxW The measured run available.
   * @param {number} tracking Extra per character, as a fraction of size.
   * @returns {object} `{size, tracking, squeeze, width}`.
   */
  function fitLine(ctx, text, size, face, maxW, tracking) {
    var t = String(text || '');
    var tr = tracking;
    var s = size;
    var FLOOR = 5;
    function widthAt(sz, trk) {
      ctx.font = Math.round(sz) + 'px ' + face;
      return ctx.measureText(t).width + Math.max(0, t.length - 1) * sz * trk;
    }
    var wpx = widthAt(s, tr);
    /* Surrender the tracking first — it is decoration, the words are not. */
    while (wpx > maxW && tr > 0) { tr = Math.max(0, tr - 0.01); wpx = widthAt(s, tr); }

    /* ⛔⛔ THIS USED TO STEP DOWN BY HALF A POINT UNDER `guard++ < 60`, AND THE
     * GUARD RAN OUT BEFORE THE TYPE FITTED. MEASURED 2026-09-14, polish stage:
     * a 21-character name declared at 46 px against an 87 px run stopped at
     * 16 px — sixty steps of 0.5 — and still measured 225 px. `fitLine` returned
     * a "fit" 2.6x wider than the room it was given, every caller believed it,
     * and the name ran off the coat and across the board's bare edge. Nothing
     * failed: the function reports a `squeeze`, and 0.347 looks like work.
     * ⛔ wing §1c: a guessed constant inside a guard is a guard that does not
     * guard. The size is SOLVED — type width is very nearly linear in point
     * size, so one division lands near the answer and a few bounded refinements
     * settle the rounding — and the result now says whether it actually FITS,
     * so a caller can act on the truth instead of on a ratio. */
    if (wpx > maxW && s > FLOOR) {
      s = Math.max(FLOOR, s * (maxW / wpx));
      wpx = widthAt(s, tr);
      for (var i = 0; i < 24 && wpx > maxW && s > FLOOR; i++) {
        /* never shrink by less than a rounding step, or `Math.round(sz)` in
         * widthAt makes the loop stand still */
        s = Math.max(FLOOR, Math.min(s - 0.5, s * (maxW / wpx)));
        wpx = widthAt(s, tr);
      }
    }
    return {
      size: s, tracking: tr, squeeze: s / size, width: wpx,
      /* ⛔ The honest answer when even the floor is too big: the caller is told,
       * rather than handed a number that quietly does not hold. */
      fits: wpx <= maxW + 0.5
    };
  }

  /**
   * Strike a line, letter by letter, so the tracking is real.
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {string} text The line.
   * @param {number} cx Centre x. @param {number} y Baseline.
   * @param {object} fit The result of `fitLine`.
   * @param {string} face The font stack.
   * @returns {number} Glyphs struck.
   */
  function strikeTracked(ctx, text, cx, y, fit, face) {
    var t = String(text || '');
    ctx.font = Math.round(fit.size) + 'px ' + face;
    ctx.textBaseline = 'alphabetic';
    ctx.textAlign = 'left';
    var extra = fit.size * fit.tracking;
    var total = ctx.measureText(t).width + Math.max(0, t.length - 1) * extra;
    var x = cx - total / 2;
    var n = 0;
    for (var i = 0; i < t.length; i++) {
      ctx.fillText(t[i], x, y);
      x += ctx.measureText(t[i]).width + extra;
      n++;
    }
    return n;
  }

  /**
   * Strike a line on an arc, following the board's own head.
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {string} text The line.
   * @param {number} cx Arc centre x. @param {number} cy Arc centre y.
   * @param {number} r Radius. @param {object} fit The fit.
   * @param {string} face The font stack.
   * @returns {number} Glyphs struck.
   */
  function strikeArc(ctx, text, cx, cy, depth, fit, face) {
    var t = String(text || '');
    ctx.font = Math.round(fit.size) + 'px ' + face;
    ctx.textBaseline = 'alphabetic';
    ctx.textAlign = 'center';
    var extra = fit.size * fit.tracking;
    var widths = [], total = 0, i;
    for (i = 0; i < t.length; i++) {
      var cw = ctx.measureText(t[i]).width + extra;
      widths.push(cw); total += cw;
    }
    /* ⛔ MEASURED 2026-09-13 by opening the Yard plate: the radius used to be
     * `max(boardW * 0.55, boardH * 0.9)`, which makes the swept angle
     * `total / r` — about 53 degrees for a full shop name. FOUR OF TWELVE names
     * swept clean off their boards and across the neighbouring cell, so one
     * board carried two shops' names. A signwright's arc is 15 to 25 degrees.
     * The radius is now DERIVED from the line's OWN width and a declared arc
     * DEPTH — the sagitta of a chord — so a long name arcs gently and a short
     * one arcs the same amount rather than curling into a circle. */
    var d = Math.max(0.5, Number(depth) || 1);
    var r = (total * total / 4 + d * d) / (2 * d);
    var span = total / r;                       /* radians the line occupies */
    cy = cy + r;                                /* the centre sits below the head */
    var a = -Math.PI / 2 - span / 2;
    var n = 0;
    for (i = 0; i < t.length; i++) {
      var step = widths[i] / r;
      a += step / 2;
      ctx.save();
      ctx.translate(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      ctx.rotate(a + Math.PI / 2);
      ctx.fillText(t[i], 0, 0);
      ctx.restore();
      a += step / 2;
      n++;
    }
    return n;
  }

  /**
   * The lettering: carved into bare oak, or gilt on paint.
   * ⛔ wing §25h: the direction of the relief is SOLVED, not assumed — try both
   * and keep the first that clears the bar, else the better.
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {object} g Geometry. @param {object} p Profile.
   * @param {number} ox Board left. @param {number} oy Board top.
   * @returns {object} `{glyphs, squeeze, ratio, gilt}`.
   */
  function letterBoard(ctx, g, p, ox, oy) {
    var C = K();
    var w = C.weather(p.weathering);
    var field = C.SCHEME_FIELD[p.scheme];
    var ground = C.groundFor(p.scheme);
    var gilt = !!field || p.scheme === 'giltOak';

    var cx = ox + g.boardW / 2;
    var nameY = oy + g.by(g.yMin + g.span * g.name.y);
    var tradeY = oy + g.by(g.yMin + g.span * g.trade.y);

    var fit = fitLine(ctx, p.name, g.name.size, FACE_DISPLAY, g.name.w, 0.06);
    var glyphs = 0;
    var ratio = 0;

    ctx.save();
    if (gilt) {
      /* GILT: a dulled gold, with a highlight up-left and a one-pixel drop. */
      var gl = C.parseHex(C.PALETTE.giltLit), gs = C.parseHex(C.PALETTE.giltShadow);
      var dull = w.giltDull;
      var lit = { r: gl.r + (gs.r - gl.r) * dull, g: gl.g + (gs.g - gl.g) * dull, b: gl.b + (gs.b - gl.b) * dull };
      var pick = C.pickContrast(ground, [lit, C.parseHex(C.PALETTE.chalk), { r: 24, g: 18, b: 12 }], 3.2);
      var drop = Math.max(1, g.name.size * 0.045);
      ctx.fillStyle = C.toHex(C.relief(ground, -1, 40));
      glyphs += strike(ctx, g, p, cx, nameY + drop, fit, FACE_DISPLAY);
      ctx.fillStyle = C.toHex(pick.ink);
      glyphs += strike(ctx, g, p, cx, nameY, fit, FACE_DISPLAY);
      var hi = C.relief(pick.ink, +1, 46);
      ctx.globalAlpha = 0.55;
      ctx.fillStyle = C.toHex(hi);
      glyphs += strike(ctx, g, p, cx - drop * 0.7, nameY - drop * 0.7, fit, FACE_DISPLAY);
      ctx.globalAlpha = 1;
      ratio = pick.ratio;
    } else {
      /* CARVED: a dark inner shadow up-left and a light bevel down-right, and
       * the letter itself in the timber's own colour a touch darker. */
      var cut = C.relief(ground, -1, 52);
      var bevel = C.relief(ground, +1, 44);
      var step = Math.max(1, g.name.size * 0.05);
      ctx.fillStyle = C.toHex(bevel);
      glyphs += strike(ctx, g, p, cx + step, nameY + step, fit, FACE_DISPLAY);
      ctx.fillStyle = C.toHex(cut);
      glyphs += strike(ctx, g, p, cx - step * 0.5, nameY - step * 0.5, fit, FACE_DISPLAY);
      /* ⛔ THE LETTER BODY'S OWN SEPARATION RISES WITH WEATHERING, and this is a
       * §22e-1 fix rather than a taste one. A carved letter is meant to be
       * quiet: 22 levels below the timber, read by its cut and its bevel. But
       * weathering also opens the GRAIN up (0.08 to 0.35 of it showing through),
       * and a 22-level letter over 35% grain noise is not quiet, it is gone —
       * MEASURED on the 48-sign board, where every name in the poorest district
       * was illegible. The noise rises, so the signal rises with it. */
      ctx.fillStyle = C.toHex(C.relief(ground, -1, 22 + w.level * 7));
      glyphs += strike(ctx, g, p, cx, nameY, fit, FACE_DISPLAY);
      ratio = C.contrast(ground, cut);
    }

    /* The trade, in body small caps, quieter than the name by design. */
    if (p.trade) {
      var tfit = fitLine(ctx, p.trade, g.trade.size, FACE_BODY, g.trade.w, 0.14);
      var tInk = C.pickContrast(ground, [
        C.parseHex(C.PALETTE.chalk), { r: 28, g: 20, b: 14 }, C.parseHex(C.PALETTE.giltLit)
      ], 3.0);
      ctx.globalAlpha = 0.86;
      ctx.fillStyle = C.toHex(tInk.ink);
      glyphs += strikeTracked(ctx, p.trade, cx, tradeY, tfit, FACE_BODY);
      ctx.globalAlpha = 1;
    }
    ctx.restore();
    return { glyphs: glyphs, squeeze: fit.squeeze, ratio: ratio, gilt: gilt };
  }

  /**
   * Strike the name, straight or on the board's own arc.
   * @param {CanvasRenderingContext2D} ctx The context. @param {object} g Geometry.
   * @param {object} p Profile. @param {number} cx Centre x. @param {number} y Baseline.
   * @param {object} fit The fit. @param {string} face The stack.
   * @returns {number} Glyphs struck.
   */
  function strike(ctx, g, p, cx, y, fit, face) {
    if (!g.name.arc) return strikeTracked(ctx, p.name, cx, y, fit, face);
    /* How far the middle of the line rises above its ends. Derived from the
     * board's own height so a tall board arcs more than a squat one, and small
     * enough that the arc is a signwright's, not a roundel's. */
    var depth = g.boardH * 0.045;
    return strikeArc(ctx, p.name, cx, y, depth, fit, face);
  }

  /* -------------------------------------------------------------- ironwork --*/

  /**
   * Draw the bracket, the rings and the chain.
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {object} g Geometry. @param {object} p Profile.
   * @param {number} wallX The wall face. @param {number} topY The plate's top.
   * @param {number} reach How far out the arm goes, in pixels.
   * @returns {object} `{links, nails, leaves, brace}`.
   */
  function drawIron(ctx, g, p, wallX, topY, reach, behind) {
    var C = K();
    var w = C.weather(p.weathering);
    /* ⛔ Icon_Doctrine §22e: NEVER HARD-CODE AN INK — pick it by luminance
     * against what it sits on. MEASURED 2026-09-13 by opening the Close Look:
     * the ironwork was drawn at a fixed `#2b2b2e` against a `#1c2431` dusk wall,
     * a contrast ratio of about 1.2:1, and the entire bracket, both rings and
     * the whole chain were INVISIBLE. Every structural check passed over a sign
     * that appeared to float. The iron keeps its colour but its VALUE is lifted
     * until it separates from the ground it is seen against, in absolute levels
     * (§22e-1), and the caller is told when the ground allows no separation. */
    var ground = C.rgbOf(behind) || C.rgbOf(C.PALETTE.dusk);
    var base = C.rgbOf(C.PALETTE.iron);
    var lifted = C.relief(base, C.lum(ground) > C.lum(base) ? -1 : +1, 48);
    var iron = { r: lifted.r, g: lifted.g, b: lifted.b };
    var ironHex = C.toHex(iron);
    var counts = { links: 0, nails: 0, leaves: 0, brace: 0, ironContrast: C.contrast(ground, iron) };
    /* ⛔ Icon_Doctrine §22a-2b: THE RESOLUTION FLOOR IS A NUMBER, MEASURE IT ONCE
     * AND AUTHOR ABOVE IT. At 0.055 of the iron height this was 3.5 px of bar
     * carrying a 300 px board, and `_probe/out/art_iron.png` showed eight
     * brackets made of hair. Stock is the bar's THICKNESS and a sign bracket is
     * substantial ironwork. */
    var stock = Math.max(2.6, g.ironH * 0.145);
    /* ⛔ MATERIAL, 2026-09-18. Opened at 2x (`_probe/out/iron_before.png`), every
     * bar, scroll and ring was a mid-grey silhouette with a pale inner stroke and
     * NO underside — clip-art iron under an oak board that has grain, a rim and a
     * lit edge. Iron reads as a round bar only with THREE values under the one
     * upper-left light the whole sign uses: a lit edge up-left, the body, and a
     * shade down-right. `under` is that shade; every run below lays it FIRST at
     * the same width offset down-right, so the body stroke leaves a sliver of it
     * showing on the far side, exactly as the lit stroke does on the near side. */
    var underHex = C.toHex(C.relief(iron, -1, 30));
    var litHex = C.toHex(C.relief(iron, +1, 34));
    var shadeDX = stock * 0.18, shadeDY = stock * 0.24;
    counts.undersides = 0;

    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    /* --- the fixing plate: a forged plate BEVELLED under the light ------------
     * a shade DARKER than the bar (it is in the wall's shadow), a lit top and
     * left edge, a dark bottom and right edge. */
    var plX = wallX - g.plate.w * 0.5, plW = g.plate.w, plH = g.plate.h;
    var bev = Math.max(1, Math.min(plW, plH) * 0.07);
    ctx.fillStyle = underHex;
    ctx.fillRect(plX, topY, plW, plH);
    ctx.fillStyle = litHex;
    ctx.fillRect(plX, topY, plW - bev, plH - bev);
    ctx.fillStyle = C.toHex(C.relief(iron, -1, 12));
    ctx.fillRect(plX + bev, topY + bev, plW - bev * 2, plH - bev * 2);

    /* --- the nails: two columns, rows derived (⛔ wing §24d) ----------------
     * DOMED heads: a shade down-right, the head, a highlight up-left. (They
     * were a light disc with a DARK centre offset down-right, which reads as a
     * drilled hole, not a nail.) */
    var nail = g.nails;
    for (var col = 0; col < nail.cols; col++) {
      var nx = wallX + (col === 0 ? -1 : 1) * g.plate.w * 0.28;
      for (var r = 0; r < nail.count; r++) {
        var ny = topY + g.nailInk + r * nail.pitch + nail.pitch * 0.3;
        var nr = g.nailInk * 0.5;
        ctx.beginPath();
        ctx.arc(nx + nr * 0.22, ny + nr * 0.26, nr, 0, Math.PI * 2);
        ctx.fillStyle = C.toHex(C.relief(iron, -1, 40));
        ctx.fill();
        ctx.beginPath();
        ctx.arc(nx, ny, nr, 0, Math.PI * 2);
        ctx.fillStyle = C.toHex(C.relief(iron, +1, 14));
        ctx.fill();
        ctx.beginPath();
        ctx.arc(nx - nr * 0.32, ny - nr * 0.34, Math.max(0.6, nr * 0.34), 0, Math.PI * 2);
        ctx.fillStyle = C.toHex(C.relief(iron, +1, 70));
        ctx.fill();
        counts.nails++;
      }
    }

    /* --- the arm, then its ornament, as SEPARATE strokes --------------------
     * ⛔ MEASURED 2026-09-13 by opening the Close Look: the arm and its scroll
     * used to be one open polyline stroked as one path, so a stray line ran
     * from the end of the scroll back to the arm and the bracket read as loose
     * wire. An ornament is a separate stroke from the thing it ornaments. */
    var spine = g.spine;
    function SX(x) { return wallX + x * reach; }
    function SY(y) { return topY + y * g.ironH; }
    /** @param {number[][]} pts A run. @param {number} lw Stroke width. @param {string} ink Colour. */
    function strokeRun(pts, lw, ink, dx, dy) {
      if (!pts || pts.length < 2) return;
      ctx.strokeStyle = ink;
      ctx.lineWidth = lw;
      ctx.beginPath();
      for (var i = 0; i < pts.length; i++) {
        var sx = SX(pts[i][0]) + (dx || 0), sy = SY(pts[i][1]) + (dy || 0);
        if (i === 0) ctx.moveTo(sx, sy); else ctx.lineTo(sx, sy);
      }
      ctx.stroke();
    }
    /** The same run, offset up-left, for the lit edge. One light, pack wide. */
    function strokeLit(pts, lw) {
      if (!pts || pts.length < 2) return;
      ctx.strokeStyle = C.toHex(C.relief(iron, +1, 34));
      ctx.lineWidth = Math.max(0.8, lw * 0.34);
      ctx.beginPath();
      for (var i = 0; i < pts.length; i++) {
        var sx = SX(pts[i][0]) - stock * 0.22, sy = SY(pts[i][1]) - stock * 0.26;
        if (i === 0) ctx.moveTo(sx, sy); else ctx.lineTo(sx, sy);
      }
      ctx.stroke();
    }
    /* An ornament anchored on the arm, drawn in IRON-HEIGHT units in BOTH axes.
     * ⛔⛔ See `BracketCompose.volute`: these used to be authored in spine space,
     * where one x unit is the reach and one y unit the iron height, so every
     * scroll came out 4.6x wider than tall and read as loose lasso wire. Nothing
     * here is allowed to stretch them. */
    function strokeUnit(anchorX, anchorY, pts, lw, ink, dx, dy) {
      if (!pts || pts.length < 2) return;
      ctx.strokeStyle = ink;
      ctx.lineWidth = lw;
      ctx.beginPath();
      for (var i = 0; i < pts.length; i++) {
        var ux = anchorX + pts[i][0] * g.ironH + (dx || 0);
        var uy = anchorY + pts[i][1] * g.ironH + (dy || 0);
        if (i === 0) ctx.moveTo(ux, uy); else ctx.lineTo(ux, uy);
      }
      ctx.stroke();
    }
    /* The ornament goes down FIRST so the arm reads as being in front of it. */
    var orn = spine.orn || [];
    var armYs = SY(spine.arm[0][1]);
    counts.ornStrokes = 0;
    for (var o = 0; o < orn.length; o++) {
      var ax = SX(orn[o].ax);
      strokeUnit(ax, armYs, orn[o].pts, stock * 0.78, underHex, shadeDX, shadeDY);
      counts.undersides++;
      strokeUnit(ax, armYs, orn[o].pts, stock * 0.78, ironHex);
      strokeUnit(ax, armYs, orn[o].pts, Math.max(0.9, stock * 0.30),
        litHex, -stock * 0.22, -stock * 0.26);
      counts.ornStrokes++;
    }
    /* The brace is a long straight run, so spine space costs it nothing. */
    var braces = spine.brace || [];
    for (var bz = 0; bz < braces.length; bz++) {
      strokeRun(braces[bz], stock * 0.86, underHex, shadeDX, shadeDY);
      counts.undersides++;
      strokeRun(braces[bz], stock * 0.86, ironHex);
      strokeLit(braces[bz], stock * 0.86);
      counts.brace++;
    }

    /* --- the arm: a TAPERED BAR, not a hairline ----------------------------
     * ⛔ Icon_Doctrine §22a-2b: THE RESOLUTION FLOOR IS A NUMBER. The arm was a
     * stroked polyline at `ironH * 0.055` — about 3.5 px carrying a 300 px board
     * — and the whole bracket read as wire. Wrought iron is stock: thick where
     * it is bolted to the wall, drawn down toward the tip. A stroke cannot
     * taper, so the arm is a filled quad with its own lit top edge. */
    var armY = armYs;
    var armX0 = SX(spine.arm[0][0]), armX1 = SX(spine.arm[spine.arm.length - 1][0]);
    var hw0 = stock * 0.62, hw1 = stock * 0.34;
    ctx.beginPath();
    ctx.moveTo(armX0, armY - hw0);
    ctx.lineTo(armX1, armY - hw1);
    ctx.lineTo(armX1, armY + hw1);
    ctx.lineTo(armX0, armY + hw0);
    ctx.closePath();
    ctx.fillStyle = ironHex;
    ctx.fill();
    /* The underside of the bar: the lower third of the quad in shade. */
    ctx.beginPath();
    ctx.moveTo(armX0, armY + hw0 * 0.34);
    ctx.lineTo(armX1, armY + hw1 * 0.34);
    ctx.lineTo(armX1, armY + hw1);
    ctx.lineTo(armX0, armY + hw0);
    ctx.closePath();
    ctx.fillStyle = underHex;
    ctx.fill();
    counts.undersides++;
    ctx.beginPath();
    ctx.moveTo(armX0, armY - hw0 + 0.6);
    ctx.lineTo(armX1, armY - hw1 + 0.6);
    ctx.strokeStyle = litHex;
    ctx.lineWidth = Math.max(0.9, stock * 0.26);
    ctx.stroke();
    /* A finial so the arm ENDS rather than stopping: a short down-turned curl
     * past the far ring, which is also what stops the overshoot reading as a
     * line running off the frame. */
    var finial = [[0, 0], [0.10, 0.04], [0.15, 0.16], [0.10, 0.27], [-0.01, 0.29]];
    strokeUnit(armX1, armY, finial, stock * 0.66, underHex, shadeDX, shadeDY);
    counts.undersides++;
    strokeUnit(armX1, armY, finial, stock * 0.66, ironHex);
    counts.finial = 1;

    /* --- leaves on the scroll, pitch declared, count derived ----------------
     * ⛔ Icon_Doctrine §22a-2b: these were `stock * 1.8` wide when stock was
     * 3.5 px, so three "leaves" were three 6 px ticks under the arm — scratch
     * marks, not ornament. A leaf is a pointed lens big enough to have a shape,
     * and it grows FROM the arm (§22a-1b: overlap, never abut). */
    if (g.trait.leaves > 0) {
      var leafRun = reach * 0.34;
      var leafInk = Math.max(5, g.ironH * 0.20);
      var lf = C.fitRepeat(leafRun, leafInk, leafInk * 1.9);
      var want = Math.min(lf.count, g.trait.leaves);
      for (var L = 0; L < want; L++) {
        var lx = SX(0.30) + L * lf.pitch;
        var ly = armYs + stock * 0.2;
        ctx.beginPath();
        ctx.moveTo(lx, ly);
        ctx.quadraticCurveTo(lx + leafInk * 0.95, ly + leafInk * 0.25,
          lx + leafInk * 0.55, ly + leafInk * 1.25);
        ctx.quadraticCurveTo(lx - leafInk * 0.18, ly + leafInk * 0.72, lx, ly);
        ctx.closePath();
        ctx.fillStyle = C.toHex(C.relief(iron, +1, 16));
        ctx.fill();
        counts.leaves++;
      }
    }

    /* --- the two rings, HANGING FROM THE ARM ------------------------------- */
    /* ⛔ The rings used to sit at `topY + ironH`, a whole iron-height below the
     * arm, with nothing between them and it. They hang FROM the arm now, so the
     * chain has something to be attached to. */
    counts.armY = armY;
    var ringY = armY + g.ring.r;
    var rr = g.ring.r;
    [g.ring.leftX, g.ring.rightX].forEach(function (rx) {
      var ringW = Math.max(1.4, rr * 0.34);
      ctx.beginPath();
      ctx.arc(wallX + rx + ringW * 0.30, ringY + ringW * 0.36, rr, Math.PI * 1.85, Math.PI * 0.95);
      ctx.strokeStyle = underHex;
      ctx.lineWidth = ringW;
      ctx.stroke();
      counts.undersides++;
      ctx.beginPath();
      ctx.arc(wallX + rx, ringY, rr, 0, Math.PI * 2);
      ctx.strokeStyle = ironHex;
      ctx.lineWidth = ringW;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(wallX + rx - rr * 0.18, ringY - rr * 0.2, rr * 0.92, Math.PI * 0.9, Math.PI * 1.7);
      ctx.strokeStyle = C.toHex(C.relief(iron, +1, 36));
      ctx.lineWidth = Math.max(0.7, rr * 0.15);
      ctx.stroke();
    });

    /* --- the chain: link pitch from the ring's own diameter -----------------
     * Each link carries the same light as the ring it hangs from: a lit rim on
     * its upper-left, so a chain reads as forged loops and not as grey beads. */
    var ch = g.chain;
    counts.chainEndY = ringY + rr + Math.max(0, ch.count - 1) * ch.pitch + g.linkH * 0.5;
    [g.ring.leftX, g.ring.rightX].forEach(function (rx, side) {
      var missing = (w.linkGone && side === 1) ? 1 : 0;
      for (var k = 0; k < ch.count - missing; k++) {
        var ly2 = ringY + rr + k * ch.pitch;
        var rot = (k % 2) ? Math.PI / 2 : 0;
        var linkW = Math.max(1.1, rr * 0.26);
        ctx.beginPath();
        ctx.ellipse(wallX + rx, ly2, rr * 0.46, g.linkH * 0.5, rot, 0, Math.PI * 2);
        ctx.strokeStyle = ironHex;
        ctx.lineWidth = linkW;
        ctx.stroke();
        ctx.beginPath();
        ctx.ellipse(wallX + rx, ly2, rr * 0.46, g.linkH * 0.5, rot,
          rot ? Math.PI * 0.4 : Math.PI * 0.95, rot ? Math.PI * 1.15 : Math.PI * 1.7);
        ctx.strokeStyle = litHex;
        ctx.lineWidth = Math.max(0.6, linkW * 0.45);
        ctx.stroke();
        counts.links++;
      }
    });

    /* --- rust on the IRON, at weathering 2 and above ---------------------------
     * Rust starts where water sits: at the rings, where the chain wears the
     * arm. It creeps along the bar from each ring, wider as the sign ages,
     * laid over the iron (never over the wall) — `rustDrop` is the one weather
     * term, so the arm and the drip beneath it age together (§11). */
    counts.rustPatches = 0;
    if (w.rustDrop > 0) {
      /* Clipped to the arm's own quad, so rust can never land on the wall past
       * the bar's end or above and below it. */
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(armX0, armY - hw0);
      ctx.lineTo(armX1, armY - hw1);
      ctx.lineTo(armX1, armY + hw1);
      ctx.lineTo(armX0, armY + hw0);
      ctx.closePath();
      ctx.clip();
      [g.ring.leftX, g.ring.rightX].forEach(function (rx) {
        var cx0 = wallX + rx;
        var span = rr * (0.9 + w.rustDrop * 0.75);
        var rgA = ctx.createLinearGradient(cx0 - span, 0, cx0 + span, 0);
        var a = Math.min(0.78, 0.30 + w.rustDrop * 0.16);
        rgA.addColorStop(0, 'rgba(139,74,43,0)');
        rgA.addColorStop(0.5, 'rgba(139,74,43,' + a.toFixed(3) + ')');
        rgA.addColorStop(1, 'rgba(139,74,43,0)');
        ctx.fillStyle = rgA;
        ctx.fillRect(cx0 - span, armY - hw0, span * 2, hw0 * 2);
        counts.rustPatches++;
      });
      ctx.restore();
    }

    /* --- rust bleeding from the rings, at weathering 2 and above ------------ */
    if (w.rustDrop > 0) {
      [g.ring.leftX, g.ring.rightX].forEach(function (rx) {
        var dropPx = rr * w.rustDrop;
        var rg = ctx.createLinearGradient(0, ringY, 0, ringY + dropPx);
        rg.addColorStop(0, 'rgba(139,74,43,0.62)');
        rg.addColorStop(1, 'rgba(139,74,43,0)');
        ctx.fillStyle = rg;
        ctx.fillRect(wallX + rx - rr * 0.55, ringY, rr * 1.1, dropPx);
      });
    }
    ctx.restore();
    return counts;
  }

  /* ------------------------------------------------------------ the weather --*/

  /**
   * A split corner, at weathering 3 and above.
   * ⛔ wing §26f: a mark that refers to another mark must be CHECKED against it —
   * `boundCrack` once stapled a crack that `wearAt` never cut. This crack is cut
   * from the board's own outline, so it cannot refer to a corner that is not
   * there, and it REMOVES material rather than drawing a dark line on top.
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {object} g Geometry. @param {object} p Profile.
   * @param {number} ox Board left. @param {number} oy Board top.
   * @param {string} behind The colour showing THROUGH the split.
   * @returns {number} How much material was removed, in pixels of run. Zero at 0-2.
   */
  function crackCorner(ctx, g, p, ox, oy, behind) {
    var C = K();
    var w = C.weather(p.weathering);
    if (w.crack <= 0) return 0;
    var pts = boardPixels(g, ox, oy);
    /* The corner that splits is the outline's own lowest-right vertex. */
    var idx = 0, bestScore = -Infinity;
    for (var i = 0; i < pts.length; i++) {
      var s = pts[i][0] + pts[i][1] * 1.4;
      if (s > bestScore) { bestScore = s; idx = i; }
    }
    var c = pts[idx];
    var bite = Math.min(g.boardW, g.boardH) * 0.10 * (0.6 + w.crack);
    var a = pts[(idx + pts.length - 1) % pts.length];
    var b = pts[(idx + 1) % pts.length];
    function toward(from, to, t) {
      return [from[0] + (to[0] - from[0]) * t, from[1] + (to[1] - from[1]) * t];
    }
    var la = Math.hypot(a[0] - c[0], a[1] - c[1]) || 1;
    var lb = Math.hypot(b[0] - c[0], b[1] - c[1]) || 1;
    var pa = toward(c, a, Math.min(0.85, bite / la));
    var pb = toward(c, b, Math.min(0.85, bite / lb));
    /* A split is jagged, and its zigzag count comes from the bite, not a number
     * somebody liked (⛔ wing §24d). */
    var tooth = Math.max(2, bite * 0.22);
    var teeth = C.fitRepeat(bite, tooth, tooth * 1.25);
    var path = [pa];
    for (var t = 1; t < teeth.count; t++) {
      var f = t / teeth.count;
      var mid = toward(pa, pb, f);
      var push = (t % 2 ? 1 : -1) * tooth * 0.55;
      path.push([mid[0] + push * 0.7, mid[1] - push * 0.7]);
    }
    path.push(pb); path.push(c);
    ctx.save();
    ctx.beginPath(); tracePoly(ctx, path);
    ctx.fillStyle = behind;
    ctx.fill();
    ctx.restore();
    return bite;
  }

  /* -------------------------------------------------------------- the sign --*/

  /**
   * Draw one whole sign: iron, chain, board, device, lettering, weather.
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {object} p A profile from BracketRead.
   * @param {number} x Left of the sign's box. @param {number} y Top of it.
   * @param {number} height The sign's full height in pixels.
   * @param {object} [opt] `{behind}` the colour behind the sign, for the crack;
   *   `{swing}` degrees added to the hang. The iron is always drawn; to draw
   *   the iron alone, call `drawIron` with the same arguments this function
   *   uses (the wall at `x + max(2, ironH * 0.20)`, the reach from geometry).
   * @returns {object} The counts every probe reads.
   */
  function drawSign(ctx, p, x, y, height, opt) {
    var C = K();
    var o = opt || {};
    var g = C.geometry(p, height);
    var behind = o.behind || C.PALETTE.dusk;
    /* ⛔ The reach is the board's, derived in `geometry` — an arm shorter than
     * the board it carries leaves the far ring hanging from nothing. */
    var reach = g.reach;
    var wallX = x + Math.max(2, g.ironH * 0.20);
    var out = { device: 0, glyphs: 0, grain: 0, links: 0, nails: 0, crack: 0, paintBands: 0 };

    /* The iron hangs from the wall and does not swing. */
    var iron = drawIron(ctx, g, p, wallX, y, reach, behind);
    out.links = iron.links; out.nails = iron.nails;
    out.leaves = iron.leaves; out.brace = iron.brace;
    out.ornStrokes = iron.ornStrokes;

    /* The board swings under the rings. ⛔ wing §15e: a GIF frame must be driven
     * to an EXPLICIT state, so the swing is a parameter and never a clock.
     * ⛔ The board's top is where the CHAIN ACTUALLY ENDS, reported by the iron
     * that drew it — not a separate arithmetic that can drift away from it. */
    var swing = (Number(o.swing) || 0) + (Number(p.tilt) || 0) * 0.18;
    var boardTop = iron.chainEndY;
    var pivotX = wallX + (g.ring.leftX + g.ring.rightX) / 2;
    var pivotY = iron.armY;
    var ox = pivotX - g.boardW / 2;

    ctx.save();
    ctx.translate(pivotX, pivotY);
    ctx.rotate(swing * Math.PI / 180);
    ctx.translate(-pivotX, -pivotY);

    var bc = paintBoard(ctx, g, p, ox, boardTop);
    out.grain = bc.grainStrokes; out.paintBands = bc.paintBands;

    /* The device, inked against whatever the board actually is. */
    var field = C.SCHEME_FIELD[p.scheme];
    var ground = C.groundFor(p.scheme);
    var w = C.weather(p.weathering);
    var gl = C.parseHex(C.PALETTE.giltLit), gs = C.parseHex(C.PALETTE.giltShadow);
    var dulled = {
      r: gl.r + (gs.r - gl.r) * w.giltDull,
      g: gl.g + (gs.g - gl.g) * w.giltDull,
      b: gl.b + (gs.b - gl.b) * w.giltDull
    };
    var devPick = C.pickContrast(ground, [
      dulled, C.parseHex(C.PALETTE.oxblood), { r: 26, g: 18, b: 12 }, C.parseHex(C.PALETTE.chalk)
    ], 3.4);
    var devCounter = C.toHex(C.relief(devPick.ink, -1, 46));
    var devCx = ox + g.boardW / 2;
    var devCy = boardTop + g.by(g.yMin + g.span * g.device.y);
    out.device = drawDevice(ctx, p.device, devCx, devCy, g.device.w, g.device.h,
      C.toHex(devPick.ink), devCounter);
    out.deviceRatio = devPick.ratio;

    var lt = letterBoard(ctx, g, p, ox, boardTop);
    out.glyphs = lt.glyphs; out.squeeze = lt.squeeze; out.nameRatio = lt.ratio;

    out.crack = crackCorner(ctx, g, p, ox, boardTop, behind);
    ctx.restore();

    out.geometry = g;
    return out;
  }

  /**
   * The dusk street the Close Look stands the sign against — sky, three blurred
   * lantern discs, a wall plane. The product draws all of it: no tile, no RTP,
   * nothing shipped (⛔ wing §15b).
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {number} w Width. @param {number} h Height.
   * @param {number} seed A seed, so the street is the same every time.
   * @returns {number} Lanterns drawn.
   */
  function drawStreet(ctx, w, h, seed) {
    var C = K();
    var R = CSAF.BracketRead;
    var rnd = R.rng(seed || 7);
    var sky = ctx.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, '#131a25');
    sky.addColorStop(0.55, C.PALETTE.dusk);
    sky.addColorStop(1, '#273040');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h);

    /* The wall plane: a flat face with a coursing pitch derived from its own
     * height, never a typed course count (⛔ wing §24d). */
    var wallW = w * 0.34;
    ctx.fillStyle = '#232b38';
    ctx.fillRect(0, 0, wallW, h);
    var courseInk = Math.max(1, h * 0.006);
    var courses = C.fitRepeat(h, courseInk, h * 0.052);
    ctx.strokeStyle = 'rgba(10,14,20,0.55)';
    ctx.lineWidth = courseInk;
    for (var i = 1; i < courses.count; i++) {
      var y = i * courses.pitch;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(wallW, y); ctx.stroke();
    }
    ctx.fillStyle = 'rgba(255,228,170,0.05)';
    ctx.fillRect(wallW - 3, 0, 3, h);

    /* ⛔ wing §18, MEASURED on the art stage of 2026-09-14 by opening
     * `g1_closelook.png`: the sign hangs off a wall on the left and the right
     * THIRD of the hero frame was flat dusk. A backdrop of a wall and three
     * blurred discs does not make a street, and dead space in a gallery image is
     * a Gate 1 defect rather than a stylistic choice. What follows is the rest
     * of the street, all of it drawn by the product: a terrace receding down the
     * far side, two more signs too distant to read, and the cobbles they stand
     * on with the lantern light pooling across them.
     * ⛔ Everything below is derived from the frame it is drawn into and from
     * the seeded RNG the Close Look already carries — no `Math.random()` in game
     * logic (wing §6 rule 2), so a given sign gets the same street every time. */

    /* The far terrace: gables at a declared pitch, count derived from the run. */
    var farY = h * 0.34;
    var runW = w - wallW;
    var gableW = Math.max(24, runW * 0.16);
    var gables = C.fitRepeat(runW, gableW, gableW * 1.08);
    var far = 0;
    for (var G = 0; G < gables.count; G++) {
      var gx = wallW + G * gables.pitch;
      var gh = farY * (0.62 + rnd() * 0.34);
      /* ⛔ wing §21b: "the code ran" and "the picture changed" are different
       * claims. The first cut of these gables was `#1b222e` and `#1e2634`
       * against a `#1c2431` sky — two levels apart, which is to say invisible,
       * and every count said three gables had been drawn. A silhouette is a
       * VALUE, so these are a clear step darker than the sky they cut into. */
      ctx.fillStyle = G % 2 ? '#0e131b' : '#121822';
      ctx.beginPath();
      ctx.moveTo(gx, h * 0.66);
      ctx.lineTo(gx, h * 0.66 - gh);
      ctx.lineTo(gx + gableW * 0.5, h * 0.66 - gh - gableW * 0.28);
      ctx.lineTo(gx + gableW, h * 0.66 - gh);
      ctx.lineTo(gx + gableW, h * 0.66);
      ctx.closePath();
      ctx.fill();
      /* One lit window per gable, which is what makes a silhouette a street. */
      if (G % 2 === 0) {
        ctx.fillStyle = 'rgba(255,214,140,0.20)';
        ctx.fillRect(gx + gableW * 0.34, h * 0.66 - gh * 0.62, gableW * 0.2, gh * 0.16);
      }
      far++;
    }

    /* The ground: cobbles in shadow, with a course pitch of their own. */
    var groundY = h * 0.66;
    var gg = ctx.createLinearGradient(0, groundY, 0, h);
    gg.addColorStop(0, '#1a212b');
    gg.addColorStop(1, '#0f141b');
    ctx.fillStyle = gg;
    ctx.fillRect(0, groundY, w, h - groundY);
    var cobbleInk = Math.max(1, h * 0.004);
    var rows = C.fitRepeat(h - groundY, cobbleInk, (h - groundY) * 0.14);
    ctx.strokeStyle = 'rgba(60,72,92,0.35)';
    ctx.lineWidth = cobbleInk;
    for (var cr = 1; cr < rows.count; cr++) {
      var cy = groundY + cr * rows.pitch;
      ctx.beginPath(); ctx.moveTo(0, cy); ctx.lineTo(w, cy); ctx.stroke();
    }

    /* ONE more sign down the row, small and soft — the product's OWN render at a
     * distance, so the hero frame says "every door" rather than "one door".
     * ⛔ There were TWO in the first cut and they read as bright blobs competing
     * with the hero; a second copy of the subject is not depth, it is clutter
     * (Icon_Doctrine §14a: the fix for a weak read is never MORE of it). One,
     * placed low and right where the frame was emptiest, blurred and dimmed far
     * enough that it reads as a sign without asking to be read. */
    var distant = 0;
    var farSign = { name: 'WEIR FISH', trade: 'FISHMONGER', device: 'fish', board: 'lozenge',
      bracket: 'barAndRing', scheme: 'verdigris', weathering: 3, tilt: 3, seed: 47 };
    ctx.save();
    ctx.globalAlpha = 0.26;
    ctx.filter = 'blur(3px)';
    drawSign(ctx, farSign, wallW + runW * 0.62, h * 0.30, h * 0.155, { behind: '#1c2431' });
    ctx.restore();
    ctx.filter = 'none';
    distant++;

    /* Three lanterns, well out of focus, drawn LAST so they wash over the
     * street rather than sitting behind it. */
    var n = 0;
    for (var L = 0; L < 3; L++) {
      var lx = wallW + (0.18 + rnd() * 0.72) * (w - wallW);
      var ly = h * (0.10 + rnd() * 0.55);
      var lr = h * (0.05 + rnd() * 0.06);
      var gd = ctx.createRadialGradient(lx, ly, 0, lx, ly, lr * 3.4);
      gd.addColorStop(0, 'rgba(255,226,160,0.55)');
      gd.addColorStop(0.34, 'rgba(228,170,90,0.16)');
      gd.addColorStop(1, 'rgba(228,170,90,0)');
      ctx.fillStyle = gd;
      ctx.beginPath(); ctx.arc(lx, ly, lr * 3.4, 0, Math.PI * 2); ctx.fill();
      n++;
    }
    return { lanterns: n, gables: far, distantSigns: distant };
  }

  /**
   * Choose the grid that draws `n` signs as LARGE as the frame allows.
   *
   * ⛔ wing §18b: a scene that wastes its frame is a PRODUCT defect, not a
   * capture one — Glaze hard-coded `cols = 6` and put twelve vessels at 114 px
   * into 266 px rows. Every plausible column count is tried, the largest sign
   * wins, and ties break on fewest empty cells.
   *
   * ⛔ wing §26e / §25a: this is its own named function, reachable by the suite
   * WITHOUT A CANVAS, because the first version lived inside `drawYard` and the
   * only way to see what it chose was to run the whole engine and read a number
   * off a scene. It chose one column of twelve and no unit test could say why.
   *
   * ⛔ wing §18b again, and this is the defect that hid in it: THE ROW PITCH IS
   * THE FRAME'S, NOT THE CELL'S. A row must leave room for the RAIL the signs
   * hang from as well as for the sign, so the usable cell height is what is
   * left after the rail — and forgetting that is what made a tall thin column
   * score as though its cells were full height.
   *
   * @param {number} n How many signs.
   * @param {number} w Usable width in pixels.
   * @param {number} h Usable height in pixels.
   * @returns {?object} `{cols, rows, cellW, cellH, signH, empties}`, or null.
   */
  function solveGrid(n, w, h) {
    if (!isFinite(n) || n <= 0 || !isFinite(w) || !isFinite(h) || w <= 0 || h <= 0) return null;
    var best = null;
    for (var cols = 1; cols <= n; cols++) {
      var rows = Math.ceil(n / cols);
      var cellW = w / cols;
      var cellH = h / rows;
      /* A sign hangs from a rail and swings a little, so it cannot use the
       * whole cell in either direction. `WIDEST` is the widest board aspect in
       * the corpus (the scroll end, 1.80) plus the bracket's reach — a sign
       * wider than its cell overlaps its neighbour, which is the failure a
       * height-only solve cannot see. */
      var WIDEST = 2.10;
      var signH = Math.min(cellH * 0.88, cellW / WIDEST);
      var empties = cols * rows - n;
      if (!best || signH > best.signH + 0.001
        || (Math.abs(signH - best.signH) <= 0.001 && empties < best.empties)) {
        best = { cols: cols, rows: rows, cellW: cellW, cellH: cellH, signH: signH, empties: empties };
      }
    }
    return best;
  }

  /**
   * The Signwright's Yard: every sign in the town hung on oak rails.
   *
   * ⛔ wing §18b: a scene that wastes its frame is a PRODUCT defect, not a
   * capture one. The grid is SOLVED — every plausible column count is tried, the
   * largest cell wins, ties break on fewest empty cells, and a partial last row
   * is centred. Nobody types `cols = 6`.
   *
   * @param {CanvasRenderingContext2D} ctx The context.
   * @param {object[]} profiles The signs.
   * @param {number} w Width. @param {number} h Height.
   * @param {object} [opt] `{title, head, foot, minSign}`.
   * @returns {object} `{cols, rows, signH, drawn, empties}`.
   */
  function drawYard(ctx, profiles, w, h, opt) {
    var C = K();
    var o = opt || {};
    var head = (o.head === undefined) ? h * 0.10 : o.head;
    var foot = (o.foot === undefined) ? h * 0.05 : o.foot;
    var padX = w * 0.025;
    var list = profiles || [];
    var n = list.length;

    var usableW = w - padX * 2, usableH = h - head - foot;
    var best = solveGrid(n, usableW, usableH);
    /* ⛔ master §2b: NAME EVERY REFUSAL. The first version of this branch
     * returned a bag of zeros with no word about WHY, and an in-engine failure
     * could not be told apart from an empty town, a zero-height frame and a
     * negative usable width. A refusal that does not report its inputs costs a
     * whole debugging session. */
    if (!best) {
      return {
        cols: 0, rows: 0, signH: 0, drawn: 0, empties: 0,
        n: n, w: w, h: h, usableW: usableW, usableH: usableH,
        why: (n <= 0 ? 'no signs to hang'
          : (usableW <= 0 ? 'no usable width' : 'no usable height'))
      };
    }

    /* The ground: a dark yard wall so the oak reads warm against it. */
    var bg = ctx.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, '#161d27');
    bg.addColorStop(1, '#1f2733');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    var drawn = 0;
    for (var r = 0; r < best.rows; r++) {
      var rowY = head + r * best.cellH;
      /* One oak rail per row, and the signs hang from it. */
      var railH = Math.max(3, best.signH * 0.055);
      ctx.fillStyle = '#4a2c14';
      ctx.fillRect(padX * 0.4, rowY, w - padX * 0.8, railH);
      ctx.fillStyle = 'rgba(180,132,80,0.5)';
      ctx.fillRect(padX * 0.4, rowY, w - padX * 0.8, Math.max(1, railH * 0.3));

      var inRow = Math.min(best.cols, n - r * best.cols);
      var rowW = inRow * best.cellW;
      var startX = padX + (w - padX * 2 - rowW) / 2;   /* a partial row is CENTRED */
      for (var c = 0; c < inRow; c++) {
        var p = list[r * best.cols + c];
        if (!p) continue;
        var g = C.geometry(p, best.signH);
        var cellCx = startX + c * best.cellW + best.cellW / 2;
        /* drawSign puts the wall at x + max(2, ironH*0.20) and hangs the board
         * from the rings just outboard of it, so this is what centres the BOARD
         * in its cell rather than the bracket. */
        var x = cellCx - g.boardW / 2 - Math.max(2, g.ironH * 0.20);
        drawSign(ctx, p, x, rowY, best.signH, { behind: '#1b2330' });
        drawn++;
      }
    }
    return { cols: best.cols, rows: best.rows, signH: best.signH, drawn: drawn, empties: best.empties, n: n, w: w, h: h };
  }

  return {
    FACE_DISPLAY: FACE_DISPLAY, FACE_BODY: FACE_BODY,
    drawSign: drawSign, drawDevice: drawDevice, drawStreet: drawStreet, drawYard: drawYard,
    solveGrid: solveGrid,
    paintBoard: paintBoard, letterBoard: letterBoard, drawIron: drawIron,
    crackCorner: crackCorner, fitLine: fitLine, boardPixels: boardPixels,
    insetPolygon: insetPolygon, offsetPolygon: offsetPolygon, tracePoly: tracePoly
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.BracketRender;
