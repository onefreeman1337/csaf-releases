//=============================================================================
// BracketRead.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Bracket [2/4] — the reader. Turns a shop's own goods list into the sign it hangs. Knows nothing about RPG Maker. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * BracketRead — what the shop sells decides what the sign shows
 * ============================================================================
 * A reader, not a plugin. It patches nothing, adds no scene and touches no
 * core method. Enable it with the other three files and forget it exists.
 *
 * Given one shop — its goods rows, its name, and the district it stands in —
 * it answers with the four things a signwright would decide, each from a
 * different piece of that shop's own data:
 *
 *   DEVICE    what the shop SELLS       (structure first, then names)
 *   BOARD     the shop's NAME           (its identity is its shape)
 *   BRACKET   the shop's STANDING       (goods count and best price)
 *   SCHEME    the TEMPER of the stock   (iron, glass, grain, ink, stone)
 *   WEATHER   the DISTRICT it hangs in  (0 crisp .. 4 falling apart)
 *
 * Change the goods and the sign re-composes. That is the whole product.
 * ============================================================================
 */

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};

CSAF.BracketRead = (function () {
  'use strict';

  /* ------------------------------------------------------------ vocabulary --
   * ⛔ wing §25a: a declared axis that nothing READS is three constants and a
   * type-checker. Every id below is reached by a named function the suite can
   * call directly, and `_probe/axis_reads.js` asserts each one MOVES the
   * picture. ⛔ wing §24a: the structural pass scores what the buyer CHOSE to
   * stock (kind, equip slot, effect code, type id); the name pass is a second,
   * weaker voice, never the only one.
   */

  /** The twelve trade devices. Order is fixed: an index is a save-compatible id. */
  var DEVICES = [
    'swordAnvil', 'shield', 'flask', 'herb', 'gem', 'scroll',
    'loaf', 'tankard', 'key', 'shears', 'fish', 'horseshoe'
  ];

  /** The trade line struck in small caps under the name. One per device. */
  var TRADES = {
    swordAnvil: 'SMITH', shield: 'ARMOURER', flask: 'APOTHECARY', herb: 'HERBALIST',
    gem: 'JEWELLER', scroll: 'SCRIBE', loaf: 'BAKER', tankard: 'TAVERN',
    key: 'INN', shears: 'TAILOR', fish: 'FISHMONGER', horseshoe: 'FARRIER'
  };

  /* The ten board outlines. `heater` rather than `shield` on purpose: the
   * armourer's DEVICE is already called shield, and one word meaning two
   * different things in one corpus is how a caption comes to name a property
   * the draw never lands (wing §17c). */
  var BOARDS = [
    'heater', 'oval', 'lozenge', 'hanging', 'arch',
    'banner', 'keyhole', 'barrelEnd', 'tankardCut', 'scrollEnd'
  ];

  /** The eight bracket forms, poorest first — standing is meant to be VISIBLE. */
  var BRACKETS = [
    'plainHook', 'barAndRing', 'singleScroll', 'doubleScroll',
    'volute', 'leafScroll', 'gallows', 'crownedScroll'
  ];

  /** The six paint schemes. `oak` is bare wood: no field colour at all. */
  var SCHEMES = ['oak', 'verdigris', 'oxblood', 'indigo', 'mustard', 'giltOak'];

  /* Names the goods can carry, per device. The STRUCTURAL pass outranks this:
   * these only speak when the structure is silent or split. Kept short on
   * purpose — a long word list is a guess wearing a lab coat. */
  var WORDS = {
    loaf: ['bread', 'loaf', 'bun', 'roll', 'pie', 'cake', 'biscuit', 'flour', 'grain', 'pastry', 'oat'],
    tankard: ['ale', 'beer', 'wine', 'mead', 'cider', 'brew', 'tankard', 'draught', 'grog', 'rum', 'spirit'],
    fish: ['fish', 'cod', 'trout', 'eel', 'herring', 'salmon', 'crab', 'oyster', 'net', 'roe',
      'whelk', 'mussel', 'clam', 'shrimp', 'prawn', 'sprat', 'pike', 'carp', 'tide', 'wharf', 'quay'],
    horseshoe: ['horse', 'shoe', 'saddle', 'bridle', 'rein', 'stable', 'harness', 'spur', 'hoof', 'oats'],
    herb: ['herb', 'leaf', 'root', 'antidote', 'salve', 'poultice', 'seed', 'moss', 'fern', 'bloom'],
    flask: ['potion', 'elixir', 'tonic', 'draught', 'water', 'vial', 'flask', 'philtre', 'drop', 'essence'],
    scroll: ['scroll', 'book', 'tome', 'grimoire', 'rune', 'map', 'ink', 'quill', 'page', 'chart'],
    gem: ['gem', 'ring', 'jewel', 'pearl', 'amulet', 'pendant', 'crown', 'stone', 'opal', 'garnet'],
    shears: ['cloth', 'robe', 'coat', 'cloak', 'silk', 'linen', 'thread', 'gown', 'tunic', 'hat'],
    key: ['bed', 'room', 'lodging', 'rest', 'key', 'night', 'board', 'bunk'],
    swordAnvil: ['sword', 'blade', 'axe', 'dagger', 'spear', 'hammer', 'anvil', 'forge', 'steel', 'iron'],
    shield: ['shield', 'buckler', 'targe', 'aegis', 'guard', 'plate', 'mail', 'helm', 'greave', 'pauldron']
  };

  /* Words that appear in a shop's NAME and name its trade outright — the
   * weakest voice of the three, and the one a buyer controls most directly by
   * typing a name. "The Gilded Tankard" is a tavern even with an empty stock. */
  var NAME_WORDS = WORDS;

  /* MZ effect codes, read out of the engine rather than remembered:
   * rmmz_objects.js Game_Action.prototype.applyItemEffect switches on these.
   * 11 HP recover · 12 MP recover · 22 remove state · 21 add state · 42 grow. */
  var EFFECT_HP = 11, EFFECT_MP = 12, EFFECT_REMOVE_STATE = 22;
  var EFFECT_ADD_STATE = 21, EFFECT_GROW = 42;

  /* ---------------------------------------------------------------- tools --*/

  /**
   * A stable 32-bit hash. The same shop must get the same sign on every boot
   * and in every session, so nothing here may touch Math.random (wing §6.2).
   * @param {string} s Any string.
   * @returns {number} An unsigned 32-bit integer.
   */
  function hash(s) {
    var h = 2166136261;
    var str = String(s === undefined || s === null ? '' : s);
    for (var i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
    }
    return h >>> 0;
  }

  /**
   * A deterministic stream from one seed — the RNG seam (wing §6.2). Nothing in
   * this product ever calls Math.random; a sign is a pure function of its shop.
   * @param {number} seed Any integer.
   * @returns {function(): number} Successive values in [0, 1).
   */
  function rng(seed) {
    var s = (seed >>> 0) || 1;
    return function () {
      s ^= s << 13; s >>>= 0;
      s ^= s >> 17;
      s ^= s << 5; s >>>= 0;
      return s / 4294967296;
    };
  }

  /**
   * Coerce to a finite number.
   * ⛔ wing §26e: a NaN that reaches a threshold makes every `got >= want`
   * false and a solver return its extreme, which a probe then scores perfect.
   * Every number crossing a seam in this product goes through here.
   * @param {*} v Anything.
   * @param {number} dflt The value to use when `v` is not finite.
   * @returns {number} A finite number, always.
   */
  function fin(v, dflt) {
    var n = Number(v);
    return isFinite(n) ? n : dflt;
  }

  /** @param {*} s Anything. @returns {string} Lower-cased text, never null. */
  function low(s) { return String(s === undefined || s === null ? '' : s).toLowerCase(); }

  /* ------------------------------------------------------------ the goods --
   * A goods row as this reader wants it. The engine seam (Bracket.js) builds
   * these from `$dataItems` / `$dataWeapons` / `$dataArmors`; the suite builds
   * them by hand. Both paths produce the SAME shape, so the reader cannot tell
   * them apart — wing §11, two paths that agree by construction.
   *
   *   {kind:'item'|'weapon'|'armor', id, name, price,
   *    itypeId, etypeId, wtypeId, atypeId, effects:[{code,dataId,value1}],
   *    typeName}          // the buyer's OWN word for the type, from $dataSystem
   */

  /**
   * Score the twelve devices against one shop's goods and name.
   *
   * Three voices, deliberately unequal:
   *   STRUCTURE (3 points) what the row IS — kind, equip slot, effect code.
   *   GOODS NAMES (2)      what the rows are CALLED.
   *   SHOP NAME (1)        what the shopkeeper calls the place.
   *
   * ⛔ wing §24a: the structural pass reads the buyer's own type vocabulary
   * (`typeName`, taken from $dataSystem.weaponTypes / armorTypes / equipTypes)
   * rather than a guessed stopword list, so a project that renamed "Sword" to
   * "Zhanmadao" still scores a smith.
   *
   * @param {object[]} goods The shop's goods rows.
   * @param {string} shopName The shop's name, or ''.
   * @returns {object} `{scores:{device:number}, top:string, runnerUp:string, margin:number}`
   */
  function scoreDevices(goods, shopName) {
    var scores = {};
    for (var d = 0; d < DEVICES.length; d++) scores[DEVICES[d]] = 0;
    var rows = Array.isArray(goods) ? goods : [];
    var silent = 0;                 /* rows that told the reader nothing at all */

    for (var i = 0; i < rows.length; i++) {
      var g = rows[i] || {};
      var name = low(g.name);
      var tname = low(g.typeName);

      /* --- voice one: structure, 3 points ---------------------------------*/
      if (g.kind === 'weapon') {
        /* A staff or a wand is a scribe's stock, not a smith's. The word comes
         * from the BUYER'S weaponTypes table, not from ours. */
        if (/staff|wand|rod|tome|grimoire/.test(tname)) scores.scroll += 3;
        else scores.swordAnvil += 3;
      } else if (g.kind === 'armor') {
        var et = fin(g.etypeId, 0);
        /* equipTypes: 1 Weapon, 2 Shield, 3 Head, 4 Body, 5 Accessory. */
        if (et === 2 || /shield|buckler|targe/.test(tname)) scores.shield += 3;
        else if (et === 5) scores.gem += 3;
        else if (/light|cloth|robe|magic/.test(tname)) scores.shears += 3;
        else if (et === 3 || et === 4) scores.shield += 2, scores.shears += 1;
        else scores.shield += 2;
      } else {
        /* An item speaks through what it DOES. */
        var fx = Array.isArray(g.effects) ? g.effects : [];
        var spoke = false;
        for (var e = 0; e < fx.length; e++) {
          var code = fin(fx[e] && fx[e].code, -1);
          if (code === EFFECT_HP || code === EFFECT_MP) { scores.flask += 3; spoke = true; }
          else if (code === EFFECT_REMOVE_STATE) { scores.herb += 3; spoke = true; }
          else if (code === EFFECT_ADD_STATE || code === EFFECT_GROW) { scores.scroll += 3; spoke = true; }
        }
        /* itypeId 2 is a Key Item: a shop selling those is keeping rooms. */
        if (fin(g.itypeId, 1) === 2) { scores.key += 3; spoke = true; }
        /* ⛔⛔ THIS USED TO BE `if (!spoke) scores.flask += 1;` AND IT WAS A BIAS
         * THAT GREW WITH THE SHOP. An ordinary consumable with no effects told
         * the reader nothing, and the reader recorded that silence as a vote for
         * APOTHECARY — once per row. So a tavern with six drinks on the shelf
         * scored flask 10 and tankard 6 and hung a flask, and the bigger the
         * shop the more certainly it was called an apothecary.
         *
         * MEASURED 2026-09-14 while building the gallery GIF, which is the only
         * reason it surfaced: four different goods lists, every one of them
         * derived `flask`, and the GIF would have shown a caption claiming a
         * change that never happened. It was ALREADY WRONG IN THE SHIPPED DEMO
         * TOWN — Netherbank has two apothecaries and no tavern, and "Last Cup"
         * is plainly a tavern. `spread_check` could not see it because every
         * axis was still REACHED; a wrong answer and a missing answer look
         * nothing alike.
         *
         * A silence is not evidence. It is counted once, for the whole shop, and
         * only if the shop said nothing else at all — which is what the fallback
         * was ever meant to be. */
        if (!spoke) silent++;
      }

      /* --- voice two: the goods' own names, 2 points -----------------------*/
      for (var k = 0; k < DEVICES.length; k++) {
        var dev = DEVICES[k];
        var list = WORDS[dev] || [];
        for (var w = 0; w < list.length; w++) {
          if (name.indexOf(list[w]) >= 0) { scores[dev] += 2; break; }
        }
      }
    }

    /* --- voice three: the shop's own name, 1 point -------------------------*/
    var sn = low(shopName);
    if (sn) {
      for (var n = 0; n < DEVICES.length; n++) {
        var dv = DEVICES[n];
        var nl = NAME_WORDS[dv] || [];
        for (var q = 0; q < nl.length; q++) {
          if (sn.indexOf(nl[q]) >= 0) { scores[dv] += 1; break; }
        }
      }
    }

    /* ⛔ The silent rows, counted ONCE for the whole shop and only when nothing
     * else spoke. A shelf of plain consumables that match no word and carry no
     * effect is weak evidence of a general store, and the nearest thing this
     * corpus has to one is the apothecary — but it is worth exactly one point,
     * not one per row (see the note above `silent++`). */
    var any = false;
    for (var t = 0; t < DEVICES.length; t++) if (scores[DEVICES[t]] > 0) any = true;
    if (!any && silent > 0) { scores.flask += 1; any = true; }

    /* A shop with nothing to sell keeps rooms. This is the one default, and it
     * is a statement rather than a fallback: an empty goods list on a door is
     * an inn in every town ever built. */
    if (!any) scores.key += 1;

    /* Rank. Ties break on the FIXED device order, so the answer never depends
     * on object key order (which V8 does not promise for us here). */
    var best = DEVICES[0], second = DEVICES[0];
    for (var r = 0; r < DEVICES.length; r++) {
      if (scores[DEVICES[r]] > scores[best]) best = DEVICES[r];
    }
    var secondScore = -1;
    for (var r2 = 0; r2 < DEVICES.length; r2++) {
      if (DEVICES[r2] === best) continue;
      if (scores[DEVICES[r2]] > secondScore) { secondScore = scores[DEVICES[r2]]; second = DEVICES[r2]; }
    }
    return {
      scores: scores,
      top: best,
      runnerUp: second,
      margin: scores[best] - (secondScore < 0 ? 0 : secondScore)
    };
  }

  /**
   * The device this shop hangs.
   * @param {object} shop A shop record.
   * @returns {string} One of `DEVICES`.
   */
  function deviceFor(shop) {
    var s = shop || {};
    if (s.device && DEVICES.indexOf(s.device) >= 0) return s.device;   /* the hand always wins */
    return scoreDevices(s.goods, s.name).top;
  }

  /**
   * A shop's stock, as one short string. This is the identity of a shop that
   * was never given a name — the only thing it has that is its own.
   * @param {object} shop A shop record.
   * @returns {string} A stable fingerprint.
   */
  function goodsPrint(shop) {
    var rows = (shop && Array.isArray(shop.goods)) ? shop.goods : [];
    var parts = [];
    for (var i = 0; i < rows.length; i++) {
      var g = rows[i] || {};
      parts.push(String(g.kind || '?') + ':' + low(g.name) + ':' + fin(g.price, 0));
    }
    return parts.join(',');
  }

  /* ⛔ wing §8 trap 2: siblings at FIRST USE, never at load time — the buyer
   * chooses the load order and `mz_harness build` loads the folder
   * alphabetically. `boardFor` needs the drawing kit's measured capacities. */
  var _K = null;
  function kit() {
    if (!_K && typeof CSAF !== 'undefined') _K = CSAF.BracketCompose;
    return _K;
  }

  /**
   * The board outline: THE BOARD IS CUT TO FIT THE NAME.
   *
   * A signwright does not pick a shape and then squeeze the words onto it. Each
   * of the ten outlines takes a measured number of characters on its own name
   * line — `BracketCompose.capacityOf`, read from the OUTLINE ITSELF, not from
   * a table anyone typed — and the shop's name is cut onto one of the three
   * that fit it best, with its trade's own cut favoured when it is among them.
   *
   * ⛔ wing §21i / §25f: the first version FORCED three trades onto one board
   * each, and the second drew from two fixed pools; both quietly deleted an
   * axis — two of the ten outlines never appeared in a forty-eight shop town.
   * Ranking on a measured fit uses all ten, and the reason a board was chosen
   * is legible on the sign.
   *
   * @param {object} shop A shop record.
   * @param {string} device The device already chosen.
   * @returns {string} One of `BOARDS`.
   */
  function boardFor(shop, device) {
    var s = shop || {};
    if (s.board && BOARDS.indexOf(s.board) >= 0) return s.board;
    var name = String(s.name || '');
    var len = Math.max(1, name.length);
    /* ⛔ A shop with no name hashed to the SAME value as every other shop of its
     * trade, so widening the shortlist would have changed nothing — six boards
     * and one hash is still one board. An unnamed shop's identity is its STOCK,
     * so that is what it is hashed on. */
    var h = hash('board|' + (name || goodsPrint(s)) + '|' + device);
    var K = kit();

    /* A trade whose object IS a shape gets that shape cut for it when the name
     * will sit on it — the tavern's tankard, the inn's keyhole, the scribe's
     * rolled ends. It is a bonus on the ranking, never an override. */
    var ownCut = { tankard: 'tankardCut', key: 'keyhole', scroll: 'scrollEnd' }[device];

    if (!K || typeof K.capacityOf !== 'function') {
      /* ⛔ wing §12.5: an unavailable instrument is UNKNOWN, not zero. With no
       * drawing kit to measure with, fall back to the hash over all ten rather
       * than to one board — a degraded answer, never a collapsed one. */
      return BOARDS[h % BOARDS.length];
    }

    var ranked = [];
    for (var i = 0; i < BOARDS.length; i++) {
      var cap = K.capacityOf(BOARDS[i]);
      /* Overflowing a board is worse than leaving room on it, so a name longer
       * than the board's run is penalised twice as hard as one shorter. */
      var miss = (len > cap) ? (len - cap) * 2 : (cap - len);
      if (ownCut === BOARDS[i]) miss -= 3.0;
      ranked.push({ id: BOARDS[i], miss: miss });
    }
    ranked.sort(function (a, b) {
      if (a.miss !== b.miss) return a.miss - b.miss;
      return BOARDS.indexOf(a.id) - BOARDS.indexOf(b.id);   /* stable, never key order */
    });
    /* ⛔ wing §21i, MEASURED 2026-09-13 on the STOCK MZ database: with no shop
     * names at all, every shop falls back to `defaultName`, every fallback name
     * is about the same length, and SIX of the ten boards became unreachable —
     * a buyer who names nothing saw four outlines. The less a shop tells us, the
     * WIDER the choice has to be: a named shop is cut from the three boards that
     * fit its name, an unnamed one from six, ranked the same way. */
    var named = String(s.name || '').trim().length > 0;
    var short = ranked.slice(0, named ? 3 : 6);
    return short[h % short.length].id;
  }

  /**
   * The bracket form. Standing is the axis, and it is meant to be READ: a shop
   * with two cheap rows hangs on a plain hook, a shop with a deep and costly
   * stock hangs on a crowned scroll.
   *
   * ⛔ wing §25g: the defect worth gating is standing being INVISIBLE — two
   * shops of different standing whose object does not differ. `standingOf`
   * is its own function so the suite can assert exactly that.
   *
   * @param {object} shop A shop record.
   * @returns {string} One of `BRACKETS`.
   */
  function bracketFor(shop) {
    var s = shop || {};
    if (s.bracket && BRACKETS.indexOf(s.bracket) >= 0) return s.bracket;
    return BRACKETS[standingOf(s)];
  }

  /* ⛔ wing §21i / §24a: ANCHOR TIER THRESHOLDS TO THE ENGINE'S OWN DATABASE,
   * NEVER TO TASTE. "Expensive" means nothing until you know what this project
   * charges for things. The default below is the STOCK MZ ladder, measured on
   * 2026-09-13 over the 145 priced rows of BlankProject's Items, Weapons and
   * Armors (q40 720, q65 1580, q85 3480) — and the engine seam replaces it with
   * the buyer's OWN quantiles at boot, so a project of copper coins and a
   * project of platinum both get the full range of brackets. */
  var PRICE_LADDER = [720, 1580, 3480];

  /**
   * Three price thresholds from a project's own prices.
   * ⛔ wing §12.5: an empty result is UNKNOWN, never zero — a database with no
   * priced row leaves the ladder exactly as it was rather than collapsing it.
   * @param {number[]} prices Every price worth more than nothing.
   * @returns {?number[]} `[q40, q65, q85]`, or null when there is nothing to read.
   */
  function ladderFrom(prices) {
    var ok = [];
    for (var i = 0; i < (prices || []).length; i++) {
      var v = fin(prices[i], 0);
      if (v > 0) ok.push(v);
    }
    if (ok.length < 4) return null;
    ok.sort(function (a, b) { return a - b; });
    function q(f) { return ok[Math.min(ok.length - 1, Math.floor(f * (ok.length - 1)))]; }
    return [q(0.40), q(0.65), q(0.85)];
  }

  /**
   * Adopt a price ladder. The engine seam calls this once at boot.
   * @param {?number[]} ladder Three ascending thresholds, or null to keep the current one.
   * @returns {number[]} The ladder now in force.
   */
  function usePriceLadder(ladder) {
    if (Array.isArray(ladder) && ladder.length === 3
      && isFinite(ladder[0]) && isFinite(ladder[1]) && isFinite(ladder[2])
      && ladder[0] > 0 && ladder[1] >= ladder[0] && ladder[2] >= ladder[1]) {
      PRICE_LADDER = [Number(ladder[0]), Number(ladder[1]), Number(ladder[2])];
    }
    return PRICE_LADDER.slice();
  }

  /**
   * How well this shop is doing, 0..7, from its own stock.
   * Depth (how many rows) and reach (the best price it dares ask) each carry
   * half the scale, so a deep cheap stall and a thin costly atelier land in
   * different places rather than averaging into the middle.
   * @param {object} shop A shop record.
   * @returns {number} An integer 0..7.
   */
  function standingOf(shop) {
    var rows = (shop && Array.isArray(shop.goods)) ? shop.goods : [];
    var best = 0;
    for (var i = 0; i < rows.length; i++) {
      var p = fin(rows[i] && rows[i].price, 0);
      if (p > best) best = p;
    }
    /* Depth 0..3, set at the measured quartiles of a real town's goods lists
     * (median 3 rows): a single-line stall, a stall, a shop, a warehouse. */
    var depth = rows.length >= 5 ? 3 : rows.length >= 3 ? 2 : rows.length >= 2 ? 1 : 0;
    /* Reach 0..3 against THIS project's ladder, never a remembered number. */
    var reach = best >= PRICE_LADDER[2] ? 3 : best >= PRICE_LADDER[1] ? 2
      : best >= PRICE_LADDER[0] ? 1 : 0;
    /* Breadth 0..1: a house stocking more than one KIND of thing, or carrying a
     * deep list, is a merchant rather than a stall.
     * ⛔ wing §21i: depth + reach alone runs 0..6, which is SEVEN values for
     * EIGHT brackets — the gallows was unreachable and the crowned scroll only
     * arrived by a remap that swallowed it. A third real signal from the data
     * makes the scale honestly 0..7 and every form reachable. */
    var kinds = {};
    for (var k = 0; k < rows.length; k++) {
      var kind = rows[k] && rows[k].kind;
      if (kind) kinds[kind] = 1;
    }
    var breadth = (Object.keys(kinds).length >= 2 || rows.length >= 8) ? 1 : 0;
    return Math.max(0, Math.min(7, depth + reach + breadth));
  }

  /**
   * The paint scheme, from the TEMPER of what is sold: iron reddens a board,
   * glass greens it, ink darkens it to indigo, grain warms it to mustard, and
   * a shop with nothing costly enough to paint leaves the oak bare.
   * @param {object} shop A shop record.
   * @param {string} device The device already chosen.
   * @returns {string} One of `SCHEMES`.
   */
  function schemeFor(shop, device) {
    var s = shop || {};
    if (s.scheme && SCHEMES.indexOf(s.scheme) >= 0) return s.scheme;
    var byDevice = {
      swordAnvil: 'oxblood', shield: 'oxblood', horseshoe: 'oxblood',
      flask: 'verdigris', herb: 'verdigris', fish: 'verdigris',
      scroll: 'indigo', gem: 'indigo',
      loaf: 'mustard', tankard: 'mustard', key: 'mustard',
      shears: 'indigo'
    };
    var field = byDevice[device] || 'oak';
    var st = standingOf(s);
    /* ⛔ wing §21i: the first rule here was "standing <= 1 leaves the oak bare",
     * and it painted HALF THE TOWN one colour — a classifier quietly deleting an
     * axis, which is the defect that probe exists for. Poverty is not why a
     * board is bare: the FORGE TRADES leave it bare because a smith's sign is
     * scorched oak, and only the destitute and the grand depart from their
     * trade's own colour. */
    if (st >= 7) return 'giltOak';               /* the grand gild the timber */
    if (device === 'swordAnvil' || device === 'horseshoe') return 'oak';
    if (st === 0) return 'oak';                  /* no money for paint at all */
    return field;
  }

  /**
   * Weathering, 0 crisp to 4 falling apart, from the district's prosperity.
   * ⛔ wing §26e: `prosperity` arrives from a plugin parameter, so it is a
   * STRING until it crosses this seam, and a blank one is absent rather than
   * zero (wing §16).
   * @param {object} shop A shop record carrying `prosperity` (0..4, high = rich).
   * @returns {number} An integer 0..4.
   */
  function weatherFor(shop) {
    var s = shop || {};
    if (s.weathering !== undefined && s.weathering !== null && String(s.weathering).trim() !== '') {
      var w = fin(s.weathering, 0);
      return Math.max(0, Math.min(4, Math.round(w)));
    }
    var prosp = (s.prosperity === undefined || s.prosperity === null || String(s.prosperity).trim() === '')
      ? 2 : fin(s.prosperity, 2);
    prosp = Math.max(0, Math.min(4, Math.round(prosp)));
    /* A shop is not only its street. A thriving trader on a poor row keeps his
     * sign painted, and a failing one on a good row does not — so the district
     * sets the base and the shop's OWN standing nudges it one step either way.
     * This is also what puts all five weathering levels into a town with four
     * districts, without anyone typing a level onto a shop. */
    var st = standingOf(s);
    var nudge = (st >= 6) ? -1 : (st <= 1) ? 1 : 0;
    return Math.max(0, Math.min(4, 4 - prosp + nudge));
  }

  /**
   * The whole sign, as data. Everything downstream — the drawing kit, the
   * scenes, the contact sheet — reads THIS and nothing else, so there is one
   * place where a sign is decided.
   * @param {object} shop A shop record.
   * @returns {object} The sign profile.
   */
  function profile(shop) {
    var s = shop || {};
    var device = deviceFor(s);
    var board = boardFor(s, device);
    var bracket = bracketFor(s);
    var scheme = schemeFor(s, device);
    var weathering = weatherFor(s);
    var name = String(s.name || '').trim() || defaultName(device);
    var seed = hash([name, device, board, bracket, scheme].join('|'));
    /* The hang. ⛔ wing §24d: the tilt is DERIVED from the seed, never typed
     * per sign, and it lands in 3..7 degrees either way of plumb. */
    var r = rng(seed);
    var tilt = (3 + r() * 4) * (r() < 0.5 ? -1 : 1);
    return {
      key: name + '#' + device,
      name: name,
      trade: String(s.trade || TRADES[device] || ''),
      device: device,
      board: board,
      bracket: bracket,
      scheme: scheme,
      weathering: weathering,
      standing: standingOf(s),
      tilt: tilt,
      seed: seed,
      goodsCount: (Array.isArray(s.goods) ? s.goods.length : 0)
    };
  }

  /**
   * A name for a shop that was never given one.
   * @param {string} device The device chosen.
   * @returns {string} A plain trade name.
   */
  function defaultName(device) {
    var t = TRADES[device] || 'SHOP';
    return 'The ' + t.charAt(0) + t.slice(1).toLowerCase();
  }

  /**
   * The full tuple two signs must not share, as one string.
   * The 48-sign distinctness test compares THESE (design brief, volumePlan).
   * @param {object} p A profile.
   * @returns {string} The tuple key.
   */
  function tupleOf(p) {
    return [p.device, p.board, p.bracket, p.scheme].join('/');
  }

  /**
   * How many signs this product COULD compose, and how many a given set of
   * shops actually RESOLVES to.
   * ⛔ wing §21i: the corpus size is what the product could make; what a buyer
   * sees is what their own database resolves to, and only the second is a
   * promise. Both numbers are returned so no caller can quote one for the other.
   * ⛔ wing §26c: a length measures something only if the entries ARE the thing
   * counted — `corpus` multiplies the four axis lengths and the weathering
   * ladder, and every one of those arrays is the array the drawing kit reads.
   * @param {object[]} [shops] Shop records to resolve, or none.
   * @returns {object} `{corpus, forms, resolved, distinctTuples, collisions}`
   */
  function volume(shops) {
    var forms = DEVICES.length * BOARDS.length * BRACKETS.length * SCHEMES.length;
    var out = {
      corpus: forms * 5,
      forms: forms,
      resolved: 0,
      distinctTuples: 0,
      collisions: []
    };
    if (!Array.isArray(shops) || !shops.length) return out;
    var seen = {};
    for (var i = 0; i < shops.length; i++) {
      var p = profile(shops[i]);
      var t = tupleOf(p);
      out.resolved++;
      if (seen[t]) out.collisions.push({ tuple: t, a: seen[t], b: p.name });
      else seen[t] = p.name;
    }
    out.distinctTuples = Object.keys(seen).length;
    return out;
  }

  return {
    DEVICES: DEVICES, BOARDS: BOARDS, BRACKETS: BRACKETS, SCHEMES: SCHEMES, TRADES: TRADES,
    hash: hash, rng: rng, fin: fin,
    scoreDevices: scoreDevices,
    deviceFor: deviceFor, boardFor: boardFor, bracketFor: bracketFor,
    schemeFor: schemeFor, weatherFor: weatherFor, standingOf: standingOf,
    ladderFrom: ladderFrom, usePriceLadder: usePriceLadder,
    /* Exported so the suite can compare them against the ENGINE'S OWN constant
     * assignments rather than against a number retyped in a test (wing §3a). */
    EFFECT_HP: EFFECT_HP, EFFECT_MP: EFFECT_MP, EFFECT_REMOVE_STATE: EFFECT_REMOVE_STATE,
    EFFECT_ADD_STATE: EFFECT_ADD_STATE, EFFECT_GROW: EFFECT_GROW,
    profile: profile, tupleOf: tupleOf, volume: volume, defaultName: defaultName
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.BracketRead;
