//=============================================================================
// Bracket.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Bracket [1/4] — the scenes, parameters and commands. Every shop in your town hangs its own sign, composed from what it actually sells. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Bracket — every door tells you what is behind it
 * ============================================================================
 * Load this LAST, after BracketCompose, BracketRead and BracketRender.
 *
 * WHAT IT DOES
 * Bracket reads the Shop Processing already in your events and hangs each shop
 * a wrought-iron bracket with a painted board on it: a trade device composed
 * from the goods that shop actually sells, the shop's name in carved or gilt
 * capitals, and weathering keyed to the district. Nothing is an image file and
 * nothing is shipped art — change a shop's stock and its sign re-composes.
 *
 * INSTALL
 * 1. Copy the four .js files into js/plugins and enable them in this order:
 *    BracketCompose, BracketRead, BracketRender, Bracket.
 * 2. Copy the two .woff2 files from fonts/ into your project's fonts/ folder.
 *    (Optional. Without them the lettering falls back to a serif — never to RPG
 *    Maker's own font, and a missing font can never stop your game booting.)
 *
 * THE FOUR PLACES A PLAYER MEETS A SIGN
 *   Over the door   Every event carrying a Shop Processing command gets its
 *                   sign hung above it on the map, automatically.
 *   The Close Look  Walk up and examine it: the sign at full size over a dusk
 *                   street, swinging on its chain. Plugin command "Close Look".
 *   The Directory   Every sign the player has seen, hung on the rails of the
 *                   Signwright's Yard. Menu command "Signs", or "Open Yard".
 *   The shop header The same sign above the goods windows in the shop scene.
 *
 * NOTETAGS — in an EVENT's note box. The hand always wins.
 *   <sign: The Gilded Tankard>     the name on the board
 *   <sign trade: VINTNER>          the line in small caps beneath it
 *   <sign device: tankard>         swordAnvil shield flask herb gem scroll
 *                                  loaf tankard key shears fish
 *                                  horseshoe
 *   <sign board: oval>             heater oval lozenge hanging arch banner
 *                                  keyhole barrelEnd tankardCut scrollEnd
 *   <sign bracket: volute>         plainHook barAndRing singleScroll
 *                                  doubleScroll volute leafScroll gallows
 *                                  crownedScroll
 *   <sign scheme: verdigris>       oak verdigris oxblood indigo mustard giltOak
 *   <sign weathering: 3>           0 crisp .. 4 falling apart
 *   <sign: skip>                   never hang a sign on this event
 *
 *   An event with NO Shop Processing can still carry a sign: give it
 *   <sign: The Wayfarer> and <sign device: key> and it hangs like any other.
 *
 * NOTETAGS — in a MAP's note box.
 *   <district: The Gilt Quarter>   the heading in the directory
 *   <prosperity: 4>                0 destitute .. 4 rich. Sets the weathering.
 *
 * SCRIPT
 *   CSAF.Bracket.signs()           every sign on this map, as data
 *   CSAF.Bracket.closeLook(id)     open the Close Look on one event's sign
 *   CSAF.Bracket.openYard()        open the directory
 *   CSAF.Bracket.seen()            how many signs the player has met
 *
 * COMPATIBILITY
 * Adds two scenes (Scene_BracketSign, Scene_BracketYard). Every core method it
 * touches is EXTENDED by saving the original and CALLING it — nothing is
 * replaced and nothing is overwritten. The compatibility block on the store
 * page lists them, generated from the code rather than typed.
 *
 * Only this file touches RPG Maker at all. BracketCompose, BracketRead and
 * BracketRender are a geometry kit, a reader and a painter, and none of them
 * knows the engine exists. Switch this file off and nothing is patched.
 * ============================================================================
 *
 * @param menuCommand
 * @text Menu command
 * @desc The wording of the command added to the main menu. Blank adds nothing.
 * @type string
 * @default Signs
 *
 * @param yardTitle
 * @text Directory heading
 * @desc The heading across the top of the Signwright's Yard.
 * @type string
 * @default The Signwright's Yard
 *
 * @param hangOnMap
 * @text Hang signs on the map
 * @desc Every event with a Shop Processing command gets its sign hung over it.
 * @type boolean
 * @default true
 *
 * @param signHeight
 * @text Map sign height
 * @desc How tall a sign is drawn over a door, in pixels.
 * @type number
 * @min 32
 * @max 320
 * @default 104
 *
 * @param closeLookHeight
 * @text Close Look height
 * @desc How tall a sign is drawn on the Close Look, in pixels.
 * @type number
 * @min 160
 * @max 560
 * @default 440
 *
 * @param shopHeader
 * @text Sign above the shop
 * @desc Draw the shop's own sign above the goods windows in the shop scene.
 * @type boolean
 * @default true
 *
 * @param shopHeaderHeight
 * @text Shop header height
 * @desc How tall the sign is in the shop scene, in pixels.
 * @type number
 * @min 80
 * @max 300
 * @default 160
 *
 * @param defaultProsperity
 * @text Default prosperity
 * @desc Used on maps with no <prosperity: n> note. 0 destitute, 4 rich.
 * @type number
 * @min 0
 * @max 4
 * @default 2
 *
 * @param closeLookHint
 * @text Close Look hint
 * @desc The quiet line at the foot of the Close Look. Blank for none.
 * @type string
 * @default OK to continue
 *
 * @param fontFolder
 * @text Font folder
 * @desc Where the two shipped .woff2 files live, relative to the game root.
 * @type string
 * @default fonts/
 *
 * @command closeLook
 * @text Close Look
 * @desc Open the full-size Close Look on one event's sign.
 *
 * @arg eventId
 * @text Event
 * @desc 0 means the event running this command.
 * @type number
 * @min 0
 * @default 0
 *
 * @command openYard
 * @text Open Yard
 * @desc Open the directory of every sign the player has met.
 *
 * @command showSignPicture
 * @text Show Sign Picture
 * @desc Draw an event's sign into a Game_Picture, for a cutscene.
 *
 * @arg eventId
 * @text Event
 * @type number
 * @min 0
 * @default 0
 *
 * @arg pictureId
 * @text Picture number
 * @type number
 * @min 1
 * @max 100
 * @default 1
 *
 * @arg x
 * @text X
 * @type number
 * @min -9999
 * @default 408
 *
 * @arg y
 * @text Y
 * @type number
 * @min -9999
 * @default 120
 */

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};
var CSAF = globalThis.CSAF;

CSAF.Bracket = (function () {
  'use strict';

  var PLUGIN = 'Bracket';
  var SAVE_VERSION = 1;

  /* ⛔ wing §8 trap 2: `mz_harness build` loads the plugin folder
   * ALPHABETICALLY, so this file — which is [1/4] — is parsed FIRST of the
   * four. Nothing below touches a sibling at load time; they are resolved at
   * first use, and the buyer's own load order cannot break it. */
  var _K = null, _R = null, _P = null;
  function deps() {
    if (!_K) { _K = CSAF.BracketCompose; _R = CSAF.BracketRead; _P = CSAF.BracketRender; }
    if (!_K || !_R || !_P) {
      throw new Error('Bracket: enable BracketCompose, BracketRead and BracketRender too.');
    }
    return _K;
  }

  /* ---------------------------------------------------------- parameters --*/

  /**
   * Plugin parameters.
   * ⛔ wing §16: parameters arrive as STRINGS, `Number('')` is 0 rather than
   * NaN, and `"0"` is TRUTHY — a raw id tested for truthiness is how Augury's
   * headline feature was disabled with every headless check green. Nothing here
   * tests a raw property for truth.
   * @returns {object} Parsed parameters.
   */
  function params() {
    var raw = (typeof PluginManager !== 'undefined' && PluginManager.parameters)
      ? PluginManager.parameters(PLUGIN) : {};
    function str(k, dflt) {
      var v = raw[k];
      return (v === undefined || v === null || String(v).trim() === '') ? dflt : String(v);
    }
    function strAllowBlank(k, dflt) {
      var v = raw[k];
      return (v === undefined || v === null) ? dflt : String(v);
    }
    function bool(k, dflt) {
      var v = raw[k];
      if (v === undefined || v === null || String(v).trim() === '') return dflt;
      return String(v) === 'true';
    }
    function num(k, dflt) {
      var v = raw[k];
      if (v === undefined || v === null || String(v).trim() === '') return dflt;
      var n = Number(v);
      return isNaN(n) ? dflt : n;
    }
    return {
      menuCommand: strAllowBlank('menuCommand', 'Signs'),
      yardTitle: str('yardTitle', "The Signwright's Yard"),
      hangOnMap: bool('hangOnMap', true),
      signHeight: num('signHeight', 104),
      closeLookHeight: num('closeLookHeight', 440),
      shopHeader: bool('shopHeader', true),
      shopHeaderHeight: num('shopHeaderHeight', 160),
      defaultProsperity: num('defaultProsperity', 2),
      closeLookHint: strAllowBlank('closeLookHint', 'OK to continue'),
      fontFolder: str('fontFolder', 'fonts/')
    };
  }

  var _params = null;
  /** @returns {object} Parameters, parsed once. */
  function P() {
    if (!_params) { _params = params(); deps(); }
    return _params;
  }

  /** The suite injects its own. @param {?object} p Parameters. */
  function _setParamsForTest(p) { _params = p; if (p) deps(); }

  /* ---------------------------------------------------------------- fonts --*/

  var _fontsAsked = false;
  /**
   * Load the two shipped faces.
   * ⛔ wing §15a: NEVER `FontManager.load` a SHIPPED font — a missing file makes
   * `isReady()` THROW at boot (`rmmz_managers.js:806`) and the buyer's game does
   * not start. `new FontFace(...).load().catch()` cannot: a face that is not
   * there simply never arrives and the CSS stack falls through to a serif.
   * @returns {number} How many faces were asked for.
   */
  function loadFonts() {
    if (_fontsAsked) return 0;
    _fontsAsked = true;
    if (typeof FontFace === 'undefined' || typeof document === 'undefined') return 0;
    var folder = P().fontFolder;
    if (folder && folder.charAt(folder.length - 1) !== '/') folder += '/';
    var want = [
      { family: 'BracketDisplay', file: 'Bracket-Display.woff2' },
      { family: 'BracketBody', file: 'Bracket-Body.woff2' }
    ];
    var asked = 0;
    for (var i = 0; i < want.length; i++) {
      (function (w) {
        try {
          var face = new FontFace(w.family, 'url("' + folder + w.file + '")');
          face.load().then(function (f) {
            try { document.fonts.add(f); } catch (e) { /* a closed font set is not our problem */ }
          }).catch(function () { /* absent font: the stack falls through to a serif */ });
          asked++;
        } catch (e) { /* older runtimes: the stack falls through */ }
      })(want[i]);
    }
    return asked;
  }

  /* ------------------------------------------------------- reading the map --*/

  /* MZ event command codes, read out of the engine rather than remembered:
   * Game_Interpreter.prototype.command302 (rmmz_objects.js:10983) pushes
   * Scene_Shop with `[params]` plus every following 605 as goods rows. */
  var CODE_SHOP = 302, CODE_SHOP_MORE = 605;

  /**
   * Pull one value out of a note box.
   * @param {string} note The note text.
   * @param {string} key The tag name after `sign`, or '' for the bare `<sign: x>`.
   * @returns {?string} The value, or null when the tag is absent.
   */
  function tag(note, key) {
    var src = String(note || '');
    var re = key
      ? new RegExp('<\\s*sign\\s+' + key + '\\s*:\\s*([^>]*)>', 'i')
      : /<\s*sign\s*:\s*([^>]*)>/i;
    var m = re.exec(src);
    return m ? String(m[1]).trim() : null;
  }

  /**
   * A map-level tag, for the district heading and its prosperity.
   * @param {string} note The map's note.
   * @param {string} key `district` or `prosperity`.
   * @returns {?string} The value, or null.
   */
  function mapTag(note, key) {
    var m = new RegExp('<\\s*' + key + '\\s*:\\s*([^>]*)>', 'i').exec(String(note || ''));
    return m ? String(m[1]).trim() : null;
  }

  /**
   * Turn one Shop Processing goods row into a row the reader understands.
   * ⛔ wing §11: the ONLY place a goods row is built, so the map path and the
   * shop-scene path cannot disagree about what a goods row is.
   * @param {number[]} row `[kind, id, priceType, price, purchaseOnly]`.
   * @returns {?object} A goods row, or null when the record is gone.
   */
  function goodsRow(row) {
    if (!row || row.length < 2) return null;
    var kindId = Number(row[0]);
    var id = Number(row[1]);
    var priceType = Number(row[2]);
    var typed = Number(row[3]);
    var data = null, kind = 'item', typeName = '';
    var sys = (typeof $dataSystem !== 'undefined') ? $dataSystem : null;
    if (kindId === 0) { data = (typeof $dataItems !== 'undefined') ? $dataItems[id] : null; kind = 'item'; }
    else if (kindId === 1) {
      data = (typeof $dataWeapons !== 'undefined') ? $dataWeapons[id] : null; kind = 'weapon';
      if (data && sys && sys.weaponTypes) typeName = sys.weaponTypes[data.wtypeId] || '';
    } else if (kindId === 2) {
      data = (typeof $dataArmors !== 'undefined') ? $dataArmors[id] : null; kind = 'armor';
      if (data && sys && sys.armorTypes) typeName = sys.armorTypes[data.atypeId] || '';
    }
    if (!data) return null;
    /* priceType 1 means the event typed its own price; 0 means the database's. */
    var price = (priceType === 1) ? typed : Number(data.price);
    return {
      kind: kind, id: id, name: String(data.name || ''),
      price: isFinite(price) ? price : 0,
      itypeId: data.itypeId, etypeId: data.etypeId,
      wtypeId: data.wtypeId, atypeId: data.atypeId,
      effects: data.effects || [], typeName: typeName
    };
  }

  /**
   * Every goods list a page's command list contains.
   * ⛔ wing §3a: this MIRRORS `command302`'s own loop — the first row is the 302
   * itself and every immediately following 605 belongs to it. Paraphrasing that
   * is how a stub comes to redefine what every test is testing.
   * @param {object[]} list A page's `list`.
   * @returns {object[][]} One array of goods rows per shop in the page.
   */
  function shopsInList(list) {
    var out = [];
    if (!Array.isArray(list)) return out;
    for (var i = 0; i < list.length; i++) {
      if (!list[i] || list[i].code !== CODE_SHOP) continue;
      var rows = [];
      var first = goodsRow(list[i].parameters);
      if (first) rows.push(first);
      var j = i + 1;
      while (j < list.length && list[j] && list[j].code === CODE_SHOP_MORE) {
        var more = goodsRow(list[j].parameters);
        if (more) rows.push(more);
        j++;
      }
      out.push(rows);
      i = j - 1;
    }
    return out;
  }

  /**
   * Read one map event into a shop record, or null when it hangs no sign.
   * @param {object} ev A `$dataMap.events` entry.
   * @param {object} ctx `{prosperity, districtName}` from the map.
   * @returns {?object} A shop record for `BracketRead.profile`.
   */
  function readEvent(ev, ctx) {
    if (!ev) return null;
    var note = ev.note || '';
    var bare = tag(note, '');
    if (bare && /^skip$/i.test(bare)) return null;

    var goods = [];
    var pages = ev.pages || [];
    for (var p = 0; p < pages.length; p++) {
      var found = shopsInList(pages[p] ? pages[p].list : null);
      for (var s = 0; s < found.length; s++) goods = goods.concat(found[s]);
      if (goods.length) break;             /* the first page that trades wins */
    }
    var named = bare && !/^skip$/i.test(bare) ? bare : null;
    var forced = tag(note, 'device');
    /* A sign is hung when the event TRADES, or when the hand asked for one. */
    if (!goods.length && !named && !forced) return null;

    var prosp = tag(note, 'prosperity');
    var weath = tag(note, 'weathering');
    return {
      eventId: ev.id,
      name: named || String(ev.name || '').trim(),
      goods: goods,
      trade: tag(note, 'trade') || '',
      device: forced || '',
      board: tag(note, 'board') || '',
      bracket: tag(note, 'bracket') || '',
      scheme: tag(note, 'scheme') || '',
      weathering: (weath === null || weath === '') ? '' : weath,
      prosperity: (prosp === null || prosp === '') ? ctx.prosperity : prosp,
      districtName: ctx.districtName
    };
  }

  /**
   * Every sign on the map now loaded.
   * @returns {object[]} Profiles, in event order.
   */
  function signs() {
    deps();
    if (typeof $dataMap === 'undefined' || !$dataMap) return [];
    var note = $dataMap.note || '';
    var prosp = mapTag(note, 'prosperity');
    var ctx = {
      prosperity: (prosp === null || prosp === '') ? P().defaultProsperity : prosp,
      districtName: mapTag(note, 'district') || ''
    };
    var out = [];
    var evs = $dataMap.events || [];
    for (var i = 0; i < evs.length; i++) {
      var shop = readEvent(evs[i], ctx);
      if (!shop) continue;
      var prof = _R.profile(shop);
      prof.eventId = shop.eventId;
      prof.districtName = shop.districtName;
      out.push(prof);
    }
    return out;
  }

  /**
   * Adopt this project's own price ladder.
   * ⛔ wing §21i / §24a: ANCHOR TIER THRESHOLDS TO THE ENGINE'S OWN DATABASE.
   * "Expensive" is meaningless until you know what THIS project charges, so the
   * standing ladder is re-derived from the buyer's own priced rows at boot.
   * @returns {?number[]} The ladder adopted, or null when nothing was readable.
   */
  function adoptLadder() {
    deps();
    var prices = [];
    var tables = [];
    if (typeof $dataItems !== 'undefined') tables.push($dataItems);
    if (typeof $dataWeapons !== 'undefined') tables.push($dataWeapons);
    if (typeof $dataArmors !== 'undefined') tables.push($dataArmors);
    for (var t = 0; t < tables.length; t++) {
      var rows = tables[t] || [];
      for (var i = 0; i < rows.length; i++) {
        if (rows[i] && Number(rows[i].price) > 0) prices.push(Number(rows[i].price));
      }
    }
    var ladder = _R.ladderFrom(prices);
    if (ladder) _R.usePriceLadder(ladder);
    return ladder;
  }

  /* ------------------------------------------------------------- the bake --*/

  var _cache = {};
  /**
   * A sign as a Bitmap, baked once and kept.
   * ⛔ wing §3 quality bar: ZERO allocation in per-frame hot paths. A sign is
   * baked the first time it is asked for and every later frame draws the same
   * cached Bitmap, so the map's update loop allocates nothing at all.
   * @param {object} prof A profile.
   * @param {number} height The sign's height in pixels.
   * @param {object} [opt] Passed to `drawSign`.
   * @returns {object} A Bitmap carrying `bracketCounts`.
   */
  function bake(prof, height, opt) {
    deps();
    var o = opt || {};
    var key = prof.key + '|' + Math.round(height) + '|' + (o.swing || 0) + '|' + (o.behind || '');
    if (_cache[key]) return _cache[key];
    var g = _K.geometry(prof, height);
    /* The bitmap is sized from the geometry, never from a typed number — and it
     * carries the bracket's whole REACH plus a margin for the swing, because
     * ⛔ wing §25c: an MZ window's rect IS its bitmap and anything drawn outside
     * it is simply gone. The first version sized the bitmap from a reach formula
     * of its own, which drifted from the renderer's the moment the renderer's
     * changed — ⛔ wing §11a, a second copy of a constant does not drift, it
     * WINS. There is one reach now and it lives on the geometry. */
    var swingRoom = g.boardW * 0.06;
    var w = Math.ceil(Math.max(2, g.ironH * 0.20) + g.reach + swingRoom + g.plate.w);
    var h = Math.ceil(height * 1.06);
    var bmp = new Bitmap(w, h);
    var ctx = bmp.context;
    ctx.save();
    var counts = _P.drawSign(ctx, prof, Math.round(height * 0.05), Math.round(height * 0.02),
      height, { behind: o.behind, swing: o.swing });
    ctx.restore();
    bmp._baseTexture.update();
    bmp.bracketCounts = counts;
    _cache[key] = bmp;
    return bmp;
  }

  /** Drop every baked sign. The suite and the capture harness both need this. */
  function clearCache() { _cache = {}; }

  /**
   * The shop scene's header band: an oak lintel the width of the screen, with
   * its own grain, a lit top arris and a shadowed soffit, and the plaster of the
   * shop front above it.
   *
   * ⛔ wing §15b: A MAP-EFFECT PRODUCT CANNOT SHOW ITS MAP. A shop scene's
   * background is `SceneManager.backgroundBitmap()` — a blurred snapshot of the
   * map, which is Kadokawa's tileset. A header sprite floating over that blur is
   * not shippable in a gallery and, worse, does not read as a shop front. The
   * band is opaque and every pixel of it is drawn here, so a crop of it is the
   * product's own picture edge to edge.
   * ⛔ Icon_Doctrine §22b-1a: the grain declares a PITCH and derives its count.
   *
   * @param {object} bmp A Bitmap the width of the screen.
   * @param {number} band The band height in pixels.
   * @returns {number} How many grain lines were struck. Zero is a defect.
   */
  function drawLintel(bmp, band) {
    deps();
    var ctx = bmp.context;
    var w = bmp.width;
    var beamH = Math.max(6, Math.round(band * 0.13));
    var beamY = band - beamH;
    /* The plaster above: a flat wall in the pack's dusk, lit from the upper left
     * like everything else in the product. */
    var wall = ctx.createLinearGradient(0, 0, w * 0.75, band);
    wall.addColorStop(0, '#2b3444');
    wall.addColorStop(1, '#1a212c');
    ctx.fillStyle = wall;
    ctx.fillRect(0, 0, w, beamY);
    /* The beam. */
    ctx.fillStyle = _K.PALETTE.oakShadow;
    ctx.fillRect(0, beamY, w, beamH);
    var ink = Math.max(1, beamH * 0.14);
    var run = _K.fitRepeat(w, ink, ink * 5.2);
    /* ⛔ Icon_Doctrine §22b-1b: `fitRepeat` returns `{count, pitch, floored}` and
     * NOT a start — reading one off it would put NaN into every `fillRect` and
     * the grain would simply not be there, with nothing thrown. The run is
     * centred on the beam from its own measured length. */
    var runLen = (run.count - 1) * run.pitch + ink;
    var start = (w - runLen) / 2;
    var struck = 0;
    ctx.fillStyle = 'rgba(24,14,7,0.42)';
    for (var i = 0; i < run.count; i++) {
      var gx = start + i * run.pitch;
      ctx.fillRect(gx, beamY + beamH * 0.28, ink, beamH * 0.5);
      struck++;
    }
    ctx.fillStyle = 'rgba(196,148,92,0.55)';
    ctx.fillRect(0, beamY, w, Math.max(1, beamH * 0.16));
    ctx.fillStyle = 'rgba(0,0,0,0.42)';
    ctx.fillRect(0, band - Math.max(1, beamH * 0.2), w, Math.max(1, beamH * 0.2));
    bmp._baseTexture.update();
    return struck;
  }

  /* -------------------------------------------------------------- the save --*/

  /**
   * The saved record: which signs the player has met.
   * ⛔ wing §13: declared with `enumerable: false` so `JsonEx._encode`, which
   * walks `Object.keys`, cannot double-write it — a `makeSaveContents` hook
   * alone is bypassed by `JsonEx.makeDeepCopy`.
   * @param {object} sys A `Game_System`.
   * @returns {object} `{version, seen}`.
   */
  function record(sys) {
    if (!sys._csafBracket) {
      sys._csafBracket = { version: SAVE_VERSION, seen: {} };
    }
    var r = sys._csafBracket;
    /* A forward-compatible read: an older save is upgraded in place, a NEWER
     * one is left exactly as it is rather than stripped. */
    if (typeof r.version !== 'number') r.version = SAVE_VERSION;
    if (!r.seen || typeof r.seen !== 'object') r.seen = {};
    return r;
  }

  /** @param {object} prof A profile. @returns {boolean} True when newly seen. */
  function markSeen(prof) {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return false;
    var r = record($gameSystem);
    if (r.seen[prof.key]) return false;
    r.seen[prof.key] = { name: prof.name, trade: prof.trade, district: prof.districtName || '' };
    return true;
  }

  /** @returns {number} How many distinct signs the player has met. */
  function seen() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return 0;
    return Object.keys(record($gameSystem).seen).length;
  }

  return {
    PLUGIN: PLUGIN, SAVE_VERSION: SAVE_VERSION,
    params: params, P: P, _setParamsForTest: _setParamsForTest,
    loadFonts: loadFonts, deps: deps,
    tag: tag, mapTag: mapTag, goodsRow: goodsRow, shopsInList: shopsInList,
    readEvent: readEvent, signs: signs, adoptLadder: adoptLadder,
    bake: bake, clearCache: clearCache, drawLintel: drawLintel,
    record: record, markSeen: markSeen, seen: seen,
    CODE_SHOP: CODE_SHOP, CODE_SHOP_MORE: CODE_SHOP_MORE
  };
})();

/* ===========================================================================
 * THE ENGINE SEAM
 *
 * Everything above is data and pixels and could run in a bare browser tab.
 * Everything below is the only part of this product that knows RPG Maker
 * exists, and every core method it touches is EXTENDED: the original is saved
 * AND CALLED. ⛔ wing §24c: saving an original and CALLING it are different
 * claims, and the compatibility block on the store page depends on the second.
 * ========================================================================= */
(function () {
  'use strict';

  /* This half only runs inside the engine. Under Node — the headless suite —
   * `Scene_Base` is not there, and nothing below should be either. */
  if (typeof Scene_Base === 'undefined' || typeof Game_System === 'undefined') return;

  var B = CSAF.Bracket;

  /* ------------------------------------------------------------ the boot --*/

  var _Scene_Boot_start = Scene_Boot.prototype.start;
  Scene_Boot.prototype.start = function () {
    _Scene_Boot_start.call(this);
    try {
      B.loadFonts();
      B.adoptLadder();
    } catch (e) {
      /* ⛔ A sign is decoration. It may never stop a buyer's game from booting,
       * so the whole read is wrapped and a failure costs signs, not the game. */
      console.error('Bracket: could not read the database — ' + e.message);
    }
  };

  /* ⛔ wing §13: the runtime record is declared NON-ENUMERABLE, because
   * `JsonEx._encode` walks `Object.keys` and would otherwise write a second
   * copy of it into every save file. */
  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () {
    _Game_System_initialize.call(this);
    Object.defineProperty(this, '_csafBracketRuntime', {
      value: null, writable: true, enumerable: false, configurable: true
    });
    B.record(this);
  };

  /* ------------------------------------------------- the sign over a door --*/

  /**
   * The sprite that hangs over one shop door.
   * ⛔ wing §3 quality bar: NOTHING is allocated per frame. The bitmap is baked
   * once by `Bracket.bake`, and `update` only moves this sprite.
   */
  function Sprite_BracketSign() { this.initialize.apply(this, arguments); }
  Sprite_BracketSign.prototype = Object.create(Sprite.prototype);
  Sprite_BracketSign.prototype.constructor = Sprite_BracketSign;

  /**
   * @param {object} profile A profile from BracketRead.
   * @param {object} character The `Game_Event` the sign hangs over.
   */
  Sprite_BracketSign.prototype.initialize = function (profile, character) {
    Sprite.prototype.initialize.call(this);
    this._profile = profile;
    this._character = character;
    this.bitmap = B.bake(profile, B.P().signHeight, { behind: '#101720' });
    this.anchor.x = 0.5;
    this.anchor.y = 1.0;
    this.z = 5;
  };

  Sprite_BracketSign.prototype.update = function () {
    Sprite.prototype.update.call(this);
    var c = this._character;
    if (!c) return;
    this.x = c.screenX();
    /* The sign hangs ABOVE the door: one tile up, then its own height. */
    this.y = c.screenY() - $gameMap.tileHeight();
    this.visible = true;
  };

  var _Spriteset_Map_createCharacters = Spriteset_Map.prototype.createCharacters;
  Spriteset_Map.prototype.createCharacters = function () {
    _Spriteset_Map_createCharacters.call(this);
    this._csafBracketSigns = [];
    if (!B.P().hangOnMap) return;
    var profiles;
    try { profiles = B.signs(); } catch (e) { profiles = []; }
    for (var i = 0; i < profiles.length; i++) {
      var ev = $gameMap.event(profiles[i].eventId);
      if (!ev) continue;
      var sp = new Sprite_BracketSign(profiles[i], ev);
      this._csafBracketSigns.push(sp);
      this._tilemap.addChild(sp);
    }
  };

  /* ⛔ Every listener and every sprite this product adds has a teardown (wing
   * §3 quality bar). A map change disposes the sprites with the tilemap, and
   * this drops our own references so nothing is retained across maps. */
  var _Spriteset_Map_destroy = Spriteset_Map.prototype.destroy;
  Spriteset_Map.prototype.destroy = function (options) {
    this._csafBracketSigns = null;
    _Spriteset_Map_destroy.call(this, options);
  };

  /* ----------------------------------------------- the Close Look (a scene) --*/

  function Scene_BracketSign() { this.initialize.apply(this, arguments); }
  Scene_BracketSign.prototype = Object.create(Scene_Base.prototype);
  Scene_BracketSign.prototype.constructor = Scene_BracketSign;
  window.Scene_BracketSign = Scene_BracketSign;

  Scene_BracketSign.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._profile = Scene_BracketSign._next || null;
    Scene_BracketSign._next = null;
    this._swing = 0;
    this._swingPinned = false;
  };

  /** @param {object} profile The sign to show. */
  Scene_BracketSign.prepare = function (profile) { Scene_BracketSign._next = profile; };

  Scene_BracketSign.prototype.create = function () {
    Scene_Base.prototype.create.call(this);
    this.createBackground();
    this.createPlate();
  };

  Scene_BracketSign.prototype.createBackground = function () {
    var w = Graphics.width, h = Graphics.height;
    var bmp = new Bitmap(w, h);
    /* ⛔ wing §15b: the street is DRAWN. No tile, no RTP, nothing shipped —
     * which is also why this scene can appear in a store image at all. */
    CSAF.BracketRender.drawStreet(bmp.context, w, h, this._profile ? this._profile.seed : 7);
    bmp._baseTexture.update();
    this._backSprite = new Sprite(bmp);
    this.addChild(this._backSprite);
  };

  Scene_BracketSign.prototype.createPlate = function () {
    if (!this._profile) return;
    var h = B.P().closeLookHeight;
    this._signSprite = new Sprite(B.bake(this._profile, h, { behind: CSAF.BracketCompose.PALETTE.dusk }));
    this._signSprite.x = Math.round((Graphics.width - this._signSprite.bitmap.width) / 2);
    this._signSprite.y = Math.round(Graphics.height * 0.055);
    this.addChild(this._signSprite);
    this.createPlaque();
  };

  /**
   * The name plaque under the sign, drawn rather than windowed.
   * ⛔ wing §7 / §25e: this product must not look like RPG Maker, and MZ's
   * `Window_Base` brings its own blue frame, its own pause sign and its own
   * font. There is no Window in this scene at all — `chromeLeaks()` in the
   * capture prelude asserts exactly that.
   */
  Scene_BracketSign.prototype.createPlaque = function () {
    var p = this._profile;
    var K = CSAF.BracketCompose;
    var w = Math.round(Graphics.width * 0.52);
    var h = Math.round(Graphics.height * 0.145);
    var bmp = new Bitmap(w, h);
    var ctx = bmp.context;
    /* An oak plate with the same two-tone edge every board carries. */
    var oak = K.parseHex(K.PALETTE.oakShadow);
    ctx.fillStyle = K.toHex(oak);
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = K.toHex(K.relief(oak, 1, 34));
    ctx.lineWidth = 2;
    ctx.strokeRect(1, 1, w - 2, h - 3);
    ctx.strokeStyle = K.toHex(K.relief(oak, -1, 14));
    ctx.beginPath(); ctx.moveTo(1, h - 1); ctx.lineTo(w - 1, h - 1); ctx.stroke();

    var chalk = K.parseHex(K.PALETTE.chalk);
    var line1 = p.name;
    var line2 = (p.districtName ? p.districtName + '  ·  ' : '') + p.trade;
    ctx.textBaseline = 'alphabetic';
    ctx.textAlign = 'center';
    ctx.fillStyle = K.toHex(K.pickContrast(oak, [chalk, K.parseHex(K.PALETTE.giltLit)], 4.5).ink);
    var f1 = CSAF.BracketRender.fitLine(ctx, line1, Math.round(h * 0.40),
      CSAF.BracketRender.FACE_DISPLAY, w * 0.88, 0.05);
    ctx.font = Math.round(f1.size) + 'px ' + CSAF.BracketRender.FACE_DISPLAY;
    ctx.fillText(line1, w / 2, Math.round(h * 0.48));
    if (line2) {
      ctx.globalAlpha = 0.78;
      var f2 = CSAF.BracketRender.fitLine(ctx, line2, Math.round(h * 0.20),
        CSAF.BracketRender.FACE_BODY, w * 0.88, 0.12);
      ctx.font = Math.round(f2.size) + 'px ' + CSAF.BracketRender.FACE_BODY;
      ctx.fillText(line2, w / 2, Math.round(h * 0.78));
      ctx.globalAlpha = 1;
    }
    bmp._baseTexture.update();
    this._plaque = new Sprite(bmp);
    this._plaque.x = Math.round((Graphics.width - w) / 2);
    this._plaque.y = Math.round(Graphics.height - h - Graphics.height * 0.045);
    this.addChild(this._plaque);
  };

  /**
   * Set the swing to an EXPLICIT value and hold it there.
   * ⛔ wing §15e: THE ENGINE'S OWN rAF LOOP IS STILL RUNNING DURING A CAPTURE,
   * so a GIF of an easing in progress is paced by screenshot latency, not by
   * the animation. Every frame of the swing is driven to a pinned state by the
   * storyboard calling this, and `update` then refuses to move it.
   * @param {number} deg Degrees either side of plumb.
   */
  Scene_BracketSign.prototype.pinSwing = function (deg) {
    this._swing = Number(deg) || 0;
    this._swingPinned = true;
    this.refreshSign();
  };

  Scene_BracketSign.prototype.refreshSign = function () {
    if (!this._profile || !this._signSprite) return;
    this._signSprite.bitmap = B.bake(this._profile, B.P().closeLookHeight, {
      behind: CSAF.BracketCompose.PALETTE.dusk, swing: Math.round(this._swing * 10) / 10
    });
  };

  Scene_BracketSign.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    if (this.isActive() && !this._swingPinned) {
      if (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered()) {
        SoundManager.playCancel();
        this.popScene();
      }
    }
  };

  /* ------------------------------------------------ the Yard (a scene too) --*/

  function Scene_BracketYard() { this.initialize.apply(this, arguments); }
  Scene_BracketYard.prototype = Object.create(Scene_Base.prototype);
  Scene_BracketYard.prototype.constructor = Scene_BracketYard;
  window.Scene_BracketYard = Scene_BracketYard;

  Scene_BracketYard.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._profiles = Scene_BracketYard._next || null;
    Scene_BracketYard._next = null;
  };

  /** @param {object[]} profiles The signs to hang. */
  Scene_BracketYard.prepare = function (profiles) { Scene_BracketYard._next = profiles; };

  Scene_BracketYard.prototype.create = function () {
    Scene_Base.prototype.create.call(this);
    var list = this._profiles || B.signs();
    var w = Graphics.width, h = Graphics.height;
    var bmp = new Bitmap(w, h);
    var res = CSAF.BracketRender.drawYard(bmp.context, list, w, h, {});
    this._yard = res;
    /* The heading, in the display face, over the yard. */
    var K = CSAF.BracketCompose;
    var ctx = bmp.context;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = K.toHex(K.relief(K.parseHex(K.PALETTE.giltLit), -1, 10));
    ctx.font = Math.round(h * 0.058) + 'px ' + CSAF.BracketRender.FACE_DISPLAY;
    ctx.fillText(B.P().yardTitle, w / 2, Math.round(h * 0.075));
    bmp._baseTexture.update();
    this._back = new Sprite(bmp);
    this.addChild(this._back);
  };

  Scene_BracketYard.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    if (this.isActive()) {
      if (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered()) {
        SoundManager.playCancel();
        this.popScene();
      }
    }
  };

  /* ------------------------------------------------- the shop scene header --*/

  /**
   * How tall a band the header needs, in pixels. Zero when there is no header.
   *
   * ⛔ MEASURED on the art stage of 2026-09-14 by opening
   * `_probe/out/in_engine_shop.png`: the header was a 160 px sprite dropped at
   * `y = 0` in the top-right corner, and it sat squarely ON TOP OF THE GOLD
   * WINDOW. Every check passed over a shop scene whose purse was hidden behind
   * a sign. A header does not overlap the scene, it HEADS it — so the band is
   * reserved from the main area before MZ lays a single window out, which is
   * also what the brief asked for ("the same sign above the goods windows").
   *
   * @returns {number} The band height in pixels.
   */
  Scene_Shop.prototype.csafBracketBand = function () {
    if (this._csafBracketBand === undefined) {
      this._csafBracketBand = 0;
      try {
        if (B.P().shopHeader) {
          var prof = currentShopProfile();
          if (prof) {
            var h = Math.max(40, Number(B.P().shopHeaderHeight) || 160);
            this._csafBracketBaked = B.bake(prof, h, { behind: '#20160d' });
            this._csafBracketProfile = prof;
            this._csafBracketBand = this._csafBracketBaked.height + Math.round(h * 0.10);
          }
        }
      } catch (e) {
        console.error('Bracket: shop header — ' + e.message);
      }
    }
    return this._csafBracketBand;
  };

  /* ⛔ wing §23a / §25d: both of these resolve up MZ's own chain
   * (`Scene_MenuBase.prototype`), so the saved originals are real and
   * `_probe/verify_method_names.js` can see them. Shrinking the main area by
   * exactly what the band takes is what stops the bottom window running off the
   * frame — a band added without paying for it is wing §18b. */
  var _Scene_Shop_mainAreaTop = Scene_Shop.prototype.mainAreaTop;
  Scene_Shop.prototype.mainAreaTop = function () {
    return _Scene_Shop_mainAreaTop.call(this) + this.csafBracketBand();
  };
  var _Scene_Shop_mainAreaHeight = Scene_Shop.prototype.mainAreaHeight;
  Scene_Shop.prototype.mainAreaHeight = function () {
    return _Scene_Shop_mainAreaHeight.call(this) - this.csafBracketBand();
  };

  var _Scene_Shop_create = Scene_Shop.prototype.create;
  Scene_Shop.prototype.create = function () {
    this.csafBracketBand();
    _Scene_Shop_create.call(this);
    var bmp = this._csafBracketBaked;
    if (!bmp) return;
    try {
      /* The lintel the sign hangs over: a full-width oak beam the PRODUCT draws,
       * so the band is the product's own picture edge to edge and no part of it
       * is the engine's blurred map (wing §15b). */
      var band = this._csafBracketBand;
      var lint = new Bitmap(Graphics.width, band);
      B.drawLintel(lint, band);
      this.addChild(new Sprite(lint));
      var sp = new Sprite(bmp);
      sp.x = Math.round((Graphics.width - bmp.width) / 2);
      sp.y = Math.round((band - bmp.height) / 2);
      this.addChild(sp);
      this._csafBracketHeader = sp;
      B.markSeen(this._csafBracketProfile);
    } catch (e) {
      /* Never let a sign break a shop. */
      console.error('Bracket: shop header — ' + e.message);
    }
  };

  /**
   * The profile of the shop the player is standing in.
   * ⛔ wing §11: it is read through the SAME `signs()` path as the map sprite,
   * matched on the running event, so the header and the door cannot disagree
   * about what the sign says.
   * @returns {?object} A profile, or null.
   */
  function currentShopProfile() {
    if (typeof $gameMap === 'undefined' || !$gameMap) return null;
    var interp = $gameMap._interpreter;
    var evId = interp ? interp.eventId() : 0;
    var all = B.signs();
    for (var i = 0; i < all.length; i++) {
      if (all[i].eventId === evId) return all[i];
    }
    return null;
  }

  /* ------------------------------------------------------- the menu command --*/

  var _Window_MenuCommand_addOriginalCommands = Window_MenuCommand.prototype.addOriginalCommands;
  Window_MenuCommand.prototype.addOriginalCommands = function () {
    _Window_MenuCommand_addOriginalCommands.call(this);
    var label = B.P().menuCommand;
    if (label && String(label).trim() !== '') this.addCommand(label, 'csafBracketYard', true);
  };

  var _Scene_Menu_createCommandWindow = Scene_Menu.prototype.createCommandWindow;
  Scene_Menu.prototype.createCommandWindow = function () {
    _Scene_Menu_createCommandWindow.call(this);
    this._commandWindow.setHandler('csafBracketYard', function () {
      SceneManager.push(Scene_BracketYard);
    });
  };

  /* ---------------------------------------------------- pictures, for scenes --*/

  /* ⛔ wing §24c: the original is saved AND CALLED for every name that is not
   * ours, so any other plugin's pictures keep working exactly as before. */
  var _ImageManager_loadPicture = ImageManager.loadPicture;
  ImageManager.loadPicture = function (filename) {
    if (typeof filename === 'string' && filename.indexOf('$csafBracket') === 0) {
      var made = CSAF.Bracket._picture(filename);
      if (made) return made;
    }
    return _ImageManager_loadPicture.call(this, filename);
  };

  /**
   * A baked sign, handed back as if it were a picture file.
   * @param {string} filename `$csafBracket<eventId>`.
   * @returns {?object} A Bitmap, or null when there is no such sign.
   */
  CSAF.Bracket._picture = function (filename) {
    var id = Number(String(filename).replace('$csafBracket', ''));
    if (!isFinite(id)) return null;
    var all = B.signs();
    for (var i = 0; i < all.length; i++) {
      if (all[i].eventId === id) return B.bake(all[i], B.P().closeLookHeight, { behind: '#00000000' });
    }
    return null;
  };

  /* -------------------------------------------------------- plugin commands --*/

  PluginManager.registerCommand(B.PLUGIN, 'closeLook', function (args) {
    var id = Number(args.eventId);
    if (!isFinite(id) || id === 0) id = this.eventId();
    CSAF.Bracket.closeLook(id);
  });

  PluginManager.registerCommand(B.PLUGIN, 'openYard', function () {
    CSAF.Bracket.openYard();
  });

  PluginManager.registerCommand(B.PLUGIN, 'showSignPicture', function (args) {
    var id = Number(args.eventId);
    if (!isFinite(id) || id === 0) id = this.eventId();
    var pic = Number(args.pictureId) || 1;
    $gameScreen.showPicture(pic, '$csafBracket' + id, 1, Number(args.x) || 0, Number(args.y) || 0,
      100, 100, 255, 0);
  });

  /* ------------------------------------------------------------- the script --*/

  /** @param {number} eventId The event whose sign to show. @returns {boolean} Shown. */
  CSAF.Bracket.closeLook = function (eventId) {
    var all = B.signs();
    for (var i = 0; i < all.length; i++) {
      if (all[i].eventId === Number(eventId)) {
        B.markSeen(all[i]);
        Scene_BracketSign.prepare(all[i]);
        SceneManager.push(Scene_BracketSign);
        return true;
      }
    }
    return false;
  };

  /** Open the directory. @returns {boolean} Always true. */
  CSAF.Bracket.openYard = function () {
    SceneManager.push(Scene_BracketYard);
    return true;
  };

  /* The capture harness and the in-engine probe reach these. */
  CSAF.Bracket.Sprite_BracketSign = Sprite_BracketSign;
  CSAF.Bracket.currentShopProfile = currentShopProfile;
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.Bracket;
