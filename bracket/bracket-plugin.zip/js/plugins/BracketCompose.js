//=============================================================================
// BracketCompose.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Bracket [3/4] — the geometry and the colour. Board outlines, trade devices, ironwork, grain and weather, all as shape. Knows nothing about RPG Maker. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * BracketCompose — where every line on a sign comes from
 * ============================================================================
 * A drawing kit, not a plugin. It patches nothing and adds no scene.
 *
 * Nothing here lands a pixel. It answers WHERE things go, and the whole point
 * of that split is that no position on a sign is typed:
 *
 *   the rings hang where the BOARD'S OWN OUTLINE is widest near its top;
 *   the lettering is as wide as the straight run the outline leaves at its
 *     baseline, not as wide as a number somebody liked;
 *   the device is the largest square the outline will take at the device's
 *     own height;
 *   the chain declares a PITCH from the ring's diameter and derives its link
 *     count from the real drop;
 *   the nail heads declare a pitch from the fixing plate and derive their
 *     count from its real width;
 *   the grain declares a pitch from the board's short side.
 *
 * Change the board outline and every one of those moves by itself.
 * ============================================================================
 */

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};

CSAF.BracketCompose = (function () {
  'use strict';

  /* ⛔ wing §22a-2d: a spacing floor is ABSOLUTE PIXELS, not a ratio — the eye
   * reads the paper between marks, not the proportion. Measured for this wing
   * on Shipwright: failing pitches left <= 2.4 px of paper, passing >= 2.49. */
  var PAPER_MIN = 2.6;

  /* ⛔ wing §22a-2f: an outline's pen is sized by the shape it outlines, not by
   * the figure. Floor so a pen never falls below a pixel and vanishes. */
  var PEN_FLOOR = 0.9;

  /* ---------------------------------------------------------------- colour --*/

  /**
   * Parse `#rrggbb`.
   * ⛔ wing §21c: an unparseable colour must return NULL, never NaN channels —
   * `parseInt('no', 16)` is NaN, NaN travels through every comparison, and the
   * caller treats null as "unpainted", which is a state this product already
   * draws (a bare oak board).
   * @param {*} hex Any value.
   * @returns {?object} `{r,g,b}` 0..255, or null.
   */
  function parseHex(hex) {
    if (typeof hex !== 'string') return null;
    var m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
    if (!m) return null;
    var n = parseInt(m[1], 16);
    if (!isFinite(n)) return null;
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }

  /** @param {object} c `{r,g,b}`. @returns {string} `#rrggbb`. */
  function toHex(c) {
    function h(v) {
      var n = Math.max(0, Math.min(255, Math.round(v)));
      return (n < 16 ? '0' : '') + n.toString(16);
    }
    return '#' + h(c.r) + h(c.g) + h(c.b);
  }

  /**
   * Relative luminance, gamma-expanded.
   * ⛔ wing §25h: a plain channel average picks the WRONG direction — BLACK was
   * chosen at 4.01:1 where WHITE was worth 5.24:1. Contrast is computed on
   * linearised light, so this is where the linearising happens.
   * @param {object} c `{r,g,b}` 0..255.
   * @returns {number} 0..1.
   */
  function lum(c) {
    var s = rgbOf(c);
    if (!s) return 0;
    function ch(v) {
      var t = v / 255;
      return t <= 0.03928 ? t / 12.92 : Math.pow((t + 0.055) / 1.055, 2.4);
    }
    return 0.2126 * ch(s.r) + 0.7152 * ch(s.g) + 0.0722 * ch(s.b);
  }

  /**
   * A real colour, or null.
   * ⛔ wing §21c / §26e, MEASURED 2026-09-13 by this product's own sabotage arm:
   * `parseHex` correctly returns NULL for a malformed colour, and then `lum`
   * read `.r` off it and THREW — so one bad character in a colour table crashed
   * a buyer's game instead of leaving a board unpainted. A null must be able to
   * travel to a caller that knows what unpainted means; it must never reach
   * arithmetic. This is the seam where it stops.
   * @param {*} c A `{r,g,b}`, a hex string, or anything at all.
   * @returns {?object} `{r,g,b}` with finite channels, or null.
   */
  function rgbOf(c) {
    if (typeof c === 'string') return parseHex(c);
    if (!c || typeof c !== 'object') return null;
    if (!isFinite(c.r) || !isFinite(c.g) || !isFinite(c.b)) return null;
    return c;
  }

  /**
   * The ground a scheme paints, guaranteed to be a real colour.
   * ⛔ wing §11a: ONE reader. Three places in the renderer used to write
   * `parseHex(field || PALETTE.oakLit)`, which falls through to oak for a NULL
   * field but hands a malformed one straight to `parseHex` and gets null back.
   * A bare board and a broken colour are different things and both end here.
   * @param {string} scheme A scheme id.
   * @returns {object} `{r,g,b}` — the oak when the scheme paints nothing.
   */
  function groundFor(scheme) {
    var field = SCHEME_FIELD[scheme];
    return rgbOf(field) || rgbOf(PALETTE.oakLit) || { r: 139, g: 90, b: 43 };
  }

  /**
   * WCAG contrast ratio between two colours.
   * @param {object} a `{r,g,b}`. @param {object} b `{r,g,b}`.
   * @returns {number} 1..21.
   */
  function contrast(a, b) {
    var la = lum(a), lb = lum(b);
    var hi = Math.max(la, lb), lo = Math.min(la, lb);
    return (hi + 0.05) / (lo + 0.05);
  }

  /**
   * Lift or drop a colour until it is `minDelta` LEVELS away from where it
   * started, in the direction asked for.
   *
   * ⛔ wing §22e-1: a MULTIPLIER is a hard-coded contrast RATIO, and it moved a
   * bright wax 27 levels and a dark wax 11 — the same call, two different
   * separations. Any tint whose job is to make something VISIBLE states its
   * separation in ABSOLUTE terms and solves for it.
   * ⛔ And the limit is real at BOTH ends: on a near-black nothing is darker and
   * on a near-white nothing is lighter, so the promise is `min(want, headroom)`
   * and the caller is told which it got.
   *
   * @param {object} c `{r,g,b}`.
   * @param {number} dir +1 lighter, -1 darker.
   * @param {number} minDelta Levels wanted, 0..255.
   * @returns {object} `{r,g,b,delta,capped}` — `delta` is what was actually moved.
   */
  function relief(c, dir, minDelta) {
    c = rgbOf(c) || { r: 0, g: 0, b: 0 };
    var want = Math.max(0, Math.min(255, Number(minDelta) || 0));
    var d = dir >= 0 ? 1 : -1;
    /* Headroom is measured on the channel with the least room, because moving
     * a colour past a channel limit changes its HUE instead of its value. */
    var head = d > 0
      ? Math.min(255 - c.r, 255 - c.g, 255 - c.b)
      : Math.min(c.r, c.g, c.b);
    var got = Math.min(want, head);
    return {
      r: c.r + d * got, g: c.g + d * got, b: c.b + d * got,
      delta: got, capped: got < want - 0.0001
    };
  }

  /**
   * Choose an ink that can actually be read on a given ground.
   * ⛔ wing §22e: never hard-code an ink — pick it by luminance against what it
   * sits on. ⛔ wing §25h: TRY BOTH DIRECTIONS and keep the first that clears
   * the bar, else the better; and the bar is `min(want, what the surface
   * allows)`, because a face no ink can be read on is a defect in the PLATE.
   * @param {object} bg `{r,g,b}` the ground.
   * @param {object[]} candidates Inks in preference order.
   * @param {number} [want] Contrast ratio wanted. 4.5 is AA.
   * @returns {object} `{ink, ratio, cleared}`.
   */
  function pickContrast(bg, candidates, want) {
    var bar = Number(want);
    if (!isFinite(bar) || bar <= 1) bar = 4.5;
    var best = null, bestRatio = -1;
    var ground = rgbOf(bg) || rgbOf(PALETTE.oakLit);
    for (var i = 0; i < candidates.length; i++) {
      var cand = rgbOf(candidates[i]);
      if (!cand) continue;            /* a malformed ink is skipped, never drawn */
      var r = contrast(ground, cand);
      if (r > bestRatio) { bestRatio = r; best = cand; }
      if (r >= bar) return { ink: cand, ratio: r, cleared: true };
    }
    if (!best) return { ink: rgbOf(PALETTE.chalk), ratio: 0, cleared: false };
    return { ink: best, ratio: bestRatio, cleared: false };
  }

  /* The palette, exactly as the design brief pins it. Roles, not decoration. */
  var PALETTE = {
    oakLit: '#8b5a2b', oakShadow: '#4a2c14',
    verdigris: '#4f8a7a', oxblood: '#7a2e2b', indigo: '#2f3d6b', mustard: '#c9a227',
    giltLit: '#e8c860', giltShadow: '#8a6d1f',
    iron: '#2b2b2e', rust: '#8b4a2b', chalk: '#efe6d2', dusk: '#1c2431'
  };

  /** Field colour per scheme. `oak` and `giltOak` leave the timber bare. */
  var SCHEME_FIELD = {
    oak: null, giltOak: null,
    verdigris: PALETTE.verdigris, oxblood: PALETTE.oxblood,
    indigo: PALETTE.indigo, mustard: PALETTE.mustard
  };

  /* -------------------------------------------------------------- outlines --
   * Every board is a closed outline in BOARD SPACE: x in [-1, 1], y in [0, 1],
   * top to bottom. The ten differ in SHAPE, never merely in proportion — wing
   * §21a, a palette is not a composition, and its geometric twin is that a
   * squashed rectangle is not a second outline.
   */

  /**
   * Sample a circle arc into points.
   * @param {number} cx Centre x. @param {number} cy Centre y.
   * @param {number} rx Radius x. @param {number} ry Radius y.
   * @param {number} a0 Start angle. @param {number} a1 End angle.
   * @param {number} n Samples.
   * @returns {number[][]} `[x,y]` pairs.
   */
  function arc(cx, cy, rx, ry, a0, a1, n) {
    var out = [];
    for (var i = 0; i <= n; i++) {
      var t = a0 + (a1 - a0) * (i / n);
      out.push([cx + Math.cos(t) * rx, cy + Math.sin(t) * ry]);
    }
    return out;
  }

  var OUTLINE = {
    /** A heater shield: square shoulders falling to a point. */
    heater: function () {
      var p = [[-1, 0.02], [1, 0.02], [1, 0.42]];
      p = p.concat(arc(0, 0.42, 1, 0.58, 0, Math.PI / 2, 14).map(function (q) { return [q[0], q[1]]; }));
      p = p.concat(arc(0, 0.42, 1, 0.58, Math.PI / 2, Math.PI, 14));
      p.push([-1, 0.42]);
      return p;
    },
    /** A true ellipse. */
    oval: function () { return arc(0, 0.5, 1, 0.5, -Math.PI, Math.PI, 48); },
    /** A four-point diamond with slightly concave flanks. */
    lozenge: function () {
      return [[0, 0], [0.55, 0.16], [1, 0.5], [0.55, 0.84], [0, 1], [-0.55, 0.84], [-1, 0.5], [-0.55, 0.16]];
    },
    /** The plain hanging rectangle, corners knocked off. */
    hanging: function () {
      var k = 0.10;
      return [[-1 + k, 0], [1 - k, 0], [1, k * 1.6], [1, 1 - k * 1.6], [1 - k, 1],
        [-1 + k, 1], [-1, 1 - k * 1.6], [-1, k * 1.6]];
    },
    /** A round-headed arch on a flat foot. */
    arch: function () {
      var p = arc(0, 0.46, 1, 0.46, Math.PI, 2 * Math.PI, 26);
      p.push([1, 1]); p.push([-1, 1]);
      return p;
    },
    /** A banner with a swallow-tail bitten out of its foot. */
    banner: function () {
      return [[-1, 0], [1, 0], [1, 0.80], [0.62, 0.80], [0.62, 1], [0, 0.72],
        [-0.62, 1], [-0.62, 0.80], [-1, 0.80]];
    },
    /** A keyhole: a round head over a tapering shaft. */
    keyhole: function () {
      var p = arc(0, 0.34, 0.74, 0.34, Math.PI, 2 * Math.PI, 24);
      p.push([0.74, 0.46]); p.push([0.52, 0.62]);
      p.push([0.66, 1]); p.push([-0.66, 1]);
      p.push([-0.52, 0.62]); p.push([-0.74, 0.46]);
      return p;
    },
    /* The head of a cask: a disc with the top and bottom sawn flat where the
     * staves were cut. Authored as ONE continuous ring so no chord can leave a
     * self-crossing edge — the first version pushed three loose points after a
     * partial arc and left a 15 px lettering run on a 91 px board. */
    barrelEnd: function () {
      var p = [];
      var flat = 0.40;                       /* half-width of each sawn flat */
      var a0 = Math.asin((0.5 - 0.5 * 0.86) / 0.5);  /* where the flat meets the curve */
      p.push([-flat, 0.07]); p.push([flat, 0.07]);
      p = p.concat(arc(0, 0.5, 0.98, 0.43, -Math.PI * 0.42 + a0 * 0, Math.PI * 0.42, 18));
      p.push([flat, 0.93]); p.push([-flat, 0.93]);
      p = p.concat(arc(0, 0.5, 0.98, 0.43, Math.PI * 0.58, Math.PI * 1.42, 18));
      return p;
    },
    /** A tankard's profile: straight sides, a lip flare, a footed base. */
    tankardCut: function () {
      return [[-0.86, 0], [0.86, 0], [0.96, 0.10], [0.80, 0.16], [0.80, 0.84],
        [0.98, 0.92], [0.98, 1], [-0.98, 1], [-0.98, 0.92], [-0.80, 0.84],
        [-0.80, 0.16], [-0.96, 0.10]];
    },
    /* A plank whose two ends are ROLLED, the way a signwright cuts a scroll
     * board: the field is a straight-sided panel and each end curls back on
     * itself in one continuous sweep.
     * ⛔ MEASURED 2026-09-13 by opening the Yard plate: the first version built
     * the outline from four disconnected arcs joined by straight jumps, and it
     * rendered as thin spikes at the corners with notches in the top edge that
     * nobody had drawn. An outline is ONE continuous run of points — a shape
     * assembled from pieces that do not meet is not a shape (§22a-1b, one
     * outline, applied to a board rather than to a beast). */
    scrollEnd: function () {
      var p = [];
      var roll = 0.30;                     /* how much of each end is rolled */
      var lip = 0.13;                      /* how deep the roll bites */
      /* the top edge, left roll to right roll */
      p.push([-1 + roll, 0.06]);
      p.push([1 - roll, 0.06]);
      /* the right-hand roll: over the top, round, and back under */
      p = p.concat(arc(1 - roll, 0.06 + lip, roll, lip, -Math.PI / 2, Math.PI / 2, 12));
      p = p.concat(arc(1 - roll, 0.06 + lip, roll * 0.46, lip * 0.46, Math.PI / 2, -Math.PI / 4, 8));
      p.push([1 - roll, 0.30]);
      /* down the right side of the field and along the foot */
      p.push([1 - roll * 0.72, 0.94]);
      p.push([-1 + roll * 0.72, 0.94]);
      p.push([-1 + roll, 0.30]);
      /* the left-hand roll, mirrored, and back up to where the top edge began */
      p = p.concat(arc(-1 + roll, 0.06 + lip, roll * 0.46, lip * 0.46, Math.PI * 1.25, Math.PI / 2, 8));
      p = p.concat(arc(-1 + roll, 0.06 + lip, roll, lip, Math.PI / 2, Math.PI * 1.5, 12));
      return p;
    }
  };

  /**
   * How wide each board hangs, as a multiple of its own height. The outlines
   * are all authored in the same normalised box, so without this table every
   * board would hang at one proportion and the corpus would lose a whole axis.
   * A shield stands tall; a scroll runs long.
   */
  var ASPECT = {
    heater: 0.85, oval: 1.50, lozenge: 1.30, hanging: 1.70, arch: 1.15,
    banner: 1.45, keyhole: 0.80, barrelEnd: 1.05, tankardCut: 0.90, scrollEnd: 1.80
  };

  /**
   * How long a name each board will take, in characters.
   *
   * This is measured from the outline ITSELF — the straight run it leaves at
   * the name line, divided by the type size the board's own height allows — so
   * a scroll board takes a long name and a keyhole takes a short one because of
   * how they are CUT, not because anyone said so. `BracketRead` ranks boards by
   * this when it decides which board a shop's name is cut onto.
   *
   * ⛔ wing §11a: the two constants below (the name line, and the type size as
   * a share of board height) also live in `geometry`. They are read from these
   * named constants in BOTH places, because a second copy of a constant does
   * not drift — it WINS.
   *
   * @param {string} board A board id.
   * @returns {number} Characters of Cinzel the board's name line will take.
   */
  function capacityOf(board) {
    var pts = (OUTLINE[board] || OUTLINE.hanging)();
    var yMin = Infinity, yMax = -Infinity, xMax = 0;
    for (var i = 0; i < pts.length; i++) {
      if (pts[i][1] < yMin) yMin = pts[i][1];
      if (pts[i][1] > yMax) yMax = pts[i][1];
      if (Math.abs(pts[i][0]) > xMax) xMax = Math.abs(pts[i][0]);
    }
    var span = Math.max(0.0001, yMax - yMin);
    var aspect = ASPECT[board];
    if (!isFinite(aspect) || aspect <= 0) aspect = 1.35;
    /* One board height is the unit. */
    var halfPx = aspect * 0.5;
    /* ⛔ wing §11a: THE SAME `letterBand` `geometry` uses. A second copy of this
     * rule would not drift, it would WIN — and the symptom would be a name cut
     * onto a board it does not fit, because the capacity was measured at one
     * height and the name struck at another. */
    var run = runAt(pts, yMin + span * letterBand(pts, yMin, span).nameY);
    var px = Math.max(0, run.width * (halfPx / (xMax || 1)) - BOARD_INSET * 2);
    /* A Cinzel capital at size s occupies about 0.58s of run with the +6%
     * tracking this product uses. Measured on the shipped face at the art
     * stage; a rough figure here only ever reorders the ranking. */
    return Math.max(1, px / (NAME_SIZE * 0.58));
  }

  /* The name line, the type size and the side inset, as shares of board height.
   * ⛔ wing §11a: declared ONCE, read by `geometry` and by `capacityOf`. */
  var NAME_Y = 0.745, TRADE_Y = 0.885, NAME_SIZE = 0.155, TRADE_SIZE = 0.085, BOARD_INSET = 0.06;

  /**
   * Where the lettering band actually is on a given outline.
   *
   * ⛔⛔ THE DEFECT, MEASURED 2026-09-14 on `src_derive_b.png`: `NAME_Y` and
   * `TRADE_Y` are shares of the outline's FULL height, and on the banner board
   * the bottom 28% of that height is a swallow-tail NOTCH — two tails with dusk
   * between them. The trade line "TAVERN" was therefore struck at 0.885 of a
   * board that stops being a board at 0.72, and half of it landed on the sky.
   * Every check was green: the width came from `runAt`, which returned the OUTER
   * extent across the hole.
   *
   * ⛔ wing §11b: a constant in a figure's coordinate space is an assumption
   * about its pose — here, the assumption that a board is solid all the way
   * down. The two heights are shares of the SOLID board now, which is the same
   * number on a rectangle and a smaller one on anything notched or pointed.
   * ⛔ wing §11 / §11a: `capacityOf` and `geometry` BOTH read this one function,
   * so the board a name is cut onto and the height it is struck at can never
   * disagree. A second copy of this rule would not drift, it would WIN.
   *
   * @param {number[][]} pts A board outline. @param {number} yMin Its top.
   * @param {number} span Its height in outline units.
   * @returns {object} `{solidBottom, nameY, tradeY, widest}`.
   */
  function letterBand(pts, yMin, span) {
    var widest = 0;
    for (var i = 0; i <= 24; i++) {
      var w = runAt(pts, yMin + span * (i / 24)).width;
      if (w > widest) widest = w;
    }
    /* The lowest height at which ONE solid run still spans the board's middle at
     * half its widest. Scanned from the foot upward, so a rectangle answers 1.0
     * on the first probe and nothing moves. */
    var solidBottom = 1;
    for (var k = 24; k >= 0; k--) {
      var t = k / 24;
      var r = runAt(pts, yMin + span * t);
      if (r.width >= widest * 0.5 && r.left <= 0 && r.right >= 0) { solidBottom = t; break; }
      solidBottom = t;
    }
    if (!(solidBottom > 0.2)) solidBottom = 1;
    return {
      solidBottom: solidBottom, widest: widest,
      nameY: NAME_Y * solidBottom,
      tradeY: TRADE_Y * solidBottom
    };
  }

  /**
   * The board's own half-width at a height.
   * ⛔ wing §11b: a constant in a figure's coordinate space is an assumption
   * about its pose. Everything a sign carries — the rings, the device, the
   * lettering, the keyline — is placed from THIS, so changing an outline moves
   * all of them without anyone editing a position.
   * @param {number[][]} pts The outline.
   * @param {number} y Height, 0 top to 1 foot.
   * @returns {object} `{left, right, width}` in board space; width 0 if outside.
   */
  function runAt(pts, y) {
    var xs = [];
    for (var i = 0; i < pts.length; i++) {
      var a = pts[i], b = pts[(i + 1) % pts.length];
      var y0 = a[1], y1 = b[1];
      if (y0 === y1) continue;
      if ((y >= y0 && y < y1) || (y >= y1 && y < y0)) {
        var t = (y - y0) / (y1 - y0);
        xs.push(a[0] + (b[0] - a[0]) * t);
      }
    }
    if (xs.length < 2) return { left: 0, right: 0, width: 0, runs: 0, outer: 0 };
    xs.sort(function (p, q) { return p - q; });
    /* ⛔⛔ THE DEFECT THIS PAIRING FIXES, and it shipped into a store image
     * before anyone opened it (2026-09-14, `src_derive_b.png`): this used to
     * return `xs[0]` to `xs[last]`, the OUTER extent of the outline at that
     * height. On a board with a notch — the banner's swallow tail, the keyhole,
     * the scroll end, the tankard cut — the outline crosses the scanline FOUR
     * times, and the outer extent spans the hole between the tails. The trade
     * line "TAVERN" was therefore centred on a notch and half of it was struck
     * onto the dusk behind the board, with every check green, because a width is
     * a number and nothing asked whether the board was actually THERE.
     *
     * Crossings come in pairs and a pair is a SOLID run. The widest solid run is
     * what anything drawn at this height can use; the outer extent is kept as
     * `outer` for the one caller that genuinely wants it (the rings, which hang
     * from the board's corners rather than from its middle). */
    var best = { left: xs[0], right: xs[1], width: xs[1] - xs[0] };
    var runs = 0;
    for (var k = 0; k + 1 < xs.length; k += 2) {
      runs++;
      var wdt = xs[k + 1] - xs[k];
      if (wdt > best.width) { best = { left: xs[k], right: xs[k + 1], width: wdt }; }
    }
    best.runs = runs;
    best.outer = xs[xs.length - 1] - xs[0];
    best.outerLeft = xs[0];
    best.outerRight = xs[xs.length - 1];
    return best;
  }

  /**
   * How many marks of width `ink` fit across `span` at the declared pitch, with
   * at least `PAPER_MIN` of paper between them.
   * ⛔ wing §22b-1a: a repeated treatment declares a PITCH and DERIVES its count
   * from the real run. If you are typing a count you are writing that defect.
   * ⛔ wing §22a-2d: the floor is absolute pixels, never a ratio.
   * ⚠️ The paper floor exists so two marks read as TWO. A chain is the one
   * repeat in this product where the marks are SUPPOSED to touch — links
   * interlock, that is what makes them a chain — so an interlocking run passes
   * `interlock: true` and keeps its pitch. Applying the floor to a chain is how
   * a 440 px sign came back with a two-link chain.
   *
   * @param {number} span Pixels available.
   * @param {number} ink Mark width in pixels.
   * @param {number} pitch Wanted centre-to-centre pixels.
   * @param {boolean} [interlock] True when the marks are meant to overlap.
   * @returns {object} `{count, pitch, floored}`.
   */
  function fitRepeat(span, ink, pitch, interlock) {
    var wanted = Number(pitch);
    if (!isFinite(wanted) || wanted <= 0) wanted = ink + PAPER_MIN;
    var minPitch = interlock ? Math.max(0.25, ink * 0.25) : ink + PAPER_MIN;
    var p = Math.max(wanted, minPitch);
    var floored = p > wanted + 0.0001;
    var n = Math.floor((Math.max(0, span) - ink) / p) + 1;
    if (!isFinite(n) || n < 0) n = 0;
    return { count: n, pitch: p, floored: floored };
  }

  /**
   * A pen for outlining one shape, from that shape's own box.
   * ⛔ wing §22a-2f: 5 px of pen on a 23 px head is the defect this exists for,
   * and an override that bypasses the rule is the same defect as not having it —
   * so this takes the SHAPE's box, never the figure's.
   * @param {number} w Shape width in pixels. @param {number} h Shape height.
   * @param {number} [k] Proportion. 0.16 against a small shape.
   * @returns {number} Pen width in pixels.
   */
  function penFor(w, h, k) {
    var kk = Number(k);
    if (!isFinite(kk) || kk <= 0) kk = 0.16;
    return Math.max(PEN_FLOOR, Math.min(w, h) * kk);
  }

  /* ------------------------------------------------------------- ironwork --
   * Eight bracket forms, poorest first. Each is a spine of points in BRACKET
   * SPACE: x 0 at the wall, 1 at the hanging point; y 0 at the fixing plate's
   * top, growing downward. The forms differ in SHAPE — a scroll that curls, a
   * gallows that braces, a volute that spirals — never merely in thickness.
   */
  /* ⛔ MEASURED 2026-09-13 by opening the Close Look: every spine below used to
   * be ONE open polyline containing both the straight arm and its scroll, and
   * the renderer stroked it as one path — so a stray line ran from the end of
   * the scroll back to the arm and the whole bracket read as loose wire. An
   * ornament is a SEPARATE stroke from the thing it ornaments. Each form now
   * returns `{arm, orn}`: `arm` is the run the board hangs from, in x 0..1 of
   * the reach; `orn` is a list of independent strokes. */
  /**
   * One volute, in UNIT space — a spiral that starts exactly on the arm at
   * (0, 0) and curls away from it, tightening as it goes.
   *
   * ⛔⛔ THE DEFECT THIS FUNCTION EXISTS FOR, measured on the art stage of
   * 2026-09-14 by opening `_probe/out/art_iron.png`: every scroll used to be an
   * `arc()` in SPINE space, where x is a share of the REACH (about 300 px) and y
   * a share of the IRON HEIGHT (about 65 px). A circle of equal radius in those
   * two units is an ellipse **4.6 times wider than it is tall**, so all eight
   * brackets carried a flattened open loop that read as loose lasso wire rather
   * than as wrought iron. It is wing §25c one level up: conflating two scales at
   * a corner kills the axis. A volute is now authored in ONE unit — the iron's
   * own height, in BOTH axes — and the renderer never stretches it.
   *
   * @param {number} R Starting radius, in iron-heights.
   * @param {number} sweep Total turn, in radians.
   * @param {number} dir +1 curls one way, -1 the other.
   * @param {number} [tighten] How much the radius falls over the sweep, 0..1.
   * @returns {number[][]} Points in iron-height units, starting at (0, 0).
   */
  function volute(R, sweep, dir, tighten) {
    var t2 = (tighten === undefined) ? 0.64 : tighten;
    var pts = [];
    for (var i = 0; i <= 26; i++) {
      var t = i / 26;
      var a = -Math.PI / 2 + dir * t * sweep;
      var r = R * (1 - t * t2);
      /* Negative y is UP. ⛔ MEASURED on the art stage of 2026-09-14: curling
       * DOWN put every scroll in the space the board occupies, so the board was
       * drawn over it and all that showed was the first few degrees of the
       * curve. A sign bracket's scroll lives in the triangle between the wall
       * and the arm, above it, which is also the only place it is free. */
      pts.push([Math.cos(a) * r, -(R + Math.sin(a) * r)]);
    }
    return pts;
  }

  /**
   * How far a spine's ornament rises ABOVE the arm it is welded to, in
   * iron-height units. Nothing types this: it is read off the ornament's own
   * points, so an ornament made bigger pushes the arm down by itself.
   * ⛔ Icon_Doctrine §25c: a treatment that draws outside the box it was given
   * is not "a bit of bleed", it is the box being wrong — reserve the margin.
   * @param {object} spine A spine from BRACKET_SPINE. @returns {number} Rise.
   */
  function spineRise(spine) {
    var rise = 0;
    var orn = (spine && spine.orn) || [];
    for (var i = 0; i < orn.length; i++) {
      var pts = orn[i].pts || [];
      for (var k = 0; k < pts.length; k++) if (-pts[k][1] > rise) rise = -pts[k][1];
    }
    return rise;
  }

  /** A closed ring in unit space, sitting ON its anchor and rising above it. */
  function unitRing(r, lift) {
    var pts = [];
    for (var i = 0; i <= 22; i++) {
      var a = i / 22 * Math.PI * 2 - Math.PI / 2;
      pts.push([Math.cos(a) * r, -(lift + r) + Math.sin(a) * r]);
    }
    return pts;
  }

  /**
   * The eight bracket forms. Each returns `{arm, orn, brace}`:
   *   `arm`   — the straight run the board hangs from. x 0 is the wall face, x 1
   *             the far end of the reach; y is a share of the iron's height.
   *   `orn`   — anchored ornaments, `{ax, pts}`: `ax` is where on the arm the
   *             ornament is welded (a share of the reach) and `pts` are in
   *             IRON-HEIGHT units in BOTH axes, so a circle stays a circle.
   *   `brace` — long straight runs in spine space, where the stretch is not a
   *             distortion because a straight line has no aspect to lose.
   * They differ in SHAPE — a scroll that curls, a gallows that braces, a volute
   * that genuinely spirals — never merely in thickness (wing §21a).
   * @returns {object} `{arm, orn, brace}`.
   */
  var BRACKET_SPINE = {
    plainHook: function () {
      return { arm: [[0, 0.14], [1, 0.14]], orn: [], brace: [] };
    },
    barAndRing: function () {
      return {
        arm: [[0, 0.13], [1, 0.13]],
        orn: [{ ax: 0.80, pts: unitRing(0.20, 0.06) }],
        brace: []
      };
    },
    singleScroll: function () {
      return {
        arm: [[0, 0.12], [1, 0.12]],
        orn: [{ ax: 0.22, pts: volute(0.40, Math.PI * 1.7, 1) }],
        brace: []
      };
    },
    doubleScroll: function () {
      return {
        arm: [[0, 0.11], [1, 0.11]],
        orn: [
          { ax: 0.18, pts: volute(0.40, Math.PI * 1.7, 1) },
          { ax: 0.58, pts: volute(0.30, Math.PI * 1.5, -1) }
        ],
        brace: []
      };
    },
    volute: function () {
      return {
        arm: [[0, 0.10], [1, 0.10]],
        orn: [{ ax: 0.24, pts: volute(0.52, Math.PI * 2.4, 1, 0.72) }],
        brace: []
      };
    },
    leafScroll: function () {
      return {
        arm: [[0, 0.10], [1, 0.10]],
        orn: [{ ax: 0.20, pts: volute(0.46, Math.PI * 1.9, 1) }],
        brace: []
      };
    },
    gallows: function () {
      /* The brace is what a gallows IS: a diagonal from the wall to the arm. */
      return {
        arm: [[0, 0.09], [1, 0.09]],
        orn: [{ ax: 0.70, pts: volute(0.26, Math.PI * 1.4, -1) }],
        brace: [[[0.015, 0.62], [0.42, 0.09]]]
      };
    },
    crownedScroll: function () {
      return {
        arm: [[0, 0.08], [1, 0.08]],
        orn: [
          { ax: 0.16, pts: volute(0.44, Math.PI * 1.8, 1) },
          { ax: 0.50, pts: volute(0.34, Math.PI * 2.2, -1, 0.70) },
          { ax: 0.82, pts: volute(0.26, Math.PI * 1.5, 1) }
        ],
        brace: [[[0.015, 0.66], [0.38, 0.08]]]
      };
    }
  };

  /** Which forms carry a diagonal brace, and which carry leaves. */
  var BRACKET_TRAIT = {
    plainHook: { brace: false, leaves: 0, plateH: 0.22 },
    barAndRing: { brace: false, leaves: 0, plateH: 0.26 },
    singleScroll: { brace: false, leaves: 0, plateH: 0.30 },
    doubleScroll: { brace: false, leaves: 0, plateH: 0.34 },
    volute: { brace: false, leaves: 0, plateH: 0.36 },
    leafScroll: { brace: false, leaves: 3, plateH: 0.40 },
    gallows: { brace: true, leaves: 0, plateH: 0.46 },
    crownedScroll: { brace: true, leaves: 2, plateH: 0.52 }
  };

  /* --------------------------------------------------------------- devices --
   * Twelve trade marks. Each is a list of primitives in DEVICE SPACE:
   * x and y both in [-1, 1], y down. The renderer fills them as ONE mass so
   * the mark reads as a silhouette (Icon_Doctrine §22c).
   *
   * ⛔ Icon_Doctrine §22a: the eye pairs symmetrical masses and infers a known
   * glyph — two rings become spectacles, radial spikes become a sun. Every mark
   * below is deliberately ASYMMETRIC about the vertical, and where a subject is
   * symmetric by nature (the shield, the horseshoe) something crosses it.
   * ⛔ §22a-1b: appendages OVERLAP the mass they grow from, never abut.
   * ⛔ §22c: a TOOL is read from the JOINT — the step where blade meets shaft.
   *
   * Primitive kinds: poly (filled), circ (filled disc), cut (a hole, traced in
   * the SAME path as the shape it bites — §22d), bar (a thick line with a
   * declared width, in device units).
   */
  var DEVICE = {
    /* A sword laid across an anvil. The anvil's horn points left and its foot
     * steps right, so the mass is asymmetric before the sword crosses it. */
    swordAnvil: [
      { t: 'poly', pts: [[-0.92, 0.10], [-0.44, -0.02], [0.62, -0.02], [0.72, 0.14], [0.30, 0.20], [0.22, 0.44], [0.46, 0.52], [0.46, 0.70], [-0.40, 0.70], [-0.40, 0.52], [-0.16, 0.44], [-0.22, 0.20], [-0.62, 0.20]] },
      { t: 'bar', a: [-0.70, -0.74], b: [0.52, -0.18], w: 0.13 },
      /* ⛔ §22a-1b: the pommel and the guard ABUTTED the blade and read as two
       * loose scraps beside it at 120 px. The pommel is a disc ON the blade's
       * own end and the guard CROSSES it — a tool is read from the joint. */
      { t: 'circ', x: -0.74, y: -0.76, r: 0.15 },
      { t: 'bar', a: [-0.58, -0.36], b: [-0.30, -0.90], w: 0.09 }
    ],
    /* A heater shield crossed by a bend, with the strap end projecting clear of
     * the outline (§22c: regalia that projects breaks an emoticon reading). */
    shield: [
      { t: 'poly', pts: [[-0.68, -0.72], [0.68, -0.72], [0.68, -0.06], [0.40, 0.46], [0, 0.78], [-0.40, 0.46], [-0.68, -0.06]] },
      { t: 'bar', a: [-0.62, -0.52], b: [0.52, 0.28], w: 0.24, ink: 'counter' },
      { t: 'poly', pts: [[0.60, -0.78], [0.94, -0.62], [0.86, -0.44], [0.56, -0.58]] }
    ],
    /* A round-bottomed flask, neck tilted right, stopper overlapping the neck,
     * a pouring lip on one side only. */
    /* ⛔⛔ IT READ AS A BOMB, and the contact sheet did not catch it — the
     * 48-sign board did, on 2026-09-14, where five apothecaries across four
     * districts were all carrying a cartoon bomb. A round body with a short neck
     * and a small angled thing on top IS a bomb with a fuse; that is the known
     * glyph the eye reaches for (Icon_Doctrine §22a), and no amount of shading
     * argues with it. The STOPPER WAS THE FUSE, so it is gone. What replaces it
     * is what actually says "vessel for liquid": a long neck, a flared pouring
     * LIP that breaks the silhouette sideways, and a level line of contents
     * across the body. A bomb has no lip and no liquid in it. */
    flask: [
      { t: 'circ', x: -0.06, y: 0.36, r: 0.52 },
      { t: 'poly', pts: [[-0.22, 0.02], [0.14, -0.04], [0.30, -0.66], [0.08, -0.70], [-0.04, -0.12], [-0.28, -0.08]] },
      { t: 'poly', pts: [[0.00, -0.62], [0.46, -0.74], [0.52, -0.92], [-0.06, -0.78]] },
      { t: 'bar', a: [-0.52, 0.30], b: [0.40, 0.22], w: 0.09, ink: 'counter' },
      { t: 'cut', pts: [[-0.38, 0.46], [-0.10, 0.42], [-0.08, 0.60], [-0.36, 0.64]] }
    ],
    /* A flowering sprig. ⛔ §22a-2b rule 1 and §22a-5b, MEASURED on the art
     * stage's first contact sheet: the leaves were THIN BARS on a straight stem
     * with a disc on top, and it read as a SIGNPOST at every size. A leaf is not
     * a stroke — it is a lens with a point at each end, wide enough to carry its
     * own midrib, OVERLAPPING the stem it grows from (§22a-1b). The stem curves
     * (two bars meeting mid-height) and the head is a CLUSTER of three discs, so
     * no single disc can read as a lollipop. */
    herb: [
      { t: 'bar', a: [0.24, 0.92], b: [0.02, 0.16], w: 0.10 },
      { t: 'bar', a: [0.02, 0.16], b: [-0.14, -0.44], w: 0.09 },
      { t: 'poly', pts: [[0.08, 0.56], [-0.26, 0.26], [-0.68, 0.16], [-0.88, 0.30], [-0.56, 0.52], [-0.18, 0.64]] },
      { t: 'poly', pts: [[0.00, 0.20], [0.36, -0.02], [0.76, -0.06], [0.88, 0.10], [0.56, 0.30], [0.18, 0.36]] },
      { t: 'poly', pts: [[-0.02, -0.16], [-0.32, -0.40], [-0.68, -0.50], [-0.82, -0.34], [-0.52, -0.14], [-0.20, -0.04]] },
      { t: 'bar', a: [-0.06, 0.46], b: [-0.70, 0.30], w: 0.045, ink: 'counter' },
      { t: 'bar', a: [0.10, 0.26], b: [0.74, 0.10], w: 0.045, ink: 'counter' },
      { t: 'circ', x: -0.20, y: -0.60, r: 0.19 },
      { t: 'circ', x: 0.06, y: -0.72, r: 0.14 },
      { t: 'circ', x: -0.36, y: -0.82, r: 0.12 }
    ],
    /* A table-cut stone set at a tilt, with a culet spur below and facet lines
     * that do not mirror. ⛔ §22d and §22c, measured on the art stage's contact
     * sheet: the table was a HOLE, and a solid ring around a void reads as a
     * bucket, not a stone. A facet is a groove in a SOLID mass — the table is
     * outlined in the counter ink and the pavilion lines run down from it. */
    gem: [
      { t: 'poly', pts: [[-0.62, -0.34], [-0.22, -0.72], [0.48, -0.66], [0.76, -0.24], [0.20, 0.70], [-0.30, 0.46]] },
      { t: 'bar', a: [-0.30, -0.30], b: [-0.02, -0.52], w: 0.06, ink: 'counter' },
      { t: 'bar', a: [-0.02, -0.52], b: [0.38, -0.44], w: 0.06, ink: 'counter' },
      { t: 'bar', a: [0.38, -0.44], b: [0.12, -0.08], w: 0.06, ink: 'counter' },
      { t: 'bar', a: [0.12, -0.08], b: [-0.30, -0.30], w: 0.06, ink: 'counter' },
      { t: 'bar', a: [0.12, -0.08], b: [0.20, 0.66], w: 0.05, ink: 'counter' },
      { t: 'bar', a: [-0.28, -0.30], b: [-0.28, 0.44], w: 0.05, ink: 'counter' },
      { t: 'bar', a: [0.38, -0.44], b: [0.74, -0.24], w: 0.05, ink: 'counter' }
    ],
    /* A part-unrolled scroll. ⛔ §22a, measured: the roll was TWO DISCS at the
     * SAME end and the pair read as the spools of a cassette. A roll is ONE
     * cylinder — a body with an elliptical end cap — and there is exactly one,
     * at the left, with the sheet running out of it and the far end curling.
     * The two ends are deliberately different: rolled, and torn. */
    scroll: [
      { t: 'poly', pts: [[-0.40, -0.40], [0.42, -0.34], [0.46, 0.34], [-0.36, 0.42]] },
      { t: 'poly', pts: [[-0.40, -0.40], [-0.64, -0.46], [-0.78, -0.22], [-0.70, 0.12], [-0.58, 0.40], [-0.36, 0.42], [-0.46, 0.12], [-0.50, -0.16]] },
      { t: 'cut', circ: true, x: -0.60, y: -0.02, r: 0.08 },
      { t: 'poly', pts: [[0.42, -0.34], [0.66, -0.40], [0.76, -0.12], [0.62, 0.04], [0.78, 0.24], [0.60, 0.42], [0.46, 0.34]] },
      { t: 'bar', a: [-0.24, -0.18], b: [0.30, -0.14], w: 0.06, ink: 'counter' },
      { t: 'bar', a: [-0.22, 0.00], b: [0.34, 0.04], w: 0.06, ink: 'counter' },
      { t: 'bar', a: [-0.20, 0.18], b: [0.06, 0.20], w: 0.06, ink: 'counter' }
    ],
    /* A bloomer. ⛔ §22i, measured on the art stage's contact sheet: the outline
     * was a rounded blob and the slashes ran nearly its whole height, so it read
     * as a CRACKED STONE. Bread is told by its BASE — a flat foot with a domed
     * crust over it — and by slashes that live on the crust only, short and
     * parallel, never reaching the foot. The counters are clipped to the mass. */
    loaf: [
      { t: 'poly', pts: [[-0.80, 0.46], [-0.84, 0.10], [-0.62, -0.28], [-0.18, -0.50], [0.26, -0.52], [0.64, -0.32], [0.82, 0.04], [0.80, 0.46]] },
      { t: 'bar', a: [-0.52, -0.22], b: [-0.32, 0.06], w: 0.10, ink: 'counter' },
      { t: 'bar', a: [-0.12, -0.38], b: [0.08, -0.10], w: 0.10, ink: 'counter' },
      { t: 'bar', a: [0.30, -0.32], b: [0.50, -0.04], w: 0.10, ink: 'counter' },
      { t: 'bar', a: [-0.82, 0.26], b: [0.82, 0.26], w: 0.05, ink: 'counter' }
    ],
    /* A tankard: handle right, hinged lid tilted OPEN so the skyline is broken
     * on one side only (§22a-4: one beast owns a skyline feature). */
    tankard: [
      { t: 'poly', pts: [[-0.56, -0.44], [0.34, -0.44], [0.42, 0.72], [-0.62, 0.72]] },
      { t: 'poly', pts: [[-0.66, -0.58], [0.44, -0.58], [0.46, -0.40], [-0.68, -0.40]] },
      { t: 'poly', pts: [[-0.60, -0.62], [0.10, -0.86], [0.40, -0.80], [0.42, -0.62]] },
      /* The handle is a squared D with a real grip hole, not a wire chevron: two
       * thin bars meeting at a point abutted the body and read as a spout. */
      { t: 'bar', a: [0.28, -0.28], b: [0.82, -0.22], w: 0.16 },
      { t: 'bar', a: [0.82, -0.22], b: [0.84, 0.30], w: 0.16 },
      { t: 'bar', a: [0.84, 0.30], b: [0.30, 0.40], w: 0.16 },
      { t: 'cut', pts: [[0.44, -0.12], [0.70, -0.10], [0.72, 0.20], [0.46, 0.26]] },
      { t: 'bar', a: [-0.50, 0.30], b: [0.36, 0.30], w: 0.06, ink: 'counter' }
    ],
    /* THE INN. ⛔ Icon_Doctrine §22a-5b, and the subject was CHANGED on the art
     * stage's evidence rather than shaded harder: a bed drawn in profile IS a
     * slab, its identity is PROPORTION, and beside a key it read as a boot at
     * 120 px and as a smear at 32. The key alone says lodging, and a ward key is
     * all silhouette — a pierced bow, a collar, a shank, and a bit that hangs
     * off ONE side so nothing about it is symmetric. The id is `key` because a
     * corpus id that lies about what is drawn is §22b-5 waiting to happen. */
    key: [
      { t: 'circ', x: -0.58, y: -0.14, r: 0.36 },
      { t: 'cut', circ: true, x: -0.58, y: -0.14, r: 0.17 },
      { t: 'bar', a: [-0.34, -0.06], b: [0.78, 0.12], w: 0.16 },
      { t: 'poly', pts: [[0.08, -0.24], [0.24, -0.21], [0.28, 0.32], [0.12, 0.29]] },
      { t: 'poly', pts: [[0.42, 0.10], [0.78, 0.16], [0.74, 0.66], [0.38, 0.58]] },
      { t: 'cut', pts: [[0.50, 0.26], [0.70, 0.29], [0.70, 0.38], [0.50, 0.35]] },
      { t: 'cut', pts: [[0.56, 0.44], [0.74, 0.47], [0.74, 0.55], [0.56, 0.52]] }
    ],
    /* THE TAILOR. ⛔ Icon_Doctrine §22a-5b again, same stage, same evidence: a
     * needle is a LINE, its identity is proportion, and at 32 px it read as a
     * spear with a snake on it. Shears say the same trade and are pure
     * silhouette — a long V of blades opening left, a pivot, and two bows of
     * DIFFERENT size and height at the right, which is what stops §22a's
     * two-rings-are-spectacles reading. The id is `shears`. */
    shears: [
      { t: 'poly', pts: [[0.22, 0.08], [-0.90, -0.42], [-0.98, -0.26], [0.16, 0.26]] },
      { t: 'poly', pts: [[0.16, 0.26], [-0.92, 0.10], [-0.88, 0.28], [0.22, 0.44]] },
      { t: 'circ', x: 0.20, y: 0.24, r: 0.14 },
      { t: 'bar', a: [0.20, 0.18], b: [0.50, 0.02], w: 0.12 },
      { t: 'circ', x: 0.64, y: -0.08, r: 0.29 },
      { t: 'cut', circ: true, x: 0.64, y: -0.08, r: 0.15 },
      { t: 'bar', a: [0.22, 0.32], b: [0.52, 0.52], w: 0.12 },
      { t: 'circ', x: 0.68, y: 0.62, r: 0.23 },
      { t: 'cut', circ: true, x: 0.68, y: 0.62, r: 0.11 }
    ],
    /* A whole fish in an S, head left, tail notched (§22i: serve it WHOLE — a
     * cross-section has no silhouette). One dorsal fin, one pectoral, one eye. */
    fish: [
      { t: 'poly', pts: [[-0.94, 0.06], [-0.52, -0.34], [0.12, -0.42], [0.56, -0.20], [0.74, 0.10], [0.42, 0.42], [-0.20, 0.48], [-0.70, 0.34]] },
      { t: 'poly', pts: [[-0.10, -0.40], [0.16, -0.82], [0.40, -0.30]] },
      { t: 'poly', pts: [[0.02, 0.40], [0.20, 0.72], [0.44, 0.36]] },
      { t: 'poly', pts: [[0.70, 0.04], [0.98, -0.34], [0.86, 0.10], [0.98, 0.52]] },
      { t: 'cut', circ: true, x: -0.60, y: -0.02, r: 0.12 }
    ],
    /* A horseshoe, open end down-RIGHT and tilted, with a calkin on one heel
     * only. ⛔ §22a: a rounded base with two points is a CRESCENT — the tilt,
     * the single calkin and the nail holes are what stop it being one. */
    horseshoe: [
      { t: 'ring', x: -0.04, y: -0.04, r: 0.66, w: 0.30, a0: Math.PI * 0.78, a1: Math.PI * 2.10 },
      { t: 'poly', pts: [[0.30, 0.50], [0.66, 0.42], [0.78, 0.72], [0.40, 0.80]] },
      { t: 'cut', circ: true, x: -0.60, y: -0.30, r: 0.09 },
      { t: 'cut', circ: true, x: -0.34, y: -0.60, r: 0.09 },
      { t: 'cut', circ: true, x: 0.16, y: -0.64, r: 0.09 },
      { t: 'cut', circ: true, x: 0.48, y: -0.32, r: 0.09 }
    ]
  };

  /**
   * The bounding box of a device's primitives, in device space.
   * ⛔ Icon_Doctrine §22a-6: a CLIPPED figure and a WRONG figure look identical.
   * Measure the box first; the contact sheet draws to this, not to +-1.
   * @param {string} id A device id.
   * @returns {object} `{minX, minY, maxX, maxY, w, h}`.
   */
  function deviceBounds(id) {
    var prims = DEVICE[id] || [];
    var b = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity };
    function add(x, y) {
      if (x < b.minX) b.minX = x; if (x > b.maxX) b.maxX = x;
      if (y < b.minY) b.minY = y; if (y > b.maxY) b.maxY = y;
    }
    for (var i = 0; i < prims.length; i++) {
      var p = prims[i];
      if (p.t === 'poly' || (p.t === 'cut' && p.pts)) {
        for (var k = 0; k < p.pts.length; k++) add(p.pts[k][0], p.pts[k][1]);
      } else if (p.t === 'circ' || (p.t === 'cut' && p.circ)) {
        add(p.x - p.r, p.y - p.r); add(p.x + p.r, p.y + p.r);
      } else if (p.t === 'bar') {
        var h = p.w / 2;
        add(Math.min(p.a[0], p.b[0]) - h, Math.min(p.a[1], p.b[1]) - h);
        add(Math.max(p.a[0], p.b[0]) + h, Math.max(p.a[1], p.b[1]) + h);
      } else if (p.t === 'ring') {
        add(p.x - p.r - p.w / 2, p.y - p.r - p.w / 2);
        add(p.x + p.r + p.w / 2, p.y + p.r + p.w / 2);
      }
    }
    b.w = b.maxX - b.minX; b.h = b.maxY - b.minY;
    return b;
  }

  /* ------------------------------------------------------------- the sign --*/

  /**
   * Everything a sign needs, in PIXELS, derived from its profile and the height
   * it is drawn at. Nothing downstream computes a position.
   *
   * The sign's total height is the budget. It is spent, in order, on the fixing
   * plate and arm, the rings and chain, and the board — and the board gets
   * whatever is left, because a board too small to letter is the failure mode
   * (wing §18b: a scene that wastes its frame is a PRODUCT defect).
   *
   * @param {object} p A profile from BracketRead.
   * @param {number} height The sign's full height in pixels, bracket to foot.
   * @returns {object} The geometry.
   */
  function geometry(p, height) {
    var H = Math.max(24, Number(height) || 128);
    var trait = BRACKET_TRAIT[p.bracket] || BRACKET_TRAIT.plainHook;

    /* The iron takes a fixed share of the height; a grander bracket takes more,
     * which is exactly how standing becomes visible (wing §25g). */
    var ironH = H * (0.20 + trait.plateH * 0.16);
    var chainH = H * 0.085;
    var boardH = H - ironH - chainH;
    var pts = (OUTLINE[p.board] || OUTLINE.hanging)();

    /* Board width follows its own outline's aspect, so a lozenge is not forced
     * into a rectangle's box. Half-width 1 in board space maps to boardHalfPx. */
    var yMin = Infinity, yMax = -Infinity, xMax = 0;
    for (var i = 0; i < pts.length; i++) {
      if (pts[i][1] < yMin) yMin = pts[i][1];
      if (pts[i][1] > yMax) yMax = pts[i][1];
      if (Math.abs(pts[i][0]) > xMax) xMax = Math.abs(pts[i][0]);
    }
    var span = Math.max(0.0001, yMax - yMin);
    /* ⛔ wing §11a: ONE assignment, one reader. A second copy of a constant does
     * not drift, it WINS, and it presents as a stale build.
     * Every outline is AUTHORED in x [-1,1] by y [0,1], which says nothing about
     * how wide the board should hang — so each one declares its own proportion
     * in `ASPECT` and that is the only place a board's width is decided. A
     * shield board is taller than wide; a scroll board is nearly twice as wide
     * as it is tall. That spread is itself an axis of the corpus. */
    var aspect = ASPECT[p.board];
    if (!isFinite(aspect) || aspect <= 0) aspect = 1.35;
    var boardHalfPx = boardH * aspect * 0.5;
    var boardW = boardHalfPx * 2;

    /** Board space -> pixels, with the board's top-left at (0,0). */
    function bx(x) { return (x / (xMax || 1)) * boardHalfPx + boardHalfPx; }
    function by(y) { return ((y - yMin) / span) * boardH; }

    /* --- the rings hang from the board's own widest run near its top --------
     * ⛔ wing §11b: not from a constant. A keyhole board is narrow at the top,
     * so its rings come in; a banner is full width, so they go out. */
    var topY = 0.06;
    var topRun = runAt(pts, yMin + span * topY);
    if (topRun.width <= 0.02) topRun = runAt(pts, yMin + span * 0.16);
    var ringR = Math.max(2, boardH * 0.055);
    var ringInset = Math.max(ringR * 1.4, topRun.width * (xMax || 1) * 0.10);
    var ringLeftX = bx(topRun.left) + ringInset;
    var ringRightX = bx(topRun.right) - ringInset;
    if (ringRightX - ringLeftX < ringR * 4) {
      var mid = (ringLeftX + ringRightX) / 2;
      ringLeftX = mid - ringR * 2; ringRightX = mid + ringR * 2;
    }

    /* --- the chain: pitch from the ring, count from the real drop -----------
     * ⛔ wing §24d / Icon_Doctrine §22b-1a. */
    var linkH = ringR * 1.5;
    var chain = fitRepeat(chainH + linkH, linkH, linkH * 0.72, true);

    /* --- where the lettering sits, FIRST, because the device is fitted to what
     * the lettering leaves. ⛔ The two heights are shares of the board's SOLID
     * run, derived by `letterBand`, which `capacityOf` reads too (wing §11). */
    var band = letterBand(pts, yMin, span);
    var nameY = band.nameY;
    var tradeY = band.tradeY;

    /* --- the device: the largest square the BAND ABOVE THE NAME will take -----
     * ⛔⛔ MEASURED 2026-09-14, and it is the second half of the notch defect.
     * Once the lettering moved up onto the solid part of a notched board, the
     * device — which took a FIXED 0.40 of the FULL board height — was left
     * sitting exactly where the name now is, and `src_derive_b.png` came back
     * with "The Gilded Tankard" struck straight through a tankard. Fixing one
     * end of a layout and leaving the other in the old coordinate space is wing
     * §11b in one board: a constant in a figure's space is an assumption about
     * its pose, and the pose changed.
     * The device's band is what is actually left: from a little off the head of
     * the board down to the cap line of the name. It is centred in that band and
     * fitted to it.
     * ⛔ The brief's floor ("a device is at least 40% of the board's height")
     * YIELDS to the band rather than overriding it. A device that meets the
     * floor by overlapping the shop's name is not a device at 40%, it is a
     * collision — and on a banner, whose solid board is only 71% of its outline,
     * the floor is simply not reachable. Recorded here rather than silently. */
    var bandTopPx = boardH * 0.055;
    var nameCapPx = boardH * nameY - Math.max(7, boardH * NAME_SIZE) * 1.08;
    var devBandH = Math.max(8, nameCapPx - bandTopPx);
    var devY = (bandTopPx + devBandH / 2) / boardH;
    var devRun = runAt(pts, yMin + span * devY);
    var devMaxW = devRun.width * (boardHalfPx / (xMax || 1));
    var devH = Math.max(8, Math.min(devBandH * 0.94, devMaxW * 0.82));
    if (devH < boardH * 0.40) devH = Math.min(boardH * 0.40, devBandH * 0.98);
    /* ⛔ A device drawn into a SQUARE box is a device squashed: the twelve marks
     * run from 0.65 (the flask, tall) to 1.62 (the loaf, wide). Each is fitted
     * by its OWN measured bounds, so the loaf stays a loaf. */
    var devBounds = deviceBounds(p.device);
    var devAspect = (devBounds.h > 0) ? (devBounds.w / devBounds.h) : 1;
    if (!isFinite(devAspect) || devAspect <= 0) devAspect = 1;
    var devW = devH * devAspect;
    if (devW > devMaxW * 0.92) { devW = devMaxW * 0.92; devH = devW / devAspect; }

    /* --- the lettering: as wide as the straight run the outline leaves -------
     * ⛔ wing §11a: NAME_Y, TRADE_Y, NAME_SIZE, TRADE_SIZE and BOARD_INSET are
     * declared once, above, and read here AND by `capacityOf`. */
    /* ⛔ A LINE OF TYPE HAS TO SIT WHERE THE BOARD IS SOLID — `nameY` and
     * `tradeY` came off `letterBand` above, before the device was fitted. */
    var nameRun = runAt(pts, yMin + span * nameY);
    var tradeRun = runAt(pts, yMin + span * tradeY);
    var inset = Math.max(3, boardH * BOARD_INSET);
    var nameW = Math.max(8, nameRun.width * (boardHalfPx / (xMax || 1)) - inset * 2);
    var tradeW = Math.max(6, tradeRun.width * (boardHalfPx / (xMax || 1)) - inset * 2);
    /* ⛔ AND THE PAINT'S OWN RETREAT, or a worn sign strikes its name onto the
     * bare oak outside the coat — 91 of 240 cases, worst 49.6% of a name's ink
     * off its own ground (2026-09-14, `_probe/letter_fit.js`). A painted board's
     * type sits on the PAINT, so the room it has is measured on the polygon the
     * painter actually fills.
     * ⛔ The first attempt subtracted the inset from each side arithmetically.
     * That is correct on a rectangle and wrong on every board that tapers: it
     * cut the failures from 91 to 40 and left the WORST case exactly where it
     * was, because a vertex pulled toward the centre moves up as well as in
     * (wing §11b — a constant in a figure's coordinate space is an assumption
     * about its pose). The run is now measured ON the inset polygon at the
     * line's own height, which is the shape the coat really has. */
    if (SCHEME_FIELD[p.scheme]) {
      var coat = paintInset(boardW, boardH, p.weathering);
      if (coat > 0.5) {
        var pxPts = [];
        for (var pi = 0; pi < pts.length; pi++) pxPts.push([bx(pts[pi][0]), by(pts[pi][1])]);
        var coated = insetPolygon(pxPts, boardHalfPx, boardH / 2, coat);
        var nameRunPx = pixelRunAt(coated, by(yMin + span * nameY), boardHalfPx);
        var tradeRunPx = pixelRunAt(coated, by(yMin + span * tradeY), boardHalfPx);
        /* A line whose band the coat no longer reaches keeps a floor rather than
         * collapsing to nothing — the name still has to be readable on a ruin. */
        if (nameRunPx > 0) nameW = Math.max(8, Math.min(nameW, nameRunPx - inset));
        if (tradeRunPx > 0) tradeW = Math.max(6, Math.min(tradeW, tradeRunPx - inset));
      }
    }
    /* An arc for the two round-headed boards, straight for the rest. */
    var arcLetters = (p.board === 'oval' || p.board === 'heater' || p.board === 'arch');

    /* --- the grain: pitch from the board's SHORT side, count derived ---------*/
    var grainInk = Math.max(1, boardH * 0.020);
    var grain = fitRepeat(boardH, grainInk, grainInk * 3.4);

    /* --- where the arm sits, DERIVED from its own ornament --------------------
     * ⛔ Icon_Doctrine §25c: 26 of 26 treatments once drew outside the box they
     * were given, and the answer is never "cut the ornament back" (§14a) — it is
     * to reserve the margin. A scroll curls UP from the arm, so the arm cannot
     * sit at the top of the iron band or the scroll is drawn off the sign. The
     * arm's height is the ornament's own rise plus a margin, and an ornament
     * made bigger pushes the arm down by itself. Nobody types this.
     * ⛔ wing §11a: the arm run is rewritten HERE, once, so the renderer cannot
     * hold a second opinion about where the arm is. */
    var armedSpine = (BRACKET_SPINE[p.bracket] || BRACKET_SPINE.plainHook)();
    var rise = spineRise(armedSpine);
    var armShare = Math.max(armedSpine.arm[0][1], rise + 0.10);
    armedSpine.arm = armedSpine.arm.map(function (q) { return [q[0], armShare]; });
    /* A brace runs from the wall TO THE ARM — that is what makes it a brace. Its
     * far end is snapped to wherever the arm ended up, so moving the arm can
     * never leave a brace ending in mid-air. ⛔ §11a: a second copy of a constant
     * does not drift, it WINS. */
    armedSpine.brace = (armedSpine.brace || []).map(function (run) {
      var out = run.slice();
      out[out.length - 1] = [out[out.length - 1][0], armShare];
      return out;
    });
    armedSpine.armShare = armShare;
    armedSpine.rise = rise;

    /* --- the fixing plate and its nails --------------------------------------*/
    var plateW = Math.max(6, ironH * 0.34);
    /* ⛔ MEASURED on the art stage of 2026-09-14 by opening `art_iron.png`: once
     * the arm moved down to make room for its scroll, the plate stopped reaching
     * it and four of eight brackets had a visible gap between the wall fixing
     * and the bar it is supposed to hold. A plate that does not reach the arm is
     * not fixing anything, so its height is at least the arm's drop. */
    var plateH = Math.max(8, ironH * (0.42 + trait.plateH * 0.42),
      Math.min(ironH, armShare * ironH + ironH * 0.12));
    /* Two columns of nails, one down each side of the plate; how many ROWS is
     * derived from the plate's real height at the declared pitch. A small plate
     * gets four nails and a crowned scroll's plate gets more, and nobody typed
     * either number (⛔ wing §24d). */
    var nailInk = Math.max(1.4, plateW * 0.16);
    var nails = fitRepeat(plateH - nailInk * 2, nailInk, nailInk * 4.0);
    nails.cols = 2;
    nails.total = nails.count * nails.cols;

    return {
      H: H, boardW: boardW, boardH: boardH, boardHalfPx: boardHalfPx,
      ironH: ironH, chainH: chainH,
      outline: pts, xMax: xMax, yMin: yMin, span: span,
      bx: bx, by: by,
      ring: { r: ringR, leftX: ringLeftX, rightX: ringRightX, y: -chainH * 0.10 },
      chain: chain, linkH: linkH,
      device: { y: devY, h: devH, w: devW, maxW: devMaxW, bounds: devBounds, aspect: devAspect },
      name: { y: nameY, w: nameW, arc: arcLetters, size: Math.max(7, boardH * NAME_SIZE) },
      trade: { y: tradeY, w: tradeW, size: Math.max(5, boardH * TRADE_SIZE) },
      keylineInset: inset * 0.7,
      grain: grain, grainInk: grainInk,
      plate: { w: plateW, h: plateH }, nails: nails, nailInk: nailInk,
      trait: trait, spine: armedSpine,
      /* ⛔ MEASURED 2026-09-13: the arm used to reach `boardW * 0.62 + ironH *
       * 0.30`, which is SHORTER THAN THE BOARD — so the right-hand ring hung
       * past the end of the arm, attached to nothing, and the chain dropped
       * through empty air. A bracket that does not reach its own rings is not
       * holding anything up. The reach is derived from the board it carries,
       * plus the stand-off the fixing plate needs at the wall. */
      reach: boardW + Math.max(2, ironH * 0.20) + ironH * 0.10,
      tilt: p.tilt
    };
  }

  /**
   * What a weathering level does, as numbers rather than adjectives.
   * Every field here is READ by the renderer — ⛔ Icon_Doctrine §22a-2e: a
   * corpus field nothing draws is a whole axis of the product that does not
   * exist, and `_probe/axis_reads.js` asserts each one moves the picture.
   * @param {number} level 0..4.
   * @returns {object} The weather.
   */
  function weather(level) {
    var L = Math.max(0, Math.min(4, Math.round(Number(level) || 0)));
    return {
      level: L,
      /* How much of the timber shows through the paint. The brief's range. */
      grainThrough: [0.08, 0.14, 0.21, 0.28, 0.35][L],
      /* How far the paint has been eaten back from each corner, as a fraction
       * of the board's short side. */
      cornerWear: [0.00, 0.04, 0.09, 0.15, 0.22][L],
      /* How much the gilt has gone off: 0 bright, 1 dead. */
      giltDull: [0.00, 0.12, 0.34, 0.58, 0.80][L],
      /* Rust bleeding down from each ring, in ring radii. */
      rustDrop: [0.0, 0.0, 0.9, 1.8, 3.0][L],
      /* A split corner appears at 3, and opens at 4. */
      crack: L >= 3 ? (L === 4 ? 1.0 : 0.55) : 0,
      /* One chain link is gone by 4. */
      linkGone: L >= 4 ? 1 : 0
    };
  }

  /**
   * How far the PAINT is inset from the board's own outline, in pixels.
   *
   * ⛔⛔ THE DEFECT THIS FUNCTION EXISTS TO CLOSE, MEASURED 2026-09-14 at the
   * polish stage by opening a fresh-install screenshot: the paint retreats from
   * the edges as the weather eats it back (`cornerWear` reaches 0.22 of the
   * short side at weathering 4), and the LETTERING never knew. The name was
   * fitted to the board outline, so on a worn sign the gilt ran off the coat and
   * onto bare oak — 91 of 240 swept cases, worst 49.6% of a name's ink off its
   * own ground (`_probe/letter_fit.js`). Every check in the project was green:
   * no counter can see type crossing a colour boundary.
   *
   * ⛔ wing §17c-1 / §25h: the ink is SOLVED against the paint colour, so a
   * letter that lands on oak is also unproven for contrast — the picture and
   * the proof were about different surfaces.
   * ⛔ wing §11: the painter and the type-fitter now read THIS, once. A second
   * copy of a constant does not drift, it WINS.
   *
   * @param {number} boardW The board's width in pixels.
   * @param {number} boardH Its height in pixels.
   * @param {number} weathering 0..4.
   * @returns {number} The inset in pixels, 0 on a crisp sign.
   */
  function paintInset(boardW, boardH, weathering) {
    return weather(weathering).cornerWear * Math.min(boardW, boardH);
  }

  /**
   * Shrink a polygon toward a centre by a number of pixels.
   * ⛔ wing §11: the painter draws the coat on THIS polygon and the type-fitter
   * measures its room on THIS polygon. It lived in the renderer and the fitter
   * approximated it with "minus the inset on each side" — which is right on a
   * rectangle and badly wrong on anything that tapers, because a vertex pulled
   * toward the centre moves UP as well as IN. On the heater board that left the
   * worst case untouched at 49.6% after the first fix.
   * @param {number[][]} pts Points. @param {number} cx Centre x.
   * @param {number} cy Centre y. @param {number} px Pixels to pull in.
   * @returns {number[][]} A new polygon.
   */
  function insetPolygon(pts, cx, cy, px) {
    var out = [];
    for (var i = 0; i < pts.length; i++) {
      var dx = pts[i][0] - cx, dy = pts[i][1] - cy;
      var d = Math.sqrt(dx * dx + dy * dy) || 1;
      var k = Math.max(0, (d - px)) / d;
      out.push([cx + dx * k, cy + dy * k]);
    }
    return out;
  }

  /**
   * The horizontal run of a PIXEL-space polygon at a pixel height — `runAt` for
   * a shape that has already been mapped out of board space.
   * ⛔ Same pairing rule as `runAt`: take the run that CONTAINS the centre, so a
   * notched board cannot report the span across its own hole.
   * @param {number[][]} pts A pixel polygon. @param {number} y A pixel height.
   * @param {number} cx The centre the run must contain.
   * @returns {number} The run's width in pixels, 0 when the shape is absent there.
   */
  function pixelRunAt(pts, y, cx) {
    var xs = [];
    for (var i = 0; i < pts.length; i++) {
      var a = pts[i], b = pts[(i + 1) % pts.length];
      if (a[1] === b[1]) continue;
      if ((y >= a[1] && y < b[1]) || (y >= b[1] && y < a[1])) {
        var t = (y - a[1]) / (b[1] - a[1]);
        xs.push(a[0] + (b[0] - a[0]) * t);
      }
    }
    if (xs.length < 2) return 0;
    xs.sort(function (p, q) { return p - q; });
    for (var k = 0; k + 1 < xs.length; k += 2) {
      if (xs[k] <= cx && xs[k + 1] >= cx) return xs[k + 1] - xs[k];
    }
    return 0;
  }

  return {
    PAPER_MIN: PAPER_MIN, PEN_FLOOR: PEN_FLOOR, PALETTE: PALETTE, SCHEME_FIELD: SCHEME_FIELD,
    paintInset: paintInset, insetPolygon: insetPolygon, pixelRunAt: pixelRunAt,
    OUTLINE: OUTLINE, ASPECT: ASPECT, DEVICE: DEVICE,
    BRACKET_SPINE: BRACKET_SPINE, BRACKET_TRAIT: BRACKET_TRAIT,
    parseHex: parseHex, toHex: toHex, lum: lum, contrast: contrast, relief: relief,
    rgbOf: rgbOf, groundFor: groundFor,
    pickContrast: pickContrast, arc: arc,
    runAt: runAt, fitRepeat: fitRepeat, penFor: penFor, letterBand: letterBand,
    deviceBounds: deviceBounds, geometry: geometry, weather: weather,
    capacityOf: capacityOf,
    NAME_Y: NAME_Y, TRADE_Y: TRADE_Y, NAME_SIZE: NAME_SIZE, TRADE_SIZE: TRADE_SIZE
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.BracketCompose;
