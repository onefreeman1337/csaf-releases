AETHERBOUND VOL. I - FREE PREVIEW
Core Systems Asset Factory

Three of the fourteen tracks, complete and unmodified, with their editable MIDI sources.

  Hearthmoot
    title · D dorian · 96 BPM · 2:05
    loops seamlessly: LOOPSTART 220500, LOOPLENGTH 5292000

  The Cooper and Crown
    tavern · G mixolydian · 128 BPM · 1:08
    loops seamlessly: LOOPSTART 165375, LOOPLENGTH 2811375

  The Little Chapel
    chapel · D aeolian · 62 BPM · 2:08
    loops seamlessly: LOOPSTART 341419, LOOPLENGTH 5292000

  The Feast Day
    festival · G mixolydian · 132 BPM · 1:05
    loops seamlessly: LOOPSTART 160364, LOOPLENGTH 2726181

WHY THESE THREE
---------------
The title states the album's main theme plainly. The town theme is the track a player hears most
in any RPG, so it is the one that has to be hummable. And the boss theme is the battle theme
transformed - augmented, re-harmonised, moved a major third from home - which is the claim the
full album is actually selling, and the only one you can check by ear.

These are the real files, not clips. The OGGs carry the same sample-accurate LOOPSTART and
LOOPLENGTH tags RPG Maker MV and MZ read. Drop one into audio/bgm/ and it will loop correctly.

THE LICENCE ON THESE THREE
--------------------------
Free to evaluate. If you want to ship them in a game, buy the pack - the full licence is in
LICENSE.txt there, and it is royalty-free with no per-title fee and no attribution requirement.

The full album is 14 tracks covering title, town, field, forest, cave, dungeon, battle, boss,
sacred, inn, three stingers and an ambient bed, in one musical voice built from one family of
eight themes.

  https://csaf.itch.io/aetherbound-vol-1
