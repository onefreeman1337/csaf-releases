/* PROMPTBOX — the simulation.
 *
 * Pure logic. No DOM, no canvas, no audio, no timers. `require()`-able from node so the test
 * harness plays the SHIPPED file rather than a copy of it (wing §0z / master §1.1b), and loaded
 * by the browser through a plain <script> tag.
 *
 * The whole game is one 180-second loop over a 3x3 cutaway of an opera-house backstage. Five of
 * the company move on SCHEDULES, not on a script: each has somewhere to be by a given bar and
 * re-routes when a door is bolted, a lamp is doused, a prop is missing, or it is being watched.
 * Nothing survives a loop except the player's casebook.
 *
 * DETERMINISM IS A REQUIREMENT, NOT A NICETY. `stepOnce()` is the only thing that advances time,
 * it takes a fixed dt, and every random draw comes from the seeded PRNG below. Same seed + same
 * inputs => same 180 seconds, every time, in node and in the browser. The harness depends on it
 * and so does the store capture (wing §3c-16: a capture harness and the game are two drivers, so
 * the model must not care which one is calling).
 */
'use strict';

(function (root, factory) {
  var M = factory();
  if (typeof module === 'object' && module.exports) module.exports = M;
  else root.PB = M;
}(typeof self !== 'undefined' ? self : this, function () {

  /* ------------------------------------------------------------------ constants */

  var LOOP_SECONDS = 180;          // the theme, the title mechanic and the fail timer at once
  var DT = 1 / 30;                 // fixed simulation step, seconds
  var SEC_PER_BAR = 2;             // 120bpm, 4/4 => 90 bars of overture
  var BARS = LOOP_SECONDS / SEC_PER_BAR;
  var PLAYER_STEP = 1.1;           // seconds to cross one doorway; the prompter knows the passes
  var AGENT_STEP = 1.8;            // the company is slower, carrying things
  var CUE_WINDOW = [170, 179];     // when a whispered line can still reach the stage

  /* Rooms are a 3x3 cutaway. Index = y*3 + x, so adjacency is grid 4-neighbours and the map
   * reads top-to-bottom as flies / stage level / understage. */
  var ROOMS = [
    { id: 0, name: 'THE FLIES',   sub: 'rope gallery'   },
    { id: 1, name: 'THE GRID',    sub: 'over the stage' },
    { id: 2, name: 'WARDROBE',    sub: 'mirrors'        },
    { id: 3, name: 'LEFT WING',   sub: 'the callboard'  },
    { id: 4, name: 'THE STAGE',   sub: 'curtain down'   },
    { id: 5, name: 'GREEN ROOM',  sub: 'the samovar'    },
    { id: 6, name: 'TRAP ROOM',   sub: 'machinery'      },
    { id: 7, name: 'PROMPT BOX',  sub: 'your hutch'     },
    { id: 8, name: 'PROP STORE',  sub: 'the pistol case'}
  ];
  var GX = function (r) { return r % 3; };
  var GY = function (r) { return (r / 3) | 0; };

  function neighbours(r) {
    var out = [], x = GX(r), y = GY(r);
    if (x > 0) out.push(r - 1);
    if (x < 2) out.push(r + 1);
    if (y > 0) out.push(r - 3);
    if (y < 2) out.push(r + 3);
    return out;
  }
  function doorId(a, b) { return a < b ? a + '-' + b : b + '-' + a; }

  /* Every grid edge is a door. These four are the ones the prompter can actually bolt: the rest
   * are open arches with no leaf to bolt, which is why BOLT is a scarce verb and not a free one. */
  var BOLTABLE = ['0-3', '1-4', '2-5', '5-8'];

  var AGENTS = [
    { id: 'sorrenta', name: 'LA SORRENTA', role: 'prima donna', tint: 'gold'  },
    { id: 'vello',    name: 'VELLO',       role: 'understudy',  tint: 'green' },
    { id: 'march',    name: 'MARCH',       role: 'flyman',      tint: 'rust'  },
    { id: 'dubois',   name: 'DUBOIS',      role: 'the patron',  tint: 'wine'  },
    { id: 'kestrel',  name: 'KESTREL',     role: 'the dresser', tint: 'blue'  }
  ];

  var SUSPECTS = ['vello', 'march', 'dubois'];

  /* ------------------------------------------------------------------ PRNG */

  function mulberry(seed) {
    var a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ------------------------------------------------------------------ the case */

  /* One of three culprits per seed. Each has a DIFFERENT observable signature — a different
   * opportunity window, a different motive scene and a different piece of method evidence — so
   * the three facts an accusation needs cannot be collected by rote. */
  var CASE = {
    vello: {
      culprit: 'vello',
      motiveText: 'VELLO is told the role will never be his while she sings.',
      methodText: 'A rope in the flies has been cut most of the way through, and the knife is in the prop store.',
      opportunity: { room: 0, from: 148, to: 166 },
      motiveScene: { room: 5, at: 62, with: 'dubois' },
      methodEvidence: { room: 8, id: 'knife' }
    },
    march: {
      culprit: 'march',
      motiveText: 'MARCH has not been paid in eleven weeks and SORRENTA laughed at him for asking.',
      methodText: 'The counterweight pins are out of their housing, and only the flyman carries the key.',
      opportunity: { room: 0, from: 152, to: 172 },
      motiveScene: { room: 3, at: 48, with: 'sorrenta' },
      methodEvidence: { room: 6, id: 'pins' }
    },
    dubois: {
      culprit: 'dubois',
      motiveText: 'SORRENTA means to tell the board what DUBOIS did with the subscription money.',
      methodText: 'A ledger page is burnt in the green-room grate, and the flyman was paid to be elsewhere.',
      opportunity: { room: 0, from: 156, to: 170 },
      motiveScene: { room: 5, at: 70, with: 'sorrenta' },
      methodEvidence: { room: 5, id: 'ledger' }
    }
  };

  /* ------------------------------------------------------------------ facts */

  /* A fact is only ever written when the player PERSONALLY witnesses it (§ the casebook is the
   * save). `need` is what an accusation requires: opportunity + motive + method, for one suspect. */
  /* TWELVE facts, not five. The first version had five, and the probe caught the consequence
   * immediately: DOUSE unlocks at 6 and CUE at 8, so on a five-fact catalogue BOTH VERBS WERE
   * UNREACHABLE and half the game could not be played (master §2b, the dead-reader class). The
   * cheap early facts are deliberate — they are what pays for the verbs. */
  function factCatalogue(culpritId) {
    var c = CASE[culpritId];
    var A = function (id) { return AGENTS.filter(function (a) { return a.id === id; })[0].name; };
    var b = function (s) { return Math.floor(s / SEC_PER_BAR); };
    return [
      { id: 'box',    kind: 'context',     text: 'From the box you can be heard on the boards and nowhere else in the house.' },
      { id: 'callbd', kind: 'context',     text: 'The callboard gives the overture at ninety bars. Three minutes exactly.' },
      { id: 'trap',   kind: 'context',     text: 'The understage machinery is locked off tonight. Nothing comes up through the boards.' },
      { id: 'dressr', kind: 'context',     text: 'KESTREL laces her in and then leaves her alone. She always leaves her alone.' },
      { id: 'flyman', kind: 'context',     text: 'MARCH carries the pin key on his belt, and the flies are his floor.' },
      { id: 'patron', kind: 'context',     text: 'DUBOIS keeps to the green room. He does not like heights and says so often.' },
      { id: 'undstd', kind: 'context',     text: 'VELLO is dressed for the part already, and there is no call for him tonight.' },
      { id: 'rope',   kind: 'context',     text: 'The sandbag over centre stage is on a single line.' },
      { id: 'mark',   kind: 'context',     text: 'LA SORRENTA takes her mark at centre stage on bar 88, and does not look up.' },
      { id: 'op',     kind: 'opportunity', text: A(culpritId) + ' was in the flies, alone, between bar '
          + b(c.opportunity.from) + ' and bar ' + b(c.opportunity.to) + '.' },
      { id: 'motive', kind: 'motive',      text: c.motiveText },
      { id: 'method', kind: 'method',      text: c.methodText }
    ];
  }

  /* ------------------------------------------------------------------ verbs */

  /* Unlocks are paced by casebook size, which is the ledger-B5 "unlocks paced over time" clause:
   * the player begins able only to watch, and every new verb opens perturbations the previous
   * one could not reach. */
  var VERBS = [
    { id: 'watch',  name: 'WATCH',  at: 0, help: 'Being in a room records who is in it.' },
    { id: 'follow', name: 'FOLLOW', at: 2, help: 'Keep pace with one of the company for a while.' },
    { id: 'bolt',   name: 'BOLT',   at: 4, help: 'Shoot a bolt. They must go round, and that shows.' },
    { id: 'douse',  name: 'DOUSE',  at: 6, help: 'Kill a lamp. Work needing light fails in the dark.' },
    { id: 'cue',    name: 'CUE',    at: 8, help: 'From the box, whisper a line to whoever is on the boards.' }
  ];

  function verbsFor(nFacts) {
    return VERBS.filter(function (v) { return nFacts >= v.at; });
  }

  /* ------------------------------------------------------------------ schedules */

  /* A plan entry is "be in `room` by `t`, then do `act`". It is a GOAL, not a position: the agent
   * paths to it and can arrive late, and arriving late is itself observable. */
  function buildPlans(culpritId, rnd) {
    var c = CASE[culpritId];
    var plans = {};

    plans.sorrenta = [
      { t: 10,  room: 2, act: 'dress'   },
      { t: 60,  room: 5, act: 'wait'    },
      { t: 120, room: 5, act: 'wait'    },
      { t: 168, room: 3, act: 'wait'    },
      { t: 176, room: 4, act: 'mark'    }
    ];
    plans.kestrel = [
      { t: 8,   room: 2, act: 'lace'    },
      { t: 70,  room: 8, act: 'fetch'   },
      { t: 110, room: 2, act: 'press'   },
      { t: 160, room: 3, act: 'wait'    }
    ];
    plans.vello = [
      { t: 12,  room: 5, act: 'wait'    },
      { t: 66,  room: 3, act: 'pace'    },
      { t: 120, room: 8, act: 'rummage' },
      { t: 170, room: 3, act: 'wait'    }
    ];
    plans.march = [
      { t: 6,   room: 0, act: 'rig'     },
      { t: 55,  room: 3, act: 'callbrd' },
      { t: 100, room: 0, act: 'rig'     },
      { t: 175, room: 0, act: 'rig'     }
    ];
    plans.dubois = [
      { t: 14,  room: 5, act: 'wait'    },
      { t: 90,  room: 5, act: 'wait'    },
      { t: 150, room: 3, act: 'wait'    },
      { t: 174, room: 3, act: 'wait'    }
    ];

    // The motive scene: both parties are pinned in one room at that bar, so it can be witnessed.
    var ms = c.motiveScene;
    [c.culprit, ms.with].forEach(function (who) {
      if (!plans[who]) return;
      plans[who] = plans[who].concat([{ t: ms.at, room: ms.room, act: 'quarrel' }]);
    });

    // The opportunity: the culprit must be in the flies, alone, in their window.
    plans[c.culprit] = plans[c.culprit].concat([
      { t: c.opportunity.from, room: 0, act: 'cut' }
    ]);

    // DUBOIS pays MARCH to be away, so MARCH's last rig call moves off the flies in that case.
    if (culpritId === 'dubois') {
      plans.march = plans.march.map(function (e) {
        return (e.t === 175) ? { t: 150, room: 5, act: 'paid' } : e;
      });
    }
    // If VELLO is the culprit he must not also be pacing in the wing at that moment.
    if (culpritId === 'vello') {
      plans.vello = plans.vello.filter(function (e) { return e.t !== 170; });
    }
    // If MARCH is the culprit his 100s rig call slides so the flies are his alone late on.
    if (culpritId === 'march') {
      plans.march = plans.march.filter(function (e) { return e.t !== 100; });
    }

    Object.keys(plans).forEach(function (k) {
      plans[k].sort(function (a, b) { return a.t - b.t; });
    });
    // One tiny seeded jitter so two seeds with the same culprit do not play identically.
    Object.keys(plans).forEach(function (k) {
      plans[k].forEach(function (e) {
        if (e.act === 'wait' || e.act === 'pace') e.t += Math.floor(rnd() * 6) - 3;
      });
      plans[k].sort(function (a, b) { return a.t - b.t; });
    });
    return plans;
  }

  /* ------------------------------------------------------------------ pathing */

  function bfs(from, to, bolted) {
    if (from === to) return [];
    var prev = {}, seen = {}, q = [from];
    seen[from] = true;
    while (q.length) {
      var cur = q.shift();
      var ns = neighbours(cur);
      for (var i = 0; i < ns.length; i++) {
        var n = ns[i];
        if (seen[n]) continue;
        if (bolted[doorId(cur, n)]) continue;
        seen[n] = true; prev[n] = cur;
        if (n === to) {
          var path = [n], p = cur;
          while (p !== from) { path.unshift(p); p = prev[p]; }
          return path;
        }
        q.push(n);
      }
    }
    return null;                                   // genuinely unreachable: the agent waits, visibly
  }

  /* ------------------------------------------------------------------ state */

  function newLoop(seed, casebook) {
    var rnd = mulberry(seed);
    var culprit = SUSPECTS[Math.floor(rnd() * SUSPECTS.length)];
    var plans = buildPlans(culprit, rnd);

    var agents = AGENTS.map(function (a) {
      return {
        id: a.id, name: a.name, role: a.role, tint: a.tint,
        room: a.id === 'march' ? 0 : (a.id === 'sorrenta' || a.id === 'kestrel' ? 2 : 5),
        path: [], moveT: 0, plan: plans[a.id], planIdx: 0,
        act: 'idle', actUntil: 0, late: false, reason: ''
      };
    });

    return {
      seed: seed, culprit: culprit,
      t: 0, bar: 1, over: false, outcome: null, ending: null,
      player: { room: 7, path: [], moveT: 0, following: null, followUntil: 0 },
      agents: agents,
      bolted: {}, doused: {}, palmed: {},
      cued: false, cueEffective: false,
      casebook: casebook || {},               // fact id -> true, PERSISTS across loops
      log: [],                                // per-loop reason lines, for readability
      newFacts: [],                           // facts written THIS loop, for the loop-end screen
      accusation: null,
      catalogue: factCatalogue(culprit)
    };
  }

  /* ------------------------------------------------------------------ observation */

  function agentsIn(S, room) {
    return S.agents.filter(function (a) { return a.room === room && a.path.length === 0; });
  }

  function witness(S, factId) {
    if (S.casebook[factId]) return false;
    S.casebook[factId] = true;
    S.newFacts.push(factId);
    return true;
  }

  function factCount(S) { return Object.keys(S.casebook).length; }

  /* The player writes a fact only by being present. Every branch here is reachable from the
   * harness, which is why the harness can prove the casebook fills without a human. */
  function observe(S) {
    var c = CASE[S.culprit];
    var here = S.player.room;
    var present = agentsIn(S, here);

    // Opportunity — the culprit alone in the flies inside their window.
    if (here === 0 && S.t >= c.opportunity.from && S.t <= c.opportunity.to) {
      var flies = present.filter(function (a) { return a.id === c.culprit; });
      if (flies.length && !S.doused[0]) witness(S, 'op');
    }
    // Motive — both parties, in the motive room, around the motive bar.
    if (here === c.motiveScene.room && Math.abs(S.t - c.motiveScene.at) < 14) {
      var ids = present.map(function (a) { return a.id; });
      if (ids.indexOf(c.culprit) >= 0 && ids.indexOf(c.motiveScene.with) >= 0) witness(S, 'motive');
    }
    // Method — the physical evidence, in its room, needs light.
    if (here === c.methodEvidence.room && !S.doused[here] && S.t > 20) witness(S, 'method');

    // Context. Cheap, but still only ever by being in the room — these are what pay for the verbs.
    var idsHere = present.map(function (x) { return x.id; });
    if (here === 7 && S.t > 8) witness(S, 'box');
    if (here === 3 && S.t > 5) witness(S, 'callbd');
    if (here === 6 && S.t > 5) witness(S, 'trap');
    if (here === 2 && idsHere.indexOf('kestrel') >= 0) witness(S, 'dressr');
    if (here === 0 && idsHere.indexOf('march') >= 0) witness(S, 'flyman');
    if (here === 5 && idsHere.indexOf('dubois') >= 0) witness(S, 'patron');
    if (idsHere.indexOf('vello') >= 0) witness(S, 'undstd');
    if (here === 4 && S.t > 100) witness(S, 'rope');
    if ((here === 4 || here === 7) && S.t > 150) witness(S, 'mark');
  }

  /* ------------------------------------------------------------------ agent tick */

  function agentStep(S, a) {
    // Mid-move?
    if (a.path.length) {
      a.moveT -= DT;
      if (a.moveT <= 0) { a.room = a.path.shift(); a.moveT = a.path.length ? AGENT_STEP : 0; }
      return;
    }
    if (S.t < a.actUntil) return;                            // busy performing

    // Advance to the plan entry that is due.
    while (a.planIdx < a.plan.length - 1 && S.t >= a.plan[a.planIdx + 1].t) a.planIdx++;
    var goal = a.plan[a.planIdx];
    if (!goal) return;

    if (a.room !== goal.room) {
      var path = bfs(a.room, goal.room, S.bolted);
      if (!path) {
        if (!a.late) { a.late = true; a.reason = a.name + ' cannot get through. Every way is bolted.'; S.log.push(a.reason); }
        return;
      }
      // Being sent the long way is the observable consequence of BOLT, and it is announced.
      var direct = bfs(a.room, goal.room, {});
      if (direct && path.length > direct.length && !a.late) {
        a.late = true;
        a.reason = a.name + ' finds a bolted door and goes round.';
        S.log.push(a.reason);
      }
      a.path = path; a.moveT = AGENT_STEP;
      return;
    }

    // In the right room: perform. Some acts fail in the dark, or without their prop.
    if (a.act !== goal.act) {
      if (goal.act === 'cut' && S.doused[a.room]) {
        if (!a.late) { a.reason = a.name + ' gropes at the pin rail in the dark and gives it up.'; S.log.push(a.reason); a.late = true; }
        a.act = 'baffled'; a.actUntil = S.t + 8;
        return;
      }
      if (goal.act === 'rummage' && S.palmed[a.room]) {
        if (!a.late) { a.reason = a.name + ' searches the prop store for something that is not there.'; S.log.push(a.reason); a.late = true; }
        a.act = 'baffled'; a.actUntil = S.t + 6;
        return;
      }
      a.act = goal.act;
      a.actUntil = S.t + 6;
    }
  }

  /* Did the culprit actually get their cut in? Everything that prevents it is a perturbation the
   * player made, which is why the loop is worth re-running. */
  function cutLanded(S) {
    var c = CASE[S.culprit];
    var a = S.agents.filter(function (x) { return x.id === c.culprit; })[0];
    return !!(a && a._cutDone);
  }

  /* ------------------------------------------------------------------ the step */

  /* THE ONLY THING THAT ADVANCES TIME. The rAF loop calls it, the harness calls it, the store
   * capture calls it — one clock, one driver (wing §3c-7 / §3c-16). */
  function stepOnce(S) {
    if (S.over) return S;
    S.t += DT;
    S.bar = Math.min(BARS, Math.floor(S.t / SEC_PER_BAR) + 1);

    // Player movement
    if (S.player.path.length) {
      S.player.moveT -= DT;
      if (S.player.moveT <= 0) {
        S.player.room = S.player.path.shift();
        S.player.moveT = S.player.path.length ? PLAYER_STEP : 0;
      }
    }
    // FOLLOW: re-target the player at whoever is being followed.
    if (S.player.following && S.t < S.player.followUntil && S.player.path.length === 0) {
      var tgt = S.agents.filter(function (a) { return a.id === S.player.following; })[0];
      if (tgt && tgt.room !== S.player.room) {
        var p = bfs(S.player.room, tgt.room, S.bolted);
        if (p && p.length) { S.player.path = p; S.player.moveT = PLAYER_STEP; }
      }
    } else if (S.player.following && S.t >= S.player.followUntil) {
      S.player.following = null;
    }

    for (var i = 0; i < S.agents.length; i++) {
      var a = S.agents[i];
      agentStep(S, a);
      // The cut only lands if the culprit is actually in the flies, in the window, with light.
      var c = CASE[S.culprit];
      if (a.id === c.culprit && a.room === 0 && a.act === 'cut' && !a._cutDone
          && S.t >= c.opportunity.from && S.t <= c.opportunity.to && !S.doused[0]) {
        a._cutDone = true;
        S.log.push('Something gives, high up over the stage.');
      }
    }

    observe(S);

    if (S.t >= LOOP_SECONDS) finish(S);
    return S;
  }

  function finish(S) {
    S.over = true;
    var sorrenta = S.agents.filter(function (a) { return a.id === 'sorrenta'; })[0];
    var onMark = sorrenta.room === 4 && !S.cueEffective;
    var falls = cutLanded(S);

    S.died = falls && onMark;
    if (S.died) {
      S.outcome = 'dead';
      S.ending = 'The curtain goes up. It goes up on a woman under a sandbag, and on nine hundred '
        + 'people who will remember it for the rest of their lives. Go back to the box.';
    } else if (!falls && !S.accusation) {
      S.outcome = 'saved';
      S.ending = 'Nothing falls. She sings. And whoever meant it to fall is still in the building, '
        + 'and will be here again tomorrow night.';
    } else if (falls && !onMark) {
      S.outcome = 'saved';
      S.ending = 'The bag comes down on bare boards two feet from her shoe. She does not even stop '
        + 'singing. But you still cannot say whose hand it was.';
    } else {
      S.outcome = 'saved';
      S.ending = 'She sings.';
    }

    // WIN requires both halves: she lives, AND the accusation is correct and evidenced.
    if (!S.died && S.accusation && S.accusation.correct) {
      S.outcome = 'won';
      S.ending = 'She sings, and at the interval they take ' + S.accusation.nameOf
        + ' out through the scene dock, quietly, so as not to spoil the second act.';
    }
    return S;
  }

  /* ------------------------------------------------------------------ player verbs */

  function can(S, verbId) {
    return verbsFor(factCount(S)).some(function (v) { return v.id === verbId; });
  }

  function moveTo(S, room) {
    if (S.over || S.player.path.length) return false;
    if (neighbours(S.player.room).indexOf(room) < 0) return false;
    if (S.bolted[doorId(S.player.room, room)]) return false;
    S.player.following = null;
    S.player.path = [room];
    S.player.moveT = PLAYER_STEP;
    return true;
  }

  function follow(S, agentId) {
    if (!can(S, 'follow') || S.over) return false;
    var a = S.agents.filter(function (x) { return x.id === agentId; })[0];
    if (!a || a.room !== S.player.room) return false;
    S.player.following = agentId;
    S.player.followUntil = S.t + 24;
    S.log.push('You keep to the passes behind ' + a.name + '.');
    return true;
  }

  function bolt(S, room) {
    if (!can(S, 'bolt') || S.over) return false;
    var d = doorId(S.player.room, room);
    if (BOLTABLE.indexOf(d) < 0) return false;
    if (S.bolted[d]) return false;
    S.bolted[d] = true;
    S.log.push('You shoot the bolt on the ' + ROOMS[room].name.toLowerCase() + ' door.');
    return true;
  }

  function douse(S) {
    if (!can(S, 'douse') || S.over) return false;
    if (S.doused[S.player.room]) return false;
    S.doused[S.player.room] = true;
    S.log.push('You pinch out the lamp in ' + ROOMS[S.player.room].name + '.');
    return true;
  }

  function palm(S) {
    if (!can(S, 'douse') || S.over) return false;      // PALM rides the same unlock as DOUSE
    if (S.player.room !== 8 || S.palmed[8]) return false;
    S.palmed[8] = true;
    S.log.push('You put the knife in your coat.');
    return true;
  }

  function cue(S) {
    if (!can(S, 'cue') || S.over) return false;
    if (S.player.room !== 7) return false;
    if (S.t < CUE_WINDOW[0] || S.t > CUE_WINDOW[1]) return false;
    if (S.cued) return false;
    S.cued = true;
    var sorrenta = S.agents.filter(function (a) { return a.id === 'sorrenta'; })[0];
    // She has to be on the boards, or close enough to them, for a whisper to reach her. Cueing
    // too early wastes the one cue you get — and knowing the right bar is exactly the kind of
    // knowledge this game asks you to carry out of a failed loop.
    if (sorrenta.room === 4 || S.t >= 172) {
      S.cueEffective = true;
      S.log.push('You give her the line a half-bar early. She takes it downstage, off the mark.');
      return true;
    }
    S.log.push('You whisper, and there is nobody on the boards to hear it.');
    return true;
  }

  function accuse(S, suspectId) {
    if (S.over) return false;
    var c = CASE[S.culprit];
    var have = S.casebook.op && S.casebook.motive && S.casebook.method;
    if (!have) return false;                            // evidence, not a guess
    var nm = AGENTS.filter(function (a) { return a.id === suspectId; })[0];
    S.accusation = {
      suspect: suspectId,
      nameOf: nm ? nm.name : suspectId,
      correct: suspectId === c.culprit
    };
    return true;
  }

  /* ------------------------------------------------------------------ helpers for the shell */

  function factsText(S) {
    return S.catalogue.filter(function (f) { return S.casebook[f.id]; });
  }
  function canAccuse(S) { return !!(S.casebook.op && S.casebook.motive && S.casebook.method); }

  return {
    LOOP_SECONDS: LOOP_SECONDS, DT: DT, BARS: BARS, SEC_PER_BAR: SEC_PER_BAR,
    CUE_WINDOW: CUE_WINDOW, BOLTABLE: BOLTABLE,
    ROOMS: ROOMS, AGENTS: AGENTS, SUSPECTS: SUSPECTS, VERBS: VERBS, CASE: CASE,
    GX: GX, GY: GY, neighbours: neighbours, doorId: doorId, bfs: bfs,
    newLoop: newLoop, stepOnce: stepOnce, finish: finish,
    moveTo: moveTo, follow: follow, bolt: bolt, douse: douse, palm: palm, cue: cue, accuse: accuse,
    can: can, verbsFor: verbsFor, factCount: factCount, factsText: factsText,
    canAccuse: canAccuse, agentsIn: agentsIn, factCatalogue: factCatalogue
  };
}));
