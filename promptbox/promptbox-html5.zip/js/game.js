/* PROMPTBOX — the shell: renderer, input, screens, persistence.
 *
 * The MODEL (js/model.js) owns every rule and is the only thing that advances time. This file
 * draws it and takes input, and holds no game rules of its own — which is what lets the headless
 * harness in Internal_Ops play the SHIPPED model without a browser (§0z: there is no human tester,
 * so the tests have to be able to reach everything).
 *
 * ⛔ ASSETS LOAD VIA new Image() / new Audio(), NEVER fetch(). fetch is blocked on file:// , and a
 *    build that only runs behind a web server cannot be checked by opening the zip.
 */
'use strict';

(function () {

  var W = 960, H = 600;
  var HEADER_H = 54;
  var GRID_X = 12, GRID_Y = 62, CELL_W = 238, CELL_H = 172, GAP = 4;
  var PANEL_X = 744, PANEL_W = 204;

  var GILT = '#c9a961', GILT_DIM = '#8f7a4e', INK = '#0b0709', PAPER = '#cdbb96';
  /* The ending screens' already-known facts, dimmer than a fresh one but still READABLE. It was
   * rgba(190,170,120,0.5), which composites over the oxblood curtain to rgb(124,94,74) — MEASURED
   * 2.77:1 against the 4.5:1 floor for body text, and an independent review measured 2.91:1 off the
   * shipped plate. The same defect had just been fixed for the room subtitles one surface over, so
   * this is §3c-22's rule about retiring a claim in one place only, in colour. At 0.75 the same hue
   * composites to rgb(157,132,97) = 4.60:1 and the fresh-vs-known hierarchy survives, because fresh
   * facts are full-strength GILT. ⛔ The text gate has no notion of contrast and never will catch
   * this — it is measured by hand or not at all. */
  var FACT_DIM = 'rgba(190,170,120,0.75)';

  var cv = document.getElementById('c');
  var ctx = cv.getContext('2d', { alpha: false });
  ctx.imageSmoothingEnabled = false;

  /* ---------------------------------------------------------------- assets */

  var PLATE_NAMES = ['boards', 'plank', 'velvet', 'flat', 'stone', 'brick'];
  /* Which material each room is made of. This is also the room's IDENTITY — a player who cannot
   * tell the trap room from the prop store cannot tell where anybody was. */
  var ROOM_PLATE = ['plank', 'plank', 'velvet', 'flat', 'boards', 'velvet', 'stone', 'boards', 'brick'];

  var SFX_NAMES = ['fact', 'bolt', 'douse', 'cue', 'step', 'fall', 'unlock'];

  var img = {}, pattern = {}, sfx = {}, music = null, figures = null, figuresDark = null;
  var figMeta = { frameW: 20, frameH: 32, frames: 2,
    order: ['sorrenta', 'vello', 'march', 'dubois', 'kestrel', 'prompter'] };

  var toLoad = 0, loaded = 0, failed = [];
  function loadImage(key, src) {
    toLoad++;
    var i = new Image();
    i.onload = function () { img[key] = i; loaded++; };
    i.onerror = function () { failed.push(src); loaded++; };
    i.src = src;
    return i;
  }
  function loadAudio(key, src) {
    var a = new Audio();
    a.preload = 'auto';
    a.src = src;
    return a;
  }

  PLATE_NAMES.forEach(function (n) { loadImage(n, 'art/' + n + '.png'); });
  loadImage('figures', 'art/figures.png');
  SFX_NAMES.forEach(function (n) { sfx[n] = loadAudio(n, 'audio/sfx_' + n + '.wav'); });
  music = loadAudio('music', 'audio/music_overture.ogg');
  music.loop = true;
  music.volume = 0.55;

  function play(name) {
    var a = sfx[name];
    if (!a) return;
    try { a.currentTime = 0; var p = a.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
  }
  /* Autoplay is denied until a gesture on every modern browser, so the music is only ever started
   * from a keypress or a tap, and a rejection is swallowed rather than thrown (adversarial pass). */
  function startMusic() {
    try { var p = music.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
  }

  /* Build a pure-black copy of the figure sheet. Adjacent rooms show that SOMEBODY is there
   * without saying who — which is the game's core scarcity, and is why the silhouettes had to be
   * distinguishable in the first place. Done with source-in compositing rather than ctx.filter,
   * which is not reliable everywhere. */
  function buildDark() {
    var s = img.figures;
    var o = document.createElement('canvas');
    o.width = s.width; o.height = s.height;
    var oc = o.getContext('2d');
    oc.drawImage(s, 0, 0);
    oc.globalCompositeOperation = 'source-in';
    oc.fillStyle = '#000';
    oc.fillRect(0, 0, o.width, o.height);
    return o;
  }

  /* ---------------------------------------------------------------- state */

  var SAVE_KEY = 'PROMPTBOX_SAVE_V1';
  var scene = 'title';           // title | play | loopend | won | book
  var S = null;                  // the model's loop state
  var save = { casebook: {}, loops: 0, wins: 0, seed: (Date.now() % 100000) | 0 };
  /* `accuseHits` is deliberately a SECOND list rather than more entries in `hits`. While the
   * accusation is open the play panel is still on screen and still holds an [A] ACCUSE row, so a
   * tap tested against `hits` would re-open the accusation the player is already inside. Keeping
   * the two lists apart lets the pointer handler consume every tap while accusing, which is what
   * makes the accusation cancellable by touch at all. */
  var ui = { boltPending: false, accusing: false, note: '', noteUntil: 0,
    hits: [], accuseHits: [], bookFrom: 'play' };
  var lastFactCount = 0;

  function loadSave() {
    try {
      var raw = window.localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      var o = JSON.parse(raw);
      if (o && typeof o === 'object' && o.casebook) {
        save.casebook = o.casebook; save.loops = o.loops || 0;
        save.wins = o.wins || 0; save.seed = o.seed != null ? o.seed : save.seed;
      }
    } catch (e) { /* a corrupt or blocked store must not stop the game starting */ }
  }
  function writeSave() {
    try { window.localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (e) {}
  }

  function newLoop() {
    S = window.PB.newLoop(save.seed, save.casebook);
    lastFactCount = window.PB.factCount(S);
    ui.boltPending = false; ui.accusing = false; ui.note = ''; ui.noteUntil = 0;
    scene = 'play';
    try { music.currentTime = 0; } catch (e) {}
    startMusic();
  }
  function endLoop() {
    save.casebook = S.casebook;
    save.loops++;
    if (S.outcome === 'won') { save.wins++; scene = 'won'; }
    else scene = 'loopend';
    writeSave();
    try { music.pause(); } catch (e) {}
    play(S.died ? 'fall' : 'unlock');
  }
  /* A solved case is spent. The wins tally survives; the knowledge does not, because the knowledge
   * WAS the solution and a new company has a new secret. */
  function nextCase() {
    save.seed = ((save.seed * 7919 + 104729) % 100000) | 0;
    save.casebook = {};
    writeSave();
    scene = 'title';
  }
  function hardReset() {
    save = { casebook: {}, loops: 0, wins: 0, seed: (Date.now() % 100000) | 0 };
    writeSave();
    scene = 'title';
  }

  function note(t) { ui.note = t; ui.noteUntil = performance.now() + 2600; }

  /* ---------------------------------------------------------------- geometry */

  function cellRect(room) {
    var gx = room % 3, gy = (room / 3) | 0;
    return { x: GRID_X + gx * (CELL_W + GAP), y: GRID_Y + gy * (CELL_H + GAP), w: CELL_W, h: CELL_H };
  }
  /* ⛔⛔ THE WHOLE GAME IS "YOU CANNOT BE EVERYWHERE", AND THE FIRST BUILD LET YOU SEE EVERYWHERE.
   * Out-of-earshot rooms were drawn at 0.88 darkness, which dims the MATERIAL but leaves a black
   * silhouette perfectly legible against it — so from the prompt box you could read off exactly
   * who was in the flies, the wardrobe and the green room at once, and the scarcity the deduction
   * depends on did not exist. Every numeric check passed while this was true; it was found by
   * opening the screenshot and looking at it.
   * The rule is now a named function so it can be asserted rather than re-eyeballed. */
  function peopleVisible(vis) { return vis <= 1; }

  /* 0 = you are here · 1 = next door, you can hear it · 2 = out of earshot */
  function visibility(room) {
    if (!S) return 2;
    if (room === S.player.room) return 0;
    return window.PB.neighbours(S.player.room).indexOf(room) >= 0 ? 1 : 2;
  }
  function agentSlotX(r, idx) { return r.x + 26 + idx * 34; }

  /* ---------------------------------------------------------------- drawing */

  function plateFill(r, plateName, dark) {
    var p = pattern[plateName];
    if (p) {
      ctx.save();
      ctx.beginPath(); ctx.rect(r.x, r.y, r.w, r.h); ctx.clip();
      ctx.fillStyle = p;
      ctx.translate(r.x, r.y);
      ctx.fillRect(0, 0, r.w, r.h);
      ctx.restore();
    } else {
      ctx.fillStyle = '#1a1a1a'; ctx.fillRect(r.x, r.y, r.w, r.h);
    }
    ctx.fillStyle = 'rgba(4,3,5,' + dark + ')';
    ctx.fillRect(r.x, r.y, r.w, r.h);
  }

  function drawFigure(name, frame, x, y, dark, alpha) {
    var idx = figMeta.order.indexOf(name);
    if (idx < 0 || !img.figures) return;
    var sheet = dark ? figuresDark : img.figures;
    if (!sheet) return;
    var sx = (idx * figMeta.frames + (frame ? 1 : 0)) * figMeta.frameW;
    if (alpha != null) { ctx.save(); ctx.globalAlpha = alpha; }
    ctx.drawImage(sheet, sx, 0, figMeta.frameW, figMeta.frameH,
      Math.round(x), Math.round(y), figMeta.frameW, figMeta.frameH);
    if (alpha != null) ctx.restore();
  }

  function drawRoom(room) {
    var r = cellRect(room);
    var vis = visibility(room);
    var doused = !!S.doused[room];
    // out of earshot is nearly black; next door is dim; your own room is lit unless you doused it
    var dark = vis === 0 ? (doused ? 0.74 : 0.16) : vis === 1 ? 0.70 : 0.88;
    plateFill(r, ROOM_PLATE[room], dark);

    // the gas in your own room, drawn by the renderer and never baked into a tile (§0-ART)
    if (vis === 0 && !doused) {
      var px = agentSlotX(r, 5) - 60, py = r.y + r.h - 30;
      var g = ctx.createRadialGradient(px, py, 6, px, py, 150);
      g.addColorStop(0, 'rgba(255,206,132,0.20)');
      g.addColorStop(1, 'rgba(255,206,132,0)');
      ctx.save();
      ctx.beginPath(); ctx.rect(r.x, r.y, r.w, r.h); ctx.clip();
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = g; ctx.fillRect(r.x, r.y, r.w, r.h);
      ctx.restore();
    }

    // the company
    var floorY = r.y + r.h - 40;
    var step = (Math.floor(S.t * 3) % 2) === 1;
    var shown = 0;
    for (var i = 0; peopleVisible(vis) && i < S.agents.length; i++) {
      var a = S.agents[i];
      if (a.room !== room) continue;
      var moving = a.path.length > 0;
      // vis 1: you can hear them, not see them — a black silhouette, no identity
      drawFigure(a.id, step && moving, agentSlotX(r, shown), floorY, vis !== 0,
        moving ? 0.55 : (vis === 0 ? 1 : 0.8));
      shown++;
    }
    if (room === S.player.room) {
      drawFigure('prompter', step && S.player.path.length > 0,
        agentSlotX(r, 5) - 70, floorY + 4, false, null);
    }

    // frame + label
    ctx.strokeStyle = vis === 0 ? GILT_DIM : 'rgba(120,100,64,0.30)';
    ctx.lineWidth = 1;
    ctx.strokeRect(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1);
    ctx.font = '11px Georgia, serif';
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    /* ⛔ THE LIT ROOM IS THE ONE PLACE THE LABEL HAS TO FIGHT THE ART. An independent review
     * measured the subtitle at 2.29-2.43:1 in EIGHT OF NINE rooms against a 3:1 floor for large
     * text, and it is on screen in the autoplaying store GIF as well as in play. Raising the ink
     * alone cannot fix it, because these plates run from near-black brick to a pale lit catwalk:
     * an ink light enough for one is invisible on the other. So the label gets a ground of its own
     * — a short vertical wash from the top of the cell, dark enough to be a known background —
     * and the ink is then chosen against THAT rather than against whichever plate is underneath
     * (§0-ART-E: pick ink by luminance against what it sits on). */
    if (vis === 0) {
      var plaque = ctx.createLinearGradient(0, r.y, 0, r.y + 40);
      plaque.addColorStop(0, 'rgba(10,7,9,0.82)');
      plaque.addColorStop(0.72, 'rgba(10,7,9,0.62)');
      plaque.addColorStop(1, 'rgba(10,7,9,0)');
      ctx.fillStyle = plaque;
      ctx.fillRect(r.x + 1, r.y + 1, r.w - 2, 40);
    }
    ctx.fillStyle = vis === 0 ? GILT : 'rgba(160,140,96,0.55)';
    ctx.fillText(window.PB.ROOMS[room].name, r.x + 8, r.y + 7);
    if (vis === 0) {
      ctx.fillStyle = 'rgba(232,219,190,0.95)';
      ctx.fillText(window.PB.ROOMS[room].sub, r.x + 8, r.y + 21);
    }
    if (doused) {
      ctx.fillStyle = 'rgba(150,150,170,0.55)';
      ctx.textAlign = 'right';
      ctx.fillText('dark', r.x + r.w - 8, r.y + 7);
      ctx.textAlign = 'left';
    }

    /* Doors. ⛔ ONLY FOUR DOORS IN THE HOUSE HAVE A LEAF TO BOLT, and nothing on screen said which
     * — so BOLT failed silently on the other eight and read as a broken verb. A door you can bolt
     * now shows a dim staple; a bolted one shows the bolt shot across it. */
    var ns = window.PB.neighbours(room);
    for (var k = 0; k < ns.length; k++) {
      var n = ns[k];
      var did = window.PB.doorId(room, n);
      var isBolted = !!S.bolted[did];
      var canBolt = window.PB.BOLTABLE.indexOf(did) >= 0;
      if (!isBolted && !(canBolt && vis === 0)) continue;
      ctx.fillStyle = isBolted ? '#b8433a' : 'rgba(201,169,97,0.42)';
      if (n === room + 1) ctx.fillRect(r.x + r.w - 5, r.y + r.h / 2 - 9, 4, 18);
      else if (n === room - 1) ctx.fillRect(r.x + 1, r.y + r.h / 2 - 9, 4, 18);
      else if (n === room + 3) ctx.fillRect(r.x + r.w / 2 - 9, r.y + r.h - 5, 18, 4);
      else if (n === room - 3) ctx.fillRect(r.x + r.w / 2 - 9, r.y + 1, 18, 4);
    }
  }

  function smallCaps(text, x, y, size, colour, spacing, align) {
    ctx.font = size + 'px Georgia, serif';
    ctx.fillStyle = colour;
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    var s = String(text).toUpperCase();
    var sp = spacing == null ? 2 : spacing;
    var total = 0, i;
    for (i = 0; i < s.length; i++) total += ctx.measureText(s[i]).width + sp;
    var cx = align === 'center' ? x - total / 2 : align === 'right' ? x - total : x;
    for (i = 0; i < s.length; i++) {
      ctx.fillText(s[i], cx, y);
      cx += ctx.measureText(s[i]).width + sp;
    }
    return total;
  }

  /** Word-wrap inside a width. Returns the y after the last line, so callers can stack blocks and
   *  nothing has to guess a line count (§3e-1: a canvas game needs a text-layout discipline). */
  function wrap(text, x, y, maxW, lineH, colour, size) {
    ctx.font = (size || 13) + 'px Georgia, serif';
    ctx.fillStyle = colour; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    var words = String(text).split(/\s+/), line = '', yy = y;
    for (var i = 0; i < words.length; i++) {
      var t = line ? line + ' ' + words[i] : words[i];
      if (ctx.measureText(t).width > maxW && line) { ctx.fillText(line, x, yy); yy += lineH; line = words[i]; }
      else line = t;
    }
    if (line) { ctx.fillText(line, x, yy); yy += lineH; }
    return yy;
  }

  /** The same wrap, measured and not drawn. §3e-5: census a variable-length list BEFORE choosing
   *  the box you are going to put it in — the loop-end screen used to pick a fixed floor and let
   *  the list run into it, which silently deleted the last three facts, and those three are the
   *  win condition. Nothing may call this and then lay out with different numbers: `factsHeight`
   *  below is the single place that turns a list into a height. */
  function wrapH(text, maxW, lineH, size) {
    ctx.font = (size || 13) + 'px Georgia, serif';
    var words = String(text).split(/\s+/), line = '', lines = 0;
    for (var i = 0; i < words.length; i++) {
      var t = line ? line + ' ' + words[i] : words[i];
      if (ctx.measureText(t).width > maxW && line) { lines++; line = words[i]; }
      else line = t;
    }
    if (line) lines++;
    return lines * lineH;
  }

  function drawHeader() {
    ctx.fillStyle = '#120c0e';
    ctx.fillRect(0, 0, W, HEADER_H);
    smallCaps('Promptbox', 14, 14, 20, GILT, 4);
    var bar = S ? S.bar : 1;
    var pct = S ? Math.min(1, S.t / window.PB.LOOP_SECONDS) : 0;
    // the overture as a bar line: three passes of the tune across one run
    var bx = 300, bw = 420, by = 24;
    ctx.fillStyle = 'rgba(120,100,64,0.28)';
    ctx.fillRect(bx, by, bw, 6);
    ctx.fillStyle = pct > 0.93 ? '#b8433a' : GILT;
    ctx.fillRect(bx, by, bw * pct, 6);
    for (var i = 1; i < 3; i++) {
      ctx.fillStyle = 'rgba(11,7,9,0.9)';
      ctx.fillRect(bx + bw * i / 3, by - 2, 1, 10);
    }
    smallCaps('bar ' + bar + ' of ' + window.PB.BARS, W - 14, 18, 13, GILT_DIM, 2, 'right');
  }

  function drawPanel() {
    var x = PANEL_X, y = GRID_Y;
    ctx.fillStyle = 'rgba(18,12,14,0.92)';
    ctx.fillRect(x, y, PANEL_W, 524);
    ctx.strokeStyle = 'rgba(120,100,64,0.35)';
    ctx.strokeRect(x + 0.5, y + 0.5, PANEL_W - 1, 523);

    var yy = y + 12;
    smallCaps('the casebook', x + 12, yy, 12, GILT, 2); yy += 22;
    var facts = window.PB.factsText(S);
    ctx.font = '11px Georgia, serif';
    ctx.fillStyle = PAPER;
    ctx.fillText(facts.length + ' of ' + S.catalogue.length + ' known', x + 12, yy); yy += 18;

    // the three that an accusation needs, called out because they are the win condition
    var need = [['op', 'opportunity'], ['motive', 'motive'], ['method', 'method']];
    for (var i = 0; i < need.length; i++) {
      var have = !!S.casebook[need[i][0]];
      ctx.fillStyle = have ? GILT : 'rgba(150,130,90,0.35)';
      ctx.fillText((have ? '■ ' : '□ ') + need[i][1], x + 12, yy);
      yy += 15;
    }
    yy += 8;

    smallCaps('what you can do', x + 12, yy, 12, GILT, 2); yy += 20;
    var verbs = window.PB.verbsFor(window.PB.factCount(S));
    var keys = { watch: '', follow: 'F', bolt: 'B', douse: 'D', cue: 'C' };
    ui.hits = [];
    /* ONE door for every row in this panel. PALM and ACCUSE used to be hand-drawn underneath the
     * loop with a fillText and no help line, so PALM — which is one of the five things a player can
     * actually DO — was the only verb the panel named without ever saying what it does. It showed a
     * key and no reason in four of the six store plates. A row that cannot exist without its help
     * string is the fix; adding the missing sentence alone would leave the next verb free to repeat
     * it (wing §3h rule 1: a guard belongs where it is ENFORCED, not where the thing is declared). */
    ui.verbRows = [];
    function verbRow(keyChar, name, help, id, gold) {
      var rowY = yy;
      /* The panel reports what it drew, from the locals that drew it. A test comparing this record
       * to the strings actually on the canvas can tell the difference between "every row has help"
       * and "every row that went through the helper has help" — which is the whole defect: PALM
       * used to bypass this function entirely. */
      ui.verbRows.push({ key: keyChar || '', name: name, help: String(help || ''), y: rowY });
      ctx.font = '12px Georgia, serif';
      ctx.fillStyle = gold || GILT;
      /* The keyless row (WATCH) used to be indented with five literal spaces, which is not the
       * width of "[F] " in this face — measured 4.61px out of true, so the one row without a key
       * did not line up with the five that have one. Measure the bracket, do not count spaces
       * (§3e-1: derive layout from measureText at draw time). */
      if (keyChar) ctx.fillText('[' + keyChar + '] ' + name, x + 12, rowY);
      else ctx.fillText(name, x + 12 + ctx.measureText('[F] ').width, rowY);
      ctx.fillStyle = 'rgba(190,170,120,0.55)';
      yy = wrap(help, x + 12, rowY + 15, PANEL_W - 24, 13, 'rgba(190,170,120,0.55)', 11) + 6;
      if (keyChar) ui.hits.push({ x: x + 8, y: rowY - 3, w: PANEL_W - 16, h: yy - rowY, verb: id });
    }
    for (var v = 0; v < verbs.length; v++) {
      var vb = verbs[v];
      verbRow(keys[vb.id], vb.name, vb.help, vb.id);
    }
    if (window.PB.can(S, 'douse')) {
      verbRow('P', 'PALM', 'Pocket the knife in the prop store. Whoever comes for it finds nothing.', 'palm');
    }
    if (window.PB.canAccuse(S)) {
      verbRow('A', 'ACCUSE', 'Name who cut the rope. You get one, and it ends the night.', 'accuse', '#d8b45c');
    }

    // the last few things that happened, so a re-route always states its reason
    yy = Math.max(yy + 6, y + 372);
    smallCaps('the house', x + 12, yy, 12, GILT, 2); yy += 18;
    /* ⛔ THE BREAK USED TO RUN AFTER THE DRAW (`yy = wrap(...); if (yy > y + 500) break;`), so the
     * line that crossed the floor was always drawn first and only then noticed. It collided with
     * the footer two pixels below. Nothing caught it for as long as the verb panel was short; the
     * moment PALM and ACCUSE gained their help lines the panel grew and the log landed on top of
     * "[TAB] casebook   [R] start over". MEASURE FIRST, THEN DRAW (§3e-1) — and derive the floor
     * from where the footer actually goes, so the two cannot drift apart. */
    var FOOTER_Y = y + 502;
    var log = S.log.slice(-5);
    for (var l = 0; l < log.length; l++) {
      if (yy + wrapH(log[l], PANEL_W - 24, 13, 11) > FOOTER_Y - 6) break;
      yy = wrap(log[l], x + 12, yy, PANEL_W - 24, 13, 'rgba(180,160,116,0.62)', 11) + 4;
    }

    smallCaps('[TAB] casebook   [R] start over', x + 12, FOOTER_Y, 10, 'rgba(150,130,90,0.5)', 1);
  }

  /** ⛔ DERIVED FROM THE MODEL, NEVER TYPED HERE. `PB.SUSPECTS` is the game's own ordered list and
   *  the capture harness already indexes into it (`PB.SUSPECTS.indexOf(S.culprit) + 1` is the key
   *  it presses). Writing the three names out again in the shell would be a second copy of one
   *  fact, and a second copy stops agreeing with the first the day the order changes — §3h rule 4,
   *  and §3c-24 rule 6. Key `n+1` here is the SAME positional rule the harness uses.
   *  Names come from AGENTS so the panel cannot show a spelling the rest of the game does not. */
  function suspects() {
    var ids = (window.PB && window.PB.SUSPECTS) || [];
    return ids.map(function (id, i) {
      var a = (window.PB.AGENTS || []).filter(function (x) { return x.id === id; })[0];
      return { key: String(i + 1), id: id, name: a ? a.name : id.toUpperCase() };
    });
  }

  /** The accusation, as something a finger can actually do.
   *
   * ⛔ It used to be one line of text saying "[1] VELLO [2] MARCH [3] DUBOIS [ESC] not yet", and
   * every one of those four inputs was a KEY. The pointer handler then returned early while
   * accusing, so on a touch device the player could open the accusation and neither make one nor
   * back out of it — a soft lock at the exact moment the game is won, on a listing whose Readme
   * says touch is supported. Now each name is a row with a hit rectangle and there is a visible
   * way out. The keys still work and are still printed: this adds a route, it does not replace one.
   */
  function drawAccuse() {
    /* Height from the COUNT, not from the three that happen to exist today: a box sized for a
     * fixed number over a list the model owns is §3e-5's silent truncation waiting to happen. */
    var rowH = 38, nSus = suspects().length;
    var bw = 430, bh = 54 + nSus * rowH + 68;
    var bx = GRID_X + 361 - bw / 2, by = GRID_Y + 262 - bh / 2;
    ctx.fillStyle = 'rgba(11,7,9,0.95)';
    ctx.fillRect(bx, by, bw, bh);
    ctx.strokeStyle = GILT; ctx.lineWidth = 2;
    ctx.strokeRect(bx + 1, by + 1, bw - 2, bh - 2);
    smallCaps('name them', bx + bw / 2, by + 18, 18, GILT, 5, 'center');

    ui.accuseHits = [];
    var rowY = by + 54;
    var sus = suspects();
    for (var i = 0; i < sus.length; i++) {
      var s = sus[i];
      ctx.fillStyle = 'rgba(201,169,97,0.07)';
      ctx.fillRect(bx + 16, rowY, bw - 32, rowH - 6);
      ctx.strokeStyle = GILT_DIM; ctx.lineWidth = 1;
      ctx.strokeRect(bx + 16.5, rowY + 0.5, bw - 33, rowH - 7);
      smallCaps('[' + s.key + ']', bx + 30, rowY + 10, 13, 'rgba(190,170,120,0.7)', 2);
      smallCaps(s.name, bx + 76, rowY + 9, 16, GILT, 4);
      ui.accuseHits.push({ x: bx + 16, y: rowY, w: bw - 32, h: rowH - 6, pick: s.id });
      rowY += rowH;
    }
    var cy = by + bh - 34;
    ctx.strokeStyle = 'rgba(150,130,90,0.5)'; ctx.lineWidth = 1;
    ctx.strokeRect(bx + 16.5, cy + 0.5, bw - 33, 25);
    smallCaps('[ESC]  not yet', bx + bw / 2, cy + 6, 12, 'rgba(190,170,120,0.75)', 2, 'center');
    ui.accuseHits.push({ x: bx + 16, y: cy, w: bw - 32, h: 26, pick: null });
  }

  function drawPrompt() {
    if (ui.accusing) { drawAccuse(); return; }
    ui.accuseHits = [];
    if (!ui.boltPending && !(ui.note && performance.now() < ui.noteUntil)) return;
    var txt = ui.boltPending ? 'BOLT WHICH DOOR?  press an arrow or tap a neighbouring room'
      : ui.note;
    ctx.fillStyle = 'rgba(11,7,9,0.92)';
    ctx.fillRect(GRID_X, GRID_Y + 524 - 34, 722, 30);
    ctx.strokeStyle = GILT_DIM;
    ctx.strokeRect(GRID_X + 0.5, GRID_Y + 524 - 33.5, 721, 29);
    smallCaps(txt, GRID_X + 361, GRID_Y + 524 - 25, 13, GILT, 2, 'center');
  }

  /* ---------------------------------------------------------------- screens */

  function curtainBackdrop() {
    var p = pattern.velvet;
    if (p) {
      ctx.save(); ctx.fillStyle = p; ctx.fillRect(0, 0, W, H); ctx.restore();
    } else { ctx.fillStyle = '#2b0c11'; ctx.fillRect(0, 0, W, H); }
    var g = ctx.createRadialGradient(W / 2, H / 2, 40, W / 2, H / 2, 620);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.82)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  }

  /** A gilt proscenium, drawn rather than typed onto a screenshot. §3e: the menu screens are where
   *  this wing loses Gate 1, and the fix is free. */
  function prosceniumArch() {
    ctx.strokeStyle = GILT; ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(150, 470); ctx.lineTo(150, 190);
    ctx.quadraticCurveTo(480, 78, 810, 190);
    ctx.lineTo(810, 470);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(201,169,97,0.45)'; ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(162, 470); ctx.lineTo(162, 198);
    ctx.quadraticCurveTo(480, 92, 798, 198);
    ctx.lineTo(798, 470);
    ctx.stroke();
    // the prompter's hood at the lip of the stage — the box you spend the game in
    ctx.fillStyle = '#120c0e';
    ctx.beginPath();
    ctx.moveTo(430, 470); ctx.quadraticCurveTo(480, 424, 530, 470);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = GILT_DIM; ctx.lineWidth = 2; ctx.stroke();
  }

  function drawTitle() {
    curtainBackdrop();
    prosceniumArch();
    smallCaps('Promptbox', W / 2, 214, 62, GILT, 12, 'center');
    ctx.textAlign = 'center';
    ctx.font = 'italic 16px Georgia, serif';
    ctx.fillStyle = 'rgba(205,187,150,0.85)';
    ctx.fillText('The overture runs three minutes.', W / 2, 300);
    ctx.fillText('At the end of it she is dead, and then it runs again.', W / 2, 324);
    ctx.font = '13px Georgia, serif';
    ctx.fillStyle = 'rgba(190,170,120,0.7)';
    ctx.fillText('You are the prompter. Nothing survives the reset but what you work out.', W / 2, 366);
    ctx.textAlign = 'left';
    var lbl = save.loops > 0
      /* The third place this copy lives. Two were corrected on the ending screens and this one was
       * found by opening the title PNG afterwards — a line retired in one place has to be grepped
       * for, not just deleted where it was noticed. A tap starts the game here exactly as a key
       * does (see the 'title' branch of the pointer handler), so the words say both. */
      ? 'press any key or tap to go back in  ·  ' + save.loops + ' loops behind you'
      : 'press any key or tap to take your place';
    smallCaps(lbl, W / 2, 500, 13, GILT, 3, 'center');
    if (save.loops > 0) smallCaps('[N] forget everything and start again', W / 2, 528, 10, 'rgba(150,130,90,0.55)', 1, 'center');
    if (failed.length) smallCaps(failed.length + ' asset(s) failed to load', W / 2, 566, 10, '#b8433a', 1, 'center');
  }

  /** Footlights along the lip of the stage: the win screen's own composition. */
  /* ⛔ THE FIRST VERSION PUT THE LAMPS AT H-54, WHICH IS WHERE "PRESS ANY KEY" LIVES, and the glow
   * swallowed it — a legible string rendered illegible by a UI element drawn over it (§3e-3, the
   * layout gate's blind spot). The lamps moved to the very lip and lost half their brightness;
   * the prompt moved above them. Caught by opening the shot, not by any check. */
  function footlights() {
    var y = H - 16;
    var g = ctx.createLinearGradient(0, y - 120, 0, H);
    g.addColorStop(0, 'rgba(255,206,132,0)');
    g.addColorStop(1, 'rgba(255,196,110,0.17)');
    ctx.fillStyle = g; ctx.fillRect(0, y - 120, W, 136);
    for (var i = 0; i < 17; i++) {
      var x = 40 + i * 55;
      var lg = ctx.createRadialGradient(x, y, 2, x, y, 34);
      lg.addColorStop(0, 'rgba(255,232,170,0.52)');
      lg.addColorStop(1, 'rgba(255,200,110,0)');
      ctx.fillStyle = lg; ctx.fillRect(x - 34, y - 34, 68, 68);
      ctx.fillStyle = '#ffe9a8';
      ctx.beginPath(); ctx.arc(x, y, 3, 0, Math.PI * 2); ctx.fill();
    }
  }

  /** The curtain coming down, and the thing that brought it: the loss screen's composition.
   *  ⛔ THE TITLE, THE WIN AND THE LOSS WERE ALL "VELVET PLUS CENTRED TEXT" AND `dedupe.js` READ
   *  ALL THREE AS ONE PICTURE (d=2 and d=3). §3c-6: two screens with one layout ARE one picture,
   *  and the fix is design, not a crop. */
  function fallenCurtain() {
    ctx.fillStyle = 'rgba(6,3,4,0.90)';
    ctx.fillRect(0, 0, W, 250);
    var g = ctx.createLinearGradient(0, 250, 0, 340);
    g.addColorStop(0, 'rgba(6,3,4,0.90)'); g.addColorStop(1, 'rgba(6,3,4,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 250, W, 90);
    /* ⛔ THE BAG WAS DRAWN STILL HANGING, which is the wrong moment AND left this screen sharing a
     * silhouette with the win screen — `dedupe.js` read them as one picture at d=8, dead on the
     * threshold. It has FALLEN: the rope is slack and the weight is on the boards, bottom right.
     * That is both the truer image and the compositional difference the hash needed. Raising the
     * dedupe threshold to pass was never an option (§4.2b). */
    ctx.strokeStyle = 'rgba(150,128,84,0.45)'; ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(W - 210, 0);
    ctx.bezierCurveTo(W - 205, 210, W - 320, 300, W - 168, H - 92);
    ctx.stroke();
    var bx = W - 158, by = H - 62;
    ctx.fillStyle = '#141210';
    ctx.beginPath(); ctx.ellipse(bx, by, 46, 40, -0.12, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(120,100,64,0.30)'; ctx.lineWidth = 1; ctx.stroke();
    // the seam across the sack, so it reads as canvas and not a hole in the screen
    ctx.strokeStyle = 'rgba(150,128,84,0.18)';
    ctx.beginPath(); ctx.moveTo(bx - 38, by - 10); ctx.quadraticCurveTo(bx, by - 2, bx + 38, by - 14); ctx.stroke();
    // dust where it landed
    ctx.fillStyle = 'rgba(190,170,140,0.05)';
    ctx.beginPath(); ctx.ellipse(bx, by + 34, 120, 16, 0, 0, Math.PI * 2); ctx.fill();
  }

  function drawEnd(won) {
    curtainBackdrop();
    if (won) footlights(); else fallenCurtain();
    ctx.textAlign = 'center';
    smallCaps(won ? 'she sings' : (S.died ? 'curtain' : 'she sings'), W / 2, 96, 44, won ? GILT : '#b8433a', 8, 'center');
    ctx.textAlign = 'left';
    var yy = wrap(S.ending, W / 2 - 300, 176, 600, 24, PAPER, 16);

    var gained = S.newFacts.length;
    yy += 22;
    ctx.textAlign = 'center';
    smallCaps(gained ? gained + ' new thing' + (gained === 1 ? '' : 's') + ' in the casebook'
      : 'nothing new tonight', W / 2, yy, 14, GILT, 3, 'center');
    ctx.textAlign = 'left';
    yy += 30;

    /* ⛔ THE THREE FACTS THE PLAYER NEEDS TO WIN WERE THE THREE THIS SCREEN CUT OFF.
     * The catalogue is twelve slots and `op`, `motive` and `method` are slots 10, 11 and 12 —
     * exactly the set `canAccuse` requires. The old loop stopped at a hard-typed `yy < 476`, which
     * fits about nine one-line facts, so a player with a full casebook was shown everything except
     * the part that mattered, and the two store plates disagreed with each other about it.
     * Eight was a decision about the LAYOUT; twelve is a fact about the GAME (§3e-5).
     * So: measure the list, then choose the column count from the measurement. */
    var facts = window.PB.factsText(S);
    var FLOOR = won ? 496 : 540;          // where 'press any key' sits on each ending
    var avail = FLOOR - yy;
    var LINE = 17, SIZE = 12, GAP = 3;

    function factsHeight(maxW, lineH, size, gap) {
      var h = 0;
      for (var i = 0; i < facts.length; i++) h += wrapH(facts[i].text, maxW, lineH, size) + gap;
      return h;
    }

    var oneCol = factsHeight(600, LINE, SIZE, GAP);
    var drawn = 0;
    if (oneCol <= avail) {
      for (var i = 0; i < facts.length; i++) {
        /* ⛔ COUNT WHAT WAS DRAWN, NOT WHAT WAS ITERATED. `drawn++` used to run unconditionally, so
         * `drawn` always equalled facts.length and the "N more" fallback below could never fire —
         * a comment describing a safety net over a variable that could not trip it. Stop at the
         * floor and let the counter tell the truth. */
        if (yy + wrapH(facts[i].text, 600, LINE, SIZE) > FLOOR) break;
        var fresh = S.newFacts.indexOf(facts[i].id) >= 0;
        yy = wrap((fresh ? '› ' : '   ') + facts[i].text, W / 2 - 300, yy, 600, LINE,
          fresh ? GILT : FACT_DIM, SIZE) + GAP;
        drawn++;
      }
    } else {
      /* Two columns, smaller face. The split is by MEASURED HEIGHT rather than by count, so one
       * long motive cannot push a column past the floor while the other sits half empty. */
      var CW = 292, CL = 14, CS = 11;
      var total = factsHeight(CW, CL, CS, GAP), half = total / 2, run = 0, split = facts.length;
      for (var k = 0; k < facts.length; k++) {
        run += wrapH(facts[k].text, CW, CL, CS) + GAP;
        if (run >= half) { split = k + 1; break; }
      }
      var cols = [[W / 2 - 306, 0, split], [W / 2 + 14, split, facts.length]];
      for (var c = 0; c < cols.length; c++) {
        var cy = yy;
        for (var j = cols[c][1]; j < cols[c][2]; j++) {
          // same floor in the two-column branch, which had none at all
          if (cy + wrapH(facts[j].text, CW, CL, CS) > FLOOR) break;
          var fr = S.newFacts.indexOf(facts[j].id) >= 0;
          cy = wrap((fr ? '› ' : '   ') + facts[j].text, cols[c][0], cy, CW, CL,
            fr ? GILT : FACT_DIM, CS) + GAP;
          drawn++;
        }
      }
    }

    ctx.textAlign = 'center';
    /* The honest fallback. If a future catalogue outgrows two columns this says so out loud and
     * names the way to the rest, rather than silently dropping the tail the way the old code did. */
    if (drawn < facts.length) {
      smallCaps((facts.length - drawn) + ' more  ·  [TAB] the casebook',
        W / 2, FLOOR - 16, 11, 'rgba(190,170,120,0.7)', 2, 'center');
    }
    /* above the footlights on a win, where the loss screen has nothing to clash with.
     * The copy names the TAP as well as the key: this game is playable end to end on touch, and a
     * screen that only says "press any key" tells a phone player the opposite of the truth. */
    var GO_SIZE = 13, BOOK_SIZE = 10;
    var goOnY = won ? 508 : 552;
    var bookY = won ? 528 : 572;
    smallCaps(won ? 'press any key or tap for the next company' : 'press any key or tap to go round again',
      W / 2, goOnY, GO_SIZE, GILT, 3, 'center');
    smallCaps('[TAB] or tap here for the casebook', W / 2, bookY, BOOK_SIZE, 'rgba(150,130,90,0.55)', 1, 'center');
    /* ⛔ AND THE STRIP HAS TO BE WHERE THE LINE IS. The tap handler used a fixed `y >= H - 88`,
     * i.e. y >= 512 — which is fine on the win screen (the go-on prompt sits at 508, just above it)
     * and WRONG on the loss screen, where that prompt is drawn at 552 and therefore INSIDE the
     * casebook strip. A touch player who tapped the words "go round again" got the casebook. The
     * strip is now derived from the y the casebook line was actually drawn at, so the two can never
     * drift apart again (wing §3e-1: derive layout at draw time, never hard-code a measured y). */
    /* ⛔ AND THE STRIP MUST CLEAR THE PROMPT'S GLYPHS, NOT JUST ITS ANCHOR. `bookY - 14` still cut
     * through the go-on line: `smallCaps` draws with textBaseline "top", so the loss prompt occupies
     * y 552..565 while the strip began at 558 — 7 of its 13 px, 54%, inside the casebook region, so
     * tapping the lower half of the words you are told to tap still did the other thing. An
     * independent review measured that. Start the strip BELOW the prompt's last pixel, and keep it
     * above the casebook line's first, so the two controls cannot overlap at any font size. */
    ui.endBookTop = Math.max(goOnY + GO_SIZE + 3, bookY - 6);
    ctx.textAlign = 'left';
  }

  function drawBook() {
    ctx.fillStyle = 'rgba(11,7,9,0.95)';
    ctx.fillRect(0, 0, W, H);
    smallCaps('the casebook', W / 2, 44, 30, GILT, 6, 'center');
    var facts = window.PB.factsText(S);
    var yy = 110;
    if (!facts.length) {
      ctx.textAlign = 'center'; ctx.font = 'italic 15px Georgia, serif';
      ctx.fillStyle = 'rgba(190,170,120,0.6)';
      ctx.fillText('Empty. You have not been anywhere yet.', W / 2, yy);
      ctx.textAlign = 'left';
    }
    /* ⛔ THIS FUNCTION STILL HELD THE BUG ITS TWIN WAS FIXED FOR. drawEnd() stopped clipping the
     * casebook at a hard-typed y; drawBook() kept `yy < 520` and would silently drop the tail the
     * same way, just further down the list. A defect fixed in one of two functions that draw the
     * same thing is a defect with a delay on it — the catalogue is twelve today and the rule that
     * cut it off is what made the game unwinnable the first time.
     * Same treatment: measure before drawing, stop at the floor, and SAY SO instead of going quiet. */
    var BOOK_FLOOR = 528;
    var shown = 0;
    for (var i = 0; i < facts.length; i++) {
      if (yy + wrapH(facts[i].text, 600, 19, 14) > BOOK_FLOOR) break;
      var kind = facts[i].kind;
      ctx.font = '11px Georgia, serif';
      ctx.fillStyle = kind === 'context' ? 'rgba(150,130,90,0.55)' : '#d8b45c';
      ctx.fillText(kind.toUpperCase(), 120, yy);
      yy = wrap(facts[i].text, 240, yy - 2, 600, 19, PAPER, 14) + 10;
      shown++;
    }
    if (shown < facts.length) {
      smallCaps((facts.length - shown) + ' more not shown', W / 2, BOOK_FLOOR + 6, 11,
        'rgba(190,170,120,0.7)', 2, 'center');
    }
    smallCaps('[TAB] back', W / 2, 556, 12, GILT_DIM, 2, 'center');
  }

  /* ---------------------------------------------------------------- input */

  function tryMove(dir) {
    var r = S.player.room, gx = r % 3, gy = (r / 3) | 0, t = -1;
    if (dir === 'l' && gx > 0) t = r - 1;
    if (dir === 'r' && gx < 2) t = r + 1;
    if (dir === 'u' && gy > 0) t = r - 3;
    if (dir === 'd' && gy < 2) t = r + 3;
    if (t < 0) return;
    if (ui.boltPending) {
      ui.boltPending = false;
      if (window.PB.bolt(S, t)) play('bolt');
      else note('That door has no leaf to bolt, or is bolted already.');
      return;
    }
    if (S.bolted[window.PB.doorId(r, t)]) { note('You bolted that one yourself.'); return; }
    if (window.PB.moveTo(S, t)) play('step');
  }

  function onKey(e) {
    var k = e.key;
    if (scene === 'title') {
      if (k === 'n' || k === 'N') { hardReset(); return; }
      startMusic(); newLoop(); e.preventDefault(); return;
    }
    /* TAB reaches the casebook from the ending screens too. The ending screen summarises the
     * loop and the casebook is the complete record, so there must be a way to the complete record
     * that does not cost the player their place — and it is the route the overflow line offers. */
    if (scene === 'loopend' || scene === 'won') {
      if (k === 'Tab') { ui.bookFrom = scene; scene = 'book'; e.preventDefault(); return; }
      if (scene === 'loopend') { newLoop(); e.preventDefault(); return; }
      /* ⛔ A WIN MUST DEAL A NEW CASE. Otherwise the next loop runs the same seed with a full
       * casebook, i.e. the player wins instantly for ever and the game is over without saying so. */
      nextCase(); e.preventDefault(); return;
    }
    if (scene === 'book') { if (k === 'Tab' || k === 'Escape') { scene = ui.bookFrom; } e.preventDefault(); return; }

    if (k === 'Tab') { ui.bookFrom = 'play'; scene = 'book'; e.preventDefault(); return; }
    if (k === 'Escape') { ui.boltPending = false; ui.accusing = false; return; }

    if (ui.accusing) {
      var pick = null;
      var sus = suspects();
      for (var si = 0; si < sus.length; si++) if (sus[si].key === k) pick = sus[si].id;
      if (pick) resolveAccusation(pick);
      e.preventDefault(); return;
    }

    /* ⛔ NO WASD. The first draft bound A and D to move-left and move-right AND to ACCUSE and
     * DOUSE, so the panel advertised "[A] ACCUSE" while pressing A walked out of the room. Arrows
     * move; letters are verbs; nothing means two things. */
    if (k === 'ArrowLeft')  { tryMove('l'); e.preventDefault(); return; }
    if (k === 'ArrowRight') { tryMove('r'); e.preventDefault(); return; }
    if (k === 'ArrowUp')    { tryMove('u'); e.preventDefault(); return; }
    if (k === 'ArrowDown')  { tryMove('d'); e.preventDefault(); return; }

    var low = k.toLowerCase();
    if (low === 'f') { doVerb('follow'); return; }
    if (low === 'b') { doVerb('bolt'); return; }
    if (low === 'd') { doVerb('douse'); return; }
    if (low === 'p') { doVerb('palm'); return; }
    if (low === 'c') { doVerb('cue'); return; }
    if (low === 'a' || k === 'Enter') { doVerb('accuse'); return; }
    if (low === 'r') { abandonLoop(); return; }
  }

  /* Leaving early is a real choice: once you know this loop is spoiled, sitting through the rest
   * of the overture teaches you nothing. It keeps the casebook, like every other ending. */
  function abandonLoop() {
    if (!S || S.over) return;
    window.PB.finish(S);
    S.outcome = 'abandoned';
    S.ending = 'You leave the box before the end. The overture finishes without you, and whatever '
      + 'was going to happen happens anyway.';
    endLoop();
  }

  /** ⛔ ONE DOOR FOR THE ACCUSATION, because there are now two ways in — a key and a tap — and
   *  §3f-4 is this wing's most expensive lesson: two paths into one screen, and only one of them
   *  did the work. The key handler and the pointer handler both call THIS; neither settles
   *  anything itself. `pick` of null is the player backing out. */
  function resolveAccusation(pick) {
    if (!ui.accusing) return;
    ui.accusing = false;
    if (!pick) return;
    if (window.PB.accuse(S, pick)) {
      play('unlock');
      note('You have named ' + pick.toUpperCase() + '. Now keep her off the mark.');
    } else {
      note('You cannot name anyone without opportunity, motive and method.');
    }
  }

  function doVerb(v) {
    if (scene !== 'play' || !S || S.over) return;
    if (v === 'follow') {
      var here = window.PB.agentsIn(S, S.player.room);
      if (!here.length) { note('There is nobody here to follow.'); return; }
      if (window.PB.follow(S, here[0].id)) play('step');
      else note('You cannot do that yet.');
      return;
    }
    if (v === 'bolt') {
      if (!window.PB.can(S, 'bolt')) { note('You have not earned that yet.'); return; }
      ui.boltPending = true; return;
    }
    if (v === 'douse') {
      if (window.PB.douse(S)) play('douse');
      else note(window.PB.can(S, 'douse') ? 'That lamp is already out.' : 'You have not earned that yet.');
      return;
    }
    if (v === 'palm') {
      if (window.PB.palm(S)) { play('fact'); note('The knife is in your coat.'); }
      else note('There is nothing here to take.');
      return;
    }
    if (v === 'cue') {
      if (!window.PB.can(S, 'cue')) { note('You have not earned that yet.'); return; }
      if (S.player.room !== 7) { note('A whisper only carries from the box.'); return; }
      if (S.cued) { note('You have already given her the line.'); return; }
      if (window.PB.cue(S)) play('cue');
      else note('Too early, or too late. The line has to land on the beat.');
      return;
    }
    if (v === 'accuse') {
      if (!window.PB.canAccuse(S)) { note('Opportunity, motive and method. You are missing one.'); return; }
      ui.accusing = true;
    }
  }

  function canvasPoint(ev) {
    var r = cv.getBoundingClientRect();
    var t = (ev.touches && ev.touches[0]) || ev;
    return { x: (t.clientX - r.left) * (W / r.width), y: (t.clientY - r.top) * (H / r.height) };
  }
  function onPoint(ev) {
    /* On itch and Game Jolt this runs in an IFRAME, and keydown is bound to `window`, so keys
     * only arrive while this frame holds focus. Clicking the surrounding store page hands focus
     * to the parent, and the preventDefault() below suppresses the default action that would
     * hand it back — so the keyboard stays dead until the player reloads, which is what a player
     * reported. window.focus() alone is a no-op on WebKit/iOS for a window the script did not
     * open, so the canvas is focused too — it carries tabindex="-1", focusable by script but
     * never a tab stop, and preventScroll keeps THAT call from jumping the page to the embed. */
    try { window.focus(); } catch (fx) { /* ok */ }
    try { cv.focus({ preventScroll: true }); } catch (cf) { /* ok */ }
    ev.preventDefault();
    var p = canvasPoint(ev), i;

    /* ⛔ THE ACCUSATION IS TESTED FIRST, AND IT SWALLOWS THE TAP EITHER WAY. It has to be first
     * because the play panel behind it still carries an [A] ACCUSE row, so falling through to
     * `ui.hits` would re-open the accusation the player is trying to answer or leave. It has to
     * swallow because the rest of this handler moves the player around the house, and a stray tap
     * outside the panel must not walk out of a room mid-accusation. */
    if (ui.accusing) {
      for (i = 0; i < ui.accuseHits.length; i++) {
        var a = ui.accuseHits[i];
        if (p.x >= a.x && p.x <= a.x + a.w && p.y >= a.y && p.y <= a.y + a.h) {
          resolveAccusation(a.pick); return;
        }
      }
      return;
    }

    if (scene === 'title') { startMusic(); newLoop(); return; }
    if (scene === 'loopend' || scene === 'won') {
      /* Touch parity with the [TAB] line printed on these screens: the casebook line's own strip
       * opens the casebook, anywhere else goes on. Without this a touch player can read "[TAB] the
       * casebook" on a screen they have no keyboard for.
       * The strip comes from where drawEnd() actually put that line (ui.endBookTop), not from a
       * fixed H - 88: that constant put the LOSS screen's "go round again" prompt (y=552) inside
       * the casebook strip, so tapping the words said one thing and did another. */
      var bookTop = (typeof ui.endBookTop === 'number') ? ui.endBookTop : H - 88;
      if (p.y >= bookTop) { ui.bookFrom = scene; scene = 'book'; return; }
      if (scene === 'loopend') { newLoop(); return; }
      nextCase(); return;
    }
    if (scene === 'book') { scene = ui.bookFrom; return; }
    for (i = 0; i < ui.hits.length; i++) {
      var h = ui.hits[i];
      if (p.x >= h.x && p.x <= h.x + h.w && p.y >= h.y && p.y <= h.y + h.h) { doVerb(h.verb); return; }
    }
    for (var room = 0; room < 9; room++) {
      var r = cellRect(room);
      if (p.x < r.x || p.x > r.x + r.w || p.y < r.y || p.y > r.y + r.h) continue;
      if (room === S.player.room) { doVerb('douse'); return; }
      var d = room - S.player.room;
      if (d === -1) tryMove('l'); else if (d === 1) tryMove('r');
      else if (d === -3) tryMove('u'); else if (d === 3) tryMove('d');
      else note('You cannot get there from here in one move.');
      return;
    }
  }

  window.addEventListener('keydown', onKey, { passive: false });
  cv.addEventListener('mousedown', onPoint, { passive: false });
  cv.addEventListener('touchstart', onPoint, { passive: false });

  /* ---------------------------------------------------------------- loop */

  var acc = 0, last = 0;
  function frame(now) {
    requestAnimationFrame(frame);
    if (!last) last = now;
    var dt = Math.min(0.25, (now - last) / 1000);   // a tab-away must not fast-forward the loop
    last = now;

    if (scene === 'play' && S && !S.over) {
      acc += dt;
      while (acc >= window.PB.DT) { window.PB.stepOnce(S); acc -= window.PB.DT; }
      var fc = window.PB.factCount(S);
      if (fc > lastFactCount) {
        play('fact');
        lastFactCount = fc;
        /* ⛔ PERSIST ON EVERY FACT, NOT ONLY AT THE END OF A LOOP. Ledger B4 says knowledge is the
         * save; a player who closes the tab mid-loop was losing everything they had just learned,
         * which is the one thing this game promises never to happen. */
        save.casebook = S.casebook;
        writeSave();
      }
    }
    /* ⛔ THIS CHECK LIVED INSIDE THE `!S.over` GUARD, so a loop that ended anywhere other than
     * inside the while() above never reached its ending screen at all — the game just sat on a
     * frozen board. It only showed up because the harness ends loops from outside the frame.
     * The transition is a property of the STATE, not of who advanced it. */
    if (scene === 'play' && S && S.over) endLoop();

    ctx.fillStyle = INK; ctx.fillRect(0, 0, W, H);
    if (scene === 'title') { drawTitle(); return; }
    if (scene === 'book') { drawBook(); return; }
    if (scene === 'loopend' || scene === 'won') { drawEnd(scene === 'won'); return; }
    drawHeader();
    for (var r = 0; r < 9; r++) drawRoom(r);
    drawPanel();
    drawPrompt();
  }

  /* ---------------------------------------------------------------- boot */

  function boot() {
    if (loaded < toLoad) { setTimeout(boot, 40); return; }
    PLATE_NAMES.forEach(function (n) {
      if (img[n]) pattern[n] = ctx.createPattern(img[n], 'repeat');
    });
    if (img.figures) figuresDark = buildDark();
    loadSave();
    document.getElementById('boot').style.display = 'none';
    cv.style.display = 'block';
    requestAnimationFrame(frame);
  }
  boot();

  // exposed ONLY so the headless capture/test harness can drive the shell without a human
  window.PBGAME = {
    get scene() { return scene; },
    get S() { return S; },
    get save() { return save; },
    setScene: function (x) { scene = x; },
    startLoop: newLoop,
    key: function (k) { onKey({ key: k, preventDefault: function () {} }); },
    verb: doVerb,
    /* Hit rectangles, exposed READ-ONLY so the touch test can find a control and then dispatch a
     * REAL pointer event at it. ⛔ The test must not call `verb` or `resolveAccusation` to prove
     * touch works — that would exercise everything except the handler that was broken (§3c-16:
     * one driver, and it is the game's own input door). */
    get accusing() { return ui.accusing; },
    /* Where drawEnd() actually put the casebook line on the ending screens. Exposed so the touch
     * test can assert that the strip the tap handler uses and the line the player is told to tap
     * are the same place — they were not, and the loss screen's own prompt sat inside the strip. */
    get endBookTop() { return ui.endBookTop; },
    verbRowsDrawn: function () { return (ui.verbRows || []).slice(); },
    hits: function () { return ui.hits.slice(); },
    accuseHits: function () { return ui.accuseHits.slice(); },
    canvasSize: function () { return { w: W, h: H }; },
    assetsFailed: function () { return failed.slice(); },
    peopleVisible: peopleVisible,
    visibilityOf: visibility
  };
}());
