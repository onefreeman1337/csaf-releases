//=============================================================================
// CourtcardInk.js — Courtcard [5/8]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [Courtcard] The colour and scale LAWS. Every ink is solved against what it sits on;
 * every repeated treatment declares a pitch. Library file - no drawing, no engine dependency.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * CourtcardInk.js
 *
 * ── WHAT THIS FILE IS ────────────────────────────────────────────────────────────────────────
 *
 * Nothing here draws. It holds the small number of measured LAWS every other file in this product
 * obeys, in one place, with one reader each. Wing §11a: a second copy of a constant does not
 * drift, it WINS - so a law with two implementations is a law with one silent winner.
 *
 * Every entry below was paid for on a shipped product in this wing:
 *
 *   relief()      §22e-1  A MULTIPLIER is a hard-coded contrast RATIO. `shade(wax, 1.22)` moved a
 *                         bright wax 27 luminance levels and a dark one 11, and the device on the
 *                         darkest seal could not be made out at all. Separation is stated in
 *                         ABSOLUTE luminance levels and solved for.
 *                 §22e-1 amendment (Elytra, 2026-09-05) THE PROPORTIONAL FLOOR IS WITHDRAWN.
 *                         `move = max(want, headroom * 0.18)` destroyed every caller wanting a
 *                         small controlled amount: two lustres asking for 3.7 and 22 levels both
 *                         received 37 and rendered as the same picture. It delivers exactly
 *                         min(want, headroom) and NOTHING ELSE.
 *   inkFor()      §25h    Direction is tried BOTH ways, never guessed from a plain average. `lum`
 *                         is a weighted mean; WCAG contrast is gamma-expanded, and the two
 *                         disagree across the middle of the range - a solver keyed on the mean
 *                         picked the WORSE direction on every mid tone.
 *   headroom()    §22e-1  Exported because an assertion MUST read `min(delta, headroom)`. A flat
 *                         `relief(base, +1, 30)` arm went red on a body at luminance 244.9, where
 *                         only 10.1 levels exist. That is arithmetic, not a defect.
 *   repeatsFor()  §22b-1a A repeated treatment declares a PITCH and derives its count from the
 *                 §22a-2d real run. The first usable ratio moves 1.8x across the ink range while
 *                         the PAPER LEFT stays ~2.6px - the eye reads the gap, not the proportion.
 *                 §22b-1b It returns a RECORD. `for (i = 0; i < repeatsFor(...))` compares against
 *                         an object, `0 < {}` is false, and five detail bands silently vanished
 *                         while the Gate 1 review blamed the draughtsmanship.
 *   penFor()      §22a-2f An outline is sized by the SHAPE it outlines, never by the figure. One
 *                 §22a-2f-1 pen derived from figure height put a 5px outline on a 23px-radius head
 *                         and consumed sixteen cells at once. The constant against a full short
 *                         side is 0.08, NOT the 0.16 the original entry states against a radius.
 *   Recorder()    §22b-1b The cheapest real check in the product: if any count is DERIVED from
 *                         size, rendering the same corpus at two sizes CANNOT produce the same
 *                         number of drawing ops.
 *
 * ⚠️ An op counter proves a call HAPPENED, never that a pixel CHANGED (§17c-1: three hachures were
 * stroked in the same ink as the fill beneath them and counted perfectly).
 */

var CourtcardInk = CourtcardInk || {};

(function (K) {
    'use strict';

    // ───────────────────────────────────────────────────────────── SECTION 1: COLOUR

    /** @param {number} v @returns {number} clamped to a byte */
    function b255(v) { return v < 0 ? 0 : v > 255 ? 255 : Math.round(v); }
    K.b255 = b255;

    /**
     * Simple weighted brightness.
     * ⚠️ FOR ORDERING ONLY, NEVER FOR A CONTRAST DECISION (§25h). Use `rel`/`contrast` for that.
     * @param {number[]} c @returns {number} 0..255
     */
    K.lum = function (c) { return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]; };

    /** WCAG relative luminance, gamma-expanded. The one to use for any contrast question. */
    K.rel = function (c) {
        var f = function (v) {
            v /= 255;
            return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
        };
        return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
    };

    /** WCAG contrast ratio between two colours, 1..21. @returns {number} */
    K.contrast = function (a, b) {
        var la = K.rel(a), lb = K.rel(b);
        return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
    };

    /**
     * Mix two colours.
     * @param {number[]} a @param {number[]} b @param {number} t 0..1 toward b @returns {number[]}
     */
    K.mix = function (a, b, t) {
        return [b255(a[0] + (b[0] - a[0]) * t),
            b255(a[1] + (b[1] - a[1]) * t),
            b255(a[2] + (b[2] - a[2]) * t)];
    };

    /**
     * How much simple-luminance headroom exists above (+1) or below (-1) a colour.
     * @param {number[]} c @param {number} dir @returns {number} 0..255
     */
    K.headroom = function (c, dir) {
        var l = K.lum(c);
        return dir > 0 ? 255 - l : l;
    };

    /**
     * Move a colour toward white or black by an ABSOLUTE number of luminance levels.
     *
     * ⛔ Delivers exactly `min(minDelta, headroom)`. There is NO proportional floor and adding one
     * back is a product-axis-killing regression (§22e-1 amendment, measured on Elytra). If a caller
     * wants a generous lift it asks for a big `minDelta`, which is what an absolute unit is FOR.
     *
     * @param {number[]} c @param {number} dir +1 lighter, -1 darker
     * @param {number} minDelta luminance levels of separation wanted
     * @returns {number[]}
     */
    K.relief = function (c, dir, minDelta) {
        var head = K.headroom(c, dir);
        var move = Math.min(minDelta, head);
        if (move <= 0) return [c[0], c[1], c[2]];
        var t = head > 0 ? move / head : 0;
        var target = dir > 0 ? 255 : 0;
        return [c[0] + (target - c[0]) * t, c[1] + (target - c[1]) * t, c[2] + (target - c[2]) * t];
    };

    /**
     * The worst excursion a textured ground drives its field to, in the direction that HURTS.
     * Solving an ink against the FLAT field is solving against a surface the product never draws.
     * @param {number[]} field @param {number} amp 0..1 @param {boolean} inkIsPale
     * @returns {number[]}
     */
    K.fieldExtreme = function (field, amp, inkIsPale) {
        return K.mix(field, inkIsPale ? [255, 255, 255] : [0, 0, 0], amp || 0);
    };

    /**
     * Solve an ink for a mark sitting on `field`, starting from `hue` so the object keeps as much
     * of its own colour as the contrast allows.
     *
     * ⛔ BOTH DIRECTIONS ARE WALKED (§25h). The first colour to clear the bar in either direction
     * wins; if neither clears it, the MOST separated colour that exists is returned together with
     * `metWant:false`, because a silent near-miss is indistinguishable from a solve (master §2b:
     * name the refusal).
     *
     * @param {number[]} field the surface the mark sits on
     * @param {number[]} hue the object's own body colour, where the walk starts
     * @param {number} wantRatio e.g. 4.5 for AA, 7 for AAA
     * @param {number} [amp] the ground's texture amplitude
     * @returns {{ink:number[], ratio:number, metWant:boolean}}
     */
    K.inkFor = function (field, hue, wantRatio, amp) {
        var want = typeof wantRatio === 'number' ? wantRatio : 4.5;
        var best = null, bestR = -1;
        for (var d = 0; d < 2; d++) {
            var pale = d === 0;
            var target = pale ? [255, 255, 255] : [0, 0, 0];
            var against = K.fieldExtreme(field, amp, pale);
            for (var t = 0; t <= 1.0001; t += 0.02) {
                var cand = K.mix(hue, target, t);
                var got = K.contrast(cand, against);
                if (got > bestR) { bestR = got; best = cand; }
                if (got >= want) return { ink: cand, ratio: got, metWant: true };
            }
        }
        return { ink: best || hue.slice(), ratio: bestR, metWant: false };
    };

    /**
     * Pick whichever candidate reads best against a background (§22e).
     * @param {number[]} bg @param {number[][]} candidates @returns {number[]}
     */
    K.pickContrast = function (bg, candidates) {
        if (!candidates || !candidates.length) throw new Error('pickContrast needs candidates');
        var best = candidates[0], bestC = -1;
        for (var i = 0; i < candidates.length; i++) {
            var k = K.contrast(bg, candidates[i]);
            if (k > bestC) { bestC = k; best = candidates[i]; }
        }
        return best;
    };

    /** @param {number[]} c rgb 0-255 @returns {number[]} [h 0-360, s 0-1, l 0-1] */
    K.toHsl = function (c) {
        var r = c[0] / 255, g = c[1] / 255, b = c[2] / 255;
        var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
        var h = 0;
        if (d) {
            if (mx === r) h = ((g - b) / d) % 6;
            else if (mx === g) h = (b - r) / d + 2;
            else h = (r - g) / d + 4;
            h *= 60; if (h < 0) h += 360;
        }
        var l = (mx + mn) / 2;
        var s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
        return [h, s, l];
    };

    /** @param {number[]} hsl @returns {number[]} rgb 0-255 */
    K.fromHsl = function (hsl) {
        var h = ((hsl[0] % 360) + 360) % 360, s = hsl[1], l = hsl[2];
        var cc = (1 - Math.abs(2 * l - 1)) * s;
        var x = cc * (1 - Math.abs(((h / 60) % 2) - 1));
        var m = l - cc / 2;
        var r = 0, g = 0, b = 0;
        if (h < 60) { r = cc; g = x; } else if (h < 120) { r = x; g = cc; }
        else if (h < 180) { g = cc; b = x; } else if (h < 240) { g = x; b = cc; }
        else if (h < 300) { r = x; b = cc; } else { r = cc; b = x; }
        return [(r + m) * 255, (g + m) * 255, (b + m) * 255];
    };

    /** `rgb(...)` for a canvas fillStyle. @param {number[]} c @returns {string} */
    K.css = function (c) { return 'rgb(' + b255(c[0]) + ',' + b255(c[1]) + ',' + b255(c[2]) + ')'; };

    /** @param {number[]} c @param {number} a 0..1 @returns {string} */
    K.rgba = function (c, a) {
        return 'rgba(' + b255(c[0]) + ',' + b255(c[1]) + ',' + b255(c[2]) + ',' + a + ')';
    };

    // =============================================================================================
    // THE LIGHT. ONE DECLARATION, EVERY READER.
    //
    // ⛔ WING §11a: A SECOND COPY OF A CONSTANT DOES NOT DRIFT - IT WINS. Elytra found three
    // independent statements of "the light comes from the upper left" in three files, none of which
    // knew about the others, and the whole point of a fixed light is that every mark on one object
    // agrees about where it comes from. A card whose foil rakes from one corner and whose rails are
    // relieved from another is exactly the coder art master §1.1 bans.
    //
    //   u, v  where the highlight sits on the card. 0,0 is the top-left corner of the face.
    //   dir   a UNIT 2-vector pointing from the surface TOWARD the light, in screen axes
    //         (x right, y DOWN), so upper-left is x<0, y<0.
    // =============================================================================================

    K.LIGHT = (function () {
        var d = [-0.62, -0.78];
        var m = Math.sqrt(d[0] * d[0] + d[1] * d[1]);
        return { u: 0.30, v: 0.24, dir: [d[0] / m, d[1] / m] };
    }());

    // ───────────────────────────────────────────────────────────── SECTION 2: SCALE

    /**
     * How many marks of a repeated treatment fit along a run, and at what real pitch.
     *
     * ⛔ RETURNS A RECORD (§22b-1b). Read `.count`. `for (i = 0; i < repeatsFor(...))` compares an
     * object and never runs, and nothing throws.
     *
     * @param {number} run length available
     * @param {number} thickness the mark's own thickness
     * @param {number} pitchMul the corpus's pitch, as a multiple of thickness
     * @param {number} [paperMin] absolute px of clear ground required between marks
     * @returns {{count:number, pitch:number, floored:boolean}}
     */
    K.repeatsFor = function (run, thickness, pitchMul, paperMin) {
        var floor = paperMin === undefined ? 2.6 : paperMin;
        var wanted = thickness * pitchMul;
        var least = thickness + floor;
        var floored = wanted < least;
        var pitch = Math.max(wanted, least);
        var count = Math.max(0, Math.floor(run / pitch));
        return { count: count, pitch: pitch, floored: floored };
    };

    /**
     * The pen width for outlining a shape, derived from the SHAPE'S OWN bounding box.
     * ⛔ 0.08 of the SHORT SIDE (§22a-2f-1). 0.16 against a full box permits the exact defect the
     * rule was written for.
     * @param {number} figureInk @param {number} w @param {number} h @returns {number}
     */
    K.penFor = function (figureInk, w, h) {
        return Math.max(0.9, Math.min(figureInk, Math.min(w, h) * 0.08));
    };

    /**
     * Deterministic noise, 0..1. ⛔ Wing rule 2: never `Math.random()` in game logic - a card must
     * be the same object in every session, on every machine, and a texture reseeded per frame makes
     * the card shimmer (invisible in a still, obvious in play).
     * @param {number} i @returns {number} 0..1
     */
    K.nz = function (i) {
        var h = Math.imul((i | 0) ^ 0x9e3779b9, 0x85ebca6b) >>> 0;
        h ^= h >>> 13;
        h = Math.imul(h, 0xc2b2ae35) >>> 0;
        return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
    };

    /**
     * Count what actually reached the bitmap. The two-size op-count comparison (§22b-1b) is the
     * only mechanical thing that can tell "the derivation is dead" from "the art is weak".
     * @param {CanvasRenderingContext2D} ctx @returns {{counts:object, done:function}}
     */
    K.Recorder = function (ctx) {
        var counts = { path: 0, fill: 0, stroke: 0, rect: 0, text: 0 };
        var orig = {};
        var wrap = function (name, key) {
            orig[name] = ctx[name];
            ctx[name] = function () { counts[key]++; return orig[name].apply(ctx, arguments); };
        };
        wrap('beginPath', 'path');
        wrap('fill', 'fill');
        wrap('stroke', 'stroke');
        wrap('fillRect', 'rect');
        wrap('fillText', 'text');
        return {
            counts: counts,
            done: function () { for (var k in orig) { ctx[k] = orig[k]; } return counts; }
        };
    };

    if (typeof module !== 'undefined' && module.exports) { module.exports = K; }
}(CourtcardInk));

if (typeof module !== 'undefined' && module.exports) { module.exports = CourtcardInk; }
