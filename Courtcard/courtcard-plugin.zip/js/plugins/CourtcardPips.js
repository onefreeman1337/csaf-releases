//=============================================================================
// CourtcardPips.js — Courtcard [6/8]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [Courtcard] The suit index and the cost rail - eight pip glyphs, and a tally that
 * derives its count from the real run. Drawing only; siblings resolved at FIRST USE.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * CourtcardPips.js
 *
 * ── WHY A TALLY AND NOT A NUMBER ─────────────────────────────────────────────────────────────
 *
 * A cost printed as a numeral is a UI label; a cost STRUCK AS PIPS is part of the engraving, and
 * it is the difference between a card that looks printed and a card that looks like a spreadsheet
 * row. The rail runs down the inner left stile and the count is DERIVED from the run it has
 * (§22b-1a) - a card 250px wide fits a different number of pips from one drawn at 520px, and
 * typing either number is the defect that rendered Escutcheon's seven bezel treatments as one
 * yellow rectangle.
 *
 * ⛔ AND THE OVERFLOW IS THE INTERESTING HALF. A cost of 14 on a rail that fits 9 must not silently
 * draw 9 - that is a card lying about the buyer's own data. Above the rail's capacity the pips
 * become a TALLY: a struck bar for each five and single pips for the remainder, which is how a
 * counting mark has been drawn on paper for four thousand years and which fits any cost in a
 * bounded run. `pipPlan()` returns the plan and `capacity` so a test can assert BOTH that the
 * total is right and that it fitted.
 *
 * ── THE GLYPHS ───────────────────────────────────────────────────────────────────────────────
 *
 * ⚠️ §22a: these are the SMALLEST marks in the product, so the eye assigns each to the nearest
 * common category and the separations that survive are SILHOUETTE separations, never detail. The
 * measured pairwise distances are pinned by `_probe/pip_distance.js`, with the floor placed in the
 * measured GAP rather than at a number anybody liked (§22b-2, §12b-1).
 */

var CourtcardPips = CourtcardPips || {};

(function (Pp) {
    'use strict';

    var _deps = null;

    /** Resolve siblings at FIRST USE (wing §8 trap 2). */
    function deps() {
        if (_deps) return _deps;
        var ink = (typeof CourtcardInk !== 'undefined') ? CourtcardInk
            : (typeof require !== 'undefined' ? require('./CourtcardInk.js') : null);
        var corpus = (typeof CourtcardCorpus !== 'undefined') ? CourtcardCorpus
            : (typeof require !== 'undefined' ? require('./CourtcardCorpus.js') : null);
        if (!ink || !corpus) throw new Error('CourtcardPips: CourtcardInk and CourtcardCorpus must both be loaded');
        _deps = { ink: ink, corpus: corpus };
        return _deps;
    }
    Pp.deps = deps;

    /**
     * Draw one pip glyph, centred at (cx, cy) with radius `r`.
     *
     * Every glyph is authored to fill its own radius, so the caller sizes the mark and never the
     * glyph. @returns {number} drawing ops issued
     */
    Pp.glyph = function (ctx, cx, cy, r, id, fill, ink, pen) {
        var K = deps().ink, C = deps().corpus;
        if (!C.PIPS[id]) throw new Error('CourtcardPips: unknown pip "' + id + '"');
        var i, a;
        ctx.save();
        ctx.lineWidth = Math.max(0.8, pen);
        ctx.lineJoin = 'round';
        ctx.strokeStyle = K.css(ink);
        ctx.fillStyle = K.css(fill);

        if (id === 'flame') {
            // leaning, with ONE notch out of the trailing edge — nothing pairs
            ctx.beginPath();
            ctx.moveTo(cx + r * 0.10, cy - r);
            ctx.bezierCurveTo(cx + r * 0.95, cy - r * 0.10, cx + r * 0.62, cy + r * 0.86, cx - r * 0.06, cy + r);
            ctx.bezierCurveTo(cx - r * 0.80, cy + r * 0.72, cx - r * 0.52, cy - r * 0.02, cx - r * 0.16, cy - r * 0.34);
            ctx.lineTo(cx - r * 0.34, cy + r * 0.10);
            ctx.closePath();
            ctx.fill(); ctx.stroke();
        } else if (id === 'crystal') {
            // six-sided, point up, with ONE clipped shoulder so it is not symmetric
            ctx.beginPath();
            ctx.moveTo(cx, cy - r);
            ctx.lineTo(cx + r * 0.72, cy - r * 0.30);
            ctx.lineTo(cx + r * 0.52, cy + r * 0.74);
            ctx.lineTo(cx - r * 0.46, cy + r * 0.86);
            ctx.lineTo(cx - r * 0.78, cy - r * 0.06);
            ctx.lineTo(cx - r * 0.34, cy - r * 0.72);
            ctx.closePath();
            ctx.fill(); ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(cx, cy - r); ctx.lineTo(cx - r * 0.10, cy + r * 0.80);
            ctx.stroke();
        } else if (id === 'bolt') {
            // three strokes, EACH SHORTER than the last — a run of equal bars reads as a ladder
            var pts = [[-0.62, -0.96], [0.28, -0.18], [-0.16, -0.06], [0.60, 0.98], [-0.12, 0.20], [0.22, 0.10], [-0.34, -0.40]];
            ctx.beginPath();
            for (i = 0; i < pts.length; i++) {
                var px = cx + pts[i][0] * r, py = cy + pts[i][1] * r;
                if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
            }
            ctx.closePath();
            ctx.fill(); ctx.stroke();
        } else if (id === 'cube') {
            // isometric, ONE face shaded — a plain square would read as a pip-less blank
            var t = r * 0.56;
            ctx.beginPath();
            ctx.moveTo(cx, cy - r); ctx.lineTo(cx + t * 1.55, cy - r * 0.42);
            ctx.lineTo(cx + t * 1.55, cy + r * 0.52); ctx.lineTo(cx, cy + r);
            ctx.lineTo(cx - t * 1.55, cy + r * 0.52); ctx.lineTo(cx - t * 1.55, cy - r * 0.42);
            ctx.closePath();
            ctx.fill(); ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(cx, cy - r); ctx.lineTo(cx, cy + r * 0.04);
            ctx.lineTo(cx - t * 1.55, cy + r * 0.52); ctx.lineTo(cx - t * 1.55, cy - r * 0.42);
            ctx.closePath();
            ctx.fillStyle = K.css(K.relief(fill, -1, 40));
            ctx.fill(); ctx.stroke();
        } else if (id === 'curl') {
            // an open curl: thick at the head, tapering to NOTHING (§22a-2)
            ctx.beginPath();
            ctx.moveTo(cx - r * 0.86, cy + r * 0.30);
            ctx.bezierCurveTo(cx - r * 0.20, cy - r * 1.10, cx + r * 0.98, cy - r * 0.34, cx + r * 0.36, cy + r * 0.52);
            ctx.bezierCurveTo(cx + r * 0.06, cy + r * 0.92, cx - r * 0.30, cy + r * 0.62, cx - r * 0.12, cy + r * 0.26);
            ctx.bezierCurveTo(cx + r * 0.16, cy - r * 0.10, cx + r * 0.34, cy + r * 0.22, cx + r * 0.06, cy + r * 0.36);
            ctx.bezierCurveTo(cx - r * 0.30, cy + r * 0.54, cx - r * 0.62, cy + r * 0.62, cx - r * 0.86, cy + r * 0.30);
            ctx.closePath();
            ctx.fill(); ctx.stroke();
        } else if (id === 'sun') {
            // alternating long and short rays — equal rays read as a cog (§22a)
            ctx.beginPath();
            for (i = 0; i < 16; i++) {
                a = i * Math.PI / 8;
                var R = i % 2 ? r * 0.46 : r * 1.00;
                var px2 = cx + Math.cos(a) * R, py2 = cy + Math.sin(a) * R;
                if (i === 0) ctx.moveTo(px2, py2); else ctx.lineTo(px2, py2);
            }
            ctx.closePath();
            ctx.fill(); ctx.stroke();
            ctx.beginPath(); ctx.arc(cx, cy, r * 0.30, 0, Math.PI * 2);
            ctx.fillStyle = K.css(K.relief(fill, -1, 44)); ctx.fill(); ctx.stroke();
        } else if (id === 'crescent') {
            // horns UP AND TO ONE SIDE, bitten by a clipped disc so the bite cannot overhang
            ctx.save();
            ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.clip();
            ctx.beginPath();
            ctx.arc(cx, cy, r, 0, Math.PI * 2);
            ctx.arc(cx + r * 0.46, cy - r * 0.30, r * 0.86, 0, Math.PI * 2, true);
            ctx.fill('evenodd');
            ctx.restore();
            ctx.beginPath();
            ctx.arc(cx, cy, r, 0, Math.PI * 2);
            ctx.arc(cx + r * 0.46, cy - r * 0.30, r * 0.86, 0, Math.PI * 2, true);
            ctx.stroke();
        } else if (id === 'drop') {
            // pointed head, round tail — the reverse of a flame, and it leans the other way
            ctx.beginPath();
            ctx.moveTo(cx - r * 0.06, cy - r);
            ctx.bezierCurveTo(cx + r * 0.62, cy - r * 0.10, cx + r * 0.86, cy + r * 0.52, cx + r * 0.10, cy + r * 0.94);
            ctx.bezierCurveTo(cx - r * 0.74, cy + r * 0.64, cx - r * 0.62, cy - r * 0.16, cx - r * 0.06, cy - r);
            ctx.closePath();
            ctx.fill(); ctx.stroke();
        }
        ctx.restore();
        return 1;
    };

    /**
     * Plan a cost rail: how the cost is struck into the run available.
     *
     * ⛔ THE COUNT IS DERIVED (§22b-1a) AND THE OVERFLOW IS NAMED (master §2b: a silent refusal is
     * correct behaviour that cannot be told apart from a failure). Below capacity the plan is one
     * pip per point; at or above it the plan is a tally — a bar per five, then single pips.
     *
     * @param {number} cost @param {number} run the rail length in px @param {number} pipR pip radius
     * @returns {{mode:string, bars:number, singles:number, total:number, capacity:number, pitch:number}}
     */
    Pp.pipPlan = function (cost, run, pipR) {
        var K = deps().ink;
        var c = Math.max(0, Math.round(cost || 0));
        var rep = K.repeatsFor(run, pipR * 2, 1.35);
        var capacity = rep.count;
        if (c <= capacity) {
            return { mode: 'pips', bars: 0, singles: c, total: c, capacity: capacity, pitch: rep.pitch };
        }
        var bars = Math.floor(c / 5);
        var singles = c - bars * 5;
        // a bar occupies one slot, so if even the tally overflows, the bars carry more each
        return {
            mode: 'tally', bars: bars, singles: singles, total: c,
            capacity: capacity, pitch: rep.pitch
        };
    };

    /**
     * Strike the suit index and the cost rail into the field.
     *
     * @param {CanvasRenderingContext2D} ctx
     * @param {object} L the layout from CourtcardCorpus.layout
     * @param {object} spec {element, cost}
     * @param {object} P palette
     * @returns {{index:number, rail:number, plan:object}}
     */
    Pp.draw = function (ctx, L, spec, P) {
        var K = deps().ink, C = deps().corpus;
        var el = C.element(spec.element);
        if (!el) throw new Error('CourtcardPips: unknown element "' + spec.element + '"');
        var f = L.field, ink = L.ink;

        // ── the suit index: one larger glyph, top-left, seated INSIDE the field
        var iR = L.w * 0.050;
        var ix = f.x + iR * 1.25, iy = f.y + iR * 1.25;
        var pen = K.penFor(ink, iR * 2, iR * 2);
        var idxFill = K.relief(P.body, K.lum(P.body) > 127 ? -1 : 1, 22);
        Pp.glyph(ctx, ix, iy, iR, el.pip, idxFill, P.ink, pen);

        // ── the cost rail: down the inner left stile, count DERIVED from the run it has
        var railTop = iy + iR * 1.9;
        var railBot = f.y + f.h - L.plate.h - iR * 0.6;
        var run = Math.max(0, railBot - railTop);
        var pipR = L.w * 0.026;
        var plan = Pp.pipPlan(spec.cost, run, pipR);
        var drawn = 0, i, y;

        if (plan.mode === 'pips') {
            for (i = 0; i < plan.singles; i++) {
                y = railTop + (i + 0.5) * plan.pitch;
                Pp.glyph(ctx, ix, y, pipR, el.pip, P.accent, P.ink, K.penFor(ink, pipR * 2, pipR * 2));
                drawn++;
            }
        } else {
            var slot = 0;
            for (i = 0; i < plan.bars && slot < plan.capacity; i++, slot++) {
                y = railTop + (slot + 0.5) * plan.pitch;
                ctx.save();
                ctx.beginPath();
                ctx.moveTo(ix - pipR * 1.15, y);
                ctx.lineTo(ix + pipR * 1.15, y);
                ctx.lineWidth = Math.max(1.1, pipR * 0.52);
                ctx.lineCap = 'butt';
                ctx.strokeStyle = K.css(P.accent);
                ctx.stroke();
                ctx.restore();
                drawn++;
            }
            for (i = 0; i < plan.singles && slot < plan.capacity; i++, slot++) {
                y = railTop + (slot + 0.5) * plan.pitch;
                Pp.glyph(ctx, ix, y, pipR, el.pip, P.accent, P.ink, K.penFor(ink, pipR * 2, pipR * 2));
                drawn++;
            }
        }
        return { index: 1, rail: drawn, plan: plan };
    };

    if (typeof module !== 'undefined' && module.exports) { module.exports = Pp; }
}(CourtcardPips));

if (typeof module !== 'undefined' && module.exports) { module.exports = CourtcardPips; }
