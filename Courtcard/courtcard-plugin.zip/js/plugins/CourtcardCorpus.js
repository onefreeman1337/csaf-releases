//=============================================================================
// CourtcardCorpus.js — Courtcard [1/8]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [Courtcard] The authored corpus - rarities, types, elements, decks and the
 * sub-vocabularies every one of them is drawn from. Data only; no drawing, no engine dependency.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * CourtcardCorpus.js
 *
 * ── THE CARD, AND WHY IT IS NOT A MAGIC FRAME ────────────────────────────────────────────────
 *
 * ⛔ THERE IS NO ART WINDOW. The commonest way to draw a game card is a rectangle of borrowed art
 * with a text box under it and a cost bubble in the corner - which is a TRACING of two commercial
 * card games, and it is the second kill condition recorded for this product. A Courtcard face is
 * ONE COMPOSED ENGRAVING in the tradition of a European pattern deck: a struck border, a charge
 * that fills the field, pips in the corners, and a cartouche at the foot carrying the buyer's own
 * title. The frame is part of the picture rather than a container for someone else's.
 *
 * ── THE FIVE AXES, AND WHAT EACH ONE OWNS ────────────────────────────────────────────────────
 *
 *   rarity   the FRAME          rails, corner treatment, ornament band, foil
 *   type     the DEVICE'S BUILD what the central charge structurally IS
 *   element  the DEVICE'S CUT   its internal geometry, and the pip glyph
 *   cost     the PIPS           how many, derived from the real run
 *   deck     the STOCK          paper, palette and the back design
 *
 * Nothing is carried by colour alone. §21a: a palette is not a composition, and §25f's measured
 * form of it is the check that matters - draw every id under ONE FIXED PALETTE and count DISTINCT
 * STRUCTURES. Cartouche read 14 structures from 40 declared names and every other instrument was
 * green.
 *
 * ── LAWS THIS CORPUS IS AUTHORED AGAINST ─────────────────────────────────────────────────────
 *
 * §22a     The eye resolves the CHEAPEST interpretation, so a symmetrical pair of masses becomes
 *          spectacles, a rayed disc becomes a sun, and equal legs under a rounded body become a
 *          caterpillar. Every `build` below is deliberately ASYMMETRIC about the vertical axis.
 * §22a-2c  An accessory only reads if it sits where no ordinary body part sits. Position first,
 *          geometry second.
 * §22b-1a  A repeated treatment declares a PITCH, never a COUNT. Every `pitchMul` in this file is
 *          a multiple of the mark's own thickness and the count is derived from the real run.
 * §22b-5   A `note` is NOT a drawing instruction. Every noun in every note below names something
 *          the renderer actually draws, and `corpus_check` greps for it.
 * §17c     An id, a count, a test and a sentence are four statements about a table. None of them
 *          is a mark on a bitmap.
 */

var CourtcardCorpus = CourtcardCorpus || {};

(function (C) {
    'use strict';

    // =============================================================================================
    // GEOMETRY OF THE CARD ITSELF
    //
    // ⛔ THE ASPECT IS DECLARED HERE AND NOWHERE ELSE. Wing §25b: Cartouche's contact sheet drew
    // cells at aspect 3.26 while the product shipped at 4.53, so the ornament was judged against a
    // shorter run than it would ever have, and the sheet flattered it for a whole pass. Every sheet,
    // probe and scene in this product derives its cell size from `ASPECT` and `layout()`.
    // =============================================================================================

    /** Height / width. 0.7 is the playing-card proportion; a card is drawn portrait. */
    C.ASPECT = 1.40;

    /**
     * The typeface. ONE DECLARATION, read by the card assembler, the scene and every sheet.
     *
     * ⛔ WING §15a: `windowsDrawn: 0` IS BLIND TO THE FONT. Every geometric and pixel gate in this
     * factory passed on a product whose scene was set in `$gameSystem.mainFontFace()` - which is
     * the single loudest "this is RPG Maker" signal after the windowskin, and `rmmz-mainfont` is
     * itself MONOSPACE. No mechanical check anywhere has an opinion about a typeface, so the answer
     * has to be a stack somebody CHOSE.
     *
     * ⚠️ §15a also says to copy a proven stack rather than re-derive one. This is Cartouche's and
     * Elytra's, unchanged, and both shipped with it: an old-style serif with real weight contrast,
     * which is what an engraved nameplate is set in.
     */
    C.TYPEFACE = {
        display: 'Georgia, "Iowan Old Style", "Palatino Linotype", Palatino, "Book Antiqua", serif',
        note: 'an old-style serif for every struck letter on the card'
    };

    /**
     * The card's internal geography, derived from its width. One declaration, every reader.
     *
     * ⛔ EVERY NUMBER IS A FRACTION OF THE SHORT SIDE (the width), because that is the run the
     * frame is thinnest against and §25b records what happens when a rail is sized off the long
     * one: on an 816x180 window a rail taken from `min(w,h)` was 1.4% of the picture and every mark
     * hung off it was invisible.
     *
     * @param {number} w card width in px
     * @returns {object} rects, all in card-local coordinates
     */
    C.layout = function (w) {
        var h = w * C.ASPECT;
        var margin = w * 0.052;          // the paper left clear outside the outermost rail
        var railBand = w * 0.086;        // total depth the frame is allowed to occupy
        var fx = margin, fy = margin;
        var fw = w - margin * 2, fh = h - margin * 2;
        var ix = fx + railBand, iy = fy + railBand;
        var iw = fw - railBand * 2, ih = fh - railBand * 2;
        var plateH = ih * 0.148;         // the nameplate cartouche at the foot
        return {
            w: w, h: h,
            margin: margin, railBand: railBand,
            frame: { x: fx, y: fy, w: fw, h: fh },
            field: { x: ix, y: iy, w: iw, h: ih },
            // the device gets everything above the nameplate, less a breath either side
            device: { x: ix + iw * 0.06, y: iy + ih * 0.045, w: iw * 0.88, h: ih - plateH - ih * 0.075 },
            plate: { x: ix + iw * 0.05, y: iy + ih - plateH, w: iw * 0.90, h: plateH },
            ink: Math.max(1.0, w * 0.0105)
        };
    };

    // =============================================================================================
    // SUB-VOCABULARIES — the marks the five axes are built from.
    // Each id below is switched on by exactly one renderer function, named in its comment.
    // =============================================================================================

    /** Corner treatments. Drawn by CourtcardFrame.cornerMark. */
    C.CORNERS = {
        nick: { reach: 0.30, note: 'a single mitred cut across the corner' },
        clip: { reach: 0.46, note: 'a stepped clip, two cuts of unequal depth' },
        rosette: { reach: 0.62, note: 'a lobed rosette seated in the corner with a pierced eye' },
        finial: { reach: 0.84, note: 'a finial projecting on the diagonal above a collar' },
        crown: { reach: 1.00, note: 'a crown of three points rising from a banded collar' }
    };

    /** Ornament bands run along the rails. Drawn by CourtcardFrame.bandRun. */
    C.BANDS = {
        none: { pitchMul: 0, depth: 0.00, note: 'no band' },
        dot: { pitchMul: 2.6, depth: 0.55, note: 'a row of struck dots' },
        cable: { pitchMul: 3.4, depth: 0.85, note: 'a twisted cable of alternating lobes' },
        dentil: { pitchMul: 2.9, depth: 1.00, note: 'square dentil blocks with clear ground between' },
        arcade: { pitchMul: 4.2, depth: 0.95, note: 'a run of round-headed arches on piers' },
        lozenge: { pitchMul: 3.1, depth: 0.80, note: 'lozenges laid point to point' }
    };

    /**
     * Foil treatments. Drawn by CourtcardFoil.apply.
     * ⚠️ `lift` is an ABSOLUTE luminance delta, never a multiplier (§22e-1).
     */
    C.FOILS = {
        none: { lift: 0, sheen: 0.00, note: 'no foil' },
        edge: { lift: 26, sheen: 0.18, note: 'a tinted bevel on the inner edge of the rails' },
        ramp: { lift: 44, sheen: 0.42, note: 'a raking sheen across the rails from the fixed light' },
        leaf: { lift: 62, sheen: 0.70, note: 'laid leaf over the whole frame with a burnished band' },
        radiant: { lift: 78, sheen: 0.92, note: 'laid leaf plus rays struck outward from the device' }
    };

    /** Paper stocks. Drawn by CourtcardFrame.stock. */
    C.STOCKS = {
        laid: { amp: 0.055, pitchMul: 6.0, note: 'laid chain lines running down the sheet' },
        wove: { amp: 0.030, pitchMul: 0.0, note: 'an even wove speckle with no lines' },
        linen: { amp: 0.062, pitchMul: 4.4, note: 'a crossed linen weave' },
        vellum: { amp: 0.048, pitchMul: 0.0, note: 'vellum mottling in soft irregular patches' },
        smoked: { amp: 0.075, pitchMul: 0.0, note: 'a smoked wash, heavier toward the edges' }
    };

    /** Back designs, one per deck. Drawn by CourtcardFrame.back. */
    C.BACKS = {
        diaper: { pitchMul: 5.2, note: 'a lattice diaper with a fleuron in every opening' },
        barb: { pitchMul: 4.6, note: 'a grid of barbed quatrefoils' },
        trellis: { pitchMul: 6.0, note: 'a vine trellis with paired leaves at each crossing' },
        ripple: { pitchMul: 3.4, note: 'concentric ripples struck from an off-centre point' },
        compass: { pitchMul: 0.0, note: 'a radiant compass rose of long and short rays' },
        herring: { pitchMul: 3.0, note: 'a broken herringbone of short parallel cuts' }
    };

    /**
     * The internal cut an element gives a device. Drawn by CourtcardDevice.cut.
     * ⛔ These are STRUCTURAL, not tints. §21a: a palette is not a composition, and an element that
     * only changed the colour would be an axis that does not exist under §25f's fixed-palette count.
     */
    C.TREATMENTS = {
        tongue: { note: 'flame tongues licking up off the charge, cut into its upper outline' },
        facet: { note: 'crystal facets cut across the charge with straight chords' },
        fork: { note: 'a forked crack splitting the charge from one edge' },
        strata: { note: 'horizontal strata bedding the charge into layers' },
        stream: { note: 'open trailing curls drawn off the charge on one side' },
        pierce: { note: 'pierced holes through the charge with rays escaping them' },
        dissolve: { note: 'the charge dissolving into detached flakes along one edge' },
        drip: { note: 'drips gathering along the lower outline and falling clear' }
    };

    /**
     * Pip glyphs, one per element. Drawn by CourtcardPips.glyph.
     * ⚠️ §22a: these are the smallest marks in the product and the eye assigns them to the nearest
     * common category. Each is separated from the others by SILHOUETTE, never by detail - and the
     * measured collision distances are pinned by `_probe/pip_distance.js`.
     */
    C.PIPS = {
        flame: { note: 'a leaning flame with one notch out of its trailing edge' },
        crystal: { note: 'a six-sided crystal seen point-up with a clipped shoulder' },
        bolt: { note: 'a bolt of three strokes, each shorter than the last' },
        cube: { note: 'a cube in isometric with one face shaded' },
        curl: { note: 'an open curl, thick at the head and tapering to nothing' },
        sun: { note: 'a disc with alternating long and short rays' },
        crescent: { note: 'a crescent bitten from a disc, horns up and to one side' },
        drop: { note: 'a drop with a pointed head and a round tail' }
    };

    // =============================================================================================
    // AXIS 1 — RARITY. Owns the frame.
    // ⛔ `rails` is a COUNT of concentric rails and it is legitimately a count: they are not a
    // repeated treatment along a run, they are two or three named members of a frame. Everything
    // that DOES repeat along a run (the band, the beading, the stock lines) declares a pitchMul.
    // =============================================================================================

    C.RARITIES = [
        {
            id: 'common', name: 'Common', rails: 1, railWeight: 1.00,
            corner: 'nick', band: 'none', foil: 'none', plateForm: 'ruled',
            note: 'a single rail with a mitred nick at each corner and no band'
        },
        {
            id: 'uncommon', name: 'Uncommon', rails: 2, railWeight: 1.15,
            corner: 'clip', band: 'dot', foil: 'none', plateForm: 'ruled',
            note: 'two rails with a row of struck dots between them and a stepped clip at each corner'
        },
        {
            id: 'rare', name: 'Rare', rails: 2, railWeight: 1.35,
            corner: 'rosette', band: 'cable', foil: 'edge', plateForm: 'recessed',
            note: 'a twisted cable band, a lobed rosette in each corner and a tinted bevel'
        },
        {
            id: 'epic', name: 'Epic', rails: 3, railWeight: 1.55,
            corner: 'finial', band: 'arcade', foil: 'ramp', plateForm: 'recessed',
            note: 'three rails carrying an arcade of round-headed arches, a finial on each diagonal'
        },
        {
            id: 'legendary', name: 'Legendary', rails: 3, railWeight: 1.80,
            corner: 'crown', band: 'lozenge', foil: 'radiant', plateForm: 'scrolled',
            note: 'three rails, lozenges laid point to point, a crown at each corner and struck rays'
        }
    ];

    // =============================================================================================
    // AXIS 2 — TYPE. Owns the device's BUILD.
    //
    // ⛔ EVERY BUILD IS ASYMMETRIC ABOUT THE VERTICAL AXIS, ON PURPOSE. §22a's whole table is
    // symmetrical shapes collapsing into the cheapest reading - two equal rings become spectacles,
    // equal legs under a body become a caterpillar, a rounded body with two curved points becomes a
    // crescent. A padlock, a fist and a trumpet survived that corpus precisely because nothing in
    // them pairs. `lean` is the drawn tilt in radians and no two builds share both a mass shape and
    // a lean.
    // =============================================================================================

    C.TYPES = [
        {
            id: 'strike', name: 'Strike', build: 'strike', lean: -0.34,
            note: 'a blade driving down across the field with an impact scatter under its point'
        },
        {
            id: 'guard', name: 'Guard', build: 'guard', lean: 0.16,
            note: 'a tower shield turned three-quarter with its boss off centre and a bracing bar'
        },
        {
            id: 'spell', name: 'Spell', build: 'spell', lean: -0.12,
            note: 'an open hand with a sigil arc breaking off the fingertips'
        },
        {
            id: 'summon', name: 'Summon', build: 'summon', lean: 0.00,
            note: 'an arch with a horned mass rising through it and breaking its inner line'
        },
        {
            id: 'curse', name: 'Curse', build: 'curse', lean: 0.28,
            note: 'a knot pulled tight around a snapped shaft with the loose ends falling away'
        },
        {
            id: 'mend', name: 'Mend', build: 'mend', lean: -0.40,
            note: 'a vessel tipped to pour, with the stream falling clear into a shallow bowl'
        },
        {
            id: 'trap', name: 'Trap', build: 'trap', lean: 0.22,
            note: 'a sprung jaw set at an angle with a taut line running off the field'
        },
        {
            id: 'aura', name: 'Aura', build: 'aura', lean: -0.18,
            note: 'a censer hanging on three chains with a pierced lid and vapour rising to one side'
        },
        {
            id: 'relic', name: 'Relic', build: 'relic', lean: 0.10,
            note: 'a key laid across a stepped plinth with one step broken away'
        },
        {
            id: 'beast', name: 'Beast', build: 'beast', lean: -0.26,
            note: 'a clawed paw print, one heel pad and four toes of unequal size on a tilted arc'
        },
        {
            id: 'rush', name: 'Rush', build: 'rush', lean: -0.46,
            note: 'a single winged spur thrown forward with the wing trailing behind the heel'
        },
        {
            id: 'ruin', name: 'Ruin', build: 'ruin', lean: 0.36,
            note: 'a leaning column snapped through with its drums scattered at the foot'
        }
    ];

    // =============================================================================================
    // AXIS 3 — ELEMENT. Owns the device's CUT and the pip glyph.
    // `hue` is a HUE ANGLE, not a colour: every actual ink is solved against the deck's own stock
    // by CourtcardInk (§22e). Authoring an RGB here would be the exact defect that file exists for.
    // =============================================================================================

    C.ELEMENTS = [
        { id: 'ember', name: 'Ember', hue: 18, chroma: 0.62, treatment: 'tongue', pip: 'flame', note: 'flame tongues cut off the charge' },
        { id: 'frost', name: 'Frost', hue: 196, chroma: 0.44, treatment: 'facet', pip: 'crystal', note: 'straight facet chords cut across the charge' },
        { id: 'storm', name: 'Storm', hue: 268, chroma: 0.50, treatment: 'fork', pip: 'bolt', note: 'a forked crack splitting the charge' },
        { id: 'stone', name: 'Stone', hue: 34, chroma: 0.26, treatment: 'strata', pip: 'cube', note: 'strata bedding the charge in layers' },
        { id: 'gale', name: 'Gale', hue: 152, chroma: 0.34, treatment: 'stream', pip: 'curl', note: 'trailing curls drawn off one side' },
        { id: 'radiance', name: 'Radiance', hue: 48, chroma: 0.58, treatment: 'pierce', pip: 'sun', note: 'pierced holes with rays escaping' },
        { id: 'umbra', name: 'Umbra', hue: 286, chroma: 0.30, treatment: 'dissolve', pip: 'crescent', note: 'the charge dissolving into detached flakes' },
        { id: 'venom', name: 'Venom', hue: 92, chroma: 0.54, treatment: 'drip', pip: 'drop', note: 'drips gathering and falling clear' }
    ];

    // =============================================================================================
    // AXIS 5 — DECK. Owns the paper, the palette and the back.
    // ⚠️ `ground`, `body` and `accent` are the only authored colours in the product, and they are
    // authored because a STOCK is a physical thing a printer chose. Every mark ON them is solved.
    // =============================================================================================

    C.DECKS = [
        {
            id: 'courtly', name: 'Courtly', stock: 'laid', back: 'diaper',
            ground: [232, 223, 200], body: [46, 42, 40], accent: [158, 46, 38],
            note: 'cream laid paper struck in black with a vermilion accent'
        },
        {
            id: 'grim', name: 'Grim', stock: 'smoked', back: 'barb',
            ground: [86, 84, 88], body: [214, 208, 196], accent: [126, 40, 44],
            note: 'smoked grey stock struck in bone with an oxblood accent'
        },
        {
            id: 'verdant', name: 'Verdant', stock: 'linen', back: 'trellis',
            ground: [216, 217, 197], body: [64, 58, 44], accent: [72, 108, 62],
            note: 'sage linen struck in sepia with a leaf green accent'
        },
        {
            id: 'abyssal', name: 'Abyssal', stock: 'wove', back: 'ripple',
            ground: [28, 34, 42], body: [196, 206, 210], accent: [64, 150, 148],
            note: 'near black wove stock struck in pale ink with a teal accent'
        },
        {
            id: 'gilded', name: 'Gilded', stock: 'vellum', back: 'compass',
            ground: [238, 228, 205], body: [78, 58, 34], accent: [176, 138, 58],
            note: 'ivory vellum struck in umber with a gold accent'
        },
        {
            id: 'ashen', name: 'Ashen', stock: 'wove', back: 'herring',
            ground: [206, 202, 196], body: [58, 56, 56], accent: [148, 84, 52],
            note: 'bleached stock struck in charcoal with a rust accent'
        }
    ];

    // =============================================================================================
    // LOOKUPS AND VOLUME
    // =============================================================================================

    /** @param {string} id @returns {object|null} */
    C.rarity = function (id) { return C.RARITIES.filter(function (r) { return r.id === id; })[0] || null; };
    /** @param {string} id @returns {object|null} */
    C.type = function (id) { return C.TYPES.filter(function (t) { return t.id === id; })[0] || null; };
    /** @param {string} id @returns {object|null} */
    C.element = function (id) { return C.ELEMENTS.filter(function (e) { return e.id === id; })[0] || null; };
    /** @param {string} id @returns {object|null} */
    C.deck = function (id) { return C.DECKS.filter(function (d) { return d.id === id; })[0] || null; };

    /**
     * What the corpus COULD make.
     *
     * ⛔ THIS IS NOT THE NUMBER THAT MATTERS AND SAYING SO IS THE POINT. Wing §21i: Glaze reported
     * 14 profiles x 12 glazes = 168 vessels, the figure was TRUE, and an in-engine shelf showed
     * twelve items in FIVE forms with four visible twins - because what a buyer sees is what their
     * own database RESOLVES to, and a classifier returns exactly one answer per branch.
     * `_probe/spread_check.js` answers the question this function cannot.
     *
     * @returns {object}
     */
    C.volume = function () {
        var devices = C.TYPES.length * C.ELEMENTS.length;
        return {
            rarities: C.RARITIES.length,
            types: C.TYPES.length,
            elements: C.ELEMENTS.length,
            decks: C.DECKS.length,
            devices: devices,
            faces: devices * C.RARITIES.length,
            backs: C.BACKS ? Object.keys(C.BACKS).length : 0,
            pips: Object.keys(C.PIPS).length,
            note: 'faces = type x element x rarity, before the deck palette. See spread_check.js '
                + 'for what a real database resolves to - that is the number master 1.1 q3 asks for.'
        };
    };

    /**
     * Every (axis, value) pair the product can actually emit, for the per-VALUE checks.
     *
     * ⛔ §25f: sweeping every declared value onto every id tests combinations the corpus cannot
     * emit and reports dead pairs that do not exist. This enumerates only what is reachable.
     *
     * @returns {Array<{table:string, field:string, value:string, via:string}>}
     */
    C.reachable = function () {
        var out = [];
        var push = function (table, field, value, via) {
            if (value === undefined || value === null || value === '') return;
            out.push({ table: table, field: field, value: String(value), via: via });
        };
        C.RARITIES.forEach(function (r) {
            push('rarities', 'corner', r.corner, r.id);
            push('rarities', 'band', r.band, r.id);
            push('rarities', 'foil', r.foil, r.id);
            push('rarities', 'plateForm', r.plateForm, r.id);
            push('rarities', 'rails', r.rails, r.id);
        });
        C.TYPES.forEach(function (t) {
            push('types', 'build', t.build, t.id);
        });
        C.ELEMENTS.forEach(function (e) {
            push('elements', 'treatment', e.treatment, e.id);
            push('elements', 'pip', e.pip, e.id);
        });
        C.DECKS.forEach(function (d) {
            push('decks', 'stock', d.stock, d.id);
            push('decks', 'back', d.back, d.id);
        });
        return out;
    };

    if (typeof module !== 'undefined' && module.exports) { module.exports = C; }
}(CourtcardCorpus));

if (typeof module !== 'undefined' && module.exports) { module.exports = CourtcardCorpus; }
