//=============================================================================
// CourtcardDevice.js — Courtcard [2/8]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [Courtcard] The central charge - twelve BUILDS from the card's type, each cut by the
 * card's element. Drawing only; siblings are resolved at FIRST USE, never at load time.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * CourtcardDevice.js
 *
 * ── THE UNIT SPACE, AND WHY THE BOUND IS NOT 1.0 ─────────────────────────────────────────────
 *
 * A build authors into x in [-1, 1] and y in [-1.30, 1.30] about the device box's centre, with
 * unit 1.0 mapped to `r = min(w/2, h/2.6)`. A card's device box is TALLER than it is wide, so a
 * square unit box would leave a third of the field as dead air - and wing §18 is explicit that
 * Gate 1 dead space is ARITHMETIC and gets computed rather than eyeballed.
 *
 * ⛔ WING §22a-6: A CLIPPED FIGURE AND A WRONG FIGURE LOOK IDENTICAL. Pushing a horn past the
 * drawable range put appendages outside the cell on Wanted Posters, the sheet rendered happily
 * with them cut off, and the review blamed geometry that was already correct.
 * `_probe/fit_check.js` measures the real extents against these bounds before any sheet is read.
 *
 * ── WHY EVERY BUILD LEANS ────────────────────────────────────────────────────────────────────
 *
 * ⛔ §22a is a table of symmetrical shapes collapsing into the cheapest available reading: two
 * equal rings become spectacles, radial spikes around a disc become a sun, equal legs under a
 * rounded body become a caterpillar. The figures that survived that corpus - a padlock, a fist, a
 * trumpet - survived because NOTHING IN THEM PAIRS. Every build here is asymmetric about the
 * vertical axis by construction, and `lean` is drawn rather than decorative.
 *
 * ── §22a-1b: A CHAIN OF ABUTTING MASSES READS AS A CHAIN ─────────────────────────────────────
 *
 * `blob()` traces a body as ONE continuous smooth outline so a join is a change of direction and
 * not a seam, and every appendage OVERLAPS the mass it grows from rather than abutting it. A
 * mammoth authored as body + skull + trunk + tusks read as "a circle, an oval, four posts and a
 * floating hook"; the same drawing as one outline read as an animal.
 */

var CourtcardDevice = CourtcardDevice || {};

(function (D) {
    'use strict';

    var _deps = null;

    /**
     * Resolve siblings at FIRST USE.
     *
     * ⛔ WING §8 TRAP 2 / 2b. `mz_harness build` loads the plugin folder ALPHABETICALLY, which is
     * exactly what a buyer creates by dragging files into the Plugin Manager in the wrong order. A
     * four-file product that captured its siblings at LOAD time ran against `undefined` and no-oped
     * behind one console line - and it would have shipped. This product ships NO plugin_order.json
     * precisely so the harness always runs that worst case.
     * @returns {{ink:object, corpus:object}}
     */
    function deps() {
        if (_deps) return _deps;
        var ink = (typeof CourtcardInk !== 'undefined') ? CourtcardInk
            : (typeof require !== 'undefined' ? require('./CourtcardInk.js') : null);
        var corpus = (typeof CourtcardCorpus !== 'undefined') ? CourtcardCorpus
            : (typeof require !== 'undefined' ? require('./CourtcardCorpus.js') : null);
        if (!ink || !corpus) throw new Error('CourtcardDevice: CourtcardInk and CourtcardCorpus must both be loaded');
        _deps = { ink: ink, corpus: corpus };
        return _deps;
    }
    D.deps = deps;

    /** The authored bounds. `fit_check` reads these rather than holding its own copy. */
    D.BOUND_X = 1.0;
    D.BOUND_Y = 1.30;

    /**
     * Map the unit space onto a box.
     * @param {{x:number,y:number,w:number,h:number}} box
     * @returns {{cx:number, cy:number, r:number, at:function}}
     */
    D.frameOf = function (box) {
        var r = Math.min(box.w / 2, box.h / (2 * D.BOUND_Y));
        var cx = box.x + box.w / 2, cy = box.y + box.h / 2;
        return {
            cx: cx, cy: cy, r: r,
            at: function (ux, uy) { return [cx + ux * r, cy + uy * r]; }
        };
    };

    // ─────────────────────────────────────────────────────── PRIMITIVES

    /**
     * Trace a closed body as ONE smooth outline through its points (§22a-1b).
     * Catmull-Rom converted to cubic beziers, so the join between two authored points is a change
     * of direction rather than a seam between two shapes.
     * @param {CanvasRenderingContext2D} ctx @param {object} F @param {number[][]} pts unit points
     */
    function blob(ctx, F, pts) {
        var n = pts.length, i;
        var p = [];
        for (i = 0; i < n; i++) p.push(F.at(pts[i][0], pts[i][1]));
        ctx.beginPath();
        ctx.moveTo(p[0][0], p[0][1]);
        for (i = 0; i < n; i++) {
            var p0 = p[(i - 1 + n) % n], p1 = p[i], p2 = p[(i + 1) % n], p3 = p[(i + 2) % n];
            ctx.bezierCurveTo(
                p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6,
                p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6,
                p2[0], p2[1]
            );
        }
        ctx.closePath();
    }
    D.blob = blob;

    /** A straight-sided closed polygon in unit space. */
    function poly(ctx, F, pts) {
        ctx.beginPath();
        for (var i = 0; i < pts.length; i++) {
            var q = F.at(pts[i][0], pts[i][1]);
            if (i === 0) ctx.moveTo(q[0], q[1]); else ctx.lineTo(q[0], q[1]);
        }
        ctx.closePath();
    }
    D.poly = poly;

    /**
     * A limb that TAPERS CONTINUOUSLY AND THEN STEPS (§22a-1b rule 3): a constant-width limb reads
     * as a tube, and a shape reads as a head only where the outline steps out and back.
     * @param {number[]} a start [ux,uy] @param {number[]} b end
     * @param {number} w0 half-width at start @param {number} w1 half-width at end
     * @returns {number[][]} a closed unit outline
     */
    function limb(a, b, w0, w1) {
        var dx = b[0] - a[0], dy = b[1] - a[1];
        var L = Math.sqrt(dx * dx + dy * dy) || 1e-6;
        var nx = -dy / L, ny = dx / L;
        var mid = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
        var wm = (w0 + w1) / 2 * 1.06;
        return [
            [a[0] + nx * w0, a[1] + ny * w0],
            [mid[0] + nx * wm, mid[1] + ny * wm],
            [b[0] + nx * w1, b[1] + ny * w1],
            [b[0] - nx * w1, b[1] - ny * w1],
            [mid[0] - nx * wm, mid[1] - ny * wm],
            [a[0] - nx * w0, a[1] - ny * w0]
        ];
    }
    D.limb = limb;

    /** Rotate a unit point about the origin by `t` radians. */
    function rot(p, t) {
        var c = Math.cos(t), s = Math.sin(t);
        return [p[0] * c - p[1] * s, p[0] * s + p[1] * c];
    }
    /** Rotate a whole outline. */
    function rotAll(pts, t) { return pts.map(function (p) { return rot(p, t); }); }
    /** Offset a whole outline. */
    function movAll(pts, dx, dy) { return pts.map(function (p) { return [p[0] + dx, p[1] + dy]; }); }
    D.rot = rot; D.rotAll = rotAll; D.movAll = movAll;

    // ─────────────────────────────────────────────────────── MODELLING THE MASS
    //
    // ⛔⛔ A FLAT FILL INSIDE AN OUTLINE IS CLIP ART, AND IT IS WHAT THIS FILE SHIPPED UNTIL
    // 2026-09-05. Every mass was `fill(P.body)` + `stroke(P.ink)` and nothing else, so a charge
    // was a single-colour silhouette however carefully its outline had been authored. MEASURED by
    // looking at the first captured gallery frame beside the wing's own stated bar
    // (`SigilCore_MZ/.../shot_4_the_grimoire.png`, master §10b): Sigil's seal carries concentric
    // rule, dozens of struck marks and real luminance; ten Courtcard charges read as flat lilac
    // and green paddles. The geometry was not the problem — `strike` really is a blade driving
    // down-left — the RENDERING carried no tone at all.
    //
    // ⭐ THE IDIOM IS ALREADY DECIDED BY THE PRODUCT: this is a printed card, drawn in ink on a
    // stock, and §22b-1b's note in CourtcardCard says it outright — "an engraving is a LINE on
    // PAPER with tone between them". So tone is carried by HATCHING whose spacing and weight ramp
    // toward the shadow, not by a gradient, and the lit side is left as bare wash. That is the
    // one modelling language that cannot look like a filter over the top of a drawing.
    //
    // ⛔ THE LIGHT IS `K.LIGHT.dir` AND IS NOT RESTATED HERE. Wing §11a: a second copy of a
    // constant does not drift, it WINS — Elytra found three independent statements of "the light
    // comes from the upper left" in three files, none aware of the others. Screen axes, x right,
    // y DOWN, and `F.at` maps unit y the same way, so no axis flip is needed.
    //
    // ⛔ AND THE LIGHT IS COUNTER-ROTATED BY THE BUILD'S LEAN. `D.draw` rotates the whole context
    // by `lean * 0.22` before any mass is drawn, so hatching authored in that rotated space would
    // arrive at a world angle of `angle + lean`. Twelve builds lean twelve different amounts, so
    // the deck would be lit from twelve directions — which is precisely the incoherence this
    // product's own kill condition names, arriving through the renderer instead of through the
    // art. Subtracting the lean is what keeps ONE light across fifty-two faces.

    /**
     * Engraved tone inside one mass. Assumes the caller has already clipped to the mass.
     *
     * ⛔ RETURNS A COUNT, and the caller is expected to read it (§2b rule 2: count the work, not
     * the verdict). A hatch that silently draws nothing — because the mass is tiny, or because
     * `repeatsFor` floored to a count of zero — is indistinguishable BY EYE from the flat-fill
     * defect this whole section exists to remove, and CourtcardCard's own §22b-1b note records
     * that the natural response to a silent no-op is to go and re-author geometry that was never
     * fully drawn. `_probe/engrave_check.js` asserts the total is non-zero across the corpus.
     *
     * @param {CanvasRenderingContext2D} ctx @param {object} F @param {number[][]} pts unit points
     * @param {object} P palette @param {number} figureInk @param {number} lean the build's lean
     * @returns {number} hatch lines actually stroked
     */
    function engrave(ctx, F, pts, P, figureInk, lean) {
        var K = deps().ink;
        // toward the shadow, in the ROTATED space the masses are drawn in
        var la = Math.atan2(K.LIGHT.dir[1], K.LIGHT.dir[0]) - lean;
        var d = [-Math.cos(la), -Math.sin(la)];
        var e = [-d[1], d[0]];

        var i, sMin = Infinity, sMax = -Infinity, uMin = Infinity, uMax = -Infinity;
        for (i = 0; i < pts.length; i++) {
            var s = pts[i][0] * d[0] + pts[i][1] * d[1];
            var u = pts[i][0] * e[0] + pts[i][1] * e[1];
            if (s < sMin) sMin = s;
            if (s > sMax) sMax = s;
            if (u < uMin) uMin = u;
            if (u > uMax) uMax = u;
        }

        // ⚠️ A MASS TOO SMALL TO HOLD SEPARATED LINES MUST BE LEFT ALONE, NOT HATCHED FINER. Below
        // roughly three pitches the lines merge into a smudge that reads as a dirty fill, which is
        // worse than the flat fill it replaced. This is §22b-1a's floor doing its job: it returns 0
        // and the count makes the abstention visible instead of silent.
        var span = (sMax - sMin) * F.r;
        var rep = K.repeatsFor(span, figureInk, 2.55);
        if (rep.count < 3) return 0;

        var run = (uMax - uMin) * F.r;
        var over = (Math.abs(run) / F.r) * 0.6 + 0.12;   // overshoot: the clip decides the ends
        var n = 0;

        ctx.lineCap = 'butt';
        for (i = 0; i < rep.count; i++) {
            var sv = sMin + (i + 0.5) * (rep.pitch / F.r);
            if (sv > sMax) break;
            // 0 at the lit edge, 1 at the deepest shadow
            var t = (sMax - sMin) > 0 ? (sv - sMin) / (sMax - sMin) : 1;
            // the lit third of every mass stays bare wash — that is what makes it read as lit
            if (t < 0.36) continue;
            var g = (t - 0.36) / 0.64;                    // 0..1 across the modelled part
            ctx.beginPath();
            var a0 = F.at(d[0] * sv + e[0] * (uMin - over), d[1] * sv + e[1] * (uMin - over));
            var a1 = F.at(d[0] * sv + e[0] * (uMax + over), d[1] * sv + e[1] * (uMax + over));
            ctx.moveTo(a0[0], a0[1]);
            ctx.lineTo(a1[0], a1[1]);
            ctx.lineWidth = Math.max(0.7, figureInk * (0.34 + g * 0.52));
            ctx.strokeStyle = K.rgba(P.ink, 0.42 + g * 0.5);
            ctx.stroke();
            n++;
        }

        // ── the deepest quarter is CROSS-hatched, which is how an engraver reaches a true dark
        // without simply drawing a black shape. Second family, steeper, coarser pitch.
        var cross = K.repeatsFor(span, figureInk, 4.1);
        var d2 = [Math.cos(la + 1.02), Math.sin(la + 1.02)];
        var e2 = [-d2[1], d2[0]];
        var c0 = Infinity, c1 = -Infinity;
        for (i = 0; i < pts.length; i++) {
            var cs = pts[i][0] * d2[0] + pts[i][1] * d2[1];
            if (cs < c0) c0 = cs;
            if (cs > c1) c1 = cs;
        }
        for (i = 0; i < cross.count; i++) {
            var cv = c0 + (i + 0.5) * (cross.pitch / F.r);
            if (cv > c1) break;
            // only where the PRIMARY axis says it is deep shadow
            var mid = [d2[0] * cv, d2[1] * cv];
            var ts = (mid[0] * d[0] + mid[1] * d[1] - sMin) / ((sMax - sMin) || 1);
            if (ts < 0.74) continue;
            ctx.beginPath();
            var b0 = F.at(d2[0] * cv + e2[0] * (uMin - over), d2[1] * cv + e2[1] * (uMin - over));
            var b1 = F.at(d2[0] * cv + e2[0] * (uMax + over), d2[1] * cv + e2[1] * (uMax + over));
            ctx.moveTo(b0[0], b0[1]);
            ctx.lineTo(b1[0], b1[1]);
            ctx.lineWidth = Math.max(0.7, figureInk * 0.44);
            ctx.strokeStyle = K.rgba(P.ink, 0.5);
            ctx.stroke();
            n++;
        }
        return n;
    }
    D.engrave = engrave;

    /**
     * Re-stroke the SHADOW SIDE of an outline heavier. A weighted contour is most of what separates
     * an illustration from clip art, and it costs one extra stroke.
     *
     * ⛔ THE SIDE IS CHOSEN BY A CLIP, NOT BY EDGE WINDING. Deciding per-edge from a normal is
     * winding-dependent, and a point list authored the other way round would weight the LIT side —
     * a defect that looks like bad art and that no count can see. A half-plane clip is true for
     * both windings, and for a `smooth` blob as well, where per-edge normals are wrong anyway
     * because the drawn curve is not the segment between two authored points.
     */
    function contour(ctx, F, pts, P, pen, lean, smooth) {
        var K = deps().ink;
        var la = Math.atan2(K.LIGHT.dir[1], K.LIGHT.dir[0]) - lean;
        var d = [-Math.cos(la), -Math.sin(la)];
        var e = [-d[1], d[0]];
        var i, cx = 0, cy = 0;
        for (i = 0; i < pts.length; i++) { cx += pts[i][0]; cy += pts[i][1]; }
        cx /= pts.length; cy /= pts.length;
        var BIG = 6;
        // the half-plane starting a little past the centroid, on the shadow side
        var o = [cx + d[0] * 0.10, cy + d[1] * 0.10];
        ctx.save();
        ctx.beginPath();
        var q = [
            F.at(o[0] + e[0] * BIG, o[1] + e[1] * BIG),
            F.at(o[0] - e[0] * BIG, o[1] - e[1] * BIG),
            F.at(o[0] - e[0] * BIG + d[0] * BIG, o[1] - e[1] * BIG + d[1] * BIG),
            F.at(o[0] + e[0] * BIG + d[0] * BIG, o[1] + e[1] * BIG + d[1] * BIG)
        ];
        ctx.moveTo(q[0][0], q[0][1]);
        for (i = 1; i < 4; i++) ctx.lineTo(q[i][0], q[i][1]);
        ctx.closePath();
        ctx.clip();
        (smooth ? blob : poly)(ctx, F, pts);
        ctx.lineWidth = pen * 1.75;
        ctx.lineJoin = 'round';
        ctx.lineCap = 'round';
        ctx.strokeStyle = K.css(P.ink);
        ctx.stroke();
        ctx.restore();
    }
    D.contour = contour;

    /**
     * Fill an outline and outline it with a pen SIZED BY THE SHAPE (§22a-2f-1).
     *
     * `model` is opt-in and is passed ONLY by the masses loop in `D.draw`. The element CUTS call
     * this too, and a flame tongue or a drip must NOT be engraved: a cut is a mark ON the charge,
     * so giving it its own interior tone would make it read as a second solid object sitting on
     * top rather than as something done to the first.
     *
     * @param {CanvasRenderingContext2D} ctx @param {object} F @param {number[][]} pts
     * @param {object} P palette {body, ink, lit, dark}
     * @param {number} figureInk the product's base ink width in px
     * @param {boolean} [smooth] trace as a smooth blob rather than a polygon
     * @param {number[]} [fillWith] override the fill colour
     * @param {{lean:number}} [model] engrave the interior, lit by `K.LIGHT`
     * @returns {number} hatch lines stroked inside this mass (0 when not modelled)
     */
    function shape(ctx, F, pts, P, figureInk, smooth, fillWith, model) {
        var K = deps().ink;
        var minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
        for (var i = 0; i < pts.length; i++) {
            if (pts[i][0] < minX) minX = pts[i][0];
            if (pts[i][0] > maxX) maxX = pts[i][0];
            if (pts[i][1] < minY) minY = pts[i][1];
            if (pts[i][1] > maxY) maxY = pts[i][1];
        }
        var w = (maxX - minX) * F.r, h = (maxY - minY) * F.r;
        var pen = K.penFor(figureInk, w, h);
        (smooth ? blob : poly)(ctx, F, pts);
        ctx.fillStyle = K.css(fillWith || P.body);
        ctx.fill();

        // ⛔ HATCH BETWEEN THE FILL AND THE STROKE. An outline is centred on its path, so half its
        // width lies INSIDE the shape; hatching drawn after the stroke crosses it and the figure
        // loses its edge. Fill, tone, then outline — the order an engraver works in.
        var hatched = 0;
        if (model) {
            ctx.save();
            (smooth ? blob : poly)(ctx, F, pts);
            ctx.clip();
            hatched = engrave(ctx, F, pts, P, figureInk, model.lean);
            ctx.restore();
        }

        (smooth ? blob : poly)(ctx, F, pts);
        ctx.lineWidth = pen;
        ctx.lineJoin = 'round';
        ctx.strokeStyle = K.css(P.ink);
        ctx.stroke();

        if (model) contour(ctx, F, pts, P, pen, model.lean, smooth);
        return hatched;
    }
    D.shape = shape;

    /** A stroked line in unit space, pen sized by its own run. */
    function line(ctx, F, a, b, P, figureInk, mul) {
        var K = deps().ink;
        var run = Math.sqrt(Math.pow((b[0] - a[0]) * F.r, 2) + Math.pow((b[1] - a[1]) * F.r, 2));
        ctx.beginPath();
        var p = F.at(a[0], a[1]), q = F.at(b[0], b[1]);
        ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]);
        ctx.lineWidth = Math.max(0.9, Math.min(figureInk * (mul || 1), run * 0.10));
        ctx.lineCap = 'round';
        ctx.strokeStyle = K.css(P.ink);
        ctx.stroke();
    }
    D.line = line;

    // ─────────────────────────────────────────────────────── THE TWELVE BUILDS
    //
    // Each returns { masses: [{pts, smooth, fill}], marks: [[a,b,mul]] } in unit space, so a build
    // is DATA the renderer draws rather than a pile of ctx calls. That is what lets `axis_reads`
    // ask whether a value landed a mark without rendering anything (§25a), and what lets
    // `silhouette_distance` compare two builds' outlines without a canvas.

    var BUILDS = {};

    /** A blade driving down-left, with an impact scatter under its point. */
    BUILDS.strike = function (t) {
        var m = [], k = [];
        // one continuous blade outline: tip low-left, spine up-right, so it never pairs
        m.push({ pts: [[-0.62, 0.98], [-0.16, -0.10], [0.06, -0.62], [0.22, -0.60], [0.14, -0.02], [-0.40, 1.06]], smooth: false });
        // cross-guard, overlapping the blade rather than abutting it (§22a-1b rule 2)
        m.push({ pts: rotAll(limb([-0.34, -0.42], [0.52, -0.66], 0.085, 0.075), 0), smooth: false });
        // grip and pommel, stepping out at the pommel so the outline says "hand ends here"
        m.push({ pts: limb([0.10, -0.56], [0.40, -1.06], 0.055, 0.050), smooth: false });
        m.push({ pts: [[0.34, -1.04], [0.48, -1.12], [0.56, -1.02], [0.44, -0.94]], smooth: true });
        // impact scatter: chips of DELIBERATELY unequal length, radiating from the point
        var chips = [[0.30, 0.36], [0.62, 0.16], [0.24, -0.30], [0.46, -0.10], [0.16, 0.55]];
        for (var i = 0; i < chips.length; i++) {
            var a = -0.9 + i * 0.36, L = chips[i][0];
            k.push([[-0.55 + chips[i][1] * 0.2, 1.02], [-0.55 + Math.cos(a) * L, 1.02 + Math.sin(a) * L * 0.5], 0.8]);
        }
        return { masses: m, marks: k, lean: t.lean };
    };

    /** A tower shield turned three-quarter, boss off centre, a bracing bar breaking its outline. */
    BUILDS.guard = function (t) {
        var m = [], k = [];
        m.push({
            pts: [[-0.62, -0.92], [0.58, -0.98], [0.66, -0.10], [0.40, 0.72], [0.02, 1.14],
                [-0.44, 0.66], [-0.66, -0.12]], smooth: true
        });
        // the boss sits LEFT of centre — a centred boss would pair the shield about its axis
        m.push({ pts: [[-0.34, -0.24], [-0.10, -0.34], [0.02, -0.12], [-0.14, 0.06], [-0.38, -0.02]], smooth: true });
        // the bracing bar projects BEYOND the shield (§22c: two shapes read as two only if their
        // outlines break each other)
        m.push({ pts: limb([-0.86, 0.34], [0.74, 0.02], 0.070, 0.052), smooth: false });
        k.push([[-0.50, -0.72], [0.44, -0.80], 0.9]);
        k.push([[-0.54, -0.44], [0.52, -0.52], 0.7]);
        return { masses: m, marks: k, lean: t.lean };
    };

    /** An open hand with a sigil arc springing off the fingertips. */
    BUILDS.spell = function (t) {
        var m = [], k = [];
        // palm and four fingers as ONE outline, thumb added on ONE side only
        m.push({
            pts: [[-0.36, 0.98], [-0.42, 0.20], [-0.40, -0.34], [-0.24, -0.36], [-0.20, -0.02],
                [-0.10, -0.52], [0.04, -0.52], [0.04, -0.06], [0.16, -0.60], [0.30, -0.56],
                [0.22, -0.02], [0.34, -0.36], [0.46, -0.28], [0.34, 0.28], [0.24, 0.92]], smooth: true
        });
        m.push({ pts: limb([-0.36, 0.44], [-0.78, 0.06], 0.090, 0.060), smooth: true });
        // the sigil arc: marks on a curve, each a DIFFERENT length, breaking off to the upper right
        for (var i = 0; i < 6; i++) {
            var a = -1.32 + i * 0.30;
            var R0 = 0.72 + (i % 2) * 0.11, R1 = R0 + 0.16 + (i % 3) * 0.06;
            k.push([[Math.cos(a) * R0 + 0.06, Math.sin(a) * R0 - 0.16],
                [Math.cos(a) * R1 + 0.06, Math.sin(a) * R1 - 0.16], 0.85]);
        }
        return { masses: m, marks: k, lean: t.lean };
    };

    /** An arch with a horned mass rising through it and breaking its inner line. */
    BUILDS.summon = function (t) {
        var m = [], k = [];
        // piers and a round head, drawn as one reserved outline
        m.push({
            pts: [[-0.72, 1.14], [-0.72, -0.30], [-0.50, -0.74], [0.00, -0.94], [0.50, -0.74],
                [0.72, -0.30], [0.72, 1.14], [0.48, 1.14], [0.48, -0.22], [0.30, -0.56],
                [0.00, -0.68], [-0.30, -0.56], [-0.48, -0.22], [-0.48, 1.14]], smooth: false
        });
        // the mass rising through it, OFFSET so it never centres in the opening
        m.push({ pts: [[-0.30, 1.10], [-0.26, 0.28], [-0.06, 0.02], [0.24, 0.16], [0.30, 1.10]], smooth: true });
        // two horns of UNEQUAL length breaking the arch's inner line
        m.push({ pts: limb([-0.20, 0.10], [-0.52, -0.62], 0.062, 0.020), smooth: true });
        m.push({ pts: limb([0.14, 0.06], [0.40, -0.40], 0.058, 0.018), smooth: true });
        k.push([[-0.14, 0.44], [0.14, 0.44], 0.8]);
        return { masses: m, marks: k, lean: t.lean };
    };

    /**
     * A snapped shaft bound by cord, the binding drawn as SEPARATE OVERLAPPING BANDS.
     *
     * ⛔ PASS 1 READ AS A SPOON, THEN AS A LOLLIPOP. It authored the binding as two closed loops,
     * which merge into one lump the moment they are filled — §22c: in a one-colour figure two
     * shapes only read as two if their OUTLINES BREAK EACH OTHER. A knot is not a lump; it is a
     * cord whose bands cross one another, and it is read from the crossings.
     */
    BUILDS.curse = function (t) {
        var m = [], k = [], i;
        // the shaft, snapped: two pieces on DIFFERENT axes so the break is a change of direction
        m.push({ pts: limb([-0.16, -1.08], [-0.02, -0.24], 0.070, 0.066), smooth: false });
        m.push({ pts: [[-0.10, -0.30], [0.10, -0.16], [-0.04, -0.06], [-0.18, -0.18]], smooth: false });
        m.push({ pts: limb([0.14, 0.34], [0.34, 1.06], 0.064, 0.070), smooth: false });
        m.push({ pts: [[0.04, 0.42], [0.24, 0.26], [0.28, 0.40], [0.12, 0.50]], smooth: false });
        // FOUR cord bands crossing the break at different angles, each a limb with its own outline
        var bands = [[-0.52, 0.02, 0.42, -0.10], [-0.46, 0.20, 0.46, 0.10],
            [-0.38, 0.36, 0.40, 0.28], [-0.30, -0.14, 0.30, -0.24]];
        for (i = 0; i < bands.length; i++) {
            var b = bands[i];
            m.push({ pts: limb([b[0], b[1]], [b[2], b[3]], 0.052, 0.046), smooth: true });
        }
        // loose ends falling to ONE side, tapering to nothing
        k.push([[-0.46, 0.30], [-0.74, 0.84], 1.1]);
        k.push([[-0.38, 0.38], [-0.56, 1.00], 0.8]);
        return { masses: m, marks: k, lean: t.lean };
    };

    /** A vessel tipped to pour, the stream falling clear into a shallow bowl. */
    BUILDS.mend = function (t) {
        var m = [], k = [];
        // ── the ewer as ONE outline.
        //
        // ⛔ A POT IS READ FROM ITS NECK, AND `smooth: true` DESTROYS A NECK. Pass 1 ran the belly
        // straight into the lip and read as a bird's head; pass 2 authored a proper lip-neck-
        // shoulder profile and STILL read as an oven mitt, because Catmull-Rom interpolates THROUGH
        // its points and rounds off exactly the direction change that makes a step a step. The
        // geometry was right both times and the tracer was wrong — §12 rule 3, a test can be the
        // bug, pointed at a drawing primitive. A struck vessel is drawn with straight runs and hard
        // shoulders anyway, so `smooth: false` is both the fix and the correct engraving.
        m.push({
            pts: [[-0.60, -1.02], [-0.14, -1.02],                    // the lip, flat and flaring
                [-0.26, -0.86], [-0.30, -0.86],                      // under the lip, stepping IN
                [-0.30, -0.58],                                      // the neck: a real straight run
                [-0.06, -0.40], [0.14, -0.10],                       // shoulder, stepping OUT
                [0.18, 0.12], [0.04, 0.32],                          // belly
                [-0.30, 0.38], [-0.52, 0.36],                        // the foot, narrower than the belly
                [-0.62, 0.16], [-0.66, -0.18], [-0.62, -0.62]], smooth: false
        });
        // handle: a loop that OVERLAPS the body and ENCLOSES PAPER, so it cannot merge with it
        // (§22c — two shapes read as two only if their outlines break each other)
        m.push({ pts: [[-0.58, -0.50], [-0.96, -0.36], [-0.94, 0.06], [-0.62, 0.10],
            [-0.72, -0.08], [-0.76, -0.30]], smooth: true });
        // the shallow bowl at the lower right, a different mass shape entirely
        m.push({ pts: [[0.06, 0.74], [0.86, 0.74], [0.72, 1.06], [0.20, 1.06]], smooth: false });
        // the stream: a falling ribbon leaving the LIP, thick at the spout and thinning as it falls
        m.push({ pts: limb([-0.30, -0.98], [0.44, 0.70], 0.052, 0.028), smooth: true });
        k.push([[0.16, 0.86], [0.74, 0.86], 0.7]);
        return { masses: m, marks: k, lean: t.lean };
    };

    /**
     * A sprung snare: a heavy base plate, two TOOTHED COMBS pivoting up, and a taut line.
     *
     * ⛔ PASS 1 READ AS THE LETTER C, IN ALL FOUR CELLS. It authored two smooth bowed arcs facing
     * one another, and two facing arcs ARE a ring — §22a's own table, where a rounded base with two
     * curved points became a crescent. The teeth were interior marks, and §22c is explicit that
     * interior detail cannot separate two masses at reading size.
     *
     * ⭐ THE FIX IS THE ONE §22a-3 PRESCRIBES: put the difference in the TRAILING EDGE. The jaws
     * are now toothed COMBS whose teeth are part of the outline rather than scratches inside it, so
     * the silhouette itself says "sprung", and a rectangular base plate at the foot breaks the
     * circular gestalt that made the pair read as one letter.
     */
    BUILDS.trap = function (t) {
        var m = [], k = [], i;
        // the base plate: a flat, heavy, unmistakably straight-sided mass at the foot
        m.push({ pts: [[-0.82, 0.72], [0.78, 0.72], [0.86, 1.02], [-0.90, 1.02]], smooth: false });
        m.push({ pts: [[-0.34, 0.52], [0.30, 0.52], [0.34, 0.74], [-0.38, 0.74]], smooth: false });

        // ── the LOWER comb, laid back to the left. Teeth are POINTS ON THE OUTLINE.
        var lower = [[-0.80, 0.66]];
        for (i = 0; i < 6; i++) {
            var lx = -0.72 + i * 0.27;
            lower.push([lx, 0.28 - (i % 2) * 0.10]);          // tooth tip
            lower.push([lx + 0.135, 0.56]);                    // gullet
        }
        lower.push([0.76, 0.66]);
        m.push({ pts: lower, smooth: false });

        // ── the UPPER comb, thrown OPEN at a steep angle so the pair never mirrors
        var upper = [[-0.86, -0.10]];
        for (i = 0; i < 6; i++) {
            var ux = -0.78 + i * 0.25;
            upper.push([ux, -0.52 - (i % 3) * 0.09]);
            upper.push([ux + 0.125, -0.24]);
        }
        upper.push([0.62, -0.34]);
        m.push({ pts: rotAll(movAll(upper, 0, 0.10), -0.34), smooth: false });

        // the hinge, overlapping both combs at one end only
        m.push({ pts: [[-0.98, -0.06], [-0.62, -0.14], [-0.56, 0.54], [-0.94, 0.60]], smooth: false });
        // the taut line, running clear off the field to the upper right
        k.push([[-0.76, 0.16], [0.98, -0.92], 1.2]);
        return { masses: m, marks: k, lean: t.lean };
    };

    /**
     * A censer hanging on a chain, its lid pierced, vapour rising to one side.
     *
     * ⛔⛔ THIS IS THE THIRD SUBJECT FOR THIS SLOT, AND CHANGING THE SUBJECT IS THE FIX §22a-5b
     * PRESCRIBES — "ask on pass 2, not pass 5". A mantle failed twice, differently each time, which
     * is itself the tell that the SUBJECT was wrong rather than the numbers:
     *
     *   pass 1  a smooth yoke abutting a smooth cloth mass    -> read as a THUMB, then a SNAIL
     *   pass 2  the same cloth given five unequal hem folds   -> read as a HAND. Five downward
     *           points off a rounded mass ARE fingers (§22a's table, arrived at from a new
     *           direction) and the folds could not have been made to read as cloth at 120px.
     *
     * ⭐ A censer says the same thing a mantle was trying to say — something carried WITH a figure
     * and around it — and it has three cues nothing else in this corpus owns: it HANGS, it is
     * suspended on CHAINS, and its lid is PIERCED. §22a-2c is satisfied by position rather than by
     * shaping, which is the only thing that has ever worked on this axis.
     */
    BUILDS.aura = function (t) {
        var m = [], k = [], i;
        // the suspension ring at the top — nothing else in this corpus hangs from anything
        m.push({ pts: (function () {
            var p = [];
            for (var j = 0; j < 14; j++) {
                var a = j * Math.PI / 7;
                var R = j % 2 ? 0.085 : 0.125;
                p.push([-0.02 + Math.cos(a) * R, -1.06 + Math.sin(a) * R]);
            }
            return p;
        }()), smooth: true });

        // three chains of UNEQUAL slack, converging on the ring
        var anchors = [[-0.52, -0.16], [0.02, -0.06], [0.50, -0.20]];
        for (i = 0; i < anchors.length; i++) {
            k.push([[-0.02, -0.94], [anchors[i][0] * 0.7, anchors[i][1] - 0.34], 0.85]);
            k.push([[anchors[i][0] * 0.7, anchors[i][1] - 0.34], anchors[i], 0.85]);
        }

        // the lid: a low dome, stepping OUT to a rim so the outline says "this opens"
        m.push({ pts: [[-0.54, -0.14], [-0.40, -0.44], [0.00, -0.56], [0.40, -0.44], [0.54, -0.14]], smooth: true });
        m.push({ pts: [[-0.62, -0.18], [0.62, -0.18], [0.60, -0.02], [-0.60, -0.02]], smooth: false });
        // the bowl, wider than the lid and standing on a foot
        m.push({ pts: [[-0.58, -0.04], [0.58, -0.04], [0.42, 0.54], [-0.42, 0.54]], smooth: false });
        m.push({ pts: [[-0.26, 0.52], [0.26, 0.52], [0.36, 0.86], [-0.36, 0.86]], smooth: false });
        m.push({ pts: [[-0.48, 0.84], [0.48, 0.84], [0.52, 1.04], [-0.52, 1.04]], smooth: false });

        // ⛔ the lid's PIERCING, drawn as real holes in the lid rather than as scratches on it
        for (i = 0; i < 5; i++) {
            var px = -0.34 + i * 0.17;
            var py = -0.26 - Math.cos((i - 2) * 0.8) * 0.14;
            m.push({ pts: [[px - 0.045, py], [px, py - 0.075], [px + 0.045, py], [px, py + 0.075]],
                smooth: true, fill: 'ink' });
        }
        // vapour: three curls leaving the lid on ONE side only, of unequal length
        for (i = 0; i < 3; i++) {
            k.push([[0.10 + i * 0.10, -0.52], [0.34 + i * 0.16, -0.78 - i * 0.14], 0.8]);
            k.push([[0.34 + i * 0.16, -0.78 - i * 0.14], [0.20 + i * 0.14, -0.96 - i * 0.10], 0.7]);
        }
        return { masses: m, marks: k, lean: t.lean };
    };

    /** A key laid across a stepped plinth with one step broken away. */
    BUILDS.relic = function (t) {
        var m = [], k = [];
        // the plinth: three steps, the RIGHTMOST broken, so the outline never mirrors
        m.push({ pts: [[-0.86, 0.44], [0.72, 0.44], [0.72, 0.64], [0.86, 0.64], [0.86, 0.86], [0.60, 0.86], [0.52, 1.12], [-0.92, 1.12], [-0.92, 0.86], [-0.86, 0.86]], smooth: false });
        // the key, laid on the DIAGONAL: bow at upper left, bit at lower right
        m.push({ pts: [[-0.56, -0.86], [-0.24, -0.98], [-0.02, -0.74], [-0.18, -0.48], [-0.50, -0.52]], smooth: true });
        m.push({ pts: [[-0.44, -0.74], [-0.28, -0.78], [-0.24, -0.64], [-0.40, -0.62]], smooth: true });
        m.push({ pts: limb([-0.24, -0.62], [0.46, 0.24], 0.048, 0.042), smooth: false });
        m.push({ pts: [[0.34, 0.10], [0.54, 0.02], [0.60, 0.16], [0.44, 0.24]], smooth: false });
        m.push({ pts: [[0.42, 0.22], [0.62, 0.14], [0.66, 0.26], [0.50, 0.34]], smooth: false });
        k.push([[-0.80, 0.56], [0.62, 0.56], 0.7]);
        k.push([[-0.86, 0.98], [0.46, 0.98], 0.7]);
        return { masses: m, marks: k, lean: t.lean };
    };

    /**
     * A clawed paw print: one heel pad and four toes on a tilted arc, each carrying a claw.
     *
     * ⛔⛔ THIS SLOT TOOK FOUR SUBJECTS, AND THE RECORD OF WHY IS THE USEFUL PART.
     *
     *   pass 1  a horned skull in profile, horn forward      -> read as a DOLPHIN
     *   pass 2  the same head re-posed vertical, spiral horn -> read as a BIRD'S HEAD with a bun
     *   pass 3  a coiled serpent rising from two loops       -> read as a HERON STANDING ON A LOG
     *           (the coil's overlapping bands fused into one horizontal bar, and the raised head
     *           plus forked tongue became a neck and a beak)
     *
     * ⭐ THREE DIFFERENT WRONG READINGS IS §22a-5b'S OWN TELL THAT THE SUBJECT IS WRONG RATHER
     * THAN THE NUMBERS — "the failures were different each time" — and §22a-5 says outright that a
     * candidate with no unoccupied position left is NOT A FIGURE and no number of passes will make
     * it one. ⚠️ Pass 3 was itself chosen on §22a-5's measured advice that reptiles land in one or
     * two passes where mammals do not; that advice is about whole ANIMALS, and a serpent reduced to
     * a coil plus a head is a chain of masses, which is §22a-1b rather than §22a-5.
     *
     * ⭐ A PRINT IS NOT AN ANIMAL, WHICH IS EXACTLY WHY IT WORKS. It carries no proportion to lose
     * at reading size, its gestalt is one of the most over-learned in the world, and nothing else in
     * this corpus is a CLUSTER OF ROUNDED MASSES. The toes are unequal and sit on a TILTED arc, so
     * the group cannot pair about the vertical axis the way §22a's spectacles did.
     */
    BUILDS.beast = function (t) {
        var m = [], k = [], i;

        // ── the heel pad: ONE large mass with a notch cut into its upper edge, so it is a pad and
        // not a disc. It is wider than it is tall, which is what separates a paw from a face.
        m.push({
            pts: [[-0.46, 0.20], [-0.16, 0.06], [0.00, 0.22], [0.18, 0.04], [0.48, 0.20],
                [0.62, 0.60], [0.34, 0.96], [-0.30, 0.98], [-0.60, 0.62]], smooth: true
        });

        // ── four toes on a TILTED arc, of unequal size, each with a claw ABOVE it. The arc's tilt
        // and the size gradient are what keep the group from pairing about a vertical axis (§22a).
        var toes = [
            { x: -0.72, y: -0.10, r: 0.19, claw: 0.30, a: -2.55 },
            { x: -0.30, y: -0.42, r: 0.23, claw: 0.38, a: -1.95 },
            { x: 0.16, y: -0.50, r: 0.22, claw: 0.35, a: -1.42 },
            { x: 0.58, y: -0.22, r: 0.17, claw: 0.26, a: -0.85 }
        ];
        for (i = 0; i < toes.length; i++) {
            var to = toes[i];
            var p = [];
            for (var j = 0; j < 12; j++) {
                var aa = j * Math.PI / 6;
                // slightly egg-shaped and rotated toward the claw, so a toe points somewhere
                p.push([to.x + Math.cos(aa) * to.r * 0.92, to.y + Math.sin(aa) * to.r * 1.10]);
            }
            m.push({ pts: p, smooth: true });
            // the claw: a sharp triangle rooted INSIDE the toe (§22a-1b rule 2, appendages overlap
            // the mass they grow from) and reaching outward along the arc's normal
            var cx2 = to.x + Math.cos(to.a) * to.r * 0.55;
            var cy2 = to.y + Math.sin(to.a) * to.r * 0.55;
            var tx = to.x + Math.cos(to.a) * (to.r + to.claw);
            var ty = to.y + Math.sin(to.a) * (to.r + to.claw);
            var nx3 = -Math.sin(to.a) * to.r * 0.42, ny3 = Math.cos(to.a) * to.r * 0.42;
            m.push({ pts: [[cx2 + nx3, cy2 + ny3], [tx, ty], [cx2 - nx3 * 0.55, cy2 - ny3 * 0.55]], smooth: false });
        }

        // pad creases — cut INTO the heel pad rather than laid on it (§22a-2b rule 2)
        k.push([[-0.20, 0.46], [-0.06, 0.74], 0.7]);
        k.push([[0.16, 0.44], [0.06, 0.76], 0.7]);
        return { masses: m, marks: k, lean: t.lean };
    };

    /**
     * A winged boot in profile with a rowel spur at the heel.
     *
     * ⛔ PASS 1 READ AS A BEETROOT WITH A STAR. There was no boot in it — an ankle blob, a stick
     * and a cog — and §22c's law for a TOOL is the one that was ignored: a tool is read from the
     * JOINT, and a shape only reads as footwear if it has the two features that define one, a FLAT
     * SOLE and a HEEL BREAK. A rounded mass with a spike is a root vegetable.
     */
    BUILDS.rush = function (t) {
        var m = [], k = [], i;
        // ── the boot as ONE outline: cuff, shin, instep, toe, then a FLAT SOLE and a HEEL BREAK
        m.push({
            pts: [[-0.34, -0.78], [0.14, -0.86], [0.22, -0.40], [0.26, 0.06], [0.62, 0.22],
                [0.80, 0.34], [0.78, 0.52], [0.10, 0.56], [-0.06, 0.52], [-0.10, 0.30],
                [-0.30, 0.28], [-0.34, 0.52], [-0.52, 0.50], [-0.48, 0.06], [-0.42, -0.40]],
            smooth: false
        });
        // the cuff, stepping OUT above the shin so the outline says "the leg ends here"
        m.push({ pts: [[-0.46, -0.92], [0.24, -1.02], [0.28, -0.74], [-0.42, -0.66]], smooth: false });
        // ── the spur neck and rowel, at the HEEL and pointing back — a spur has a direction.
        //
        // ⛔ THE REACH IS BUDGETED, NOT EYEBALLED. `corpus_check` arm 4 measured this build at a fit
        // scale of 0.766 while ten of its eleven siblings sat at 1.00 — the wing and the rowel were
        // authored past x = -1.34 against a bound of 1.0, so the auto-fit shrank the WHOLE boot by
        // a quarter and it rendered as a smaller object on an otherwise identical card. That is a
        // SET defect (§22f) and no single cell can show it. Everything below is inside |x| <= 0.96.
        m.push({ pts: limb([-0.42, 0.34], [-0.68, 0.42], 0.046, 0.032), smooth: false });
        m.push({ pts: (function () {
            var p = [];
            for (var j = 0; j < 12; j++) {
                var a = j * Math.PI / 6, R = (j % 2 ? 0.065 : 0.145);
                p.push([-0.80 + Math.cos(a) * R, 0.44 + Math.sin(a) * R]);
            }
            return p;
        }()), smooth: false });
        // ── the wing, growing from the ANKLE and trailing back, primaries notching the TRAILING
        // EDGE (§22a-3: two winged things are told apart by the outline, never by interior detail)
        var wing = [[-0.30, -0.34]];
        for (i = 0; i < 5; i++) {
            var L = 0.36 + i * 0.085;
            wing.push([-0.26 - L, -0.52 + i * 0.20]);        // primary tip
            wing.push([-0.26 - L * 0.70, -0.40 + i * 0.20]); // the notch between two primaries
        }
        wing.push([-0.34, 0.30]);
        m.push({ pts: wing, smooth: false });
        for (i = 0; i < 4; i++) {
            k.push([[-0.36, -0.28 + i * 0.17], [-0.60 - i * 0.06, -0.34 + i * 0.19], 0.7]);
        }
        // the sole's own line, which is what makes the flat edge read as a sole rather than a base
        k.push([[-0.48, 0.40], [0.72, 0.42], 0.9]);
        return { masses: m, marks: k, lean: t.lean };
    };

    /** A leaning column snapped through, its drums scattered at the foot. */
    BUILDS.ruin = function (t) {
        // ⛔ RE-AUTHORED 2026-09-05, AND THE OLD VERSION IS THE TEXTBOOK CASE OF §22a-1b. The
        // capital was placed at y -1.14..-0.74 while the nearest mass below it — the fallen drum —
        // topped out at y -0.23, leaving a 0.5-unit gap of open paper UNDER it. §22a-1b's rule is
        // that "every appendage OVERLAPS the mass it grows from rather than abutting it", and this
        // did not even abut: on the contact sheet it read as a pebble hovering in the top-right
        // corner, which is why `ruin` was the least legible of the twelve builds.
        //
        // ⚠️ AND THE FLOAT WAS ONLY HALF OF IT. The stump broke off at y = -0.06 — the vertical
        // middle of a box running to -1.30 — so the entire upper half of the device field was
        // empty except for that floating chip. §18b is about a scene wasting its frame; the same
        // arithmetic applies to a figure wasting its box, and here the two defects were causing
        // each other, because the capital had been pushed up there to fill the hole the short
        // stump left.
        //
        // Both are fixed by the composition a toppled column actually makes: a TALL standing stump
        // that owns the box and breaks near the top, with the drum lying across its foot and the
        // capital tumbled ON the drum, each overlapping the last. Extents stay inside BOUND_X 1.0
        // and BOUND_Y 1.30, so `fitScale` is untouched and this build does not fall out of family
        // with its siblings (§22f).
        var m = [], k = [];
        // the standing stump, LEANING, tall enough to own the field, with a jagged break at the top
        m.push({ pts: [[-0.44, 1.06], [-0.36, -0.24], [-0.30, -0.62], [-0.19, -0.86], [-0.07, -0.58], [0.00, -0.18], [0.08, 1.06]], smooth: false });
        // the base, stepping out
        m.push({ pts: [[-0.60, 1.06], [0.24, 1.06], [0.30, 1.24], [-0.66, 1.24]], smooth: false });
        // the fallen upper drum, lying across the stump's foot and OVERLAPPING it
        m.push({ pts: rotAll([[-0.12, 0.42], [0.80, 0.42], [0.80, 0.76], [-0.12, 0.76]], -0.22), smooth: false });
        // the capital, tumbled, RESTING ON the drum and overlapping it — a different shape from it
        m.push({ pts: [[0.52, 0.30], [0.92, 0.22], [0.98, 0.52], [0.76, 0.62], [0.50, 0.54]], smooth: true });
        // flutes: a repeated treatment, so the count is DERIVED by the renderer, not typed here
        k.push([[-0.34, 0.06], [-0.30, 0.98], 0.7]);
        k.push([[-0.19, -0.16], [-0.13, 0.98], 0.7]);
        k.push([[-0.03, -0.08], [0.01, 0.98], 0.7]);
        return { masses: m, marks: k, lean: t.lean };
    };

    D.BUILDS = BUILDS;

    /**
     * Build the unit-space geometry for a card's device.
     * @param {object} spec {type, element}
     * @returns {{masses:Array, marks:Array, lean:number}}
     */
    D.geometry = function (spec) {
        var C = deps().corpus;
        var t = C.type(spec.type);
        if (!t) throw new Error('CourtcardDevice: unknown type "' + spec.type + '"');
        var fn = BUILDS[t.build];
        // ⛔ §21c: an unknown id must NEVER crash a buyer's battle, and it must never silently
        // vanish either. A missing build is a defect in THIS product, so it throws in the corpus
        // check and falls back to a plain charge at run time. `corpus_check` proves the set is
        // complete, so the fallback can never be reached by shipped data.
        if (!fn) throw new Error('CourtcardDevice: type "' + t.id + '" declares build "' + t.build + '" and nothing draws it');
        var g = fn(t);
        return { masses: g.masses, marks: g.marks, lean: typeof g.lean === 'number' ? g.lean : 0 };
    };

    // ─────────────────────────────────────────────────────── THE EIGHT CUTS
    //
    // ⛔ A CUT IS STRUCTURAL, NOT A TINT. §21a: a palette is not a composition, and §25f's
    // fixed-palette structure count is what proves it — an element that only recoloured the charge
    // would collapse to ONE picture under that count while `volume()` went on reporting 96.

    var CUTS = {};

    /**
     * ⛔⛔ WHERE A CUT IS ALLOWED TO BE, AND WHY THIS TABLE EXISTS.
     *
     * The first version of this file placed every cut at FIXED unit coordinates spanning the whole
     * device box. MEASURED by looking at `sheet_types_160.png`: `facet` and `strata` ruled straight
     * lines from one side of the CARD to the other, across open paper, over the charge and past it;
     * `tongue` lit flames in mid-air above the charge; `dissolve` stacked flakes in a column beside
     * it. Nothing was clipped to anything, so the corpus's own sentence — "cut INTO its upper
     * outline", "cut ACROSS the charge" — was false of every one of them (§22b-5: a note is not a
     * drawing instruction, and here the note described a picture the renderer did not draw).
     *
     * A cut is either INSIDE the charge, in which case it is clipped to the union of the charge's
     * own masses and the word "cut" is literally true, or it ESCAPES from a named EDGE of the
     * charge — in which case it is placed against the charge's REAL bounding box, so it attaches
     * whatever the build is and however it leans. §11b is the law underneath: a constant in a
     * figure's coordinate space is an assumption about its pose, and this corpus's whole premise is
     * that twelve builds have twelve different poses.
     */
    var CONTAINMENT = {
        tongue: 'top', facet: 'inside', fork: 'inside', strata: 'inside',
        stream: 'right', pierce: 'inside', dissolve: 'right', drip: 'bottom'
    };
    D.CONTAINMENT = CONTAINMENT;

    /** Flame tongues licking up off the charge's TOP edge. */
    CUTS.tongue = function (ctx, F, bb, P, ink, seed) {
        var K = deps().ink;
        var span = (bb.x1 - bb.x0) * F.r;
        var rep = K.repeatsFor(span * 0.94, ink * 2.2, 3.0);
        var n = 0;
        for (var i = 0; i < rep.count; i++) {
            var u = bb.x0 + (i + 0.5) * (rep.pitch / F.r);
            if (u > bb.x1) break;
            var hgt = 0.20 + K.nz(seed + i * 7) * 0.30;
            var sway = (K.nz(seed + i * 13) - 0.5) * 0.20;
            // seated ON the top edge and rising, so it grows out of the charge rather than hovering
            var base = bb.y0 + 0.05;
            var pts = [[u - 0.050, base], [u + sway * 0.5, base - hgt * 0.55],
                [u + sway, base - hgt], [u + 0.028 + sway * 0.4, base - hgt * 0.45], [u + 0.050, base]];
            shape(ctx, F, pts, P, ink, true, P.lit);
            n++;
        }
        return n;
    };

    /** Straight facet chords cut across the charge. Clipped INSIDE it. */
    CUTS.facet = function (ctx, F, bb, P, ink, seed) {
        var K = deps().ink;
        var run = (bb.y1 - bb.y0) * F.r;
        var rep = K.repeatsFor(run, ink * 1.6, 7.6);
        var n = 0;
        for (var i = 0; i < rep.count; i++) {
            var v = bb.y0 + (i + 0.5) * (rep.pitch / F.r);
            if (v > bb.y1) break;
            var tilt = (i % 2 ? 0.14 : -0.18);
            line(ctx, F, [bb.x0 - 0.10, v], [bb.x1 + 0.10, v + tilt], { ink: P.dark }, ink, 0.75);
            n++;
        }
        return n;
    };

    /** A forked crack splitting the charge from one edge. Clipped INSIDE it. */
    CUTS.fork = function (ctx, F, bb, P, ink, seed) {
        var K = deps().ink;
        var head = [bb.x0 - 0.04, bb.y1 - (bb.y1 - bb.y0) * 0.22];
        var step = (bb.x1 - bb.x0) / 5.5;
        var n = 0;
        for (var i = 0; i < 7; i++) {
            var nx = head[0] + step * (0.8 + K.nz(seed + i * 5) * 0.5);
            var ny = head[1] - (bb.y1 - bb.y0) * (0.10 + K.nz(seed + i * 11) * 0.08);
            line(ctx, F, head, [nx, ny], { ink: P.ink }, ink, 1.4 - i * 0.10);
            n++;
            if (i === 2 || i === 4) {
                line(ctx, F, [nx, ny], [nx + step * 0.4, ny - (bb.y1 - bb.y0) * 0.22], { ink: P.ink }, ink, 0.7);
                n++;
            }
            head = [nx, ny];
        }
        return n;
    };

    /** Horizontal strata bedding the charge into layers. Clipped INSIDE it. */
    CUTS.strata = function (ctx, F, bb, P, ink, seed) {
        var K = deps().ink;
        var run = (bb.y1 - bb.y0) * F.r;
        var rep = K.repeatsFor(run, ink * 2.0, 6.2);
        var n = 0;
        for (var i = 0; i < rep.count; i++) {
            var v = bb.y0 + (i + 0.5) * (rep.pitch / F.r);
            if (v > bb.y1) break;
            var jog = bb.x0 + (bb.x1 - bb.x0) * (0.35 + K.nz(seed + i * 3) * 0.3);
            line(ctx, F, [bb.x0 - 0.10, v], [jog, v + 0.015], { ink: P.dark }, ink, 1.0);
            line(ctx, F, [jog + 0.03, v + 0.015], [bb.x1 + 0.10, v - 0.015], { ink: P.dark }, ink, 1.0);
            n++;
        }
        return n;
    };

    /** Open trailing curls drawn off the charge's RIGHT edge. */
    CUTS.stream = function (ctx, F, bb, P, ink, seed) {
        var K = deps().ink;
        var run = (bb.y1 - bb.y0) * F.r * 0.72;
        var rep = K.repeatsFor(run, ink * 2.4, 5.0);
        var n = 0;
        var edge = bb.x1 - 0.04;
        for (var i = 0; i < rep.count; i++) {
            var v = bb.y0 + (bb.y1 - bb.y0) * 0.14 + (i + 0.5) * (rep.pitch / F.r);
            if (v > bb.y1) break;
            var L = 0.34 + K.nz(seed + i * 9) * 0.40;
            ctx.beginPath();
            var a = F.at(edge, v), b = F.at(edge + L * 0.6, v - 0.14), c = F.at(edge + L, v + 0.09);
            ctx.moveTo(a[0], a[1]);
            ctx.quadraticCurveTo(b[0], b[1], c[0], c[1]);
            ctx.lineWidth = Math.max(0.9, ink * (1.15 - i * 0.07));
            ctx.lineCap = 'round';
            ctx.strokeStyle = K.css(P.ink);
            ctx.stroke();
            n++;
        }
        return n;
    };

    /** Pierced holes with rays escaping them. Clipped INSIDE the charge. */
    CUTS.pierce = function (ctx, F, bb, P, ink, seed) {
        var K = deps().ink;
        var span = (bb.x1 - bb.x0) * F.r;
        var rep = K.repeatsFor(span * 0.86, ink * 3.0, 4.0);
        var n = 0;
        for (var i = 0; i < rep.count; i++) {
            var u = bb.x0 + (i + 0.5) * (rep.pitch / F.r);
            if (u > bb.x1) break;
            var v = bb.y0 + (bb.y1 - bb.y0) * (0.22 + K.nz(seed + i * 17) * 0.56);
            var R = 0.046 + K.nz(seed + i * 23) * 0.026;
            var pts = [];
            for (var j = 0; j < 8; j++) {
                var a = j * Math.PI / 4;
                pts.push([u + Math.cos(a) * R, v + Math.sin(a) * R]);
            }
            shape(ctx, F, pts, P, ink, true, P.ground);
            // rays escaping the hole, alternating long and short so nothing pairs (§22a)
            for (var k2 = 0; k2 < 6; k2++) {
                var ra = k2 * Math.PI / 3 + 0.3;
                var L = R * (k2 % 2 ? 3.2 : 1.9);
                line(ctx, F, [u + Math.cos(ra) * R * 1.25, v + Math.sin(ra) * R * 1.25],
                    [u + Math.cos(ra) * L, v + Math.sin(ra) * L], { ink: P.ink }, ink, 0.6);
            }
            n++;
        }
        return n;
    };

    /** The charge dissolving into detached flakes off its RIGHT edge. */
    CUTS.dissolve = function (ctx, F, bb, P, ink, seed) {
        var K = deps().ink;
        var run = (bb.y1 - bb.y0) * F.r;
        var rep = K.repeatsFor(run, ink * 2.6, 3.2);
        var n = 0;
        for (var i = 0; i < rep.count; i++) {
            var v = bb.y0 + (i + 0.5) * (rep.pitch / F.r);
            if (v > bb.y1) break;
            // flakes leave from the edge and travel further as they go, so the charge frays rather
            // than acquiring a tidy second column beside it
            var away = K.nz(seed + i * 7) * 0.44 * ((v - bb.y0) / Math.max(0.001, bb.y1 - bb.y0));
            var s = 0.026 + K.nz(seed + i * 31) * 0.040;
            var u = bb.x1 - 0.06 + away;
            shape(ctx, F, [[u - s, v - s * 0.7], [u + s, v - s], [u + s * 0.8, v + s], [u - s, v + s * 0.6]],
                P, ink, false, P.dark);
            n++;
        }
        return n;
    };

    /** Drips gathering along the charge's BOTTOM edge and falling clear. */
    CUTS.drip = function (ctx, F, bb, P, ink, seed) {
        var K = deps().ink;
        var span = (bb.x1 - bb.x0) * F.r;
        var rep = K.repeatsFor(span * 0.90, ink * 2.4, 4.6);
        var n = 0;
        for (var i = 0; i < rep.count; i++) {
            var u = bb.x0 + (i + 0.5) * (rep.pitch / F.r);
            if (u > bb.x1) break;
            var top = bb.y1 - 0.05;
            var fall = 0.10 + K.nz(seed + i * 19) * 0.34;
            var r0 = 0.026 + K.nz(seed + i * 29) * 0.022;
            // a hanging tear: a neck at the top, round at the bottom
            shape(ctx, F, [[u - r0 * 0.5, top], [u + r0 * 0.5, top], [u + r0, top + fall],
                [u, top + fall + r0 * 1.2], [u - r0, top + fall]], P, ink, true, P.lit);
            n++;
        }
        return n;
    };

    D.CUTS = CUTS;

    /**
     * The charge's own bounding box in UNROTATED unit space.
     * ⚠️ Unrotated on purpose: `draw` applies the lean with a canvas transform, so a cut placed
     * against a rotated box would be placed twice.
     * @param {object} g @returns {{x0:number,y0:number,x1:number,y1:number}}
     */
    D.boundsOf = function (g) {
        var b = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
        g.masses.forEach(function (m) {
            m.pts.forEach(function (p) {
                if (p[0] < b.x0) b.x0 = p[0];
                if (p[0] > b.x1) b.x1 = p[0];
                if (p[1] < b.y0) b.y0 = p[1];
                if (p[1] > b.y1) b.y1 = p[1];
            });
        });
        return b;
    };

    /**
     * Draw the whole device into `box`.
     *
     * @param {CanvasRenderingContext2D} ctx
     * @param {{x:number,y:number,w:number,h:number}} box
     * @param {object} spec {type, element, seed}
     * @param {object} P palette {body, ink, lit, dark}
     * @param {number} figureInk
     * @returns {{masses:number, marks:number, cuts:number}} what reached the bitmap
     */
    D.draw = function (ctx, box, spec, P, figureInk) {
        var C = deps().corpus, K = deps().ink;
        var el = C.element(spec.element);
        if (!el) throw new Error('CourtcardDevice: unknown element "' + spec.element + '"');
        var g = D.geometry(spec);
        var F = D.frameOf(box);
        var seed = (spec.seed || 0) | 0;

        // ⛔ FIT THE WHOLE PIECE, NEVER CUT IT BACK (§25c). Five of twelve builds were authored
        // past the drawable range — `rush` reached x=1.305 against a bound of 1.0 — and a card has
        // a FIXED rect, so the overhang lands on the pip rail or is severed at the field edge.
        // §25c is explicit that the fix must not be "cut the ornament back until nothing
        // overhangs", which is §14a's trap committed against ornament: reserve the margin and
        // scale the whole piece uniformly into it. `fitScale` is reported so a build that has to
        // be shrunk far more than its siblings shows up as a SET inconsistency (§22f) rather than
        // silently rendering smaller.
        var fit = D.fitScale(spec);

        ctx.save();
        ctx.translate(F.cx, F.cy);
        ctx.rotate(g.lean * 0.22);
        if (fit < 1) ctx.scale(fit, fit);
        ctx.translate(-F.cx, -F.cy);

        var i;
        // ⛔ `hatched` IS RETURNED AND IS ASSERTED ON. A mass whose engraving abstained looks
        // exactly like the flat-fill defect this renderer shipped with, so the count leaves the
        // draw call rather than dying inside it (§2b rule 2).
        var hatched = 0;
        for (i = 0; i < g.masses.length; i++) {
            var m = g.masses[i];
            // a mass explicitly filled with INK is a solid silhouette by authorial intent — an eye
            // socket, a bracing bar — and has no interior to model. Engraving it would only muddy
            // the one part of the figure that is meant to read as a hole.
            var solid = m.fill === 'ink';
            hatched += shape(ctx, F, m.pts, P, figureInk, m.smooth, solid ? P.ink : null,
                solid ? null : { lean: g.lean * 0.22 });
        }
        for (i = 0; i < g.marks.length; i++) {
            line(ctx, F, g.marks[i][0], g.marks[i][1], P, figureInk, g.marks[i][2]);
        }

        // ── the element's cut, applied INSIDE the same rotation so it belongs to the charge
        var cut = CUTS[el.treatment];
        if (!cut) throw new Error('CourtcardDevice: element "' + el.id + '" declares treatment "' + el.treatment + '" and nothing draws it');
        var where = CONTAINMENT[el.treatment];
        if (!where) throw new Error('CourtcardDevice: treatment "' + el.treatment + '" declares no containment');
        var bb = D.boundsOf(g);
        var cuts;

        if (where === 'inside') {
            // ⛔ CLIP TO THE UNION OF THE CHARGE'S OWN MASSES. Without this a "facet chord cut
            // across the charge" is a rule ruled across the whole CARD, over open paper and past
            // the frame — which is what the first sheet showed on sixteen cells at once.
            ctx.save();
            ctx.beginPath();
            for (i = 0; i < g.masses.length; i++) {
                var mm = g.masses[i];
                var q0 = F.at(mm.pts[0][0], mm.pts[0][1]);
                ctx.moveTo(q0[0], q0[1]);
                for (var j = 1; j < mm.pts.length; j++) {
                    var qq = F.at(mm.pts[j][0], mm.pts[j][1]);
                    ctx.lineTo(qq[0], qq[1]);
                }
                ctx.closePath();
            }
            ctx.clip();
            cuts = cut(ctx, F, bb, P, figureInk, seed + 7919);
            ctx.restore();
        } else {
            cuts = cut(ctx, F, bb, P, figureInk, seed + 7919);
        }

        ctx.restore();
        return {
            masses: g.masses.length, marks: g.marks.length, cuts: cuts, containment: where,
            hatched: hatched, fit: Math.round(fit * 1000) / 1000
        };
    };

    /**
     * The uniform scale that brings a build's whole ROTATED extent inside the drawable range.
     *
     * Returns 1 when the build already fits. ⚠️ It is reported by `draw()` rather than applied
     * silently: a build needing 0.77 while its siblings need 1.00 renders as a visibly smaller
     * object on an otherwise identical card, which is a SET defect (§22f — typographic consistency
     * is a set property, and the same is true of devices) that no single cell can show.
     *
     * @param {object} spec @returns {number} 0 < s <= 1
     */
    D.fitScale = function (spec) {
        var e = D.extent(spec);
        var ox = Math.max(Math.abs(e.minX), Math.abs(e.maxX));
        var oy = Math.max(Math.abs(e.minY), Math.abs(e.maxY));
        var sx = ox > 0 ? D.BOUND_X / ox : 1;
        var sy = oy > 0 ? D.BOUND_Y / oy : 1;
        return Math.min(1, sx, sy);
    };

    /**
     * The device's unit-space extent, for `fit_check` (§22a-6: a clipped figure and a wrong figure
     * look identical, so the box is measured before any sheet is read).
     * @param {object} spec @returns {{minX:number,maxX:number,minY:number,maxY:number}}
     */
    D.extent = function (spec) {
        var g = D.geometry(spec);
        var e = { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity };
        var take = function (p) {
            var q = rot(p, g.lean * 0.22);
            if (q[0] < e.minX) e.minX = q[0];
            if (q[0] > e.maxX) e.maxX = q[0];
            if (q[1] < e.minY) e.minY = q[1];
            if (q[1] > e.maxY) e.maxY = q[1];
        };
        g.masses.forEach(function (m) { m.pts.forEach(take); });
        g.marks.forEach(function (k) { take(k[0]); take(k[1]); });
        return e;
    };

    if (typeof module !== 'undefined' && module.exports) { module.exports = D; }
}(CourtcardDevice));

if (typeof module !== 'undefined' && module.exports) { module.exports = CourtcardDevice; }
