//=============================================================================
// CourtcardFoil.js — Courtcard [3/8]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [Courtcard] The finishing passes - foil, edge and handling wear. What makes a rare
 * card read as rare without changing a line of its drawing. Siblings resolved at FIRST USE.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * CourtcardFoil.js
 *
 * ── FOIL IS A LIGHT EFFECT, NOT A COLOUR ─────────────────────────────────────────────────────
 *
 * ⛔ Every lift here is an ABSOLUTE luminance delta solved by `CourtcardInk.relief` (§22e-1). The
 * obvious implementation - multiply the rail colour by 1.2 and call it gold - is a hard-coded
 * contrast RATIO, and its separation is proportional to the base: on the Abyssal deck's near-black
 * stock it moves almost nothing while on Gilded ivory it blows out. The same defect was measured
 * on a struck seal at 27 luminance levels against 11, with the device on the darkest wax
 * impossible to make out.
 *
 * ⛔ AND THE RAKE COMES FROM `CourtcardInk.LIGHT`, WHICH IS THE PRODUCT'S ONLY STATEMENT ABOUT
 * WHERE THE LIGHT IS. §11a: a second copy of that vector would not drift, it would WIN, and the
 * card would be lit from two directions at once.
 *
 * ── WEAR IS A BUYER PARAMETER, NOT A HIDDEN AXIS ─────────────────────────────────────────────
 *
 * `handling` is a plugin parameter (0 = mint, 1 = well played) so a buyer chooses how used their
 * deck looks. It is deliberately NOT a corpus field: a corpus field nothing draws is a dead axis
 * (§22a-2e) and a drawn thing nothing declares is just as bad, so it is declared where it is
 * actually set - in the Plugin Manager - and read in exactly one place, here.
 *
 * ⚠️ §14a is the trap this pass must not fall into: a wear axis judged by a perceptual hash tempts
 * you to make the wear more violent until dedupe separates the cells, which means a card that
 * warps into a different object as it ages. Wear here stays a SURFACE effect and is measured by an
 * object-scale instrument (`_probe/wear_delta.js`), never by dHash.
 */

var CourtcardFoil = CourtcardFoil || {};

(function (Fo) {
    'use strict';

    var _deps = null;

    /** Resolve siblings at FIRST USE (wing §8 trap 2). */
    function deps() {
        if (_deps) return _deps;
        var ink = (typeof CourtcardInk !== 'undefined') ? CourtcardInk
            : (typeof require !== 'undefined' ? require('./CourtcardInk.js') : null);
        var corpus = (typeof CourtcardCorpus !== 'undefined') ? CourtcardCorpus
            : (typeof require !== 'undefined' ? require('./CourtcardCorpus.js') : null);
        var frame = (typeof CourtcardFrame !== 'undefined') ? CourtcardFrame
            : (typeof require !== 'undefined' ? require('./CourtcardFrame.js') : null);
        if (!ink || !corpus || !frame) throw new Error('CourtcardFoil: Ink, Corpus and Frame must all be loaded');
        _deps = { ink: ink, corpus: corpus, frame: frame };
        return _deps;
    }
    Fo.deps = deps;

    /**
     * The colour of a rarity's foil on a given deck. EXPORTED so the suite can assert the law
     * rather than the picture.
     *
     * ⛔⛔ THIS IS THE FUNCTION THAT CARRIED A TERNARY WITH THE SAME VALUE ON BOTH ARMS —
     * `K.lum(deck.ground) > 127 ? 1 : 1` — which is wing §25h verbatim: *"a no-op ternary is
     * §22a-2e in one line: the intent is in the source and the picture does not contain it."* The
     * intent (the direction must depend on the stock) was written down and never finished, and the
     * surviving always-`+1` lifted every foil toward WHITE. MEASURED on `sheet_rarity_150.png`: the
     * legendary card of ALL SIX decks rendered near-white, and Abyssal — whose entire identity is
     * near-black stock — came out light grey. One axis was destroying another.
     *
     * ⭐ The law, and the suite asserts exactly this: foil is LEAF, so it is the deck's own metal
     * moved AWAY from the stock in whichever direction has room. Gold reads DARKER than ivory and
     * teal reads LIGHTER than near-black, and BOTH are correct — which is precisely what a
     * hard-coded direction cannot express.
     *
     * @param {object} deck @param {string} foilId @returns {number[]}
     */
    Fo.foilColour = function (deck, foilId) {
        var K = deps().ink, C = deps().corpus;
        var fo = C.FOILS[foilId];
        if (!fo) throw new Error('CourtcardFoil: unknown foil "' + foilId + '"');
        var away = K.lum(deck.accent) >= K.lum(deck.ground) ? 1 : -1;
        return K.relief(deck.accent, away, fo.lift * 0.45);
    };

    /**
     * Apply the rarity's foil to the frame.
     *
     * @param {CanvasRenderingContext2D} ctx
     * @param {object} L layout @param {object} rarity @param {object} deck
     * @param {object} P palette @param {number} seed
     * @returns {number} marks drawn — 0 for `none`, which is legitimate and asserted per value
     */
    Fo.apply = function (ctx, L, rarity, deck, P, seed) {
        var K = deps().ink, C = deps().corpus, Fr = deps().frame;
        var fo = C.FOILS[rarity.foil];
        if (!fo) throw new Error('CourtcardFoil: rarity "' + rarity.id + '" declares foil "' + rarity.foil + '" and nothing draws it');
        if (rarity.foil === 'none' || fo.lift <= 0) return 0;

        var f = L.frame, band = L.railBand, n = 0, i;

        // ── THE FOIL COLOUR.
        //
        // ⛔⛔ THIS LINE USED TO READ `K.relief(P.body, K.lum(deck.ground) > 127 ? 1 : 1, fo.lift)`
        // — A TERNARY WITH THE SAME VALUE ON BOTH ARMS. Wing §25h records exactly this shape in
        // this wing's own shipped source: *"a no-op ternary is §22a-2e in one line: the intent is
        // in the source and the picture does not contain it."* I wrote the intent down (the
        // direction should depend on the stock), did not finish it, and the always-`+1` that
        // survived lifted every foil toward WHITE.
        //
        // MEASURED on `sheet_rarity_150.png`: the legendary card of ALL SIX DECKS rendered as a
        // pale, near-white card. The Abyssal deck — whose whole identity is near-black stock — came
        // out light grey. The foil axis was destroying the deck axis, which is the same
        // one-axis-painting-another's-territory failure the element tint had against the frame.
        //
        // ⭐ THE FIX IS ALSO THE BETTER PRODUCT, WHICH IS USUALLY THE TELL. Foil is not "brighter";
        // it is LEAF, and leaf is the deck's own precious metal. So it is the deck's ACCENT moved
        // AWAY from the stock's luminance in whichever direction has room — gold reads DARKER than
        // ivory and teal reads LIGHTER than near-black, and both are correct. Gilded now takes
        // gold, Courtly vermilion, Abyssal teal, Grim oxblood.
        var gold = Fo.foilColour(deck, rarity.foil);
        var lightDir = K.LIGHT.dir;

        ctx.save();

        if (rarity.foil === 'edge') {
            // a tinted bevel on the INNER edge of the rails: one stroke, inside the frame
            ctx.lineWidth = Math.max(1.0, L.ink * 1.1);
            ctx.strokeStyle = K.css(gold);
            Fr.roundRect(ctx, f.x + band * 0.86, f.y + band * 0.86,
                f.w - band * 1.72, f.h - band * 1.72, L.w * 0.020);
            ctx.stroke();
            n = 1;
        } else if (rarity.foil === 'ramp' || rarity.foil === 'leaf' || rarity.foil === 'radiant') {
            // laid leaf: the frame band itself, filled, then a burnished run raking with the light
            // ⛔ ONE path, TWO subpaths, THEN fill — see `CourtcardFrame.addRoundRect`. Tracing
            // them with `roundRect` discarded the first and filled the INNER rect solid, so the
            // leaf covered the whole field and every epic and legendary card lost its paper.
            ctx.save();
            ctx.beginPath();
            Fr.addRoundRect(ctx, f.x, f.y, f.w, f.h, L.w * 0.028);
            Fr.addRoundRect(ctx, f.x + band, f.y + band, f.w - band * 2, f.h - band * 2, L.w * 0.020);
            ctx.fillStyle = K.css(gold);
            ctx.globalAlpha = rarity.foil === 'ramp' ? 0.30 : 0.58;
            ctx.fill('evenodd');
            ctx.restore();
            n++;

            // the burnish: strokes across the rails, brightest where the light lands, and their
            // COUNT IS DERIVED from the run (§22b-1a)
            var burn = K.relief(gold, 1, 34 * fo.sheen);
            var rep = K.repeatsFor(f.w + f.h, L.ink * 2.2, 5.5);
            ctx.save();
            ctx.beginPath();
            Fr.addRoundRect(ctx, f.x, f.y, f.w, f.h, L.w * 0.028);
            Fr.addRoundRect(ctx, f.x + band, f.y + band, f.w - band * 2, f.h - band * 2, L.w * 0.020);
            ctx.clip('evenodd');
            ctx.strokeStyle = K.css(burn);
            ctx.lineWidth = Math.max(0.9, L.ink * 0.7);
            for (i = 0; i < rep.count; i++) {
                var t = (i + 0.5) * rep.pitch;
                var sx = f.x - f.h + t, sy = f.y;
                ctx.globalAlpha = 0.20 + 0.55 * fo.sheen * Math.max(0, 1 - Math.abs((t / (f.w + f.h)) - K.LIGHT.u) * 2.4);
                ctx.beginPath();
                ctx.moveTo(sx, sy);
                ctx.lineTo(sx - lightDir[0] * f.h * 1.4, sy - lightDir[1] * f.h * 1.4);
                ctx.stroke();
                n++;
            }
            ctx.restore();
            ctx.globalAlpha = 1;
        }

        if (rarity.foil === 'radiant') {
            // rays struck OUTWARD from the device, alternating long and short so nothing pairs, and
            // clipped to the field so they can never cross the rails
            var fl = L.field;
            var cx = fl.x + fl.w / 2, cy = fl.y + (fl.h - L.plate.h) / 2;
            var R = Math.max(fl.w, fl.h) * 0.72;
            ctx.save();
            Fr.roundRect(ctx, fl.x, fl.y, fl.w, fl.h - L.plate.h * 0.92, L.w * 0.018);
            ctx.clip();
            ctx.strokeStyle = K.css(K.relief(deck.ground, K.lum(deck.ground) > 127 ? -1 : 1, 16));
            ctx.lineWidth = Math.max(0.9, L.ink * 0.75);
            for (i = 0; i < 24; i++) {
                var a = i * Math.PI / 12 + 0.13;
                var L2 = R * (i % 2 ? 0.52 : 1.0);
                ctx.globalAlpha = 0.22;
                ctx.beginPath();
                ctx.moveTo(cx + Math.cos(a) * R * 0.20, cy + Math.sin(a) * R * 0.20);
                ctx.lineTo(cx + Math.cos(a) * L2, cy + Math.sin(a) * L2);
                ctx.stroke();
                n++;
            }
            ctx.restore();
            ctx.globalAlpha = 1;
        }

        ctx.restore();
        return n;
    };

    /**
     * Handling wear: corner rub and surface scuff, seeded per card.
     *
     * @param {number} amount 0..1 from the plugin parameter
     * @returns {number} marks drawn
     */
    Fo.wear = function (ctx, L, deck, P, amount, seed) {
        var K = deps().ink, Fr = deps().frame;
        var a = Math.max(0, Math.min(1, amount || 0));
        if (a <= 0.001) return 0;
        var n = 0, i;
        // the rub is the STOCK showing through, so it is solved from the ground rather than painted
        var rub = K.relief(deck.ground, K.lum(deck.ground) > 127 ? -1 : 1, 10 + 22 * a);

        ctx.save();
        Fr.roundRect(ctx, 0, 0, L.w, L.h, L.w * 0.035);
        ctx.clip();

        // corner rub — heaviest where a thumb actually sits, i.e. the two lower corners
        var corners = [[0, 0, 0.55], [L.w, 0, 0.55], [0, L.h, 1.0], [L.w, L.h, 1.0]];
        for (i = 0; i < corners.length; i++) {
            var R = L.w * (0.05 + 0.10 * a) * corners[i][2];
            var steps = Math.max(3, Math.round(R / 2));
            for (var s = 0; s < steps; s++) {
                var t = s / steps;
                ctx.globalAlpha = 0.30 * a * (1 - t);
                ctx.fillStyle = K.css(rub);
                ctx.beginPath();
                ctx.arc(corners[i][0], corners[i][1], R * (1 - t), 0, Math.PI * 2);
                ctx.fill();
                n++;
            }
        }

        // surface scuff — short cuts, seeded, never a random field per frame (wing rule 2)
        var scuffs = Math.round(18 + 90 * a);
        ctx.strokeStyle = K.css(rub);
        ctx.lineCap = 'round';
        for (i = 0; i < scuffs; i++) {
            var x = K.nz(seed + i * 3) * L.w, y = K.nz(seed + i * 5 + 11) * L.h;
            var len = L.w * (0.01 + K.nz(seed + i * 7) * 0.05);
            var ang = K.nz(seed + i * 13) * Math.PI;
            ctx.globalAlpha = 0.10 + 0.22 * a * K.nz(seed + i * 17);
            ctx.lineWidth = Math.max(0.6, L.ink * 0.45);
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x + Math.cos(ang) * len, y + Math.sin(ang) * len);
            ctx.stroke();
            n++;
        }
        ctx.globalAlpha = 1;
        ctx.restore();
        return n;
    };

    if (typeof module !== 'undefined' && module.exports) { module.exports = Fo; }
}(CourtcardFoil));

if (typeof module !== 'undefined' && module.exports) { module.exports = CourtcardFoil; }
