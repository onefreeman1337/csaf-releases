//=============================================================================
// CourtcardFrame.js — Courtcard [4/8]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [Courtcard] The card itself - stock, rails, corner treatments, ornament bands, the
 * nameplate cartouche and the back design. Drawing only; siblings resolved at FIRST USE.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * CourtcardFrame.js
 *
 * ── THE THREE SCALES THAT LIVE AT A CORNER ───────────────────────────────────────────────────
 *
 * ⛔ WING §25c, measured on Cartouche in one session and in both directions:
 *
 *   1. THE PEN comes from the shape it outlines (§22a-2f-1). One pen derived from the whole figure
 *      put a 5px outline on a 23px head and consumed sixteen cells at once.
 *   2. THE REACH belongs to the HEAD RAIL, not to the side stile. Taking it from the frame's
 *      thinnest dimension rendered twenty-six authored corner treatments as 12-24px nicks.
 *   3. THE BLEED. Fixing (2) then made all 26 draw OUTSIDE the rect, worst overhang 64px - and an
 *      MZ window's rect IS its bitmap, so every finial and crown would have shipped SEVERED. A
 *      contact sheet structurally cannot show this, because a sheet has gutters and the overhang
 *      runs into the margin and reads as generous.
 *
 * So `CORNER_MARGIN` below is real, `cornerMark` is passed the margin it may not cross, and
 * `_probe/bleed_check.js` draws on a larger canvas and counts non-background pixels outside the
 * card rect. ⚠️ The fix is never "cut the ornament back until nothing overhangs" - that is §14a's
 * trap committed against ornament. Reserve the margin and scale the whole piece into it.
 *
 * ── EVERY REPEATED TREATMENT DECLARES A PITCH ────────────────────────────────────────────────
 *
 * §22b-1a: a COUNT cannot express a worked band, because the right count changes with the size of
 * the piece. Escutcheon declared `marks: 18` for beading and landed eighteen specks 39px apart on
 * a 700px perimeter - and all seven treatments rendered as the same yellow rectangle, which was
 * verbatim the thing that product was forbidden to ship. Every band, every stock line and every
 * back motif here derives its count from `CourtcardInk.repeatsFor` against the REAL run.
 */

var CourtcardFrame = CourtcardFrame || {};

(function (Fr) {
    'use strict';

    var _deps = null;

    /** Resolve siblings at FIRST USE (wing §8 trap 2). */
    function deps() {
        if (_deps) return _deps;
        var ink = (typeof CourtcardInk !== 'undefined') ? CourtcardInk
            : (typeof require !== 'undefined' ? require('./CourtcardInk.js') : null);
        var corpus = (typeof CourtcardCorpus !== 'undefined') ? CourtcardCorpus
            : (typeof require !== 'undefined' ? require('./CourtcardCorpus.js') : null);
        if (!ink || !corpus) throw new Error('CourtcardFrame: CourtcardInk and CourtcardCorpus must both be loaded');
        _deps = { ink: ink, corpus: corpus };
        return _deps;
    }
    Fr.deps = deps;

    /** Fraction of the card width a corner treatment may NEVER cross. See §25c above. */
    Fr.CORNER_MARGIN = 0.042;

    /**
     * Add a rounded rectangle to the CURRENT path, without starting a new one.
     *
     * ⛔⛔ THIS EXISTS BECAUSE `roundRect` BELOW CALLS `beginPath()`, AND THAT MADE EVERY
     * TWO-SUBPATH `evenodd` FILL IN THIS PRODUCT FILL THE WRONG SHAPE. The foil laid its leaf by
     * tracing the frame's outer rect, then the inner rect, then filling `evenodd` — intending the
     * RING between them. The second `roundRect` discarded the first, so the fill was the INNER
     * rectangle, solid: on every epic and legendary card the leaf covered the whole FIELD and the
     * deck's paper disappeared under it.
     *
     * ⚠️ It was invisible in the offline rarity sheet, where it read as a deliberate coloured card,
     * and obvious the moment the scene was photographed at 816x624 beside its uncommon siblings —
     * wing §9.5: the Gate 1 enforcement human is YOU, and a counter cannot see a fill that is the
     * wrong shape but the right colour.
     *
     * ⭐ Same family as §22d ("two ways to put a hole in a shape, and both obvious versions are
     * wrong"): canvas has no "punch a hole in what I already drew", so the hole must be traced in
     * the SAME path as the shape it belongs to — which is impossible if the tracer resets the path.
     */
    function addRoundRect(ctx, x, y, w, h, r) {
        var rr = Math.max(0, Math.min(r, w / 2, h / 2));
        ctx.moveTo(x + rr, y);
        ctx.lineTo(x + w - rr, y);
        ctx.arcTo(x + w, y, x + w, y + rr, rr);
        ctx.lineTo(x + w, y + h - rr);
        ctx.arcTo(x + w, y + h, x + w - rr, y + h, rr);
        ctx.lineTo(x + rr, y + h);
        ctx.arcTo(x, y + h, x, y + h - rr, rr);
        ctx.lineTo(x, y + rr);
        ctx.arcTo(x, y, x + rr, y, rr);
        ctx.closePath();
    }
    Fr.addRoundRect = addRoundRect;

    /** A rounded-rectangle path, as its OWN path. Use `addRoundRect` to compose two. */
    function roundRect(ctx, x, y, w, h, r) {
        var rr = Math.max(0, Math.min(r, w / 2, h / 2));
        ctx.beginPath();
        ctx.moveTo(x + rr, y);
        ctx.lineTo(x + w - rr, y);
        ctx.arcTo(x + w, y, x + w, y + rr, rr);
        ctx.lineTo(x + w, y + h - rr);
        ctx.arcTo(x + w, y + h, x + w - rr, y + h, rr);
        ctx.lineTo(x + rr, y + h);
        ctx.arcTo(x, y + h, x, y + h - rr, rr);
        ctx.lineTo(x, y + rr);
        ctx.arcTo(x, y, x + rr, y, rr);
        ctx.closePath();
    }
    Fr.roundRect = roundRect;

    // ───────────────────────────────────────────────────────────── STOCK

    /**
     * Lay the paper: the ground colour plus the stock's own texture.
     *
     * ⛔ §21b: "the code ran" and "the picture changed" are different claims. A contour band at
     * globalAlpha 0.12 on a near-black fill was invisible while every counter reported work, so the
     * excursion here is an ABSOLUTE luminance move via `relief`, and `amp` is the corpus's own
     * declared amplitude rather than an alpha nobody can reason about.
     *
     * @param {CanvasRenderingContext2D} ctx
     * @param {number} x @param {number} y @param {number} w @param {number} h
     * @param {object} deck @param {number} ink base ink width @param {number} seed
     * @returns {number} marks drawn
     */
    Fr.stock = function (ctx, x, y, w, h, deck, ink, seed) {
        var K = deps().ink, C = deps().corpus;
        var st = C.STOCKS[deck.stock];
        if (!st) throw new Error('CourtcardFrame: deck "' + deck.id + '" declares stock "' + deck.stock + '" and nothing draws it');
        var ground = deck.ground;
        ctx.save();
        roundRect(ctx, x, y, w, h, w * 0.035);
        ctx.clip();
        ctx.fillStyle = K.css(ground);
        ctx.fillRect(x, y, w, h);

        // the excursion the ground drives the field to, in absolute luminance levels
        var lift = K.relief(ground, 1, 255 * st.amp);
        var sink = K.relief(ground, -1, 255 * st.amp);
        var n = 0, i;

        if (st.pitchMul > 0) {
            // chain / weave lines — a repeated treatment, so the COUNT IS DERIVED
            var rep = K.repeatsFor(w, ink * 0.9, st.pitchMul);
            for (i = 0; i < rep.count; i++) {
                var lx = x + (i + 0.5) * rep.pitch;
                ctx.beginPath();
                ctx.moveTo(lx, y); ctx.lineTo(lx, y + h);
                ctx.lineWidth = Math.max(0.7, ink * 0.55);
                ctx.strokeStyle = K.css(sink);
                ctx.stroke();
                n++;
            }
            if (deck.stock === 'linen') {
                var repY = K.repeatsFor(h, ink * 0.9, st.pitchMul);
                for (i = 0; i < repY.count; i++) {
                    var ly = y + (i + 0.5) * repY.pitch;
                    ctx.beginPath();
                    ctx.moveTo(x, ly); ctx.lineTo(x + w, ly);
                    ctx.lineWidth = Math.max(0.7, ink * 0.45);
                    ctx.strokeStyle = K.css(lift);
                    ctx.stroke();
                    n++;
                }
            }
        }

        // the speckle / mottle / wash every stock carries, seeded so a card never shimmers
        var grains = Math.round((w * h) / (ink * ink * 34));
        for (i = 0; i < grains; i++) {
            var gx = x + K.nz(seed + i * 3) * w;
            var gy = y + K.nz(seed + i * 5 + 1) * h;
            var s = ink * (0.35 + K.nz(seed + i * 7) * (deck.stock === 'vellum' ? 2.4 : 0.9));
            ctx.fillStyle = K.css(K.nz(seed + i * 11) > 0.5 ? lift : sink);
            ctx.globalAlpha = deck.stock === 'vellum' ? 0.45 : 0.7;
            ctx.fillRect(gx, gy, s, s);
            n++;
        }
        ctx.globalAlpha = 1;

        if (deck.stock === 'smoked') {
            // heavier toward the edges: a real vignette, drawn as a ring of graded strokes
            var steps = Math.max(3, Math.round(w * 0.06));
            for (i = 0; i < steps; i++) {
                var t = i / steps;
                ctx.strokeStyle = K.css(K.relief(ground, -1, 255 * st.amp * (1 - t)));
                ctx.globalAlpha = 0.30 * (1 - t);
                ctx.lineWidth = 2;
                roundRect(ctx, x + i, y + i, w - i * 2, h - i * 2, w * 0.035);
                ctx.stroke();
                n++;
            }
            ctx.globalAlpha = 1;
        }
        ctx.restore();
        return n;
    };

    // ───────────────────────────────────────────────────────────── BANDS

    /**
     * Run an ornament band along a straight rail.
     * @returns {number} marks drawn — 0 when the motif is `none`, which is legitimate
     */
    Fr.bandRun = function (ctx, x, y, run, thick, motif, pitchMul, P, ink, vertical) {
        var K = deps().ink, C = deps().corpus;
        var b = C.BANDS[motif];
        if (!b) throw new Error('CourtcardFrame: unknown band "' + motif + '"');
        if (motif === 'none' || pitchMul <= 0) return 0;
        var rep = K.repeatsFor(run, thick, pitchMul);
        if (rep.count <= 0) return 0;
        var at = function (u, v) { return vertical ? [x + v, y + u] : [x + u, y + v]; };
        var pen = K.penFor(ink, thick, thick);
        var n = 0;
        var lit = K.relief(P.body, 1, 30 * b.depth);
        var dark = K.relief(P.body, -1, 34 * b.depth);
        for (var i = 0; i < rep.count; i++) {
            var u = (i + 0.5) * rep.pitch;
            var s = thick * 0.42 * b.depth;
            var q;
            ctx.lineWidth = pen;
            ctx.strokeStyle = K.css(P.ink);
            if (motif === 'dot') {
                q = at(u, thick / 2);
                ctx.beginPath(); ctx.arc(q[0], q[1], s, 0, Math.PI * 2);
                ctx.fillStyle = K.css(dark); ctx.fill(); ctx.stroke();
            } else if (motif === 'lozenge') {
                q = at(u, thick / 2);
                ctx.beginPath();
                var a1 = at(u - s * 1.2, thick / 2), a2 = at(u, thick / 2 - s), a3 = at(u + s * 1.2, thick / 2), a4 = at(u, thick / 2 + s);
                ctx.moveTo(a1[0], a1[1]); ctx.lineTo(a2[0], a2[1]); ctx.lineTo(a3[0], a3[1]); ctx.lineTo(a4[0], a4[1]);
                ctx.closePath();
                ctx.fillStyle = K.css(i % 2 ? lit : dark); ctx.fill(); ctx.stroke();
            } else if (motif === 'dentil') {
                var d0 = at(u - s, thick * 0.18), d1 = at(u + s, thick * 0.18);
                var d2 = at(u + s, thick * 0.82), d3 = at(u - s, thick * 0.82);
                ctx.beginPath();
                ctx.moveTo(d0[0], d0[1]); ctx.lineTo(d1[0], d1[1]); ctx.lineTo(d2[0], d2[1]); ctx.lineTo(d3[0], d3[1]);
                ctx.closePath();
                ctx.fillStyle = K.css(dark); ctx.fill(); ctx.stroke();
            } else if (motif === 'cable') {
                // alternating lobes — a twist reads as a twist only because the lobes ALTERNATE
                var side = i % 2 ? 0.30 : 0.70;
                q = at(u, thick * side);
                ctx.beginPath();
                ctx.ellipse(q[0], q[1], vertical ? s * 0.85 : s * 1.25, vertical ? s * 1.25 : s * 0.85,
                    0, 0, Math.PI * 2);
                ctx.fillStyle = K.css(i % 2 ? lit : dark); ctx.fill(); ctx.stroke();
            } else if (motif === 'arcade') {
                // a round-headed arch on two piers: the head is a real arc, not a bump
                var w2 = s * 1.35;
                var f0 = at(u - w2, thick * 0.92), f1 = at(u - w2, thick * 0.46);
                var f2 = at(u, thick * 0.10), f3 = at(u + w2, thick * 0.46), f4 = at(u + w2, thick * 0.92);
                ctx.beginPath();
                ctx.moveTo(f0[0], f0[1]); ctx.lineTo(f1[0], f1[1]);
                ctx.quadraticCurveTo(f2[0], f2[1], f3[0], f3[1]);
                ctx.lineTo(f4[0], f4[1]);
                ctx.fillStyle = K.css(dark);
                ctx.fill(); ctx.stroke();
            }
            n++;
        }
        return n;
    };

    // ───────────────────────────────────────────────────────────── CORNERS

    /**
     * Strike a corner treatment.
     *
     * @param {CanvasRenderingContext2D} ctx
     * @param {number} cx @param {number} cy the corner point
     * @param {number} qx @param {number} qy unit direction INTO the card (+/-1 each)
     * @param {string} form @param {number} railH the HEAD RAIL depth — the reach's true parent
     * @param {number} maxOut how far outward the mark may go before it is severed (§25c)
     * @returns {number} marks drawn
     */
    Fr.cornerMark = function (ctx, cx, cy, qx, qy, form, railH, P, ink, maxOut) {
        var K = deps().ink, C = deps().corpus;
        var f = C.CORNERS[form];
        if (!f) throw new Error('CourtcardFrame: unknown corner "' + form + '"');
        // ⛔ THE REACH BELONGS TO THE HEAD RAIL (§25c-2), and is then clamped by the margin the
        // card actually has (§25c-3). Both halves are needed: one alone gives nicks, the other
        // alone gives severed finials.
        var reach = railH * f.reach * 1.55;
        var out = Math.min(reach * 0.42, maxOut);
        var pen = K.penFor(ink, reach, reach);
        var lit = K.relief(P.body, 1, 28);
        var dark = K.relief(P.body, -1, 32);
        ctx.save();
        ctx.translate(cx, cy);
        ctx.scale(qx, qy);
        ctx.lineWidth = pen;
        ctx.lineJoin = 'round';
        ctx.strokeStyle = K.css(P.ink);
        var n = 0;

        if (form === 'nick') {
            ctx.beginPath();
            ctx.moveTo(reach, 0); ctx.lineTo(0, reach);
            ctx.stroke();
            n = 1;
        } else if (form === 'clip') {
            // two cuts of UNEQUAL depth, so the corner never mirrors about its own diagonal
            ctx.beginPath();
            ctx.moveTo(reach, 0); ctx.lineTo(0, reach * 0.62);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(reach * 0.55, 0); ctx.lineTo(0, reach * 0.34);
            ctx.stroke();
            n = 2;
        } else if (form === 'rosette') {
            var R = reach * 0.44, i;
            ctx.beginPath();
            for (i = 0; i <= 24; i++) {
                var a = (i / 24) * Math.PI * 2;
                var rr = R * (1 + 0.30 * Math.cos(a * 5));
                var px = R * 0.95 + Math.cos(a) * rr, py = R * 0.95 + Math.sin(a) * rr;
                if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
            }
            ctx.closePath();
            ctx.fillStyle = K.css(dark); ctx.fill(); ctx.stroke();
            ctx.beginPath();
            ctx.arc(R * 0.95, R * 0.95, R * 0.26, 0, Math.PI * 2);
            ctx.fillStyle = K.css(lit); ctx.fill(); ctx.stroke();
            n = 2;
        } else if (form === 'finial') {
            // a collar, then a point projecting ON THE DIAGONAL and staying inside `out`
            ctx.beginPath();
            ctx.moveTo(reach * 0.86, reach * 0.10);
            ctx.lineTo(reach * 0.10, reach * 0.86);
            ctx.lineTo(reach * 0.24, reach * 0.24);
            ctx.closePath();
            ctx.fillStyle = K.css(dark); ctx.fill(); ctx.stroke();
            var d = out * 0.70;
            ctx.beginPath();
            ctx.moveTo(reach * 0.30, reach * 0.06);
            ctx.lineTo(-d, -d);
            ctx.lineTo(reach * 0.06, reach * 0.30);
            ctx.closePath();
            ctx.fillStyle = K.css(lit); ctx.fill(); ctx.stroke();
            n = 2;
        } else if (form === 'crown') {
            var base = reach * 0.86;
            ctx.beginPath();
            ctx.moveTo(base, reach * 0.16);
            ctx.lineTo(reach * 0.16, base);
            ctx.lineTo(reach * 0.30, reach * 0.30);
            ctx.closePath();
            ctx.fillStyle = K.css(dark); ctx.fill(); ctx.stroke();
            // THREE points of unequal length, on the diagonal, inside the reserved margin
            var pts = [[0.94, 0.34], [1.00, 1.00], [0.34, 0.94]];
            for (var j = 0; j < 3; j++) {
                var L = out * (j === 1 ? 0.96 : 0.62);
                var vx = -pts[j][0], vy = -pts[j][1];
                var m = Math.sqrt(vx * vx + vy * vy);
                ctx.beginPath();
                ctx.moveTo(reach * 0.20 * pts[j][1], reach * 0.20 * pts[j][0]);
                ctx.lineTo(vx / m * L, vy / m * L);
                ctx.lineTo(reach * 0.26 * pts[j][0], reach * 0.26 * pts[j][1]);
                ctx.closePath();
                ctx.fillStyle = K.css(lit); ctx.fill(); ctx.stroke();
                n++;
            }
            n += 1;
        }
        ctx.restore();
        return n;
    };

    // ───────────────────────────────────────────────────────────── THE FRAME

    /**
     * Draw the rails, bands and corners for a rarity.
     * @returns {{rails:number, band:number, corners:number}}
     */
    Fr.frame = function (ctx, L, rarity, P, seed) {
        var K = deps().ink;
        var ink = L.ink;
        var f = L.frame;
        var out = { rails: 0, band: 0, corners: 0 };
        var gap = L.railBand / Math.max(1, rarity.rails * 1.6);
        var i;

        for (i = 0; i < rarity.rails; i++) {
            var inset = i * gap * 1.55;
            var wgt = ink * rarity.railWeight * (i === 0 ? 1.35 : 0.80);
            ctx.lineWidth = wgt;
            ctx.strokeStyle = K.css(P.ink);
            roundRect(ctx, f.x + inset, f.y + inset, f.w - inset * 2, f.h - inset * 2, L.w * 0.028);
            ctx.stroke();
            out.rails++;
        }

        // ── the band runs between rail 0 and the field, on all four sides.
        //
        // ⛔ THE PITCH COMES FROM THE BAND, NOT FROM THE RARITY. It used to be read from
        // `rarity.bandPitchMul`, a SECOND COPY of `C.BANDS[motif].pitchMul` — and wing §11a is
        // exactly this: a second copy of a constant does not drift, it WINS, so editing the band's
        // own declared pitch would have moved nothing and the corpus's copy would have been dead.
        // The four pairs happened to agree, which is what makes the shape dangerous rather than
        // harmless — they agree until somebody edits one. A cable's pitch is a property of cable.
        if (rarity.band !== 'none' && rarity.rails > 1) {
            var bandDef = deps().corpus.BANDS[rarity.band];
            if (!bandDef) throw new Error('CourtcardFrame: rarity "' + rarity.id + '" declares band "' + rarity.band + '" and nothing declares it');
            var pm = bandDef.pitchMul;
            var bx = f.x + gap * 1.55, by = f.y + gap * 1.55;
            var bw = f.w - gap * 3.10, bh = f.h - gap * 3.10;
            var thick = L.railBand - gap * 1.55;
            out.band += Fr.bandRun(ctx, bx, by - thick * 0.02, bw, thick * 0.86, rarity.band, pm, P, ink, false);
            out.band += Fr.bandRun(ctx, bx, by + bh - thick * 0.84, bw, thick * 0.86, rarity.band, pm, P, ink, false);
            out.band += Fr.bandRun(ctx, bx - thick * 0.02, by + thick, thick * 0.86, bh - thick * 2, rarity.band, pm, P, ink, true);
            out.band += Fr.bandRun(ctx, bx + bw - thick * 0.84, by + thick, thick * 0.86, bh - thick * 2, rarity.band, pm, P, ink, true);
        }

        var maxOut = L.w * Fr.CORNER_MARGIN;
        var cs = [[f.x, f.y, 1, 1], [f.x + f.w, f.y, -1, 1], [f.x + f.w, f.y + f.h, -1, -1], [f.x, f.y + f.h, 1, -1]];
        for (i = 0; i < cs.length; i++) {
            out.corners += Fr.cornerMark(ctx, cs[i][0], cs[i][1], cs[i][2], cs[i][3],
                rarity.corner, L.railBand, P, ink, maxOut);
        }
        return out;
    };

    // ───────────────────────────────────────────────────────────── NAMEPLATE

    /**
     * The cartouche at the foot that carries the buyer's own title text.
     *
     * ⛔ §22b-1b's companion: `relief()` IS FOR A RAISED SURFACE AND IS THE WRONG TOOL FOR ASKING
     * "what colour is paper". A plate is a sheet the device is struck ON, so it is filled FROM THE
     * STOCK and outlined in ink; filling it with "a slightly lighter ink" renders a near-black bar
     * on near-black ink with the lettering invisible inside it.
     *
     * @returns {{ink:number[], ratio:number, metWant:boolean, face:number[]}}
     */
    Fr.plate = function (ctx, L, rarity, deck, P) {
        var K = deps().ink;
        var p = L.plate, ink = L.ink;
        var face;
        if (rarity.plateForm === 'ruled') {
            face = deck.ground;
        } else if (rarity.plateForm === 'recessed') {
            face = K.relief(deck.ground, K.lum(deck.ground) > 127 ? -1 : 1, 16);
        } else {
            face = K.relief(deck.ground, K.lum(deck.ground) > 127 ? -1 : 1, 26);
        }
        var pen = K.penFor(ink, p.w, p.h);

        ctx.save();
        if (rarity.plateForm === 'scrolled') {
            // a scroll: the ends curl back, so the plate is not a rectangle at the top rarity
            var curl = p.h * 0.46;
            ctx.beginPath();
            ctx.moveTo(p.x + curl * 0.5, p.y);
            ctx.lineTo(p.x + p.w - curl * 0.5, p.y);
            ctx.quadraticCurveTo(p.x + p.w + curl * 0.35, p.y + p.h * 0.5, p.x + p.w - curl * 0.5, p.y + p.h);
            ctx.lineTo(p.x + curl * 0.5, p.y + p.h);
            ctx.quadraticCurveTo(p.x - curl * 0.35, p.y + p.h * 0.5, p.x + curl * 0.5, p.y);
            ctx.closePath();
        } else {
            roundRect(ctx, p.x, p.y, p.w, p.h, p.h * 0.22);
        }
        ctx.fillStyle = K.css(face);
        ctx.fill();
        ctx.lineWidth = pen;
        ctx.strokeStyle = K.css(P.ink);
        ctx.stroke();

        if (rarity.plateForm !== 'ruled') {
            // an inner rule, set in from the plate's own edge by its own thickness
            ctx.lineWidth = Math.max(0.8, pen * 0.55);
            roundRect(ctx, p.x + pen * 2.2, p.y + pen * 2.2, p.w - pen * 4.4, p.h - pen * 4.4, p.h * 0.18);
            ctx.stroke();
        }
        ctx.restore();

        // the ink for the title, solved against the plate face it actually sits on
        var solved = K.inkFor(face, P.ink, 7, 0.02);
        return { ink: solved.ink, ratio: solved.ratio, metWant: solved.metWant, face: face };
    };

    // ───────────────────────────────────────────────────────────── THE BACK

    /**
     * The deck's back design, filling the whole card.
     * @returns {number} marks drawn
     */
    Fr.back = function (ctx, L, deck, P, seed) {
        var K = deps().ink, C = deps().corpus;
        var b = C.BACKS[deck.back];
        if (!b) throw new Error('CourtcardFrame: deck "' + deck.id + '" declares back "' + deck.back + '" and nothing draws it');
        var f = L.field, ink = L.ink;
        var n = 0, i, j;
        var dark = K.relief(deck.ground, -1, 34);
        var accent = deck.accent;

        ctx.save();
        roundRect(ctx, f.x, f.y, f.w, f.h, L.w * 0.02);
        ctx.clip();
        ctx.lineWidth = Math.max(0.9, ink * 0.85);
        ctx.strokeStyle = K.css(dark);

        if (deck.back === 'compass') {
            // the one back with no pitch: a single radiant rose, rays alternating long and short
            var cx = f.x + f.w / 2, cy = f.y + f.h / 2;
            var R = Math.min(f.w, f.h) * 0.46;
            for (i = 0; i < 32; i++) {
                var a = i * Math.PI / 16;
                var L2 = R * (i % 4 === 0 ? 1.0 : (i % 2 ? 0.44 : 0.68));
                ctx.beginPath();
                ctx.moveTo(cx + Math.cos(a) * R * 0.10, cy + Math.sin(a) * R * 0.10);
                ctx.lineTo(cx + Math.cos(a) * L2, cy + Math.sin(a) * L2);
                ctx.strokeStyle = K.css(i % 4 === 0 ? accent : dark);
                ctx.stroke();
                n++;
            }
            ctx.beginPath(); ctx.arc(cx, cy, R * 0.16, 0, Math.PI * 2);
            ctx.fillStyle = K.css(accent); ctx.fill(); ctx.stroke(); n++;
        } else {
            var rep = K.repeatsFor(f.w, ink * 1.4, b.pitchMul);
            var repY = K.repeatsFor(f.h, ink * 1.4, b.pitchMul);
            var s = rep.pitch;
            for (i = -1; i <= rep.count + 1; i++) {
                for (j = -1; j <= repY.count + 1; j++) {
                    var x = f.x + i * s, y = f.y + j * repY.pitch;
                    var odd = ((i + j) % 2 + 2) % 2;
                    if (deck.back === 'diaper') {
                        ctx.beginPath();
                        ctx.moveTo(x + s / 2, y); ctx.lineTo(x + s, y + repY.pitch / 2);
                        ctx.lineTo(x + s / 2, y + repY.pitch); ctx.lineTo(x, y + repY.pitch / 2);
                        ctx.closePath(); ctx.stroke();
                        if (odd) {
                            ctx.beginPath();
                            ctx.arc(x + s / 2, y + repY.pitch / 2, s * 0.14, 0, Math.PI * 2);
                            ctx.fillStyle = K.css(accent); ctx.fill();
                        }
                    } else if (deck.back === 'barb') {
                        ctx.beginPath();
                        for (var q = 0; q < 4; q++) {
                            var aa = q * Math.PI / 2 + Math.PI / 4;
                            ctx.moveTo(x + s / 2, y + repY.pitch / 2);
                            ctx.lineTo(x + s / 2 + Math.cos(aa) * s * 0.44, y + repY.pitch / 2 + Math.sin(aa) * repY.pitch * 0.44);
                        }
                        ctx.strokeStyle = K.css(odd ? accent : dark);
                        ctx.stroke();
                    } else if (deck.back === 'trellis') {
                        ctx.beginPath();
                        ctx.moveTo(x, y + repY.pitch); ctx.quadraticCurveTo(x + s / 2, y + repY.pitch * (odd ? 0.1 : 0.9), x + s, y);
                        ctx.stroke();
                        ctx.beginPath();
                        ctx.ellipse(x + s / 2, y + repY.pitch / 2, s * 0.16, repY.pitch * 0.10, odd ? 0.6 : -0.6, 0, Math.PI * 2);
                        ctx.fillStyle = K.css(accent); ctx.fill();
                    } else if (deck.back === 'ripple') {
                        if (i === 0 && j === 0) {
                            var rx = f.x + f.w * 0.38, ry = f.y + f.h * 0.44;
                            var rings = Math.max(4, Math.round(Math.max(f.w, f.h) / s));
                            for (var r2 = 1; r2 <= rings; r2++) {
                                ctx.beginPath();
                                ctx.arc(rx, ry, r2 * s, 0, Math.PI * 2);
                                ctx.strokeStyle = K.css(r2 % 3 === 0 ? accent : dark);
                                ctx.stroke();
                                n++;
                            }
                        }
                        continue;
                    } else if (deck.back === 'herring') {
                        ctx.beginPath();
                        var dir = odd ? 1 : -1;
                        ctx.moveTo(x, y + repY.pitch * (odd ? 0 : 1));
                        ctx.lineTo(x + s * 0.8, y + repY.pitch * (odd ? 1 : 0));
                        ctx.strokeStyle = K.css(odd ? dark : accent);
                        ctx.stroke();
                    }
                    n++;
                }
            }
        }
        ctx.restore();
        return n;
    };

    if (typeof module !== 'undefined' && module.exports) { module.exports = Fr; }
}(CourtcardFrame));

if (typeof module !== 'undefined' && module.exports) { module.exports = CourtcardFrame; }
