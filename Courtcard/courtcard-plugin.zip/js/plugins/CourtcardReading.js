//=============================================================================
// CourtcardReading.js — Courtcard [8/9]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [Courtcard] The classifier - turns a row of the buyer's OWN skill or item data into a
 * card spec. The one file where this product can silently become one picture. No drawing.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * CourtcardReading.js
 *
 * ── ⛔ THIS IS THE FILE THAT DECIDES WHETHER THE PRODUCT HAS ANY RANGE AT ALL ─────────────────
 *
 * `CourtcardCorpus.volume()` reports 480 faces. Wing §21i is the entry that says why that number is
 * not the one that matters: Glaze reported "14 profiles x 12 glazes = 168 vessels", the figure was
 * TRUE, the test asserting it was honest, 130 headless checks were green — and the in-engine shelf
 * showed TWELVE ITEMS IN FIVE FORMS WITH FOUR VISIBLE TWINS.
 *
 * > **The corpus size is what the product COULD make. What a buyer sees is what their own database
 * > RESOLVES to, and a classifier written as a decision tree returns exactly one answer per branch
 * > - so a project with six healing items gets one pot six times.**
 *
 * Master §1.1 question 3 asks about the SECOND number, and every instrument in this factory
 * measures the first. `_probe/spread_check.js` runs this classifier over real and synthetic
 * databases and PRINTS what they resolve to.
 *
 * ── ⛔ AND §24a IS THE TRAP UNDERNEATH IT: MOST MZ PROJECTS SHIP THE STOCK DATABASE ───────────
 *
 * Frontispiece's own spread probe returned `hall` TWELVE TIMES OUT OF TWELVE across twelve
 * synthetic projects, because `System.json` already contains Axe, Shield, Spear, Ice and Staff and
 * those scored `hall` outright. The fallback written specifically to spread the market was DEAD
 * CODE for the common case, and the product would have rendered one screen for most buyers with
 * every test green.
 *
 * > **A reading of a buyer's project must score only what the buyer CHANGED.**
 *
 * That law does NOT bar reading `damage.elementId` or `mpCost`: those are MECHANICAL fields whose
 * values the buyer sets per skill, not a shipped vocabulary being mistaken for a choice. What it
 * bars is inferring from stock TEXT. So the ladder below is: an explicit tag the buyer wrote, then
 * the buyer's own mechanical fields, and only then a deterministic spread over the id - never a
 * constant, because a constant IS the twelve-times-out-of-twelve failure.
 */

var CourtcardReading = CourtcardReading || {};

(function (R) {
    'use strict';

    var _deps = null;

    /** Resolve siblings at FIRST USE (wing §8 trap 2). */
    function deps() {
        if (_deps) return _deps;
        var corpus = (typeof CourtcardCorpus !== 'undefined') ? CourtcardCorpus
            : (typeof require !== 'undefined' ? require('./CourtcardCorpus.js') : null);
        var ink = (typeof CourtcardInk !== 'undefined') ? CourtcardInk
            : (typeof require !== 'undefined' ? require('./CourtcardInk.js') : null);
        if (!corpus || !ink) throw new Error('CourtcardReading: CourtcardCorpus and CourtcardInk must both be loaded');
        _deps = { corpus: corpus, ink: ink };
        return _deps;
    }
    R.deps = deps;

    /**
     * MZ's stock element table, by INDEX. `System.json` ships
     * ["", "Physical", "Fire", "Ice", "Thunder", "Water", "Earth", "Wind", "Light", "Darkness"].
     *
     * ⚠️ Indices are read rather than names, because a buyer who RENAMES element 2 to "Pyre" still
     * means fire and a name match would lose them. A buyer who reorders the table is handled by the
     * note tag, which is why the tag exists and is documented first.
     */
    R.STOCK_ELEMENTS = {
        2: 'ember', 3: 'frost', 4: 'storm', 5: 'venom', 6: 'stone', 7: 'gale', 8: 'radiance', 9: 'umbra'
    };

    /**
     * Read an explicit `<courtcard ...>` note tag.
     * @param {string} note @returns {object|null} whatever the buyer stated, nothing else
     */
    R.readTag = function (note) {
        var m = /<courtcard\s+([^>]*)>/i.exec(String(note || ''));
        if (!m) return null;
        var out = {};
        var re = /(\w+)\s*:\s*([^\s]+)/g, g;
        while ((g = re.exec(m[1])) !== null) {
            out[g[1].toLowerCase()] = g[2];
        }
        if (out.cost !== undefined) out.cost = Number(out.cost);
        return out;
    };

    /**
     * Deterministic spread over a string, for the LAST resort only.
     *
     * ⛔ The last resort must never be a CONSTANT. §24a's whole finding is that a fallback which
     * returns one answer renders one picture for the entire market, and §21g's is that a generator
     * picking from a small vocabulary has a degenerate tail. A hash spreads; a default does not.
     * @param {string} s @param {number} n @returns {number} 0..n-1
     */
    function spread(s, n) {
        var K = deps().ink;
        var h = 0;
        for (var i = 0; i < String(s).length; i++) h = (h * 31 + String(s).charCodeAt(i)) >>> 0;
        return Math.floor(K.nz(h) * n) % n;
    }
    R.spread = spread;

    /**
     * What TYPE a skill or item is, from what it actually DOES.
     *
     * ⚠️ Order matters and the specific cases come first: an item that both damages and adds a
     * state is a curse before it is a strike, because the state is the interesting half.
     * @param {object} row a $dataSkills / $dataItems row @returns {string} a type id
     */
    /**
     * The engine's two hard-wired skill ids. `Game_BattlerBase.prototype.attackSkillId()` returns 1
     * and `guardSkillId()` returns 2 (`rmmz_objects.js`), and NOTHING in the data tables says so —
     * Guard carries no effect, no damage and no state, and is identified by the engine comparing
     * the action's item against that id.
     *
     * ⚠️ This is NOT §24a's banned move. That law bars inferring from stock TEXT a buyer never
     * chose; these are ENGINE CONSTANTS about what a row DOES. Without them the stock skill
     * literally named Guard fell through to the last-resort pool and came out as `curse` — a
     * defensive skill drawn as a knot around a broken shaft, on the one row every MZ project has.
     * MEASURED by `spread_check` against the unmodified BlankProject database.
     */
    R.ENGINE_SKILL_IDS = { 1: 'strike', 2: 'guard' };

    R.readType = function (row) {
        var C = deps().corpus;
        var d = row.damage || {};
        var eff = row.effects || [];
        var has = function (code) { return eff.some(function (e) { return e && e.code === code; }); };

        // the engine's own two, before anything else — see ENGINE_SKILL_IDS above
        if (row.stypeId !== undefined && R.ENGINE_SKILL_IDS[row.id]) return R.ENGINE_SKILL_IDS[row.id];

        // 11 HP recover, 12 MP recover, 13 TP gain, 21 add state, 22 remove state,
        // 31 add buff, 32 add debuff, 41 special, 42 grow, 43 learn skill, 44 common event
        if (has(21) && (d.type === 0 || !d.type)) return 'curse';
        if (has(43) || has(42)) return 'relic';
        if (has(44)) return 'summon';
        if (has(11) || has(12) || has(13) || d.type === 3 || d.type === 4) return 'mend';
        if (has(31)) return 'aura';
        if (has(32)) return 'curse';
        if (has(22)) return 'mend';

        if (d.type === 1 || d.type === 5) {
            // a damaging row: physical vs magical decides blade or hand
            if (row.hitType === 1) return 'strike';
            if (row.hitType === 2) return 'spell';
            return d.elementId === 1 ? 'strike' : 'spell';
        }
        if (d.type === 2 || d.type === 6) return 'trap';

        // no damage and no effects: a passive or an object
        if (row.occasion === 3) return 'aura';
        if (row.scope === 0) return 'relic';

        // ⛔ LAST RESORT, AND IT SPREADS. A constant here is §24a's twelve-out-of-twelve.
        var pool = ['guard', 'beast', 'rush', 'ruin', 'relic', 'trap'];
        return pool[spread((row.name || '') + '|' + (row.id || 0), pool.length)];
    };

    /**
     * What ELEMENT a row carries.
     * @param {object} row @returns {string} an element id
     */
    R.readElement = function (row) {
        var C = deps().corpus;
        var d = row.damage || {};
        var id = Number(d.elementId || 0);
        if (R.STOCK_ELEMENTS[id]) return R.STOCK_ELEMENTS[id];
        // a buyer's own element beyond the stock nine: spread it, deterministically and stably
        if (id > 9) {
            return C.ELEMENTS[spread('element#' + id, C.ELEMENTS.length)].id;
        }
        return C.ELEMENTS[spread((row.name || '') + '|e|' + (row.id || 0), C.ELEMENTS.length)].id;
    };

    /**
     * What the card COSTS, in pips.
     * @param {object} row @returns {number}
     */
    R.readCost = function (row) {
        if (row.mpCost) return Math.max(1, Math.round(row.mpCost / 4));
        if (row.tpCost) return Math.max(1, Math.round(row.tpCost / 10));
        if (row.price) return Math.max(1, Math.round(Math.log(row.price + 1) / Math.log(2.6)));
        return 1 + spread('cost|' + (row.name || '') + (row.id || 0), 5);
    };

    /**
     * ⛔ RARITY THRESHOLDS ARE ANCHORED TO THE ENGINE'S OWN DATABASE, NEVER TO TASTE.
     *
     * Wing §21i: `BlankProject/data/Items.json` ships Potion at 500, Magic Water at 300 and Super
     * Potion at 1500, so THOSE numbers decide the tiers and §22a-6's warning about invented
     * thresholds is satisfied by construction rather than by argument.
     *
     * ⚠️ `effects[].value1` IS A FRACTION OF THE MAX BAR, NOT A POINT COUNT — the same section
     * records scoring it as 100 points making MZ's Full Potion read as one fifth of a stock Potion,
     * so the grandest healing item in the vendor database drew the smallest pot on the shelf. Price
     * and cost are used here instead, and both are absolute.
     */
    R.PRICE_TIERS = [0, 300, 500, 1500, 4000];

    /**
     * @param {object} row @returns {string} a rarity id
     */
    R.readRarity = function (row) {
        var C = deps().corpus;
        var price = Number(row.price || 0);
        var mp = Number(row.mpCost || 0);
        // a skill has no price, so its magnitude is what it costs to cast
        var score = price || (mp ? mp * 40 : 0);
        if (score > 0) {
            var t = 0;
            for (var i = 0; i < R.PRICE_TIERS.length; i++) if (score >= R.PRICE_TIERS[i]) t = i;
            return C.RARITIES[Math.min(t, C.RARITIES.length - 1)].id;
        }
        return C.RARITIES[spread('rarity|' + (row.name || '') + (row.id || 0), C.RARITIES.length)].id;
    };

    /**
     * Turn one database row into a complete card spec.
     *
     * @param {object} row a $dataSkills or $dataItems row
     * @param {object} [opts] {deck: default deck id, handling: 0..1}
     * @returns {object} a spec CourtcardCard.draw can take unchanged
     */
    R.readCard = function (row, opts) {
        var C = deps().corpus;
        var o = opts || {};
        var tag = R.readTag(row.note) || {};

        var deck = tag.deck && C.deck(tag.deck) ? tag.deck
            : (o.deck && C.deck(o.deck) ? o.deck : C.DECKS[spread('deck|' + (row.id || 0), C.DECKS.length)].id);

        var type = tag.type && C.type(tag.type) ? tag.type : R.readType(row);
        var element = tag.element && C.element(tag.element) ? tag.element : R.readElement(row);
        var rarity = tag.rarity && C.rarity(tag.rarity) ? tag.rarity : R.readRarity(row);
        var cost = (typeof tag.cost === 'number' && !isNaN(tag.cost)) ? tag.cost : R.readCost(row);

        return {
            rarity: rarity, type: type, element: element, cost: cost, deck: deck,
            title: String(row.name || ''),
            seed: Number(row.id || 0) * 7919,
            handling: typeof o.handling === 'number' ? o.handling : 0.10,
            // ⚠️ reported so a caller can tell a buyer's STATED card from an inferred one. Master
            // §2b: name the difference rather than letting an inference look like a declaration.
            fromTag: Object.keys(tag).length > 0
        };
    };

    if (typeof module !== 'undefined' && module.exports) { module.exports = R; }
}(CourtcardReading));

if (typeof module !== 'undefined' && module.exports) { module.exports = CourtcardReading; }
