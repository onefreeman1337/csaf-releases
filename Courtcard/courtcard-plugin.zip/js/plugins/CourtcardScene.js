//=============================================================================
// CourtcardScene.js — Courtcard [9/9]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [Courtcard] The deck viewer scene, the plugin commands and the save seam. The only
 * file that touches the engine.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @param deck
 * @text Default deck
 * @desc Which deck's stock, palette and back a card takes when nothing says otherwise.
 * @type select
 * @option courtly
 * @option grim
 * @option verdant
 * @option abyssal
 * @option gilded
 * @option ashen
 * @default courtly
 *
 * @param handling
 * @text Handling wear
 * @desc How used the deck looks. 0 is mint from the printer, 1 is well played. Try 0.10.
 * @type number
 * @decimals 2
 * @min 0
 * @max 1
 * @default 0.10
 *
 * @param source
 * @text Card source
 * @desc Which database the deck viewer reads when a plugin command does not name one.
 * @type select
 * @option skills
 * @option items
 * @option both
 * @default skills
 *
 * @param cardWidth
 * @text Card width
 * @desc 0 = fit the screen automatically (recommended). Otherwise a width in px; height follows the card proportion.
 * @type number
 * @min 0
 * @max 320
 * @default 0
 *
 * @command openDeck
 * @text Open the deck viewer
 * @desc Opens the Courtcard viewer on a source of cards.
 *
 * @arg source
 * @text Source
 * @type select
 * @option skills
 * @option items
 * @option both
 * @default skills
 *
 * @arg deck
 * @text Deck
 * @desc Leave blank to use the plugin's default deck.
 * @default
 *
 * @command setDeck
 * @text Set the deck
 * @desc Changes which deck new cards are printed on. Saved with the game.
 *
 * @arg deck
 * @text Deck
 * @type select
 * @option courtly
 * @option grim
 * @option verdant
 * @option abyssal
 * @option gilded
 * @option ashen
 * @default courtly
 *
 * @command clearDeck
 * @text Clear the deck override
 * @desc Goes back to the plugin's default deck.
 *
 * @help
 * CourtcardScene.js
 *
 * ── ⛔ WHY THIS PLUGIN REGISTERS COMMANDS AT ALL ─────────────────────────────────────────────
 *
 * Wing §24b, measured on Frontispiece: `mz_gate` reported **NOT CLEAN — "ZERO plugin commands were
 * registered AND every run measured a stock MZ scene"** on a product whose entire purpose was
 * replacing that scene. The gate's heuristic is sound and it cannot see the difference.
 *
 * > **Do not argue with the guard and do not route around it** (master §8.9a). The honest fix is to
 * > give the product the commands it should have had anyway.
 *
 * `setDeck` and `clearDeck` are real features — a game can print its cards on the Abyssal stock
 * after a chapter turn — and they make the gate's premise true rather than working around it.
 *
 * ── THE SAVE SEAM ────────────────────────────────────────────────────────────────────────────
 *
 * The chosen deck is REAL save data, so it is a plain enumerable property with a version beside it.
 * ⚠️ §13's `enumerable: false` trick is for a RUNTIME WRAPPER that must not be serialised — the
 * opposite problem — and applying it here would silently drop the buyer's own setting from every
 * save. Read that section before touching this.
 *
 * ── NO STOCK CHROME, BY CONSTRUCTION ─────────────────────────────────────────────────────────
 *
 * The scene extends `Scene_Base` rather than `Scene_MenuBase`, so no window layer, no background
 * filter and — the one that matters — no `Sprite_Button`. §15's correction is that `windowsDrawn: 0`
 * is NOT sufficient proof of Gate 1 because MZ's touch-UI controls are `Sprite_Button`, not
 * `Window_Base`; a started `Scene_Map` reports four stock buttons with `windows: 0` still true.
 * Extending the bare base means there is nothing to hide.
 *
 * ⚠️ And §15a: no mechanical check in this factory has an opinion about a TYPEFACE. Every string
 * here is set in `CourtcardCorpus.TYPEFACE.display`, never in `$gameSystem.mainFontFace()`.
 */

var CourtcardScene = CourtcardScene || {};

(function (S) {
    'use strict';

    var PLUGIN = 'CourtcardScene';
    var _deps = null;

    /** Resolve siblings at FIRST USE (wing §8 trap 2 — the harness loads ALPHABETICALLY). */
    function deps() {
        if (_deps) return _deps;
        var d = {
            corpus: typeof CourtcardCorpus !== 'undefined' ? CourtcardCorpus : null,
            ink: typeof CourtcardInk !== 'undefined' ? CourtcardInk : null,
            card: typeof CourtcardCard !== 'undefined' ? CourtcardCard : null,
            reading: typeof CourtcardReading !== 'undefined' ? CourtcardReading : null
        };
        for (var k in d) {
            if (!d[k]) throw new Error('CourtcardScene: sibling "' + k + '" is not loaded');
        }
        _deps = d;
        return d;
    }
    S.deps = deps;

    // ─────────────────────────────────────────────────────────── PARAMETERS
    //
    // ⛔ WING §16: plugin parameters arrive as STRINGS, and `Number('')` is 0 rather than NaN — so a
    // blank must be treated as ABSENT, never as zero. And ⛔ `"0"` IS TRUTHY: `if (p.variableId)`
    // fired on the string "0" and disabled Augury's headline feature with every headless check
    // green. Coerce with `Number()` and compare against zero; never test the raw property.

    var RAW = (typeof PluginManager !== 'undefined' && PluginManager.parameters)
        ? PluginManager.parameters(PLUGIN) : {};

    /** @param {string} v @param {number} dflt @returns {number} */
    function num(v, dflt) {
        if (v === undefined || v === null || String(v).trim() === '') return dflt;
        var n = Number(v);
        return isNaN(n) ? dflt : n;
    }
    /** @param {string} v @param {string} dflt @returns {string} */
    function str(v, dflt) {
        return (v === undefined || v === null || String(v).trim() === '') ? dflt : String(v).trim();
    }

    S.params = {
        deck: str(RAW.deck, 'courtly'),
        handling: num(RAW.handling, 0.10),
        source: str(RAW.source, 'skills'),
        // ⛔ 0 = AUTO, and it must match the @param @default above. Two statements of one default
        // do not drift, one WINS (wing §11a) — and this is the copy that runs, so a stale 132 here
        // would quietly disable the frame solve for every buyer who never opens Plugin Manager.
        cardWidth: num(RAW.cardWidth, 0)
    };

    // ─────────────────────────────────────────────────────────── THE SAVE SEAM

    /** The schema version, so a later change can migrate rather than break a save. */
    S.SAVE_VERSION = 1;

    /**
     * The deck the game is currently printing on.
     * @returns {string} a deck id that is guaranteed to resolve
     */
    S.currentDeck = function () {
        var C = deps().corpus;
        var sys = (typeof $gameSystem !== 'undefined') ? $gameSystem : null;
        var chosen = sys && sys._csafCourtcard ? sys._csafCourtcard.deck : null;
        if (chosen && C.deck(chosen)) return chosen;
        return C.deck(S.params.deck) ? S.params.deck : C.DECKS[0].id;
    };

    /** @param {string|null} deckId null clears the override */
    S.setDeck = function (deckId) {
        var C = deps().corpus;
        if (typeof $gameSystem === 'undefined' || !$gameSystem) return false;
        if (deckId !== null && !C.deck(deckId)) return false;
        if (!$gameSystem._csafCourtcard) {
            $gameSystem._csafCourtcard = { v: S.SAVE_VERSION, deck: null };
        }
        // ⚠️ MIGRATION, not a reset. A save written by an older version keeps its data and gains
        // the new fields; overwriting the record would discard the buyer's own setting.
        if ($gameSystem._csafCourtcard.v !== S.SAVE_VERSION) {
            $gameSystem._csafCourtcard.v = S.SAVE_VERSION;
        }
        $gameSystem._csafCourtcard.deck = deckId;
        return true;
    };

    // ─────────────────────────────────────────────────────────── CARD SOURCES

    /**
     * The rows a viewer should show.
     *
     * ⛔ A DIVIDER IS NOT A CARD, AND THE STOCK DATABASE IS FULL OF THEM. MEASURED 2026-09-05 by
     * the FRESH-INSTALL probe — i.e. by looking at the screen a buyer sees on their very first run,
     * which no other instrument in this product renders. The unmodified Blank Project's
     * `Skills.json` carries rows literally named `-----Reserved-----` and `-----Enemy-----`, and
     * page one of the viewer printed two cards with those on their nameplates. They are engine
     * scaffolding, and `-----name-----` is the universal RPG Maker convention for a SEPARATOR row
     * in any database — every serious project uses it — so this is not a Blank-Project-only
     * artefact and it would have printed a card for every divider in the buyer's own tables.
     *
     * ⚠️ The old filter was correct about what it tested (`name` non-empty) and the sentence above
     * it, "blanks removed", read as though it covered this. It did not: a divider is not blank.
     *
     * ⛔ THE RULE WAS WRITTEN WRONG FIRST, AND READING THE ACTUAL DATA IS WHAT FIXED IT. The
     * obvious test — "a name with no letter or digit in it is punctuation" — catches a bare
     * `-----` and catches NONE of the real ones, because MZ's dividers carry a LABEL:
     * `Skills.json` in the stock Blank Project holds `-----Reserved`, `-----Enemy`,
     * `-----Basic Magic`, `-----Swordsman Skills`, `-----Priest & Sorcerer Skills`,
     * `-----Knight Skills`, `-----Bandit Skills`, `-----Martial Artist Skills` and
     * `-----Hunter Skills`. All nine have letters. A rule that "reads sensibly" and was never run
     * against the data would have shipped nine divider cards.
     *
     * So the test is the CONVENTION, measured: a name that OPENS with two or more punctuation
     * characters is a separator. ⚠️ The same table proves why it must be a LEADING test rather
     * than "contains a dash": `Warm-up` (id 207) is a real skill with a dash in the middle, and a
     * contains-rule would delete it. A real name begins with a letter.
     *
     * @param {string} source 'skills' | 'items' | 'both'
     * @returns {object[]} real database rows; blanks and divider rows removed
     */
    /**
     * Is this database row name a SEPARATOR rather than a real entry?
     *
     * Exported so the suite can test it directly against the stock names rather than inferring it
     * from a rendered page — a rule tested only through the viewer is a rule nobody can see fail.
     * @param {string} name @returns {boolean}
     */
    S.isDivider = function (name) {
        var nm = String(name == null ? '' : name).trim();
        if (nm === '') return true;
        if (!/[0-9a-z]/i.test(nm)) return true;         // `-----`, `=====`, `***` on their own
        return /^[-=_~*.#+<>|/\\]{2,}/.test(nm);        // `-----Basic Magic`, the MZ convention
    };

    S.rowsFor = function (source) {
        var out = [];
        var push = function (arr) {
            if (!arr) return;
            for (var i = 0; i < arr.length; i++) {
                var r = arr[i];
                // ⚠️ MZ's data arrays are 1-based with a null at 0, and the stock database also
                // carries unnamed placeholder rows. A card with no name has nothing to print.
                if (!r || !r.name) continue;
                var nm = String(r.name).trim();
                if (nm === '') continue;
                if (S.isDivider(nm)) continue;
                out.push(r);
            }
        };
        if (source === 'items') push(typeof $dataItems !== 'undefined' ? $dataItems : null);
        else if (source === 'both') {
            push(typeof $dataSkills !== 'undefined' ? $dataSkills : null);
            push(typeof $dataItems !== 'undefined' ? $dataItems : null);
        } else push(typeof $dataSkills !== 'undefined' ? $dataSkills : null);
        return out;
    };

    /**
     * Render one card into a fresh MZ Bitmap.
     *
     * ⛔ `bitmap.context` is the real 2D context (`rmmz_core.js:1369`, via `_ensureCanvas`), and a
     * custom draw MUST be pushed to the GPU afterwards or the sprite shows an empty texture. This
     * is the shipped pattern from this wing's own Elytra scene, verified in the engine source
     * rather than remembered (§3a: copy an engine method's behaviour, never paraphrase it).
     *
     * @param {object} spec @param {number} w @returns {Bitmap}
     */
    S.cardBitmap = function (spec, w) {
        var C = deps().corpus, Cd = deps().card;
        var h = Math.ceil(w * C.ASPECT);
        var bmp = new Bitmap(w, h);
        var ctx = bmp.context;
        ctx.save();
        Cd.draw(ctx, 0, 0, w, spec);
        ctx.restore();
        if (bmp._baseTexture && bmp._baseTexture.update) bmp._baseTexture.update();
        return bmp;
    };

    // ─────────────────────────────────────────────────────────── THE SCENE

    function Scene_Courtcard() { this.initialize.apply(this, arguments); }
    Scene_Courtcard.prototype = Object.create(Scene_Base.prototype);
    Scene_Courtcard.prototype.constructor = Scene_Courtcard;
    S.Scene_Courtcard = Scene_Courtcard;

    Scene_Courtcard.prototype.initialize = function () {
        Scene_Base.prototype.initialize.call(this);
        this._index = 0;
        this._cards = [];
        this._sprites = [];
        this._page = 0;
        this._needsLayout = true;
    };

    /**
     * The grid, SOLVED rather than typed.
     *
     * ⛔⛔ THIS COMMENT USED TO SAY "solved rather than typed" OVER CODE THAT TYPED THE CARD AND
     * LET THE GRID FALL OUT OF IT, which is a claimed property standing in for a checked one. The
     * card width was a plugin param, `cols` and `rows` were whatever happened to fit, and whatever
     * was left over became flat ground. MEASURED 2026-09-05 on the shipped default (132 px, 816x624):
     * 5x2 cards occupying 236,600 of 509,184 px = **46.5% of the frame**, with 123 px of dead
     * height and 94 px of dead width. Wing §18b is exactly this defect, found on Glaze's shelf:
     * "a hard-coded cols left twelve vessels width-bound and a third of the frame empty air.
     * Cropping cannot fix that, and it is WORSE IN THE BUYER'S GAME than in the capture, which is
     * the test of whether a layout fix is real."
     *
     * So the card is now derived and the grid is the thing chosen. Both gaps are the same multiple
     * of the card width (gapX = 0.14w, gapY = 0.10h = 0.10 x 1.40w = 0.14w), so each candidate
     * grid closes to a single inequality per axis and the largest admissible card falls straight
     * out:
     *     width :  w * (cols + 0.14(cols-1))        <= availW
     *     height:  w * (1.40 rows + 0.14(rows-1))   <= availH
     *
     * ⚠️ §18b BREAKS TIES ON FEWEST EMPTY CELLS AND THAT TIEBREAK IS WRONG HERE — copying it would
     * be a number remembered rather than measured. Glaze had a FIXED population of twelve pots, so
     * a half-empty last row was a real defect in a known picture. This viewer paginates the
     * BUYER'S database, whose length is unknowable at design time, so "fewest empty cells" would
     * tune the layout to one project's skill count and be wrong for every other. The tiebreak that
     * is database-independent is MORE CARDS PER PAGE: a denser page is fewer page turns for any
     * population, and it never argues that the buyer's inventory is short.
     *
     * MEASURED after: 4x2 at 171 px = 64.7% of the frame, against 46.5% before — and the card is
     * 1.7x the area, which is what lets the engraved charge actually read.
     *
     * `cardWidth` 0 means AUTO and is the default. A buyer who types a width still gets it.
     * @returns {object}
     */
    Scene_Courtcard.prototype.layout = function () {
        var C = deps().corpus;
        var W = Graphics.width, H = Graphics.height;
        var head = Math.round(H * 0.105);
        var foot = Math.round(H * 0.085);
        var padX = Math.round(W * 0.035);
        var availW = W - padX * 2;
        var availH = H - head - foot;

        var w = S.params.cardWidth, cols, rows;
        if (w > 0) {
            // an explicit width: keep the old behaviour exactly, so a buyer's setting is honoured
            var gx = Math.round(w * 0.14), gy = Math.round(w * C.ASPECT * 0.10);
            cols = Math.max(1, Math.floor((availW + gx) / (w + gx)));
            rows = Math.max(1, Math.floor((availH + gy) / (w * C.ASPECT + gy)));
        } else {
            // ⛔⛔ "KEEP THE LARGEST CELL" IS §18b's RULE AND ON ITS OWN IT IS DEGENERATE HERE.
            // MEASURED 2026-09-05, first run of this solver: with the page size free, the largest
            // card is always the one on a page holding the FEWEST cards — it chose 2x1 at 354 px,
            // i.e. 68.9% frame coverage and TWO cards, which is 75 pages for a 149-card database.
            // Glaze's shelf had a FIXED twelve pots that all had to fit, so its search could not
            // reach this degenerate corner; this viewer paginates, so it can, and it went straight
            // there. ⭐ The tell was NOT a failing check — `in_engine.js` printed
            // "PASS ... 2 distinct builds across 2 cards on page one", a PASS whose own number said
            // the page had collapsed, and its assertion (every card differs) is near-vacuous at
            // n=2 (§2b: require a non-empty set before believing any `every()`).
            //
            // ⛔ AND FRAME COVERAGE ALONE DOES NOT FIX IT: 2x1 scores 68.9% against 4x2's 64.3%,
            // so the obvious objective picks the same degenerate grid. The missing constraint is a
            // PRODUCT one, not a geometric one.
            //
            // ⭐ THE FLOOR COMES FROM THE PRODUCT'S OWN KILL CONDITION, which is the only
            // non-arbitrary place to get it: "52+ faces must read as ONE DECK rather than 52
            // unrelated pictures". A page showing one or two cards cannot show coherence AT ALL —
            // the buyer never sees a set, so the thing this product is sold on is invisible in it.
            // Two full rows is the smallest arrangement that reads as a set rather than a row.
            var MIN_PER_PAGE = 8;
            /**
             * Largest admissible card over every grid holding at least `floor` cards.
             * @param {number} floor cards per page required
             * @returns {?{w:number, cols:number, rows:number}}
             */
            var search = function (floor) {
                var b = null;
                for (var c = 2; c <= 7; c++) {
                    for (var r = 1; r <= 4; r++) {
                        if (c * r < floor) continue;
                        var byW = availW / (c + 0.14 * (c - 1));
                        var byH = availH / (C.ASPECT * r + 0.14 * (r - 1));
                        var cand = Math.floor(Math.min(byW, byH));
                        if (cand < 80) continue;         // the param's own @min: below this a card cannot be read
                        // largest card wins; within 1% it is a tie, broken by a denser page
                        if (!b || cand > b.w * 1.01
                            || (cand > b.w * 0.99 && c * r > b.cols * b.rows)) {
                            b = { w: cand, cols: c, rows: r };
                        }
                    }
                }
                return b;
            };
            // ⚠️ THE FALLBACK RELAXES THE PRODUCT FLOOR, IT DOES NOT ABANDON THE SOLVE. A frame too
            // small to seat eight readable cards is a real configuration (a buyer running a
            // reduced Graphics size), and dropping straight to 1x1 there would be a worse layout
            // than the search can still find. Re-running with no floor degrades one step at a
            // time; only a frame that cannot seat a single 80 px card reaches the last resort,
            // and that returns a drawable layout rather than null so `create()` cannot fault far
            // away from the cause.
            var best = search(MIN_PER_PAGE) || search(1) || { w: 80, cols: 1, rows: 1 };
            w = best.w; cols = best.cols; rows = best.rows;
        }

        var h = w * C.ASPECT;
        var gapX = Math.round(w * 0.14), gapY = Math.round(h * 0.10);
        var gridW = cols * w + (cols - 1) * gapX;
        var gridH = rows * h + (rows - 1) * gapY;
        return {
            w: w, h: h, cols: cols, rows: rows, per: cols * rows,
            x0: Math.round((W - gridW) / 2),
            y0: Math.round(head + (availH - gridH) / 2),
            gapX: gapX, gapY: gapY, head: head, foot: foot
        };
    };

    Scene_Courtcard.prototype.create = function () {
        Scene_Base.prototype.create.call(this);
        var C = deps().corpus, K = deps().ink, R = deps().reading;

        this._layout = this.layout();
        var rows = S.rowsFor(this._source || S.params.source);
        var deck = this._deck || S.currentDeck();
        var self = this;
        this._cards = rows.map(function (r) {
            var spec = R.readCard(r, { deck: deck, handling: S.params.handling });
            spec.flatPalette = false;
            return { row: r, spec: spec };
        });
        this._deckId = deck;

        this.createBackdrop();
        this.createCards();
        this.createChrome();
        this._needsLayout = false;
    };

    /**
     * The backdrop: a table the cards are laid on, drawn from the deck's own stock so the scene is
     * part of the same object rather than a grey panel behind it.
     */
    Scene_Courtcard.prototype.createBackdrop = function () {
        var C = deps().corpus, K = deps().ink;
        var deck = C.deck(this._deckId);
        var bmp = new Bitmap(Graphics.width, Graphics.height);
        var ctx = bmp.context;
        // a dark table, solved from the deck's own ground so every deck sits on its own surface
        var table = K.relief(deck.ground, K.lum(deck.ground) > 127 ? -1 : -1, 96);
        ctx.fillStyle = K.css(table);
        ctx.fillRect(0, 0, Graphics.width, Graphics.height);
        // a raking sheen from the product's ONE declared light (§11a)
        var g = ctx.createLinearGradient(0, 0, Graphics.width * 0.8, Graphics.height);
        g.addColorStop(0, K.rgba(K.relief(table, 1, 26), 0.55));
        g.addColorStop(1, K.rgba(table, 0));
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, Graphics.width, Graphics.height);
        if (bmp._baseTexture && bmp._baseTexture.update) bmp._baseTexture.update();
        this._backdrop = new Sprite(bmp);
        this.addChild(this._backdrop);
    };

    Scene_Courtcard.prototype.createCards = function () {
        var L = this._layout;
        this._cardLayer = new Sprite();
        this.addChild(this._cardLayer);
        this._sprites = [];
        for (var i = 0; i < L.per; i++) {
            var sp = new Sprite();
            sp.anchor.x = 0.5;
            sp.anchor.y = 0.5;
            this._cardLayer.addChild(sp);
            this._sprites.push(sp);
        }
        this.refreshPage();
    };

    /** Draw the page's cards. Bitmaps are built ONCE per page, never per frame. */
    Scene_Courtcard.prototype.refreshPage = function () {
        var L = this._layout;
        var start = this._page * L.per;
        for (var i = 0; i < this._sprites.length; i++) {
            var sp = this._sprites[i];
            var card = this._cards[start + i];
            if (!card) { sp.visible = false; continue; }
            sp.visible = true;
            if (!card.bitmap) card.bitmap = S.cardBitmap(card.spec, L.w);
            sp.bitmap = card.bitmap;
            var col = i % L.cols, row = Math.floor(i / L.cols);
            sp.x = L.x0 + col * (L.w + L.gapX) + L.w / 2;
            sp.y = L.y0 + row * (L.h + L.gapY) + L.h / 2;
            sp.scale.x = sp.scale.y = 1;
        }
    };

    /** Header and footer, set in the product's own typeface (§15a). */
    Scene_Courtcard.prototype.createChrome = function () {
        var C = deps().corpus, K = deps().ink;
        var deck = C.deck(this._deckId);
        var L = this._layout;
        var bmp = new Bitmap(Graphics.width, Graphics.height);
        this._chrome = new Sprite(bmp);
        this.addChild(this._chrome);
        this.refreshChrome();
    };

    Scene_Courtcard.prototype.refreshChrome = function () {
        var C = deps().corpus, K = deps().ink;
        var deck = C.deck(this._deckId);
        var L = this._layout;
        var bmp = this._chrome.bitmap;
        var ctx = bmp.context;
        bmp.clear();

        var table = K.relief(deck.ground, -1, 96);
        var ink = K.inkFor(table, deck.ground, 7, 0.02).ink;
        var card = this._cards[this._page * L.per + this._index];

        ctx.save();
        ctx.textBaseline = 'middle';
        ctx.fillStyle = K.css(ink);

        // ── the header: the deck's name, struck and letterspaced
        var hs = Math.round(L.head * 0.40);
        ctx.font = hs + 'px ' + C.TYPEFACE.display;
        var title = deck.name.toUpperCase();
        var gap = hs * 0.22;
        var total = ctx.measureText(title).width + gap * Math.max(0, title.length - 1);
        var x = (Graphics.width - total) / 2;
        for (var i = 0; i < title.length; i++) {
            ctx.fillText(title[i], x, L.head * 0.52);
            x += ctx.measureText(title[i]).width + gap;
        }
        // a rule under it, inset from the type rather than the frame
        ctx.strokeStyle = K.css(ink);
        ctx.globalAlpha = 0.45;
        ctx.lineWidth = Math.max(1, Graphics.width * 0.0012);
        ctx.beginPath();
        ctx.moveTo(Graphics.width * 0.30, L.head * 0.80);
        ctx.lineTo(Graphics.width * 0.70, L.head * 0.80);
        ctx.stroke();
        ctx.globalAlpha = 1;

        // ── the footer: what the selected card actually IS, so the axes are legible in play
        var fs = Math.round(L.foot * 0.34);
        ctx.font = fs + 'px ' + C.TYPEFACE.display;
        var pages = Math.max(1, Math.ceil(this._cards.length / L.per));
        var line = card
            ? card.row.name + '   ·   ' + C.rarity(card.spec.rarity).name
                + '   ·   ' + C.type(card.spec.type).name
                + '   ·   ' + C.element(card.spec.element).name
                + '   ·   cost ' + card.spec.cost
            : 'no cards';
        ctx.fillText(line, Graphics.width * 0.045, Graphics.height - L.foot * 0.52);
        var pg = 'page ' + (this._page + 1) + ' / ' + pages;
        ctx.fillText(pg, Graphics.width - Graphics.width * 0.045 - ctx.measureText(pg).width,
            Graphics.height - L.foot * 0.52);
        ctx.restore();

        if (bmp._baseTexture && bmp._baseTexture.update) bmp._baseTexture.update();
    };

    Scene_Courtcard.prototype.start = function () {
        Scene_Base.prototype.start.call(this);
        this.startFadeIn(this.fadeSpeed(), false);
    };

    /**
     * ⛔ ZERO ALLOCATION IN THE PER-FRAME PATH (wing §3, quality bar). No object, array or closure
     * literal is created here and nothing calls `.map`/`.filter`/`.slice`. The selection lift is a
     * scale assignment on sprites that already exist.
     */
    Scene_Courtcard.prototype.update = function () {
        Scene_Base.prototype.update.call(this);
        this.updateInput();
        this.updateSelection();
    };

    Scene_Courtcard.prototype.updateInput = function () {
        var L = this._layout;
        var moved = false;
        var before = this._index;
        var beforePage = this._page;
        if (Input.isRepeated('right')) { this._index += 1; moved = true; }
        if (Input.isRepeated('left')) { this._index -= 1; moved = true; }
        if (Input.isRepeated('down')) { this._index += L.cols; moved = true; }
        if (Input.isRepeated('up')) { this._index -= L.cols; moved = true; }
        if (Input.isTriggered('pagedown')) { this._page += 1; this._index = 0; moved = true; }
        if (Input.isTriggered('pageup')) { this._page -= 1; this._index = 0; moved = true; }

        if (moved) {
            var pages = Math.max(1, Math.ceil(this._cards.length / L.per));
            // walking off one edge of a page turns the page, which is what a deck does
            if (this._index < 0) {
                if (this._page > 0) { this._page -= 1; this._index = L.per - 1; } else this._index = 0;
            } else if (this._index >= L.per) {
                if (this._page < pages - 1) { this._page += 1; this._index = 0; } else this._index = L.per - 1;
            }
            if (this._page < 0) this._page = 0;
            if (this._page > pages - 1) this._page = pages - 1;
            var last = this._cards.length - this._page * L.per - 1;
            if (this._index > last) this._index = last < 0 ? 0 : last;

            if (this._page !== beforePage) this.refreshPage();
            if (this._index !== before || this._page !== beforePage) {
                SoundManager.playCursor();
                this.refreshChrome();
            }
        }
        if (Input.isTriggered('cancel') || Input.isTriggered('escape')) {
            SoundManager.playCancel();
            this.popScene();
        }
    };

    /** Lift the selected card. One scale assignment per sprite, no allocation. */
    Scene_Courtcard.prototype.updateSelection = function () {
        for (var i = 0; i < this._sprites.length; i++) {
            var sp = this._sprites[i];
            if (!sp.visible) continue;
            var want = (i === this._index) ? 1.08 : 1.0;
            // an ease rather than a jump, and it settles exactly (no epsilon drift)
            var d = want - sp.scale.x;
            if (Math.abs(d) < 0.002) sp.scale.x = sp.scale.y = want;
            else { sp.scale.x += d * 0.28; sp.scale.y = sp.scale.x; }
        }
    };

    /** ⛔ Every listener and cached bitmap has a matching teardown (wing §3 quality bar). */
    Scene_Courtcard.prototype.terminate = function () {
        Scene_Base.prototype.terminate.call(this);
        for (var i = 0; i < this._cards.length; i++) {
            var c = this._cards[i];
            if (c.bitmap && c.bitmap.destroy) c.bitmap.destroy();
            c.bitmap = null;
        }
        this._cards.length = 0;
        this._sprites.length = 0;
    };

    /**
     * Open the viewer.
     * @param {string} [source] @param {string} [deck]
     */
    S.open = function (source, deck) {
        var C = deps().corpus;
        var Scene = S.Scene_Courtcard;
        Scene.prototype._source = source && ['skills', 'items', 'both'].indexOf(source) >= 0
            ? source : S.params.source;
        Scene.prototype._deck = deck && C.deck(deck) ? deck : null;
        SceneManager.push(Scene);
    };

    // ─────────────────────────────────────────────────────────── PLUGIN COMMANDS
    //
    // See the §24b note in the header: these are real features AND they make the gate's premise
    // true, which is the honest way past a guard that cannot see a replaced scene.

    if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
        PluginManager.registerCommand(PLUGIN, 'openDeck', function (args) {
            S.open(str(args.source, S.params.source), str(args.deck, ''));
        });
        PluginManager.registerCommand(PLUGIN, 'setDeck', function (args) {
            S.setDeck(str(args.deck, S.params.deck));
        });
        PluginManager.registerCommand(PLUGIN, 'clearDeck', function () {
            S.setDeck(null);
        });
    }

    if (typeof module !== 'undefined' && module.exports) { module.exports = S; }
}(CourtcardScene));

if (typeof module !== 'undefined' && module.exports) { module.exports = CourtcardScene; }
