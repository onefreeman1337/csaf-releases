//=============================================================================
// CourtcardCard.js — Courtcard [7/9]
//=============================================================================
/*:
 * @target MZ
 * @plugindesc [Courtcard] The assembler - draws one complete card face or back into a rect. Engine
 * free on purpose, so the scene, the probes and the store plates all draw the SAME card.
 * @author Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * CourtcardCard.js
 *
 * ── WHY THE ASSEMBLER IS NOT IN THE SCENE ────────────────────────────────────────────────────
 *
 * ⛔ WING §11a AND §21h, TOGETHER. If the scene assembled the card, then every contact sheet, every
 * probe and every store plate would have to assemble a SECOND one - and a second copy of a
 * composition does not drift, it WINS somewhere. Arras computed one panel width in two places, the
 * scene's copy silently won, and two rebuilds plus a port change were spent before anyone grepped
 * for the number. §21h is the same failure through the other door: a caption read off a
 * development preview said "19 notes" while the product's own layout wrapped to three lines.
 *
 * So there is ONE `draw()`. The scene calls it, `contact_sheet.js` calls it, `make_store_plates.js`
 * calls it. A picture in the gallery is then the picture in the buyer's game BY CONSTRUCTION, and
 * a caption pinned to what this function returns cannot disagree with what it drew.
 *
 * ── THE PALETTE IS SOLVED, NOT PASSED ────────────────────────────────────────────────────────
 *
 * `palette()` is the only place a card's four working colours come from, and all four are derived
 * from the deck's stock. §22e: an ink chosen independently of what it lands on is a defect waiting
 * - card titles were once drawn in the palette's own ground colour, which was correct on a light
 * deck and left every title unreadable on the four dark ones.
 */

var CourtcardCard = CourtcardCard || {};

(function (Cd) {
    'use strict';

    var _deps = null;

    /** Resolve siblings at FIRST USE (wing §8 trap 2 — the harness loads ALPHABETICALLY). */
    function deps() {
        if (_deps) return _deps;
        var g = function (name, path) {
            return (typeof global !== 'undefined' && global[name]) ? global[name]
                : (typeof window !== 'undefined' && window[name]) ? window[name]
                    : (typeof require !== 'undefined' ? require(path) : null);
        };
        var d = {
            ink: (typeof CourtcardInk !== 'undefined') ? CourtcardInk : g('CourtcardInk', './CourtcardInk.js'),
            corpus: (typeof CourtcardCorpus !== 'undefined') ? CourtcardCorpus : g('CourtcardCorpus', './CourtcardCorpus.js'),
            frame: (typeof CourtcardFrame !== 'undefined') ? CourtcardFrame : g('CourtcardFrame', './CourtcardFrame.js'),
            device: (typeof CourtcardDevice !== 'undefined') ? CourtcardDevice : g('CourtcardDevice', './CourtcardDevice.js'),
            pips: (typeof CourtcardPips !== 'undefined') ? CourtcardPips : g('CourtcardPips', './CourtcardPips.js'),
            foil: (typeof CourtcardFoil !== 'undefined') ? CourtcardFoil : g('CourtcardFoil', './CourtcardFoil.js')
        };
        for (var k in d) {
            if (!d[k]) throw new Error('CourtcardCard: sibling "' + k + '" is not loaded');
        }
        _deps = d;
        return d;
    }
    Cd.deps = deps;

    /**
     * The four working colours of a card, all solved against the deck's own stock.
     *
     * @param {object} deck @returns {{body:number[], ink:number[], lit:number[], dark:number[], accent:number[]}}
     */
    Cd.palette = function (deck, element, flat) {
        var K = deps().ink;
        // which way "toward the ink" runs on this stock: dark ink on pale paper, or the reverse
        var toInk = K.lum(deck.body) < K.lum(deck.ground) ? -1 : 1;

        // ⛔⛔ `body` IS A WASH OF THE STOCK, NOT THE INK — AND THE FIRST VERSION OF THIS FUNCTION
        // SET THEM TO THE SAME COLOUR, WHICH IS §17c-1 IN ITS PUREST FORM. Every charge was filled
        // with `deck.body` and outlined with `deck.body`, so every outline, boss, eye socket, jaw
        // step and bracing bar was STROKED IN THE COLOUR IT WAS DRAWN ON. The ops all counted, the
        // paths were all built, and the whole device layer rendered as forty-eight flat black
        // blobs. MEASURED by looking at `sheet_types_160.png` — three builds read as the LETTERS f,
        // C and D, and the natural response is to re-author the geometry.
        //
        // ⭐ §22b-1b IS THE ENTRY THAT SAVES THE SESSION HERE: "a silent no-op in the detail layer
        // is indistinguishable, by eye, from bad drawing - so the natural response is to re-author
        // shapes that were never fully drawn. Check that first." An engraving is a LINE on PAPER
        // with tone between them, so the charge is filled with a wash of the stock and drawn in
        // ink, and every interior mark is solved against the wash rather than against the paper.
        var wash = K.relief(deck.ground, toInk, 30);

        // ── THE ELEMENT'S TINT.
        //
        // ⛔ `hue` AND `chroma` WERE DECLARED ON ALL EIGHT ELEMENTS AND READ BY NOTHING — a dead
        // axis in the §22a-2e sense, found by `corpus_check` arm 2b, and visible on the first
        // contact sheet as four cells per row that were the same colour. The element changed the
        // CUT and nothing else, so an ember card and a frost card were the same picture in the same
        // ink.
        //
        // ⚠️ AND THE OBVIOUS IMPLEMENTATION IS THE ONE §21a BANS. The tint is applied ONLY to the
        // charge's wash, by a BOUNDED amount, and only AFTER the structural cut has already made
        // the two cards different pictures — colour is confirming a difference the drawing already
        // carries, never creating one. `--flat` neutralises it precisely so the §25f structure
        // count is still asking its own question.
        if (element && !flat && element.chroma) {
            var hsl = K.toHsl(wash);
            // saturation is capped low: this is a tinted paper wash, not a painted card
            var sat = Math.min(0.34, hsl[1] + element.chroma * 0.30);
            wash = K.fromHsl([element.hue, sat, hsl[2]]);
        }

        return {
            ground: deck.ground,
            ink: deck.body,
            body: wash,
            lit: K.relief(wash, -toInk, 22),
            dark: K.relief(wash, toInk, 46),
            accent: deck.accent,
            toInk: toInk
        };
    };

    /**
     * Set a title into the nameplate, surrendering TRACKING before size.
     *
     * ⛔ WING §22f: a fitter that can fail to fit MUST SAY SO. `fitTracked` once shrank to its
     * minimum and returned a still-too-wide result, which the caller drew anyway, and "SEVEN OF
     * WANDS" shipped as "SEVEN OF WAND". This returns the squeeze it applied and whether it fitted,
     * and the caller is expected to read both.
     *
     * ⚠️ Typographic consistency is a SET property. Titles are fitted into a narrow size BAND and
     * tracking gives way first, so a short name is not set huge beside a long one - which is what
     * makes a deck look amateur even when every single card is fine.
     *
     * @returns {{size:number, tracking:number, fitted:boolean, width:number}}
     */
    Cd.fitTitle = function (ctx, text, maxW, maxH, font) {
        var hi = maxH * 0.62, lo = maxH * 0.44;
        var best = null;
        for (var size = hi; size >= lo; size -= 0.5) {
            for (var tr = 0.14; tr >= -0.02; tr -= 0.02) {
                ctx.font = Math.round(size * 100) / 100 + 'px ' + font;
                var w = ctx.measureText(text).width + tr * size * Math.max(0, text.length - 1);
                if (!best || w < best.width) best = { size: size, tracking: tr, width: w, fitted: false };
                if (w <= maxW) return { size: size, tracking: tr, width: w, fitted: true };
            }
        }
        return best || { size: lo, tracking: 0, width: maxW, fitted: false };
    };

    /** Draw letterspaced text, since canvas has no tracking. @returns {number} glyphs drawn */
    function tracked(ctx, text, cx, cy, size, tr, font, colour) {
        var K = deps().ink;
        ctx.font = Math.round(size * 100) / 100 + 'px ' + font;
        ctx.textBaseline = 'middle';
        ctx.fillStyle = K.css(colour);
        var gap = tr * size;
        var total = ctx.measureText(text).width + gap * Math.max(0, text.length - 1);
        var x = cx - total / 2;
        for (var i = 0; i < text.length; i++) {
            ctx.fillText(text[i], x, cy);
            x += ctx.measureText(text[i]).width + gap;
        }
        return text.length;
    }
    Cd.tracked = tracked;

    /**
     * Draw one complete card FACE.
     *
     * @param {CanvasRenderingContext2D} ctx
     * @param {number} x @param {number} y @param {number} w card width; height follows ASPECT
     * @param {object} spec {rarity, type, element, cost, deck, title, seed, handling}
     * @returns {object} a COUNT of what reached the bitmap, per layer — never a verdict
     */
    Cd.draw = function (ctx, x, y, w, spec) {
        var d = deps(), K = d.ink, C = d.corpus;
        var rarity = C.rarity(spec.rarity), deck = C.deck(spec.deck);
        if (!rarity) throw new Error('CourtcardCard: unknown rarity "' + spec.rarity + '"');
        if (!deck) throw new Error('CourtcardCard: unknown deck "' + spec.deck + '"');
        var L = C.layout(w);
        var el = C.element(spec.element);
        if (!el) throw new Error('CourtcardCard: unknown element "' + spec.element + '"');
        // ⛔ TWO PALETTES, AND THE SPLIT IS THE AXIS TABLE MADE LITERAL. The corpus says RARITY owns
        // the frame and ELEMENT owns the device's cut, so an element tint reaching the rails would
        // let one axis paint another's territory — measured on the first tinted sheet, where the
        // corner rosettes and the ornament band went blue on every frost card and violet on every
        // umbra one, making the rarity harder to read than before the tint existed. The frame takes
        // the deck's own untinted palette; only the charge and its own suit glyph are tinted.
        var Pframe = Cd.palette(deck, null, true);
        var P = Cd.palette(deck, el, !!spec.flatPalette);
        var seed = (spec.seed || 0) | 0;
        var report = {};

        ctx.save();
        ctx.translate(x, y);

        report.stock = d.frame.stock(ctx, 0, 0, L.w, L.h, deck, L.ink, seed);
        report.foil = d.foil.apply(ctx, L, rarity, deck, Pframe, seed);
        report.frame = d.frame.frame(ctx, L, rarity, Pframe, seed);

        var dev = d.device.draw(ctx, L.device, {
            type: spec.type, element: spec.element, seed: seed
        }, P, L.ink);
        report.device = dev;

        report.pips = d.pips.draw(ctx, L, { element: spec.element, cost: spec.cost }, P);

        var plate = d.frame.plate(ctx, L, rarity, deck, Pframe);
        report.plateInk = { ratio: Math.round(plate.ratio * 100) / 100, metWant: plate.metWant };

        var title = String(spec.title === undefined || spec.title === null ? '' : spec.title);
        if (title) {
            var fit = Cd.fitTitle(ctx, title, L.plate.w * 0.86, L.plate.h, C.TYPEFACE.display);
            report.title = {
                glyphs: tracked(ctx, title, L.plate.x + L.plate.w / 2, L.plate.y + L.plate.h * 0.54,
                    fit.size, fit.tracking, C.TYPEFACE.display, plate.ink),
                fitted: fit.fitted, size: Math.round(fit.size * 10) / 10
            };
        } else {
            report.title = { glyphs: 0, fitted: true, size: 0 };
        }

        report.wear = d.foil.wear(ctx, L, deck, P, spec.handling === undefined ? 0.10 : spec.handling, seed + 4211);

        ctx.restore();
        return report;
    };

    /**
     * Draw one card BACK.
     * @returns {object} counts
     */
    Cd.drawBack = function (ctx, x, y, w, spec) {
        var d = deps(), C = d.corpus;
        var deck = C.deck(spec.deck);
        var rarity = C.rarity(spec.rarity || 'common');
        if (!deck) throw new Error('CourtcardCard: unknown deck "' + spec.deck + '"');
        var L = C.layout(w);
        // a BACK carries no element, so it takes the deck's own untinted palette by construction
        var P = Cd.palette(deck, null, true);
        var seed = (spec.seed || 0) | 0;
        var report = {};
        ctx.save();
        ctx.translate(x, y);
        report.stock = d.frame.stock(ctx, 0, 0, L.w, L.h, deck, L.ink, seed);
        report.back = d.frame.back(ctx, L, deck, P, seed);
        report.frame = d.frame.frame(ctx, L, rarity, P, seed);
        report.wear = d.foil.wear(ctx, L, deck, P, spec.handling === undefined ? 0.10 : spec.handling, seed + 4211);
        ctx.restore();
        return report;
    };

    if (typeof module !== 'undefined' && module.exports) { module.exports = Cd; }
}(CourtcardCard));

if (typeof module !== 'undefined' && module.exports) { module.exports = CourtcardCard; }
