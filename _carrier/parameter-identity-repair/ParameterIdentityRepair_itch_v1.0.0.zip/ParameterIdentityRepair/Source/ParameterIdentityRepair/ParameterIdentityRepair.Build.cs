// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

using UnrealBuildTool;

/// <summary>
/// Parameter Identity Repair: asset discovery, the ExpressionGUID collision audit, the
/// snapshot/re-mint/re-bind repair with its undo journal, the HTML report, and both entry points.
///
/// EVERY MODULE NAME BELOW WAS READ OUT OF THE INSTALLED UE 5.8 TREE RATHER THAN GUESSED, with the
/// header and line that justifies it. This wing has measured a packaging cycle parking for over two
/// hours without reaching a compile action, so one wrong string costs a session.
/// </summary>
public class ParameterIdentityRepair : ModuleRules
{
	public ParameterIdentityRepair(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		// The zero-warning policy is enforced by the packaging build rather than by a flag here:
		// `RunUAT BuildPlugin -Rocket` compiles against a clean installed engine, which is what a
		// Fab reviewer effectively reproduces.

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",

			// THE SUBJECT OF THE PRODUCT. The exact surface used, all verified in 5.8:
			//   Public/Materials/MaterialExpression.h:207  bIsParameterExpression - the only safe
			//                                    predicate before touching a parameter accessor.
			//   Public/Materials/MaterialExpression.h:514  GetParameterExpressionId() -> FGuid&.
			//                                    ⛔ It checkf()s when bIsParameterExpression is
			//                                    false, so the guard above is load-bearing, not
			//                                    defensive style.
			//   Public/Materials/MaterialExpression.h:511  UpdateParameterGuid(bool bForce, bool).
			//                                    The ONLY sanctioned re-mint. See PIRRepair.cpp for
			//                                    why FGuid::NewGuid() would be a cook-determinism
			//                                    regression.
			//   Public/Materials/MaterialExpression.h:580/586  HasAParameterName/GetParameterName -
			//                                    generic because several parameter classes are not
			//                                    UMaterialExpressionParameter (Epic's own comment
			//                                    at :578 says exactly this).
			//   Public/Materials/Material.h:1479           GetExpressions(), WITH_EDITORONLY_DATA.
			//   Public/Materials/Material.h:1632           GetAllExpressionsInMaterialAndFunctionsOfType
			//                                    - recurses through function calls AND layer/blend
			//                                    interfaces, which is what makes the CRITICAL
			//                                    "both reachable from one material" grade possible.
			//   Public/Materials/MaterialInterface.h:949   GetAllParameterInfoOfType(Type, Infos, Guids)
			//                                    - the parallel-array lookup the re-bind resolves
			//                                    names through.
			//   Public/Materials/MaterialInstance.h:82     FScalarParameterValue::ExpressionGUID and
			//                                    its per-type siblings - the binding this tool moves.
			//   Public/Materials/MaterialParameters.h:187  EMaterialParameterType, ::Num for iteration.
			"Engine",
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			// Enumerating WHICH assets are materials, functions and instances is an asset-registry
			// class query, never a blanket load. Only assets in the candidate set are loaded, and
			// the report prints the count loaded against the count found so a buyer can see the
			// difference. ⚠️ ExpressionGUID is NOT an asset-registry tag in 5.8 - the audit
			// genuinely has to open the materials, and the Readme says so rather than implying a
			// tag-only scan.
			"AssetRegistry",

			// The commandlet host, and UEditorLoadingAndSavingUtils::SavePackages
			// (Editor/UnrealEd/Public/FileHelpers.h).
			"UnrealEd",

			// The undo journal is JSON: written before any package is saved, replayed by -Revert.
			"Json",

			// The EXPLICIT half of the checkout. SavePackages already checks out, but a tool that
			// promises "it checks out before it writes" has to be able to REPORT what it checked
			// out. Developer/SourceControl/Public/SourceControlHelpers.h
			"SourceControl",
		});
	}
}
