// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "PIRArgs.h"
#include "PIRTypes.h"

namespace PIRScan
{
	/**
	 * Audits every Material and Material Function under Options.Paths, finds every ExpressionGUID
	 * held by two or more parameter expressions, grades each collision, and collects every material
	 * instance override that points at one.
	 *
	 * ⚠️ THIS LOADS ASSETS, AND THE README SAYS SO. The asset registry gives the candidate SET for
	 * free, but ExpressionGUID is not an asset-registry tag in UE 5.8, so the parameters themselves
	 * can only be read by opening the package. The scan therefore reports found-versus-loaded
	 * counts, collects garbage periodically so a large project does not exhaust memory, and never
	 * pretends to be a tag-only pass.
	 *
	 * @param OutAllGuids every valid parameter identity seen anywhere in the scan - not just the
	 *        colliding ones. The repair needs this to prove that a re-minted GUID does not land on
	 *        an unrelated parameter, i.e. that it is not trading one collision for another.
	 * @return false only when the scan could not run at all; an empty result is reported through
	 *         Summary.ParametersExamined == 0 and is treated as a FAILURE by the caller, never as a
	 *         clean project.
	 */
	bool Run(const FPIRRunOptions& Options,
	         FPIRRunSummary& Summary,
	         TArray<FPIRCollision>& OutCollisions,
	         TSet<FGuid>& OutAllGuids,
	         FString& OutError);
}
