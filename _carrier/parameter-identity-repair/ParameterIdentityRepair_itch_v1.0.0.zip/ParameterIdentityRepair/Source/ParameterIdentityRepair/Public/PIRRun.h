// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "PIRArgs.h"
#include "PIRTypes.h"

namespace PIRRun
{
	/**
	 * The whole run, from either entry point.
	 *
	 * @return an EPIRExit value, widened. Stable across versions: CI scripts key off it.
	 */
	int32 Execute(const FPIRRunOptions& Options, FPIRRunSummary& Summary);

	/**
	 * Prints the run summary as COUNTS, never as a bare verdict.
	 *
	 * ⭐ SHARED DELIBERATELY BY BOTH ENTRY POINTS. The console command and the commandlet used to be
	 * the obvious place to paste the same twenty log lines twice, and a shared fact held in two
	 * hand-typed copies is how the two come to disagree - this factory has paid for that pattern in
	 * a shipped font table and in two "priceUSD vs price" state fields. One function, two callers.
	 */
	void LogSummary(const FPIRRunSummary& Summary, int32 Code);
}
