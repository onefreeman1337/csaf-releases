// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "PIRArgs.h"
#include "PIRTypes.h"

namespace PIRRepair
{
	/**
	 * Repairs every collision at or above Options.Threshold, in place, and updates each group's
	 * Remints, Overrides, bRepaired and FailureReason.
	 *
	 * THE ORDER IS THE SAFETY ARGUMENT, and it is deliberate:
	 *   1. pick a keeper (PIRClassify::ChooseKeeper) so the fewest overrides need to move at all
	 *   2. re-mint every other holder through the engine's own UpdateParameterGuid(true, ...)
	 *   3. VERIFY each re-mint actually changed the value AND did not land on a GUID already in use
	 *   4. re-bind each affected instance override by NAME to the holder that name identifies
	 *   5. refuse - and roll the whole group back - the moment any step cannot be answered exactly
	 *
	 * @param AllKnownGuids every GUID seen anywhere in the scan, so a re-mint that collides with an
	 *                      unrelated parameter is caught instead of shipped. Updated as it goes.
	 */
	void Apply(const FPIRRunOptions& Options,
	           TArray<FPIRCollision>& Collisions,
	           TSet<FGuid>& AllKnownGuids,
	           FPIRRunSummary& Summary);

	/** Writes the undo journal. Called BEFORE the first package is saved, never after. */
	bool WriteJournal(const FString& JournalPath,
	                  const TArray<FPIRCollision>& Collisions,
	                  FString& OutError);

	/** Replays a journal, putting every recorded identity back where it was. */
	bool Revert(const FString& JournalPath, FPIRRunSummary& Summary, FString& OutError);

	/** Saves every package touched. Returns the counts through Summary. */
	void SaveTouchedPackages(const TArray<FPIRCollision>& Collisions, FPIRRunSummary& Summary);
}
