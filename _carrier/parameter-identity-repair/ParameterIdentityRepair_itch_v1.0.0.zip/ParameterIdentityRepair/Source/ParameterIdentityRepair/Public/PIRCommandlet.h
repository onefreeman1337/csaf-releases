// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Commandlets/Commandlet.h"
#include "PIRCommandlet.generated.h"

/**
 * The CI entry point.
 *
 *   Preview, fails the job when anything Serious or worse exists:
 *     UnrealEditor-Cmd.exe Project.uproject -run=ParameterIdentityRepair -Paths=/Game
 *
 *   Repair, with an undo journal written before the first save:
 *     UnrealEditor-Cmd.exe Project.uproject -run=ParameterIdentityRepair -Paths=/Game -Apply
 *
 * ⛔ THE CLASS NAME IS LOAD-BEARING AND IT IS WHY THIS IS NOT CALLED UPIRCommandlet.
 * UE resolves -run=<name> by looking for a UClass called <name>, then for one called
 * <name>Commandlet. It does NOT know about the module name. So a class named UPIRCommandlet is
 * reachable only as -run=PIR, and a Readme promising -run=ParameterIdentityRepair against it would
 * document an invocation that does not exist. Naming the class after the documented switch is the
 * cheapest way to keep those two facts from drifting apart.
 *
 * ⚠️ This commandlet does NOT need an RHI: everything it reads is editor-only asset data and no
 * rendering happens, so -nullrhi is safe here. Worth stating because it is NOT true of every tool
 * in this catalogue - one of them produces a complete, well-formed, entirely EMPTY report under
 * -nullrhi - so "the flag is fine" is a per-product fact, never a habit.
 */
UCLASS()
class UParameterIdentityRepairCommandlet : public UCommandlet
{
	GENERATED_BODY()

public:
	UParameterIdentityRepairCommandlet();

	virtual int32 Main(const FString& Params) override;
};
