// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

/**
 * Shared vocabulary for Parameter Identity Repair.
 *
 * ⛔ DESIGN RULE, AND IT IS NOT STYLE: NOTHING IN THIS FILE HOLDS A UObject POINTER.
 * Every persistent record identifies an asset by its path string and a parameter by name, type and
 * GUID. A project-wide audit opens thousands of packages and a commandlet can garbage-collect
 * between them, so a UMaterialExpression* cached in a results array is a dangling pointer waiting
 * for a slow project. Pointers live inside the tightest scope that can use them and never escape.
 */

/** How much damage a single shared ExpressionGUID is doing, worst first. */
enum class EPIRSeverity : uint8
{
	/**
	 * Two or more parameter expressions share one GUID, they carry DIFFERENT names, and at least
	 * one material can reach more than one of them (directly, through a material function, or
	 * through a layer or blend). This is shadowing happening right now: the material resolves one
	 * identity where two were authored, so one parameter is unreachable and instance overrides
	 * written against it are already going nowhere.
	 */
	Critical = 0,

	/**
	 * Different names, one GUID, but no single material currently reaches more than one of them.
	 * Nothing is visibly broken today. It breaks the moment someone uses both in one material - the
	 * ordinary consequence of building a material family - and a rename of either one migrates the
	 * other's instance overrides in the meantime.
	 */
	Serious = 1,

	/**
	 * One GUID, and every holder has the same parameter name and type. Harmless in every current
	 * lookup, because name resolution lands on an equivalent parameter either way. It is still a
	 * defect: rename one of them and the engine migrates instance overrides by GUID, so the other
	 * holder's instances follow a rename they never asked for.
	 */
	Latent = 2,
};

/** Process exit codes. Stable: CI scripts key off these. */
enum class EPIRExit : uint8
{
	/** Ran, and (preview) found nothing at or above the reporting threshold, or (apply) repaired everything it found. */
	Ok = 0,
	/** A switch was malformed. Nothing was scanned and nothing was written. */
	BadArguments = 1,
	/**
	 * The scan completed and examined ZERO parameter expressions.
	 * ⛔ THIS IS A FAILURE, NOT A CLEAN BILL OF HEALTH. An asset registry that has not scanned the
	 * path you named returns an empty set exactly like a project with no materials in it, and this
	 * wing has already shipped one tool that had to learn the difference. Refusing here is the
	 * whole point: a silent zero is how an audit tool tells you a lie you want to hear.
	 */
	NothingScanned = 2,
	/** Preview mode, and collisions at or above the threshold exist. The CI gate signal. */
	CollisionsFound = 3,
	/** Apply mode, and at least one collision group could not be repaired safely and was rolled back or skipped. */
	RepairIncomplete = 4,
};

/** One parameter expression, identified without holding it. */
struct FPIRParameterRef
{
	/** Package-qualified path of the Material or MaterialFunction that owns the expression. */
	FString OwnerPath;

	/** "Material" or "MaterialFunction" - which side of the audit this came from. */
	FString OwnerKind;

	/** The expression UObject's own name, so a user can find the node in a graph of forty. */
	FString ExpressionName;

	/** The authored parameter name. This, not the GUID, is what the repair re-binds against. */
	FName ParameterName;

	/** EMaterialParameterType, stored widened so this header does not drag in MaterialParameters.h. */
	uint8 ParameterType = 0xff;

	/** Human-readable form of ParameterType for the report. */
	FString ParameterTypeName;

	/** The identity itself. */
	FGuid Guid;

	/** Stable, sortable key. Used to choose a keeper deterministically - see PIRClassify. */
	FString SortKey() const { return OwnerPath + TEXT("|") + ExpressionName; }
};

/** One material instance override that points at a colliding identity. */
struct FPIROverrideRef
{
	/** Package-qualified path of the UMaterialInstance. */
	FString InstancePath;

	/** Which UPROPERTY array it came from, e.g. "ScalarParameterValues". Printed in the report. */
	FString ArrayName;

	/** The override's parameter name - the key the re-bind resolves through. */
	FName ParameterName;

	/**
	 * EMaterialParameterAssociation, widened.
	 * ⚠️ Defaulted to 2, which is GlobalParameter - NOT zero, which is LayerParameter
	 * (Engine/Public/Materials/MaterialParameters.h:25, the enum runs Layer, Blend, Global). A
	 * zero-initialised association would silently describe every ordinary parameter as belonging to
	 * material layer -1, and the re-bind resolves on this field.
	 */
	uint8 Association = 2;

	/** Layer/blend index, or INDEX_NONE for a global parameter. */
	int32 Index = INDEX_NONE;

	/** The GUID this override carried before the repair. */
	FGuid GuidBefore;

	/** The GUID it carries after. Equal to GuidBefore when nothing needed to move. */
	FGuid GuidAfter;

	/** True once the override has been resolved by name and written. */
	bool bRebound = false;

	/** Why an override was left alone. Empty when it was re-bound cleanly. */
	FString Note;
};

/** One re-minted expression: what its identity was, and what it became. */
struct FPIRRemint
{
	FPIRParameterRef Parameter;
	FGuid GuidBefore;
	FGuid GuidAfter;
};

/** One shared GUID and everything known about it. */
struct FPIRCollision
{
	/** The identity that is being shared. */
	FGuid Guid;

	/** Every parameter expression holding it. Always two or more, or it is not a collision. */
	TArray<FPIRParameterRef> Members;

	EPIRSeverity Severity = EPIRSeverity::Latent;

	/** One sentence naming why it got that grade, quoted straight into the report. */
	FString SeverityReason;

	/** Materials from which more than one member is reachable. Non-empty exactly when Critical. */
	TArray<FString> CoReachableMaterials;

	/** The member whose identity is kept. Everything else is re-minted. */
	FString KeeperSortKey;

	/** Populated in apply mode. */
	TArray<FPIRRemint> Remints;

	/** Material instance overrides that referenced this GUID. */
	TArray<FPIROverrideRef> Overrides;

	/** True when every re-mint and every re-bind for this group succeeded and was verified. */
	bool bRepaired = false;

	/** Why the group was skipped or rolled back. Empty on success. */
	FString FailureReason;

	/** Distinct owning assets, for the report's "assets touched" column. */
	TArray<FString> DistinctOwners() const
	{
		TArray<FString> Out;
		for (const FPIRParameterRef& M : Members)
		{
			Out.AddUnique(M.OwnerPath);
		}
		Out.Sort();
		return Out;
	}

	/** True when the members do not all share one parameter name. */
	bool HasNameDisagreement() const
	{
		for (int32 i = 1; i < Members.Num(); ++i)
		{
			if (Members[i].ParameterName != Members[0].ParameterName)
			{
				return true;
			}
		}
		return false;
	}
};

/** Everything a run produces, for the summary log, the report and the state record. */
struct FPIRRunSummary
{
	bool bApplied = false;

	/**
	 * Set only by -Revert. It is NOT a kind of apply, and it must not print as a preview either.
	 *
	 * A revert writes packages while scanning nothing, so every scan counter is legitimately zero.
	 * Before this flag existed the summary printed "mode: preview (nothing written)" over a run that
	 * had just restored 40 groups and saved 49 packages - true of the fields it read, false about
	 * the run.
	 */
	bool bReverted = false;

	/** Assets the registry offered, before any load. */
	int32 MaterialsFound = 0;
	int32 FunctionsFound = 0;
	int32 InstancesFound = 0;

	/** Assets actually opened. The gap between found and loaded is printed, never hidden. */
	int32 MaterialsLoaded = 0;
	int32 FunctionsLoaded = 0;
	int32 InstancesLoaded = 0;

	/** Total parameter expressions examined. Zero here is a hard failure - see EPIRExit. */
	int32 ParametersExamined = 0;

	int32 CollisionsCritical = 0;
	int32 CollisionsSerious = 0;
	int32 CollisionsLatent = 0;

	int32 GroupsRepaired = 0;
	int32 GroupsFailed = 0;
	int32 ExpressionsReminted = 0;
	int32 OverridesRebound = 0;
	int32 OverridesLeftAlone = 0;

	/**
	 * Revert only: rows that were ALREADY holding the value the journal wanted to restore.
	 *
	 * This is a success, and it needs its own counter because it is indistinguishable from a
	 * missing row unless you look for it. A revert loads each instance fresh, and the engine
	 * re-resolves an instance's override rows from the parent by NAME on load, so a row whose
	 * expression this same run has already restored can arrive at the correct identity before the
	 * journal gets to it. Counting that as a failure reports a complete undo as a partial one.
	 */
	int32 OverridesAlreadyCorrect = 0;

	int32 PackagesSaved = 0;
	int32 PackagesFailed = 0;

	double Seconds = 0.0;

	FString ReportPath;
	FString JournalPath;

	/** Anything the operator should read. Logged as warnings, and printed in the report. */
	TArray<FString> Problems;

	int32 TotalCollisions() const { return CollisionsCritical + CollisionsSerious + CollisionsLatent; }
};

namespace PIRTypes
{
	/** "Critical" / "Serious" / "Latent". */
	FString SeverityToString(EPIRSeverity Severity);

	/** Parses the -Severity= switch. Returns false on an unrecognised word. */
	bool SeverityFromString(const FString& In, EPIRSeverity& Out);

	/** Lower enum value is worse, so this reads "is A at least as bad as B". */
	inline bool AtLeastAsSevere(EPIRSeverity A, EPIRSeverity B)
	{
		return static_cast<uint8>(A) <= static_cast<uint8>(B);
	}

	/** Human-readable name for an EMaterialParameterType value. */
	FString ParameterTypeToString(uint8 ParameterType);

	/** Escapes a string for safe inclusion in the HTML report. */
	FString EscapeHtml(const FString& In);
}
