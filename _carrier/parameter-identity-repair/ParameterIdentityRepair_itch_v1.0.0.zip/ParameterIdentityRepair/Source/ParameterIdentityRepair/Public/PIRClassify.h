// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "PIRTypes.h"

/**
 * The decision layer, deliberately kept free of every engine type.
 *
 * ⭐ WHY THIS FILE EXISTS SEPARATELY FROM PIRScan: the grading rule and the keeper rule are the two
 * places where this tool can be WRONG IN A WAY THAT CORRUPTS A PROJECT, and neither of them needs a
 * UMaterial to be decided. Pulling them out means both can be driven by automation tests over hand
 * built inputs - including deliberately sabotaged ones - instead of only over whatever a fixture
 * project happens to contain. The wing's recorded risk note for this product asked for exactly
 * that: "the snapshot/restore proven by test with a deliberate sabotage arm before any of it ships".
 */
namespace PIRClassify
{
	/**
	 * Grades a collision and writes Severity plus SeverityReason.
	 *
	 * Requires Members and CoReachableMaterials to be populated. Pure: touches nothing else.
	 *
	 * The rule, in order:
	 *   - every holder shares one name  -> Latent   (resolution is equivalent today; renames are not)
	 *   - names differ, co-reachable    -> Critical (one parameter is shadowing another right now)
	 *   - names differ, not co-reachable-> Serious  (breaks the day both are used in one material)
	 */
	void Grade(FPIRCollision& Collision);

	/**
	 * Picks which member keeps the shared identity. Everything else is re-minted.
	 *
	 * ⭐ NOT ARBITRARY, AND THE REASON IS THE SAFETY ARGUMENT FOR THE WHOLE TOOL. Re-minting an
	 * expression is cheap and provably correct; RE-BINDING a material instance override is the step
	 * that can lose a buyer's authored value. So the keeper is the member whose parameter NAME
	 * carries the most instance overrides: that maximises the number of overrides which need no
	 * re-bind at all, because their GUID is still correct afterwards. Fewer writes, less risk.
	 *
	 * Ties break on SortKey (owner path, then expression name) so a run is reproducible and a
	 * second run over an unchanged project is a no-op.
	 *
	 * @param Members             the colliding expressions, two or more
	 * @param OverrideCountByName how many material instance overrides carry each parameter name
	 * @return                    the SortKey of the keeper, or empty if Members is empty
	 */
	FString ChooseKeeper(const TArray<FPIRParameterRef>& Members, const TMap<FName, int32>& OverrideCountByName);

	/**
	 * True when a group should be repaired under the given threshold.
	 * Split out so the "what would this have done" question has exactly one answer in the codebase.
	 */
	bool ShouldRepair(const FPIRCollision& Collision, EPIRSeverity Threshold);

	/** Worst first, then most members, then GUID, so report order is stable across runs. */
	void SortForReport(TArray<FPIRCollision>& Collisions);
}
