// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "PIRArgs.h"
#include "PIRTypes.h"

namespace PIRReport
{
	/**
	 * Writes the HTML sheet.
	 *
	 * ⛔ TWO RULES THIS FILE OBEYS THAT ARE NOT OBVIOUS, both paid for by earlier products in this
	 * wing:
	 *
	 * 1. EVERY SWATCH IS DRAWN WITH CSS, NEVER TYPED AS A CHARACTER. A previous product shipped a
	 *    legend using &#9647; beside &#9646;; the second has a glyph in the default font stack and
	 *    the first does not, so every sheet it generated rendered a missing-glyph box next to the
	 *    word it was labelling. Nothing mechanical could catch it - the HTML was valid and the
	 *    entity well-formed. A span with a border IS the swatch and needs no font coverage.
	 *
	 * 2. THE ABSOLUTE OUTPUT PATH IS NEVER PRINTED INTO THE SHEET. Every product in this wing prints
	 *    file paths, and two of them put the author's Windows username on a live store page because
	 *    a screenshot of a report included one. Content paths (/Game/...) are the user's own and are
	 *    the point; the local disk path of the report is neither.
	 */
	bool Write(const FPIRRunOptions& Options,
	           const TArray<FPIRCollision>& Collisions,
	           const FPIRRunSummary& Summary,
	           FString& OutError);
}
