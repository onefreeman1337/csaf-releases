// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "PIRTypes.h"

/** Everything a run needs, fully resolved. Pure data, so the parser is unit-testable. */
struct FPIRRunOptions
{
	/** Content roots to audit. Defaults to a single entry, "/Game". */
	TArray<FString> Paths;

	/** False by default. Nothing is written to any asset unless this is true. */
	bool bApply = false;

	/** When set, the run replays this journal instead of auditing. */
	FString RevertJournal;

	/** Where the HTML sheet goes. */
	FString ReportPath;

	/** Where the undo journal goes. Written BEFORE the first package is saved. */
	FString JournalPath;

	/**
	 * Collisions less severe than this are counted and listed but never repaired, and do not
	 * influence the exit code. Default Serious: Latent collisions are real but repairing them
	 * churns assets for a defect nobody has hit yet, and a tool that rewrites a thousand packages
	 * on its first run gets uninstalled.
	 */
	EPIRSeverity Threshold = EPIRSeverity::Serious;

	/** Stop after repairing this many groups. INDEX_NONE means no limit. */
	int32 Limit = INDEX_NONE;

	/** Do the whole repair in memory and report it, but never save. Used by the test project. */
	bool bNoSave = false;

	bool IsRevert() const { return !RevertJournal.IsEmpty(); }
};

namespace PIRArgs
{
	/**
	 * Parses a command line into options.
	 *
	 * @param Params      the raw switch string, with or without leading dashes on each token
	 * @param OutOptions  filled on success; untouched fields keep their defaults
	 * @param OutError    a sentence naming the offending switch, on failure
	 * @return            false if any switch was malformed
	 */
	bool Parse(const FString& Params, FPIRRunOptions& OutOptions, FString& OutError);

	/** The -Help text. Also printed on a parse failure, because that is when it is wanted. */
	FString Usage();

	/**
	 * Default output path for a given file, under the project's Saved/ProjectIdentityRepair folder.
	 * Split out so the parser stays pure and the tests do not touch the filesystem.
	 */
	FString DefaultOutputPath(const FString& FileName);
}
