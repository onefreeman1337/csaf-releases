// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "PIRReport.h"

#include "Misc/DateTime.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"

namespace
{
	using PIRTypes::EscapeHtml;

	/** CSS class suffix for a grade, so the stylesheet carries the colour and the code does not. */
	const TCHAR* GradeClass(EPIRSeverity Severity)
	{
		switch (Severity)
		{
		case EPIRSeverity::Critical: return TEXT("critical");
		case EPIRSeverity::Serious:  return TEXT("serious");
		default:                     return TEXT("latent");
		}
	}

	FString Stylesheet()
	{
		return FString(
			TEXT("<style>\n")
			TEXT(":root{--bg:#12141a;--panel:#181b23;--panel2:#1e222c;--line:#2b3140;--ink:#e6e9f0;\n")
			TEXT("      --dim:#8d96ab;--accent:#7aa2f7;--critical:#f7768e;--serious:#e0af68;--latent:#7dcfff;--ok:#9ece6a}\n")
			TEXT("*{box-sizing:border-box}\n")
			TEXT("body{margin:0;background:var(--bg);color:var(--ink);\n")
			TEXT("     font:14px/1.55 'Segoe UI',system-ui,-apple-system,sans-serif}\n")
			TEXT(".wrap{max-width:1320px;margin:0 auto;padding:48px 40px}\n")
			TEXT("header{border-bottom:1px solid var(--line);padding-bottom:24px;margin-bottom:32px}\n")
			TEXT("h1{margin:0 0 6px;font-size:26px;font-weight:650;letter-spacing:-.015em}\n")
			TEXT(".sub{color:var(--dim);font-size:13px}\n")
			TEXT(".mode{display:inline-block;margin-left:10px;padding:3px 10px;border-radius:999px;\n")
			TEXT("      font-size:11px;font-weight:650;letter-spacing:.08em;text-transform:uppercase}\n")
			TEXT(".mode.preview{background:rgba(122,162,247,.14);color:var(--accent);border:1px solid rgba(122,162,247,.35)}\n")
			TEXT(".mode.apply{background:rgba(158,206,106,.14);color:var(--ok);border:1px solid rgba(158,206,106,.35)}\n")
			TEXT(".strip{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:1px;\n")
			TEXT("       background:var(--line);border:1px solid var(--line);border-radius:10px;overflow:hidden;margin-bottom:34px}\n")
			TEXT(".stat{background:var(--panel);padding:16px 18px}\n")
			TEXT(".stat .n{font-size:25px;font-weight:650;letter-spacing:-.02em;font-variant-numeric:tabular-nums}\n")
			TEXT(".stat .k{color:var(--dim);font-size:11px;text-transform:uppercase;letter-spacing:.07em;margin-top:3px}\n")
			TEXT(".stat.critical .n{color:var(--critical)}.stat.serious .n{color:var(--serious)}\n")
			TEXT(".stat.latent .n{color:var(--latent)}.stat.ok .n{color:var(--ok)}\n")
			TEXT(".legend{display:flex;flex-wrap:wrap;gap:22px;margin:-14px 0 34px;font-size:12px;color:var(--dim)}\n")
			TEXT(".legend b{color:var(--ink);font-weight:600}\n")
			// The swatch is a DRAWN box: a span with a background and a border. No glyph, no font
			// dependency, nothing that can render as a missing-character box on someone else's machine.
			TEXT(".sw{display:inline-block;width:11px;height:11px;border-radius:3px;margin-right:7px;\n")
			TEXT("    vertical-align:-1px;border:1px solid rgba(255,255,255,.18)}\n")
			TEXT(".sw.critical{background:var(--critical)}.sw.serious{background:var(--serious)}.sw.latent{background:var(--latent)}\n")
			TEXT(".card{background:var(--panel);border:1px solid var(--line);border-radius:10px;\n")
			TEXT("      margin-bottom:20px;overflow:hidden}\n")
			TEXT(".card>.head{padding:16px 20px;border-bottom:1px solid var(--line);display:flex;\n")
			TEXT("            align-items:baseline;gap:14px;flex-wrap:wrap}\n")
			TEXT(".chip{padding:3px 10px;border-radius:999px;font-size:11px;font-weight:700;\n")
			TEXT("      letter-spacing:.07em;text-transform:uppercase}\n")
			TEXT(".chip.critical{background:rgba(247,118,142,.15);color:var(--critical);border:1px solid rgba(247,118,142,.4)}\n")
			TEXT(".chip.serious{background:rgba(224,175,104,.15);color:var(--serious);border:1px solid rgba(224,175,104,.4)}\n")
			TEXT(".chip.latent{background:rgba(125,207,255,.13);color:var(--latent);border:1px solid rgba(125,207,255,.36)}\n")
			TEXT(".guid{font-family:'Cascadia Mono',Consolas,monospace;font-size:12px;color:var(--dim)}\n")
			TEXT(".why{padding:14px 20px;color:var(--dim);font-size:13px;border-bottom:1px solid var(--line);\n")
			TEXT("     background:var(--panel2)}\n")
			TEXT(".outcome{padding:10px 20px;font-size:12.5px;border-bottom:1px solid var(--line)}\n")
			TEXT(".outcome.done{color:var(--ok);background:rgba(158,206,106,.06)}\n")
			TEXT(".outcome.held{color:var(--serious);background:rgba(224,175,104,.06)}\n")
			TEXT("table{width:100%;border-collapse:collapse;font-size:13px}\n")
			TEXT("th{text-align:left;padding:9px 20px;color:var(--dim);font-size:10.5px;font-weight:650;\n")
			TEXT("   letter-spacing:.08em;text-transform:uppercase;border-bottom:1px solid var(--line)}\n")
			TEXT("td{padding:9px 20px;border-bottom:1px solid rgba(43,49,64,.55);vertical-align:top}\n")
			TEXT("tr:last-child td{border-bottom:none}\n")
			TEXT(".path{font-family:'Cascadia Mono',Consolas,monospace;font-size:12px;word-break:break-all}\n")
			TEXT(".keep{color:var(--ok);font-weight:650}\n")
			TEXT(".moved{color:var(--accent)}\n")
			TEXT(".held{color:var(--serious)}\n")
			TEXT(".sect{margin:8px 0 10px;padding:0 20px;color:var(--dim);font-size:10.5px;\n")
			TEXT("      letter-spacing:.08em;text-transform:uppercase;font-weight:650}\n")
			TEXT(".empty{padding:40px 20px;text-align:center;color:var(--dim)}\n")
			TEXT(".problems{background:rgba(224,175,104,.07);border:1px solid rgba(224,175,104,.3);\n")
			TEXT("          border-radius:10px;padding:16px 20px;margin-bottom:28px}\n")
			TEXT(".problems h2{margin:0 0 8px;font-size:13px;color:var(--serious);letter-spacing:.04em}\n")
			TEXT(".problems li{color:var(--dim);font-size:12.5px;margin:4px 0}\n")
			TEXT("footer{margin-top:38px;padding-top:20px;border-top:1px solid var(--line);\n")
			TEXT("       color:var(--dim);font-size:11.5px;line-height:1.7}\n")
			TEXT("</style>\n"));
	}

	void AppendStat(FString& Html, const TCHAR* Extra, int32 Number, const TCHAR* Label)
	{
		Html += FString::Printf(
			TEXT("<div class=\"stat %s\"><div class=\"n\">%d</div><div class=\"k\">%s</div></div>\n"),
			Extra, Number, Label);
	}

	void AppendMembers(FString& Html, const FPIRCollision& Collision)
	{
		Html += TEXT("<div class=\"sect\">Parameters holding this identity</div>\n<table>\n");
		Html += TEXT("<tr><th>Owning asset</th><th>Expression</th><th>Parameter</th><th>Type</th><th>Outcome</th></tr>\n");

		for (const FPIRParameterRef& Member : Collision.Members)
		{
			const bool bKeeper = Member.SortKey() == Collision.KeeperSortKey;

			FString Outcome;
			if (bKeeper)
			{
				Outcome = TEXT("<span class=\"keep\">keeps this identity</span>");
			}
			else
			{
				const FPIRRemint* Remint = Collision.Remints.FindByPredicate(
					[&Member](const FPIRRemint& R) { return R.Parameter.SortKey() == Member.SortKey(); });
				Outcome = Remint != nullptr
					? FString::Printf(TEXT("<span class=\"moved\">re-minted to</span><br><span class=\"guid\">%s</span>"),
						*EscapeHtml(Remint->GuidAfter.ToString()))
					: TEXT("<span class=\"held\">not changed</span>");
			}

			Html += FString::Printf(
				TEXT("<tr><td class=\"path\">%s<br><span class=\"guid\">%s</span></td>")
				TEXT("<td class=\"path\">%s</td><td><b>%s</b></td><td>%s</td><td>%s</td></tr>\n"),
				*EscapeHtml(Member.OwnerPath),
				*EscapeHtml(Member.OwnerKind),
				*EscapeHtml(Member.ExpressionName),
				*EscapeHtml(Member.ParameterName.ToString()),
				*EscapeHtml(Member.ParameterTypeName),
				*Outcome);
		}
		Html += TEXT("</table>\n");
	}

	void AppendOverrides(FString& Html, const FPIRCollision& Collision)
	{
		if (Collision.Overrides.Num() == 0)
		{
			return;
		}

		Html += FString::Printf(
			TEXT("<div class=\"sect\">Material instance overrides bound to this identity (%d)</div>\n<table>\n"),
			Collision.Overrides.Num());
		Html += TEXT("<tr><th>Instance</th><th>Parameter</th><th>Array</th><th>Identity before</th><th>Identity after</th></tr>\n");

		for (const FPIROverrideRef& Override : Collision.Overrides)
		{
			FString After;
			if (!Override.bRebound)
			{
				After = FString::Printf(TEXT("<span class=\"held\">left alone</span><br><span class=\"guid\">%s</span>"),
					*EscapeHtml(Override.Note));
			}
			else if (Override.GuidAfter == Override.GuidBefore)
			{
				After = TEXT("<span class=\"keep\">unchanged, already correct</span>");
			}
			else
			{
				After = FString::Printf(TEXT("<span class=\"moved guid\">%s</span>"),
					*EscapeHtml(Override.GuidAfter.ToString()));
			}

			Html += FString::Printf(
				TEXT("<tr><td class=\"path\">%s</td><td><b>%s</b></td><td class=\"guid\">%s</td>")
				TEXT("<td class=\"guid\">%s</td><td>%s</td></tr>\n"),
				*EscapeHtml(Override.InstancePath),
				*EscapeHtml(Override.ParameterName.ToString()),
				*EscapeHtml(Override.ArrayName),
				*EscapeHtml(Override.GuidBefore.ToString()),
				*After);
		}
		Html += TEXT("</table>\n");
	}
}

namespace PIRReport
{
	bool Write(const FPIRRunOptions& Options,
	           const TArray<FPIRCollision>& Collisions,
	           const FPIRRunSummary& Summary,
	           FString& OutError)
	{
		FString Html;
		Html.Reserve(64 * 1024);

		Html += TEXT("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n");
		Html += TEXT("<title>Parameter Identity Repair</title>\n");
		Html += Stylesheet();
		Html += TEXT("</head>\n<body>\n<div class=\"wrap\">\n");

		Html += TEXT("<header>\n<h1>Parameter Identity Repair");
		Html += Summary.bApplied
			? TEXT("<span class=\"mode apply\">applied</span>")
			: TEXT("<span class=\"mode preview\">preview, nothing written</span>");
		Html += TEXT("</h1>\n");
		Html += FString::Printf(
			TEXT("<div class=\"sub\">%s &nbsp;&bull;&nbsp; audited %s &nbsp;&bull;&nbsp; %.1f seconds</div>\n</header>\n"),
			*EscapeHtml(FDateTime::Now().ToString(TEXT("%Y-%m-%d %H:%M"))),
			*EscapeHtml(FString::Join(Options.Paths, TEXT(", "))),
			Summary.Seconds);

		Html += TEXT("<div class=\"strip\">\n");
		AppendStat(Html, TEXT(""),         Summary.ParametersExamined, TEXT("parameters examined"));
		AppendStat(Html, TEXT("critical"), Summary.CollisionsCritical, TEXT("critical"));
		AppendStat(Html, TEXT("serious"),  Summary.CollisionsSerious,  TEXT("serious"));
		AppendStat(Html, TEXT("latent"),   Summary.CollisionsLatent,   TEXT("latent"));
		if (Summary.bApplied)
		{
			AppendStat(Html, TEXT("ok"), Summary.GroupsRepaired,       TEXT("groups repaired"));
			AppendStat(Html, TEXT("ok"), Summary.ExpressionsReminted,  TEXT("identities re-minted"));
			AppendStat(Html, TEXT("ok"), Summary.OverridesRebound,     TEXT("overrides re-bound"));
			AppendStat(Html, TEXT(""),   Summary.OverridesLeftAlone,   TEXT("overrides left alone"));
		}
		Html += TEXT("</div>\n");

		Html += TEXT("<div class=\"legend\">\n");
		Html += TEXT("<span><span class=\"sw critical\"></span><b>Critical</b> different names, and one material reaches both. Shadowing today.</span>\n");
		Html += TEXT("<span><span class=\"sw serious\"></span><b>Serious</b> different names, not yet used together. Renames already migrate wrongly.</span>\n");
		Html += TEXT("<span><span class=\"sw latent\"></span><b>Latent</b> same name everywhere. Harmless until one is renamed.</span>\n");
		Html += TEXT("</div>\n");

		if (Summary.Problems.Num() > 0)
		{
			Html += TEXT("<div class=\"problems\">\n<h2>Read these</h2>\n<ul>\n");
			for (const FString& Problem : Summary.Problems)
			{
				Html += FString::Printf(TEXT("<li>%s</li>\n"), *EscapeHtml(Problem));
			}
			Html += TEXT("</ul>\n</div>\n");
		}

		if (Collisions.Num() == 0)
		{
			Html += FString::Printf(
				TEXT("<div class=\"card\"><div class=\"empty\">")
				TEXT("<b>No shared identities.</b><br>Every one of the %d parameter expressions under %s carries its own ExpressionGUID.")
				TEXT("</div></div>\n"),
				Summary.ParametersExamined,
				*EscapeHtml(FString::Join(Options.Paths, TEXT(", "))));
		}

		for (const FPIRCollision& Collision : Collisions)
		{
			const TCHAR* Grade = GradeClass(Collision.Severity);

			Html += TEXT("<div class=\"card\">\n<div class=\"head\">\n");
			Html += FString::Printf(TEXT("<span class=\"chip %s\">%s</span>\n"),
				Grade, *PIRTypes::SeverityToString(Collision.Severity));
			Html += FString::Printf(TEXT("<span class=\"guid\">%s</span>\n"),
				*EscapeHtml(Collision.Guid.ToString()));
			Html += FString::Printf(TEXT("<span class=\"sub\">%d holders across %d asset(s)</span>\n"),
				Collision.Members.Num(), Collision.DistinctOwners().Num());
			Html += TEXT("</div>\n");

			Html += FString::Printf(TEXT("<div class=\"why\">%s</div>\n"),
				*EscapeHtml(Collision.SeverityReason));

			if (Collision.CoReachableMaterials.Num() > 0)
			{
				Html += TEXT("<div class=\"why\"><b>Reached together from:</b> ");
				Html += EscapeHtml(FString::Join(Collision.CoReachableMaterials, TEXT("  |  ")));
				Html += TEXT("</div>\n");
			}

			if (Summary.bApplied)
			{
				if (Collision.bRepaired)
				{
					Html += FString::Printf(
						TEXT("<div class=\"outcome done\">Repaired. %d identity(ies) re-minted, %d override(s) re-bound by name.</div>\n"),
						Collision.Remints.Num(),
						Collision.Overrides.FilterByPredicate([](const FPIROverrideRef& O)
							{ return O.bRebound && O.GuidAfter != O.GuidBefore; }).Num());
				}
				else if (!Collision.FailureReason.IsEmpty())
				{
					Html += FString::Printf(TEXT("<div class=\"outcome held\">Not repaired. %s</div>\n"),
						*EscapeHtml(Collision.FailureReason));
				}
				else
				{
					Html += TEXT("<div class=\"outcome held\">Below the requested severity threshold, so it was listed but not touched.</div>\n");
				}
			}

			AppendMembers(Html, Collision);
			AppendOverrides(Html, Collision);
			Html += TEXT("</div>\n");
		}

		// ⛔ NO ABSOLUTE PATHS IN THE FOOTER. See the header comment: a screenshot of this sheet is a
		// store image, and this wing has already published a Windows username twice that way.
		Html += TEXT("<footer>\n");
		Html += FString::Printf(
			TEXT("Registry offered %d material(s), %d function(s), %d instance(s); this run opened %d, %d and %d of them. ")
			TEXT("ExpressionGUID is not an asset-registry tag in UE 5.8, so the parameters can only be read by loading the packages - ")
			TEXT("the counts above are printed rather than hidden so the gap is yours to see.<br>\n"),
			Summary.MaterialsFound, Summary.FunctionsFound, Summary.InstancesFound,
			Summary.MaterialsLoaded, Summary.FunctionsLoaded, Summary.InstancesLoaded);
		Html += TEXT("Static switch and static component mask overrides are reported by grade but are NOT re-bound in 1.0.0: ")
		        TEXT("in UE 5.8 those live behind FMaterialInstanceParameterUpdateContext rather than on a plain UPROPERTY array, ")
		        TEXT("and this tool does not write through a path it has not proven.<br>\n");
		Html += TEXT("Parameter Identity Repair &bull; Core Systems Asset Factory\n</footer>\n");

		Html += TEXT("</div>\n</body>\n</html>\n");

		if (!FFileHelper::SaveStringToFile(Html, *Options.ReportPath))
		{
			OutError = FString::Printf(TEXT("Could not write the report to '%s'."), *Options.ReportPath);
			return false;
		}
		return true;
	}
}
