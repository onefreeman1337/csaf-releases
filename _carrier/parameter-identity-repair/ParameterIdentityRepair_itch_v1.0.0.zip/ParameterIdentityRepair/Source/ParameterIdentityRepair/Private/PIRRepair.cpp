// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "PIRRepair.h"

#include "Dom/JsonObject.h"
#include "FileHelpers.h"
#include "Materials/Material.h"
#include "Materials/MaterialExpression.h"
#include "Materials/MaterialFunction.h"
#include "Materials/MaterialInstance.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "ParameterIdentityRepairModule.h"
#include "PIRClassify.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "UObject/Package.h"
#include "UObject/UObjectGlobals.h"

namespace
{
	/** Loads an asset by path without caring which of the two owner kinds it is. */
	UObject* LoadOwner(const FString& Path)
	{
		return StaticLoadObject(UObject::StaticClass(), nullptr, *Path);
	}

	/** The owner's expression list, whichever kind of owner it is. Empty view if neither. */
	TConstArrayView<TObjectPtr<UMaterialExpression>> GetOwnerExpressions(UObject* Owner)
	{
#if WITH_EDITORONLY_DATA
		if (UMaterial* Material = Cast<UMaterial>(Owner))
		{
			return Material->GetExpressions();
		}
		if (UMaterialFunction* Function = Cast<UMaterialFunction>(Owner))
		{
			return Function->GetExpressions();
		}
#endif
		return TConstArrayView<TObjectPtr<UMaterialExpression>>();
	}

	/** Finds one expression by its object name inside an already-loaded owner. */
	UMaterialExpression* FindExpression(UObject* Owner, const FString& ExpressionName)
	{
		for (const TObjectPtr<UMaterialExpression>& ExpressionPtr : GetOwnerExpressions(Owner))
		{
			UMaterialExpression* Expression = ExpressionPtr.Get();
			if (Expression != nullptr && Expression->GetName() == ExpressionName)
			{
				return Expression;
			}
		}
		return nullptr;
	}

	/**
	 * Rewrites the ExpressionGUID of one override, matched by name, association and index.
	 * Returns true when a matching entry was found and written.
	 *
	 * ⭐ Templated for the same reason the scanner's collector is: nine arrays, one shape. And as
	 * there, it assigns to ExpressionGUID and to nothing else, which is why "did the buyer's value
	 * survive?" is answered by construction rather than by a comparison.
	 */
	template <typename TParamValue>
	bool RebindInArray(TArray<TParamValue>& Values, const FPIROverrideRef& Ref, const FGuid& NewGuid)
	{
		for (TParamValue& Value : Values)
		{
			if (Value.ParameterInfo.Name == Ref.ParameterName
				&& static_cast<uint8>(Value.ParameterInfo.Association.GetValue()) == Ref.Association
				&& Value.ParameterInfo.Index == Ref.Index
				&& Value.ExpressionGUID == Ref.GuidBefore)
			{
				Value.ExpressionGUID = NewGuid;
				return true;
			}
		}
		return false;
	}

	/** Dispatches a re-bind to whichever array the scan recorded it in. */
	bool RebindOverride(UMaterialInstance* Instance, const FPIROverrideRef& Ref, const FGuid& NewGuid)
	{
		if (Ref.ArrayName == TEXT("ScalarParameterValues"))                { return RebindInArray(Instance->ScalarParameterValues, Ref, NewGuid); }
		if (Ref.ArrayName == TEXT("VectorParameterValues"))                { return RebindInArray(Instance->VectorParameterValues, Ref, NewGuid); }
		if (Ref.ArrayName == TEXT("DoubleVectorParameterValues"))          { return RebindInArray(Instance->DoubleVectorParameterValues, Ref, NewGuid); }
		if (Ref.ArrayName == TEXT("TextureParameterValues"))               { return RebindInArray(Instance->TextureParameterValues, Ref, NewGuid); }
		if (Ref.ArrayName == TEXT("TextureCollectionParameterValues"))     { return RebindInArray(Instance->TextureCollectionParameterValues, Ref, NewGuid); }
		if (Ref.ArrayName == TEXT("ParameterCollectionParameterValues"))   { return RebindInArray(Instance->ParameterCollectionParameterValues, Ref, NewGuid); }
		if (Ref.ArrayName == TEXT("RuntimeVirtualTextureParameterValues")) { return RebindInArray(Instance->RuntimeVirtualTextureParameterValues, Ref, NewGuid); }
		if (Ref.ArrayName == TEXT("SparseVolumeTextureParameterValues"))   { return RebindInArray(Instance->SparseVolumeTextureParameterValues, Ref, NewGuid); }
		if (Ref.ArrayName == TEXT("FontParameterValues"))                  { return RebindInArray(Instance->FontParameterValues, Ref, NewGuid); }
		return false;
	}

	/** Puts one expression's identity back to a recorded value. Used only by -Revert. */
	bool RestoreExpressionGuid(const FString& OwnerPath, const FString& ExpressionName, const FGuid& Guid)
	{
		UObject* Owner = LoadOwner(OwnerPath);
		if (Owner == nullptr)
		{
			return false;
		}
		UMaterialExpression* Expression = FindExpression(Owner, ExpressionName);
		if (Expression == nullptr || !Expression->bIsParameterExpression)
		{
			return false;
		}
		Owner->Modify();
		Expression->GetParameterExpressionId() = Guid;
		Owner->MarkPackageDirty();
		return true;
	}
}

namespace PIRRepair
{
	void Apply(const FPIRRunOptions& Options,
	           TArray<FPIRCollision>& Collisions,
	           TSet<FGuid>& AllKnownGuids,
	           FPIRRunSummary& Summary)
	{
		int32 Repaired = 0;

		for (FPIRCollision& Collision : Collisions)
		{
			if (!PIRClassify::ShouldRepair(Collision, Options.Threshold))
			{
				continue;
			}
			if (Options.Limit != INDEX_NONE && Repaired >= Options.Limit)
			{
				Collision.FailureReason = TEXT("Not attempted: -Limit reached. Re-run to continue.");
				continue;
			}
			++Repaired;

			// -------------------------------------------------- 1. choose the keeper
			TMap<FName, int32> OverrideCountByName;
			for (const FPIROverrideRef& Override : Collision.Overrides)
			{
				++OverrideCountByName.FindOrAdd(Override.ParameterName);
			}
			Collision.KeeperSortKey = PIRClassify::ChooseKeeper(Collision.Members, OverrideCountByName);

			// -------------------------------------------------- 2 + 3. re-mint and verify
			TArray<FPIRRemint> Remints;
			TMap<FString, FGuid> NewGuidByExpressionKey;
			bool bGroupOk = true;

			for (const FPIRParameterRef& Member : Collision.Members)
			{
				if (Member.SortKey() == Collision.KeeperSortKey)
				{
					NewGuidByExpressionKey.Add(Member.SortKey(), Collision.Guid);
					continue;
				}

				UObject* Owner = LoadOwner(Member.OwnerPath);
				UMaterialExpression* Expression = Owner != nullptr ? FindExpression(Owner, Member.ExpressionName) : nullptr;
				if (Expression == nullptr || !Expression->bIsParameterExpression)
				{
					Collision.FailureReason = FString::Printf(
						TEXT("Could not re-open '%s' in %s. Nothing was written for this group."),
						*Member.ExpressionName, *Member.OwnerPath);
					bGroupOk = false;
					break;
				}

				Owner->Modify();

				// ⛔ THE ENGINE'S OWN GENERATOR, NEVER FGuid::NewGuid().
				// MaterialExpressions.cpp:2145 seeds a parameter GUID from the expression's PATH via
				// CookDeterminism::NewGuid(GetPathName(), ESeed::Parameter). A randomly minted GUID
				// would compile and look identical in the editor while quietly making the package
				// non-deterministic between cooks - the exact class of defect this tool sells
				// itself on removing.
				Expression->UpdateParameterGuid(/*bForceGeneration*/ true, /*bAllowMarkingPackageDirty*/ true);
				const FGuid NewGuid = Expression->GetParameterExpressionId();

				// ⛔ VERIFY, DO NOT ASSUME. Two ways this legitimately fails, both silent:
				//   (a) the re-mint produced the SAME value, which means this holder's identity was
				//       already correctly derived from its own path and it should have been the
				//       keeper. Continuing would leave the collision in place while reporting a fix.
				//   (b) the re-mint landed on a GUID already in use somewhere else in the project,
				//       which would trade this collision for a new one somewhere the user is not
				//       looking.
				if (NewGuid == Collision.Guid || !NewGuid.IsValid())
				{
					Collision.FailureReason = FString::Printf(
						TEXT("Re-minting '%s' in %s returned the identity it already had, so this holder cannot be moved off the shared GUID. Group left untouched."),
						*Member.ExpressionName, *Member.OwnerPath);
					Expression->GetParameterExpressionId() = Collision.Guid;
					bGroupOk = false;
					break;
				}
				if (AllKnownGuids.Contains(NewGuid))
				{
					Collision.FailureReason = FString::Printf(
						TEXT("Re-minting '%s' in %s produced an identity already in use elsewhere in the project. Refused rather than trade one collision for another."),
						*Member.ExpressionName, *Member.OwnerPath);
					Expression->GetParameterExpressionId() = Collision.Guid;
					bGroupOk = false;
					break;
				}

				AllKnownGuids.Add(NewGuid);
				NewGuidByExpressionKey.Add(Member.SortKey(), NewGuid);

				FPIRRemint Remint;
				Remint.Parameter = Member;
				Remint.GuidBefore = Collision.Guid;
				Remint.GuidAfter = NewGuid;
				Remints.Add(Remint);

				Owner->MarkPackageDirty();
			}

			if (!bGroupOk)
			{
				// Roll back anything already moved in this group, so a partial failure never leaves
				// the project in a state neither the tool nor the user can describe.
				for (const FPIRRemint& Remint : Remints)
				{
					RestoreExpressionGuid(Remint.Parameter.OwnerPath, Remint.Parameter.ExpressionName, Remint.GuidBefore);
					AllKnownGuids.Remove(Remint.GuidAfter);
				}
				++Summary.GroupsFailed;
				Summary.Problems.Add(FString::Printf(TEXT("%s: %s"), *Collision.Guid.ToString(), *Collision.FailureReason));
				continue;
			}

			Collision.Remints = MoveTemp(Remints);
			Summary.ExpressionsReminted += Collision.Remints.Num();

			// -------------------------------------------------- 4. re-bind the overrides by NAME
			for (FPIROverrideRef& Override : Collision.Overrides)
			{
				// Which holder does this override's NAME identify? Exactly one, or the tool refuses.
				const FPIRParameterRef* Match = nullptr;
				int32 MatchCount = 0;
				for (const FPIRParameterRef& Member : Collision.Members)
				{
					if (Member.ParameterName == Override.ParameterName)
					{
						Match = &Member;
						++MatchCount;
					}
				}

				if (MatchCount == 0)
				{
					// The override names a parameter that no holder of this GUID carries - usually
					// an override left behind by a rename. Guessing a binding here is precisely the
					// corruption this tool exists to cure.
					Override.Note = TEXT("No holder of this identity carries this parameter name. Left exactly as it was.");
					++Summary.OverridesLeftAlone;
					continue;
				}
				if (MatchCount > 1)
				{
					Override.Note = TEXT("Two or more holders share this parameter name, so the correct binding is genuinely ambiguous. Left exactly as it was.");
					++Summary.OverridesLeftAlone;
					continue;
				}

				const FGuid* Resolved = NewGuidByExpressionKey.Find(Match->SortKey());
				if (Resolved == nullptr)
				{
					Override.Note = TEXT("Holder resolved but its post-repair identity was not recorded. Left exactly as it was.");
					++Summary.OverridesLeftAlone;
					continue;
				}

				if (*Resolved == Override.GuidBefore)
				{
					// The keeper's name. Nothing to do, and that is the point of the keeper rule.
					Override.GuidAfter = Override.GuidBefore;
					Override.bRebound = true;
					continue;
				}

				UMaterialInstance* Instance = Cast<UMaterialInstance>(LoadOwner(Override.InstancePath));
				if (Instance == nullptr)
				{
					Override.Note = TEXT("Instance could not be re-opened. Left exactly as it was.");
					++Summary.OverridesLeftAlone;
					continue;
				}

				Instance->Modify();
				if (RebindOverride(Instance, Override, *Resolved))
				{
					Instance->MarkPackageDirty();
					Override.GuidAfter = *Resolved;
					Override.bRebound = true;
					++Summary.OverridesRebound;
				}
				else
				{
					Override.Note = TEXT("The override row recorded during the scan was no longer present. Left exactly as it was.");
					++Summary.OverridesLeftAlone;
				}
			}

			Collision.bRepaired = true;
			++Summary.GroupsRepaired;
		}
	}

	bool WriteJournal(const FString& JournalPath, const TArray<FPIRCollision>& Collisions, FString& OutError)
	{
		const TSharedRef<FJsonObject> Root = MakeShared<FJsonObject>();
		Root->SetStringField(TEXT("tool"), TEXT("Parameter Identity Repair"));
		Root->SetStringField(TEXT("version"), TEXT("1.0.0"));
		Root->SetStringField(TEXT("writtenAtUtc"), FDateTime::UtcNow().ToIso8601());

		TArray<TSharedPtr<FJsonValue>> Groups;
		for (const FPIRCollision& Collision : Collisions)
		{
			if (!Collision.bRepaired)
			{
				continue;
			}

			const TSharedRef<FJsonObject> Group = MakeShared<FJsonObject>();
			Group->SetStringField(TEXT("guid"), Collision.Guid.ToString());

			TArray<TSharedPtr<FJsonValue>> RemintValues;
			for (const FPIRRemint& Remint : Collision.Remints)
			{
				const TSharedRef<FJsonObject> Entry = MakeShared<FJsonObject>();
				Entry->SetStringField(TEXT("ownerPath"), Remint.Parameter.OwnerPath);
				Entry->SetStringField(TEXT("expressionName"), Remint.Parameter.ExpressionName);
				Entry->SetStringField(TEXT("parameterName"), Remint.Parameter.ParameterName.ToString());
				Entry->SetStringField(TEXT("guidBefore"), Remint.GuidBefore.ToString());
				Entry->SetStringField(TEXT("guidAfter"), Remint.GuidAfter.ToString());
				RemintValues.Add(MakeShared<FJsonValueObject>(Entry));
			}
			Group->SetArrayField(TEXT("remints"), RemintValues);

			TArray<TSharedPtr<FJsonValue>> OverrideValues;
			for (const FPIROverrideRef& Override : Collision.Overrides)
			{
				if (!Override.bRebound || Override.GuidAfter == Override.GuidBefore)
				{
					continue;
				}
				const TSharedRef<FJsonObject> Entry = MakeShared<FJsonObject>();
				Entry->SetStringField(TEXT("instancePath"), Override.InstancePath);
				Entry->SetStringField(TEXT("arrayName"), Override.ArrayName);
				Entry->SetStringField(TEXT("parameterName"), Override.ParameterName.ToString());
				Entry->SetNumberField(TEXT("association"), Override.Association);
				Entry->SetNumberField(TEXT("index"), Override.Index);
				Entry->SetStringField(TEXT("guidBefore"), Override.GuidBefore.ToString());
				Entry->SetStringField(TEXT("guidAfter"), Override.GuidAfter.ToString());
				OverrideValues.Add(MakeShared<FJsonValueObject>(Entry));
			}
			Group->SetArrayField(TEXT("overrides"), OverrideValues);

			Groups.Add(MakeShared<FJsonValueObject>(Group));
		}
		Root->SetArrayField(TEXT("groups"), Groups);

		FString Text;
		const TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Text);
		if (!FJsonSerializer::Serialize(Root, Writer))
		{
			OutError = TEXT("Could not serialise the undo journal. Nothing was saved.");
			return false;
		}

		if (!FFileHelper::SaveStringToFile(Text, *JournalPath))
		{
			OutError = FString::Printf(TEXT("Could not write the undo journal to '%s'. Nothing was saved."), *JournalPath);
			return false;
		}
		return true;
	}

	bool Revert(const FString& JournalPath, FPIRRunSummary& Summary, FString& OutError)
	{
		FString Text;
		if (!FFileHelper::LoadFileToString(Text, *JournalPath))
		{
			OutError = FString::Printf(TEXT("Could not read the journal '%s'."), *JournalPath);
			return false;
		}

		TSharedPtr<FJsonObject> Root;
		const TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Text);
		if (!FJsonSerializer::Deserialize(Reader, Root) || !Root.IsValid())
		{
			OutError = FString::Printf(TEXT("'%s' is not a journal this tool wrote."), *JournalPath);
			return false;
		}

		const TArray<TSharedPtr<FJsonValue>>* Groups = nullptr;
		if (!Root->TryGetArrayField(TEXT("groups"), Groups) || Groups == nullptr)
		{
			OutError = FString::Printf(TEXT("'%s' has no groups array."), *JournalPath);
			return false;
		}

		TArray<UPackage*> Touched;
		Summary.bReverted = true;

		for (const TSharedPtr<FJsonValue>& GroupValue : *Groups)
		{
			const TSharedPtr<FJsonObject> Group = GroupValue->AsObject();
			if (!Group.IsValid())
			{
				continue;
			}
			++Summary.GroupsRepaired;

			const TArray<TSharedPtr<FJsonValue>>* Remints = nullptr;
			if (Group->TryGetArrayField(TEXT("remints"), Remints) && Remints != nullptr)
			{
				for (const TSharedPtr<FJsonValue>& Value : *Remints)
				{
					const TSharedPtr<FJsonObject> Entry = Value->AsObject();
					if (!Entry.IsValid())
					{
						continue;
					}
					FGuid Before;
					if (!FGuid::Parse(Entry->GetStringField(TEXT("guidBefore")), Before))
					{
						continue;
					}
					const FString OwnerPath = Entry->GetStringField(TEXT("ownerPath"));
					if (RestoreExpressionGuid(OwnerPath, Entry->GetStringField(TEXT("expressionName")), Before))
					{
						++Summary.ExpressionsReminted;
						if (UObject* Owner = LoadOwner(OwnerPath))
						{
							Touched.AddUnique(Owner->GetOutermost());
						}
					}
					else
					{
						Summary.Problems.Add(FString::Printf(
							TEXT("Revert could not restore '%s' in %s."),
							*Entry->GetStringField(TEXT("expressionName")), *OwnerPath));
					}
				}
			}

			const TArray<TSharedPtr<FJsonValue>>* Overrides = nullptr;
			if (Group->TryGetArrayField(TEXT("overrides"), Overrides) && Overrides != nullptr)
			{
				for (const TSharedPtr<FJsonValue>& Value : *Overrides)
				{
					const TSharedPtr<FJsonObject> Entry = Value->AsObject();
					if (!Entry.IsValid())
					{
						continue;
					}

					FGuid Before;
					FGuid After;
					if (!FGuid::Parse(Entry->GetStringField(TEXT("guidBefore")), Before)
						|| !FGuid::Parse(Entry->GetStringField(TEXT("guidAfter")), After))
					{
						continue;
					}

					const FString InstancePath = Entry->GetStringField(TEXT("instancePath"));
					UMaterialInstance* Instance = Cast<UMaterialInstance>(LoadOwner(InstancePath));
					if (Instance == nullptr)
					{
						Summary.Problems.Add(FString::Printf(TEXT("Revert could not open %s."), *InstancePath));
						continue;
					}

					// The forward record says "this row moved from Before to After". To undo it we
					// look the row up by its CURRENT identity - After - and put Before back.
					FPIROverrideRef Ref;
					Ref.InstancePath = InstancePath;
					Ref.ArrayName = Entry->GetStringField(TEXT("arrayName"));
					Ref.ParameterName = FName(*Entry->GetStringField(TEXT("parameterName")));
					Ref.Association = static_cast<uint8>(Entry->GetIntegerField(TEXT("association")));
					Ref.Index = Entry->GetIntegerField(TEXT("index"));
					Ref.GuidBefore = After;

					Instance->Modify();
					if (RebindOverride(Instance, Ref, Before))
					{
						Instance->MarkPackageDirty();
						Touched.AddUnique(Instance->GetOutermost());
						++Summary.OverridesRebound;
					}
					else
					{
						/*
						 * ⭐ A MISS HERE IS NOT YET A FAILURE, AND TREATING IT AS ONE REPORTED A
						 * COMPLETE UNDO AS A PARTIAL FAILURE. MEASURED 2026-08-31, first ever run of
						 * -Revert: six rows were reported as "may have been edited since" while the
						 * project had in fact come back EXACTLY - a sheet-level comparison against the
						 * pre-repair report matched on all 774 meaningful lines, every GUID included.
						 * The run still exited 4 (RepairIncomplete), which is the code a build agent
						 * gates on.
						 *
						 * The cause is ordering, not damage. A revert restores a group's EXPRESSIONS
						 * before its overrides, and the engine re-resolves an instance's rows from the
						 * parent by NAME when the instance is loaded. So the first group to touch a
						 * given instance can find its row already carrying the restored identity: the
						 * lookup by GuidAfter misses because the row is already correct.
						 *
						 * ⛔ So ask the second question before reporting anything. Looking the row up
						 * at the TARGET identity distinguishes "already restored" from "genuinely not
						 * there", and only the second is a problem. Re-binding Before to Before is a
						 * deliberate no-op write - it is the same dispatch table over the same nine
						 * arrays, which is the point: a duplicated finder could go out of step with
						 * the re-binder the day a tenth array is added.
						 */
						FPIROverrideRef AtTarget = Ref;
						AtTarget.GuidBefore = Before;
						if (RebindOverride(Instance, AtTarget, Before))
						{
							++Summary.OverridesAlreadyCorrect;
						}
						else
						{
							Summary.Problems.Add(FString::Printf(
								TEXT("Revert could not find the '%s' row in %s, at either the repaired "
								     "or the original identity. It may have been edited since."),
								*Ref.ParameterName.ToString(), *InstancePath));
						}
					}
				}
			}
		}

		if (Touched.Num() > 0)
		{
			const bool bSaved = UEditorLoadingAndSavingUtils::SavePackages(Touched, /*bOnlyDirty*/ true);
			Summary.PackagesSaved = bSaved ? Touched.Num() : 0;
			Summary.PackagesFailed = bSaved ? 0 : Touched.Num();
		}

		return true;
	}

	void SaveTouchedPackages(const TArray<FPIRCollision>& Collisions, FPIRRunSummary& Summary)
	{
		TArray<UPackage*> Touched;

		auto AddPackageFor = [&Touched](const FString& AssetPath)
		{
			if (UObject* Asset = LoadOwner(AssetPath))
			{
				Touched.AddUnique(Asset->GetOutermost());
			}
		};

		for (const FPIRCollision& Collision : Collisions)
		{
			if (!Collision.bRepaired)
			{
				continue;
			}
			for (const FPIRRemint& Remint : Collision.Remints)
			{
				AddPackageFor(Remint.Parameter.OwnerPath);
			}
			for (const FPIROverrideRef& Override : Collision.Overrides)
			{
				if (Override.bRebound && Override.GuidAfter != Override.GuidBefore)
				{
					AddPackageFor(Override.InstancePath);
				}
			}
		}

		if (Touched.Num() == 0)
		{
			return;
		}

		const bool bSaved = UEditorLoadingAndSavingUtils::SavePackages(Touched, /*bOnlyDirty*/ true);
		if (bSaved)
		{
			Summary.PackagesSaved = Touched.Num();
		}
		else
		{
			// ⚠️ SavePackages reports one boolean for the whole batch, so this counts packages
			// ATTEMPTED, not packages proven unwritten. The report says exactly that rather than
			// implying a per-file result the API never gave us.
			Summary.PackagesFailed = Touched.Num();
			Summary.Problems.Add(FString::Printf(
				TEXT("SavePackages reported failure for a batch of %d package(s). The repair is in memory but may not be on disk - check source control state before re-running."),
				Touched.Num()));
		}
	}
}
