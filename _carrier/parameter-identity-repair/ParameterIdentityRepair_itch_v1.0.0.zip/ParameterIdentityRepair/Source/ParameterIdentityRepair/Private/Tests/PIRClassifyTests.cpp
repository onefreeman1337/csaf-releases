// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "Algo/Reverse.h"
#include "Misc/AutomationTest.h"
#include "PIRClassify.h"

#if WITH_DEV_AUTOMATION_TESTS

namespace
{
	/** Builds one holder. Kept tiny so each test reads as the scenario it is describing. */
	FPIRParameterRef MakeRef(const TCHAR* OwnerPath, const TCHAR* ExpressionName, const TCHAR* ParameterName)
	{
		FPIRParameterRef Ref;
		Ref.OwnerPath = OwnerPath;
		Ref.OwnerKind = TEXT("Material");
		Ref.ExpressionName = ExpressionName;
		Ref.ParameterName = FName(ParameterName);
		Ref.ParameterType = 0; // Scalar
		Ref.ParameterTypeName = TEXT("Scalar");
		Ref.Guid = FGuid(1, 2, 3, 4);
		return Ref;
	}

	FPIROverrideRef MakeOverride(const TCHAR* InstancePath, const TCHAR* ParameterName)
	{
		FPIROverrideRef Ref;
		Ref.InstancePath = InstancePath;
		Ref.ArrayName = TEXT("ScalarParameterValues");
		Ref.ParameterName = FName(ParameterName);
		Ref.GuidBefore = FGuid(1, 2, 3, 4);
		Ref.GuidAfter = Ref.GuidBefore;
		return Ref;
	}
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPIRGradeCritical,
	"CSAF.ParameterIdentityRepair.Grade.Critical",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FPIRGradeCritical::RunTest(const FString&)
{
	FPIRCollision Collision;
	Collision.Guid = FGuid(1, 2, 3, 4);
	Collision.Members.Add(MakeRef(TEXT("/Game/MF_Rough.MF_Rough"), TEXT("Param_0"), TEXT("Roughness Scale")));
	Collision.Members.Add(MakeRef(TEXT("/Game/MF_Metal.MF_Metal"), TEXT("Param_0"), TEXT("Metallic Scale")));
	Collision.CoReachableMaterials.Add(TEXT("/Game/M_Master.M_Master"));

	PIRClassify::Grade(Collision);

	TestTrue(TEXT("different names reachable from one material is Critical"),
		Collision.Severity == EPIRSeverity::Critical);
	TestTrue(TEXT("the reason is specific, not a label"), Collision.SeverityReason.Contains(TEXT("shadowing")));
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPIRGradeSerious,
	"CSAF.ParameterIdentityRepair.Grade.Serious",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FPIRGradeSerious::RunTest(const FString&)
{
	FPIRCollision Collision;
	Collision.Guid = FGuid(1, 2, 3, 4);
	Collision.Members.Add(MakeRef(TEXT("/Game/MF_Rough.MF_Rough"), TEXT("Param_0"), TEXT("Roughness Scale")));
	Collision.Members.Add(MakeRef(TEXT("/Game/MF_Metal.MF_Metal"), TEXT("Param_0"), TEXT("Metallic Scale")));
	// No co-reachable material: the identical input as Critical, minus the one fact that separates them.

	PIRClassify::Grade(Collision);

	TestTrue(TEXT("different names not yet used together is Serious"),
		Collision.Severity == EPIRSeverity::Serious);
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPIRGradeLatent,
	"CSAF.ParameterIdentityRepair.Grade.Latent",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FPIRGradeLatent::RunTest(const FString&)
{
	FPIRCollision Collision;
	Collision.Guid = FGuid(1, 2, 3, 4);
	Collision.Members.Add(MakeRef(TEXT("/Game/MF_A.MF_A"), TEXT("Param_0"), TEXT("Tint")));
	Collision.Members.Add(MakeRef(TEXT("/Game/MF_B.MF_B"), TEXT("Param_0"), TEXT("Tint")));

	PIRClassify::Grade(Collision);

	TestTrue(TEXT("one shared name everywhere is Latent"), Collision.Severity == EPIRSeverity::Latent);

	// ⛔ THE SABOTAGE ARM. Same holders, same everything, except a co-reachable material is added -
	// which for DIFFERENT names would force Critical. Matching names must beat co-reachability,
	// because two parameters called the same thing resolve equivalently however they are reached.
	// Without this the grader would promote every same-name group in a shared master material to
	// Critical and the tool would rewrite thousands of packages it should not touch.
	Collision.CoReachableMaterials.Add(TEXT("/Game/M_Master.M_Master"));
	PIRClassify::Grade(Collision);
	TestTrue(TEXT("co-reachability does NOT promote a same-name group"),
		Collision.Severity == EPIRSeverity::Latent);

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPIRKeeperMinimisesRebinds,
	"CSAF.ParameterIdentityRepair.Keeper.MinimisesRebinds",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FPIRKeeperMinimisesRebinds::RunTest(const FString&)
{
	TArray<FPIRParameterRef> Members;
	// "A_First" sorts before "Z_Last", so a naive lexical keeper would pick it.
	Members.Add(MakeRef(TEXT("/Game/A_First.A_First"), TEXT("Param_0"), TEXT("Rarely Overridden")));
	Members.Add(MakeRef(TEXT("/Game/Z_Last.Z_Last"),   TEXT("Param_0"), TEXT("Often Overridden")));

	TMap<FName, int32> Counts;
	Counts.Add(FName(TEXT("Rarely Overridden")), 1);
	Counts.Add(FName(TEXT("Often Overridden")), 40);

	const FString Keeper = PIRClassify::ChooseKeeper(Members, Counts);

	// ⭐ The whole safety argument: re-minting an expression is provably correct, re-binding a
	// buyer's instance override is the step that can lose an authored value. Keeping the identity
	// on the heavily-overridden parameter means 40 overrides need no write at all instead of 1.
	TestEqual(TEXT("the keeper is the parameter with the most overrides, not the first alphabetically"),
		Keeper, Members[1].SortKey());
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPIRKeeperIsDeterministic,
	"CSAF.ParameterIdentityRepair.Keeper.Deterministic",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FPIRKeeperIsDeterministic::RunTest(const FString&)
{
	TArray<FPIRParameterRef> Members;
	Members.Add(MakeRef(TEXT("/Game/B_Mid.B_Mid"),   TEXT("Param_0"), TEXT("One")));
	Members.Add(MakeRef(TEXT("/Game/A_First.A_First"), TEXT("Param_0"), TEXT("Two")));
	Members.Add(MakeRef(TEXT("/Game/C_Last.C_Last"), TEXT("Param_0"), TEXT("Three")));

	// All tied on overrides, so the lexical tie-break decides. A run over an unchanged project must
	// reach the same answer every time or a second run rewrites what the first one just fixed.
	TMap<FName, int32> Counts;
	const FString First = PIRClassify::ChooseKeeper(Members, Counts);

	Algo::Reverse(Members);
	const FString Second = PIRClassify::ChooseKeeper(Members, Counts);

	TestEqual(TEXT("input order does not change the keeper"), First, Second);
	TestEqual(TEXT("and it is the lexically smallest sort key"), First, FString(TEXT("/Game/A_First.A_First|Param_0")));
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPIRThresholdGate,
	"CSAF.ParameterIdentityRepair.Threshold.Gate",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FPIRThresholdGate::RunTest(const FString&)
{
	FPIRCollision Latent;
	Latent.Members.Add(MakeRef(TEXT("/Game/A.A"), TEXT("P"), TEXT("Tint")));
	Latent.Members.Add(MakeRef(TEXT("/Game/B.B"), TEXT("P"), TEXT("Tint")));
	PIRClassify::Grade(Latent);

	FPIRCollision Critical;
	Critical.Members.Add(MakeRef(TEXT("/Game/A.A"), TEXT("P"), TEXT("One")));
	Critical.Members.Add(MakeRef(TEXT("/Game/B.B"), TEXT("P"), TEXT("Two")));
	Critical.CoReachableMaterials.Add(TEXT("/Game/M.M"));
	PIRClassify::Grade(Critical);

	TestTrue(TEXT("Critical passes a Critical threshold"),
		PIRClassify::ShouldRepair(Critical, EPIRSeverity::Critical));
	TestFalse(TEXT("Latent does not pass a Critical threshold"),
		PIRClassify::ShouldRepair(Latent, EPIRSeverity::Critical));
	TestTrue(TEXT("Latent passes a Latent threshold"),
		PIRClassify::ShouldRepair(Latent, EPIRSeverity::Latent));
	TestTrue(TEXT("Critical passes a Latent threshold too - worse is always included"),
		PIRClassify::ShouldRepair(Critical, EPIRSeverity::Latent));

	// A single holder is not a collision and must never be repaired, whatever the threshold.
	FPIRCollision Lone;
	Lone.Members.Add(MakeRef(TEXT("/Game/A.A"), TEXT("P"), TEXT("Tint")));
	PIRClassify::Grade(Lone);
	TestFalse(TEXT("a one-holder group is never repaired"),
		PIRClassify::ShouldRepair(Lone, EPIRSeverity::Latent));

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPIRReportOrderIsStable,
	"CSAF.ParameterIdentityRepair.Report.OrderIsStable",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FPIRReportOrderIsStable::RunTest(const FString&)
{
	auto Build = [](EPIRSeverity Severity, const FGuid& Guid)
	{
		FPIRCollision C;
		C.Severity = Severity;
		C.Guid = Guid;
		C.Members.Add(MakeRef(TEXT("/Game/A.A"), TEXT("P"), TEXT("One")));
		C.Members.Add(MakeRef(TEXT("/Game/B.B"), TEXT("P"), TEXT("Two")));
		return C;
	};

	TArray<FPIRCollision> Collisions;
	Collisions.Add(Build(EPIRSeverity::Latent,   FGuid(9, 9, 9, 9)));
	Collisions.Add(Build(EPIRSeverity::Critical, FGuid(5, 5, 5, 5)));
	Collisions.Add(Build(EPIRSeverity::Serious,  FGuid(1, 1, 1, 1)));

	PIRClassify::SortForReport(Collisions);

	TestTrue(TEXT("worst first"), Collisions[0].Severity == EPIRSeverity::Critical);
	TestTrue(TEXT("then serious"), Collisions[1].Severity == EPIRSeverity::Serious);
	TestTrue(TEXT("then latent"),  Collisions[2].Severity == EPIRSeverity::Latent);

	// Two groups equal on every earlier rule must still land in a fixed order, or the report looks
	// like it found different things on two runs over an unchanged project.
	TArray<FPIRCollision> Ties;
	Ties.Add(Build(EPIRSeverity::Serious, FGuid(8, 8, 8, 8)));
	Ties.Add(Build(EPIRSeverity::Serious, FGuid(2, 2, 2, 2)));
	PIRClassify::SortForReport(Ties);
	const FString FirstGuid = Ties[0].Guid.ToString();

	Algo::Reverse(Ties);
	PIRClassify::SortForReport(Ties);
	TestEqual(TEXT("ties resolve the same way regardless of input order"),
		Ties[0].Guid.ToString(), FirstGuid);

	return true;
}

#endif // WITH_DEV_AUTOMATION_TESTS
