// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "Misc/AutomationTest.h"
#include "PIRArgs.h"

#if WITH_DEV_AUTOMATION_TESTS

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPIRArgsDefaults,
	"CSAF.ParameterIdentityRepair.Args.Defaults",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FPIRArgsDefaults::RunTest(const FString&)
{
	FPIRRunOptions Options;
	FString Error;

	TestTrue(TEXT("an empty command line parses"), PIRArgs::Parse(TEXT(""), Options, Error));
	TestEqual(TEXT("audits exactly one path by default"), Options.Paths.Num(), 1);
	TestEqual(TEXT("and that path is /Game"), Options.Paths[0], FString(TEXT("/Game")));

	// ⛔ The default MUST be preview. A tool that rewrites every material in the project because
	// somebody typed the command without reading it is not a tool anyone keeps installed.
	TestFalse(TEXT("does not apply by default"), Options.bApply);
	TestFalse(TEXT("is not a revert by default"), Options.IsRevert());

	// Serious, not Latent: repairing every same-name group on a first run would churn thousands of
	// packages for a defect nobody has hit, which is its own kind of damage.
	TestTrue(TEXT("default threshold is Serious"), Options.Threshold == EPIRSeverity::Serious);
	TestEqual(TEXT("no repair limit by default"), Options.Limit, (int32)INDEX_NONE);

	TestTrue(TEXT("a report path is always chosen"), Options.ReportPath.Len() > 0);
	TestTrue(TEXT("a journal path is always chosen"), Options.JournalPath.Len() > 0);
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPIRArgsRejectsBadValues,
	"CSAF.ParameterIdentityRepair.Args.RejectsBadValues",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FPIRArgsRejectsBadValues::RunTest(const FString&)
{
	FString Error;

	{
		FPIRRunOptions Options;
		// A disk path instead of a mount point. Left unchecked this scans nothing and the tool
		// reports "nothing scanned", which blames the registry for a typo.
		TestFalse(TEXT("a relative path is refused"), PIRArgs::Parse(TEXT("-Paths=Game/Env"), Options, Error));
		TestTrue(TEXT("and the error names the offending entry"), Error.Contains(TEXT("Game/Env")));
	}
	{
		FPIRRunOptions Options;
		TestFalse(TEXT("an unknown severity is refused"), PIRArgs::Parse(TEXT("-Severity=Mild"), Options, Error));
	}
	{
		FPIRRunOptions Options;
		TestFalse(TEXT("a non-numeric limit is refused"), PIRArgs::Parse(TEXT("-Limit=some"), Options, Error));
	}
	{
		FPIRRunOptions Options;
		// ⛔ Zero must be an ERROR, never silently "no limit". That misreading, on a tool that
		// rewrites assets, is the most expensive one available.
		TestFalse(TEXT("-Limit=0 is refused rather than meaning everything"),
			PIRArgs::Parse(TEXT("-Limit=0"), Options, Error));
	}
	{
		FPIRRunOptions Options;
		// Contradictory switches are an error, never a silent precedence rule.
		TestFalse(TEXT("-Apply with -Revert is refused"),
			PIRArgs::Parse(TEXT("-Apply -Revert=C:/x.json"), Options, Error));
	}
	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPIRArgsAcceptsGoodValues,
	"CSAF.ParameterIdentityRepair.Args.AcceptsGoodValues",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FPIRArgsAcceptsGoodValues::RunTest(const FString&)
{
	FPIRRunOptions Options;
	FString Error;

	// ⭐ THE VACUITY CONTROL FOR THE SUITE ABOVE. Every test in RejectsBadValues asserts a FALSE
	// return, and a Parse() that returned false unconditionally would pass all five of them. This
	// one proves the parser can still say yes, so those refusals mean something.
	TestTrue(TEXT("a full command line parses"),
		PIRArgs::Parse(TEXT("-Paths=/Game/Env,/Game/Chars -Severity=Critical -Limit=25 -Apply"), Options, Error));
	TestEqual(TEXT("both paths survive"), Options.Paths.Num(), 2);
	TestTrue(TEXT("apply was read"), Options.bApply);
	TestTrue(TEXT("severity was read"), Options.Threshold == EPIRSeverity::Critical);
	TestEqual(TEXT("limit was read"), Options.Limit, 25);
	TestEqual(TEXT("no error text on success"), Error.Len(), 0);

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPIRArgsNormalisesPaths,
	"CSAF.ParameterIdentityRepair.Args.NormalisesPaths",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FPIRArgsNormalisesPaths::RunTest(const FString&)
{
	FPIRRunOptions Options;
	FString Error;

	// A trailing slash changes how the registry's prefix match behaves, so "/Game/Env" and
	// "/Game/Env/" must not scan different sets. Duplicates collapse for the same reason.
	//
	// ⛔ THIS INPUT USED TO CONTAIN SPACES, AND THE TEST PASSED FOR THE WRONG REASON.
	// FParse::Value stops at whitespace, so "-Paths=/Game/Env/, /Game/Env ,/Game/Env" was truncated
	// to "/Game/Env/," before the splitter ever saw it. The assertion "three spellings collapse to
	// one" was therefore satisfied by ONE spelling arriving, not by three collapsing - it would have
	// gone green with the deduplication removed entirely. Spaces are gone so the splitter genuinely
	// receives three entries and AddUnique has to do the work.
	TestTrue(TEXT("parses"), PIRArgs::Parse(TEXT("-Paths=/Game/Env/,/Game/Env,/Game/Env"), Options, Error));
	TestEqual(TEXT("three spellings of one path collapse to one"), Options.Paths.Num(), 1);
	TestEqual(TEXT("and it is the unslashed form"), Options.Paths[0], FString(TEXT("/Game/Env")));

	// The root itself must survive: chopping "/" down to "" would silently scan nothing.
	FPIRRunOptions RootOptions;
	TestTrue(TEXT("bare root parses"), PIRArgs::Parse(TEXT("-Paths=/"), RootOptions, Error));
	TestEqual(TEXT("bare root is preserved"), RootOptions.Paths[0], FString(TEXT("/")));

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPIRArgsCommaSeparatedPathsSurvive,
	"CSAF.ParameterIdentityRepair.Args.CommaSeparatedPathsSurvive",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FPIRArgsCommaSeparatedPathsSurvive::RunTest(const FString&)
{
	FPIRRunOptions Options;
	FString Error;

	/*
	 * ⛔ A DEDICATED REGRESSION TEST FOR A REAL SHIPPED-CANDIDATE BUG, kept separate from
	 * AcceptsGoodValues so that a future edit which "simplifies" the parser cannot quietly take the
	 * whole multi-root feature with it.
	 *
	 * FParse::Value's bShouldStopOnSeparator defaults to TRUE and truncates the value at the first
	 * ',' (Engine/.../Misc/Parse.h:65). The three-argument call therefore turned
	 * "-Paths=/Game/A,/Game/B" into "/Game/A" and the tool audited ONE of the two roots the user
	 * named, then reported a clean result for the half it never opened. The packaging gate compiled
	 * that happily; only running the tests found it.
	 */
	TestTrue(TEXT("parses"), PIRArgs::Parse(TEXT("-Paths=/Game/Alpha,/Game/Beta,/Game/Gamma"), Options, Error));
	TestEqual(TEXT("all THREE comma-separated roots survive the parse"), Options.Paths.Num(), 3);
	TestEqual(TEXT("first root"),  Options.Paths[0], FString(TEXT("/Game/Alpha")));
	TestEqual(TEXT("second root"), Options.Paths[1], FString(TEXT("/Game/Beta")));
	TestEqual(TEXT("third root"),  Options.Paths[2], FString(TEXT("/Game/Gamma")));

	return true;
}

#endif // WITH_DEV_AUTOMATION_TESTS
