// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "PIRRun.h"

#include "HAL/PlatformTime.h"
#include "Misc/Paths.h"
#include "ParameterIdentityRepairModule.h"
#include "PIRClassify.h"
#include "PIRRepair.h"
#include "PIRReport.h"
#include "PIRScan.h"

namespace PIRRun
{
	void LogSummary(const FPIRRunSummary& Summary, int32 Code)
	{
		UE_LOG(LogParameterIdentityRepair, Display, TEXT("---- Parameter Identity Repair ----"));

		/*
		 * ⛔ A REVERT IS ITS OWN MODE AND THE SCAN BLOCK IS A LIE ABOUT IT. Measured 2026-08-31 on
		 * the first ever -Revert run: it printed "mode: preview (nothing written)", then
		 * "parameters examined: 0" and "collisions: 0 / 0 / 0", over a run that had restored 40
		 * groups and written 49 packages. Every one of those fields was accurate and the block as a
		 * whole was false, because a revert never scans - so the zeros describe work that was never
		 * attempted, not work that found nothing. Print what the run actually did.
		 */
		if (Summary.bReverted)
		{
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  mode                  : REVERT (assets restored from a journal)"));
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  groups in journal     : %d"), Summary.GroupsRepaired);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  identities restored   : %d"), Summary.ExpressionsReminted);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  overrides restored    : %d"), Summary.OverridesRebound);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  overrides already ok  : %d"), Summary.OverridesAlreadyCorrect);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  packages saved        : %d"), Summary.PackagesSaved);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  packages not written  : %d"), Summary.PackagesFailed);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  seconds               : %.1f"), Summary.Seconds);
			// No report path: a revert writes no sheet, and printing the default one implied a file
			// that does not exist.
			for (const FString& Problem : Summary.Problems)
			{
				UE_LOG(LogParameterIdentityRepair, Warning, TEXT("  ! %s"), *Problem);
			}
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  exit code             : %d"), Code);
			return;
		}

		UE_LOG(LogParameterIdentityRepair, Display, TEXT("  mode                  : %s"),
			Summary.bApplied ? TEXT("APPLY (assets written)") : TEXT("preview (nothing written)"));
		UE_LOG(LogParameterIdentityRepair, Display, TEXT("  materials  found/read : %d / %d"),
			Summary.MaterialsFound, Summary.MaterialsLoaded);
		UE_LOG(LogParameterIdentityRepair, Display, TEXT("  functions  found/read : %d / %d"),
			Summary.FunctionsFound, Summary.FunctionsLoaded);
		UE_LOG(LogParameterIdentityRepair, Display, TEXT("  instances  found/read : %d / %d"),
			Summary.InstancesFound, Summary.InstancesLoaded);
		UE_LOG(LogParameterIdentityRepair, Display, TEXT("  parameters examined   : %d"), Summary.ParametersExamined);
		UE_LOG(LogParameterIdentityRepair, Display, TEXT("  collisions critical   : %d"), Summary.CollisionsCritical);
		UE_LOG(LogParameterIdentityRepair, Display, TEXT("  collisions serious    : %d"), Summary.CollisionsSerious);
		UE_LOG(LogParameterIdentityRepair, Display, TEXT("  collisions latent     : %d"), Summary.CollisionsLatent);

		if (Summary.bApplied)
		{
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  groups repaired       : %d"), Summary.GroupsRepaired);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  groups refused        : %d"), Summary.GroupsFailed);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  identities re-minted  : %d"), Summary.ExpressionsReminted);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  overrides re-bound    : %d"), Summary.OverridesRebound);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  overrides left alone  : %d"), Summary.OverridesLeftAlone);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  packages saved        : %d"), Summary.PackagesSaved);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  packages not written  : %d"), Summary.PackagesFailed);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("  undo journal          : %s"), *Summary.JournalPath);
		}

		UE_LOG(LogParameterIdentityRepair, Display, TEXT("  seconds               : %.1f"), Summary.Seconds);
		UE_LOG(LogParameterIdentityRepair, Display, TEXT("  report                : %s"), *Summary.ReportPath);

		for (const FString& Problem : Summary.Problems)
		{
			UE_LOG(LogParameterIdentityRepair, Warning, TEXT("  ! %s"), *Problem);
		}

		UE_LOG(LogParameterIdentityRepair, Display, TEXT("  exit code             : %d"), Code);
	}

	int32 Execute(const FPIRRunOptions& Options, FPIRRunSummary& Summary)
	{
		const double Started = FPlatformTime::Seconds();
		Summary.bApplied = Options.bApply;
		Summary.ReportPath = Options.ReportPath;
		Summary.JournalPath = Options.JournalPath;

		// ------------------------------------------------------------------ revert
		if (Options.IsRevert())
		{
			FString RevertError;
			if (!PIRRepair::Revert(Options.RevertJournal, Summary, RevertError))
			{
				UE_LOG(LogParameterIdentityRepair, Error, TEXT("%s"), *RevertError);
				Summary.Seconds = FPlatformTime::Seconds() - Started;
				return static_cast<int32>(EPIRExit::BadArguments);
			}
			Summary.Seconds = FPlatformTime::Seconds() - Started;
			return static_cast<int32>(
				Summary.Problems.Num() > 0 ? EPIRExit::RepairIncomplete : EPIRExit::Ok);
		}

		// -------------------------------------------------------------------- scan
		TArray<FPIRCollision> Collisions;
		TSet<FGuid> AllKnownGuids;
		FString ScanError;

		if (!PIRScan::Run(Options, Summary, Collisions, AllKnownGuids, ScanError))
		{
			UE_LOG(LogParameterIdentityRepair, Error, TEXT("%s"), *ScanError);
			Summary.Problems.Add(ScanError);
			Summary.Seconds = FPlatformTime::Seconds() - Started;

			// ⛔ The report is still written, and it still says zero. A run that refuses must leave
			// the same artefact a run that succeeds does, or a CI job that only collects the HTML
			// silently reports nothing at all on the one occasion it mattered.
			FString ReportError;
			PIRReport::Write(Options, Collisions, Summary, ReportError);
			return static_cast<int32>(EPIRExit::NothingScanned);
		}

		// ------------------------------------------------------------------- apply
		if (Options.bApply)
		{
			PIRRepair::Apply(Options, Collisions, AllKnownGuids, Summary);

			// ⛔ JOURNAL FIRST, SAVE SECOND, ALWAYS. If the journal cannot be written the repair is
			// abandoned before a single package reaches disk, because an un-undoable batch edit to a
			// buyer's material library is exactly the outcome this tool exists to prevent.
			FString JournalError;
			if (!PIRRepair::WriteJournal(Options.JournalPath, Collisions, JournalError))
			{
				UE_LOG(LogParameterIdentityRepair, Error, TEXT("%s"), *JournalError);
				Summary.Problems.Add(JournalError + TEXT(" Nothing was saved to disk."));
			}
			else if (!Options.bNoSave)
			{
				PIRRepair::SaveTouchedPackages(Collisions, Summary);
			}
		}

		Summary.Seconds = FPlatformTime::Seconds() - Started;

		FString ReportError;
		if (!PIRReport::Write(Options, Collisions, Summary, ReportError))
		{
			UE_LOG(LogParameterIdentityRepair, Warning, TEXT("%s"), *ReportError);
			Summary.Problems.Add(ReportError);
		}

		// -------------------------------------------------------------- exit code
		if (Options.bApply)
		{
			return static_cast<int32>(
				Summary.GroupsFailed > 0 ? EPIRExit::RepairIncomplete : EPIRExit::Ok);
		}

		// Preview: only collisions the user asked about move the exit code. A project full of
		// Latent groups must not fail a CI gate that was configured for Critical.
		int32 AtOrAboveThreshold = 0;
		for (const FPIRCollision& Collision : Collisions)
		{
			if (PIRClassify::ShouldRepair(Collision, Options.Threshold))
			{
				++AtOrAboveThreshold;
			}
		}
		return static_cast<int32>(
			AtOrAboveThreshold > 0 ? EPIRExit::CollisionsFound : EPIRExit::Ok);
	}
}
