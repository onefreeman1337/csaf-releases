// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "PIRScan.h"

#include "AssetRegistry/ARFilter.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "Materials/Material.h"
#include "Materials/MaterialExpression.h"
#include "Materials/MaterialFunction.h"
#include "Materials/MaterialInstance.h"
#include "Materials/MaterialParameters.h"
#include "Modules/ModuleManager.h"
#include "ParameterIdentityRepairModule.h"
#include "PIRClassify.h"
#include "UObject/UObjectGlobals.h"

namespace
{
	/** Collect garbage every this many loaded assets, so a 40,000 material project survives. */
	constexpr int32 GarbageCollectInterval = 512;

	/** Log a progress line every this many loaded assets. Silence for ten minutes reads as a hang. */
	constexpr int32 ProgressInterval = 500;

	/**
	 * Reads one expression's identity, if it has one.
	 *
	 * ⛔ THE bIsParameterExpression GUARD IS LOAD-BEARING, NOT DEFENSIVE STYLE.
	 * UMaterialExpression::GetParameterExpressionId (MaterialExpression.h:514) is a base
	 * implementation that checkf()s when bIsParameterExpression is false. Calling it on an Add node
	 * is an assertion failure, not a null GUID, so a scan that skipped this test would take down
	 * the editor on the first ordinary material it opened.
	 */
	bool ReadParameterRef(UMaterialExpression* Expression,
	                      const FString& OwnerPath,
	                      const FString& OwnerKind,
	                      FPIRParameterRef& Out)
	{
		if (Expression == nullptr || !Expression->bIsParameterExpression)
		{
			return false;
		}

		const FGuid Guid = Expression->GetParameterExpressionId();
		if (!Guid.IsValid())
		{
			// An invalid GUID is not a collision and is not this tool's business: the engine mints
			// one on the next PostLoad or PostInitProperties. Counting it as a parameter examined
			// would also be honest, and it is - see the caller.
			return false;
		}

		Out.OwnerPath = OwnerPath;
		Out.OwnerKind = OwnerKind;
		Out.ExpressionName = Expression->GetName();
		Out.ParameterName = Expression->HasAParameterName() ? Expression->GetParameterName() : NAME_None;
		Out.ParameterType = static_cast<uint8>(Expression->GetParameterType());
		Out.ParameterTypeName = PIRTypes::ParameterTypeToString(Out.ParameterType);
		Out.Guid = Guid;
		return true;
	}

	/**
	 * Records every override in one typed array whose GUID is in the collision set.
	 *
	 * Templated over the element type rather than written nine times, because all nine of UE 5.8's
	 * material instance override arrays share the shape {ParameterInfo, <value>, ExpressionGUID} -
	 * verified field by field in MaterialInstance.h before this was written, at :82 :141 :190 :243
	 * :291 :339 :387 :435 :491.
	 *
	 * ⭐ NOTE WHAT THIS FUNCTION CANNOT DO: it never reads or writes the value field. That is not an
	 * omission, it is the safety argument. The repair moves an ExpressionGUID and nothing else, so
	 * "did the buyer's authored value survive?" is answered by construction rather than by a
	 * comparison that could itself be wrong.
	 */
	template <typename TParamValue>
	void CollectOverridesFromArray(const TArray<TParamValue>& Values,
	                               const TCHAR* ArrayName,
	                               const FString& InstancePath,
	                               const TSet<FGuid>& CollidingGuids,
	                               TArray<FPIROverrideRef>& Out)
	{
		for (const TParamValue& Value : Values)
		{
			if (!CollidingGuids.Contains(Value.ExpressionGUID))
			{
				continue;
			}

			FPIROverrideRef Ref;
			Ref.InstancePath = InstancePath;
			Ref.ArrayName = ArrayName;
			Ref.ParameterName = Value.ParameterInfo.Name;
			Ref.Association = static_cast<uint8>(Value.ParameterInfo.Association.GetValue());
			Ref.Index = Value.ParameterInfo.Index;
			Ref.GuidBefore = Value.ExpressionGUID;
			Ref.GuidAfter = Value.ExpressionGUID;
			Out.Add(Ref);
		}
	}

	/** Every override array on one instance, in one call. Kept beside the template it drives. */
	void CollectOverrides(const UMaterialInstance* Instance,
	                      const TSet<FGuid>& CollidingGuids,
	                      TArray<FPIROverrideRef>& Out)
	{
		const FString Path = Instance->GetPathName();

		CollectOverridesFromArray(Instance->ScalarParameterValues,                TEXT("ScalarParameterValues"),                Path, CollidingGuids, Out);
		CollectOverridesFromArray(Instance->VectorParameterValues,                TEXT("VectorParameterValues"),                Path, CollidingGuids, Out);
		CollectOverridesFromArray(Instance->DoubleVectorParameterValues,          TEXT("DoubleVectorParameterValues"),          Path, CollidingGuids, Out);
		CollectOverridesFromArray(Instance->TextureParameterValues,               TEXT("TextureParameterValues"),               Path, CollidingGuids, Out);
		CollectOverridesFromArray(Instance->TextureCollectionParameterValues,     TEXT("TextureCollectionParameterValues"),     Path, CollidingGuids, Out);
		CollectOverridesFromArray(Instance->ParameterCollectionParameterValues,   TEXT("ParameterCollectionParameterValues"),   Path, CollidingGuids, Out);
		CollectOverridesFromArray(Instance->RuntimeVirtualTextureParameterValues, TEXT("RuntimeVirtualTextureParameterValues"), Path, CollidingGuids, Out);
		CollectOverridesFromArray(Instance->SparseVolumeTextureParameterValues,   TEXT("SparseVolumeTextureParameterValues"),   Path, CollidingGuids, Out);
		CollectOverridesFromArray(Instance->FontParameterValues,                  TEXT("FontParameterValues"),                  Path, CollidingGuids, Out);
	}

	/** Asks the registry for one class, recursively, under the requested paths. */
	void QueryAssets(IAssetRegistry& Registry,
	                 const UClass* Class,
	                 const TArray<FString>& Paths,
	                 TArray<FAssetData>& Out)
	{
		FARFilter Filter;
		Filter.bRecursiveClasses = true;
		Filter.bRecursivePaths = true;
		Filter.ClassPaths.Add(Class->GetClassPathName());
		for (const FString& Path : Paths)
		{
			Filter.PackagePaths.Add(FName(*Path));
		}
		Registry.GetAssets(Filter, Out);
	}
}

namespace PIRScan
{
	bool Run(const FPIRRunOptions& Options,
	         FPIRRunSummary& Summary,
	         TArray<FPIRCollision>& OutCollisions,
	         TSet<FGuid>& OutAllGuids,
	         FString& OutError)
	{
		OutError.Reset();
		OutCollisions.Reset();
		OutAllGuids.Reset();

		FAssetRegistryModule& RegistryModule =
			FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
		IAssetRegistry& Registry = RegistryModule.Get();

		// ⛔ SCAN FIRST, THEN WAIT. WaitForCompletion() alone does NOT index a root the registry was
		// never told about - measured in this wing shipping Source Link, where -Paths=/Engine
		// returned zero assets from a fully-completed registry. ScanPathsSynchronous is a no-op for
		// paths already covered, so the ordinary /Game case pays nothing for this.
		Registry.ScanPathsSynchronous(Options.Paths, /*bForceRescan*/ false);
		Registry.WaitForCompletion();

		TArray<FAssetData> MaterialAssets;
		TArray<FAssetData> FunctionAssets;
		TArray<FAssetData> InstanceAssets;
		QueryAssets(Registry, UMaterial::StaticClass(), Options.Paths, MaterialAssets);
		QueryAssets(Registry, UMaterialFunction::StaticClass(), Options.Paths, FunctionAssets);
		QueryAssets(Registry, UMaterialInstance::StaticClass(), Options.Paths, InstanceAssets);

		Summary.MaterialsFound = MaterialAssets.Num();
		Summary.FunctionsFound = FunctionAssets.Num();
		Summary.InstancesFound = InstanceAssets.Num();

		UE_LOG(LogParameterIdentityRepair, Display,
			TEXT("Registry offered %d material(s), %d function(s), %d instance(s) under %d path(s)."),
			Summary.MaterialsFound, Summary.FunctionsFound, Summary.InstancesFound, Options.Paths.Num());

		/** Guid -> every expression holding it, keyed by SortKey so a re-scan cannot double count. */
		TMap<FGuid, TArray<FPIRParameterRef>> ByGuid;

		/** Guid -> materials from which two or more DISTINCT holders are reachable. */
		TMap<FGuid, TArray<FString>> CoReachable;

		int32 LoadedSinceCollect = 0;

		// ⚠️ A lambda rather than a repeated block, but note it takes the owning object by pointer
		// and lets it die at the end of the iteration. Nothing here outlives the loop body, which
		// is what makes the periodic CollectGarbage below safe.
		auto RecordOwnExpressions =
			[&ByGuid, &Summary](TConstArrayView<TObjectPtr<UMaterialExpression>> Expressions,
			                    const FString& OwnerPath,
			                    const FString& OwnerKind)
		{
			for (const TObjectPtr<UMaterialExpression>& ExpressionPtr : Expressions)
			{
				UMaterialExpression* Expression = ExpressionPtr.Get();
				if (Expression == nullptr || !Expression->bIsParameterExpression)
				{
					continue;
				}

				++Summary.ParametersExamined;

				FPIRParameterRef Ref;
				if (ReadParameterRef(Expression, OwnerPath, OwnerKind, Ref))
				{
					TArray<FPIRParameterRef>& Holders = ByGuid.FindOrAdd(Ref.Guid);
					const FString Key = Ref.SortKey();
					const bool bAlreadyKnown = Holders.ContainsByPredicate(
						[&Key](const FPIRParameterRef& Existing) { return Existing.SortKey() == Key; });
					if (!bAlreadyKnown)
					{
						Holders.Add(Ref);
					}
				}
			}
		};

		// ---------------------------------------------------------------- materials
		for (int32 Index = 0; Index < MaterialAssets.Num(); ++Index)
		{
			UMaterial* Material = Cast<UMaterial>(MaterialAssets[Index].GetAsset());
			if (Material == nullptr)
			{
				continue;
			}
			++Summary.MaterialsLoaded;
			++LoadedSinceCollect;

			const FString OwnerPath = Material->GetPathName();

#if WITH_EDITORONLY_DATA
			RecordOwnExpressions(Material->GetExpressions(), OwnerPath, TEXT("Material"));

			// Co-reachability, computed while the material is already open so it costs no second
			// load. GetAllExpressionsInMaterialAndFunctionsOfType recurses through function calls
			// AND through layer/blend interfaces (Material.h:1632), which is the only way to see
			// that two holders in two different functions meet inside one material.
			TArray<UMaterialExpression*> Reachable;
			Material->GetAllExpressionsInMaterialAndFunctionsOfType<UMaterialExpression>(Reachable);

			TMap<FGuid, TSet<FString>> DistinctHoldersHere;
			for (UMaterialExpression* Expression : Reachable)
			{
				if (Expression == nullptr || !Expression->bIsParameterExpression)
				{
					continue;
				}
				const FGuid Guid = Expression->GetParameterExpressionId();
				if (!Guid.IsValid())
				{
					continue;
				}

				// The owner of a reachable expression is whatever package it lives in, which for a
				// function call is the FUNCTION, not this material. GetOutermost() is what
				// distinguishes "the same node seen twice" from "two nodes that collide".
				const FString HolderKey = Expression->GetOutermost()->GetName() + TEXT("|") + Expression->GetName();
				DistinctHoldersHere.FindOrAdd(Guid).Add(HolderKey);
			}

			for (const TPair<FGuid, TSet<FString>>& Pair : DistinctHoldersHere)
			{
				if (Pair.Value.Num() >= 2)
				{
					CoReachable.FindOrAdd(Pair.Key).AddUnique(OwnerPath);
				}
			}
#endif // WITH_EDITORONLY_DATA

			if ((Index + 1) % ProgressInterval == 0)
			{
				UE_LOG(LogParameterIdentityRepair, Display, TEXT("  ... %d/%d materials read"),
					Index + 1, MaterialAssets.Num());
			}
			if (LoadedSinceCollect >= GarbageCollectInterval)
			{
				// Safe here and only here: no UObject pointer from this loop survives the iteration.
				CollectGarbage(RF_NoFlags);
				LoadedSinceCollect = 0;
			}
		}

		// ------------------------------------------------------- material functions
		for (int32 Index = 0; Index < FunctionAssets.Num(); ++Index)
		{
			UMaterialFunction* Function = Cast<UMaterialFunction>(FunctionAssets[Index].GetAsset());
			if (Function == nullptr)
			{
				continue;
			}
			++Summary.FunctionsLoaded;
			++LoadedSinceCollect;

#if WITH_EDITORONLY_DATA
			RecordOwnExpressions(Function->GetExpressions(), Function->GetPathName(), TEXT("MaterialFunction"));
#endif

			if (LoadedSinceCollect >= GarbageCollectInterval)
			{
				CollectGarbage(RF_NoFlags);
				LoadedSinceCollect = 0;
			}
		}

		// ⛔ THE REFUSAL. An empty result set is not a clean bill of health: an asset registry that
		// never indexed the requested path answers exactly like a project with no materials in it.
		// This wing has already shipped one scanner that had to learn the difference, so the check
		// is here rather than in a caller that might forget it.
		if (Summary.ParametersExamined == 0)
		{
			OutError = FString::Printf(
				TEXT("Examined ZERO parameter expressions across %d material(s) and %d function(s) under %s. ")
				TEXT("That is a scan that never reached your content, not a project without material parameters. ")
				TEXT("Check the -Paths= value names a real mount point."),
				Summary.MaterialsFound, Summary.FunctionsFound, *FString::Join(Options.Paths, TEXT(", ")));
			return false;
		}

		// ------------------------------------------------------------ the collisions
		TSet<FGuid> CollidingGuids;
		for (TPair<FGuid, TArray<FPIRParameterRef>>& Pair : ByGuid)
		{
			// Every identity seen anywhere, colliding or not. The repair checks a freshly minted
			// GUID against this set so it cannot quietly trade one collision for a new one.
			OutAllGuids.Add(Pair.Key);

			if (Pair.Value.Num() < 2)
			{
				continue;
			}

			FPIRCollision Collision;
			Collision.Guid = Pair.Key;
			Collision.Members = MoveTemp(Pair.Value);
			Collision.Members.Sort([](const FPIRParameterRef& A, const FPIRParameterRef& B)
			{
				return A.SortKey() < B.SortKey();
			});

			if (const TArray<FString>* Materials = CoReachable.Find(Pair.Key))
			{
				Collision.CoReachableMaterials = *Materials;
				Collision.CoReachableMaterials.Sort();
			}

			PIRClassify::Grade(Collision);
			CollidingGuids.Add(Pair.Key);
			OutCollisions.Add(MoveTemp(Collision));
		}

		UE_LOG(LogParameterIdentityRepair, Display,
			TEXT("Examined %d parameter expression(s); %d identity collision(s) found."),
			Summary.ParametersExamined, OutCollisions.Num());

		// -------------------------------------------------- instances that reference them
		// Skipped entirely when nothing collides - there is no reason to open thousands of
		// instances to look for GUIDs that are not in question.
		if (CollidingGuids.Num() > 0)
		{
			TArray<FPIROverrideRef> AllOverrides;
			LoadedSinceCollect = 0;

			for (int32 Index = 0; Index < InstanceAssets.Num(); ++Index)
			{
				UMaterialInstance* Instance = Cast<UMaterialInstance>(InstanceAssets[Index].GetAsset());
				if (Instance == nullptr)
				{
					continue;
				}
				++Summary.InstancesLoaded;
				++LoadedSinceCollect;

				CollectOverrides(Instance, CollidingGuids, AllOverrides);

				if ((Index + 1) % ProgressInterval == 0)
				{
					UE_LOG(LogParameterIdentityRepair, Display, TEXT("  ... %d/%d instances read"),
						Index + 1, InstanceAssets.Num());
				}
				if (LoadedSinceCollect >= GarbageCollectInterval)
				{
					CollectGarbage(RF_NoFlags);
					LoadedSinceCollect = 0;
				}
			}

			for (FPIRCollision& Collision : OutCollisions)
			{
				for (const FPIROverrideRef& Override : AllOverrides)
				{
					if (Override.GuidBefore == Collision.Guid)
					{
						Collision.Overrides.Add(Override);
					}
				}
			}

			UE_LOG(LogParameterIdentityRepair, Display,
				TEXT("Read %d material instance(s); %d override(s) point at a shared identity."),
				Summary.InstancesLoaded, AllOverrides.Num());
		}

		for (const FPIRCollision& Collision : OutCollisions)
		{
			switch (Collision.Severity)
			{
			case EPIRSeverity::Critical: ++Summary.CollisionsCritical; break;
			case EPIRSeverity::Serious:  ++Summary.CollisionsSerious;  break;
			default:                     ++Summary.CollisionsLatent;   break;
			}
		}

		PIRClassify::SortForReport(OutCollisions);
		return true;
	}
}
