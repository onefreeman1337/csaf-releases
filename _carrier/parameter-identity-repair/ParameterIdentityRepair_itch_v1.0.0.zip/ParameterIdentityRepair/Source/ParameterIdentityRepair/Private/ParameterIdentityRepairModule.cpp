// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "ParameterIdentityRepairModule.h"

#include "HAL/IConsoleManager.h"
#include "HAL/PlatformMisc.h"
#include "Misc/Parse.h"
#include "Modules/ModuleManager.h"
#include "PIRArgs.h"
#include "PIRRun.h"

DEFINE_LOG_CATEGORY(LogParameterIdentityRepair);

#define LOCTEXT_NAMESPACE "FParameterIdentityRepairModule"

namespace
{
	IConsoleCommand* RepairCommand = nullptr;

	/**
	 * The in-editor entry point.
	 *
	 * On a build agent, an editor started headless still works and is the cheapest way to run this
	 * inside an existing project setup:
	 *
	 *   UnrealEditor-Cmd.exe Project.uproject -unattended -nosplash
	 *     -ExecCmds="MaterialParams.Repair -Apply -ExitOnFinish"
	 *
	 * ⛔ `-ExitOnFinish`, NEVER a trailing `,Quit`. `Quit` is not an editor console command - the
	 * editor's is QUIT_EDITOR - so an editor started with `,Quit` does the work, writes the report,
	 * and then sits there forever holding the plugin binary. On a build agent that is a wedged job.
	 */
	void HandleRepairCommand(const TArray<FString>& Args)
	{
		const FString Params = FString::Join(Args, TEXT(" "));

		if (FParse::Param(*Params, TEXT("Help")) || FParse::Param(*Params, TEXT("?")))
		{
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("\n%s"), *PIRArgs::Usage());
			return;
		}

		FPIRRunOptions Options;
		FString ParseError;
		if (!PIRArgs::Parse(Params, Options, ParseError))
		{
			UE_LOG(LogParameterIdentityRepair, Error, TEXT("%s"), *ParseError);
			UE_LOG(LogParameterIdentityRepair, Display, TEXT("\n%s"), *PIRArgs::Usage());
			if (FParse::Param(*Params, TEXT("ExitOnFinish")))
			{
				FPlatformMisc::RequestExitWithStatus(false, static_cast<uint8>(EPIRExit::BadArguments));
			}
			return;
		}

		FPIRRunSummary Summary;
		const int32 Code = PIRRun::Execute(Options, Summary);
		PIRRun::LogSummary(Summary, Code);

		if (FParse::Param(*Params, TEXT("ExitOnFinish")))
		{
			FPlatformMisc::RequestExitWithStatus(false, static_cast<uint8>(Code));
		}
	}
}

void FParameterIdentityRepairModule::StartupModule()
{
	RepairCommand = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("MaterialParams.Repair"),
		TEXT("Find and fix material parameters that share one ExpressionGUID. Add -Help for the switch list."),
		FConsoleCommandWithArgsDelegate::CreateStatic(&HandleRepairCommand),
		ECVF_Default);
}

void FParameterIdentityRepairModule::ShutdownModule()
{
	if (RepairCommand != nullptr)
	{
		IConsoleManager::Get().UnregisterConsoleObject(RepairCommand);
		RepairCommand = nullptr;
	}
}

#undef LOCTEXT_NAMESPACE

// ⛔ The module name argument MUST equal the plugin folder name, the .uplugin filename and
// Modules[0].Name in the descriptor. Fab rejects on that disagreement, and a module with no
// IMPLEMENT_MODULE gates perfectly and then cannot load at all - measured in this wing, where the
// editor answered "module could not be initialized successfully" and then threw an access violation
// inside CoreUObject. The error never names the macro.
IMPLEMENT_MODULE(FParameterIdentityRepairModule, ParameterIdentityRepair)
