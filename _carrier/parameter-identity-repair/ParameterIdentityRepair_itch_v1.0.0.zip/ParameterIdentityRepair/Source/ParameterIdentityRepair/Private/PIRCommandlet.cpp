// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "PIRCommandlet.h"

#include "Misc/Parse.h"
#include "ParameterIdentityRepairModule.h"
#include "PIRArgs.h"
#include "PIRRun.h"

UParameterIdentityRepairCommandlet::UParameterIdentityRepairCommandlet()
{
	IsClient = false;
	IsServer = false;
	IsEditor = true;
	LogToConsole = true;
}

int32 UParameterIdentityRepairCommandlet::Main(const FString& Params)
{
	if (FParse::Param(*Params, TEXT("Help")) || FParse::Param(*Params, TEXT("?")))
	{
		UE_LOG(LogParameterIdentityRepair, Display, TEXT("\n%s"), *PIRArgs::Usage());
		return static_cast<int32>(EPIRExit::Ok);
	}

	FPIRRunOptions Options;
	FString ParseError;
	if (!PIRArgs::Parse(Params, Options, ParseError))
	{
		UE_LOG(LogParameterIdentityRepair, Error, TEXT("%s"), *ParseError);
		UE_LOG(LogParameterIdentityRepair, Display, TEXT("\n%s"), *PIRArgs::Usage());
		return static_cast<int32>(EPIRExit::BadArguments);
	}

	FPIRRunSummary Summary;
	const int32 Code = PIRRun::Execute(Options, Summary);
	PIRRun::LogSummary(Summary, Code);
	return Code;
}
