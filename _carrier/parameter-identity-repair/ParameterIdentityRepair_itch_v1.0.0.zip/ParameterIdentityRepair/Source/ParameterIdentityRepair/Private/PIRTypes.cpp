// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "PIRTypes.h"

#include "Materials/MaterialParameters.h"

namespace PIRTypes
{
	FString SeverityToString(EPIRSeverity Severity)
	{
		switch (Severity)
		{
		case EPIRSeverity::Critical: return TEXT("Critical");
		case EPIRSeverity::Serious:  return TEXT("Serious");
		case EPIRSeverity::Latent:   return TEXT("Latent");
		default:                     return TEXT("Unknown");
		}
	}

	bool SeverityFromString(const FString& In, EPIRSeverity& Out)
	{
		if (In.Equals(TEXT("Critical"), ESearchCase::IgnoreCase)) { Out = EPIRSeverity::Critical; return true; }
		if (In.Equals(TEXT("Serious"),  ESearchCase::IgnoreCase)) { Out = EPIRSeverity::Serious;  return true; }
		if (In.Equals(TEXT("Latent"),   ESearchCase::IgnoreCase)) { Out = EPIRSeverity::Latent;   return true; }
		if (In.Equals(TEXT("All"),      ESearchCase::IgnoreCase)) { Out = EPIRSeverity::Latent;   return true; }
		return false;
	}

	FString ParameterTypeToString(uint8 ParameterType)
	{
		// Mirrors EMaterialParameterType, Engine/Public/Materials/MaterialParameters.h:187.
		// ⚠️ Deliberately a switch over the widened value rather than a cast back to the enum:
		// a future engine version that adds a type must produce a legible "Type 12" in the report
		// rather than undefined behaviour from casting an out-of-range value into an enum class.
		switch (ParameterType)
		{
		case static_cast<uint8>(EMaterialParameterType::Scalar):               return TEXT("Scalar");
		case static_cast<uint8>(EMaterialParameterType::Vector):               return TEXT("Vector");
		case static_cast<uint8>(EMaterialParameterType::DoubleVector):         return TEXT("DoubleVector");
		case static_cast<uint8>(EMaterialParameterType::Texture):              return TEXT("Texture");
		case static_cast<uint8>(EMaterialParameterType::TextureCollection):    return TEXT("TextureCollection");
		case static_cast<uint8>(EMaterialParameterType::Font):                 return TEXT("Font");
		case static_cast<uint8>(EMaterialParameterType::RuntimeVirtualTexture):return TEXT("RuntimeVirtualTexture");
		case static_cast<uint8>(EMaterialParameterType::SparseVolumeTexture):  return TEXT("SparseVolumeTexture");
		case static_cast<uint8>(EMaterialParameterType::StaticSwitch):         return TEXT("StaticSwitch");
		case static_cast<uint8>(EMaterialParameterType::ParameterCollection):  return TEXT("ParameterCollection");
		case static_cast<uint8>(EMaterialParameterType::StaticComponentMask):  return TEXT("StaticComponentMask");
		case static_cast<uint8>(EMaterialParameterType::None):                 return TEXT("None");
		default: break;
		}
		return FString::Printf(TEXT("Type %u"), static_cast<uint32>(ParameterType));
	}

	FString EscapeHtml(const FString& In)
	{
		FString Out = In;
		// & FIRST, or the ampersands introduced by the later replacements get double-escaped.
		Out.ReplaceInline(TEXT("&"), TEXT("&amp;"), ESearchCase::CaseSensitive);
		Out.ReplaceInline(TEXT("<"), TEXT("&lt;"), ESearchCase::CaseSensitive);
		Out.ReplaceInline(TEXT(">"), TEXT("&gt;"), ESearchCase::CaseSensitive);
		Out.ReplaceInline(TEXT("\""), TEXT("&quot;"), ESearchCase::CaseSensitive);
		return Out;
	}
}
