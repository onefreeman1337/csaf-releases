// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "PIRClassify.h"

#include "Algo/Sort.h"

namespace PIRClassify
{
	void Grade(FPIRCollision& Collision)
	{
		if (Collision.Members.Num() < 2)
		{
			// Not reachable through the scanner, which only emits groups of two or more. Graded
			// defensively rather than left at whatever the struct was constructed with, because a
			// future caller that builds a group by hand should not inherit a silent Latent.
			Collision.Severity = EPIRSeverity::Latent;
			Collision.SeverityReason = TEXT("Fewer than two holders - not a collision.");
			return;
		}

		if (!Collision.HasNameDisagreement())
		{
			Collision.Severity = EPIRSeverity::Latent;
			Collision.SeverityReason = FString::Printf(
				TEXT("All %d holders are named '%s', so every lookup resolves to an equivalent parameter today. ")
				TEXT("It is still a defect: rename one and the engine migrates instance overrides by GUID, so the other holders' instances follow a rename they never asked for."),
				Collision.Members.Num(),
				*Collision.Members[0].ParameterName.ToString());
			return;
		}

		if (Collision.CoReachableMaterials.Num() > 0)
		{
			Collision.Severity = EPIRSeverity::Critical;
			Collision.SeverityReason = FString::Printf(
				TEXT("%d holders carry different names and %d material(s) can reach more than one of them, ")
				TEXT("so one parameter is shadowing another right now and overrides written against the shadowed one are going nowhere."),
				Collision.Members.Num(),
				Collision.CoReachableMaterials.Num());
			return;
		}

		Collision.Severity = EPIRSeverity::Serious;
		Collision.SeverityReason = FString::Printf(
			TEXT("%d holders carry different names but no single material reaches more than one of them yet. ")
			TEXT("Nothing is visibly broken today; it breaks the moment both are used in one material, and a rename of either already migrates the other's overrides."),
			Collision.Members.Num());
	}

	FString ChooseKeeper(const TArray<FPIRParameterRef>& Members, const TMap<FName, int32>& OverrideCountByName)
	{
		if (Members.Num() == 0)
		{
			return FString();
		}

		const FPIRParameterRef* Best = &Members[0];
		int32 BestCount = OverrideCountByName.FindRef(Best->ParameterName);
		FString BestKey = Best->SortKey();

		for (int32 i = 1; i < Members.Num(); ++i)
		{
			const FPIRParameterRef& Candidate = Members[i];
			const int32 CandidateCount = OverrideCountByName.FindRef(Candidate.ParameterName);
			const FString CandidateKey = Candidate.SortKey();

			// More overrides wins. Equal overrides falls through to the lexical tie-break, which is
			// what makes a second run over an unchanged project produce an identical decision.
			if (CandidateCount > BestCount || (CandidateCount == BestCount && CandidateKey < BestKey))
			{
				Best = &Candidate;
				BestCount = CandidateCount;
				BestKey = CandidateKey;
			}
		}

		return BestKey;
	}

	bool ShouldRepair(const FPIRCollision& Collision, EPIRSeverity Threshold)
	{
		return Collision.Members.Num() >= 2 && PIRTypes::AtLeastAsSevere(Collision.Severity, Threshold);
	}

	void SortForReport(TArray<FPIRCollision>& Collisions)
	{
		Algo::Sort(Collisions, [](const FPIRCollision& A, const FPIRCollision& B)
		{
			if (A.Severity != B.Severity)
			{
				// Lower enum value is worse, and worse sorts first.
				return static_cast<uint8>(A.Severity) < static_cast<uint8>(B.Severity);
			}
			if (A.Members.Num() != B.Members.Num())
			{
				return A.Members.Num() > B.Members.Num();
			}
			// ⚠️ Final tie-break on the GUID string, never on nothing. Two groups that compare equal
			// under every earlier rule would otherwise land in whatever order the TMap iterated,
			// which changes between runs and makes the report look like it found different things.
			return A.Guid.ToString() < B.Guid.ToString();
		});
	}
}
