// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "PIRArgs.h"

#include "HAL/FileManager.h"
#include "Misc/Parse.h"
#include "Misc/Paths.h"

namespace
{
	/** Splits "/Game/A,/Game/B" and rejects an entry that is not a mount-point-shaped path. */
	bool ParsePathList(const FString& Value, TArray<FString>& OutPaths, FString& OutError)
	{
		TArray<FString> Raw;
		Value.ParseIntoArray(Raw, TEXT(","), /*InCullEmpty*/ true);

		if (Raw.Num() == 0)
		{
			OutError = TEXT("-Paths= was given with nothing after the equals sign. Supply one or more content roots, e.g. -Paths=/Game/Characters,/Game/Env");
			return false;
		}

		for (FString Entry : Raw)
		{
			Entry.TrimStartAndEndInline();
			if (!Entry.StartsWith(TEXT("/")))
			{
				// ⚠️ A relative path here is the single most likely user error, and left unchecked it
				// produces a scan of zero assets - which this tool then correctly refuses as
				// NothingScanned, but with a message about the registry rather than about the typo.
				// Catching it at parse time turns a confusing exit 2 into a one-line fix.
				OutError = FString::Printf(
					TEXT("-Paths entry '%s' is not a content path. It must start with a mount point, e.g. /Game or /MyPlugin - not a directory on disk."),
					*Entry);
				return false;
			}

			// Trailing slashes make the registry's prefix match behave differently for
			// "/Game/Foo" and "/Game/Foo/". Normalise so both spellings scan the same set.
			while (Entry.Len() > 1 && Entry.EndsWith(TEXT("/")))
			{
				Entry.LeftChopInline(1);
			}

			OutPaths.AddUnique(Entry);
		}

		return true;
	}
}

namespace PIRArgs
{
	bool Parse(const FString& Params, FPIRRunOptions& OutOptions, FString& OutError)
	{
		OutError.Reset();

		OutOptions.bApply = FParse::Param(*Params, TEXT("Apply"));
		OutOptions.bNoSave = FParse::Param(*Params, TEXT("NoSave"));

		FString Value;

		/*
		 * ⛔ THE `false` IS THE WHOLE POINT AND IT IS A REAL BUG THIS ONCE HAD.
		 *
		 * FParse::Value's fourth parameter is bShouldStopOnSeparator and it DEFAULTS TO TRUE.
		 * Engine/Source/Runtime/Core/Public/Misc/Parse.h:65-66, verbatim: "If this is true, and the
		 * value doesn't start with a '\"' then it may be truncated to ',' or ')' in addition to
		 * whitespace."
		 *
		 * So the obvious three-argument call silently truncates `-Paths=/Game/A,/Game/B` to
		 * `/Game/A`. The audit then scans ONE of the two roots the user named, reports a clean
		 * result for the half it never opened, and nothing anywhere says so - which is exactly the
		 * silent-wrong-answer this product exists to remove from someone else's project.
		 *
		 * Caught by RUNNING the automation tests, not by the packaging gate, which compiled this
		 * happily. The same applies to the path-valued switches below: a comma in a filename would
		 * truncate the path in precisely the same way.
		 */
		if (FParse::Value(*Params, TEXT("Paths="), Value, /*bShouldStopOnSeparator*/ false))
		{
			if (!ParsePathList(Value, OutOptions.Paths, OutError))
			{
				return false;
			}
		}
		if (OutOptions.Paths.Num() == 0)
		{
			OutOptions.Paths.Add(TEXT("/Game"));
		}

		if (FParse::Value(*Params, TEXT("Severity="), Value))
		{
			if (!PIRTypes::SeverityFromString(Value, OutOptions.Threshold))
			{
				OutError = FString::Printf(
					TEXT("-Severity=%s is not a grade. Use Critical, Serious, Latent or All."), *Value);
				return false;
			}
		}

		if (FParse::Value(*Params, TEXT("Limit="), Value))
		{
			if (!Value.IsNumeric())
			{
				OutError = FString::Printf(TEXT("-Limit=%s is not a number."), *Value);
				return false;
			}
			const int32 Parsed = FCString::Atoi(*Value);
			if (Parsed <= 0)
			{
				// ⛔ Zero is rejected rather than treated as "no limit". A -Limit=0 that silently
				// meant "everything" would be the most expensive possible misreading of a switch on
				// a tool that rewrites assets.
				OutError = FString::Printf(
					TEXT("-Limit=%s must be 1 or more. Omit the switch entirely for no limit."), *Value);
				return false;
			}
			OutOptions.Limit = Parsed;
		}

		// bShouldStopOnSeparator = false on every path-valued switch, for the reason given above:
		// a comma anywhere in a path would otherwise silently truncate it.
		if (FParse::Value(*Params, TEXT("Revert="), Value, /*bShouldStopOnSeparator*/ false))
		{
			OutOptions.RevertJournal = Value;
			OutOptions.RevertJournal.TrimStartAndEndInline();
			OutOptions.RevertJournal.TrimQuotesInline();
			if (OutOptions.RevertJournal.IsEmpty())
			{
				OutError = TEXT("-Revert= needs the path of a journal written by an earlier -Apply run.");
				return false;
			}
		}

		if (FParse::Value(*Params, TEXT("Report="), Value, /*bShouldStopOnSeparator*/ false))
		{
			OutOptions.ReportPath = Value;
			OutOptions.ReportPath.TrimStartAndEndInline();
			OutOptions.ReportPath.TrimQuotesInline();
		}
		if (OutOptions.ReportPath.IsEmpty())
		{
			OutOptions.ReportPath = DefaultOutputPath(TEXT("ParameterIdentityRepair.html"));
		}

		if (FParse::Value(*Params, TEXT("Journal="), Value, /*bShouldStopOnSeparator*/ false))
		{
			OutOptions.JournalPath = Value;
			OutOptions.JournalPath.TrimStartAndEndInline();
			OutOptions.JournalPath.TrimQuotesInline();
		}
		if (OutOptions.JournalPath.IsEmpty())
		{
			OutOptions.JournalPath = DefaultOutputPath(TEXT("ParameterIdentityRepair.journal.json"));
		}

		// ⚠️ Contradictory switches are an ERROR, never a silent precedence rule. A user who typed
		// both meant one of them, and picking one for them is how a preview run writes assets.
		if (OutOptions.IsRevert() && OutOptions.bApply)
		{
			OutError = TEXT("-Revert and -Apply cannot be combined. A revert already writes assets; run it on its own.");
			return false;
		}

		return true;
	}

	FString DefaultOutputPath(const FString& FileName)
	{
		return FPaths::ConvertRelativePathToFull(
			FPaths::Combine(FPaths::ProjectSavedDir(), TEXT("ParameterIdentityRepair"), FileName));
	}

	FString Usage()
	{
		return FString(
			TEXT("Parameter Identity Repair - finds and fixes material parameters that share one ExpressionGUID.\n")
			TEXT("\n")
			TEXT("  -Paths=/Game[,/More]  Content roots to audit. Default /Game.\n")
			TEXT("  -Severity=<grade>     Critical | Serious | Latent | All. Default Serious.\n")
			TEXT("                        Groups below the grade are listed in the report but never repaired.\n")
			TEXT("  -Apply                Write the repair. WITHOUT THIS NOTHING IS EVER MODIFIED.\n")
			TEXT("  -Limit=<n>            Repair at most n collision groups. Useful for a first cautious pass.\n")
			TEXT("  -NoSave               Do the whole repair in memory and report it, but save nothing.\n")
			TEXT("  -Revert=<journal>     Replay an undo journal written by an earlier -Apply run.\n")
			TEXT("  -Report=<file.html>   Where the sheet goes. Default Saved/ParameterIdentityRepair/.\n")
			TEXT("  -Journal=<file.json>  Where the undo journal goes. Default alongside the report.\n")
			TEXT("  -ExitOnFinish         Quit the host process with the exit code (build agents).\n")
			TEXT("  -Help                 This text.\n")
			TEXT("\n")
			TEXT("Exit codes: 0 clean  1 bad arguments  2 NOTHING SCANNED (a failure, not a pass)\n")
			TEXT("            3 collisions found in preview  4 apply finished with unrepaired groups\n"));
	}
}
