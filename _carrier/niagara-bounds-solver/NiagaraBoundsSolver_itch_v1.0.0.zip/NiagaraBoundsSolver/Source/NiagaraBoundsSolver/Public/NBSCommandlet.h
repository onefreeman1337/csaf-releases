// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Commandlets/Commandlet.h"
#include "NBSCommandlet.generated.h"

/**
 * The CI entry point.
 *
 *   UnrealEditor-Cmd.exe Project.uproject -run=NBS -Path=/Game/Effects -Apply
 *
 * ⛔ THE SWITCH IS -run=NBS AND IT IS NAMED BY THIS CLASS, NOT BY THE PLUGIN. `-run=X` resolves to
 * exactly one class called `XCommandlet` (LaunchEngineLoop.cpp:2334 appends the suffix, :3939 looks
 * the name up) and knows nothing about the module or friendly name. This comment and the Readme both
 * said `-run=NiagaraBoundsSolver` until 2026-09-03, which resolves to `NiagaraBoundsSolverCommandlet`
 * — a class that does not exist in this package — so the documented CI entry point could never start.
 *
 * ⚠️ CPU systems only, and it says so rather than pretending. GPU emitters need an RHI to read
 * their particle counts back through, so under -nullrhi they are reported as skipped with
 * "gpu-needs-editor-run" instead of being silently measured as empty. Run the console command in a
 * headless editor session when the project has GPU effects.
 */
UCLASS()
class UNBSCommandlet : public UCommandlet
{
	GENERATED_BODY()

public:
	UNBSCommandlet();

	virtual int32 Main(const FString& Params) override;
};
