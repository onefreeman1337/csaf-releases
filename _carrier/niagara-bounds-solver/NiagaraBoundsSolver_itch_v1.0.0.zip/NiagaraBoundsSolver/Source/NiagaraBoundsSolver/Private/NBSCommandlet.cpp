// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "NBSCommandlet.h"

#include "Misc/Parse.h"
#include "NBSArgs.h"
#include "NBSRun.h"
#include "NiagaraBoundsSolverModule.h"

UNBSCommandlet::UNBSCommandlet()
{
	IsClient = false;
	IsServer = false;
	IsEditor = true;
	LogToConsole = true;
}

int32 UNBSCommandlet::Main(const FString& Params)
{
	if (FParse::Param(*Params, TEXT("Help")) || FParse::Param(*Params, TEXT("?")))
	{
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("\n%s"), *NBSArgs::Usage());
		return static_cast<int32>(ENBSExit::Ok);
	}

	FNBSRunOptions Options;
	FString ParseError;
	if (!NBSArgs::Parse(Params, Options, ParseError))
	{
		UE_LOG(LogNiagaraBoundsSolver, Error, TEXT("%s"), *ParseError);
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("\n%s"), *NBSArgs::Usage());
		return static_cast<int32>(ENBSExit::BadArguments);
	}

	FNBSRunSummary Summary;
	const int32 Code = NBSRun::Execute(Options, Summary);

	UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("---- Niagara Bounds Solver ----"));
	UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  mode                 : %s"),
		Summary.bApplied ? TEXT("APPLY (assets written)") : TEXT("preview (nothing written)"));
	UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  systems found        : %d"), Summary.SystemsFound);
	// "loaded", not "simulated": SystemsLoaded counts a successful asset cast (NBSRun.cpp:108),
	// which happens BEFORE measurement, so skipped systems are included. See NBSReport.cpp.
	UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  systems loaded       : %d"), Summary.SystemsLoaded);
	UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  systems solved       : %d"), Summary.SystemsSolved);
	UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  were under-bounded   : %d"), Summary.SystemsUnderBounded);
	UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  systems skipped      : %d"), Summary.SystemsSkipped);
	UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  emitters pinned      : %d"), Summary.EmittersWritten);
	UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  ticks simulated      : %d"), Summary.TotalTicksSimulated);
	UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  assets saved         : %d"), Summary.PackagesSaved);
	UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  seconds              : %.1f"), Summary.Seconds);
	UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  report               : %s"), *Options.ReportPath);
	for (const FString& Problem : Summary.Problems)
	{
		UE_LOG(LogNiagaraBoundsSolver, Warning, TEXT("  ! %s"), *Problem);
	}

	return Code;
}
