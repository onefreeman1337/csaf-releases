// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "Misc/AutomationTest.h"
#include "NBSUnion.h"
// FNBSSystemResult, for the under-bounded containment test below. Included explicitly rather than
// leaned on transitively: NBSUnion.h pulls in CoreMinimal only.
#include "NBSTypes.h"

#if WITH_DEV_AUTOMATION_TESTS

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnionAcceptsRealSamples,
	"CSAF.NiagaraBoundsSolver.Union.AcceptsRealSamples",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnionAcceptsRealSamples::RunTest(const FString&)
{
	FNBSBoundsAccumulator Acc;

	TestTrue(TEXT("a real box is accepted"), Acc.Add(FBox(FVector(-10), FVector(10))));
	TestTrue(TEXT("a second real box is accepted"), Acc.Add(FBox(FVector(0), FVector(50))));

	TestTrue(TEXT("has a result"), Acc.HasResult());
	TestEqual(TEXT("two offered"), Acc.NumOffered(), 2);
	TestEqual(TEXT("two accepted"), Acc.NumAccepted(), 2);

	// The union, not the last sample - which is the entire difference from the engine's own
	// one-frame path.
	const FBox Union = Acc.GetUnion();
	TestEqual(TEXT("union min X"), Union.Min.X, -10.0);
	TestEqual(TEXT("union max X"), Union.Max.X, 50.0);

	return true;
}

/**
 * ⛔ THE TEST THAT PROTECTS THE PRODUCT'S ONE PROMISE.
 *
 * A Niagara instance with no live particles reports a VALID box of zero extent
 * (NiagaraSystemInstance.cpp:155 and :1056 both assign FBox(ZeroVector, ZeroVector)). Unioning
 * that with a real box drags a corner to the origin, producing a bound that is both too big and
 * centred wrong - and nothing would ever throw.
 */
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnionRejectsEmptyFrames,
	"CSAF.NiagaraBoundsSolver.Union.RejectsEmptyFrames",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnionRejectsEmptyFrames::RunTest(const FString&)
{
	FNBSBoundsAccumulator Acc;

	// Exactly what the engine hands back before the first spawn.
	const FBox EngineEmpty(FVector::ZeroVector, FVector::ZeroVector);
	TestFalse(TEXT("a zero-extent box is refused"), Acc.Add(EngineEmpty));
	TestFalse(TEXT("and it does not create a result"), Acc.HasResult());

	// A real burst, far from the origin.
	TestTrue(TEXT("the real sample is accepted"), Acc.Add(FBox(FVector(1000), FVector(1100))));

	// The burst dies; the engine goes back to reporting a point at the origin.
	TestFalse(TEXT("the trailing empty frame is refused too"), Acc.Add(EngineEmpty));

	TestEqual(TEXT("three offered"), Acc.NumOffered(), 3);
	TestEqual(TEXT("one accepted"), Acc.NumAccepted(), 1);

	// If an empty frame had been folded in, Min would have been dragged to 0.
	TestEqual(TEXT("union was not dragged to the origin"), Acc.GetUnion().Min.X, 1000.0);

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnionRejectsNaN,
	"CSAF.NiagaraBoundsSolver.Union.RejectsNaN",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnionRejectsNaN::RunTest(const FString&)
{
	FNBSBoundsAccumulator Acc;
	TestTrue(TEXT("a real box first"), Acc.Add(FBox(FVector(-5), FVector(5))));

	// NaN fails every comparison, so a naive size test would ACCEPT this and poison the union for
	// the rest of the run.
	FBox Poison(FVector(0), FVector(1));
	Poison.Max.Y = FMath::Sqrt(-1.0);
	TestFalse(TEXT("a NaN box is refused"), Acc.Add(Poison));

	TestEqual(TEXT("still one accepted"), Acc.NumAccepted(), 1);
	TestTrue(TEXT("union is still finite"), FMath::IsFinite(Acc.GetUnion().Max.Y));

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnionPadNeverShrinks,
	"CSAF.NiagaraBoundsSolver.Union.PadNeverShrinks",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnionPadNeverShrinks::RunTest(const FString&)
{
	FNBSBoundsAccumulator Acc;
	Acc.Add(FBox(FVector(-100), FVector(100)));

	const FBox NoPad = Acc.GetPadded(0.0f);
	TestEqual(TEXT("zero pad is the union"), NoPad.Max.X, 100.0);

	const FBox Padded = Acc.GetPadded(0.1f);
	TestTrue(TEXT("a positive pad grows the box"), Padded.Max.X > 100.0);

	// Shrinking a measured bound would re-create the exact defect this product removes.
	const FBox Negative = Acc.GetPadded(-0.5f);
	TestEqual(TEXT("a negative pad is clamped, not honoured"), Negative.Max.X, 100.0);

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnionGrowthFactor,
	"CSAF.NiagaraBoundsSolver.Union.GrowthFactor",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnionGrowthFactor::RunTest(const FString&)
{
	const FBox Small(FVector(-1), FVector(1));   // 2x2x2 = 8
	const FBox Big(FVector(-2), FVector(2));     // 4x4x4 = 64

	TestEqual(TEXT("8x growth"), FNBSBoundsAccumulator::GrowthFactor(Small, Big), 8.0);

	// A degenerate old box must not produce an infinity that prints as garbage.
	const FBox Point(FVector::ZeroVector, FVector::ZeroVector);
	TestEqual(TEXT("a point old box is not comparable"),
		FNBSBoundsAccumulator::GrowthFactor(Point, Big), 0.0);

	const FBox Invalid(ForceInit);
	TestEqual(TEXT("an invalid box is not comparable"),
		FNBSBoundsAccumulator::GrowthFactor(Invalid, Big), 0.0);

	return true;
}

/**
 * ⚠️ THIS TEST ASSERTS A LIMITATION RATHER THAN A FEATURE, DELIBERATELY.
 *
 * When a tick produces no bounds at all the engine substitutes FBox(-1,-1,-1)..(1,1,1)
 * (NiagaraSystemInstance.cpp:2802-2807) - a valid, non-degenerate 2cm cube. The accumulator CANNOT
 * tell that apart from a genuinely tiny effect, and pretending otherwise would be the lie. That is
 * exactly why NBSSolve gates every sample on a live particle count instead of trusting the box, and
 * this test pins the reason down so nobody later "fixes" the accumulator into silently dropping
 * small real effects.
 */
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnionCannotDetectEngineDefaultBox,
	"CSAF.NiagaraBoundsSolver.Union.CannotDetectEngineDefaultBox",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnionCannotDetectEngineDefaultBox::RunTest(const FString&)
{
	FNBSBoundsAccumulator Acc;
	const FBox EngineFallback(-FVector::OneVector, FVector::OneVector);

	TestTrue(TEXT("the engine's 2cm fallback is indistinguishable from a real tiny effect"),
		Acc.Add(EngineFallback));

	return true;
}

/**
 * ⛔ THE REGRESSION TEST FOR THE PRODUCT'S CENTRAL CLAIM, AND IT IS A REAL SHIPPED CASE.
 *
 * "Under-bounded" was decided from GrowthFactor, a VOLUME ratio, until 2026-09-04. A volume ratio
 * cannot see an effect escaping along one axis while the other two shrink - the volume falls, and
 * the row prints green over a system that is being culled. That is the exact defect the Readme
 * accuses the engine's own validator of: "bounds that are wrong ... pass clean. That is the case
 * that actually ships."
 *
 * The numbers below are MEASURED, not invented: NS_Ability_Nova in the fixture project carried a
 * stored box of 1051 x 1187 x 1984 and measured a union of 856 x 798 x 2099. It overshoots on Z by
 * 115 units and the old volume ratio came out at 0.77x.
 *
 * ⚠️ Both arms matter and the second is the one that keeps the fix honest: widening a check until
 * it catches the bug is easy, and a check that reports every system is a deleted check, not a
 * stricter one. So a genuinely contained union must still read as contained.
 */
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FNBSUnderBoundedIsContainmentNotVolume,
	"CSAF.NiagaraBoundsSolver.Result.UnderBoundedIsContainmentNotVolume",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool FNBSUnderBoundedIsContainmentNotVolume::RunTest(const FString&)
{
	// A helper matching how NBSSolve fills a result for a system that already had fixed bounds.
	auto Make = [](const FVector& OldSize, const FVector& MeasuredSize)
	{
		FNBSSystemResult R;
		R.bOldFixedBounds = true;
		R.OldBounds = FBox(-OldSize * 0.5, OldSize * 0.5);
		R.MeasuredBounds = FBox(-MeasuredSize * 0.5, MeasuredSize * 0.5);
		return R;
	};

	// --- the real case: two axes shrink, one escapes -------------------------------------------
	const FNBSSystemResult Nova = Make(FVector(1051, 1187, 1984), FVector(856, 798, 2099));
	TestTrue(TEXT("an effect that overshoots on Z is under-bounded, even though the volume fell"),
		Nova.WasUnderBounded());

	// and the volume really does fall, so this test is exercising the case it claims to
	const double NovaVolumeRatio = (856.0 * 798.0 * 2099.0) / (1051.0 * 1187.0 * 1984.0);
	TestTrue(TEXT("the measured volume is SMALLER than the stored volume"), NovaVolumeRatio < 1.0);

	// --- the control: a union comfortably inside the stored box is NOT under-bounded ------------
	const FNBSSystemResult Contained = Make(FVector(1000, 1000, 1000), FVector(500, 500, 500));
	TestFalse(TEXT("a union inside the stored box is not under-bounded"),
		Contained.WasUnderBounded());

	// --- the boundary: exactly equal boxes are contained, not escaping --------------------------
	const FNBSSystemResult Exact = Make(FVector(400, 400, 400), FVector(400, 400, 400));
	TestFalse(TEXT("a union exactly filling the stored box is contained (closed bounds)"),
		Exact.WasUnderBounded());

	// --- an offset union escapes even though it is smaller on every axis ------------------------
	// Size alone cannot answer containment; this is why the test is IsInsideOrOn and not a compare
	// of extents.
	FNBSSystemResult Offset = Make(FVector(1000, 1000, 1000), FVector(200, 200, 200));
	Offset.MeasuredBounds = FBox(FVector(400, 400, 400), FVector(600, 600, 600));
	TestTrue(TEXT("a small union pushed outside the stored box is under-bounded"),
		Offset.WasUnderBounded());

	// --- a system that never had fixed bounds is not "under-bounded", it is unbounded -----------
	FNBSSystemResult Dynamic = Make(FVector(100, 100, 100), FVector(900, 900, 900));
	Dynamic.bOldFixedBounds = false;
	TestFalse(TEXT("a dynamic-bounds system is not counted as under-bounded"),
		Dynamic.WasUnderBounded());

	return true;
}

#endif // WITH_DEV_AUTOMATION_TESTS
