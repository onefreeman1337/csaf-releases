// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "NBSReport.h"

#include "Misc/DateTime.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "NBSUnion.h"

namespace
{
	/** Plate geometry for the two orthographic projections. */
	constexpr double PlateW = 300.0;
	constexpr double PlateH = 150.0;
	constexpr double PlatePad = 14.0;

	FString Esc(const FString& In)
	{
		FString Out = In;
		Out.ReplaceInline(TEXT("&"), TEXT("&amp;"));
		Out.ReplaceInline(TEXT("<"), TEXT("&lt;"));
		Out.ReplaceInline(TEXT(">"), TEXT("&gt;"));
		return Out;
	}

	FString Vec(const FVector& V)
	{
		return FString::Printf(TEXT("%.0f, %.0f, %.0f"), V.X, V.Y, V.Z);
	}

	FString BoxSize(const FBox& Box)
	{
		if (!Box.IsValid)
		{
			return TEXT("&mdash;");
		}
		return Esc(Vec(Box.GetSize()));
	}

	/**
	 * One orthographic projection, drawn TO SCALE against a shared world extent.
	 *
	 * ⚠️ Both boxes are projected through the SAME scale, deliberately. Fitting each box to its own
	 * plate would draw a tiny wrong box and a correct box at identical on-screen size, which would
	 * make the single number the report exists to communicate - how badly the old bound
	 * under-covered the effect - literally invisible.
	 */
	FString Projection(const FBox& Old, const FBox& New, int32 AxisH, int32 AxisV, const TCHAR* Caption, double OffsetX)
	{
		FBox Frame = New;
		if (Old.IsValid)
		{
			Frame += Old;
		}
		if (!Frame.IsValid)
		{
			return FString();
		}

		const FVector FrameSize = Frame.GetSize();
		const double SpanH = FMath::Max(FrameSize[AxisH], 1.0);
		const double SpanV = FMath::Max(FrameSize[AxisV], 1.0);
		const double Scale = FMath::Min((PlateW - 2 * PlatePad) / SpanH, (PlateH - 2 * PlatePad) / SpanV);

		auto Rect = [&](const FBox& Box, const TCHAR* Class) -> FString
		{
			if (!Box.IsValid)
			{
				return FString();
			}
			const double X = OffsetX + PlatePad + (Box.Min[AxisH] - Frame.Min[AxisH]) * Scale;
			// SVG y grows downward while world Z grows upward, so the vertical axis is flipped here
			// rather than in the caller - a box drawn upside down would still look plausible.
			const double Y = PlatePad + (Frame.Max[AxisV] - Box.Max[AxisV]) * Scale;
			const double W = FMath::Max(1.0, Box.GetSize()[AxisH] * Scale);
			const double H = FMath::Max(1.0, Box.GetSize()[AxisV] * Scale);
			return FString::Printf(
				TEXT("<rect class=\"%s\" x=\"%.1f\" y=\"%.1f\" width=\"%.1f\" height=\"%.1f\" rx=\"2\"/>"),
				Class, X, Y, W, H);
		};

		return FString::Printf(
			TEXT("<rect class=\"plate\" x=\"%.1f\" y=\"0\" width=\"%.1f\" height=\"%.1f\" rx=\"6\"/>%s%s")
			TEXT("<text class=\"cap\" x=\"%.1f\" y=\"%.1f\">%s</text>"),
			OffsetX, PlateW, PlateH,
			*Rect(Old, TEXT("old")), *Rect(New, TEXT("new")),
			OffsetX + 8.0, PlateH - 6.0, Caption);
	}
}

FString NBSReport::BuildBoxSvg(const FBox& Old, const FBox& Measured)
{
	if (!Measured.IsValid)
	{
		return FString();
	}

	// Axis indices: 0=X, 1=Y, 2=Z. Top-down is X across / Y up; front is X across / Z up.
	const FString Top = Projection(Old, Measured, 0, 1, TEXT("top  (X/Y)"), 0.0);
	const FString Front = Projection(Old, Measured, 0, 2, TEXT("front  (X/Z)"), PlateW + 12.0);

	return FString::Printf(
		TEXT("<svg class=\"proj\" viewBox=\"0 0 %.0f %.0f\" width=\"100%%\" role=\"img\">%s%s</svg>"),
		PlateW * 2 + 12.0, PlateH, *Top, *Front);
}

bool NBSReport::Write(
	const FString& Path,
	const FNBSRunOptions& Options,
	const FNBSRunSummary& Summary,
	const TArray<FNBSSystemResult>& Results,
	FString& OutError)
{
	OutError.Reset();

	FString H;
	H.Reserve(64 * 1024);

	H += TEXT("<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\">");
	H += TEXT("<title>Niagara Bounds Solver</title><style>");
	H += TEXT(":root{--ink:#12161c;--dim:#6b7480;--line:#e2e6ec;--old:#d1444a;--new:#2f8f5b;--warn:#b8791f;}");
	H += TEXT("*{box-sizing:border-box}body{margin:0;background:#f6f7f9;color:var(--ink);");
	H += TEXT("font:14px/1.55 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif}");
	H += TEXT(".wrap{max-width:1080px;margin:0 auto;padding:40px 28px 72px}");
	H += TEXT("h1{font-size:23px;letter-spacing:-.015em;margin:0 0 2px}");
	H += TEXT(".sub{color:var(--dim);font-size:13px;margin-bottom:26px}");
	H += TEXT(".tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(132px,1fr));gap:10px;margin-bottom:30px}");
	H += TEXT(".tile{background:#fff;border:1px solid var(--line);border-radius:9px;padding:12px 14px}");
	H += TEXT(".tile .n{font-size:21px;font-variant-numeric:tabular-nums;font-weight:600}");
	H += TEXT(".tile .l{color:var(--dim);font-size:11px;text-transform:uppercase;letter-spacing:.06em;margin-top:2px}");
	H += TEXT(".sys{background:#fff;border:1px solid var(--line);border-radius:10px;padding:16px 18px;margin-bottom:12px}");
	H += TEXT(".sys h2{font-size:15px;margin:0 0 3px;font-weight:600}");
	H += TEXT(".sys .path{color:var(--dim);font-size:12px;font-family:ui-monospace,Consolas,monospace;margin-bottom:12px;word-break:break-all}");
	H += TEXT(".cols{display:grid;grid-template-columns:1fr 320px;gap:20px;align-items:start}");
	H += TEXT("@media(max-width:760px){.cols{grid-template-columns:1fr}}");
	H += TEXT("table{width:100%;border-collapse:collapse;font-size:13px}");
	H += TEXT("th,td{text-align:left;padding:5px 10px 5px 0;border-bottom:1px solid var(--line);vertical-align:top}");
	H += TEXT("th{color:var(--dim);font-weight:500;width:150px}");
	H += TEXT("td{font-variant-numeric:tabular-nums}");
	H += TEXT(".grow{font-weight:600;color:var(--old)}.ok{color:var(--new);font-weight:600}");
	H += TEXT(".skip{border-left:3px solid var(--warn);padding-left:12px;color:#5a4a2a;background:#fdf8ee;");
	H += TEXT("border-radius:0 6px 6px 0;padding:10px 12px;font-size:13px}");
	H += TEXT(".proj{display:block}.plate{fill:#fafbfc;stroke:var(--line)}");
	H += TEXT(".old{fill:none;stroke:var(--old);stroke-width:1.6;stroke-dasharray:4 3}");
	H += TEXT(".new{fill:rgba(47,143,91,.13);stroke:var(--new);stroke-width:1.6}");
	H += TEXT(".cap{fill:var(--dim);font-size:10px;font-family:ui-monospace,Consolas,monospace}");
	H += TEXT(".key{color:var(--dim);font-size:11px;margin-top:6px}");
	H += TEXT(".key b{color:var(--old);font-weight:600}.key i{color:var(--new);font-style:normal;font-weight:600}");
	/*
	 * ⛔ THE LEGEND SWATCHES ARE DRAWN, NOT TYPED. Measured 2026-08-31.
	 *
	 * They used to be the characters &#9647; (U+25AF WHITE VERTICAL RECTANGLE) and &#9646;
	 * (U+25AE BLACK VERTICAL RECTANGLE). The black one has a glyph in this font stack and the
	 * white one DOES NOT, so every generated sheet rendered a TOFU BOX next to the word "dashed".
	 * Nothing mechanical caught it - it was found by opening a store plate and looking at it.
	 *
	 * A swatch that depends on the reader's font coverage renders differently on someone else's
	 * machine. These spans ARE the thing they describe: a dashed outline in the old-bounds colour
	 * and a filled block in the measured colour. No glyph, so there is nothing to be missing.
	 */
	H += TEXT(".sw{display:inline-block;width:10px;height:10px;vertical-align:-1px;margin-right:4px;border-radius:2px}");
	H += TEXT(".sw-old{border:1.5px dashed var(--old)}");
	H += TEXT(".sw-new{background:rgba(47,143,91,.18);border:1.5px solid var(--new)}");
	H += TEXT("footer{color:var(--dim);font-size:12px;margin-top:34px;border-top:1px solid var(--line);padding-top:14px}");
	H += TEXT("</style></head><body><div class=\"wrap\">");

	H += TEXT("<h1>Niagara Bounds Solver</h1><div class=\"sub\">");
	H += Summary.bApplied
		? TEXT("Applied &mdash; measured bounds written to the assets below. ")
		: TEXT("Preview &mdash; nothing was written. Pass <code>-Apply</code> to write. ");
	H += FString::Printf(TEXT("Scanned <code>%s</code> at %s, stepping %.4fs up to %.1fs per system, pad %.0f%%.</div>"),
		*Esc(Options.ScanPath), *FDateTime::Now().ToString(TEXT("%Y-%m-%d %H:%M")),
		Options.TickDelta, Options.MaxSeconds, Options.Pad * 100.0f);

	auto Tile = [&H](const TCHAR* Label, const FString& Value)
	{
		H += FString::Printf(TEXT("<div class=\"tile\"><div class=\"n\">%s</div><div class=\"l\">%s</div></div>"),
			*Value, Label);
	};

	H += TEXT("<div class=\"tiles\">");
	Tile(TEXT("systems found"), FString::FromInt(Summary.SystemsFound));
	/*
	 * ⛔ THIS TILE SAID "simulated" UNTIL 2026-09-04 AND THE FIELD IS SystemsLoaded. NBSRun.cpp:108
	 * increments it as soon as the asset casts, BEFORE MeasureSystem runs, so a system that loaded
	 * and was then skipped counted as simulated. MEASURED on the fixture: the sheet read
	 * "18 SIMULATED" beside "8 SKIPPED" over 18 found, while two of the skipped rows printed
	 * "ticks simulated 0" three inches below. The headline overstated the work by 80% in a product
	 * whose whole promise is that it never invents a number.
	 * The count is honest and useful - it is LOADED - so the label is what was wrong.
	 */
	Tile(TEXT("loaded"), FString::FromInt(Summary.SystemsLoaded));
	Tile(TEXT("solved"), FString::FromInt(Summary.SystemsSolved));
	Tile(TEXT("under-bounded"), FString::FromInt(Summary.SystemsUnderBounded));
	Tile(TEXT("skipped"), FString::FromInt(Summary.SystemsSkipped));
	Tile(TEXT("ticks simulated"), FString::FromInt(Summary.TotalTicksSimulated));
	H += TEXT("</div>");

	for (const FNBSSystemResult& R : Results)
	{
		H += TEXT("<div class=\"sys\">");
		H += FString::Printf(TEXT("<h2>%s</h2><div class=\"path\">%s</div>"), *Esc(R.AssetName), *Esc(R.AssetPath));
		H += TEXT("<div class=\"cols\"><div>");

		H += TEXT("<table>");
		H += FString::Printf(TEXT("<tr><th>bounds before</th><td>%s%s</td></tr>"),
			R.bOldFixedBounds ? TEXT("fixed &mdash; ") : TEXT("dynamic &mdash; "),
			*BoxSize(R.OldBounds));
		H += FString::Printf(TEXT("<tr><th>measured union</th><td>%s</td></tr>"), *BoxSize(R.MeasuredBounds));

		if (R.WrittenBounds.IsValid)
		{
			H += FString::Printf(TEXT("<tr><th>written (padded)</th><td>%s</td></tr>"), *BoxSize(R.WrittenBounds));
		}

		/*
		 * ⛔ THE VERDICT COMES FROM WasUnderBounded(), NEVER FROM GrowthFactor. Until 2026-09-04
		 * this line read `R.GrowthFactor > 1.05`, which is a volume ratio and so cannot see an
		 * effect escaping along one axis while the others shrink - it printed NS_Ability_Nova green
		 * at 0.77x while the union overshot the stored box on Z by 115 units.
		 *
		 * It was also a SECOND threshold for the same question: the summary tile counted
		 * WasUnderBounded() (then > 1.0) while this row used > 1.05, so the headline and the detail
		 * could disagree about the same system. One predicate now answers it in both places.
		 *
		 * GrowthFactor is still SHOWN, because "this box is 8x bigger than what shipped" is the
		 * number a reader wants - it is just not the verdict.
		 */
		if (R.GrowthFactor > 0.0)
		{
			/*
			 * Two different findings, and they were one message until 2026-09-04:
			 *
			 *   FIXED bounds + the union escapes  -> the asset carried a box that was culling the
			 *     effect. This is the product's headline finding.
			 *   DYNAMIC bounds                    -> there was no stored box to escape. The old box
			 *     is the engine's fallback, so a large factor is expected and is still worth
			 *     flagging, but "the stored box did not contain the effect" is not what happened.
			 *
			 * ⚠️ Keeping the dynamic case RED is deliberate. Routing the row through
			 * WasUnderBounded() alone would have turned every dynamic-bounds row green, which is a
			 * LOST SIGNAL dressed up as a bug fix - the reason those rows are interesting has not
			 * changed, only the sentence that is true about them.
			 */
			const bool bUnderBounded = R.WasUnderBounded();
			const bool bAgainstFallback = !R.bOldFixedBounds && R.GrowthFactor > 1.0;
			const TCHAR* Note =
				bUnderBounded ? TEXT(" &mdash; the stored box did not contain the effect")
				: bAgainstFallback ? TEXT(" &mdash; measured against the engine's fallback box; this system was on dynamic bounds")
				: TEXT("");
			H += FString::Printf(
				TEXT("<tr><th>volume change</th><td class=\"%s\">%.2f&times;%s</td></tr>"),
				(bUnderBounded || bAgainstFallback) ? TEXT("grow") : TEXT("ok"), R.GrowthFactor, Note);
		}

		H += FString::Printf(
			TEXT("<tr><th>ticks simulated</th><td>%d over %.2fs</td></tr>")
			TEXT("<tr><th>ticks with particles</th><td>%d</td></tr>"),
			R.TicksSimulated, R.SimulatedSeconds, R.TicksWithParticles);
		H += FString::Printf(TEXT("<tr><th>emitters</th><td>%d</td></tr>"), R.Emitters.Num());
		H += TEXT("</table>");

		if (R.Skip != ENBSSkip::None)
		{
			H += FString::Printf(TEXT("<p class=\"skip\"><strong>Skipped (%s).</strong> %s</p>"),
				LexToString(R.Skip), *Esc(NBSSkipReasonText(R.Skip)));
		}

		H += TEXT("</div><div>");
		const FString Svg = BuildBoxSvg(R.OldBounds, R.MeasuredBounds);
		if (!Svg.IsEmpty())
		{
			H += Svg;
			H += TEXT("<div class=\"key\">Drawn to a shared scale. <b><span class=\"sw sw-old\"></span>dashed</b> = bounds the asset carried, ");
			H += TEXT("<i><span class=\"sw sw-new\"></span>filled</i> = union measured across the lifetime.</div>");
		}
		H += TEXT("</div></div></div>");
	}

	if (Summary.Problems.Num() > 0)
	{
		H += TEXT("<div class=\"sys\"><h2>Problems</h2><ul>");
		for (const FString& Problem : Summary.Problems)
		{
			H += FString::Printf(TEXT("<li>%s</li>"), *Esc(Problem));
		}
		H += TEXT("</ul></div>");
	}

	H += TEXT("<footer>Niagara Bounds Solver &middot; CSAF &mdash; Core Systems Asset Factory. ");
	H += TEXT("Bounds are measured by simulating each system one tick at a time and taking the union of ");
	H += TEXT("its local bounds over every tick in which a particle was alive. A system that could not be ");
	H += TEXT("honestly simulated is reported above and left untouched.</footer>");
	H += TEXT("</div></body></html>");

	if (!FFileHelper::SaveStringToFile(H, *Path))
	{
		OutError = FString::Printf(TEXT("The report could not be written to '%s'."), *Path);
		return false;
	}

	return true;
}
