// Copyright (c) 2026 Core Systems Asset Factory. All Rights Reserved.

#include "NiagaraBoundsSolverModule.h"

#include "HAL/IConsoleManager.h"
#include "HAL/PlatformMisc.h"
#include "Misc/Parse.h"
#include "Modules/ModuleManager.h"
#include "NBSArgs.h"
#include "NBSRun.h"

DEFINE_LOG_CATEGORY(LogNiagaraBoundsSolver);

#define LOCTEXT_NAMESPACE "FNiagaraBoundsSolverModule"

namespace
{
	IConsoleCommand* RunCommand = nullptr;

	/**
	 * The in-editor entry point.
	 *
	 * ⭐ FOR THIS PRODUCT THE EDITOR PATH IS NOT A CONVENIENCE, IT IS THE ONLY WAY TO MEASURE A GPU
	 * SYSTEM. Reading GPU particle counts back needs a live compute dispatch interface
	 * (NiagaraEmitterInstanceImpl.cpp:890-901), and a commandlet started with -nullrhi has none, so
	 * every GPU system is honestly reported as skipped there rather than silently measured as
	 * empty. An editor session started headless on a build agent still has an RHI:
	 *
	 *   UnrealEditor-Cmd.exe Project.uproject -unattended -nosplash
	 *     -ExecCmds="NiagaraBounds.Solve -Apply -ExitOnFinish"
	 *
	 * ⛔ `-ExitOnFinish`, NEVER a trailing `,Quit`. `Quit` is not an editor console command - the
	 * editor's is QUIT_EDITOR - so an editor started with `,Quit` does the work, writes the report,
	 * and then sits there forever holding the plugin binary. On a build agent that is a wedged job.
	 */
	void HandleSolveCommand(const TArray<FString>& Args)
	{
		const FString Params = FString::Join(Args, TEXT(" "));

		if (FParse::Param(*Params, TEXT("Help")) || FParse::Param(*Params, TEXT("?")))
		{
			UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("\n%s"), *NBSArgs::Usage());
			/*
			 * ⛔ THIS BRANCH RETURNED WITHOUT HONOURING -ExitOnFinish UNTIL 2026-09-04, AND THAT IS
			 * THE WEDGED BUILD AGENT THIS PLUGIN'S OWN DOCUMENTATION WARNS ABOUT.
			 * MEASURED: `-ExecCmds="NiagaraBounds.Solve -Help -ExitOnFinish"` never exited - the
			 * editor was still running eleven minutes later holding the plugin binary, while every
			 * other case in the same suite finished in 44-133 seconds. The comment 30 lines above
			 * describes exactly this outcome for a trailing `,Quit` and it was reachable through
			 * our own -Help all along, because the early return skips the exit handling at the
			 * bottom of the function.
			 * ⇒ Every branch that can END this command must honour -ExitOnFinish, not just the ones
			 * that do work. -Help is a successful run, so it exits Ok.
			 */
			if (FParse::Param(*Params, TEXT("ExitOnFinish")))
			{
				FPlatformMisc::RequestExitWithStatus(false, static_cast<uint8>(ENBSExit::Ok));
			}
			return;
		}

		FNBSRunOptions Options;
		FString ParseError;
		if (!NBSArgs::Parse(Params, Options, ParseError))
		{
			UE_LOG(LogNiagaraBoundsSolver, Error, TEXT("%s"), *ParseError);
			UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("\n%s"), *NBSArgs::Usage());
			if (FParse::Param(*Params, TEXT("ExitOnFinish")))
			{
				FPlatformMisc::RequestExitWithStatus(false, static_cast<uint8>(ENBSExit::BadArguments));
			}
			return;
		}

		FNBSRunSummary Summary;
		const int32 Code = NBSRun::Execute(Options, Summary);

		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("---- Niagara Bounds Solver ----"));
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  mode                 : %s"),
			Summary.bApplied ? TEXT("APPLY (assets written)") : TEXT("preview (nothing written)"));
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  systems found        : %d"), Summary.SystemsFound);
		// "loaded", not "simulated": SystemsLoaded counts a successful asset cast (NBSRun.cpp:108),
		// which happens BEFORE measurement, so skipped systems are included. See NBSReport.cpp.
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  systems loaded       : %d"), Summary.SystemsLoaded);
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  systems solved       : %d"), Summary.SystemsSolved);
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  were under-bounded   : %d"), Summary.SystemsUnderBounded);
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  systems skipped      : %d"), Summary.SystemsSkipped);
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  emitters pinned      : %d"), Summary.EmittersWritten);
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  ticks simulated      : %d"), Summary.TotalTicksSimulated);
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  assets saved         : %d"), Summary.PackagesSaved);
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  assets not written   : %d"), Summary.PackagesFailed);
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  seconds              : %.1f"), Summary.Seconds);
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  report               : %s"), *Options.ReportPath);
		for (const FString& Problem : Summary.Problems)
		{
			UE_LOG(LogNiagaraBoundsSolver, Warning, TEXT("  ! %s"), *Problem);
		}
		UE_LOG(LogNiagaraBoundsSolver, Display, TEXT("  exit code            : %d"), Code);

		if (FParse::Param(*Params, TEXT("ExitOnFinish")))
		{
			FPlatformMisc::RequestExitWithStatus(false, static_cast<uint8>(Code));
		}
	}
}

void FNiagaraBoundsSolverModule::StartupModule()
{
	RunCommand = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("NiagaraBounds.Solve"),
		TEXT("Measure and fix Niagara fixed bounds across the project. Add -Help for the switch list."),
		FConsoleCommandWithArgsDelegate::CreateStatic(&HandleSolveCommand),
		ECVF_Default);
}

void FNiagaraBoundsSolverModule::ShutdownModule()
{
	if (RunCommand != nullptr)
	{
		IConsoleManager::Get().UnregisterConsoleObject(RunCommand);
		RunCommand = nullptr;
	}
}

#undef LOCTEXT_NAMESPACE

// ⛔ The module name argument MUST equal the plugin folder name, the .uplugin filename and
// Modules[0].Name in the descriptor. Fab rejects on that disagreement, and a module with no
// IMPLEMENT_MODULE gates perfectly and then cannot load at all - measured in this wing, where the
// editor answered "module could not be initialized successfully" and then threw an access violation
// inside CoreUObject. The error never names the macro.
IMPLEMENT_MODULE(FNiagaraBoundsSolverModule, NiagaraBoundsSolver)
