/// CHITIN - cht_elytra. THE HARD FOREWINGS, AND EVERYTHING CARVED INTO THEM.
///
/// An elytron is a forewing that has become a shell. It is the single largest surface on a beetle,
/// it carries the animal's colour and almost all of its sculpture, and it is what a player is
/// actually looking at when they decide whether they have caught the beetle they wanted.
///
/// ⛔ THE ELYTRA ARE NOT A SHAPE PLACED ON THE BODY. Their outer margin IS the body outline over
/// the abdominal region, taken from the same half-width function, so a species that widens its
/// elytral mass widens its elytra by construction and the two can never disagree. What they add is
/// the SUTURE down the middle, the scutellum at the top of it, and the sculpture.
///
/// -- WHY THE SCULPTURE IS THE PRODUCT -------------------------------------------------------
/// A stria is a groove running the length of an elytron; a puncture is a pit; a costa is a raised
/// rib. Real beetles are told apart by how many of each and where. Those are NUMBERS, so this is
/// the part of the animal that a generator can do and a sprite sheet cannot: change the stria
/// count from 9 to 5 and the beetle is a different family, and the drawing follows because the
/// drawing is computed from the same number the identification screen reads.
///
/// ⚠️ AND THE RESOLUTION FLOOR IS ARITHMETIC, NOT AN OPINION. GML floors every stroke at 1.0 px
/// (no antialiasing; a sub-pixel quad rasterises to dashes), so ten striae across an elytron 30 px
/// wide is ten strokes into three pixels of usable space - a barcode, which is what this wing has
/// shipped before by ramping tone with line width. cht_elytra_stria_fit below decides how many
/// striae ACTUALLY get drawn at the size being drawn at, and it is why the cabinet plate and the
/// hero image can share one corpus.
/// ============================================================================================

/// Sculpture programs. The number is a species property; the program is a family property.
///
/// ⛔ INDEX-PARALLEL WITH cht_sculpture_names(), AND THE FIRST DRAFT OF THIS FILE WAS NOT. It had
/// striate at 1 and punctate at 2 while the shipped name table has them the other way round, so
/// every weevil in the corpus would have been drawn grooved and labelled punctate - a defect no
/// gate, no ink floor and no assertion about drawing could ever see, because both pictures are
/// correct pictures. cht_selftest asserts the pairing by name.
#macro CHT_SCULPT_SMOOTH      0   // no sculpture at all - a ladybird, a leaf beetle
#macro CHT_SCULPT_PUNCTATE    1   // rows of pits rather than continuous grooves - a weevil
#macro CHT_SCULPT_STRIATE     2   // grooves the length of the elytron - a ground beetle
#macro CHT_SCULPT_COSTATE     3   // raised ribs standing proud - a longhorn, a click beetle
#macro CHT_SCULPT_RUGOSE      4   // irregular wrinkling - a stag beetle's flanks, a chafer
#macro CHT_SCULPT_GRANULATE   5   // a fine even sand of raised grains - a dor beetle, a dung beetle
#macro CHT_SCULPT_TUBERCULATE 6   // scattered large bumps - a tortoise beetle, a warty weevil
#macro CHT_SCULPT_N           7

/// The suture half-gap: how far each elytron's inner margin sits from the midline. A physical
/// dimension, so it is bounded at BOTH ends against the body it is drawn on rather than left as a
/// pure proportion - this wing has shipped a 112 px cove on an 840 px frame from exactly that
/// mistake, four times on one image.
#macro CHT_SUTURE_GAP 0.0055

/// ============================================================================================
/// THE ELYTRON OUTLINE
/// ============================================================================================

/// The inner (sutural) margin half-offset at axis position _t.
///
/// ⛔ IT MUST COLLAPSE WITH THE BODY. A constant gap crosses the outer margin near the apex, where
/// the body's own half-width has fallen below the gap - and a self-crossing outline fills the
/// wrong region and throws its inset points far outside, which is how a previous product in this
/// catalogue grew corner hooks on every panel it drew. Taking the minimum makes the crossing
/// impossible rather than unlikely.
function cht_elytra_inner(_sp, _t) {
    return min(CHT_SUTURE_GAP, cht_body_halfw(_sp, _t) * 0.42);
}

/// One elytron as a closed outline. _side is -1 (left) or +1 (right).
/// _t0 is where the elytral base sits on the axis; the apex is always the body's own tip.
function cht_elytron_outline(_sp, _side, _t0, _samples) {
    var _n = max(8, is_undefined(_samples) ? 56 : _samples);
    var _pts = [];
    // Outer margin, base -> apex. This IS the body silhouette.
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _t0 + (1 - _t0) * (_i / _n);
        _pts[array_length(_pts)] = [_side * cht_body_halfw(_sp, _t), cht_body_y(_sp, _t)];
    }
    // Inner margin, apex -> base.
    for (var _i = _n; _i >= 0; _i--) {
        var _t = _t0 + (1 - _t0) * (_i / _n);
        _pts[array_length(_pts)] = [_side * cht_elytra_inner(_sp, _t), cht_body_y(_sp, _t)];
    }
    return cht_dedupe_pts(_pts);
}

/// ============================================================================================
/// THE RESOLUTION FLOOR
/// ============================================================================================

/// How many striae to actually draw, given how wide the elytron will be ON SCREEN.
///
/// _px is the drawn width of ONE elytron in pixels. Below the point where consecutive grooves are
/// less than about 2.4 px apart they stop being grooves and become a texture, so the count is
/// halved until they are - and at the bottom the answer is honestly zero, which is what a beetle
/// 12 px across looks like.
///
/// ⭐ THE COUNT IS RETURNED, NOT SILENTLY APPLIED, so the identification screen can say "9 striae"
/// while the cabinet thumbnail draws 4 and neither is lying. A level-of-detail decision that is
/// hidden inside a draw call is a decision no caller can reason about.
function cht_elytra_stria_fit(_want, _px) {
    if (_want <= 0 || _px <= 0) return 0;
    var _n = _want;
    while (_n > 0 && (_px / (_n + 1)) < 2.4) _n = floor(_n * 0.5);
    return _n;
}

/// ============================================================================================
/// SCULPTURE
/// ============================================================================================

/// The striae of one elytron.
///
/// Each groove runs from the elytral base to near the apex at a CONSTANT FRACTION of the local
/// elytron width, which is what makes them converge at the apex exactly as they do on a real
/// beetle - and, more usefully, what guarantees every groove is inside the outline at every
/// height without a single clip test. The shape does the containment.
function cht_elytra_striae(_sp, _side, _t0, _n, _w) {
    var _out = [];
    if (_n <= 0) return _out;
    var _steps = 22;
    for (var _s = 0; _s < _n; _s++) {
        // Fractional station across the elytron, from the suture (0) to the outer margin (1).
        var _u = (_s + 1) / (_n + 1);
        var _pts = array_create(_steps + 1);
        for (var _i = 0; _i <= _steps; _i++) {
            // The groove starts a little below the base and stops short of the apex: a stria that
            // reaches the very tip crosses the suture, because both margins meet there.
            var _t = _t0 + 0.03 + (0.955 - _t0 - 0.03) * (_i / _steps);
            var _in = cht_elytra_inner(_sp, _t);
            var _ou = cht_body_halfw(_sp, _t);
            _pts[_i] = [_side * lerp(_in, _ou, _u), cht_body_y(_sp, _t)];
        }
        cht_append(_out, cht_incise(_pts, false, _w));
    }
    return _out;
}

/// Rows of punctures instead of continuous grooves.
///
/// ⚠️ A PUNCTURE IS A DRILLED PIT, WHICH IS A DIFFERENT PRIMITIVE FROM AN INCISED LINE. An outline
/// scratched inside a small mass is a scribble at any size below hero; cht_pit lays a lit wall and
/// a dark wall around a round hollow, which is what a puncture on a shell actually is.
function cht_elytra_punctures(_sp, _side, _t0, _rows, _per, _r) {
    var _out = [];
    if (_rows <= 0 || _per <= 0) return _out;
    for (var _s = 0; _s < _rows; _s++) {
        var _u = (_s + 1) / (_rows + 1);
        for (var _i = 0; _i < _per; _i++) {
            var _t = _t0 + 0.05 + (0.930 - _t0 - 0.05) * (_i / max(1, _per - 1));
            var _in = cht_elytra_inner(_sp, _t);
            var _ou = cht_body_halfw(_sp, _t);
            var _x = _side * lerp(_in, _ou, _u);
            // The pit must fit at every height it occupies, not only at its centre.
            var _room = cht_body_span_min(_sp, _t - 0.02, _t + 0.02) * 0.30;
            cht_append(_out, cht_pit(_x, cht_body_y(_sp, _t), min(_r, _room), 8));
        }
    }
    return _out;
}

/// Raised ribs. The opposite relief sign from a stria, and the reason a longhorn beetle looks
/// ribbed rather than grooved.
function cht_elytra_costae(_sp, _side, _t0, _n, _w) {
    var _out = [];
    if (_n <= 0) return _out;
    var _steps = 20;
    for (var _s = 0; _s < _n; _s++) {
        var _u = (_s + 1) / (_n + 1);
        var _pts = array_create(_steps + 1);
        for (var _i = 0; _i <= _steps; _i++) {
            var _t = _t0 + 0.05 + (0.930 - _t0 - 0.05) * (_i / _steps);
            var _in = cht_elytra_inner(_sp, _t);
            var _ou = cht_body_halfw(_sp, _t);
            _pts[_i] = [_side * lerp(_in, _ou, _u), cht_body_y(_sp, _t)];
        }
        cht_append(_out, cht_ridge(_pts, false, _w));
    }
    return _out;
}

/// Raised grains and tubercles: the two sculptures that are neither lines nor rows.
///
/// _big switches between a fine even sand (granulate) and scattered large bumps (tuberculate).
/// They share one builder because they are one program with two size regimes, and splitting them
/// would give the corpus two places to drift.
///
/// ⚠️ THE GRAINS ARE PLACED IN THE ELYTRON'S OWN FRACTIONAL COORDINATES, so every one of them is
/// inside the outline at every height by construction rather than by a clip test - the same reason
/// the striae above need no clipping. A grain placed in x and then clamped would ride up onto the
/// suture wherever the elytron narrows.
function cht_elytra_grains(_sp, _side, _t0, _count, _cut, _r, _big) {
    var _out = [];
    var _n = max(0, _count);
    if (_n <= 0) return _out;
    var _rng = cht_rng(3307 + round(_cut.grain * 613) + _n * 47 + (_big ? 91 : 0));
    var _total = _big ? (_n * 4) : (_n * 26);
    for (var _k = 0; _k < _total; _k++) {
        var _u = 0.10 + 0.82 * cht_rng_next(_rng);
        var _t = _t0 + 0.05 + (0.935 - _t0 - 0.05) * cht_rng_next(_rng);
        var _in = cht_elytra_inner(_sp, _t);
        var _ou = cht_body_halfw(_sp, _t);
        var _x = _side * lerp(_in, _ou, _u);
        // A grain occupies a range of heights, so it must fit at ALL of them - not merely at its
        // own centre. This wing measured a speckle poking out of a crystal's shoulder for exactly
        // that reason.
        var _room = cht_body_span_min(_sp, _t - _r, _t + _r) * 0.34;
        var _rr = min(_r * (0.72 + 0.56 * cht_rng_next(_rng)), _room);
        if (_rr <= 0) continue;
        cht_append(_out, cht_boss(_x, cht_body_y(_sp, _t), _rr, _big ? 10 : 6));
    }
    return _out;
}

/// ============================================================================================
/// THE SCUTELLUM
/// ============================================================================================

/// The small triangular plate between the elytral bases. Tiny, and one of the loudest cues that a
/// drawing was made by somebody who has looked at a beetle: without it the two elytra meet the
/// pronotum in a straight line and the animal reads as a shell glued to a shield.
function cht_scutellum(_sp, _t0, _k) {
    var _w = cht_body_halfw(_sp, _t0) * clamp(_k, 0.05, 0.60);
    var _y = cht_body_y(_sp, _t0);
    var _h = _w * 1.35;
    var _pts = [[-_w, _y - _h * 0.20], [_w, _y - _h * 0.20], [0, _y + _h * 0.80]];
    var _out = [];
    array_push(_out, cht_ring_fill(_pts, "m2", 0, _y + _h * 0.10));
    cht_append(_out, cht_bevel(_pts, cht_bevel_cap(_pts, _w * 0.34), 2, false));
    return _out;
}

/// ============================================================================================
/// THE WHOLE ELYTRAL ASSEMBLY
/// ============================================================================================

/// Both elytra, their sculpture, the suture and the scutellum.
///
/// _cut is the cuticle spec (for grain), _sculpt one of CHT_SCULPT_*, _count the family's stria or
/// costa or puncture-row count, and _px the drawn width of the whole animal in pixels - which is
/// what the level-of-detail decision is made against.
function cht_elytra_parts(_sp, _t0, _sculpt, _count, _cut, _px) {
    var _out = [];

    // ⛔ THE ELYTRA DO NOT FILL THEMSELVES, AND THAT IS THE WHOLE ARCHITECTURE OF THE SHELL.
    //
    // The obvious build - two closed shapes, each filled and domed - is anatomically wrong in a way
    // that is invisible until you look at where the light lands. A beetle's two elytra together
    // form ONE dome across its back. Shading them as two independent shells puts a lit edge along
    // the inner margin of the shaded-side elytron, i.e. a highlight on a surface that faces away
    // from the lamp, and the animal reads as two separate objects lying side by side.
    //
    // So cht_body_parts has already shaded the entire back as one tube. What an elytron adds is its
    // EDGES: the raised rim where the shell turns down at the flank, and the raised sutural margin
    // where the two meet. Those are real features and they are what make the pair read as a pair.
    for (var _s = -1; _s <= 1; _s += 2) {
        var _rel = cht_elytron_outline(_sp, _s, _t0, 16);
        cht_append(_out, cht_bevel(_rel, cht_bevel_cap(_rel, 0.020), 2, false));
    }

    // The sculpture. One elytron's worth of drawn width is what the floor is measured against.
    var _ew = _px * 0.5 * 0.86;
    for (var _s = -1; _s <= 1; _s += 2) {
        switch (clamp(_sculpt, 0, CHT_SCULPT_N - 1)) {
            case CHT_SCULPT_STRIATE:
                cht_append(_out, cht_elytra_striae(_sp, _s, _t0,
                    cht_elytra_stria_fit(_count, _ew), 0.0045));
                break;
            case CHT_SCULPT_PUNCTATE:
                cht_append(_out, cht_elytra_punctures(_sp, _s, _t0,
                    cht_elytra_stria_fit(_count, _ew), 9, 0.0105));
                break;
            case CHT_SCULPT_COSTATE:
                cht_append(_out, cht_elytra_costae(_sp, _s, _t0,
                    cht_elytra_stria_fit(_count, _ew), 0.0085));
                break;
            case CHT_SCULPT_RUGOSE:
                // Irregular wrinkling: short costae at scattered stations rather than full-length
                // ribs. Seeded off the cuticle's grain so the same species wrinkles the same way
                // every time it is drawn - nothing in this package is random at draw time.
                var _rng = cht_rng(1471 + round(_cut.grain * 997) + _count * 31);
                var _m = cht_elytra_stria_fit(_count, _ew);
                for (var _k = 0; _k < _m * 3; _k++) {
                    var _u = 0.14 + 0.72 * cht_rng_next(_rng);
                    var _ta = _t0 + 0.06 + (0.86 - _t0) * cht_rng_next(_rng);
                    var _tb = min(0.94, _ta + 0.05 + 0.09 * cht_rng_next(_rng));
                    var _pts = array_create(7);
                    for (var _i = 0; _i < 7; _i++) {
                        var _t = lerp(_ta, _tb, _i / 6);
                        var _in = cht_elytra_inner(_sp, _t);
                        var _ou = cht_body_halfw(_sp, _t);
                        var _uu = _u + 0.05 * sin(_i * 1.1);
                        _pts[_i] = [_s * lerp(_in, _ou, clamp(_uu, 0.04, 0.96)), cht_body_y(_sp, _t)];
                    }
                    cht_append(_out, cht_ridge(_pts, false, 0.0060));
                }
                break;
            case CHT_SCULPT_GRANULATE:
                cht_append(_out, cht_elytra_grains(_sp, _s, _t0, _count, _cut, 0.0075, false));
                break;
            case CHT_SCULPT_TUBERCULATE:
                cht_append(_out, cht_elytra_grains(_sp, _s, _t0, _count, _cut, 0.0230, true));
                break;
            default: break;   // CHT_SCULPT_SMOOTH draws nothing, which is the point of it
        }
    }

    // The suture itself: one incised line down the midline, from the scutellum to the apex.
    var _sut = [];
    for (var _i = 0; _i <= 16; _i++) {
        var _t = _t0 + 0.02 + (0.985 - _t0 - 0.02) * (_i / 16);
        _sut[array_length(_sut)] = [0, cht_body_y(_sp, _t)];
    }
    cht_append(_out, cht_incise(_sut, false, 0.0075));

    cht_append(_out, cht_scutellum(_sp, _t0, 0.26));
    return _out;
}
