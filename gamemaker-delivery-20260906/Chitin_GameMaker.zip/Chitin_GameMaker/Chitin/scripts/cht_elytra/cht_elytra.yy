{
  "$GMScript": "v1",
  "%Name": "cht_elytra",
  "name": "cht_elytra",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}