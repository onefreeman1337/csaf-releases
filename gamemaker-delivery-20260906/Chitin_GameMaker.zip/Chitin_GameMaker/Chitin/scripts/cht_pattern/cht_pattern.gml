/// CHITIN - cht_pattern. THE MARKINGS, WRITTEN INTO THE ANIMAL'S OWN COORDINATE SPACE.
///
/// ⛔ A PATTERN IS NOT A TEXTURE LAID OVER A SILHOUETTE. That is the whole content of this file.
///
/// The cheap implementation draws marks in x and y and clips them to a bounding box, and it fails
/// in a way that is invisible on the one species it is tuned on: a band drawn as a horizontal
/// rectangle across a tapering abdomen sticks out at the waist and stops short at the shoulder,
/// because a shape is only as wide as its bounding box AT ONE HEIGHT. This wing has paid for that
/// law three times - a boulder with whiskers, a speck on a crystal's shoulder, a mark placed by
/// its centre height on a body that narrows above it.
///
/// So every mark here is placed in TWO body coordinates:
///
///   t  along the animal, 0 at the head apex and 1 at the abdomen tip
///   u  ACROSS it, -1 at the left margin and +1 at the right, at that t
///
/// and (t,u) is converted to a point by asking cht_body_halfw where the margin actually is. A band
/// is then a strip of constant t-width, and it follows the taper because the taper is what defines
/// its ends. Nothing in this file clips anything, because nothing in it can leave the animal.
///
/// ⚠️ AND A MARK OCCUPIES A RANGE OF t, SO IT MUST FIT AT ALL OF THEM. A spot placed by its centre
/// and sized by the half-width there pokes out of the shoulder wherever the body narrows above it.
/// Every spot below is sized against cht_body_span_min over the range it actually covers.
///
/// -- WHAT COLOUR A MARK IS ------------------------------------------------------------------
/// "ink", always, and never a ramp stop. This corpus holds a chalk-white marbled white and a
/// pitch-black burying beetle and puts bands on both; a mark set in the cuticle's darkest stop is
/// merely LESS PALE on the white one and invisible. cht_chroma_ink is defined relative to its own
/// ground with an asserted separation, which is what makes one pattern program serve both.
/// ============================================================================================

#macro CHT_PAT_PLAIN      0   // nothing at all - a stag beetle, a brimstone
#macro CHT_PAT_BANDED     1   // transverse bands across the animal - a wasp beetle, a cinnabar
#macro CHT_PAT_SPOTTED    2   // discrete round spots - a ladybird, a tiger beetle
#macro CHT_PAT_STRIPED    3   // longitudinal stripes down it - a colorado beetle, a caterpillar
#macro CHT_PAT_MARBLED    4   // irregular mottling - a poplar hawk moth, a painted lady
#macro CHT_PAT_EYESPOT    5   // ringed ocelli - a peacock butterfly, an emperor moth
#macro CHT_PAT_RETICULATE 6   // a net of veins and cells - a marbled white, a swallowtail
#macro CHT_PAT_METALLIC   7   // no mark at all; the SHEEN is the pattern - a jewel beetle
#macro CHT_PAT_N          8

/// The region a pattern is allowed to occupy: from the front of the thorax to just short of the
/// abdomen tip. The head is left plain on purpose - markings on a real insect's head are rare, and
/// a spot drawn on a head 20 px across is one pixel of mud.
#macro CHT_PAT_T0 0.265
#macro CHT_PAT_T1 0.965

/// A body point from the two pattern coordinates. This function IS the file's argument.
function cht_pat_pt(_bd, _t, _u) {
    return [clamp(_u, -1, 1) * cht_body_halfw(_bd, _t), cht_body_y(_bd, _t)];
}

/// A transverse band: a strip between two t stations, following both margins.
///
/// _inset keeps the band off the very edge of the animal, because a band that reaches the outline
/// is painted over by the body's own lit rim and reads as a chewed edge rather than as a marking.
function cht_pat_band(_bd, _ta, _tb, _inset, _role) {
    var _n = 14;
    var _a = array_create(_n + 1), _b = array_create(_n + 1);
    var _k = 1 - clamp(_inset, 0, 0.9);
    for (var _i = 0; _i <= _n; _i++) {
        var _u = -_k + 2 * _k * (_i / _n);
        _a[_i] = cht_pat_pt(_bd, _ta, _u);
        _b[_i] = cht_pat_pt(_bd, _tb, _u);
    }
    return cht_strip(_a, _b, _role);
}

/// A longitudinal stripe: a strip between two u stations, running the length of the region.
function cht_pat_stripe(_bd, _ua, _ub, _t0, _t1, _role) {
    var _n = 20;
    var _a = array_create(_n + 1), _b = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _t0 + (_t1 - _t0) * (_i / _n);
        _a[_i] = cht_pat_pt(_bd, _t, _ua);
        _b[_i] = cht_pat_pt(_bd, _t, _ub);
    }
    return cht_strip(_a, _b, _role);
}

/// A round spot, sized so it fits at every height it covers rather than only at its centre.
function cht_pat_spot(_bd, _t, _u, _r, _role) {
    var _room = cht_body_span_min(_bd, _t - _r, _t + _r);
    var _rr = min(_r, _room * 0.46);
    if (_rr <= 0) return [];
    var _p = cht_pat_pt(_bd, _t, _u * (1 - _rr / max(0.0001, cht_body_halfw(_bd, _t))));
    return [cht_dot(_p[0], _p[1], _rr, _role)];
}

/// ============================================================================================
/// THE PROGRAMS
/// ============================================================================================

/// Every mark on one animal.
///
/// ⚠️ THE SPOT COUNT IS PER ANIMAL, NOT PER SIDE, because that is how a field guide counts. A
/// SEVEN spot ladybird has three spots on each elytron and one shared across the suture, and
/// getting that right is the difference between a drawing made by somebody who looked at one and a
/// drawing made from the words "red with black dots".
function cht_pattern_parts(_bd, _sp, _cut, _px) {
    var _out = [];
    var _pat = clamp(_sp.pat, 0, CHT_PAT_N - 1);
    var _n = max(0, _sp.patn);

    // A mark below about 2 px is a smudge that dirties the colour it sits on and reads as
    // compression noise. Below that the honest answer is a clean animal.
    if (_px < 26) return _out;

    switch (_pat) {
        case CHT_PAT_BANDED: {
            if (_n <= 0) return _out;
            // Bands narrow toward the tail, which is what a real transverse pattern does as the
            // segments themselves shorten. Even-width bands read as a barcode.
            for (var _k = 0; _k < _n; _k++) {
                var _c = CHT_PAT_T0 + (CHT_PAT_T1 - CHT_PAT_T0) * ((_k + 0.62) / _n);
                var _h = (CHT_PAT_T1 - CHT_PAT_T0) / _n * (0.42 - 0.10 * (_k / max(1, _n)));
                array_push(_out, cht_pat_band(_bd, _c - _h, _c + _h, 0.10, "ink"));
            }
        } break;

        case CHT_PAT_SPOTTED: {
            if (_n <= 0) return _out;
            // Odd counts put one spot ON the midline and pair the rest either side; even counts
            // are all paired. That is exactly how a seven-spot is arranged and it falls out of the
            // arithmetic rather than being special-cased.
            var _pairs = floor(_n / 2);
            var _mid = (_n % 2) == 1;
            var _r = 0.030 + 0.012 * (1 - clamp(_n / 12, 0, 1));
            if (_mid) {
                cht_append(_out, cht_pat_spot(_bd, CHT_PAT_T0 + 0.055, 0, _r * 0.92, "ink"));
            }
            for (var _k = 0; _k < _pairs; _k++) {
                var _t = CHT_PAT_T0 + 0.13 + (CHT_PAT_T1 - CHT_PAT_T0 - 0.20)
                       * (_k / max(1, _pairs - 0.001));
                var _u = 0.46 + 0.16 * sin(_k * 1.7);
                for (var _s = -1; _s <= 1; _s += 2) {
                    cht_append(_out, cht_pat_spot(_bd, _t, _s * _u, _r, "ink"));
                }
            }
        } break;

        case CHT_PAT_STRIPED: {
            if (_n <= 0) return _out;
            for (var _k = 0; _k < _n; _k++) {
                var _u = -0.86 + 1.72 * ((_k + 0.5) / _n);
                var _w = 1.72 / _n * 0.34;
                array_push(_out, cht_pat_stripe(_bd, _u - _w, _u + _w,
                    CHT_PAT_T0, CHT_PAT_T1, "ink"));
            }
        } break;

        case CHT_PAT_MARBLED: {
            // Irregular mottling. Seeded off the cuticle so a species mottles the same way every
            // time - nothing in this package is random at draw time.
            var _rng = cht_rng(6151 + _sp.cut * 131 + _n * 17 + _sp.pat * 7);
            var _total = _n * 5;
            for (var _k = 0; _k < _total; _k++) {
                var _t = CHT_PAT_T0 + (CHT_PAT_T1 - CHT_PAT_T0) * cht_rng_next(_rng);
                var _u = -0.88 + 1.76 * cht_rng_next(_rng);
                var _r = 0.016 + 0.030 * cht_rng_next(_rng);
                cht_append(_out, cht_pat_spot(_bd, _t, _u, _r, "ink"));
            }
        } break;

        case CHT_PAT_EYESPOT: {
            if (_n <= 0) return _out;
            // An ocellus is THREE rings, and the pale one is what makes it an eye. Two rings read
            // as a spot with an outline; drop the highlight and the whole mark stops working.
            var _pairs = max(1, floor(_n / 2));
            for (var _k = 0; _k < _pairs; _k++) {
                var _t = CHT_PAT_T0 + 0.12 + (CHT_PAT_T1 - CHT_PAT_T0 - 0.24)
                       * (_k / max(1, _pairs - 0.001));
                for (var _s = -1; _s <= 1; _s += 2) {
                    cht_append(_out, cht_pat_spot(_bd, _t, _s * 0.52, 0.055, "ink"));
                    cht_append(_out, cht_pat_spot(_bd, _t, _s * 0.52, 0.034, "m4"));
                    cht_append(_out, cht_pat_spot(_bd, _t, _s * 0.52, 0.016, "ink"));
                }
            }
        } break;

        case CHT_PAT_RETICULATE: {
            if (_n <= 0) return _out;
            // A net: longitudinal stripes crossed by transverse ones, both thin. The cells between
            // them are the pattern, which is why neither set alone can produce it.
            for (var _k = 0; _k < _n; _k++) {
                var _u = -0.84 + 1.68 * ((_k + 0.5) / _n);
                array_push(_out, cht_pat_stripe(_bd, _u - 0.035, _u + 0.035,
                    CHT_PAT_T0, CHT_PAT_T1, "ink"));
            }
            var _rows = max(2, round(_n * 0.8));
            for (var _k = 0; _k < _rows; _k++) {
                var _c = CHT_PAT_T0 + (CHT_PAT_T1 - CHT_PAT_T0) * ((_k + 0.5) / _rows);
                var _h = (CHT_PAT_T1 - CHT_PAT_T0) / _rows * 0.13;
                array_push(_out, cht_pat_band(_bd, _c - _h, _c + _h, 0.12, "ink"));
            }
        } break;

        default: break;   // PLAIN and METALLIC both draw nothing. See the header on METALLIC:
                          // the sheen IS the pattern, and it is emitted by cht_body_shimmer.
    }
    return _out;
}
