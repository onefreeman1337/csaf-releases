/// CHITIN - cht_selftest. The in-engine suite.
///
/// ============================================================================================
/// ⛔ GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE. There is no headless runner, no mock and no
/// assertion library. This wing's answer is to build the product through Igor, run the executable
/// with `-selftest`, and have it write a JSON result file - the only route that survives a release
/// build. `show_debug_message` plus `-debugoutput` writes engine boot lines and nothing else, and
/// `game_end(n)` does not propagate n to the process exit code. Both measured in this wing.
///
/// ⛔ A SUITE FULL OF GREEN ASSERTIONS PROVES NOTHING UNTIL ONE OF THEM HAS BEEN MADE TO FAIL, and
/// this wing has shipped two suites that could never have gone red: a duplicate check written with
/// a tolerance below GML's default epsilon passed VACUOUSLY for every input, and a containment
/// assertion passed on 216 letters while most of them were being silently shrunk. Every assertion
/// here that could be vacuous is PAIRED with one proving its fixture is in the state it needs, and
/// those pairs are marked VACUITY GUARD.
///
/// ⛔ THE DEFAULT EPSILON. math_get_epsilon() returns 0.00001 on this runtime and it PARTICIPATES
/// IN COMPARISONS, so `abs(a - b) < 0.0000001` is FALSE for every pair of values including equal
/// ones, and `abs(a - b) < 0.00001` goes RED for two values that are the same object. Never write a
/// tolerance below or at about 1e-5. CHT_ST_EPS is the one this file uses. GML also has no
/// exponent-literal syntax at all: `1e-5` is a lexer error that reads like a bracket bug.
///
/// ============================================================================================
/// WHAT THIS SUITE IS FOR, ON THIS PRODUCT SPECIFICALLY
///
/// Chitin's claim is that FORTY-EIGHT animals are each recognisably themselves AND recognisably
/// part of one drawing, all composed from the same twelve functions. Two stages carry that claim
/// and everything else supports them:
///
///   STAGE 4  THE FIT CORRECTION. Every species is scaled to fit the unit box, which makes the
///            containment property true BY CONSTRUCTION and therefore makes asserting it vacuous.
///            So the CORRECTION is what is asserted. A species that has to be shrunk below the
///            floor is not a long-antennaed insect, it is a mistake in its row, and it fires by
///            name. (Carried in from Hearth, which learned it on declared extents.)
///
///   STAGE 8  THE ALL-PAIRS SWEEP, over all 1,128 pairs. The eye finds the collision it happens to
///            land on; a measured sweep finds the pair that is actually worst. The signature is
///            built by STAMPING THE DRAWN GEOMETRY into an occupancy grid - it never reads a
///            species row - because comparing the numbers two species were authored with proves
///            only that they were typed differently.
///
///   STAGE 13 THE APPROACH. The system half's design claim - that a SLOW approach beats a fast one
///            on the same animal over the same ground - measured as CLOSEST APPROACH ACHIEVED
///            rather than as a survivor count, because a count moves in whole animals and any floor
///            put on it is a guess wearing a measurement's clothes. Two halves, and neither is
///            enough alone: creeping must NEVER cost ground (satisfied vacuously by a model that
///            ignores speed) and it must BUY ground somewhere (satisfied by one lucky species).
///
/// ⚠️ WHAT THIS SUITE CANNOT SEE, said here rather than left for a buyer to discover: it computes
/// POINTS and NUMBERS. It cannot see a FILL RULE, a DRAW ORDER, a COLOUR ON A PAGE or a PICTURE.
/// This wing has shipped a crescent moon rendered as a quarter, a rainbow that never drew at all,
/// a gilt rim across twelve plates and - on this very product - forty-eight insects collapsed to a
/// vertical line, every one of them with a fully green geometry story. The instrument for those is
/// opening the baked sheet and LOOKING, and that step is not optional because this file exists.
/// ============================================================================================

/// The one tolerance in this file. Above GML's 0.00001 epsilon by a factor of ten, which is the
/// smallest number that can fire in BOTH directions.
#macro CHT_ST_EPS 0.0001

/// How far a species may be shrunk by cht_fit_unit before its row is considered wrong rather than
/// its animal long. See STAGE 4. A longhorn's antennae really are longer than its body; a species
/// that has to come down below this is drawn as a speck beside every other cell on a cabinet plate,
/// which is a corpus defect and not a containment one.
#macro CHT_ST_FIT_FLOOR 0.55

/// The occupancy grid the pairwise sweep compares species on. 20x20 over the unit box is about
/// 2.5% of the box per cell, which is the scale at which two cabinet thumbnails start to look alike.
#macro CHT_ST_GRID 20

/// How different two species drawn the SAME WAY must be.
///
/// ⭐ CHOSEN FROM A MEASURED GAP, AND THE GAP ONLY OPENED AFTER THE CORPUS WAS FIXED. That order is
/// the whole point of this macro and it is worth recording, because the first two runs of this
/// suite had NO gap to put a threshold in: the same-plan distances ran continuously from 0.036
/// upward, which is what a corpus with real collisions in it looks like, and any number chosen
/// there would have been a number somebody liked.
///
/// MEASURED after the wing rewrite, the per-species wing variants, the stag beetle's mandibles, the
/// rhinoceros beetle's horn and four cuticle reassignments - histogram over the 343 same-plan
/// pairs, in buckets of 0.025:
///
///   0.000-0.050   0 pairs
///   0.050-0.075   1 pair    <- the seven spot / eyed ladybird, exempt and authored that way
///   0.075-0.100   0 pairs   <- THE GAP
///   0.100-0.125   3 pairs
///   0.125-0.150   8 pairs   ... and on up, 68 pairs in the top bucket
///
/// Nothing lands between 0.057 and 0.108, so the floor goes in the middle of that empty band. It is
/// therefore a property of this corpus rather than a value that was tuned until the suite agreed,
/// and a future row edit that pushes any pair under it fires by name.
///
/// ⚠️ SAID PLAINLY: at 0.09 every non-exempt pair currently PASSES, so this assertion is a
/// REGRESSION guard rather than a live finding. That is the honest description of it. The histogram
/// is written into the result file on every run precisely so the next session re-derives this
/// number from the data instead of inheriting it - and so that a corpus which drifts back into the
/// gap is visible before the assertion fires.
#macro CHT_ST_PAIR_FLOOR 0.09

function cht_st_new() {
    return { pass: 0, fail: 0, notes: [] };
}

function cht_st_ok(_r, _cond, _what) {
    if (_cond) { _r.pass += 1; return; }
    _r.fail += 1;
    // Cap the note list. A systemic failure fires hundreds of times and a result file too large to
    // write is a result file nobody reads.
    if (array_length(_r.notes) < 60) array_push(_r.notes, _what);
}

/// ============================================================================================
/// THE SUITE
/// ============================================================================================

function cht_selftest_run() {
    var _r = cht_st_new();
    var _i, _j, _k, _p, _s, _px;

    // -- STAGE 0: the runtime still behaves the way this package assumes -----------------------
    global.cht_stage = 0;
    var _e = math_get_epsilon();
    // ⛔ TWO CLAUSES, AND THE FIRST IS `!(_e > 0)` ON PURPOSE. The natural single expression
    // `_e > 0 && _e < TOL` goes RED on its first clause forever: the difference between the epsilon
    // and zero IS the epsilon, so GML calls them equal, and equal is not greater-than. Written this
    // way it is a POSITIVE test that the runtime still applies an epsilon, and it goes red the day
    // a release stops - which this package, whose body function underflowed into it, must know.
    cht_st_ok(_r, !(_e > 0), "epsilon: expected (_e > 0) to be FALSE - the epsilon trap is gone");
    cht_st_ok(_r, _e < 0.001,
              "epsilon: " + string_format(_e, 1, 12) + " is larger than this package assumes");

    // -- STAGE 1: THE CORPUS IS COUNTABLE AND EVERY FORM HAS A NAME -----------------------------
    // ⛔ A NAME ARRAY AND ITS SWITCH ARE ONE FACT WITH TWO DECLARATIONS (CLAUDE.md 2b, six recorded
    // instances in this factory). This stage is what makes that fire by name - and on its first run
    // it found TWO arrays naming forms the package does not have, both of them being added into the
    // figure the store listing quotes. See cht_corpus.
    global.cht_stage = 1;
    cht_st_ok(_r, array_length(cht_plan_names())       == CHT_PLAN_N,    "names: body plans");
    cht_st_ok(_r, array_length(cht_pattern_names())    == CHT_PAT_N,     "names: patterns");
    cht_st_ok(_r, array_length(cht_wing_shape_names()) == CHT_WSHAPE_N,  "names: wing shapes");
    cht_st_ok(_r, array_length(cht_antenna_names())    == CHT_ANT_N,     "names: antennae");
    cht_st_ok(_r, array_length(cht_leg_names())        == CHT_LEG_N,     "names: legs");
    cht_st_ok(_r, array_length(cht_sculpture_names())  == CHT_SCULPT_N,  "names: sculptures");
    cht_st_ok(_r, array_length(cht_cuticle_names())    == CHT_CUTICLE_N, "names: cuticles");
    cht_st_ok(_r, array_length(cht_species_names())    == 48,
              "names: roster holds " + string(array_length(cht_species_names())) + ", not 48");
    cht_st_ok(_r, cht_species_n() == array_length(cht_species_names()),
              "cht_species_n disagrees with the roster it is supposed to be derived from");
    // The operator's volume floor for a Line-A product: 40+ distinct generated forms.
    cht_st_ok(_r, cht_corpus_forms() >= 40,
              "corpus: " + string(cht_corpus_forms()) + " forms is below the volume floor of 40");
    // Every cuticle's own name_i must address the array. A row whose name_i is out of range would
    // caption an insect "?12" on a store plate.
    for (_i = 0; _i < CHT_CUTICLE_N; _i++) {
        var _cs = cht_cuticle_spec(_i);
        cht_st_ok(_r, _cs.name_i == _i,
                  "cuticle " + string(_i) + " carries name_i " + string(_cs.name_i));
    }
    // VACUITY GUARD. cht_name_of must be able to say NO, or every naming assertion above is being
    // made against a function that answers anything.
    cht_st_ok(_r, cht_name_of(cht_plan_names(), 99) == "?99",
              "VACUITY: cht_name_of did not flag an out-of-range index");

    // -- STAGE 2: EVERY BODY PLAN CLOSES ITSELF AT BOTH ENDS ------------------------------------
    // ⛔ THIS IS THE ASSERTION THE PRODUCT'S SECOND SHIPPED DEFECT NEEDED. Every animal was cut off
    // flat at head and tail because the end lobes did not reach zero at t=0 and t=1, and nothing
    // said so: a flat-topped outline is still simple, still closed, still inside the box.
    // The lobe layout in cht_body_plan is authored so that lobe0.c - lobe0.r == 0 and
    // lobeN.c + lobeN.r == 1 exactly; this is what checks that it still is.
    global.cht_stage = 2;
    for (_p = 0; _p < CHT_PLAN_N; _p++) {
        var _bd = cht_body_plan(_p);
        var _nm = cht_name_of(cht_plan_names(), _p);
        cht_st_ok(_r, cht_body_halfw(_bd, 0) < CHT_ST_EPS,
                  _nm + ": halfw(0) = " + string_format(cht_body_halfw(_bd, 0), 1, 5) + ", not 0");
        cht_st_ok(_r, cht_body_halfw(_bd, 1) < CHT_ST_EPS,
                  _nm + ": halfw(1) = " + string_format(cht_body_halfw(_bd, 1), 1, 5) + ", not 0");

        // ⛔⛔ VACUITY GUARD, AND IT IS THE ONE THAT MATTERS ON THIS PRODUCT. The two assertions
        // above are ALSO satisfied by a body that is zero everywhere - which is exactly the animal
        // this package shipped to its first preview, when GML's epsilon swallowed the p-norm's
        // intermediate and cht_body_halfw returned 0 at EVERY station. Without this line the fix
        // for that defect has no test at all.
        var _wmax = 0;
        for (_k = 0; _k <= 100; _k++) _wmax = max(_wmax, cht_body_halfw(_bd, _k / 100));
        cht_st_ok(_r, _wmax > 0.03,
                  "VACUITY " + _nm + ": widest half-width is " + string_format(_wmax, 1, 5)
                  + " - the body has collapsed and halfw(0)==halfw(1)==0 is passing on nothing");

        // The outline the whole animal is built on must be a simple closed polygon that turns once.
        var _o = cht_body_outline(_bd, 96);
        cht_st_ok(_r, abs(abs(cht_turning(_o)) - 1) < 0.02,
                  _nm + ": body outline turns " + string_format(cht_turning(_o), 1, 3) + " revolutions");
        cht_st_ok(_r, cht_is_simple(_o), _nm + ": body outline is self-intersecting");
    }

    // -- STAGE 3: THE ROSTER'S OWN RULES --------------------------------------------------------
    // Facts a reader of cht_species is entitled to rely on, checked rather than commented.
    global.cht_stage = 3;
    var _nButterfly = 0, _nMoth = 0, _nBeetle = 0;
    for (_i = 0; _i < cht_species_n(); _i++) {
        var _sp = cht_species_spec(_i);
        var _sn = cht_name_of(cht_species_names(), _i);

        cht_st_ok(_r, _sp.plan >= 0 && _sp.plan < CHT_PLAN_N, _sn + ": plan out of range");
        cht_st_ok(_r, _sp.cut  >= 0 && _sp.cut  < CHT_CUTICLE_N, _sn + ": cuticle out of range");
        cht_st_ok(_r, _sp.ant  >= 0 && _sp.ant  < CHT_ANT_N,  _sn + ": antenna out of range");
        cht_st_ok(_r, _sp.leg  >= 0 && _sp.leg  < CHT_LEG_N,  _sn + ": leg out of range");
        cht_st_ok(_r, _sp.scu  >= 0 && _sp.scu  < CHT_SCULPT_N, _sn + ": sculpture out of range");
        cht_st_ok(_r, _sp.pat  >= 0 && _sp.pat  < CHT_PAT_N,  _sn + ": pattern out of range");

        if (_sp.plan == CHT_PLAN_SPREAD) {
            _nButterfly += 1;
            // ⛔ EVERY BUTTERFLY IS CLAVATE. It is the oldest field mark there is - it is how a
            // butterfly is told from a moth before anything else about it is looked at - so it is
            // authored rather than varied, and a row that drifts off it fires here.
            cht_st_ok(_r, _sp.ant == CHT_ANT_CLAVATE,
                      _sn + ": a butterfly with " + cht_name_of(cht_antenna_names(), _sp.ant)
                      + " antennae");
            // And no butterfly has mandibles. An adult Lepidopteran has a proboscis.
            cht_st_ok(_r, _sp.mnd <= 0, _sn + ": a butterfly with mandibles");
        }
        if (_sp.plan == CHT_PLAN_FOLDED) {
            _nMoth += 1;
            // The converse, and it is the half that stops the rule above being satisfied by making
            // EVERYTHING clavate.
            cht_st_ok(_r, _sp.ant != CHT_ANT_CLAVATE, _sn + ": a moth with clavate antennae");
            cht_st_ok(_r, _sp.mnd <= 0, _sn + ": a moth with mandibles");
        }
        if (_sp.plan == CHT_PLAN_ELYTRA) {
            _nBeetle += 1;
            // A beetle has jaws. A row with none is a row that lost its mandible column.
            cht_st_ok(_r, _sp.mnd > 0, _sn + ": a beetle with no mandibles at all");
        }
        // ⛔⛔ THE SPECIES-LEVEL BODY GUARD, AND IT EXISTS BECAUSE A SABOTAGE RUN SHOWED THE
        // PLAN-LEVEL ONE COVERING A THIRD OF THE CORPUS.
        //
        // MEASURED 2026-09-01. Re-instating the epsilon underflow that collapsed every body on this
        // product's first preview - `if (_sum <= 0) return 0` over an un-normalised p-norm - fired
        // STAGE 2's vacuity guard on only TWO of the six plans, because only the two beetle plans
        // carry a blend exponent (6.5) high enough for `power(0.168, 6.5)` to land under GML's
        // 0.00001 epsilon. The other four plans blend at 2.0 to 4.0 and never underflow. So the
        // guard written FOR that defect was reporting on a third of the animals, and 24 beetles
        // drawing as vertical sticks would have passed every species-level assertion in the suite:
        // the fit correction, the containment, and all 343 pairs of the collision sweep.
        //
        // ⭐ "An assertion that goes red on your sabotage is not the same as an assertion that would
        // have caught your defect - check WHICH cases fire." This is that check having a
        // consequence. The guard below runs on all 48 ROWS rather than on the 6 plans, so it sees
        // every species' own blend multiplier, and under the same sabotage it fires on 24 of them.
        var _bdy = cht_species_body(_sp);
        var _thin = -1;
        for (_k = 1; _k <= 9; _k++) {
            if (cht_body_halfw(_bdy, _k / 10) < 0.015 && _thin < 0) _thin = _k;
        }
        cht_st_ok(_r, _thin < 0,
                  _sn + ": the body has no width at station 0." + string(_thin)
                  + " - it will draw as a line, and nothing downstream can see that");

        // An eye is a physical feature and must be visible without being a headlamp.
        cht_st_ok(_r, _sp.eye > 0.010 && _sp.eye < 0.060,
                  _sn + ": eye radius " + string_format(_sp.eye, 1, 4) + " is outside 0.010..0.060");
        // A pattern with a count of zero draws nothing, so a row asking for one is a row that will
        // silently produce a plain animal.
        if (_sp.pat != CHT_PAT_PLAIN && _sp.pat != CHT_PAT_METALLIC) {
            cht_st_ok(_r, _sp.patn > 0, _sn + ": pattern "
                      + cht_name_of(cht_pattern_names(), _sp.pat) + " with a count of 0");
        }
    }
    // VACUITY GUARDS on the three group rules above: each must actually have run on something.
    cht_st_ok(_r, _nButterfly >= 10,
              "VACUITY: only " + string(_nButterfly) + " SPREAD rows - the clavate rule ran on nothing");
    cht_st_ok(_r, _nMoth >= 10,
              "VACUITY: only " + string(_nMoth) + " FOLDED rows - the moth rule ran on nothing");
    cht_st_ok(_r, _nBeetle >= 15,
              "VACUITY: only " + string(_nBeetle) + " ELYTRA rows - the mandible rule ran on nothing");

    // -- STAGE 4: THE FIT CORRECTION, WHICH IS THE ONE THAT CAN STILL GO RED --------------------
    // See the header. Containment is true by construction because cht_fit_unit scales a finished
    // list, so the property is worthless as an assertion and the CORRECTION is asserted instead.
    global.cht_stage = 4;
    var _tightest = 1.0, _tightestName = "";
    for (_i = 0; _i < cht_species_n(); _i++) {
        var _raw = cht_species_parts_raw(_i, 700, 0.50);
        var _fk = cht_fit_factor(_raw, 0.485);
        if (_fk < _tightest) { _tightest = _fk; _tightestName = cht_name_of(cht_species_names(), _i); }
        cht_st_ok(_r, _fk >= CHT_ST_FIT_FLOOR,
                  cht_name_of(cht_species_names(), _i) + ": fit correction "
                  + string_format(_fk, 1, 3) + " is below the floor of "
                  + string_format(CHT_ST_FIT_FLOOR, 1, 2)
                  + " - it will draw as a speck beside every other cell");
        // And the fitted list really is inside the box. Structural, stated as such, kept because it
        // is the thing the correction is FOR and a broken fitter would otherwise be invisible.
        var _fb = cht_render_bounds(cht_fit_unit(_raw, 0.485));
        var _fr = max(max(abs(_fb[0]), abs(_fb[2])), max(abs(_fb[1]), abs(_fb[3])));
        cht_st_ok(_r, _fr <= 0.4851,
                  cht_name_of(cht_species_names(), _i) + ": fitted list still reaches "
                  + string_format(_fr, 1, 4));
    }
    // VACUITY GUARD, both directions. The fitter must ACT on an oversized list and must NOT touch
    // one that already fits - otherwise "everything is inside the box" is satisfied by a function
    // that shrinks everything to nothing, or by one that does nothing at all.
    var _big = [cht_dot(0, 0, 0.90, "m2")];
    var _sml = [cht_dot(0, 0, 0.10, "m2")];
    cht_st_ok(_r, cht_fit_factor(_big, 0.485) < 0.60,
              "VACUITY: the fitter did not shrink a list reaching 0.90");
    cht_st_ok(_r, cht_fit_factor(_sml, 0.485) == 1,
              "VACUITY: the fitter shrank a list that already fitted");

    // -- STAGE 5: WING GEOMETRY -----------------------------------------------------------------
    // Half this corpus is Lepidoptera and for those 24 species the wings ARE the animal.
    global.cht_stage = 5;
    for (_s = 0; _s < CHT_WSHAPE_N; _s++) {
        var _wn = cht_name_of(cht_wing_shape_names(), _s);
        var _ws = _cht_st_wings(_s);
        for (_k = 0; _k < 2; _k++) {
            var _w = _ws[_k];
            var _lbl = _wn + (_k == 0 ? " forewing" : " hindwing");
            var _wo = cht_wing_outline(_w, 40);
            cht_st_ok(_r, abs(abs(cht_turning(_wo)) - 1) < 0.03,
                      _lbl + ": outline turns " + string_format(cht_turning(_wo), 1, 3));
            cht_st_ok(_r, cht_is_simple(_wo), _lbl + ": outline is self-intersecting");

            // ⛔ THE LEADING EDGE MUST STAY AHEAD OF THE TRAILING ONE AT EVERY STATION. If they
            // cross anywhere the wing turns inside out for the rest of its span, which is a bowtie
            // that a turning test can miss entirely.
            var _crossed = false;
            for (_j = 0; _j <= 40; _j++) {
                var _st = _j / 40;
                if (cht_wing_lead(_w, _st) > cht_wing_trail(_w, _st) + CHT_ST_EPS) _crossed = true;
            }
            cht_st_ok(_r, !_crossed, _lbl + ": the leading edge crosses the trailing edge");

            // The chord must be REAL somewhere, or the wing is a line.
            var _cmax = 0;
            for (_j = 0; _j <= 40; _j++) _cmax = max(_cmax, cht_wing_halfc(_w, _j / 40, 1));
            cht_st_ok(_r, _cmax > 0.030,
                      "VACUITY " + _lbl + ": widest half-chord is only "
                      + string_format(_cmax, 1, 4));
        }
        // A forewing must be LONGER than the hindwing it lies over, on every shape family. A
        // hindwing that outreaches its forewing is drawn under it and simply disappears.
        cht_st_ok(_r, _ws[0].span > _ws[1].span,
                  _wn + ": the hindwing spans further than the forewing");
    }

    // -- STAGE 6: A MARK ON A WING FITS THE WING AT EVERY HEIGHT IT OCCUPIES --------------------
    // ⚠️ THIS WING'S STANDING LAW, ONE LEVEL UP: a shape is only as wide as its bounding box at ONE
    // height, so a spot clipped against the chord at its own CENTRE pokes out where the wing
    // narrows above it. The test is the real one - a circle in wing space, checked against both
    // edges at every station it covers - rather than a restatement of what the clipper computes.
    global.cht_stage = 6;
    var _tw = _cht_st_wings(CHT_WSHAPE_BUTTERFLY)[0];
    var _spotsChecked = 0, _spotsOut = 0;
    for (_j = 2; _j <= 9; _j++) {
        for (_k = -2; _k <= 2; _k++) {
            var _ss = _j / 10;
            var _cc = _k / 2.4;
            var _want = _tw.trailMax * 0.55;
            var _rr = cht_wing_spot_r(_tw, _ss, _cc, _want);
            if (_rr <= 0) continue;
            var _pt = cht_wing_spot_c(_tw, _ss, _cc, _rr);
            _spotsChecked += 1;
            if (!_cht_st_circle_in_wing(_tw, _pt[0], _pt[1], _rr)) _spotsOut += 1;
        }
    }
    cht_st_ok(_r, _spotsChecked >= 20,
              "VACUITY: only " + string(_spotsChecked) + " spots were placed at all");
    cht_st_ok(_r, _spotsOut == 0,
              string(_spotsOut) + " of " + string(_spotsChecked)
              + " wing spots reach outside the wing at some station they cover");

    // AN OCELLUS IS CONCENTRIC. Three rings on three centres is a spiral, and this product drew one
    // on every eyespot in the corpus until 2026-09-01. The rings must share a centre EXACTLY, and
    // they must alternate dark-pale-dark rather than all resolving to the same role.
    // ⚠️ THESE ARE cht_wing_pattern's OWN NUMBERS, and the first version of this line invented its
    // own. When the wing's widest station moved inboard from 0.86 to 0.62, a fixture placing an
    // ocellus at 0.68 fell off the end of the room and emitted NOTHING - so the concentricity
    // assertion beside it silently stopped running, and only the guard on the ring COUNT said so.
    // A fixture that does not track the code it is a fixture for is a test that quietly retires.
    var _oc = cht_wing_ocellus(_tw, 0.56, -0.12, cht_wing_chord(_tw) * 0.40);
    cht_st_ok(_r, array_length(_oc) == 3, "ocellus: emitted " + string(array_length(_oc)) + " rings");
    if (array_length(_oc) == 3) {
        cht_st_ok(_r, _oc[0].cx == _oc[1].cx && _oc[1].cx == _oc[2].cx
                   && _oc[0].cy == _oc[1].cy && _oc[1].cy == _oc[2].cy,
                  "ocellus: the three rings do not share one centre - it will draw as a spiral");
        cht_st_ok(_r, _oc[0].r > _oc[1].r && _oc[1].r > _oc[2].r,
                  "ocellus: the rings are not strictly nested");
        cht_st_ok(_r, _oc[0].role != _oc[1].role && _oc[1].role != _oc[2].role,
                  "ocellus: adjacent rings share a role, so it draws as one flat disc");
    }

    // -- STAGE 7: COLOUR ------------------------------------------------------------------------
    global.cht_stage = 7;
    var _iridSeen = 0;
    for (_i = 0; _i < CHT_CUTICLE_N; _i++) {
        var _cu = cht_cuticle_spec(_i);
        var _cn = cht_name_of(cht_cuticle_names(), _i);

        // SLIDE THE RAMP, NEVER CLAMP ITS ENDS. Two stops that clamp to the same value make a bevel
        // whose brightest walls are identical, which reads as a flat fill with a line round it.
        cht_st_ok(_r, cht_chroma_min_step(_cu) > 0.012,
                  _cn + ": smallest adjacent ramp step is "
                  + string_format(cht_chroma_min_step(_cu), 1, 4) + " - the ramp has collapsed");

        // An ink must go the OTHER WAY from its own ground by a real amount, on a corpus that holds
        // both chalk white scale and pitch black cuticle.
        cht_st_ok(_r, cht_chroma_ink_sep(_cu) > 0.30,
                  _cn + ": ink sits only " + string_format(cht_chroma_ink_sep(_cu), 1, 3)
                  + " from its own ground");

        if (_cu.irid > 0) {
            _iridSeen += 1;
            // ⛔ THE PROPERTY IS THAT THE LIFT SURVIVES THE LIGHTNESS CEILING, NOT THAT IT CLEARS
            // A FIXED NUMBER, AND THE FIRST VERSION OF THIS LINE GOT THAT WRONG.
            //
            // It read `sep > 0.09` flat and went RED on gilded bronze at 0.051 - correctly
            // computed, since that cuticle declares irid 0.34 and the lift is CHT_IRID_SEP times
            // irid. A weakly structural bronze is supposed to shimmer weakly. The failure the
            // absolute-separation rule exists to catch is a lift that gets EATEN - either by
            // someone reintroducing a multiplier, or by a pale cuticle whose lifted lightness
            // clamps at CHT_L_CEIL - and both of those show up as the realised lift falling short
            // of what the declaration asked for. That is what is asserted.
            //
            // ⚠️ A test that hard-codes a design constant goes red on the next legitimate change to
            // it; this wing has a receipt for that too. The floor below is derived from
            // CHT_IRID_SEP and the cuticle's own irid, so moving either moves the test with them.
            cht_st_ok(_r, cht_irid_sep_of(_cu) > CHT_IRID_SEP * _cu.irid * 0.90,
                      _cn + ": structural lift is " + string_format(cht_irid_sep_of(_cu), 1, 3)
                      + " against the " + string_format(CHT_IRID_SEP * _cu.irid, 1, 3)
                      + " it declares - the lightness ceiling is eating it");
            // And a cuticle that claims to be STRONGLY structural must produce a lift a viewer can
            // actually see. Scoped to the ones that make the claim.
            if (_cu.irid >= 0.60) {
                cht_st_ok(_r, cht_irid_sep_of(_cu) > 0.085,
                          _cn + ": declares irid " + string_format(_cu.irid, 1, 2)
                          + " but lifts only " + string_format(cht_irid_sep_of(_cu), 1, 3));
            }
            // ⛔ THE HUE MUST NOT TRAVEL THROUGH A THIRD COLOUR. Stated as a PROPERTY rather than as
            // "the midpoint is not green": a test that names the failure mode it expects cannot see
            // the one standing next to it, which is how a sibling shipped MAGENTA rusting iron after
            // fixing green rusting iron. At every step of the band the hue must lie between the
            // pigment's own hue and the structural target, never outside the shorter arc.
            var _bad = false;
            var _base = cht_chroma_base(_cu);
            for (_j = 1; _j <= 9; _j++) {
                var _ph = _j / 10;
                var _tgt = cht_hue_mix(_cu.h0, _cu.h1, _ph);
                var _got = _cht_st_hue_of(cht_chroma_ramp_at(_cu, 0.5, 0, _ph));
                // The arc from the pigment hue to the target: the realised hue must not be further
                // from EITHER end than the two ends are from each other, plus a working margin.
                var _arc = cht_hue_gap(_base.h, _tgt);
                if (cht_hue_gap(_base.h, _got) > _arc + 26
                 || cht_hue_gap(_tgt, _got)   > _arc + 26) _bad = true;
            }
            cht_st_ok(_r, !_bad,
                      _cn + ": the structural swing leaves the arc between its own two hues");
        }
    }
    cht_st_ok(_r, _iridSeen >= 5,
              "VACUITY: only " + string(_iridSeen) + " iridescent cuticles - the headline of the "
              + "product is being asserted on almost nothing");

    // The shell's tonal range. A tube whose lit and shaded flanks differ by nothing IS a sticker,
    // and no ink or extent floor can see that - they measure whether ink is present, not whether it
    // varies. Checked on every cuticle so a flat one fires by name.
    for (_i = 0; _i < CHT_CUTICLE_N; _i++) {
        var _cu2 = cht_cuticle_spec(_i);
        var _lLit = cht_oklch_L_of(cht_chroma_ramp_at(_cu2, cht_tube_k(-0.92), -0.92, 0.5));
        var _lDrk = cht_oklch_L_of(cht_chroma_ramp_at(_cu2, cht_tube_k(0.92), 0.92, 0.5));
        cht_st_ok(_r, _lLit - _lDrk > 0.055,
                  cht_name_of(cht_cuticle_names(), _i) + ": the shell's lit and shaded flanks "
                  + "differ by only " + string_format(_lLit - _lDrk, 1, 3));
    }
    // VACUITY GUARD on the tube itself: it must be BRIGHTEST toward the lamp and darkest away from
    // it, or the range above is satisfied by a gradient pointing the wrong way.
    cht_st_ok(_r, cht_tube_k(-0.92) > cht_tube_k(0.92),
              "VACUITY: the tube is lit from the wrong side");

    // -- STAGE 8: THE ALL-PAIRS SWEEP -----------------------------------------------------------
    // ⭐ 48 species is 1,128 pairs. The eye finds the pair it lands on; this finds the pair that is
    // actually worst. The signature stamps the DRAWN GEOMETRY into an occupancy grid and reads the
    // cuticle's realised colour - it never looks at a species row, because comparing the numbers
    // two species were authored with proves only that somebody typed them differently.
    //
    // ⚠️ ONLY SPECIES THE PRODUCT DRAWS THE SAME WAY ARE COMPARED. A spread butterfly and a
    // closed-wing beetle are different PICTURES however close their colours, and scoring them
    // against each other would flood the sweep with pairs nobody could confuse.
    global.cht_stage = 8;
    var _n = cht_species_n();
    var _sig = array_create(_n);
    for (_i = 0; _i < _n; _i++) _sig[_i] = _cht_st_signature(_i);

    var _worstD = 2.0, _worstA = -1, _worstB = -1;
    var _pairs = 0, _same = 0, _exempt = 0, _below = 0;
    // The eight worst pairs, kept so the result file can state the DISTRIBUTION rather than a
    // verdict - the next session re-derives the floor from these instead of trusting the macro.
    var _tA = array_create(8, -1), _tB = array_create(8, -1), _tD = array_create(8, 9.0);
    // ⭐ AND A HISTOGRAM, BECAUSE THIS WING'S RULE IS TO PUT A THRESHOLD IN THE MEASURED GAP RATHER
    // THAN AT A NUMBER THAT SOUNDS RIGHT. Twenty buckets of 0.025 across the same-plan
    // distribution: an empty run of buckets IS the gap, and a floor chosen in it is a property of
    // the corpus instead of a value somebody liked.
    var _hist = array_create(20, 0);

    for (_i = 0; _i < _n; _i++) {
        for (_j = _i + 1; _j < _n; _j++) {
            _pairs += 1;
            if (cht_species_spec(_i).plan != cht_species_spec(_j).plan) continue;
            _same += 1;
            var _d = _cht_st_distance(_sig[_i], _sig[_j]);
            if (_d < _worstD) { _worstD = _d; _worstA = _i; _worstB = _j; }
            _hist[clamp(floor(_d / 0.025), 0, 19)] += 1;
            // Slot it into the worst-eight table.
            for (_k = 0; _k < 8; _k++) {
                if (_d < _tD[_k]) {
                    for (var _m = 7; _m > _k; _m--) {
                        _tD[_m] = _tD[_m - 1]; _tA[_m] = _tA[_m - 1]; _tB[_m] = _tB[_m - 1];
                    }
                    _tD[_k] = _d; _tA[_k] = _i; _tB[_k] = _j;
                    break;
                }
            }
            if (_cht_st_lookalike(_i, _j)) {
                _exempt += 1;
                // An authored lookalike still has to be MEASURABLY different, or the tell it exists
                // to carry is not reaching the picture at all.
                cht_st_ok(_r, _d > 0.02,
                          "lookalike pair " + cht_name_of(cht_species_names(), _i) + " / "
                          + cht_name_of(cht_species_names(), _j) + " differ by only "
                          + string_format(_d, 1, 3) + " - the tell is not reaching the drawing");
                continue;
            }
            if (_d < CHT_ST_PAIR_FLOOR) _below += 1;
            cht_st_ok(_r, _d >= CHT_ST_PAIR_FLOOR,
                      "COLLISION " + cht_name_of(cht_species_names(), _i) + " / "
                      + cht_name_of(cht_species_names(), _j) + " = "
                      + string_format(_d, 1, 3));
        }
    }
    cht_st_ok(_r, _pairs == _n * (_n - 1) / 2,
              "sweep walked " + string(_pairs) + " pairs, not " + string(_n * (_n - 1) / 2));
    cht_st_ok(_r, _same >= 200,
              "VACUITY: only " + string(_same) + " same-plan pairs were scored");
    // ⛔ THE EXEMPTION LIST MUST BE TINY, and this is what stops it from quietly growing into a way
    // of making the sweep green. An exemption is a claim that two real insects genuinely look alike.
    cht_st_ok(_r, _exempt <= 4,
              "the lookalike exemption covers " + string(_exempt) + " pairs, which is too many "
              + "for it to still be an exception");
    // VACUITY GUARDS on the metric itself. It must read zero for a species against ITSELF, and it
    // must be able to reach a large value - a metric that returns a constant would pass every
    // assertion in this stage.
    cht_st_ok(_r, _cht_st_distance(_sig[0], _sig[0]) < CHT_ST_EPS,
              "VACUITY: the metric does not read 0 for a species against itself");
    var _far = _cht_st_distance(_sig[0], _sig[30]);
    cht_st_ok(_r, _far > 0.30,
              "VACUITY: a stag beetle and a common blue read only " + string_format(_far, 1, 3)
              + " apart - the metric cannot distinguish anything");

    // -- STAGE 9: THE LEVEL-OF-DETAIL CONTRACTS -------------------------------------------------
    // Every count in this package that has a resolution floor RETURNS its decision rather than
    // applying it silently, so each one is a function with a contract: zero at zero, never
    // decreasing as the drawing gets bigger, never above what was asked for.
    global.cht_stage = 9;
    cht_st_ok(_r, cht_species_bands(0) == 0, "LOD: bands(0) is not 0");
    cht_st_ok(_r, cht_wing_fit(7, 0) == 0,   "LOD: wing veins at 0 px is not 0");
    cht_st_ok(_r, cht_elytra_stria_fit(9, 0) == 0, "LOD: striae at 0 px is not 0");
    var _prevB = -1, _prevV = -1, _prevS = -1, _prevL = -1;
    for (_px = 0; _px <= 900; _px += 15) {
        var _b2 = cht_species_bands(_px);
        var _v2 = cht_wing_fit(7, _px);
        var _s2 = cht_elytra_stria_fit(9, _px);
        var _l2 = cht_leg_fit(_px);
        cht_st_ok(_r, _b2 >= _prevB, "LOD: band count fell going from a smaller drawing to " + string(_px) + " px");
        cht_st_ok(_r, _v2 >= _prevV, "LOD: vein count fell at " + string(_px) + " px");
        cht_st_ok(_r, _s2 >= _prevS, "LOD: stria count fell at " + string(_px) + " px");
        cht_st_ok(_r, _l2 >= _prevL, "LOD: leg count fell at " + string(_px) + " px");
        cht_st_ok(_r, _v2 <= 7, "LOD: wing_fit returned more veins than were asked for");
        cht_st_ok(_r, _s2 <= 9, "LOD: stria_fit returned more striae than were asked for");
        _prevB = _b2; _prevV = _v2; _prevS = _s2; _prevL = _l2;
    }
    // VACUITY GUARD: the monotonicity above is satisfied by a function that returns a constant.
    cht_st_ok(_r, cht_species_bands(700) > cht_species_bands(40),
              "VACUITY: the band count does not respond to drawn size");
    cht_st_ok(_r, cht_wing_fit(7, 700) > cht_wing_fit(7, 40),
              "VACUITY: the vein count does not respond to drawn size");

    // -- STAGE 10: DETERMINISM ------------------------------------------------------------------
    // ⛔ NOTHING IN THIS PACKAGE MAY BE RANDOM AT DRAW TIME. A jittered edge that re-jitters every
    // frame is the one defect a buyer notices immediately and cannot work around, and this wing has
    // measured a generator that failed exactly that way when it was a struct with a method.
    global.cht_stage = 10;
    for (_i = 0; _i < cht_species_n(); _i += 7) {
        var _a1 = cht_species_parts(_i, 240, 0.50);
        var _a2 = cht_species_parts(_i, 240, 0.50);
        cht_st_ok(_r, array_length(_a1) == array_length(_a2),
                  cht_name_of(cht_species_names(), _i) + ": two identical calls drew "
                  + string(array_length(_a1)) + " and " + string(array_length(_a2)) + " parts");
        var _bb1 = cht_render_bounds(_a1);
        var _bb2 = cht_render_bounds(_a2);
        var _dmax = 0;
        for (_k = 0; _k < 4; _k++) _dmax = max(_dmax, abs(_bb1[_k] - _bb2[_k]));
        cht_st_ok(_r, _dmax < CHT_ST_EPS,
                  cht_name_of(cht_species_names(), _i) + ": geometry differs between identical "
                  + "calls by " + string_format(_dmax, 1, 6));
    }
    // And the generator itself decorrelates nearby seeds. A Lehmer generator's FIRST draw is very
    // nearly a straight line in the seed, and every caller here seeds with `base + index` - so a
    // first draw spent on a decision makes that decision a function of the index. A sibling product
    // measured a stated 30% chance at exactly 0% over 440 trials for this reason.
    var _lo2 = 1.0, _hi2 = 0.0;
    for (_i = 0; _i < 440; _i++) {
        var _g = cht_rng(9000 + _i);
        var _v3 = cht_rng_next(_g);
        _lo2 = min(_lo2, _v3); _hi2 = max(_hi2, _v3);
    }
    cht_st_ok(_r, _lo2 < 0.02 && _hi2 > 0.98,
              "rng: over 440 nearby seeds the first draw spanned only "
              + string_format(_lo2, 1, 4) + ".." + string_format(_hi2, 1, 4)
              + " - the warm-up is gone");

    // -- STAGE 11: THE FIELD LAYER ---------------------------------------------------------------
    // ⛔ THIS IS THE HALF THAT MAKES IT A PRODUCT RATHER THAN A CORPUS, AND IT IS THE HALF WITH NO
    // PICTURE - so it is the half where a suite is the ONLY instrument. A wrong flight period does
    // not draw badly; it draws perfectly and is simply false, and nothing but an assertion can see
    // the difference.
    global.cht_stage = 11;
    var _widest = 0, _narrowest = 99999;
    for (_i = 0; _i < cht_species_n(); _i++) {
        var _fd = cht_field_spec(_i);
        var _fn = cht_name_of(cht_species_names(), _i);

        cht_st_ok(_r, _fd.hab > 0 && _fd.hab < 256, _fn + ": habitat mask out of range");
        cht_st_ok(_r, _fd.sea > 0 && _fd.sea < 64,  _fn + ": season mask out of range");
        cht_st_ok(_r, _fd.day > 0 && _fd.day < 64,  _fn + ": daypart mask out of range");
        cht_st_ok(_r, _fd.wx  > 0 && _fd.wx  < 16,  _fn + ": weather mask out of range");
        cht_st_ok(_r, _fd.evade >= 0 && _fd.evade < CHT_EVADE_N, _fn + ": evade out of range");
        cht_st_ok(_r, _fd.abund > 0 && _fd.abund <= 1, _fn + ": abundance out of range");
        cht_st_ok(_r, _fd.alarm > 0 && _fd.speed > 0, _fn + ": alarm or speed is zero");

        // ⛔ THE PEAK MUST BE INSIDE THE FLIGHT PERIOD AND THE PREFERRED WEATHER INSIDE THE
        // TOLERATED SET. Both are the same defect shape: a row naming a favourite condition the row
        // itself says the animal is never in. Silent, and it makes the species permanently thin -
        // cht_field_density multiplies by 0.55 in every cell because the peak is never reached.
        cht_st_ok(_r, cht_bit(_fd.sea, cht_bit_at(_fd.peak)),
                  _fn + ": peak season " + cht_name_of(cht_season_names(), _fd.peak)
                  + " is outside its own flight period");
        cht_st_ok(_r, cht_bit(_fd.wx, _fd.wxp),
                  _fn + ": preferred weather is not in its tolerated set");

        // Every species must be findable SOMEWHERE. A row that no query can ever return is 48th of
        // 48 species the buyer paid for and can never see - the phantom-form defect, in the field
        // layer instead of the name arrays.
        var _cells = cht_field_cells(_i);
        cht_st_ok(_r, _cells > 0, _fn + ": occupies no habitat/season/time/weather cell at all");
        _widest = max(_widest, _cells);
        _narrowest = min(_narrowest, _cells);

        // The rarity band must address its own name array.
        var _bd2 = cht_field_rarity_band(_i);
        cht_st_ok(_r, _bd2 >= 0 && _bd2 < array_length(cht_rarity_names()),
                  _fn + ": rarity band " + string(_bd2) + " has no name");
        // And the guide line must be drawable: ASCII only, and never the "nowhere" marker.
        var _wl = cht_field_when_line(_i);
        cht_st_ok(_r, string_length(_wl) > 10 && string_pos("nowhere", _wl) == 0,
                  _fn + ": field guide line reads \"" + _wl + "\"");
    }
    // ⛔⛔ VACUITY GUARD ON THE WHOLE STAGE. Every assertion above is also satisfied by a corpus in
    // which all 48 rows are identical - and an identical field layer is the same failure as an
    // identical drawing: one animal, 48 times, wearing different names. Require a real SPREAD.
    cht_st_ok(_r, _widest >= _narrowest * 4,
              "VACUITY field: the widest species occupies " + string(_widest) + " cells and the "
              + "narrowest " + string(_narrowest) + " - the field data is nearly uniform");

    // The query itself. A midday meadow in high summer in clear weather is the single most
    // populated cell in the space and must return several species; a pine wood in the rain at
    // 3am must return none, or the gating is not gating.
    var _busy = cht_field_now(0, 3, 2, CHT_WX_CLEAR);
    cht_st_ok(_r, array_length(_busy) >= 6,
              "field: a clear midday meadow in high summer holds only "
              + string(array_length(_busy)) + " species");
    var _dead = cht_field_now(3, 5, 5, CHT_WX_RAIN);
    cht_st_ok(_r, array_length(_dead) == 0,
              "field: a pine wood at night in autumn rain holds "
              + string(array_length(_dead)) + " species - the gate is not gating");
    // Sorted, commonest first, with a deterministic tie-break.
    var _sorted = true;
    for (_k = 1; _k < array_length(_busy); _k++) {
        if (_busy[_k].p > _busy[_k - 1].p) _sorted = false;
    }
    cht_st_ok(_r, _sorted, "field: cht_field_now returned an unsorted list");
    var _busy2 = cht_field_now(0, 3, 2, CHT_WX_CLEAR);
    var _same2 = (array_length(_busy) == array_length(_busy2));
    if (_same2) {
        for (_k = 0; _k < array_length(_busy); _k++) {
            if (_busy[_k].i != _busy2[_k].i) _same2 = false;
        }
    }
    cht_st_ok(_r, _same2, "field: two identical queries returned different orders");

    // THE HIBERNATORS. The reason the season column is a mask rather than a window, asserted so
    // that a later edit cannot quietly turn it back into a window.
    var _pk = cht_field_spec(24);
    cht_st_ok(_r, cht_bit(_pk.sea, CHT_SEA_ESPRING) && cht_bit(_pk.sea, CHT_SEA_AUTUMN)
                  && !cht_bit(_pk.sea, CHT_SEA_ESUMMER),
              "field: the peacock's flight period is no longer split across the summer gap");

    // The weighted picker. 4,000 draws over one cell: every species present must come up, nothing
    // absent may, and the commonest must beat the scarcest.
    var _cell = cht_field_now(0, 3, 2, CHT_WX_CLEAR);
    var _hits = array_create(cht_species_n(), 0);
    for (_k = 0; _k < 4000; _k++) {
        var _pick = cht_field_pick(0, 3, 2, CHT_WX_CLEAR, 500000 + _k);
        cht_st_ok(_r, _pick >= 0, "field: picker returned -1 from a non-empty cell");
        if (_pick >= 0) _hits[_pick] += 1;
    }
    var _unseen = 0;
    for (_k = 0; _k < array_length(_cell); _k++) if (_hits[_cell[_k].i] == 0) _unseen += 1;
    cht_st_ok(_r, _unseen == 0,
              "field: " + string(_unseen) + " available species never came up in 4,000 draws");
    var _absentHit = 0;
    for (_i = 0; _i < cht_species_n(); _i++) {
        if (_hits[_i] > 0 && cht_field_density(_i, 0, 3, 2, CHT_WX_CLEAR) <= 0) _absentHit += 1;
    }
    cht_st_ok(_r, _absentHit == 0,
              "field: the picker returned " + string(_absentHit) + " species that are not out");
    cht_st_ok(_r, cht_field_pick(3, 5, 5, CHT_WX_RAIN, 77) == -1,
              "field: the picker invented a species in an empty cell");

    // -- STAGE 12: IDENTIFICATION ----------------------------------------------------------------
    // ⛔ NO TWO SPECIES MAY SHARE ALL SIX FIELD MARKS. Two that do are two the player can never
    // separate, which makes one of them redundant - the corpus-collision test, run on the
    // IDENTIFICATION surface rather than on the drawing.
    global.cht_stage = 12;
    var _identClash = 0, _worstPairA = -1, _worstPairB = -1, _minMarks = 99;
    for (_i = 0; _i < cht_species_n(); _i++) {
        cht_st_ok(_r, array_length(cht_field_marks(_i)) == 6,
                  cht_name_of(cht_species_names(), _i) + ": wrong number of field marks");
        cht_st_ok(_r, array_length(cht_field_separates(_i, _i)) == 0,
                  "VACUITY ident: a species differs from itself");
        for (_j = _i + 1; _j < cht_species_n(); _j++) {
            var _mk = array_length(cht_field_separates(_i, _j));
            if (_mk == 0) _identClash += 1;
            if (_mk < _minMarks) { _minMarks = _mk; _worstPairA = _i; _worstPairB = _j; }
        }
    }
    cht_st_ok(_r, _identClash == 0,
              "ident: " + string(_identClash) + " pair(s) share every field mark - closest is "
              + cht_name_of(cht_species_names(), _worstPairA) + " / "
              + cht_name_of(cht_species_names(), _worstPairB));
    // The two ladybirds are the authored lookalike pair and must differ by EXACTLY the marking.
    var _lady = cht_field_separates(12, 13);
    cht_st_ok(_r, array_length(_lady) == 1 && _lady[0] == "marking",
              "ident: the two ladybirds differ by " + string(array_length(_lady))
              + " mark(s), not by the marking alone");
    var _idOk = cht_field_identify(12, 12);
    cht_st_ok(_r, _idOk.correct, "ident: a correct guess was rejected");
    var _idNear = cht_field_identify(12, 13);
    cht_st_ok(_r, !_idNear.correct && _idNear.near,
              "ident: eyed-for-seven-spot was not scored as a near miss");
    var _idFar = cht_field_identify(0, 24);
    cht_st_ok(_r, !_idFar.correct && !_idFar.near,
              "ident: stag-beetle-for-peacock was scored as a near miss");

    // ⛔ cht_field_nearest IS ON A STORE PLATE, so its answer is a published claim about the corpus
    // and gets the same treatment as any other. It must never return the species itself, must agree
    // with cht_field_separates about the marks it reports, and must be DETERMINISTIC - a guide page
    // that names a different lookalike between two runs is a page nobody can trust, and the
    // lowest-index tie-break is the only thing standing between it and loop order.
    for (_i = 0; _i < cht_species_n(); _i++) {
        var _nr = cht_field_nearest(_i);
        var _nm = cht_name_of(cht_species_names(), _i);
        cht_st_ok(_r, _nr.i >= 0 && _nr.i != _i, _nm + ": nearest lookalike is itself or missing");
        cht_st_ok(_r, _nr.n >= 1 && _nr.n <= 6, _nm + ": lookalike differs by " + string(_nr.n));
        cht_st_ok(_r, array_length(_nr.marks) == _nr.n,
                  _nm + ": nearest reports " + string(_nr.n) + " marks and returned "
                  + string(array_length(_nr.marks)));
        var _nr2 = cht_field_nearest(_i);
        cht_st_ok(_r, _nr2.i == _nr.i,
                  _nm + ": two identical calls named different lookalikes ("
                  + string(_nr.i) + " then " + string(_nr2.i) + ")");
        // And it really is the MINIMUM - the claim the plate makes when it prints the count.
        var _trueMin = 99;
        for (_j = 0; _j < cht_species_n(); _j++) {
            if (_j == _i) continue;
            _trueMin = min(_trueMin, array_length(cht_field_separates(_i, _j)));
        }
        cht_st_ok(_r, _nr.n == _trueMin,
                  _nm + ": nearest returned " + string(_nr.n) + " but the true minimum is "
                  + string(_trueMin));
    }
    // The two ladybirds must find EACH OTHER, which is the corpus's own authored lookalike pair.
    cht_st_ok(_r, cht_field_nearest(12).i == 13 && cht_field_nearest(13).i == 12,
              "ident: the two authored lookalike ladybirds do not name each other as nearest");

    // -- STAGE 13: THE CATCH -------------------------------------------------------------------
    // ⛔ THE CLAIM UNDER TEST IS THE DESIGN CLAIM: A SLOW APPROACH BEATS A FAST ONE, on the same
    // animal, from the same start, with nothing else changed. If that is not measurably true the
    // whole system half is a distance check with extra steps.
    // ⚠️ THE METRIC IS THE CLOSEST APPROACH ACHIEVED, NOT "did it flee". A count of survivors is a
    // pass/fail per animal and it moves in whole steps, so any floor put on it is a guess dressed as
    // a measurement. CLOSEST APPROACH is continuous, it is the thing the player actually cares
    // about, and it lets the same 4 units of ground be walked at two speeds and compared directly.
    // Both approaches cover the SAME distance, so if neither animal reacts the two tie exactly -
    // which makes "creeping is never worse" a real claim rather than an artefact of the test.
    global.cht_stage = 13;
    var _creepWins = 0, _creepLoses = 0, _gainSum = 0, _gainMax = 0, _gainName = "";
    for (_i = 0; _i < cht_species_n(); _i++) {
        var _spn = cht_name_of(cht_species_names(), _i);
        // CREEP: 200 steps of 0.02s covering 4 units. 1.0 unit widths per second.
        var _sSlow = cht_catch_new(_i, 5, 0, 4000 + _i);
        var _pxp = 0.0, _creepMin = 5.0;
        for (_k = 0; _k < 200; _k++) {
            _pxp += 0.02;
            _sSlow = cht_catch_step(_sSlow, _pxp, 0, 0.02);
            if (_sSlow.mode == CHT_MODE_CALM || _sSlow.mode == CHT_MODE_ALERT) {
                _creepMin = min(_creepMin, abs(_sSlow.x - _pxp));
            }
        }
        // RUSH: the SAME 4 units of ground in 40 steps of 0.02s. Five times the speed.
        var _sFast = cht_catch_new(_i, 5, 0, 4000 + _i);
        var _pxp2 = 0.0, _rushMin = 5.0;
        for (_k = 0; _k < 40; _k++) {
            _pxp2 += 0.10;
            _sFast = cht_catch_step(_sFast, _pxp2, 0, 0.02);
            if (_sFast.mode == CHT_MODE_CALM || _sFast.mode == CHT_MODE_ALERT) {
                _rushMin = min(_rushMin, abs(_sFast.x - _pxp2));
            }
        }
        var _gain = _rushMin - _creepMin;
        if (_gain > 0.01)  _creepWins += 1;
        if (_gain < -0.01) _creepLoses += 1;
        _gainSum += _gain;
        if (_gain > _gainMax) { _gainMax = _gain; _gainName = _spn; }

        // Whatever happened, the state is well-formed.
        cht_st_ok(_r, _sSlow.mode >= 0 && _sSlow.mode < CHT_MODE_N,
                  _spn + ": mode out of range after a creep");
        cht_st_ok(_r, cht_catch_difficulty(_i) > 0 && cht_catch_difficulty(_i) <= 1,
                  _spn + ": difficulty out of range");
    }
    // ⛔ THE DESIGN CLAIM, IN TWO HALVES, AND NEITHER HALF IS ENOUGH ALONE. "Creeping is never
    // worse" is the safety property and is satisfied vacuously by a model that ignores speed
    // entirely; "creeping is better somewhere" is the interesting property and is satisfied by one
    // lucky species. Both, together, are the claim.
    cht_st_ok(_r, _creepLoses == 0,
              "catch: creeping got you CLOSER on " + string(_creepWins) + " species but FURTHER on "
              + string(_creepLoses) + " - a careful approach must never cost you ground");
    cht_st_ok(_r, _creepWins >= 20,
              "VACUITY catch: creeping beat rushing on only " + string(_creepWins) + " of "
              + string(cht_species_n()) + " species - speed barely matters");
    cht_st_ok(_r, _gainMax > 0.50,
              "VACUITY catch: the largest advantage a careful approach ever bought was "
              + string_format(_gainMax, 1, 3) + " unit widths");

    // The alarm radius is the difficulty, so the hardest animal in the corpus must actually be
    // harder than the easiest. Named rather than indexed, so a roster edit fires here.
    cht_st_ok(_r, cht_catch_difficulty(4) > cht_catch_difficulty(10),
              "catch: the green tiger beetle is not harder than the bloody nosed beetle");
    cht_st_ok(_r, cht_catch_difficulty(39) > cht_catch_difficulty(16),
              "catch: the hummingbird hawk moth is not harder than the glow worm");

    // THREAT: at the same distance, a faster player is more alarming; outside the radius, neither is.
    var _tSlow = cht_catch_threat(4, 2.0, 0.2);
    var _tFast = cht_catch_threat(4, 2.0, 3.0);
    cht_st_ok(_r, _tFast > _tSlow, "catch: player speed does not affect threat");
    cht_st_ok(_r, cht_catch_threat(4, 99, 3.0) == 0, "catch: threat leaks outside the alarm radius");

    // THE SWING. A calm centred catch must be able to reach perfect; a fleeing one must not, at ANY
    // centring - which is the arithmetic claim cht_catch_condition's comment makes.
    var _calmSt = cht_catch_new(0, 0, 0, 11);
    var _netCalm = cht_catch_net(_calmSt, 0, 0, 1.0);
    cht_st_ok(_r, _netCalm.hit && cht_catch_condition(_netCalm.quality) == 3,
              "catch: a dead-centre swing on a calm specimen did not produce a perfect one");
    var _fleeSt = cht_catch_new(0, 0, 0, 11);
    _fleeSt.mode = CHT_MODE_FLEE;
    _fleeSt.vx = 6; _fleeSt.vy = 0;
    var _netFlee = cht_catch_net(_fleeSt, 0, 0, 1.0);
    cht_st_ok(_r, _netFlee.hit && cht_catch_condition(_netFlee.quality) < 3,
              "catch: a specimen caught at full flight was graded perfect");
    // A miss is a miss.
    var _netMiss = cht_catch_net(_calmSt, 4, 4, 1.0);
    cht_st_ok(_r, !_netMiss.hit, "catch: the net reached a specimen outside it");
    // And a caught specimen cannot be caught again, or the cabinet fills from one swing.
    var _taken = cht_catch_take(_calmSt);
    cht_st_ok(_r, _taken.mode == CHT_MODE_CAUGHT, "catch: cht_catch_take did not set CAUGHT");
    cht_st_ok(_r, !cht_catch_net(_taken, 0, 0, 1.0).hit,
              "catch: a specimen already in the net was caught a second time");
    // Every condition band is reachable from a real swing quality, or a band is dead code.
    var _bandSeen = array_create(4, 0);
    for (_k = 0; _k <= 100; _k++) _bandSeen[cht_catch_condition(_k / 100)] = 1;
    var _bandsMissing = 0;
    for (_k = 0; _k < 4; _k++) if (_bandSeen[_k] == 0) _bandsMissing += 1;
    cht_st_ok(_r, _bandsMissing == 0,
              "catch: " + string(_bandsMissing) + " condition band(s) are unreachable");

    // -- STAGE 14: THE CABINET -----------------------------------------------------------------
    global.cht_stage = 14;
    var _cab = cht_cabinet_new();
    cht_st_ok(_r, cht_cabinet_count(_cab) == 0 && cht_cabinet_score(_cab) == 0,
              "cabinet: a new cabinet is not empty");
    cht_st_ok(_r, array_length(cht_cabinet_gaps(_cab)) == cht_species_n(),
              "cabinet: a new cabinet does not report every species as a gap");

    // ⛔ THE VALUE-SEMANTICS ASSERTION, AND IT IS THE ONE THAT WOULD HAVE CAUGHT THE DEFECT THIS
    // FILE'S HEADER IS ABOUT. GML arrays are references: a mutator that writes through the array it
    // was handed corrupts the caller's copy, every save-state taken from it, and any preview screen
    // - silently, and only under undo.
    var _cab1 = cht_cabinet_pin(_cab, 4, 2);
    cht_st_ok(_r, cht_cabinet_count(_cab) == 0,
              "cabinet: pinning mutated the cabinet it was given - arrays are by reference in GML");
    cht_st_ok(_r, cht_cabinet_count(_cab1) == 1, "cabinet: pinning did not record the specimen");

    // Best condition is KEPT, not overwritten.
    var _cab2 = cht_cabinet_pin(_cab1, 4, 3);
    var _cab3 = cht_cabinet_pin(_cab2, 4, 0);
    cht_st_ok(_r, _cab3.best[4] == 3, "cabinet: a worse specimen overwrote a better one");
    cht_st_ok(_r, _cab3.taken[4] == 3, "cabinet: the catch count did not rise");

    // The score respects difficulty, and completion tracks it.
    var _cheap = cht_cabinet_pin(cht_cabinet_new(), 23, 3);   // flea beetle, common
    var _dear  = cht_cabinet_pin(cht_cabinet_new(), 33, 3);   // purple emperor, rare and hard
    cht_st_ok(_r, cht_cabinet_score(_dear) > cht_cabinet_score(_cheap),
              "cabinet: a purple emperor scores no more than a flea beetle");

    // ⛔⛔ THE BREADTH INCENTIVE, MEASURED AT BOTH EXTREMES OVER THE WHOLE ROSTER RATHER THAN
    // ASSERTED ON A NAMED PAIR. The design property the collection rests on is that a species you
    // have NEVER caught, in the WORST condition, is always worth more than upgrading a specimen you
    // already have by one grade - otherwise the optimal play is to farm the nearest nettle forever.
    //
    // ⭐ IT REPLACES AN ASSERTION THAT WENT RED FOR THE RIGHT REASON. The first version claimed a
    // damaged rare beats a perfect common, which the arithmetic simply does not say (192 against
    // 294) because rarity and catch difficulty are deliberately different axes. A design claim
    // nobody computed is a green lie waiting for a build; this one is computed here, from the
    // shipped scoring function, at its own worst case.
    var _minNew = 999999, _maxUpgrade = 0, _minNewName = "", _maxUpName = "";
    for (_i = 0; _i < cht_species_n(); _i++) {
        var _empty = cht_cabinet_new();
        var _newVal = cht_cabinet_score(cht_cabinet_pin(_empty, _i, 0));
        if (_newVal < _minNew) { _minNew = _newVal; _minNewName = cht_name_of(cht_species_names(), _i); }
        for (_k = 0; _k < 3; _k++) {
            var _lo = cht_cabinet_score(cht_cabinet_pin(_empty, _i, _k));
            var _hi = cht_cabinet_score(cht_cabinet_pin(_empty, _i, _k + 1));
            if (_hi - _lo > _maxUpgrade) {
                _maxUpgrade = _hi - _lo;
                _maxUpName = cht_name_of(cht_species_names(), _i);
            }
        }
    }
    cht_st_ok(_r, _minNew > _maxUpgrade,
              "cabinet: the cheapest NEW species (" + _minNewName + ", " + string(_minNew)
              + " points damaged) is worth no more than the best single UPGRADE ("
              + _maxUpName + ", " + string(_maxUpgrade)
              + ") - the optimal play is to farm one species instead of collecting");

    // A full cabinet scores exactly the published maximum. Two expressions of one number, checked
    // rather than trusted - a progress bar divides by the second one.
    var _full = cht_cabinet_new();
    for (_i = 0; _i < cht_species_n(); _i++) _full = cht_cabinet_pin(_full, _i, 3);
    cht_st_ok(_r, cht_cabinet_complete(_full) == 1, "cabinet: a full cabinet is not complete");
    cht_st_ok(_r, abs(cht_cabinet_score(_full) - cht_cabinet_score_max()) <= 1,
              "cabinet: a perfect cabinet scores " + string(cht_cabinet_score(_full))
              + " against a published maximum of " + string(cht_cabinet_score_max()));
    cht_st_ok(_r, array_length(cht_cabinet_gaps(_full)) == 0,
              "cabinet: a full cabinet still reports gaps");

    // The drawers must partition the roster exactly - no species in two drawers, none in none.
    var _dr = cht_cabinet_drawers();
    var _covered = 0;
    for (_k = 0; _k < array_length(_dr); _k++) _covered += _dr[_k].n;
    cht_st_ok(_r, _covered == cht_species_n(),
              "cabinet: the drawers cover " + string(_covered) + " of " + string(cht_species_n()));
    cht_st_ok(_r, array_length(_dr) >= 3,
              "cabinet: only " + string(array_length(_dr)) + " drawer(s) - the groups have merged");
    for (_k = 1; _k < array_length(_dr); _k++) {
        cht_st_ok(_r, _dr[_k].from == _dr[_k - 1].to + 1, "cabinet: drawer ranges have a hole");
    }

    // Display state: every Lepidopteran is SET, every beetle is PINNED.
    for (_i = 0; _i < cht_species_n(); _i++) {
        var _plan2 = cht_species_spec(_i).plan;
        var _want = (_plan2 == CHT_PLAN_SPREAD || _plan2 == CHT_PLAN_FOLDED)
                  ? CHT_STATE_SPREAD : CHT_STATE_PINNED;
        cht_st_ok(_r, cht_display_state(_i) == _want,
                  cht_name_of(cht_species_names(), _i) + ": wrong display state");
    }

    // LAYOUT. Every cell inside the rect, none overlapping, and the grid filling it.
    var _cells2 = cht_cabinet_layout(48, 8, 100, 200, 800, 400, 10);
    cht_st_ok(_r, array_length(_cells2) == 48, "cabinet: layout produced the wrong cell count");
    var _outside = 0, _overlap = 0;
    for (_k = 0; _k < array_length(_cells2); _k++) {
        var _c2 = _cells2[_k];
        if (_c2.x < 100 - CHT_ST_EPS || _c2.y < 200 - CHT_ST_EPS
            || _c2.x + _c2.w > 900 + CHT_ST_EPS || _c2.y + _c2.h > 600 + CHT_ST_EPS) _outside += 1;
        for (var _m = _k + 1; _m < array_length(_cells2); _m++) {
            var _d2 = _cells2[_m];
            if (_c2.x < _d2.x + _d2.w - CHT_ST_EPS && _d2.x < _c2.x + _c2.w - CHT_ST_EPS
                && _c2.y < _d2.y + _d2.h - CHT_ST_EPS && _d2.y < _c2.y + _c2.h - CHT_ST_EPS) {
                _overlap += 1;
            }
        }
    }
    cht_st_ok(_r, _outside == 0, "cabinet: " + string(_outside) + " cell(s) fall outside the rect");
    cht_st_ok(_r, _overlap == 0, "cabinet: " + string(_overlap) + " overlapping cell pair(s)");
    cht_st_ok(_r, array_length(cht_cabinet_layout(0, 8, 0, 0, 10, 10, 2)) == 0,
              "VACUITY cabinet: laying out zero cells produced cells");

    // THE GHOST SLOT. It is the reason an empty drawer reads as something to finish, so it must
    // actually be geometry - and it must fit the compartment it is drawn in.
    var _ghost = cht_cabinet_ghost_parts();
    cht_st_ok(_r, array_length(_ghost) >= 6,
              "cabinet: the empty-slot pin drew " + string(array_length(_ghost)) + " parts");
    var _gb = cht_render_bounds(_ghost);
    cht_st_ok(_r, _gb[0] >= -0.01 && _gb[1] >= -0.01 && _gb[2] <= 1.01 && _gb[3] <= 1.01,
              "cabinet: the empty-slot pin leaves the unit box");

    // The gaps-now screens must be subsets of what is actually out, and must shrink as the cabinet
    // fills. This is the one query that ties all three system layers together.
    var _gn = cht_cabinet_gaps_now(cht_cabinet_new(), 0, 3, 2, CHT_WX_CLEAR);
    cht_st_ok(_r, array_length(_gn) == array_length(_busy),
              "cabinet: an empty cabinet's gaps-now list is not the whole available list");
    var _gnFull = cht_cabinet_gaps_now(_full, 0, 3, 2, CHT_WX_CLEAR);
    cht_st_ok(_r, array_length(_gnFull) == 0, "cabinet: a full cabinet still has gaps in the field");
    var _upFull = cht_cabinet_upgrades_now(_full, 0, 3, 2, CHT_WX_CLEAR);
    cht_st_ok(_r, array_length(_upFull) == 0,
              "cabinet: a perfect cabinet still offers upgrades");
    var _oneWorn = cht_cabinet_pin(cht_cabinet_new(), _busy[0].i, 1);
    cht_st_ok(_r, array_length(cht_cabinet_upgrades_now(_oneWorn, 0, 3, 2, CHT_WX_CLEAR)) == 1,
              "cabinet: a worn specimen of an available species is not offered as an upgrade");

    global.cht_stage = 99;
    return {
        pass: _r.pass, fail: _r.fail, notes: _r.notes,
        worstD: _worstD, worstA: _worstA, worstB: _worstB,
        tightest: _tightest, tightestName: _tightestName,
        pairs: _pairs, samePlan: _same, below: _below, exempt: _exempt,
        tA: _tA, tB: _tB, tD: _tD, hist: _hist,
        creepWins: _creepWins, creepLoses: _creepLoses,
        gainMean: _gainSum / max(1, cht_species_n()), gainMax: _gainMax, gainName: _gainName,
        widest: _widest, narrowest: _narrowest, identMinMarks: _minMarks
    };
}

/// ============================================================================================
/// HELPERS
/// ============================================================================================

/// The two wing specs of a shape family, exactly as cht_wing_pair builds them.
///
/// ⚠️ IT CALLS cht_wing_pair_specs RATHER THAN RESTATING THE NUMBERS. A suite that holds its own
/// copy of the values it is testing certifies the staleness it exists to catch - this factory has a
/// live receipt for that, on a listing that sold a pack at half its real size because a checker
/// held the same stale literal the page held.
function _cht_st_wings(_shape) {
    return cht_wing_pair_specs(_shape);
}

/// Is a circle of radius _rr at (_x,_y) in WING space entirely inside the wing?
///
/// The honest test rather than a restatement of what the clipper computes: sample the circle's own
/// vertical extent at eleven stations across its width and require both to lie between the two
/// edges there. A spot that fits at its centre and pokes out at its shoulder fails here.
function _cht_st_circle_in_wing(_w, _x, _y, _rr) {
    for (var _i = 0; _i <= 10; _i++) {
        var _dx = -_rr + 2 * _rr * (_i / 10);
        var _h = sqrt(max(0, _rr * _rr - _dx * _dx));
        var _s = (_x + _dx) / max(0.0001, _w.span);
        if (_s < 0 || _s > 1) return false;
        if (_y - _h < cht_wing_lead(_w, _s) - CHT_ST_EPS) return false;
        if (_y + _h > cht_wing_trail(_w, _s) + CHT_ST_EPS) return false;
    }
    return true;
}

/// The hue of a packed colour, in degrees, via Oklab. Assertions only.
function _cht_st_hue_of(_col) {
    var _r = colour_get_red(_col) / 255;
    var _g = colour_get_green(_col) / 255;
    var _b = colour_get_blue(_col) / 255;
    _r = (_r <= 0.04045) ? (_r / 12.92) : power((_r + 0.055) / 1.055, 2.4);
    _g = (_g <= 0.04045) ? (_g / 12.92) : power((_g + 0.055) / 1.055, 2.4);
    _b = (_b <= 0.04045) ? (_b / 12.92) : power((_b + 0.055) / 1.055, 2.4);
    var _l = power(max(0, 0.4122214708 * _r + 0.5363325363 * _g + 0.0514459929 * _b), 1 / 3);
    var _m = power(max(0, 0.2119034982 * _r + 0.6806995451 * _g + 0.1073969566 * _b), 1 / 3);
    var _s = power(max(0, 0.0883024619 * _r + 0.2817188376 * _g + 0.6299787005 * _b), 1 / 3);
    var _A = 1.9779984951 * _l - 2.4285922050 * _m + 0.4505937099 * _s;
    var _B = 0.0259040371 * _l + 0.7827717662 * _m - 0.8086757660 * _s;
    var _h = radtodeg(arctan2(_B, _A));
    while (_h < 0) _h += 360;
    return _h;
}

/// ⛔ THE PAIRS THIS CORPUS DELIBERATELY DRAWS ALIKE, WITH THE REASON, BY NAME.
///
/// An exemption is a CLAIM ABOUT THE WORLD - that these two insects genuinely resemble each other -
/// and it is the only way this sweep can be made green dishonestly, so it is kept to almost
/// nothing and the suite asserts its own size. The two ladybirds share every body number to the
/// digit because that IS the relationship between them: for a lookalike pair everything that is not
/// the tell must be authored identical, or a proportion difference disagrees across the whole
/// animal while the tell occupies one spot. They must still be MEASURABLY apart, which is asserted
/// separately - an exemption buys a lower bar, never no bar.
function _cht_st_lookalike(_i, _j) {
    var _a = min(_i, _j), _b = max(_i, _j);
    if (_a == 12 && _b == 13) return true;    // seven spot ladybird / eyed ladybird
    return false;
}

/// ============================================================================================
/// THE COLLISION SIGNATURE
///
/// ⛔ BUILT FROM THE DRAWING, NEVER FROM THE ROW. Scoring two species on the numbers they were
/// authored with answers "were these typed differently", which is not the question. Stamping the
/// geometry answers "do these produce the same picture", which is.
///
/// ⛔⛔ AND ITS FIRST VERSION WAS ONE GRID, WHICH READ THE TWO LADYBIRDS AS EXACTLY 0.000 APART.
///
/// MEASURED on this suite's first run. A single occupancy grid is a SILHOUETTE map, and the two
/// ladybirds share every body number to the digit by design - so their silhouettes are identical,
/// their cuticle is the same, and the seven black spots of one against the four ringed ocelli of
/// the other landed in cells the body's own shading strips had already filled. The distance was not
/// small, it was ZERO: the metric could not see the only thing that distinguishes them.
///
/// ⭐ THAT IS THIS WING'S OWN STANDING LAW ARRIVING AS A MEASUREMENT PROBLEM: a difference drawn
/// inside a filled shape is not a difference in the shape. The answer is not a better threshold, it
/// is a SECOND grid built only from the marks. Two species now differ if their outlines differ, if
/// their MARKINGS differ, or if their colour differs, and the three are weighted separately.
///
/// ⚠️ The mark grid keys on the `ink` role, which is what every patterning program in this package
/// writes with and nothing structural uses. It is deliberately a narrow definition: including the
/// relief stops would fold the body's own shading back in and undo the split.
/// ============================================================================================

/// One species' signature at cabinet size - the size at which a collision actually costs a buyer.
function _cht_st_signature(_i) {
    var _g = array_create(CHT_ST_GRID * CHT_ST_GRID, 0);
    var _mk = array_create(CHT_ST_GRID * CHT_ST_GRID, 0);
    var _parts = cht_species_parts(_i, 96, 0.50);
    var _n = array_length(_parts);
    var _hits = 0, _marks = 0;
    for (var _k = 0; _k < _n; _k++) {
        var _isMark = (_parts[_k].role == "ink");
        var _pts = _cht_st_points(_parts[_k]);
        for (var _q = 0; _q < array_length(_pts); _q++) {
            var _gx = floor((_pts[_q][0] + 0.5) * CHT_ST_GRID);
            var _gy = floor((_pts[_q][1] + 0.5) * CHT_ST_GRID);
            if (_gx < 0 || _gx >= CHT_ST_GRID || _gy < 0 || _gy >= CHT_ST_GRID) continue;
            var _o = _gy * CHT_ST_GRID + _gx;
            if (_g[_o] == 0) { _g[_o] = 1; _hits += 1; }
            if (_isMark && _mk[_o] == 0) { _mk[_o] = 1; _marks += 1; }
        }
    }
    var _cut = cht_cuticle_spec(cht_species_spec(_i).cut);
    var _base = cht_chroma_base(_cut);
    return { g: _g, mk: _mk, n: _hits, marks: _marks,
             L: _base.L,
             a: _base.C * cos(degtorad(_base.h)),
             b: _base.C * sin(degtorad(_base.h)) };
}

/// Every point a part occupies, as one flat list.
///
/// ⚠️ A DOT CONTRIBUTES FIVE POINTS, NOT ONE. A spot is a real area on the animal and returning
/// only its centre made every mark a single grid cell wherever it was drawn, which is most of why
/// the marks were invisible to the first metric. The four rim points put a mark's actual FOOTPRINT
/// into the grid.
function _cht_st_points(_p) {
    switch (_p.kind) {
        case CHT_DOT: return [[_p.cx, _p.cy],
                              [_p.cx - _p.r, _p.cy], [_p.cx + _p.r, _p.cy],
                              [_p.cx, _p.cy - _p.r], [_p.cx, _p.cy + _p.r]];
        case CHT_ARC: return [[_p.cx, _p.cy]];
        case CHT_STRIP: {
            var _out = [];
            for (var _i = 0; _i < array_length(_p.a); _i++) array_push(_out, _p.a[_i]);
            for (var _i = 0; _i < array_length(_p.b); _i++) array_push(_out, _p.b[_i]);
            return _out;
        }
        default: return _p.pts;
    }
}

/// Jaccard distance between two occupancy grids, 0 identical .. 1 disjoint.
function _cht_st_jaccard(_a, _b) {
    var _inter = 0, _union = 0;
    for (var _i = 0; _i < CHT_ST_GRID * CHT_ST_GRID; _i++) {
        if (_a[_i] == 1 && _b[_i] == 1) _inter += 1;
        if (_a[_i] == 1 || _b[_i] == 1) _union += 1;
    }
    return (_union > 0) ? (1 - _inter / _union) : 0;
}

/// How different two species look, 0 identical .. 1 unrelated.
///
/// Silhouette carries the most because that is what a buyer sees in a cabinet grid at 90 pixels;
/// MARKINGS come next, because within one body plan they are usually the whole difference; colour
/// last, measured in Oklab, where a fixed distance means roughly the same perceived difference
/// wherever it lands.
function _cht_st_distance(_p, _q) {
    var _shape = _cht_st_jaccard(_p.g, _q.g);
    // Two plain species have no marks at all, and "neither of us has markings" must not score as a
    // difference - the Jaccard of two empty sets is defined as 0 here for exactly that reason.
    var _mark = _cht_st_jaccard(_p.mk, _q.mk);
    var _dl = _p.L - _q.L, _da = _p.a - _q.a, _db = _p.b - _q.b;
    var _col = clamp(sqrt(_dl * _dl + _da * _da + _db * _db) / 0.55, 0, 1);
    return 0.50 * _shape + 0.22 * _mark + 0.28 * _col;
}

/// ============================================================================================
/// THE RESULT FILE
///
/// ⛔ A SANDBOXED FILE WRITE IS THE ONLY ROUTE THAT SURVIVES A RELEASE BUILD. Measured in this
/// wing: show_debug_message plus -debugoutput writes only engine boot lines, and game_end(n) does
/// not propagate n to the process exit code.
/// ============================================================================================
function cht_selftest_write(_res) {
    var _f = file_text_open_write("cht_selftest.json");
    var _notes = "";
    for (var _i = 0; _i < array_length(_res.notes); _i++) {
        if (_i > 0) _notes += " | ";
        _notes += string_replace_all(string(_res.notes[_i]), "\"", "'");
    }
    var _hs = "";
    for (var _k = 0; _k < 20; _k++) {
        if (_k > 0) _hs += ",";
        _hs += string(_res.hist[_k]);
    }
    var _worst = "";
    for (var _k = 0; _k < 8; _k++) {
        if (_res.tA[_k] < 0) continue;
        if (_worst != "") _worst += " | ";
        _worst += cht_name_of(cht_species_names(), _res.tA[_k]) + " / "
                + cht_name_of(cht_species_names(), _res.tB[_k]) + " "
                + string_format(_res.tD[_k], 1, 3);
    }
    file_text_write_string(_f,
        "{\"pass\":" + string(_res.pass)
        + ",\"fail\":" + string(_res.fail)
        + ",\"stage\":" + string(global.cht_stage)
        + ",\"epsilon\":" + string_format(math_get_epsilon(), 1, 12)
        + ",\"species\":" + string(cht_species_n())
        + ",\"forms\":" + string(cht_corpus_forms())
        + ",\"drawn\":" + string(cht_corpus_drawn())
        + ",\"pairs\":" + string(_res.pairs)
        + ",\"samePlanPairs\":" + string(_res.samePlan)
        + ",\"pairsBelowFloor\":" + string(_res.below)
        + ",\"pairFloor\":" + string_format(CHT_ST_PAIR_FLOOR, 1, 3)
        + ",\"worstPair\":\"" + _worst + "\""
        + ",\"histBucket\":0.025"
        + ",\"hist\":[" + _hs + "]"
        + ",\"fitTightest\":" + string_format(_res.tightest, 1, 3)
        + ",\"fitTightestName\":\"" + _res.tightestName + "\""
        // The system half's own numbers, so the approach model can be READ rather than only passed
        // or failed. A stage that only ever prints a verdict is a stage nobody can tune.
        + ",\"systems\":" + string(cht_corpus_systems())
        + ",\"creepWins\":" + string(_res.creepWins)
        + ",\"creepLoses\":" + string(_res.creepLoses)
        + ",\"creepGainMean\":" + string_format(_res.gainMean, 1, 3)
        + ",\"creepGainMax\":" + string_format(_res.gainMax, 1, 3)
        + ",\"creepGainMaxName\":\"" + _res.gainName + "\""
        + ",\"fieldCellsWidest\":" + string(_res.widest)
        + ",\"fieldCellsNarrowest\":" + string(_res.narrowest)
        + ",\"identMinMarks\":" + string(_res.identMinMarks)
        + ",\"cabinetScoreMax\":" + string(cht_cabinet_score_max())
        + ",\"version\":\"" + CHT_VERSION + "\""
        + ",\"notes\":\"" + _notes + "\"}");
    file_text_close(_f);
}
