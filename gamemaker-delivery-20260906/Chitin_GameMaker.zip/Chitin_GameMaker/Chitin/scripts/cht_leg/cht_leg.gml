/// CHITIN - cht_leg. SIX LEGS, WHICH IS THE HARDEST DRAWING PROBLEM IN THIS PRODUCT.
///
/// ⛔ THE RESOLUTION FLOOR IS ARITHMETIC AND THIS IS WHERE IT BITES.
///
/// The RPG Maker wing measured it on a 50-figure corpus: an appendage below about 0.05 units of
/// half-width reads as a HAIR, and three hairs read as ONE leg rather than as three. An insect has
/// six legs and two antennae, so this is the densest thin-appendage subject the studio has drawn,
/// and a beetle on a cabinet plate is about 90 px wide.
///
/// Two consequences, both in the code below rather than in a comment:
///
///   1. A leg is not one stroke, it is a TAPERING CHAIN of three masses with visible joints. The
///      femur is genuinely thick - on a real beetle it is the fattest part of the animal after the
///      thorax - and the taper down to the tarsus is what says "leg" rather than "wire".
///   2. cht_leg_fit DROPS legs rather than thinning them. Four legs that read beat six that
///      merge into a grey fringe, and at cabinet-thumbnail size the honest answer is a silhouette
///      with no legs at all.
///
/// ⚠️ AND THEY MUST OVERLAP THE BODY. A leg starting exactly on the outline leaves a hairline of
/// page between limb and animal the moment either is bevelled - six times over. Every root here
/// comes from cht_body_socket, which sinks it under the thorax.
///
/// ⭐ THE PAIRS ARE NOT IDENTICAL AND THAT IS ANATOMY, NOT JITTER. A real insect's front legs are
/// short and turned forward, its middle legs sit square, and its hind legs are the long ones that
/// push - and they trail backward. Drawing three identical pairs is the single loudest way to make
/// six legs read as a centipede.
/// ============================================================================================

#macro CHT_LEG_CURSORIAL  0   // running - long, thin, unarmed. A ground beetle, a cockroach
#macro CHT_LEG_FOSSORIAL  1   // digging - short, broad, toothed tibia. A dung beetle, a mole cricket
#macro CHT_LEG_NATATORIAL 2   // swimming - flattened and fringed with swimming hairs. A diving beetle
#macro CHT_LEG_RAPTORIAL  3   // grasping - a long spined femur that folds against the tibia. A mantis
#macro CHT_LEG_SALTATORIAL 4  // jumping - an enormously thickened hind femur. A flea beetle, a grasshopper
#macro CHT_LEG_N          5

/// Which axis stations the three leg pairs come off. Front legs from the head end of the thorax,
/// middle from its hind margin, hind from the base of the elytra - which is where they are on the
/// animal, and it is what makes the hind pair look like it is pushing the body along.
#macro CHT_LEG_T0 0.235
#macro CHT_LEG_T1 0.365
#macro CHT_LEG_T2 0.470

/// How many of the three pairs to draw at a given drawn body width in pixels.
///
/// ⭐ RETURNED, NOT APPLIED SILENTLY. Same contract as the elytral stria count: the identification
/// screen can say "fossorial" while the cabinet thumbnail draws two pairs, and neither is lying.
/// A level-of-detail decision hidden inside a draw call is one no caller can reason about.
function cht_leg_fit(_px) {
    if (_px >= 150) return 3;
    if (_px >= 78)  return 2;
    if (_px >= 34)  return 1;
    return 0;
}

/// The three segment lengths and thicknesses for one leg form, as fractions of the leg's length.
///
/// Returned as a struct rather than baked into the builder so cht_selftest can assert the
/// proportions per form BY NAME - a raptorial leg whose femur is not the longest segment is not a
/// raptorial leg, and that is a checkable statement.
function cht_leg_spec(_form) {
    switch (clamp(_form, 0, CHT_LEG_N - 1)) {
        case CHT_LEG_FOSSORIAL:
            return { femL: 0.36, tibL: 0.36, tarL: 0.28,
                     femW: 1.55, tibW: 1.70, tarW: 0.55, teeth: 4, fringe: 0, bend: 0.62 };
        case CHT_LEG_NATATORIAL:
            return { femL: 0.34, tibL: 0.40, tarL: 0.26,
                     femW: 1.20, tibW: 1.35, tarW: 1.10, teeth: 0, fringe: 9, bend: 0.34 };
        case CHT_LEG_RAPTORIAL:
            return { femL: 0.48, tibL: 0.34, tarL: 0.18,
                     femW: 1.85, tibW: 0.80, tarW: 0.42, teeth: 6, fringe: 0, bend: 1.15 };
        case CHT_LEG_SALTATORIAL:
            return { femL: 0.42, tibL: 0.40, tarL: 0.18,
                     femW: 2.60, tibW: 0.62, tarW: 0.38, teeth: 0, fringe: 0, bend: 0.95 };
        default:
            return { femL: 0.34, tibL: 0.38, tarL: 0.28,
                     femW: 1.00, tibW: 0.72, tarW: 0.40, teeth: 0, fringe: 0, bend: 0.48 };
    }
}

/// One leg. _pair is 0 (front), 1 (middle) or 2 (hind); _side is -1 or +1.
///
/// The leg is built in the animal's own frame: out from the body, then down and back by the pair's
/// own rake. Every segment is a tapered ribbon and every joint is a small raised boss, because a
/// chain of masses reads as a chain UNLESS the joins are what a joint looks like.
function cht_leg_parts(_form, _sp_body, _pair, _side, _len, _w) {
    var _out = [];
    var _ls = cht_leg_spec(_form);

    // Which station, and which way the leg rakes. See the header: the three pairs differ.
    var _t = CHT_LEG_T0;
    var _rake = -0.62;                      // forward, in radians of extra sweep
    var _scale = 0.86;
    if (_pair == 1) { _t = CHT_LEG_T1; _rake =  0.05; _scale = 1.00; }
    if (_pair == 2) { _t = CHT_LEG_T2; _rake =  0.74; _scale = 1.22; }

    var _root = cht_body_socket(_sp_body, _t, _side, 0.42);
    var _L = _len * _scale;

    // -- coxa/femur: out and slightly forward or back -------------------------------------------
    var _a1 = _rake;
    var _fx = _root[0] + _side * _L * _ls.femL * cos(_a1);
    var _fy = _root[1] + _L * _ls.femL * sin(_a1);
    var _fem = cht_qbez(_root,
        [(_root[0] + _fx) * 0.5 + _side * _L * 0.04, (_root[1] + _fy) * 0.5 - _L * 0.05],
        [_fx, _fy], 8);
    cht_append(_out, cht_taper_ribbon(_fem, _w * _ls.femW, _w * _ls.femW * 0.66, "m2"));

    // -- tibia: the bend. This is the joint that makes a leg look like a leg ---------------------
    var _a2 = _a1 + _ls.bend;
    var _tx = _fx + _side * _L * _ls.tibL * cos(_a2);
    var _ty = _fy + _L * _ls.tibL * sin(_a2);
    var _tib = [[_fx, _fy], [_tx, _ty]];
    cht_append(_out, cht_taper_ribbon(_tib, _w * _ls.tibW, _w * _ls.tibW * 0.62, "m2"));

    // The femur-tibia joint, as a raised boss. Two masses read as two when their SILHOUETTE steps,
    // not when their fill changes - so the boss is wider than both segments meeting in it.
    cht_append(_out, cht_boss(_fx, _fy, _w * max(_ls.femW, _ls.tibW) * 0.92, 8));

    // -- tarsus: thin, and it curves. A straight tarsus reads as a pin ---------------------------
    var _a3 = _a2 + _ls.bend * 0.55;
    var _sx = _tx + _side * _L * _ls.tarL * cos(_a3);
    var _sy = _ty + _L * _ls.tarL * sin(_a3);
    var _tar = cht_qbez([_tx, _ty],
        [_tx + _side * _L * _ls.tarL * 0.55 * cos(_a2), _ty + _L * _ls.tarL * 0.55 * sin(_a2)],
        [_sx, _sy], 8);
    cht_append(_out, cht_taper_ribbon(_tar, _w * _ls.tarW, _w * _ls.tarW * 0.44, "m1"));

    // -- the form's own armament ----------------------------------------------------------------
    // Digging teeth on the outer edge of the tibia. A fossorial leg without them is just a short
    // leg, and "short leg" is not a field mark anyone can use.
    if (_ls.teeth > 0) {
        var _dx = _tx - _fx, _dy = _ty - _fy;
        var _dl = max(0.0001, point_distance(0, 0, _dx, _dy));
        var _nx = -_dy / _dl, _ny = _dx / _dl;
        for (var _k = 0; _k < _ls.teeth; _k++) {
            var _u = 0.26 + 0.66 * (_k / max(1, _ls.teeth - 1));
            var _bx = _fx + _dx * _u, _by = _fy + _dy * _u;
            var _tl = _w * _ls.tibW * (2.6 - 1.1 * _u);
            cht_append(_out, cht_taper_ribbon(
                [[_bx, _by], [_bx + _nx * _tl * _side, _by + _ny * _tl * _side]],
                _w * 0.62, _w * 0.16, "m3"));
        }
    }

    // Swimming hairs. Fine, many, and along BOTH the tibia and the tarsus - a fringe on one
    // segment reads as damage rather than as an oar.
    if (_ls.fringe > 0) {
        var _dx2 = _sx - _fx, _dy2 = _sy - _fy;
        var _dl2 = max(0.0001, point_distance(0, 0, _dx2, _dy2));
        var _nx2 = -_dy2 / _dl2, _ny2 = _dx2 / _dl2;
        for (var _k = 0; _k < _ls.fringe; _k++) {
            var _u = 0.20 + 0.74 * (_k / max(1, _ls.fringe - 1));
            var _bx = _fx + _dx2 * _u, _by = _fy + _dy2 * _u;
            var _hl = _w * 3.4 * sin(_u * pi) + _w * 0.7;
            cht_append(_out, cht_taper_ribbon(
                [[_bx, _by], [_bx + _nx2 * _hl * _side, _by + _ny2 * _hl * _side]],
                _w * 0.30, _w * 0.09, "m1"));
        }
    }

    return _out;
}

/// All the legs the drawn size can honestly carry, both sides.
///
/// ⚠️ THE PAIRS ARE DROPPED FROM THE FRONT, NOT THE BACK. If only one pair can be drawn it should
/// be the HIND pair: it is the longest, it sits where the eye expects the animal's push to come
/// from, and a beetle with only front legs reads as damaged.
function cht_legs_parts(_form, _sp_body, _len, _w, _px) {
    var _out = [];
    var _n = cht_leg_fit(_px);
    for (var _p = 2; _p > 2 - _n; _p--) {
        for (var _s = -1; _s <= 1; _s += 2) {
            cht_append(_out, cht_leg_parts(_form, _sp_body, _p, _s, _len, _w));
        }
    }
    return _out;
}
