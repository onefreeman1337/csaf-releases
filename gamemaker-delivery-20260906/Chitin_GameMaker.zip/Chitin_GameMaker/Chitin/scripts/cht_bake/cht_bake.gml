/// CHITIN - cht_bake. RENDER EVERY IMAGE THROUGH THE PRODUCT ITSELF.
///
/// NEVER SHIPS AS A FEATURE - it is in the package because it must be built by the same compiler
/// as the thing it photographs, and because a listing that says "every image on this page was
/// rendered by the product" has to be literally true.
///
/// ⛔ A GALLERY RENDERED BY A SIDE PREVIEWER IS A PICTURE OF A RE-IMPLEMENTATION. This wing
/// measured that on a previous product whose JavaScript previewer carried a defect invisible in
/// the previewer and plainly visible in engine.
///
/// -- THE TWO PREVIEW MODES, AND WHY THEY EXIST BEFORE THE STORE SHEETS DO -------------------
///
/// The architecture note written at promotion says, in these words: build the big preview and look
/// at ONE beetle at cabinet size BEFORE authoring species 2. The reason is a measured one, carried
/// in from a 50-figure corpus in another wing: A COLLISION IS A CORPUS PROPERTY AND ONLY A CONTACT
/// SHEET CAN SEE IT, and 48 species is 1,128 pairs. Authoring forty-eight animals and then
/// discovering the drawing does not work is the expensive order.
///
///   -big <id>   ONE species, as large as the page allows, with its own numbers printed beside it.
///               This is the instrument for "is this a beetle or is it a shape".
///   -contact    ALL of them at cabinet size in one grid. This is the instrument for "are these
///               forty-eight animals or one animal in forty-eight colours".
///
/// ⚠️ THE INK BOX STEPS y BY 1, NOT BY 2. This wing shipped a clipped hairline because an
/// even-only scan walked past a 1 px feature on an odd row - and a clipped hairline is exactly the
/// shape that lands on one row. Stepping x by 2 is fine; nothing here draws a 1 px vertical.
/// ============================================================================================

#macro CHT_SHEET_W 1600
#macro CHT_SHEET_H 1000
#macro CHT_BIG_W    900
#macro CHT_BIG_H    900

/// itch's cover slot. 630x500 is the size itch itself states, and the aspect is what a browse row
/// crops to - a cover authored at any other ratio gets centre-cropped by the store and loses its
/// title block.
#macro CHT_COVER_W  630
#macro CHT_COVER_H  500

/// The page. A dark, slightly blue ground: an entomological drawer is dark, and every cuticle in
/// the corpus - including the chalk white one - has to sit on it legibly.
function cht_bk_page() { return cht_oklch(0.140, 0.008, 262); }
function cht_bk_ink()  { return cht_oklch(0.900, 0.010, 262); }
function cht_bk_dim()  { return cht_oklch(0.560, 0.010, 262); }
function cht_bk_rule() { return cht_oklch(0.305, 0.012, 262); }

/// A sheet heading. Returns the y the content may start at.
///
/// ⛔ cht_text_label DRAWS AT THE x IT IS GIVEN - it does not centre on it. Pass a LEFT edge; a
/// donor product shipped titles running off the right margin because the page midpoint was passed
/// here and the short titles looked deliberately centred.
function cht_bk_head(_title, _sub, _y, _w) {
    cht_text_label(_title, 60, _y, _w - 120, 46, cht_bk_page(), cht_bk_ink());
    var _yy = _y + 58;
    if (_sub != "") {
        cht_text_body(_sub, 60, _yy, _w - 420, 19, cht_bk_dim());
        _yy += 30;
    }
    draw_set_colour(cht_bk_rule());
    draw_rectangle(60, _yy + 14, _w - 60, _yy + 15, false);
    return _yy + 40;
}

/// A recessed well for a specimen cell - a drawer compartment.
function cht_bk_well(_x, _y, _w, _h) {
    draw_set_colour(cht_oklch(0.185, 0.009, 262));
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);
    draw_set_colour(cht_bk_rule());
    draw_rectangle(_x, _y, _x + _w, _y + _h, true);
}

/// The ink bounding box over the current render target. Two boxes: `full` for the clip test and
/// `content` (below the title rule) for the coverage floors, so a full-width rule cannot satisfy
/// the floors on the picture's behalf.
function cht_bk_ink_bounds(_w, _h, _contentY) {
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, surface_get_target(), 0);
    var _pg = cht_bk_page();
    var _pr = colour_get_red(_pg), _pgn = colour_get_green(_pg), _pb = colour_get_blue(_pg);

    var _fx0 = _w, _fy0 = _h, _fx1 = -1, _fy1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;
    var _ink = 0;

    for (var _y = 0; _y < _h; _y++) {
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = (_y * _w + _x) * 4;
            var _r = buffer_peek(_buf, _o, buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_r - _pr) <= 10 && abs(_g - _pgn) <= 10 && abs(_b - _pb) <= 10) continue;
            _ink += 1;
            if (_x < _fx0) _fx0 = _x;
            if (_x > _fx1) _fx1 = _x;
            if (_y < _fy0) _fy0 = _y;
            if (_y > _fy1) _fy1 = _y;
            if (_y >= _contentY) {
                if (_x < _cx0) _cx0 = _x;
                if (_x > _cx1) _cx1 = _x;
                if (_y < _cy0) _cy0 = _y;
                if (_y > _cy1) _cy1 = _y;
            }
        }
    }
    buffer_delete(_buf);
    return { full: [_fx0, _fy0, _fx1, _fy1], content: [_cx0, _cy0, _cx1, _cy1], ink: _ink };
}

/// ============================================================================================
/// THE BIG PREVIEW - one animal, as large as the page allows
/// ============================================================================================

/// Draw one species into a rect at a stated drawn width, and return the parts count so the caller
/// can see that work actually happened.
///
/// ⛔ THE DRAWN WIDTH IS PASSED IN, NOT MEASURED AFTERWARDS. Every level-of-detail decision in the
/// package - stria count, leg pairs, shimmer bands - is made from it, so a caller that guesses it
/// gets a picture drawn for a size it is not being shown at. This is the one number a cell must
/// compute honestly.
function cht_bk_specimen(_i, _x, _y, _w, _h, _phase) {
    var _px = min(_w, _h);
    var _parts = cht_species_parts(_i, _px, _phase);
    var _pal = cht_species_palette(_i, _phase, _px);
    cht_render_in_rect(_parts, _pal, _x, _y, _w, _h, 0, cht_species_map());
    return array_length(_parts);
}

/// ONE SPECIES, HUGE, with its own numbers printed beside it.
///
/// The numbers are DERIVED from the same spec the drawing came from, never typed. A caption that
/// restates a constant is the defect this factory keeps paying for: a checker that holds the same
/// stale literal the page holds certifies the staleness it exists to catch.
function cht_bk_big(_i, _phase) {
    var _y = cht_bk_head("CHITIN - " + cht_name_of(cht_species_names(), _i),
        "One specimen, drawn from its own numbers.", 46, CHT_BIG_W);

    var _sp = cht_species_spec(_i);
    var _cut = cht_cuticle_spec(_sp.cut);

    // ⛔ 620, NOT 780, AND THE REASON IS THAT cht_bk_specimen FITS THE SQUARE. It takes
    // `min(_w, _h)` as the drawn width, so a 780x520 well draws a 472 px animal with 154 px of
    // empty page down EACH SIDE - a third of the well, on the one plate whose entire job is to show
    // one animal as large as the page allows. preflight reported it as THIN and it is: the ink
    // bounding box spans the frame (the well's own border sees to that) while the inside is mostly
    // nothing. A well shaped like the thing it holds is the fix; cropping the plate is not.
    var _boxw = 620;
    // ⚠️ 520 AND A 24 px PITCH, MEASURED AGAINST THE PAGE. At 560 with a 26 px pitch the seventh
    // caption line started at y=918 on a 900 px page and was cut in half - which the sheet's own
    // clip test reported as `clipped=True` and which is visible in every big preview this product
    // has produced. A caption block is content and it has to fit.
    var _boxh = 520;
    // Centred, because a 620-wide well left-aligned on a 900 page is a plate with a margin problem
    // instead of a plate with a dead-space problem.
    var _bx = round((CHT_BIG_W - _boxw) * 0.5);
    cht_bk_well(_bx, _y, _boxw, _boxh);
    var _n = cht_bk_specimen(_i, _bx + 24, _y + 24, _boxw - 48, _boxh - 48, _phase);

    var _ly = _y + _boxh + 26;
    var _lines = [
        "plan       " + cht_name_of(cht_plan_names(), _sp.plan),
        // ⛔ NOT `min(4, _sp.cut)`. That clamp shipped on this plate and captioned every cuticle
        // above index 4 as "structural" - see cht_cuticle_names. A caption is a claim.
        "cuticle    " + cht_name_of(cht_cuticle_names(), _sp.cut),
        "antenna    " + cht_name_of(cht_antenna_names(), _sp.ant),
        "leg        " + cht_name_of(cht_leg_names(), _sp.leg),
        "sculpture  " + cht_name_of(cht_sculpture_names(), _sp.scu) + "  x" + string(_sp.scun),
        "pattern    " + cht_name_of(cht_pattern_names(), _sp.pat) + "  x" + string(_sp.patn),
        "iridescent " + string_format(_cut.irid, 1, 2)
                      + "   parts drawn " + string(_n),
    ];
    for (var _k = 0; _k < array_length(_lines); _k++) {
        cht_text_line(_lines[_k], 60, _ly + _k * 24, _boxw, 19, cht_bk_dim(), false);
    }
    return _ly + array_length(_lines) * 24 + 10;
}

/// ============================================================================================
/// THE CONTACT SHEET - every species at cabinet size
///
/// ⛔ THIS IS THE INSTRUMENT FOR THE ONLY QUESTION THAT MATTERS ABOUT A CORPUS: are these 48
/// animals, or one animal 48 times? The eye finds the collision it happens to land on; this sheet
/// is what puts every pair in front of it at once. The pairwise metric in cht_selftest is the
/// follow-up, not the substitute - a measured sweep finds the worst pair, and looking finds the
/// pair that is wrong in a way no metric was written for.
/// ============================================================================================
function cht_bk_contact(_phase) {
    var _y = cht_bk_head("CHITIN - " + cht_corpus_line(),
        "Every species in the package, at the size a cabinet plate draws it.", 46, CHT_SHEET_W);

    var _n = cht_species_n();
    var _cols = 8;
    var _rows = ceil(_n / _cols);
    var _pad = 10;
    var _cw = (CHT_SHEET_W - 120 - _pad * (_cols - 1)) / _cols;
    var _ch = (CHT_SHEET_H - _y - 40 - _pad * (_rows - 1)) / _rows;

    for (var _i = 0; _i < _n; _i++) {
        var _cx = 60 + (_i % _cols) * (_cw + _pad);
        var _cy = _y + floor(_i / _cols) * (_ch + _pad);
        cht_bk_well(_cx, _cy, _cw, _ch);
        cht_bk_specimen(_i, _cx + 6, _cy + 6, _cw - 12, _ch - 26, _phase);
        cht_text_line(cht_name_of(cht_species_names(), _i),
            _cx + 4, _cy + _ch - 19, _cw - 8, 12, cht_bk_dim(), false);
    }
    return _y + _rows * (_ch + _pad);
}

/// ============================================================================================
/// THE CABINET PLATE - the drawer, with its gaps showing
///
/// ⭐ THIS IS THE PLATE THAT SELLS THE PRODUCT RATHER THAN THE CORPUS, and it could not be drawn
/// until cht_cabinet existed. A contact sheet says "here are 48 insects", which is an art pack; a
/// drawer with four empty compartments in it says "here is a game about filling this", which is
/// what the shelf pays for. Wing CLAUDE.md §2, measured over 646 assets and again over 2,131:
/// complete systems clear the band and single-behaviour utilities do not.
///
/// ⛔ THE EMPTY SLOTS ARE DRAWN, NOT LISTED, and they are drawn through the SAME render path as a
/// specimen - cht_cabinet_ghost_parts returns a parts array exactly like cht_species_parts does.
/// A "missing" caption in dim text would have been four lines and would have sold nothing.
/// ============================================================================================

/// A neutral steel ramp for the pin and label, so the empty slot is not tinted by whichever
/// species happens to be beside it.
function cht_bk_ghost_pal() {
    var _p = {};
    variable_struct_set(_p, "c0", cht_oklch(0.200, 0.006, 262));
    variable_struct_set(_p, "c1", cht_oklch(0.330, 0.006, 262));
    variable_struct_set(_p, "c2", cht_oklch(0.440, 0.005, 262));
    variable_struct_set(_p, "c3", cht_oklch(0.560, 0.005, 262));
    variable_struct_set(_p, "c4", cht_oklch(0.680, 0.004, 262));
    variable_struct_set(_p, "line", cht_oklch(0.120, 0.008, 262));
    variable_struct_set(_p, "ink", cht_oklch(0.700, 0.006, 262));
    return _p;
}

/// One drawer of the cabinet. `_cab` decides which compartments are full.
function cht_bk_cabinet(_cab, _drawer, _phase, _w, _h) {
    var _dr = cht_cabinet_drawers();
    var _d = _dr[clamp(_drawer, 0, array_length(_dr) - 1)];
    var _y = cht_bk_head("CHITIN - the cabinet",
        cht_cabinet_line(_cab) + ".  Drawer: " + _d.name
        + ".  The empty compartments are drawn, not listed.", 46, _w);

    var _cells = cht_cabinet_layout(_d.n, 6, 60, _y, _w - 120, _h - _y - 46, 12);
    var _ghost = cht_cabinet_ghost_parts();
    var _gpal = cht_bk_ghost_pal();
    var _gmap = cht_chroma_map("c");

    for (var _k = 0; _k < array_length(_cells); _k++) {
        var _c = _cells[_k];
        var _i = _d.from + _k;
        cht_bk_well(_c.x, _c.y, _c.w, _c.h);
        if (cht_cabinet_has(_cab, _i)) {
            cht_bk_specimen(_i, _c.x + 8, _c.y + 8, _c.w - 16, _c.h - 34, _phase);
            cht_text_line(cht_name_of(cht_species_names(), _i),
                _c.x + 5, _c.y + _c.h - 26, _c.w - 10, 12, cht_bk_dim(), false);
            cht_text_line(cht_name_of(cht_condition_names(), _cab.best[_i]),
                _c.x + 5, _c.y + _c.h - 14, _c.w - 10, 11, cht_bk_rule(), false);
        } else {
            // ⛔ THE GHOST IS DRAWN AT THE SAME SIZE AND IN THE SAME COMPARTMENT AS A SPECIMEN.
            // Shrinking it, or dimming the whole cell, turns a gap into a decoration; the point is
            // that the eye reads the row and stops on the hole.
            // ⛔ `_tight`, NOT `cht_render_in_rect`. MEASURED 2026-09-01 by opening
            // sheet_2_cabinet_beetles: the plain version fits the UNIT BOX into the rect, and the
            // pin occupies only the middle strip of that box - so it drew small AND its label
            // hung below the compartment border into the row underneath. The tight variant fits
            // the PARTS' OWN BOUNDS, which is what "fill this compartment" actually means.
            // ⚠️ No ink check can see this: overhanging ink is ink, and it lands on a neighbouring
            // cell that is also supposed to have ink in it.
            cht_render_in_rect_tight(_ghost, _gpal, _c.x + 14, _c.y + 12,
                                     _c.w - 28, _c.h - 42, _gmap);
            cht_text_line("- not taken -", _c.x + 5, _c.y + _c.h - 26, _c.w - 10, 12,
                          cht_bk_dim(), false);
        }
    }
    return _y + (_h - _y - 46);
}

/// ============================================================================================
/// THE FIELD GUIDE PLATE - where and when, and how to tell it from the next one
/// ============================================================================================

/// The season x daypart availability grid for one species: 36 cells, filled where it is out.
///
/// ⭐ IT IS THE PICTURE OF THE FIELD LAYER, and the field layer is otherwise invisible on a store
/// page. A sentence saying "flies at dusk in high summer" is a claim; a grid with four cells lit
/// out of thirty six is the same claim as a SHAPE, and it is different for all 48 species.
function cht_bk_field_grid(_i, _x, _y, _w, _h) {
    var _f = cht_field_spec(_i);
    var _cw = _w / CHT_SEASON_N;
    var _ch = _h / CHT_DAYPART_N;
    for (var _s = 0; _s < CHT_SEASON_N; _s++) {
        for (var _d = 0; _d < CHT_DAYPART_N; _d++) {
            var _cx = _x + _s * _cw, _cy = _y + _d * _ch;
            var _out = cht_bit(_f.sea, cht_bit_at(_s)) && cht_bit(_f.day, cht_bit_at(_d));
            if (_out) {
                // The peak season reads brighter, because "commonest in high summer" is a real
                // fact about the animal and the grid is the only place it can be seen.
                draw_set_colour((_s == _f.peak) ? cht_bk_ink() : cht_bk_dim());
                draw_rectangle(_cx + 1, _cy + 1, _cx + _cw - 2, _cy + _ch - 2, false);
            } else {
                draw_set_colour(cht_bk_rule());
                draw_rectangle(_cx + 1, _cy + 1, _cx + _cw - 2, _cy + _ch - 2, true);
            }
        }
    }
}

/// One field-guide page: the animal, its marks, where and when, and how hard it is.
function cht_bk_field(_i, _phase, _w, _h) {
    var _y = cht_bk_head("CHITIN - the field guide",
        "Every line on this page is DERIVED from the same numbers that drew the animal.", 46, _w);

    // ⛔ 0.46 AND A RIGHT COLUMN THAT REACHES THE MARGIN. THE FIRST LAYOUT PUT EVERYTHING AFTER THE
    // TITLE INTO A 190 px STRIP AND LEFT A THIRD OF THE PAGE BLANK - measured by the sheet's own
    // content floor, `contentW 0.604` against a floor of 0.86, and visible the moment the file was
    // opened. CLAUDE.md §4.2b calls a composite more than 20% empty a hard fail, and it is right:
    // dead space on a store plate reads as an unfinished product, not as restraint.
    var _boxw = floor((_w - 140) * 0.46);
    var _boxh = _h - _y - 46;
    cht_bk_well(60, _y, _boxw, _boxh);
    var _n = cht_bk_specimen(_i, 60 + 16, _y + 16, _boxw - 32, _boxh - 32, _phase);

    var _rx = 60 + _boxw + 34;
    var _rw = _w - _rx - 60;
    var _ry = _y + 2;
    var _colW = floor(_rw * 0.46);      // the marks table's value column start

    cht_text_label(cht_name_of(cht_species_names(), _i), _rx, _ry, _rw, 46,
                   cht_bk_page(), cht_bk_ink());
    _ry += 66;

    // ⚠️ THE LABELS ARE `dim` AND NOT `rule`. On the first plate every caption on this page was
    // drawn in the rule colour - L 0.305 on an L 0.140 page - and was effectively unreadable at
    // 100%, let alone in an itch gallery thumbnail. `rule` is for HAIRLINES.
    cht_text_line("FOUND", _rx, _ry, _rw, 17, cht_bk_dim(), false);
    _ry += 26;
    // The habitat list is a generated English sentence, not a stored string.
    cht_text_body(cht_field_list(cht_field_spec(_i).hab, cht_habitat_names()),
                  _rx, _ry, _rw, 24, cht_bk_ink());
    _ry += 56;

    // ⛔ THE GRID IS PUSHED TO THE RIGHT MARGIN, AND THAT IS A MEASUREMENT RATHER THAN A TASTE.
    // cht_text_line SHRINKS text to fit a width and never pads it, so no caption can be made to
    // reach an edge - the ink stops wherever the words stop. After widening the columns once, the
    // sheet still read `contentW 0.794` against a 0.86 floor because everything on the page was
    // left-aligned into the middle third. A BLOCK of known width, right-aligned, is the only thing
    // on this page that can put ink at the margin on purpose.
    // ⛔⛔ THE GRID SITS BESIDE THE FIELD MARKS, NOT ABOVE THEM, AND THE FIRST VERSION OF THIS FIX
    // TRADED ONE DEFECT FOR ANOTHER. Right-aligning the grid put ink at the margin and cleared the
    // contentW floor - and left a 375x320 HOLE in the middle of the page where the grid used to be,
    // because nothing took its place. MEASURED by opening sheet_5 and looking: about 16% of the
    // plate was empty, against Gate 1 question 3's ~20% limit, i.e. passing on a technicality.
    //
    // ⭐ A CONTENT FLOOR AND A DEAD-SPACE RULE PULL IN OPPOSITE DIRECTIONS AND ONLY A LAYOUT SATISFIES
    // BOTH. Spreading the same content wider passes the first and fails the second; stacking it
    // tightly does the reverse. Two columns inside the right column - marks on the left, the
    // availability grid on the right, both starting at the same y - reach the margin AND fill the
    // middle, because they are two real things rather than one thing stretched.
    var _gw = min(floor(_rw * 0.46), 380);
    var _gx = _w - 60 - _gw;
    var _mw = _gx - _rx - 30;               // the marks column, stopping clear of the grid
    var _mcol = floor(_mw * 0.46);
    var _topY = _ry;

    cht_text_line("SEASON ACROSS, TIME OF DAY DOWN", _gx, _topY, _gw, 17, cht_bk_dim(), false);
    cht_bk_field_grid(_i, _gx, _topY + 26, _gw, 216);
    // The peak season is drawn brighter than the rest, and a legend is what makes that legible
    // rather than decorative.
    cht_text_line("lit = out.  brightest column = commonest.", _gx, _topY + 252, _gw, 16,
                  cht_bk_dim(), false);

    cht_text_line("FIELD MARKS", _rx, _topY, _mw, 17, cht_bk_dim(), false);
    _ry = _topY + 28;
    var _marks = cht_field_marks(_i);
    for (var _k = 0; _k < array_length(_marks); _k++) {
        cht_text_line(_marks[_k].label, _rx, _ry, _mcol, 21, cht_bk_dim(), false);
        cht_text_line(_marks[_k].value, _rx + _mcol, _ry, _mw - _mcol, 21, cht_bk_ink(), false);
        _ry += 30;
    }
    _ry += 20;
    _colW = _mcol;
    _rw = _mw;

    // ⛔ RARITY AND DIFFICULTY ARE TWO DIFFERENT AXES AND THE PAGE SAYS SO. They are DERIVED - one
    // from how much of the habitat/season/time/weather space the animal occupies, the other from
    // its alarm radius, escape speed and escape program - so a buyer who edits a flight period gets
    // a guide page that moves with it and never a stale table.
    cht_text_line("TO FIND", _rx, _ry, _colW, 21, cht_bk_dim(), false);
    cht_text_line(cht_name_of(cht_rarity_names(), cht_field_rarity_band(_i)),
                  _rx + _colW, _ry, _rw - _colW, 21, cht_bk_ink(), false);
    _ry += 30;
    cht_text_line("TO CATCH", _rx, _ry, _colW, 21, cht_bk_dim(), false);
    cht_text_line(string(round(cht_catch_difficulty(_i) * 100)) + " of 100, "
                  + cht_name_of(cht_evade_names(), cht_field_spec(_i).evade) + "s away",
                  _rx + _colW, _ry, _rw - _colW, 21, cht_bk_ink(), false);
    _ry += 44;

    cht_text_line("drawn from " + string(_n) + " generated parts, no image files",
                  _rx, _ry, _rw, 16, cht_bk_dim(), false);

    // ⭐ THE LOOKALIKE BLOCK, AND IT IS HERE BECAUSE THE PLATE HAD A HOLE IN IT. Compacting the
    // marks and the grid into two columns fixed the middle of the page and left the bottom third
    // empty - about 16% of the plate, which passes Gate 1 question 3's ~20% limit on a technicality
    // and looks like an unfinished layout.
    //
    // ⛔ THE FIX IS CONTENT, NOT PADDING. Dead space and a thin product are the same hole (§17c),
    // and the thing missing from this page was the half of a field guide that actually teaches: not
    // "here is an animal" but "here is the one you will confuse it with, and here is the ONE WORD
    // that separates them". It is derived by cht_field_nearest, so it cannot go stale, and it puts
    // the identification surface on the store page where nothing else showed it.
    var _near = cht_field_nearest(_i);
    if (_near.i >= 0) {
        // ⛔ DERIVED FROM THE FLOW, NOT A LITERAL. The first placement was `_y + 430`, which put the
        // rule and the heading straight THROUGH the "drawn from N generated parts" footer - two
        // blocks laying themselves out against different origins, which is trap 22a-2f's shape in a
        // layout: a constant that is an assumption about where something else ended. MEASURED by
        // rendering it and reading "...mage files" showing through the heading.
        var _ly = max(_ry + 52, _y + 430);
        draw_set_colour(cht_bk_rule());
        draw_rectangle(_rx, _ly - 26, _w - 60, _ly - 25, false);
        cht_text_line("TOLD APART FROM", _rx, _ly, _rw, 17, cht_bk_dim(), false);

        var _cw2 = 200, _chh2 = 200;
        cht_bk_well(_rx, _ly + 28, _cw2, _chh2);
        cht_bk_specimen(_near.i, _rx + 10, _ly + 38, _cw2 - 20, _chh2 - 44, _phase);
        cht_text_line(cht_name_of(cht_species_names(), _near.i),
                      _rx + 6, _ly + 28 + _chh2 - 22, _cw2 - 12, 14, cht_bk_dim(), false);

        var _tx = _rx + _cw2 + 30;
        var _tw = _w - 60 - _tx;
        cht_text_line("they differ by " + string(_near.n)
                    + ((_near.n == 1) ? " mark:" : " marks:"),
                      _tx, _ly + 34, _tw, 21, cht_bk_dim(), false);
        for (var _m = 0; _m < array_length(_near.marks); _m++) {
            cht_text_line(_near.marks[_m], _tx, _ly + 70 + _m * 30, _tw, 23, cht_bk_ink(), false);
        }
        // ⚠️ THE SENTENCE IS BUILT, NOT TYPED. A store plate that states a rule the code does not
        // follow is the caption-as-a-claim defect this file already carries twice.
        cht_text_line("no two of the " + string(cht_species_n())
                    + " species share all six marks - asserted over all "
                    + string(cht_species_n() * (cht_species_n() - 1) / 2) + " pairs",
                      _tx, _ly + 190, _tw, 16, cht_bk_dim(), false);
    }
    return _y + _boxh + 20;
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

/// Render one named surface, measure it, save it, and return its result line.
function cht_bk_one(_name, _w, _h, _fn, _contentY) {
    var _surf = surface_create(_w, _h);
    surface_set_target(_surf);
    draw_clear(cht_bk_page());
    cht_lamp_reset();

    var _endY = _fn();
    var _ib = cht_bk_ink_bounds(_w, _h, _contentY);
    cht_render_opaque(_w, _h);

    surface_reset_target();
    surface_save(_surf, _name + ".png");
    surface_free(_surf);

    var _clipped = (_endY > _h) || (_ib.full[3] >= _h - 6) || (_ib.full[2] >= _w - 6)
                || (_ib.full[0] <= 5) || (_ib.full[1] <= 5);
    var _cw = (_ib.content[2] - _ib.content[0]) / _w;
    var _chh = (_ib.content[3] - _ib.content[1]) / max(1, _h - _contentY);

    return "{\"name\":\"" + _name + "\""
         + ",\"endY\":" + string(round(_endY))
         + ",\"ink\":" + string(_ib.ink)
         + ",\"fullBox\":[" + string(_ib.full[0]) + "," + string(_ib.full[1]) + ","
                            + string(_ib.full[2]) + "," + string(_ib.full[3]) + "]"
         + ",\"contentW\":" + string_format(_cw, 1, 3)
         + ",\"contentH\":" + string_format(_chh, 1, 3)
         + ",\"clipped\":" + (_clipped ? "true" : "false")
         // ⛔ THE INK FLOOR IS A FRACTION OF THE SHEET, NOT A COUNT. It was the literal 12000, which
         // is calibrated for the 1600x1000 plates and is simply the wrong question for a 630x500
         // cover: the same DENSITY of ink on a sheet with a fifth of the pixels scores a fifth of
         // the count and fails. MEASURED 2026-09-01 - the cover came back ok=False at ink 11394,
         // which is 3.6% coverage, denser than sheet_6_specimen at 1.9% that the same check passes.
         // 0.0075 reproduces the old threshold EXACTLY at 1600x1000 (0.0075 * 1600000 = 12000), so
         // no existing verdict moves; it just now means the same thing on every size.
         + ",\"ok\":" + ((!_clipped && _cw >= 0.86 && _chh >= 0.80 && _ib.ink > 0.0075 * _w * _h)
                         ? "true" : "false")
         + "}";
}

/// ============================================================================================
/// THE DIAGNOSTIC
///
/// ⭐ THIS EXISTS BECAUSE OF WHAT THE FIRST PREVIEW COST. Two defects were live on it - a body that
/// collapsed to a line and an animal cut off flat at both ends - and BOTH were found by opening a
/// PNG and staring at it, which is slow and finds only what it happens to look at. A picture that
/// two readings disagree about is a picture to MEASURE.
///
/// So the run also emits numbers that no image can state: where every species' parts actually
/// reach, how deep the bevel on the body really got after the inset limiter had its say, and
/// whether each plan's half-width truly falls to zero at both ends. None of these is a floor that
/// fails the run - they are the readings a fix is decided from.
/// ============================================================================================
function cht_bk_diagnose() {
    var _s = "";

    // Per-plan: does the outline close itself at both ends, and how wide does it get?
    _s += "\"plans\":[";
    for (var _p = 0; _p < CHT_PLAN_N; _p++) {
        if (_p > 0) _s += ",";
        var _bd = cht_body_plan(_p);
        var _wmax = 0;
        for (var _k = 0; _k <= 100; _k++) _wmax = max(_wmax, cht_body_halfw(_bd, _k / 100));
        _s += "{\"plan\":" + string(_p)
            + ",\"w0\":" + string_format(cht_body_halfw(_bd, 0), 1, 5)
            + ",\"w1\":" + string_format(cht_body_halfw(_bd, 1), 1, 5)
            + ",\"wmax\":" + string_format(_wmax, 1, 4) + "}";
    }
    _s += "]";

    // Per-species: how far the drawn parts actually reach. The unit box is [-0.5, 0.5]; anything
    // past it is drawn OUTSIDE the rect a buyer hands us, which on a HUD is over their interface.
    var _worst = 0;
    var _over = 0;
    var _tightest = 1;
    _s += ",\"reach\":[";
    for (var _i = 0; _i < cht_species_n(); _i++) {
        var _raw = cht_species_parts_raw(_i, 700, 0.50);
        var _bb = cht_render_bounds(_raw);
        var _r = max(max(abs(_bb[0]), abs(_bb[2])), max(abs(_bb[1]), abs(_bb[3])));
        var _k = cht_fit_factor(_raw, 0.485);
        if (_k < _tightest) _tightest = _k;

        // The FITTED list is what ships, so it is the one the containment number is read off - a
        // diagnostic that measures the input to a correction cannot tell you the correction worked.
        var _fit = cht_fit_unit(_raw, 0.485);
        var _fb = cht_render_bounds(_fit);
        var _fr = max(max(abs(_fb[0]), abs(_fb[2])), max(abs(_fb[1]), abs(_fb[3])));
        if (_fr > 0.4851) _over += 1;
        if (_r > _worst) _worst = _r;

        if (_i > 0) _s += ",";
        _s += "{\"i\":" + string(_i) + ",\"n\":" + string(array_length(_raw))
            + ",\"raw\":" + string_format(_r, 1, 3)
            + ",\"fit\":" + string_format(_k, 1, 3)
            + ",\"out\":" + string_format(_fr, 1, 3) + "}";
    }
    _s += "],\"rawWorst\":" + string_format(_worst, 1, 3)
        + ",\"fitTightest\":" + string_format(_tightest, 1, 3)
        + ",\"stillOver\":" + string(_over);

    // The body bevel, after the inset limiter. A dome that the limiter has crushed to nothing is
    // invisible in exactly the way a flat sticker is, and no ink or extent floor can see it.
    var _b0 = cht_species_body(cht_species_spec(0));
    var _fine = cht_body_outline(_b0, CHT_BODY_SAMPLES);
    var _rel = cht_body_outline(_b0, CHT_BODY_RELIEF_SAMPLES);
    _s += ",\"bevel\":{\"want\":0.026"
        + ",\"finePoints\":" + string(array_length(_fine))
        + ",\"fineLimit\":" + string_format(cht_inset_limit(_fine), 1, 5)
        + ",\"reliefPoints\":" + string(array_length(_rel))
        + ",\"reliefLimit\":" + string_format(cht_inset_limit(_rel), 1, 5)
        + ",\"got\":" + string_format(cht_bevel_cap(_rel, 0.026), 1, 5)
        + ",\"reliefShortestEdge\":" + string_format(cht_shortest_edge(_rel), 1, 5) + "}";

    // The shell's own tonal range, which is the number that says whether the animal is round.
    // A tube whose lit and shaded flanks differ by almost nothing IS a flat sticker, and no ink or
    // extent floor can see that - they measure whether ink is present, not whether it varies.
    var _cut0 = cht_cuticle_spec(cht_species_spec(0).cut);
    var _lLit = cht_oklch_L_of(cht_chroma_ramp_at(_cut0, cht_tube_k(-0.92), -0.92, 0.5));
    var _lMid = cht_oklch_L_of(cht_chroma_ramp_at(_cut0, cht_tube_k(0.00), 0.00, 0.5));
    var _lDrk = cht_oklch_L_of(cht_chroma_ramp_at(_cut0, cht_tube_k(0.92), 0.92, 0.5));
    _s += ",\"shell\":{\"kLit\":" + string_format(cht_tube_k(-0.92), 1, 3)
        + ",\"kMid\":" + string_format(cht_tube_k(0), 1, 3)
        + ",\"kDark\":" + string_format(cht_tube_k(0.92), 1, 3)
        + ",\"Llit\":" + string_format(_lLit, 1, 3)
        + ",\"Lmid\":" + string_format(_lMid, 1, 3)
        + ",\"Ldark\":" + string_format(_lDrk, 1, 3)
        + ",\"range\":" + string_format(_lLit - _lDrk, 1, 3)
        + ",\"bandsAt700\":" + string(cht_species_bands(700)) + "}";

    return _s;
}

/// The preview run. One big specimen and the whole contact sheet.
///
/// ⚠️ THE FLOORS BELOW CATCH EMPTY AND CLIPPED. THEY CANNOT SEE SPARSE AND THEY CANNOT SEE UGLY.
/// The manifest exists so a failure is named rather than hunted; the instrument for whether the
/// drawing is any good is opening the file.
function cht_bake_preview(_i) {
    var _res = [];
    array_push(_res, cht_bk_one("big_" + string(_i), CHT_BIG_W, CHT_BIG_H,
        function() { return cht_bk_big(global.cht_bake_i, 0.50); }, 150));
    array_push(_res, cht_bk_one("contact", CHT_SHEET_W, CHT_SHEET_H,
        function() { return cht_bk_contact(0.50); }, 150));

    var _s = "{\"mode\":\"preview\",\"species\":" + string(cht_species_n())
           + ",\"sheets\":[";
    for (var _k = 0; _k < array_length(_res); _k++) {
        if (_k > 0) _s += ",";
        _s += _res[_k];
    }
    _s += "]," + cht_bk_diagnose() + "}";
    var _f = file_text_open_write("cht_bake.json");
    file_text_write_string(_f, _s);
    file_text_close(_f);
}

/// ============================================================================================
/// THE GIF FRAMES
///
/// ⛔ THE SUBJECT IS THE ONLY THING IN THIS PACKAGE THAT MOVES, AND IT IS ALSO THE HEADLINE.
/// Structural colour is a claim a still image literally cannot make: "green at one angle and copper
/// at another" is a statement about CHANGE, and every plate in the gallery is a single angle. The
/// GIF is where the product's central argument actually lands.
///
/// ⚠️ THE SWEEP IS A FULL CYCLE AND IT LOOPS SEAMLESSLY. phase is 0..1 and wraps, so rendering
/// frames at k/N for k in [0, N) returns exactly to the first frame - no hold, no snap. A GIF whose
/// last frame does not meet its first reads as a stutter every two seconds forever.
///
/// ⛔ AND IT IS RENDERED AT ITS NATIVE SIZE. make_gif.ps1's own header records this wing measuring
/// the same 72 frames at 600px (upscaled) = 0.84 MB, 480px (downscaled) = 0.59 MB, and 520px
/// (native, no resampling) = 0.15 MB. Any resample invents intermediate colours and GIF pays for
/// each one twice, in the palette and in the LZW runs it breaks. Bigger picture, a fifth of the
/// bytes.
#macro CHT_GIF_PX 520
#macro CHT_GIF_N   60

function cht_bake_gif() {
    var _i = 8;                     // the jewel beetle - the species the shimmer is named for
    for (var _k = 0; _k < CHT_GIF_N; _k++) {
        var _phase = _k / CHT_GIF_N;
        var _surf = surface_create(CHT_GIF_PX, CHT_GIF_PX);
        surface_set_target(_surf);
        draw_clear(cht_bk_page());
        cht_lamp_reset();
        cht_bk_specimen(_i, 16, 16, CHT_GIF_PX - 32, CHT_GIF_PX - 32, _phase);
        cht_render_opaque(CHT_GIF_PX, CHT_GIF_PX);
        surface_reset_target();
        // Zero-padded so ffmpeg's frame_%04d pattern picks them up in order. An unpadded name
        // sorts frame_10 before frame_2 and the shimmer runs backwards through the middle.
        var _n = string(_k);
        while (string_length(_n) < 4) _n = "0" + _n;
        surface_save(_surf, "frame_" + _n + ".png");
        surface_free(_surf);
    }
    var _f = file_text_open_write("cht_bake.json");
    file_text_write_string(_f, "{\"mode\":\"gif\",\"frames\":" + string(CHT_GIF_N)
        + ",\"px\":" + string(CHT_GIF_PX)
        + ",\"species\":\"" + cht_name_of(cht_species_names(), _i) + "\"}");
    file_text_close(_f);
}

/// ============================================================================================
/// THE STRUCTURAL COLOUR PLATE
///
/// ⛔ IT REPLACED A SINGLE-SPECIMEN HERO PLATE THAT COULD NOT BE MADE TO FILL ITS OWN FRAME, AND
/// THE ARITHMETIC IS WHY. cht_bk_specimen fits the SQUARE (`min(w,h)`), the big plate reserves ~150
/// px for a header and ~200 for its caption block, so on a 900x900 page the animal can never be
/// wider than about 520 - and a 780-wide well then carries 130 px of dead page down each side.
/// Narrowing the well fixed the dead space and broke the content floor instead (contentW 0.776
/// against 0.86): the two constraints are unsatisfiable together for ONE animal on THIS page.
///
/// ⭐ So the plate shows FOUR, which satisfies both and is a better argument anyway. The single
/// specimen was the weakest image in the gallery precisely because the contact sheet and both field
/// guide pages already show specimens; what nothing showed was the product's actual HEADLINE -
/// that a jewel beetle is not green, it is a diffraction grating, and four cuticles running the
/// same program land in four different places.
///
/// ⚠️ 2x2, DELIBERATELY. The cabinet plates are 6x2 and the contact sheet 8x6; §22b-3's measured
/// law is that a shared ROW COUNT collides under dHash however different the content, so a new
/// plate needs a new grid shape and not just new animals.
function cht_bk_chroma(_phase, _w, _h) {
    var _y = cht_bk_head("CHITIN - structural colour",
        "A jewel beetle is not green. It is a grating that returns green at one angle and copper at "
      + "another, and that is a program.", 46, _w);

    // Four species whose cuticles carry a real iridescence term, chosen to land far apart on the
    // hue circle. Read off the roster rather than typed as colours, so a cuticle edit moves them.
    var _cast = [8, 7, 21, 33];             // jewel beetle, rose chafer, whirligig, purple emperor
    var _pad = 14;
    var _cw = (_w - 120 - _pad) / 2;
    var _ch = (_h - _y - 46 - _pad) / 2;
    for (var _k = 0; _k < 4; _k++) {
        var _cx = 60 + (_k mod 2) * (_cw + _pad);
        var _cy = _y + (_k div 2) * (_ch + _pad);
        cht_bk_well(_cx, _cy, _cw, _ch);
        cht_bk_specimen(_cast[_k], _cx + 14, _cy + 12, _cw - 28, _ch - 52, _phase);
        var _sp = cht_species_spec(_cast[_k]);
        var _cut = cht_cuticle_spec(_sp.cut);
        cht_text_line(cht_name_of(cht_species_names(), _cast[_k]),
                      _cx + 12, _cy + _ch - 38, _cw - 24, 19, cht_bk_ink(), false);
        // ⛔ THE FIGURE IS READ OFF THE CUTICLE, NEVER TYPED. A plate that prints an iridescence
        // value the spec does not hold is the caption-as-a-claim defect this file carries three
        // times already.
        cht_text_line(cht_name_of(cht_cuticle_names(), _sp.cut)
                    + "   iridescence " + string_format(_cut.irid, 1, 2),
                      _cx + 12, _cy + _ch - 18, _cw - 24, 14, cht_bk_dim(), false);
    }
    return _y + 2 * (_ch + _pad);
}

/// ============================================================================================
/// THE COVER
///
/// ⛔ 630x500, AND IT IS THE ONLY IMAGE MOST BUYERS EVER SEE. It has to work in a browse row at
/// 315x250, which is why it carries four animals and not forty eight: a contact sheet shrunk to
/// thumbnail size is a grey rectangle.
///
/// ⚠️ THIS IS A DESIGNED ILLUSTRATION RENDERED BY THE PRODUCT, NOT A SCREENSHOT OF IT, and the
/// distinction is the one CLAUDE.md §4.2c is actually making. A screenshot is a picture of a tool
/// being used; this is a composition - a chosen cast, a chosen arrangement, a title block and an
/// empty compartment placed on purpose - that happens to be drawn by the same generator that draws
/// the product. The wing has shipped covers this way before and they are the honest kind: every
/// beetle on it is a beetle the buyer gets.
///
/// ⚠️ IT EXISTS BECAUSE THE IMAGE MODELS WERE BOTH DOWN. MEASURED 2026-09-01: OpenAI answered
/// "prepaid credits exhausted" (image_gen exit 7) and every model in the Gemini fallback chain
/// answered HTTP 429 with `limit: 0` on the free tier. §4.2c's chain ends "ship a DESIGNED cover
/// and upgrade later", and a cover NEVER blocks a publish.
/// ============================================================================================
function cht_bk_cover() {
    var _w = CHT_COVER_W, _h = CHT_COVER_H;

    cht_text_label("CHITIN", 34, 26, 300, 58, cht_bk_page(), cht_bk_ink());
    cht_text_line("insects that draw their own shells", 36, 94, 400, 19, cht_bk_dim(), false);
    draw_set_colour(cht_bk_rule());
    draw_rectangle(34, 124, _w - 34, 125, false);

    // THE HERO: the jewel beetle, because structural colour is the headline and it is the species
    // that carries it. 0.62 rather than 0.50 puts the shimmer band off the centre line, where it
    // reads as a moving highlight instead of as a symmetrical stripe.
    cht_bk_well(34, 140, 264, 322);
    cht_bk_specimen(8, 46, 152, 240, 298, 0.62);

    // THREE MORE, one from each of the other groups, so the cover states the range.
    //
    // ⛔ TWO CELLS AND A GAP, NOT THREE AND A GAP. MEASURED by rendering it and looking: at four
    // compartments of 74 px the three specimens were about 60 px across, which is 30 px in the
    // 315x250 browse thumbnail itch actually shows - a smudge. The cover's job is to survive that
    // crop, so it carries FEWER animals LARGER. The ladybird was the one cut; the peacock and the
    // emperor moth are kept because between them they state "butterflies and moths" at a glance.
    //
    // ⛔⛔ AND THE THIRD CELL WAS AN EMPTY PIN UNTIL 2026-09-01, ON THE ARGUMENT THAT "a cover
    // showing three insects and a bare pin sells a collection". The argument is good and the cell
    // failed it, BY THIS FUNCTION'S OWN STATED STANDARD one paragraph above.
    //
    // MEASURED, the same way the cast size was: `ffmpeg -vf scale=315:250` on the finished cover,
    // then opening it. cht_cabinet_ghost_parts() is a 0.013-wide pin shaft and a small label card -
    // about FOUR pixels of shaft and a 20x9 card once itch crops to a browse row. It does not read
    // as a pin, it reads as an empty box beside two full ones, i.e. as a rendering failure. The
    // ghost is RIGHT where it was designed to be used: inside a drawer plate (sheet_2, sheet_3) it
    // sits among filled compartments and the contrast is what carries the meaning. Isolated in its
    // own well it has nothing to be missing FROM.
    //
    // ⭐ The general form, and it is this wing's own law arriving from the other side: a mark whose
    // meaning comes from CONTRAST WITH ITS NEIGHBOURS cannot be moved somewhere it has no
    // neighbours. The collection story is carried by two whole gallery sheets and by the listing
    // copy; the cover's one job is to stop a stranger scrolling.
    //
    // Species 7 is the third cell: a green chafer. Chosen for HUE - the hero is orange-brown and
    // both lepidoptera are dark red, so at 30 px the cover was three warm smudges and a hole.
    var _rx = 314, _rw = _w - _rx - 34;
    var _ch = 104, _gap = 9;
    var _cast = [24, 42, 7];                // peacock, emperor moth, green chafer
    for (var _k = 0; _k < array_length(_cast); _k++) {
        var _cy = 140 + _k * (_ch + _gap);
        cht_bk_well(_rx, _cy, _rw, _ch);
        cht_bk_specimen(_cast[_k], _rx + 6, _cy + 5, _rw - 12, _ch - 10, 0.50);
    }

    // The counts, DERIVED. A cover that quotes a number a tool did not produce is the defect this
    // factory has a live receipt for - a pack sold at half its real size because a figure was typed
    // into a checker instead of measured.
    cht_text_line(string(cht_species_n()) + " species  -  "
                + string(cht_corpus_forms()) + " component forms  -  pure GML, no sprites",
                  34, 472, _w - 68, 17, cht_bk_dim(), false);
    return 496;
}

/// ============================================================================================
/// THE STORE BAKE
/// ============================================================================================

/// A part-filled cabinet for the cabinet plate.
///
/// ⚠️ DETERMINISTIC, AND SAID OUT LOUD RATHER THAN DRESSED UP AS A PLAYTHROUGH. This is a plate
/// generator, not a save file; what it has to be is REPRODUCIBLE, so that re-baking a sheet does
/// not silently change which compartments are empty and turn a re-render into a new picture. The
/// gaps land on the rarest species in each drawer, which is both true to how a real collection
/// fills and the honest thing to show a buyer.
function cht_bk_demo_cabinet() {
    var _cab = cht_cabinet_new();
    for (var _i = 0; _i < cht_species_n(); _i++) {
        // The hardest and rarest stay out of the drawer, which is what an in-progress cabinet
        // actually looks like.
        // ⚠️ 0.84, NOT 0.74, AND IT IS A PRESENTATION DECISION MADE BY LOOKING. At 0.74 the
        // butterfly drawer came back with SIX of twelve compartments empty and the entire second
        // row blank - truthful, because butterflies score high on both terms, and it reads to a
        // skimming buyer as "this product cannot draw those". The plate has to show the mechanic
        // without arguing the corpus is thin. Two or three gaps a drawer does both.
        var _hard = cht_field_rarity(_i) * 0.62 + cht_catch_difficulty(_i) * 0.38;
        if (_hard > 0.84) continue;
        // Condition falls with difficulty: the awkward ones you did get, you got badly.
        var _cond = 3;
        if (_hard > 0.66) _cond = 0;
        else if (_hard > 0.58) _cond = 1;
        else if (_hard > 0.48) _cond = 2;
        _cab = cht_cabinet_pin(_cab, _i, _cond);
    }
    return _cab;
}

/// The store gallery. SIX sheets, and each one shows something the others do not.
///
/// ⛔ CLAUDE.md §4.2b: "every image shows something different" is a HARD FAIL in preflight and
/// dedupe.js measures it. Five frames of one screen argues the product has one screen. The split
/// here is deliberate - the corpus, the collection loop with its gaps, the field layer, and two
/// single specimens at opposite ends of the difficulty range.
function cht_bake_store() {
    var _res = [];
    var _cab = cht_bk_demo_cabinet();
    global.cht_bake_cab = _cab;

    // ⚠️ THE COVER'S contentY IS 130, NOT 150. cht_bk_one measures "content" BELOW that line, and
    // on a 500 px sheet with a title block ending at 125 a 150 px cut would put the first row of
    // compartments partly into the header region and understate the coverage it is checking.
    array_push(_res, cht_bk_one("cover", CHT_COVER_W, CHT_COVER_H,
        function() { return cht_bk_cover(); }, 130));

    array_push(_res, cht_bk_one("sheet_1_corpus", CHT_SHEET_W, CHT_SHEET_H,
        function() { return cht_bk_contact(0.50); }, 150));

    // Two DIFFERENT drawers: beetles pinned, Lepidoptera set. They are different pictures because
    // cht_display_state says a beetle and a butterfly are mounted differently, which is a real
    // curatorial fact and not a rendering choice.
    array_push(_res, cht_bk_one("sheet_2_cabinet_beetles", CHT_SHEET_W, CHT_SHEET_H,
        function() { return cht_bk_cabinet(global.cht_bake_cab, 0, 0.50,
                                           CHT_SHEET_W, CHT_SHEET_H); }, 150));
    array_push(_res, cht_bk_one("sheet_3_cabinet_lepidoptera", CHT_SHEET_W, CHT_SHEET_H,
        function() { return cht_bk_cabinet(global.cht_bake_cab, 1, 0.50,
                                           CHT_SHEET_W, CHT_SHEET_H); }, 150));

    // Two field pages at opposite ends of the range: the green tiger beetle is the hardest animal
    // in the corpus to get near, the seven spot ladybird one of the easiest.
    global.cht_bake_i = 4;
    array_push(_res, cht_bk_one("sheet_4_field_tiger", CHT_SHEET_W, CHT_SHEET_H,
        function() { return cht_bk_field(4, 0.50, CHT_SHEET_W, CHT_SHEET_H); }, 150));
    array_push(_res, cht_bk_one("sheet_5_field_peacock", CHT_SHEET_W, CHT_SHEET_H,
        function() { return cht_bk_field(24, 0.50, CHT_SHEET_W, CHT_SHEET_H); }, 150));

    // The headline, on four cuticles at once. See cht_bk_chroma for why this is not one specimen.
    array_push(_res, cht_bk_one("sheet_6_structural_colour", CHT_SHEET_W, CHT_SHEET_H,
        function() { return cht_bk_chroma(0.62, CHT_SHEET_W, CHT_SHEET_H); }, 150));

    var _s = "{\"mode\":\"store\",\"species\":" + string(cht_species_n())
           + ",\"corpusLine\":\"" + cht_corpus_line() + "\""
           + ",\"systemLine\":\"" + cht_corpus_system_line() + "\""
           + ",\"cabinetLine\":\"" + cht_cabinet_line(_cab) + "\""
           + ",\"sheets\":[";
    for (var _k = 0; _k < array_length(_res); _k++) {
        if (_k > 0) _s += ",";
        _s += _res[_k];
    }
    _s += "]}";
    var _f = file_text_open_write("cht_bake.json");
    file_text_write_string(_f, _s);
    file_text_close(_f);
}
