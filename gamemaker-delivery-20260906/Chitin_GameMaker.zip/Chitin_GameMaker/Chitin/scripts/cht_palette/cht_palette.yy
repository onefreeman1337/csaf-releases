{
  "$GMScript": "v1",
  "%Name": "cht_palette",
  "name": "cht_palette",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}