/// CHITIN - cht_antenna. THE LOUDEST FIELD MARK ON THE ANIMAL.
///
/// If a player can only see one thing about an insect, it should be the antennae. A cockchafer's
/// lamellate fan, a longhorn's whip, a moth's feathers and a weevil's elbow are recognisable from
/// across a room, and they are the first thing a real field guide asks you to look at. So this is
/// the module the identification screen leans on hardest.
///
/// ⛔ AND IT IS ALSO THE MODULE MOST LIKELY TO MAKE A MOTH READ AS A RABBIT.
///
/// Carried in from the RPG Maker wing's silhouette corpus: AN ACCESSORY READS BY POSITION FIRST.
/// A pair of large soft appendages either side of the top of a body is what an ear IS, and a
/// plumose antenna is exactly that shape in exactly that place. The corpus fix is not to shrink
/// them - a saturniid moth's antennae really are enormous - but to keep them SWEPT FORWARD and
/// TAPERED, because an ear is upright and a bracket-shaped ear is not a thing. Test it on the
/// contact sheet, at thumbnail size, where the mistake is visible and at hero size it is not.
///
/// ⚠️ EVERY FORM STARTS INSIDE THE HEAD. An appendage that begins exactly on the outline leaves a
/// hairline of page between itself and the animal the moment either is bevelled. cht_body_socket
/// sinks the root under the head for us; this file must not undo that by starting the stem at the
/// socket's outer edge.
/// ============================================================================================

#macro CHT_ANT_FILIFORM   0   // a plain thread - a ground beetle, a longhorn
#macro CHT_ANT_CLAVATE    1   // thickening to a club at the tip - a butterfly, a burying beetle
#macro CHT_ANT_LAMELLATE  2   // a fan of flat plates - a chafer, a stag beetle, a dung beetle
#macro CHT_ANT_PECTINATE  3   // a comb of teeth down one side - a click beetle, a fire beetle
#macro CHT_ANT_PLUMOSE    4   // feathered on both sides - a male saturniid moth, a mosquito
#macro CHT_ANT_GENICULATE 5   // a long scape then an elbow - a weevil, an ant, a bee
#macro CHT_ANT_MONILIFORM 6   // a string of beads - a termite, some darkling beetles
#macro CHT_ANT_SERRATE    7   // saw-toothed - a jewel beetle, a soldier beetle
#macro CHT_ANT_N          8

/// The stem of an antenna: a quadratic bezier from the head, swept forward and outward.
///
/// The control point sits AHEAD of the root, which is what puts the curve's belly forward. A
/// control point placed outward instead sweeps the antenna sideways and the animal reads as
/// horned rather than antennate - the same "position first" trap as the ear above, one step over.
///
/// ⛔⛔ _back IS WHY A LONGHORN BEETLE IS NOT A SPECK, AND IT IS ANATOMY RATHER THAN A WORKAROUND.
///
/// MEASURED on the first shaded contact sheet: the musk beetle and the longhorn beetle were drawn
/// at roughly a third the size of every other species, and the diagnostic said why - their antennae
/// are 1.45 and 1.60 body lengths, so cht_fit_unit had to shrink the whole animal to 0.384 and
/// 0.352 to get those antennae inside the unit box. The corpus rows are RIGHT: a longhorn's
/// antennae really are longer than its body. What was wrong is that they were drawn standing
/// straight up, and no real longhorn holds them that way - it sweeps them back over its own elytra,
/// which is the pose in every field guide and on the animal itself.
///
/// So a long antenna arcs forward, out, and then BACK down the flank. The tip ends up beside the
/// body instead of a body-length above it, the reach falls to something like the animal's own size,
/// and the fit stops paying for a pose nobody wanted. ⭐ The general form: WHEN A CONTAINMENT FIX
/// IS COSTING SOMETHING VISIBLE, CHECK WHETHER THE POSE IS WRONG BEFORE SHRINKING THE SUBJECT.
/// ⛔⛔ AND THE FIRST VERSION OF THAT FIX MOVED THE TIP AND LEFT THE CONTROL POINT WHERE IT WAS,
/// WHICH IS WHY IT DID NOT WORK. MEASURED 2026-09-01 by opening big_19: the longhorn's antennae
/// still swept up and out in two enormous arcs that dominated the frame, and the fit correction was
/// still 0.458 - the tip had been brought back but the BELLY of the curve had not, because the
/// control point's height was `-_len * (0.72 + _sweep * 0.30)` with no `_bk` term in it at all.
///
/// ⭐ A BEZIER'S REACH IS ITS CONTROL POLYGON, NOT ITS ENDPOINTS. Moving one endpoint of a curve
/// whose control point is a body-length away moves the reach by a fraction of what the arithmetic
/// suggests, and the containment cost stays almost exactly where it was. Every term that decides
/// where a curve GOES has to carry the pose, or the pose is decoration on one point of it.
///
/// All four terms below now carry `_bk`. At `_bk = 0` they are the values that drew every
/// short-antennaed species correctly and are unchanged to the digit; at 0.72 - the longhorn - the
/// antenna leaves the head forward, sweeps out to about a third of its own length, and comes back
/// down the flank to end just past the abdomen tip, which is the pose in every field guide.
function cht_ant_stem(_root, _side, _len, _spread, _sweep, _n, _back) {
    // Clamped at 0.72 rather than 0.85: past that the tip term goes far enough negative to throw
    // the antenna behind the animal entirely, and no caller asks for it. A limit nothing reaches is
    // a limit nobody has tested.
    var _bk = clamp(is_undefined(_back) ? 0 : _back, 0, 0.72);
    var _tipx = _root[0] + _side * _len * (_spread * (1 - _bk * 0.86) + _bk * 0.05);
    var _tipy = _root[1] - _len * (1 - _spread * 0.45) * (1 - _bk * 2.55);
    var _ctlx = _root[0] + _side * _len * (_spread * 0.28 + _bk * 0.40);
    var _ctly = _root[1] - _len * (0.72 + _sweep * 0.30) * (1 - _bk * 0.92);
    return cht_qbez(_root, [_ctlx, _ctly], [_tipx, _tipy], is_undefined(_n) ? 16 : _n);
}

/// A point along a sampled polyline, and the unit direction there. Used by every branching form
/// below so the branches leave the stem perpendicular to it rather than at a fixed angle - a comb
/// whose teeth all point the same way reads as a rake lying beside the animal.
function cht_ant_frame(_pts, _i) {
    var _n = array_length(_pts);
    var _a = _pts[max(0, _i - 1)], _b = _pts[min(_n - 1, _i + 1)];
    var _dx = _b[0] - _a[0], _dy = _b[1] - _a[1];
    var _l = point_distance(0, 0, _dx, _dy);
    if (_l == 0) return { x: _pts[_i][0], y: _pts[_i][1], nx: 1, ny: 0 };
    return { x: _pts[_i][0], y: _pts[_i][1], nx: -_dy / _l, ny: _dx / _l };
}

/// One antenna, whole. _w is the stem half-width at the base; every form tapers from it.
///
/// ⛔ THE HALF-WIDTH IS THE RESOLUTION FLOOR IN DISGUISE. An appendage below about 0.05 units of
/// half-width reads as a hair rather than as a limb, and an insect has two antennae and six legs -
/// the densest thin-appendage subject this studio has drawn. Anything thinner than the floor is
/// not made thinner here, it is DROPPED by the caller's level-of-detail decision, because a hair
/// that is present and unreadable costs more than an absence.
function cht_antenna_parts(_form, _root, _side, _len, _w, _seed, _back) {
    var _out = [];
    var _f = clamp(_form, 0, CHT_ANT_N - 1);
    var _bk = clamp(is_undefined(_back) ? 0 : _back, 0, 0.85);

    // Geniculate is the one form whose STEM is different rather than its decoration: a long
    // straight scape, then a sharp elbow into a short club. Handled first so the shared code below
    // does not have to carry a special case through every branch.
    if (_f == CHT_ANT_GENICULATE) {
        var _elbx = _root[0] + _side * _len * 0.52;
        var _elby = _root[1] - _len * 0.46;
        var _scape = [[_root[0], _root[1]], [_elbx, _elby]];
        cht_append(_out, cht_taper_ribbon(_scape, _w, _w * 0.72, "m2"));
        var _fun = cht_qbez([_elbx, _elby],
                            [_elbx + _side * _len * 0.16, _elby - _len * 0.30],
                            [_elbx + _side * _len * 0.06, _elby - _len * 0.44], 10);
        cht_append(_out, cht_taper_ribbon(_fun, _w * 0.72, _w * 0.48, "m2"));
        // The club at the end of the funicle - a weevil's antenna is clubbed as well as elbowed.
        var _tp = _fun[array_length(_fun) - 1];
        array_push(_out, cht_dot(_tp[0], _tp[1] - _w * 0.6, _w * 2.1, "m3"));
        array_push(_out, cht_dot(_tp[0] - _side * _w * 0.5, _tp[1] - _w * 1.1, _w * 1.0, "m4"));
        return _out;
    }

    var _spread = 0.62;
    var _sweep = 0.35;
    if (_f == CHT_ANT_PLUMOSE)   { _spread = 0.70; _sweep = 0.52; }
    if (_f == CHT_ANT_LAMELLATE) { _spread = 0.56; _sweep = 0.28; }
    if (_f == CHT_ANT_CLAVATE)   { _spread = 0.58; _sweep = 0.44; }

    var _stem = cht_ant_stem(_root, _side, _len, _spread, _sweep, 18, _bk);
    var _ns = array_length(_stem);

    switch (_f) {
        case CHT_ANT_CLAVATE: {
            // Thin for most of its run, then a club. The club is a separate raised mass so it
            // catches the lamp differently from the shaft - a club drawn as a fat end of the same
            // ribbon reads as a blob of ink.
            cht_append(_out, cht_taper_ribbon(_stem, _w, _w * 0.58, "m2"));
            var _tp = _stem[_ns - 1], _pp = _stem[_ns - 4];
            var _cl = cht_qbez(_pp, [(_pp[0] + _tp[0]) * 0.5, (_pp[1] + _tp[1]) * 0.5], _tp, 8);
            cht_append(_out, cht_taper_ribbon(_cl, _w * 0.7, _w * 2.3, "m3"));
            array_push(_out, cht_dot(_tp[0], _tp[1], _w * 2.2, "m3"));
            array_push(_out, cht_dot(_tp[0] - _side * _w * 0.6, _tp[1] - _w * 0.6, _w * 1.05, "m4"));
        } break;

        case CHT_ANT_LAMELLATE: {
            // The fan. Seven plates on one side of the last third of the stem, each a flat blade
            // standing off it. This is the shape that makes a chafer a chafer.
            cht_append(_out, cht_taper_ribbon(_stem, _w, _w * 0.80, "m2"));
            var _plates = 7;
            for (var _k = 0; _k < _plates; _k++) {
                var _i = round((_ns - 1) * (0.58 + 0.40 * (_k / max(1, _plates - 1))));
                var _fr = cht_ant_frame(_stem, _i);
                // The plates lengthen toward the tip, which is what opens the fan.
                var _pl = _w * (5.2 + 3.4 * (_k / max(1, _plates - 1)));
                var _bx = _fr.x, _by = _fr.y;
                var _ex = _bx + _fr.nx * _pl * _side * -1;
                var _ey = _by + _fr.ny * _pl * _side * -1;
                cht_append(_out, cht_taper_ribbon([[_bx, _by], [_ex, _ey]], _w * 1.15, _w * 0.62, "m3"));
            }
        } break;

        case CHT_ANT_PECTINATE: {
            // A comb: teeth down ONE side only. The asymmetry is the identification, so it must
            // survive being mirrored onto the other antenna - the teeth point outward on both.
            cht_append(_out, cht_taper_ribbon(_stem, _w, _w * 0.52, "m2"));
            for (var _i = 3; _i < _ns - 1; _i += 2) {
                var _fr = cht_ant_frame(_stem, _i);
                var _u = _i / (_ns - 1);
                var _tl = _w * (6.5 * sin(_u * pi) + 1.2);
                cht_append(_out, cht_taper_ribbon(
                    [[_fr.x, _fr.y], [_fr.x - _fr.nx * _tl * _side, _fr.y - _fr.ny * _tl * _side]],
                    _w * 0.60, _w * 0.22, "m2"));
            }
        } break;

        case CHT_ANT_PLUMOSE: {
            // Feathered on BOTH sides, and the barbs are longest in the middle - a saturniid
            // antenna is a lens shape, not a rectangle. That silhouette is what keeps it from
            // reading as an ear: an ear does not taper at both ends.
            cht_append(_out, cht_taper_ribbon(_stem, _w * 0.9, _w * 0.42, "m2"));
            for (var _i = 2; _i < _ns - 1; _i++) {
                var _fr = cht_ant_frame(_stem, _i);
                var _u = _i / (_ns - 1);
                var _bl = _w * (8.5 * sin(power(_u, 0.78) * pi) + 0.8);
                for (var _sg = -1; _sg <= 1; _sg += 2) {
                    // The barbs rake FORWARD along the stem as well as out from it, which is what
                    // makes a feather look grown rather than assembled.
                    var _ex = _fr.x + _fr.nx * _bl * _sg + (_stem[_i][0] - _stem[_i - 1][0]) * 1.6;
                    var _ey = _fr.y + _fr.ny * _bl * _sg + (_stem[_i][1] - _stem[_i - 1][1]) * 1.6;
                    cht_append(_out, cht_taper_ribbon([[_fr.x, _fr.y], [_ex, _ey]],
                        _w * 0.40, _w * 0.13, "m1"));
                }
            }
        } break;

        case CHT_ANT_MONILIFORM: {
            // A string of beads. Drawn as the beads themselves with a thin thread behind, because
            // a bumpy ribbon at this scale is just a ribbon.
            cht_append(_out, cht_taper_ribbon(_stem, _w * 0.55, _w * 0.40, "m1"));
            for (var _i = 1; _i < _ns; _i += 2) {
                array_push(_out, cht_dot(_stem[_i][0], _stem[_i][1], _w * 1.45, "m2"));
                array_push(_out, cht_dot(_stem[_i][0] - _side * _w * 0.35, _stem[_i][1] - _w * 0.35,
                    _w * 0.62, "m4"));
            }
        } break;

        case CHT_ANT_SERRATE: {
            // Saw teeth: short, blunt, and every one of them on the outer edge.
            cht_append(_out, cht_taper_ribbon(_stem, _w * 1.05, _w * 0.55, "m2"));
            for (var _i = 4; _i < _ns - 1; _i += 2) {
                var _fr = cht_ant_frame(_stem, _i);
                var _tl = _w * 2.4;
                cht_append(_out, cht_taper_ribbon(
                    [[_fr.x, _fr.y], [_fr.x - _fr.nx * _tl * _side, _fr.y - _fr.ny * _tl * _side]],
                    _w * 0.85, _w * 0.20, "m3"));
            }
        } break;

        default: {
            // Filiform. A plain tapering thread, and it must not be a constant-width one: a
            // ribbon of even thickness is the loudest tell of programmer art in this whole
            // catalogue, and an antenna is the thinnest thing on the animal.
            cht_append(_out, cht_taper_ribbon(_stem, _w, _w * 0.34, "m2"));
        } break;
    }
    return _out;
}
