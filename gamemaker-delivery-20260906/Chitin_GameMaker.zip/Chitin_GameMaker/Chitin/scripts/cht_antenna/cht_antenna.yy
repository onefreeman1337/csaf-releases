{
  "$GMScript": "v1",
  "%Name": "cht_antenna",
  "name": "cht_antenna",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}