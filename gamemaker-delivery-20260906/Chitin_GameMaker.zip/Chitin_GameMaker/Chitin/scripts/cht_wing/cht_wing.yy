{
  "$GMScript": "v1",
  "%Name": "cht_wing",
  "name": "cht_wing",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}