/// CHITIN - cht_wing. MEMBRANE AND VENATION, AND WHERE A BUTTERFLY'S PATTERN ACTUALLY LIVES.
///
/// Half this corpus is Lepidoptera, and for those 24 species the wings ARE the animal: the body is
/// a dark stick in the middle and every field mark a player uses is on the wing. So this file
/// carries more of the product's visible value than any other, and it has one structural idea:
///
/// ⛔ A WING IS AUTHORED IN ITS OWN SPACE, EXACTLY LIKE THE BODY IS.
///
/// The wing has a root (where it meets the thorax), a span (root to apex) and a chord (leading edge
/// to trailing edge), and every vein, band, spot and eyespot on it is placed in those two
/// coordinates - never in x and y. That is the same law cht_pattern already states for the body,
/// and it matters more here: a wing TAPERS to its apex, so a band drawn as a rectangle is wrong
/// everywhere except the one station where the chord happens to match it.
///
/// ⭐ AND IT IS WHY THE PATTERN CODE COULD NOT SIMPLY BE REUSED. cht_pattern writes into BODY
/// coordinates, which is right for a beetle - a ladybird's spots are on its elytra, which are its
/// body outline. A butterfly's spots are not on its body at all. Drawing them there put a red
/// admiral's bands across its abdomen, which is a picture of an insect nobody has ever seen.
///
/// -- THE VENATION IS A TREE, NOT A SET OF STROKES ---------------------------------------------
/// A vein leaves the wing base thick, runs toward the margin, and BRANCHES - and each branch is
/// thinner than what it came from. That single property is what separates a drawn wing from a wing
/// with lines on it, and it is why the veins here are built by recursion rather than by a loop over
/// a list of angles.
///
/// ⚠️ AND THE VEIN COUNT IS A RESOLUTION DECISION LIKE EVERY OTHER COUNT IN THIS PACKAGE. GML
/// floors a stroke at 1.0 px, so eleven veins on a wing 40 px across is a grey smear. cht_wing_fit
/// answers how many actually get drawn, and it RETURNS the number rather than applying it silently.
/// ============================================================================================

#macro CHT_WING_FORE 0
#macro CHT_WING_HIND 1

/// Wing shape families. A plan picks the pair; a species moves the numbers.
#macro CHT_WSHAPE_BUTTERFLY 0   // forewing triangular with a pointed apex, hindwing round
#macro CHT_WSHAPE_MOTH      1   // forewing elongate and blunt, hindwing broad and short
#macro CHT_WSHAPE_TAILED    2   // a swallowtail: hindwing carries a real tail
#macro CHT_WSHAPE_N         3

/// How many points a wing outline is sampled at, per edge.
#macro CHT_WING_SAMPLES 40

/// ============================================================================================
/// WING GEOMETRY
/// ============================================================================================

/// ⛔⛔ A WING IS BOUNDED BY TWO INDEPENDENT EDGES. A CHORD FUNCTION ABOUT A CAMBER LINE DRAWS A
/// LEAF, AND THIS PRODUCT SHIPPED TWENTY-FOUR OF THEM TO ITS FIRST PREVIEW.
///
/// MEASURED 2026-09-01 by opening big_24 (the peacock): every butterfly and every moth rendered as
/// two rounded LOBES per side, fore and hind indistinguishable, and the animal read as a body lying
/// on two leaves. The old model was `halfc(s) = chord * power(1 - (2u-1)^2, e)` offset from a
/// camber line - a lens, zero-width at BOTH ends, symmetric about its own midline whatever the
/// exponents did.
///
/// ⭐ THE DEFECT WAS IN THE MODEL AND NOT IN ITS NUMBERS, WHICH IS WHY FOUR PASSES OF TUNING WOULD
/// HAVE FAILED. A lepidopteran forewing is not a fat middle: it is a nearly STRAIGHT COSTA running
/// out to a CORNER at the apex, an outer margin cutting back from that corner to the tornus, and an
/// inner margin returning to the body. The apex is the whole identity of the shape - it is what a
/// butterfly's silhouette is - and a lens has no corner anywhere on it. No exponent puts one there.
///
/// So a wing is now TWO FUNCTIONS OF THE SAME STATION:
///
///     cht_wing_lead(w, s)    the costa,  a NEGATIVE offset (toward the head)
///     cht_wing_trail(w, s)   the margin, a POSITIVE offset (toward the tail)
///
/// and `cht_wing_pt(w, s, c)` still maps c = -1 to the leading edge and c = +1 to the trailing one,
/// so every band, spot, ocellus and vein in this file kept working unchanged. That is the reason for
/// this shape of fix rather than a new outline builder: the pattern layer is authored in (s, c) and
/// is CORRECT; only the boundary those coordinates were stretched between was wrong.
///
/// -- THE FIELDS --------------------------------------------------------------------------------
/// span      root to apex, in unit-box units
/// lead0     how far ahead of the wing axis the costa sits AT THE ROOT
/// lead1     ... and AT THE APEX. lead1 > lead0 rakes the whole wing forward, which is the pose a
///           set specimen is pinned in and what stops four wings reading as one disc
/// bow       how far the costa bows forward at mid-span. 0 is a ruler-straight leading edge
/// trail0    the trailing offset at the root, i.e. half the wing's attachment width
/// trailMax  the widest the wing gets, at station `trailAt`
/// trailAt   where the wing is broadest, as a fraction of the span
/// rise      shape of the inner margin from root to widest. Below 1 flares fast off the body
/// fall      shape of the OUTER MARGIN from widest back to the apex, and this is the field that
///           decides whether the wing has a corner.
///           ⛔ THE SENSE OF THIS FIELD WAS DOCUMENTED BACKWARDS AND THE VALUES WERE SET FROM THE
///           WRONG READING. It used to say "above 1 holds the wing wide and then cuts back sharply;
///           below 1 rounds it away". The arithmetic says the opposite, and so does the render.
///           The margin is `lerp(trailMax, apex, power(u, fall))` and the apex offset is NEGATIVE,
///           so `power(u, fall)` is how much of the drop has already happened. BELOW 1 spends the
///           whole drop in the first third of the outer margin - at fall 0.82 the wing is down to
///           0.04 of its 0.226 widest by u=0.5 - which is a long straight taper to a spike. ABOVE 1
///           holds the chord out and turns late, which is a full, round margin with a corner only
///           at the very tip.
///           MEASURED 2026-09-01 by opening big_24 and big_42 at fall 0.82 and 1.15: every
///           Lepidopteran in the corpus read as a PAPER DART. The base values below were raised
///           accordingly; the per-species fallK multipliers were kept, because their SPREAD is what
///           the all-pairs sweep depends on and only their centre was wrong.
/// tail      length of a swallowtail tail, 0 for none
function cht_wing_spec(_span, _lead0, _lead1, _bow, _trail0, _trailMax, _trailAt,
                       _rise, _fall, _tail) {
    return { span: _span, lead0: _lead0, lead1: _lead1, bow: _bow,
             trail0: _trail0, trailMax: _trailMax, trailAt: _trailAt,
             rise: _rise, fall: _fall, tail: _tail };
}

/// THE COSTA. Returns a NEGATIVE offset: the leading edge is ahead of the wing's own axis.
function cht_wing_lead(_w, _s) {
    var _t = clamp(_s, 0, 1);
    // ⛔ 1.30, NOT 0.72, AND THE FIRST VALUE MADE EVERY WING A PADDLE. An exponent BELOW 1 spends
    // the costa's whole forward rake in the first fifth of the span, so the wing is already at a
    // third of its full chord where it leaves the thorax - and a shape that starts wide and stays
    // wide is a rectangle whatever happens at its tip. Above 1 the costa leaves the body nearly
    // square to it and rakes forward as it runs out, which is what a wing does and what makes the
    // inner half NARROW. MEASURED by opening the contact sheet: twenty-four Lepidoptera reading as
    // a body between two slabs.
    return -(lerp(_w.lead0, _w.lead1, power(_t, 1.30)) + _w.bow * sin(pi * _t));
}

/// THE INNER AND OUTER MARGINS, as one function of the station. Returns a POSITIVE offset except
/// at the apex, where it MEETS the costa - that shared endpoint is what closes the outline to a
/// point, and the two edges arriving there at very different slopes is what makes it a CORNER
/// rather than a smooth nose.
function cht_wing_trail(_w, _s) {
    var _t = clamp(_s, 0, 1);
    var _g = clamp(_w.trailAt, 0.10, 0.94);
    if (_t <= _g) {
        return lerp(_w.trail0, _w.trailMax, power(_t / _g, max(0.05, _w.rise)));
    }
    // The apex is wherever the costa ends, so the outer margin is aimed AT IT rather than at a
    // number of its own. Any other target opens a gap or crosses the leading edge.
    var _apex = -(lerp(_w.lead0, _w.lead1, 1.0));
    return lerp(_w.trailMax, _apex, power((_t - _g) / (1 - _g), max(0.05, _w.fall)));
}

/// The wing's half-chord at span fraction _s. Derived from the two edges rather than authored, so
/// there is only one description of the shape.
///
/// ⚠️ The `_side_of_chord` argument is retained and IGNORED: the two edges are now independent
/// functions, so "how full is this side" is no longer a property of the half-chord. Kept in the
/// signature because four call sites pass it and dropping it would be a silent behaviour change in
/// files this rewrite is not touching.
function cht_wing_halfc(_w, _s, _side_of_chord) {
    return (cht_wing_trail(_w, _s) - cht_wing_lead(_w, _s)) * 0.5;
}

/// The chord's own midline at span fraction _s. What `cht_wing_camber` used to be, except it is now
/// a CONSEQUENCE of the two edges instead of a term added to a symmetric shape.
function cht_wing_mid(_w, _s) {
    return (cht_wing_trail(_w, _s) + cht_wing_lead(_w, _s)) * 0.5;
}

/// A point on the wing, in WING space: _s along the span, _c across the chord where -1 is the
/// leading edge and +1 the trailing edge. This function is the file's argument, exactly as
/// cht_pat_pt is cht_pattern's.
function cht_wing_pt(_w, _s, _c) {
    var _cc = clamp(_c, -1, 1);
    return [_w.span * clamp(_s, 0, 1),
            cht_wing_mid(_w, _s) + _cc * cht_wing_halfc(_w, _s)];
}

/// The wing outline, closed: out along the costa, back along the margins.
function cht_wing_outline(_w, _n) {
    var _m = max(6, is_undefined(_n) ? CHT_WING_SAMPLES : _n);
    var _pts = [];
    for (var _i = 0; _i <= _m; _i++) {
        var _s = _i / _m;
        _pts[array_length(_pts)] = [_w.span * _s, cht_wing_lead(_w, _s)];
    }
    // ⛔ THE TAIL IS SPLICED BY STATION, NOT BY A COORDINATE TEST. The first version detected the
    // splice point with `pts[i][0] < b[0] && pts[i-1][0] >= b[0] && pts[i][1] > 0` - a condition
    // that reads x AND y off an outline whose y can now be negative near the apex, so it silently
    // stopped firing. Walking the trailing edge here means the station is simply KNOWN.
    // A SWALLOWTAIL'S TAIL IS SPATULATE, IT HANGS BACKWARD, AND IT MUST SURVIVE CABINET SIZE.
    //
    // ⚠️ MEASURED on the first contact sheet: at 0.150 of the span, with a stalk two chord
    // hundredths wide and pointing outward, it was invisible at 90 px - which is the size the
    // product's own contact sheet draws a specimen at. A field mark nobody can see is one the
    // identification screen cannot ask about.
    //
    // ⛔⛔ AND THE FIRST REWRITE OF IT SPLICED SIX POINTS IN BETWEEN TWO ADJACENT MARGIN SAMPLES,
    // WHICH MADE THE OUTLINE WIND TWICE. MEASURED by cht_selftest on its very first run:
    // `tailed hindwing: outline turns 2.000`. The two roots of the stalk were about a fifth of a
    // tail-length apart while the margin step they were inserted into is a twentieth of that, so
    // the walk ran left to the far root, right past its own entry point, and left again - a
    // backtrack, i.e. a crossing.
    //
    // ⭐ THE FIX IS THAT A TAIL REPLACES A RUN OF THE MARGIN RATHER THAN BEING PUSHED BETWEEN TWO
    // SAMPLES OF IT. The stalk's two roots ARE margin points, at stations a tenth of the span
    // either side of the tail, and the samples between them are skipped. An appendage wide enough
    // to see needs a base wide enough to attach to, and inserting one into a gap narrower than
    // itself is a crossing every time.
    var _tailAt = 0.58;
    var _gap = 0.10;
    var _done = false;
    for (var _i = _m; _i >= 0; _i--) {
        var _s = _i / _m;
        if (_w.tail > 0 && !_done && _s <= _tailAt + _gap) {
            var _sa = _tailAt + _gap;
            var _sb = _tailAt - _gap;
            var _ax = _w.span * _sa, _ay = cht_wing_trail(_w, _sa);
            var _bx = _w.span * _sb, _by = cht_wing_trail(_w, _sb);
            var _tx = (_ax + _bx) * 0.5 - _w.tail * 0.34;
            var _ty = (_ay + _by) * 0.5 + _w.tail;
            var _sw = _w.tail * 0.130;
            _pts[array_length(_pts)] = [_ax, _ay];
            _pts[array_length(_pts)] = [_tx + _sw * 1.7, _ty - _w.tail * 0.30];
            _pts[array_length(_pts)] = [_tx + _sw * 1.5, _ty - _w.tail * 0.06];
            _pts[array_length(_pts)] = [_tx + _sw * 0.6, _ty];
            _pts[array_length(_pts)] = [_tx - _sw * 0.9, _ty - _w.tail * 0.04];
            _pts[array_length(_pts)] = [_tx - _sw * 1.6, _ty - _w.tail * 0.34];
            _pts[array_length(_pts)] = [_bx, _by];
            _done = true;
        }
        if (_w.tail > 0 && _s < _tailAt + _gap && _s > _tailAt - _gap) continue;
        _pts[array_length(_pts)] = [_w.span * _s, cht_wing_trail(_w, _s)];
    }
    return cht_dedupe_pts(_pts);
}

/// The wing's WIDEST chord, which is what every mark on it is sized against.
///
/// ⚠️ DERIVED, NOT A FIELD. It was a field (`chord`) in the lens model and it is now a consequence
/// of two edges, so keeping it as a stored number would give the file two descriptions of one
/// shape - the exact defect the corpus name arrays were carrying elsewhere in this package on the
/// same day.
function cht_wing_chord(_w) {
    return 2 * cht_wing_halfc(_w, _w.trailAt, 1);
}

/// ============================================================================================
/// THE RESOLUTION FLOOR
/// ============================================================================================

/// How many main veins to actually draw on a wing drawn _px pixels across.
///
/// ⭐ RETURNED, NOT APPLIED SILENTLY - the same contract as the elytral stria count and the leg
/// pairs. A level-of-detail decision hidden inside a draw call is one no caller can reason about,
/// and the identification screen needs to be able to say what the wing HAS while the cabinet
/// thumbnail draws what it can.
/// ⛔ 7.0 PIXELS PER VEIN, NOT 3.0, AND THE OLD NUMBER MADE THIS FUNCTION DEAD CODE.
///
/// MEASURED by cht_selftest's vacuity guard on its first run: `cht_wing_fit(7, 700)` and
/// `cht_wing_fit(7, 40)` both returned SEVEN. At three pixels of spacing the reduction loop can
/// only fire below 24 px, and the cutoff below returns 0 there anyway - so the loop had never
/// executed once in the product's life and the level-of-detail rule this file's header describes
/// did not exist. A rule that cannot change its answer is not a rule.
///
/// Seven pixels is the honest figure: GML floors a stroke at 1.0 px with no antialiasing, so a vein
/// needs several pixels of membrane either side of it or seven of them are a grey smear. The
/// argument is the WING'S drawn width, not the animal's - see the call site in cht_wing_pair.
function cht_wing_fit(_want, _px) {
    if (_want <= 0 || _px <= 0) return 0;
    var _n = _want;
    while (_n > 1 && (_px / (_n + 1)) < 7.0) _n -= 1;
    if (_px < 24) return 0;
    return _n;
}

/// ============================================================================================
/// VENATION
/// ============================================================================================

/// One vein and its branches, as tapering ribbons.
///
/// ⛔ THE BRANCH IS THINNER THAN ITS PARENT AND STARTS ON IT, NOT NEAR IT. A branch that begins in
/// open membrane is a scratch; a branch of the same width as its parent is a fork in a road. Both
/// destroy the one property that makes venation read as venation.
/// ⛔⛔ A VEIN ENDS AT ITS OWN POINT ON THE MARGIN. IT DOES NOT RUN THE WHOLE SPAN.
///
/// MEASURED 2026-09-01 by opening big_24 and big_42 and looking at the wings: the venation read as
/// a set of NESTED ARCS, like contour lines on a map or the growth lines on a shell. Every vein ran
/// from station 0.06 to station 0.96 - the full length of the wing - and differed from its
/// neighbour only by an offset ACROSS the chord, so twelve of them are twelve parallel curves
/// however far apart their endpoints are.
///
/// ⭐ THE DEFECT WAS IN THE ENDPOINTS, NOT THE SPREAD, AND THE OLD COMMENT SAYS SO WITHOUT
/// NOTICING: it claims the veins "spread across the chord at the margin, which is what a real wing
/// does". They did spread. But a real wing's veins spread by ENDING IN DIFFERENT PLACES AROUND THE
/// MARGIN - some at the apex, some on the outer margin, some on the trailing edge barely half way
/// along - and they all START at one point, the wing base. That is what makes it a FAN. Two veins
/// that both run the entire span cannot fan no matter where across the chord they sit.
///
/// So the terminus now walks the margin: `_te` is 0 at the apex and 1 at the innermost trailing
/// vein, and the station falls with it. The start is a small spread at the base rather than a third
/// of the chord.
function cht_wing_vein(_w, _cbase, _sEnd, _cEnd, _w0, _depth, _rng) {
    var _out = [];
    var _steps = 12;
    var _pts = array_create(_steps + 1);
    var _s0 = 0.04;
    for (var _i = 0; _i <= _steps; _i++) {
        var _u = _i / _steps;
        // The station advances slightly ahead of the chord drift, so the vein leaves the base
        // running ALONG the wing and swings out to its terminus late. A linear pair reads as a
        // straight spoke; this is the shallow S a real vein has.
        var _s = lerp(_s0, _sEnd, power(_u, 0.88));
        var _c = lerp(_cbase, _cEnd, power(_u, 1.35));
        _pts[_i] = cht_wing_pt(_w, _s, _c);
    }
    cht_append(_out, cht_taper_ribbon(_pts, _w0, _w0 * 0.34, "m1"));

    if (_depth > 0) {
        // The branch leaves the parent at about two thirds of its run and heads for the margin
        // OUTBOARD of its parent's terminus - a cross-vein that runs back inboard is a scratch.
        var _bu = 0.62;
        var _bs = lerp(_s0, _sEnd, power(_bu, 0.88));
        var _bc = lerp(_cbase, _cEnd, power(_bu, 1.35));
        var _to = clamp(_cEnd + (0.10 + 0.14 * cht_rng_next(_rng)), -0.96, 0.96);
        var _ts = clamp(_sEnd - 0.10 - 0.08 * cht_rng_next(_rng), 0.12, 0.985);
        var _bp = array_create(7);
        for (var _i = 0; _i < 7; _i++) {
            var _u2 = _i / 6;
            _bp[_i] = cht_wing_pt(_w, lerp(_bs, _ts, _u2), lerp(_bc, _to, _u2));
        }
        cht_append(_out, cht_taper_ribbon(_bp, _w0 * 0.62, _w0 * 0.22, "m1"));
    }
    return _out;
}

/// The whole venation of one wing: a FAN from the base to the margin.
///
/// The terminus walks around the wing's edge. The first veins run right out to the apex; the last
/// ones stop less than half way along the trailing edge. `_te` is that walk, 0 at the apex.
function cht_wing_venation(_w, _n, _w0, _seed) {
    var _out = [];
    if (_n <= 0) return _out;
    var _rng = cht_rng(9173 + _seed * 61 + _n * 13);
    for (var _k = 0; _k < _n; _k++) {
        var _te = (_k + 0.5) / _n;
        // Where on the margin this vein comes out.
        //   near the apex   : station high, chord swinging from the LEADING edge round to trailing
        //   further round   : station falling, chord pinned to the trailing edge
        var _sEnd, _cEnd;
        if (_te < 0.34) {
            var _u = _te / 0.34;
            _sEnd = lerp(0.975, 0.900, _u);
            _cEnd = lerp(-0.55, 0.92, _u);
        } else {
            var _u2 = (_te - 0.34) / 0.66;
            _sEnd = lerp(0.900, 0.240, power(_u2, 0.90));
            _cEnd = 0.94;
        }
        // All the veins leave the base within a narrow bundle, which is the anatomy: they emerge
        // from one articulation. The small spread keeps them from drawing over each other there.
        var _cbase = -0.30 + 0.55 * _te;
        cht_append(_out, cht_wing_vein(_w, _cbase, _sEnd, _cEnd, _w0,
                                       (_k % 2 == 0) ? 1 : 0, _rng));
    }
    return _out;
}

/// ============================================================================================
/// THE MEMBRANE
/// ============================================================================================

/// The membrane, as bands running along the span.
///
/// ⚠️ A WING IS NEARLY FLAT, SO ITS SHADING IS SUBTLE AND ITS DIRECTION IS NOT THE BODY'S. The body
/// is a tube and takes a strong across-the-width gradient; a wing is a sheet held almost in the
/// plane of the picture, and the only real tonal variation on it is that the outer half is further
/// from the light and slightly in the body's shadow near the root. Giving a wing the body's tube
/// shading makes it read as a rolled tube of paper.
function cht_wing_membrane(_w, _nb, _prefix) {
    var _out = [];
    if (_nb <= 0) return _out;
    var _rows = 22;
    for (var _b = 0; _b < _nb; _b++) {
        var _c0 = -1 + 2 * (_b / _nb);
        var _c1 = -1 + 2 * ((_b + 1) / _nb);
        var _ra = array_create(_rows + 1);
        var _rb = array_create(_rows + 1);
        for (var _i = 0; _i <= _rows; _i++) {
            var _s = _i / _rows;
            _ra[_i] = cht_wing_pt(_w, _s, _c0);
            _rb[_i] = cht_wing_pt(_w, _s, _c1);
        }
        array_push(_out, cht_strip(_ra, _rb, _prefix + string(_b)));
    }
    return _out;
}

/// ============================================================================================
/// PATTERN, IN WING SPACE
/// ============================================================================================

/// A band running ACROSS the wing at span fraction _s. This is the shape a butterfly's bands
/// actually take - they follow the outer margin, so they run across the chord, not along it.
function cht_wing_band(_w, _sa, _sb, _inset, _role) {
    var _n = 12;
    var _a = array_create(_n + 1), _b = array_create(_n + 1);
    var _k = 1 - clamp(_inset, 0, 0.9);
    for (var _i = 0; _i <= _n; _i++) {
        var _c = -_k + 2 * _k * (_i / _n);
        _a[_i] = cht_wing_pt(_w, _sa, _c);
        _b[_i] = cht_wing_pt(_w, _sb, _c);
    }
    return cht_strip(_a, _b, _role);
}

/// The radius a spot may have at (_s,_c): it must fit the chord at EVERY station it covers, not
/// only at its own centre. Split out from the drawing so an ocellus can size itself from its
/// OUTERMOST ring and then put every ring on that one centre - see cht_wing_ocellus.
/// ⛔ THE RADIUS IS CONVERTED TO A SPAN FRACTION BEFORE IT IS ADDED TO A STATION, AND THE FIRST
/// VERSION DID NOT DO THAT. `_s` is 0..1 along the span and `_r` is a LENGTH in unit-box units, so
/// `_s - _r` subtracted about 0.036 from a fraction where the honest figure is `_r / span`, roughly
/// 0.082 - the check looked two and a half times less far along the wing than the spot actually
/// reaches. A units error inside a containment check is the worst place for one: it does not fail,
/// it just stops covering the range it claims to. Found by writing the honest circle-in-wing test
/// in cht_selftest and asking why it disagreed with the clipper.
/// ⚠️ AND THE CHORD'S MIDLINE MOVES ALONG THE WING WHILE A CIRCLE DOES NOT FOLLOW IT. Taking the
/// narrowest half-chord over the spot's span is necessary and not sufficient: on a raked wing the
/// whole chord slides forward as the station advances, so a spot centred on the midline at its own
/// station is off-centre at the stations either side of it, by exactly that slide. Both terms are
/// subtracted here.
/// ⛔⛔ AND THE SPAN IT CHECKS OVER IS ITS OWN FINAL RADIUS, NOT THE ONE IT WAS ASKED FOR. THE
/// FIRST VERSION SOLVED THE WRONG PROBLEM AND THEN HALVED THE ANSWER.
///
/// MEASURED 2026-09-01 by opening big_24 and big_42: a peacock butterfly and an EMPEROR MOTH - two
/// animals whose eyespots are the entire reason anybody can name them - rendered with ocelli about
/// eight pixels across on a five hundred pixel wing, while the caption beside them read
/// "pattern eyespot x4". A caption is a claim, and that one was not supported by the picture.
///
/// TWO compounding causes, and both are the same mistake in different clothes:
///
///   1. The range was computed from the REQUESTED radius. A big request reaches back into the
///      narrow inner wing, finds almost no room there, and returns a tiny radius - which would
///      have fitted comfortably over its OWN much shorter range. The bigger you ask, the smaller
///      you get, which is a feedback loop rather than a containment rule.
///   2. `* 0.50` then halved whatever survived. A radius equal to the narrowest half-chord over the
///      range TOUCHES both edges; half of it is a spot a quarter of the width the wing can hold.
///
/// ⭐ The honest form is a FIXED POINT: guess a radius, measure the room over the range THAT radius
/// actually covers, take the smaller, repeat. It converges in three passes because the room is
/// monotone in the range. The margin is then a real margin (0.90, keeping the rim off the edge)
/// rather than a factor doing the containment's job for it.
/// ⛔⛔⛔ AND THE FIRST ATTEMPT AT THAT FIX WAS ITSELF WRONG, IN THE MOST INSTRUCTIVE WAY AVAILABLE:
/// IT DELETED EVERY OCELLUS IN THE CORPUS INSTEAD OF SHRINKING THEM.
///
/// MEASURED 2026-09-01 by re-rendering big_24 after "fixing" this function as an iterated fixed
/// point (`_rr = min(_rr, room(_rr) * 0.90)`, three passes). The peacock came back with NO eyespots
/// at all where it had previously had small ones - STRICTLY WORSE than the defect being repaired,
/// and green on every mechanical check both times.
///
/// ⭐ THE ITERATION ONLY EVER SHRINKS. `min` is one-directional, so the moment any pass measures a
/// negative room the radius is zero, and every later pass then measures the room for a radius of
/// zero, finds it enormous, and takes the min - which is still zero. A fixed point that cannot
/// climb is not a fixed point, it is a ratchet, and its FIRST GUESS decides everything. The first
/// guess here is the full requested radius, whose range covers most of the wing, where the midline
/// slide on a raked wing exceeds the half-chord - so the first measurement is negative almost
/// always.
///
/// The honest form is a BISECTION on a monotone predicate. `room(r)` falls as r rises, so "does a
/// disc of radius r fit here" flips exactly once; ten halvings find that crossing to within a
/// thousandth of the request and cannot get stuck at either end.
/// ⛔⛔⛔⛔ AND THE PREDICATE HAS TO BE THE REAL QUESTION, NOT A PROXY FOR IT. The first bisection
/// asked "is the narrowest HALF-CHORD over this range at least the radius", which is the right
/// question for a disc centred ON THE MIDLINE - and this file does not put them there.
/// cht_wing_spot_c offsets a spot to chord fraction `_c`, so the proxy was answering about a
/// different circle than the one that gets drawn. With the old 0.50 factor the error was buried in
/// the slack; at 0.90 it surfaced immediately and cht_selftest said so: "2 of 40 wing spots reach
/// outside the wing at some station they cover".
///
/// ⭐ So the predicate is now the HONEST test, the same one the suite states the contract as: put
/// the circle where it will actually be drawn, walk eleven stations across its own width, and
/// require its top and bottom at each station to lie between the two edges there. It is not
/// circular reasoning to make the sizer satisfy the spec the suite checks - the suite re-derives
/// that test from cht_wing_lead and cht_wing_trail independently, and still fails if this drifts.
function _cht_wing_circle_fits(_w, _cx, _cy, _rr) {
    for (var _i = 0; _i <= 10; _i++) {
        var _dx = -_rr + 2 * _rr * (_i / 10);
        var _h = sqrt(max(0, _rr * _rr - _dx * _dx));
        var _ss = (_cx + _dx) / max(0.0001, _w.span);
        if (_ss < 0 || _ss > 1) return false;
        if (_cy - _h < cht_wing_lead(_w, _ss)) return false;
        if (_cy + _h > cht_wing_trail(_w, _ss)) return false;
    }
    return true;
}

/// Would a spot of radius _rr, placed the way cht_wing_spot_c places it, stay inside the wing?
function _cht_wing_spot_fits(_w, _s, _c, _rr) {
    if (_rr <= 0) return true;
    var _p = cht_wing_spot_c(_w, _s, _c, _rr);
    return _cht_wing_circle_fits(_w, _p[0], _p[1], _rr);
}

function cht_wing_spot_r(_w, _s, _c, _r) {
    if (_r <= 0) return 0;
    // The whole request fits: no search needed.
    if (_cht_wing_spot_fits(_w, _s, _c, _r)) return _r;
    var _lo = 0, _hi = _r;
    for (var _k = 0; _k < 12; _k++) {
        var _md = (_lo + _hi) * 0.5;
        if (_cht_wing_spot_fits(_w, _s, _c, _md)) _lo = _md; else _hi = _md;
    }
    // Below about a two hundredth of the span a mark is a speck at any drawn size. Report nothing
    // rather than a dot the buyer will read as a rendering artefact.
    return (_lo < _w.span * 0.02) ? 0 : _lo;
}

/// The centre a spot of radius _rr must sit at to stay inside the wing. The 1.25 is deliberate
/// slack: the sizing above is an approximation over nine samples, and a mark that lands exactly on
/// the margin reads as a bite out of the wing rather than as a spot on it.
function cht_wing_spot_c(_w, _s, _c, _rr) {
    var _h = max(0.0001, cht_wing_halfc(_w, _s, _c));
    return cht_wing_pt(_w, _s, clamp(_c * (1 - (_rr * 1.25) / _h), -1, 1));
}

/// A spot, sized so it fits the chord at every station it covers rather than only at its centre.
function cht_wing_spot(_w, _s, _c, _r, _role) {
    var _rr = cht_wing_spot_r(_w, _s, _c, _r);
    if (_rr <= 0) return [];
    var _p = cht_wing_spot_c(_w, _s, _c, _rr);
    return [cht_dot(_p[0], _p[1], _rr, _role)];
}

/// ⛔ AN OCELLUS IS CONCENTRIC, AND CALLING cht_wing_spot THREE TIMES DOES NOT PRODUCE ONE.
///
/// MEASURED 2026-09-01 by opening the peacock preview: the eyespots rendered as a pale blob with a
/// dark S curled through it. Each ring was nudged inboard by its OWN radius to keep it inside the
/// wing, so the three rings sat at three different centres - correctly contained, and not an eye.
/// The bigger the ring, the further it moved, which is precisely a spiral.
///
/// ⭐ The general form, and this wing has now paid for it in two coordinate spaces: A CONTAINMENT
/// CORRECTION APPLIED PER PART BREAKS ANY RELATIONSHIP BETWEEN THOSE PARTS. Size the correction
/// from the OUTERMOST element and apply that one offset to all of them, or the group stops being a
/// group. (The body's cht_fit_unit gets this right by construction - it scales a finished list.)
/// ⛔ AND AN OCELLUS IS DARK-PALE-DARK, WHICH `ink` CANNOT EXPRESS. MEASURED the same pass.
///
/// Everywhere else in this package a mark is set in `ink`, and that is right: cht_chroma_ink is
/// defined RELATIVE to its own ground and goes the other way from it, so one pattern program serves
/// a chalk-white marbled white and a pitch-black burying beetle. But an eyespot is not a mark, it
/// is a STRUCTURE with a fixed internal order - a dark ring, a bright iris, a dark pupil - and on
/// the peacock's mid-dark red cuticle `ink` resolves to L 0.84, i.e. PALE. Three pale-ish rings on
/// red rendered as a putty blob with a dark arc through it, which is what "correct code, wrong
/// question" looks like.
///
/// ⭐ The distinction is worth keeping: `ink` answers "what contrasts with this surface". An
/// ocellus needs "what is DARK on this surface" and "what is BRIGHT on it", which are the ramp's
/// own ends - m0 and ink - used as a pair rather than singly.
function cht_wing_ocellus(_w, _s, _c, _r) {
    var _out = [];
    var _rr = cht_wing_spot_r(_w, _s, _c, _r);
    if (_rr <= 0) return _out;
    var _p = cht_wing_spot_c(_w, _s, _c, _rr);
    array_push(_out, cht_dot(_p[0], _p[1], _rr,        "m0"));
    array_push(_out, cht_dot(_p[0], _p[1], _rr * 0.66, "ink"));
    array_push(_out, cht_dot(_p[0], _p[1], _rr * 0.30, "m0"));
    return _out;
}

/// Every mark on one wing.
///
/// The programs are the same eight as cht_pattern's, deliberately - a species has ONE pattern and
/// it should read the same whether it is written on an elytron or on a wing. What differs is only
/// the coordinate space it is written into.
function cht_wing_pattern(_w, _pat, _n, _cut, _px) {
    var _out = [];
    if (_px < 30 || _n <= 0) return _out;

    switch (clamp(_pat, 0, CHT_PAT_N - 1)) {
        case CHT_PAT_BANDED: {
            for (var _k = 0; _k < _n; _k++) {
                var _c = 0.22 + 0.68 * ((_k + 0.5) / _n);
                var _h = 0.68 / _n * 0.32;
                array_push(_out, cht_wing_band(_w, _c - _h, _c + _h, 0.08, "ink"));
            }
        } break;

        case CHT_PAT_SPOTTED: {
            var _rng = cht_rng(4127 + _n * 29);
            for (var _k = 0; _k < _n; _k++) {
                var _s = 0.30 + 0.58 * (_k / max(1, _n - 1));
                var _c = -0.52 + 1.04 * cht_rng_next(_rng);
                cht_append(_out, cht_wing_spot(_w, _s, _c, cht_wing_chord(_w) * 0.20, "ink"));
            }
        } break;

        case CHT_PAT_STRIPED: {
            for (var _k = 0; _k < _n; _k++) {
                var _c = -0.80 + 1.60 * ((_k + 0.5) / _n);
                var _hw = 1.60 / _n * 0.30;
                var _rows = 14;
                var _a = array_create(_rows + 1), _b = array_create(_rows + 1);
                for (var _i = 0; _i <= _rows; _i++) {
                    var _s = 0.12 + 0.80 * (_i / _rows);
                    _a[_i] = cht_wing_pt(_w, _s, _c - _hw);
                    _b[_i] = cht_wing_pt(_w, _s, _c + _hw);
                }
                array_push(_out, cht_strip(_a, _b, "ink"));
            }
        } break;

        case CHT_PAT_MARBLED: {
            var _rng2 = cht_rng(5231 + _n * 37);
            for (var _k = 0; _k < _n * 4; _k++) {
                var _s = 0.14 + 0.78 * cht_rng_next(_rng2);
                var _c = -0.86 + 1.72 * cht_rng_next(_rng2);
                cht_append(_out, cht_wing_spot(_w, _s, _c,
                    cht_wing_chord(_w) * (0.10 + 0.14 * cht_rng_next(_rng2)), "ink"));
            }
        } break;

        case CHT_PAT_EYESPOT: {
            // An ocellus sits near the OUTER MARGIN of a wing, because that is what it is for - it
            // draws a strike away from the body. Putting it near the root is both wrong and
            // pointless, and it is the sort of detail that decides whether a drawing looks studied.
            // ⚠️ 0.44 TO 0.66, NOT 0.62 TO 0.84. Moving the widest station of the wing inboard -
            // which is what gave the forewing a long straight outer margin instead of a paddle end
            // - left the old eyespot stations out where the chord is closing, so cht_wing_spot_r
            // correctly returned zero room and EVERY OCELLUS IN THE CORPUS SILENTLY STOPPED BEING
            // DRAWN. A shape change moves every mark authored against the old shape; the marks do
            // not report it, they just disappear.
            // ⛔ ONE PER WING, NOT TWO, AND THE DIVISOR IS THE FIELD MARK. A peacock butterfly has
            // FOUR eyespots on a spread specimen - one on each of its four wings - and that count is
            // what the identification screen asks the player for. `floor(_n / 2)` put two on every
            // wing and produced eight, which is not a species anybody can look up.
            //
            // ⚠️ AND THE STATION IS 0.56, WHICH IS WHERE THE WING IS WIDE OVER A LONG RUN. An
            // ocellus is a DISC, so cht_wing_spot_r has to find room for it at every station it
            // covers, not only under its own centre - and a big disc placed at 0.44 reaches back to
            // 0.23, where a wing is narrow, so the sizing correctly crushed it to a speck. MEASURED
            // by opening big_24 and finding two white pinpricks where a peacock's eyes should be.
            // The fix is to place the mark where the room is, not to weaken the containment rule.
            //
            // ⛔⛔ AND THE STATION IS NOW THE WING'S OWN WIDEST ONE, READ OFF THE SPEC, NOT 0.56.
            // MEASURED again on 2026-09-01: 0.56 is a number that happened to suit ONE wing spec,
            // and this file carries fourteen of them plus a per-species variant table - the emperor
            // moth is broadest at 0.50 and the elephant hawk at 0.66, so a literal station puts the
            // biggest mark in the corpus somewhere the chord is closing on half of them. `trailAt`
            // is where the room IS, and it is already a field of every spec.
            var _m = max(1, floor(_n / 4));
            var _sWide = clamp(_w.trailAt, 0.30, 0.80);
            for (var _k = 0; _k < _m; _k++) {
                var _s = _sWide + 0.10 * (_k / max(1, _m - 0.001));
                var _c = -0.12 + 0.34 * (_k % 2);
                cht_append(_out, cht_wing_ocellus(_w, _s, _c, cht_wing_chord(_w) * 0.46));
            }
        } break;

        case CHT_PAT_RETICULATE: {
            for (var _k = 0; _k < _n; _k++) {
                var _c2 = 0.18 + 0.74 * ((_k + 0.5) / _n);
                array_push(_out, cht_wing_band(_w, _c2 - 0.022, _c2 + 0.022, 0.06, "ink"));
            }
        } break;

        default: break;   // PLAIN and METALLIC put no mark on a wing either.
    }
    return _out;
}

/// ============================================================================================
/// THE WHOLE WING PAIR
/// ============================================================================================

/// The two wings of one side, placed on the body.
///
/// ⛔ THE HINDWING GOES DOWN FIRST AND THE FOREWING OVER IT, WHICH IS BOTH THE ANATOMY AND THE ONLY
/// ORDER THAT READS. A resting Lepidopteran holds its forewing over its hindwing; drawn the other
/// way the hindwing's outer margin cuts across the forewing and the animal looks broken.
///
/// THE THREE WING FAMILIES, AS [forewing, hindwing].
///
/// ⚠️ SPLIT OUT OF cht_wing_pair SO THE SUITE READS THE SAME NUMBERS THE DRAWING DOES. A suite that
/// restates the values it is testing certifies whatever it was told; this factory has a live
/// receipt for that, on a listing that sold a pack at half its real size because a checker held the
/// same stale literal the page held. cht_selftest calls this function.
///
/// The families differ in three things and they are the three a field guide leads with:
///   BUTTERFLY  a long forewing with a raked costa and a SHARP apex (fall 2.1), over a small round
///              hindwing (fall 0.62). The difference in the two `fall` values is the difference
///              between the two wings, and it is what stopped four wings reading as one disc.
///   MOTH       a longer, narrower, blunter forewing held further back, over a BROAD hindwing that
///              is nearly as wide as the forewing - which is why a moth at rest is a triangle and a
///              butterfly is an hourglass.
///   TAILED     a swallowtail: a butterfly forewing over a hindwing carrying a real tail.
function cht_wing_pair_specs(_shape) {
    switch (clamp(_shape, 0, CHT_WSHAPE_N - 1)) {
        case CHT_WSHAPE_MOTH:
            //                          span  lead0  lead1   bow  trail0 trailMx trailAt rise fall  tail
            return [cht_wing_spec(0.545, 0.020, 0.074, 0.014, 0.024, 0.180, 0.66, 1.45, 2.30, 0),
                    cht_wing_spec(0.360, 0.018, 0.044, 0.012, 0.022, 0.178, 0.50, 1.20, 1.90, 0)];
        case CHT_WSHAPE_TAILED:
            return [cht_wing_spec(0.510, 0.020, 0.102, 0.022, 0.024, 0.198, 0.62, 1.45, 2.20, 0),
                    cht_wing_spec(0.340, 0.020, 0.046, 0.014, 0.022, 0.190, 0.48, 1.18, 1.85, 0.190)];
        default:
            return [cht_wing_spec(0.505, 0.020, 0.100, 0.022, 0.024, 0.202, 0.62, 1.45, 2.10, 0),
                    cht_wing_spec(0.340, 0.020, 0.048, 0.014, 0.022, 0.192, 0.48, 1.20, 1.80, 0)];
    }
}

/// ⛔⛔ THE WING VARIANT, PER SPECIES, BY NAME - AND WITHOUT IT TWELVE MOTHS ARE ONE MOTH.
///
/// MEASURED by cht_selftest's all-pairs sweep: with all twelve moths sharing one forewing spec and
/// all twelve butterflies sharing another, the sweep scored `garden tiger / lime hawk moth` at
/// 0.098 and `poplar hawk moth / lime hawk moth` at 0.067 - and a garden tiger is BRIGHT RED while
/// a lime hawk is olive green, so almost the whole of that small distance was colour. Their
/// silhouettes were the same picture. On a corpus whose headline is that the shape is generated,
/// three shapes across twenty-four Lepidoptera is the defect.
///
/// ⭐ IT IS A TABLE HERE RATHER THAN THREE MORE COLUMNS ON EVERY SPECIES ROW, and that is a real
/// decision: a wing modifier is meaningless for the twenty-four beetles, so putting it in cht_sp
/// would add seventy-two numbers of which half are noise nobody can read past. This reads off the
/// roster index exactly as the swallowtail's own wing shape already does.
///
///   spanK   how far the wing reaches. A death's head hawk moth is a glider; a blue is a scrap
///   chordK  how BROAD it is. This is the loudest of the three - it is the difference between a
///           tiger moth, which is a triangle, and a hawk moth, which is a dart
///   fallK   how sharp the apex is. Above 1 pulls the outer margin out to a point; below 1 rounds
///           it off. A brimstone's hooked apex and a common blue's round one are the same function
///           with this number moved
function cht_wing_variant(_i) {
    switch (_i) {
        // -- butterflies ---------------------------------------------------------------------
        case 24: return { spanK: 1.00, chordK: 1.12, fallK: 0.78 };  // peacock, broad and scalloped
        case 25: return { spanK: 1.02, chordK: 0.98, fallK: 1.28 };  // red admiral
        case 26: return { spanK: 1.05, chordK: 0.94, fallK: 1.40 };  // painted lady, falcate
        case 27: return { spanK: 0.91, chordK: 1.08, fallK: 0.84 };  // small tortoiseshell
        case 28: return { spanK: 1.00, chordK: 1.14, fallK: 1.95 };  // brimstone, a hooked leaf
        case 29: return { spanK: 0.96, chordK: 0.90, fallK: 0.68 };  // orange tip, round-tipped
        case 30: return { spanK: 0.82, chordK: 1.00, fallK: 0.60 };  // common blue, a scrap
        case 31: return { spanK: 0.87, chordK: 1.04, fallK: 0.66 };  // chalkhill blue
        case 32: return { spanK: 1.10, chordK: 1.00, fallK: 1.05 };  // swallowtail
        case 33: return { spanK: 1.12, chordK: 1.10, fallK: 1.15 };  // purple emperor, large
        case 34: return { spanK: 1.06, chordK: 0.99, fallK: 1.50 };  // silver washed fritillary
        case 35: return { spanK: 0.98, chordK: 1.07, fallK: 0.74 };  // marbled white
        // -- moths ------------------------------------------------------------------------------
        case 36: return { spanK: 1.07, chordK: 0.84, fallK: 1.62 };  // elephant hawk, a dart
        case 37: return { spanK: 0.95, chordK: 1.26, fallK: 0.68 };  // poplar hawk, broad
        case 38: return { spanK: 1.16, chordK: 0.82, fallK: 1.85 };  // death's head, a glider
        case 39: return { spanK: 0.86, chordK: 0.78, fallK: 1.50 };  // hummingbird hawk, stubby
        case 40: return { spanK: 0.90, chordK: 1.28, fallK: 0.60 };  // garden tiger, a triangle
        case 41: return { spanK: 1.00, chordK: 0.79, fallK: 1.32 };  // cinnabar, narrow
        case 42: return { spanK: 1.09, chordK: 1.30, fallK: 0.64 };  // emperor moth, big and round
        case 43: return { spanK: 0.99, chordK: 1.10, fallK: 1.08 };  // lime hawk, angular margin
        case 44: return { spanK: 0.94, chordK: 0.99, fallK: 1.26 };  // burnished brass
        case 45: return { spanK: 0.97, chordK: 1.04, fallK: 1.32 };  // angle shades, broad and folded
        case 46: return { spanK: 1.05, chordK: 0.70, fallK: 1.92 };  // buff tip, rolled like a twig
        default: return { spanK: 1.00, chordK: 0.76, fallK: 0.92 };  // six spot burnet, narrow
    }
}

/// Apply a variant to a wing spec. Returns a NEW spec; nothing mutates a shared struct.
function cht_wing_varied(_w, _v) {
    return cht_wing_spec(_w.span * _v.spanK,
                         _w.lead0 * _v.chordK, _w.lead1 * _v.chordK, _w.bow * _v.chordK,
                         _w.trail0 * _v.chordK, _w.trailMax * _v.chordK, _w.trailAt,
                         _w.rise, _w.fall * _v.fallK, _w.tail);
}

/// _shape is one of CHT_WSHAPE_*, _side -1 or +1, _bd the body (for the attachment point).
/// _seed doubles as the ROSTER INDEX, which is what selects the wing variant.
function cht_wing_pair(_bd, _shape, _side, _scale, _pat, _patn, _cut, _px, _nb, _prefix, _seed) {
    var _out = [];

    var _ws = cht_wing_pair_specs(_shape);
    var _v = cht_wing_variant(_seed);
    var _fore = cht_wing_varied(_ws[0], _v);
    var _hind = cht_wing_varied(_ws[1], _v);

    // Attachment. Both wings hang off the thorax and OVERLAP it - the wing bases disappear under
    // the thorax rather than meeting its outline, which is this package's standing rule for every
    // appendage and the reason no join in the animal shows a hairline of page.
    var _rootF = cht_body_socket(_bd, 0.255, _side, 0.62);
    var _rootH = cht_body_socket(_bd, 0.400, _side, 0.62);

    // ⛔ THE VEIN COUNT IS FITTED TO THE WING'S OWN DRAWN WIDTH, NOT TO THE ANIMAL'S. The first
    // version passed `_px * _scale` - the whole insect - and a forewing is only about 0.44 of that,
    // so the level-of-detail rule was reasoning about a picture more than twice the size of the one
    // it was deciding for. cht_selftest caught it from the other end, as a VACUITY failure: the
    // count came out at the full 7 for every size from 40 px to 700 px, i.e. the rule was never
    // doing anything at all. A level-of-detail decision that cannot change is not one.
    var _veins = cht_wing_fit(7, _px * _scale * _fore.span);

    // ⛔ THE TWO WINGS ARE HELD AT DIFFERENT ANGLES, AND THAT IS WHAT STOPS FOUR OF THEM READING AS
    // ONE DISC. A set butterfly carries its forewings ANGLED FORWARD, so the costa points ahead of
    // the thorax, and its hindwings back and down behind them; a moth at rest holds BOTH back,
    // roofwise over the abdomen, which is why a resting moth is a triangle and a spread butterfly
    // is an hourglass. The old model drew both wings straight out sideways and every Lepidopteran
    // in the corpus came out as a body between two ovals - the angle carries as much of the
    // identification as the outline does.
    //
    // ⚠️ THE SIGN FLIPS WITH THE SIDE, because _cht_wing_one MIRRORS the points before placing and
    // a mirror reverses the sense of a rotation. Angles are in radians, y down.
    // ⚠️ MEASURED BY LOOKING, TWICE. At -0.17 and 0.30 the two wings of a side overlapped into one
    // mass and the specimen read as a body with two paddles; a set butterfly carries its forewings
    // a good 25 degrees AHEAD of square and its hindwings behind them, and the ANGLE BETWEEN THEM
    // is what makes four wings read as four.
    //
    // ⛔⛔ AND THE THIRD MEASUREMENT CLOSED THE ANGLE BACK DOWN, BECAUSE 42 DEGREES OPENED A WEDGE
    // OF PAGE BETWEEN THE TWO WINGS. MEASURED 2026-09-01 by opening big_24 and big_42: on both, the
    // forewing's trailing edge and the hindwing's leading edge diverge from a common root and leave
    // a clean V of background between them on each flank. That is the same defect as ARCHITECTURE
    // section 5 rule 1 - "every appendage must OVERLAP the mass it grows from, never abut it" -
    // arriving BETWEEN two appendages instead of between an appendage and the body, and it reads
    // exactly as badly: four separate leaves rather than two wings per side.
    //
    // ⚠️ THE FIX IS THE ANGLE, NOT THE SPANS, and that is deliberate. Widening the hindwing would
    // close the gap too and would move every mark authored against the old chord - the eyespot
    // sizing above has already been through one shape change that silently deleted every ocellus in
    // the corpus. An angle costs nothing downstream.
    var _angF = -0.24, _angH = 0.30;
    if (_shape == CHT_WSHAPE_MOTH) { _angF = 0.24; _angH = 0.50; }

    // -- hindwing, underneath ------------------------------------------------------------------
    // ⛔⛔ `_side * _ang`, NOT `-_side * _ang`, AND THE INVERTED SIGN PUT EVERY FOREWING BELOW ITS
    // OWN HINDWING. MEASURED by opening big_24: the peacock's forewings - the long ones, the ones
    // carrying the eyespots - were raked DOWNWARD and the short hindwings stood up over them as two
    // slivers beside the thorax. The angles below are already SIGNED (negative is forward), so
    // negating them again is a second reversal on top of the mirror's.
    //
    // ⭐ It is the shape of error nothing mechanical can see: both wings were drawn, both were the
    // right size, both were inside the box, the outlines were simple and the suite was green at
    // 1,482 assertions. The animal was simply built upside down.
    cht_append(_out, _cht_wing_one(_hind, _rootH, _side, _scale, _pat, _patn, _cut, _px,
                                   max(0, _nb - 2), _prefix, _veins - 2, _seed + 1,
                                   _side * _angH));
    // -- forewing, over it ---------------------------------------------------------------------
    cht_append(_out, _cht_wing_one(_fore, _rootF, _side, _scale, _pat, _patn, _cut, _px,
                                   _nb, _prefix, _veins, _seed, _side * _angF));
    return _out;
}

/// THE DARK OUTER MARGIN - a band of scales along the termen, in the cuticle's own darker stop.
///
/// ⛔ THIS IS ANATOMY, NOT ORNAMENT ADDED TO SATISFY A COVERAGE FLOOR (this wing's standing warning
/// against leader rules and hairline dividers). Almost every Lepidopteran carries a darker border
/// along the outer margin of both wings, and on the first preview its absence was doing real
/// damage: the wings and the body resolved to ONE mass of one colour, because a wing painted in the
/// same ramp as the thorax with no edge of its own has nothing to end at.
///
/// It narrows to nothing at the apex by construction - the half-chord does - so it can never be a
/// blunt stripe across the wing tip.
function cht_wing_margin(_w, _px) {
    if (_px < 34) return [];       // below this it is one pixel, and one pixel of border is dirt
    var _n = 16;
    var _a = array_create(_n + 1), _b = array_create(_n + 1);
    // ⚠️ NARROW, AND STARTING LATE. The first version ran from 0.72 of the widest station at a
    // fifth of the chord deep, and on the contact sheet that is not a border, it is a black bar
    // along the bottom of each wing. A real marginal band is a rim.
    var _s0 = _w.trailAt * 0.88;
    for (var _i = 0; _i <= _n; _i++) {
        var _s = _s0 + (1 - _s0) * (_i / _n);
        _a[_i] = cht_wing_pt(_w, _s, 1.00);
        _b[_i] = cht_wing_pt(_w, _s, 0.87);
    }
    return [cht_strip(_a, _b, "m1")];
}

/// One wing: membrane, pattern, venation, rim. Private to this file.
///
/// ⛔ PAINTER'S ORDER IS THE WHOLE THING, AND THE FIRST VERSION HAD IT BACKWARDS. Membrane, then
/// the VEINS, then the PATTERN over them, then the rim last so the outline survives everything
/// drawn inside it.
///
/// The reasoning that put veins on top was "a vein is a structure in the wing and the scales are
/// laid on it, so a band that interrupts a vein reads as a printing error". That is true of the
/// MEMBRANE and false of the animal: a butterfly's colour is in SCALES lying on the outside of the
/// wing, so the veins show only faintly THROUGH them and an eyespot covers them completely.
/// MEASURED by opening the peacock preview - a vein ran straight across both eyespots, which is the
/// one mark on the animal that has to read as a single object.
function _cht_wing_one(_w, _root, _side, _scale, _pat, _patn, _cut, _px, _nb, _prefix, _veins,
                       _seed, _rot) {
    var _parts = [];

    var _pts = cht_wing_outline(_w, CHT_WING_SAMPLES);
    array_push(_parts, cht_ring_fill(_pts, "m2", _w.span * _w.trailAt, cht_wing_mid(_w, _w.trailAt)));
    // ⛔ THE SHADING BANDS ARE COUNTED ACROSS THE WING'S CHORD, NOT ACROSS THE ANIMAL. The caller's
    // _nb comes from cht_species_bands(animal px) - the same units mistake the vein count carried -
    // and a chord is about a quarter of the animal's width, so nineteen bands landed on a 28-pixel
    // chord at cabinet size. At one and a half pixels each they stop being a gradient and become
    // VERTICAL HATCHING, which is what the whole Lepidoptera half of the contact sheet looked like.
    // The cap is the caller's number, because the palette only holds that many entries.
    var _wnb = clamp(floor((cht_wing_chord(_w) * _px * _scale) / 5), 0, _nb);
    cht_append(_parts, cht_wing_membrane(_w, _wnb, _prefix));
    cht_append(_parts, cht_wing_venation(_w, _veins, 0.0055, _seed));
    cht_append(_parts, cht_wing_margin(_w, _px * _scale));
    cht_append(_parts, cht_wing_pattern(_w, _pat, _patn, _cut, _px * _scale));

    var _rel = cht_wing_outline(_w, 14);
    cht_append(_parts, cht_bevel(_rel, cht_bevel_cap(_rel, 0.012), 2, false));

    // A wing is authored pointing along +x from its own root. Mirroring for the left side is a
    // scale of -1 on x, which cht_place cannot express - it takes a uniform scale and a rotation -
    // so the mirror is done here on the points, before placing.
    if (_side < 0) {
        for (var _i = 0; _i < array_length(_parts); _i++) {
            _parts[_i] = _cht_wing_mirror(_parts[_i]);
        }
    }
    return cht_place(_parts, _root[0], _root[1], _scale,
                     is_undefined(_rot) ? 0 : _rot, _scale);
}

/// Mirror one part about x = 0. Private.
///
/// ⚠️ MIRRORING AN ARC MUST FLIP ITS ANGLES, NOT JUST ITS CENTRE, and the sweep direction reverses
/// with it. Nothing in a wing currently emits an arc, but a part list is a part list and a builder
/// that silently drew a mirrored arc wrongly would be found on some future sheet rather than here.
function _cht_wing_mirror(_p) {
    switch (_p.kind) {
        case CHT_DOT: return cht_dot(-_p.cx, _p.cy, _p.r, _p.role);
        case CHT_ARC: return cht_arc(-_p.cx, _p.cy, _p.r, pi - _p.a0, pi - _p.a1, _p.w, _p.role);
        case CHT_STRIP: {
            var _a = array_create(array_length(_p.a));
            var _b = array_create(array_length(_p.b));
            for (var _i = 0; _i < array_length(_p.a); _i++) _a[_i] = [-_p.a[_i][0], _p.a[_i][1]];
            for (var _i = 0; _i < array_length(_p.b); _i++) _b[_i] = [-_p.b[_i][0], _p.b[_i][1]];
            return cht_strip(_a, _b, _p.role);
        }
        case CHT_FILL: {
            var _q = array_create(array_length(_p.pts));
            for (var _i = 0; _i < array_length(_p.pts); _i++) _q[_i] = [-_p.pts[_i][0], _p.pts[_i][1]];
            return cht_fill(_q, _p.role);
        }
        default: {
            var _r = array_create(array_length(_p.pts));
            for (var _i = 0; _i < array_length(_p.pts); _i++) _r[_i] = [-_p.pts[_i][0], _p.pts[_i][1]];
            return cht_poly(_r, _p.closed, _p.w, _p.role);
        }
    }
}
