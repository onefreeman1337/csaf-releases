{
  "$GMScript": "v1",
  "%Name": "cht_cabinet",
  "name": "cht_cabinet",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}