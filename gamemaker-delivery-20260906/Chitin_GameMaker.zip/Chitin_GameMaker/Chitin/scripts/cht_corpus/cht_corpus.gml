/// CHITIN - cht_corpus. Every name in the package, in one place.
///
/// ============================================================================================
/// WHY THE NAMES LIVE HERE AND NOT BESIDE THE THING THEY NAME
///
/// Each builder in this package switches on an integer, and integers are what a buyer's save file
/// and their item definitions will hold. The NAMES are a presentation layer over those integers,
/// and keeping them together does two things:
///
///   1. It makes the corpus countable. cht_corpus_forms() below adds up what is actually in the
///      package, from the same arrays the labels come from, so the number on the store page cannot
///      drift from the number in the code. CLAUDE.md 2b records a live listing that sold a pack at
///      HALF its real size because a figure was TYPED into a checker instead of derived - the
///      checker held the same stale literal the page held, and certified the staleness it existed
///      to catch.
///   2. It makes translation one file. A buyer shipping in French replaces this file and nothing
///      else; every builder keeps working because none of them contains a word.
///
/// THE ARRAYS ARE INDEX-PARALLEL WITH THE SWITCHES THEY NAME, and that is a shared fact with two
/// declarations - exactly the shape CLAUDE.md 2b warns about. It is checked rather than trusted:
/// cht_selftest asserts array_length against every CHT_*_N macro, so adding a body plan and
/// forgetting its name fires by name instead of drawing an unlabelled insect.
///
/// A NOTE ON THE SPECIES NAMES. They are ENGLISH VERNACULAR NAMES OF REAL INSECTS, chosen because
/// a buyer's player recognises "stag beetle" and does not recognise a genus. They are NOT
/// scientific names and this package does not claim taxonomic authority: it claims that a stag
/// beetle drawn from these numbers looks like a stag beetle. Where a name is a group rather than a
/// species (there are hundreds of tiger beetles) it is used as the group, deliberately.
/// ============================================================================================

/// The six body plans. Everything else in the package is drawn ONTO one of these.
///
/// A body plan is the whole silhouette, not a part of it. Wings/RPGMaker/CLAUDE.md 22a-1b measured
/// what happens when a body is assembled from adjacent closed shapes: at reading size it becomes
/// "a circle, an oval and a blob". So a plan here is ONE continuous outline from head to abdomen
/// tip, and the constrictions between tagmata are changes of direction in that outline rather than
/// seams between shapes.
function cht_plan_names() {
    return ["elytra closed", "elytra open", "wings spread", "wings folded",
            "soft bodied", "larval"];
}

/// The patterning programs. Each takes the body outline and writes marks INTO its own coordinate
/// space, so a band follows the curve of the abdomen it is drawn on rather than crossing a
/// rectangle laid over it.
function cht_pattern_names() {
    return ["plain", "banded", "spotted", "striped", "marbled", "eyespot",
            "reticulate", "metallic sheen"];
}

/// Wing shapes. A plan picks the pair, a species moves the numbers, and each is a real switch case
/// in cht_wing_pair - so this array is index-parallel with CHT_WSHAPE_* and cht_selftest says so.
///
/// ⛔ THIS ARRAY REPLACED A `cht_venation_names()` THAT NAMED SIX FORMS THE PACKAGE DOES NOT HAVE.
/// MEASURED 2026-09-01: it returned ["beetle hindwing", "moth", "butterfly", "lacewing", "fly",
/// "none"] and NOTHING in the package switched on it - there is one venation algorithm,
/// parameterised by a vein count, and there is not a lacewing or a fly in the 48-species roster.
/// Those six phantom forms were being ADDED INTO cht_corpus_forms(), i.e. into the figure the store
/// listing quotes, which is the same defect this file's own header condemns for "aristate": a
/// component the buyer pays for and can never see. The three below are real and are drawn.
function cht_wing_shape_names() {
    return ["butterfly", "moth", "tailed"];
}

/// Antennae. The loudest identification mark on a real insect and the one a player learns first.
///
/// Wings/RPGMaker/CLAUDE.md 22a-2c: an accessory reads by POSITION before geometry, and "on top of
/// the head" is the position the eye assigns to EARS. On an insect that placement is correct and
/// unavoidable, so the risk runs the other way - a moth with large plumose antennae can read as a
/// rabbit at thumbnail size. That is a contact-sheet question, not a code question, and it is
/// written down here so the first bake looks for it.
/// ⚠️ "aristate" WAS HERE AND WAS REPLACED BY "moniliform" WHEN THE FORMS WERE BUILT, 2026-09-01.
/// An arista is a FLY's antenna - a stub carrying one long bristle - and there is not a single fly
/// in the 48-species roster below. Shipping a form no species in the package uses is a component
/// the buyer pays for and can never see, and it would have been counted in cht_corpus_forms().
/// Moniliform - a string of beads - occurs in the darkling and termite groups this roster does
/// reach, and cht_antenna implements it.
function cht_antenna_names() {
    return ["filiform", "clavate", "lamellate", "pectinate", "plumose",
            "geniculate", "moniliform", "serrate"];
}

/// Legs. Six of them, which makes this the densest thin-appendage subject this studio has drawn.
///
/// Wings/RPGMaker/CLAUDE.md 22a-2b: an appendage below about 0.05 unit half-width reads as a hair,
/// and three of them read as legs. Here they ARE legs, so the floor is not about identity - it is
/// about whether six of them at cabinet size read as an insect or as a smudge. Expect a
/// level-of-detail rule rather than a single width.
function cht_leg_names() {
    return ["cursorial", "fossorial", "natatorial", "raptorial", "saltatorial"];
}

/// Pronotum and elytra sculpture - the surface texture that makes a beetle read as chitin rather
/// than as a painted oval.
function cht_sculpture_names() {
    return ["smooth", "punctate", "striate", "costate", "rugose",
            "granulate", "tuberculate"];
}

/// THE CUTICLES. Eighteen of them, index-parallel with cht_cuticle_spec's switch and with the
/// `name_i` field each of its rows carries.
///
/// ⛔ THIS ARRAY REPLACED A SIX-ENTRY `cht_chroma_names()` AND THE MISMATCH WAS ALREADY BEING
/// PAPERED OVER AT A CALL SITE. MEASURED 2026-09-01: that array returned six SURFACE FINISHES
/// ("matte", "waxy", "glossy", "velvet", "structural", "translucent"), no switch in the package
/// took those as an argument, and cht_bk_big printed a cuticle's name with
/// `cht_name_of(cht_chroma_names(), min(4, _sp.cut))` - so every one of the twelve cuticles above
/// index 4 was captioned "structural" on a store-bound plate, including the oxblood longhorn, which
/// is not structural at all. A clamp inside a lookup is a lookup that has given up.
///
/// ⭐ AND THE RECOUNT WENT THE RIGHT WAY. Deleting six phantom venations and six phantom finishes
/// while ADDING the eighteen cuticles and three wing shapes that genuinely exist takes the figure
/// the listing quotes from 46 to 55. The honest number was the bigger one, which is usually how it
/// goes when a count is derived rather than assembled.
///
/// A cuticle is a colour AND a surface: gloss, grain, and whether the colour is pigment or a
/// diffraction grating. "jewel green" is not a green - it is a green that returns copper at another
/// angle, which is what makes a jewel beetle a jewel beetle.
function cht_cuticle_names() {
    return ["pitch black", "chestnut brown", "ochre yellow", "warning red",
            "cream scale", "chalk white scale", "jewel green", "fire copper",
            "morpho blue", "oil-slick teal", "violet ground", "olive drab",
            "oxblood", "gilded bronze", "slate grey", "moss green scale",
            "tortoiseshell orange", "pale larval flesh"];
}

/// Where and when a species is out. The field layer gates on these.
function cht_habitat_names() {
    return ["meadow", "hedgerow", "oak wood", "pine wood", "heath", "marsh",
            "riverbank", "orchard"];
}

function cht_season_names() {
    return ["early spring", "late spring", "early summer", "high summer",
            "late summer", "autumn"];
}

function cht_daypart_names() {
    return ["dawn", "morning", "midday", "afternoon", "dusk", "night"];
}

/// The four weathers the field layer gates on. Index-parallel with the CHT_WX_* bits.
function cht_weather_names() {
    return ["clear", "overcast", "rain", "wind"];
}

/// The six escape programs. Index-parallel with CHT_EVADE_* and with a real switch case in
/// cht_catch_escape - a name here that nothing switches on is the phantom-form defect this file's
/// header records twice, and cht_selftest asserts the length against CHT_EVADE_N.
function cht_evade_names() {
    return ["run", "flit", "drop", "dive", "jump", "bolt"];
}

/// What a specimen is doing during an encounter. Index-parallel with CHT_MODE_*.
function cht_mode_names() {
    return ["calm", "alert", "fleeing", "gone", "caught"];
}

/// How good a pinned specimen is. Index-parallel with the bands in cht_catch_condition.
function cht_condition_names() {
    return ["damaged", "worn", "good", "perfect"];
}

/// How hard a species is to FIND. Index-parallel with the bands in cht_field_rarity_band.
function cht_rarity_names() {
    return ["common", "frequent", "local", "scarce", "rare"];
}

/// The specimen states a player sees. Each is a DIFFERENT DRAWING of the same species, not the
/// same drawing at three sizes.
function cht_state_names() {
    return ["live", "spread", "pinned"];
}

/// ============================================================================================
/// THE SPECIES
///
/// 48 vernacular names. The corpus builder composes each one from a plan, a pattern, a venation,
/// an antenna, a leg, a sculpture and a chroma program - so this array is the ROSTER, and the
/// numbers that make each one look like itself live in cht_species.
/// ============================================================================================
function cht_species_names() {
    return [
        // beetles - elytra closed
        "stag beetle", "rhinoceros beetle", "great diving beetle", "dor beetle",
        "green tiger beetle", "violet ground beetle", "cockchafer", "rose chafer",
        "jewel beetle", "click beetle", "bloody nosed beetle", "musk beetle",
        // beetles - marked and small
        "seven spot ladybird", "eyed ladybird", "wasp beetle", "soldier beetle",
        "glow worm", "devils coach horse", "weevil", "longhorn beetle",
        "burying beetle", "whirligig beetle", "cardinal beetle", "flea beetle",
        // butterflies
        "peacock", "red admiral", "painted lady", "small tortoiseshell",
        "brimstone", "orange tip", "common blue", "chalkhill blue",
        "swallowtail", "purple emperor", "silver washed fritillary", "marbled white",
        // moths
        "elephant hawk moth", "poplar hawk moth", "death's head hawk moth", "hummingbird hawk moth",
        "garden tiger", "cinnabar", "emperor moth", "lime hawk moth",
        "burnished brass", "angle shades", "buff tip", "six spot burnet"
    ];
}

/// ============================================================================================
/// THE COUNT
/// ============================================================================================

/// How many distinct authored COMPONENT FORMS the package contains.
///
/// DERIVED FROM THE NAME ARRAYS, NEVER TYPED. This is the number the store listing quotes, and a
/// listing that quotes a figure a tool did not produce is the defect CLAUDE.md 2b records. Print
/// this, do not remember it.
///
/// IT DOES NOT COUNT SPECIES, HABITATS, SEASONS OR DAYPARTS, and the omission is deliberate: those
/// multiply the forms rather than adding to them, and a count that multiplies everything by
/// everything is the kind of number that is technically true and reads as a lie. Species are
/// quoted separately, because 48 of them is the honest headline.
/// ⛔ EVERY ARRAY SUMMED HERE MUST BE INDEX-PARALLEL WITH A REAL SWITCH, and cht_selftest STAGE 1
/// asserts each length against its own CHT_*_N macro. That is not tidiness: this sum is the number
/// on the store page, so an array that names forms nothing switches on inflates a market claim.
/// Two of them did until 2026-09-01 - see cht_wing_shape_names and cht_cuticle_names above.
function cht_corpus_forms() {
    return array_length(cht_plan_names())
         + array_length(cht_pattern_names())
         + array_length(cht_wing_shape_names())
         + array_length(cht_antenna_names())
         + array_length(cht_leg_names())
         + array_length(cht_sculpture_names())
         + array_length(cht_cuticle_names());
}

/// How many distinct DRAWN OBJECTS the package produces before palettes: every species in every
/// state. This is the figure that answers CLAUDE.md 1.1 question 3.
function cht_corpus_drawn() {
    return array_length(cht_species_names()) * array_length(cht_state_names());
}

/// How many distinct SYSTEM STATES the field, catch and cabinet layers switch on.
///
/// ⛔ KEPT SEPARATE FROM cht_corpus_forms() ON PURPOSE, AND THAT SEPARATION IS THE HONEST BIT. The
/// forms figure is what the store listing quotes and every entry in it is something the buyer can
/// SEE - a body plan, a pattern, a cuticle. Habitats, weathers and escape programs are behaviour,
/// and folding them into a visual count to make the headline bigger is exactly the inflation this
/// file's header condemns twice. They are real, they are worth quoting, and they are quoted as
/// what they are.
function cht_corpus_systems() {
    return array_length(cht_habitat_names())
         + array_length(cht_season_names())
         + array_length(cht_daypart_names())
         + array_length(cht_weather_names())
         + array_length(cht_evade_names())
         + array_length(cht_condition_names());
}

/// A one-line summary of what is in the package, built from the arrays above.
function cht_corpus_line() {
    return string(array_length(cht_species_names())) + " species, "
         + string(cht_corpus_forms()) + " component forms, "
         + string(cht_corpus_drawn()) + " drawn objects";
}

/// The system half, in one line, for the same reason.
function cht_corpus_system_line() {
    return string(array_length(cht_habitat_names())) + " habitats, "
         + string(array_length(cht_season_names())) + " seasons, "
         + string(array_length(cht_daypart_names())) + " times of day, "
         + string(array_length(cht_weather_names())) + " weathers, "
         + string(array_length(cht_evade_names())) + " escape programs";
}

/// ============================================================================================
/// LOOKUP HELPERS
/// ============================================================================================

/// Safe indexed lookup: a name array and an index that might be out of range.
///
/// RETURNS A VISIBLE MARKER RATHER THAN AN EMPTY STRING. An out-of-range name that reads "" draws
/// as a blank label, which looks like a layout problem and gets chased in the wrong file for half
/// an hour. "?12" says immediately what happened and where.
function cht_name_of(_arr, _i) {
    if (_i < 0 || _i >= array_length(_arr)) return "?" + string(_i);
    return _arr[_i];
}
