{
  "$GMScript": "v1",
  "%Name": "cht_corpus",
  "name": "cht_corpus",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}