{
  "$GMScript": "v1",
  "%Name": "cht_chroma",
  "name": "cht_chroma",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}