/// CHITIN - cht_chroma. THE CUTICLE, AND THE PRODUCT'S HEADLINE CLAIM.
///
/// A jewel beetle is not green. It is a stack of transparent chitin layers about a quarter of a
/// micron thick, and it returns green at one viewing angle and copper at another because the
/// layers interfere. Nothing about that colour is a pigment, which is exactly why it is worth
/// GENERATING rather than painting: change the layer spacing and the beetle becomes a different
/// species, in a way no repaint can fake.
///
/// So a cuticle here is TWO colour systems stacked, and keeping them apart is the whole file:
///
///   1. PIGMENT      - a flat body colour with a five-stop relief ramp, exactly like every other
///                     material in this catalogue. This is what a stag beetle, a cockchafer or a
///                     cabbage white is made of, and for those species the second system is off.
///   2. STRUCTURAL   - a narrow shimmer that runs ACROSS the pigment, swinging between two hues.
///                     This is what makes a jewel beetle a jewel beetle.
///
/// ⛔ IRIDESCENCE IS A NARROW SHIMMER ACROSS THE BODY, NOT A REPAINT OF IT. Carried in from the
/// mineral product in this catalogue, which paid for it: a hue that drifts smoothly over a whole
/// elytron reads as a RAINBOW DECAL stuck on a beetle, not as a beetle. The interference band on a
/// real elytron is narrow and it MOVES; the pigment underneath is still visible either side of it.
/// CHT_IRID_W below is that narrowness and it is load-bearing, not a taste setting.
///
/// ⛔⛔ AND THE SHIMMER IS AN ABSOLUTE SEPARATION, NEVER A MULTIPLIER. The obvious implementation
/// is `shade(base, 1.22)` and it is wrong in a way that is invisible on the one species you tune
/// it on: a 22% lift moves a bright elytron about 27 luminance levels and a dark one about 11, so
/// the beetles whose whole identity IS the shimmer - the dark-bodied ones - get the least of it.
/// Every offset in this file is an absolute Oklab lightness delta, and cht_selftest asserts the
/// realised separation on the DARKEST cuticle in the corpus, not on the average.
///
/// ⚠️ AND THE HUE SWING IS WEIGHTED BY CHROMA CONTRIBUTION, not by the swing's own progress.
/// Carried in from the weapons product, which shipped MAGENTA rusting iron: interpolating the hue
/// of a colour that has almost no chroma treats a number nobody can see as a starting appearance,
/// and every intermediate hue it passes through IS visible because the chroma is climbing at the
/// same time. A near-black cuticle therefore adopts the structural hue almost immediately and
/// simply gets MORE of it, while a green one blends properly, because both terms are real.
/// ============================================================================================

/// How many stops the relief ramp has. Mirrors CHT_RAMP_N in cht_relief; named here so the two
/// files do not have to import each other's constants.
#macro CHT_CHROMA_STOPS 5

/// The number of cuticles in the corpus. cht_selftest walks every one of them.
#macro CHT_CUTICLE_N 18

/// THE NARROWNESS OF THE STRUCTURAL BAND, as a fraction of the surface it crosses.
///
/// ⛔ DO NOT RAISE THIS TO MAKE THE EFFECT MORE VISIBLE. At 1.0 the band covers the whole elytron
/// and the product ships a rainbow sticker, which is the single failure mode this system has. If
/// the shimmer is not reading, the fix is CHT_IRID_SEP (make the band brighter against its
/// pigment) or the species' own irid value - never the width.
#macro CHT_IRID_W 0.30

/// The absolute Oklab lightness the crest of the band sits ABOVE its own pigment. See the header:
/// absolute, not a multiplier, so a dark cuticle gets the same visible lift as a pale one.
#macro CHT_IRID_SEP 0.150

/// The floor a cuticle's own pigment lightness is held at while the band is subtracted from it,
/// so that a dark species' shadowed flank cannot go to pure black. No real surface is 0.
#macro CHT_L_FLOOR 0.055
#macro CHT_L_CEIL  0.930

/// ============================================================================================
/// THE CORPUS
///
/// Authored in hue / saturation / value because that is how a colour is described out loud, and
/// converted to Oklch in exactly one place below (cht_chroma_base). A corpus authored directly in
/// a perceptual space is a corpus nobody can read or amend.
///
/// gloss   0 matte (a moth's scales, a larval grub) .. 1 mirror (a polished ground beetle)
/// irid    0 pigment only .. 1 the whole surface is structural (a jewel beetle, a blue morpho)
/// h0, h1  the two hues the grating returns at the two ends of the viewing swing. They are the
///         SPECIES, not a decoration: 128 -> 28 is a green beetle that flashes copper, 250 -> 190
///         is a morpho that flashes cyan.
/// grain   how fine the surface texture is, 0 smooth .. 1 heavily punctured/scaled. Consumed by
///         the elytra sculpture, kept here because it is a property of the cuticle.
/// ============================================================================================
function cht_cuticle_spec(_c) {
    switch (clamp(_c, 0, CHT_CUTICLE_N - 1)) {
        //                       hue  sat   val   gloss irid  h0   h1   grain name_i
        case  0: return { hue:  36, sat: 0.22, val: 0.16, gloss: 0.86, irid: 0.00,
                          h0:  36, h1:  36, grain: 0.30, name_i:  0 }; // pitch black cuticle
        case  1: return { hue:  44, sat: 0.52, val: 0.30, gloss: 0.62, irid: 0.00,
                          h0:  44, h1:  44, grain: 0.55, name_i:  1 }; // chestnut brown
        case  2: return { hue:  68, sat: 0.74, val: 0.62, gloss: 0.40, irid: 0.00,
                          h0:  68, h1:  68, grain: 0.40, name_i:  2 }; // ochre yellow
        case  3: return { hue:  28, sat: 0.92, val: 0.46, gloss: 0.55, irid: 0.00,
                          h0:  28, h1:  28, grain: 0.35, name_i:  3 }; // warning red
        case  4: return { hue:  84, sat: 0.30, val: 0.74, gloss: 0.18, irid: 0.00,
                          h0:  84, h1:  84, grain: 0.72, name_i:  4 }; // cream scale
        case  5: return { hue:  96, sat: 0.10, val: 0.86, gloss: 0.12, irid: 0.00,
                          h0:  96, h1:  96, grain: 0.80, name_i:  5 }; // chalk white scale
        case  6: return { hue: 142, sat: 0.58, val: 0.34, gloss: 0.70, irid: 0.72,
                          h0: 142, h1:  36, grain: 0.25, name_i:  6 }; // jewel green
        case  7: return { hue:  46, sat: 0.86, val: 0.44, gloss: 0.88, irid: 0.80,
                          h0:  46, h1: 320, grain: 0.20, name_i:  7 }; // fire copper
        case  8: return { hue: 258, sat: 0.72, val: 0.36, gloss: 0.84, irid: 0.90,
                          h0: 258, h1: 196, grain: 0.18, name_i:  8 }; // morpho blue
        case  9: return { hue: 196, sat: 0.44, val: 0.30, gloss: 0.78, irid: 0.62,
                          h0: 196, h1: 128, grain: 0.28, name_i:  9 }; // oil-slick teal
        case 10: return { hue: 312, sat: 0.40, val: 0.26, gloss: 0.80, irid: 0.66,
                          h0: 312, h1: 246, grain: 0.24, name_i: 10 }; // violet ground beetle
        case 11: return { hue:  74, sat: 0.34, val: 0.52, gloss: 0.30, irid: 0.00,
                          h0:  74, h1:  74, grain: 0.66, name_i: 11 }; // olive drab
        case 12: return { hue:  10, sat: 0.55, val: 0.22, gloss: 0.48, irid: 0.00,
                          h0:  10, h1:  10, grain: 0.60, name_i: 12 }; // oxblood
        case 13: return { hue:  56, sat: 0.66, val: 0.72, gloss: 0.66, irid: 0.34,
                          h0:  56, h1:  92, grain: 0.22, name_i: 13 }; // gilded bronze
        case 14: return { hue: 250, sat: 0.06, val: 0.42, gloss: 0.34, irid: 0.00,
                          h0: 250, h1: 250, grain: 0.58, name_i: 14 }; // slate grey
        case 15: return { hue: 118, sat: 0.26, val: 0.44, gloss: 0.22, irid: 0.00,
                          h0: 118, h1: 118, grain: 0.74, name_i: 15 }; // moss green scale
        case 16: return { hue:  20, sat: 0.70, val: 0.58, gloss: 0.26, irid: 0.00,
                          h0:  20, h1:  20, grain: 0.68, name_i: 16 }; // tortoiseshell orange
        default: return { hue:  88, sat: 0.14, val: 0.58, gloss: 0.20, irid: 0.00,
                          h0:  88, h1:  88, grain: 0.86, name_i: 17 }; // pale larval flesh
    }
}

/// ============================================================================================
/// PIGMENT
/// ============================================================================================

/// A cuticle's base colour in Oklch, before gloss shapes it into a ramp.
///
/// Compressive at both ends on purpose: nothing in nature is pure black or pure white, and a stop
/// authored at either limit has no room left to be shaded, which is what makes a flat sticker.
function cht_chroma_base(_sp) {
    return {
        L: CHT_L_FLOOR + (CHT_L_CEIL - CHT_L_FLOOR) * clamp(_sp.val, 0, 1),
        C: 0.150 * clamp(_sp.sat, 0, 1),
        h: _sp.hue
    };
}

/// Shortest-path hue blend, in degrees, on the hue circle.
///
/// Split out so the suite can assert the DIRECTION separately from the weighting. This wing
/// shipped magenta rusting iron once because those two mistakes were stacked inside one function
/// and no assertion could tell which half was wrong.
function cht_hue_mix(_h0, _h1, _k) {
    var _d = _h1 - _h0;
    while (_d > 180) _d -= 360;
    while (_d < -180) _d += 360;
    var _h = _h0 + _d * _k;
    while (_h < 0) _h += 360;
    while (_h >= 360) _h -= 360;
    return _h;
}

/// How far apart two hues are on the circle, 0..180. Used by the suite to state a swing's size
/// without caring which way round it goes.
function cht_hue_gap(_h0, _h1) {
    var _d = abs(_h1 - _h0);
    while (_d > 360) _d -= 360;
    if (_d > 180) _d = 360 - _d;
    return _d;
}

/// The five relief stops for one cuticle.
///
/// SLIDE THE RAMP TO FIT, NEVER CLAMP ITS ENDS. A ramp whose top two stops both hit the ceiling
/// makes them the same colour, and a bevel whose two brightest walls are identical reads as a flat
/// fill with a line round it - which is precisely the sticker this whole file exists to avoid.
function cht_chroma_ramp(_sp) {
    var _b = cht_chroma_base(_sp);

    // A glossy cuticle has a WIDER tonal span (it takes a real specular) and a matte scaled one a
    // narrower one. A moth's wing has almost no highlight and should not be given one.
    var _span = 0.26 + 0.34 * clamp(_sp.gloss, 0, 1);
    var _lo = _b.L - _span * 0.5;
    var _hi = _b.L + _span * 0.5;
    if (_hi > CHT_L_CEIL)  { _lo -= (_hi - CHT_L_CEIL); _hi = CHT_L_CEIL; }
    if (_lo < CHT_L_FLOOR) { _hi += (CHT_L_FLOOR - _lo); _lo = CHT_L_FLOOR; }
    _hi = min(_hi, CHT_L_CEIL);

    var _out = array_create(CHT_CHROMA_STOPS);
    for (var _i = 0; _i < CHT_CHROMA_STOPS; _i++) {
        var _t = _i / (CHT_CHROMA_STOPS - 1);
        // THE WARP. An exponent above 1 holds the low stops down and leaves a wide gap up to the
        // top stop, which is what a specular highlight physically IS. At gloss 0 it is nearly the
        // identity and the stops space evenly, which is what a matte scale wants.
        var _u = power(_t, 1 + clamp(_sp.gloss, 0, 1) * 1.5);
        var _Li = _lo + (_hi - _lo) * _u;
        // Chroma falls away at the specular end - a highlight on any surface washes toward white.
        var _Ci = _b.C * lerp(1.02, 0.52, _u);
        _out[_i] = cht_oklch(_Li, max(0, _Ci), _b.h);
    }
    return _out;
}

/// The role map that points cht_relief's m0..m4 at a named ramp inside a palette struct.
/// Returned fresh every call: a shared mutable map works right up until two insects are built in
/// the same frame.
function cht_chroma_map(_prefix) {
    return {
        m0: _prefix + "0", m1: _prefix + "1", m2: _prefix + "2",
        m3: _prefix + "3", m4: _prefix + "4",
    };
}

/// Write one cuticle's five stops into a palette struct under a prefix.
function cht_chroma_into(_pal, _prefix, _sp) {
    var _r = cht_chroma_ramp(_sp);
    for (var _i = 0; _i < CHT_CHROMA_STOPS; _i++) {
        variable_struct_set(_pal, _prefix + string(_i), _r[_i]);
    }
    return _pal;
}

/// ============================================================================================
/// STRUCTURAL COLOUR
/// ============================================================================================

/// How strongly the interference band lights up at lateral position _u.
///
/// _u  is -1 at one edge of the surface, +1 at the other, 0 at the midline.
/// _ph is the viewing phase, 0..1 - which way the specimen is tilted. Moving it sweeps the band
///     ACROSS the surface, which is the whole observable behaviour of structural colour and the
///     reason the catch and cabinet screens tilt a specimen rather than spinning it.
///
/// Returns 0..1. The band is a raised cosine of half-width CHT_IRID_W, so it falls to exactly
/// zero at its own edges rather than tailing off across the whole surface - the difference
/// between a shimmer and a wash.
function cht_irid_band(_u, _ph) {
    var _c = -1 + 2 * clamp(_ph, 0, 1);        // where the crest currently sits
    var _d = abs(clamp(_u, -1, 1) - _c) / CHT_IRID_W;
    if (_d >= 1) return 0;
    return 0.5 + 0.5 * cos(_d * pi);
}

/// The colour of a cuticle at lateral position _u under viewing phase _ph, at relief stop _stop.
///
/// This is the function the whole product is sold on. For a pigment species (irid 0) it returns
/// the plain ramp stop and nothing else happens. For a structural one the band lifts the surface
/// by an ABSOLUTE lightness separation and swings its hue between h0 and h1.
///
/// ⚠️ THE HUE IS WEIGHTED BY CHROMA CONTRIBUTION, NOT BY BAND STRENGTH. See the header. A near
/// black cuticle brings almost no chroma of its own, so the structural hue takes over at once
/// instead of dragging the surface through every hue in between.
/// ⭐ THE ONE TRUE COLOUR FUNCTION, AND IT TAKES A CONTINUOUS RAMP POSITION.
///
/// _k01 is where on the cuticle's own tonal ramp this piece of surface sits: 0 is the deepest
/// shadow the material reaches, 1 its specular. It is CONTINUOUS on purpose.
///
/// ⛔ THE FIVE-STOP RELIEF RAMP IS RIGHT FOR A CUT EDGE AND WRONG FOR A SHELL. Five hard bands
/// around a rim is what a struck coin photographs like, and this catalogue's whole relief system is
/// built on that - correctly. But a beetle's elytron is a smoothly curved surface a third of the
/// picture wide, and quantising it to five values puts five vertical stripes down the animal.
/// MEASURED by looking, twice: as radial contour bands under a centroid-scaled dome, and again as
/// clean vertical stripes once the dome was replaced by a tube. The stripes were tidier and just as
/// wrong. So the SHELL is shaded continuously here and the EDGES keep the five-stop relief; using
/// one model for both was the mistake.
function cht_chroma_ramp_at(_sp, _k01, _u, _ph) {
    var _b = cht_chroma_base(_sp);

    var _span = 0.26 + 0.34 * clamp(_sp.gloss, 0, 1);
    var _lo = _b.L - _span * 0.5;
    var _hi = _b.L + _span * 0.5;
    if (_hi > CHT_L_CEIL)  { _lo -= (_hi - CHT_L_CEIL); _hi = CHT_L_CEIL; }
    if (_lo < CHT_L_FLOOR) { _hi += (CHT_L_FLOOR - _lo); _lo = CHT_L_FLOOR; }
    _hi = min(_hi, CHT_L_CEIL);

    var _w = power(clamp(_k01, 0, 1), 1 + clamp(_sp.gloss, 0, 1) * 1.5);
    var _L = _lo + (_hi - _lo) * _w;
    var _C = _b.C * lerp(1.02, 0.52, _w);

    var _irid = clamp(_sp.irid, 0, 1);
    if (_irid <= 0) return cht_oklch(_L, max(0, _C), _b.h);

    var _k = cht_irid_band(_u, _ph) * _irid;
    if (_k <= 0) return cht_oklch(_L, max(0, _C), _b.h);

    // ABSOLUTE separation. Not a multiplier. See the header.
    var _Lb = min(CHT_L_CEIL, _L + CHT_IRID_SEP * _k);

    // The structural hue at this phase: the grating returns h0 at one end of the swing and h1 at
    // the other, so the CREST colour depends on where the specimen is tilted to.
    var _hs = cht_hue_mix(_sp.h0, _sp.h1, clamp(_ph, 0, 1));

    // Structural chroma is high - that is what makes it read as metal rather than as paint.
    var _Cs = 0.150 * (0.62 + 0.38 * _irid);

    // Weight the hue by what each side actually CONTRIBUTES to the chroma.
    var _cs = _C  * (1 - _k);
    var _ct = _Cs * _k;
    var _hw = (_cs + _ct > 0.0001) ? (_ct / (_cs + _ct)) : _k;

    return cht_oklch(_Lb, lerp(_C, _Cs, _k), cht_hue_mix(_b.h, _hs, _hw));
}

/// The colour of a cuticle at one of the five DISCRETE relief stops. A thin wrapper, kept because
/// every edge, wall and cut mark in the package is authored in stop terms and should stay that way.
function cht_chroma_at(_sp, _stop, _u, _ph) {
    return cht_chroma_ramp_at(_sp, clamp(_stop, 0, CHT_CHROMA_STOPS - 1)
                                   / (CHT_CHROMA_STOPS - 1), _u, _ph);
}

/// The realised lightness separation the band achieves on this cuticle, in Oklab L.
///
/// Exists so the suite can assert the SEPARATION rather than trust the arithmetic, and so a
/// cuticle authored at an awkward lightness fires BY NAME instead of shipping a shimmer nobody can
/// see. This is the assertion that catches the multiplier mistake if it is ever reintroduced.
function cht_irid_sep_of(_sp) {
    var _irid = clamp(_sp.irid, 0, 1);
    if (_irid <= 0) return 0;
    var _b = cht_chroma_base(_sp);
    var _span = 0.26 + 0.34 * clamp(_sp.gloss, 0, 1);
    var _lo = _b.L - _span * 0.5;
    var _hi = _b.L + _span * 0.5;
    if (_hi > CHT_L_CEIL)  { _lo -= (_hi - CHT_L_CEIL); _hi = CHT_L_CEIL; }
    if (_lo < CHT_L_FLOOR) { _hi += (CHT_L_FLOOR - _lo); _lo = CHT_L_FLOOR; }
    _hi = min(_hi, CHT_L_CEIL);
    var _t = 2 / (CHT_CHROMA_STOPS - 1);
    var _u2 = power(_t, 1 + clamp(_sp.gloss, 0, 1) * 1.5);
    var _L = _lo + (_hi - _lo) * _u2;
    return min(CHT_L_CEIL, _L + CHT_IRID_SEP * _irid) - _L;
}

/// ============================================================================================
/// INK
///
/// ⛔ THE THING YOU WRITE ON A SURFACE IS NOT THAT SURFACE'S DARKEST STOP. This corpus holds CHALK
/// WHITE SCALE at val 0.86 and PITCH BLACK CUTICLE at val 0.16, and the identification card writes
/// a species name over both. An ink is defined RELATIVE to its own ground and goes the other way
/// from it by an asserted minimum, or half the corpus ships an unreadable label.
/// ============================================================================================
function cht_chroma_ink(_sp) {
    var _b = cht_chroma_base(_sp);
    var _sep = 0.38;
    var _L = (_b.L > 0.5) ? max(0.045, _b.L - _sep) : min(0.960, _b.L + _sep);
    return cht_oklch(_L, _b.C * 0.45, _b.h);
}

/// How far a cuticle's ink sits from its own base, in Oklab lightness. Asserted, not trusted.
function cht_chroma_ink_sep(_sp) {
    var _b = cht_chroma_base(_sp);
    var _L = (_b.L > 0.5) ? max(0.045, _b.L - 0.38) : min(0.960, _b.L + 0.38);
    return abs(_L - _b.L);
}

/// The smallest adjacent-stop lightness gap in this cuticle's ramp.
///
/// A ramp whose two brightest stops are the same colour draws a bevel that reads as a flat fill
/// with a line round it. The suite asserts a floor on this across every cuticle, which is what
/// makes "slide, never clamp" a checked property rather than a comment.
function cht_chroma_min_step(_sp) {
    var _r = cht_chroma_ramp(_sp);
    var _worst = 999;
    for (var _i = 0; _i < CHT_CHROMA_STOPS - 1; _i++) {
        _worst = min(_worst, abs(cht_oklch_L_of(_r[_i + 1]) - cht_oklch_L_of(_r[_i])));
    }
    return _worst;
}

/// Approximate Oklab lightness of a packed BGR colour. Used only by assertions and by the
/// separation checks above - never on a draw path.
function cht_oklch_L_of(_col) {
    var _r = (colour_get_red(_col)   / 255);
    var _g = (colour_get_green(_col) / 255);
    var _b = (colour_get_blue(_col)  / 255);
    // sRGB -> linear
    _r = (_r <= 0.04045) ? (_r / 12.92) : power((_r + 0.055) / 1.055, 2.4);
    _g = (_g <= 0.04045) ? (_g / 12.92) : power((_g + 0.055) / 1.055, 2.4);
    _b = (_b <= 0.04045) ? (_b / 12.92) : power((_b + 0.055) / 1.055, 2.4);
    var _l = 0.4122214708 * _r + 0.5363325363 * _g + 0.0514459929 * _b;
    var _m = 0.2119034982 * _r + 0.6806995451 * _g + 0.1073969566 * _b;
    var _s = 0.0883024619 * _r + 0.2817188376 * _g + 0.6299787005 * _b;
    _l = power(max(0, _l), 1.0 / 3.0);
    _m = power(max(0, _m), 1.0 / 3.0);
    _s = power(max(0, _s), 1.0 / 3.0);
    return 0.2104542553 * _l + 0.7936177850 * _m - 0.0040720468 * _s;
}
