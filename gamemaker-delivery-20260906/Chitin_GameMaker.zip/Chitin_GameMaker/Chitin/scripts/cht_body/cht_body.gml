/// CHITIN - cht_body. HEAD, THORAX AND ABDOMEN AS ONE CONTINUOUS OUTLINE.
///
/// ⛔ THE SINGLE MOST IMPORTANT DECISION IN THIS PRODUCT, AND IT IS NOT AN AESTHETIC ONE.
///
/// An insect is three obvious masses, so the obvious implementation is three closed shapes placed
/// end to end. The RPG Maker wing measured what that produces on a 50-figure corpus and wrote it
/// down: A CHAIN OF ABUTTING MASSES READS AS A CHAIN. Three adjacent closed outlines with three
/// separate bevels put a lit edge across every join, and the eye reads "a circle, an oval and a
/// blob" rather than "a beetle". Every join is a place the animal comes apart.
///
/// So the body here is ONE outline, and the constrictions - the neck behind the head, the waist
/// behind the pronotum - are CHANGES OF DIRECTION in a single continuous curve. There is exactly
/// one silhouette, one bevel and one lit rim, and the animal cannot come apart because there is
/// nothing to come apart at.
///
/// ⭐ AND THE OUTLINE IS BUILT FROM A HALF-WIDTH FUNCTION, NEVER SWEPT AS A PATH.
///
/// Carried in from the weapons product in this catalogue, which grew a thin needle off the tip of
/// six of eighteen blades: it walked up one side while ALSO moving a shape parameter across, so
/// the parameter controlled a CROSSING rather than a shape. Here the body plan lives entirely in
/// cht_body_halfw - a function of position along the animal - and the outline is mechanically
/// "down one side and back up the other". A tapered abdomen, a blunt one and a pointed one differ
/// only in that function, and none of them can produce a spike, because a spike is not expressible.
///
/// -- HOW A PLAN IS WRITTEN -----------------------------------------------------------------
/// A body is a set of LOBES along the axis, blended by a p-norm. Each lobe is:
///
///     c  centre, in axis coordinates 0 (head apex) .. 1 (abdomen tip)
///     r  half-length: the lobe is zero outside c +/- r
///     w  half-width at its own peak
///     e  fullness. 0.5 is a true ellipse. Below 0.5 is boxier (a squared-off pronotum); above
///        0.5 is more tapered (a drawn-out abdomen tip).
///     g  skew. 1 is symmetric; above 1 moves the widest point toward the tail; below 1 toward
///        the head. This is what makes a pronotum a trapezoid rather than a disc.
///
/// The p-norm blend is the constriction knob and it is the only one: a HIGH blend exponent
/// approaches a hard maximum and gives a deeply pinched wasp waist, a LOW one merges the lobes
/// into a single fusiform mass. A ground beetle is about 7; a grub is about 2.
///
/// ⚠️ LOBES MUST OVERLAP. Two lobes that do not reach each other leave a stretch where every term
/// is zero, and the outline pinches to a point in the middle of the animal - which does not look
/// like a waist, it looks like the body was cut in half. cht_selftest asserts a positive half-width
/// across the whole interior of every plan in the corpus, which is the assertion that catches it.
///
/// ⛔⛔ AND THE END LOBES MUST TERMINATE EXACTLY AT t=0 AND t=1, OR THE ANIMAL IS CUT OFF FLAT.
///
/// MEASURED 2026-09-01 by opening the first contact sheet: every one of the 48 specimens had a
/// hard horizontal edge across the top of its head and across the end of its abdomen, as though
/// the drawing had been cropped. The cause is arithmetic and it is not obvious from the numbers:
/// the head lobe was written c=0.090, r=0.150, so it BEGINS at t = -0.060 - before the animal
/// does. The outline therefore starts at t=0 with a half-width already at 78% of the head's
/// maximum, and a closed outline that starts wide is a flat cut. The abdomen lobe ended at 1.02
/// and did the same thing at the tail.
///
/// ⭐ THE TERMINATION IS WHAT MAKES THE END SHAPE AUTHORABLE AT ALL. With c-r exactly 0 the head
/// closes itself, and the FULLNESS exponent then decides what kind of end it is: 0.5 is an ellipse
/// pole and gives the round head of a chafer, above 0.5 draws it out into the snout of a weevil,
/// below 0.5 squares it off. Get the range wrong and none of that is reachable, because every
/// species ends in the same flat cut whatever its exponent says.
///
/// cht_selftest asserts halfw(0) and halfw(1) are zero for every plan, which is the assertion that
/// would have caught this before the first bake rather than after it.
/// ============================================================================================

/// The six body plans. A plan decides which lobes exist and what is drawn on them; a SPECIES
/// decides the numbers. Two beetles are the same plan and different animals.
///
/// ⛔ THESE ARE INDEX-PARALLEL WITH cht_plan_names() AND THAT IS A SHARED FACT WITH TWO
/// DECLARATIONS. CLAUDE.md 2b's standing lesson is that such a pair drifts silently, so
/// cht_selftest asserts array_length(cht_plan_names()) == CHT_PLAN_N and every macro's position by
/// name. The first draft of this file had SIX plans in a different ORDER from the name array it
/// was written beside - every plan would have drawn correctly under the wrong label.
#macro CHT_PLAN_ELYTRA       0   // elytra closed - a beetle at rest, the commonest thing drawn here
#macro CHT_PLAN_ELYTRA_OPEN  1   // elytra open   - a beetle in flight, shells raised, hindwings out
#macro CHT_PLAN_SPREAD       2   // wings spread  - a set specimen, all four wings displayed
#macro CHT_PLAN_FOLDED       3   // wings folded  - a moth at rest, wings held roofwise over the back
#macro CHT_PLAN_SOFT         4   // soft bodied   - a glow worm, a soldier beetle, a true bug
#macro CHT_PLAN_LARVAL       5   // larval        - a caterpillar or grub, no wings and no elytra
#macro CHT_PLAN_N            6

/// How many points the outline is sampled at, per side.
///
/// ⚠️ MEASURED CONSTRAINT, NOT A TASTE SETTING. A canopy sampled at 30 points around a ring shows
/// visible chords above about 120 px, and this product's hero images draw a specimen at 700 px.
/// The body is a smoother curve than a canopy, but it is also the biggest single object on the
/// sheet and the one the buyer is looking at. 96 per side.
#macro CHT_BODY_SAMPLES 96

/// How many points the outline used for the RIM BEVEL is sampled at, per side.
///
/// ⚠️ THIS NUMBER IS A TRADE WITH NO FREE END, WHICH IS WHY IT IS A MACRO WITH A COMMENT RATHER
/// THAN A CONSTANT AT A CALL SITE. Coarser buys BEVEL DEPTH (cht_inset_limit allows an inset of
/// about 0.56 of the shortest edge, so long edges are the whole budget) and costs FACETS, which at
/// 18 per side showed as a pale wedge across the pronotum shoulder where a chord cut the
/// silhouette. Finer buys smoothness and takes the depth away again. 30 with a shallower request
/// is the reading that looked right: a crisp rim rather than a wide banded one.
#macro CHT_BODY_RELIEF_SAMPLES 30

/// The outline sample count for a specimen drawn at _px pixels.
///
/// A 700 px hero needs every one of its 96 stations; a 40 px cabinet thumbnail does not, and
/// paying for them there costs a buyer's frame rate on the screen where the most specimens are on
/// show at once. The floor of 12 is where the silhouette stops being a curve at all.
function cht_body_samples_for(_px) {
    return clamp(round(_px / 6), 12, CHT_BODY_SAMPLES);
}

/// The axis coordinates the three regions occupy. Everything drawn ON the body - a suture, an eye,
/// an elytron, a leg socket - is placed in these terms rather than in y, so a species that
/// lengthens its abdomen moves all of them correctly and none of them has to be re-authored.
#macro CHT_T_HEAD_END  0.185
#macro CHT_T_THORAX_END 0.400

/// ============================================================================================
/// LOBES
/// ============================================================================================

function cht_lobe(_c, _r, _w, _e, _g) {
    return { c: _c, r: _r, w: _w, e: _e, g: _g };
}

/// One lobe's half-width contribution at axis position _t.
///
/// Returns 0 outside the lobe, which is what makes the p-norm below behave: a lobe that is not
/// present at this station contributes nothing rather than contributing a floor.
function cht_lobe_at(_lb, _t) {
    var _u = (_t - _lb.c) / max(0.0001, _lb.r);
    if (_u <= -1 || _u >= 1) return 0;
    // Skew: warp the parameter before taking the profile, so the widest point can sit anywhere
    // inside the lobe. This is the whole difference between a disc and a trapezoid.
    var _s = power(clamp((_u + 1) * 0.5, 0, 1), max(0.05, _lb.g));
    var _uu = _s * 2 - 1;
    return _lb.w * power(max(0, 1 - _uu * _uu), max(0.05, _lb.e));
}

/// ============================================================================================
/// THE HALF-WIDTH FUNCTION - the body plan itself
/// ============================================================================================

/// The animal's half-width at axis position _t, 0 (head apex) to 1 (abdomen tip).
///
/// This is the ONLY place a body plan exists. Nothing else in the package knows what shape the
/// animal is, which is why a new plan costs a lobe list and no drawing code at all.
///
/// ⛔⛔ THE P-NORM IS NORMALISED BEFORE THE POWER, AND THE FIRST VERSION WAS NOT. IT DREW NOTHING.
///
/// MEASURED 2026-09-01, on this product's first preview, by opening the image: every specimen was
/// a bundle of thin curves radiating from a single vertical line, because this function returned
/// ZERO for every station on every animal.
///
/// A lobe half-width here is about 0.15 and the beetle's blend exponent is 6.5, so the raw sum was
/// `power(0.15, 6.5) * 3`, which is about 0.000013. GML APPLIES A DEFAULT EPSILON OF 0.00001 TO
/// NUMERIC COMPARISONS - so `_sum <= 0` asked whether a number thirteen millionths from zero was
/// less than or equal to zero, GML answered YES, and the guard that exists to catch an empty lobe
/// list threw away every real body in the corpus.
///
/// ⭐ THE GENERAL FORM IS WORTH MORE THAN THE FIX, AND IT IS NEW TO THIS WING'S CATALOGUE. Every
/// epsilon defect recorded here so far was a TOLERANCE somebody wrote too small. This one has no
/// tolerance in it at all: the epsilon caught a legitimate INTERMEDIATE VALUE of a correct
/// computation, because raising a number below 1 to a high power is an underflow machine.
/// ⇒ ANY p-NORM, PRODUCT, OR REPEATED POWER OVER SUB-UNIT VALUES CAN LAND ON THE EPSILON, and no
/// amount of care about the tolerances you write protects you from it.
///
/// The fix is the standard numerical one and it is not merely a guard: divide by the largest term
/// first, so the sum is at least 1.0 BY CONSTRUCTION, then scale the result back. The comparison
/// that remains is against 0.0001 - safely above the epsilon, and honest, because a half-width
/// below a ten-thousandth of the unit box is sub-pixel at every size this package draws at.
///
/// ⚠️ NOTHING MECHANICAL COULD HAVE SEEN IT. The geometry was valid (a zero-width outline is a
/// simple closed polygon), the gate compiled clean, the ink floor PASSED on the contact sheet at
/// 50,372 ink pixels, and the sheet reported ok=true - because 48 collapsed insects still draw
/// legs, antennae and captions. Found by opening the file.
function cht_body_halfw(_sp, _t) {
    var _n = array_length(_sp.lobes);
    if (_n == 0) return 0;
    var _p = max(1.2, _sp.blend);

    var _mx = 0;
    for (var _i = 0; _i < _n; _i++) _mx = max(_mx, cht_lobe_at(_sp.lobes[_i], _t));
    if (_mx < 0.0001) return 0;

    var _sum = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _r = cht_lobe_at(_sp.lobes[_i], _t) / _mx;
        if (_r > 0) _sum += power(_r, _p);
    }
    return _mx * power(_sum, 1 / _p);
}

/// Axis position -> y in the unit box. The animal is centred on the origin, head toward -y.
function cht_body_y(_sp, _t) {
    return -_sp.len * 0.5 + _sp.len * clamp(_t, 0, 1);
}

/// y in the unit box -> axis position. The inverse of the above, for placing something that was
/// measured in y (a sheet caption rule, a cabinet pin) back onto the animal.
function cht_body_t(_sp, _y) {
    return clamp((_y + _sp.len * 0.5) / max(0.0001, _sp.len), 0, 1);
}

/// ⛔ THE BODY'S TRUE WIDTH AT A GIVEN HEIGHT, WHICH IS NOT ITS BOUNDING BOX.
///
/// This wing has paid for this twice: a mark placed by clamping against a shape's bounding box
/// overhangs it at every height except the one where the shape is widest, and a shape reaches its
/// box width at exactly one station. Every spot, band, stripe and puncture in this product is
/// clipped through this function.
///
/// ⚠️ AND A MARK OCCUPIES A RANGE OF HEIGHTS, so it must fit at ALL of them - clipping a spot
/// against the span at its own CENTRE lets its shoulder poke out where the body narrows above it.
/// Callers that place a mark of nonzero height use cht_body_span_min below instead.
function cht_body_span_at(_sp, _t) {
    return cht_body_halfw(_sp, _t);
}

/// The NARROWEST half-width the body reaches anywhere between _t0 and _t1.
///
/// This is what a mark spanning that range has to fit inside. Sampled rather than solved: the
/// half-width function is a p-norm of skewed profiles and has no closed-form minimum, and 12
/// samples over the span of one spot is nothing next to being wrong.
function cht_body_span_min(_sp, _t0, _t1) {
    var _a = min(_t0, _t1), _b = max(_t0, _t1);
    var _w = cht_body_halfw(_sp, _a);
    for (var _i = 1; _i <= 12; _i++) {
        _w = min(_w, cht_body_halfw(_sp, _a + (_b - _a) * (_i / 12)));
    }
    return _w;
}

/// ============================================================================================
/// THE OUTLINE
/// ============================================================================================

/// The animal's dorsal silhouette as ONE closed outline: down the left side from head apex to
/// abdomen tip, and back up the right.
///
/// ⚠️ THE TIPS ARE SAMPLED, NOT CAPPED. At t=0 and t=1 the half-width is zero, so both ends close
/// themselves and there is no special case at either. A fullness exponent of 0.5 makes that end
/// round (an ellipse has a vertical tangent at its pole); a higher one makes it drawn out. The
/// shape of the head and the shape of the tail are therefore both properties of the corpus rather
/// than of this function, which is the point.
function cht_body_outline(_sp, _samples) {
    var _n = max(8, is_undefined(_samples) ? CHT_BODY_SAMPLES : _samples);
    var _pts = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        var _w = cht_body_halfw(_sp, _t);
        array_push(_pts, [-_w, cht_body_y(_sp, _t)]);
    }
    for (var _i = _n; _i >= 0; _i--) {
        var _t = _i / _n;
        var _w = cht_body_halfw(_sp, _t);
        array_push(_pts, [_w, cht_body_y(_sp, _t)]);
    }
    return cht_dedupe_pts(_pts);
}

/// ============================================================================================
/// ATTACHMENT
///
/// Every appendage in this package attaches through here, and the reason is one rule: AN
/// APPENDAGE MUST OVERLAP THE MASS IT GROWS FROM, NEVER ABUT IT. A leg whose first point sits
/// exactly on the body outline leaves a hairline of page between the two the moment either is
/// bevelled, and six legs and two antennae is eight chances to look like a kit of parts.
///
/// The socket is therefore returned INSET into the body by a fraction of the local half-width,
/// so the appendage starts underneath the animal and emerges from it.
/// ============================================================================================

/// Where an appendage on side _side (-1 left, +1 right) at axis position _t starts.
/// _sink is how far under the body it begins, as a fraction of the local half-width.
function cht_body_socket(_sp, _t, _side, _sink) {
    var _w = cht_body_halfw(_sp, _t);
    var _k = clamp(is_undefined(_sink) ? 0.34 : _sink, 0, 0.95);
    return [_side * _w * (1 - _k), cht_body_y(_sp, _t)];
}

/// ============================================================================================
/// THE DRAWN BODY
/// ============================================================================================

/// The dorsal body: one filled mass, one dome, and the two sutures that make the regions read.
///
/// ⚠️ THE SUTURES ARE INCISED LINES, NOT SEAMS BETWEEN MASSES. That is the whole trick of this
/// file. A real beetle's head and pronotum meet at a groove cut into a continuous cuticle, and
/// drawing it as a groove is both anatomically right and the thing that stops the animal reading
/// as three stuck-together shapes.
///
/// _bev is the dome depth in unit-box units; _px the drawn width, for the sampling decision.
///
/// ⛔⛔ THE SILHOUETTE AND THE RELIEF ARE SAMPLED FROM THE SAME CURVE AT DIFFERENT DENSITIES, AND
/// THAT IS THE FIX FOR A DEFECT THIS PRODUCT SHIPPED TO ITS FIRST PREVIEW: EVERY ANIMAL WAS FLAT.
///
/// MEASURED, from the preview's own diagnostic rather than by eye: a requested dome of 0.026 came
/// out at 0.00497 - a 3 px shell on a 700 px beetle, which is indistinguishable from a sticker.
/// The limiter was not broken. cht_inset_limit refuses an inset that would turn a bevel quad into
/// a bowtie, and on a 192-point outline the shortest edge is 0.00885, so 0.005 is genuinely all
/// the room there is.
///
/// ⭐ THE GENERAL FORM, AND IT IS NOT IN THIS WING'S CATALOGUE YET: THE SAFE BEVEL DEPTH IS A
/// FUNCTION OF SAMPLING DENSITY, SO SAMPLING A CURVE MORE FINELY SILENTLY REMOVES ITS RELIEF.
/// Those two quality knobs pull against each other, and both of them look like "more is better".
/// Nothing reports the trade: the outline is smoother, the geometry is valid, the ink floor rises
/// because a bevel is ink either way, and the picture gets worse.
///
/// So: the FILL takes the fine outline, because that is the edge a buyer sees against their
/// background; the WALLS take a coarse one, because their job is to catch the lamp and a 36-point
/// ring does that as well as a 192-point one. The coarse ring is inscribed in the fine one, so the
/// outermost sliver of the animal stays face colour - about 1 px at hero size, which reads as the
/// rim of a shell, and which is what a shell has.
function cht_body_parts(_sp, _bev, _px, _nb, _prefix) {
    var _out = [];
    var _n = cht_body_samples_for(is_undefined(_px) ? 700 : _px);
    var _pts = cht_body_outline(_sp, _n);

    // The mass. Filled from the animal's own centre so the fan is star-shaped about a point that
    // is genuinely inside every plan in the corpus - a lobe blend is convex enough for that, and
    // cht_selftest asserts it rather than assuming it.
    //
    // ⚠️ IT IS DRAWN EVEN THOUGH THE SHELL COVERS IT, AND THAT IS NOT WASTE. The shell strips are
    // clipped per row to the body's span, so along a curved margin they approximate the outline
    // with a staircase one strip wide; the fill underneath is what the animal's true silhouette is
    // made of. Removing it leaves a jagged edge that no floor can see.
    array_push(_out, cht_ring_fill(_pts, "m2", 0, 0));

    // The shell, as a tube. See cht_body_shell for why this is not a dome and not a bevel.
    cht_append(_out, cht_body_shell(_sp, 0, 1, _nb, _prefix));

    // A shallow distance bevel at the RIM only. The tube gives the broad curvature; this gives the
    // hard bright edge where the shell turns over, which is the thing that says CHITIN rather than
    // putty. The two are not redundant - one is the form, the other is the material - and this one
    // IS bound by the inset limiter, so it takes a COARSE ring, where the limiter has room to allow
    // a rim you can see. That is the opposite density from the shell above, on purpose.
    var _rel = cht_body_outline(_sp, min(_n, CHT_BODY_RELIEF_SAMPLES));
    var _b = cht_bevel_cap(_rel, is_undefined(_bev) ? 0.028 : _bev);
    cht_append(_out, cht_bevel(_rel, _b, 2, false));

    return _out;
}

/// ⛔ SHRINK A FINISHED PART LIST UNTIL IT FITS THE UNIT BOX.
///
/// MEASURED on the first preview: 26 of the 48 species drew OUTSIDE the unit box, the worst
/// reaching 1.377 - a longhorn beetle whose antennae are longer than its body, which is not a bug
/// in the corpus, it is what a longhorn beetle IS. But the unit box is the contract: a buyer hands
/// this package a rectangle, and geometry outside it lands on whatever their interface has there.
///
/// The obvious fix - shorten the antennae - is the wrong one twice over: it makes the longhorn
/// wrong, and it treats a CONTAINMENT problem as a CORPUS problem. Scaling the finished animal
/// about the origin costs nothing anatomically (every proportion is preserved, which is the whole
/// point of a corpus) and makes the property true by construction.
///
/// ⚠️ AND THAT MAKES THE CONTAINMENT ASSERTION VACUOUS, SO IT IS NOT THE ONE TO KEEP. Carried in
/// from Hearth, which learned it on declared extents: when a property is guaranteed by
/// construction, assert the CORRECTION FACTOR instead. A species needing to be shrunk below about
/// 0.55 is not a long-antennaed insect, it is a mistake in its row, and the suite names it.
///
/// Scaling goes through cht_place so stroke widths and arc radii scale with the geometry; a list
/// scaled by moving points alone keeps hero-scale pen widths on a shrunken animal.
function cht_fit_unit(_parts, _limit) {
    var _bb = cht_render_bounds(_parts);
    var _r = max(max(abs(_bb[0]), abs(_bb[2])), max(abs(_bb[1]), abs(_bb[3])));
    if (_r <= _limit || _r <= 0) return _parts;
    var _k = _limit / _r;
    return cht_place(_parts, 0, 0, _k, 0, _k);
}

/// How much a species has to be shrunk to fit the unit box, 1.0 meaning not at all.
/// Exists so the suite can assert the CORRECTION rather than the property the correction
/// guarantees. See cht_fit_unit.
function cht_fit_factor(_parts, _limit) {
    var _bb = cht_render_bounds(_parts);
    var _r = max(max(abs(_bb[0]), abs(_bb[2])), max(abs(_bb[1]), abs(_bb[3])));
    if (_r <= _limit || _r <= 0) return 1;
    return _limit / _r;
}

/// The transverse groove at an axis position, clipped to the body's own span there.
///
/// Used for the neck suture, the pronotum's hind margin and a larva's segment rings. Drawn as a
/// cut rather than a line: cht_incise lays a dark wall and a lit wall either side of the stroke,
/// so it reads as a groove in a shell instead of a pen mark on a picture.
function cht_body_suture(_sp, _t, _reach, _w) {
    var _hw = cht_body_halfw(_sp, _t) * clamp(is_undefined(_reach) ? 0.92 : _reach, 0, 1);
    var _y = cht_body_y(_sp, _t);
    // Bowed backward, the way a real suture is - a straight rule across an animal reads as a
    // scratch on the image rather than a feature of the shell.
    var _pts = [];
    var _bow = _hw * 0.22;
    for (var _i = 0; _i <= 10; _i++) {
        var _u = -1 + 2 * (_i / 10);
        array_push(_pts, [_u * _hw, _y + _bow * (1 - _u * _u)]);
    }
    return cht_incise(_pts, false, is_undefined(_w) ? 0.006 : _w);
}

/// ============================================================================================
/// THE HEAD
///
/// Small, and it carries the two features that decide whether the drawing is of an animal or of a
/// shape: the compound eyes and the mandibles. Both are placed in AXIS coordinates and clipped to
/// the head's own span, so a species with a narrow head gets narrow-set eyes for free.
/// ============================================================================================

/// The compound eyes. Set at the widest part of the head and slightly forward of its centre,
/// which is where they are - eyes set at the head's midpoint read as nostrils.
///
/// ⚠️ AN EYE IS A DRILLED, DOMED MASS, NOT A DOT. A flat dark disc on a lit shell reads as a hole
/// punched in the animal. The highlight is what makes it a lens, and it is offset TOWARD the lamp
/// rather than centred, or it reads as a second pupil.
function cht_head_eyes(_sp, _t, _r, _bulge) {
    var _out = [];
    var _hw = cht_body_halfw(_sp, _t);
    var _rr = min(_r, _hw * 0.52);
    if (_rr <= 0) return _out;
    var _y = cht_body_y(_sp, _t);
    for (var _s = -1; _s <= 1; _s += 2) {
        var _x = _s * (_hw - _rr * (1 - clamp(_bulge, 0, 0.9)));
        var _ring = cht_ellipse_pts(_x, _y, _rr, _rr * 1.18, 18);
        array_push(_out, cht_ring_fill(_ring, "m0", _x, _y));
        cht_append(_out, cht_bevel(_ring, cht_bevel_cap(_ring, _rr * 0.42), 2, true));
        // The lens highlight. Toward the lamp, which the relief file points up and to the left.
        array_push(_out, cht_dot(_x - _rr * 0.34, _y - _rr * 0.42, _rr * 0.30, "m4"));
    }
    return _out;
}

/// The mandibles. Two curved jaws crossing in front of the head apex.
///
/// ⛔ THEY OVERLAP THE HEAD, LIKE EVERY OTHER APPENDAGE HERE - a jaw that begins at the outline
/// leaves a hairline of page across the front of the animal, which is the first place anybody
/// looks. _len is in unit-box units; _cross is how far past the midline the tips reach, and a
/// value of 0 gives the blunt jaws of a leaf beetle rather than the crossed ones of a ground beetle.
/// ⛔⛔ A STAG BEETLE'S MANDIBLES ARE THE ANIMAL, AND THE FIRST VERSION DREW THEM AS TWO HAIRS.
///
/// MEASURED 2026-09-01 by opening big_0 at 900 px: the most recognisable beetle in the roster came
/// out as a plain brown oval, and cht_selftest's all-pairs sweep agreed from the other side -
/// `stag beetle / click beetle` scored 0.097, i.e. the two were nearly the same picture. Both jaws
/// were there and both were drawn: a constant 0.0125 half-width tapering ribbon, which on a
/// 0.190-long jaw is a wire. The mandible had a LENGTH column and no thickness of its own.
///
/// ⭐ THE THICKNESS IS A FUNCTION OF THE LENGTH, and that is anatomy rather than a fudge. A beetle
/// that fights with its jaws grows them heavy; the small blunt jaws of a leaf beetle are short AND
/// fine, and nothing in nature has a long thread for a mandible. One column therefore drives both,
/// and the corpus does not need a second number it would get wrong.
///
/// ⚠️ AND THE INNER TOOTH IS WHAT MAKES IT A STAG BEETLE RATHER THAN A PAIR OF PINCERS. It only
/// appears on jaws long enough to carry it - below that it is one pixel of noise on the front of
/// the animal, which is the first place anybody looks.
///
/// _len is in unit-box units; _cross is how far past the midline the tips reach, and 0 gives the
/// blunt jaws of a leaf beetle rather than the crossed ones of a ground beetle.
/// ⛔ THEY OVERLAP THE HEAD, like every other appendage here - a jaw that begins at the outline
/// leaves a hairline of page across the front of the animal.
function cht_head_mandibles(_sp, _len, _w, _cross) {
    var _out = [];
    if (_len <= 0) return _out;
    var _troot = 0.045;
    var _y0 = cht_body_y(_sp, _troot);
    var _hw = cht_body_halfw(_sp, _troot);
    var _th = max(_w, _len * 0.155);
    var _big = (_len > 0.10);
    for (var _s = -1; _s <= 1; _s += 2) {
        var _bx = _s * _hw * 0.72;
        var _tipx = -_s * _len * _cross;
        var _tipy = _y0 - _len;
        // The control point is pushed out by the jaw's own LENGTH as well as by the head's width,
        // so a long jaw bows outward into the arc a stag beetle actually has instead of running
        // straight to the crossing point.
        var _j = cht_qbez([_bx, _y0 + _len * 0.16],
                          [_s * (_hw * 0.88 + _len * 0.46), _y0 - _len * 0.66],
                          [_tipx, _tipy], 12);
        var _n = array_length(_j);
        var _ws = array_create(_n);
        for (var _k = 0; _k < _n; _k++) {
            var _u = _k / (_n - 1);
            var _t2 = _th * power(1 - _u, 0.58);
            if (_big) {
                var _d = abs(_u - 0.50);
                if (_d < 0.18) _t2 += _th * 0.55 * (1 - _d / 0.18);
            }
            _ws[_k] = max(_th * 0.09, _t2);
        }
        cht_append(_out, _cht_jaw_mass(_j, _ws));
    }
    return _out;
}

/// A tapering appendage with real mass: the spine offset by a per-point half-width, filled as a
/// STRIP and given a lit rim.
///
/// ⚠️ A STRIP, NOT A FAN. A jaw carrying an inner tooth is CONCAVE, and cht_ring_fill is a triangle
/// fan whose own header states its precondition - the outline must be star-shaped about the centre
/// it is given. This wing shipped every crescent moon as a quarter by ignoring that. A strip
/// between two rails is exact wherever a ribbon is the shape, which is exactly here.
function _cht_jaw_mass(_pts, _ws) {
    var _n = array_length(_pts);
    var _a = array_create(_n), _b = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _l = point_distance(0, 0, _dx, _dy);
        if (_l == 0) _l = 1;
        _dx /= _l; _dy /= _l;
        _a[_i] = [_pts[_i][0] - _dy * _ws[_i], _pts[_i][1] + _dx * _ws[_i]];
        _b[_i] = [_pts[_i][0] + _dy * _ws[_i], _pts[_i][1] - _dx * _ws[_i]];
    }
    var _out = [cht_strip(_a, _b, "m2")];
    var _o = [];
    for (var _i = 0; _i < _n; _i++) array_push(_o, _a[_i]);
    for (var _i = _n - 1; _i >= 0; _i--) array_push(_o, _b[_i]);
    _o = cht_dedupe_pts(_o);
    cht_append(_out, cht_bevel(_o, cht_bevel_cap(_o, _ws[0] * 0.50), 2, false));
    return _out;
}

/// THE MEDIAN HORN of a rhinoceros beetle: a stout tapering spike on the midline, forked at the tip.
///
/// ⭐ READ OFF THE ROSTER RATHER THAN ADDED AS A COLUMN, exactly as the swallowtail's wing shape is.
/// One species in forty-eight has a horn, so a `hrn` column would be forty-seven zeroes and one
/// number - a field nobody reads, on every row, forever. cht_species names the species.
///
/// Seen from above, which is the view this whole package draws, a rhinoceros beetle's horn projects
/// FORWARD over its head and splits into two short prongs. It is the single feature that makes the
/// animal what its name says, and without it the sweep scored it 0.103 from a dor beetle.
function cht_head_horn(_sp, _len, _w) {
    var _out = [];
    if (_len <= 0) return _out;
    var _y0 = cht_body_y(_sp, 0.030);
    var _th = max(_w, _len * 0.150);
    var _shaft = cht_qbez([0, _y0 + _len * 0.34], [0, _y0 - _len * 0.30], [0, _y0 - _len * 0.62], 8);
    var _n = array_length(_shaft);
    var _ws = array_create(_n);
    for (var _k = 0; _k < _n; _k++) {
        _ws[_k] = max(_th * 0.30, _th * power(1 - _k / (_n - 1), 0.42));
    }
    cht_append(_out, _cht_jaw_mass(_shaft, _ws));
    // The fork. Two short prongs off the tip, and they are what separates a horn from a spine.
    for (var _s = -1; _s <= 1; _s += 2) {
        var _pr = cht_qbez([0, _y0 - _len * 0.50],
                           [_s * _len * 0.10, _y0 - _len * 0.82],
                           [_s * _len * 0.20, _y0 - _len], 7);
        var _m = array_length(_pr);
        var _pw = array_create(_m);
        for (var _k = 0; _k < _m; _k++) {
            _pw[_k] = max(_th * 0.10, _th * 0.62 * power(1 - _k / (_m - 1), 0.55));
        }
        cht_append(_out, _cht_jaw_mass(_pr, _pw));
    }
    return _out;
}

/// ============================================================================================
/// THE SHELL
///
/// ⛔⛔ AN INSECT IS A TUBE, AND MODELLING IT AS A DOME IS WHY THE FIRST THREE ATTEMPTS LOOKED WRONG.
///
/// Measured by looking, in this order. (1) A distance bevel: the inset limiter correctly capped it
/// at a 3 px rim on a 700 px animal, so the beetle was flat. (2) A centroid-scaled dome: deep
/// enough at last, and BLOTCHY - it put a pale puzzle-piece across the pronotum, because scaling a
/// LONG WAISTED shape about one centroid is not a dome, it is a collapse toward the middle, and the
/// head's rings are not concentric with the head. (3) This.
///
/// A beetle seen from above is a half-cylinder whose axis runs head to tail. It is curved ACROSS
/// its width and very nearly flat ALONG its length - which is why a photograph of one has a bright
/// side, a dark side, and no highlight at either end. So the shading is a function of the LATERAL
/// coordinate alone, and the surface normal at lateral fraction u is the normal of a cylinder:
/// it swings from pointing fully left at the left margin to fully right at the right.
///
/// ⭐ AND THE STRUCTURAL COLOUR IS PART OF THE SAME FUNCTION RATHER THAN AN OVERLAY ON TOP OF IT.
/// The first version painted a shimmer over a finished shell, which is a second lighting model
/// stacked on the first and reads as a decal. Iridescence is not paint ON the cuticle, it IS the
/// cuticle, so it belongs in the one place the cuticle's colour is decided.
///
/// The caller writes one colour per band into the palette under _prefix + index; cht_species does.
/// ============================================================================================

/// Where on the cuticle's tonal ramp a tube surface sits at lateral fraction _u.
///
/// The lamp's x component is all that matters on a cylinder whose axis faces the viewer: the ends
/// of a tube are not lit differently from its middle, and adding an along-axis term to "make it
/// more three-dimensional" is what produced the blotches in attempt (2).
function cht_tube_k(_u) {
    var _a = clamp(_u, -1, 1) * pi * 0.5;
    return clamp(0.5 + 0.5 * (sin(_a) * CHT_LX + cos(_a) * 0.14), 0, 1);
}

/// The shell: longitudinal strips down the animal, each clipped to the body's own span at every
/// height it crosses.
///
/// ⚠️ CLIPPED PER ROW, NOT PER STRIP. This is the wing's containment law applied to a surface
/// rather than to a mark: a strip is only as wide as the body is AT THAT HEIGHT, and a strip
/// clamped once against the widest point would hang off the animal everywhere else.
function cht_body_shell(_sp, _t0, _t1, _nb, _prefix) {
    var _out = [];
    if (_nb <= 0) return _out;

    // The widest half-width anywhere in the region: the lateral coordinate is measured against the
    // animal's own beam, so band i sits at the same place on a broad species and a narrow one.
    var _wmax = 0;
    for (var _i = 0; _i <= 24; _i++) {
        _wmax = max(_wmax, cht_body_halfw(_sp, _t0 + (_t1 - _t0) * (_i / 24)));
    }
    if (_wmax <= 0) return _out;

    var _rows = 30;
    for (var _b = 0; _b < _nb; _b++) {
        var _u0 = -1 + 2 * (_b / _nb);
        var _u1 = -1 + 2 * ((_b + 1) / _nb);
        var _ra = array_create(_rows + 1);
        var _rb = array_create(_rows + 1);
        for (var _i = 0; _i <= _rows; _i++) {
            var _t = _t0 + (_t1 - _t0) * (_i / _rows);
            var _hw = cht_body_halfw(_sp, _t);
            var _y = cht_body_y(_sp, _t);
            _ra[_i] = [clamp(_u0 * _wmax, -_hw, _hw), _y];
            _rb[_i] = [clamp(_u1 * _wmax, -_hw, _hw), _y];
        }
        array_push(_out, cht_strip(_ra, _rb, _prefix + string(_b)));
    }
    return _out;
}

/// ============================================================================================
/// PLANS
///
/// The lobe lists. A species overrides any of these numbers; these are the shapes of the CLASSES.
/// ============================================================================================

/// A body spec ready to draw. _len is the animal's length in unit-box units.
function cht_body_spec(_plan, _len, _lobes, _blend) {
    return { plan: _plan, len: _len, lobes: _lobes, blend: _blend };
}

/// The default body for a plan. Every number here is a starting point a species is expected to
/// move; what a species must NOT move is the number of lobes, because the drawn features - the
/// sutures, the elytra, the leg sockets - are placed in axis coordinates that assume this layout.
function cht_body_plan(_plan) {
    switch (clamp(_plan, 0, CHT_PLAN_N - 1)) {
        case CHT_PLAN_ELYTRA:
            // A beetle. Small round head, trapezoidal pronotum widest at its hind margin, long
            // elytral mass. The waist is shallow: a beetle is a compact animal.
            return cht_body_spec(CHT_PLAN_ELYTRA, 0.72, [
                cht_lobe(0.095, 0.095, 0.104, 0.50, 1.00),   // head       c-r = 0.000
                cht_lobe(0.300, 0.190, 0.150, 0.38, 1.45),   // pronotum, widest at the back
                cht_lobe(0.660, 0.340, 0.168, 0.44, 0.86),   // elytra     c+r = 1.000
            ], 6.5);

        case CHT_PLAN_ELYTRA_OPEN:
            // A beetle in flight. The same animal as above - identical lobes, deliberately, since
            // an insect does not change shape to take off - and what differs is entirely in what
            // is drawn ON it: the elytra are raised and the hindwings are unfolded. Sharing the
            // lobes is the point, not a shortcut: it is what makes the flying and resting pictures
            // recognisably the same individual.
            return cht_body_spec(CHT_PLAN_ELYTRA_OPEN, 0.72, [
                cht_lobe(0.095, 0.095, 0.104, 0.50, 1.00),
                cht_lobe(0.300, 0.190, 0.150, 0.38, 1.45),
                cht_lobe(0.660, 0.340, 0.168, 0.44, 0.86),
            ], 6.5);

        case CHT_PLAN_SPREAD:
            // A spread butterfly. The body is SLIM because the wings are the picture; a thick
            // body on a spread specimen reads as a moth whatever the wings do.
            return cht_body_spec(CHT_PLAN_SPREAD, 0.66, [
                cht_lobe(0.080, 0.080, 0.056, 0.50, 1.00),   // head     c-r = 0.000
                cht_lobe(0.270, 0.190, 0.078, 0.42, 1.10),   // thorax
                cht_lobe(0.670, 0.330, 0.058, 0.62, 0.95),   // abdomen  c+r = 1.000
            ], 4.0);

        case CHT_PLAN_FOLDED:
            // A moth at rest. Thicker, furrier thorax and a stouter abdomen than the butterfly,
            // because that difference is most of how the two read apart at a glance.
            return cht_body_spec(CHT_PLAN_FOLDED, 0.64, [
                cht_lobe(0.085, 0.085, 0.072, 0.46, 1.00),   // head     c-r = 0.000
                cht_lobe(0.280, 0.200, 0.110, 0.36, 1.05),   // thorax, deep and square
                cht_lobe(0.680, 0.320, 0.086, 0.55, 0.92),   // abdomen  c+r = 1.000
            ], 3.4);

        case CHT_PLAN_SOFT:
            // A soft-bodied adult - a firefly, a soldier beetle, a true bug. The pronotum is a
            // shield and the abdomen is flexible, so the waist is nearly absent.
            return cht_body_spec(CHT_PLAN_SOFT, 0.70, [
                cht_lobe(0.090, 0.090, 0.082, 0.50, 1.00),   // head     c-r = 0.000
                cht_lobe(0.290, 0.200, 0.132, 0.34, 1.20),
                cht_lobe(0.650, 0.350, 0.140, 0.50, 0.94),   // abdomen  c+r = 1.000
            ], 3.0);

        default:
            // A caterpillar or grub. One tube: a low blend exponent fuses the lobes into a single
            // fusiform mass with no waist at all, which is what a larva is.
            return cht_body_spec(CHT_PLAN_LARVAL, 0.78, [
                cht_lobe(0.075, 0.075, 0.092, 0.50, 1.00),   // head     c-r = 0.000
                cht_lobe(0.400, 0.330, 0.124, 0.30, 1.00),
                cht_lobe(0.720, 0.280, 0.108, 0.40, 0.90),   // abdomen  c+r = 1.000
            ], 2.0);
    }
}

/// A species' own body: the plan's lobes, moved by that species' four scalar modifiers.
///
/// ⭐ SCALARS RATHER THAN A LOBE LIST PER SPECIES, AND THE REASON IS THE CORPUS. 48 hand-written
/// lobe lists is 144 numbers nobody can hold in their head, and the failure mode is not a wrong
/// beetle - it is a corpus that drifts apart until two families no longer share a shape language.
/// Four modifiers over a plan keeps every beetle recognisably a beetle while letting a stag beetle
/// be long and a ladybird be round, and it is what makes the collision sweep meaningful: species
/// that collide do so because their NUMBERS are close, not because one of them was typed wrong.
///
/// _hk head, _pk pronotum/thorax, _ak abdomen/elytra, all multipliers on the lobe's half-width.
/// _lk multiplies the body length. _bk multiplies the blend exponent, i.e. how pinched the waist is.
function cht_body_of(_plan, _hk, _pk, _ak, _lk, _bk) {
    var _b = cht_body_plan(_plan);
    var _n = array_length(_b.lobes);
    var _out = array_create(_n);
    var _k = [_hk, _pk, _ak];
    for (var _i = 0; _i < _n; _i++) {
        var _lb = _b.lobes[_i];
        var _m = (_i < 3) ? _k[_i] : 1;
        _out[_i] = cht_lobe(_lb.c, _lb.r, _lb.w * _m, _lb.e, _lb.g);
    }
    return cht_body_spec(_plan, _b.len * _lk, _out, _b.blend * _bk);
}
