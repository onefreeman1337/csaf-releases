{
  "$GMScript": "v1",
  "%Name": "cht_catch",
  "name": "cht_catch",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}