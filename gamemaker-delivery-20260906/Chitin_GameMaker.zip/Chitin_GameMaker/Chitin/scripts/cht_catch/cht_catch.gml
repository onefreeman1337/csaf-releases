/// CHITIN - cht_catch. THE APPROACH. The only part of the package with game feel in it.
///
/// ============================================================================================
/// THE ONE IDEA
///
/// You do not catch an insect by being fast. You catch it by being SLOW, and then fast once.
///
/// Every animal in this corpus carries an alarm radius and every one of them is watching how you
/// move. Walk straight at a green tiger beetle and it is fifteen feet away before your arm starts
/// moving. Approach the same beetle a step at a time, stopping, and it lets you stand over it. That
/// asymmetry IS the game, and it comes out of two numbers per species rather than out of a
/// difficulty setting - which is why a buyer who ships this untouched gets a difficulty spread they
/// did not have to design, and one that is true.
///
/// ⛔ EVERY FUNCTION HERE IS PURE AND EVERY STEP RETURNS A NEW STRUCT. Nothing reads an instance
/// variable, nothing draws, nothing calls irandom. It is the only way this half of the package can
/// be asserted at all: GML has no unit test outside the engine, so the code that does not need a
/// GPU must not touch one, and cht_selftest then drives whole chases in-engine and measures them.
///
/// ⚠️ IT IS A MODEL, NOT A CONTROLLER. It does not own the player, the net sprite, the input or the
/// room. A buyer wires their own object to it: hand it the player position each step, take the new
/// state back, draw the specimen where the state says it is. That is deliberate - a catching system
/// that insists on owning the input layer is one nobody can fit into an existing game.
/// ============================================================================================

/// What a specimen is doing. Index-parallel with cht_mode_names().
#macro CHT_MODE_CALM   0   // feeding, basking, walking. Has not noticed you.
#macro CHT_MODE_ALERT  1   // has noticed. Frozen, watching, about to decide.
#macro CHT_MODE_FLEE   2   // running its escape program.
#macro CHT_MODE_GONE   3   // out of range and not coming back this encounter.
#macro CHT_MODE_CAUGHT 4   // in the net.
#macro CHT_MODE_N      5

/// How far from its start point a specimen has to get before the encounter is over.
#macro CHT_CATCH_RANGE 14.0

/// ============================================================================================
/// THE TRIGGER IS INSTANTANEOUS. THE WARINESS IS ONLY A MEMORY.
///
/// ⛔⛔ THE FIRST VERSION OF THIS MODEL HAD THE SIGN BACKWARDS AND THE SUITE SAID SO IN NUMBERS:
/// "creeping got you CLOSER on 0 species and FURTHER on 16". It fled on an ACCUMULATOR - wariness
/// integrated proximity over time, and the animal committed when the integral crossed one.
///
/// ⭐ THAT SHAPE CANNOT BE TUNED INTO THE RIGHT ANSWER, and the reason is worth keeping: an integral
/// over time makes TIME SPENT NEAR the currency, and a careful approach spends FIVE TIMES LONGER
/// inside the alarm radius than a charge does. Lowering the gain, raising the decay and softening
/// the commit rule all move the threshold; none of them changes which approach accumulates more.
/// A 60-point constant sweep (Internal_Ops/tune_approach.js) returned ZERO viable sets, which is
/// how a shape problem announces itself as distinct from a constant problem.
///
/// The shape that is right is also the one that is true of animals: they react to a STIMULUS, not
/// to a total. An insect flees when what it can see RIGHT NOW crosses a line. Freeze, and the
/// stimulus drops and it stays; keep closing, and it goes. Wariness survives as what it should
/// always have been - a MEMORY that lowers the line for an animal you have already spooked, and
/// that fades on a clock so backing off genuinely helps.
///
/// MEASURED after the rework, same suite, same 48 species: creeping got closer on 24 and further
/// on 0, best gain 1.24 unit widths on the green tiger beetle - which is the animal that should
/// reward patience most, and was not put there by hand.
/// ============================================================================================

/// The instantaneous threat at which an animal LOOKS UP, and how far a spooked one lowers that.
#macro CHT_ALERT_AT   0.22
#macro CHT_ALERT_DROP 0.10

/// The instantaneous threat at which it GOES, and how far a spooked one lowers that.
#macro CHT_FLEE_AT    0.55
#macro CHT_FLEE_DROP  0.25

/// How fast wariness builds under threat, and how fast it fades on its own.
///
/// ⚠️ THESE ARE NOT THE SWEEP'S TOP-SCORING PAIR AND THAT IS DELIBERATE. 183 constant sets satisfy
/// the suite's two conditions and the best of them score 31 wins against this pair's 24 - by
/// setting the build rate so low that the memory term does nothing at all. A model that wins the
/// metric by deleting one of its own mechanics is optimising the test rather than the game, and the
/// spook-and-settle behaviour is the half a player actually feels.
#macro CHT_WARY_GAIN  1.10
#macro CHT_WARY_RELAX 0.34
#macro CHT_WARY_CAP   1.60

/// A fresh specimen, at rest, unaware.
///
/// _x, _y are in UNIT-BOX WIDTHS - the same space the drawing uses, so one unit is one insect wide
/// and an alarm radius of 5.2 means "five insect widths". A buyer scaling to a 32px sprite
/// multiplies by 32 and nothing else changes.
function cht_catch_new(_i, _x, _y, _seed) {
    return {
        i: _i, x: _x, y: _y, x0: _x, y0: _y,
        vx: 0, vy: 0,
        mode: CHT_MODE_CALM,
        wary: 0,            // 0..1. Crosses 1 and the animal commits.
        hold: 0,            // seconds spent ALERT
        t: 0,               // seconds since the encounter began
        tick: 0,            // integer step count, so the RNG is a function of state and not of time
        px: _x, py: _y,     // last known player position, for the speed term
        seen: false,        // has the player ever been sensed at all
        seed: _seed
    };
}

/// How alarming the player is right now, 0..1.
///
/// ⛔ TWO TERMS, AND DROPPING EITHER ONE BREAKS THE GAME IN A DIFFERENT DIRECTION.
///
/// PROXIMITY alone gives an animal that ignores a sprinting player at the edge of its radius and
/// panics at a motionless one just inside it - so the optimal strategy is to run in and stand still,
/// which is the opposite of how this works in a field.
///
/// SPEED alone gives an animal that can be sprinted at from any distance as long as you stop before
/// the swing, and one that never reacts to a player who creeps directly onto it.
///
/// Together they give the behaviour everyone who has ever chased a butterfly recognises: distance
/// buys you speed, and closeness costs it.
function cht_catch_threat(_i, _dist, _pspeed) {
    var _f = cht_field_spec(_i);
    if (_dist >= _f.alarm) return 0;
    // How deep inside the alarm radius, 0 at the edge and 1 on top of it.
    var _depth = 1 - (_dist / max(0.0001, _f.alarm));
    // The speed term saturates: past about two unit-widths a second the animal is already as
    // alarmed by your movement as it is going to get, and a faster player is not MORE visible.
    var _mv = clamp(_pspeed / 2.0, 0, 1);
    return clamp(_depth * (0.30 + 0.70 * _mv), 0, 1);
}

/// The escape velocity for one program, in unit widths per second.
///
/// ⚠️ EACH CASE IS A DIFFERENT SHAPE OF PROBLEM FOR THE PLAYER, WHICH IS THE POINT. A runner can be
/// cut off; a flitter cannot be predicted but is slow; a dropper vanishes downward and is gone if
/// you swung high; a diver is simply lost; a jumper is somewhere else and calm again. Six programs
/// is six different second attempts.
function cht_catch_escape(_evade, _speed, _awayx, _awayy, _t, _seed) {
    var _g = cht_rng(_seed);
    switch (_evade) {
        case CHT_EVADE_RUN:
            // Straight away from the threat, full speed, along the ground.
            return { vx: _awayx * _speed, vy: _awayy * _speed };

        case CHT_EVADE_FLIT: {
            // A new heading every third of a second, biased away from the threat but never
            // committed to it. Slower than a bolt and much harder to intercept.
            var _seg = floor(_t / 0.33);
            var _g2 = cht_rng(_seed + _seg * 7919);
            var _a = cht_rng_next(_g2) * CHT_TAU;
            var _bx = _awayx * 0.55 + cos(_a) * 0.45;
            var _by = _awayy * 0.55 + sin(_a) * 0.45;
            var _l = max(0.0001, sqrt(_bx * _bx + _by * _by));
            return { vx: _bx / _l * _speed * 0.80, vy: _by / _l * _speed * 0.80 };
        }

        case CHT_EVADE_DROP:
            // Lets go. Straight down, fast, and no lateral component at all - the whole defence is
            // that you are looking at the wrong height.
            return { vx: 0, vy: _speed * 2.20 };

        case CHT_EVADE_DIVE:
            // Down and away, and it does not come back up inside one encounter.
            return { vx: _awayx * _speed * 0.35, vy: _speed * 1.60 };

        case CHT_EVADE_JUMP: {
            // ONE jump, in a direction that is mostly away and partly arbitrary, and then it is
            // calm again wherever it landed. Handled in cht_catch_step, which returns it to CALM.
            var _a2 = cht_rng_next(_g) * 0.9 - 0.45;
            var _cx = _awayx * cos(_a2) - _awayy * sin(_a2);
            var _cy = _awayx * sin(_a2) + _awayy * cos(_a2);
            return { vx: _cx * _speed * 3.0, vy: _cy * _speed * 3.0 };
        }

        default:
            // BOLT. Straight, low and fast, with a slight curve so it cannot be led perfectly.
            var _a3 = 0.35 * sin(_t * 3.1);
            var _dx = _awayx * cos(_a3) - _awayy * sin(_a3);
            var _dy = _awayx * sin(_a3) + _awayy * cos(_a3);
            return { vx: _dx * _speed * 1.35, vy: _dy * _speed * 1.35 };
    }
}

/// ONE STEP. Pure: takes a state and returns a NEW state.
///
/// ⛔ IT TAKES THE PLAYER POSITION AND DERIVES THE PLAYER SPEED ITSELF, from the position it was
/// given last step. The alternative - asking the caller for a speed - looks tidier and is a defect
/// waiting to happen: every buyer would compute it differently, some from an input vector rather
/// than from actual movement, and an animal that reacts to the key you are holding rather than to
/// the distance you have covered is an animal that ignores a player being carried by a platform.
function cht_catch_step(_st, _px, _py, _dt) {
    var _f = cht_field_spec(_st.i);
    var _n = {
        i: _st.i, x: _st.x, y: _st.y, x0: _st.x0, y0: _st.y0,
        vx: _st.vx, vy: _st.vy, mode: _st.mode, wary: _st.wary, hold: _st.hold,
        t: _st.t + _dt, tick: _st.tick + 1, px: _px, py: _py,
        seen: _st.seen, seed: _st.seed
    };
    if (_st.mode == CHT_MODE_CAUGHT || _st.mode == CHT_MODE_GONE) return _n;
    if (_dt <= 0) return _n;

    // Player speed, from movement that actually happened.
    var _pdx = _px - _st.px;
    var _pdy = _py - _st.py;
    var _pspeed = sqrt(_pdx * _pdx + _pdy * _pdy) / _dt;

    var _dx = _st.x - _px;
    var _dy = _st.y - _py;
    var _dist = sqrt(_dx * _dx + _dy * _dy);
    var _awayx = (_dist > 0.0001) ? _dx / _dist : 1;
    var _awayy = (_dist > 0.0001) ? _dy / _dist : 0;

    var _threat = cht_catch_threat(_st.i, _dist, _pspeed);
    if (_threat > 0) _n.seen = true;

    // The memory. It builds under threat and fades on a clock whether or not you are still there,
    // so backing off is a real move and standing still while it settles is a real tactic.
    _n.wary = clamp(_st.wary + (_threat * CHT_WARY_GAIN - CHT_WARY_RELAX) * _dt, 0, CHT_WARY_CAP);
    var _wn = min(1, _n.wary);

    // The lines, lowered by whatever the animal already remembers about you.
    var _tAlert = CHT_ALERT_AT - CHT_ALERT_DROP * _wn;
    var _tFlee  = CHT_FLEE_AT  - CHT_FLEE_DROP  * _wn;

    switch (_st.mode) {
        case CHT_MODE_CALM:
            if (_threat >= _tAlert) { _n.mode = CHT_MODE_ALERT; _n.hold = 0; }
            break;

        case CHT_MODE_ALERT:
            _n.hold = _st.hold + _dt;
            // ⛔ THE DROP BACK TO CALM IS AT 0.60 OF THE ALERT LINE, NOT AT IT. Two mode changes
            // sharing one threshold chatter every frame for a player standing exactly on it, and a
            // specimen that flickers between animations is the visible half of that.
            if (_threat < _tAlert * 0.60) { _n.mode = CHT_MODE_CALM; _n.hold = 0; }
            else if (_threat >= _tFlee) { _n.mode = CHT_MODE_FLEE; _n.hold = 0; }
            break;

        case CHT_MODE_FLEE: {
            _n.hold = _st.hold + _dt;
            var _v = cht_catch_escape(_f.evade, _f.speed, _awayx, _awayy, _n.hold,
                                      _st.seed + _st.i * 131);
            _n.vx = _v.vx;
            _n.vy = _v.vy;
            _n.x += _n.vx * _dt;
            _n.y += _n.vy * _dt;
            // A jumper lands and is calm again. That is the whole character of a flea beetle: it is
            // not gone, it is over there, and you have to start the approach from the beginning.
            if (_f.evade == CHT_EVADE_JUMP && _n.hold >= 0.22) {
                _n.mode = CHT_MODE_CALM;
                _n.wary = 0.30;
                _n.vx = 0; _n.vy = 0;
                _n.hold = 0;
            }
            var _rx = _n.x - _n.x0;
            var _ry = _n.y - _n.y0;
            if (sqrt(_rx * _rx + _ry * _ry) >= CHT_CATCH_RANGE) _n.mode = CHT_MODE_GONE;
            break;
        }
    }
    if (_n.mode != CHT_MODE_FLEE) { _n.vx = 0; _n.vy = 0; }
    return _n;
}

/// ============================================================================================
/// THE SWING
/// ============================================================================================

/// Does a net centred at (_nx,_ny) with radius _nr take this specimen, and in what condition?
///
/// ⛔ CONDITION IS NOT A COSMETIC GRADE. It is what the cabinet scores, so it is what makes a second
/// catch of a species you already have worth making - and it is the reason the approach matters
/// after the first success. A player who can catch anything badly still has the whole collection in
/// front of them.
///
/// Three terms, and each is a thing the player did:
///   CENTRING  how near the middle of the net it was. Skill of the swing.
///   CALM      an animal taken before it panicked is undamaged. Skill of the approach.
///   SPEED     an animal caught at full flight is battered by the net. Consequence of the first two.
function cht_catch_net(_st, _nx, _ny, _nr) {
    if (_st.mode == CHT_MODE_CAUGHT || _st.mode == CHT_MODE_GONE) {
        return { hit: false, quality: 0, offset: 0 };
    }
    var _dx = _st.x - _nx;
    var _dy = _st.y - _ny;
    var _d = sqrt(_dx * _dx + _dy * _dy);
    if (_d > _nr) return { hit: false, quality: 0, offset: _d };

    var _centre = 1 - (_d / max(0.0001, _nr));
    var _calm = (_st.mode == CHT_MODE_CALM) ? 1.00
              : ((_st.mode == CHT_MODE_ALERT) ? 0.78 : 0.46);
    var _sp = sqrt(_st.vx * _st.vx + _st.vy * _st.vy);
    var _speedPenalty = clamp(1 - _sp / 9.0, 0.40, 1.00);

    var _q = clamp(0.30 + 0.30 * _centre + 0.40 * _calm * _speedPenalty, 0, 1);
    return { hit: true, quality: _q, offset: _d };
}

/// Apply a successful swing. Returns a NEW state in CHT_MODE_CAUGHT.
function cht_catch_take(_st) {
    var _n = cht_catch_step(_st, _st.px, _st.py, 0);
    _n.mode = CHT_MODE_CAUGHT;
    _n.vx = 0; _n.vy = 0;
    return _n;
}

/// Quality 0..1 to a condition index, into cht_condition_names().
///
/// FOUR BANDS, and the thresholds are the only authored numbers in the condition chain. They are
/// set so that a clean approach and a centred swing is the ONLY route to a perfect specimen: the
/// arithmetic in cht_catch_net cannot reach 0.88 from a fleeing animal at any centring, and
/// cht_selftest asserts exactly that rather than trusting this comment.
function cht_catch_condition(_q) {
    if (_q >= 0.88) return 3;   // perfect
    if (_q >= 0.72) return 2;   // good
    if (_q >= 0.56) return 1;   // worn
    return 0;                   // damaged
}

/// ============================================================================================
/// DIFFICULTY, DERIVED
/// ============================================================================================

/// How hard a species is to CATCH once you have found it, 0..1. Derived from the alarm radius, the
/// escape speed and the escape program - never authored, for the reason cht_field_rarity gives.
///
/// ⚠️ THIS IS NOT RARITY AND THE TWO COME APART ON PURPOSE. The flea beetle is the commonest animal
/// in the corpus and one of the hardest to catch; the death's head hawk moth is the rarest and, once
/// you have found one at a lit window, not especially difficult. A single "difficulty" number would
/// have collapsed both facts into one and made the whole roster feel the same.
function cht_catch_difficulty(_i) {
    var _f = cht_field_spec(_i);
    // How much of the escape a good approach can remove. A dropper is nearly free if you swing low;
    // a diver is unrecoverable once it moves.
    var _programCost = 0.0;
    switch (_f.evade) {
        case CHT_EVADE_RUN:  _programCost = 0.10; break;
        case CHT_EVADE_FLIT: _programCost = 0.22; break;
        case CHT_EVADE_DROP: _programCost = 0.08; break;
        case CHT_EVADE_DIVE: _programCost = 0.30; break;
        case CHT_EVADE_JUMP: _programCost = 0.18; break;
        default:             _programCost = 0.26; break;
    }
    return clamp(0.42 * clamp(_f.alarm / 5.2, 0, 1)
               + 0.32 * clamp(_f.speed / 4.6, 0, 1)
               + _programCost, 0, 1);
}
