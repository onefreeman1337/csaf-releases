/// @description Step

// The viewing phase sweeps the structural-colour band ACROSS the specimen, which is the whole
// observable behaviour of iridescence: a jewel beetle is green at one angle and copper at another,
// and a still picture of one cannot say that. Nothing here is random - the phase is a clock, so
// the same specimen looks the same way at the same moment on every run.
if (spin && !paused) {
    phase += 0.006;
    if (phase > 1) phase -= 1;
}

if (keyboard_check_pressed(vk_right)) species = (species + 1) mod cht_species_n();
if (keyboard_check_pressed(vk_left))  species = (species + cht_species_n() - 1) mod cht_species_n();
if (keyboard_check_pressed(vk_space)) paused = !paused;
if (keyboard_check_pressed(ord("S"))) spin = !spin;
// TAB walks the four views: the specimen, its field-guide page, and the two cabinet drawers.
if (keyboard_check_pressed(vk_tab))   view = (view + 1) mod 4;
