/// @description Clean Up

// ⛔ CLEAN UP RUNS EVEN WHEN CREATE EXITED EARLY, and that is the trap this event exists to not
// fall into. The headless branches in Create call game_end() and exit part way down; GameMaker
// still fires this event on the way out. A sibling product in this wing threw "variable not set
// before reading it" here AFTER a fully green self-test - reported against the last stage the
// SUITE had reached, so a crash was blamed on code that had already finished and passed.
//
// This object holds no surfaces, buffers or data structures of its own: every surface cht_bake
// creates is freed inside the function that created it, in the same call. So there is genuinely
// nothing to release, and the guard below says so rather than leaving the event empty - an empty
// Clean Up reads as an oversight and invites somebody to "fix" it by freeing something twice.
if (variable_instance_exists(id, "species")) species = 0;
