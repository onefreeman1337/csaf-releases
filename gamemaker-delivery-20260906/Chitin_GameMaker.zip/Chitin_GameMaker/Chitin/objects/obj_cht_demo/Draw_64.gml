/// @description Draw GUI

// The demo room. FOUR views, because the product is four things: a corpus, a field layer, an
// identification surface and a collection.
//
// ⛔ A DEMO THAT ONLY CYCLES SPECIMENS SELLS AN ART PACK. Wing CLAUDE.md §2 measures the whole
// GameMaker shelf twice and reaches the same law both times - a complete SYSTEM clears the band and
// a corpus of pictures does not - so the field guide and the cabinet have to be one key away, not
// buried in a Readme.
//
// ⚠️ DRAWN AT THE GUI LAYER ON PURPOSE. A buyer dropping this object into their own project gets a
// specimen that does not move with their camera, which is what a field-guide overlay is; the
// in-world drawing route is cht_render_parts and the Readme says so.
//
// ⚠️ THE PLATE FUNCTIONS ARE THE ONES cht_bake USES FOR THE STORE IMAGES, at the GUI's own size.
// That is deliberate and it is a claim a buyer can check: the pictures on the store page are the
// pictures this room draws, rendered by the same code, and not a mock-up made somewhere else.
var _w = display_get_gui_width();
var _h = display_get_gui_height();

draw_clear(cht_bk_page());

var _hint = "TAB view    LEFT / RIGHT species    SPACE pause    S stop the shimmer";

switch (view) {
    case 1:
        cht_bk_field(species, phase, _w, _h);
        break;

    case 2:
        cht_bk_cabinet(cab, 0, phase, _w, _h);
        break;

    case 3:
        cht_bk_cabinet(cab, 1, phase, _w, _h);
        break;

    default: {
        var _pad = 40;
        var _boxh = _h - 150;
        cht_bk_well(_pad, 86, _w - _pad * 2, _boxh);

        var _px = min(_w - _pad * 2 - 48, _boxh - 48);
        var _parts = cht_species_parts(species, _px, phase);
        var _pal = cht_species_palette(species, phase, _px);
        cht_render_in_rect(_parts, _pal, _pad + 24, 110, _w - _pad * 2 - 48, _boxh - 48, 0,
                           cht_species_map());

        cht_text_label(cht_name_of(cht_species_names(), species), _pad, 30, _w - _pad * 2, 34,
                       cht_bk_page(), cht_bk_ink());

        var _sp = cht_species_spec(species);
        var _cut = cht_cuticle_spec(_sp.cut);
        cht_text_line(cht_name_of(cht_antenna_names(), _sp.ant) + " antennae   "
                    + cht_name_of(cht_leg_names(), _sp.leg) + " legs   "
                    + cht_name_of(cht_sculpture_names(), _sp.scu) + " sculpture   "
                    + cht_name_of(cht_pattern_names(), _sp.pat) + " pattern"
                    + (_cut.irid > 0 ? "   structural colour" : ""),
                      _pad, _h - 56, _w - _pad * 2, 17, cht_bk_dim(), false);
        _hint += "    " + string(array_length(_parts)) + " parts drawn";
    } break;
}

cht_text_line(_hint, 40, _h - 30, _w - 80, 15, cht_bk_dim(), false);
