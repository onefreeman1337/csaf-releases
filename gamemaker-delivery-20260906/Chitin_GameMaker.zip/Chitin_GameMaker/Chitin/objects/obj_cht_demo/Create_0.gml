/// @description Create

// ⛔ THE FIRST LINE OF ANY HEADLESS ENTRY POINT, AND IT IS NOT OPTIONAL.
// A GML runtime error opens a MODAL DIALOG. Headless, nothing dismisses it and the process never
// exits, so a build robot reports a TIMEOUT instead of a defect and the next session re-runs a
// ten-minute bake to learn nothing. Recording the stage number and ending the game turns an opaque
// hang into a named line in a result file. This wing measured that exact conversion on a previous
// product: an opaque 180 s hang became "CRASH at stage 5: Variable Index [25] out of range [25]".
//
// ⛔ THIS IS THE ONLY exception_unhandled_handler IN THE PACKAGE. Whichever is installed last
// silently wins, so two handlers is a coin toss over how much a crash tells you.
global.cht_stage = -1;
exception_unhandled_handler(function(_ex) {
    var _st = "";
    try {
        var _tr = _ex.stacktrace;
        for (var _i = 0; _i < array_length(_tr); _i++) {
            if (_i > 0) _st += " <- ";
            _st += string(_tr[_i]);
        }
    } catch (_e) { _st = "(no stacktrace)"; }
    var _f = file_text_open_write("cht_crash.json");
    file_text_write_string(_f, "{\"stage\":" + string(global.cht_stage)
        + ",\"message\":\"" + string_replace_all(string(_ex.message), "\"", "'") + "\""
        + ",\"where\":\"" + string_replace_all(_st, "\"", "'") + "\"}");
    file_text_close(_f);
    game_end(1);
});

// ⛔ EVERY VARIABLE A LATER EVENT READS IS DECLARED ABOVE THE EARLY EXITS, AND CLEAN UP ALWAYS
// RUNS. The headless branches below leave Create part way down, and GameMaker still fires Clean Up
// on the way out - a sibling product in this wing threw "variable not set before reading it" AFTER
// a fully green self-test, reported against the last stage the suite had reached, i.e. a crash
// blamed on code that had already finished and passed.
species = 0;
phase = 0.50;
paused = false;
spin = true;
global.cht_bake_i = 0;

// ⛔ THE DEMO SHOWS THE SYSTEM, NOT ONLY THE CORPUS, AND THAT IS THE WHOLE POINT OF THE PRODUCT.
// A demo room that cycles 48 beautiful insects is a demo of an ART PACK, and wing CLAUDE.md §2 has
// measured twice - over 646 assets and again over 2,131 - that an art pack in a code territory
// prices at the bottom of the shelf. The field guide and the cabinet are what make this the spine
// of a game, so a buyer must be able to reach them with one key.
//
// ⚠️ THE DEMO CABINET IS BUILT ONCE, IN CREATE. Rebuilding it every frame would allocate 48 array
// copies a frame for a picture that never changes, and cht_cabinet is deliberately value-typed -
// every pin returns a NEW cabinet, which is correct and is not free.
view = 0;                       // 0 specimen, 1 field guide, 2 beetle drawer, 3 lepidoptera drawer
cab = cht_bk_demo_cabinet();

// -- headless modes: run, write the result file, exit -------------------------------------------
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i + 1) + " ";

if (string_pos("-selftest", _args) > 0) {
    // ⛔ THE STAGE NUMBER IS SET INSIDE THE SUITE AND READ BY THE WRITER, so a crash mid-suite
    // still names where it died. The runner treats stage 99 as the suite's own "reached the end"
    // marker: anything less means it stopped partway and the pass count is a count of what it got
    // through, not a green run.
    global.cht_stage = 0;
    cht_selftest_write(cht_selftest_run());
    game_end(0);
    exit;
}

if (string_pos("-preview", _args) > 0) {
    // The species id follows the flag. Parsed defensively: an absent or unparseable id previews
    // species 0 rather than crashing, because a preview that refuses to run teaches nothing.
    var _id = 0;
    for (var _i = 1; _i <= parameter_count(); _i++) {
        if (parameter_string(_i) == "-preview" && _i < parameter_count()) {
            var _v = parameter_string(_i + 1);
            if (string_digits(_v) != "") _id = real(string_digits(_v));
        }
    }
    global.cht_bake_i = clamp(_id, 0, cht_species_n() - 1);
    global.cht_stage = 1;
    cht_bake_preview(global.cht_bake_i);
    game_end(0);
    exit;
}

if (string_pos("-gif", _args) > 0) {
    // A full shimmer cycle on one specimen, at native size, as numbered frames.
    global.cht_stage = 3;
    cht_bake_gif();
    game_end(0);
    exit;
}

if (string_pos("-store", _args) > 0) {
    // The store gallery. Six sheets, each showing something the others do not (CLAUDE.md §4.2b).
    global.cht_stage = 2;
    cht_bake_store();
    game_end(0);
    exit;
}

// -- the interactive demo -----------------------------------------------------------------------
// ⛔ A RUNNABLE DEMO ROOM IS MANDATORY IN THIS WING. A buyer who cannot press Play cannot evaluate,
// and it is also the only real smoke test a GML package has - GML cannot be unit-tested outside
// the engine, so the demo IS part of the verification story and not a courtesy.
cht_lamp_reset();
