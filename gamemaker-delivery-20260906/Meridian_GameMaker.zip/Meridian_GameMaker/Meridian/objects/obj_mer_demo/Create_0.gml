/// @file    obj_mer_demo / Create
/// @package Meridian for GameMaker
///
/// @summary Builds the demonstration tree and the five demo pages.
///
/// @remarks THIS OBJECT IS THE QUICKSTART. Read it top to bottom and you have seen the entire
///          public API of the package in the order you would use it: make a tree, add nodes with
///          their prerequisites, choose a layout, make a view, and draw it.
///
///          TWO BLOCKS IN THIS DEMO ARE SCAFFOLDING AND YOU SHOULD DELETE THEM RATHER THAN COPY
///          THEM INTO YOUR GAME. They are marked SCAFFOLDING where they appear, in the Step
///          event. One drives the interface on its own when nothing has been touched, so that an
///          unattended screen recording has something to record. The other parses command-line
///          arguments so a capture can be made deterministic. Neither belongs in a shipping game
///          — copy the self-drive block into your project and you will have a skill tree that
///          buys its own skills.

/// ⛔ TWO ORDERING TRAPS, BOTH PAID FOR IN THIS WING, BOTH HANDLED BY THE FIRST LINES BELOW.
///
/// 1. A GML RUNTIME ERROR OPENS A MODAL DIALOG. Headless there is nothing to dismiss it, so the
///    process NEVER EXITS — an opaque hang with no output and no clue where it stopped. The handler
///    turns that into a recorded stage number and a clean exit, which is the difference between
///    "the build is broken somehow" and "CRASH at stage 12".
///
/// 2. THE STAGE MUST GO TO A GLOBAL. A sibling product wrote it only to the suite's local struct,
///    so the handler — which reads the global — reported stage 1 for a crash anywhere at all. An
///    instrument that always answers 1 is not reporting, it is agreeing.

exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("mer_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.mer_stage) + ": " + _ex.message);
    file_text_close(_f);
    game_end();
});

global.mer_stage = 0;

randomise();

// ---------------------------------------------------------------------------------------------
// Headless self-test: `Meridian.exe -selftest`
//
// ⚠️ RUNS BEFORE ANY DEMO STATE IS BUILT, so a suite failure cannot be caused by the demo, and the
// suite's runtime is not spent constructing a 34-node tree it never looks at.
// ---------------------------------------------------------------------------------------------
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";

if (string_pos("-selftest", _args) > 0) {
    global.mer_stage = 1;
    var _st = mer_selftest_run();
    global.mer_stage = _st.stage;
    mer_selftest_write(_st);
    game_end();
    exit;
}

// ---------------------------------------------------------------------------------------------
// SCAFFOLDING — open straight into ARMATURE. DELETE THIS BLOCK FOR YOUR GAME.
//
// rm_mer_demo is deliberately the FIRST room, so a buyer who double-clicks the exe lands on the
// quickstart rather than on the editor. That makes the editor unreachable to a capture, which can
// neither press F nor click anything, so `--forge` and `--bake` send it there on the first step.
//
// ⚠️ The rest of this event still runs. room_goto takes effect at the END of the step, so leaving
// the demo half-initialised here would give its own Step and Draw one frame with variables that
// were never set — a crash in the room being left, attributed to the room being entered.
// ---------------------------------------------------------------------------------------------
// ⚠️ EVERY Armature CAPTURE FLAG HAS TO BE LISTED HERE, and forgetting one does not error — the
// game simply stays in the demo room and runs forever, which presents as the capture HANGING. That
// is exactly what `--film=` did: obj_mer_forge understood it perfectly and never got the chance to,
// because this line did not send anything to its room.
//
// ⚠️ MATCHED WITH THE EQUALS SIGN ON PURPOSE. string_pos is substring matching, and this object
// already owns `--filmstrip=` for the demo reel. Testing for `--film` alone would match
// `--filmstrip=60` and send the demo's own capture into the editor's room; testing for `--film=`
// cannot, because what follows `--film` in the longer flag is `strip`. Do not shorten it.
var _toForge = (string_pos("--forge", _args) > 0)
            || (string_pos("--bake", _args) > 0)
            || (string_pos("--film=", _args) > 0);

// ---------------------------------------------------------------------------------------------
// Presentation state
// ---------------------------------------------------------------------------------------------
page       = 0;
pageCount  = 5;
themeIndex = 0;
layoutIndex = 0;
still      = false;
idleFor    = 0;
driveAt    = 0;
driveStep  = 0;

mer_theme_set(mer_theme_by_index(themeIndex));

// ---------------------------------------------------------------------------------------------
// The tree.
//
// Six disciplines, each rooted at its own node, growing outward. Note how little is declared:
// what a node IS, what it COSTS, and what it DEPENDS ON. Nowhere is there an x or a y — the
// layout engines derive every position from the prerequisite graph.
// ---------------------------------------------------------------------------------------------
tree = mer_tree_make();

var _add = function(_t, _id, _name, _sig, _disc, _tier, _cost, _max, _req, _stat, _val, _desc) {
    mer_tree_add(_t, _id, {
        name: _name, sigil: _sig, disc: _disc, tier: _tier, cost: _cost, maxRank: _max,
        requires: _req, stat: _stat, value: _val, desc: _desc
    });
};

// --- BLADE ------------------------------------------------------------------------------------
_add(tree, "bl_root", "EDGE",      "THRUST",   0, MER_TIER_MAJOR,    1, 1, [],            "power",  4, "The first lesson. Everything martial grows from it.");
_add(tree, "bl_a",    "CLEAVE",    "CLEAVE",   0, MER_TIER_MINOR,    1, 3, ["bl_root"],   "power",  3, "Heavy swings carry through to a second target.");
_add(tree, "bl_b",    "PARRY",     "PARRY",    0, MER_TIER_MINOR,    1, 3, ["bl_root"],   "guard",  5, "Deflect an incoming blow and open the counter.");
_add(tree, "bl_c",    "RIPOSTE",   "RIPOSTE",  0, MER_TIER_MINOR,    1, 2, ["bl_b"],      "power",  6, "A parry becomes an attack of its own.");
_add(tree, "bl_d",    "SUNDER",    "SUNDER",   0, MER_TIER_MAJOR,    2, 2, ["bl_a"],      "pierce", 8, "Split armour. Damage ignores a share of protection.");
_add(tree, "bl_e",    "BULWARK",   "BULWARK",  0, MER_TIER_MINOR,    1, 3, ["bl_b"],      "guard",  7, "Hold the line. Blocking costs less stamina.");
_add(tree, "bl_key",  "EXECUTE",   "EXECUTE",  0, MER_TIER_KEYSTONE, 3, 1, ["bl_d", "bl_c"], "power", 20, "Finish a wounded enemy outright below a health threshold.");

// --- ARCANE -----------------------------------------------------------------------------------
_add(tree, "ar_root", "FOCUS",     "FOCUS",    1, MER_TIER_MAJOR,    1, 1, [],            "mana",   6, "Hold a spell steady while the world moves around you.");
_add(tree, "ar_a",    "CHANNEL",   "CHANNEL",  1, MER_TIER_MINOR,    1, 3, ["ar_root"],   "mana",   5, "Sustained casting drains more slowly.");
_add(tree, "ar_b",    "WARD",      "WARD",     1, MER_TIER_MINOR,    1, 3, ["ar_root"],   "guard",  6, "A standing barrier absorbs the first hit of a fight.");
_add(tree, "ar_c",    "PRISM",     "PRISM",    1, MER_TIER_MINOR,    1, 2, ["ar_a"],      "power",  7, "Split a bolt into three narrower ones.");
_add(tree, "ar_d",    "SEAL",      "SEAL",     1, MER_TIER_MAJOR,    2, 2, ["ar_b"],      "guard", 10, "Bind a target in place for a short time.");
_add(tree, "ar_key",  "NEXUS",     "NEXUS",    1, MER_TIER_KEYSTONE, 3, 1, ["ar_c", "ar_d"], "mana", 25, "Every spell you cast leaves a mote that feeds the next.");

// --- VITALITY ---------------------------------------------------------------------------------
_add(tree, "vi_root", "VIGOR",     "VIGOR",    2, MER_TIER_MAJOR,    1, 1, [],            "health", 10, "Deeper reserves. Everything else lasts longer.");
_add(tree, "vi_a",    "MEND",      "MEND",     2, MER_TIER_MINOR,    1, 3, ["vi_root"],   "health",  8, "Recover between encounters without resting.");
_add(tree, "vi_b",    "ROOT",      "ROOT",     2, MER_TIER_MINOR,    1, 3, ["vi_root"],   "guard",   6, "Stand firm. Knockback and stagger are reduced.");
_add(tree, "vi_c",    "BLOOM",     "BLOOM",    2, MER_TIER_MINOR,    1, 2, ["vi_a"],      "health", 12, "Healing overflows into a temporary shield.");
_add(tree, "vi_key",  "RENEWAL",   "RENEW",    2, MER_TIER_KEYSTONE, 3, 1, ["vi_c", "vi_b"], "health", 30, "Survive a lethal blow once per encounter.");

// --- SHADOW -----------------------------------------------------------------------------------
_add(tree, "sh_root", "VEIL",      "VEIL",     3, MER_TIER_MAJOR,    1, 1, [],            "evade",  5, "Move unseen at the edge of a light source.");
_add(tree, "sh_a",    "STALK",     "STALK",    3, MER_TIER_MINOR,    1, 3, ["sh_root"],   "evade",  4, "Move at full speed while concealed.");
_add(tree, "sh_b",    "VENOM",     "VENOM",    3, MER_TIER_MINOR,    1, 3, ["sh_root"],   "power",  5, "Blades carry a lingering toxin.");
_add(tree, "sh_c",    "DRAIN",     "DRAIN",    3, MER_TIER_MINOR,    1, 2, ["sh_b"],      "health",  7, "Damage dealt returns a fraction as health.");
_add(tree, "sh_key",  "SHROUD",    "SHROUD",   3, MER_TIER_KEYSTONE, 3, 1, ["sh_a", "sh_c"], "evade", 22, "Break line of sight and vanish outright, mid-combat.");

// --- FLAME ------------------------------------------------------------------------------------
_add(tree, "fl_root", "IGNITE",    "IGNITE",   4, MER_TIER_MAJOR,    1, 1, [],            "power",  6, "Set what you strike alight.");
_add(tree, "fl_a",    "CINDER",    "CINDER",   4, MER_TIER_MINOR,    1, 3, ["fl_root"],   "power",  4, "Burning enemies scatter embers to their neighbours.");
_add(tree, "fl_b",    "SCORCH",    "SCORCH",   4, MER_TIER_MINOR,    1, 3, ["fl_root"],   "pierce", 5, "Fire strips armour as it burns.");
_add(tree, "fl_c",    "PYRE",      "PYRE",     4, MER_TIER_MAJOR,    2, 2, ["fl_a"],      "power", 11, "A killed enemy detonates.");
_add(tree, "fl_key",  "CONFLAGRATION", "BLAST", 4, MER_TIER_KEYSTONE, 3, 1, ["fl_c", "fl_b"], "power", 28, "Every burning target feeds every other. The field goes up at once.");

// --- FORGE ------------------------------------------------------------------------------------
_add(tree, "fo_root", "TEMPER",    "ANVIL",    7, MER_TIER_MAJOR,    1, 1, [],            "guard",  8, "Your equipment holds its edge far longer.");
_add(tree, "fo_a",    "ALLOY",     "ALLOY",    7, MER_TIER_MINOR,    1, 3, ["fo_root"],   "guard",  6, "Combine materials for a better result than either.");
_add(tree, "fo_b",    "CIRCUIT",   "CIRCUIT",  7, MER_TIER_MINOR,    1, 3, ["fo_root"],   "mana",   5, "Wire a device to draw from your own reserves.");
_add(tree, "fo_c",    "OVERCLOCK", "OVERCLOCK",7, MER_TIER_MINOR,    1, 2, ["fo_b"],      "power",  9, "Push a device past its rating, at a cost.");
_add(tree, "fo_key",  "MASTERWORK","GEAR",     7, MER_TIER_KEYSTONE, 3, 1, ["fo_a", "fo_c"], "guard", 26, "Everything you make comes out one grade above its materials.");

mer_layout_apply(layoutIndex, tree);

// ---------------------------------------------------------------------------------------------
// Progression state, pre-seeded so the demo opens on a tree that has clearly been PLAYED.
//
// An empty tree is the worst possible first screenshot: every node locked, every connector dim,
// and nothing on screen demonstrating any of the states the product actually ships.
// ---------------------------------------------------------------------------------------------
prog = mer_progress_make(6);

var _seed = ["bl_root", "bl_a", "bl_a", "bl_b", "bl_c", "bl_d",
             "ar_root", "ar_a", "ar_b", "ar_b",
             "vi_root", "vi_a", "vi_a", "vi_a",
             "sh_root", "sh_b",
             "fl_root", "fl_a",
             "fo_root", "fo_b"];
mer_progress_grant(prog, 40);
for (var _i = 0; _i < array_length(_seed); _i++) mer_progress_unlock(tree, prog, _seed[_i]);

view = mer_view_make(tree);
view.selected = "bl_d";

// The tree page draws into the left-hand region; the detail panel takes the right.
TREE_X = 0;
TREE_Y = 62;
TREE_W = 946;
TREE_H = 596;
PANEL_X = 962;
PANEL_Y = 74;
PANEL_W = 300;
PANEL_H = 572;

mer_view_frame_all(view, tree, TREE_W, TREE_H, 44);

// ---------------------------------------------------------------------------------------------
// SCAFFOLDING — command-line arguments, for deterministic captures. Delete for your game.
//
// A capture harness cannot press keys reliably: an unfocused GameMaker window stops repainting,
// so synthetic keystrokes produce two identical screenshots taken three seconds apart. Driving
// the demo by argument instead removes the window's focus state from the equation entirely.
// ---------------------------------------------------------------------------------------------
filmTotal = 0;    // > 0 puts the demo in filmstrip mode
filmIndex = 0;
filmFps   = 12;

for (var _i = 0; _i < parameter_count(); _i++) {
    var _p = parameter_string(_i);
    if (string_copy(_p, 1, 7) == "--page=")   page        = real(string_delete(_p, 1, 7));
    if (string_copy(_p, 1, 8) == "--theme=")  themeIndex  = real(string_delete(_p, 1, 8));
    if (string_copy(_p, 1, 9) == "--layout=") layoutIndex = real(string_delete(_p, 1, 9));
    if (string_copy(_p, 1, 12) == "--filmstrip=") filmTotal = real(string_delete(_p, 1, 12));
    if (string_copy(_p, 1, 6) == "--fps=")    filmFps     = max(1, real(string_delete(_p, 1, 6)));
    if (_p == "--still")                      still       = true;
}
page = clamp(page, 0, pageCount - 1);
mer_theme_set(mer_theme_by_index(themeIndex));
mer_layout_apply(layoutIndex, tree);
mer_view_frame_all(view, tree, TREE_W, TREE_H, 44);

// A still needs the springs already settled and the reveal already finished, or the shutter
// catches a half-assembled tree. Advancing the clock in fixed steps is the deterministic way to
// do that — waiting on wall time is not reproducible.
if (still) {
    view.revealAt = 4;
    for (var _i = 0; _i < 240; _i++) {
        mer_view_update(view, tree, prog, -999, -999,
                        TREE_X + TREE_W * 0.5, TREE_Y + TREE_H * 0.5, 1 / 60);
    }
    view.time = 3.1;   // a fixed phase, so the link pulses land in the same place every capture
}

// SCAFFOLDING. Last line of the event, so everything above is initialised before the room changes.
if (_toForge) room_goto(rm_mer_forge);
