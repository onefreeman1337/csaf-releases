/// @file    obj_mer_demo / Step
/// @package Meridian for GameMaker
///
/// @summary Input and per-frame update for the demo.
///
/// @remarks The only lines here that belong in a real game are the mer_view_update call and the
///          click handling. Everything under SCAFFOLDING exists to make the demo capturable and
///          self-demonstrating, and is called out so you delete it rather than inherit it.

if (still) exit;   // a still capture freezes the frame the Create event already settled

// ---------------------------------------------------------------------------------------------
// SCAFFOLDING - FILMSTRIP MODE. DELETE THIS BLOCK FOR YOUR GAME.
//
// Steps the demo at a FIXED timestep and writes one PNG per frame from inside the engine, then
// exits. This exists because screen recording this window is impossible: a GameMaker window that
// does not hold focus STOPS REPAINTING, so ffmpeg's gdigrab returns the same frame over and over.
// Measured 2026-08-10 - 168 "frames" captured, correct window, correct brightness, and the first
// and last byte-identical. Two single grabs four seconds apart were identical too, which is what
// proved the game was frozen rather than the recorder.
//
// Driving the clock by hand instead removes focus, wall time and frame pacing from the problem
// entirely, and makes the output reproducible: the same command yields the same frames every run.
// Same principle the MZ capture pipeline uses when it steps Graphics._onTick by hand.
if (filmTotal > 0) {
    var _fdt = 1 / filmFps;

    // A scripted purchase schedule, so the strip has events in it rather than just idle drift.
    var _script = ["bl_e", "ar_c", "vi_b", "sh_a", "fl_b", "fo_a"];
    var _every = max(1, floor(filmTotal / (array_length(_script) + 1)));
    if (filmIndex > 0 && (filmIndex mod _every) == 0) {
        var _k = (filmIndex div _every) - 1;
        if (_k >= 0 && _k < array_length(_script)) {
            var _id = _script[_k];
            mer_progress_grant(prog, 4);
            view.selected = _id;
            if (mer_progress_unlock(tree, prog, _id) == MER_UNLOCK_OK) {
                view.pulse[variable_struct_get(tree.byId, _id)] = 0;
            }
        }
    }

    mer_view_update(view, tree, prog, -999, -999,
                    TREE_X + TREE_W * 0.5, TREE_Y + TREE_H * 0.5, _fdt);
    exit;
}

var _dt = delta_time / 1000000;   // delta_time is MICROseconds. This conversion is not optional.
_dt = min(_dt, 1 / 20);           // clamp, so an alt-tab does not fling every spring

var _mx = device_mouse_x_to_gui(0);
var _my = device_mouse_y_to_gui(0);

// ---------------------------------------------------------------------------------------------
// Keys
// ---------------------------------------------------------------------------------------------
if (keyboard_check_pressed(vk_right) || keyboard_check_pressed(ord("D"))) {
    page = (page + 1) mod pageCount;  idleFor = 0;
}
if (keyboard_check_pressed(vk_left) || keyboard_check_pressed(ord("A"))) {
    page = (page + pageCount - 1) mod pageCount;  idleFor = 0;
}
if (keyboard_check_pressed(ord("T"))) {
    themeIndex = (themeIndex + 1) mod mer_theme_count();
    mer_theme_set(mer_theme_by_index(themeIndex));
    idleFor = 0;
}
if (keyboard_check_pressed(ord("L"))) {
    layoutIndex = (layoutIndex + 1) mod mer_layout_count();
    mer_layout_apply(layoutIndex, tree);
    mer_view_frame_all(view, tree, TREE_W, TREE_H, 44);
    idleFor = 0;
}
if (keyboard_check_pressed(ord("R"))) {
    mer_progress_respec(tree, prog);  idleFor = 0;
}
if (keyboard_check_pressed(vk_space)) {
    view.revealAt = 0;  idleFor = 0;   // replay the staggered entrance
}
// F opens ARMATURE, the authoring layer, in its own room.
//
// ⚠️ A SEPARATE ROOM RATHER THAN A SIXTH PAGE, and the reason is the key map. This demo already
// binds A and D to page navigation and the arrow keys to the same, while the editor needs A for
// "add node" and the arrows for the inspector. Two screens with two vocabularies do not belong in
// one input handler; one of them ends up quietly shadowing the other, and the shadowed binding is
// the kind of defect nobody finds because everything still appears to work.
if (keyboard_check_pressed(ord("F"))) room_goto(rm_mer_forge);

// ---------------------------------------------------------------------------------------------
// Pointer
// ---------------------------------------------------------------------------------------------
if (page == 0) {
    mer_view_update(view, tree, prog, _mx, _my,
                    TREE_X + TREE_W * 0.5, TREE_Y + TREE_H * 0.5, _dt);

    if (mouse_check_button_pressed(mb_left) && _mx < PANEL_X) {
        mer_view_click(view, tree, prog, true);
        idleFor = 0;
    }
    if (mouse_check_button_pressed(mb_right) && view.hoveredId != "") {
        mer_progress_refund(tree, prog, view.hoveredId);
        idleFor = 0;
    }
    if (mouse_wheel_up())   { view.zoom.target = clamp(view.zoom.target * 1.12, 0.35, 2.0); idleFor = 0; }
    if (mouse_wheel_down()) { view.zoom.target = clamp(view.zoom.target / 1.12, 0.35, 2.0); idleFor = 0; }

    // Drag to pan. The delta is divided by zoom so a drag moves the tree with the pointer at any
    // zoom level rather than accelerating as you zoom in.
    if (mouse_check_button_pressed(mb_middle)
     || (mouse_check_button_pressed(mb_left) && view.hoveredId == "" && _mx < PANEL_X)) {
        view.dragging = true;  view.dragX = _mx;  view.dragY = _my;
    }
    if (!mouse_check_button(mb_left) && !mouse_check_button(mb_middle)) view.dragging = false;
    if (view.dragging) {
        var _z = max(view.zoom.value, 0.01);
        view.panX.target += (_mx - view.dragX) / _z;
        view.panY.target += (_my - view.dragY) / _z;
        view.dragX = _mx;  view.dragY = _my;
        idleFor = 0;
    }
} else {
    // Off the tree page the view still needs its clock advanced, or the pulses and the starfield
    // freeze and returning to page 0 shows a stalled scene for one frame.
    mer_view_update(view, tree, prog, -999, -999,
                    TREE_X + TREE_W * 0.5, TREE_Y + TREE_H * 0.5, _dt);
}

if (mouse_check_button_pressed(mb_any) || keyboard_check_pressed(vk_anykey)) idleFor = 0;
idleFor += _dt;

// ---------------------------------------------------------------------------------------------
// SCAFFOLDING — the self-drive. DELETE THIS BLOCK FOR YOUR GAME.
//
// After eight seconds with no input the demo starts operating itself, so an unattended screen
// recording has something to record. It hovers a node, buys it, moves on, and eventually respecs
// and starts again. A skill tree that buys its own skills is obviously not what you want shipped
// inside a game, which is exactly why this is fenced off and labelled.
// ---------------------------------------------------------------------------------------------
if (idleFor > 8 && page == 0 && !still) {
    driveAt += _dt;
    if (driveAt > 1.15) {
        driveAt = 0;
        var _order = ["bl_e", "ar_c", "vi_b", "sh_a", "fl_b", "fo_a", "bl_key",
                      "vi_c", "ar_d", "sh_c", "fo_c", "fl_c"];
        if (driveStep >= array_length(_order)) {
            mer_progress_respec(tree, prog);
            mer_progress_grant(prog, 0);
            for (var _i = 0; _i < 12; _i++) {
                mer_progress_unlock(tree, prog, ["bl_root", "ar_root", "vi_root", "sh_root",
                                                 "fl_root", "fo_root", "bl_a", "ar_a", "vi_a",
                                                 "sh_b", "fl_a", "fo_b"][_i]);
            }
            driveStep = 0;
            view.revealAt = 0;
        } else {
            var _id = _order[driveStep++];
            view.selected = _id;
            view.hoveredId = _id;
            mer_progress_grant(prog, 4);
            if (mer_progress_unlock(tree, prog, _id) == MER_UNLOCK_OK) {
                var _idx = variable_struct_get(tree.byId, _id);
                view.pulse[_idx] = 0;
            }
            mer_view_focus(view, tree, _id);
        }
    }
}
