/// @file    obj_mer_demo / Draw GUI
/// @package Meridian for GameMaker
///
/// @summary The five demo pages.
///
/// @remarks Drawn in the GUI event rather than the world event so the interface is in screen
///          pixels regardless of the room's camera. That is what you want for a progression
///          screen: it should not zoom with the game world behind it.

var _t = mer_theme_get();
var _W = display_get_gui_width();
var _H = display_get_gui_height();

mer_draw_backdrop(0, 0, _W, _H);

// ---------------------------------------------------------------------------------------------
// Header, shared by every page
// ---------------------------------------------------------------------------------------------
var _titles = ["THE TREE", "EVERY MARK, DRAWN NOT LOADED", "ONE GRAPH, FOUR LAYOUTS",
               "STATES, TIERS AND SCALE", "EIGHT DISCIPLINES"];

mer_draw_text(40, 26, "MERIDIAN", 21, _t.text, 1);
var _tw = mer_text_width("MERIDIAN", 21);
mer_draw_text(40 + _tw + 16, 32, _titles[page], 11, _t.accent, 0.95);

mer_draw_text_right(_W - 40, 30, "PAGE " + string(page + 1) + " / " + string(pageCount),
                    10, _t.textDim, 0.85);

draw_set_alpha(0.30);
draw_set_colour(_t.edge);
draw_line(40, 58, _W - 40, 58);
draw_set_alpha(1);

// ---------------------------------------------------------------------------------------------
switch (page) {

// =============================================================================================
// PAGE 0 — the tree itself
// =============================================================================================
case 0: {
    // The tree region is clipped by drawing the panel chrome over it afterwards rather than by a
    // scissor rect: GameMaker's clipping is a camera-level concern and this is a GUI-space draw.
    mer_view_draw(view, tree, prog, TREE_X, TREE_Y, TREE_W, TREE_H, true);

    // Mask the strip behind the detail panel so nodes panned off the right edge do not slide
    // under it and reappear at the wrong depth.
    draw_set_colour(_t.backdrop);
    draw_set_alpha(1);
    draw_rectangle(PANEL_X - 14, TREE_Y - 4, _W, _H, false);

    mer_view_draw_detail(view, tree, prog, PANEL_X, PANEL_Y, PANEL_W, PANEL_H);

    // --- points readout, bottom left of the tree region -------------------------------------
    var _pc = mer_progress_purchased_count(tree, prog);
    var _bx = 40, _by = _H - 104;
    mer_draw_round_rect(_bx, _by, 268, 40, 8, _t.surface, 0.9);
    mer_draw_round_rect_outline(_bx, _by, 268, 40, 8, _t.edge, 0.5, 1);
    mer_draw_text(_bx + 16, _by + 13, "POINTS", 10, _t.textDim, 0.9);
    mer_draw_text(_bx + 84, _by + 10, string(prog.points), 15, _t.accent, 1);
    mer_draw_text(_bx + 130, _by + 13, "SPENT", 10, _t.textDim, 0.9);
    mer_draw_text(_bx + 188, _by + 10, string(_pc.ranks), 15, _t.text, 1);

    mer_draw_text(324, _H - 54, string(mer_tree_count(tree)) + " NODES  /  "
                + mer_layout_name(layoutIndex) + "  /  " + mer_theme_name(themeIndex),
                  10, _t.textDim, 0.7);
    break;
}

// =============================================================================================
// PAGE 1 — the sigil catalogue. The "how much is in here" page.
// =============================================================================================
case 1: {
    var _n = mer_sigil_count();
    var _cols = 10;
    var _rows = ceil(_n / _cols);
    var _m = 46;
    var _cw = (_W - _m * 2) / _cols;
    var _top = 104;
    var _rh = 92;

    mer_draw_text(40, 76, string(_n) + " MOTIFS  x  " + string(mer_discipline_count())
                + " DISCIPLINES  =  " + string(mer_sigil_variant_count())
                + " MARKS, AND NOT ONE PNG", 10, _t.textDim, 0.85);

    for (var _i = 0; _i < _n; _i++) {
        var _cx = _m + (_i mod _cols) * _cw + _cw * 0.5;
        var _cy = _top + (_i div _cols) * _rh + 30;
        mer_sigil_draw(_i, _cx, _cy, 58, undefined, 1, 1, 0);
        mer_draw_text_centred(_cx, _cy + 34, mer_sigil_name(_i), 7, _t.textDim, 0.8);
    }
    break;
}

// =============================================================================================
// PAGE 2 — one graph, four layouts. A claim a still photograph can actually prove.
// =============================================================================================
case 2: {
    // The node count is READ FROM THE TREE, never typed. A sibling product shipped a header
    // claiming sixty-four forms over a table holding seventy-five; the fix is to never write the
    // number down anywhere a human has to keep in sync.
    mer_draw_text(40, 76, "THE SAME " + string(mer_tree_count(tree)) + "-NODE GRAPH. "
                + "NO POSITION IS TYPED IN ANYWHERE. EVERY ONE IS DERIVED FROM WHAT DEPENDS ON WHAT.",
                  10, _t.textDim, 0.85);

    var _qw = (_W - 100) / 2, _qh = (_H - 200) / 2;
    var _saveLayout = layoutIndex;

    for (var _q = 0; _q < 4; _q++) {
        var _ox = 40 + (_q mod 2) * (_qw + 20);
        var _oy = 108 + (_q div 2) * (_qh + 30);

        mer_draw_round_rect(_ox, _oy, _qw, _qh, 10, _t.surface, 0.5);
        mer_draw_round_rect_outline(_ox, _oy, _qw, _qh, 10, _t.edge, 0.4, 1);
        mer_draw_text(_ox + 14, _oy + 12, mer_layout_name(_q), 10, _t.accent, 0.95);

        mer_layout_apply(_q, tree);
        var _b = mer_tree_bounds(tree);
        var _pad = 34;
        var _sc = min((_qw - _pad * 2) / max(_b.w, 1), (_qh - _pad * 2 - 18) / max(_b.h, 1));
        _sc = min(_sc, 0.42);
        var _mx2 = _ox + _qw * 0.5, _my2 = _oy + _qh * 0.5 + 9;

        // Links first, then nodes — same ordering rule as the real view.
        var _nodes = tree.nodes, _nn = array_length(_nodes);
        for (var _i = 0; _i < _nn; _i++) {
            var _nd = _nodes[_i];
            var _ax = _mx2 + (_nd.lx - _b.cx) * _sc, _ay = _my2 + (_nd.ly - _b.cy) * _sc;
            for (var _r = 0; _r < array_length(_nd.requires); _r++) {
                var _pn = mer_tree_get(tree, _nd.requires[_r]);
                if (is_undefined(_pn)) continue;
                var _px = _mx2 + (_pn.lx - _b.cx) * _sc, _py = _my2 + (_pn.ly - _b.cy) * _sc;
                var _own = (mer_progress_rank(prog, _nd.id) > 0
                         && mer_progress_rank(prog, _pn.id) > 0);
                draw_set_colour(_own ? mer_discipline_palette(_nd.disc)[MER_ROLE_LIMB] : _t.edge);
                draw_set_alpha(_own ? 0.85 : 0.30);
                draw_line_width(_px, _py, _ax, _ay, _own ? 2 : 1);
            }
        }
        for (var _i = 0; _i < _nn; _i++) {
            var _nd = _nodes[_i];
            var _ax = _mx2 + (_nd.lx - _b.cx) * _sc, _ay = _my2 + (_nd.ly - _b.cy) * _sc;
            var _pal = mer_discipline_palette(_nd.disc);
            var _own = mer_progress_rank(prog, _nd.id) > 0;
            var _rr = (_nd.tier == MER_TIER_KEYSTONE) ? 8 : (_nd.tier == MER_TIER_MAJOR ? 6 : 4.2);
            if (_own) {
                draw_set_colour(_pal[MER_ROLE_LIMB]);
                for (var _g = 3; _g >= 1; _g--) {
                    draw_set_alpha(0.10 * (4 - _g));
                    draw_circle(_ax, _ay, _rr + _g * 2.4, false);
                }
            }
            draw_set_colour(_own ? _pal[MER_ROLE_CORE] : _t.surfaceLo);
            draw_set_alpha(_own ? 1 : 0.75);
            draw_circle(_ax, _ay, _rr, false);
        }
        draw_set_alpha(1);
    }

    mer_layout_apply(_saveLayout, tree);   // restore what the tree page is using
    break;
}

// =============================================================================================
// PAGE 3 — states, tiers, and the resolution-independence proof
// =============================================================================================
case 3: {
    var _demoSig = mer_sigil_find("NEXUS");
    var _pal = mer_discipline_palette(1);

    // --- states ------------------------------------------------------------------------------
    mer_draw_text(40, 78, "FOUR STATES, AND EACH ONE MEANS SOMETHING DIFFERENT", 11, _t.accent, 0.95);
    var _labels = ["LOCKED", "AVAILABLE", "RANK 2 OF 3", "MASTERED"];
    var _notes  = ["prerequisites unmet", "reachable, breathing", "partly invested", "fully invested"];
    var _drains = [0.85, 0.35, 0, 0];
    var _blooms = [0.3, 0.7, 1, 1.25];
    var _ranks  = [0, 0, 2, 3];

    for (var _i = 0; _i < 4; _i++) {
        var _cx = 150 + _i * 250;
        var _cy = 176;
        var _r = 40;

        if (_i >= 1) {
            draw_set_colour(_pal[MER_ROLE_LIMB]);
            for (var _g = 5; _g >= 1; _g--) {
                draw_set_alpha((_i == 1 ? 0.26 : 0.5) * 0.075 * (6 - _g) / 5);
                draw_circle(_cx, _cy, _r + _g * 3.6, false);
            }
        }
        draw_set_colour(_i >= 2 ? mer_colour_mix(_t.surface, _pal[MER_ROLE_HALO], 0.35) : _t.surface);
        draw_set_alpha(0.96);
        draw_circle(_cx, _cy, _r, false);
        draw_set_colour(_i >= 2 ? _pal[MER_ROLE_CORE] : (_i == 1 ? _t.edge : _t.surfaceLo));
        draw_set_alpha(_i >= 2 ? 0.98 : (_i == 1 ? 0.8 : 0.5));
        mer_draw_ngon_outline(_cx, _cy, _r * 1.06, 6, 90, 2.4);
        draw_set_alpha(1);

        mer_sigil_draw(_demoSig, _cx, _cy, _r * 1.28, 1, 1, _blooms[_i], _drains[_i]);

        for (var _k = 0; _k < 3; _k++) {
            var _pa = 90 + (_k - 1) * 37;
            var _on = (_k < _ranks[_i]);
            draw_set_colour(_on ? _pal[MER_ROLE_SPARK] : _t.track);
            draw_set_alpha(_on ? 1 : 0.55);
            draw_circle(_cx + lengthdir_x(_r * 1.26, _pa), _cy + lengthdir_y(_r * 1.26, _pa),
                        _on ? 3.4 : 2.4, false);
        }
        draw_set_alpha(1);

        mer_draw_text_centred(_cx, _cy + 62, _labels[_i], 10, _t.text, 0.95);
        mer_draw_text_centred(_cx, _cy + 78, _notes[_i], 8, _t.textDim, 0.75);
    }

    // --- tiers ---------------------------------------------------------------------------------
    mer_draw_text(40, 286, "THREE TIERS, DRAWN DIFFERENTLY", 11, _t.accent, 0.95);
    var _tierName = ["MINOR", "MAJOR", "KEYSTONE"];
    var _tierR = [MER_NODE_R_MINOR, MER_NODE_R_MAJOR, MER_NODE_R_KEYSTONE];
    var _tierSig = [mer_sigil_find("CINDER"), mer_sigil_find("WARD"), mer_sigil_find("GEAR")];

    for (var _i = 0; _i < 3; _i++) {
        var _cx = 150 + _i * 210;
        var _cy = 386;
        var _r = _tierR[_i];
        var _p2 = mer_discipline_palette(_i == 0 ? 4 : (_i == 1 ? 1 : 7));

        draw_set_colour(_p2[MER_ROLE_LIMB]);
        for (var _g = 5; _g >= 1; _g--) {
            draw_set_alpha(0.5 * 0.075 * (6 - _g) / 5);
            draw_circle(_cx, _cy, _r + _g * 3.4, false);
        }
        draw_set_colour(mer_colour_mix(_t.surface, _p2[MER_ROLE_HALO], 0.35));
        draw_set_alpha(0.96);
        draw_circle(_cx, _cy, _r, false);
        draw_set_colour(_p2[MER_ROLE_CORE]);
        draw_set_alpha(0.98);

        if (_i == 0) {
            mer_draw_ring(_cx, _cy, _r, 2.4);
        } else {
            mer_draw_ngon_outline(_cx, _cy, _r * 1.06, _i == 2 ? 8 : 6, 90, 2.6);
            if (_i == 2) {
                mer_draw_ring(_cx, _cy, _r * 1.30, 1.4);
                for (var _s = 0; _s < 8; _s++) {
                    var _sa = _s * 45;
                    draw_line_width(_cx + lengthdir_x(_r * 1.10, _sa), _cy + lengthdir_y(_r * 1.10, _sa),
                                    _cx + lengthdir_x(_r * 1.26, _sa), _cy + lengthdir_y(_r * 1.26, _sa), 1.4);
                }
            }
        }
        draw_set_alpha(1);
        mer_sigil_draw(_tierSig[_i], _cx, _cy, _r * 1.28, _i == 0 ? 4 : (_i == 1 ? 1 : 7), 1, 1, 0);
        mer_draw_text_centred(_cx, _cy + _r + 22, _tierName[_i], 10, _t.text, 0.95);
    }

    // --- scale strip ------------------------------------------------------------------------
    mer_draw_text(700, 286, "ONE DEFINITION, EVERY SIZE", 11, _t.accent, 0.95);
    var _sizes = [26, 40, 60, 86, 122];
    var _sx = 700;
    for (var _i = 0; _i < 5; _i++) {
        var _sz = _sizes[_i];
        mer_sigil_draw(mer_sigil_find("FROST"), _sx + _sz * 0.5, 400, _sz, 5, 1, 1, 0);
        mer_draw_text_centred(_sx + _sz * 0.5, 470, string(_sz) + "PX", 8, _t.textDim, 0.75);
        _sx += _sz + 26;
    }

    // --- what the same code does with a stroke weight -----------------------------------------
    mer_draw_text(40, 508, "THE SAME MARK UNDER EVERY SHIPPED PALETTE", 11, _t.accent, 0.95);
    for (var _i = 0; _i < mer_discipline_count(); _i++) {
        var _cx = 92 + _i * 148;
        mer_sigil_draw(mer_sigil_find("HEXGRAM"), _cx, 588, 74, _i, 1, 1, 0);
        mer_draw_text_centred(_cx, 634, mer_discipline_name(_i), 8, _t.textDim, 0.8);
    }
    break;
}

// =============================================================================================
// PAGE 4 — the disciplines
// =============================================================================================
case 4: {
    mer_draw_text(40, 76, "A DISCIPLINE IS A FOUR-COLOUR PALETTE. THE GEOMETRY NEVER CHANGES. "
                + "WHICH BRANCH YOU HANG A NODE ON DOES.", 10, _t.textDim, 0.85);

    var _dc = mer_discipline_count();
    var _cw = (_W - 80) / _dc;
    var _members = [
        ["CLEAVE", "GUARD", "EXECUTE"],
        ["FOCUS",  "SEAL",  "NEXUS"],
        ["HEART",  "BLOOM", "RENEW"],
        ["VEIL",   "VENOM", "SHROUD"],
        ["FLAME",  "PYRE",  "BLAST"],
        ["FROST",  "SHARD", "RIME"],
        ["BOLT",   "GALE",  "CYCLONE"],
        ["GEAR",   "ANVIL", "PISTON"],
    ];

    for (var _d = 0; _d < _dc; _d++) {
        var _cx = 40 + _d * _cw + _cw * 0.5;
        var _pal = mer_discipline_palette(_d);

        // Column plate, tinted by the discipline so the eight read as eight.
        mer_draw_round_rect(_cx - _cw * 0.44, 112, _cw * 0.88, 512, 10,
                            mer_colour_mix(_t.surface, _pal[MER_ROLE_HALO], 0.22), 0.55);
        draw_set_colour(_pal[MER_ROLE_LIMB]);
        draw_set_alpha(0.5);
        draw_line_width(_cx - _cw * 0.30, 114, _cx + _cw * 0.30, 114, 2);
        draw_set_alpha(1);

        mer_draw_text_centred(_cx, 132, mer_discipline_name(_d), 11, _pal[MER_ROLE_CORE], 1);

        for (var _k = 0; _k < 3; _k++) {
            var _idx = mer_sigil_find(_members[_d][_k]);
            if (_idx < 0) continue;
            var _cy = 214 + _k * 132;
            mer_sigil_draw(_idx, _cx, _cy, 86, _d, 1, 1.05, 0);
            mer_draw_text_centred(_cx, _cy + 52, mer_sigil_name(_idx), 8, _t.textDim, 0.82);
        }

        // Palette swatch strip at the foot of the column.
        for (var _s = 0; _s < 4; _s++) {
            draw_set_colour(_pal[_s]);
            draw_set_alpha(0.95);
            draw_rectangle(_cx - 34 + _s * 18, 592, _cx - 34 + _s * 18 + 14, 606, false);
        }
        draw_set_alpha(1);
    }
    break;
}

}

// ---------------------------------------------------------------------------------------------
// Footer, shared. Kept to one line and measured, because two runs of text drawn from opposite
// sides of the same baseline is exactly how a sibling product printed one string through another.
// ---------------------------------------------------------------------------------------------
draw_set_alpha(0.30);
draw_set_colour(_t.edge);
draw_line(40, _H - 30, _W - 40, _H - 30);
draw_set_alpha(1);

var _left  = (page == 0) ? "LEFT-CLICK BUY   RIGHT-CLICK REFUND   DRAG PAN   WHEEL ZOOM"
                         : "ARROWS PAGE   T THEME   L LAYOUT   R RESPEC";
mer_draw_text(40, _H - 22, _left, 8, _t.textDim, 0.7);
mer_draw_text_right(_W - 40, _H - 22, "MERIDIAN  /  PROCEDURAL SKILL TREES FOR GAMEMAKER",
                    8, _t.textDim, 0.55);

// ---------------------------------------------------------------------------------------------
// SCAFFOLDING - FILMSTRIP OUTPUT. DELETE THIS BLOCK FOR YOUR GAME.
//
// screen_save writes the composited frame from INSIDE the engine, so it needs no window focus and
// no screen grabber. Files land in the sandboxed save area, %LOCALAPPDATA%\Meridian\.
// ---------------------------------------------------------------------------------------------
if (filmTotal > 0) {
    screen_save("mer_frame_" + string_replace_all(string_format(filmIndex, 4, 0), " ", "0") + ".png");
    filmIndex++;
    if (filmIndex >= filmTotal) game_end();
}
