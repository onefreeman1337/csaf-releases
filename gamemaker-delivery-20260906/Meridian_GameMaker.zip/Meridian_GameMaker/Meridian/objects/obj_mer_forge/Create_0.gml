/// @file    obj_mer_forge / Create
/// @package Meridian for GameMaker — ARMATURE
///
/// @summary Opens an authoring session on a starter tree.
///
/// @remarks WHY THE EDITOR OPENS ON A TREE RATHER THAN ON NOTHING. An empty canvas is the worst
///          first screen an authoring tool can show: there is no gesture to imitate, nothing
///          demonstrates what a finished thing looks like, and the first click has to be explained
///          in words. Six nodes across three disciplines is enough to show the shape of an answer
///          and small enough to delete in six keystrokes.
///
///          Press N for a genuinely empty tree once you have seen how it works.

randomise();

layoutIndex = 0;
themeIndex  = 0;
mer_theme_set(mer_theme_by_index(themeIndex));

tree = mer_forge_starter_tree();
mer_layout_apply(layoutIndex, tree);

forge = mer_forge_make(tree);
forge.selected = "root";
forge.layout = layoutIndex;

// The canvas takes the left, the inspector the right, matching the demo room's proportions so the
// two rooms' screenshots sit together in one gallery.
CANVAS_X = 0;
CANVAS_Y = 56;
CANVAS_W = 946;
CANVAS_H = 608;
PANEL_X  = 962;
PANEL_Y  = 68;
PANEL_W  = 300;
PANEL_H  = 584;

mer_view_frame_all(forge.view, tree, CANVAS_W, CANVAS_H - MER_FORGE_STRIP_H, 60);

// Deterministic capture, the same way obj_mer_demo does it: an unfocused GameMaker window stops
// repainting, so synthetic keystrokes produce identical screenshots taken seconds apart. Driving by
// argument removes focus from the problem entirely.
still     = false;
shotMode  = 0;      // 0 the editor, 1 mid-link, 2 the export overlay, 3 the motif browser
for (var _i = 0; _i < parameter_count(); _i++) {
    var _p = parameter_string(_i);
    if (string_copy(_p, 1, 7) == "--shot=")  shotMode   = real(string_delete(_p, 1, 7));
    // ⚠️ Sets the INDEX and then applies it, rather than applying a theme the index does not know
    // about. Setting only the theme leaves themeIndex at 0, so the first press of T in a captured
    // session jumps back to the theme before the one on screen.
    if (string_copy(_p, 1, 8) == "--theme=") themeIndex = real(string_delete(_p, 1, 8));
    if (_p == "--still")                     still      = true;
}

themeIndex = clamp(themeIndex, 0, mer_theme_count() - 1);
mer_theme_set(mer_theme_by_index(themeIndex));

mer_forge_say(forge, "ARMATURE READY - " + string(mer_tree_count(tree)) + " NODES");

// SCAFFOLDING — BAKE MODE. DELETE THIS BLOCK FOR YOUR GAME.
//
// `--bake` walks every capture pose and writes one PNG each with screen_save, from INSIDE the
// engine, then exits. screen_save needs no window focus and no screen grabber, which is the whole
// reason it is used: an unfocused GameMaker window STOPS REPAINTING, so a gdigrab of this window
// returns the same frame over and over, and an occluded one returns whatever is drawn on top of it.
// Both of those have produced store images in this factory before.
bakeMode  = false;
bakeIndex = 0;
bakeWait  = 0;
filmTotal = 0;      // > 0 runs the scripted authoring session and writes one PNG per frame
filmIndex = 0;
for (var _i = 0; _i < parameter_count(); _i++) {
    var _q = parameter_string(_i);
    if (_q == "--bake") bakeMode = true;
    if (string_copy(_q, 1, 7) == "--film=") filmTotal = real(string_delete(_q, 1, 7));
}

mer_forge_pose(forge, tree, shotMode, CANVAS_X + CANVAS_W * 0.5, CANVAS_Y + CANVAS_H * 0.5);
if (bakeMode) mer_forge_pose(forge, tree, 0, CANVAS_X + CANVAS_W * 0.5, CANVAS_Y + CANVAS_H * 0.5);

// A still needs the springs settled and the reveal finished, or the shutter catches a
// half-assembled tree. Advancing the clock in fixed steps is the deterministic way; waiting on wall
// time is not reproducible.
if (still) {
    forge.view.revealAt = 4;
    for (var _i = 0; _i < 240; _i++) {
        mer_forge_update(forge, tree, -999, -999,
                         CANVAS_X + CANVAS_W * 0.5, CANVAS_Y + CANVAS_H * 0.5, 1 / 60);
    }
    forge.view.time = 3.1;
    forge.messageAt = 0;
}
