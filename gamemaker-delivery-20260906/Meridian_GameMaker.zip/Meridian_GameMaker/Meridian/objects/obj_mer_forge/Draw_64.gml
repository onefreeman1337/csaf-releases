/// @file    obj_mer_forge / Draw GUI
/// @package Meridian for GameMaker — ARMATURE
///
/// @summary Draws the authoring screen: title strip, canvas, inspector, status line.
///
/// @remarks Draw GUI rather than Draw, so the layout is in GUI coordinates and is immune to the
///          room camera. Mixing the two is how a UI ends up at a different scale from the thing it
///          annotates.

var _t = mer_theme_get();
var _gw = display_get_gui_width();
var _gh = display_get_gui_height();

mer_draw_backdrop(0, 0, _gw, _gh);

// ---------------------------------------------------------------------------------------------
// Title strip
// ---------------------------------------------------------------------------------------------
mer_draw_text(28, 20, "ARMATURE", 15, _t.accent, 1);
mer_draw_text(28 + mer_text_width("ARMATURE", 15) + 16, 26,
              "MERIDIAN'S AUTHORING LAYER", 8, _t.textDim, 1);

var _counts = string(mer_tree_count(tree)) + " NODES   " +
              mer_layout_name(forge.layout) + "   " +
              string(mer_sigil_count()) + "x" + string(mer_discipline_count()) + " = " +
              string(mer_sigil_variant_count()) + " MARKS";
mer_draw_text_right(_gw - 28, 26, _counts, 8, _t.textDim, 1);

mer_draw_round_rect(28, 48, _gw - 56, 1, 0, _t.edge, _t.edgeAlpha);

// ---------------------------------------------------------------------------------------------
// Canvas and inspector
// ---------------------------------------------------------------------------------------------
mer_forge_draw(forge, tree, CANVAS_X, CANVAS_Y, CANVAS_W, CANVAS_H);
mer_forge_draw_inspector(forge, tree, PANEL_X, PANEL_Y, PANEL_W, PANEL_H);

// ---------------------------------------------------------------------------------------------
// Status line. Fades rather than vanishing: a message that disappears between frames reads as a
// glitch, and one that never leaves becomes furniture the eye stops seeing.
// ---------------------------------------------------------------------------------------------
if (forge.message != "") {
    var _a = 1 - clamp((forge.messageAt - 2.4) / 0.8, 0, 1);
    if (_a > 0) {
        var _w = mer_text_width(forge.message, 9) + 34;
        var _x = CANVAS_X + 26;
        var _y = CANVAS_Y + CANVAS_H - 44;
        mer_draw_round_rect(_x, _y, _w, 28, _t.radiusSmall, _t.surface, 0.92 * _a);
        mer_draw_round_rect_outline(_x, _y, _w, 28, _t.radiusSmall, _t.edge, _t.edgeAlpha * _a, 1);
        mer_draw_text(_x + 17, _y + 9, forge.message, 9, _t.accentAlt, _a);
    }
}

// ---------------------------------------------------------------------------------------------
// The export overlay draws last, over everything, because it is modal.
// ---------------------------------------------------------------------------------------------
if (forge.mode == MER_FORGE_MODE_EXPORT) {
    mer_forge_draw_export(forge, 0, 0, _gw, _gh);
}

// ---------------------------------------------------------------------------------------------
// SCAFFOLDING — BAKE OUTPUT. DELETE THIS BLOCK FOR YOUR GAME.
//
// One PNG per pose, written from inside the engine after the springs have had time to settle.
// ⚠️ THE SAVE HAPPENS AT THE END OF Draw GUI, so what lands in the file is the frame that was just
// composited. Saving from Step would capture the PREVIOUS frame, which is how a capture ends up
// one pose behind its own filename — the pose is set, the picture is of the pose before it, and
// every file looks plausible.
// ---------------------------------------------------------------------------------------------
if (filmTotal > 0) {
    screen_save("mer_film_" + string_replace_all(string_format(filmIndex, 4, 0), " ", "0") + ".png");
    filmIndex += 1;
    if (filmIndex >= filmTotal) game_end();
}

if (bakeMode) {
    if (bakeWait >= 90) {
        screen_save("mer_forge_" + string(bakeIndex) + "_" + mer_forge_pose_name(bakeIndex) + ".png");
        bakeIndex += 1;
        bakeWait = 0;
        if (bakeIndex >= mer_forge_pose_count()) {
            game_end();
        } else {
            // Theme rotates on the last pose so the gallery shows the palette layer doing its job
            // rather than six pictures of one colour scheme.
            if (bakeIndex == 5) {
                themeIndex = 2;
                mer_theme_set(mer_theme_by_index(themeIndex));
            }
            mer_forge_pose(forge, tree, bakeIndex,
                           CANVAS_X + CANVAS_W * 0.5, CANVAS_Y + CANVAS_H * 0.5);
            mer_view_frame_all(forge.view, tree, CANVAS_W, CANVAS_H - MER_FORGE_STRIP_H, 60);
        }
    }
}
