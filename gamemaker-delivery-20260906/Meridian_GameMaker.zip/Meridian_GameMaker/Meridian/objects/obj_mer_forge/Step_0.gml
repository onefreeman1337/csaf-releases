/// @file    obj_mer_forge / Step
/// @package Meridian for GameMaker — ARMATURE
///
/// @summary Editor input.
///
/// @remarks THE GESTURE SET IS DELIBERATELY FOUR THINGS. Click selects, drag between two nodes
///          toggles a prerequisite, A adds a child of the selection, DEL removes. Everything else is
///          a field step. An authoring tool for a package this size earns nothing by having modes.
///
///          ⛔ NOTE WHAT DRAGGING DOES **NOT** DO: it never moves a node. Positions in Meridian are
///          DERIVED from the prerequisite graph, and an editor that let you drag nodes to x,y would
///          be quietly abolishing the one claim the package is built on. Dragging draws an EDGE.

// ---------------------------------------------------------------------------------------------
// SCAFFOLDING — BAKE MODE. DELETE THIS BLOCK FOR YOUR GAME.
//
// Steps the springs at a FIXED timestep so every pose is captured with the layout settled, then
// hands over to Draw GUI, which does the saving. Fixed rather than real time because a capture that
// depends on frame pacing is a capture that differs between runs.
// ---------------------------------------------------------------------------------------------
if (filmTotal > 0) {
    // ⚠️ THE SCRIPT RUNS BEFORE THE UPDATE, so an action taken on this frame is already reflected in
    // the springs the update then advances. Running it after would show every act one frame late,
    // which reads as input lag in the finished GIF.
    var _act = mer_forge_film_step(forge, tree, filmIndex, filmTotal,
                                   CANVAS_X + CANVAS_W * 0.5, CANVAS_Y + CANVAS_H * 0.5);
    // ⚠️ RE-FRAME WHENEVER THE GRAPH GROWS OR THE SHAPE CHANGES. Adding a node makes the tree
    // bigger, and without this the new node lands half off the bottom of the canvas — which the
    // baked frame showed and no assertion did. The springs make the re-frame a glide rather than a
    // jump, so it reads as the view following the work.
    if (_act == "add" || _act == "link" || _act == "layout") {
        mer_view_frame_all(forge.view, tree, CANVAS_W, CANVAS_H - MER_FORGE_STRIP_H, 70);
    }
    mer_forge_update(forge, tree, -999, -999,
                     CANVAS_X + CANVAS_W * 0.5, CANVAS_Y + CANVAS_H * 0.5, 1 / 12);
    exit;
}

if (bakeMode) {
    mer_forge_update(forge, tree, -999, -999,
                     CANVAS_X + CANVAS_W * 0.5, CANVAS_Y + CANVAS_H * 0.5, 1 / 60);
    bakeWait += 1;
    exit;
}

if (still) exit;   // a still capture freezes the frame the Create event already settled

var _dt = delta_time / 1000000;   // delta_time is MICROseconds. This conversion is not optional.
_dt = min(_dt, 1 / 20);           // clamp, so an alt-tab does not fling every spring

var _mx = device_mouse_x_to_gui(0);
var _my = device_mouse_y_to_gui(0);
var _cx = CANVAS_X + CANVAS_W * 0.5;
var _cy = CANVAS_Y + CANVAS_H * 0.5;

mer_forge_update(forge, tree, _mx, _my, _cx, _cy, _dt);

// ---------------------------------------------------------------------------------------------
// The export overlay swallows input while it is up, so a keystroke meant for the reader cannot
// edit the tree behind it. A modal that does not capture its keys is how a "harmless" glance at
// the output ends up renumbering a node.
// ---------------------------------------------------------------------------------------------
if (forge.mode == MER_FORGE_MODE_EXPORT) {
    if (keyboard_check_pressed(vk_escape) || keyboard_check_pressed(ord("E"))) {
        forge.mode = MER_FORGE_MODE_SELECT;
    }
    if (keyboard_check_pressed(vk_down) || mouse_wheel_down()) forge.exportLine += 3;
    if (keyboard_check_pressed(vk_up)   || mouse_wheel_up())   forge.exportLine -= 3;
    forge.exportLine = max(0, forge.exportLine);
    exit;
}

// ---------------------------------------------------------------------------------------------
// Pointer: click to select, drag from one node to another to toggle a prerequisite.
// ---------------------------------------------------------------------------------------------
var _over = mer_forge_hit(forge, tree, _mx, _my, _cx, _cy);

if (mouse_check_button_pressed(mb_left)) {
    if (_over != "") {
        forge.selected = _over;
        forge.linkFrom = _over;      // a drag may be starting; a plain click ends it harmlessly
    } else if (_mx < PANEL_X) {
        forge.view.dragging = true;
        forge.view.dragX = _mx;
        forge.view.dragY = _my;
    }
}

if (mouse_check_button_released(mb_left)) {
    if (forge.linkFrom != "" && _over != "" && _over != forge.linkFrom) {
        var _r = mer_forge_toggle_link(tree, forge.linkFrom, _over);
        mer_forge_say(forge, string_upper(_r.reason));
        if (_r.ok) mer_forge_touch(forge, tree);
    }
    forge.linkFrom = "";
    forge.view.dragging = false;
}

if (forge.view.dragging) {
    var _z = max(forge.view.zoom.value, 0.01);
    forge.view.panX.target += (_mx - forge.view.dragX) / _z;
    forge.view.panY.target += (_my - forge.view.dragY) / _z;
    forge.view.dragX = _mx;
    forge.view.dragY = _my;
}

if (mouse_wheel_up())   forge.view.zoom.target = clamp(forge.view.zoom.target * 1.12, 0.35, 2.0);
if (mouse_wheel_down()) forge.view.zoom.target = clamp(forge.view.zoom.target / 1.12, 0.35, 2.0);

// ---------------------------------------------------------------------------------------------
// Graph editing
// ---------------------------------------------------------------------------------------------
if (keyboard_check_pressed(ord("A"))) {
    // A new node is a CHILD of the selection, which is the gesture that matches a graph-first
    // editor: you are always saying "and then this becomes available".
    var _parent = forge.selected;
    var _req = (_parent == "" || is_undefined(mer_tree_get(tree, _parent))) ? [] : [_parent];
    var _seed = (array_length(_req) == 0) ? 0 : mer_tree_get(tree, _parent).disc;
    var _id = mer_forge_add(forge, tree, {
        name: "NEW SKILL", requires: _req, disc: _seed,
        sigil: irandom(mer_sigil_count() - 1), tier: MER_TIER_MINOR,
        cost: 1, maxRank: 1, desc: "Describe what this does."
    });
    mer_forge_say(forge, (_id == "") ? "COULD NOT ADD" : ("ADDED " + string_upper(_id)));
}

if (keyboard_check_pressed(vk_delete) || keyboard_check_pressed(vk_backspace)) {
    if (forge.selected != "") {
        var _swept = mer_forge_remove(tree, forge.selected);
        if (_swept >= 0) {
            mer_forge_say(forge, "DELETED - " + string(_swept) + " LINK(S) SWEPT");
            forge.selected = (mer_tree_count(tree) > 0) ? tree.nodes[0].id : "";
            mer_forge_touch(forge, tree);
        }
    }
}

if (keyboard_check_pressed(ord("N"))) {
    tree = mer_tree_make();
    mer_tree_add(tree, "root", { name: "ROOT", sigil: 0, disc: 0, tier: MER_TIER_MAJOR, cost: 1,
                                 maxRank: 1, requires: [], desc: "The first thing anyone buys." });
    forge.selected = "root";
    mer_forge_touch(forge, tree);
    mer_view_frame_all(forge.view, tree, CANVAS_W, CANVAS_H - MER_FORGE_STRIP_H, 60);
    mer_forge_say(forge, "NEW TREE");
}

// ---------------------------------------------------------------------------------------------
// Inspector: up/down chooses the field, left/right changes its value.
// ---------------------------------------------------------------------------------------------
if (keyboard_check_pressed(vk_down)) forge.field = (forge.field + 1) mod MER_FORGE_FIELD_COUNT;
if (keyboard_check_pressed(vk_up))   forge.field = (forge.field + MER_FORGE_FIELD_COUNT - 1) mod MER_FORGE_FIELD_COUNT;

var _step = 0;
if (keyboard_check_pressed(vk_right)) _step = 1;
if (keyboard_check_pressed(vk_left))  _step = -1;
if (_step != 0 && forge.selected != "") {
    if (mer_forge_step_field(tree, forge.selected, forge.field, _step)) {
        // The tier changes a node's RADIUS, so the layout has to be re-derived or the tree draws
        // with overlapping nodes until something else happens to touch it.
        if (forge.field == MER_FORGE_FIELD_TIER) mer_forge_touch(forge, tree);
        mer_forge_say(forge, mer_forge_field_name(forge.field) + ": " +
                             mer_forge_field_value(tree, forge.selected, forge.field));
    }
}

// ---------------------------------------------------------------------------------------------
// Layout, theme, validation, export
// ---------------------------------------------------------------------------------------------
if (keyboard_check_pressed(ord("L"))) {
    mer_forge_layout_cycle(forge, tree, 1);
    mer_view_frame_all(forge.view, tree, CANVAS_W, CANVAS_H - MER_FORGE_STRIP_H, 60);
}

if (keyboard_check_pressed(ord("T"))) {
    themeIndex = (themeIndex + 1) mod mer_theme_count();
    mer_theme_set(mer_theme_by_index(themeIndex));
    mer_forge_say(forge, "THEME: " + mer_theme_name(themeIndex));
}

if (keyboard_check_pressed(ord("V"))) {
    var _report = mer_forge_validate(tree);
    if (_report.ok) mer_forge_say(forge, "VALID - " + string(_report.nodes) + " NODES, " +
                                         string(_report.roots) + " ROOT(S)");
    else mer_forge_say(forge, string_upper(_report.problems[0].text));
}

if (keyboard_check_pressed(ord("E"))) {
    forge.exportText = mer_forge_export_gml(tree, "build_skill_tree");
    forge.exportLine = 0;
    forge.mode = MER_FORGE_MODE_EXPORT;
}

if (keyboard_check_pressed(vk_escape)) room_goto(rm_mer_demo);
