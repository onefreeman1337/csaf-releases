/// @file    mer_ease.gml
/// @package Meridian for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary Easing curves and the spring integrator that drive every Meridian animation.
///
/// @remarks EVERY FUNCTION IN THIS FILE IS PURE.
///          No engine calls, no globals, no instance variables, no side effects. Given the same
///          arguments each one returns the same result. That is deliberate: GML cannot be unit
///          tested outside the engine, so the next best thing is a core that can be read and
///          reasoned about in isolation without running anything. Keep it that way — if you need
///          to touch a surface or an instance, it belongs in mer_draw or mer_widget, not here.
///
///          All easing functions take normalised time t in [0, 1] and return a normalised
///          position, which is NOT clamped to [0, 1] — the "back" and "elastic" families
///          deliberately overshoot, and that overshoot is the reason the UI reads as alive
///          rather than as a slide transition.

#macro MER_EASE_LINEAR      0
#macro MER_EASE_IN_QUAD     1
#macro MER_EASE_OUT_QUAD    2
#macro MER_EASE_IN_OUT_QUAD 3
#macro MER_EASE_IN_CUBIC    4
#macro MER_EASE_OUT_CUBIC   5
#macro MER_EASE_IN_OUT_CUBIC 6
#macro MER_EASE_OUT_EXPO    7
#macro MER_EASE_IN_OUT_EXPO 8
#macro MER_EASE_OUT_BACK    9
#macro MER_EASE_IN_BACK     10
#macro MER_EASE_OUT_ELASTIC 11
#macro MER_EASE_OUT_BOUNCE  12

/// @func   mer_ease(_t, _curve)
/// @desc   Applies a named easing curve to a normalised time value.
/// @param  {Real} _t      Normalised time, expected in [0, 1]. Values outside are clamped.
/// @param  {Real} _curve  One of the MER_EASE_* macros.
/// @return {Real} Normalised position. May exceed [0, 1] for the back and elastic curves.
/// @pure
function mer_ease(_t, _curve) {
    var _x = clamp(_t, 0, 1);

    switch (_curve) {
        case MER_EASE_LINEAR:
            return _x;

        case MER_EASE_IN_QUAD:
            return _x * _x;

        case MER_EASE_OUT_QUAD:
            return 1 - (1 - _x) * (1 - _x);

        case MER_EASE_IN_OUT_QUAD:
            return (_x < 0.5) ? (2 * _x * _x)
                              : (1 - power(-2 * _x + 2, 2) * 0.5);

        case MER_EASE_IN_CUBIC:
            return _x * _x * _x;

        case MER_EASE_OUT_CUBIC:
            return 1 - power(1 - _x, 3);

        case MER_EASE_IN_OUT_CUBIC:
            return (_x < 0.5) ? (4 * _x * _x * _x)
                              : (1 - power(-2 * _x + 2, 3) * 0.5);

        case MER_EASE_OUT_EXPO:
            // The == 1 guard matters: power(2, -infinity) is not what we want at the endpoint.
            return (_x >= 1) ? 1 : (1 - power(2, -10 * _x));

        case MER_EASE_IN_OUT_EXPO:
            if (_x <= 0) return 0;
            if (_x >= 1) return 1;
            return (_x < 0.5) ? (power(2, 20 * _x - 10) * 0.5)
                              : ((2 - power(2, -20 * _x + 10)) * 0.5);

        case MER_EASE_OUT_BACK:
            // c1 is the classic 1.70158 overshoot constant; c3 = c1 + 1.
            var _c1 = 1.70158;
            var _c3 = _c1 + 1;
            return 1 + _c3 * power(_x - 1, 3) + _c1 * power(_x - 1, 2);

        case MER_EASE_IN_BACK:
            var _b1 = 1.70158;
            var _b3 = _b1 + 1;
            return _b3 * _x * _x * _x - _b1 * _x * _x;

        case MER_EASE_OUT_ELASTIC:
            if (_x <= 0) return 0;
            if (_x >= 1) return 1;
            var _c4 = (2 * pi) / 3;
            return power(2, -10 * _x) * sin((_x * 10 - 0.75) * _c4) + 1;

        case MER_EASE_OUT_BOUNCE:
            return mer_ease_out_bounce(_x);

        default:
            return _x;
    }
}

/// @func   mer_ease_out_bounce(_t)
/// @desc   The four-segment bounce curve, split out because mer_ease dispatches to it and
///         because a bounce reads far better as explicit piecewise segments than as a nested
///         ternary. Constants are the standard Penner values.
/// @param  {Real} _t  Normalised time in [0, 1].
/// @return {Real} Normalised position in [0, 1].
/// @pure
function mer_ease_out_bounce(_t) {
    var _n1 = 7.5625;
    var _d1 = 2.75;
    var _x  = clamp(_t, 0, 1);

    if (_x < 1 / _d1)       return _n1 * _x * _x;
    if (_x < 2 / _d1)     { _x -= 1.5   / _d1; return _n1 * _x * _x + 0.75;    }
    if (_x < 2.5 / _d1)   { _x -= 2.25  / _d1; return _n1 * _x * _x + 0.9375;  }
                            _x -= 2.625 / _d1; return _n1 * _x * _x + 0.984375;
}

/// @func   mer_spring_make(_stiffness, _damping, _value)
/// @desc   Creates a critically-tunable spring state struct.
///
///         A spring is what separates Meridian from a tween library, so it is worth being
///         precise about why. A tween needs to know its duration and its destination up front;
///         if the target moves mid-flight the animation has to be torn down and restarted, which
///         is what produces the small visual "hitch" you see in most GameMaker UI code. A spring
///         has no duration and no schedule — it only ever reads its current position, its
///         velocity, and where it is being pulled. Retarget it every single frame and it stays
///         smooth, because there is nothing to restart.
///
/// @param  {Real} _stiffness  Pull toward the target. Higher is snappier. Sane range 60-400.
/// @param  {Real} _damping    Resistance. Higher settles sooner with less overshoot. Range 5-40.
/// @param  {Real} _value      Initial position, also used as the initial target.
/// @return {Struct} Spring state, to be advanced with mer_spring_step.
/// @pure
function mer_spring_make(_stiffness, _damping, _value) {
    return {
        stiffness : _stiffness,
        damping   : _damping,
        value     : _value,
        target    : _value,
        velocity  : 0,
    };
}

/// @func   mer_spring_step(_spring, _dt)
/// @desc   Advances a spring by one timestep using semi-implicit Euler integration.
///
/// @remarks Semi-implicit Euler is chosen over explicit Euler on purpose: velocity is updated
///          FIRST and the new velocity is then used to update position. Explicit Euler (position
///          first, from the old velocity) injects energy at every step and a stiff spring will
///          visibly diverge instead of settling. The ordering below is the whole difference and
///          it is one line apart, so do not "tidy" it.
///
///          The timestep is also sub-stepped. At 60fps a single step is fine, but a frame spike
///          on a buyer's machine produces a large _dt, and a large _dt through any explicit
///          integrator makes a stiff spring explode. Clamping the sub-step count bounds the work
///          done in a bad frame so a hitch never becomes a spiral.
///
/// @param  {Struct} _spring  A struct from mer_spring_make. Mutated in place.
/// @param  {Real}   _dt      Delta time in seconds.
/// @return {Real} The spring's new position, also written to _spring.value.
function mer_spring_step(_spring, _dt) {
    // Bound the sub-step count so a long frame cannot cost unbounded work.
    var _steps = clamp(ceil(_dt / (1 / 120)), 1, 8);
    var _h     = _dt / _steps;

    var _v = _spring.velocity;
    var _p = _spring.value;
    var _k = _spring.stiffness;
    var _c = _spring.damping;
    var _x = _spring.target;

    for (var _i = 0; _i < _steps; _i++) {
        var _accel = (_k * (_x - _p)) - (_c * _v);
        _v += _accel * _h;   // velocity first...
        _p += _v * _h;       // ...then position, using the NEW velocity. See @remarks.
    }

    _spring.velocity = _v;
    _spring.value    = _p;
    return _p;
}

/// @func   mer_spring_settled(_spring, _epsilon)
/// @desc   Reports whether a spring has effectively come to rest, so callers can stop redrawing
///         a region that is no longer moving.
/// @param  {Struct} _spring   A spring state struct.
/// @param  {Real}   _epsilon  Tolerance in pixels. Defaults to a quarter pixel.
/// @return {Bool} True when both displacement and velocity are below tolerance.
/// @pure
function mer_spring_settled(_spring, _epsilon = 0.25) {
    return (abs(_spring.target - _spring.value) < _epsilon)
        && (abs(_spring.velocity) < _epsilon);
}

/// @func   mer_stagger(_index, _count, _elapsed, _duration, _overlap)
/// @desc   Returns the normalised progress of item _index within a staggered reveal.
///
///         Staggering is the cheapest trick in this whole package and the one buyers notice
///         first: a menu whose six entries arrive together reads as a screen being switched on,
///         and the same six arriving 40ms apart reads as a screen being assembled. Same code
///         path, entirely different impression.
///
/// @param  {Real} _index     Zero-based index of the item.
/// @param  {Real} _count     Total item count. Guarded against zero.
/// @param  {Real} _elapsed   Seconds since the reveal began.
/// @param  {Real} _duration  Seconds each individual item takes.
/// @param  {Real} _overlap   0 = strictly sequential, 1 = fully simultaneous.
/// @return {Real} Normalised progress in [0, 1] for this item.
/// @pure
function mer_stagger(_index, _count, _elapsed, _duration, _overlap = 0.75) {
    var _n = max(_count, 1);

    // Spacing between consecutive item starts. At _overlap = 1 every item starts at t = 0.
    var _gap   = _duration * (1 - clamp(_overlap, 0, 1));
    var _start = _index * _gap;
    var _local = _elapsed - _start;

    if (_local <= 0)         return 0;
    if (_duration <= 0)      return 1;
    return clamp(_local / _duration, 0, 1);
}
