{
  "$GMScript": "v1",
  "%Name": "mer_ease",
  "isCompatibility": false,
  "isDnD": false,
  "name": "mer_ease",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}