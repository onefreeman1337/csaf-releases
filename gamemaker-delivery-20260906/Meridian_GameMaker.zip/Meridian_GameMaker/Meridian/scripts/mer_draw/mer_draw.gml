/// @file    mer_draw.gml
/// @package Meridian for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary The procedural drawing layer. Every panel, border, bar, glyph and glow in Meridian
///          is generated from primitives and colour maths at draw time.
///
/// @remarks WHY THERE ARE NO SPRITES ANYWHERE IN THIS PACKAGE.
///
///          A conventional GameMaker UI kit ships nine-slice PNGs. That works, and it locks the
///          buyer into one art style, one resolution band, and a texture page. Retheming means
///          reopening an image editor.
///
///          Drawing procedurally costs a little more per frame and buys three things that matter
///          more: the interface is resolution independent, so it is crisp at 480p and at 4K from
///          the same code; the entire look is a palette struct, so a buyer restyles the whole UI
///          by changing six colours; and there is no texture page, so dropping the package into an
///          existing project cannot disturb that project's atlas packing.
///
///          NOT ONE COLOUR IS HARDCODED IN THIS FILE. Every function reads mer_theme_get(), or
///          takes an explicit colour from its caller. If you find a literal colour here it is a
///          bug — that promise used to be made in this header and not kept by the code beneath
///          it, which is exactly the kind of thing that earns a refund.
///
///          Functions here DO call engine draw routines and are therefore not pure — the pure
///          maths lives in mer_ease.gml. Keep that separation.

#macro MER_CORNER_SEGMENTS 6   // Segments per rounded corner. 6 is smooth past ~4px radius.

// ---------------------------------------------------------------------------------------------
// Path construction
// ---------------------------------------------------------------------------------------------

/// @func   mer_round_rect_points(_x, _y, _w, _h, _radius)
/// @desc   Builds the perimeter of a rounded rectangle as a flat array of alternating x,y.
///
/// @remarks Factored out so the fill and the outline walk THE SAME path. When they were computed
///          separately a one-pixel disagreement at the corners was visible as a hairline gap on
///          any panel with a bright edge.
///
/// @param  {Real} _x       Left edge.
/// @param  {Real} _y       Top edge.
/// @param  {Real} _w       Width.
/// @param  {Real} _h       Height.
/// @param  {Real} _radius  Corner radius. Clamped to half the shorter side.
/// @return {Array} Flat array of x,y pairs, walked clockwise from the top-left corner.
/// @pure
function mer_round_rect_points(_x, _y, _w, _h, _radius) {
    var _r  = min(_radius, _w * 0.5, _h * 0.5);
    var _cx = [_x + _r,  _x + _w - _r, _x + _w - _r, _x + _r     ];
    var _cy = [_y + _r,  _y + _r,      _y + _h - _r, _y + _h - _r];
    var _a0 = [180,      270,          0,            90          ];

    var _pts = [];
    for (var _c = 0; _c < 4; _c++) {
        for (var _s = 0; _s <= MER_CORNER_SEGMENTS; _s++) {
            var _ang = _a0[_c] + (_s / MER_CORNER_SEGMENTS) * 90;
            array_push(_pts, _cx[_c] + lengthdir_x(_r, -_ang));
            array_push(_pts, _cy[_c] + lengthdir_y(_r, -_ang));
        }
    }
    return _pts;
}

// ---------------------------------------------------------------------------------------------
// Fills and strokes
// ---------------------------------------------------------------------------------------------

/// @func   mer_draw_round_rect(_x, _y, _w, _h, _radius, _colour, _alpha)
/// @desc   Draws a filled rounded rectangle as a single triangle fan.
///
/// @remarks Built as ONE primitive rather than the usual rectangle-plus-four-circles. The naive
///          construction is visibly wrong on any translucent panel: the circles overlap the
///          rectangle, the overlapping pixels get blended twice, and the corners render darker
///          than the edges. A single fan touches every pixel exactly once, so alpha is uniform.
///
/// @param  {Real} _x       Left edge.
/// @param  {Real} _y       Top edge.
/// @param  {Real} _w       Width.
/// @param  {Real} _h       Height.
/// @param  {Real} _radius  Corner radius. Clamped to half the shorter side.
/// @param  {Real} _colour  BGR colour value.
/// @param  {Real} _alpha   Alpha in [0, 1].
function mer_draw_round_rect(_x, _y, _w, _h, _radius, _colour, _alpha) {
    if (_w <= 0 || _h <= 0 || _alpha <= 0) return;

    var _pts = mer_round_rect_points(_x, _y, _w, _h, _radius);
    var _n   = array_length(_pts) div 2;

    draw_primitive_begin(pr_trianglefan);
    // Fan origin at the centre keeps every triangle well-formed for any aspect ratio.
    draw_vertex_colour(_x + _w * 0.5, _y + _h * 0.5, _colour, _alpha);
    for (var _i = 0; _i < _n; _i++) {
        draw_vertex_colour(_pts[_i * 2], _pts[_i * 2 + 1], _colour, _alpha);
    }
    // Close the fan back onto the first perimeter vertex.
    draw_vertex_colour(_pts[0], _pts[1], _colour, _alpha);
    draw_primitive_end();
}

/// @func   mer_draw_round_rect_outline(_x, _y, _w, _h, _radius, _colour, _alpha, _weight)
/// @desc   Strokes the outline of a rounded rectangle.
/// @param  {Real} _x       Left edge.
/// @param  {Real} _y       Top edge.
/// @param  {Real} _w       Width.
/// @param  {Real} _h       Height.
/// @param  {Real} _radius  Corner radius.
/// @param  {Real} _colour  BGR colour value.
/// @param  {Real} _alpha   Alpha in [0, 1].
/// @param  {Real} _weight  Line width in pixels.
function mer_draw_round_rect_outline(_x, _y, _w, _h, _radius, _colour, _alpha, _weight = 1) {
    if (_w <= 0 || _h <= 0 || _alpha <= 0) return;

    var _pts = mer_round_rect_points(_x, _y, _w, _h, _radius);
    var _n   = array_length(_pts) div 2;

    draw_set_alpha(_alpha);
    draw_set_colour(_colour);
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n;
        draw_line_width(_pts[_i * 2], _pts[_i * 2 + 1], _pts[_j * 2], _pts[_j * 2 + 1], _weight);
    }
    draw_set_alpha(1);
    draw_set_colour(c_white);
}

/// @func   mer_draw_gradient_v(_x, _y, _w, _h, _top, _bottom, _alpha_top, _alpha_bottom)
/// @desc   A vertical two-stop gradient as a single triangle strip.
/// @param  {Real} _x             Left edge.
/// @param  {Real} _y             Top edge.
/// @param  {Real} _w             Width.
/// @param  {Real} _h             Height.
/// @param  {Real} _top           Colour at the top.
/// @param  {Real} _bottom        Colour at the bottom.
/// @param  {Real} _alpha_top     Alpha at the top.
/// @param  {Real} _alpha_bottom  Alpha at the bottom.
function mer_draw_gradient_v(_x, _y, _w, _h, _top, _bottom, _alpha_top = 1, _alpha_bottom = 1) {
    if (_w <= 0 || _h <= 0) return;

    draw_primitive_begin(pr_trianglestrip);
    draw_vertex_colour(_x,      _y,      _top,    _alpha_top);
    draw_vertex_colour(_x + _w, _y,      _top,    _alpha_top);
    draw_vertex_colour(_x,      _y + _h, _bottom, _alpha_bottom);
    draw_vertex_colour(_x + _w, _y + _h, _bottom, _alpha_bottom);
    draw_primitive_end();
}

/// @func   mer_draw_glow(_x, _y, _w, _h, _radius, _colour, _alpha, _rings, _spread)
/// @desc   A soft outer glow built from concentric rounded rectangles at falling alpha.
///
/// @remarks This is the cheapest convincing drop shadow available without a shader or a blurred
///          sprite. Each ring is one primitive and the alpha falls off quadratically, which reads
///          much closer to a real blur than a linear ramp does — a linear ramp has a visible hard
///          outer boundary because the eye is very good at spotting a constant gradient stopping.
///
/// @param  {Real} _x       Left edge of the glowing object.
/// @param  {Real} _y       Top edge.
/// @param  {Real} _w       Width.
/// @param  {Real} _h       Height.
/// @param  {Real} _radius  Corner radius of the object.
/// @param  {Real} _colour  Glow colour.
/// @param  {Real} _alpha   Alpha of the innermost ring.
/// @param  {Real} _rings   How many rings. More is smoother and costs one primitive each.
/// @param  {Real} _spread  Pixels of glow per ring.
function mer_draw_glow(_x, _y, _w, _h, _radius, _colour, _alpha, _rings = 6, _spread = 2) {
    if (_alpha <= 0 || _rings <= 0) return;

    for (var _g = _rings; _g > 0; _g--) {
        var _o = _g * _spread;
        var _f = 1 - (_g / (_rings + 1));
        mer_draw_round_rect(_x - _o, _y - _o, _w + _o * 2, _h + _o * 2,
                            _radius + _o, _colour, _alpha * _f * _f);
    }
}

/// @func   mer_draw_arc(_cx, _cy, _radius, _from, _to, _colour, _alpha, _weight, _segments)
/// @desc   Strokes a circular arc. Used by the radial gauge widget.
/// @param  {Real} _cx        Centre x.
/// @param  {Real} _cy        Centre y.
/// @param  {Real} _radius    Radius in pixels.
/// @param  {Real} _from      Start angle in degrees, GameMaker convention (0 = right, CCW).
/// @param  {Real} _to        End angle in degrees.
/// @param  {Real} _colour    BGR colour value.
/// @param  {Real} _alpha     Alpha in [0, 1].
/// @param  {Real} _weight    Line width.
/// @param  {Real} _segments  Segment count. 48 is smooth for a full circle at typical HUD sizes.
function mer_draw_arc(_cx, _cy, _radius, _from, _to, _colour, _alpha, _weight = 2, _segments = 48) {
    if (_alpha <= 0 || _radius <= 0) return;

    var _steps = max(1, ceil(_segments * abs(_to - _from) / 360));
    var _rad   = _weight * 0.5;
    var _cap   = (_weight >= 2.5);

    draw_set_alpha(_alpha);
    draw_set_colour(_colour);
    for (var _i = 0; _i < _steps; _i++) {
        var _a1 = lerp(_from, _to, _i / _steps);
        var _a2 = lerp(_from, _to, (_i + 1) / _steps);
        var _x1 = _cx + lengthdir_x(_radius, _a1);
        var _y1 = _cy + lengthdir_y(_radius, _a1);
        var _x2 = _cx + lengthdir_x(_radius, _a2);
        var _y2 = _cy + lengthdir_y(_radius, _a2);
        draw_line_width(_x1, _y1, _x2, _y2, _weight);
        if (_cap && _i < _steps - 1) draw_circle(_x2, _y2, _rad, false);
    }
    draw_set_alpha(1);
    draw_set_colour(c_white);
}

// ---------------------------------------------------------------------------------------------
// Composed chrome
// ---------------------------------------------------------------------------------------------

/// @func   mer_draw_backdrop(_x, _y, _w, _h)
/// @desc   Fills a region with the theme's backdrop gradient. Call it before anything else.
/// @param  {Real} _x  Left edge.
/// @param  {Real} _y  Top edge.
/// @param  {Real} _w  Width.
/// @param  {Real} _h  Height.
function mer_draw_backdrop(_x, _y, _w, _h) {
    var _t = mer_theme_get();
    mer_draw_gradient_v(_x, _y, _w, _h, _t.backdropTop, _t.backdropBase, 1, 1);
}

/// @func   mer_draw_panel(_x, _y, _w, _h, _alpha)
/// @desc   The standard Meridian panel: outer glow, translucent body with a vertical tint,
///         a hairline edge, and a top highlight.
///
/// @remarks The top highlight is the detail that does the most work for the least cost. A flat
///          translucent rectangle reads as a debug overlay; a single lighter line along the top
///          edge reads as a lit surface, because it is the cue the eye uses for "this object has a
///          thickness and there is a light above it". It is one draw call.
///
/// @param  {Real} _x      Left edge.
/// @param  {Real} _y      Top edge.
/// @param  {Real} _w      Width.
/// @param  {Real} _h      Height.
/// @param  {Real} _alpha  Master alpha, so a whole panel can fade in as one unit. Defaults to 1.
function mer_draw_panel(_x, _y, _w, _h, _alpha = 1) {
    if (_alpha <= 0 || _w <= 0 || _h <= 0) return;

    var _t = mer_theme_get();
    var _r = _t.radius;

    mer_draw_glow(_x, _y, _w, _h, _r, _t.glow, _t.glowAlpha * _alpha, _t.glowRings, 2);

    // Body.
    mer_draw_round_rect(_x, _y, _w, _h, _r, _t.surface, _t.panelAlpha * _alpha);

    // Vertical tint over the lower half, so the panel is not a flat field of one colour.
    mer_draw_gradient_v(_x, _y + _h * 0.45, _w, _h * 0.55 - _r,
                        _t.surfaceHi, _t.surfaceHi, 0, 0.5 * _alpha);

    // Hairline edge and top highlight.
    mer_draw_round_rect_outline(_x, _y, _w, _h, _r, _t.edge, _t.edgeAlpha * 0.6 * _alpha, 1);

    draw_set_alpha(_t.edgeAlpha * _alpha);
    draw_set_colour(_t.accent);
    draw_line(_x + _r + 4, _y + 1, _x + _w - _r - 4, _y + 1);
    draw_set_alpha(1);
    draw_set_colour(c_white);
}

/// @func   mer_draw_highlight(_x, _y, _w, _h, _alpha)
/// @desc   The moving selection highlight: a soft body plus a bright leading edge.
///
/// @remarks The bright left edge is what makes the highlight read as travelling rather than
///          teleporting. During a transition the body is stretched between two rows and the eye
///          needs an anchor to track; the edge gives it one.
///
/// @param  {Real} _x      Left edge.
/// @param  {Real} _y      Top edge.
/// @param  {Real} _w      Width.
/// @param  {Real} _h      Height.
/// @param  {Real} _alpha  Master alpha. Defaults to 1.
function mer_draw_highlight(_x, _y, _w, _h, _alpha = 1) {
    if (_alpha <= 0 || _w <= 0 || _h <= 0) return;

    var _t = mer_theme_get();

    mer_draw_round_rect(_x, _y, _w, _h, _t.radiusSmall, _t.highlight, 0.42 * _alpha);
    mer_draw_gradient_v(_x + _t.radiusSmall, _y, _w - _t.radiusSmall * 2, _h,
                        _t.accent, _t.accent, 0.18 * _alpha, 0);

    // Leading edge.
    draw_set_alpha(0.95 * _alpha);
    draw_set_colour(_t.leadingEdge);
    draw_rectangle(_x, _y + 4, _x + 3, _y + _h - 4, false);
    draw_set_alpha(1);
    draw_set_colour(c_white);
}

/// @func   mer_draw_scanlines(_x, _y, _w, _h, _spacing, _alpha)
/// @desc   A subtle horizontal scanline overlay. Set theme.scanlineAlpha to 0 to disable.
///
/// @remarks Two pixels of texture over a flat fill is the single cheapest way to stop a
///          procedurally drawn panel reading as "programmer art". A perfectly flat surface is a
///          giveaway that nothing was authored; any regular micro-texture reads as a material.
///
/// @param  {Real} _x        Left edge.
/// @param  {Real} _y        Top edge.
/// @param  {Real} _w        Width.
/// @param  {Real} _h        Height.
/// @param  {Real} _spacing  Pixels between lines.
/// @param  {Real} _alpha    Override alpha, or undefined to use theme.scanlineAlpha.
function mer_draw_scanlines(_x, _y, _w, _h, _spacing = 3, _alpha = undefined) {
    var _t = mer_theme_get();
    var _a = is_undefined(_alpha) ? _t.scanlineAlpha : _alpha;
    if (_a <= 0 || _spacing <= 0) return;

    draw_set_alpha(_a);
    draw_set_colour(_t.accent);
    var _yy = _y;
    while (_yy < _y + _h) {
        draw_line(_x, _yy, _x + _w, _yy);
        _yy += _spacing;
    }
    draw_set_alpha(1);
    draw_set_colour(c_white);
}

/// @func   mer_draw_corner_ticks(_x, _y, _w, _h, _length, _colour, _alpha, _weight)
/// @desc   Four L-shaped corner brackets. HUD framing, and a strong "this was designed" signal.
/// @param  {Real} _x       Left edge.
/// @param  {Real} _y       Top edge.
/// @param  {Real} _w       Width.
/// @param  {Real} _h       Height.
/// @param  {Real} _length  Arm length in pixels.
/// @param  {Real} _colour  BGR colour, or undefined for the theme accent.
/// @param  {Real} _alpha   Alpha in [0, 1].
/// @param  {Real} _weight  Line width.
function mer_draw_corner_ticks(_x, _y, _w, _h, _length = 12, _colour = undefined,
                               _alpha = 0.8, _weight = 2) {
    var _t = mer_theme_get();
    var _c = is_undefined(_colour) ? _t.accent : _colour;
    if (_alpha <= 0) return;

    draw_set_alpha(_alpha);
    draw_set_colour(_c);

    draw_line_width(_x,           _y,      _x + _length, _y,      _weight);
    draw_line_width(_x,           _y,      _x,           _y + _length, _weight);
    draw_line_width(_x + _w,      _y,      _x + _w - _length, _y, _weight);
    draw_line_width(_x + _w,      _y,      _x + _w,      _y + _length, _weight);
    draw_line_width(_x,           _y + _h, _x + _length, _y + _h, _weight);
    draw_line_width(_x,           _y + _h, _x,           _y + _h - _length, _weight);
    draw_line_width(_x + _w,      _y + _h, _x + _w - _length, _y + _h, _weight);
    draw_line_width(_x + _w,      _y + _h, _x + _w,      _y + _h - _length, _weight);

    draw_set_alpha(1);
    draw_set_colour(c_white);
}

// ---------------------------------------------------------------------------------------------
// Vector glyphs. Drawn, not sprited — same reasoning as the typeface in mer_font.gml.
// ---------------------------------------------------------------------------------------------

/// @func   mer_draw_chevron(_cx, _cy, _size, _direction, _colour, _alpha, _weight)
/// @desc   A directional chevron. Used for dropdowns, sliders and "more" affordances.
/// @param  {Real} _cx         Centre x.
/// @param  {Real} _cy         Centre y.
/// @param  {Real} _size       Half-extent in pixels.
/// @param  {Real} _direction  Degrees. 0 points right, 90 up, 180 left, 270 down.
/// @param  {Real} _colour     BGR colour, or undefined for the theme accent.
/// @param  {Real} _alpha      Alpha in [0, 1].
/// @param  {Real} _weight     Line width.
function mer_draw_chevron(_cx, _cy, _size, _direction = 0, _colour = undefined,
                          _alpha = 1, _weight = 2) {
    var _t = mer_theme_get();
    var _c = is_undefined(_colour) ? _t.accent : _colour;
    if (_alpha <= 0) return;

    // Two arms swept back 135 degrees either side of the pointing direction.
    var _tipx = _cx + lengthdir_x(_size, _direction);
    var _tipy = _cy + lengthdir_y(_size, _direction);
    var _ax   = _cx + lengthdir_x(_size, _direction + 135);
    var _ay   = _cy + lengthdir_y(_size, _direction + 135);
    var _bx   = _cx + lengthdir_x(_size, _direction - 135);
    var _by   = _cy + lengthdir_y(_size, _direction - 135);

    draw_set_alpha(_alpha);
    draw_set_colour(_c);
    draw_line_width(_ax, _ay, _tipx, _tipy, _weight);
    draw_line_width(_tipx, _tipy, _bx, _by, _weight);
    if (_weight >= 2.5) draw_circle(_tipx, _tipy, _weight * 0.5, false);
    draw_set_alpha(1);
    draw_set_colour(c_white);
}

/// @func   mer_draw_check(_cx, _cy, _size, _colour, _alpha, _weight, _progress)
/// @desc   A tick mark, optionally drawn partially so it can be animated on.
///
/// @remarks _progress exists because a checkbox that pops its tick in fully formed looks like a
///          state change, and one that draws the tick on over four frames looks like a
///          confirmation. Same two line segments either way.
///
/// @param  {Real} _cx        Centre x.
/// @param  {Real} _cy        Centre y.
/// @param  {Real} _size      Half-extent in pixels.
/// @param  {Real} _colour    BGR colour, or undefined for the theme accentAlt.
/// @param  {Real} _alpha     Alpha in [0, 1].
/// @param  {Real} _weight    Line width.
/// @param  {Real} _progress  0 draws nothing, 1 draws the whole tick.
function mer_draw_check(_cx, _cy, _size, _colour = undefined, _alpha = 1,
                        _weight = 2, _progress = 1) {
    var _t = mer_theme_get();
    var _c = is_undefined(_colour) ? _t.accentAlt : _colour;
    var _p = clamp(_progress, 0, 1);
    if (_alpha <= 0 || _p <= 0) return;

    // Short down-stroke then a long up-stroke. The first is 35% of the total path.
    var _x0 = _cx - _size,        _y0 = _cy + _size * 0.05;
    var _x1 = _cx - _size * 0.25, _y1 = _cy + _size * 0.75;
    var _x2 = _cx + _size,        _y2 = _cy - _size * 0.75;
    var _split = 0.35;

    draw_set_alpha(_alpha);
    draw_set_colour(_c);

    if (_p <= _split) {
        var _k = _p / _split;
        draw_line_width(_x0, _y0, lerp(_x0, _x1, _k), lerp(_y0, _y1, _k), _weight);
    } else {
        var _k2 = (_p - _split) / (1 - _split);
        draw_line_width(_x0, _y0, _x1, _y1, _weight);
        if (_weight >= 2.5) draw_circle(_x1, _y1, _weight * 0.5, false);
        draw_line_width(_x1, _y1, lerp(_x1, _x2, _k2), lerp(_y1, _y2, _k2), _weight);
    }

    draw_set_alpha(1);
    draw_set_colour(c_white);
}

/// @func   mer_draw_cross(_cx, _cy, _size, _colour, _alpha, _weight)
/// @desc   An X. Close buttons, denied states.
/// @param  {Real} _cx      Centre x.
/// @param  {Real} _cy      Centre y.
/// @param  {Real} _size    Half-extent in pixels.
/// @param  {Real} _colour  BGR colour, or undefined for the theme textDim.
/// @param  {Real} _alpha   Alpha in [0, 1].
/// @param  {Real} _weight  Line width.
function mer_draw_cross(_cx, _cy, _size, _colour = undefined, _alpha = 1, _weight = 2) {
    var _t = mer_theme_get();
    var _c = is_undefined(_colour) ? _t.textDim : _colour;
    if (_alpha <= 0) return;

    draw_set_alpha(_alpha);
    draw_set_colour(_c);
    draw_line_width(_cx - _size, _cy - _size, _cx + _size, _cy + _size, _weight);
    draw_line_width(_cx + _size, _cy - _size, _cx - _size, _cy + _size, _weight);
    draw_set_alpha(1);
    draw_set_colour(c_white);
}
