{
  "$GMScript": "v1",
  "%Name": "mer_draw",
  "isCompatibility": false,
  "isDnD": false,
  "name": "mer_draw",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}