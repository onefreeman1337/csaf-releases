/// @file    mer_font.gml
/// @package Meridian for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary A geometric stroke typeface drawn from line segments. No font resource, no glyph
///          atlas, no texture page.
///
/// @remarks WHY A PACKAGE THIS SIZE SHIPS ITS OWN TYPEFACE.
///
///          Meridian claims to be resolution independent and to add nothing to your texture
///          pages. Draw one line of text with a normal GameMaker font and both claims are false:
///          a font resource is a bitmap atlas, it lives on a texture page, and it is authored at
///          one size and resampled at every other. The interface would be crisp at 4K and the
///          words on it would not.
///
///          So the typeface is geometry. Every glyph is a short list of polylines on a 5-wide by
///          7-tall grid, stroked with draw_line_width at a weight derived from the requested cap
///          height. Scale it to 9 px or to 900 px and it is exactly as sharp, because there is
///          nothing to resample. It also means the text colour, weight and tracking are all
///          runtime parameters rather than baked into an image.
///
///          It is a deliberate, opinionated display face — uppercase, wide tracking, geometric.
///          It is meant for menus, HUDs, titles and labels, which is what this package is for.
///          IT IS NOT A BODY-TEXT FACE, and it should not be used for paragraphs or for dialogue.
///          Pair it with a normal font or with Scribble for those; Meridian does not care what
///          draws your prose and will not fight it.
///
///          Lowercase input is folded to uppercase rather than rejected, so passing a buyer's
///          existing strings through it always renders something legible.
///
///          COORDINATE SYSTEM. x runs 0 to 5, y runs 0 (cap height) to 7 (baseline). Descenders
///          and quotes deliberately exceed that box. A stroke is a flat array of alternating
///          x,y pairs. A stroke of exactly one point is drawn as a dot, which is how the full
///          stop, colon and exclamation mark are built.

/// @func   mer_font_build()
/// @desc   Builds the glyph table. Called once, lazily, by mer_font_get.
///
/// @remarks Returns an array indexed by ASCII code so glyph lookup is an array read rather than a
///          struct hash — this runs per character per frame and it is the only part of Meridian
///          where that distinction is measurable.
///
/// @return {Array} 128 entries, each either undefined or {a: advance, s: array of strokes}.
function mer_font_build() {
    var _f = array_create(128, undefined);

    // --- space and letters ---------------------------------------------------------------
    _f[ord(" ")] = { a: 4, s: [] };

    _f[ord("A")] = { a: 7, s: [[0,7, 2.5,0, 5,7], [0.9,4.6, 4.1,4.6]] };
    _f[ord("B")] = { a: 7, s: [[0,7, 0,0, 3.4,0, 4.8,1.1, 4.8,2.4, 3.4,3.4, 0,3.4],
                               [3.4,3.4, 5,4.5, 5,5.9, 3.4,7, 0,7]] };
    _f[ord("C")] = { a: 7, s: [[5,1.4, 3.6,0, 1.6,0, 0,1.7, 0,5.3, 1.6,7, 3.6,7, 5,5.6]] };
    _f[ord("D")] = { a: 7, s: [[0,0, 3,0, 5,2, 5,5, 3,7, 0,7, 0,0]] };
    _f[ord("E")] = { a: 7, s: [[5,0, 0,0, 0,7, 5,7], [0,3.4, 3.9,3.4]] };
    _f[ord("F")] = { a: 7, s: [[5,0, 0,0, 0,7], [0,3.4, 3.7,3.4]] };
    _f[ord("G")] = { a: 7, s: [[5,1.4, 3.6,0, 1.6,0, 0,1.7, 0,5.3, 1.6,7, 3.6,7, 5,5.6, 5,4, 3,4]] };
    _f[ord("H")] = { a: 7, s: [[0,0, 0,7], [5,0, 5,7], [0,3.5, 5,3.5]] };
    // I is narrow, so its ink is flush LEFT like every other capital and the slack goes on the
    // right. Centring it inside its advance instead adds a left side bearing that nothing else
    // has, and the result is a visible hole in common words — "CONTINUE" renders as "CONT INUE".
    _f[ord("I")] = { a: 5, s: [[0,0, 3,0], [1.5,0, 1.5,7], [0,7, 3,7]] };
    _f[ord("J")] = { a: 7, s: [[4.6,0, 4.6,5.4, 3.2,7, 1.4,7, 0,5.6]] };
    _f[ord("K")] = { a: 7, s: [[0,0, 0,7], [4.8,0, 0.4,3.9], [1.6,2.8, 5,7]] };
    _f[ord("L")] = { a: 7, s: [[0,0, 0,7, 4.8,7]] };
    _f[ord("M")] = { a: 7, s: [[0,7, 0,0, 2.5,3.4, 5,0, 5,7]] };
    _f[ord("N")] = { a: 7, s: [[0,7, 0,0, 5,7, 5,0]] };
    _f[ord("O")] = { a: 7, s: [[1.6,0, 3.4,0, 5,1.7, 5,5.3, 3.4,7, 1.6,7, 0,5.3, 0,1.7, 1.6,0]] };
    _f[ord("P")] = { a: 7, s: [[0,7, 0,0, 3.4,0, 5,1.3, 5,2.7, 3.4,4, 0,4]] };
    _f[ord("Q")] = { a: 7, s: [[1.6,0, 3.4,0, 5,1.7, 5,5.3, 3.4,7, 1.6,7, 0,5.3, 0,1.7, 1.6,0],
                               [3.1,4.9, 5.2,7.5]] };
    _f[ord("R")] = { a: 7, s: [[0,7, 0,0, 3.4,0, 5,1.3, 5,2.7, 3.4,4, 0,4], [2.6,4, 5,7]] };
    _f[ord("S")] = { a: 7, s: [[5,1.3, 3.4,0, 1.5,0, 0,1.2, 0,2.5, 1.4,3.4, 3.6,3.6, 5,4.6,
                                5,5.9, 3.5,7, 1.5,7, 0,5.8]] };
    _f[ord("T")] = { a: 7, s: [[0,0, 5,0], [2.5,0, 2.5,7]] };
    _f[ord("U")] = { a: 7, s: [[0,0, 0,5.3, 1.6,7, 3.4,7, 5,5.3, 5,0]] };
    _f[ord("V")] = { a: 7, s: [[0,0, 2.5,7, 5,0]] };
    _f[ord("W")] = { a: 7, s: [[0,0, 1.1,7, 2.5,2.8, 3.9,7, 5,0]] };
    _f[ord("X")] = { a: 7, s: [[0,0, 5,7], [5,0, 0,7]] };
    _f[ord("Y")] = { a: 7, s: [[0,0, 2.5,3.6, 5,0], [2.5,3.6, 2.5,7]] };
    _f[ord("Z")] = { a: 7, s: [[0,0, 5,0, 0,7, 5,7]] };

    // --- digits --------------------------------------------------------------------------
    _f[ord("0")] = { a: 7, s: [[1.6,0, 3.4,0, 5,1.7, 5,5.3, 3.4,7, 1.6,7, 0,5.3, 0,1.7, 1.6,0],
                               [1.0,5.6, 4.0,1.4]] };
    _f[ord("1")] = { a: 7, s: [[0.6,1.6, 2.4,0, 2.4,7], [0.6,7, 4.4,7]] };
    _f[ord("2")] = { a: 7, s: [[0,1.5, 1.5,0, 3.6,0, 5,1.4, 5,2.6, 0,7, 5,7]] };
    _f[ord("3")] = { a: 7, s: [[0.2,0.9, 1.7,0, 3.6,0, 5,1.2, 5,2.4, 3.6,3.4, 2.2,3.4],
                               [3.6,3.4, 5,4.4, 5,5.8, 3.5,7, 1.6,7, 0.2,6.1]] };
    _f[ord("4")] = { a: 7, s: [[3.7,0, 0,4.9, 5,4.9], [3.7,0, 3.7,7]] };
    _f[ord("5")] = { a: 7, s: [[4.8,0, 0.6,0, 0.2,3.1, 1.6,2.5, 3.4,2.5, 5,3.9, 5,5.6,
                                3.4,7, 1.5,7, 0.1,6.1]] };
    _f[ord("6")] = { a: 7, s: [[4.6,0.7, 3.2,0, 1.6,0, 0,1.8, 0,5.4, 1.5,7, 3.4,7, 5,5.6,
                                5,4.6, 3.4,3.3, 1.5,3.3, 0,4.5]] };
    _f[ord("7")] = { a: 7, s: [[0,0, 5,0, 2,7]] };
    _f[ord("8")] = { a: 7, s: [[1.7,3.4, 0.1,2.4, 0.1,1.1, 1.6,0, 3.4,0, 4.9,1.1, 4.9,2.4,
                                3.3,3.4, 1.7,3.4, 0,4.6, 0,5.9, 1.6,7, 3.4,7, 5,5.9, 5,4.6, 3.3,3.4]] };
    _f[ord("9")] = { a: 7, s: [[0.4,6.3, 1.8,7, 3.4,7, 5,5.2, 5,1.6, 3.5,0, 1.6,0, 0,1.4,
                                0,2.4, 1.6,3.7, 3.5,3.7, 5,2.4]] };

    // --- punctuation -----------------------------------------------------------------------
    // A one-point stroke renders as a dot. See the file header.
    _f[ord(".")]  = { a: 4, s: [[1.5,6.7]] };
    _f[ord(",")]  = { a: 4, s: [[1.9,6.2, 1.0,8.1]] };
    _f[ord(":")]  = { a: 4, s: [[1.5,2.5], [1.5,6.7]] };
    _f[ord(";")]  = { a: 4, s: [[1.5,2.5], [1.7,6.4, 1.0,8.1]] };
    _f[ord("!")]  = { a: 4, s: [[1.5,0, 1.5,4.9], [1.5,6.7]] };
    _f[ord("?")]  = { a: 7, s: [[0.2,1.4, 1.6,0, 3.4,0, 4.8,1.4, 4.8,2.4, 2.5,3.9, 2.5,4.9],
                                [2.5,6.7]] };
    _f[ord("-")]  = { a: 7, s: [[0.6,3.6, 4.4,3.6]] };
    _f[ord("_")]  = { a: 7, s: [[0,7.6, 5,7.6]] };
    _f[ord("+")]  = { a: 7, s: [[0.6,3.6, 4.4,3.6], [2.5,1.7, 2.5,5.5]] };
    _f[ord("=")]  = { a: 7, s: [[0.6,2.6, 4.4,2.6], [0.6,4.6, 4.4,4.6]] };
    _f[ord("/")]  = { a: 7, s: [[0,7.4, 5,-0.4]] };
    _f[ord("\\")] = { a: 7, s: [[0,-0.4, 5,7.4]] };
    _f[ord("(")]  = { a: 4, s: [[2.4,-0.4, 0.8,2.0, 0.8,5.0, 2.4,7.4]] };
    _f[ord(")")]  = { a: 4, s: [[0.4,-0.4, 2.0,2.0, 2.0,5.0, 0.4,7.4]] };
    _f[ord("[")]  = { a: 4, s: [[2.4,-0.4, 0.8,-0.4, 0.8,7.4, 2.4,7.4]] };
    _f[ord("]")]  = { a: 4, s: [[0.4,-0.4, 2.0,-0.4, 2.0,7.4, 0.4,7.4]] };
    _f[ord("<")]  = { a: 7, s: [[4.2,0.8, 0.6,3.5, 4.2,6.2]] };
    _f[ord(">")]  = { a: 7, s: [[0.8,0.8, 4.4,3.5, 0.8,6.2]] };
    _f[ord("*")]  = { a: 7, s: [[2.5,1.2, 2.5,5.0], [0.9,2.1, 4.1,4.1], [4.1,2.1, 0.9,4.1]] };
    _f[ord("|")]  = { a: 4, s: [[1.0,-0.3, 1.0,7.3]] };
    _f[ord("'")]  = { a: 3, s: [[1.0,0, 1.0,2.0]] };
    _f[ord("\"")] = { a: 5, s: [[0.9,0, 0.9,2.0], [2.7,0, 2.7,2.0]] };
    _f[ord("#")]  = { a: 8, s: [[1.6,0.4, 1.0,6.8], [4.4,0.4, 3.8,6.8],
                                [0.3,2.5, 5.3,2.5], [0.1,4.8, 5.1,4.8]] };
    _f[ord("%")]  = { a: 8, s: [[0.2,7.0, 5.8,0.2],
                                [0.3,0.3, 1.9,0.3, 1.9,1.9, 0.3,1.9, 0.3,0.3],
                                [4.1,5.1, 5.7,5.1, 5.7,6.7, 4.1,6.7, 4.1,5.1]] };

    return _f;
}

/// @func   mer_font_get()
/// @desc   Returns the glyph table, building it on first use.
///
/// @remarks Lazily initialised for the same reason the theme is: there is no setup call to
///          forget. The table is built once per run and costs nothing thereafter.
///
/// @return {Array} The glyph table.
function mer_font_get() {
    if (!variable_global_exists("__mer_font")) {
        global.__mer_font = mer_font_build();
    }
    return global.__mer_font;
}

/// @func   mer_text_width(_text, _size, _tracking)
/// @desc   Measures a string in the stroke typeface, in pixels.
///
/// @remarks Needed by every centred or right-aligned label, and by widgets that size themselves
///          to their content. Measuring is exact rather than estimated because the advance table
///          is the same data the renderer walks.
///
/// @param  {String} _text      The string. Lowercase is folded to uppercase.
/// @param  {Real}   _size      Cap height in pixels.
/// @param  {Real}   _tracking  Extra pixels between glyphs. Defaults to a tenth of the cap height.
/// @return {Real} Width in pixels.
/// @pure
function mer_text_width(_text, _size, _tracking = undefined) {
    var _font  = mer_font_get();
    var _scale = _size / 7;
    var _track = is_undefined(_tracking) ? (_size * 0.10) : _tracking;
    var _n     = string_length(_text);
    var _w     = 0;

    for (var _i = 1; _i <= _n; _i++) {
        var _c = ord(string_char_at(_text, _i));
        if (_c >= 97 && _c <= 122) _c -= 32;      // fold lowercase
        if (_c < 0 || _c > 127) _c = ord(" ");

        var _g = _font[_c];
        if (is_undefined(_g)) _g = _font[ord(" ")];

        _w += _g.a * _scale + _track;
    }

    // The final glyph contributes no trailing tracking.
    return max(0, _w - _track);
}

/// @func   mer_text_fit_size(_text, _size, _max_width, _tracking)
/// @desc   Returns the largest cap height, no greater than _size, at which _text fits inside
///         _max_width pixels. Returns _size unchanged when the string already fits.
///
/// @remarks THIS EXISTS BECAUSE A CAPTURE CAUGHT IT. KuiDialog sized its body text as a fraction
///          of the dialog height and never measured it against the dialog WIDTH, so
///          "UNSAVED PROGRESS WILL BE LOST." rendered straight through both side walls of the
///          panel. It compiled perfectly and the gate was clean through it — the defect only
///          exists in pixels. Any widget that draws a caller-supplied string into a fixed box has
///          the same exposure, which is why this is a shared function rather than a local patch.
///
/// @remarks At the default tracking, width is exactly proportional to cap height, so the first
///          step lands on the answer. An explicitly supplied tracking does NOT scale with size,
///          so the result is verified and shaved until it genuinely fits rather than assumed.
///
/// @param  {String} _text       The string to fit.
/// @param  {Real}   _size       Desired cap height in pixels. Never exceeded.
/// @param  {Real}   _max_width  Width budget in pixels.
/// @param  {Real}   _tracking   Optional tracking, matching the eventual draw call.
/// @return {Real} A cap height in pixels.
function mer_text_fit_size(_text, _size, _max_width, _tracking = undefined) {
    if (_text == "" || _max_width <= 0) return _size;

    var _w = mer_text_width(_text, _size, _tracking);
    if (_w <= _max_width) return _size;

    var _s     = _size * (_max_width / _w);
    var _guard = 0;
    while (mer_text_width(_text, _s, _tracking) > _max_width && _guard < 32) {
        _s *= 0.96;
        _guard += 1;
    }
    return max(1, _s);
}

/// @func   mer_draw_text(_x, _y, _text, _size, _colour, _alpha, _tracking, _weight)
/// @desc   Draws a string in the stroke typeface. _y is the CAP TOP, not the baseline.
///
/// @remarks Joints are capped with a dot whenever the stroke is thick enough for the notch to be
///          visible. draw_line_width produces butt caps, so an unfilled corner on a letter like A
///          or M reads as a chip out of the glyph at any weight above about two pixels. Filling
///          the joint costs one circle per vertex and it is the difference between "vector text"
///          and "vector text that looks finished".
///
/// @param  {Real}   _x         Left edge of the first glyph.
/// @param  {Real}   _y         Top of the cap height.
/// @param  {String} _text      The string. Lowercase is folded to uppercase.
/// @param  {Real}   _size      Cap height in pixels.
/// @param  {Real}   _colour    BGR colour. Defaults to the theme's text colour.
/// @param  {Real}   _alpha     0 to 1.
/// @param  {Real}   _tracking  Extra pixels between glyphs. Defaults to a tenth of the cap height.
/// @param  {Real}   _weight    Stroke width in pixels. Defaults to theme.strokeWeight * _size.
/// @return {Real} The total width drawn, so callers can chain runs of text.
function mer_draw_text(_x, _y, _text, _size, _colour = undefined, _alpha = 1,
                       _tracking = undefined, _weight = undefined) {
    var _theme = mer_theme_get();
    var _font  = mer_font_get();

    var _col   = is_undefined(_colour)   ? _theme.text : _colour;
    var _scale = _size / 7;
    var _track = is_undefined(_tracking) ? (_size * 0.10) : _tracking;
    var _w     = is_undefined(_weight)   ? max(1, _size * _theme.strokeWeight) : _weight;
    var _cap   = (_w >= 2.5);                 // only worth filling joints above this
    var _rad   = _w * 0.5;

    draw_set_alpha(_alpha);
    draw_set_colour(_col);

    var _pen = _x;
    var _n   = string_length(_text);

    for (var _i = 1; _i <= _n; _i++) {
        var _c = ord(string_char_at(_text, _i));
        if (_c >= 97 && _c <= 122) _c -= 32;
        if (_c < 0 || _c > 127) _c = ord(" ");

        var _g = _font[_c];
        if (is_undefined(_g)) _g = _font[ord(" ")];

        var _strokes = _g.s;
        for (var _s = 0; _s < array_length(_strokes); _s++) {
            var _pts = _strokes[_s];
            var _np  = array_length(_pts) div 2;

            if (_np == 1) {
                // Single point: a dot. Used by . : ; ! ?
                draw_circle(_pen + _pts[0] * _scale, _y + _pts[1] * _scale, max(_rad, 1), false);
                continue;
            }

            for (var _p = 0; _p < _np - 1; _p++) {
                var _ax = _pen + _pts[_p * 2]       * _scale;
                var _ay = _y   + _pts[_p * 2 + 1]   * _scale;
                var _bx = _pen + _pts[_p * 2 + 2]   * _scale;
                var _by = _y   + _pts[_p * 2 + 3]   * _scale;

                draw_line_width(_ax, _ay, _bx, _by, _w);

                // Fill the joint to the next segment. See @remarks.
                if (_cap && _p < _np - 2) draw_circle(_bx, _by, _rad, false);
            }
        }

        _pen += _g.a * _scale + _track;
    }

    draw_set_alpha(1);
    draw_set_colour(c_white);

    return max(0, (_pen - _x) - _track);
}

/// @func   mer_draw_text_centred(_cx, _y, _text, _size, _colour, _alpha, _tracking, _weight)
/// @desc   Draws a string horizontally centred on _cx. _y is the cap top.
/// @param  {Real}   _cx        Centre x.
/// @param  {Real}   _y         Top of the cap height.
/// @param  {String} _text      The string.
/// @param  {Real}   _size      Cap height in pixels.
/// @param  {Real}   _colour    BGR colour, or undefined for the theme's text colour.
/// @param  {Real}   _alpha     0 to 1.
/// @param  {Real}   _tracking  Extra pixels between glyphs.
/// @param  {Real}   _weight    Stroke width in pixels.
/// @return {Real} The total width drawn.
function mer_draw_text_centred(_cx, _y, _text, _size, _colour = undefined, _alpha = 1,
                               _tracking = undefined, _weight = undefined) {
    var _w = mer_text_width(_text, _size, _tracking);
    return mer_draw_text(_cx - _w * 0.5, _y, _text, _size, _colour, _alpha, _tracking, _weight);
}

/// @func   mer_draw_text_right(_rx, _y, _text, _size, _colour, _alpha, _tracking, _weight)
/// @desc   Draws a string right-aligned to _rx. _y is the cap top.
/// @param  {Real}   _rx        Right edge.
/// @param  {Real}   _y         Top of the cap height.
/// @param  {String} _text      The string.
/// @param  {Real}   _size      Cap height in pixels.
/// @param  {Real}   _colour    BGR colour, or undefined for the theme's text colour.
/// @param  {Real}   _alpha     0 to 1.
/// @param  {Real}   _tracking  Extra pixels between glyphs.
/// @param  {Real}   _weight    Stroke width in pixels.
/// @return {Real} The total width drawn.
function mer_draw_text_right(_rx, _y, _text, _size, _colour = undefined, _alpha = 1,
                             _tracking = undefined, _weight = undefined) {
    var _w = mer_text_width(_text, _size, _tracking);
    return mer_draw_text(_rx - _w, _y, _text, _size, _colour, _alpha, _tracking, _weight);
}
