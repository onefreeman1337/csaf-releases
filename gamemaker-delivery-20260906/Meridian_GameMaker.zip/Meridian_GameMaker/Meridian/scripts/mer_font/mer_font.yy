{
  "$GMScript": "v1",
  "%Name": "mer_font",
  "isCompatibility": false,
  "isDnD": false,
  "name": "mer_font",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}