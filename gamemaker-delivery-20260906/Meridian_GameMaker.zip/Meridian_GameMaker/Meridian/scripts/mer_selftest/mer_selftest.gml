/// @file    mer_selftest.gml
/// @package Meridian for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary The in-engine suite. Runs headless from `Meridian.exe -selftest` and writes its result
///          to mer_selftest.json in the save area.
///
/// @remarks ⚠️ THIS IS THE ONLY REAL TEST THIS PACKAGE HAS. GML cannot be unit-tested outside the
///          engine — there is no Node-mockable core and no batch-mode harness. Verification risk
///          here is structurally higher than in a C# or C++ package and saying otherwise would be
///          the dishonesty this factory forbids. What compensates is that Meridian's logic is
///          deliberately pure: the graph, the layout, the validator and the exporter make no draw
///          calls and read no input, so almost all of it can be asserted on directly, right here.
///
///          ⛔ WHAT THIS SUITE CANNOT SEE, stated plainly because a large green number is exactly
///          how a wing talks itself out of looking. A sibling product in this wing passed 164/164
///          with its ENTIRE TEXT LAYER DEAD, because not one of its assertions drew a string. Every
///          assertion below computes numbers and strings. NONE of them draws a pixel. The drawing
///          is covered by baking the store sheets and LOOKING at them, which is a separate step and
///          is the only thing that has ever caught a geometry defect in this wing.
///
///          ⛔ A GML RUNTIME ERROR OPENS A MODAL DIALOG, so headless the process never exits — an
///          opaque hang with no output. The demo object installs exception_unhandled_handler before
///          anything else, and every stage writes its number to a GLOBAL so a crash reports WHERE.
///          The stage must go to the global and not only to the local struct: a sibling product set
///          only the local, so the crash handler reported "stage 1" for a crash anywhere at all.
///          An instrument that always answers 1 is not reporting, it is agreeing.

/// ⚠️ TOLERANCE FLOOR. GML applies a default epsilon to numeric comparisons, measured by this wing
/// at 0.00001 off a real Igor-built exe. A tolerance at or below it is unusable in both directions.
/// And GML has no exponent-literal syntax: `1e-5` is a lexer error that reads like a bracket bug.
#macro MER_ST_EPS 0.0001

/// @func   mer_st_assert(_st, _cond, _msg)
/// @desc   One assertion.
/// @param  {Struct} _st    The suite state.
/// @param  {Bool}   _cond  What must be true.
/// @param  {String} _msg   What it means if it is not.
/// @return {Bool} _cond.
function mer_st_assert(_st, _cond, _msg) {
    _st.total += 1;
    if (_cond) { _st.pass += 1; return true; }
    _st.fail += 1;
    if (array_length(_st.failures) < 40) array_push(_st.failures, "stage " + string(_st.stage) + ": " + _msg);
    return false;
}

/// @func   mer_st_stage(_st, _n)
/// @desc   Marks which stage is running, in the struct AND in the global the crash handler reads.
/// @param  {Struct} _st  The suite state.
/// @param  {Real}   _n   Stage number.
function mer_st_stage(_st, _n) {
    _st.stage = _n;
    global.mer_stage = _n;
}

/// @func   mer_st_fixture()
/// @desc   A small, deliberately awkward tree the suite can edit without touching the demo's.
///
/// @remarks Shaped to EXHIBIT the things under test: a diamond (so a cycle refusal has something to
///          refuse), a node with two prerequisites (so a delete has more than one reference to
///          sweep), and a quote in a description (so the exporter's escaping is exercised rather
///          than assumed). A fixture that cannot exhibit the defect proves nothing about the check.
///
/// @return {Struct} A tree.
function mer_st_fixture() {
    var _t = mer_tree_make();
    mer_tree_add(_t, "root",  { name: "ROOT",  sigil: 0, disc: 0, tier: MER_TIER_MAJOR, cost: 1, maxRank: 1, requires: [] });
    mer_tree_add(_t, "left",  { name: "LEFT",  sigil: 1, disc: 1, tier: MER_TIER_MINOR, cost: 1, maxRank: 3, requires: ["root"] });
    mer_tree_add(_t, "right", { name: "RIGHT", sigil: 2, disc: 2, tier: MER_TIER_MINOR, cost: 1, maxRank: 2, requires: ["root"] });
    mer_tree_add(_t, "join",  { name: "JOIN",  sigil: 3, disc: 3, tier: MER_TIER_KEYSTONE, cost: 3, maxRank: 1,
                                requires: ["left", "right"], stat: "power", value: 9,
                                desc: "A \"quoted\" description, on purpose." });
    return _t;
}

/// @func   mer_selftest_run()
/// @desc   Runs every stage and returns the result.
/// @return {Struct} {total, pass, fail, stage, failures, notes}.
function mer_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: [] };

    // == STAGE 1: the runtime is the one we think it is ============================================
    // ⛔ A POSITIVE TEST ON PURPOSE. The natural form `_e > 0 && _e < TOL` goes red on its first
    // clause: the difference between the epsilon and zero IS the epsilon, so GML calls them equal,
    // and equal is not greater-than. Do not "repair" this into one clause.
    mer_st_stage(_st, 1);
    var _e = math_get_epsilon();
    mer_st_assert(_st, !(_e > MER_ST_EPS), "default epsilon larger than this suite's tolerance: " + string(_e));

    // == STAGE 2: THE CORPUS CLAIM ================================================================
    // CLAIM, and it is the number in the listing copy: "60 motifs across 8 disciplines = 480 marks".
    // Asserted against the TABLES, never against a macro. This wing has shipped a live page claiming
    // a pack was half its real size because the checker held the same stale number the page did.
    mer_st_stage(_st, 2);
    var _sc = mer_sigil_count();
    var _dc = mer_discipline_count();
    mer_st_assert(_st, _sc == 60, "motif corpus is " + string(_sc) + ", the listing says 60");
    mer_st_assert(_st, _dc == 8, "discipline count is " + string(_dc) + ", the listing says 8");
    mer_st_assert(_st, mer_sigil_variant_count() == _sc * _dc,
                  "variant count " + string(mer_sigil_variant_count()) + " is not motifs x disciplines");
    mer_st_assert(_st, mer_sigil_variant_count() == 480,
                  "variant count is " + string(mer_sigil_variant_count()) + ", the listing says 480");
    array_push(_st.notes, "corpus " + string(_sc) + " x " + string(_dc) + " = " + string(_sc * _dc));

    // Every motif must have a name and shapes. An empty motif draws nothing and would be an
    // invisible node in a buyer's tree — the kind of hole a count never reveals.
    mer_st_stage(_st, 3);
    var _sigils = mer_sigil_get();
    var _emptyShapes = 0;
    var _blankNames = 0;
    for (var _i = 0; _i < array_length(_sigils); _i++) {
        if (array_length(_sigils[_i].s) == 0) _emptyShapes += 1;
        if (string_length(_sigils[_i].n) == 0) _blankNames += 1;
    }
    mer_st_assert(_st, _emptyShapes == 0, string(_emptyShapes) + " motif(s) have no shapes and would draw nothing");
    mer_st_assert(_st, _blankNames == 0, string(_blankNames) + " motif(s) have no name");

    // Motif names must be DISTINCT, because mer_tree_add resolves a named sigil through
    // mer_sigil_find, which returns the first match. Two motifs sharing a name makes one of them
    // unreachable by name for every buyer, silently.
    mer_st_stage(_st, 4);
    var _seen = {};
    var _dupes = 0;
    for (var _i = 0; _i < array_length(_sigils); _i++) {
        var _n = _sigils[_i].n;
        if (variable_struct_exists(_seen, _n)) _dupes += 1;
        variable_struct_set(_seen, _n, true);
    }
    mer_st_assert(_st, _dupes == 0, string(_dupes) + " duplicate motif name(s): mer_sigil_find would shadow one");

    // == STAGE 5: ARMATURE — adding ===============================================================
    mer_st_stage(_st, 5);
    var _t = mer_st_fixture();
    mer_st_assert(_st, mer_tree_count(_t) == 4, "fixture should have 4 nodes, has " + string(mer_tree_count(_t)));

    var _newId = mer_forge_new_id(_t, "root");
    mer_st_assert(_st, _newId != "root", "mer_forge_new_id handed back an id already in the tree");
    mer_st_assert(_st, !variable_struct_exists(_t.byId, _newId), "generated id " + _newId + " already exists");

    var _added = mer_forge_add(undefined, _t, { id: "extra", name: "EXTRA", requires: ["root"] });
    mer_st_assert(_st, _added == "extra", "add returned '" + string(_added) + "'");
    mer_st_assert(_st, mer_tree_count(_t) == 5, "after add the tree should hold 5 nodes");

    // == STAGE 6: ARMATURE — deleting sweeps the references =======================================
    // THE CLAIM THIS DEFENDS: deleting a node deletes the edges INTO it, in the same operation.
    // Without the sweep, children are left requiring an id that is not in the tree and become
    // permanently unbuyable — a tree that loads, draws and looks correct with a dead branch in it.
    mer_st_stage(_st, 6);
    var _swept = mer_forge_remove(_t, "root");
    mer_st_assert(_st, _swept == 3, "deleting root should sweep 3 references (left, right, extra), swept " + string(_swept));
    mer_st_assert(_st, mer_tree_count(_t) == 4, "after delete the tree should hold 4 nodes");
    mer_st_assert(_st, is_undefined(mer_tree_get(_t, "root")), "root is still retrievable after deletion");

    var _dangling = 0;
    for (var _i = 0; _i < mer_tree_count(_t); _i++) {
        var _req = _t.nodes[_i].requires;
        for (var _r = 0; _r < array_length(_req); _r++) {
            if (!variable_struct_exists(_t.byId, _req[_r])) _dangling += 1;
        }
    }
    mer_st_assert(_st, _dangling == 0, string(_dangling) + " dangling prerequisite(s) survived the delete");

    // byId must still address the right rows after the rebuild — an off-by-one here would return
    // the WRONG NODE for every lookup past the deleted index, which is worse than a crash.
    for (var _i = 0; _i < mer_tree_count(_t); _i++) {
        var _node = _t.nodes[_i];
        mer_st_assert(_st, variable_struct_get(_t.byId, _node.id) == _i,
                      "byId['" + _node.id + "'] points at the wrong row after delete");
    }

    mer_st_assert(_st, mer_forge_remove(_t, "no_such_node") == -1, "removing an absent id should report -1");

    // == STAGE 7: ARMATURE — linking, and the cycle refusal =======================================
    mer_st_stage(_st, 7);
    var _t2 = mer_st_fixture();

    var _r1 = mer_forge_link(_t2, "root", "join");
    mer_st_assert(_st, _r1.ok, "linking root -> join should succeed, got: " + _r1.reason);
    var _r2 = mer_forge_link(_t2, "root", "join");
    mer_st_assert(_st, !_r2.ok, "linking the same edge twice should be refused");

    var _r3 = mer_forge_link(_t2, "join", "join");
    mer_st_assert(_st, !_r3.ok, "a node requiring itself should be refused");

    // The load-bearing one: join already depends on left, so left depending on join closes a loop.
    var _r4 = mer_forge_link(_t2, "join", "left");
    mer_st_assert(_st, !_r4.ok, "closing a cycle should be REFUSED, got ok with reason: " + _r4.reason);
    mer_st_assert(_st, string_pos("cycle", _r4.reason) > 0, "the cycle refusal should say cycle, said: " + _r4.reason);

    // ...and the refusal must not have half-applied. A guard that rejects AFTER mutating is worse
    // than no guard, because the tree is now in the state the guard exists to prevent.
    mer_st_assert(_st, mer_tree_compute_depth(_t2), "the graph acquired a cycle despite the refusal");

    mer_st_assert(_st, mer_forge_unlink(_t2, "root", "join"), "unlink should report that it removed an edge");
    mer_st_assert(_st, !mer_forge_unlink(_t2, "root", "join"), "unlinking twice should report nothing removed");

    // Toggle is the gesture the editor binds to a drag: it must go both ways from one call.
    var _tg1 = mer_forge_toggle_link(_t2, "root", "join");
    mer_st_assert(_st, _tg1.ok && _tg1.reason == "linked", "toggle on an absent edge should link");
    var _tg2 = mer_forge_toggle_link(_t2, "root", "join");
    mer_st_assert(_st, _tg2.ok && _tg2.reason == "unlinked", "toggle on a present edge should unlink");

    // == STAGE 8: reachability, on a graph that already has a cycle ================================
    // mer_forge_reaches is called BY the cycle guard, so it must survive being called on a cyclic
    // graph. A recursive walk would not return, and the failure mode is a hang rather than a red.
    mer_st_stage(_st, 8);
    var _t3 = mer_st_fixture();
    mer_st_assert(_st, mer_forge_reaches(_t3, "root", "join"), "root should reach join");
    mer_st_assert(_st, !mer_forge_reaches(_t3, "join", "root"), "join should NOT reach root");
    mer_st_assert(_st, mer_forge_reaches(_t3, "left", "left"), "a node reaches itself");

    // Force a real cycle in past the guard, the way a hand-edited file or a bad import would.
    var _leftNode = mer_tree_get(_t3, "left");
    _leftNode.requires = ["join"];
    mer_st_assert(_st, mer_forge_reaches(_t3, "join", "left"), "reaches should still answer on a cyclic graph");
    mer_st_assert(_st, !mer_tree_compute_depth(_t3), "compute_depth should report the forced cycle");

    // == STAGE 9: VALIDATION finds each fault, and finds nothing on a clean tree ===================
    mer_st_stage(_st, 9);
    var _clean = mer_st_fixture();
    var _vc = mer_forge_validate(_clean);
    mer_st_assert(_st, _vc.ok, "a clean fixture reported " + string(array_length(_vc.problems)) + " problem(s)");
    mer_st_assert(_st, _vc.roots == 1, "the fixture has one root, validate said " + string(_vc.roots));
    mer_st_assert(_st, _vc.nodes == 4, "validate counted " + string(_vc.nodes) + " nodes, expected 4");

    // Each fault, one at a time, on its own tree — so a pass cannot be a different fault firing.
    var _fd = mer_st_fixture();
    mer_tree_get(_fd, "join").requires = ["left", "ghost"];
    var _vd = mer_forge_validate(_fd);
    mer_st_assert(_st, !_vd.ok, "a dangling prerequisite was not reported");
    mer_st_assert(_st, mer_st_has_kind(_vd, "dangling"), "the dangling fault was reported under the wrong kind");

    var _fs = mer_st_fixture();
    mer_tree_get(_fs, "left").sigil = 9999;
    var _vs = mer_forge_validate(_fs);
    mer_st_assert(_st, !_vs.ok, "an out-of-corpus motif index was not reported");
    mer_st_assert(_st, mer_st_has_kind(_vs, "sigil"), "the motif fault was reported under the wrong kind");

    var _fc = mer_st_fixture();
    mer_tree_get(_fc, "root").requires = ["join"];
    var _vcy = mer_forge_validate(_fc);
    mer_st_assert(_st, !_vcy.ok, "a cycle was not reported");
    mer_st_assert(_st, mer_st_has_kind(_vcy, "cycle"), "the cycle was reported under the wrong kind");
    mer_st_assert(_st, mer_st_has_kind(_vcy, "noroot"), "a fully-cyclic graph also has no root and that was not reported");

    // == STAGE 10: REPAIR fixes what it can and REFUSES what it must not guess at ==================
    // The second half is the important half. A guard that FABRICATES a value when it cannot find a
    // good one encodes a design decision nobody made, and that is a defect even when the value is
    // plausible. Repair must leave cycles and rootlessness alone.
    mer_st_stage(_st, 10);
    var _fr = mer_st_fixture();
    mer_tree_get(_fr, "join").requires = ["left", "ghost"];
    mer_tree_get(_fr, "right").sigil = -7;
    var _rep = mer_forge_repair(_fr);
    mer_st_assert(_st, _rep.changed == 2, "repair should have made 2 changes, made " + string(_rep.changed));
    mer_st_assert(_st, mer_forge_validate(_fr).ok, "repair left the tree still invalid");
    mer_st_assert(_st, mer_tree_get(_fr, "right").sigil >= 0 && mer_tree_get(_fr, "right").sigil < _sc,
                  "repair left the motif index outside the corpus");

    var _fr2 = mer_st_fixture();
    mer_tree_get(_fr2, "root").requires = ["join"];
    var _rep2 = mer_forge_repair(_fr2);
    mer_st_assert(_st, _rep2.changed == 0, "repair must not silently break a cycle, it made " + string(_rep2.changed) + " change(s)");
    mer_st_assert(_st, !mer_forge_validate(_fr2).ok, "the cycle should still be reported after repair declines it");

    // == STAGE 11: THE EXPORT CARRIES PARAMETERS, NOT PIXELS =======================================
    // ⭐ THIS IS THE CLAIM THE WHOLE FEATURE RESTS ON. An exported tree must regenerate its own
    // artwork in the buyer's game, which is only true if the export carries the motif and
    // discipline INDICES and no reference to any baked image. Asserted on the emitted text.
    mer_st_stage(_st, 11);
    var _ex = mer_st_fixture();
    var _gml = mer_forge_export_gml(_ex, "build_skill_tree");

    mer_st_assert(_st, string_length(_gml) > 200, "the export is only " + string(string_length(_gml)) + " characters long");
    mer_st_assert(_st, mer_st_count(_gml, "mer_tree_add(") == 4,
                  "export emitted " + string(mer_st_count(_gml, "mer_tree_add(")) + " add calls for 4 nodes");
    mer_st_assert(_st, string_pos("function build_skill_tree()", _gml) > 0, "the export has no wrapper function");
    mer_st_assert(_st, string_pos("mer_tree_make()", _gml) > 0, "the export never makes a tree");
    mer_st_assert(_st, string_pos("return _t;", _gml) > 0, "the export never returns the tree");

    // Every node's two integers must appear.
    for (var _i = 0; _i < mer_tree_count(_ex); _i++) {
        var _node = _ex.nodes[_i];
        mer_st_assert(_st, string_pos("sigil: " + string(_node.sigil) + ",", _gml) > 0,
                      "node " + _node.id + "'s motif index is not in the export");
        mer_st_assert(_st, string_pos("\"" + _node.id + "\"", _gml) > 0,
                      "node " + _node.id + "'s id is not in the export");
    }

    // Tier macros rather than bare integers, so the generated source is maintainable.
    mer_st_assert(_st, string_pos("MER_TIER_KEYSTONE", _gml) > 0, "the keystone node exported as a bare integer");
    mer_st_assert(_st, string_pos("MER_TIER_MAJOR", _gml) > 0, "the major node exported as a bare integer");

    // ⛔ AND NOT ONE REFERENCE TO A PICTURE. This is the negative half and it is the one that makes
    // the positive half mean anything: an export that carried BOTH indices and a sprite path would
    // pass every assertion above.
    mer_st_assert(_st, string_pos("sprite", _gml) == 0, "the export mentions a sprite");
    mer_st_assert(_st, string_pos(".png", _gml) == 0, "the export references a png");
    mer_st_assert(_st, string_pos("atlas", _gml) == 0, "the export references an atlas");
    mer_st_assert(_st, string_pos("surface", _gml) == 0, "the export references a surface");

    // The quote in the fixture's description must have been made literal-safe, or the generated
    // source does not compile — the one outcome an exporter must never produce.
    mer_st_assert(_st, string_pos("A 'quoted' description", _gml) > 0, "the exporter did not fold the embedded quote");
    var _quotes = mer_st_count(_gml, "\"");
    mer_st_assert(_st, (_quotes % 2) == 0, "the export has an odd number of quote characters (" + string(_quotes) + ")");

    // == STAGE 12: JSON ROUND-TRIP IS FIELD-IDENTICAL ==============================================
    // A save format that loses a field loses a buyer's work. Compared field by field rather than by
    // string equality, because two different serialisations can both be correct.
    mer_st_stage(_st, 12);
    var _json = mer_forge_export_json(_ex);
    var _back = mer_forge_import_json(_json);
    mer_st_assert(_st, !is_undefined(_back), "the exported JSON did not import back");

    if (!is_undefined(_back)) {
        mer_st_assert(_st, mer_tree_count(_back) == mer_tree_count(_ex),
                      "round trip changed the node count: " + string(mer_tree_count(_back)) + " vs " + string(mer_tree_count(_ex)));
        var _mismatch = 0;
        for (var _i = 0; _i < mer_tree_count(_ex); _i++) {
            var _a = _ex.nodes[_i];
            var _b = mer_tree_get(_back, _a.id);
            if (is_undefined(_b)) { _mismatch += 1; continue; }
            if (_b.sigil != _a.sigil) _mismatch += 1;
            if (_b.disc != _a.disc) _mismatch += 1;
            if (_b.tier != _a.tier) _mismatch += 1;
            if (_b.cost != _a.cost) _mismatch += 1;
            if (_b.maxRank != _a.maxRank) _mismatch += 1;
            if (_b.value != _a.value) _mismatch += 1;
            if (_b.name != _a.name) _mismatch += 1;
            if (array_length(_b.requires) != array_length(_a.requires)) _mismatch += 1;
        }
        mer_st_assert(_st, _mismatch == 0, string(_mismatch) + " field(s) differ after a JSON round trip");

        // ⭐ THE STEP-2 CLAIM, ASSERTED IN THE ENGINE ON A ROUND-TRIPPED TREE: every node that came
        // back through the save format still indexes a real motif, so mer_sigil_draw will draw a
        // GENERATED mark for every one of them. This is what "the exported tree still renders the
        // 480 marks" means operationally, and it is checked rather than argued.
        var _outOfCorpus = 0;
        for (var _i = 0; _i < mer_tree_count(_back); _i++) {
            var _node = _back.nodes[_i];
            if (_node.sigil < 0 || _node.sigil >= _sc) _outOfCorpus += 1;
            if (_node.disc < 0 || _node.disc >= _dc) _outOfCorpus += 1;
        }
        mer_st_assert(_st, _outOfCorpus == 0,
                      string(_outOfCorpus) + " round-tripped node(s) index outside the generated corpus");
    }

    // Malformed input must be refused, not half-loaded.
    mer_st_assert(_st, is_undefined(mer_forge_import_json("not json at all")), "garbage imported as a tree");
    mer_st_assert(_st, is_undefined(mer_forge_import_json("{\"format\":\"x\"}")), "a document with no nodes imported as a tree");

    // == STAGE 13: FIELD STEPPING WRAPS AND CLAMPS AS DOCUMENTED ===================================
    mer_st_stage(_st, 13);
    var _fs2 = mer_st_fixture();
    var _n0 = mer_tree_get(_fs2, "root");

    _n0.sigil = _sc - 1;
    mer_forge_step_field(_fs2, "root", MER_FORGE_FIELD_SIGIL, 1);
    mer_st_assert(_st, _n0.sigil == 0, "motif should wrap past the end of the corpus, got " + string(_n0.sigil));
    mer_forge_step_field(_fs2, "root", MER_FORGE_FIELD_SIGIL, -1);
    mer_st_assert(_st, _n0.sigil == _sc - 1, "motif should wrap backwards past zero, got " + string(_n0.sigil));

    _n0.disc = _dc - 1;
    mer_forge_step_field(_fs2, "root", MER_FORGE_FIELD_DISC, 1);
    mer_st_assert(_st, _n0.disc == 0, "discipline should wrap, got " + string(_n0.disc));

    // Tier CLAMPS rather than wraps: wrapping a keystone to a minor on one keypress is destructive.
    _n0.tier = MER_TIER_KEYSTONE;
    mer_forge_step_field(_fs2, "root", MER_FORGE_FIELD_TIER, 1);
    mer_st_assert(_st, _n0.tier == MER_TIER_KEYSTONE, "tier wrapped instead of clamping at the top");
    _n0.tier = MER_TIER_MINOR;
    mer_forge_step_field(_fs2, "root", MER_FORGE_FIELD_TIER, -1);
    mer_st_assert(_st, _n0.tier == MER_TIER_MINOR, "tier wrapped instead of clamping at the bottom");

    _n0.cost = 0;
    mer_forge_step_field(_fs2, "root", MER_FORGE_FIELD_COST, -1);
    mer_st_assert(_st, _n0.cost == 0, "cost went below zero");
    _n0.maxRank = 1;
    mer_forge_step_field(_fs2, "root", MER_FORGE_FIELD_RANK, -1);
    mer_st_assert(_st, _n0.maxRank == 1, "max rank went below one, which would make a node unbuyable");

    mer_st_assert(_st, !mer_forge_step_field(_fs2, "no_such_node", MER_FORGE_FIELD_SIGIL, 1),
                  "stepping a field on a missing node reported success");

    // Every field must have a distinct label, or the inspector shows two rows that read the same.
    var _labels = {};
    var _dupLabels = 0;
    for (var _i = 0; _i < MER_FORGE_FIELD_COUNT; _i++) {
        var _lab = mer_forge_field_name(_i);
        mer_st_assert(_st, _lab != "?", "field " + string(_i) + " has no label");
        if (variable_struct_exists(_labels, _lab)) _dupLabels += 1;
        variable_struct_set(_labels, _lab, true);
        mer_st_assert(_st, mer_forge_field_value(_fs2, "root", _i) != "-",
                      "field " + _lab + " renders as an empty dash on a real node");
    }
    mer_st_assert(_st, _dupLabels == 0, string(_dupLabels) + " inspector field(s) share a label");

    // == STAGE 14: THE LAYOUTS ALL STILL DERIVE, ON AN EDITED TREE =================================
    // Armature's pitch is that the layout re-derives as you wire the graph up. So every layout must
    // produce finite, distinct positions on a tree that has just been edited — not only on the
    // hand-authored demo tree the layouts were written against.
    mer_st_stage(_st, 14);
    var _lt = mer_st_fixture();
    mer_forge_add(undefined, _lt, { id: "e1", name: "E1", requires: ["left"] });
    mer_forge_add(undefined, _lt, { id: "e2", name: "E2", requires: ["left"] });
    mer_forge_add(undefined, _lt, { id: "e3", name: "E3", requires: ["right"] });

    mer_st_assert(_st, mer_layout_count() == 4, "layout count is " + string(mer_layout_count()) + ", expected 4");
    for (var _l = 0; _l < mer_layout_count(); _l++) {
        mer_layout_apply(_l, _lt);
        var _name = mer_layout_name(_l);
        mer_st_assert(_st, string_length(_name) > 0, "layout " + string(_l) + " has no name");

        var _finite = true;
        var _overlaps = 0;
        for (var _i = 0; _i < mer_tree_count(_lt); _i++) {
            var _a = _lt.nodes[_i];
            if (is_nan(_a.lx) || is_nan(_a.ly) || is_infinity(_a.lx) || is_infinity(_a.ly)) _finite = false;
            for (var _j = _i + 1; _j < mer_tree_count(_lt); _j++) {
                var _b = _lt.nodes[_j];
                if (point_distance(_a.lx, _a.ly, _b.lx, _b.ly) < MER_ST_EPS) _overlaps += 1;
            }
        }
        mer_st_assert(_st, _finite, "layout " + _name + " produced a non-finite position");
        mer_st_assert(_st, _overlaps == 0, "layout " + _name + " stacked " + string(_overlaps) + " node pair(s) on one point");

        var _b2 = mer_tree_bounds(_lt);
        mer_st_assert(_st, _b2.w > 0 && _b2.h > 0, "layout " + _name + " produced a zero-area tree");
    }

    // == STAGE 15: THE PROGRESSION RULES STILL HOLD AFTER EDITING ==================================
    // Editing the graph must not be able to produce a tree whose economy is broken — the check that
    // ties Armature back to the runtime it feeds.
    // ⛔⛔ EVERY COMPARISON BELOW IS AGAINST THE MACRO, NEVER AGAINST TRUTH. `MER_UNLOCK_OK` is 0,
    // which is FALSY, so `if (mer_progress_can_unlock(...))` means "cannot be unlocked" and reads
    // as the opposite. That inversion was written into mer_forge_unlock_all and into the first
    // draft of this very stage on the same afternoon: in the editor it HUNG a headless build (a
    // truthy MAXED code spinning a while loop forever, no crash, no output, killed on a timeout),
    // and here it would have quietly asserted the reverse of every sentence in the messages.
    // The first line of this stage now pins the constant itself, so if the contract ever changes
    // this goes red with a clear reason instead of every assertion below flipping meaning.
    mer_st_stage(_st, 15);
    mer_st_assert(_st, MER_UNLOCK_OK == 0, "MER_UNLOCK_OK is no longer 0 — every truthiness assumption about it must be re-read");
    mer_st_assert(_st, MER_UNLOCK_LOCKED != 0 && MER_UNLOCK_NO_POINTS != 0 && MER_UNLOCK_MAXED != 0,
                  "a failure code became 0, so success and failure are no longer distinguishable by value");

    var _pt = mer_st_fixture();
    var _prog = mer_progress_make(0);
    mer_st_assert(_st, mer_progress_can_unlock(_pt, _prog, "root") == MER_UNLOCK_NO_POINTS,
                  "root should be unaffordable with zero points, got code " + string(mer_progress_can_unlock(_pt, _prog, "root")));
    mer_progress_grant(_prog, 10);
    mer_st_assert(_st, mer_progress_can_unlock(_pt, _prog, "root") == MER_UNLOCK_OK,
                  "root should be buyable with ten points, got code " + string(mer_progress_can_unlock(_pt, _prog, "root")));
    mer_st_assert(_st, mer_progress_can_unlock(_pt, _prog, "join") == MER_UNLOCK_LOCKED,
                  "join should be locked before its prerequisites, got code " + string(mer_progress_can_unlock(_pt, _prog, "join")));

    mer_st_assert(_st, mer_progress_unlock(_pt, _prog, "root") == MER_UNLOCK_OK, "buying root failed");
    mer_st_assert(_st, mer_progress_unlock(_pt, _prog, "left") == MER_UNLOCK_OK, "buying left failed");
    mer_st_assert(_st, mer_progress_unlock(_pt, _prog, "right") == MER_UNLOCK_OK, "buying right failed");
    mer_st_assert(_st, mer_progress_can_unlock(_pt, _prog, "join") == MER_UNLOCK_OK,
                  "join should be buyable with both prerequisites bought, got code " + string(mer_progress_can_unlock(_pt, _prog, "join")));

    // A maxed node must report MAXED rather than OK forever — this is the exact code whose
    // truthiness spun the editor's unlock-all, so it is asserted by value here.
    var _mx = mer_tree_get(_pt, "left");
    var _spin = _mx.maxRank + 4;
    while (_spin > 0 && mer_progress_can_unlock(_pt, _prog, "left") == MER_UNLOCK_OK) {
        mer_progress_unlock(_pt, _prog, "left");
        _spin -= 1;
    }
    mer_st_assert(_st, mer_progress_can_unlock(_pt, _prog, "left") == MER_UNLOCK_MAXED,
                  "a fully-bought node should report MAXED, got code " + string(mer_progress_can_unlock(_pt, _prog, "left")));
    mer_st_assert(_st, mer_progress_rank(_prog, "left") == _mx.maxRank,
                  "a fully-bought node sits at rank " + string(mer_progress_rank(_prog, "left")) + ", expected " + string(_mx.maxRank));

    // And the editor's own unlock-all must reach every node, or the editor shows a greyed tree.
    var _ut = mer_st_fixture();
    var _uprog = mer_progress_make(0);
    mer_forge_unlock_all(_ut, _uprog);
    var _locked = 0;
    for (var _i = 0; _i < mer_tree_count(_ut); _i++) {
        if (mer_progress_rank(_uprog, _ut.nodes[_i].id) <= 0) _locked += 1;
    }
    mer_st_assert(_st, _locked == 0, string(_locked) + " node(s) stayed locked in the editor's unlock-all");

    // == STAGE 16: EXPORT SCALES, AND STAYS DETERMINISTIC ==========================================
    // A buyer keeps the exported file in version control. Two exports of an unchanged tree that
    // differ would make every diff useless.
    mer_st_stage(_st, 16);
    var _big = mer_tree_make();
    mer_tree_add(_big, "r", { name: "R", requires: [] });
    for (var _i = 0; _i < 60; _i++) {
        mer_tree_add(_big, "n" + string(_i), { name: "N" + string(_i), sigil: _i % _sc, disc: _i % _dc, requires: ["r"] });
    }
    var _g1 = mer_forge_export_gml(_big, "big_tree");
    var _g2 = mer_forge_export_gml(_big, "big_tree");
    mer_st_assert(_st, _g1 == _g2, "two exports of an unchanged tree differ");
    mer_st_assert(_st, mer_st_count(_g1, "mer_tree_add(") == 61,
                  "the 61-node export emitted " + string(mer_st_count(_g1, "mer_tree_add(")) + " calls");
    mer_st_assert(_st, mer_forge_validate(_big).ok, "the generated 61-node tree does not validate");

    // == STAGE 17: THE PACKAGE'S OWN NAMESPACE ====================================================
    // Every public symbol this package adds is prefixed. GML's global namespace is flat, so an
    // unprefixed helper shipped in a package silently collides inside the BUYER'S project, where it
    // cannot be debugged remotely. The first draft of mer_forge.gml shipped a `string_trim_left`
    // and this stage is why it did not survive.
    mer_st_stage(_st, 17);
    mer_st_assert(_st, is_callable(mer_forge_trim_left), "the trim helper is not under the mer_forge_ prefix");
    mer_st_assert(_st, mer_forge_trim_left("   hello") == "hello", "trim helper did not strip leading spaces");
    mer_st_assert(_st, mer_forge_trim_left("hello") == "hello", "trim helper damaged a string with no leading spaces");
    mer_st_assert(_st, mer_forge_trim_left("") == "", "trim helper did not survive an empty string");
    mer_st_assert(_st, mer_forge_trim_left("   ") == "", "trim helper did not survive an all-space string");

    // == STAGE 18: THE STARTER TREE ARMATURE OPENS ON ============================================
    // ⛔ IT NAMES ITS MOTIFS AS STRINGS, AND A TYPO IN ONE SELF-HEALS SILENTLY. mer_tree_add falls
    // back from an unresolved name to a name match and then to a hash of the id, so a misspelled
    // "VIGOUR" does not error, does not warn, and quietly gives that node a motif chosen by
    // arithmetic. The tree would still look fine — which is exactly why it needs asserting rather
    // than eyeballing.
    mer_st_stage(_st, 18);
    var _starter = mer_forge_starter_tree();
    mer_st_assert(_st, mer_tree_count(_starter) == 6, "the starter tree has " + string(mer_tree_count(_starter)) + " nodes, expected 6");
    mer_st_assert(_st, mer_forge_validate(_starter).ok, "the tree Armature opens on does not validate");

    var _wantNames = ["FOCUS", "CLEAVE", "VIGOR", "GUARD", "MEND", "RENEW"];
    for (var _i = 0; _i < array_length(_wantNames); _i++) {
        mer_st_assert(_st, mer_sigil_find(_wantNames[_i]) >= 0,
                      "the starter tree asks for motif '" + _wantNames[_i] + "', which is not in the corpus");
    }

    // Every starter node must land on the motif its NAME asked for, not on a hash fallback.
    var _starterIds = ["root", "might", "vitality", "guard", "mend", "keystone"];
    for (var _i = 0; _i < array_length(_starterIds); _i++) {
        var _sn = mer_tree_get(_starter, _starterIds[_i]);
        mer_st_assert(_st, !is_undefined(_sn), "starter node '" + _starterIds[_i] + "' is missing");
        if (!is_undefined(_sn)) {
            mer_st_assert(_st, _sn.sigil == mer_sigil_find(_wantNames[_i]),
                          "starter node " + _starterIds[_i] + " fell back to motif " + string(_sn.sigil) +
                          " instead of resolving '" + _wantNames[_i] + "'");
        }
    }

    // It has to survive the whole editing surface without a crash or an invalid state, because
    // this is the exact tree every buyer's first ten keystrokes land on.
    var _sf = mer_forge_make(_starter);
    mer_forge_add(_sf, _starter, { name: "ADDED", requires: ["keystone"] });
    mer_forge_step_field(_starter, _sf.selected, MER_FORGE_FIELD_SIGIL, 7);
    mer_forge_step_field(_starter, _sf.selected, MER_FORGE_FIELD_DISC, 3);
    mer_forge_layout_cycle(_sf, _starter, 1);
    mer_forge_remove(_starter, "might");
    mer_forge_touch(_sf, _starter);
    mer_st_assert(_st, mer_forge_validate(_starter).ok, "the starter tree broke under an ordinary editing sequence");
    mer_st_assert(_st, string_length(mer_forge_export_gml(_starter, "t")) > 100, "the edited starter tree exported nothing");

    // == STAGE 19: AN EMPTY TREE IS NOT A CRASH ===================================================
    // The N key hands the editor a tree with one node, and a delete can take it to zero. Every
    // pure entry point has to survive that, because "the user deleted everything" is the first
    // thing anyone tries.
    mer_st_stage(_st, 19);
    var _empty = mer_tree_make();
    var _ve = mer_forge_validate(_empty);
    mer_st_assert(_st, _ve.ok, "an empty tree reported a problem: " + (array_length(_ve.problems) > 0 ? _ve.problems[0].text : ""));
    mer_st_assert(_st, _ve.nodes == 0, "an empty tree counted " + string(_ve.nodes) + " nodes");
    mer_st_assert(_st, mer_forge_repair(_empty).changed == 0, "repair changed something in an empty tree");
    var _eg = mer_forge_export_gml(_empty, "empty_tree");
    mer_st_assert(_st, mer_st_count(_eg, "mer_tree_add(") == 0, "the empty export emitted an add call");
    mer_st_assert(_st, string_pos("return _t;", _eg) > 0, "the empty export is not still valid GML");
    var _eb = mer_forge_import_json(mer_forge_export_json(_empty));
    mer_st_assert(_st, !is_undefined(_eb) && mer_tree_count(_eb) == 0, "an empty tree did not round trip");
    mer_st_assert(_st, mer_forge_new_id(_empty, "node") == "node1", "id generation failed on an empty tree");

    // == STAGE 20: EVERY CAPTURE POSE SELECTS SOMETHING REAL =====================================
    // ⛔ A POSE THAT QUIETLY SELECTS NOTHING STILL PRODUCES A PERFECTLY VALID PNG — of an empty
    // inspector. Nothing downstream complains: the file exists, it is the right size, it is not
    // blank, and it goes in the gallery. This wing has shipped store images that passed every
    // mechanical check and were wrong, so the poses are asserted here rather than trusted to the
    // moment somebody looks at six pictures.
    //
    // ⚠️ This does NOT check that the pose LOOKS right. Nothing in this file can. The images are
    // opened and looked at as a separate, mandatory step.
    mer_st_stage(_st, 20);
    var _pt2 = mer_forge_starter_tree();
    var _pf = mer_forge_make(_pt2);
    mer_st_assert(_st, mer_forge_pose_count() == 6, "pose count is " + string(mer_forge_pose_count()) + ", expected 6");

    var _poseNames = {};
    for (var _i = 0; _i < mer_forge_pose_count(); _i++) {
        mer_st_assert(_st, mer_forge_pose(_pf, _pt2, _i, 480, 360), "pose " + string(_i) + " refused to apply");

        var _pname = mer_forge_pose_name(_i);
        mer_st_assert(_st, string_length(_pname) > 0, "pose " + string(_i) + " has no name");
        mer_st_assert(_st, !variable_struct_exists(_poseNames, _pname),
                      "two poses share the name '" + _pname + "', so one capture would overwrite the other");
        variable_struct_set(_poseNames, _pname, true);

        // Every pose must select a node that EXISTS, or the inspector draws its empty state.
        mer_st_assert(_st, _pf.selected != "", "pose " + _pname + " selected nothing");
        mer_st_assert(_st, !is_undefined(mer_tree_get(_pt2, _pf.selected)),
                      "pose " + _pname + " selected '" + _pf.selected + "', which is not in the tree");
    }

    // The export pose must carry real text, not an empty overlay. This wing published a $19.99
    // listing whose entire body was the word "undefined" because a value was read back after a
    // navigation and nobody looked; an empty export panel is the same picture.
    mer_forge_pose(_pf, _pt2, 2, 480, 360);
    mer_st_assert(_st, _pf.mode == MER_FORGE_MODE_EXPORT, "the export pose did not open the overlay");
    mer_st_assert(_st, string_length(_pf.exportText) > 400,
                  "the export pose would photograph " + string(string_length(_pf.exportText)) + " characters of GML");
    mer_st_assert(_st, mer_st_count(_pf.exportText, "mer_tree_add(") == 6,
                  "the export pose shows " + string(mer_st_count(_pf.exportText, "mer_tree_add(")) + " nodes, the tree has 6");

    // == THE EXPORT PANEL IS SIZED TO ITS CODE, AND CANNOT COLLIDE ITS OWN HEADER ================
    // ⛔ THE SHIPPED PANEL WAS THE FULL WINDOW WIDTH WHILE ITS TEXT FILLED HALF OF IT, and that
    // reached a store gallery: `visual_density.js` scored the export screenshot THIN at 175 colours,
    // the lowest in the gallery, over a picture of this product's headline feature. The height of
    // the same panel had ALREADY been fixed for the same reason, with a comment citing master's
    // "more than a fifth empty is a reject" rule — so the argument was right and was applied to one
    // of the two axes it holds. Nothing could see it, because the width was computed inline in a
    // Draw event where the only available instrument is baking a PNG and looking at it.
    //
    // ⚠️ TESTED IN BOTH DIRECTIONS ON PURPOSE. A width check that only asserts "not too wide" is
    // satisfied by a panel of zero width, which would be a worse defect than the one being fixed —
    // master's own catalogue records a one-sided threshold drifting out of its permissive side for
    // months with every check green. So: never wider than its bound, never narrower than its own
    // header row, and STRICTLY narrower than the window on real content, which is the claim.
    var _exLines = string_split(mer_forge_export_gml(_pt2, "build_skill_tree"), chr(10));
    var _exMax   = 1212;                                     // the window less the overlay margins
    var _exW     = mer_forge_export_panel_w(_exLines, _exMax);

    mer_st_assert(_st, _exW <= _exMax,
                  "the export panel is " + string(_exW) + "px inside a " + string(_exMax) + "px bound");
    mer_st_assert(_st, _exW < _exMax,
                  "the export panel still fills the whole window (" + string(_exW) +
                  "px), so it is not sized to its content at all");

    // The header floor, derived the same way the panel derives it. A panel narrower than this draws
    // "EXPORTED GML" and "E OR ESC TO CLOSE" into each other.
    var _exHead = mer_text_width("EXPORTED GML", 12) + mer_text_width("E OR ESC TO CLOSE", 7) + 44;
    mer_st_assert(_st, _exW >= _exHead,
                  "the export panel is " + string(_exW) + "px, narrower than its own header row at " +
                  string(_exHead) + "px, so the title and the hint would overlap");

    // The widest line must actually fit inside the padding, or code runs off the edge it was fitted
    // to — the silent failure, because a clipped line still looks like a line.
    var _exWidest = 0;
    for (var _exi = 0; _exi < array_length(_exLines); _exi++) {
        _exWidest = max(_exWidest, mer_text_width(_exLines[_exi], mer_forge_export_code_size(),
                                                  mer_forge_export_code_tracking()));
    }
    mer_st_assert(_st, _exWidest > 0, "measured 0px of export code, so this stage proved nothing");
    mer_st_assert(_st, _exWidest + 44 <= _exW,
                  "the widest export line is " + string(_exWidest) +
                  "px and the panel gives it " + string(_exW - 44) + "px");

    // A one-line export must not produce a sliver, and a bound smaller than the header must still
    // be honoured — the caller's window is the hard limit even when the content wants more.
    mer_st_assert(_st, mer_forge_export_panel_w(["x"], _exMax) >= _exHead,
                  "a one-line export collapsed the panel below its header row");
    mer_st_assert(_st, mer_forge_export_panel_w(_exLines, 300) <= 300,
                  "the export panel ignored a bound narrower than its content");

    // The linking pose must actually be mid-drag with a fixed endpoint, or the shot draws a line
    // to wherever the pointer happens to be — usually the corner of the window.
    mer_forge_pose(_pf, _pt2, 1, 480, 360);
    mer_st_assert(_st, _pf.linkFrom != "", "the linking pose is not holding an edge");
    mer_st_assert(_st, _pf.linkToX >= 0 && _pf.linkToY >= 0, "the linking pose left its endpoint on the pointer");

    // ⛔ AND POSES MUST NOT LEAK INTO EACH OTHER. They are baked in sequence from ONE process, so a
    // pose that fails to clear the previous one produces a screenshot with the wrong overlay on it
    // — the shot after the export shot silently containing the export panel.
    mer_forge_pose(_pf, _pt2, 2, 480, 360);
    mer_forge_pose(_pf, _pt2, 3, 480, 360);
    mer_st_assert(_st, _pf.mode == MER_FORGE_MODE_SELECT, "the export overlay survived into the next pose");
    mer_st_assert(_st, _pf.linkFrom == "", "a dragged edge survived into the next pose");

    // == STAGE 21: THE INSPECTOR'S BLOCKS DO NOT OVERLAP, AT ANY PREREQUISITE COUNT ==============
    // ⛔ THE DEFECT THIS DEFENDS SHIPPED INTO A BAKED SCREENSHOT. The key legend was pinned to a
    // constant offset from the panel's bottom while the prerequisite list flowed down from above,
    // so a node with parents printed "GUARD" and "MEND" straight through the word "CLICK". Two
    // hundred and two assertions were green at the time, because not one of them draws a string.
    //
    // ⚠️ WHAT THIS CHECKS AND WHAT IT DOES NOT. It reads the SAME layout the renderer consumes and
    // asserts the blocks are disjoint and inside the panel. It cannot tell you the panel looks
    // good. That is a picture, and a picture is looked at.
    mer_st_stage(_st, 21);
    var _iy = 68;
    var _ih = 584;
    var _it = mer_forge_starter_tree();

    // Empty selection must still lay out — the panel draws its "nothing selected" state.
    var _l0 = mer_forge_inspector_layout(_it, "", _iy, _ih);
    mer_st_assert(_st, _l0.ok, "the inspector layout overlaps with nothing selected");

    // A root (no prerequisites), and the starter tree's deepest node (two).
    var _l1 = mer_forge_inspector_layout(_it, "root", _iy, _ih);
    mer_st_assert(_st, _l1.ok, "the inspector layout overlaps on a root node");
    mer_st_assert(_st, _l1.reqHidden == 0, "a root node reported hidden prerequisites");

    var _l2 = mer_forge_inspector_layout(_it, "keystone", _iy, _ih);
    mer_st_assert(_st, _l2.ok, "the inspector layout overlaps on a node with two prerequisites");
    mer_st_assert(_st, _l2.reqRows >= 2, "only " + string(_l2.reqRows) + " of 2 prerequisites would be drawn");
    mer_st_assert(_st, _l2.reqBottom <= _l2.legendY,
                  "prerequisites end at " + string(_l2.reqBottom) + ", the legend starts at " + string(_l2.legendY));

    // ⭐ THE ADVERSARIAL CASE, and the one that produced the original defect: many parents. A node
    // with more prerequisites than fit must NOT draw into the legend, and must say how many it hid
    // rather than stopping silently — a list that just stops is a lie about the buyer's own data.
    var _many = mer_st_fixture();
    for (var _i = 0; _i < 24; _i++) {
        mer_tree_add(_many, "p" + string(_i), { name: "P" + string(_i), requires: [] });
    }
    var _sink = mer_tree_get(_many, "join");
    var _reqs = [];
    for (var _i = 0; _i < 24; _i++) array_push(_reqs, "p" + string(_i));
    _sink.requires = _reqs;

    var _l3 = mer_forge_inspector_layout(_many, "join", _iy, _ih);
    mer_st_assert(_st, _l3.ok, "a node with 24 prerequisites still overlaps the legend");
    mer_st_assert(_st, _l3.reqBottom <= _l3.legendY,
                  "24 prerequisites reach " + string(_l3.reqBottom) + " past the legend at " + string(_l3.legendY));
    mer_st_assert(_st, _l3.reqHidden > 0, "24 prerequisites cannot all fit, yet none were reported hidden");
    mer_st_assert(_st, _l3.reqRows + _l3.reqHidden == 24,
                  "drawn " + string(_l3.reqRows) + " + hidden " + string(_l3.reqHidden) + " does not account for 24");

    // A CONTROL IN THE OTHER DIRECTION: squeeze the panel until nothing can fit, and the layout must
    // report NOT ok rather than quietly returning negative row counts that draw off the panel.
    var _tiny = mer_forge_inspector_layout(_it, "keystone", _iy, 260);
    mer_st_assert(_st, _tiny.reqRows >= 0, "a squeezed panel produced a negative row count");
    mer_st_assert(_st, !_tiny.ok, "a 260px panel cannot hold this inspector, but the layout called itself ok");

    // == STAGE 22: ADVERSARIAL ====================================================================
    // Everything a buyer can do to this API that it was not designed for. The bar is not "produces
    // a good result" — it is "does not crash, does not hang, and does not silently corrupt the
    // tree". A GML runtime error opens a modal dialog, so in a shipped game every one of these is a
    // hard lock rather than an exception somebody catches.
    mer_st_stage(_st, 22);

    // --- ids: empty, duplicate, absurd, and characters that break a generated string literal ----
    var _a = mer_tree_make();
    mer_st_assert(_st, mer_forge_add(undefined, _a, { id: "x", name: "X" }) == "x", "a plain add failed");
    mer_st_assert(_st, mer_forge_add(undefined, _a, { id: "x", name: "X AGAIN" }) == "",
                  "a DUPLICATE id was accepted, which silently drops one of the two nodes");
    mer_st_assert(_st, mer_tree_count(_a) == 1, "the duplicate add changed the node count");

    var _weird = "he said \"hi\" \\ and left";
    mer_forge_add(undefined, _a, { id: "q", name: _weird, desc: _weird });
    var _wg = mer_forge_export_gml(_a, "t");
    mer_st_assert(_st, (mer_st_count(_wg, "\"") % 2) == 0,
                  "a name containing a quote produced generated GML with unbalanced quotes, which would not compile");
    mer_st_assert(_st, string_pos("\\", _wg) == 0, "a backslash survived into generated GML, where it is an escape");

    // A very long name must not be able to break the exporter.
    var _long = "";
    for (var _i = 0; _i < 400; _i++) _long += "A";
    mer_forge_add(undefined, _a, { id: "long", name: _long });
    mer_st_assert(_st, string_length(mer_forge_export_gml(_a, "t")) > 400, "a 400-character name broke the export");

    // --- links: to nothing, from nothing, both ways ---------------------------------------------
    mer_st_assert(_st, !mer_forge_link(_a, "x", "nope").ok, "linking TO a missing node was accepted");
    mer_st_assert(_st, !mer_forge_link(_a, "nope", "x").ok, "linking FROM a missing node was accepted");
    mer_st_assert(_st, !mer_forge_link(_a, "", "x").ok, "linking from an empty id was accepted");
    mer_st_assert(_st, !mer_forge_link(_a, "x", "").ok, "linking to an empty id was accepted");
    mer_st_assert(_st, !mer_forge_unlink(_a, "x", "nope"), "unlinking a missing node claimed to remove something");
    mer_st_assert(_st, mer_forge_validate(_a).ok, "the tree was corrupted by a series of refused links");

    // --- delete everything, then keep using it ---------------------------------------------------
    var _b = mer_st_fixture();
    while (mer_tree_count(_b) > 0) mer_forge_remove(_b, _b.nodes[0].id);
    mer_st_assert(_st, mer_tree_count(_b) == 0, "deleting every node left " + string(mer_tree_count(_b)) + " behind");
    mer_st_assert(_st, mer_forge_validate(_b).ok, "an emptied tree does not validate");
    mer_st_assert(_st, mer_tree_bounds(_b).w >= 0, "bounds of an empty tree went negative");
    for (var _l = 0; _l < mer_layout_count(); _l++) mer_layout_apply(_l, _b);
    mer_st_assert(_st, true, "every layout survived an empty tree");
    mer_st_assert(_st, mer_forge_add(undefined, _b, { id: "back", name: "BACK" }) == "back",
                  "an emptied tree would not accept a new node");

    // --- absurd field values --------------------------------------------------------------------
    var _c = mer_st_fixture();
    var _cn = mer_tree_get(_c, "root");
    _cn.sigil = 100000;
    _cn.disc = -100000;
    _cn.cost = -50;
    _cn.maxRank = -3;
    var _cv = mer_forge_validate(_c);
    mer_st_assert(_st, !_cv.ok, "wildly out-of-range indices validated clean");
    mer_forge_repair(_c);
    mer_st_assert(_st, _cn.sigil >= 0 && _cn.sigil < _sc, "repair left an out-of-range motif");
    mer_st_assert(_st, _cn.disc >= 0 && _cn.disc < _dc, "repair left an out-of-range discipline");
    // Stepping from an absurd value must land in range rather than wrapping to another absurd one.
    mer_forge_step_field(_c, "root", MER_FORGE_FIELD_SIGIL, 1);
    mer_st_assert(_st, _cn.sigil >= 0 && _cn.sigil < _sc, "stepping from a repaired index went out of range");

    // --- a deep chain, which is where an O(n^2) walk or a recursion would show ---------------------
    var _d = mer_tree_make();
    mer_tree_add(_d, "n0", { name: "N0", requires: [] });
    for (var _i = 1; _i < 120; _i++) {
        mer_tree_add(_d, "n" + string(_i), { name: "N" + string(_i), requires: ["n" + string(_i - 1)] });
    }
    mer_st_assert(_st, mer_tree_compute_depth(_d), "a 120-deep chain was reported as a cycle");
    mer_st_assert(_st, mer_tree_get(_d, "n119").depth == 119,
                  "the deepest node is at depth " + string(mer_tree_get(_d, "n119").depth) + ", expected 119");
    mer_st_assert(_st, mer_forge_reaches(_d, "n0", "n119"), "reachability failed across a 120-deep chain");
    mer_st_assert(_st, !mer_forge_reaches(_d, "n119", "n0"), "reachability ran backwards along a chain");
    mer_st_assert(_st, !mer_forge_link(_d, "n119", "n0").ok, "closing a 120-long cycle was accepted");
    mer_st_assert(_st, mer_forge_validate(_d).ok, "the deep chain was corrupted by the refused link");

    // --- a wide fan, the other shape --------------------------------------------------------------
    var _e2 = mer_tree_make();
    mer_tree_add(_e2, "hub", { name: "HUB", requires: [] });
    for (var _i = 0; _i < 150; _i++) mer_tree_add(_e2, "leaf" + string(_i), { name: "L", requires: ["hub"] });
    mer_st_assert(_st, mer_tree_count(_e2) == 151, "the fan lost nodes");
    var _swept2 = mer_forge_remove(_e2, "hub");
    mer_st_assert(_st, _swept2 == 150, "deleting the hub swept " + string(_swept2) + " of 150 references");
    mer_st_assert(_st, mer_forge_validate(_e2).ok, "150 dangling references survived the hub's deletion");

    // --- imports that are not documents -----------------------------------------------------------
    mer_st_assert(_st, is_undefined(mer_forge_import_json("")), "an empty string imported as a tree");
    mer_st_assert(_st, is_undefined(mer_forge_import_json("[]")), "a bare array imported as a tree");
    mer_st_assert(_st, is_undefined(mer_forge_import_json("{\"nodes\":\"not an array\"}")), "a string nodes field imported");
    mer_st_assert(_st, is_undefined(mer_forge_import_json("{\"nodes\":[{}]}")), "a node with no id imported");
    mer_st_assert(_st, is_undefined(mer_forge_import_json("{{{")), "malformed JSON imported instead of being refused");
    var _ok2 = mer_forge_import_json("{\"nodes\":[{\"id\":\"a\"}]}");
    mer_st_assert(_st, !is_undefined(_ok2) && mer_tree_count(_ok2) == 1,
                  "a minimal but VALID document was refused, so the guard is too strict");
    // ⚠️ That last one is the control: a refuser that refuses everything is not a validator.

    // == STAGE 23: THE STORE FILM ACTUALLY DOES SOMETHING ========================================
    // ⛔ A SCRIPT THAT SILENTLY STOPS PERFORMING ITS MIDDLE ACT STILL PRODUCES A PERFECTLY VALID
    // GIF — of a tree sitting still. Nothing downstream can tell the difference: the frames exist,
    // they are the right size, they are not blank, and the file goes on the store page. So the
    // script is run headlessly here and every act is required to fire.
    mer_st_stage(_st, 23);
    var _ft = mer_forge_starter_tree();
    var _ff = mer_forge_make(_ft);

    // ⛔ THE CONTROL THAT CAUGHT A REAL DEFECT. mer_forge_make must leave the tree LAID OUT: before
    // this assertion existed it did not, so opening a session on a freshly-built tree stacked every
    // node on the origin — one node visible, the rest underneath it, and nothing reporting anything.
    var _coincident = 0;
    for (var _i = 0; _i < mer_tree_count(_ft); _i++) {
        for (var _j = _i + 1; _j < mer_tree_count(_ft); _j++) {
            if (point_distance(_ft.nodes[_i].lx, _ft.nodes[_i].ly,
                               _ft.nodes[_j].lx, _ft.nodes[_j].ly) < MER_ST_EPS) _coincident += 1;
        }
    }
    mer_st_assert(_st, _coincident == 0,
                  "mer_forge_make left " + string(_coincident) + " node pair(s) stacked on one point — it did not lay the tree out");
    var _acts = mer_forge_film_acts();
    var _fired = {};
    var _frames = 78;
    var _before = mer_tree_count(_ft);

    for (var _i = 0; _i < _frames; _i++) {
        var _act = mer_forge_film_step(_ff, _ft, _i, _frames, 480, 360);
        if (_act != "") variable_struct_set(_fired, _act, true);
    }

    for (var _i = 0; _i < array_length(_acts); _i++) {
        mer_st_assert(_st, variable_struct_exists(_fired, _acts[_i]),
                      "the store film never performed its '" + _acts[_i] + "' act");
    }

    // Each act must have left a REAL trace, not merely returned its own name.
    mer_st_assert(_st, mer_tree_count(_ft) == _before + 1,
                  "the film's add act did not add a node (" + string(_before) + " -> " + string(mer_tree_count(_ft)) + ")");
    var _mend = mer_tree_get(_ft, "mend");
    var _linked = false;
    for (var _i = 0; _i < array_length(_mend.requires); _i++) if (_mend.requires[_i] == "might") _linked = true;
    mer_st_assert(_st, _linked, "the film's link act did not create the prerequisite it demonstrates");
    mer_st_assert(_st, _ff.layout != 0, "the film's layout act did not change the layout");
    mer_st_assert(_st, _ff.linkFrom == "", "the film ended still holding a dragged edge");
    mer_st_assert(_st, mer_forge_validate(_ft).ok, "the film left the tree in an invalid state");

    // The whole point of the drag act is MOTION. If the endpoint never moves, the GIF shows a
    // static line and the gesture is not demonstrated — a picture of the feature, not the feature.
    var _ft2 = mer_forge_starter_tree();
    var _ff2 = mer_forge_make(_ft2);
    var _minX = 999999;
    var _maxX = -999999;
    for (var _i = 0; _i < 24; _i++) {
        mer_forge_film_step(_ff2, _ft2, _i, _frames, 480, 360);
        if (_ff2.linkFrom != "" && _ff2.linkToX >= 0) {
            _minX = min(_minX, _ff2.linkToX);
            _maxX = max(_maxX, _ff2.linkToX);
        }
    }
    mer_st_assert(_st, _maxX > _minX + 40,
                  "the dragged edge moved only " + string(_maxX - _minX) + " px across the whole drag, so the GIF shows a static line");

    mer_st_stage(_st, 99);
    return _st;
}

/// @func   mer_st_has_kind(_report, _kind)
/// @desc   Did a validation report include a problem of this kind?
/// @param  {Struct} _report  A mer_forge_validate result.
/// @param  {String} _kind    The kind to look for.
/// @return {Bool} True if present.
function mer_st_has_kind(_report, _kind) {
    for (var _i = 0; _i < array_length(_report.problems); _i++) {
        if (_report.problems[_i].kind == _kind) return true;
    }
    return false;
}

/// @func   mer_st_count(_haystack, _needle)
/// @desc   How many times _needle appears in _haystack.
/// @param  {String} _haystack  The text.
/// @param  {String} _needle    What to count.
/// @return {Real} The count.
function mer_st_count(_haystack, _needle) {
    if (string_length(_needle) == 0) return 0;
    var _n = 0;
    var _at = 1;
    while (true) {
        var _p = string_pos_ext(_needle, _haystack, _at);
        if (_p <= 0) break;
        _n += 1;
        _at = _p + string_length(_needle);
    }
    return _n;
}

/// @func   mer_selftest_write(_st)
/// @desc   Writes the result where the harness reads it.
///
/// @remarks ⛔ FOUR ROUTES OUT OF A HEADLESS GAMEMAKER BUILD DO NOT WORK, all measured by this wing:
///          show_debug_message with -debugoutput is dead in a release build; game_end(n) does not
///          propagate its argument to the process exit code; driving Igor without --uf= reports a
///          permission error indistinguishable from a lapsed licence. Writing a file in the save
///          area is the one that works.
///
/// @param  {Struct} _st  The suite result.
function mer_selftest_write(_st) {
    var _f = file_text_open_write("mer_selftest.json");
    file_text_write_string(_f, "{");
    file_text_write_string(_f, "\"total\":" + string(_st.total));
    file_text_write_string(_f, ",\"pass\":" + string(_st.pass));
    file_text_write_string(_f, ",\"fail\":" + string(_st.fail));
    file_text_write_string(_f, ",\"stage\":" + string(_st.stage));
    file_text_write_string(_f, ",\"notes\":[");
    for (var _i = 0; _i < array_length(_st.notes); _i++) {
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "\"" + string_replace_all(_st.notes[_i], "\"", "'") + "\"");
    }
    file_text_write_string(_f, "],\"failures\":[");
    for (var _i = 0; _i < array_length(_st.failures); _i++) {
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "\"" + string_replace_all(_st.failures[_i], "\"", "'") + "\"");
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}
