{
  "$GMScript": "v1",
  "%Name": "mer_selftest",
  "isCompatibility": false,
  "isDnD": false,
  "name": "mer_selftest",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}
