{
  "$GMScript": "v1",
  "%Name": "mer_sigil",
  "isCompatibility": false,
  "isDnD": false,
  "name": "mer_sigil",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}