/// @file    mer_sigil.gml
/// @package Meridian for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary The ability-sigil engine. Every node mark in Meridian is generated from geometry and
///          colour maths at draw time. There is no icon sprite anywhere in this package.
///
/// @remarks WHY A SKILL TREE SHIPS ITS OWN ARTWORK.
///
///          Look at what a progression system normally asks of you. It gives you the graph, the
///          prerequisites and the points economy, and then it says: supply an icon per node. A
///          modest tree has forty nodes. Forty icons is a commission, an art pack, or forty
///          evenings — and it is the reason so many otherwise-finished skill trees ship with
///          forty coloured squares in them.
///
///          Meridian draws the marks itself. Sixty motifs across eight disciplines, and because
///          a discipline is a palette rather than a redraw, the same motif is a fire skill or a
///          frost skill depending on which branch you hang it on.
///
///          WHY THESE ARE STROKES AND GLOWS RATHER THAN LITTLE PICTURES OF OBJECTS. A skill icon
///          is not an item icon. An item is a thing sitting in a box and it wants a contact
///          shadow and a rim light so it reads as solid. An ability is a MARK — engraved, lit
///          from within, symmetrical. That is why this renderer's three passes are bloom, body
///          and core rather than shadow, body and rim: it is drawing light, not matter.
///
///          THE SYMMETRY OPERATOR IS WHERE THE VISUAL DENSITY COMES FROM. Most motifs here are
///          three or four shapes. Stamped six times around their centre they become something
///          that looks laboured over, because radial symmetry is the single strongest cue the eye
///          uses for "somebody designed this". Authoring sixty elaborate marks by hand would have
///          produced sixty worse ones.
///
///          Coordinates are on a CENTRED grid running -5 to +5 on both axes, unlike the 0..10 box
///          an item icon uses. That is not a style choice: every rotation in this file is about
///          the origin, and a centred grid makes the symmetry operator a rotation rather than a
///          translate-rotate-translate at every vertex.

// ---------------------------------------------------------------------------------------------
// Shape kinds
// ---------------------------------------------------------------------------------------------

#macro MER_SHAPE_POLY 0   // filled polygon,  p = flat x,y list, wound either way
#macro MER_SHAPE_LINE 1   // stroked polyline, p = flat x,y list, w = weight in grid units
#macro MER_SHAPE_DISC 2   // filled circle,    p = [cx, cy, radius]
#macro MER_SHAPE_RING 3   // stroked circle,   p = [cx, cy, radius], w = weight
#macro MER_SHAPE_ARC  4   // stroked arc,      p = [cx, cy, radius, from_deg, to_deg], w = weight

// ---------------------------------------------------------------------------------------------
// Roles. A sigil has four, and they are about LIGHT rather than material.
// ---------------------------------------------------------------------------------------------

#macro MER_ROLE_CORE  0   // the central mark. Brightest thing in the sigil.
#macro MER_ROLE_LIMB  1   // radiating structure — arms, blades, rays
#macro MER_ROLE_HALO  2   // enclosing geometry — rings, frames, containment
#macro MER_ROLE_SPARK 3   // pips, dots, punctuation

// ---------------------------------------------------------------------------------------------
// Shape constructors. Terse on purpose — the motif table below is sixty entries long and reads
// far better as data than as sixty struct literals.
// ---------------------------------------------------------------------------------------------

/// @func   mer_gp(_role, _points)
/// @desc   A filled polygon. Concave is fine; it is triangulated, not fanned.
/// @param  {Real}  _role    One of the MER_ROLE_* macros.
/// @param  {Array} _points  Flat x,y list on the -5..+5 grid.
/// @return {Struct} A shape.
/// @pure
function mer_gp(_role, _points) { return { k: MER_SHAPE_POLY, r: _role, p: _points, w: 0 }; }

/// @func   mer_gl(_role, _weight, _points)
/// @desc   A stroked polyline.
/// @param  {Real}  _role    One of the MER_ROLE_* macros.
/// @param  {Real}  _weight  Stroke weight in grid units.
/// @param  {Array} _points  Flat x,y list.
/// @return {Struct} A shape.
/// @pure
function mer_gl(_role, _weight, _points) { return { k: MER_SHAPE_LINE, r: _role, p: _points, w: _weight }; }

/// @func   mer_gd(_role, _cx, _cy, _radius)
/// @desc   A filled disc.
/// @param  {Real} _role    One of the MER_ROLE_* macros.
/// @param  {Real} _cx      Centre x on the grid.
/// @param  {Real} _cy      Centre y on the grid.
/// @param  {Real} _radius  Radius in grid units.
/// @return {Struct} A shape.
/// @pure
function mer_gd(_role, _cx, _cy, _radius) { return { k: MER_SHAPE_DISC, r: _role, p: [_cx, _cy, _radius], w: 0 }; }

/// @func   mer_go(_role, _weight, _cx, _cy, _radius)
/// @desc   A stroked circle, drawn as a true annulus.
/// @param  {Real} _role    One of the MER_ROLE_* macros.
/// @param  {Real} _weight  Stroke weight in grid units.
/// @param  {Real} _cx      Centre x.
/// @param  {Real} _cy      Centre y.
/// @param  {Real} _radius  Radius.
/// @return {Struct} A shape.
/// @pure
function mer_go(_role, _weight, _cx, _cy, _radius) { return { k: MER_SHAPE_RING, r: _role, p: [_cx, _cy, _radius], w: _weight }; }

/// @func   mer_ga(_role, _weight, _cx, _cy, _radius, _from, _to)
/// @desc   A stroked arc. The single most useful shape in this file — almost every sigil that
///         reads as "arcane" rather than "geometric" gets there through an open arc.
/// @param  {Real} _role    One of the MER_ROLE_* macros.
/// @param  {Real} _weight  Stroke weight in grid units.
/// @param  {Real} _cx      Centre x.
/// @param  {Real} _cy      Centre y.
/// @param  {Real} _radius  Radius.
/// @param  {Real} _from    Start angle in degrees.
/// @param  {Real} _to      End angle in degrees.
/// @return {Struct} A shape.
/// @pure
function mer_ga(_role, _weight, _cx, _cy, _radius, _from, _to) {
    return { k: MER_SHAPE_ARC, r: _role, p: [_cx, _cy, _radius, _from, _to], w: _weight };
}

// ---------------------------------------------------------------------------------------------
// Geometry helpers, used while BUILDING the table rather than while drawing it.
// ---------------------------------------------------------------------------------------------

/// @func   mer_poly_regular(_sides, _radius, _rotation)
/// @desc   Flat x,y list for a regular polygon centred on the origin.
/// @param  {Real} _sides     Number of sides, 3 or more.
/// @param  {Real} _radius    Circumradius in grid units.
/// @param  {Real} _rotation  Rotation in degrees.
/// @return {Array} Flat x,y list.
/// @pure
function mer_poly_regular(_sides, _radius, _rotation = 0) {
    var _pts = [];
    for (var _i = 0; _i < _sides; _i++) {
        var _a = _rotation + _i * 360 / _sides;
        array_push(_pts, lengthdir_x(_radius, _a), lengthdir_y(_radius, _a));
    }
    return _pts;
}

/// @func   mer_poly_star(_points_count, _outer, _inner, _rotation)
/// @desc   Flat x,y list for a star, centred on the origin. Concave by construction, which is
///         exactly why the renderer triangulates instead of fanning.
/// @param  {Real} _points_count  Number of star points.
/// @param  {Real} _outer         Outer radius.
/// @param  {Real} _inner         Inner radius.
/// @param  {Real} _rotation      Rotation in degrees.
/// @return {Array} Flat x,y list.
/// @pure
function mer_poly_star(_points_count, _outer, _inner, _rotation = 0) {
    var _pts = [];
    for (var _i = 0; _i < _points_count * 2; _i++) {
        var _a = _rotation + _i * 180 / _points_count;
        var _r = (_i % 2 == 0) ? _outer : _inner;
        array_push(_pts, lengthdir_x(_r, _a), lengthdir_y(_r, _a));
    }
    return _pts;
}

// ---------------------------------------------------------------------------------------------
// Disciplines. A discipline is a four-colour palette in MER_ROLE order plus a name.
//
// These are semantic rather than decorative — players read fire as warm and frost as cold, and a
// progression screen that fights that costs the player a beat every time they look at it. What
// the palettes DO share is construction: each is built as a bright core, a mid limb, a dim halo
// and a near-white spark, so sixty motifs across eight disciplines still read as one set.
// ---------------------------------------------------------------------------------------------

/// @func   mer_discipline_build()
/// @desc   Builds the discipline table. Called once, lazily, by mer_discipline_get.
/// @return {Array} Discipline structs: {n: name, c: [core, limb, halo, spark]}.
function mer_discipline_build() {
    var _d = function(_name, _cr, _cg, _cb, _lr, _lg, _lb, _hr, _hg, _hb, _sr, _sg, _sb) {
        return { n: _name, c: [make_colour_rgb(_cr, _cg, _cb), make_colour_rgb(_lr, _lg, _lb),
                               make_colour_rgb(_hr, _hg, _hb), make_colour_rgb(_sr, _sg, _sb)] };
    };
    return [
        _d("BLADE",    255, 232, 214,   224, 168, 152,   196, 104,  96,   255, 246, 238),
        _d("ARCANE",   238, 214, 255,   186, 132, 250,   138,  84, 214,   248, 238, 255),
        _d("VITALITY", 226, 255, 214,   142, 226, 130,    92, 176,  96,   244, 255, 236),
        _d("SHADOW",   214, 210, 255,   142, 124, 214,    92,  78, 158,   232, 226, 255),
        _d("FLAME",    255, 226, 178,   255, 158,  70,   214,  92,  44,   255, 244, 220),
        _d("FROST",    216, 246, 255,   126, 206, 246,    76, 148, 202,   238, 250, 255),
        _d("STORM",    246, 242, 200,   240, 214,  92,   196, 158,  48,   255, 252, 226),
        _d("FORGE",    226, 234, 244,   158, 178, 202,   106, 124, 148,   240, 246, 255),
    ];
}

/// @func   mer_discipline_get()
/// @desc   Returns the discipline table, building it on first use.
/// @return {Array} The table.
function mer_discipline_get() {
    if (!variable_global_exists("__mer_disciplines")) {
        global.__mer_disciplines = mer_discipline_build();
    }
    return global.__mer_disciplines;
}

/// @func   mer_discipline_count()
/// @desc   How many disciplines ship. Derived from the table so it cannot go stale.
/// @return {Real} The count.
function mer_discipline_count() { return array_length(mer_discipline_get()); }

/// @func   mer_discipline_name(_index)
/// @desc   Display name of a discipline.
/// @param  {Real} _index  Any integer; wrapped into range.
/// @return {String} The name.
function mer_discipline_name(_index) {
    var _t = mer_discipline_get(), _n = array_length(_t);
    return _t[(_index % _n + _n) % _n].n;
}

/// @func   mer_discipline_palette(_index)
/// @desc   The four colours of a discipline, in MER_ROLE order.
/// @param  {Real} _index  Any integer; wrapped into range.
/// @return {Array} Four BGR colour values.
function mer_discipline_palette(_index) {
    var _t = mer_discipline_get(), _n = array_length(_t);
    return _t[(_index % _n + _n) % _n].c;
}

// ---------------------------------------------------------------------------------------------
// The motif table.
//
// Each entry is {n: name, d: default discipline, y: symmetry count, s: shapes}.
//
// `y` is the symmetry order: the shape list is stamped y times at 360/y degree intervals. y = 1
// draws the motif once, as authored. Anything drawn at y > 1 should be authored in the UPPER
// portion of the grid — it will be rotated into the rest.
// ---------------------------------------------------------------------------------------------

/// @func   mer_sigil_build()
/// @desc   Builds the motif table. Called once, lazily, by mer_sigil_get.
///
/// @remarks Read one entry and the format is obvious, which is the point — a buyer adding their
///          own mark should not have to reverse-engineer anything. Add a struct to this array and
///          it is immediately available to every node, every palette and every size, with the
///          bloom and core passes applied for free.
///
/// @return {Array} Motif structs.
function mer_sigil_build() {
    var _m = function(_name, _disc, _sym, _shapes) {
        return { n: _name, d: _disc, y: _sym, s: _shapes };
    };

    return [
    // --- BLADE: martial offence and defence ---------------------------------------------------
    _m("CLEAVE", 0, 1, [
        mer_gp(MER_ROLE_LIMB, [-3.6, -3.4, -1.4, -3.9, 3.4, 1.6, 2.0, 3.4, -1.0, 0.4, -3.6, -1.2]),
        mer_ga(MER_ROLE_CORE, 0.5, 0.4, 0.2, 4.2, 150, 250),
    ]),
    _m("THRUST", 0, 1, [
        mer_gp(MER_ROLE_LIMB, [0, -4.6, 1.5, -1.6, 0.55, -1.9, 0.55, 4.3, -0.55, 4.3, -0.55, -1.9, -1.5, -1.6]),
        mer_gl(MER_ROLE_SPARK, 0.55, [-2.4, 1.6, 2.4, 1.6]),
    ]),
    _m("PARRY", 0, 2, [
        mer_gl(MER_ROLE_LIMB, 0.75, [-3.6, 3.4, 3.4, -3.6]),
        mer_gd(MER_ROLE_SPARK, 3.4, -3.6, 0.7),
    ]),
    _m("WHIRL", 0, 4, [
        mer_gp(MER_ROLE_LIMB, [0.5, -1.1, 2.2, -3.9, 3.9, -2.0, 1.5, -0.5]),
        mer_ga(MER_ROLE_HALO, 0.4, 0, 0, 4.4, -80, -20),
    ]),
    _m("GUARD", 0, 1, [
        mer_gp(MER_ROLE_HALO, [0, -4.3, 3.7, -2.8, 3.7, 0.6, 0, 4.4, -3.7, 0.6, -3.7, -2.8]),
        mer_gp(MER_ROLE_CORE, [0, -2.6, 2.1, -1.7, 2.1, 0.3, 0, 2.7, -2.1, 0.3, -2.1, -1.7]),
    ]),
    _m("VOLLEY", 0, 3, [
        mer_gp(MER_ROLE_LIMB, [0, -4.5, 1.25, -2.4, 0.45, -2.7, 0.45, -0.5, -0.45, -0.5, -0.45, -2.7, -1.25, -2.4]),
    ]),
    _m("RIPOSTE", 0, 2, [
        mer_gl(MER_ROLE_LIMB, 0.65, [-3.8, 1.4, -1.4, -1.0, -2.6, -2.2, 0.4, -3.8]),
        mer_gd(MER_ROLE_CORE, 0.4, -3.8, 0.75),
    ]),
    _m("SUNDER", 0, 1, [
        mer_gp(MER_ROLE_LIMB, [-4.1, -2.4, -1.1, -3.2, -0.2, -0.4, -2.0, 3.6, -3.4, 2.8, -1.9, -0.3]),
        mer_gp(MER_ROLE_LIMB, [1.1, -3.2, 4.1, -2.4, 1.9, -0.3, 3.4, 2.8, 2.0, 3.6, 0.2, -0.4]),
    ]),
    _m("BULWARK", 0, 1, [
        mer_ga(MER_ROLE_HALO, 0.7, 0, 1.2, 4.2, 20, 160),
        mer_ga(MER_ROLE_LIMB, 0.55, 0, 1.2, 2.9, 20, 160),
        mer_gl(MER_ROLE_CORE, 0.6, [0, -3.4, 0, 3.8]),
    ]),
    _m("EXECUTE", 0, 1, [
        mer_gp(MER_ROLE_LIMB, [-0.6, -4.2, 3.6, -3.0, 4.0, 0.2, -0.6, 0.8]),
        mer_gl(MER_ROLE_HALO, 0.7, [-1.0, -4.4, -1.0, 4.3]),
    ]),

    // --- ARCANE: casting, focus, containment --------------------------------------------------
    _m("FOCUS", 1, 1, [
        mer_go(MER_ROLE_HALO, 0.4, 0, 0, 4.3),
        mer_go(MER_ROLE_LIMB, 0.35, 0, 0, 2.8),
        mer_gd(MER_ROLE_CORE, 0, 0, 1.35),
    ]),
    _m("HEXGRAM", 1, 6, [
        mer_gl(MER_ROLE_LIMB, 0.4, [0, -4.2, 3.64, 2.1]),
    ]),
    _m("CHANNEL", 1, 2, [
        mer_gl(MER_ROLE_LIMB, 0.55, [0, -4.4, 0, -1.2]),
        mer_gd(MER_ROLE_SPARK, 0, -3.0, 0.75),
        mer_gd(MER_ROLE_CORE, 0, 0, 1.2),
    ]),
    _m("WARD", 1, 1, [
        mer_gp(MER_ROLE_HALO, mer_poly_regular(6, 4.3, 90)),
        mer_gp(MER_ROLE_CORE, mer_poly_regular(6, 2.9, 90)),
        mer_gd(MER_ROLE_SPARK, 0, 0, 1.0),
    ]),
    _m("RUNE", 1, 1, [
        mer_gl(MER_ROLE_LIMB, 0.65, [-2.4, -4.0, -2.4, 4.0]),
        mer_gl(MER_ROLE_LIMB, 0.65, [-2.4, -1.2, 2.4, -4.0]),
        mer_gl(MER_ROLE_LIMB, 0.65, [-2.4, 1.0, 2.4, 4.0]),
        mer_gd(MER_ROLE_CORE, 2.4, -0.9, 0.85),
    ]),
    _m("PRISM", 1, 3, [
        mer_gp(MER_ROLE_LIMB, [0, -4.2, 1.9, -0.9, -1.9, -0.9]),
    ]),
    _m("ORBIT", 1, 3, [
        mer_gd(MER_ROLE_SPARK, 0, -3.6, 0.95),
        mer_ga(MER_ROLE_HALO, 0.35, 0, 0, 3.6, -150, -30),
        mer_gd(MER_ROLE_CORE, 0, 0, 1.5),
    ]),
    _m("NEXUS", 1, 8, [
        mer_gl(MER_ROLE_LIMB, 0.4, [0, -1.5, 0, -4.4]),
        mer_gd(MER_ROLE_CORE, 0, 0, 1.3),
    ]),
    _m("SEAL", 1, 1, [
        mer_gp(MER_ROLE_HALO, mer_poly_regular(4, 4.2, 45)),
        mer_go(MER_ROLE_CORE, 0.45, 0, 0, 2.6),
        mer_gd(MER_ROLE_SPARK, 0, 0, 0.8),
    ]),
    _m("CONVERGE", 1, 4, [
        mer_gp(MER_ROLE_LIMB, [0, -1.6, 1.3, -3.4, -1.3, -3.4]),
        mer_gl(MER_ROLE_HALO, 0.35, [-1.8, -4.3, 1.8, -4.3]),
    ]),

    // --- VITALITY: health, growth, restoration ------------------------------------------------
    _m("HEART", 2, 1, [
        mer_gp(MER_ROLE_CORE, [0, 4.2, -3.9, 0.0, -3.9, -2.0, -2.1, -3.3, 0, -1.9,
                               2.1, -3.3, 3.9, -2.0, 3.9, 0.0]),
    ]),
    _m("BLOOM", 2, 6, [
        mer_gp(MER_ROLE_LIMB, [0, -1.3, 1.5, -2.9, 0, -4.4, -1.5, -2.9]),
        mer_gd(MER_ROLE_CORE, 0, 0, 1.1),
    ]),
    _m("MEND", 2, 1, [
        mer_gp(MER_ROLE_CORE, [-1.3, -4.1, 1.3, -4.1, 1.3, -1.3, 4.1, -1.3, 4.1, 1.3,
                               1.3, 1.3, 1.3, 4.1, -1.3, 4.1, -1.3, 1.3, -4.1, 1.3,
                               -4.1, -1.3, -1.3, -1.3]),
    ]),
    _m("SURGE", 2, 1, [
        mer_gp(MER_ROLE_LIMB, [0, -4.4, 3.2, -0.6, 1.3, -0.6, 1.3, 4.2, -1.3, 4.2, -1.3, -0.6, -3.2, -0.6]),
    ]),
    _m("VIGOR", 2, 1, [
        mer_gp(MER_ROLE_CORE, [0, -4.5, 1.9, -1.6, 1.2, -2.0, 1.9, 1.4, 0, 4.2, -1.9, 1.4,
                               -1.2, -2.0, -1.9, -1.6]),
    ]),
    _m("ROOT", 2, 1, [
        mer_gl(MER_ROLE_LIMB, 0.6, [0, 4.3, 0, -1.0]),
        mer_gl(MER_ROLE_LIMB, 0.45, [0, 0.6, -3.0, -2.4]),
        mer_gl(MER_ROLE_LIMB, 0.45, [0, -0.6, 3.0, -3.6]),
        mer_gd(MER_ROLE_SPARK, -3.0, -2.4, 0.75),
        mer_gd(MER_ROLE_CORE, 3.0, -3.6, 0.9),
    ]),
    _m("LIFEBIND", 2, 1, [
        mer_go(MER_ROLE_LIMB, 0.5, -1.7, 0, 2.5),
        mer_go(MER_ROLE_CORE, 0.5, 1.7, 0, 2.5),
    ]),
    _m("RENEW", 2, 1, [
        mer_ga(MER_ROLE_LIMB, 0.65, 0, 0, 3.4, -60, 260),
        mer_gp(MER_ROLE_CORE, [3.4, -2.2, 4.6, 0.3, 1.7, 0.1]),
    ]),

    // --- SHADOW: stealth, decay, denial -------------------------------------------------------
    _m("VEIL", 3, 1, [
        mer_gp(MER_ROLE_CORE, [0, -4.3, 2.6, -3.2, 1.0, -1.4, 1.0, 1.4, 2.6, 3.2, 0, 4.3,
                               -2.6, 3.2, -1.0, 1.4, -1.0, -1.4, -2.6, -3.2]),
        mer_gd(MER_ROLE_SPARK, 0, 0, 0.85),
    ]),
    _m("DAGGER", 3, 1, [
        mer_gp(MER_ROLE_LIMB, [0, -4.5, 0.95, -1.4, 0.95, 1.2, 0, 2.1, -0.95, 1.2, -0.95, -1.4]),
        mer_gl(MER_ROLE_HALO, 0.7, [-2.2, 2.1, 2.2, 2.1]),
        mer_gl(MER_ROLE_CORE, 0.5, [0, 2.1, 0, 4.3]),
    ]),
    _m("VENOM", 3, 1, [
        mer_gp(MER_ROLE_CORE, [0, -4.3, 2.7, -0.3, 2.7, 1.6, 0, 4.0, -2.7, 1.6, -2.7, -0.3]),
        mer_gd(MER_ROLE_SPARK, 0, 0.6, 1.0),
    ]),
    _m("FADE", 3, 1, [
        mer_gp(MER_ROLE_LIMB, [-4.0, -3.6, 4.0, -3.6, 4.0, -2.2, -4.0, -2.2]),
        mer_gp(MER_ROLE_LIMB, [-2.8, -0.7, 4.0, -0.7, 4.0, 0.7, -2.8, 0.7]),
        mer_gp(MER_ROLE_CORE, [-0.6, 2.2, 4.0, 2.2, 4.0, 3.6, -0.6, 3.6]),
    ]),
    _m("STALK", 3, 2, [
        mer_gl(MER_ROLE_LIMB, 0.6, [-3.0, -1.2, 0, -3.9, 3.0, -1.2]),
    ]),
    _m("HEX", 3, 1, [
        mer_gp(MER_ROLE_HALO, [-4.2, -3.2, 4.2, -3.2, 0, 4.3]),
        mer_gd(MER_ROLE_CORE, 0, -1.3, 1.5),
        mer_gd(MER_ROLE_SPARK, 0, -1.3, 0.6),
    ]),
    _m("DRAIN", 3, 1, [
        mer_gp(MER_ROLE_LIMB, [-4.0, -4.0, 4.0, -4.0, 0.9, 0.4, 0.9, 4.2, -0.9, 4.2, -0.9, 0.4]),
        mer_gd(MER_ROLE_CORE, 0, -2.2, 1.0),
    ]),
    _m("SHROUD", 3, 1, [
        mer_ga(MER_ROLE_HALO, 0.5, 0, 0.8, 4.2, 200, 340),
        mer_ga(MER_ROLE_LIMB, 0.5, 0, 0.8, 3.0, 200, 340),
        mer_ga(MER_ROLE_CORE, 0.5, 0, 0.8, 1.8, 200, 340),
    ]),

    // --- FLAME --------------------------------------------------------------------------------
    _m("FLAME", 4, 1, [
        mer_gp(MER_ROLE_LIMB, [0, -4.6, 2.2, -1.4, 1.6, -2.1, 2.6, 1.4, 0, 4.3, -2.6, 1.4,
                               -1.6, -2.1, -2.2, -1.4]),
        mer_gp(MER_ROLE_CORE, [0, -1.2, 1.2, 1.0, 0, 3.0, -1.2, 1.0]),
    ]),
    _m("BLAST", 4, 8, [
        mer_gp(MER_ROLE_LIMB, [0, -4.5, 0.8, -2.0, -0.8, -2.0]),
        mer_gd(MER_ROLE_CORE, 0, 0, 1.6),
    ]),
    _m("CINDER", 4, 3, [
        mer_gp(MER_ROLE_CORE, [0, -4.2, 1.2, -2.4, 0, -1.2, -1.2, -2.4]),
        mer_gd(MER_ROLE_SPARK, 0, 0, 0.7),
    ]),
    _m("PYRE", 4, 1, [
        mer_gp(MER_ROLE_LIMB, [0, -4.4, 1.9, -1.6, 1.1, -2.0, 2.0, 0.6, 0, 2.2, -2.0, 0.6,
                               -1.1, -2.0, -1.9, -1.6]),
        mer_gp(MER_ROLE_HALO, [-3.4, 2.4, 3.4, 2.4, 2.4, 4.3, -2.4, 4.3]),
    ]),
    _m("SCORCH", 4, 1, [
        mer_gl(MER_ROLE_LIMB, 0.55, [-4.0, -2.6, -1.4, -3.6, 1.4, -1.6, 4.0, -2.6]),
        mer_gl(MER_ROLE_CORE, 0.55, [-4.0, 0.4, -1.4, -0.6, 1.4, 1.4, 4.0, 0.4]),
        mer_gl(MER_ROLE_LIMB, 0.55, [-4.0, 3.4, -1.4, 2.4, 1.4, 4.4, 4.0, 3.4]),
    ]),
    _m("IGNITE", 4, 1, [
        mer_gp(MER_ROLE_CORE, mer_poly_star(4, 4.4, 1.1, -90)),
        mer_gd(MER_ROLE_SPARK, 0, 0, 1.0),
    ]),

    // --- FROST --------------------------------------------------------------------------------
    _m("FROST", 5, 6, [
        mer_gl(MER_ROLE_LIMB, 0.4, [0, -1.0, 0, -4.4]),
        mer_gl(MER_ROLE_SPARK, 0.35, [0, -3.2, -1.2, -4.2]),
        mer_gl(MER_ROLE_SPARK, 0.35, [0, -3.2, 1.2, -4.2]),
    ]),
    _m("SHARD", 5, 1, [
        mer_gp(MER_ROLE_CORE, [0, -4.5, 2.0, -1.0, 1.1, 4.3, -1.1, 4.3, -2.0, -1.0]),
        mer_gl(MER_ROLE_SPARK, 0.4, [0, -4.5, 0, 4.3]),
    ]),
    _m("GLACIER", 5, 1, [
        mer_gp(MER_ROLE_HALO, [-4.2, 4.2, -1.4, -1.2, 1.4, 4.2]),
        mer_gp(MER_ROLE_CORE, [-0.6, 4.2, 2.2, -3.8, 4.2, 4.2]),
    ]),
    _m("CHILL", 5, 1, [
        mer_gl(MER_ROLE_HALO, 0.5, [-4.2, -3.4, 4.2, -3.4]),
        mer_gp(MER_ROLE_CORE, [-3.4, -3.0, -2.0, -3.0, -2.7, 1.4]),
        mer_gp(MER_ROLE_LIMB, [-0.7, -3.0, 0.7, -3.0, 0, 4.2]),
        mer_gp(MER_ROLE_CORE, [2.0, -3.0, 3.4, -3.0, 2.7, 0.6]),
    ]),
    _m("RIME", 5, 6, [
        mer_gl(MER_ROLE_HALO, 0.4, [0, -4.3, 3.72, -2.15]),
        mer_gl(MER_ROLE_CORE, 0.4, [0, -2.2, 0, 0]),
    ]),
    _m("FREEZE", 5, 3, [
        mer_gp(MER_ROLE_CORE, [0, -4.4, 1.5, -2.2, 0.9, 0.4, -0.9, 0.4, -1.5, -2.2]),
    ]),

    // --- STORM --------------------------------------------------------------------------------
    _m("BOLT", 6, 1, [
        mer_gp(MER_ROLE_CORE, [1.1, -4.5, -2.9, 0.7, -0.3, 0.7, -1.3, 4.5, 2.9, -0.9, 0.2, -0.9]),
    ]),
    _m("TEMPEST", 6, 1, [
        mer_ga(MER_ROLE_HALO, 0.5, 0, 0, 4.2, 30, 330),
        mer_ga(MER_ROLE_LIMB, 0.5, 0, 0, 2.9, -60, 240),
        mer_ga(MER_ROLE_CORE, 0.5, 0, 0, 1.6, 60, 360),
    ]),
    _m("GALE", 6, 3, [
        mer_ga(MER_ROLE_LIMB, 0.5, 0, 0, 3.6, -140, -40),
        mer_gd(MER_ROLE_SPARK, 2.76, -2.31, 0.6),
    ]),
    _m("THUNDER", 6, 1, [
        mer_ga(MER_ROLE_HALO, 0.7, 0, -1.4, 3.4, 185, 355),
        mer_gl(MER_ROLE_HALO, 0.7, [-3.4, -1.4, 3.4, -1.4]),
        mer_gp(MER_ROLE_CORE, [0.9, -0.8, -1.5, 2.0, 0.1, 2.0, -0.7, 4.4, 1.9, 1.2, 0.2, 1.2]),
    ]),
    _m("ARCFLOW", 6, 2, [
        mer_gd(MER_ROLE_CORE, 0, -3.6, 1.2),
        mer_gl(MER_ROLE_LIMB, 0.45, [0, -2.2, 1.4, -0.9, -1.4, 0.9, 0, 2.2]),
    ]),
    _m("CYCLONE", 6, 4, [
        mer_ga(MER_ROLE_LIMB, 0.45, 0, 0, 4.2, -110, -25),
        mer_ga(MER_ROLE_CORE, 0.45, 0, 0, 2.6, -110, -25),
    ]),

    // --- FORGE: crafting, machinery, engineering ----------------------------------------------
    _m("GEAR", 7, 8, [
        mer_gp(MER_ROLE_LIMB, [-0.85, -4.4, 0.85, -4.4, 0.85, -2.6, -0.85, -2.6]),
        mer_go(MER_ROLE_CORE, 0.9, 0, 0, 2.6),
    ]),
    _m("ANVIL", 7, 1, [
        mer_gp(MER_ROLE_CORE, [-4.2, -3.0, 4.2, -3.0, 2.6, -0.4, 1.0, -0.4, 1.0, 2.2,
                               2.8, 2.2, 2.8, 3.9, -2.8, 3.9, -2.8, 2.2, -1.0, 2.2, -1.0, -0.4, -2.6, -0.4]),
    ]),
    _m("CIRCUIT", 7, 2, [
        mer_gl(MER_ROLE_LIMB, 0.4, [-4.2, -2.4, -1.4, -2.4, -1.4, 0, 1.4, 0]),
        mer_gd(MER_ROLE_SPARK, -4.2, -2.4, 0.7),
        mer_gd(MER_ROLE_CORE, 0, 0, 0.9),
    ]),
    _m("PISTON", 7, 1, [
        mer_gp(MER_ROLE_HALO, [-2.6, -4.3, 2.6, -4.3, 2.6, -1.9, -2.6, -1.9]),
        mer_gp(MER_ROLE_CORE, [-1.0, -1.9, 1.0, -1.9, 1.0, 1.8, -1.0, 1.8]),
        mer_gp(MER_ROLE_LIMB, [-3.4, 1.8, 3.4, 1.8, 3.4, 4.2, -3.4, 4.2]),
    ]),
    _m("ALLOY", 7, 1, [
        mer_gp(MER_ROLE_LIMB, mer_poly_regular(6, 2.7, 90)),
        mer_go(MER_ROLE_CORE, 0.45, 1.9, 1.9, 2.2),
        mer_go(MER_ROLE_HALO, 0.45, -1.9, 1.9, 2.2),
    ]),
    _m("OVERCLOCK", 7, 1, [
        mer_ga(MER_ROLE_HALO, 0.6, 0, 1.4, 4.0, 15, 165),
        mer_gl(MER_ROLE_CORE, 0.6, [0, 1.4, 2.6, -1.6]),
        mer_gd(MER_ROLE_SPARK, 0, 1.4, 0.8),
    ]),
    ];
}

/// @func   mer_sigil_get()
/// @desc   Returns the motif table, building it on first use.
/// @return {Array} The table.
function mer_sigil_get() {
    if (!variable_global_exists("__mer_sigils")) {
        global.__mer_sigils = mer_sigil_build();
    }
    return global.__mer_sigils;
}

/// @func   mer_sigil_count()
/// @desc   How many motifs ship. DERIVED from the table, never a literal.
///
/// @remarks A sibling product shipped with a header claiming sixty-four forms over a table of seventy-five,
///          because the number was written by hand in a comment. Everything user-visible in this
///          package counts the array instead, so the documentation cannot drift from the code.
///
/// @return {Real} The count.
function mer_sigil_count() { return array_length(mer_sigil_get()); }

/// @func   mer_sigil_variant_count()
/// @desc   Total distinct marks the package can draw: motifs times disciplines.
/// @return {Real} The count.
function mer_sigil_variant_count() { return mer_sigil_count() * mer_discipline_count(); }

/// @func   mer_sigil_name(_index)
/// @desc   The motif's name.
/// @param  {Real} _index  Any integer; wrapped into range.
/// @return {String} The name.
function mer_sigil_name(_index) {
    var _t = mer_sigil_get(), _n = array_length(_t);
    return _t[(_index % _n + _n) % _n].n;
}

/// @func   mer_sigil_discipline(_index)
/// @desc   The motif's default discipline index.
/// @param  {Real} _index  Any integer; wrapped into range.
/// @return {Real} A discipline index.
function mer_sigil_discipline(_index) {
    var _t = mer_sigil_get(), _n = array_length(_t);
    return _t[(_index % _n + _n) % _n].d;
}

/// @func   mer_sigil_find(_name)
/// @desc   Looks a motif up by name so buyer code can read as mer_sigil_find("BOLT") rather than
///         as a magic number that shifts whenever a motif is inserted above it.
/// @param  {String} _name  Motif name, case sensitive.
/// @return {Real} The index, or -1 if not found.
function mer_sigil_find(_name) {
    var _t = mer_sigil_get(), _n = array_length(_t);
    for (var _i = 0; _i < _n; _i++) if (_t[_i].n == _name) return _i;
    return -1;
}

// ---------------------------------------------------------------------------------------------
// The renderer
// ---------------------------------------------------------------------------------------------

/// @func   mer_sigil_draw(_index, _cx, _cy, _size, _discipline, _alpha, _bloom, _desaturate)
/// @desc   Draws one motif in one discipline, centred on a point.
///
/// @remarks THREE PASSES, AND THE ORDER IS THE WHOLE LOOK.
///
///          1. BLOOM — every stroke redrawn at three times its weight in the halo colour at low
///             alpha, twice, at different widths. This is a cheap approximation of a glow and it
///             is what makes a flat vector mark read as something lit from inside. Filled shapes
///             are skipped: a bloomed fill just looks like a blurry fill.
///          2. BODY — the shapes as authored, in their role colours.
///          3. CORE — strokes redrawn thin in the spark colour down the middle of themselves.
///             One extra pass and the mark acquires a hot filament.
///
///          _desaturate exists for locked nodes. A locked skill drawn at low alpha alone still
///          reads as "loading"; drawn desaturated toward the theme's dim text colour it reads as
///          "not yours yet", which is the actual meaning.
///
/// @param  {Real} _index        Motif index. Wrapped into range.
/// @param  {Real} _cx           Centre x in pixels.
/// @param  {Real} _cy           Centre y in pixels.
/// @param  {Real} _size         Box size in pixels. The -5..+5 grid maps onto it.
/// @param  {Real} _discipline   Discipline index, or undefined for the motif's own default.
/// @param  {Real} _alpha        Overall alpha.
/// @param  {Real} _bloom        Bloom intensity multiplier. 0 disables the glow pass entirely.
/// @param  {Real} _desaturate   0 = full colour, 1 = fully drained toward the theme's dim text.
function mer_sigil_draw(_index, _cx, _cy, _size, _discipline = undefined, _alpha = 1,
                        _bloom = 1, _desaturate = 0) {
    if (_alpha <= 0 || _size <= 0) return;

    var _table = mer_sigil_get();
    var _n = array_length(_table);
    var _sig = _table[(_index % _n + _n) % _n];
    var _disc = is_undefined(_discipline) ? _sig.d : _discipline;
    var _pal = mer_discipline_palette(_disc);
    var _u = _size / 10;   // one grid unit in pixels

    // Resolve the four role colours once, applying the drain before anything is drawn.
    var _drain = clamp(_desaturate, 0, 1);
    var _dim = mer_theme_get().textDim;
    var _c = array_create(4);
    for (var _r = 0; _r < 4; _r++) {
        _c[_r] = (_drain <= 0) ? _pal[_r] : mer_colour_mix(_pal[_r], _dim, _drain);
    }

    var _shapes = _sig.s;
    var _count  = array_length(_shapes);
    var _sym    = max(1, _sig.y);
    var _step   = 360 / _sym;

    // --- pass 1: bloom -------------------------------------------------------------------------
    var _b = _bloom * (1 - _drain * 0.75);
    if (_b > 0.01) {
        for (var _ring = 0; _ring < 2; _ring++) {
            var _fat = (_ring == 0) ? 3.6 : 2.0;
            var _ba  = _alpha * _b * ((_ring == 0) ? 0.10 : 0.16);
            for (var _k = 0; _k < _sym; _k++) {
                for (var _i = 0; _i < _count; _i++) {
                    var _s = _shapes[_i];
                    if (_s.k == MER_SHAPE_POLY || _s.k == MER_SHAPE_DISC) continue;
                    mer_sigil_shape(_s, _cx, _cy, _u, _c[MER_ROLE_HALO], _ba, _k * _step, _fat);
                }
            }
        }
    }

    // --- pass 2: body --------------------------------------------------------------------------
    for (var _k = 0; _k < _sym; _k++) {
        for (var _i = 0; _i < _count; _i++) {
            var _s = _shapes[_i];
            mer_sigil_shape(_s, _cx, _cy, _u, _c[_s.r], _alpha, _k * _step, 1);
        }
    }

    // --- pass 3: core filament -----------------------------------------------------------------
    if (_drain < 0.9) {
        var _ca = _alpha * 0.5 * (1 - _drain);
        for (var _k = 0; _k < _sym; _k++) {
            for (var _i = 0; _i < _count; _i++) {
                var _s = _shapes[_i];
                if (_s.k == MER_SHAPE_POLY || _s.k == MER_SHAPE_DISC) continue;
                mer_sigil_shape(_s, _cx, _cy, _u, _c[MER_ROLE_SPARK], _ca, _k * _step, 0.34);
            }
        }
    }

    draw_set_alpha(1);
    draw_set_colour(c_white);
}

/// @func   mer_sigil_shape(_shape, _cx, _cy, _unit, _colour, _alpha, _rotation, _weight_scale)
/// @desc   Draws one shape of one motif, rotated about the sigil centre.
///
/// @remarks The triangulation is cached on the shape struct, and it is cached UNROTATED. Rotation
///          is applied to the triangulated vertices as they are emitted. That ordering matters:
///          triangulating per rotation would run ear clipping eight times per frame for an
///          eight-fold sigil, and caching a rotated triangulation would mean one cache entry per
///          angle. Topology does not change under rotation, so one cache serves every stamp.
///
/// @param  {Struct} _shape         A shape from a motif's s array.
/// @param  {Real}   _cx            Sigil centre x in pixels.
/// @param  {Real}   _cy            Sigil centre y in pixels.
/// @param  {Real}   _unit          Pixels per grid unit.
/// @param  {Real}   _colour        Colour to draw in.
/// @param  {Real}   _alpha         Alpha.
/// @param  {Real}   _rotation      Degrees to rotate about the centre.
/// @param  {Real}   _weight_scale  Multiplier on stroke weight. Used by the bloom and core passes.
function mer_sigil_shape(_shape, _cx, _cy, _unit, _colour, _alpha, _rotation = 0, _weight_scale = 1) {
    if (_alpha <= 0) return;
    var _p = _shape.p, _k = _shape.k;

    // Precomputed rotation. GML's lengthdir_* are convenient but they are two trig calls per
    // vertex; a sigil with eight-fold symmetry and a bloom pass emits a lot of vertices.
    var _rad = -degtorad(_rotation);
    var _cs  = cos(_rad), _sn = sin(_rad);

    draw_set_colour(_colour);
    draw_set_alpha(_alpha);

    switch (_k) {
        case MER_SHAPE_POLY: {
            var _np = array_length(_p) div 2;
            if (_np < 3) break;
            if (!variable_struct_exists(_shape, "t")) _shape.t = mer_poly_triangulate(_p);
            var _tri = _shape.t, _tn = array_length(_tri) div 2;
            if (_tn < 3) break;
            draw_primitive_begin(pr_trianglelist);
            for (var _i = 0; _i < _tn; _i++) {
                var _vx = _tri[_i * 2] * _unit, _vy = _tri[_i * 2 + 1] * _unit;
                draw_vertex(_cx + _vx * _cs - _vy * _sn, _cy + _vx * _sn + _vy * _cs);
            }
            draw_primitive_end();
            break;
        }
        case MER_SHAPE_LINE: {
            var _np = array_length(_p) div 2;
            var _w  = max(1, _shape.w * _unit * _weight_scale);
            var _px = 0, _py = 0, _qx = 0, _qy = 0;
            for (var _i = 0; _i < _np - 1; _i++) {
                var _ax = _p[_i * 2] * _unit,     _ay = _p[_i * 2 + 1] * _unit;
                var _bx = _p[_i * 2 + 2] * _unit, _by = _p[_i * 2 + 3] * _unit;
                _px = _cx + _ax * _cs - _ay * _sn;  _py = _cy + _ax * _sn + _ay * _cs;
                _qx = _cx + _bx * _cs - _by * _sn;  _qy = _cy + _bx * _sn + _by * _cs;
                draw_line_width(_px, _py, _qx, _qy, _w);
                // Round the joint at the far end of every segment but the last. Without this a
                // bent stroke shows a notch on the outside of each corner, very visible at 96 px.
                if (_w > 2 && _i < _np - 2) draw_circle(_qx, _qy, _w * 0.5, false);
            }
            break;
        }
        case MER_SHAPE_DISC: {
            var _dx = _p[0] * _unit, _dy = _p[1] * _unit;
            draw_circle(_cx + _dx * _cs - _dy * _sn, _cy + _dx * _sn + _dy * _cs, _p[2] * _unit, false);
            break;
        }
        case MER_SHAPE_RING: {
            // A true annulus from a triangle strip. Drawing a disc and punching a smaller one out
            // in the background colour would leave a visible plug, because sigils are drawn over
            // gradients and over the tree's link lines.
            var _w  = max(1, _shape.w * _unit * _weight_scale);
            var _ox = _p[0] * _unit, _oy = _p[1] * _unit;
            var _rx = _cx + _ox * _cs - _oy * _sn, _ry = _cy + _ox * _sn + _oy * _cs;
            var _rr = _p[2] * _unit;
            var _outer = _rr + _w * 0.5, _inner = max(0, _rr - _w * 0.5);
            draw_primitive_begin(pr_trianglestrip);
            for (var _i = 0; _i <= 40; _i++) {
                var _a = _i / 40 * 2 * pi, _ca = cos(_a), _sa = sin(_a);
                draw_vertex(_rx + _ca * _outer, _ry + _sa * _outer);
                draw_vertex(_rx + _ca * _inner, _ry + _sa * _inner);
            }
            draw_primitive_end();
            break;
        }
        case MER_SHAPE_ARC: {
            var _w  = max(1, _shape.w * _unit * _weight_scale);
            var _ox = _p[0] * _unit, _oy = _p[1] * _unit;
            var _rx = _cx + _ox * _cs - _oy * _sn, _ry = _cy + _ox * _sn + _oy * _cs;
            var _rr = _p[2] * _unit;
            var _f = _p[3] - _rotation, _t2 = _p[4] - _rotation;
            var _steps = max(2, ceil(abs(_t2 - _f) / 9));
            var _cap = (_w > 2);
            for (var _i = 0; _i < _steps; _i++) {
                var _a1 = lerp(_f, _t2, _i / _steps);
                var _a2 = lerp(_f, _t2, (_i + 1) / _steps);
                var _x1 = _rx + lengthdir_x(_rr, _a1), _y1 = _ry + lengthdir_y(_rr, _a1);
                var _x2 = _rx + lengthdir_x(_rr, _a2), _y2 = _ry + lengthdir_y(_rr, _a2);
                draw_line_width(_x1, _y1, _x2, _y2, _w);
                if (_cap && _i < _steps - 1) draw_circle(_x2, _y2, _w * 0.5, false);
            }
            break;
        }
    }

    draw_set_alpha(1);
}

/// @func   mer_poly_triangulate(_points)
/// @desc   Ear-clipping triangulation of a simple polygon. Handles concave shapes; does not handle
///         self-intersecting ones, which no motif should be.
///
/// @remarks THIS EXISTS BECAUSE THE OBVIOUS IMPLEMENTATION IS SILENTLY WRONG. A filled polygon
///          drawn as pr_trianglefan from vertex 0 is only correct when the polygon is star-shaped
///          about that vertex. Meridian's HEART, MEND, ANVIL, BOLT and every mer_poly_star are
///          not. Fanned, they lose their concavities and render as blobs — and they COMPILE
///          PERFECTLY while doing it. The identical bug shipped three broken icons in a sibling
///          product before anyone rendered the executable and looked at the picture.
///
///          Winding is normalised first so the convexity test has one sign to check. The bail-out
///          counter is not defensive padding: a degenerate polygon has no ear to find, and without
///          it the loop never terminates and the game hangs inside a draw call.
///
/// @param  {Array} _points  Flat x,y list, at least three vertices.
/// @return {Array} Flat x,y list, three vertices per triangle.
/// @pure
function mer_poly_triangulate(_points) {
    var _n = array_length(_points) div 2;
    if (_n < 3) return [];

    var _area = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _j = (_i + 1) mod _n;
        _area += _points[_i * 2] * _points[_j * 2 + 1] - _points[_j * 2] * _points[_i * 2 + 1];
    }

    var _idx = [];
    if (_area < 0) { for (var _i = _n - 1; _i >= 0; _i--) array_push(_idx, _i); }
    else           { for (var _i = 0; _i < _n; _i++)     array_push(_idx, _i); }

    var _out = [];
    var _guard = _n * _n + 8;
    var _count = array_length(_idx);

    while (_count > 3 && _guard-- > 0) {
        var _clipped = false;
        for (var _k = 0; _k < _count; _k++) {
            var _ia = _idx[(_k + _count - 1) mod _count];
            var _ib = _idx[_k];
            var _ic = _idx[(_k + 1) mod _count];

            var _ax = _points[_ia * 2], _ay = _points[_ia * 2 + 1];
            var _bx = _points[_ib * 2], _by = _points[_ib * 2 + 1];
            var _cx = _points[_ic * 2], _cy = _points[_ic * 2 + 1];

            var _cross = (_bx - _ax) * (_cy - _ay) - (_by - _ay) * (_cx - _ax);
            if (_cross <= 0) continue;

            var _clear = true;
            for (var _m = 0; _m < _count; _m++) {
                var _ip = _idx[_m];
                if (_ip == _ia || _ip == _ib || _ip == _ic) continue;
                var _px = _points[_ip * 2], _py = _points[_ip * 2 + 1];
                var _d1 = (_bx - _ax) * (_py - _ay) - (_by - _ay) * (_px - _ax);
                var _d2 = (_cx - _bx) * (_py - _by) - (_cy - _by) * (_px - _bx);
                var _d3 = (_ax - _cx) * (_py - _cy) - (_ay - _cy) * (_px - _cx);
                if (_d1 >= 0 && _d2 >= 0 && _d3 >= 0) { _clear = false; break; }
            }
            if (!_clear) continue;

            array_push(_out, _ax, _ay, _bx, _by, _cx, _cy);
            array_delete(_idx, _k, 1);
            _count--;
            _clipped = true;
            break;
        }
        if (!_clipped) break;   // self-intersecting or degenerate: stop rather than spin
    }

    if (_count == 3) {
        for (var _k = 0; _k < 3; _k++) {
            array_push(_out, _points[_idx[_k] * 2], _points[_idx[_k] * 2 + 1]);
        }
    }
    return _out;
}
