{
  "$GMScript": "v1",
  "%Name": "mer_progress",
  "isCompatibility": false,
  "isDnD": false,
  "name": "mer_progress",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}