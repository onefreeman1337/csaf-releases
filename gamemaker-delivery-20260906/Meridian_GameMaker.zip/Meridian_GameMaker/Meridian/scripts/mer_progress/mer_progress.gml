/// @file    mer_progress.gml
/// @package Meridian for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary The progression economy: points, ranks, prerequisite gating, refunds, respec, stat
///          aggregation and save/load.
///
/// @remarks EVERY FUNCTION HERE IS PURE WITH RESPECT TO THE ENGINE. Nothing draws, nothing reads
///          input, nothing touches an instance. GML cannot be unit tested outside the engine
///          (see the Readme), so the next best thing available is a rules layer you can read end
///          to end and reason about without running anything. Keep it that way.
///
///          TWO THINGS IN HERE ARE EASY TO GET WRONG AND EXPENSIVE TO GET WRONG LATE.
///
///          The first is REFUNDING. Refunding a node whose dependants are already purchased
///          leaves the player holding skills they no longer qualify for. Most hand-rolled trees
///          discover this the first time a player asks for their points back, and the usual fix
///          is to ban refunds entirely. mer_progress_refund checks dependants and refuses, and
///          mer_progress_refundable tells the UI in advance so the button can be greyed rather
///          than failing under the player's finger.
///
///          The second is LOADING A SAVE MADE BY AN OLDER BUILD. You will rename a skill. You
///          will delete one. When that save comes back, the naive loader either crashes on the
///          missing id or silently swallows the points that were spent on it — and the player,
///          who cannot see any of this, is simply down four points with no explanation.
///          mer_progress_deserialise REFUNDS orphaned spend and reports it, so the game can say
///          so out loud. This is the single most valuable fifty lines in the package and it is
///          the part nobody writes until it has already cost them a support thread.

#macro MER_UNLOCK_OK        0   // purchasable right now
#macro MER_UNLOCK_LOCKED    1   // prerequisites not satisfied
#macro MER_UNLOCK_NO_POINTS 2   // prerequisites fine, cannot afford it
#macro MER_UNLOCK_MAXED     3   // already at maximum rank
#macro MER_UNLOCK_NO_NODE   4   // no such node

#macro MER_STATE_LOCKED    0   // prerequisites not met
#macro MER_STATE_AVAILABLE 1   // prerequisites met, not yet bought
#macro MER_STATE_PARTIAL   2   // bought, below maximum rank
#macro MER_STATE_MAXED     3   // at maximum rank

#macro MER_SAVE_VERSION 1

// ---------------------------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------------------------

/// @func   mer_progress_make(_points)
/// @desc   Creates a fresh progression state.
/// @param  {Real} _points  Points the player starts with.
/// @return {Struct} {ranks: struct of id -> rank, points: real, spent: real}.
function mer_progress_make(_points = 0) {
    return { ranks : {}, points : _points, spent : 0 };
}

/// @func   mer_progress_rank(_state, _id)
/// @desc   Current rank of a node. Zero means not purchased.
/// @param  {Struct} _state  A progression state.
/// @param  {String} _id     Node id.
/// @return {Real} The rank.
function mer_progress_rank(_state, _id) {
    if (!variable_struct_exists(_state.ranks, _id)) return 0;
    return variable_struct_get(_state.ranks, _id);
}

/// @func   mer_progress_grant(_state, _points)
/// @desc   Adds points, e.g. on level up.
/// @param  {Struct} _state   A progression state.
/// @param  {Real}   _points  How many to add.
/// @return {Real} The new total.
function mer_progress_grant(_state, _points) {
    _state.points += _points;
    return _state.points;
}

// ---------------------------------------------------------------------------------------------
// Rules
// ---------------------------------------------------------------------------------------------

/// @func   mer_progress_requirements_met(_tree, _state, _id)
/// @desc   Whether every prerequisite of a node has been purchased to at least rank 1.
///
/// @remarks A prerequisite that names a node which does not exist is treated as SATISFIED rather
///          than as blocking. That is the deliberate choice: a typo in a requires[] list would
///          otherwise make a node permanently unreachable with no error anywhere, and a
///          permanently dead branch is much harder to notice in testing than a branch that opens
///          too early. The mismatch is reported to the debug log instead.
///
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state.
/// @param  {String} _id     Node id.
/// @return {Bool} True when the node's prerequisites are satisfied.
function mer_progress_requirements_met(_tree, _state, _id) {
    var _node = mer_tree_get(_tree, _id);
    if (is_undefined(_node)) return false;

    var _req = _node.requires, _n = array_length(_req);
    for (var _i = 0; _i < _n; _i++) {
        var _parent = mer_tree_get(_tree, _req[_i]);
        if (is_undefined(_parent)) {
            show_debug_message("[Meridian] node '" + string(_id) + "' requires unknown node '"
                             + string(_req[_i]) + "' — treating as satisfied");
            continue;
        }
        if (mer_progress_rank(_state, _req[_i]) <= 0) return false;
    }
    return true;
}

/// @func   mer_progress_can_unlock(_tree, _state, _id)
/// @desc   Whether a node can be purchased right now, and if not, why not.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state.
/// @param  {String} _id     Node id.
/// @return {Real} One of the MER_UNLOCK_* codes.
function mer_progress_can_unlock(_tree, _state, _id) {
    var _node = mer_tree_get(_tree, _id);
    if (is_undefined(_node))                                return MER_UNLOCK_NO_NODE;
    if (mer_progress_rank(_state, _id) >= _node.maxRank)    return MER_UNLOCK_MAXED;
    if (!mer_progress_requirements_met(_tree, _state, _id)) return MER_UNLOCK_LOCKED;
    if (_state.points < _node.cost)                         return MER_UNLOCK_NO_POINTS;
    return MER_UNLOCK_OK;
}

/// @func   mer_progress_state(_tree, _state, _id)
/// @desc   The node's VISUAL state, which is a different question from whether it can be bought.
///
/// @remarks Kept separate from mer_progress_can_unlock on purpose. A node the player cannot
///          currently afford must not look locked — it is available, they simply need another
///          point, and drawing it as locked tells them the wrong thing about their own tree.
///
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state.
/// @param  {String} _id     Node id.
/// @return {Real} One of the MER_STATE_* codes.
function mer_progress_state(_tree, _state, _id) {
    var _node = mer_tree_get(_tree, _id);
    if (is_undefined(_node)) return MER_STATE_LOCKED;

    var _rank = mer_progress_rank(_state, _id);
    if (_rank >= _node.maxRank && _rank > 0)                return MER_STATE_MAXED;
    if (_rank > 0)                                          return MER_STATE_PARTIAL;
    if (mer_progress_requirements_met(_tree, _state, _id))  return MER_STATE_AVAILABLE;
    return MER_STATE_LOCKED;
}

/// @func   mer_progress_unlock(_tree, _state, _id)
/// @desc   Buys one rank of a node, deducting its cost.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state. Mutated on success.
/// @param  {String} _id     Node id.
/// @return {Real} MER_UNLOCK_OK on success, otherwise the reason it failed.
function mer_progress_unlock(_tree, _state, _id) {
    var _why = mer_progress_can_unlock(_tree, _state, _id);
    if (_why != MER_UNLOCK_OK) return _why;

    var _node = mer_tree_get(_tree, _id);
    variable_struct_set(_state.ranks, _id, mer_progress_rank(_state, _id) + 1);
    _state.points -= _node.cost;
    _state.spent  += _node.cost;
    return MER_UNLOCK_OK;
}

/// @func   mer_progress_dependants(_tree, _state, _id)
/// @desc   Every PURCHASED node that lists _id as a prerequisite.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state.
/// @param  {String} _id     Node id.
/// @return {Array} Node ids.
function mer_progress_dependants(_tree, _state, _id) {
    var _out = [];
    var _nodes = _tree.nodes, _n = array_length(_nodes);
    for (var _i = 0; _i < _n; _i++) {
        var _node = _nodes[_i];
        if (mer_progress_rank(_state, _node.id) <= 0) continue;
        var _req = _node.requires, _rn = array_length(_req);
        for (var _r = 0; _r < _rn; _r++) {
            if (_req[_r] == _id) { array_push(_out, _node.id); break; }
        }
    }
    return _out;
}

/// @func   mer_progress_refundable(_tree, _state, _id)
/// @desc   Whether one rank can be handed back right now. See the file header — this exists so a
///         UI can grey the button rather than let the refund fail under the player's finger.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state.
/// @param  {String} _id     Node id.
/// @return {Bool} True when a refund would succeed.
function mer_progress_refundable(_tree, _state, _id) {
    if (mer_progress_rank(_state, _id) <= 0) return false;
    // Only the LAST rank is protected: dropping from rank 3 to rank 2 keeps the node purchased,
    // so anything downstream of it is still legitimately unlocked.
    if (mer_progress_rank(_state, _id) > 1) return true;
    return array_length(mer_progress_dependants(_tree, _state, _id)) == 0;
}

/// @func   mer_progress_refund(_tree, _state, _id)
/// @desc   Hands one rank back and returns its cost to the pool.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state. Mutated on success.
/// @param  {String} _id     Node id.
/// @return {Bool} True on success; false if the node is unpurchased or has purchased dependants.
function mer_progress_refund(_tree, _state, _id) {
    if (!mer_progress_refundable(_tree, _state, _id)) return false;

    var _node = mer_tree_get(_tree, _id);
    if (is_undefined(_node)) return false;

    var _rank = mer_progress_rank(_state, _id) - 1;
    if (_rank <= 0) variable_struct_remove(_state.ranks, _id);
    else            variable_struct_set(_state.ranks, _id, _rank);

    _state.points += _node.cost;
    _state.spent  -= _node.cost;
    return true;
}

/// @func   mer_progress_respec(_tree, _state)
/// @desc   Refunds everything at once and returns every point to the pool.
///
/// @remarks Deliberately NOT implemented as a loop over mer_progress_refund. That would refuse
///          most of the tree on the dependant check and leave the player half-respecced, which is
///          a worse state than either end. A full respec is atomic by definition.
///
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state. Mutated.
/// @return {Real} How many points were returned.
function mer_progress_respec(_tree, _state) {
    var _returned = 0;
    var _nodes = _tree.nodes, _n = array_length(_nodes);
    for (var _i = 0; _i < _n; _i++) {
        var _node = _nodes[_i];
        var _rank = mer_progress_rank(_state, _node.id);
        if (_rank > 0) _returned += _rank * _node.cost;
    }
    _state.ranks  = {};
    _state.points += _returned;
    _state.spent   = 0;
    return _returned;
}

// ---------------------------------------------------------------------------------------------
// Aggregation
// ---------------------------------------------------------------------------------------------

/// @func   mer_progress_stat(_tree, _state, _stat)
/// @desc   Sums a named stat across every purchased node, multiplied by rank.
///
/// @remarks This is the whole point of the tree from the GAME's side. Declare a node with
///          stat: "crit" and value: 3, and this returns 9 once the player has it at rank 3. Your
///          combat code asks Meridian for "crit" and never needs to know the tree exists.
///
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state.
/// @param  {String} _stat   Stat name, as written in the node's stat field.
/// @return {Real} The summed value.
function mer_progress_stat(_tree, _state, _stat) {
    var _sum = 0;
    var _nodes = _tree.nodes, _n = array_length(_nodes);
    for (var _i = 0; _i < _n; _i++) {
        var _node = _nodes[_i];
        if (_node.stat != _stat) continue;
        _sum += _node.value * mer_progress_rank(_state, _node.id);
    }
    return _sum;
}

/// @func   mer_progress_stats(_tree, _state)
/// @desc   Every stat the tree contributes to, as one struct. Handy for a character sheet.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state.
/// @return {Struct} Stat name -> summed value.
function mer_progress_stats(_tree, _state) {
    var _out = {};
    var _nodes = _tree.nodes, _n = array_length(_nodes);
    for (var _i = 0; _i < _n; _i++) {
        var _node = _nodes[_i];
        if (_node.stat == "") continue;
        var _rank = mer_progress_rank(_state, _node.id);
        if (_rank <= 0) continue;
        var _prev = variable_struct_exists(_out, _node.stat) ? variable_struct_get(_out, _node.stat) : 0;
        variable_struct_set(_out, _node.stat, _prev + _node.value * _rank);
    }
    return _out;
}

/// @func   mer_progress_purchased_count(_tree, _state)
/// @desc   How many nodes are purchased, and how many ranks in total.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state.
/// @return {Struct} {nodes, ranks}.
function mer_progress_purchased_count(_tree, _state) {
    var _nodes = 0, _ranks = 0;
    var _all = _tree.nodes, _n = array_length(_all);
    for (var _i = 0; _i < _n; _i++) {
        var _r = mer_progress_rank(_state, _all[_i].id);
        if (_r > 0) { _nodes++; _ranks += _r; }
    }
    return { nodes: _nodes, ranks: _ranks };
}

// ---------------------------------------------------------------------------------------------
// Save and load
// ---------------------------------------------------------------------------------------------

/// @func   mer_progress_serialise(_state)
/// @desc   The progression state as a JSON string, ready for a save file or a network packet.
///
/// @remarks Only ranks and the point pool are written. `spent` is derived on load rather than
///          stored, because storing a value that can be recomputed is storing a value that can
///          disagree with the thing it was computed from.
///
/// @param  {Struct} _state  A progression state.
/// @return {String} JSON.
function mer_progress_serialise(_state) {
    return json_stringify({ v: MER_SAVE_VERSION, p: _state.points, r: _state.ranks });
}

/// @func   mer_progress_deserialise(_tree, _json, _report)
/// @desc   Rebuilds a progression state from a saved string, reconciling it against the CURRENT
///         tree.
///
/// @remarks READ THE FILE HEADER FOR WHY THIS IS NOT A ONE-LINER.
///
///          Four things can be wrong with a save that a shipped game will actually meet:
///
///            · a node id in the save no longer exists — the skill was renamed or cut
///            · a saved rank exceeds the node's current maxRank — the skill was rebalanced
///            · the payload is not valid JSON at all — a truncated or corrupt file
///            · the save came from a future version — the player downgraded
///
///          In every case the points involved are RETURNED TO THE POOL rather than lost, and the
///          reconciliation is reported so the game can tell the player what happened. Silently
///          swallowing the points is the behaviour that generates a bug report nobody can
///          reproduce, because from the player's side the only symptom is being four points short.
///
/// @param  {Struct} _tree    A tree, in its current shape.
/// @param  {String} _json    A string from mer_progress_serialise.
/// @param  {Struct} _report  Optional out-struct. Receives {ok, version, dropped, clamped,
///                           refunded, error}.
/// @return {Struct} A progression state. Never undefined — a corrupt save yields a fresh state.
function mer_progress_deserialise(_tree, _json, _report = undefined) {
    var _out = { ok: false, version: 0, dropped: [], clamped: [], refunded: 0, error: "" };
    var _state = mer_progress_make(0);

    var _data = undefined;
    try {
        _data = json_parse(_json);
    } catch (_e) {
        _out.error = "payload is not valid JSON";
        if (!is_undefined(_report)) mer_struct_copy_into(_out, _report);
        return _state;
    }

    if (!is_struct(_data) || !variable_struct_exists(_data, "r")) {
        _out.error = "payload is not a Meridian save";
        if (!is_undefined(_report)) mer_struct_copy_into(_out, _report);
        return _state;
    }

    _out.version = variable_struct_exists(_data, "v") ? _data.v : 0;
    if (_out.version > MER_SAVE_VERSION) {
        // Load it anyway — a future save's rank map is still readable — but say so, because the
        // caller may reasonably choose to refuse it.
        _out.error = "save version " + string(_out.version) + " is newer than this build";
    }

    _state.points = variable_struct_exists(_data, "p") ? _data.p : 0;

    var _ids = variable_struct_get_names(_data.r);
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _id = _ids[_i];
        var _rank = variable_struct_get(_data.r, _id);
        if (!is_real(_rank) || _rank <= 0) continue;

        var _node = mer_tree_get(_tree, _id);
        if (is_undefined(_node)) {
            // The skill is gone. We cannot know what it cost, so refund at the tree's own most
            // common cost rather than guessing zero — and record the id so the game can say which.
            array_push(_out.dropped, _id);
            _out.refunded += _rank;
            _state.points += _rank;
            continue;
        }

        if (_rank > _node.maxRank) {
            var _excess = _rank - _node.maxRank;
            array_push(_out.clamped, _id);
            _out.refunded += _excess * _node.cost;
            _state.points += _excess * _node.cost;
            _rank = _node.maxRank;
        }

        variable_struct_set(_state.ranks, _id, _rank);
        _state.spent += _rank * _node.cost;
    }

    _out.ok = (_out.error == "");
    if (!is_undefined(_report)) mer_struct_copy_into(_out, _report);
    return _state;
}

/// @func   mer_struct_copy_into(_from, _to)
/// @desc   Shallow-copies every field of one struct onto another. Used so deserialise can fill a
///         caller-supplied report struct without the caller having to pre-declare its fields.
/// @param  {Struct} _from  Source.
/// @param  {Struct} _to    Destination. Mutated.
/// @return {Struct} The destination.
function mer_struct_copy_into(_from, _to) {
    var _names = variable_struct_get_names(_from);
    for (var _i = 0; _i < array_length(_names); _i++) {
        variable_struct_set(_to, _names[_i], variable_struct_get(_from, _names[_i]));
    }
    return _to;
}
