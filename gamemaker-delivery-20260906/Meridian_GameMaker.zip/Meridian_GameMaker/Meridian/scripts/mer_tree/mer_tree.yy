{
  "$GMScript": "v1",
  "%Name": "mer_tree",
  "isCompatibility": false,
  "isDnD": false,
  "name": "mer_tree",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}