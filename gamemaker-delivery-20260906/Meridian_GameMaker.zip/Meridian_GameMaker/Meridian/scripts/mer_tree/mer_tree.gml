/// @file    mer_tree.gml
/// @package Meridian for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary The graph: nodes, prerequisite edges, and four layout engines that position them.
///
/// @remarks THE LAYOUT ENGINES ARE THE PART WORTH READING.
///
///          A skill tree's node positions are almost always typed in by hand, one pair of
///          coordinates per node, and then re-typed every time a node is inserted. That is the
///          real reason skill trees get frozen early in a project: moving one node means moving
///          nine.
///
///          Here you declare only what depends on what. The layout is DERIVED — from depth in the
///          prerequisite graph and from which discipline a node belongs to. Insert a node, and
///          everything downstream of it moves out of the way on its own. Change your mind about
///          the shape of the whole screen and it is one function call, because the same graph
///          lays out as a constellation, a branching tree, concentric rings or a column grid.
///
///          Nothing in this file draws. Positions come out in TREE SPACE — an arbitrary
///          coordinate system centred on the origin — and mer_view.gml maps tree space to screen
///          space through its own pan and zoom. Keeping those separate is what lets the view
///          animate a layout change: it can interpolate between two sets of tree-space positions
///          without knowing anything about what produced them.

#macro MER_TIER_MINOR    0   // a small stat node. Drawn as a plain disc.
#macro MER_TIER_MAJOR    1   // a real ability. Drawn framed.
#macro MER_TIER_KEYSTONE 2   // build-defining. Drawn with a double frame and spokes.

// ---------------------------------------------------------------------------------------------
// Construction
// ---------------------------------------------------------------------------------------------

/// @func   mer_tree_make()
/// @desc   Creates an empty tree.
/// @return {Struct} A tree: {nodes: array, byId: struct, dirty: bool}.
function mer_tree_make() {
    return {
        nodes : [],
        byId  : {},     // id string -> array index, so lookups are not a linear scan
        dirty : true,   // set when the graph changes; cleared by a layout pass
    };
}

/// @func   mer_tree_add(_tree, _id, _def)
/// @desc   Adds a node.
///
/// @remarks _def is a plain struct and every field is optional except name. Defaults are chosen
///          so that the shortest useful call is genuinely short:
///
///              mer_tree_add(_tree, "cleave", { name: "CLEAVE", requires: ["root"] });
///
///          The sigil defaults to a motif whose name matches, then to a stable hash of the id.
///          That second fallback matters more than it looks: it means a tree of forty nodes drawn
///          before a single sigil has been chosen still shows forty DIFFERENT marks, so the
///          screen is legible while you are still designing it.
///
/// @param  {Struct} _tree  A tree from mer_tree_make.
/// @param  {String} _id    Unique id. Used by requires[] and by the save format.
/// @param  {Struct} _def   {name, desc, sigil, disc, tier, cost, maxRank, requires, stat, value}.
/// @return {Struct} The node struct that was added.
function mer_tree_add(_tree, _id, _def) {
    if (variable_struct_exists(_tree.byId, _id)) {
        show_debug_message("[Meridian] duplicate node id '" + string(_id) + "' ignored");
        return undefined;
    }

    var _name = variable_struct_exists(_def, "name") ? _def.name : string_upper(_id);

    // Sigil resolution: explicit index, then explicit name, then name-match, then id hash.
    var _sig = -1;
    if (variable_struct_exists(_def, "sigil")) {
        _sig = is_string(_def.sigil) ? mer_sigil_find(_def.sigil) : _def.sigil;
    }
    if (_sig < 0) _sig = mer_sigil_find(_name);
    if (_sig < 0) {
        var _h = 0;
        for (var _i = 1; _i <= string_length(_id); _i++) _h = (_h * 31 + ord(string_char_at(_id, _i))) % 100003;
        _sig = _h % mer_sigil_count();
    }

    var _node = {
        id       : _id,
        name     : _name,
        desc     : variable_struct_exists(_def, "desc")     ? _def.desc     : "",
        sigil    : _sig,
        disc     : variable_struct_exists(_def, "disc")     ? _def.disc     : mer_sigil_discipline(_sig),
        tier     : variable_struct_exists(_def, "tier")     ? _def.tier     : MER_TIER_MINOR,
        cost     : variable_struct_exists(_def, "cost")     ? _def.cost     : 1,
        maxRank  : variable_struct_exists(_def, "maxRank")  ? _def.maxRank  : 1,
        requires : variable_struct_exists(_def, "requires") ? _def.requires : [],
        stat     : variable_struct_exists(_def, "stat")     ? _def.stat     : "",
        value    : variable_struct_exists(_def, "value")    ? _def.value    : 0,
        // Filled by the layout pass.
        lx : 0, ly : 0, depth : 0, arm : 0,
    };

    variable_struct_set(_tree.byId, _id, array_length(_tree.nodes));
    array_push(_tree.nodes, _node);
    _tree.dirty = true;
    return _node;
}

/// @func   mer_tree_get(_tree, _id)
/// @desc   Looks a node up by id.
/// @param  {Struct} _tree  A tree.
/// @param  {String} _id    Node id.
/// @return {Struct} The node, or undefined.
function mer_tree_get(_tree, _id) {
    if (!variable_struct_exists(_tree.byId, _id)) return undefined;
    return _tree.nodes[variable_struct_get(_tree.byId, _id)];
}

/// @func   mer_tree_count(_tree)
/// @desc   How many nodes the tree holds.
/// @param  {Struct} _tree  A tree.
/// @return {Real} The count.
function mer_tree_count(_tree) { return array_length(_tree.nodes); }

// ---------------------------------------------------------------------------------------------
// Depth
// ---------------------------------------------------------------------------------------------

/// @func   mer_tree_compute_depth(_tree)
/// @desc   Assigns every node its distance from the nearest root, and its "arm" — the discipline
///         group it will be laid out along.
///
/// @remarks Depth is longest-path-from-root rather than shortest. That is deliberate: a node
///          requiring both a depth-1 and a depth-4 prerequisite belongs visually AFTER both, and
///          shortest-path would place it at depth 2 with an edge running backwards across four
///          rings of the layout. Longest path guarantees every edge points outward.
///
///          Iterated to a fixed point rather than recursed, because a buyer's graph may contain a
///          cycle by accident and a recursive walk would blow the stack instead of reporting it.
///          The iteration cap is the node count: a correct DAG always converges within it, so
///          hitting the cap IS the cycle detection.
///
/// @param  {Struct} _tree  A tree.
/// @return {Bool} True if the graph is a clean DAG; false if a cycle was detected.
function mer_tree_compute_depth(_tree) {
    var _nodes = _tree.nodes, _n = array_length(_nodes);
    for (var _i = 0; _i < _n; _i++) _nodes[_i].depth = 0;

    var _clean = false;
    for (var _pass = 0; _pass < _n && !_clean; _pass++) {
        var _changed = false;
        for (var _i = 0; _i < _n; _i++) {
            var _node = _nodes[_i];
            var _req = _node.requires, _rn = array_length(_req);
            for (var _r = 0; _r < _rn; _r++) {
                var _parent = mer_tree_get(_tree, _req[_r]);
                if (is_undefined(_parent)) continue;
                if (_parent.depth + 1 > _node.depth) { _node.depth = _parent.depth + 1; _changed = true; }
            }
        }
        if (!_changed) _clean = true;
    }

    if (!_clean) show_debug_message("[Meridian] prerequisite cycle detected — layout will be approximate");

    // Arm assignment: a node inherits its first ancestor's arm so a branch stays together, and a
    // root starts a new arm of its own. Without this, two disciplines that share a root would
    // interleave and the constellation would read as noise.
    for (var _i = 0; _i < _n; _i++) _nodes[_i].arm = -1;
    var _arms = 0;
    for (var _pass = 0; _pass < _n; _pass++) {
        for (var _i = 0; _i < _n; _i++) {
            var _node = _nodes[_i];
            if (_node.arm >= 0) continue;
            if (array_length(_node.requires) == 0) { _node.arm = _arms++; continue; }
            var _parent = mer_tree_get(_tree, _node.requires[0]);
            if (!is_undefined(_parent) && _parent.arm >= 0) _node.arm = _parent.arm;
        }
    }
    for (var _i = 0; _i < _n; _i++) if (_nodes[_i].arm < 0) _nodes[_i].arm = 0;

    return _clean;
}

// ---------------------------------------------------------------------------------------------
// Layouts. Each writes lx/ly on every node and clears the dirty flag.
// ---------------------------------------------------------------------------------------------

/// @func   mer_layout_constellation(_tree, _spacing, _spread)
/// @desc   Radial arms fanning out from a common origin. The default, and the one the product is
///         named for.
///
/// @remarks Two details do the work. Nodes at the same depth on the same arm are fanned by a
///          small angle rather than stacked, so a branch that splits reads as a branch; and the
///          ring radius grows slightly faster than linearly, so the outer rings have room for the
///          extra nodes a tree accumulates as it widens. A strictly linear radius makes every
///          tree look cramped at the rim, which is the giveaway of a hand-rolled layout.
///
/// @param  {Struct} _tree     A tree.
/// @param  {Real}   _spacing  Base ring spacing in tree units.
/// @param  {Real}   _spread   Degrees of fan between siblings at the same depth.
function mer_layout_constellation(_tree, _spacing = 96, _wedge_fill = 0.66) {
    mer_tree_compute_depth(_tree);
    var _nodes = _tree.nodes, _n = array_length(_nodes);
    if (_n == 0) { _tree.dirty = false; return; }

    var _maxArm = 0;
    for (var _i = 0; _i < _n; _i++) _maxArm = max(_maxArm, _nodes[_i].arm);
    var _armCount = _maxArm + 1;
    var _wedge = (360 / _armCount) * _wedge_fill;

    // TWO PASSES, AND THE FIRST ONE IS THE WHOLE FIX.
    //
    // The original single-pass version fanned siblings by a FIXED angle either side of the arm's
    // centre line without knowing how many siblings there would be. With six arms only sixty
    // degrees apart, a three-way split at one depth reached straight into its neighbour's
    // territory, and the result was a huddle with links crossing everywhere rather than a
    // constellation. Counting first means each depth's siblings can be distributed across the
    // arm's OWN wedge and nothing can stray outside it.
    var _count = {};
    for (var _i = 0; _i < _n; _i++) {
        var _key = string(_nodes[_i].arm) + ":" + string(_nodes[_i].depth);
        var _c = variable_struct_exists(_count, _key) ? variable_struct_get(_count, _key) : 0;
        variable_struct_set(_count, _key, _c + 1);
    }

    var _seen = {};
    for (var _i = 0; _i < _n; _i++) {
        var _node = _nodes[_i];
        var _key = string(_node.arm) + ":" + string(_node.depth);
        var _total = variable_struct_get(_count, _key);
        var _ord = variable_struct_exists(_seen, _key) ? variable_struct_get(_seen, _key) : 0;
        variable_struct_set(_seen, _key, _ord + 1);

        var _base = (_node.arm / _armCount) * 360 - 90;
        // Spread the k siblings across the wedge, centred on the arm's line. A lone node sits
        // exactly on it; two straddle it; three put one on it and one either side.
        var _off = (_total <= 1) ? 0 : (_ord / (_total - 1) - 0.5) * _wedge;
        var _ang = _base + _off;

        // Radius grows by a constant per depth with the roots already off the origin. The old
        // power curve put depth 0 and depth 1 too close together, so a root and its children
        // overlapped.
        var _rad = _spacing * (0.95 + _node.depth * 1.05);

        _node.lx = lengthdir_x(_rad, _ang);
        // Squashed vertically on purpose. A true circle is 1:1 and every viewport a progression
        // screen lives in is 16:9, so a circular constellation wastes the sides and forces the
        // zoom down until the nodes are too small to read. Squashing to 0.72 fills the frame.
        _node.ly = lengthdir_y(_rad, _ang) * 0.66;
    }
    _tree.dirty = false;
}

/// @func   mer_layout_branching(_tree, _gap_x, _gap_y)
/// @desc   Classic top-down tiers: depth becomes a row, siblings spread along it.
/// @param  {Struct} _tree   A tree.
/// @param  {Real}   _gap_x  Horizontal spacing between siblings.
/// @param  {Real}   _gap_y  Vertical spacing between depths.
function mer_layout_branching(_tree, _gap_x = 120, _gap_y = 130) {
    mer_tree_compute_depth(_tree);
    var _nodes = _tree.nodes, _n = array_length(_nodes);

    var _maxDepth = 0;
    for (var _i = 0; _i < _n; _i++) _maxDepth = max(_maxDepth, _nodes[_i].depth);

    // Count per row first so each row can be centred rather than left-aligned.
    var _rowTotal = array_create(_maxDepth + 1, 0);
    for (var _i = 0; _i < _n; _i++) _rowTotal[_nodes[_i].depth]++;

    var _rowSeen = array_create(_maxDepth + 1, 0);
    for (var _i = 0; _i < _n; _i++) {
        var _node = _nodes[_i];
        var _d = _node.depth;
        var _k = _rowSeen[_d]++;
        _node.lx = (_k - (_rowTotal[_d] - 1) * 0.5) * _gap_x;
        _node.ly = (_d - _maxDepth * 0.5) * _gap_y;
    }
    _tree.dirty = false;
}

/// @func   mer_layout_radial(_tree, _spacing)
/// @desc   Concentric rings: depth becomes a ring, every node on it evenly spaced round the circle.
/// @param  {Struct} _tree     A tree.
/// @param  {Real}   _spacing  Ring spacing in tree units.
function mer_layout_radial(_tree, _spacing = 115) {
    mer_tree_compute_depth(_tree);
    var _nodes = _tree.nodes, _n = array_length(_nodes);

    var _maxDepth = 0;
    for (var _i = 0; _i < _n; _i++) _maxDepth = max(_maxDepth, _nodes[_i].depth);

    var _ringTotal = array_create(_maxDepth + 1, 0);
    for (var _i = 0; _i < _n; _i++) _ringTotal[_nodes[_i].depth]++;

    var _ringSeen = array_create(_maxDepth + 1, 0);
    for (var _i = 0; _i < _n; _i++) {
        var _node = _nodes[_i];
        var _d = _node.depth;
        var _k = _ringSeen[_d]++;
        var _ang = (_ringTotal[_d] <= 1) ? -90 : (_k / _ringTotal[_d]) * 360 - 90;
        // The +0.85 is load-bearing. A plain _spacing * _d puts EVERY depth-0 node at the origin,
        // so a tree with six roots stacked all six on one point and rendered as a single pale
        // blob. Roots get their own inner ring instead.
        var _rad = _spacing * (_d + 0.85);
        _node.lx = lengthdir_x(_rad, _ang);
        _node.ly = lengthdir_y(_rad, _ang) * 0.66;   // same 16:9 squash as the constellation
    }
    _tree.dirty = false;
}

/// @func   mer_layout_grid(_tree, _gap_x, _gap_y)
/// @desc   One column per arm, depth down the column. The most legible layout for a large tree,
///         and the one to use when a buyer's tree has more nodes than a constellation can hold.
/// @param  {Struct} _tree   A tree.
/// @param  {Real}   _gap_x  Column spacing.
/// @param  {Real}   _gap_y  Row spacing.
function mer_layout_grid(_tree, _gap_x = 150, _gap_y = 105) {
    mer_tree_compute_depth(_tree);
    var _nodes = _tree.nodes, _n = array_length(_nodes);

    var _maxArm = 0, _maxDepth = 0;
    for (var _i = 0; _i < _n; _i++) {
        _maxArm   = max(_maxArm,   _nodes[_i].arm);
        _maxDepth = max(_maxDepth, _nodes[_i].depth);
    }

    // Sub-column offset when two nodes share an (arm, depth) cell.
    var _seen = {};
    for (var _i = 0; _i < _n; _i++) {
        var _node = _nodes[_i];
        var _key = string(_node.arm) + ":" + string(_node.depth);
        var _ord = variable_struct_exists(_seen, _key) ? variable_struct_get(_seen, _key) : 0;
        variable_struct_set(_seen, _key, _ord + 1);

        _node.lx = (_node.arm - _maxArm * 0.5) * _gap_x + (_ord * _gap_x * 0.36);
        _node.ly = (_node.depth - _maxDepth * 0.5) * _gap_y;
    }
    _tree.dirty = false;
}

/// @func   mer_layout_count()
/// @desc   How many layout engines ship, so a demo or settings screen can cycle them.
/// @return {Real} The count.
function mer_layout_count() { return 4; }

/// @func   mer_layout_name(_index)
/// @desc   Display name of a layout.
/// @param  {Real} _index  Any integer; wrapped.
/// @return {String} The name.
function mer_layout_name(_index) {
    var _i = ((_index mod 4) + 4) mod 4;
    switch (_i) {
        case 0:  return "CONSTELLATION";
        case 1:  return "BRANCHING";
        case 2:  return "RADIAL";
        default: return "GRID";
    }
}

/// @func   mer_layout_apply(_index, _tree)
/// @desc   Applies a shipped layout by index.
/// @param  {Real}   _index  Any integer; wrapped.
/// @param  {Struct} _tree   A tree.
function mer_layout_apply(_index, _tree) {
    var _i = ((_index mod 4) + 4) mod 4;
    switch (_i) {
        case 0:  mer_layout_constellation(_tree); break;
        case 1:  mer_layout_branching(_tree);     break;
        case 2:  mer_layout_radial(_tree);        break;
        default: mer_layout_grid(_tree);          break;
    }
}

/// @func   mer_tree_bounds(_tree)
/// @desc   The tree-space bounding box of every node, so a view can frame the whole graph.
/// @param  {Struct} _tree  A tree.
/// @return {Struct} {x1, y1, x2, y2, cx, cy, w, h}.
function mer_tree_bounds(_tree) {
    var _nodes = _tree.nodes, _n = array_length(_nodes);
    if (_n == 0) return { x1: 0, y1: 0, x2: 0, y2: 0, cx: 0, cy: 0, w: 0, h: 0 };

    var _x1 = _nodes[0].lx, _y1 = _nodes[0].ly, _x2 = _x1, _y2 = _y1;
    for (var _i = 1; _i < _n; _i++) {
        _x1 = min(_x1, _nodes[_i].lx); _x2 = max(_x2, _nodes[_i].lx);
        _y1 = min(_y1, _nodes[_i].ly); _y2 = max(_y2, _nodes[_i].ly);
    }
    return {
        x1: _x1, y1: _y1, x2: _x2, y2: _y2,
        cx: (_x1 + _x2) * 0.5, cy: (_y1 + _y2) * 0.5,
        w: _x2 - _x1, h: _y2 - _y1
    };
}
