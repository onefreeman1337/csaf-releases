/// @file    mer_theme.gml
/// @package Meridian for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary The palette. Six seed colours in, a complete coherent interface out.
///
/// @remarks THIS FILE IS THE PRODUCT'S MAIN PROMISE, SO IT IS WORTH READING BEFORE THE REST.
///
///          Every other file in Meridian asks this one what colour to use. There is not a
///          single hardcoded colour anywhere in the draw or widget layers — if you find one,
///          it is a bug, please report it.
///
///          A theme is built from SIX seeds:
///
///              backdrop   the room behind the interface
///              surface    the body of a panel
///              accent     the primary brand colour: glow, selection, focus
///              accentAlt  the secondary: leading edges, knobs, gauge needles
///              text       primary label colour
///              textDim    secondary / unselected label colour
///
///          Everything else — panel edges, gradient stops, track colours, hover states, the
///          three status colours — is DERIVED from those six by colour maths. That is why
///          changing one seed restyles the whole interface instead of producing a UI where
///          four things changed and eleven did not.
///
///          Status colours deserve a note because they are the detail that makes a theme read
///          as designed rather than assembled. Most UI kits hardcode red/amber/green. Meridian
///          takes the HUE it needs and borrows the SATURATION AND VALUE from your accent,
///          so a danger colour in a washed-out pastel theme is a washed-out pastel red, and in
///          a hot neon theme it is a hot neon red. They never clash, because they are the same
///          material as the rest of the palette.
///
///          COLOURS ARE DECLARED WITH make_colour_rgb(r, g, b), NEVER AS $ HEX LITERALS.
///          This is deliberate and it is not a style preference. A GML hex literal is BGR, not
///          RGB — c_blue is $FF0000 — so $1A1224 is NOT the dark violet a web developer reads
///          it as, it is a dark red-brown with the red and blue channels transposed. That trap
///          costs an hour every time somebody hits it and the result still looks plausible,
///          which is what makes it dangerous. make_colour_rgb takes its arguments in the order
///          its name says, so the ambiguity cannot arise.

// ---------------------------------------------------------------------------------------------
// Colour maths. Pure — no engine state is read or written, only value transforms.
// ---------------------------------------------------------------------------------------------

/// @func   mer_colour_shade(_colour, _amount)
/// @desc   Lightens or darkens a colour without changing its hue.
/// @param  {Real} _colour  A BGR colour value.
/// @param  {Real} _amount  -1 to 1. Negative darkens toward black, positive lightens toward white.
/// @return {Real} The shaded colour.
/// @pure
function mer_colour_shade(_colour, _amount) {
    if (_amount >= 0) return merge_colour(_colour, c_white, clamp(_amount, 0, 1));
    return merge_colour(_colour, c_black, clamp(-_amount, 0, 1));
}

/// @func   mer_colour_mix(_a, _b, _t)
/// @desc   Linear blend between two colours.
/// @param  {Real} _a  First colour.
/// @param  {Real} _b  Second colour.
/// @param  {Real} _t  0 returns _a, 1 returns _b.
/// @return {Real} The blended colour.
/// @pure
function mer_colour_mix(_a, _b, _t) {
    return merge_colour(_a, _b, clamp(_t, 0, 1));
}

/// @func   mer_colour_status(_reference, _hue)
/// @desc   Builds a status colour at a given hue that matches the reference colour's intensity.
///
/// @remarks See the file header. The hue is chosen by the role (danger / warning / success) and
///          the saturation and value are borrowed from the theme's accent, with a floor applied
///          so that a very dark or very desaturated accent still yields a legible status colour.
///
/// @param  {Real} _reference  Usually the theme accent.
/// @param  {Real} _hue        Target hue, 0-255 in GameMaker's HSV space. 0 red, 26 amber, 92 green.
/// @return {Real} A status colour tonally consistent with the theme.
/// @pure
function mer_colour_status(_reference, _hue) {
    var _s = max(colour_get_saturation(_reference), 130);
    var _v = max(colour_get_value(_reference),      170);
    return make_colour_hsv(_hue, _s, _v);
}

// ---------------------------------------------------------------------------------------------
// Theme construction
// ---------------------------------------------------------------------------------------------

/// @func   mer_theme_make(_backdrop, _surface, _accent, _accent_alt, _text, _text_dim)
/// @desc   Builds a complete theme struct from the six seed colours.
///
/// @remarks The returned struct is a plain struct with no methods, so you can freely override any
///          single field after building it:
///
///              var _t = mer_theme_make(...);
///              _t.radius = 4;              // square-ish, for a pixel-art game
///              _t.glowAlpha = 0;           // no glow at all
///              mer_theme_set(_t);
///
///          Nothing in the package caches derived values, so an override takes effect on the very
///          next frame. That is what makes live theme switching possible at zero cost.
///
/// @param  {Real} _backdrop    The room behind the interface.
/// @param  {Real} _surface     Panel body.
/// @param  {Real} _accent      Primary: glow, selection, focus.
/// @param  {Real} _accent_alt  Secondary: leading edges, knobs, needles.
/// @param  {Real} _text        Primary label colour.
/// @param  {Real} _text_dim    Secondary / unselected label colour.
/// @return {Struct} A complete theme.
/// @pure
function mer_theme_make(_backdrop, _surface, _accent, _accent_alt, _text, _text_dim) {
    return {
        // --- the six seeds, verbatim -----------------------------------------------------
        backdrop     : _backdrop,
        surface      : _surface,
        accent       : _accent,
        accentAlt    : _accent_alt,
        text         : _text,
        textDim      : _text_dim,

        // --- derived surfaces ------------------------------------------------------------
        backdropTop  : mer_colour_shade(_backdrop, -0.30),
        backdropBase : mer_colour_mix(_backdrop, _accent, 0.20),
        surfaceHi    : mer_colour_mix(_surface, _accent, 0.24),
        surfaceLo    : mer_colour_shade(_surface, -0.40),
        edge         : mer_colour_mix(_surface, _accent, 0.60),
        glow         : _accent,
        highlight    : mer_colour_mix(_accent, _surface, 0.30),
        leadingEdge  : mer_colour_shade(_accent_alt, 0.40),
        track        : mer_colour_shade(_surface, 0.12),
        knob         : mer_colour_shade(_accent_alt, 0.22),
        hover        : mer_colour_mix(_surface, _accent, 0.40),

        // --- derived status colours, tonally matched to the accent -----------------------
        danger       : mer_colour_status(_accent, 2),
        warning      : mer_colour_status(_accent, 26),
        success      : mer_colour_status(_accent, 92),

        // --- geometry and intensity ------------------------------------------------------
        radius       : 14,     // panel corner radius in px at 1x
        radiusSmall  : 7,      // widgets
        panelAlpha   : 0.94,
        glowAlpha    : 0.05,   // per glow ring; six rings are drawn
        glowRings    : 6,
        edgeAlpha    : 0.55,
        scanlineAlpha: 0.045,  // 0 disables the scanline overlay entirely
        strokeWeight : 0.16,   // text stroke width as a fraction of cap height
    };
}

// ---------------------------------------------------------------------------------------------
// The four shipped themes.
//
// These exist to be read as much as used: each one is six lines, which is the clearest possible
// demonstration that a buyer's own theme is also six lines. Press T in the demo room to cycle them
// and watch every widget on screen restyle at once.
// ---------------------------------------------------------------------------------------------

/// @func   mer_theme_violet()
/// @desc   The default. Deep plum surfaces, violet glow, near-white text. Fantasy / sci-fi menus.
/// @return {Struct} A theme.
function mer_theme_violet() {
    return mer_theme_make(
        make_colour_rgb( 26,  18,  36),   // backdrop
        make_colour_rgb( 40,  27,  62),   // surface
        make_colour_rgb(199, 125, 255),   // accent
        make_colour_rgb(233, 199, 255),   // accentAlt
        make_colour_rgb(242, 233, 255),   // text
        make_colour_rgb(154, 134, 184)    // textDim
    );
}

/// @func   mer_theme_ember()
/// @desc   Warm charcoal and molten amber. Action games, forges, anything that should feel hot.
/// @return {Struct} A theme.
function mer_theme_ember() {
    return mer_theme_make(
        make_colour_rgb( 28,  19,  16),
        make_colour_rgb( 48,  30,  24),
        make_colour_rgb(255, 148,  58),
        make_colour_rgb(255, 214, 140),
        make_colour_rgb(255, 240, 225),
        make_colour_rgb(176, 145, 124)
    );
}

/// @func   mer_theme_terminal()
/// @desc   Phosphor green on near-black. Retro, hacking, roguelikes. Turn radius down to 2 for CRT.
/// @return {Struct} A theme.
function mer_theme_terminal() {
    return mer_theme_make(
        make_colour_rgb(  8,  16,  11),
        make_colour_rgb( 16,  32,  22),
        make_colour_rgb( 90, 255, 150),
        make_colour_rgb(198, 255, 216),
        make_colour_rgb(214, 255, 228),
        make_colour_rgb(104, 156, 124)
    );
}

/// @func   mer_theme_frost()
/// @desc   Cold slate and glacier cyan. Strategy, UI-heavy sims, anything that should read clean.
/// @return {Struct} A theme.
function mer_theme_frost() {
    return mer_theme_make(
        make_colour_rgb( 15,  23,  34),
        make_colour_rgb( 28,  42,  60),
        make_colour_rgb( 96, 208, 255),
        make_colour_rgb(198, 238, 255),
        make_colour_rgb(232, 244, 255),
        make_colour_rgb(130, 156, 180)
    );
}

/// @func   mer_theme_count()
/// @desc   How many themes ship with the package. Lets a settings screen enumerate them without
///         hardcoding a number that goes stale when a theme is added.
/// @return {Real} The count.
function mer_theme_count() {
    return 4;
}

/// @func   mer_theme_by_index(_index)
/// @desc   Returns a shipped theme by index, wrapping so a caller can increment freely.
/// @param  {Real} _index  Any integer.
/// @return {Struct} A theme.
function mer_theme_by_index(_index) {
    var _i = ((_index mod 4) + 4) mod 4;
    switch (_i) {
        case 0:  return mer_theme_violet();
        case 1:  return mer_theme_ember();
        case 2:  return mer_theme_terminal();
        default: return mer_theme_frost();
    }
}

/// @func   mer_theme_name(_index)
/// @desc   The display name of a shipped theme, for settings screens.
/// @param  {Real} _index  Any integer.
/// @return {String} The name.
function mer_theme_name(_index) {
    var _i = ((_index mod 4) + 4) mod 4;
    switch (_i) {
        case 0:  return "VIOLET";
        case 1:  return "EMBER";
        case 2:  return "TERMINAL";
        default: return "FROST";
    }
}

// ---------------------------------------------------------------------------------------------
// The current theme.
//
// One global, namespaced with a double underscore and the package prefix. GML's global namespace
// is flat and shared with the buyer's own code, so a collision here would be a support ticket
// nobody can debug remotely.
// ---------------------------------------------------------------------------------------------

/// @func   mer_theme_get()
/// @desc   Returns the active theme, creating the default one on first use.
///
/// @remarks Lazily initialised on purpose: there is no setup call to forget. Draw a panel in a
///          fresh project with no boilerplate at all and it works.
///
/// @return {Struct} The active theme.
function mer_theme_get() {
    if (!variable_global_exists("__mer_theme")) {
        global.__mer_theme = mer_theme_violet();
    }
    return global.__mer_theme;
}

/// @func   mer_theme_set(_theme)
/// @desc   Replaces the active theme. Takes effect on the next frame drawn — nothing is cached.
/// @param  {Struct} _theme  A struct from mer_theme_make or one of the shipped themes.
/// @return {Struct} The theme that was set, so calls can be chained.
function mer_theme_set(_theme) {
    global.__mer_theme = _theme;
    return _theme;
}
