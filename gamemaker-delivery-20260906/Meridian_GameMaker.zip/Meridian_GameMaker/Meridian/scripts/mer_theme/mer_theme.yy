{
  "$GMScript": "v1",
  "%Name": "mer_theme",
  "isCompatibility": false,
  "isDnD": false,
  "name": "mer_theme",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}