{
  "$GMScript": "v1",
  "%Name": "mer_view",
  "isCompatibility": false,
  "isDnD": false,
  "name": "mer_view",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}