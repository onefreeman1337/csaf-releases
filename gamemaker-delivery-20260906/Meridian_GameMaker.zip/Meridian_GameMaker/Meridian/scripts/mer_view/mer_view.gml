/// @file    mer_view.gml
/// @package Meridian for GameMaker
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary The presentation layer: pan and zoom, node frames, connectors, hover and selection
///          motion, the unlock cascade, and the detail panel.
///
/// @remarks WHAT MAKES A SKILL TREE LOOK EXPENSIVE, IN ORDER OF HOW MUCH IT MATTERS.
///
///          1. The connectors carry light. A purchased edge is not merely a brighter line — it
///             has a pulse travelling along it, away from the node you bought. That one detail
///             does more for the sense of a living tree than any amount of node art, because it
///             is the only thing on screen that tells you which way progression FLOWS.
///          2. Nodes have three visual states and they mean three different things. Locked,
///             available and owned must be distinguishable at a glance and from across the room.
///             Most hand-rolled trees ship two, and the player cannot tell "cannot afford" from
///             "cannot reach".
///          3. Everything moves on springs, not tweens. Hovering retargets a spring; the node is
///             already moving when you arrive at it and it settles after you leave. A tween has a
///             duration, so moving the pointer across six nodes quickly restarts six animations
///             and the row visibly stutters.
///          4. The backdrop is not flat. A seeded starfield behind a constellation costs one loop
///             and stops the panel reading as a dialog box with circles in it.
///
///          Tree space is mapped to screen space by pan and zoom, both of which are springs. That
///          is what makes focusing a node feel like a camera move rather than a jump cut, and it
///          is why changing layout mid-session animates: the nodes' tree-space positions change
///          under a view that is still interpolating.

#macro MER_NODE_R_MINOR    19
#macro MER_NODE_R_MAJOR    27
#macro MER_NODE_R_KEYSTONE 37

// ---------------------------------------------------------------------------------------------
// Construction
// ---------------------------------------------------------------------------------------------

/// @func   mer_view_make(_tree)
/// @desc   Creates a view over a tree.
/// @param  {Struct} _tree  A tree, already laid out.
/// @return {Struct} A view.
function mer_view_make(_tree) {
    var _b = mer_tree_bounds(_tree);
    var _v = {
        panX     : mer_spring_make(90, 17, -_b.cx),
        panY     : mer_spring_make(90, 17, -_b.cy),
        zoom     : mer_spring_make(110, 19, 1),
        hover    : [],      // one 0..1 spring per node
        pulse    : [],      // seconds since this node was purchased, or -1
        hoveredId: "",
        selected : "",
        time     : 0,
        dragging : false,
        dragX    : 0,
        dragY    : 0,
        stars    : [],
        revealAt : 0,       // seconds since the tree began revealing, for the stagger
    };
    mer_view_sync(_v, _tree);
    return _v;
}

/// @func   mer_view_sync(_view, _tree)
/// @desc   Resizes the view's per-node arrays to match the tree. Call after adding nodes.
/// @param  {Struct} _view  A view.
/// @param  {Struct} _tree  A tree.
function mer_view_sync(_view, _tree) {
    var _n = mer_tree_count(_tree);
    while (array_length(_view.hover) < _n) {
        array_push(_view.hover, mer_spring_make(240, 26, 0));
        array_push(_view.pulse, -1);
    }
    // The starfield is generated once from a fixed seed. A per-frame random() would make the sky
    // boil, which is the single most obvious "this is programmer art" tell in a procedural scene.
    if (array_length(_view.stars) == 0) {
        var _seed = random_get_seed();
        random_set_seed(20260810);
        for (var _i = 0; _i < 150; _i++) {
            array_push(_view.stars, {
                x: random_range(-1400, 1400), y: random_range(-1000, 1000),
                r: random_range(0.5, 1.9),    a: random_range(0.12, 0.5),
                p: random_range(0, 2 * pi),   d: random_range(0.35, 1.1)
            });
        }
        random_set_seed(_seed);
    }
}

// ---------------------------------------------------------------------------------------------
// Coordinate mapping
// ---------------------------------------------------------------------------------------------

/// @func   mer_view_to_screen(_view, _lx, _ly, _cx, _cy)
/// @desc   Maps a tree-space point to screen space.
/// @param  {Struct} _view  A view.
/// @param  {Real}   _lx    Tree-space x.
/// @param  {Real}   _ly    Tree-space y.
/// @param  {Real}   _cx    Screen-space centre of the viewport.
/// @param  {Real}   _cy    Screen-space centre of the viewport.
/// @return {Struct} {x, y}.
function mer_view_to_screen(_view, _lx, _ly, _cx, _cy) {
    var _z = _view.zoom.value;
    return { x: _cx + (_lx + _view.panX.value) * _z, y: _cy + (_ly + _view.panY.value) * _z };
}

/// @func   mer_view_node_radius(_node, _zoom)
/// @desc   Screen radius of a node at the current zoom.
/// @param  {Struct} _node  A node.
/// @param  {Real}   _zoom  Current zoom.
/// @return {Real} Radius in pixels.
function mer_view_node_radius(_node, _zoom) {
    switch (_node.tier) {
        case MER_TIER_KEYSTONE: return MER_NODE_R_KEYSTONE * _zoom;
        case MER_TIER_MAJOR:    return MER_NODE_R_MAJOR * _zoom;
        default:                return MER_NODE_R_MINOR * _zoom;
    }
}

/// @func   mer_view_focus(_view, _tree, _id)
/// @desc   Pans the view so a node sits at the centre. The springs make it a camera move.
/// @param  {Struct} _view  A view.
/// @param  {Struct} _tree  A tree.
/// @param  {String} _id    Node id.
function mer_view_focus(_view, _tree, _id) {
    var _node = mer_tree_get(_tree, _id);
    if (is_undefined(_node)) return;
    _view.panX.target = -_node.lx;
    _view.panY.target = -_node.ly;
}

/// @func   mer_view_frame_all(_view, _tree, _w, _h, _margin)
/// @desc   Sets pan and zoom so the entire tree fits the viewport.
/// @param  {Struct} _view    A view.
/// @param  {Struct} _tree    A tree.
/// @param  {Real}   _w       Viewport width.
/// @param  {Real}   _h       Viewport height.
/// @param  {Real}   _margin  Pixels of breathing room on every side.
function mer_view_frame_all(_view, _tree, _w, _h, _margin = 90) {
    var _b = mer_tree_bounds(_tree);
    _view.panX.target = -_b.cx;
    _view.panY.target = -_b.cy;
    var _zx = (_b.w > 1) ? (_w - _margin * 2) / _b.w : 1;
    var _zy = (_b.h > 1) ? (_h - _margin * 2) / _b.h : 1;
    _view.zoom.target = clamp(min(_zx, _zy), 0.35, 1.6);
}

// ---------------------------------------------------------------------------------------------
// Update
// ---------------------------------------------------------------------------------------------

/// @func   mer_view_update(_view, _tree, _state, _mx, _my, _cx, _cy, _dt)
/// @desc   Advances every spring, resolves what the pointer is over, and ages the unlock pulses.
///
/// @remarks _dt is passed in rather than read from delta_time so a caller can drive the view at a
///          fixed step. That is what makes an unattended screen capture reproducible, and it is
///          also what a buyer needs if their game pauses. Note that GameMaker's delta_time is in
///          MICROseconds — the conversion is delta_time / 1000000, and getting that wrong by a
///          factor of a thousand is one of the most common GML bugs there is.
///
/// @param  {Struct} _view   A view.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state.
/// @param  {Real}   _mx     Pointer x in screen space.
/// @param  {Real}   _my     Pointer y in screen space.
/// @param  {Real}   _cx     Viewport centre x.
/// @param  {Real}   _cy     Viewport centre y.
/// @param  {Real}   _dt     Delta time in SECONDS.
function mer_view_update(_view, _tree, _state, _mx, _my, _cx, _cy, _dt) {
    _view.time += _dt;
    _view.revealAt += _dt;
    mer_view_sync(_view, _tree);

    mer_spring_step(_view.panX, _dt);
    mer_spring_step(_view.panY, _dt);
    mer_spring_step(_view.zoom, _dt);

    // Resolve hover. Nearest node wins rather than first hit, so overlapping nodes at low zoom
    // still select the one whose centre the pointer is actually closest to.
    var _nodes = _tree.nodes, _n = array_length(_nodes);
    // Not 1e9 — GML's lexer does not accept scientific notation and reads it as the number 1
    // followed by an identifier "e9", which fails with "Assignment operator expected" on a line
    // that looks perfectly correct.
    var _best = -1, _bestD = 999999999;
    for (var _i = 0; _i < _n; _i++) {
        var _p = mer_view_to_screen(_view, _nodes[_i].lx, _nodes[_i].ly, _cx, _cy);
        var _r = mer_view_node_radius(_nodes[_i], _view.zoom.value);
        var _d = point_distance(_mx, _my, _p.x, _p.y);
        if (_d <= _r * 1.15 && _d < _bestD) { _best = _i; _bestD = _d; }
    }
    _view.hoveredId = (_best >= 0) ? _nodes[_best].id : "";

    for (var _i = 0; _i < _n; _i++) {
        _view.hover[_i].target = (_i == _best) ? 1 : 0;
        mer_spring_step(_view.hover[_i], _dt);
        if (_view.pulse[_i] >= 0) {
            _view.pulse[_i] += _dt;
            if (_view.pulse[_i] > 1.6) _view.pulse[_i] = -1;
        }
    }
}

/// @func   mer_view_click(_view, _tree, _state, _buy)
/// @desc   Acts on whatever the pointer is over: buys a rank, or selects it.
/// @param  {Struct} _view   A view.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state.
/// @param  {Bool}   _buy    True to attempt a purchase, false to only select.
/// @return {Real} The MER_UNLOCK_* result when _buy is true, otherwise MER_UNLOCK_OK.
function mer_view_click(_view, _tree, _state, _buy = true) {
    if (_view.hoveredId == "") return MER_UNLOCK_NO_NODE;
    _view.selected = _view.hoveredId;
    if (!_buy) return MER_UNLOCK_OK;

    var _why = mer_progress_unlock(_tree, _state, _view.hoveredId);
    if (_why == MER_UNLOCK_OK) {
        var _idx = variable_struct_get(_tree.byId, _view.hoveredId);
        _view.pulse[_idx] = 0;
    }
    return _why;
}

// ---------------------------------------------------------------------------------------------
// Drawing
// ---------------------------------------------------------------------------------------------

/// @func   mer_view_draw_backdrop(_view, _x, _y, _w, _h, _cx, _cy)
/// @desc   The theme gradient plus a parallaxed, gently twinkling starfield.
/// @param  {Struct} _view  A view.
/// @param  {Real}   _x     Viewport left.
/// @param  {Real}   _y     Viewport top.
/// @param  {Real}   _w     Viewport width.
/// @param  {Real}   _h     Viewport height.
/// @param  {Real}   _cx    Viewport centre x.
/// @param  {Real}   _cy    Viewport centre y.
function mer_view_draw_backdrop(_view, _x, _y, _w, _h, _cx, _cy) {
    var _t = mer_theme_get();
    mer_draw_backdrop(_x, _y, _w, _h);

    var _stars = _view.stars, _n = array_length(_stars);
    // Parallax at a fraction of the pan, so the sky sits behind the tree rather than glued to it.
    var _px = _view.panX.value * 0.25, _py = _view.panY.value * 0.25;

    draw_set_colour(_t.text);
    for (var _i = 0; _i < _n; _i++) {
        var _s = _stars[_i];
        var _sx = _cx + _s.x + _px, _sy = _cy + _s.y + _py;
        if (_sx < _x - 4 || _sx > _x + _w + 4 || _sy < _y - 4 || _sy > _y + _h + 4) continue;
        var _tw = 0.62 + 0.38 * sin(_view.time * _s.d + _s.p);
        draw_set_alpha(_s.a * _tw);
        draw_circle(_sx, _sy, _s.r, false);
    }
    draw_set_alpha(1);
    draw_set_colour(c_white);
}

/// @func   mer_view_draw_links(_view, _tree, _state, _cx, _cy)
/// @desc   Every prerequisite edge, with an energy pulse along the purchased ones.
///
/// @remarks Drawn as a separate pass BEFORE any node, so a connector always passes behind the
///          discs it joins. Interleaving the two passes is the usual mistake and it shows up as
///          lines crossing over the top of node art at certain zoom levels only.
///
/// @param  {Struct} _view   A view.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state.
/// @param  {Real}   _cx     Viewport centre x.
/// @param  {Real}   _cy     Viewport centre y.
function mer_view_draw_links(_view, _tree, _state, _cx, _cy) {
    var _t = mer_theme_get();
    var _z = _view.zoom.value;
    var _nodes = _tree.nodes, _n = array_length(_nodes);

    for (var _i = 0; _i < _n; _i++) {
        var _node = _nodes[_i];
        var _req = _node.requires, _rn = array_length(_req);
        if (_rn == 0) continue;

        var _to = mer_view_to_screen(_view, _node.lx, _node.ly, _cx, _cy);
        var _childRank = mer_progress_rank(_state, _node.id);

        for (var _r = 0; _r < _rn; _r++) {
            var _parent = mer_tree_get(_tree, _req[_r]);
            if (is_undefined(_parent)) continue;
            var _from = mer_view_to_screen(_view, _parent.lx, _parent.ly, _cx, _cy);

            var _parentRank = mer_progress_rank(_state, _parent.id);
            var _live = (_parentRank > 0);
            var _full = (_live && _childRank > 0);

            // Trim the line back to each node's rim so it does not tunnel under the disc.
            var _dir = point_direction(_from.x, _from.y, _to.x, _to.y);
            var _r1 = mer_view_node_radius(_parent, _z) * 0.94;
            var _r2 = mer_view_node_radius(_node, _z) * 0.94;
            var _ax = _from.x + lengthdir_x(_r1, _dir), _ay = _from.y + lengthdir_y(_r1, _dir);
            var _bx = _to.x - lengthdir_x(_r2, _dir),   _by = _to.y - lengthdir_y(_r2, _dir);

            var _col = _full ? mer_discipline_palette(_node.disc)[MER_ROLE_LIMB]
                             : (_live ? _t.edge : _t.surfaceLo);
            var _wgt = max(1, (_full ? 3.0 : (_live ? 2.2 : 1.7)) * _z);

            if (_full) {
                draw_set_alpha(0.16);
                draw_set_colour(_col);
                draw_line_width(_ax, _ay, _bx, _by, _wgt * 3.2);
            }
            draw_set_alpha(_full ? 0.95 : (_live ? 0.72 : 0.44));
            draw_set_colour(_col);
            draw_line_width(_ax, _ay, _bx, _by, _wgt);

            // The travelling pulse. Only on fully-owned edges — an edge whose child is unbought
            // has nothing flowing through it yet, and animating it would say otherwise.
            if (_full) {
                var _len = point_distance(_ax, _ay, _bx, _by);
                var _k = frac(_view.time * 0.42 + _i * 0.17 + _r * 0.31);
                var _hx = lerp(_ax, _bx, _k), _hy = lerp(_ay, _by, _k);
                var _spark = mer_discipline_palette(_node.disc)[MER_ROLE_SPARK];
                draw_set_colour(_spark);
                for (var _g = 3; _g >= 1; _g--) {
                    draw_set_alpha(0.11 * (4 - _g) * min(1, _len / 60));
                    draw_circle(_hx, _hy, (1.6 + _g * 1.5) * _z, false);
                }
                draw_set_alpha(0.95);
                draw_circle(_hx, _hy, 2.1 * _z, false);
            }
        }
    }
    draw_set_alpha(1);
    draw_set_colour(c_white);
}

/// @func   mer_view_draw_node(_view, _tree, _state, _index, _cx, _cy, _reveal)
/// @desc   One node: frame, sigil, rank pips, hover lift and purchase flash.
/// @param  {Struct} _view    A view.
/// @param  {Struct} _tree    A tree.
/// @param  {Struct} _state   A progression state.
/// @param  {Real}   _index   Node index.
/// @param  {Real}   _cx      Viewport centre x.
/// @param  {Real}   _cy      Viewport centre y.
/// @param  {Real}   _reveal  0..1 reveal progress for the staggered entrance.
function mer_view_draw_node(_view, _tree, _state, _index, _cx, _cy, _reveal = 1) {
    if (_reveal <= 0.001) return;

    var _t = mer_theme_get();
    var _node = _tree.nodes[_index];
    var _p = mer_view_to_screen(_view, _node.lx, _node.ly, _cx, _cy);
    var _z = _view.zoom.value;
    var _hov = _view.hover[_index].value;
    var _vis = mer_progress_state(_tree, _state, _node.id);
    var _rank = mer_progress_rank(_state, _node.id);
    var _pal = mer_discipline_palette(_node.disc);

    // A node arrives by scaling up from 40% with an overshoot, so a tree assembles rather than
    // switching on. The hover lift is added on top, not multiplied, so a hovered node that is
    // still arriving does not double its scale.
    var _in = mer_ease(_reveal, MER_EASE_OUT_BACK);
    var _r  = mer_view_node_radius(_node, _z) * (0.4 + 0.6 * _in) * (1 + 0.13 * _hov);
    var _a  = _reveal;

    // Purchase flash: a ring that expands and fades once, when a rank is bought.
    var _pulse = _view.pulse[_index];
    if (_pulse >= 0) {
        var _pk = clamp(_pulse / 1.6, 0, 1);
        draw_set_colour(_pal[MER_ROLE_SPARK]);
        draw_set_alpha((1 - _pk) * 0.55);
        draw_circle(_p.x, _p.y, _r * (1 + _pk * 2.4), true);
        draw_set_alpha((1 - _pk) * 0.3);
        draw_circle(_p.x, _p.y, _r * (1 + _pk * 1.7), true);
    }

    var _owned = (_vis == MER_STATE_PARTIAL || _vis == MER_STATE_MAXED);
    var _avail = (_vis == MER_STATE_AVAILABLE);

    // --- outer glow ---------------------------------------------------------------------------
    if (_owned || _avail || _hov > 0.01) {
        // An available node breathes; an owned node burns steadily. That difference is what makes
        // "you can buy this" legible without a label.
        var _breathe = _avail ? (0.55 + 0.45 * sin(_view.time * 2.4 + _index)) : 1;
        var _gi = (_owned ? 0.5 : (_avail ? 0.32 : 0)) * _breathe + _hov * 0.42;
        draw_set_colour(_pal[MER_ROLE_LIMB]);
        for (var _g = 5; _g >= 1; _g--) {
            draw_set_alpha(_a * _gi * 0.075 * (6 - _g) / 5);
            draw_circle(_p.x, _p.y, _r + _g * 3.4 * _z, false);
        }
    }

    // --- body ---------------------------------------------------------------------------------
    draw_set_colour(_owned ? mer_colour_mix(_t.surface, _pal[MER_ROLE_HALO], 0.35) : _t.surface);
    draw_set_alpha(_a * 0.96);
    draw_circle(_p.x, _p.y, _r, false);

    // --- frame, by tier -------------------------------------------------------------------------
    var _edge = _owned ? _pal[MER_ROLE_CORE] : (_avail ? _t.edge : _t.surfaceLo);
    var _ew = max(1, (_owned ? 2.6 : 1.8) * _z);
    draw_set_colour(_edge);
    draw_set_alpha(_a * (_owned ? 0.98 : (_avail ? 0.8 : 0.5)));

    if (_node.tier == MER_TIER_MINOR) {
        mer_draw_ring(_p.x, _p.y, _r, _ew);
    } else {
        var _sides = (_node.tier == MER_TIER_KEYSTONE) ? 8 : 6;
        mer_draw_ngon_outline(_p.x, _p.y, _r * 1.06, _sides, 90 + _view.time * (_owned ? 6 : 0), _ew);
        if (_node.tier == MER_TIER_KEYSTONE) {
            mer_draw_ring(_p.x, _p.y, _r * 1.30, max(1, 1.4 * _z));
            // Spokes. Only a keystone gets them; they are the cue that this node is different
            // before the player has read a single word of the tooltip.
            for (var _s = 0; _s < 8; _s++) {
                var _sa = _s * 45 + _view.time * 9;
                draw_line_width(_p.x + lengthdir_x(_r * 1.10, _sa), _p.y + lengthdir_y(_r * 1.10, _sa),
                                _p.x + lengthdir_x(_r * 1.26, _sa), _p.y + lengthdir_y(_r * 1.26, _sa),
                                max(1, 1.3 * _z));
            }
        }
    }

    // --- the sigil ------------------------------------------------------------------------------
    var _drain = _owned ? 0 : (_avail ? 0.35 : 0.85);
    var _sa2 = _a * (_owned ? 1 : (_avail ? 0.9 : 0.55));
    mer_sigil_draw(_node.sigil, _p.x, _p.y, _r * 1.28, _node.disc, _sa2,
                   (_owned ? 1 : 0.45) + _hov * 0.5, _drain);

    // --- rank pips ------------------------------------------------------------------------------
    // Only for nodes that CAN hold more than one rank. Drawing one pip on a single-rank node adds
    // a mark that carries no information, and forty of those is visual noise.
    if (_node.maxRank > 1) {
        var _pipR = _r * (_node.tier == MER_TIER_KEYSTONE ? 1.46 : 1.24);
        var _span = 74;
        for (var _k = 0; _k < _node.maxRank; _k++) {
            var _pa = 90 + (_k - (_node.maxRank - 1) * 0.5) * (_span / max(1, _node.maxRank - 1));
            var _px2 = _p.x + lengthdir_x(_pipR, _pa);
            var _py2 = _p.y + lengthdir_y(_pipR, _pa);
            var _on = (_k < _rank);
            draw_set_colour(_on ? _pal[MER_ROLE_SPARK] : _t.surfaceLo);
            draw_set_alpha(_a * (_on ? 0.98 : 0.6));
            draw_circle(_px2, _py2, (_on ? 2.7 : 2.0) * _z, false);
        }
    }

    draw_set_alpha(1);
    draw_set_colour(c_white);
}

/// @func   mer_view_draw(_view, _tree, _state, _x, _y, _w, _h, _stagger)
/// @desc   Draws the whole tree inside a viewport.
/// @param  {Struct} _view     A view.
/// @param  {Struct} _tree     A tree.
/// @param  {Struct} _state    A progression state.
/// @param  {Real}   _x        Viewport left.
/// @param  {Real}   _y        Viewport top.
/// @param  {Real}   _w        Viewport width.
/// @param  {Real}   _h        Viewport height.
/// @param  {Bool}   _stagger  True to play the staggered entrance from view.revealAt.
function mer_view_draw(_view, _tree, _state, _x, _y, _w, _h, _stagger = true) {
    var _cx = _x + _w * 0.5, _cy = _y + _h * 0.5;

    mer_view_draw_backdrop(_view, _x, _y, _w, _h, _cx, _cy);
    mer_view_draw_links(_view, _tree, _state, _cx, _cy);

    var _n = mer_tree_count(_tree);
    for (var _i = 0; _i < _n; _i++) {
        // Reveal in DEPTH order rather than array order, so the tree grows outward from its roots
        // instead of appearing in whatever sequence the nodes happened to be declared.
        var _rv = 1;
        if (_stagger) {
            _rv = mer_stagger(_tree.nodes[_i].depth, 6, _view.revealAt, 0.42, 0.55);
        }
        mer_view_draw_node(_view, _tree, _state, _i, _cx, _cy, _rv);
    }
}

// ---------------------------------------------------------------------------------------------
// Extra primitives the tree needs and the shared draw layer does not carry
// ---------------------------------------------------------------------------------------------

/// @func   mer_draw_ring(_cx, _cy, _radius, _weight)
/// @desc   A stroked circle as a true annulus, using the current colour and alpha.
/// @param  {Real} _cx      Centre x.
/// @param  {Real} _cy      Centre y.
/// @param  {Real} _radius  Radius.
/// @param  {Real} _weight  Stroke weight in pixels.
function mer_draw_ring(_cx, _cy, _radius, _weight) {
    var _outer = _radius + _weight * 0.5, _inner = max(0, _radius - _weight * 0.5);
    draw_primitive_begin(pr_trianglestrip);
    for (var _i = 0; _i <= 44; _i++) {
        var _a = _i / 44 * 2 * pi, _ca = cos(_a), _sa = sin(_a);
        draw_vertex(_cx + _ca * _outer, _cy + _sa * _outer);
        draw_vertex(_cx + _ca * _inner, _cy + _sa * _inner);
    }
    draw_primitive_end();
}

/// @func   mer_draw_ngon_outline(_cx, _cy, _radius, _sides, _rotation, _weight)
/// @desc   A regular polygon outline, using the current colour and alpha.
/// @param  {Real} _cx        Centre x.
/// @param  {Real} _cy        Centre y.
/// @param  {Real} _radius    Circumradius.
/// @param  {Real} _sides     Side count.
/// @param  {Real} _rotation  Rotation in degrees.
/// @param  {Real} _weight    Stroke weight.
function mer_draw_ngon_outline(_cx, _cy, _radius, _sides, _rotation, _weight) {
    for (var _i = 0; _i < _sides; _i++) {
        var _a1 = _rotation + _i * 360 / _sides;
        var _a2 = _rotation + (_i + 1) * 360 / _sides;
        var _x1 = _cx + lengthdir_x(_radius, _a1), _y1 = _cy + lengthdir_y(_radius, _a1);
        var _x2 = _cx + lengthdir_x(_radius, _a2), _y2 = _cy + lengthdir_y(_radius, _a2);
        draw_line_width(_x1, _y1, _x2, _y2, _weight);
        if (_weight > 2) draw_circle(_x2, _y2, _weight * 0.5, false);
    }
}

// ---------------------------------------------------------------------------------------------
// The detail panel
// ---------------------------------------------------------------------------------------------

/// @func   mer_text_wrap(_text, _size, _max_width, _tracking)
/// @desc   Breaks a string into lines that each fit a width budget in the stroke typeface.
///
/// @remarks Word wrapping is here rather than in mer_font because it needs mer_text_width, and
///          because the failure it prevents is a presentation failure: a description running out
///          through the side of its panel and over the tree behind it. A sibling product shipped
///          exactly that bug — the modal had never been photographed, so nobody saw it.
///
/// @param  {String} _text       Text to wrap.
/// @param  {Real}   _size       Cap height in pixels.
/// @param  {Real}   _max_width  Width budget in pixels.
/// @param  {Real}   _tracking   Letter spacing, or undefined for the default.
/// @return {Array} Lines.
function mer_text_wrap(_text, _size, _max_width, _tracking = undefined) {
    var _lines = [];
    if (_text == "") return _lines;

    var _cur = "";
    var _word = "";
    var _len = string_length(_text);

    for (var _i = 1; _i <= _len + 1; _i++) {
        var _ch = (_i <= _len) ? string_char_at(_text, _i) : " ";
        if (_ch != " ") { _word += _ch; continue; }
        if (_word == "") continue;

        var _try = (_cur == "") ? _word : _cur + " " + _word;
        if (mer_text_width(_try, _size, _tracking) <= _max_width || _cur == "") {
            _cur = _try;
        } else {
            array_push(_lines, _cur);
            _cur = _word;
        }
        _word = "";
    }
    if (_cur != "") array_push(_lines, _cur);
    return _lines;
}

/// @func   mer_view_draw_detail(_view, _tree, _state, _x, _y, _w, _h)
/// @desc   The side panel for the selected node: its mark at display size, its name, discipline,
///         rank, cost, description and current status.
///
/// @remarks THE LARGE SIGIL IS THE POINT OF THIS PANEL. It is the same geometry the 38 px node
///          draws, rendered at 120 px, and it is the clearest possible demonstration that these
///          marks are resolution independent — there is no larger version of the asset, because
///          there is no asset.
///
/// @param  {Struct} _view   A view.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progression state.
/// @param  {Real}   _x      Panel left.
/// @param  {Real}   _y      Panel top.
/// @param  {Real}   _w      Panel width.
/// @param  {Real}   _h      Panel height.
function mer_view_draw_detail(_view, _tree, _state, _x, _y, _w, _h) {
    var _t = mer_theme_get();
    mer_draw_panel(_x, _y, _w, _h, 1);

    var _id = (_view.hoveredId != "") ? _view.hoveredId : _view.selected;
    var _pad = 22;
    var _iw = _w - _pad * 2;

    if (_id == "") {
        mer_draw_text_centred(_x + _w * 0.5, _y + _h * 0.5 - 8, "SELECT A NODE", 13, _t.textDim, 0.75);
        return;
    }

    var _node = mer_tree_get(_tree, _id);
    if (is_undefined(_node)) return;

    var _pal  = mer_discipline_palette(_node.disc);
    var _vis  = mer_progress_state(_tree, _state, _id);
    var _rank = mer_progress_rank(_state, _id);
    var _cy2  = _y + 86;

    // --- the mark, large --------------------------------------------------------------------
    draw_set_colour(_pal[MER_ROLE_LIMB]);
    for (var _g = 6; _g >= 1; _g--) {
        draw_set_alpha(0.045 * (7 - _g) / 6);
        draw_circle(_x + _w * 0.5, _cy2, 52 + _g * 5, false);
    }
    draw_set_alpha(1);
    mer_sigil_draw(_node.sigil, _x + _w * 0.5, _cy2, 116, _node.disc, 1, 1.15,
                   (_vis == MER_STATE_LOCKED) ? 0.6 : 0);

    var _ty = _y + 156;

    // --- name, fitted to the panel so a long skill name cannot run through the wall ----------
    var _ns = mer_text_fit_size(_node.name, 22, _iw);
    mer_draw_text_centred(_x + _w * 0.5, _ty, _node.name, _ns, _t.text, 1);
    _ty += _ns + 14;

    // --- discipline and tier ------------------------------------------------------------------
    var _tier = (_node.tier == MER_TIER_KEYSTONE) ? "KEYSTONE"
              : (_node.tier == MER_TIER_MAJOR ? "MAJOR" : "MINOR");
    var _sub = mer_discipline_name(_node.disc) + "  /  " + _tier;
    mer_draw_text_centred(_x + _w * 0.5, _ty, _sub, 10, _pal[MER_ROLE_LIMB], 0.95);
    _ty += 26;

    // --- separator ------------------------------------------------------------------------------
    draw_set_alpha(0.35);
    draw_set_colour(_t.edge);
    draw_line(_x + _pad, _ty, _x + _w - _pad, _ty);
    draw_set_alpha(1);
    _ty += 18;

    // --- rank readout ---------------------------------------------------------------------------
    if (_node.maxRank > 1) {
        mer_draw_text(_x + _pad, _ty, "RANK", 10, _t.textDim, 0.9);
        var _rx = _x + _w - _pad - _node.maxRank * 22;
        for (var _k = 0; _k < _node.maxRank; _k++) {
            var _on = (_k < _rank);
            var _px3 = _rx + _k * 22 + 9, _py3 = _ty + 5;
            draw_set_colour(_t.track);
            draw_set_alpha(0.7);
            draw_circle(_px3, _py3, 8, false);
            if (_on) {
                draw_set_colour(_pal[MER_ROLE_LIMB]);
                draw_set_alpha(0.30);
                draw_circle(_px3, _py3, 11, false);
                draw_set_colour(_pal[MER_ROLE_SPARK]);
                draw_set_alpha(1);
                draw_circle(_px3, _py3, 6, false);
            }
        }
        draw_set_alpha(1);
        _ty += 30;
    }

    // --- cost -------------------------------------------------------------------------------
    mer_draw_text(_x + _pad, _ty, "COST", 10, _t.textDim, 0.9);
    mer_draw_text_right(_x + _w - _pad, _ty, string(_node.cost) + (_node.cost == 1 ? " POINT" : " POINTS"),
                        10, _t.text, 0.95);
    _ty += 26;

    // --- description --------------------------------------------------------------------------
    if (_node.desc != "") {
        var _lines = mer_text_wrap(_node.desc, 10, _iw);
        for (var _l = 0; _l < array_length(_lines); _l++) {
            mer_draw_text(_x + _pad, _ty, _lines[_l], 10, _t.textDim, 0.92);
            _ty += 17;
        }
        _ty += 8;
    }

    // --- stat contribution ----------------------------------------------------------------------
    if (_node.stat != "") {
        var _now = _node.value * max(_rank, 1);
        mer_draw_text(_x + _pad, _ty, string_upper(_node.stat), 10, _t.textDim, 0.9);
        mer_draw_text_right(_x + _w - _pad, _ty, "+" + string(_now), 10, _pal[MER_ROLE_CORE], 1);
        _ty += 26;
    }

    // --- status, pinned to the bottom so it is always in the same place ------------------------
    var _msg = "", _col = _t.textDim;
    switch (_vis) {
        case MER_STATE_MAXED:     _msg = "MASTERED";  _col = _t.success; break;
        case MER_STATE_PARTIAL:   _msg = "RANK " + string(_rank) + " OF " + string(_node.maxRank);
                                  _col = _pal[MER_ROLE_CORE]; break;
        case MER_STATE_AVAILABLE:
            _msg = (_state.points >= _node.cost) ? "AVAILABLE" : "NOT ENOUGH POINTS";
            _col = (_state.points >= _node.cost) ? _t.success : _t.warning;
            break;
        default:                  _msg = "LOCKED";    _col = _t.danger;  break;
    }
    var _by = _y + _h - 42;
    draw_set_alpha(0.16);
    draw_set_colour(_col);
    draw_rectangle(_x + _pad, _by - 8, _x + _w - _pad, _by + 22, false);
    draw_set_alpha(1);
    mer_draw_text_centred(_x + _w * 0.5, _by, _msg, 12, _col, 1);
}
