/// @file    mer_forge.gml
/// @package Meridian for GameMaker — ARMATURE, the authoring layer
/// @author  CSAF
/// @licence See LICENSE.txt shipped alongside this package.
///
/// @summary Armature: build the tree by hand instead of by typing it. Add nodes, draw prerequisite
///          edges, flip through all 480 generated marks on the node you are looking at, then EXPORT
///          the whole thing as GML you paste into your game.
///
/// @remarks WHY AN AUTHORING LAYER AND NOT A LEVEL EDITOR.
///
///          Meridian's whole argument is that you should declare what depends on what and let the
///          layout be DERIVED. A builder that makes you drag nodes to x,y positions would contradict
///          the product it ships inside — you would be back to hand-placing forty pairs of
///          coordinates, which is the thing mer_tree.gml exists to abolish.
///
///          So Armature edits the GRAPH, never the canvas. You add a node, you connect it, and the
///          layout re-derives in front of you with the springs already in mer_view. Change your mind
///          about the shape of the screen and all four layouts are one keypress apart. Watching a
///          tree reflow as you wire it up is the clearest possible demonstration of the claim the
///          package is built on, which is why this is also the store GIF.
///
///          WHAT YOU ACTUALLY GET OUT. mer_forge_export_gml returns source text: one mer_tree_add
///          call per node, tier macros spelled out, motif names in trailing comments, ready to paste.
///          A node's entire art payload in that text is TWO INTEGERS — its motif index and its
///          discipline — because Meridian draws every mark from geometry at draw time and ships no
///          art at all. That matters more than it sounds: an exported tree is not a baked atlas that
///          will go stale, it is a description that regenerates its own artwork in your game, at your
///          theme, at any size, forever.
///
///          EVERYTHING ABOVE THE INTERACTION SECTION IS PURE. No draw calls, no mouse, no globals
///          except the motif tables. That is deliberate and it is this wing's only real defence:
///          GML cannot be unit-tested outside the engine, so the logic is pushed into functions the
///          in-engine suite can call directly and assert on, and only the thin top layer needs eyes.

#macro MER_FORGE_VERSION "1.1.0"

// Editing modes. The mode is a property of the SESSION, never of the tree, so a tree that has been
// through Armature is byte-identical to one typed by hand — there is no editor metadata to strip
// before shipping, and no way to accidentally ship a half-edited state.
#macro MER_FORGE_MODE_SELECT 0
#macro MER_FORGE_MODE_LINK   1
#macro MER_FORGE_MODE_EXPORT 2

// Fields the inspector can step through, in the order they appear down the panel.
#macro MER_FORGE_FIELD_SIGIL 0
#macro MER_FORGE_FIELD_DISC  1
#macro MER_FORGE_FIELD_TIER  2
#macro MER_FORGE_FIELD_COST  3
#macro MER_FORGE_FIELD_RANK  4
#macro MER_FORGE_FIELD_COUNT 5

/// Height reserved at the foot of the canvas for the status strip. The tree is framed into the
/// canvas MINUS this, because framing into the full height put the deepest node underneath the
/// message box — visible in a baked screenshot and in nothing else.
#macro MER_FORGE_STRIP_H 56

// =================================================================================================
// SESSION
// =================================================================================================

/// @func   mer_forge_make(_tree)
/// @desc   Opens an authoring session on a tree.
///
/// @remarks The session owns a view, because the editor and the runtime look at the tree through
///          exactly the same lens. Sharing mer_view rather than writing a second renderer is what
///          guarantees that what you author is what your players see — a separate editor renderer
///          is how "it looked right in the tool" happens.
///
/// @param  {Struct} _tree  A tree from mer_tree_make.
/// @return {Struct} A forge session.
function mer_forge_make(_tree) {
    // ⛔ THE LAYOUT IS APPLIED BEFORE THE VIEW IS BUILT, AND THAT IS NOT TIDINESS. mer_tree_add
    // leaves every node at lx,ly = 0 until a layout pass runs, so a session opened on a tree that
    // has not been laid out shows every node STACKED ON THE ORIGIN — one visible node, the rest
    // hidden underneath it, and no error anywhere.
    //
    // The first version left this to the caller, because the demo object happened to call
    // mer_layout_apply first. That made the defect invisible in this package and guaranteed for any
    // buyer who called mer_forge_make on a tree they had just built, which is the obvious thing to
    // do. It was caught by an assertion about the store GIF, of all things: the scripted drag
    // measured 0 px of travel, because both of its endpoints were the same point.
    //
    // The view also has to be built AFTER, since mer_view_make reads mer_tree_bounds to centre
    // itself, and the bounds of a tree stacked on the origin are zero.
    mer_layout_apply(0, _tree);

    var _f = {
        view      : mer_view_make(_tree),
        prog      : mer_progress_make(0),
        mode      : MER_FORGE_MODE_SELECT,
        selected  : "",
        linkFrom  : "",         // non-empty while a prerequisite edge is being dragged
        field     : MER_FORGE_FIELD_SIGIL,
        layout    : 0,
        message   : "",
        messageAt : 0,
        exportText: "",
        exportLine: 0,
        linkToX   : -1,        // where a dragged edge ends; -1 means "follow the pointer"
        linkToY   : -1,
        dirty     : true,
        serial    : 0,          // bumped on every graph change; the suite asserts against it
    };
    // Everything is unlocked, because in the editor you are looking at the tree as a DESIGNER, and
    // a designer needs to see every node at full strength rather than most of them greyed out.
    mer_forge_unlock_all(_tree, _f.prog);
    return _f;
}

/// @func   mer_forge_starter_tree()
/// @desc   The six-node tree Armature opens on.
///
/// @remarks AN EMPTY CANVAS IS THE WORST FIRST SCREEN AN AUTHORING TOOL CAN SHOW. There is no
///          gesture to imitate, nothing on screen demonstrates what a finished thing looks like,
///          and the first click has to be explained in words instead of copied. Six nodes across
///          three disciplines is enough to show the shape of an answer — a root, two branches, a
///          keystone that needs both — and small enough to delete in six keystrokes.
///
///          Deliberately NOT the demo room's 34-node tree: that one exists to look impressive, and
///          an editor opening on something impressive suggests you are meant to edit it rather than
///          replace it.
///
/// @return {Struct} A tree.
function mer_forge_starter_tree() {
    var _t = mer_tree_make();
    mer_tree_add(_t, "root",     { name: "AWAKENING", sigil: mer_sigil_find("FOCUS"),  disc: 1,
                                   tier: MER_TIER_MAJOR, cost: 1, maxRank: 1, requires: [],
                                   stat: "mana", value: 5, desc: "Where everything starts." });
    mer_tree_add(_t, "might",    { name: "MIGHT",     sigil: mer_sigil_find("CLEAVE"), disc: 0,
                                   tier: MER_TIER_MINOR, cost: 1, maxRank: 3, requires: ["root"],
                                   stat: "power", value: 4, desc: "Hit harder." });
    mer_tree_add(_t, "vitality", { name: "VITALITY",  sigil: mer_sigil_find("VIGOR"),  disc: 2,
                                   tier: MER_TIER_MINOR, cost: 1, maxRank: 3, requires: ["root"],
                                   stat: "health", value: 8, desc: "Last longer." });
    mer_tree_add(_t, "guard",    { name: "GUARD",     sigil: mer_sigil_find("GUARD"),  disc: 0,
                                   tier: MER_TIER_MINOR, cost: 1, maxRank: 2, requires: ["might"],
                                   stat: "guard", value: 6, desc: "Hold the line." });
    mer_tree_add(_t, "mend",     { name: "MEND",      sigil: mer_sigil_find("MEND"),   disc: 2,
                                   tier: MER_TIER_MINOR, cost: 1, maxRank: 2, requires: ["vitality"],
                                   stat: "health", value: 7, desc: "Recover between fights." });
    mer_tree_add(_t, "keystone", { name: "RESOLVE",   sigil: mer_sigil_find("RENEW"),  disc: 2,
                                   tier: MER_TIER_KEYSTONE, cost: 3, maxRank: 1,
                                   requires: ["guard", "mend"], stat: "health", value: 25,
                                   desc: "Survive a lethal blow once per encounter." });
    return _t;
}

/// @func   mer_forge_unlock_all(_tree, _state)
/// @desc   Grants and buys every node, so the editor shows the tree at full colour.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _state  A progress state.
/// @remarks ⛔⛔ `mer_progress_can_unlock` RETURNS A STATUS CODE, AND `MER_UNLOCK_OK` IS **0**.
///          Zero is falsy, so the obvious `while (mer_progress_can_unlock(...))` is EXACTLY
///          INVERTED: it skips the node that can be bought and spins forever on the node that
///          cannot, because MAXED, LOCKED, NO_POINTS and NO_NODE are 3, 1, 2 and 4 — all truthy —
///          and mer_progress_unlock correctly refuses to change anything, so the condition never
///          becomes false.
///
///          That defect was written here and it HUNG A HEADLESS BUILD rather than failing it: no
///          crash, no dialog, no output, a process that had to be killed on a timeout. It is the
///          worst available failure mode in this wing, and it is invisible to the compiler because
///          GML has no types to disagree about. ⇒ NEVER test a mer_* status code for truth. Compare
///          it to the macro, every time.
///
///          The pass counter is a hard bound as well as a convergence limit: with the comparison
///          fixed this loop terminates on its own, and the bound means a future change to the
///          progression contract degrades into a wrong picture rather than back into a hang.
function mer_forge_unlock_all(_tree, _state) {
    var _n = mer_tree_count(_tree);
    mer_progress_grant(_state, 9999);
    // Repeated passes: a node cannot be bought before its prerequisites, and one pass in array
    // order would leave anything declared before its parent locked. Depth-many passes always
    // suffice, and the node count is a safe bound on depth.
    for (var _pass = 0; _pass < _n; _pass++) {
        var _any = false;
        for (var _i = 0; _i < _n; _i++) {
            var _id = _tree.nodes[_i].id;
            // Bounded by maxRank rather than by "until it stops working", so no contract change can
            // turn this back into an unbounded spin.
            var _guard = mer_tree_get(_tree, _id).maxRank + 1;
            while (_guard > 0 && mer_progress_can_unlock(_tree, _state, _id) == MER_UNLOCK_OK) {
                mer_progress_unlock(_tree, _state, _id);
                _any = true;
                _guard -= 1;
            }
        }
        if (!_any) break;
    }
}

/// @func   mer_forge_touch(_forge, _tree)
/// @desc   Call after ANY change to the graph. Re-derives the layout and resizes the view.
/// @param  {Struct} _forge  A session.
/// @param  {Struct} _tree   A tree.
function mer_forge_touch(_forge, _tree) {
    _forge.serial += 1;
    mer_layout_apply(_forge.layout, _tree);
    mer_view_sync(_forge.view, _tree);
    mer_forge_unlock_all(_tree, _forge.prog);
    _forge.dirty = true;
}

/// @func   mer_forge_say(_forge, _text)
/// @desc   Posts a transient line to the editor's status strip.
/// @param  {Struct} _forge  A session.
/// @param  {String} _text   The message.
function mer_forge_say(_forge, _text) {
    _forge.message = _text;
    _forge.messageAt = 0;
}

// =================================================================================================
// GRAPH EDITING — pure. No drawing, no input, no globals. The suite asserts directly on these.
// =================================================================================================

/// @func   mer_forge_new_id(_tree, _stem)
/// @desc   Produces an id that is not already in the tree.
///
/// @remarks Ids are the save format's primary key and a duplicate silently drops a node
///          (mer_tree_add refuses it and logs). Generating rather than prompting removes the one
///          way a hand-authored tree loses work without saying so.
///
/// @param  {Struct} _tree  A tree.
/// @param  {String} _stem  A prefix, e.g. "node".
/// @return {String} A free id.
function mer_forge_new_id(_tree, _stem) {
    var _i = 1;
    while (_i < 100000) {
        var _candidate = _stem + string(_i);
        if (!variable_struct_exists(_tree.byId, _candidate)) return _candidate;
        _i += 1;
    }
    return _stem + "_overflow";
}

/// @func   mer_forge_add(_forge, _tree, _def)
/// @desc   Adds a node and selects it.
/// @param  {Struct} _forge  A session, or undefined for a headless edit.
/// @param  {Struct} _tree   A tree.
/// @param  {Struct} _def    A node definition, as mer_tree_add takes.
/// @return {String} The new node's id, or "" if it was refused.
function mer_forge_add(_forge, _tree, _def) {
    var _id = variable_struct_exists(_def, "id") ? _def.id : mer_forge_new_id(_tree, "node");
    var _node = mer_tree_add(_tree, _id, _def);
    if (is_undefined(_node)) return "";
    if (!is_undefined(_forge)) {
        _forge.selected = _id;
        mer_forge_touch(_forge, _tree);
    }
    return _id;
}

/// @func   mer_forge_remove(_tree, _id)
/// @desc   Deletes a node AND every reference to it from other nodes' prerequisites.
///
/// @remarks THE DANGLING-PREREQUISITE TRAP, and it is why this function exists rather than a
///          one-line array_delete. Removing a node without sweeping the references leaves children
///          requiring an id that is not in the tree. mer_progress_requirements_met looks that id up,
///          gets undefined, and the child becomes PERMANENTLY unbuyable — a tree that loads, draws,
///          validates by eye, and has a dead branch in it. Deleting a node has to mean deleting the
///          edges into it, in the same operation, or the operation is not finished.
///
/// @param  {Struct} _tree  A tree.
/// @param  {String} _id    The node to remove.
/// @return {Real} How many prerequisite references were swept, or -1 if the id was not present.
function mer_forge_remove(_tree, _id) {
    if (!variable_struct_exists(_tree.byId, _id)) return -1;

    var _index = variable_struct_get(_tree.byId, _id);
    array_delete(_tree.nodes, _index, 1);

    // Rebuild byId wholesale. Patching indices in place is where an off-by-one lives, and the
    // rebuild is O(n) on a structure that is never large enough for that to matter.
    _tree.byId = {};
    var _n = array_length(_tree.nodes);
    var _swept = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _node = _tree.nodes[_i];
        variable_struct_set(_tree.byId, _node.id, _i);

        var _req = _node.requires;
        var _keep = [];
        for (var _r = 0; _r < array_length(_req); _r++) {
            if (_req[_r] == _id) _swept += 1;
            else array_push(_keep, _req[_r]);
        }
        _node.requires = _keep;
    }
    _tree.dirty = true;
    return _swept;
}

/// @func   mer_forge_reaches(_tree, _from, _to)
/// @desc   Is _to reachable from _from by following prerequisite edges forward?
///
/// @remarks Iterative, with a visited set. A recursive walk on a graph that ALREADY contains a
///          cycle — which is exactly the state this is called to prevent, and therefore exactly the
///          state it can be called in — does not return.
///
/// @param  {Struct} _tree  A tree.
/// @param  {String} _from  Start id.
/// @param  {String} _to    Target id.
/// @return {Bool} True if a path exists.
function mer_forge_reaches(_tree, _from, _to) {
    if (_from == _to) return true;
    var _seen = {};
    var _stack = [_from];
    while (array_length(_stack) > 0) {
        var _cur = array_pop(_stack);
        if (variable_struct_exists(_seen, _cur)) continue;
        variable_struct_set(_seen, _cur, true);

        // Every node that requires _cur is a forward step.
        var _n = mer_tree_count(_tree);
        for (var _i = 0; _i < _n; _i++) {
            var _node = _tree.nodes[_i];
            var _req = _node.requires;
            for (var _r = 0; _r < array_length(_req); _r++) {
                if (_req[_r] != _cur) continue;
                if (_node.id == _to) return true;
                array_push(_stack, _node.id);
            }
        }
    }
    return false;
}

/// @func   mer_forge_link(_tree, _from, _to)
/// @desc   Makes _to require _from.
///
/// @remarks REFUSES RATHER THAN REPAIRS, and says why. A cycle in a prerequisite graph is not a
///          cosmetic problem: mer_tree_compute_depth detects it and gives up, so the layout stops
///          being derivable and the whole screen degrades. Catching it at the gesture — the instant
///          the edge is drawn — is the only point at which the author still knows what they meant.
///
/// @param  {Struct} _tree  A tree.
/// @param  {String} _from  The prerequisite.
/// @param  {String} _to    The node that will require it.
/// @return {Struct} {ok: bool, reason: string}.
function mer_forge_link(_tree, _from, _to) {
    if (_from == "" || _to == "")            return { ok: false, reason: "nothing selected" };
    if (_from == _to)                        return { ok: false, reason: "a node cannot require itself" };
    if (!variable_struct_exists(_tree.byId, _from)) return { ok: false, reason: "no node '" + _from + "'" };
    if (!variable_struct_exists(_tree.byId, _to))   return { ok: false, reason: "no node '" + _to + "'" };

    var _target = mer_tree_get(_tree, _to);
    for (var _i = 0; _i < array_length(_target.requires); _i++) {
        if (_target.requires[_i] == _from) return { ok: false, reason: "already required" };
    }
    // Would this edge close a loop? _to already reaching _from means yes.
    if (mer_forge_reaches(_tree, _to, _from)) {
        return { ok: false, reason: "refused: that would make a cycle" };
    }

    var _req = _target.requires;
    array_push(_req, _from);
    _target.requires = _req;
    _tree.dirty = true;
    return { ok: true, reason: "linked" };
}

/// @func   mer_forge_unlink(_tree, _from, _to)
/// @desc   Removes the requirement of _from from _to.
/// @param  {Struct} _tree  A tree.
/// @param  {String} _from  The prerequisite to drop.
/// @param  {String} _to    The node to drop it from.
/// @return {Bool} True if an edge was removed.
function mer_forge_unlink(_tree, _from, _to) {
    if (!variable_struct_exists(_tree.byId, _to)) return false;
    var _target = mer_tree_get(_tree, _to);
    var _keep = [];
    var _hit = false;
    for (var _i = 0; _i < array_length(_target.requires); _i++) {
        if (_target.requires[_i] == _from) { _hit = true; continue; }
        array_push(_keep, _target.requires[_i]);
    }
    _target.requires = _keep;
    if (_hit) _tree.dirty = true;
    return _hit;
}

/// @func   mer_forge_toggle_link(_tree, _from, _to)
/// @desc   Links if unlinked, unlinks if linked. The single gesture the editor binds to a drag.
/// @param  {Struct} _tree  A tree.
/// @param  {String} _from  The prerequisite.
/// @param  {String} _to    The dependent node.
/// @return {Struct} {ok, reason}.
function mer_forge_toggle_link(_tree, _from, _to) {
    if (mer_forge_unlink(_tree, _from, _to)) return { ok: true, reason: "unlinked" };
    return mer_forge_link(_tree, _from, _to);
}

/// @func   mer_forge_step_field(_tree, _id, _field, _delta)
/// @desc   Steps one inspector field on one node, wrapping or clamping as that field requires.
///
/// @remarks THIS IS WHERE THE 480 MARKS BECOME BROWSABLE. Stepping the sigil field walks all sixty
///          motifs; stepping the discipline field re-palettes the same motif across all eight. The
///          product has always been able to draw them; until now there was no way to LOOK at them
///          without editing source and rebuilding.
///
/// @param  {Struct} _tree   A tree.
/// @param  {String} _id     Node id.
/// @param  {Real}   _field  One of the MER_FORGE_FIELD_* macros.
/// @param  {Real}   _delta  Usually +1 or -1.
/// @return {Bool} True if something changed.
function mer_forge_step_field(_tree, _id, _field, _delta) {
    var _node = mer_tree_get(_tree, _id);
    if (is_undefined(_node)) return false;

    switch (_field) {
        case MER_FORGE_FIELD_SIGIL:
            var _sc = mer_sigil_count();
            _node.sigil = ((_node.sigil + _delta) % _sc + _sc) % _sc;
            return true;

        case MER_FORGE_FIELD_DISC:
            var _dc = mer_discipline_count();
            _node.disc = ((_node.disc + _delta) % _dc + _dc) % _dc;
            return true;

        case MER_FORGE_FIELD_TIER:
            // Clamped, not wrapped: tier is an ordered scale and wrapping a keystone back to a
            // minor with one keypress is a destructive surprise rather than a convenience.
            _node.tier = clamp(_node.tier + _delta, MER_TIER_MINOR, MER_TIER_KEYSTONE);
            return true;

        case MER_FORGE_FIELD_COST:
            _node.cost = max(0, _node.cost + _delta);
            return true;

        case MER_FORGE_FIELD_RANK:
            _node.maxRank = max(1, _node.maxRank + _delta);
            return true;
    }
    return false;
}

/// @func   mer_forge_field_name(_field)
/// @desc   The inspector's label for a field.
/// @param  {Real} _field  A MER_FORGE_FIELD_* macro.
/// @return {String} The label.
function mer_forge_field_name(_field) {
    switch (_field) {
        case MER_FORGE_FIELD_SIGIL: return "MOTIF";
        case MER_FORGE_FIELD_DISC:  return "DISCIPLINE";
        case MER_FORGE_FIELD_TIER:  return "TIER";
        case MER_FORGE_FIELD_COST:  return "COST";
        case MER_FORGE_FIELD_RANK:  return "MAX RANK";
    }
    return "?";
}

/// @func   mer_forge_field_value(_tree, _id, _field)
/// @desc   The inspector's displayed value for a field.
/// @param  {Struct} _tree   A tree.
/// @param  {String} _id     Node id.
/// @param  {Real}   _field  A MER_FORGE_FIELD_* macro.
/// @return {String} The value, already formatted.
function mer_forge_field_value(_tree, _id, _field) {
    var _node = mer_tree_get(_tree, _id);
    if (is_undefined(_node)) return "-";
    switch (_field) {
        case MER_FORGE_FIELD_SIGIL: return mer_sigil_name(_node.sigil) + "  " + string(_node.sigil + 1) + "/" + string(mer_sigil_count());
        case MER_FORGE_FIELD_DISC:  return mer_discipline_name(_node.disc);
        case MER_FORGE_FIELD_TIER:  return mer_forge_tier_name(_node.tier);
        case MER_FORGE_FIELD_COST:  return string(_node.cost);
        case MER_FORGE_FIELD_RANK:  return string(_node.maxRank);
    }
    return "-";
}

/// @func   mer_forge_tier_name(_tier)
/// @desc   Human name for a tier.
/// @param  {Real} _tier  A MER_TIER_* macro.
/// @return {String} The name.
function mer_forge_tier_name(_tier) {
    switch (_tier) {
        case MER_TIER_KEYSTONE: return "KEYSTONE";
        case MER_TIER_MAJOR:    return "MAJOR";
    }
    return "MINOR";
}

/// @func   mer_forge_tier_macro(_tier)
/// @desc   The MACRO NAME for a tier, for the GML export.
///
/// @remarks Exported source says MER_TIER_KEYSTONE rather than 2. A buyer reads the export; a
///          bare integer there is the difference between generated code you can maintain and
///          generated code you delete and rewrite.
///
/// @param  {Real} _tier  A MER_TIER_* macro.
/// @return {String} The macro's name.
function mer_forge_tier_macro(_tier) {
    switch (_tier) {
        case MER_TIER_KEYSTONE: return "MER_TIER_KEYSTONE";
        case MER_TIER_MAJOR:    return "MER_TIER_MAJOR";
    }
    return "MER_TIER_MINOR";
}

// =================================================================================================
// VALIDATION — an ACTOR, not a reporter. It names the defect and mer_forge_repair fixes it.
// =================================================================================================

/// @func   mer_forge_validate(_tree)
/// @desc   Checks a tree for the four faults that make one unusable at runtime.
///
/// @remarks WHAT IT LOOKS FOR, and every one of these has a runtime consequence rather than being
///          a matter of taste:
///            - a CYCLE, which stops mer_tree_compute_depth converging and kills the layout;
///            - a DANGLING prerequisite, which makes a node permanently unbuyable;
///            - a node whose SIGIL is out of the corpus, which would draw the wrong mark;
///            - NO ROOT, which makes the entire tree unbuyable because nothing can be bought first.
///
/// @param  {Struct} _tree  A tree.
/// @return {Struct} {ok, problems: array of {kind, id, text}, roots, nodes}.
function mer_forge_validate(_tree) {
    var _problems = [];
    var _n = mer_tree_count(_tree);
    var _roots = 0;
    var _sc = mer_sigil_count();
    var _dc = mer_discipline_count();

    for (var _i = 0; _i < _n; _i++) {
        var _node = _tree.nodes[_i];
        var _req = _node.requires;

        if (array_length(_req) == 0) _roots += 1;

        for (var _r = 0; _r < array_length(_req); _r++) {
            if (!variable_struct_exists(_tree.byId, _req[_r])) {
                array_push(_problems, { kind: "dangling", id: _node.id,
                    text: _node.id + " requires '" + string(_req[_r]) + "', which is not in the tree" });
            }
        }

        if (_node.sigil < 0 || _node.sigil >= _sc) {
            array_push(_problems, { kind: "sigil", id: _node.id,
                text: _node.id + " has motif " + string(_node.sigil) + ", outside 0.." + string(_sc - 1) });
        }
        if (_node.disc < 0 || _node.disc >= _dc) {
            array_push(_problems, { kind: "disc", id: _node.id,
                text: _node.id + " has discipline " + string(_node.disc) + ", outside 0.." + string(_dc - 1) });
        }
    }

    // A cycle is detected by the same routine the layout uses, so validation and runtime cannot
    // disagree about what counts as one.
    if (_n > 0 && !mer_tree_compute_depth(_tree)) {
        array_push(_problems, { kind: "cycle", id: "",
            text: "the prerequisite graph contains a cycle, so no layout can be derived" });
    }

    if (_n > 0 && _roots == 0) {
        array_push(_problems, { kind: "noroot", id: "",
            text: "every node has a prerequisite, so nothing can ever be bought first" });
    }

    return { ok: array_length(_problems) == 0, problems: _problems, roots: _roots, nodes: _n };
}

/// @func   mer_forge_repair(_tree)
/// @desc   Fixes what mer_forge_validate can fix without guessing at intent, and reports what it did.
///
/// @remarks IT DOES NOT TOUCH CYCLES OR A MISSING ROOT. Both have several equally valid repairs and
///          picking one silently would be the tool making a design decision on the author's behalf.
///          Master's own catalogue records what that costs: a guard that FABRICATES a value when it
///          cannot find a good one encodes a decision nobody made. Dangling references and
///          out-of-range indices have exactly one sane repair each, so those are taken.
///
/// @param  {Struct} _tree  A tree.
/// @return {Struct} {changed, actions: array of string}.
function mer_forge_repair(_tree) {
    var _actions = [];
    var _n = mer_tree_count(_tree);
    var _sc = mer_sigil_count();
    var _dc = mer_discipline_count();

    for (var _i = 0; _i < _n; _i++) {
        var _node = _tree.nodes[_i];

        var _keep = [];
        for (var _r = 0; _r < array_length(_node.requires); _r++) {
            var _id = _node.requires[_r];
            if (variable_struct_exists(_tree.byId, _id)) array_push(_keep, _id);
            else array_push(_actions, "dropped dangling prerequisite '" + string(_id) + "' from " + _node.id);
        }
        _node.requires = _keep;

        if (_node.sigil < 0 || _node.sigil >= _sc) {
            var _was = _node.sigil;
            _node.sigil = ((_node.sigil % _sc) + _sc) % _sc;
            array_push(_actions, _node.id + " motif " + string(_was) + " wrapped into range as " + string(_node.sigil));
        }
        if (_node.disc < 0 || _node.disc >= _dc) {
            var _wasd = _node.disc;
            _node.disc = ((_node.disc % _dc) + _dc) % _dc;
            array_push(_actions, _node.id + " discipline " + string(_wasd) + " wrapped into range as " + string(_node.disc));
        }
    }

    if (array_length(_actions) > 0) _tree.dirty = true;
    return { changed: array_length(_actions), actions: _actions };
}

// =================================================================================================
// EXPORT — the deliverable. Pure string building.
// =================================================================================================

/// @func   mer_forge_escape(_s)
/// @desc   Makes a string safe inside a GML double-quoted literal.
///
/// @remarks GML has no escape sequence for a double quote inside a string literal — the language
///          expects you to concatenate chr(34). Emitting that inside a generated struct literal is
///          unreadable, so a quote in a node's name or description is folded to a typographic-free
///          apostrophe instead. That is a lossy transform and it is the right one: the alternative
///          is generated source that does not compile, which is the one outcome an exporter must
///          never produce.
///
/// @param  {String} _s  Any string.
/// @return {String} A literal-safe string.
function mer_forge_escape(_s) {
    var _out = string_replace_all(string(_s), "\"", "'");
    _out = string_replace_all(_out, "\\", "/");
    _out = string_replace_all(_out, "\n", " ");
    _out = string_replace_all(_out, "\r", " ");
    return _out;
}

/// @func   mer_forge_export_gml(_tree, _function_name)
/// @desc   Renders the whole tree as pasteable GML: one mer_tree_add call per node.
///
/// @remarks ⭐ THE ART PAYLOAD OF EVERY LINE THIS EMITS IS TWO INTEGERS — sigil and disc. There is
///          no atlas reference, no sprite name and no path, because Meridian generates all 480 marks
///          from geometry at draw time. An exported tree therefore GENERATES its artwork in the
///          buyer's shipped game exactly as a hand-typed one does, at their theme and at any size.
///          That property is what makes an authoring layer legitimate here rather than a bolt-on:
///          the editor cannot bake anything, because there is nothing to bake.
///
///          Node order is the tree's own array order, which is insertion order, which is stable.
///          Deterministic output matters for a file a buyer will keep in version control.
///
/// @param  {Struct} _tree           A tree.
/// @param  {String} _function_name  The wrapper function to generate.
/// @return {String} GML source text.
function mer_forge_export_gml(_tree, _function_name = "build_skill_tree") {
    var _n = mer_tree_count(_tree);
    var _nl = chr(10);

    var _s = "/// Generated by Armature, the Meridian authoring layer (v" + MER_FORGE_VERSION + ")." + _nl;
    _s += "/// " + string(_n) + " node(s). Every mark is drawn from geometry at run time:" + _nl;
    _s += "/// the only artwork reference below is a motif index and a discipline index." + _nl;
    _s += "function " + _function_name + "() {" + _nl;
    _s += "    var _t = mer_tree_make();" + _nl + _nl;

    for (var _i = 0; _i < _n; _i++) {
        var _node = _tree.nodes[_i];

        var _req = "[";
        for (var _r = 0; _r < array_length(_node.requires); _r++) {
            if (_r > 0) _req += ", ";
            _req += "\"" + mer_forge_escape(_node.requires[_r]) + "\"";
        }
        _req += "]";

        // ⛔ WRAPPED ACROSS LINES ON PURPOSE. The first version emitted one line per node and they
        // ran to about 250 characters — genuinely bad GML to hand somebody, and it overflowed the
        // export panel so the store screenshot showed code sliced off at the window edge. Both
        // problems have the same cause and the same fix, and the file a buyer keeps in version
        // control is the one that matters: a 250-character line makes every diff unreadable.
        _s += "    mer_tree_add(_t, \"" + mer_forge_escape(_node.id) + "\", {" +
              "   // " + mer_sigil_name(_node.sigil) + " / " + mer_discipline_name(_node.disc) + _nl;
        _s += "        name: \"" + mer_forge_escape(_node.name) + "\"," +
              " sigil: " + string(_node.sigil) + "," +
              " disc: " + string(_node.disc) + "," +
              " tier: " + mer_forge_tier_macro(_node.tier) + "," + _nl;
        _s += "        cost: " + string(_node.cost) + "," +
              " maxRank: " + string(_node.maxRank) + "," +
              " stat: \"" + mer_forge_escape(_node.stat) + "\"," +
              " value: " + string(_node.value) + "," + _nl;
        _s += "        requires: " + _req + "," + _nl;
        _s += "        desc: \"" + mer_forge_escape(_node.desc) + "\"" + _nl;
        _s += "    });" + _nl;
    }

    _s += _nl + "    mer_layout_apply(0, _t);   // 0 constellation, 1 branching, 2 radial, 3 grid" + _nl;
    _s += "    return _t;" + _nl;
    _s += "}" + _nl;
    return _s;
}

/// @func   mer_forge_export_json(_tree)
/// @desc   Renders the tree as JSON, for a project that would rather load data than compile it.
///
/// @remarks Hand-built rather than json_stringify, because struct field ORDER is not guaranteed and
///          a save format whose bytes move between runs makes a diff useless.
///
/// @param  {Struct} _tree  A tree.
/// @return {String} JSON text.
function mer_forge_export_json(_tree) {
    var _n = mer_tree_count(_tree);
    var _s = "{\"format\":\"meridian-tree\",\"version\":\"" + MER_FORGE_VERSION + "\",\"nodes\":[";
    for (var _i = 0; _i < _n; _i++) {
        var _node = _tree.nodes[_i];
        if (_i > 0) _s += ",";
        _s += "{\"id\":\"" + mer_forge_escape(_node.id) + "\"";
        _s += ",\"name\":\"" + mer_forge_escape(_node.name) + "\"";
        _s += ",\"sigil\":" + string(_node.sigil);
        _s += ",\"disc\":" + string(_node.disc);
        _s += ",\"tier\":" + string(_node.tier);
        _s += ",\"cost\":" + string(_node.cost);
        _s += ",\"maxRank\":" + string(_node.maxRank);
        _s += ",\"stat\":\"" + mer_forge_escape(_node.stat) + "\"";
        _s += ",\"value\":" + string(_node.value);
        _s += ",\"desc\":\"" + mer_forge_escape(_node.desc) + "\"";
        _s += ",\"requires\":[";
        for (var _r = 0; _r < array_length(_node.requires); _r++) {
            if (_r > 0) _s += ",";
            _s += "\"" + mer_forge_escape(_node.requires[_r]) + "\"";
        }
        _s += "]}";
    }
    _s += "]}";
    return _s;
}

/// @func   mer_forge_import_json(_json)
/// @desc   Rebuilds a tree from mer_forge_export_json output.
///
/// @remarks REFUSES LOUDLY RATHER THAN RETURNING A HALF-TREE. A partial load is worse than none: it
///          looks like a tree, draws like a tree, and is missing branches nobody notices until a
///          player cannot buy something. Anything malformed returns undefined and says so.
///
/// @param  {String} _json  Text from mer_forge_export_json.
/// @return {Struct} A tree, or undefined.
function mer_forge_import_json(_json) {
    var _data = undefined;
    try {
        _data = json_parse(_json);
    } catch (_e) {
        show_debug_message("[Armature] import failed: " + string(_e.message));
        return undefined;
    }
    if (!is_struct(_data) || !variable_struct_exists(_data, "nodes")) {
        show_debug_message("[Armature] import failed: not a meridian-tree document");
        return undefined;
    }

    var _nodes = _data.nodes;
    if (!is_array(_nodes)) return undefined;

    var _t = mer_tree_make();
    for (var _i = 0; _i < array_length(_nodes); _i++) {
        var _r = _nodes[_i];
        if (!is_struct(_r) || !variable_struct_exists(_r, "id")) {
            show_debug_message("[Armature] import failed: node " + string(_i) + " has no id");
            return undefined;
        }
        mer_tree_add(_t, _r.id, {
            name    : variable_struct_exists(_r, "name")    ? _r.name    : string_upper(_r.id),
            sigil   : variable_struct_exists(_r, "sigil")   ? _r.sigil   : 0,
            disc    : variable_struct_exists(_r, "disc")    ? _r.disc    : 0,
            tier    : variable_struct_exists(_r, "tier")    ? _r.tier    : MER_TIER_MINOR,
            cost    : variable_struct_exists(_r, "cost")    ? _r.cost    : 1,
            maxRank : variable_struct_exists(_r, "maxRank") ? _r.maxRank : 1,
            requires: variable_struct_exists(_r, "requires") ? _r.requires : [],
            stat    : variable_struct_exists(_r, "stat")    ? _r.stat    : "",
            value   : variable_struct_exists(_r, "value")   ? _r.value   : 0,
            desc    : variable_struct_exists(_r, "desc")    ? _r.desc    : "",
        });
    }
    return _t;
}

// =================================================================================================
// INTERACTION
// =================================================================================================

/// @func   mer_forge_hit(_forge, _tree, _mx, _my, _cx, _cy)
/// @desc   Which node is under the pointer.
/// @param  {Struct} _forge  A session.
/// @param  {Struct} _tree   A tree.
/// @param  {Real}   _mx     Pointer x.
/// @param  {Real}   _my     Pointer y.
/// @param  {Real}   _cx     Canvas centre x.
/// @param  {Real}   _cy     Canvas centre y.
/// @return {String} A node id, or "".
function mer_forge_hit(_forge, _tree, _mx, _my, _cx, _cy) {
    var _v = _forge.view;
    var _n = mer_tree_count(_tree);
    var _best = "";
    var _bestD = 999999;
    for (var _i = 0; _i < _n; _i++) {
        var _node = _tree.nodes[_i];
        var _p = mer_view_to_screen(_v, _node.lx, _node.ly, _cx, _cy);
        var _r = mer_view_node_radius(_node, _v.zoom.value) + 6;
        var _d = point_distance(_mx, _my, _p.x, _p.y);
        if (_d <= _r && _d < _bestD) { _best = _node.id; _bestD = _d; }
    }
    return _best;
}

/// @func   mer_forge_update(_forge, _tree, _mx, _my, _cx, _cy, _dt)
/// @desc   One frame of editor logic. Call from Step.
/// @param  {Struct} _forge  A session.
/// @param  {Struct} _tree   A tree.
/// @param  {Real}   _mx     Pointer x.
/// @param  {Real}   _my     Pointer y.
/// @param  {Real}   _cx     Canvas centre x.
/// @param  {Real}   _cy     Canvas centre y.
/// @param  {Real}   _dt     Seconds since the last frame.
function mer_forge_update(_forge, _tree, _mx, _my, _cx, _cy, _dt) {
    _forge.messageAt += _dt;
    mer_view_update(_forge.view, _tree, _forge.prog, _mx, _my, _cx, _cy, _dt);
}

/// @func   mer_forge_layout_cycle(_forge, _tree, _delta)
/// @desc   Steps to the next layout engine and re-derives every position.
/// @param  {Struct} _forge  A session.
/// @param  {Struct} _tree   A tree.
/// @param  {Real}   _delta  +1 or -1.
function mer_forge_layout_cycle(_forge, _tree, _delta) {
    var _c = mer_layout_count();
    _forge.layout = ((_forge.layout + _delta) % _c + _c) % _c;
    mer_layout_apply(_forge.layout, _tree);
    mer_forge_say(_forge, "LAYOUT: " + mer_layout_name(_forge.layout));
}

/// @func   mer_forge_pose_count()
/// @desc   How many capture poses mer_forge_pose knows.
/// @return {Real} The count.
function mer_forge_pose_count() { return 6; }

/// @func   mer_forge_pose_name(_shot)
/// @desc   A short name for a pose, used as the captured file's name.
/// @param  {Real} _shot  Pose index.
/// @return {String} The name.
function mer_forge_pose_name(_shot) {
    switch (_shot) {
        case 0: return "editor";
        case 1: return "linking";
        case 2: return "export";
        case 3: return "motifs";
        case 4: return "layout";
        case 5: return "theme";
    }
    return "shot" + string(_shot);
}

/// @func   mer_forge_pose(_forge, _tree, _shot, _cx, _cy)
/// @desc   Puts the editor into a state a still image can actually show.
///
/// @remarks A SCREENSHOT CANNOT HOLD A MOUSE BUTTON DOWN, and it cannot press a key either. Every
///          state worth showing — mid-drag, the export overlay open, a motif being stepped — is a
///          state that only exists WHILE an input is held. So the poses are set as data rather than
///          performed as input, and they live in one function so the capture and the store gallery
///          cannot drift apart from each other.
///
///          Kept beside the editor rather than in the demo object because it is pure state, which
///          means the suite can assert on it: a pose that silently stopped selecting anything would
///          otherwise produce a plausible, empty screenshot.
///
/// @param  {Struct} _forge  A session.
/// @param  {Struct} _tree   A tree.
/// @param  {Real}   _shot   0..mer_forge_pose_count()-1.
/// @param  {Real}   _cx     Canvas centre x, for placing a dragged edge.
/// @param  {Real}   _cy     Canvas centre y.
/// @return {Bool} True if the pose was applied.
function mer_forge_pose(_forge, _tree, _shot, _cx = 480, _cy = 360) {
    if (mer_tree_count(_tree) == 0) return false;

    // Reset the transient bits, so poses cannot leak into each other when they are baked in
    // sequence from one process — the bug that makes shot 3 quietly contain shot 2's overlay.
    _forge.mode = MER_FORGE_MODE_SELECT;
    _forge.linkFrom = "";
    _forge.linkToX = -1;
    _forge.linkToY = -1;
    _forge.exportLine = 0;

    switch (_shot) {
        case 0:
            _forge.selected = "keystone";
            _forge.field = MER_FORGE_FIELD_SIGIL;
            mer_forge_say(_forge, "CLICK A NODE, DRAG BETWEEN TWO TO LINK THEM");
            return true;

        case 1:
            // ⚠️ THE ENDPOINT IS TAKEN FROM A REAL NODE, not from an offset. A hand-picked offset put
            // the dragged edge in empty space, and the shot read as a stray dash rather than as the
            // gesture — the whole point of this pose is that you drag BETWEEN TWO NODES, so the
            // other node has to be under the end of the line. Stopping just short of it keeps the
            // node's own mark readable underneath.
            _forge.selected = "might";
            _forge.linkFrom = "might";
            var _to = mer_tree_get(_tree, "mend");
            if (!is_undefined(_to)) {
                var _from = mer_tree_get(_tree, "might");
                var _pa = mer_view_to_screen(_forge.view, _from.lx, _from.ly, _cx, _cy);
                var _pb = mer_view_to_screen(_forge.view, _to.lx, _to.ly, _cx, _cy);
                var _d = max(1, point_distance(_pa.x, _pa.y, _pb.x, _pb.y));
                var _stop = max(0, (_d - 34)) / _d;      // stop short of the target node's rim
                _forge.linkToX = lerp(_pa.x, _pb.x, _stop);
                _forge.linkToY = lerp(_pa.y, _pb.y, _stop);
            }
            mer_forge_say(_forge, "DRAG BETWEEN TWO NODES TO MAKE ONE REQUIRE THE OTHER");
            return true;

        case 2:
            _forge.selected = "keystone";
            _forge.exportText = mer_forge_export_gml(_tree, "build_skill_tree");
            _forge.mode = MER_FORGE_MODE_EXPORT;
            return true;

        case 3:
            _forge.selected = "keystone";
            _forge.field = MER_FORGE_FIELD_SIGIL;
            mer_forge_say(_forge, "60 MOTIFS x 8 DISCIPLINES = " + string(mer_sigil_variant_count()) + " MARKS");
            return true;

        case 4:
            _forge.selected = "might";
            _forge.layout = 1;
            mer_layout_apply(_forge.layout, _tree);
            mer_forge_say(_forge, "LAYOUT: " + mer_layout_name(_forge.layout) + " - POSITIONS ARE DERIVED, NEVER TYPED");
            return true;

        case 5:
            // ⛔ THE CAPTION WAS A FALSEHOOD AND IS FIXED, not softened. It read "EVERY MARK
            // RE-COLOURS WITH THE THEME" — and the baked shot shows the marks keeping their red and
            // green, because a mark's colour comes from its DISCIPLINE and a theme restyles the
            // interface around it. Both behaviours are correct; the sentence was not, and it would
            // have been photographed onto a store page beside a picture disproving it.
            _forge.selected = "mend";
            _forge.field = MER_FORGE_FIELD_DISC;
            mer_forge_say(_forge, "FOUR THEMES RESTYLE THE INTERFACE - DISCIPLINE STILL COLOURS THE MARK");
            return true;
    }
    return false;
}

/// @func   mer_forge_film_step(_forge, _tree, _frame, _total, _cx, _cy)
/// @desc   One frame of a scripted authoring session, for the store GIF.
///
/// @remarks ⛔ THE GIF IS THE ONLY ASSET THAT CAN SHOW THE ACTUAL PRODUCT. Armature's whole claim is
///          that you wire a graph up and the layout re-derives in front of you — a claim about
///          MOTION, which a still image cannot make and a paragraph cannot prove. Every static shot
///          of an editor looks like every other static shot of an editor.
///
///          Scripted here rather than in the object so the sequence is data the suite can check:
///          a script that silently stopped performing its middle act would still produce a
///          perfectly valid GIF of a tree sitting still.
///
/// @param  {Struct} _forge  A session.
/// @param  {Struct} _tree   A tree.
/// @param  {Real}   _frame  Frame index, from 0.
/// @param  {Real}   _total  How many frames the film runs for.
/// @param  {Real}   _cx     Canvas centre x.
/// @param  {Real}   _cy     Canvas centre y.
/// @return {String} A short name for what this frame did, or "" for a frame that only advances time.
function mer_forge_film_step(_forge, _tree, _frame, _total, _cx, _cy) {
    // --- act one: reach out from one node toward another --------------------------------------
    if (_frame == 4) {
        _forge.selected = "might";
        _forge.linkFrom = "might";
        mer_forge_say(_forge, "DRAG BETWEEN TWO NODES TO LINK THEM");
        return "grab";
    }
    if (_frame > 4 && _frame < 22 && _forge.linkFrom != "") {
        // The endpoint travels from the source node to the target, so the GIF shows a hand moving
        // rather than a line that simply appears.
        var _from = mer_tree_get(_tree, "might");
        var _to = mer_tree_get(_tree, "mend");
        if (!is_undefined(_from) && !is_undefined(_to)) {
            var _pa = mer_view_to_screen(_forge.view, _from.lx, _from.ly, _cx, _cy);
            var _pb = mer_view_to_screen(_forge.view, _to.lx, _to.ly, _cx, _cy);
            var _k = mer_ease((_frame - 4) / 17, 2);
            _forge.linkToX = lerp(_pa.x, _pb.x, _k);
            _forge.linkToY = lerp(_pa.y, _pb.y, _k);
        }
        return "";
    }
    if (_frame == 22) {
        var _r = mer_forge_toggle_link(_tree, "might", "mend");
        _forge.linkFrom = "";
        _forge.linkToX = -1;
        _forge.linkToY = -1;
        mer_forge_say(_forge, string_upper(_r.reason) + " - THE LAYOUT RE-DERIVES ITSELF");
        mer_forge_touch(_forge, _tree);
        return "link";
    }

    // --- act two: add a node, and watch everything downstream move out of its way ---------------
    if (_frame == 36) {
        _forge.selected = "keystone";
        mer_forge_add(_forge, _tree, { name: "ASCENDANCE", requires: ["keystone"], disc: 2,
                                       sigil: mer_sigil_find("BLOOM"), tier: MER_TIER_MAJOR,
                                       cost: 2, maxRank: 1, desc: "Added live, in the editor." });
        mer_forge_say(_forge, "A - ADD A CHILD OF THE SELECTION");
        return "add";
    }

    // --- act three: walk the corpus, with the mark redrawing every frame -------------------------
    if (_frame >= 50 && _frame <= 62) {
        mer_forge_step_field(_tree, _forge.selected, MER_FORGE_FIELD_SIGIL, 1);
        if (_frame == 50) mer_forge_say(_forge, "ARROWS - STEP ALL " + string(mer_sigil_variant_count()) + " MARKS");
        return "motif";
    }

    // --- act four: the same graph as a different shape --------------------------------------------
    if (_frame == 70) {
        mer_forge_layout_cycle(_forge, _tree, 1);
        return "layout";
    }

    return "";
}

/// @func   mer_forge_film_acts()
/// @desc   The acts mer_forge_film_step performs, in order. The suite asserts every one fires.
/// @return {Array} Act names.
function mer_forge_film_acts() { return ["grab", "link", "add", "motif", "layout"]; }

// =================================================================================================
// DRAWING
// =================================================================================================

/// @func   mer_forge_draw(_forge, _tree, _x, _y, _w, _h)
/// @desc   Draws the authoring canvas: the tree, plus the edge currently being dragged.
/// @param  {Struct} _forge  A session.
/// @param  {Struct} _tree   A tree.
/// @param  {Real}   _x      Canvas left.
/// @param  {Real}   _y      Canvas top.
/// @param  {Real}   _w      Canvas width.
/// @param  {Real}   _h      Canvas height.
function mer_forge_draw(_forge, _tree, _x, _y, _w, _h) {
    var _t = mer_theme_get();
    var _v = _forge.view;

    // The tree, through the runtime renderer. Same lens as the game: what you author is what your
    // players see, because there is only one renderer.
    _v.selected = _forge.selected;
    mer_view_draw(_v, _tree, _forge.prog, _x, _y, _w, _h, false);

    var _cx = _x + _w * 0.5;
    var _cy = _y + _h * 0.5;

    // The edge under construction, drawn as a dashed reach from its origin to the pointer.
    if (_forge.linkFrom != "" && variable_struct_exists(_tree.byId, _forge.linkFrom)) {
        var _from = mer_tree_get(_tree, _forge.linkFrom);
        var _p = mer_view_to_screen(_v, _from.lx, _from.ly, _cx, _cy);
        // ⚠️ A capture cannot hold a mouse button down, so the endpoint is overridable. Without
        // this the "mid-drag" store shot would draw its edge to wherever the pointer happened to
        // be — usually 0,0 — and the screenshot would show a line into the corner of the window.
        var _mx = (_forge.linkToX >= 0) ? _forge.linkToX : clamp(mouse_x, _x, _x + _w);
        var _my = (_forge.linkToY >= 0) ? _forge.linkToY : clamp(mouse_y, _y, _y + _h);

        var _steps = 22;
        draw_set_colour(_t.accentAlt);
        for (var _i = 0; _i < _steps; _i += 2) {
            var _a0 = _i / _steps;
            var _a1 = min(1, (_i + 1) / _steps);
            draw_set_alpha(0.85);
            draw_line_width(lerp(_p.x, _mx, _a0), lerp(_p.y, _my, _a0),
                            lerp(_p.x, _mx, _a1), lerp(_p.y, _my, _a1), 2);
        }
        draw_set_alpha(1);
        mer_draw_arc(_p.x, _p.y, 15, 0, 360, _t.accentAlt, 0.9, 2, 36);
    }
}

/// @func   mer_forge_legend_keys()
/// @desc   The editor's key map, as data.
///
/// @remarks ⛔ ONE DECLARATION, READ BY BOTH THE LAYOUT AND THE RENDERER. The layout has to RESERVE
///          the legend's height and the renderer has to DRAW it, and when those were two facts —
///          a literal 7 in one place and an array literal in the other — they were one edit away
///          from disagreeing, at which point the space reserved is not the space used and the
///          prerequisite list walks into the legend again with every check still green. This is the
///          same law the shipped `mer_sigil_variant_count()` follows: derive the number from the
///          table, never restate it.
///
/// @return {Array} An array of [key, meaning] pairs.
function mer_forge_legend_keys() {
    return [
        ["CLICK",  "select"],
        ["DRAG",   "link / unlink"],
        ["A",      "add child"],
        ["DEL",    "delete node"],
        ["ARROWS", "field / value"],
        ["L",      "layout"],
        ["E",      "export GML"],
    ];
}

/// @func   mer_forge_inspector_layout(_tree, _id, _y, _h)
/// @desc   Where every block of the inspector sits, as numbers, before anything is drawn.
///
/// @remarks ⛔ THIS EXISTS BECAUSE THE FIRST VERSION DREW THE PREREQUISITE LIST STRAIGHT THROUGH THE
///          KEY LEGEND. The legend was pinned to a constant offset from the panel's bottom while the
///          list flowed down from above it, so any node with prerequisites printed its parents on
///          top of the word CLICK. Two hundred and two green assertions passed over it, because not
///          one of them draws a string — the same blindness that shipped gm-liege with its entire
///          text layer dead. It was found by baking a PNG and LOOKING at it.
///
///          The fix is not "move the legend down". It is to make the layout a VALUE, so the suite
///          can read the same numbers the renderer uses and assert that the blocks do not overlap
///          at any prerequisite count. A layout computed inline inside a draw call cannot be tested
///          by anything except a person looking at a picture, and a person looking at a picture is
///          exactly what this factory does not have.
///
/// @param  {Struct} _tree  A tree.
/// @param  {String} _id    The selected node id, or "".
/// @param  {Real}   _y     Panel top.
/// @param  {Real}   _h     Panel height.
/// @return {Struct} {pad, titleY, previewY, previewBox, nameY, idY, fieldsY, fieldRow, reqY,
///                   reqRows, reqHidden, reqBottom, legendY, legendH, ok}.
function mer_forge_inspector_layout(_tree, _id, _y, _h) {
    // ⚠️ THESE NUMBERS WERE MEASURED, NOT CHOSEN. The first set left the prerequisite list with
    // THREE pixels of room — reqBottom 512 against a legend starting at 511 — so zero rows fitted
    // and every node with a parent overflowed. The suite reported it as an arithmetic failure
    // instead of a picture, which is the entire reason the layout is a value. Every block below was
    // tightened until three rows fit with a real gap; changing any of them re-runs stage 21.
    var _pad = 18;
    var _legendRows = array_length(mer_forge_legend_keys());   // derived, never restated
    var _legendH = 16 + _legendRows * 14;
    var _legendY = _y + _h - _pad - _legendH;

    var _cur = _y + _pad;
    var _titleY = _cur;
    _cur += 24 + 26;                       // title, then the subtitle under it

    var _previewBox = 92;
    var _previewY = _cur + _previewBox * 0.5;
    _cur += _previewBox + 12;

    var _nameY = _cur;  _cur += 20;
    var _idY   = _cur;  _cur += 20;

    var _fieldsY = _cur;
    var _fieldRow = 28;
    _cur += MER_FORGE_FIELD_COUNT * _fieldRow + 10;

    var _reqY = _cur;
    var _rowH = 16;

    // How many prerequisite rows fit between the fields and the legend, leaving a real gap. A node
    // with more parents than that reports the overflow rather than drawing into the legend.
    var _gap = 12;
    var _avail = (_legendY - _gap) - (_reqY + 18);
    var _fits = max(0, floor(_avail / _rowH));

    var _want = 0;
    var _node = (_id == "") ? undefined : mer_tree_get(_tree, _id);
    if (!is_undefined(_node)) _want = max(1, array_length(_node.requires));   // "NOTHING" is one row

    var _rows = min(_want, _fits);
    var _hidden = max(0, _want - _rows);
    if (_hidden > 0 && _rows > 0) { _rows -= 1; _hidden += 1; }   // one row spent saying "+N MORE"

    var _reqBottom = _reqY + 18 + _rows * _rowH + (_hidden > 0 ? _rowH : 0);

    return {
        pad: _pad, titleY: _titleY,
        previewY: _previewY, previewBox: _previewBox,
        nameY: _nameY, idY: _idY,
        fieldsY: _fieldsY, fieldRow: _fieldRow,
        reqY: _reqY, reqRows: _rows, reqHidden: _hidden, reqRowH: _rowH, reqBottom: _reqBottom,
        legendY: _legendY, legendH: _legendH, legendRows: _legendRows,
        ok: (_reqBottom <= _legendY) && (_legendY + _legendH <= _y + _h),
    };
}

/// @func   mer_forge_draw_inspector(_forge, _tree, _x, _y, _w, _h)
/// @desc   The right-hand editing panel: the live mark, the fields, and the graph summary.
///
/// @remarks THE PREVIEW IS THE POINT OF THE PANEL. It is a real mer_sigil_draw at a large size, so
///          stepping the motif or the discipline redraws the actual generated artwork rather than a
///          thumbnail of it. There is nothing cached between the field and the picture.
///
/// @param  {Struct} _forge  A session.
/// @param  {Struct} _tree   A tree.
/// @param  {Real}   _x      Panel left.
/// @param  {Real}   _y      Panel top.
/// @param  {Real}   _w      Panel width.
/// @param  {Real}   _h      Panel height.
function mer_forge_draw_inspector(_forge, _tree, _x, _y, _w, _h) {
    var _t = mer_theme_get();
    mer_draw_panel(_x, _y, _w, _h, 1);

    var _node = (_forge.selected == "") ? undefined : mer_tree_get(_tree, _forge.selected);
    var _L = mer_forge_inspector_layout(_tree, _forge.selected, _y, _h);
    var _cx = _x + _w * 0.5;
    var _pad = _L.pad;

    mer_draw_text_centred(_cx, _L.titleY, "ARMATURE", 13, _t.accent, 1);
    mer_draw_text_centred(_cx, _L.titleY + 26, "THE AUTHORING LAYER", 8, _t.textDim, 1);

    if (is_undefined(_node)) {
        mer_draw_text_centred(_cx, _L.previewY, "NOTHING SELECTED", 10, _t.textDim, 1);
        mer_draw_text_centred(_cx, _L.previewY + 26, "CLICK A NODE", 8, _t.textDim, 0.75);
        mer_forge_draw_legend(_forge, _x + _pad, _L.legendY, _w - _pad * 2);
        return;
    }

    // --- the live generated mark ---------------------------------------------------------------
    var _box = min(_w - _pad * 2, _L.previewBox);
    mer_draw_arc(_cx, _L.previewY, _box * 0.46, 0, 360, _t.edge, _t.edgeAlpha, 1, 48);
    mer_sigil_draw(_node.sigil, _cx, _L.previewY, _box * 0.72, _node.disc, 1, 1.15, 0);

    mer_draw_text_centred(_cx, _L.nameY, _node.name, 12, _t.text, 1);
    mer_draw_text_centred(_cx, _L.idY, _node.id, 7, _t.textDim, 0.8);

    // --- the fields ----------------------------------------------------------------------------
    for (var _i = 0; _i < MER_FORGE_FIELD_COUNT; _i++) {
        var _sel = (_i == _forge.field);
        var _rowY = _L.fieldsY + _i * _L.fieldRow;

        if (_sel) {
            mer_draw_round_rect(_x + _pad - 6, _rowY - 6, _w - _pad * 2 + 12, 26,
                                _t.radiusSmall, _t.hover, 0.55);
            mer_draw_chevron(_x + _pad + 2, _rowY + 7, 5, 0, _t.accent, 1);
        }
        mer_draw_text(_x + _pad + 16, _rowY, mer_forge_field_name(_i), 8,
                      _sel ? _t.accentAlt : _t.textDim, 1);
        mer_draw_text_right(_x + _w - _pad, _rowY, mer_forge_field_value(_tree, _node.id, _i), 9,
                            _sel ? _t.text : _t.textDim, 1);
    }

    // --- prerequisites, bounded by the layout so they cannot reach the legend --------------------
    mer_draw_text(_x + _pad, _L.reqY, "REQUIRES", 8, _t.textDim, 1);
    var _rowY = _L.reqY + 18;

    if (array_length(_node.requires) == 0) {
        if (_L.reqRows > 0) mer_draw_text(_x + _pad + 8, _rowY, "NOTHING - THIS IS A ROOT", 7, _t.success, 0.9);
    } else {
        for (var _i = 0; _i < _L.reqRows; _i++) {
            var _rid = _node.requires[_i];
            var _known = variable_struct_exists(_tree.byId, _rid);
            mer_draw_text(_x + _pad + 8, _rowY + _i * _L.reqRowH, string(_rid), 7,
                          _known ? _t.text : _t.danger, _known ? 0.9 : 1);
        }
        // ⚠️ SAYS SO RATHER THAN TRUNCATING SILENTLY. A list that just stops is indistinguishable
        // from a node with fewer parents than it has, which is a lie about the buyer's own data.
        if (_L.reqHidden > 0) {
            mer_draw_text(_x + _pad + 8, _rowY + _L.reqRows * _L.reqRowH,
                          "+" + string(_L.reqHidden) + " MORE", 7, _t.warning, 0.9);
        }
    }

    mer_forge_draw_legend(_forge, _x + _pad, _L.legendY, _w - _pad * 2);
}

/// @func   mer_forge_draw_legend(_forge, _x, _y, _w)
/// @desc   The key map, drawn at the foot of the inspector.
/// @param  {Struct} _forge  A session.
/// @param  {Real}   _x      Left.
/// @param  {Real}   _y      Top.
/// @param  {Real}   _w      Width.
function mer_forge_draw_legend(_forge, _x, _y, _w) {
    var _t = mer_theme_get();
    var _keys = mer_forge_legend_keys();
    // ⚠️ The row pitch here MUST match mer_forge_inspector_layout's legendH, or the legend the test
    // reserves space for is a different size from the one that gets drawn.
    mer_draw_text(_x, _y, "KEYS", 8, _t.accent, 1);
    for (var _i = 0; _i < array_length(_keys); _i++) {
        var _rowY = _y + 16 + _i * 14;
        mer_draw_text(_x + 4, _rowY, _keys[_i][0], 7, _t.accentAlt, 0.95);
        mer_draw_text_right(_x + _w, _rowY, _keys[_i][1], 7, _t.textDim, 0.85);
    }
}

/// @func   mer_forge_export_code_size()
/// @desc   The cap height the export overlay renders code at.
///
/// @remarks A constant rather than a literal at each site because the panel is SIZED from a
///          measurement of the same text it later DRAWS. Master's green-lie catalogue records this
///          exact shape twice: two expressions for one value, where breaking the one that ships
///          leaves the other to certify it. One declaration means the measure and the draw cannot
///          disagree about what they are talking about.
///
/// @return {Real} Cap height in pixels.
function mer_forge_export_code_size() { return 7; }

/// @func   mer_forge_export_code_tracking()
/// @desc   The letter tracking the export overlay renders code at. See mer_forge_export_code_size.
/// @return {Real} Extra pixels between glyphs.
function mer_forge_export_code_tracking() { return 0.6; }

/// @func   mer_forge_export_panel_w(_lines, _maxW)
/// @desc   How wide the export panel has to be to hold its content without waste.
///
/// @remarks ⛔ THE HEIGHT OF THIS PANEL WAS ALREADY FIXED FOR EXACTLY THIS REASON AND THE WIDTH WAS
///          MISSED — the comment three lines below the old height calculation cites master's Gate 1
///          rule that a composite more than a fifth empty is a reject, and then set the width to the
///          whole window regardless of content. A 47-line export whose longest line is 85 characters
///          measured ~560px inside a 1,212px panel, so the store shot of the product's headline
///          feature was HALF EMPTY, and `visual_density.js` flagged it THIN. Sizing one axis to its
///          content and not the other is the "half a field" defect: the reasoning was right and it
///          was applied to one of the two places it holds.
///
///          ⚠️ THE FLOOR IS THE PANEL'S OWN HEADER ROW, NOT A ROUND NUMBER. "EXPORTED GML" is drawn
///          from the left and "E OR ESC TO CLOSE" from the right of the SAME row, so a panel narrow
///          enough to remove the dead space could remove the gap between them instead — fixing the
///          emptiness by creating a text collision, which is a defect this wing has shipped before
///          and found only by looking at a baked PNG. Deriving the floor from both strings means the
///          two can never overlap however short the exported code is.
///
///          Pure: takes the lines and a bound, calls no drawing, returns a number. That is what lets
///          the suite assert on it at all — a width computed inline inside a Draw event is only
///          checkable by baking a picture and looking at it.
///
/// @param  {Array<String>} _lines  The exported GML, already split into lines.
/// @param  {Real}          _maxW   The widest the panel may be (the window, less its margins).
/// @return {Real} The panel width in pixels.
function mer_forge_export_panel_w(_lines, _maxW) {
    var _size  = mer_forge_export_code_size();
    var _track = mer_forge_export_code_tracking();

    var _widest = 0;
    for (var _i = 0; _i < array_length(_lines); _i++) {
        _widest = max(_widest, mer_text_width(_lines[_i], _size, _track));
    }

    // 22px of padding each side, matching where the code and the header are actually drawn.
    var _content = _widest + 44;

    // The header row: title on the left, hint on the right, and a gap that has to survive.
    var _header = mer_text_width("EXPORTED GML", 12)
                + mer_text_width("E OR ESC TO CLOSE", 7)
                + 44 + 48;

    return clamp(max(_content, _header), 0, _maxW);
}

/// @func   mer_forge_draw_export(_forge, _x, _y, _w, _h)
/// @desc   The export overlay: the generated GML, scrollable, exactly as it will be written out.
///
/// @remarks Showing the real text rather than a "saved!" toast is the whole point. This wing has
///          shipped a listing whose entire public body was the word "undefined" because a value was
///          read back after a navigation and nothing ever LOOKED at it. An exporter that displays
///          its own output cannot fail that way silently.
///
/// @param  {Struct} _forge  A session.
/// @param  {Real}   _x      Left.
/// @param  {Real}   _y      Top.
/// @param  {Real}   _w      Width.
/// @param  {Real}   _h      Height.
function mer_forge_draw_export(_forge, _x, _y, _w, _h) {
    var _t = mer_theme_get();

    draw_set_alpha(0.82);
    draw_set_colour(_t.backdrop);
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);
    draw_set_alpha(1);

    var _pad = 34;
    var _py = _y + _pad;

    var _lines = string_split(_forge.exportText, chr(10));

    // ⚠️ THE PANEL IS SIZED TO ITS CONTENT ON BOTH AXES, capped at the window. A fixed full-height
    // panel showing a seventeen-line export was two thirds empty — which is not merely ugly:
    // master's Gate 1 puts a composite more than a fifth empty in the reject pile, and a store
    // screenshot of this screen is exactly such a composite. The WIDTH was missed when that was
    // written and is now derived the same way; see mer_forge_export_panel_w.
    var _maxH = _h - _pad * 2;
    var _need = 76 + array_length(_lines) * 13 + 16;
    var _ph = clamp(_need, 200, _maxH);

    var _pw = mer_forge_export_panel_w(_lines, _w - _pad * 2);
    // Centred, because a content-sized panel pinned to the left margin just moves the dead space to
    // the other side of the screen.
    var _px = _x + (_w - _pw) * 0.5;

    mer_draw_panel(_px, _py, _pw, _ph, 1);

    mer_draw_text(_px + 22, _py + 20, "EXPORTED GML", 12, _t.accent, 1);
    mer_draw_text_right(_px + _pw - 22, _py + 22, "E OR ESC TO CLOSE", 7, _t.textDim, 0.85);

    var _rows = floor((_ph - 76) / 13);
    var _first = clamp(_forge.exportLine, 0, max(0, array_length(_lines) - _rows));

    for (var _i = 0; _i < _rows; _i++) {
        var _index = _first + _i;
        if (_index >= array_length(_lines)) break;
        var _line = _lines[_index];
        // Comment lines dim, code lines bright: a wall of one colour is unreadable and the
        // distinction costs one branch.
        var _isComment = (string_copy(mer_forge_trim_left(_line), 1, 3) == "///");
        // ⚠️ SIZE AND TRACKING COME FROM THE SAME TWO FUNCTIONS mer_forge_export_panel_w MEASURES
        // WITH. Typed literals here would let the panel be sized for one typeface metric and drawn
        // at another, and the failure is silent: text simply runs past the edge it was fitted to.
        mer_draw_text(_px + 22, _py + 52 + _i * 13, _line, mer_forge_export_code_size(),
                      _isComment ? _t.textDim : _t.text, _isComment ? 0.7 : 0.95,
                      mer_forge_export_code_tracking());
    }

    mer_draw_text(_px + 22, _py + _ph - 22,
                  string(array_length(_lines)) + " LINES   " +
                  string(_first + 1) + "-" + string(min(array_length(_lines), _first + _rows)) +
                  "   UP/DOWN TO SCROLL", 7, _t.textDim, 0.8);
}

/// @func   mer_forge_trim_left(_s)
/// @desc   Drops leading spaces. Present because the export view classifies lines by their first
///         non-space characters.
///
/// @remarks ⛔ NAMESPACED, AND THE FIRST DRAFT OF THIS FILE WAS NOT. It was written as
///          `string_trim_left`, which is the exact defect this wing's packaging law names: GML's
///          global namespace is flat, so a plausibly-named helper shipped inside a package silently
///          redefines or collides with whatever the buyer already has under that name, in THEIR
///          project, where it cannot be debugged remotely. A generic name is the dangerous case
///          precisely because it is the one a buyer is also likely to have written.
///
/// @param  {String} _s  Any string.
/// @return {String} The string without leading spaces.
function mer_forge_trim_left(_s) {
    var _i = 1;
    var _n = string_length(_s);
    while (_i <= _n && string_char_at(_s, _i) == " ") _i += 1;
    return string_delete(_s, 1, _i - 1);
}
