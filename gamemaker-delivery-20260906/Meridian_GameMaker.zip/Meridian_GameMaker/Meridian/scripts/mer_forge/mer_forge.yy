{
  "$GMScript": "v1",
  "%Name": "mer_forge",
  "isCompatibility": false,
  "isDnD": false,
  "name": "mer_forge",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}
