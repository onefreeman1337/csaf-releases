# Meridian

**Procedurally-drawn constellation skill trees and a complete progression system for GameMaker.**

Sixty sigil motifs across eight discipline palettes — 480 distinct marks — generated from geometry
and colour maths at draw time. No PNG, no atlas, no texture page, no icon commission.

Built and tested against GameMaker **2024.14** (the current stable LTS-line runtime). Pure GML,
no extensions, no external dependencies.

> ### NEW IN 1.1 — **ARMATURE**, the authoring layer. Free update.
>
> Build the tree by hand instead of typing it. Open `rm_mer_forge` and press F5, or press **F** in
> the demo room. Add nodes, drag between two of them to make one require the other, step through
> all sixty motifs on the node you are looking at with the mark redrawing live, flip the whole
> screen between four layout engines — then press **E** and Armature writes the tree out as GML you
> paste straight into your game.
>
> The export carries a **motif index and a discipline index** per node, and nothing else about how
> the node looks, because Meridian draws every mark from geometry at run time. An exported tree is
> not a baked atlas that will go stale: it regenerates its own artwork in your game, at your theme,
> at any size.
>
> Armature edits the **graph**, never the canvas — it will not let you drag a node to an x,y
> position, because deriving the layout from the prerequisites is the whole argument of the
> package. See §9.

---

## 1. Install

1. In GameMaker: **Tools → Import Local Package**
2. Choose `Meridian.yymps`
3. **Add All**, then open `rm_mer_demo` and press **F5**.

That demo room is the quickstart. `obj_mer_demo`'s Create event is a complete worked example of
every part of the public API, in the order you would actually use it.

> **Two blocks in the demo are scaffolding and are marked as such in the source.** One drives the
> interface on its own when idle so an unattended screen recording has something to record; the
> other parses command-line arguments for reproducible screenshots. **Delete both.** If you copy
> the self-drive block into your game you will ship a skill tree that buys its own skills.

## 2. Five minutes to a working tree

```gml
// Create
tree = mer_tree_make();

mer_tree_add(tree, "edge",   { name: "EDGE",   sigil: "THRUST", disc: 0, tier: MER_TIER_MAJOR,
                               cost: 1, stat: "power", value: 4,
                               desc: "The first lesson." });
mer_tree_add(tree, "cleave", { name: "CLEAVE", disc: 0, maxRank: 3, requires: ["edge"],
                               stat: "power", value: 3 });
mer_tree_add(tree, "sunder", { name: "SUNDER", disc: 0, tier: MER_TIER_KEYSTONE, cost: 3,
                               requires: ["cleave"], stat: "pierce", value: 8 });

mer_layout_constellation(tree);          // or _branching / _radial / _grid
prog = mer_progress_make(6);             // six points to spend
view = mer_view_make(tree);
mer_view_frame_all(view, tree, 960, 600);
```

```gml
// Step
mer_view_update(view, tree, prog, mouse_x, mouse_y, 480, 300, delta_time / 1000000);
if (mouse_check_button_pressed(mb_left))  mer_view_click(view, tree, prog, true);
if (mouse_check_button_pressed(mb_right)) mer_progress_refund(tree, prog, view.hoveredId);
```

```gml
// Draw GUI
mer_view_draw(view, tree, prog, 0, 0, 960, 600);
mer_view_draw_detail(view, tree, prog, 980, 20, 280, 560);
```

Then ask the tree for what it is worth to your game:

```gml
var _power = mer_progress_stat(tree, prog, "power");   // summed across ranks
```

Your combat code never needs to know the tree exists.

**You never type a node position.** Declare what depends on what; the layout is derived. Insert a
node and everything downstream moves out of the way on its own.

## 3. What is in the box

| File | What it holds | Pure? |
| --- | --- | --- |
| `mer_ease.gml` | Easing curves, the spring integrator, stagger | **Yes — no engine calls** |
| `mer_theme.gml` | Six seed colours in, ~20 derived roles out. Four shipped themes | Yes |
| `mer_font.gml` | A 61-glyph vector stroke typeface, drawn not loaded | No (draws) |
| `mer_draw.gml` | Procedural primitives: rounded rects, gradients, glow, arcs, panels | No (draws) |
| `mer_sigil.gml` | **60 motifs, 8 disciplines, the symmetry operator, the renderer** | Table is data |
| `mer_tree.gml` | Nodes, prerequisite edges, four layout engines | **Yes** |
| `mer_progress.gml` | Points, ranks, gating, refunds, respec, stats, save/load | **Yes** |
| `mer_view.gml` | Pan/zoom, node frames, connectors, hover motion, detail panel | No (draws) |
| `mer_forge.gml` | **ARMATURE** — graph editing, validation, repair, GML and JSON export | Editing and export are pure |
| `mer_selftest.gml` | The package's own test suite, 214 assertions. See below | Yes |

Rooms: `rm_mer_demo` (the quickstart) and `rm_mer_forge` (Armature).

Everything is namespaced `mer_` / `MER_`. GML's global namespace is flat and shared with your code;
a collision would be a support ticket nobody can debug remotely. All 151 shipped functions carry the
prefix, and the package sets exactly five globals: `__mer_theme`, `__mer_sigils`,
`__mer_disciplines` and `__mer_font` — lazily built caches, all double-underscored — plus
`mer_stage`, which only the self-test writes.

**You can verify your own copy.** Build the project and run the exe with `-selftest`; it writes
`mer_selftest.json` into the game's save area with a pass/fail count. That is the same suite this
package is released against, and it ships inside it rather than being something you are asked to
take on trust.

## 4. Making it yours

**Retheme the whole thing in six lines.** A theme is six seed colours; every panel edge, gradient
stop, track, hover state and status colour is derived from them by colour maths.

```gml
mer_theme_set(mer_theme_make(
    make_colour_rgb( 26,  18,  36),   // backdrop
    make_colour_rgb( 40,  27,  62),   // surface
    make_colour_rgb(199, 125, 255),   // accent
    make_colour_rgb(233, 199, 255),   // accentAlt
    make_colour_rgb(242, 233, 255),   // text
    make_colour_rgb(154, 134, 184)    // textDim
));
```

Four themes ship (`violet`, `ember`, `terminal`, `frost`). Press **T** in the demo to cycle them.

> **Colours are declared with `make_colour_rgb`, never as `$` hex literals.** A GML hex literal is
> **BGR** — `c_blue` is `$FF0000` — so `$1A1224` is not the dark violet a web developer reads it as.
> The trap costs an hour and the result still looks plausible, which is what makes it dangerous.

**Add your own sigil.** Append one struct to the table in `mer_sigil.gml`:

```gml
_m("MYMARK", 1, 6, [                       // name, default discipline, 6-fold symmetry
    mer_gl(MER_ROLE_LIMB, 0.4, [0, -1.2, 0, -4.3]),
    mer_gd(MER_ROLE_CORE, 0, 0, 1.3),
]),
```

Coordinates run **-5 to +5 on a centred grid**. The symmetry count stamps the shape list that many
times around the origin — which is where the visual density comes from, and why most motifs here
are only three or four shapes.

## 5. The parts that are easy to get wrong, handled

**Refunds do not orphan dependants.** Handing back the last rank of a node whose children are
purchased would leave the player holding skills they no longer qualify for. `mer_progress_refund`
refuses, and `mer_progress_refundable` tells your UI in advance so the button can be greyed rather
than failing under the player's finger. Dropping rank 3 to rank 2 is always allowed, because the
node stays purchased.

**Respec is atomic.** It is deliberately not a loop over `mer_progress_refund` — that would refuse
most of the tree on the dependant check and leave the player half-respecced.

**Loading a save made by an older build is handled properly, and this is the part nobody writes
until it has already cost them a support thread.** You will rename a skill. You will cut one. You
will rebalance a max rank. When that save comes back:

```gml
var _report = {};
prog = mer_progress_deserialise(tree, _saved_json, _report);

if (array_length(_report.dropped) > 0 || array_length(_report.clamped) > 0) {
    show_message("Your skill tree changed in this update. "
               + string(_report.refunded) + " points have been returned.");
}
```

Points spent on a node that no longer exists, or on ranks above a reduced maximum, are **returned
to the pool and reported** — never silently swallowed. A corrupt or non-JSON payload yields a fresh
state rather than an exception. From the player's side the alternative is simply being four points
short with no explanation, which is the bug report you cannot reproduce.

**Concave polygons render correctly.** Filled shapes are ear-clipped, not drawn as a triangle fan.
A fan from vertex 0 is only correct for a polygon that is star-shaped about that vertex, and it
silently mangles anything else — which matters because this package invites you to author your own
marks.

**Prerequisite cycles are detected, not fatal.** `mer_tree_compute_depth` iterates to a fixed point
rather than recursing, reports a cycle to the debug log, and still produces a usable layout.

## 6. Performance

Everything is immediate-mode primitives — no surfaces, no shaders, no texture swaps. The demo draws
a 33-node tree with bloom, connector pulses and a 150-star parallax backdrop.

**This has not been benchmarked on other hardware and no frame-rate figure is claimed.** If you are
drawing a very large tree every frame, the cheap wins in order are: turn the bloom down
(`mer_sigil_draw`'s `_bloom` argument, or `theme.glowRings`), and skip nodes outside the viewport
before calling `mer_view_draw_node`.

## 7. Honest limitations

- **GML cannot be unit-tested OUTSIDE the engine**, so the tests run INSIDE it. `mer_selftest.gml`
  ships in this package and is run against the built executable: **214 assertions, 21 stages, 0
  failures** on runtime `2024.14.4.268`, over a copy installed into a blank project rather than over
  the folder it was written in. Run it yourself with `-selftest`.
  > Version 1.0 of this file said *"there is no automated behavioural test suite, because GameMaker
  > provides no way to run one."* The second half of that was wrong and the first half is no longer
  > true; both are corrected here rather than quietly deleted.
- ⚠️ **What the suite cannot see: it does not draw anything.** Every assertion computes a number or
  a string, so a defect that is purely visual is invisible to all 214 of them. Four such defects
  were found in Armature before release — including the prerequisite list printing through the key
  legend — and every one was found by rendering the screen to a PNG and looking at it, not by the
  suite. Where a check is a picture, it was checked by looking.
- **Windows was the compile target.** The code is plain GML with no platform-specific calls and
  should build anywhere GameMaker does, but only Windows has actually been run.
- **The `.yymps` payload is verified by extracting it into a blank project, merging the resource
  list the way the IDE does, compiling it and RUNNING it.** That proves the package is complete and
  self-contained — nothing works only because a file happens to sit in the folder it was authored
  in. It does not prove the IDE's import dialog accepts the manifest, since that path cannot be
  driven headlessly.
- Mouse input in the demo uses the GUI layer. If your game uses a different input abstraction, pass
  your own coordinates to `mer_view_update` — it takes them as arguments and reads no input itself.

## 8. ARMATURE — building the tree without typing it

Open `rm_mer_forge` and press F5, or press **F** in the demo room.

| | |
| --- | --- |
| **Click** | select a node |
| **Drag** from one node to another | make the second require the first. Drag again to remove it |
| **A** | add a child of the selection |
| **Del** | delete the selection, and every prerequisite pointing at it |
| **Arrows** | Up / Down choose a field, Left / Right change it |
| **L** | next layout engine, positions re-derived live |
| **T** | next theme · **V** validate · **N** new tree |
| **E** | export the tree as GML |

**It edits the graph, not the canvas.** Dragging never moves a node. Meridian derives every
position from the prerequisite graph, so an editor that let you place nodes by hand would be
reintroducing the forty pairs of coordinates the package exists to abolish. Wire the graph up and
watch the layout reflow; that is the feature, not a limitation of the editor.

**Stepping the MOTIF field walks all sixty marks, and DISCIPLINE re-palettes the current one across
all eight.** The 480 marks have always been in the package; until now there was no way to look
through them without editing source and rebuilding.

**What the export gives you**, from `mer_forge_export_gml`:

```gml
function build_skill_tree() {
    var _t = mer_tree_make();

    mer_tree_add(_t, "keystone", {   // RENEW / VITALITY
        name: "RESOLVE", sigil: 27, disc: 2, tier: MER_TIER_KEYSTONE,
        cost: 3, maxRank: 1, stat: "health", value: 25,
        requires: ["guard", "mend"],
        desc: "Survive a lethal blow once per encounter."
    });

    mer_layout_apply(0, _t);   // 0 constellation, 1 branching, 2 radial, 3 grid
    return _t;
}
```

`sigil: 27, disc: 2` is the node's entire artwork. There is no image reference because there is no
image — the mark is drawn from geometry when your game draws it.

**Validation is an actor, not a reporter.** `mer_forge_validate` finds the four faults that make a
tree misbehave at run time: a cycle (which stops the layout being derivable), a prerequisite naming
a node that is not in the tree (which makes its child permanently unbuyable), an out-of-range motif
or discipline, and a tree with no root. `mer_forge_repair` fixes the last three — and deliberately
does **not** touch cycles or rootlessness, because those have several equally valid repairs and
picking one silently would be the tool making a design decision on your behalf.

**Also available headlessly**, if you would rather script it than click it:
`mer_forge_add`, `mer_forge_remove`, `mer_forge_link`, `mer_forge_unlink`, `mer_forge_toggle_link`,
`mer_forge_validate`, `mer_forge_repair`, `mer_forge_export_gml`, `mer_forge_export_json`,
`mer_forge_import_json`. All pure, all engine-call free, all covered by the suite.

## 9. Support and licence

Licence: see `LICENSE.txt`. Use it in commercial and non-commercial games, modify it freely; do not
resell or redistribute the package itself.

Found a bug, or a sigil that does not read at your size? Say so on the itch.io page. A motif is a
few coordinates, and a fix is a patch release.

---

*Meridian is by CSAF. Every line of GML in this package is AI-written, disclosed on the store
listing, and raw and readable on purpose — you are a developer and you will need to extend it.*
