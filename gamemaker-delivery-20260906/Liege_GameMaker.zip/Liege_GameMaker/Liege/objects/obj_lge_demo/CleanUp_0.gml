/// obj_lge_demo — Clean Up.
///
/// ⚠️ THERE IS NOTHING TO FREE, AND THAT IS WORTH SAYING RATHER THAN LEAVING AN EMPTY EVENT.
///
/// Nothing in this room owns a surface, a sprite, a buffer or a data structure. Part lists are plain
/// GML arrays of plain structs and the garbage collector owns them; the palette is a struct of
/// integers; the town is a struct of structs. There is no atlas, no PNG and no texture page anywhere
/// in this package - which is the same fact the store copy sells and is why a theme change is one
/// call rather than a re-import.
///
/// ⛔ THE ONE THING THAT WOULD NEED FREEING IS `lge_render_to_sprite`, WHICH THIS ROOM DELIBERATELY
/// DOES NOT USE. Its own header says the caller owns the sprite and must `sprite_delete` it, and it
/// crashed on its first ever call in the donor product precisely because nothing exercised it. A
/// buyer following the Readme's crowd advice reaches it; this event is where their delete goes, and
/// the comment is here so the place is obvious rather than inferred.
///
/// ⚠️ AND `lge_lamp_reset` IS NOT CALLED HERE EITHER, ON PURPOSE. The lamp is global state that
/// `lge_figure_parts` sets and resets around every mirrored figure, on every exit path including the
/// early ones. If it ever needed a reset at room end, that would mean a path leaks it - so an
/// insurance call here would hide exactly the defect the suite's lamp assertion exists to catch.
