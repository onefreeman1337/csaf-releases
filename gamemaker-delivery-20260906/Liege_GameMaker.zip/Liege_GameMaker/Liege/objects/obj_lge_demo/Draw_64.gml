/// obj_lge_demo — Draw GUI. The street, then the caption.
///
/// ⚠️ DRAWN IN THE GUI LAYER AND PANNED BY HAND rather than moved with a camera. Not a
/// recommendation - a buyer should use a camera - but this room has to be a self-contained smoke
/// test, and a demo that also configures a view is a demo where a view misconfiguration looks like a
/// package defect. `lge_render_work` takes screen coordinates either way.

var _w = display_get_gui_width();
var _h = display_get_gui_height();

/// ============================================================================================
/// THE BACKDROP — and the reason the sky is in the palette at all
/// ============================================================================================
///
/// ⭐ THE LIGHT IS THE HALF OF "THE DAY" THAT A SCHEDULE CANNOT SHOW ON ITS OWN. Twelve people
/// changing station across twenty-four hours under one flat noon tells a player the day is a lookup
/// table. `lge_daylight` is continuous and wrapped, so dawn arrives as a warm low light, noon is
/// neutral and bright, dusk pulls orange and 02:00 is a real blue shift rather than the same picture
/// dimmed.
lge_render_vgrad(0, 0, _w, ground_y, pal.sky, merge_colour(pal.sky, pal.ground, 0.62));
draw_set_colour(pal.ground);
draw_rectangle(0, ground_y, _w, _h, false);
/// The far edge of the road, so the ground is a surface and not a colour.
draw_set_colour(pal.shade);
draw_set_alpha(0.30);
draw_rectangle(0, ground_y, _w, ground_y + 3, false);
draw_set_alpha(1);

/// ============================================================================================
/// THE PAN
/// ============================================================================================

var _pan = 0;
if (follow >= 0 && follow < array_length(town.people)) {
    var _fat = lge_where(town, town.people[follow], hour);
    _pan = _fat.x - _w * 0.5;
} else {
    // The whole street, centred. `town.width` is what `lge_town_make` laid out, so the demo never
    // has to know how wide twelve stations are.
    _pan = town.width * 0.5 - _w * 0.5;
}

/// ============================================================================================
/// THE STREET
/// ============================================================================================
///
/// ⛔ DRAWN BACK TO FRONT BY THE PLACE'S OWN y, because `lge_town_make` gives every station a
/// shallow depth offset and a street drawn in list order has a near stall painted behind a far one.
/// Sorted by insertion into an index array rather than by sorting the town itself: the town is the
/// buyer's data and a renderer that reorders it would change `lge_town_place_of`'s answers.
var _order = [];
for (var _i = 0; _i < array_length(town.places); _i++) array_push(_order, _i);
for (var _i = 1; _i < array_length(_order); _i++) {
    var _j = _i;
    while (_j > 0 && town.places[_order[_j - 1]].y > town.places[_order[_j]].y) {
        var _tmp = _order[_j - 1]; _order[_j - 1] = _order[_j]; _order[_j] = _tmp;
        _j--;
    }
}

for (var _k = 0; _k < array_length(_order); _k++) {
    var _ix = _order[_k];
    var _pl = town.places[_ix];
    var _sx = _pl.x - _pan;
    var _gy = ground_y + _pl.y;
    if (_sx < -stature * 2 || _sx > _w + stature * 2) continue;

    // Who, if anyone, is at this place right now.
    var _fig = undefined;
    var _fx = _sx;
    for (var _p = 0; _p < array_length(town.people); _p++) {
        var _at = lge_where(town, town.people[_p], hour);
        if (!_at.visible || _at.work != _pl.work) continue;
        _fig = lge_figure_parts(town.people[_p], _at.work, _at.phase, _at.moving, _at.face);
        _fx = _at.x - _pan;
        // ⚠️ A WALKING FIGURE IS DRAWN WITHOUT ITS STATION'S FRONT HALF OVER IT. Somebody crossing
        // the street in front of a well must not be painted behind the well's near rim - the depth
        // split is a fact about a worker STANDING at a prop, and a passer-by is not one.
        if (_at.moving) {
            lge_render_work(pal, undefined, _fig, _sx, _gy, _fx, stature);
            _fig = undefined;
        }
        break;
    }
    if (is_undefined(_fig)) {
        lge_render_work(pal, town.cache[_ix], { back: [], main: [] }, _sx, _gy, _sx, stature);
    } else {
        lge_render_work(pal, town.cache[_ix], _fig, _sx, _gy, _fx, stature);
    }
}

/// ============================================================================================
/// THE CAPTION
/// ============================================================================================

if (!show_hud) exit;

var _c = lge_town_census(town, hour);
var _hh = floor(hour);
var _mm = floor((hour - _hh) * 60);
var _clock = string_replace(string_format(_hh, 2, 0), " ", "0") + ":"
           + string_replace(string_format(_mm, 2, 0), " ", "0");

draw_set_colour(pal.shade);
draw_set_alpha(0.72);
draw_rectangle(0, 0, _w, 76, false);
draw_rectangle(0, _h - 34, _w, _h, false);
draw_set_alpha(1);

lge_text_fit("LIEGE  " + _clock, 18, 10, 460, 34, pal.stn0, pal.cnv4);

/// ⚠️ THE CAPTION STATES A COUNT THE ROOM CAN BE CHECKED AGAINST, not an adjective. This wing has a
/// standing law that a caption naming something the image is not drawing is a market claim, and the
/// cheapest way to obey it is to print a number the viewer can count.
lge_text_line(string(_c.working) + " at work   |   " + string(_c.walking) + " walking   |   "
            + string(_c.away) + " indoors   |   theme " + themes[theme_ix]
            + "   |   x" + string_format(hours_per_s, 1, 2) + " hours/sec",
            18, 50, _w - 36, 17, pal.cnv3, false);

if (test_result != "") lge_text_line(test_result, 18, _h - 56, _w - 36, 17, pal.cnv4, true);

lge_text_line("SPACE pause the PEOPLE (the clock keeps running)   |   LEFT/RIGHT scrub   |   "
            + "UP/DOWN speed   |   ENTER stop   |   TAB follow   |   T theme   |   R new town   |   "
            + "F1 self-test   |   F2 caption",
            18, _h - 26, _w - 36, 15, pal.cnv3, false);
