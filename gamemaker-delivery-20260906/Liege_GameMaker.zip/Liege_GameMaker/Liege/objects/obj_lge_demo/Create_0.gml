/// ============================================================================================
/// LIEGE — THE DEMO ROOM
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// ⭐ THIS ROOM IS THE QUICKSTART, THE STORE GIF AND THE ONLY REAL SMOKE TEST THIS ENGINE ALLOWS,
/// ALL AT ONCE. GML cannot be unit-tested outside the engine, so a runnable room is not a courtesy
/// here - it is the difference between a package that has been run and one that has only compiled.
///
/// ⛔ AND IT IS WRITTEN THE WAY A BUYER WOULD WRITE IT, NOT THE WAY A DEMO USUALLY IS. Every call
/// below is public API from the shipped scripts; there is no private hook, no debug-only branch and
/// nothing that would stop working if this object were deleted. If a step here needs something the
/// Readme does not document, that is a defect in the package rather than a note for the demo.
///
/// The whole integration is these four lines:
///
///     town = lge_town_populate(lge_town_make(seed, theme, stature_px, works), undefined);
///     ...
///     var _at = lge_where(town, person, hour);
///     lge_render_work(pal, station_parts, lge_figure_parts(person, _at.work, _at.phase,
///                                                          _at.moving, _at.face),
///                     station_x, ground_y, _at.x, stature_px);
///
/// ============================================================================================

/// ============================================================================================
/// ⛔⛔ THE CRASH HANDLER IS THE FIRST LINE OF THIS EVENT, AND IT IS NOT DEFENSIVE PROGRAMMING.
/// ============================================================================================
///
/// A GML runtime error opens a MODAL DIALOG. Run headless by `Internal_Ops/run_selftest.ps1` there is
/// nobody to dismiss it, so the process does not fail - it HANGS, forever, and the runner's only
/// signal is a timeout that says nothing about where or why. Turning that into a file naming a stage
/// number is the difference between a diagnosable failure and a wedged build machine.
///
/// ⚠️ IT MUST BE INSTALLED BEFORE ANY OTHER LINE RUNS. Everything below it can throw.
global.lge_stage = 0;
exception_unhandled_handler(function(_ex) {
    // ⛔⛔ THE HANDLER READS ITS ARGUMENT DEFENSIVELY, AND THAT IS NOT PARANOIA. If anything in here
    // throws, GameMaker falls back to its OWN fatal dialog - and headless, minimized, with no window
    // title yet, that dialog is invisible: the process sits alive, Responding, using no CPU, writing
    // nothing, forever. A crash handler that can itself crash converts a diagnosable failure into an
    // undiagnosable hang, which is strictly worse than having no handler at all.
    //
    // MEASURED 2026-09-03: two runs sat 13+ minutes on 4.5 SECONDS of CPU between them, with no
    // result file, no crash file, no window and no dialog anywhere on the desktop. `longMessage` is
    // not guaranteed on every exception struct, and reading it was one of exactly two things in this
    // event that could throw.
    var _msg = "(no message)";
    var _lng = "(no longMessage)";
    try { if (variable_struct_exists(_ex, "message")) _msg = string(_ex.message); } catch (_e) {}
    try { if (variable_struct_exists(_ex, "longMessage")) _lng = string(_ex.longMessage); } catch (_e) {}
    var _f = file_text_open_write("lge_crash.json");
    file_text_write_string(_f, "{\"stage\":" + string(global.lge_stage)
        + ",\"message\":\"" + string_replace_all(_msg, "\"", "'") + "\""
        + ",\"line\":\"" + string_replace_all(_lng, "\"", "'") + "\"}");
    file_text_close(_f);
    game_end(3);
});

/// ⛔ THE HEADLESS MODES COME NEXT, BEFORE ANY TOWN IS BUILT. A `-selftest` run that first
/// constructed a demo town would be testing the demo's setup as well as the package, and a failure
/// there would be reported as a suite failure.
///
/// ⚠️ `game_end()` DOES NOT PROPAGATE ITS ARGUMENT to the process exit code - measured in this wing -
/// so the exit code of these branches means nothing and the RESULT FILE means everything. The runner
/// script clears the file before launching and reads only one written after the launch timestamp,
/// because a stale result read as a fresh one is the worst outcome available here.
var _args = "";
for (var _ai = 0; _ai < parameter_count(); _ai++) _args += parameter_string(_ai + 1) + " ";

if (string_pos("-selftest", _args) > 0) {
    var _res = lge_selftest_run();
    lge_selftest_write(_res);
    game_end(_res.fail > 0 ? 1 : 0);
    exit;
}

if (string_pos("-bake", _args) > 0) {
    global.lge_stage = 200;
    lge_bake_store();
    game_end(0);
    exit;
}

randomise();   // ⚠️ ONLY to pick a seed on startup, so pressing R shows a different town. Nothing in
               // the package itself ever calls random() - every prop, every dye and every build comes
               // from a seeded stream, which is why a town looks the same on every buyer's machine.

/// ============================================================================================
/// WHICH TRADES ARE ON THE STREET
/// ============================================================================================
///
/// ⚠️ A SUBSET, AND THE SUBSET IS THE POINT OF THE DEMO. All forty-six loops laid out at once make a
/// street four thousand pixels wide, which reads as a spreadsheet. Twelve at a legible size shows
/// what the product does; the store sheet "the work loops" shows how many there are.
///
/// Chosen so the street changes VISIBLY across the day: the baker starts at 04:30 and is gone by
/// 08:00, the watch stands all night, the children appear after ten, and the reaper is out at 05:30.
demo_works = [
    "baker_peel", "smith_strike", "sawyer_saw", "weaver_shuttle",
    "monger_call", "waterward_draw", "potter_wheel", "reaper_scythe",
    "child_hoop", "elder_sit", "watch_stand", "scribe_write"
];

demo_seed = irandom(99999);
theme_ix  = 0;
themes    = lge_themes_all();

/// One stature, in pixels. The street is laid out in these units by `lge_town_make`.
stature = 132;

hour        = 6.0;
hours_per_s = 0.55;        // town hours per real second: a full day in about 44 seconds
running     = true;
follow      = -1;          // which person the camera is locked to, or -1 for the whole street
show_hud    = true;
test_result = "";

/// ⚠️ THE PALETTE IS CACHED AND REBUILT ONLY WHEN THE HOUR HAS MOVED. `lge_pal` resolves about 170
/// colours through a gamut-reduction loop; that is cheap once a frame and wasteful once a prop, and
/// its own header says so.
pal_hour = -99;
pal      = lge_pal(themes[theme_ix], hour);

/// ============================================================================================
/// THE TOWN
/// ============================================================================================

/// ⛔ THE STATION PART LISTS ARE BUILT ONCE, HERE, AND THE FIGURES ARE NOT. A station never changes -
/// same id, same seed, same prop forever - so rebuilding one every frame is pure waste. A figure's
/// pose is a continuous function of phase and MUST be rebuilt. That asymmetry is the whole
/// performance story of this package and it is why `lge_station_parts` takes a seed rather than
/// reading a clock.
function lge_demo_build(_seed, _theme) {
    var _t = lge_town_populate(lge_town_make(_seed, _theme, stature, demo_works), undefined);
    _t.cache = [];
    for (var _i = 0; _i < array_length(_t.places); _i++) {
        var _p = _t.places[_i];
        array_push(_t.cache, lge_station_parts(_p.station, _p.seed));
    }
    return _t;
}

town = lge_demo_build(demo_seed, themes[theme_ix]);

/// The ground line, in pixels. Everything - props and people - sits on this one number, because
/// `lge_geom`'s header records that the two previous products in this line each carried a separate
/// ground constant and that a station standing on a different floor from its worker is the defect a
/// second constant produces.
ground_y = room_height * 0.78;
