/// obj_lge_demo — Step. The clock, and the controls that demonstrate the spine.
///
/// ⭐ EVERY CONTROL HERE EXISTS TO SHOW A CLAIM RATHER THAN TO BE A CONTROL. Scrubbing the clock
/// backwards is only possible because position is SOLVED from the routine; pausing and resuming is
/// the incumbent's "interaction pauses corrupt movement" answered live; and pressing R rebuilds the
/// whole town from a new seed with no reload, which is what a generator means.

var _dt = delta_time / 1000000;

if (running) hour = lge_wrap(hour + hours_per_s * _dt);

/// SPACE — pause every townsperson where they stand.
///
/// ⛔ IT PAUSES THE PEOPLE, NOT THE CLOCK, AND THAT IS THE DEMONSTRATION. The world clock keeps
/// running (watch the hour in the corner) while every routine's time ORIGIN is frozen, so when the
/// pause is released nobody has drifted, nobody has to catch up, and nobody re-rolls. Freezing the
/// clock instead would prove nothing at all.
if (keyboard_check_pressed(vk_space)) {
    for (var _i = 0; _i < array_length(town.people); _i++) {
        var _r = town.people[_i].routine;
        if (_r.paused) lge_routine_resume(_r, hour);
        else lge_routine_pause(_r, hour);
    }
}

/// LEFT / RIGHT — scrub the clock. Free, because there is no integrator to unwind.
if (keyboard_check(vk_right)) hour = lge_wrap(hour + 6 * _dt);
if (keyboard_check(vk_left))  hour = lge_wrap(hour - 6 * _dt);

/// UP / DOWN — the speed of the day.
if (keyboard_check_pressed(vk_up))   hours_per_s = min(6.0, hours_per_s * 1.6);
if (keyboard_check_pressed(vk_down)) hours_per_s = max(0.05, hours_per_s / 1.6);
if (keyboard_check_pressed(vk_enter)) running = !running;

/// T — the theme layer. One struct re-colours every prop, every garment and the light.
if (keyboard_check_pressed(ord("T"))) {
    theme_ix = (theme_ix + 1) mod array_length(themes);
    pal_hour = -99;
    town = lge_demo_build(demo_seed, themes[theme_ix]);
}

/// R — a new town from a new seed.
if (keyboard_check_pressed(ord("R"))) {
    demo_seed = irandom(99999);
    town = lge_demo_build(demo_seed, themes[theme_ix]);
}

/// TAB — follow one person through their whole day. The clearest way to see that a routine is a day
/// and not a loop: the same figure walks, works, moves to the well, and goes indoors at night.
if (keyboard_check_pressed(vk_tab)) {
    follow = (follow + 2 > array_length(town.people)) ? -1 : (follow + 1);
}

if (keyboard_check_pressed(vk_f2)) show_hud = !show_hud;

/// F1 — the in-engine suite, from the demo room.
///
/// ⛔ IT CALLS `lge_selftest()` AND DOES NOT NAME ANY SUITE. This wing's constitution records what a
/// second runner with its own shorter list costs: it prints a true statement about a third of the
/// gates that is indistinguishable from a true statement about all of them. There is one runner in
/// this package and every other entry point delegates to it.
if (keyboard_check_pressed(vk_f1)) {
    var _r2 = lge_selftest();
    test_result = "self-test: " + string(_r2.pass) + " passed, " + string(_r2.fail) + " failed";
    if (_r2.fail > 0) test_result += "  |  first: " + _r2.notes[0];
}

/// The palette follows the hour. Rebuilt on a step rather than continuously: at 132 discrete steps
/// across the day the light moves smoothly to the eye and the cost is 132 builds instead of one per
/// frame. ⚠️ The threshold is a rendering decision, not a schedule one - `lge_daylight` itself is
/// continuous and a buyer wanting per-frame light just calls `lge_pal` every frame.
if (abs(hour - pal_hour) > LGE_DAY / 132) {
    pal_hour = hour;
    pal = lge_pal(themes[theme_ix], hour);
}
