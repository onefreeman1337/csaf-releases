/// ============================================================================================
/// LIEGE — WORKWEAR
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// ⛔⛔ THIS FILE EXISTS BECAUSE WITHOUT IT EVERY TOWNSPERSON IN THIS PRODUCT IS NAKED, AND THAT WAS
/// FOUND BY READING THE PORTED ARMATURE'S OWN HEADER RATHER THAN BY ANY TEST.
///
/// `lge_armature` says of itself: "THIS IS A SUBSTRATE, NOT A CHARACTER ... it exists so a garment has
/// something to hang on", and the function the whole file is built around - `lge_body_halfwidth` -
/// exists solely so that something worn can sample the body's width at its own height. In the donor
/// product that something was a fourteen-item wardrobe system. Liege ported the substrate and not the
/// thing it is a substrate FOR.
///
/// ============================================================================================
/// ⛔ AND IT IS NOT A WARDROBE. THE SCOPE IS FIXED HERE SO IT CANNOT DRIFT INTO ONE.
/// ============================================================================================
///
///   ships                                    does not ship
///   ONE worn set per trade, chosen BY        a wardrobe the buyer browses
///   the work loop                            14 item families, layer bands, materials
///   smock / sleeve / apron / belt / cap      dyes, wear states, trims, fasteners
///   colour from the trade's own dye          per-loop outfit structs
///
/// ⭐ THE TEST THAT KEEPS IT HONEST, and it is mechanical rather than a promise: A TRADE'S CLOTHING
/// MUST BE DERIVABLE FROM THE TRADE WITH NO EXTRA AUTHORING. There is no outfit table in this file.
/// Every slot is a function of three things the corpus already declares somewhere else:
///
///   the station's MATERIAL   -> `lge_mat_hazard`  -> whether an apron and a cap are worn
///   the labour's STANCE      ->                      whether the smock is long or short
///   the labour's HEIGHT      ->                      whether the head is covered
///
/// The moment a work loop needs its own garment struct, this has become a wardrobe and the volume has
/// left the work loops - which is where the product's value is. `Internal_Ops/wear_probe.js` asserts
/// the absence of such a table, so the drift is caught rather than noticed.
///
/// ⚠️ THE CONSEQUENCE IS THAT SOME TRADES DRESS ALIKE, AND THAT IS CORRECT. A joiner and a cooper both
/// work timber standing up, so they wear the same thing in different dyes - which is what actual
/// trades do. The distinctness this product claims is in the POSE, the PROP and the TOOL, all three of
/// which carry their own measured distinctness check; claiming it in the clothing as well would be a
/// claim the derivation cannot support.
///
/// ============================================================================================

/// How far a garment stands off the body, as a fraction of stature. Cloth does not lie on skin.
///
/// ⚠️ IT IS NOT UNIFORM DOWN THE FIGURE. A garment is pulled tight across the shoulders and hangs
/// free at the hem, so the ease GROWS downward - a constant offset produces a shrink-wrapped tube,
/// which is the single most reliable way to make a clothed generated figure look like a painted one.
#macro LGE_EASE_TOP 0.006
#macro LGE_EASE_HEM 0.026

/// Where a cap's lower edge crosses the skull, in head radii from the head's CENTRE, negative up.
///
/// ⛔ IT IS A LAW ABOUT THE FACE, NOT A LOOK. `lge_face_parts` puts the top of the brow at
/// -0.225r (see `lge_face_brow_top`, which derives it rather than restating it), so any cap edge
/// below that erases the brows on every figure wearing one - which is what shipped, and what made
/// three baked galleries of capped workers read as blank ovals. The suite asserts
/// `LGE_CAP_BRIM < lge_face_brow_top`, so this number cannot drift back down without going red.
///
/// ⚠️ AND IT IS BOUNDED FROM ABOVE TOO: a cap tangent to the crown (-1.0) reads as a bowl balanced
/// on the head. This sits between the two, nearer the brow, because the clearance a face needs is
/// small and the bowl failure starts a long way up.
#macro LGE_CAP_BRIM (-0.32)

/// ============================================================================================
/// THE DERIVATION
/// ============================================================================================

/// @desc What a trade wears. Derived from the work loop; there is no table.
///
/// @param {String} _work_id  from lge_works_all()
/// @returns {Struct|Undefined} {dye, hem, sleeve, apron, apron_bib, belt, cap} or undefined
function lge_wear_spec(_work_id) {
    var _w = lge_work_spec(_work_id);
    if (is_undefined(_w)) return undefined;
    if (!_w.visible) return undefined;
    var _st = lge_station_spec(_w.station);
    var _lb = lge_labour_spec(_w.labour);
    if (is_undefined(_st) || is_undefined(_lb)) return undefined;

    var _hz = lge_mat_hazard(_st.mat);
    var _seated = (_lb.stance == "seated" || _lb.stance == "kneel");

    return {
        // The dye wheel index, hashed off the loop id so it is stable for the life of the product.
        dye : lge_dye_of(_work_id),

        // HOW LONG THE SMOCK IS. A standing worker's hangs; measured from the shoulder as a fraction
        // of the body's own shoulder-to-sole length, so it follows the build rather than being a
        // fixed height.
        hem : _seated ? 0.62 : 0.80,

        // ⛔⛔ AND FOR A FOLDED LEG THE HEM IS PLACED AGAINST THE KNEE, NOT AGAINST A FRACTION. This
        // line used to be a COMMENT - "a seated or kneeling worker's smock is caught up over the
        // knees" - and the code under it was a fraction that happened to land near a STANDING knee.
        // It was true by coincidence and stopped being true the moment the seated figures were solved
        // into actually sitting down: 0.62 of a folded body's length is most of the way to the floor,
        // and the re-bake came back with the elder, the weaver and the tailor in full-length robes
        // with no knees, no shins and no feet. MEASURED 2026-09-03 by looking at the crops.
        //
        // ⭐ THE POSE IS THE PRODUCT. A cell whose whole job is to show that this loop's pose differs
        // from the other 45 cannot hide the pose under a bell of cloth - and a working woman hitching
        // her skirt to sit at a loom is what the comment always described. `lge_wear_smock_parts`
        // reads this and places the hem against the higher KNEE, which is a landmark the armature
        // publishes, so the hem cannot drift out of step with the leg it is cut around.
        hem_knee : _seated,

        // SLEEVES. A fire or metal trade rolls them back - a hanging sleeve near a forge is how a
        // smith loses an arm, and it is also the single most legible silhouette difference between
        // a smith and a scribe.
        sleeve : (_hz >= 0.70) ? "short" : "long",

        // THE APRON, and the bib. Dust and shavings need a waist apron; sparks, hot metal and wet
        // clay need one that comes up over the chest.
        apron     : (_hz >= 0.55),
        apron_bib : (_hz >= 0.90),

        // A BELT. A long smock has to be gathered or it cannot be worked in; a short one does not
        // need one. Derived from the hem rather than declared, so the two cannot disagree.
        belt : !_seated,

        // A CAP. A fire trade covers its hair; a trade working at ground level has the sun and the
        // dust on the back of its neck all day. `height` >= 0.72 is stooped work - the corpus's
        // reapers, diggers, shearers and washers.
        cap : (_hz >= 0.90) || (_lb.height >= 0.72)
    };
}

/// @desc The role map that puts a garment in a trade's own dye.
function lge_dye_map(_dye) {
    var _p = "dy" + string(_dye) + "_";
    return { m0: _p + "0", m1: _p + "1", m2: _p + "2", m3: _p + "3", m4: _p + "4", ink: _p + "ink" };
}

/// ============================================================================================
/// THE GARMENTS
/// ============================================================================================

/// @desc A hanging panel: sampled down the body between two heights, with ease that grows downward.
///
/// ⛔ SAMPLED, NEVER A TRAPEZIUM BETWEEN TWO WIDTHS. `lge_body_halfwidth` is piecewise across the
/// shoulder, waist, hip and leg bands, and a two-point panel would cut the corner at every one of
/// them - so the garment would be narrower than the body at the waist on a heavy build and wider at
/// the hip on a slight one. Sampling is what makes "change the build and the clothes follow" true
/// rather than approximately true.
///
/// ⭐ IT RETURNS THE TWO RAILS, AND `lge_wear_panel_pts` IS A READER OF IT RATHER THAN A SECOND
/// COPY. A garment is a TUBE - it wraps a body - so the thing that shades it correctly is
/// `lge_tube_bands`, which needs the left and right rails, not an outline. Building the outline
/// from the rails and the shading from the same rails means the light and the silhouette cannot
/// disagree, which is the failure mode this wing already paid for on the torso.
///
/// ⚠️ THE EASE IS PASSED IN RATHER THAN SPANNING TOP-TO-HEM INSIDE THE LOOP, because a garment is
/// now built from TWO calls (a yoke and a body) and a loop that ran the whole ease range inside
/// each of them would put hem-ease across the shoulders. The ease is a property of the position on
/// the GARMENT, not on the segment.
///
/// @param {Struct} _arm
/// @param {Real} _y0  top height, unit space
/// @param {Real} _y1  hem height
/// @param {Real} _k   width multiplier: 1.0 hangs on the body, <1 is a narrower apron panel
/// @param {Real} _n   samples
/// @param {Real} _e0  ease at _y0
/// @param {Real} _e1  ease at _y1
/// @returns {Struct} {l, r} rails, both _n+1 long, top to bottom
function lge_wear_panel_rails(_arm, _y0, _y1, _k, _n, _e0, _e1) {
    var _l = array_create(_n + 1);
    var _r = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        var _y = lerp(_y0, _y1, _t);
        var _hw = lge_body_halfwidth(_arm, _y);
        // ⚠️ THE FLOOR MATTERS AT THE TOP. lge_body_halfwidth returns 0 ABOVE the shoulder line, and
        // a panel whose first sample lands a hair above it would pinch to a point - a collar drawn as
        // a spike. The armature's own header records the shoulder-cap version of this defect.
        var _w = max(_arm.w_limb * 0.55, _hw * _k) + lerp(_e0, _e1, _t);
        // ⛔ THE PANEL LEANS WITH THE BODY IT IS WORN ON. Every worn panel in the product is built
        // here - smock, apron, everything - and until 2026-09-03 they were all symmetric about x = 0
        // with no lean term at all, so on a leaning pose the visible torso stood bolt upright while
        // the head and arms translated off it. See `lge_lean_at`'s header for the receipt.
        var _lx = lge_lean_at(_arm, _y);
        _l[_i] = [_lx - _w, _y];
        _r[_i] = [_lx + _w, _y];
    }
    return { l: _l, r: _r };
}

/// @desc The closed outline of a hanging panel. A reader of `lge_wear_panel_rails`.
///
/// @param {Struct} _arm
/// @param {Real} _y0  top height, unit space
/// @param {Real} _y1  hem height
/// @param {Real} _k   width multiplier: 1.0 hangs on the body, <1 is a narrower apron panel
/// @param {Real} _n   samples
/// @returns {Array} closed outline
function lge_wear_panel_pts(_arm, _y0, _y1, _k, _n) {
    var _ra = lge_wear_panel_rails(_arm, _y0, _y1, _k, _n, LGE_EASE_TOP, LGE_EASE_HEM);
    return lge_wear_rails_outline(_ra.l, _ra.r);
}

/// @desc One closed outline from a left rail and a right rail: down the left, back up the right.
///
/// ⚠️ NAMED RATHER THAN INLINED because two call sites now build it and a silent disagreement in
/// point order between them would fill the wrong region - which is this wing's `lge_ring_fill`
/// precondition, and the bowtie failure it already records twice.
function lge_wear_rails_outline(_l, _r) {
    var _n = array_length(_l);
    var _pts = [];
    for (var _i = 0; _i < _n; _i++) array_push(_pts, _l[_i]);
    for (var _i = _n - 1; _i >= 0; _i--) array_push(_pts, _r[_i]);
    return _pts;
}

/// @desc Where a smock's hem falls, in unit space. The one derivation; the apron reads it too.
///
/// ⛔⛔ THREE BAKES WERE SPENT ON THIS ONE NUMBER AND EACH WRONG ANSWER LOOKED REASONABLE WRITTEN
/// DOWN. Worth recording in full, because the shape of the mistake is general.
///
///   1. `lerp(shoulder, y_sole, hem)` - a fraction of the run to the FLOOR. Correct for as long as
///      every figure was standing. The moment the seated figures were solved into actually sitting,
///      the shoulder came down and the floor did not, so the run shrank by 0.155 of stature and
///      every seated townsperson was in a short dress with bare legs.
///   2. `lerp(shoulder, y_body_sole, hem)` - a fraction of the BODY, which is how a garment is
///      really cut. Right in principle and still wrong on the picture: a folded body's length is
///      spent going up and back down, so 0.62 of it lands near the floor and the elder came out in
///      a full-length bell with no knees, no shins and no feet. The pose IS the product; a cell that
///      hides it is worth nothing whatever the cloth is doing.
///   3. `above the higher KNEE` - the wear spec's own words, "caught up over the knees", taken
///      literally. ⛔ A SEATED KNEE IS ABOVE THE HIP, so "above the knee" is not a short skirt, it
///      is a crop top: the figure came back nude from the ribs down. The sentence was written about
///      a STANDING body and quietly stops being true when the leg folds.
///   4. `a fifth of the way from the knee down to the planted ankle` - the obvious repair for (3),
///      and it produced THE SAME PICTURE, because on a village bench the hip sits at 0.22 of unit
///      height and the knee at 0.29, so a fifth of the way down the shin is still ABOVE THE PELVIS.
///      Measured, baked, looked at: another crop top.
///
/// ⭐⭐ THE LESSON IS (3) AND (4) TOGETHER, AND IT IS THE GENERAL ONE: ON A SEATED FIGURE THE KNEE IS
/// ABOVE THE HIP, SO ANY HEM KEYED ON THE KNEE CAN LAND ABOVE THE PELVIS. A garment's first job is
/// to cover the body, and the landmark that says where the body needs covering is the HIP. So the
/// hem hangs a fixed body-distance below the hip whenever the leg is folded: it always covers the
/// pelvis, the cloth still reaches over the raised knees (they are inside the shoulder-to-hem band),
/// and what comes out below is the SHIN - which is the part that reads as sitting at a glance.
/// One landmark, one distance, no interpolation between two things that can swap order.
///
/// @param {Struct} _arm from lge_armature
/// @param {Struct} _spec from lge_wear_spec
/// @returns {Real} the hem's y in unit space
function lge_wear_hem_y(_arm, _spec) {
    var _y1 = lerp(_arm.y_shoulder, _arm.y_body_sole, _spec.hem);
    if (!variable_struct_exists(_spec, "hem_knee") || !_spec.hem_knee) return _y1;
    // ⚠️ `min`, NEVER `max`. y grows downward, so this can only SHORTEN the hem - a rule able to
    // lengthen one would reach the 35 standing loops, which are correct and were not being fixed.
    return min(_y1, _arm.y_hip + _arm.span * 0.055);
}

/// @desc The smock: the base garment, worn by everyone.
///
/// ⚠️ THE FAN APEX IS THE WAIST, NOT THE CENTROID, and that is the same decision `lge_body_parts`
/// makes for the torso ring and for the same reason: the panel is WAISTED where the body is, so it is
/// not convex, and while it stays star-shaped about the waist point a future edit that flares the hem
/// harder would break a centroid apex silently. Naming the apex makes the assumption visible.
/// ⛔⛔ AND THE YOKE WAS RESOLVED BY EXACTLY ONE SEGMENT, SO IT DREW AS A STRAIGHT CHORD ANYWAY.
/// MEASURED 2026-09-04 by cropping the cover's left figure to 3x. The 2026-09-03 fix started the
/// panel 0.42 of the way from the shoulder up to the neck, which is correct - and then handed the
/// whole shoulder-to-hem run to `lge_wear_panel_pts` with NINE uniform samples. The trapezius band
/// is a few hundredths of a stature tall against a run ten times that, so the first sample sat in
/// the yoke and the second was already past the shoulder: the garment's top edge was ONE horizontal
/// chord about 0.8 of shoulder width, with the deltoids bare on both sides of it. The figure read
/// as a sandwich board with the arms hung outside it.
///
/// ⭐ THE FIX IS TO SAMPLE THE YOKE AS ITS OWN PANEL. Two rail sets - neck to shoulder in 3 steps,
/// shoulder to hem in 9 - concatenated into one rail pair with the duplicated shoulder row dropped.
/// The top edge is then a NECKLINE at about neck width and the shoulders SLOPE out to full width,
/// which is what a cut garment does and is the single most visible difference between a person in
/// clothes and a rectangle with a head on it.
///
/// ⭐ AND IT IS SHADED AS A TUBE, NOT AS A DOME. `lge_form_dome` scales nested rings about a
/// centroid; on a tall waisted panel those rings' left and right edges land as VERTICAL STRIPES and
/// the smock reads as corrugated board (the Chitin entry in the wing constitution is the same
/// finding on a beetle: "a dome is the wrong model for a long body, it is a tube"). A torso is a
/// half-cylinder lit from one side, which is exactly `lge_tube_bands` over the panel's own rails.
function lge_wear_smock_parts(_arm, _spec) {
    var _out = [];
    // ⛔ THE TOP EDGE SITS ON THE TRAPEZIUS, NOT ON THE SHOULDER LINE. Starting at `y_shoulder` is
    // what put every townsperson in an off-the-shoulder tabard: the panel's top became a straight
    // horizontal cut across the chest and everything above it - collarbone, upper chest, the base of
    // the neck - was bare skin on all 46 figures. It was there because `lge_body_halfwidth` returned
    // 0 above the shoulder, so a higher start pinched to the width floor and drew a spike; that band
    // is now a real part of the body (see that function's header) and the garment can be cut over it.
    //
    // ⚠️ 0.86 of the way from the shoulder up to the neck, not all the way. A panel starting AT the
    // neck joint is a polo neck on a village weaver; stopping a little short of it leaves the collar
    // of the neck visible, which is what a round-necked smock looks like.
    var _y0 = lerp(_arm.y_shoulder, _arm.neck[1], 0.86);
    // ⛔ AGAINST `y_body_sole`, THE BODY, NEVER `y_sole`, THE FLOOR. A hem is a length of cloth cut
    // to a person; measuring it to the ground makes the same smock a different garment the moment
    // its wearer sits down. See the landmark's own header in lge_armature for the receipt - it put
    // every seated townsperson in a short dress with bare legs.
    var _y1 = lge_wear_hem_y(_arm, _spec);

    var _yk = lge_wear_panel_rails(_arm, _y0, _arm.y_shoulder, 1.0, 3, LGE_EASE_TOP, LGE_EASE_TOP);
    var _bd = lge_wear_panel_rails(_arm, _arm.y_shoulder, _y1, 1.0, 9, LGE_EASE_TOP, LGE_EASE_HEM);
    var _L = [], _R = [], _i;
    for (_i = 0; _i < array_length(_yk.l); _i++) { array_push(_L, _yk.l[_i]); array_push(_R, _yk.r[_i]); }
    // _bd[0] is the same row as _yk[last] - both are the shoulder line - so it is skipped rather
    // than pushed twice: a duplicated point is a zero-length edge, and a zero-length edge is what
    // caps every bevel in a part list to nothing (the Hearth entry in the wing constitution).
    for (_i = 1; _i < array_length(_bd.l); _i++) { array_push(_L, _bd.l[_i]); array_push(_R, _bd.r[_i]); }

    var _pts = lge_wear_rails_outline(_L, _R);
    array_push(_out, lge_ring_fill(_pts, "m2", _arm.waist[0], _arm.y_waist));
    lge_append(_out, lge_tube_bands(_L, _R, 7));

    // The placket: a short incised line down the centre front from the neckline. It is the one mark
    // that survives at cover scale, and it is what says "this garment was cut and sewn" rather than
    // "this is a coloured region". Drawn from the neckline down a fifth of the way to the hem.
    var _px = lge_lean_at(_arm, _y0);
    var _pb = lerp(_y0, _y1, 0.22);
    lge_append(_out, lge_incise([[_px, _y0 + _arm.span * 0.004],
                                 [lge_lean_at(_arm, _pb), _pb]], false, 0.007));

    // The hem: an incised line just above the bottom edge, so the garment ENDS rather than fading.
    var _hsp = lge_span_at_y(_pts, _y1 - _arm.span * 0.016);
    if (!is_undefined(_hsp)) {
        lge_append(_out, lge_incise([[_hsp[0], _y1 - _arm.span * 0.016], [_hsp[1], _y1 - _arm.span * 0.016]],
                                    false, 0.007));
    }
    return _out;
}

/// @desc Hose, and the shoes over them: the legs, covered.
///
/// ⛔⛔ WITHOUT IT EVERY FIGURE IN THIS PRODUCT IS A CLOTHED TORSO ON TWO BARE PALE POLES, WHICH IS
/// WHAT TWO CONSECUTIVE GATE 1 REVIEWS RECORDED ON THE COVER. The smock's hem is 0.80 of the body's
/// shoulder-to-sole run when standing and is pulled up over the knee when seated, so between a
/// fifth and a half of every figure was skin - and skin is the one role in the palette that does
/// not carry the trade's dye, so the corpus sheet read as 46 people wearing the same colour from
/// the hem down.
///
/// ⭐ IT IS DERIVED, NOT TABLED, which is this file's standing constraint (§2a): hose is what is
/// under a smock, so its extent is the smock's own hem read from `lge_wear_hem_y` and its top is
/// the hip. No work loop declares it and no work loop can opt out of it.
///
/// ⚠️ THE SHOE IS THE FOOT RE-DRAWN IN THE DARKEST STOP, NOT A NEW SHAPE. `lge_foot_pts` already
/// solves the foot against the planted ankle and the ground; giving it a second, darker mass is a
/// shoe, and inventing a separate outline would be a second derivation of the same thing that can
/// disagree with the first - which is exactly how the apron kept its own copy of every wrong answer
/// in `lge_wear_hem_y`.
function lge_wear_hose_parts(_arm) {
    var _out = [];
    var _w = _arm.w_limb;
    for (var _s = 0; _s < 2; _s++) {
        // Wider than the leg inside it, for the reason `lge_wear_sleeve_parts` gives about sleeves:
        // cloth at the limb's own width is a colour change, and a colour change reads as skin tone.
        lge_append(_out, lge_limb_parts(_arm.hip[_s], _arm.knee[_s], _w * 1.30, _w * 1.02, "m1"));
        lge_append(_out, lge_limb_parts(_arm.knee[_s], _arm.ankle[_s], _w * 1.02, _w * 0.78, "m1"));
        lge_append(_out, lge_joint_parts(_arm.knee[_s], _w * 1.02, "m1"));
        lge_append(_out, lge_mass(lge_foot_pts(_arm, _s), 0.52, 2, "m0"));
    }
    return _out;
}

/// @desc Sleeves, over the arms. Two segments for a long sleeve, one for a rolled-back short one.
///
/// ⚠️ DRAWN WIDER THAN THE ARM INSIDE IT BY A REAL MARGIN. A sleeve at the arm's own width is
/// invisible except as a colour change, which reads as a tattoo rather than as cloth.
function lge_wear_sleeve_parts(_arm, _spec) {
    var _out = [];
    var _w = _arm.w_limb;
    for (var _s = 0; _s < 2; _s++) {
        if (_spec.sleeve == "long") {
            lge_append(_out, lge_limb_parts(_arm.shoulder[_s], _arm.elbow[_s], _w * 1.30, _w * 1.06, "m2"));
            lge_append(_out, lge_limb_parts(_arm.elbow[_s], _arm.wrist[_s], _w * 1.02, _w * 0.80, "m2"));
            // The cuff.
            lge_append(_out, lge_ridge([_arm.elbow[_s], _arm.wrist[_s]], false, 0.006));
        } else {
            // Rolled to just below the shoulder: the sleeve stops at 44% of the upper arm and the
            // roll itself is a band, which is what says "rolled" rather than "cut short".
            var _mid = [lerp(_arm.shoulder[_s][0], _arm.elbow[_s][0], 0.44),
                        lerp(_arm.shoulder[_s][1], _arm.elbow[_s][1], 0.44)];
            lge_append(_out, lge_limb_parts(_arm.shoulder[_s], _mid, _w * 1.32, _w * 1.24, "m2"));
            lge_append(_out, lge_joint_parts(_mid, _w * 1.24, "m1"));
        }
    }
    return _out;
}

/// @desc The apron: a narrower panel over the smock, with a bib and straps on the hazardous trades.
function lge_wear_apron_parts(_arm, _spec) {
    var _out = [];
    var _top = _spec.apron_bib ? (_arm.y_shoulder + _arm.span * 0.17) : _arm.y_waist;
    // ⛔ DERIVED FROM THE SMOCK'S OWN HEM, NOT RE-COMPUTED. An apron hangs a little LOWER than the
    // smock under it, on a folded leg exactly as on a straight one, and the two must not be two
    // separate derivations that can disagree - which is what they were, and how the apron kept its
    // own copy of every wrong answer in `lge_wear_hem_y`'s header.
    // ⚠️ THE DROP IS THE ONE THE OLD FRACTION PRODUCED, RE-DERIVED RATHER THAN REPLACED BY A
    // CONSTANT. `hem + 0.10` was 0.10 of the body's own length, so a fixed number here would have
    // changed the apron on all 35 STANDING loops - which are correct and were not what was being
    // fixed. Written this way a standing apron is bit-for-bit where it was.
    var _drop = lerp(_arm.y_shoulder, _arm.y_body_sole, min(0.94, _spec.hem + 0.10))
              - lerp(_arm.y_shoulder, _arm.y_body_sole, _spec.hem);
    var _y1 = lge_wear_hem_y(_arm, _spec) + _drop;
    // Shaded as a tube over its own rails, for the reason `lge_wear_smock_parts` gives: nested
    // scaled rings on a tall panel are vertical stripes, and an apron is the flattest, widest cloth
    // on the figure, so it showed them worst.
    var _ar = lge_wear_panel_rails(_arm, _top, _y1, _spec.apron_bib ? 0.74 : 0.90, 8,
                                   LGE_EASE_TOP * 1.6, LGE_EASE_HEM * 1.15);
    var _pts = lge_wear_rails_outline(_ar.l, _ar.r);
    array_push(_out, lge_ring_fill(_pts, "m1", _arm.waist[0], _arm.y_waist));
    lge_append(_out, lge_tube_bands(_ar.l, _ar.r, 5));

    if (_spec.apron_bib) {
        // Two straps from the top corners of the bib to the shoulders. Their feet are clamped to the
        // bib's own span at the bib height, so a narrow build cannot leave a strap starting in mid air.
        var _sp = lge_span_at_y(_pts, _top + _arm.span * 0.010);
        if (!is_undefined(_sp)) {
            for (var _s = 0; _s < 2; _s++) {
                var _x = (_s == 0) ? _sp[0] * 0.72 : _sp[1] * 0.72;
                var _sh = [_arm.shoulder[_s][0] * 0.62, _arm.y_shoulder + _arm.span * 0.030];
                lge_append(_out, [lge_taper_ribbon([[_x, _top + _arm.span * 0.010], _sh],
                                                   _arm.w_limb * 0.34, _arm.w_limb * 0.28, "m2")]);
            }
        }
    }
    return _out;
}

/// @desc A belt at the waist, with a buckle.
///
/// ⛔ CLIPPED TO THE GARMENT'S SPAN AT THE BELT'S OWN HEIGHT. A belt drawn from -w to +w using the
/// figure's widest half-width pokes out of both sides of a slight build, and using the narrowest
/// leaves a gap on a heavy one. `lge_body_halfwidth` answers the question at exactly the right
/// height, which is the whole reason the armature publishes it.
function lge_wear_belt_parts(_arm) {
    var _out = [];
    var _y = _arm.y_waist + _arm.span * 0.012;
    var _w = lge_body_halfwidth(_arm, _y) + LGE_EASE_HEM * 0.75;
    var _t = _arm.span * 0.020;
    lge_append(_out, lge_mass([[-_w, _y - _t], [_w, _y - _t], [_w, _y + _t], [-_w, _y + _t]], 0.40, 2, "m2"));
    lge_append(_out, lge_boss(_w * 0.24, _y, _t * 0.85, 10));
    return _out;
}

/// @desc A cap over the skull.
///
/// ⚠️ IT MUST OVERLAP THE HAIRLINE, NOT SIT ON THE CROWN. A dome tangent to the top of the head reads
/// as a bowl balanced on it; a cap whose brim crosses the skull well below the crown reads as worn.
/// The armature's shoulder-cap row records the same class of mistake made in the other direction.
///
/// ⛔⛔ AND THE BRIM WAS SO FAR DOWN IT SAT BELOW THE BROW, SO EVERY CAPPED FIGURE IN THE CORPUS HAD
/// NO FACE. MEASURED 2026-09-04 by arithmetic against `lge_face_parts`, which is the only other
/// reader of these coordinates:
///
///     brows      head_y - 0.165r .. head_y - 0.225r
///     eyes       head_y + 0.075r
///     cap fill   everything ABOVE head_y - 0.060r        <- covers both brows, every time
///     brim band  head_y - 0.100r                         <- lands 0.175r under the brow
///
/// So the cap ate the brows outright and left the eyes jammed against its own brim edge. On the
/// store cover the three headed figures read as blank ovals under helmets, which is exactly what the
/// Gate 1 review recorded ("no nose or mouth at cover size", "featureless faces") - and the cause was
/// not the face at all, it was the hat.
///
/// ⭐ THE CONTROL THAT SETTLED IT IS IN THIS PACKAGE ALREADY: `lge_hair_band` covers the same skull
/// and DOES clear the brow, because it follows the skull's own arc from ear to ear instead of cutting
/// a straight horizontal line across it. Two things cover this head; one of them was the outlier.
///
/// ⚠️ BOTH BOUNDS ARE REAL AND THE FIX IS THE BAND BETWEEN THEM. Too high is the bowl this header
/// always warned about; too low is the defect above. The brim now sits at `head_y - 0.32r` - a
/// tenth of a head-radius clear of the brow's top at -0.225r, and still 0.68r below the crown, so it
/// crosses the skull rather than balancing on it. The cap's TOP is unmoved (-1.20r, proud of the
/// head as before): only its lower edge came up, which is done by shrinking `ry` rather than by
/// sliding the whole ellipse, or the dome would float.
function lge_wear_cap_parts(_arm) {
    var _out = [];
    var _r = _arm.head_r;
    var _cx = _arm.head[0];
    var _rx = _r * 1.06;
    var _ry = _r * 0.78;
    // Solved, not typed: the lower edge is `cy + 0.10r` (the closing chord below), so the centre
    // that puts that edge at LGE_CAP_BRIM is LGE_CAP_BRIM - 0.10, and the top then lands at
    // cy - ry. Writing the EDGE down and deriving the centre is what stops the two drifting.
    var _cy = _arm.head[1] + _r * (LGE_CAP_BRIM - 0.10);
    var _pts = lge_ellipse_arc_pts(_cx, _cy, _rx, _ry, pi, LGE_TAU, 16);
    // Close the arc across the forehead so the fill has an outline to work with.
    array_push(_pts, [_cx + _rx, _cy + _r * 0.10]);
    array_push(_pts, [_cx - _rx, _cy + _r * 0.10]);
    array_push(_out, lge_ring_fill(_pts, "m2", _cx, _cy - _r * 0.24));
    lge_append(_out, lge_form_dome(_pts, 0.46, 3));
    // The brim band.
    lge_append(_out, lge_ridge([[_cx - _rx, _cy + _r * 0.06], [_cx + _rx, _cy + _r * 0.06]],
                               false, 0.008));
    return _out;
}

/// ============================================================================================
/// THE WHOLE WORN SET
/// ============================================================================================

/// @desc Everything trade `_work_id` wears, on armature `_arm`, in that trade's dye.
///
/// ⛔ THE ORDER IS THE PRODUCT. Hose, then smock, then sleeves, then apron, then belt, then cap:
/// hose over the smock is a pair of leggings worn outside a dress, a sleeve under the smock's
/// shoulder is a bare arm, an apron under the smock is invisible, and a belt under the apron is a
/// belt worn inside a coat. `lge_render_work` draws this list between `lge_body_parts` and
/// `lge_hand_parts`, which is the split the armature's own header explains at length - a wrist-length
/// sleeve would otherwise cover the hand.
///
/// ⚠️ `_dye` OVERRIDES THE TRADE'S OWN DYE AND IS FOR ONE THING: TWO PEOPLE WORKING THE SAME TRADE.
/// `lge_wear_spec` derives the dye from the WORK LOOP, which is right and is what makes a trade
/// recognisable - and it means a second person at the same bench wears the identical colour. With
/// one worker per place that never showed; the moment `lge_town_populate` could seat a household it
/// baked the hero as four pairs of TWINS, differing only in skin and hair (MEASURED 2026-09-04 by
/// looking at the sheet). The CUT of the garment still comes from the trade, so this is a family
/// dyeing with what they have rather than a wardrobe: nothing else about the set moves.
///
/// @param {Struct} _arm from lge_armature
/// @param {String} _work_id
/// @param {Real|Undefined} _dye  optional dye index; undefined = the trade's own
/// @returns {Array} part list, already in the dye roles
function lge_wear_parts(_arm, _work_id, _dye) {
    var _sp = lge_wear_spec(_work_id);
    if (is_undefined(_sp)) return [];
    if (!is_undefined(_dye)) _sp.dye = ((_dye mod LGE_DYES) + LGE_DYES) mod LGE_DYES;
    var _o = [];
    lge_append(_o, lge_wear_hose_parts(_arm));
    lge_append(_o, lge_wear_smock_parts(_arm, _sp));
    lge_append(_o, lge_wear_sleeve_parts(_arm, _sp));
    if (_sp.apron) lge_append(_o, lge_wear_apron_parts(_arm, _sp));
    if (_sp.belt)  lge_append(_o, lge_wear_belt_parts(_arm));
    if (_sp.cap)   lge_append(_o, lge_wear_cap_parts(_arm));
    // Mapped into the dye in ONE place, at the end - the third file in this package to end on that
    // rule, for the reason `lge_map_roles`' own header gives.
    return lge_map_roles(_o, lge_dye_map(_sp.dye));
}

/// @desc How many slots trade `_work_id` fills. The distinctness this layer CAN claim, and the number
/// the probe reports so nobody has to guess whether the derivation is doing any work.
///
/// ⚠️ A LOW SPREAD HERE IS NOT A DEFECT, it is the honest consequence of §2a's scope. It is reported
/// rather than asserted, because an assertion on it would be a bar invented to fit today's data.
function lge_wear_slots(_work_id) {
    var _sp = lge_wear_spec(_work_id);
    if (is_undefined(_sp)) return 0;
    var _n = 2;                                  // the smock and the hose, always
    if (_sp.sleeve == "long") _n++;
    if (_sp.apron) _n++;
    if (_sp.apron_bib) _n++;
    if (_sp.belt) _n++;
    if (_sp.cap) _n++;
    return _n;
}
