{
  "$GMScript": "v1",
  "%Name": "lge_wear",
  "name": "lge_wear",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}
