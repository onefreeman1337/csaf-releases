/// ============================================================================================
/// LIEGE — THE FIGURE
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// The figure every townsperson is drawn on: builds, poses, and a solved skeleton in unit space.
///
/// ⚠️ PORTED FROM THIS WING'S `gm-raiment`, which shipped and gated this armature. The port is deliberate reuse of a proven solve - the arithmetic below has already been
/// corrected six times against baked sheets, and every one of those corrections is documented in
/// place. Do not "tidy" a comment that names a defect; it is the only thing standing between this
/// file and that defect returning.
///
/// ⛔ WHAT LIEGE ADDS is not here. This file knows about STANDING, WALKING and REACHING. The work
/// poses - the 40+ joint sets that are this product's volume - live in `lge_pose`, and the props
/// they hold live in `lge_station`. Keeping them apart is what makes the figure reusable across
/// every work loop instead of once per station.
///
/// ============================================================================================

#macro LGE_CROWN  (-0.470)
#macro LGE_SOLE   ( 0.470)

/// The face, in head radii from the head's CENTRE, y down. Named because a HAT has to clear them
/// and until 2026-09-04 no hat did - see `lge_face_brow_top` and `LGE_CAP_BRIM`.
///
/// ⚠️ THE INNER END OF A BROW IS ITS HIGH END, so LGE_FACE_BROW_IN is the larger rise. Swapping the
/// two draws a permanently surprised village and moves the number a cap is checked against.
#macro LGE_FACE_EYE_Y     (0.075)
#macro LGE_FACE_BROW_OUT  (0.24)
#macro LGE_FACE_BROW_IN   (0.30)
/// Where the mouth sits between the eye line and the chin, as a fraction of that span.
#macro LGE_FACE_MOUTH_T   (0.62)

/// ⛔ A PHYSICAL DETAIL BOUNDED ONLY AS A PROPORTION IS WRONG ON THE LARGEST THING YOU DRAW - the
/// inherited law from lge_geom's header, and it binds here too. A belt buckle, a seam or a rivet is
/// about the same size on a tall figure as on a short one. Body SEGMENT lengths scale with the
/// build (they are the figure); detail sizes do not.
#macro LGE_MIN_LIMB_W (0.006)

/// How far inboard of the torso's own shoulder edge the arm hangs, as a fraction of it.
///
/// ⛔ THIS IS THE NUMBER THAT DECIDES HOW WIDE A CLOTHED FIGURE IS. The shoulder half-width is the
/// acromion; the humerus head is inside it, and a smock's sleeve is a tube around the ARM. Setting
/// this to 1.0 - which is what the first version effectively did - puts the whole sleeve outboard of
/// the silhouette, and no sleeve width makes that look right.
#macro LGE_ARM_INSET (0.86)

/// The most a forward reach may foreshorten the arm's LATERAL extent, as a fraction.
///
/// ⛔ A LOWER BOUND, NOT A TUNING KNOB. `cos(fwd)` is the correct foreshortening and it goes to zero
/// at 90 degrees, where an arm reaching straight at the viewer draws as a point - anatomically right
/// and unreadable. This file already records what that looks like when it happened for a different
/// reason: "a skin-coloured blob sitting on the centreline of the chest", which read as a stain
/// rather than as an arm. 0.46 is cos(62 deg), so the arm keeps just under half its lateral spread
/// and stays legible as an arm at the 190px cell the grid sheet draws.
#macro LGE_ARM_FS_MIN (0.46)

/// ============================================================================================
/// THE STOOP
/// ============================================================================================
///
/// ⛔⛔ A LEAN IS A ROTATION IN THE SAGITTAL PLANE AND THIS ARMATURE DREW IT AS A SIDEWAYS SHEAR, SO
/// 17 OF THE 46 WORK LOOPS WERE BANANAS. It is the SAME defect the arms had - a picture-plane model
/// with no depth term - one level up, and it survived the arm fix because nobody looked for it twice.
///
/// `lean` means leaning INTO the work: `lge_labour_pose` peaks it with the working beat, and the work
/// is in front of the figure. The armature spent all of it in x - head at `lean * 1.20`, neck 0.85,
/// shoulders 0.70, waist 0.30 - so at the corpus maximum of 0.40 the head sat 0.48 OF A STATURE off
/// the hip line. MEASURED 2026-09-03 by cropping `joiner_plane` to 4x and looking: the silhouette is
/// a comma, the head hangs off the end of a stretched neck, and the whole body arcs.
///
/// ⭐ AND THE HEAD-ATTACHMENT GATE WAS GREEN OVER IT, CORRECTLY. That check asks whether the head has
/// come OFF the torso; here it had not - the torso came with it. A check is only ever about the thing
/// it compares (master 2b), and nothing compared the body to the VERTICAL.
///
/// ⭐ THE FIX IS THE ARMS' FIX. Rotate the torso about the hip toward the viewer: a front view sees
/// that as FORESHORTENING - every landmark drops toward the hip by `1 - cos(phi)` of its own height -
/// and only a small residual is drawn sideways. A stooping worker gets visibly shorter over the beat,
/// which is what a stoop looks like head-on, instead of sliding out of their own silhouette.
///
/// ⚠️ THE LATERAL SHARE IS NOT ZERO ON PURPOSE. A pure foreshortening reads as a figure shrinking,
/// and a little sideways tilt is what tells a viewer which way the body is going. It keeps the
/// authored gradient, so the relative shape of the lean is exactly as tuned; only its size changes.

/// Radians of stoop per unit of a pose's `lean`.
///
/// ⛔ DERIVED FROM THE CROWN DROP IT IS MEANT TO PRODUCE, NOT PICKED. The first value put the corpus
/// maximum (`lean` 0.40) at 55 degrees, which spends 43% of the torso's drawn height: baked and
/// looked at, `digger_spade` came out as a hunched dwarf - a compressed torso over a full-length
/// skirt, because the skirt hangs from the waist and does not foreshorten with the chest. The bar
/// that matters is how far the CROWN comes down, so it is set from that: 0.12 of a stature is a
/// clearly-reading stoop, which needs `1 - cos(phi) = 0.262` over the crown-to-hip run, i.e. 42.5
/// degrees at the corpus maximum. 0.742 / 0.40 = 1.855.
#macro LGE_LEAN_RAD (1.855)

/// The hard cap on a stoop. Past this the torso foreshortens away to nothing and the figure reads as
/// a head on a pair of legs - the same failure `LGE_ARM_FS_MIN` exists to prevent for the arms.
#macro LGE_LEAN_MAX (1.05)

/// How much of a lean is drawn SIDEWAYS rather than spent as forward foreshortening.
#macro LGE_LEAN_LATERAL (0.32)

/// How far the hip JOINT sits above the surface a figure is sitting on, in unit space.
///
/// ⚠️ A PHYSICAL DETAIL, SO IT IS A CONSTANT AND NOT A PROPORTION - the same law the limb-width macro
/// above states. The femur head clears a bench top by about half a thigh's thickness whether the
/// sitter is tall or short, so scaling this with the build would sink the short townspeople into
/// their own stools. `lge_figure_parts` adds it to the station's declared seat height and hands the
/// sum to the armature as `hip_h`.
#macro LGE_SEAT_RISE (0.030)

/// @desc How much a pose's forward reach shortens its arms in the picture plane, 0..1.
///
/// Reads `fwd` (radians of rotation about the body's own vertical axis) and returns `cos(fwd)`,
/// floored at LGE_ARM_FS_MIN. A pose that does not declare `fwd` returns exactly 1.0, so every
/// hand-authored pose in `lge_pose` is bit-for-bit unchanged - those five were tuned by eye against
/// baked sheets and must not move because the WORK loops needed a fix.
///
/// @param {Struct} _p a pose struct from lge_pose or lge_labour_pose
/// @returns {Real} the lateral scale, LGE_ARM_FS_MIN..1
function lge_arm_foreshorten(_p) {
    if (!variable_struct_exists(_p, "fwd")) return 1.0;
    var _f = _p.fwd;
    if (_f <= 0) return 1.0;
    return max(LGE_ARM_FS_MIN, cos(min(_f, pi * 0.5)));
}

/// ============================================================================================
/// BUILDS - the small, deliberate amount of body variety this product ships
/// ============================================================================================

/// The build ids, in a stable order. Five, and no more - see the header.
function lge_builds_all() {
    return ["slight", "average", "broad", "tall", "short"];
}

/// Proportions for a build.
///
/// Every number is a MULTIPLIER on the average figure, so `average` is all 1.0 and reads as the
/// definition rather than as one more special case.
///
/// @param {String} _id one of lge_builds_all()
/// @returns {Struct} the proportion set
function lge_build(_id) {
    switch (_id) {
        case "slight": return { stature: 0.965, shoulder: 0.86, hip: 0.92, limb: 0.84, torso: 0.98, head: 1.02 };
        case "broad":  return { stature: 1.000, shoulder: 1.22, hip: 1.14, limb: 1.26, torso: 1.03, head: 0.99 };
        case "tall":   return { stature: 1.055, shoulder: 1.04, hip: 0.98, limb: 0.96, torso: 1.02, head: 0.95 };
        case "short":  return { stature: 0.930, shoulder: 1.02, hip: 1.06, limb: 1.08, torso: 0.96, head: 1.07 };
        default:       return { stature: 1.000, shoulder: 1.00, hip: 1.00, limb: 1.00, torso: 1.00, head: 1.00 };
    }
}

/// ============================================================================================
/// POSES - authored joint angles, never an interpolated rig
/// ============================================================================================
///
/// ⛔ SCOPE GUARD, from ARCHITECTURE.md SS4. A pose is a NAMED SET OF ANGLES, authored by hand. If
/// the figure needs to move, it switches between these. A general animation system is not this
/// product and adding one is how this build runs over.

/// The pose ids, in a stable order.
function lge_poses_all() {
    return ["stand", "walk", "reach", "guard", "sit"];
}

/// Joint angles for a pose, in radians, measured from straight-down for legs and straight-out for
/// arms so that all-zero is a plausible figure rather than a heap.
///
/// @param {String} _id one of lge_poses_all()
/// @returns {Struct} the angle set
function lge_pose(_id) {
    // ⛔ `thigh_k` IS FORESHORTENING AND IT IS THE ONE THING A FRONT VIEW CANNOT DO WITHOUT.
    // Every other angle here is a rotation IN the picture plane, which is all a front view has -
    // except when a limb points AT the viewer, and a seated figure's thighs do exactly that. With
    // thigh_k left at 1 the `sit` pose swung both knees out by sin(1.28) = 0.958 of a full thigh
    // length, so the figure sat with its knees a metre apart and lge_body_halfwidth, which takes
    // its below-hip width from the outermost knee, cut the smock as wide as the pose was.
    // The result on the pose sheet was unmistakable and it was not a person: it was somebody
    // sitting in a large upholstered armchair. MEASURED 2026-09-02 by looking at sheet 7.
    //
    // ⭐ A LIMB POINTING AT THE VIEWER IS SHORT. The correct model in a front view is that the
    // thigh's DRAWN length is its true length times the cosine of how far it has swung out of the
    // picture plane, and that is a per-pose number rather than a per-joint one - so it is authored
    // here beside the angles it belongs with.
    // ⛔⛔ THE ARMS ARE PER-SIDE, AND A SINGLE `sh`/`el` PAIR IS WHAT MADE THIS FIGURE A SCARECROW.
    // Every pose here used to carry ONE shoulder angle and ONE elbow angle applied to both arms, so
    // the only figure it could describe was bilaterally symmetric - and `reach` at sh 1.15 is then
    // not a reach at all, it is a T-pose with both arms out. Twenty-four of those on the crowd
    // sheet read as a field of scarecrows. A person reaching moves ONE arm; the other hangs.
    //
    // `sh0`/`el0` are the viewer-LEFT arm and `sh1`/`el1` the viewer-RIGHT, measured from straight
    // down and opening OUTWARD on each side (so a positive angle swings the left arm to -x and the
    // right arm to +x - see the solve loop). `sh`/`el` remain as the fallback for any caller that
    // authors a symmetric pose, and lge_pose_arm() below is the only reader.
    //
    // ⚠️ PERFECT SYMMETRY IS ITS OWN TELL. `stand` carries 0.10/0.13 rather than 0.11/0.11: two arms
    // at identical angles read as a shop dummy, and the asymmetry is small enough that nobody sees
    // it as a pose and large enough that nobody sees it as a machine.
    switch (_id) {
        //                    ---- viewer LEFT ----  ---- viewer RIGHT ---
        //                     shoulder    elbow      shoulder    elbow      hip     knee    lean   headtilt   thigh
        // ⭐ ONE LEG PLANTED, ONE SWINGING - WHICH IS WHAT A STEP IS, AND WHAT THE MIRRORED FORM
        // COULD NOT SAY. Under `hp: 0.30` both thighs rotated toward the centre and met there
        // (measured knee gap 0.0151 against a 0.1354 stance), so `walk` was a person standing with
        // their ankles crossed. The right leg is now planted at 0 and the left swings through at
        // 0.34 with the knee folding 0.30, which drops its ankle 0.0126 of stature short of the sole
        // - a foot just off the ground, not a floating figure.
        case "walk":  return { sh0: 0.22, el0: 0.16, sh1: 0.40, el1: 0.34, sh: 0.34, el: 0.30, hp: 0.30, kn: 0.26, hp0: 0.34, kn0: 0.30, hp1: 0.00, kn1: 0.02, splay: 0.02, lean:  0.020, tilt:  0.000, thigh_k: 0.30 };
        // The reaching arm is the right; the left hangs almost at rest with a little elbow in it.
        // ⚠️ 1.15 + 0.42 IS 1.57 RADIANS, WHICH IS EXACTLY 90 DEGREES, AND A DEAD-HORIZONTAL FOREARM
        // IS THE ONE ANGLE THAT READS AS A MACHINE. It made the reach a ruled line across the cell
        // with a hand on the end. 1.05 + 0.30 = 1.35 puts the forearm 13 degrees below horizontal,
        // which is where an arm actually rests when it reaches for something.
        case "reach": return { sh0: 0.13, el0: 0.14, sh1: 1.05, el1: 0.30, sh: 1.15, el: 0.42, hp: 0.06, kn: 0.08, hp0: 0.06, kn0: 0.08, hp1: -0.05, kn1: 0.03, splay: 0.03, lean: -0.030, tilt: -0.040, thigh_k: 0.55 };
        // ⚠️ THE ANGLES ADD, AND THAT IS WHY THE FIRST GUARD WAS A T-POSE. `el` is measured from the
        // upper arm's own line and both are taken from straight DOWN, so the forearm's direction is
        // sh + el: at 0.30 + 1.32 = 1.62 rad the lead forearm was 93 degrees off vertical - PAST
        // horizontal - and the rear at 1.48 was 85. Two horizontal forearms is a T, whatever the
        // shoulders are doing, and on the pose sheet it was indistinguishable from the scarecrow it
        // replaced. A guard is ASYMMETRIC: shield arm up and out, weapon arm low with a cocked
        // elbow, which is also what tells it apart from `walk` and from `reach` at a glance.
        // ⛔ AND THE FIRST ASYMMETRIC GUARD WAS STILL A T, BECAUSE BOTH TOTALS LANDED NEAR 60
        // DEGREES. 1.02+0.30 = 1.32 rad on the left and 0.18+0.72 = 0.90 on the right both put a
        // forearm out at roughly shoulder height, so "shield arm up, weapon arm low" described the
        // shoulders while the picture showed two arms out. It is the TOTAL that points the forearm.
        //
        // The weapon arm comes in to 0.14 + 0.30 = 0.44 rad - 25 degrees, hanging close to the body
        // with a slight bend - so the two arms are doing visibly different things.
        //
        // ⛔ THIS WAS ALSO WRITTEN AS THE FIX FOR THE POSE SHEET BEING A THIRD EMPTY AIR, AND THAT
        // WAS FALSE. The reasoning was that the five cells share a scale set by the WIDEST figure,
        // so narrowing `guard` would let them all grow. The change was made, the sheet was re-baked,
        // and the dead space did not move by a pixel. `lge_bake`'s pose sheet takes its scale from
        // the HEIGHT budget; width enters only through a shrink factor that never touched the well
        // height, which is where the air came from and where it was actually fixed. The pose change
        // is kept because the T-pose reading was real - but it fixed one defect, not two.
        //
        // ⚠️ Left here deliberately rather than deleted. A plausible mechanism that survives one
        // edit becomes doctrine, and the next session would have re-derived the same wrong story
        // from a comment that sounded measured (master 2b: verifying against the thing you wrote).
        // ⛔⛔ AND THE THIRD GUARD WAS STILL WRONG, FOR A REASON THE TWO ABOVE BOTH MISS: IT WAS
        // `reach` IN A MIRROR. sh0 1.02 + el0 0.30 = 1.32 rad puts the lead forearm 76 degrees off
        // vertical; `reach` sits at 1.05 + 0.30 = 1.35, i.e. 77. So sheet 7 showed five poses of
        // which two were the same picture flipped, and the block above spent three paragraphs
        // tuning WHICH arm was out instead of asking whether the two cells differed at all.
        // MEASURED 2026-09-02 by putting the two cells side by side and looking.
        //
        // ⛔ AND THE DONOR SHEET'S CAPTION WAS A CLAIM NO CELL SUPPORTED: "a sleeve follows a BENT
        // ELBOW instead of crossing it", over five poses whose largest elbow angle was 0.44 rad.
        // That is this wing's standing law about a caption naming something the image is not drawn
        // at (Lexicon, "at dialogue size - 14 pixels" over a 34px row), and it is a market claim
        // under master 2 either way.
        //
        // ⭐ A GUARD IS TWO BENT ELBOWS AND NO STRAIGHT LINE ANYWHERE. Shield arm: shoulder out at
        // 0.88 and the elbow folding 1.42 rad (81 degrees), so the forearm runs UP and out and the
        // hand finishes at about shoulder height with the elbow low - which is the shape of a raised
        // guard and cannot be confused with a reach. Weapon arm: elbow tucked at 0.18 with a 0.86
        // rad (49 degree) fold, forearm out and DOWN. Both elbows are now visibly bent, the two arms
        // are doing different things, and the caption is true for the first time.
        //
        // Legs: braced rather than mirrored - weight back on the right, splay 0.10 for a stance a
        // fighter could actually hold.
        case "guard": return { sh0: 0.88, el0: 1.42, sh1: 0.18, el1: 0.86, sh: 0.52, el: 1.05, hp: 0.16, kn: 0.30, hp0: 0.16, kn0: 0.16, hp1: -0.10, kn1: 0.00, splay: 0.10, lean:  0.045, tilt:  0.030, thigh_k: 0.30 };
        // Seated: forearms come in to rest on the thighs, so the elbow closes and the shoulder does not.
        //
        // ⛔ BOTH THIGHS GO FORWARD, WHICH IS THE ONE THING A MIRRORED PAIR CANNOT SAY. Under
        // `hp: 0.92 * swing` the two thighs rotated toward each other and the knees swapped sides on
        // all five builds (_leg_probe.js: average +0.0115 / -0.0115). They now carry the same
        // sagittal angle, so the drawn thigh SHORTENS - cos(0.92) = 0.6055, the knee rises 8.5% of
        // stature - and the separation comes from `splay` where it belongs.
        // ⛔ AND AT 0.92 RAD IT WAS STILL A SHORT STANDING PERSON, WHICH IS WHAT SHEET 7 SHOWED.
        // cos(0.92) = 0.6055, so the thigh only lost 39% of its drawn length and the visible leg came
        // out at 81% of the standing one - a figure a tenth of a stature shorter, upright, with
        // parallel legs. MEASURED 2026-09-02 by cropping the sit cell to 3x: nothing in the picture
        // says seated, over a caption that does.
        //
        // ⭐ A FRONT VIEW SEES SITTING AS THE THIGH DISAPPEARING. The femur of a seated figure is
        // roughly horizontal, so head-on it foreshortens to almost nothing and what is left is a
        // vertical shin under a knee at hip height. cos(1.32) = 0.2482 spends 75% of the thigh, which
        // puts the knee just above the crotch where a seated knee actually is. The knee fold tracks
        // the hip (1.36 against 1.32) so the shin stays within 2 degrees of vertical, and the splay
        // opens the stance because a seated figure's knees are apart.
        // ⛔ AND EVEN AT 1.32 RAD IT WAS STILL A SHAPE WITHOUT A PLACE. The angles above describe a
        // seated FIGURE correctly and say nothing about where that figure is, so the solve left the
        // hips at standing height and lifted the FEET instead - which beside any piece of furniture
        // reads as somebody standing on it. `hip_h` states the hip's height above the floor and the
        // thigh angle is solved from it (see the block in lge_armature); 0.25 is a stool at 0.22 plus
        // LGE_SEAT_RISE, which is the seat this product's own stations are built at. A buyer drawing
        // this pose supplies the stool; the townspeople get theirs from `lge_station_spec.seat`.
        case "sit":   return { sh0: 0.16, el0: 0.44, sh1: 0.22, el1: 0.34, sh: 0.18, el: 0.38, hp: 1.30, kn: 1.34, hp0: 1.32, kn0: 1.36, hp1: 1.28, kn1: 1.32, splay: 0.15, lean:  0.030, tilt:  0.000, thigh_k: 0.02, hip_h: 0.25 };
        // `stand`, and the fallback for any id this table does not know. Its hip angle is small
        // enough that the lateral term was never the problem here, so thigh_k stays at 1 and the
        // slight inward set of the knees (femurs converge on a real figure) is kept deliberately.
        default:      return { sh0: 0.10, el0: 0.13, sh1: 0.13, el1: 0.08, sh: 0.11, el: 0.09, hp: 0.05, kn: 0.05, hp0: 0.05, kn0: 0.05, hp1: -0.045, kn1: -0.04, splay: 0.00, lean:  0.000, tilt:  0.000, thigh_k: 1.00 };
    }
}

/// The shoulder and elbow angle for ONE side of a pose, as [shoulder, elbow].
///
/// Reads the per-side keys when the pose declares them and falls back to the symmetric pair
/// otherwise, so a pose struct written by hand with only `sh`/`el` still solves.
///
/// @param {Struct} _p from lge_pose
/// @param {Real} _side 0 for the viewer-LEFT arm, 1 for the viewer-RIGHT
/// @returns {Array} [shoulder, elbow] in radians
function lge_pose_arm(_p, _side) {
    var _ks = (_side == 0) ? "sh0" : "sh1";
    var _ke = (_side == 0) ? "el0" : "el1";
    return [
        variable_struct_exists(_p, _ks) ? variable_struct_get(_p, _ks) : _p.sh,
        variable_struct_exists(_p, _ke) ? variable_struct_get(_p, _ke) : _p.el
    ];
}

/// The hip and knee angle for ONE side of a pose, as [hip, knee], both in radians.
///
/// The counterpart of lge_pose_arm, added for the same reason and eight hours later: a single
/// `hp`/`kn` pair can only describe a bilaterally mirrored figure, and mirroring a stride in the
/// PICTURE plane swings both knees toward the centre line (see the leg block in lge_armature).
///
/// ⚠️ THE FALLBACK IS NOT DECORATION AND IT IS NOT THE SAME ARITHMETIC. The old form alternated the
/// sign of BOTH angles per side (`hp * swing`, `kn * swing * -1`); the solve loop now subtracts the
/// knee angle unconditionally, so the fallback has to hand back an already-signed pair for the old
/// meaning to survive. A pose struct carrying only `hp`/`kn` therefore still solves to exactly what
/// it used to.
///
/// @param {Struct} _p from lge_pose
/// @param {Real} _side 0 for the viewer-LEFT leg, 1 for the viewer-RIGHT
/// @returns {Array} [hip, knee] in radians
function lge_pose_leg(_p, _side) {
    var _kh = (_side == 0) ? "hp0" : "hp1";
    var _kk = (_side == 0) ? "kn0" : "kn1";
    if (variable_struct_exists(_p, _kh) && variable_struct_exists(_p, _kk)) {
        return [variable_struct_get(_p, _kh), variable_struct_get(_p, _kk)];
    }
    var _swing = (_side == 0) ? 1 : -1;
    return [_p.hp * _swing, _p.kn * _swing];
}

/// ============================================================================================
/// THE SKELETON
/// ============================================================================================

/// Solve the armature into absolute joint positions in unit space.
///
/// The figure is built DOWNWARD from the crown so that stature changes lengthen the legs and torso
/// rather than sinking the head into the shoulders, and every joint is returned as [x, y] so a
/// worn item or held tool can be authored against joints by name.
///
/// ⚠️ `_side` is +1 for the figure's LEFT as the viewer sees it. Front view, so the figure's own
/// right is the viewer's left; nothing in this product needs to care, and the naming is by VIEWER
/// throughout to stop two modules disagreeing about it.
///
/// @param {String} _build_id one of lge_builds_all()
/// @param {String} _pose_id one of lge_poses_all()
/// @returns {Struct} joints, plus the body widths lge_wear samples
/// ⭐ `_pose_id` MAY BE A POSE STRUCT INSTEAD OF AN ID, AND THAT IS WHAT MAKES THE WORK LOOPS
/// POSSIBLE. The donor had five named poses and needed nothing else. This product's whole volume is
/// work: 46 loops, each cycling through its own phases, so a pose here is a CONTINUOUS FUNCTION of
/// the loop's phase rather than one of a handful of constants - `lge_labour_pose(id, u)` returns a
/// freshly computed angle set for any u, and there is no id to look it up by.
///
/// Accepting both keeps ONE solver. The alternative - a second `lge_armature_posed` beside this one -
/// is how two solvers drift apart, and every defect narrative in this file would then apply to only
/// one of them.
function lge_armature(_build_id, _pose_id) {
    var _b = lge_build(_build_id);
    var _p = is_struct(_pose_id) ? _pose_id : lge_pose(_pose_id);

    var _span = (LGE_SOLE - LGE_CROWN) * _b.stature;
    var _top  = -_span * 0.5;

    // Vertical landmarks as fractions of total stature. These are the canon of the figure and are
    // the one place a proportion is allowed to be a magic number, because they ARE the figure.
    var _head_r  = _span * 0.072 * _b.head;
    var _neck_y  = _top + _head_r * 2.05;
    var _shl_y   = _neck_y + _span * 0.038;
    var _waist_y = _shl_y  + _span * 0.185 * _b.torso;
    var _hip_y   = _waist_y + _span * 0.088 * _b.torso;
    var _sole_y  = _top + _span;

    var _shl_x = _span * 0.104 * _b.shoulder;
    var _hip_x = _span * 0.072 * _b.hip;

    // Limb segment lengths, taken from what is left below the hip so the figure always reaches
    // the sole exactly - a figure whose feet float is the first thing a buyer notices.
    //
    // ⛔⛔ THE FOOT HAD NO ROOM AND THEREFORE DID NOT EXIST, ON EVERY FIGURE THIS PRODUCT HAS
    // DRAWN. Thigh 0.470 + shin 0.530 is the whole leg, so the ankle joint landed exactly on the
    // sole and there was nowhere below it to put a foot - which is why lge_body_parts drew none
    // and every figure on every store sheet ended in a flat cut across the shin. Found 2026-09-02
    // by looking at the donor's own store sheet: five figures standing on two pale stumps each.
    //
    // ⭐ AND THE FIX IS A BUDGET, NOT A DRAWING. A foot is about a tenth of the leg's height in a
    // front view (it is mostly LENGTH, and length is foreshortened to nothing head-on), so the
    // segments are solved against 90.5% of the leg and the remainder is the foot's own band. The
    // sole does not move, so no smock hem and no boot top shifts by a pixel.
    //
    // ⚠️ NOT SOLVED BY LETTING THE FOOT HANG BELOW LGE_SOLE. The margin between LGE_SOLE and the
    // unit box is 0.030, and `tall` spends stature 1.055 of it: measured, that leaves 0.004 of
    // clearance, so a foot drawn past the sole would be clipped on exactly one build and nowhere
    // else - the worst kind of defect, because four of the five builds look correct.
    var _leg_total = _sole_y - _hip_y;
    var _foot_h = _leg_total * 0.095;
    var _leg = _leg_total - _foot_h;
    var _thigh = _leg * 0.470;
    var _shin  = _leg * 0.530;
    // ⚠️ ARM LENGTH IS ANATOMY, AND THE FIRST NUMBERS WERE SHORT. Shoulder-to-wrist ran
    // 0.150 + 0.145 = 0.295 of stature against roughly 0.33 on a real figure, and a short arm plus
    // a sleeve that flared toward the wrist is most of why the arms read as
    // stubby paddles rather than limbs. Corrected 2026-09-02 off the donor's pose sheet.
    // ⛔ Kept BELOW the anatomical figure on purpose: these are the segment lengths, and the wrist
    // is not the fingertip. Pushing them to a true 0.33 puts the wrist past the hip on `stand` and
    // the hand disappears into the hem of anything worn over it.
    var _upper = _span * 0.166;
    var _fore  = _span * 0.152;

    // THE STOOP. See the block above LGE_LEAN_RAD for why this is not a sideways offset.
    //
    // ⚠️ THE PIVOT IS THE HIP AND THE FLOOR DOES NOT MOVE. `_sole_y` and `_hip_y` are both already
    // solved above and neither is touched here, so the legs, the plant translation and the seat solve
    // are all untouched by a lean - which is correct, because bending over does not move your feet.
    // What moves is everything ABOVE the hip, downward, by its own share of the foreshortening.
    var _lean_phi = min(abs(_p.lean) * LGE_LEAN_RAD, LGE_LEAN_MAX);
    var _lean_fs  = 1 - cos(_lean_phi);
    _top     += (_hip_y - _top)     * _lean_fs;
    _neck_y  += (_hip_y - _neck_y)  * _lean_fs;
    _shl_y   += (_hip_y - _shl_y)   * _lean_fs;
    _waist_y += (_hip_y - _waist_y) * _lean_fs;

    // The residual sideways component. The authored gradient (1.20 / 0.85 / 0.70 / 0.30) is kept
    // exactly as tuned and only its SIZE changes, so a lean still reads as the same shape of tilt.
    var _lean = _p.lean * _span * LGE_LEAN_LATERAL;

    // Arms: angles measured from straight down, opening outward.
    var _elb = [];
    var _wri = [];
    var _kne = [];
    var _ank = [];
    var _s;
    // `thigh_k` damps the leg swing's LATERAL arm only - see the leg block below for what it is and
    // why it is not 1 on any pose whose stride is sagittal.
    var _tk = variable_struct_exists(_p, "thigh_k") ? _p.thigh_k : 1.0;
    // Stance width, in units of thigh length, outward on each side. Default 0 = feet under hips.
    var _splay = variable_struct_exists(_p, "splay") ? _p.splay : 0;

    // ⛔⛔ A SEATED FIGURE IS DEFINED BY WHERE ITS HIP IS, NOT BY ITS HIP ANGLE - AND SOLVING IT AS AN
    // ANGLE PUT EIGHT WORKERS ON TOP OF THEIR OWN FURNITURE. `lge_stance("seated")` authored
    // hp 1.32 / kn 1.36, which is a perfectly good SHAPE, and the shape is all an angle can say. Where
    // the figure ends up is then whatever the arithmetic happens to produce, and what it produced was
    // a hip 0.164 of stature above the bench it was drawn beside - a woman standing on a bench with
    // its back rail through her skirt (Internal_Ops/_c_elder.png, cropped and looked at 2026-09-03).
    //
    // ⭐ SO THE POSE STATES THE HIP HEIGHT AND THE ANGLE IS SOLVED FROM IT. `hip_h` is the height of
    // the hip joint above the floor, in UNIT space - the same space every station in this product is
    // authored in - and it is deliberately NOT scaled by the build, because a bench is the same
    // height for a tall weaver and a short one. Given a planted foot and the shin's authored lean,
    //
    //     hip_h = foot_h + cos(shin) * shin_len + cos(thigh) * thigh_len
    //
    // has exactly one unknown, so the thigh angle falls out. A short figure on the same bench gets a
    // more open thigh, which is what actually happens when a short person sits on a tall bench.
    //
    // ⚠️ THE PER-SIDE ASYMMETRY IS PRESERVED, NOT OVERWRITTEN. The solve moves BOTH hip angles by one
    // shared amount, so each side keeps its own deviation and its own shin lean (`kn` moves with
    // `hp`, so `hp - kn` - which is what points the shin - does not move at all). A pose with no
    // `hip_h` is bit-for-bit unchanged.
    //
    // ⛔ AND THE SHARED AMOUNT IS THE MAX OF THE TWO PER-SIDE SOLUTIONS, NOT THEIR MEAN. The first
    // version solved against the average of the two authored hip angles and was WRONG BY 0.0045 of
    // unit height on every seated figure, because the plant translation below stands the figure on
    // its LOWEST foot and the lowest foot is the one whose thigh solved SHALLOWEST - not the average
    // of the two. A larger adjustment lowers the hip (cos is decreasing here), so the side needing
    // the most adjustment is the one that binds, and taking the max makes the other side land at or
    // above the seat rather than through it. MEASURED by _stand_probe.js, which went red at
    // scribe_write/tall and green on all 40 build-loop pairs once this became a max.
    var _hp_adj = 0;
    if (variable_struct_exists(_p, "hip_h") && _p.hip_h > 0) {
        for (var _q = 0; _q < 2; _q++) {
            var _plq = lge_pose_leg(_p, _q);
            var _lean_q = _plq[0] - _plq[1];                  // the drawn shin's angle off vertical
            var _cq = (_p.hip_h - _foot_h - cos(_lean_q) * _shin) / max(0.00001, _thigh);
            // ⚠️ A CLAMP, NOT A TUNING KNOB. cos is only defined on [-1,1] and a seat height the legs
            // cannot reach must degrade to the closest sittable pose rather than to a NaN. The real
            // stations span 0.19-0.23 of unit height, which lands _cq between -0.34 and -0.03 on
            // every build, so this bound is never reached by anything this product ships - the suite
            // asserts that separately rather than trusting the sentence.
            _cq = clamp(_cq, -0.55, 0.80);
            var _aq = arccos(_cq) - _plq[0];
            if (_q == 0 || _aq > _hp_adj) _hp_adj = _aq;
        }
    }

    for (_s = 0; _s < 2; _s++) {
        var _dir = (_s == 0) ? -1 : 1;
        // ⛔⛔ THE ARM HANGS INBOARD OF THE SHOULDER'S EDGE, AND IT USED TO HANG ON IT. `_shl_x` is
        // the TORSO's half-width at the shoulder - the acromion - and the humerus head sits about
        // an eighth of a shoulder width inside that. With the arm's origin ON the edge, every
        // sleeve was a tube centred on the silhouette, so half its width was added to the figure
        // and the outer edge landed at 1.6 shoulder half-widths. On the donor's store sheets that
        // read as two cardboard wings, and no amount of narrowing the sleeve itself fixes it
        // because the sleeve was in the wrong PLACE. MEASURED 2026-09-02.
        //
        // ⛔⛔ AND `+ _lean * 0.70` IS NOT DECORATION - WITHOUT IT THE ARM HANGS OFF ITS OWN SHOULDER
        // SOCKET. The `shoulder[]` this function RETURNS carries the lean term, and its own header
        // says everything worn on the upper arm anchors on it; this line - the arm's actual root -
        // did not. So on all three leaning poses the drawn arm and the sleeve covering it started
        // from two different places, up to lean*0.70 = 0.0315 of stature apart on `guard`, which is
        // about a third of a shoulder half-width. That is most of why an armoured upper arm read as
        // a slab lying beside the body rather than a sleeve on it. It is the same defect for a
        // work smock, and this product puts a smock on every person in the town.
        //
        // ⭐ FOUND BY THE NEW LATERALITY ASSERTION IN lge_selftest STAGE 2, NOT BY LOOKING - it went
        // red on slight/reach and tall/reach at -0.00265 and -0.00034, the two cases where `reach`'s
        // small outward swing on the idle left arm is narrower than the lean offset, so the elbow
        // ended up displaced INBOARD of its shoulder. The other 23 build/pose pairs hid it because
        // the swing was simply larger than the error. An assertion written for one defect found a
        // second one nobody had seen.
        var _sx = _dir * _shl_x * LGE_ARM_INSET + _lean * 0.70;

        // ⛔⛔ THE DIRECTION WAS APPLIED TWICE AND THEREFORE NOT AT ALL, SO BOTH ARMS SWUNG THE SAME
        // WAY - ON EVERY FIGURE THIS PRODUCT HAS EVER DRAWN. The lines read
        // `sin(_p.sh * _dir) * _dir`, and sin is an ODD function: sin(a*d)*d == sin(a) for d = -1
        // exactly as for d = +1, so the two sides cancelled and both elbows displaced +x by an
        // identical amount. MEASURED by Internal_Ops/_arm_sign_probe.js, which ports these lines
        // and runs them both ways: on 4 of the 5 poses BOTH wrists landed on the +x side of the
        // body, and on `stand` the viewer-left wrist sat at -0.0386 against the viewer-right's
        // +0.1296 - a 3.4x asymmetry on a pose that is meant to be very nearly mirrored.
        //
        // ⭐ WHAT IT LOOKED LIKE IS WHY IT SURVIVED SO LONG. The arm limbs are drawn UNDER the
        // worn layer and the hands ON TOP of it, so the misplaced left
        // arm was invisible and only its HAND showed - as a skin-coloured blob sitting on the
        // centreline of the chest or the hem, on every figure of every store sheet and on the
        // cover. It read as a stain or a pouch, never as an arm in the wrong place, and on `reach`
        // and `guard` it put two hands on the one visible arm.
        //
        // ⚠️ The LEGS below are correct and were the control that named the bug: they apply the
        // direction ONCE, inside the sine, and are the same shape of calculation.
        var _pa = lge_pose_arm(_p, _s);
        // ⛔⛔ THE ARM WAS A PURE PICTURE-PLANE CHAIN, SO EVERY RAISED HAND WAS NECESSARILY A SPREAD
        // ARM - AND THAT MADE 61% OF THE CORPUS A SCARECROW. MEASURED 2026-09-03.
        //
        // `lge_labour_pose` turns a work loop's `height` - how high the HANDS work - into a shoulder
        // angle, `(1 - height) * 1.35` from straight down. These two lines then spent that angle
        // entirely in x and y: `sin(a)` laterally, `cos(a)` vertically, with NO depth term. So the
        // only way this armature could put a hand at bench height was to swing the arm OUT TO THE
        // SIDE, and a figure with both hands at bench height was a figure with both arms held
        // horizontally - which is a scarecrow, whatever the pose table intended.
        //
        // Internal_Ops/_pose_drawn.js ports the whole solve and measures it at the phases the store
        // sheet actually draws: 28 of 46 grid cells had BOTH forearms within the horizontal band,
        // and 19 loops were in it at EVERY phase. It is not one bad archetype - the worst offenders
        // are the LOW-MOTION verbs (`stir` 100%, `hold_still` 100%, `tend_fine` 83%), where the
        // drawn angle collapses onto this base and nothing else moves it.
        //
        // ⭐ NO PARAMETER REACHED IT, WHICH IS THIS WING'S OWN TEST FOR A MODEL DEFECT RATHER THAN A
        // TUNING ONE (see the Chitin wing-shape entry). Four cover bakes were spent re-PICKING which
        // three loops to show, because the picks are what a pick-shaped defect suggests. The corpus
        // was never the problem; the arm had no way to point anywhere but sideways.
        //
        // ⭐ THE FIX IS ONE ROTATION AND IT COSTS NOTHING ELSE. Rotate the whole arm about the body's
        // own vertical axis by `fwd` - i.e. reach IN FRONT of yourself, which is where manual work
        // actually happens. Under that rotation the elbow sits at
        //     x = sin(θ)·cos(fwd)·L      y = cos(θ)·L      z = sin(θ)·sin(fwd)·L   (z is toward the
        // viewer and is not drawn), so the LATERAL extent shrinks by cos(fwd) and the HEIGHT IS
        // UNCHANGED. The hand stays exactly where the work loop said it works; only the arm stops
        // being flung out to reach it, and the shortened limb IS foreshortening, drawn correctly.
        //
        // ⚠️ `_fs` is bounded below (see LGE_ARM_FS_MIN): past about 65 degrees of forward reach the
        // lateral extent collapses far enough that the hand lands ON the chest, and this file already
        // records what that reads as - "a skin-coloured blob sitting on the centreline", the tell of
        // the arm-sign bug above. A foreshortened arm must still be legible as an arm.
        var _fs = lge_arm_foreshorten(_p);
        var _a1 = _pa[0] * _dir;
        var _ex = _sx + sin(_a1) * _upper * _b.limb * _fs;
        var _ey = _shl_y + cos(_a1) * _upper;
        _elb[_s] = [_ex, _ey];

        var _a2 = (_pa[0] + _pa[1]) * _dir;
        _wri[_s] = [_ex + sin(_a2) * _fore * _b.limb * _fs, _ey + cos(_a2) * _fore];

        // ⛔⛔ THE LEGS WERE THE ARMS' BUG, UNFIXED, AND IT CROSSED THE KNEES ON EVERY WALKING AND
        // EVERY SEATED FIGURE THIS PRODUCT HAS DRAWN. The arms were given per-side angles on
        // 2026-09-02 because "the only figure a single pair can describe is bilaterally symmetric";
        // the legs kept `_b1 = _p.hp * _swing`, a mirrored picture-plane rotation, and the lateral
        // arm of that rotation is `sin(hp) * thigh` - which on this figure is 0.0601 of stature
        // against a hip half-width of 0.0677. So a hip angle of 0.34 rad puts a knee ON the centre
        // line and anything above it puts it PAST.
        //
        // MEASURED by Internal_Ops/_leg_probe.js, which ports these four lines and runs all 25
        // build/pose pairs: `sit` CROSSED on all five builds (average knees at +0.0115 and -0.0115,
        // i.e. the viewer-left knee ends up to the RIGHT of the viewer-right one), and the probe's
        // own control - "a walk must show a real stride" - went red at the same time with
        // average/walk knee gap 0.0151 against a stance width of 0.1354. Both legs converge on the
        // midline, which is why `walk` and `sit` on sheet 7 are one dark column with two overlapping
        // feet, and why `sit` reads as a smaller standing person.
        //
        // ⭐ THE ASSERTION THAT FOUND IT WAS THE CONTROL, NOT THE TEST. The probe was written to
        // confirm a suspicion about `sit`; the line at the bottom that exists only to prove the port
        // is live reported the same defect on `walk`, which nobody had suspected. Same shape as this
        // file's own laterality assertion finding a second defect on `reach`.
        //
        // THE MODEL. A stride is a rotation in the SAGITTAL plane - toward and away from the viewer
        // - and a front view sees that as FORESHORTENING, not as sideways travel. So:
        //   * `_ky` keeps `cos(_b1)`, which is the foreshortening and was always right;
        //   * the LATERAL term is damped by `thigh_k`, which is now documented as what it is, and is
        //     small on any pose whose swing is sagittal;
        //   * `splay` is the stance width - how far apart the feet are planted - which is a real,
        //     separate thing a pose has to be able to say, and is what a braced guard and a seated
        //     figure both need;
        //   * angles are PER SIDE (`hp0/kn0`, `hp1/kn1`) exactly like the arms, so a pose can plant
        //     one leg and swing the other instead of scissoring both.
        // `hp`/`kn` with the old alternation remain the fallback, so a pose struct written by hand
        // still solves - see lge_pose_leg.
        var _hx = _dir * _hip_x;
        var _pl = lge_pose_leg(_p, _s);
        // `_hp_adj` is 0 unless the pose declared a hip height - see the solve above. It is added to
        // the KNEE angle as well as the hip so that `_b2` below, which is what points the shin, comes
        // out exactly as authored: rotating the thigh must not swing the shin with it.
        var _b1 = _pl[0] + _hp_adj;
        // ⚠️ THE SHIN'S LATERAL TERM TAKES THE SAME DAMPING AS THE THIGH'S, AND IT USED TO TAKE
        // NONE. An undamped shin under a damped thigh is a leg foreshortened at the top and not at
        // the bottom, which on `guard` put the knees 0.0664 apart and the ankles 0.1345 apart - a
        // knock-kneed stance nobody authored.
        var _kx = _hx + _dir * _splay * _thigh + sin(_b1) * _thigh * _tk;
        var _ky = _hip_y + cos(_b1) * _thigh;
        _kne[_s] = [_kx, _ky];

        // Knee flexion always folds the shin BACK from the thigh's own line, on both sides. Under
        // the old mirrored form this was `_b1 + kn * _swing * -1`, which is the same thing when the
        // sides are mirrored and wrong the moment they are not.
        var _b2 = _b1 - (_pl[1] + _hp_adj);
        _ank[_s] = [_kx + sin(_b2) * _shin * _tk, _ky + cos(_b2) * _shin];
    }

    // ⛔⛔ THE FIGURE STANDS ON ITS LOWEST FOOT. Without this the HIPS stay at standing height and the
    // FEET come up, which is the same defect in every bent-legged pose this product draws.
    //
    // The block above sizes the leg as whatever is left below the hip "so the figure always reaches
    // the sole exactly", and that sentence is true only for a STRAIGHT leg: the ankle is solved as
    // hip + cos(hip)*thigh + cos(shin)*shin, so any bend lands it SHORT. MEASURED 2026-09-03 by
    // Internal_Ops/_stand_probe.js, which ports these four lines and runs every stance on every
    // build: `seated` floats 0.1645 of stature and `kneel` 0.1560, which at the 168px stature the
    // grid sheet draws is 27.6px and 26.2px of clear air under both feet. ELEVEN of the 46 work
    // loops are in it - not the eight the first reading named, because the three `kneel` loops
    // (farrier_rasp, shepherd_shear, washer_beat) float almost as far and nobody had looked at them.
    //
    // ⭐ IT IS GENERAL RATHER THAN SEATED-SPECIFIC, AND THAT IS WHY IT IS HERE AND NOT IN THE STANCE
    // TABLE. Translate the whole figure down by (where a planted ankle belongs) minus (the lowest
    // ankle solved). For a straight-legged pose that is EXACTLY zero - measured at 0.000000000 - so
    // `stand`, `reach` and every square stance are untouched to the last bit. It can never be
    // negative, because cos <= 1 means no bend can push an ankle PAST the plant line.
    //
    // ⚠️ ON `walk` IT INTRODUCES A REAL VERTICAL BOB OF ABOUT 1% OF STATURE, AND THAT IS CORRECT
    // RATHER THAN A SIDE EFFECT. `lge_walk_pose`'s header refuses to ADD a bob, because the figure's
    // position comes from `lge_where` and a second thing moving the body would fight it. This is not
    // that: the body is not being moved, the FOOT is being kept on the ground, and a walking figure
    // whose planted foot floats 1.7px above the road is the defect the refusal was protecting
    // against. Measured range over one cycle: 0.00047..0.01075 of stature.
    //
    // ⛔ `y_sole` DOES NOT MOVE. It is the FLOOR, not a part of the figure - `lge_figure_parts` puts
    // the assembly on the ground by it, and translating it too would put the feet right back in the
    // air by exactly the amount they were just lowered.
    var _seat_y = 0;
    var _dy = (_sole_y - _foot_h) - max(_ank[0][1], _ank[1][1]);
    if (_dy != 0) {
        _top     += _dy;
        _neck_y  += _dy;
        _shl_y   += _dy;
        _waist_y += _dy;
        var _hip_y0 = _hip_y;                 // kept for y_seat, which is a body landmark, below
        _hip_y   += _dy;
        for (_s = 0; _s < 2; _s++) {
            _elb[_s] = [_elb[_s][0], _elb[_s][1] + _dy];
            _wri[_s] = [_wri[_s][0], _wri[_s][1] + _dy];
            _kne[_s] = [_kne[_s][0], _kne[_s][1] + _dy];
            _ank[_s] = [_ank[_s][0], _ank[_s][1] + _dy];
        }
        // The crotch is a fixed distance below the hip on the BODY, so it is re-derived from the
        // figure's own leg run rather than from the floor, which is no longer a fixed distance away.
        _seat_y = _hip_y0 + (_sole_y - _hip_y0) * 0.115 + _dy;
    } else {
        _seat_y = _hip_y + (_sole_y - _hip_y) * 0.115;
    }

    return {
        build: _build_id,
        pose: _pose_id,
        span: _span,
        head:   [_lean * 1.20 + sin(_p.tilt) * _head_r, _top + _head_r],
        head_r: _head_r,
        neck:   [_lean * 0.85, _neck_y],
        // ⚠️ THE SHOULDER JOINT AND THE SHOULDER WIDTH ARE TWO DIFFERENT NUMBERS AND THEY MUST NOT
        // BE CONFLATED. `shoulder[]` is where the ARM hangs from (inset - see LGE_ARM_INSET) and
        // everything worn on the arm anchors on it; `w_shoulder` below is how wide the
        // TORSO is up there, and every worn panel samples THAT. They agreed before this line
        // existed, which is exactly why the sleeves were in the wrong place.
        shoulder: [[-_shl_x * LGE_ARM_INSET + _lean * 0.70, _shl_y],
                   [ _shl_x * LGE_ARM_INSET + _lean * 0.70, _shl_y]],
        elbow: _elb,
        wrist: _wri,
        waist: [_lean * 0.30, _waist_y],
        hip:   [[-_hip_x, _hip_y], [_hip_x, _hip_y]],
        knee: _kne,
        ankle: _ank,
        // The body widths lge_wear samples. Half-widths, in unit space.
        w_shoulder: _shl_x,
        w_waist: _span * 0.062 * _b.hip,
        w_hip: _hip_x,
        // ⛔⛔ `w_hip` IS WHERE THE LEGS ARE HUNG. IT IS NOT HOW WIDE THE BODY IS THERE, AND USING IT
        // FOR BOTH IS WHY EVERY FIGURE THIS PRODUCT HAS EVER DRAWN HAD A HOLE IN IT.
        // lge_torso_ring ended at [±w_hip, y_hip] with a straight edge between them, and the thighs
        // were drawn as tubes hanging off those two corners - so between the legs, from the hip line
        // down, there was nothing at all. On the bare figure, WHATEVER STOOD BEHIND IT SHOWED
        // THROUGH THE HIP (measured 2026-09-02 at 3x on the donor's own store sheet), and on a
        // clothed one the gap ran as a bare column between the two thighs - on a sheet AND ON THE
        // COVER. In a town that means the street shows through a person standing in it.
        //
        // It is the same family as the floating head and the missing feet recorded below, and it
        // survived those two fixes because it is not a missing PART - the torso and both legs were
        // drawn, correctly, and simply did not meet. 1,170 assertions pass over it: turning,
        // simplicity, containment and distinctness are all satisfied by a figure with a hole in it.
        //
        // ⭐ A PELVIS IS A SEPARATE LANDMARK FROM A HIP JOINT. `w_pelvis` is the drawn half-width of
        // the body at the hip - wide enough to meet the outer edge of the thigh where it leaves the
        // socket, so the silhouette has no step in it - and `y_seat` is the crotch, which on a real
        // figure is BELOW the femur head by about a third of a thigh diameter. Both are read by
        // lge_torso_ring (the drawing) and lge_body_halfwidth (what lge_wear samples), so the
        // body and the clothes on it cannot disagree about where the body is.
        w_pelvis: _hip_x + max(LGE_MIN_LIMB_W, _span * 0.026 * _b.limb) * 1.22 * 0.85,
        w_limb: max(LGE_MIN_LIMB_W, _span * 0.026 * _b.limb),
        w_neck: _span * 0.024,
        // The band between the ankle joint and the sole. lge_foot_pts is the only reader.
        foot_h: _foot_h,
        // The solved segment lengths. Published because a pose assertion about FORESHORTENING has to
        // be stated against the segment that is foreshortening - a seated figure lifts its ankle by
        // exactly the part of the thigh the front view stops seeing, so the honest bar on that lift
        // is a fraction of the THIGH and not a fraction of stature somebody picked.
        len_thigh: _thigh,
        len_shin: _shin,
        y_shoulder: _shl_y,
        y_waist: _waist_y,
        y_hip: _hip_y,
        // The crotch. 0.115 of the hip-to-sole run below the hip line puts it at 0.521 of stature on
        // the default build, against the 0.50-0.53 a standing figure actually measures.
        // ⚠️ Solved above, from the figure's own STANDING leg run, so that a seated figure's crotch
        // stays a fixed distance below its hip instead of being re-derived against a floor that is
        // no longer a leg's length away.
        y_seat: _seat_y,
        y_sole: _sole_y,
        // ⛔⛔ WHERE THIS FIGURE'S FEET WOULD BE IF IT STOOD UP - A BODY LANDMARK, NOT THE FLOOR, AND
        // THE TWO ARE ONLY THE SAME THING FOR A FIGURE THAT HAPPENS TO BE STANDING.
        //
        // `y_sole` is the FLOOR. `lge_wear` measured every hem as a fraction of the run from the
        // shoulder to it, which is correct while those two numbers are a body's length apart and
        // wrong the moment the figure sits down: the seat solve above lowers the shoulder and leaves
        // the floor where it is, so the shoulder-to-floor run SHRANK by 0.155 of stature and every
        // garment shortened with it. MEASURED 2026-09-03 by baking and looking - the seated elder,
        // weaver, scribe and tailor all came out in short dresses with bare legs, on the sheet that
        // sells the wear system as a headline feature.
        //
        // ⭐ A GARMENT IS CUT TO THE PERSON, NOT TO THE ROOM. Measured against this landmark a hem
        // lands in the same place on the body whatever the pose, which is the property "change the
        // build and the clothes follow" was always claiming and only accidentally had.
        y_body_sole: _sole_y + _dy,
        y_crown: _top
    };
}

/// ============================================================================================
/// THE BODY OUTLINE
/// ============================================================================================

/// A tapered limb segment as a closed outline.
///
/// ⛔ RETURNS A CLOSED RING, and the caller must treat it as one. lge_geom's header records that a
/// fan never walks the edge from the last point back to the first, so every closed outline in this
/// product is explicitly closed.
///
/// @param {Array} _a [x,y] proximal joint
/// @param {Array} _b [x,y] distal joint
/// @param {Real} _w0 half-width at _a
/// @param {Real} _w1 half-width at _b
/// @returns {Array} closed ring of [x,y]
function lge_limb_ring(_a, _b, _w0, _w1) {
    var _dx = _b[0] - _a[0];
    var _dy = _b[1] - _a[1];
    var _len = sqrt(_dx * _dx + _dy * _dy);
    if (_len <= 0) { _len = 0.0001; _dy = 0.0001; }
    var _nx = -_dy / _len;
    var _ny =  _dx / _len;
    return [
        [_a[0] + _nx * _w0, _a[1] + _ny * _w0],
        [_b[0] + _nx * _w1, _b[1] + _ny * _w1],
        [_b[0] - _nx * _w1, _b[1] - _ny * _w1],
        [_a[0] - _nx * _w0, _a[1] - _ny * _w0]
    ];
}

/// The torso outline: shoulders to hips, waisted.
///
/// Built as an explicit ring rather than a stack of rectangles so that a worn panel can sample it
/// as ONE curve. A torso assembled from boxes produces a hem with corners in it.
///
/// @param {Struct} _arm from lge_armature
/// @returns {Array} closed ring of [x,y]
/// @desc How far the body has leaned, at a given height. THE one reader of the lean, for everything.
///
/// ⛔⛔ WITHOUT THIS, A LEANING FIGURE COMES APART - AND IT SHIPPED THAT WAY INTO THE FIRST THREE
/// BAKED GALLERIES OF THIS PRODUCT. The skeleton leans on a GRADIENT, which is correct and is what
/// makes a lean read as a lean: `lge_armature` puts the head at `lean * 1.20`, the neck at `0.85`,
/// the shoulders at `0.70` and the waist at `0.30`, so the further up the body you go the further
/// over it is. But NOTHING THAT IS ACTUALLY DRAWN read that gradient:
///
///   * `lge_torso_ring` applied the WAIST's offset to exactly 2 of its 21 points and none to the
///     other 19 - so the neck, both shoulders, both hips and the whole pelvis had NO lean at all.
///   * `lge_wear_panel_pts` - the smock, the apron, every worn panel, i.e. the entire VISIBLE
///     torso - is built symmetrically about x = 0 and had no lean term whatsoever.
///
/// So on a leaning pose the drawn body stood bolt upright while the head, neck and both arms
/// translated sideways off it. MEASURED on `potter_wheel` (lean 0.30, the corpus maximum): the head
/// sits at 0.36 statures off centre and the smock at 0.09, leaving the head, neck and one whole arm
/// floating as a DETACHED ISLAND beside a headless smock. Eight of the forty-six loops are seated
/// and lean hardest, and it is on `sheet_2_work_loops` - a sheet whose whole job is to show the
/// corpus off. 164 in-engine assertions were green over it, and it was found by cropping one grid
/// cell to 3x and looking at it.
///
/// ⭐ ONE FUNCTION, EVERY READER - the same law this wing already applies to `lge_work_envelope`. It
/// DERIVES the gradient from the skeleton rather than restating it (the two shoulder x's average to
/// exactly `lean * 0.70`, since the inset is equal and opposite), so it cannot drift away from the
/// numbers in `lge_armature` the way a second copy of them would. Below the waist it ramps to zero
/// at the seat, because feet are planted.
///
/// @param {Struct} _arm from lge_armature
/// @param {Real} _y a height in the same space as the armature's own y's
/// @returns {Real} the x offset to add at that height
function lge_lean_at(_arm, _y) {
    var _lw = _arm.waist[0];
    var _ls = (_arm.shoulder[0][0] + _arm.shoulder[1][0]) * 0.5;
    var _ln = _arm.neck[0];
    var _yn = _arm.neck[1];
    var _ys = _arm.y_shoulder;
    var _yw = _arm.y_waist;
    var _yb = _arm.y_seat;
    if (_y <= _yn) return _ln;
    if (_y <= _ys) return lerp(_ln, _ls, (_y - _yn) / max(0.0001, _ys - _yn));
    if (_y <= _yw) return lerp(_ls, _lw, (_y - _ys) / max(0.0001, _yw - _ys));
    if (_y >= _yb) return 0;
    return lerp(_lw, 0, (_y - _yw) / max(0.0001, _yb - _yw));
}

function lge_torso_ring(_arm) {
    var _sx = _arm.w_shoulder;
    var _wx = _arm.w_waist;
    var _hx = _arm.w_hip;
    var _sy = _arm.y_shoulder;
    var _wy = _arm.y_waist;
    var _hy = _arm.y_hip;

    // ⛔⛔ THE TOP EDGE WAS A STRAIGHT LINE FROM SHOULDER TIP TO SHOULDER TIP, SO THE BARE FIGURE HAD
    // SQUARE SHOULDERS AND A NECK STUCK ON LIKE A CHIMNEY. The ring ran [_sx,_sy] ... [-_sx,_sy] and
    // a fan closes from the last point back to the first, so that closing edge WAS the top of the
    // torso: one horizontal line at full shoulder width, with a 90 degree corner at each end. On the
    // donor's first cell - the bare figure, the one case with nothing worn over it to hide behind -
    // it read as a cardboard box. Found 2026-09-02 by looking at it.
    //
    // ⭐ THE TRAPEZIUS IS PART OF THE TORSO, NOT PART OF THE HEAD. Four points now carry the top
    // edge up from each acromion to the base of the neck, so the silhouette leaves the shoulder as
    // a slope and meets the neck as a curve. This is also what every worn panel samples through
    // lge_body_halfwidth, so the yoke sits on a shoulder that has a shape underneath it.
    var _nkx = _arm.w_neck * 1.50;
    var _nky = _arm.neck[1] + (_sy - _arm.neck[1]) * 0.30;
    var _tr  = (_sy - _nky);

    // ⛔⛔ AND THE BOTTOM EDGE WAS A STRAIGHT LINE FROM HIP TO HIP, WHICH IS THE SAME DEFECT AT THE
    // OTHER END OF THE FIGURE. The ring ran [_hx,_hy] then [-_hx,_hy], so the torso stopped dead at
    // the hip LINE while both thighs hung off those two corners as separate tubes - leaving a gap
    // 0.081 of stature wide running from the hip to the floor with the BACKGROUND showing through it.
    // Found 2026-09-02 by cropping a donor sheet cell to 3x and seeing the coloured panel behind
    // the figure through its own hip. See the w_pelvis header in lge_armature for the full receipt.
    //
    // ⭐ THE PELVIS IS PART OF THE TORSO. Five points carry the ring below the hip line: out to the
    // full pelvis half-width at the hip, down the outer wall, in to the root of each inner thigh at
    // the seat, and up to a crotch apex between them. The apex is ABOVE the two roots, which is what
    // makes it a crotch rather than a point - and it is the one concavity in this outline, so it is
    // shallow on purpose (lge_ring_fill is a triangle fan and this wing's Welkin entry records what
    // a fan does to a concavity it cannot see into; the fan apex here is the WAIST, from which every
    // point below is still directly visible).
    var _sd = _arm.y_seat - _hy;
    var _px = _arm.w_pelvis;

    // Right side down, then left side up. Sampled, not cornered: the mid points are what make the
    // waist read as a curve and give a worn panel something continuous to follow.
    //
    // ⛔ EVERY POINT IS LEANED BY ITS OWN HEIGHT through `lge_lean_at`. This list used to carry a
    // bare `+ _lean` on the two waist points and nothing anywhere else - see that function's header
    // for what that did to a seated figure.
    var _ring = [
        [ _nkx,         _nky],
        [ _sx * 0.62,   _nky + _tr * 0.34],
        [ _sx * 0.88,   _nky + _tr * 0.74],
        [ _sx,          _sy],
        [ _sx * 0.99,   _sy + (_wy - _sy) * 0.34],
        [ _wx * 1.06,   _wy],
        [ _px * 0.94,   _hy - (_hy - _wy) * 0.30],
        [ _px,          _hy],
        [ _px * 0.90,   _hy + _sd * 0.58],
        [ _hx * 0.70,   _hy + _sd],
        [ 0,            _hy + _sd * 0.70],
        [-_hx * 0.70,   _hy + _sd],
        [-_px * 0.90,   _hy + _sd * 0.58],
        [-_px,          _hy],
        [-_px * 0.94,   _hy - (_hy - _wy) * 0.30],
        [-_wx * 1.06,   _wy],
        [-_sx * 0.99,   _sy + (_wy - _sy) * 0.34],
        [-_sx,          _sy],
        [-_sx * 0.88,   _nky + _tr * 0.74],
        [-_sx * 0.62,   _nky + _tr * 0.34],
        [-_nkx,         _nky]
    ];
    for (var _i = 0; _i < array_length(_ring); _i++) {
        _ring[_i][0] += lge_lean_at(_arm, _ring[_i][1]);
    }
    return _ring;
}

/// ============================================================================================
/// THE EXTREMITIES - head, hands and feet
///
/// ⛔⛔ NONE OF THESE EXISTED UNTIL 2026-09-02 AND THE FIGURE READ AS A SHOP DUMMY BECAUSE OF IT.
/// The head was one lge_dot, the hands were a lge_dot of 0.62 limb-widths at the wrist, and the
/// feet were nothing at all. Every mechanical check in the package passed over that for weeks:
/// turning, simplicity, containment, distinctness and the ink floors are all satisfied by a
/// figure with no hands, no feet and a ball for a head. The instrument was opening the PNG.
///
/// ⭐ AND THIS DOES NOT CONTRADICT THE SUBSTRATE RULE AT THE TOP OF THIS FILE - it is what the
/// rule assumed. "The body is a substrate" is an argument against forty DISTINGUISHABLE bodies,
/// because proportion is the first thing to go at reading size. A hand, a foot and a jaw are not
/// identity: they are the difference between a human silhouette and a coat rack, they are the
/// SAME on every build, and they cost one outline each. The rule bars variety here, not anatomy.
/// ============================================================================================

/// The skull outline: an oval that narrows to a jaw.
///
/// ⛔ A CIRCLE IS THE ONE SHAPE A HEAD IS NOT, and the failure is legible at every size. A human
/// head seen head-on is about 0.72 as wide as it is tall and it loses another third of that width
/// between the cheekbone and the chin; a circle has neither property, so it reads as a ball on a
/// stalk - which is exactly what the crowd sheet showed twenty-four times over.
///
/// The taper is spent on the LOWER half only (`max(0, sin a)`), because the cranium really is
/// close to elliptical and narrowing it as well produces an egg standing on its point.
///
/// @param {Struct} _arm from lge_armature
/// @param {Real} _n segment count, or undefined for the default
/// @returns {Array} closed ring of [x,y]
function lge_head_pts(_arm, _n) {
    var _segs = is_undefined(_n) ? 22 : max(8, _n);
    var _r  = _arm.head_r;
    var _rx = _r * 0.855;
    var _hx = _arm.head[0];
    var _hy = _arm.head[1];
    var _out = array_create(_segs);
    var _i;
    for (_i = 0; _i < _segs; _i++) {
        var _a = (_i / _segs) * LGE_TAU;
        var _c = cos(_a);
        var _s = sin(_a);
        // y grows DOWNWARD, so sin > 0 is the jaw half. power() of a negative base is not defined,
        // which is the whole reason for the max().
        var _low = max(0, _s);
        _out[_i] = [_hx + _c * _rx * (1 - 0.40 * power(_low, 1.35)),
                    _hy + _s * _r  * (1 + 0.07 * power(_low, 2.00))];
    }
    return _out;
}

/// One ear. Drawn BEFORE the head so only its outer half survives, which is what an ear is.
///
/// @param {Struct} _arm from lge_armature
/// @param {Real} _side 0 or 1
/// @returns {Array} closed ring of [x,y]
function lge_ear_pts(_arm, _side) {
    var _dir = (_side == 0) ? -1 : 1;
    var _r = _arm.head_r;
    return lge_ellipse_pts(_arm.head[0] + _dir * _r * 0.78, _arm.head[1] + _r * 0.10,
                           _r * 0.20, _r * 0.27, 10);
}

/// Where the TOP of the brow sits, in world y. The one number a hat may not cross.
///
/// ⛔ IT IS DERIVED FROM `lge_face_parts`' OWN CONSTANTS, NOT RESTATED. This wing has a standing row
/// about a checker holding the same stale number as the thing it checks; a brow line written down
/// twice is that row waiting to happen. The inner end of the brow is its highest point
/// (LGE_FACE_BROW_IN > LGE_FACE_BROW_OUT), so that is what a cap has to clear.
///
/// @param {Struct} _arm from lge_armature
/// @returns {Real} world y of the brow's highest point
function lge_face_brow_top(_arm) {
    return _arm.head[1] + _arm.head_r * (LGE_FACE_EYE_Y - LGE_FACE_BROW_IN);
}

/// The face: a brow pair, two eyes and a mouth.
///
/// ⛔ DELIBERATELY THE MINIMUM, AND THE MINIMUM IS NOT ZERO. This product sells clothes, so the
/// face must not compete with them - but a head with no marks at all is not neutral, it is
/// UNCANNY, and twenty-four of them on one store sheet read as shop dummies rather
/// than as a village. Two eyes and a brow is what every 48-pixel sprite in the genre carries and
/// it is legible from four pixels upward.
///
/// ⛔⛔ THE MOUTH WAS ARGUED OUT OF THIS FUNCTION AND THE ARGUMENT WAS ABOUT THE WRONG SIZE. This
/// header used to end "a nose and a mouth are not [legible], and at figure size they collapse into a
/// smudge" - true of a NOSE, which is a form and needs shading, and measured false of a mouth, which
/// is one stroke of exactly the weight the brows already carry and at exactly their length. The
/// price of leaving it out is paid at the other end of the size range: on the store cover a head is
/// ~45px and the whole lower half of it - eyes to chin, 0.995 head-radii - carried NO mark at all,
/// which is the "featureless faces" the Gate 1 review recorded twice. A blank muzzle is not
/// restraint, it is an unfinished drawing.
///
/// ⚠️ NO NOSE, AND THAT HALF OF THE OLD ARGUMENT STANDS. A nose reads only as a shadow, a shadow
/// needs two tones, and two tones on a 8px head at corpus scale is the smudge this header warned of.
///
/// ⚠️ THE ROLE IS NOT FROM THE SKIN RAMP AND THAT IS MEASURED, NOT FUSSY. An `ink` role is defined
/// to CONTRAST with its own material, so on a dark skin it resolves PALE - which would put white
/// eyes on the darker complexions and dark eyes on the lighter ones, in the same town, from one
/// call. `m0` is only one ramp step below the face and gives a smear rather than an eye. So the
/// caller passes a dedicated dark stop in: lge_palette mixes one into every skin palette, and this
/// function takes the role rather than choosing it.
///
/// @param {Struct} _arm from lge_armature
/// @param {String} _role colour role for the marks
/// @returns {Array} part list
function lge_face_parts(_arm, _role) {
    var _r  = _arm.head_r;
    var _hx = _arm.head[0];
    var _hy = _arm.head[1];
    var _ex = _r * 0.355;
    var _ey = _hy + _r * LGE_FACE_EYE_Y;
    var _bw = _r * 0.175;
    var _lw = _r * 0.085;
    // The mouth. `lge_head_pts` puts the chin at +1.07r and the eyes sit at LGE_FACE_EYE_Y, so the
    // mouth is placed as a FRACTION of that span rather than as its own constant - move the head
    // and the mouth moves with it. Two thirds down from the eyes is the classical placement and it
    // is what stops the mark reading as a chin stripe.
    var _my = _ey + (_hy + _r * 1.07 - _ey) * LGE_FACE_MOUTH_T;
    // ⚠️ HALF-WIDTH TAKEN FROM THE JAW AT THAT HEIGHT, NEVER FROM `_r`. `lge_head_pts` tapers the
    // lower head by up to 40%, so a mouth sized off the head's nominal radius runs off the chin on
    // the narrow builds - this wing's standing "a shape is only as wide as its span AT THAT y" law.
    var _jaw = _r * 0.855 * (1 - 0.40 * power(clamp(_my - _hy, 0, _r) / _r, 1.35));
    var _mw  = _jaw * 0.40;
    return [
        lge_dot(_hx - _ex, _ey, _r * 0.105, _role),
        lge_dot(_hx + _ex, _ey, _r * 0.105, _role),
        lge_poly([[_hx - _ex - _bw, _ey - _r * LGE_FACE_BROW_OUT], [_hx - _ex + _bw, _ey - _r * LGE_FACE_BROW_IN]],
                 false, _lw, _role),
        lge_poly([[_hx + _ex - _bw, _ey - _r * LGE_FACE_BROW_IN], [_hx + _ex + _bw, _ey - _r * LGE_FACE_BROW_OUT]],
                 false, _lw, _role),
        lge_poly([[_hx - _mw, _my], [_hx + _mw, _my]], false, _lw, _role)
    ];
}

/// A hand, as a closed mitt along the forearm's own direction.
///
/// ⚠️ NO FINGERS, AND THAT IS THE SAME ARGUMENT AS THE FACE. Fingers are sub-pixel at figure size
/// and read as fringe; the SILHOUETTE - a mass wider than the wrist that closes to a rounded end,
/// with a thumb standing off the body side - is what says hand at every size this ships at.
///
/// @param {Struct} _arm from lge_armature
/// @param {Real} _side 0 or 1
/// @returns {Array} closed ring of [x,y]
function lge_hand_pts(_arm, _side) {
    var _wr = _arm.wrist[_side];
    var _el = _arm.elbow[_side];
    var _dx = _wr[0] - _el[0];
    var _dy = _wr[1] - _el[1];
    var _len = point_distance(0, 0, _dx, _dy);
    // A zero-length forearm cannot happen from lge_armature, but a caller could hand one in and a
    // divide by zero here would poison every point in the ring.
    if (_len <= 0.0001) { _dx = 0; _dy = 1; _len = 1; }
    _dx /= _len;
    _dy /= _len;
    var _nx = -_dy;
    var _ny =  _dx;
    var _l  = _arm.head_r * 0.92;
    var _w  = _arm.w_limb;
    var _w0 = _w * 0.62, _w1 = _w * 0.90, _w2 = _w * 0.80, _w3 = _w * 0.30;
    var _a1 = 0.38, _a2 = 0.76, _a3 = 1.00;
    return [
        [_wr[0] + _nx * _w0, _wr[1] + _ny * _w0],
        [_wr[0] + _dx * _l * _a1 + _nx * _w1, _wr[1] + _dy * _l * _a1 + _ny * _w1],
        [_wr[0] + _dx * _l * _a2 + _nx * _w2, _wr[1] + _dy * _l * _a2 + _ny * _w2],
        [_wr[0] + _dx * _l * _a3 + _nx * _w3, _wr[1] + _dy * _l * _a3 + _ny * _w3],
        [_wr[0] + _dx * _l * _a3 - _nx * _w3, _wr[1] + _dy * _l * _a3 - _ny * _w3],
        [_wr[0] + _dx * _l * _a2 - _nx * _w2, _wr[1] + _dy * _l * _a2 - _ny * _w2],
        [_wr[0] + _dx * _l * _a1 - _nx * _w1, _wr[1] + _dy * _l * _a1 - _ny * _w1],
        [_wr[0] - _nx * _w0, _wr[1] - _ny * _w0]
    ];
}

/// Where the thumb bump sits, as [x, y, r]. Separate from the mitt because a bump welded onto the
/// outline would make it non-star-shaped and lge_ring_fill is a FAN (lge_geom's header).
///
/// ⚠️ THE SIDE MATTERS AND THE SIGN IS NOT OBVIOUS. `n` is the left-hand normal of the forearm, so
/// for an arm hanging down it points toward -x. On the figure's viewer-LEFT arm (side 0, at -x)
/// the body is to the +x side, which is -n; on the viewer-RIGHT arm it is +n.
///
/// @param {Struct} _arm from lge_armature
/// @param {Real} _side 0 or 1
/// @returns {Array} [x, y, r]
function lge_thumb_at(_arm, _side) {
    var _wr = _arm.wrist[_side];
    var _el = _arm.elbow[_side];
    var _dx = _wr[0] - _el[0];
    var _dy = _wr[1] - _el[1];
    var _len = point_distance(0, 0, _dx, _dy);
    if (_len <= 0.0001) { _dx = 0; _dy = 1; _len = 1; }
    _dx /= _len;
    _dy /= _len;
    var _sgn = (_side == 0) ? -1 : 1;
    var _nx = -_dy * _sgn;
    var _ny =  _dx * _sgn;
    var _w = _arm.w_limb;
    return [_wr[0] + _dx * _arm.head_r * 0.30 + _nx * _w * 0.88,
            _wr[1] + _dy * _arm.head_r * 0.30 + _ny * _w * 0.88,
            _w * 0.44];
}

/// A foot, seen head-on: a short splayed wedge from the ankle to the sole.
///
/// ⚠️ A FRONT-VIEW FOOT IS ALMOST ALL WIDTH. Its length runs away from the viewer and is
/// foreshortened to nothing, so drawing it as a long shape is the mistake - what the eye reads is
/// that the leg ENDS in something wider than itself, splayed slightly outward.
///
/// @param {Struct} _arm from lge_armature
/// @param {Real} _side 0 or 1
/// @returns {Array} closed ring of [x,y]
function lge_foot_pts(_arm, _side) {
    var _dir = (_side == 0) ? -1 : 1;
    var _an = _arm.ankle[_side];
    var _h  = _arm.foot_h;
    // ⚠️ WIDER THAN THE ANKLE BY HALF, AND THE FIRST NUMBER WAS TOO TIMID. At 0.74 limb-widths the
    // foot was narrower than the shin above it, so it read as the shin simply stopping - which is
    // the defect it was added to fix, wearing a slightly different shape. A foot is the widest
    // part of the leg from the front.
    var _w  = _arm.w_limb * 1.02;
    var _y1 = _an[1] + _h;
    var _sp = _dir * _w * 0.52;
    return [
        [_an[0] - _w * 0.96,        _an[1] - _h * 0.12],
        [_an[0] + _w * 0.96,        _an[1] - _h * 0.12],
        [_an[0] + _w * 1.02 + _sp * 0.55, _an[1] + _h * 0.52],
        [_an[0] + _w * 0.86 + _sp,  _y1],
        [_an[0] - _w * 0.86 + _sp,  _y1],
        [_an[0] - _w * 1.02 + _sp * 0.55, _an[1] + _h * 0.52]
    ];
}

/// ============================================================================================
/// HAIR
///
/// ⭐ HAIR IS AN ACCESSORY, WHICH IS WHY IT IS ALLOWED HERE AND A SECOND BODY TYPE IS NOT. The
/// header's rule is that variety lives in what is WORN. Hair is worn in every sense that matters
/// to this file: it sits on top of the skull, it has its own material and its own silhouette, a
/// a cap covers it, and it changes nothing about the armature underneath. Eight styles across
/// thirty materials is 240 heads.
///
/// ⛔ AND IT IS THE ANSWER TO THE ONE THING THE CROWD SHEET COULD NOT DO. The listing's claim is
/// that a crowd of NPCs all look like themselves; before this, twenty-four villagers differed
/// only in the four hide materials the skin is drawn from, so a third of them were the same pale
/// bald head and the sheet read as a rack of dummies rather than as a village.
/// ============================================================================================

/// The hair style ids, in a stable order.
///
/// ⛔ THE ORDER IS PART OF THE PRODUCT - lge_selftest counts the corpus from this list and the
/// listing quotes that number.
function lge_hair_styles_all() {
    return ["crop", "bob", "long", "bound", "braid", "tonsure", "wild", "bald"];
}

/// How a style is built.
///
/// `drop` is how far past the ear line the mass hangs, in radians of the skull sweep; `thick` and
/// `line` are fractions of head_r - `thick` is the standoff from the skull and `line` is how far
/// the hairline sits below the crown, which is what separates a full head of hair from a tonsure.
///
/// @param {String} _id one of lge_hair_styles_all()
/// @returns {Struct} the spec
function lge_hair_spec(_id) {
    switch (_id) {
        // ⛔⛔ EVERY STYLE BUT `wild` CARRIED jag 0.00, AND A ZERO-JAG HAIR MASS IS A HELMET.
        // The outer rail is a smooth offset of the skull, so with no jag the silhouette is a perfect
        // dome - and on the 2026-09-02 equip bake all six figures read as wearing a red knitted
        // beanie. Nothing was wrong with the shading; the OUTLINE was the tell, because no head of
        // hair on any person has a mathematically smooth edge.
        //
        // ⭐ A LITTLE ON EVERY STYLE, AND STILL FAR LESS THAN `wild`. The two-frequency ripple in
        // lge_hair_band is seeded off u, so this is deterministic per style and costs nothing: the
        // edge simply stops being a circle. `bound` gets the least because it IS a tight style, and
        // `tonsure` gets the least of all because a shaved crown has a razor line, not a fringe.
        //                    drop   thick   line   bun   braid  back   jag
        case "bob":     return { drop: 1.05, thick: 0.150, line: 0.60, bun: 0.00, braid: false, back: 0.00, jag: 0.20 };
        case "long":    return { drop: 1.18, thick: 0.155, line: 0.62, bun: 0.00, braid: false, back: 0.72, jag: 0.22 };
        case "bound":   return { drop: 0.18, thick: 0.115, line: 0.66, bun: 0.36, braid: false, back: 0.00, jag: 0.14 };
        case "braid":   return { drop: 0.44, thick: 0.130, line: 0.60, bun: 0.00, braid: true,  back: 0.00, jag: 0.18 };
        case "tonsure": return { drop: 0.74, thick: 0.115, line: 0.10, bun: 0.00, braid: false, back: 0.00, jag: 0.08 };
        case "wild":    return { drop: 0.50, thick: 0.185, line: 0.58, bun: 0.00, braid: false, back: 0.00, jag: 0.60 };
        case "bald":    return { drop: 0.00, thick: 0.000, line: 0.00, bun: 0.00, braid: false, back: 0.00, jag: 0.00 };
        default:        return { drop: 0.22, thick: 0.120, line: 0.62, bun: 0.00, braid: false, back: 0.00, jag: 0.24 };
    }
}

/// The two rails of the hair mass, as {outer, inner} arrays of equal length.
///
/// ⛔ IT IS A STRIP AND IT CANNOT BE A FAN. Hair is a CRESCENT - a band following the skull with
/// the face cut out of the middle of it - and the wing constitution records exactly what happens
/// when a crescent is handed to lge_render_fill: the fan spans the concavity and the moon phase
/// that was supposed to be a crescent renders as a quarter. Two rails and lge_strip are exact.
///
/// The sweep runs left to right THROUGH THE TOP: angle -pi is the figure's viewer-left horizon,
/// -pi/2 is the crown, 0 is the right horizon, and extending the ends past those by `drop` is what
/// brings a bob down past the jaw without a second construction.
///
/// @param {Struct} _arm from lge_armature
/// @param {Struct} _sp from lge_hair_spec
/// @returns {Struct} {outer, inner}
function lge_hair_band(_arm, _sp) {
    var _r  = _arm.head_r;
    var _rx = _r * 0.855;
    var _hx = _arm.head[0];
    var _hy = _arm.head[1];
    var _t  = _r * _sp.thick;
    var _n  = 26;
    var _outer = array_create(_n + 1);
    var _inner = array_create(_n + 1);
    var _i;
    for (_i = 0; _i <= _n; _i++) {
        var _u = _i / _n;
        var _a = lerp(-pi - _sp.drop, _sp.drop, _u);
        var _c = cos(_a);
        var _s = sin(_a);
        var _low = max(0, _s);
        var _tap = 1 - 0.40 * power(_low, 1.35);
        var _dpy = 1 + 0.07 * power(_low, 2.00);
        var _sx = _hx + _c * _rx * _tap;
        var _sy = _hy + _s * _r  * _dpy;
        // Outward normal of the skull at this station, normalised so `thick` is a real distance
        // rather than a fraction of whichever radius happens to dominate here.
        var _ox = _c * _tap;
        var _oy = _s * _dpy;
        var _ol = max(0.0001, point_distance(0, 0, _ox, _oy));
        // A ragged edge for `wild`, driven by u so it is identical on every redraw. Two
        // frequencies rather than one: a single sine is a scallop and reads as a wig.
        var _jag = _sp.jag * _t * sin(_u * 17.0) * sin(_u * 6.0);
        _outer[_i] = [_sx + (_ox / _ol) * (_t + _jag), _sy + (_oy / _ol) * (_t + _jag)];
        _inner[_i] = [_sx, _sy + _r * _sp.line * power(sin(pi * _u), 1.25)];
    }
    return { outer: _outer, inner: _inner };
}

/// A sub-range of a rail, as its own array. Used to put the sheen on the lit side only.
function lge_rail_slice(_pts, _u0, _u1) {
    var _n = array_length(_pts);
    var _a = clamp(floor(_n * _u0), 0, _n - 2);
    var _b = clamp(ceil(_n * _u1), _a + 1, _n - 1);
    var _out = array_create(_b - _a + 1);
    var _i;
    for (_i = _a; _i <= _b; _i++) _out[_i - _a] = _pts[_i];
    return _out;
}

/// Hair drawn IN FRONT of the head.
///
/// @param {Struct} _arm from lge_armature
/// @param {String} _style one of lge_hair_styles_all()
/// @param {Struct} _roles {face, shade, line} - the three colour roles the hair draws in
/// @returns {Array} part list
function lge_hair_parts(_arm, _style, _roles) {
    var _sp = lge_hair_spec(_style);
    var _out = [];
    if (_sp.thick <= 0) return _out;

    var _r = _arm.head_r;
    var _b = lge_hair_band(_arm, _sp);
    var _n = array_length(_b.outer);
    var _i;

    // The knot first: it sits behind the crown, so the band's own outline covers where it meets
    // the skull and it reads as gathered rather than as a ball balanced on top.
    if (_sp.bun > 0) {
        array_push(_out, lge_dot(_arm.head[0], _arm.head[1] - _r * (0.86 + _sp.bun * 0.30),
                                 _r * _sp.bun, _roles.face));
        array_push(_out, lge_dot(_arm.head[0] - _r * _sp.bun * 0.34,
                                 _arm.head[1] - _r * (0.98 + _sp.bun * 0.44),
                                 _r * _sp.bun * 0.40, _roles.shade));
    }

    array_push(_out, lge_strip(_b.outer, _b.inner, _roles.face));

    // TWO TONES, AND FLAT HAIR IS WHY THE FIRST DRAFT READ AS A HELMET. The mass is darkest where
    // it turns under at the hairline and brightest along the lamp side of the crown - the lamp is
    // up and to the LEFT (lge_relief), so the sheen is on the left half of the sweep and nowhere
    // else. A rim highlight all the way round is a halo, which this product already shipped once.
    var _dk0 = array_create(_n);
    var _dk1 = array_create(_n);
    var _hi0 = array_create(_n);
    var _hi1 = array_create(_n);
    for (_i = 0; _i < _n; _i++) {
        var _o = _b.outer[_i];
        var _q = _b.inner[_i];
        _dk0[_i] = [lerp(_o[0], _q[0], 0.66), lerp(_o[1], _q[1], 0.66)];
        _dk1[_i] = [_q[0], _q[1]];
        _hi0[_i] = [lerp(_o[0], _q[0], 0.10), lerp(_o[1], _q[1], 0.10)];
        _hi1[_i] = [lerp(_o[0], _q[0], 0.32), lerp(_o[1], _q[1], 0.32)];
    }
    array_push(_out, lge_strip(_dk0, _dk1, _roles.shade));
    // ⛔ THE SHEEN WAS "m4" AND IT WAS THE SINGLE WORST MARK ON THE FIGURE. A broad slab of the
    // brightest ramp stop laid across the crown of a smooth dome is what a moulded plastic helmet
    // looks like - on the equip sheet of 2026-09-02 every one of the six figures appeared to be
    // wearing a red swim cap, and the hair was the first thing the eye went to for the wrong reason.
    // m3 is one stop down and still reads as the lit side of the head.
    array_push(_out, lge_strip(lge_rail_slice(_hi0, 0.16, 0.50), lge_rail_slice(_hi1, 0.16, 0.50),
                               "m3"));

    // ⭐ STRANDS. Gate 1's holdsUpBeside answer on 2026-09-02 named "no fine linework" as one of the
    // three reasons the figures read as schematic, and hair is where that costs the most: a mass of
    // one tone with a highlight on it is a shape, and it takes very little line to make it fibrous.
    // Seven strokes, each following the band at its own depth and over its own arc of the sweep, so
    // no two are parallel for their whole length and none reaches either end of the mass - a strand
    // that runs the full sweep is a contour line and reads as a seam.
    //
    // ⚠️ THEY ARE SAMPLED OFF THE SAME TWO RAILS AS EVERYTHING ELSE HERE, so a jagged `wild` head
    // gets jagged strands and a bob gets smooth ones, with no second construction to keep in step.
    // ⚠️ FIVE SHALLOW SHORT ONES, NOT SEVEN LONG DEEP ONES. The first version ran strands at depths
    // up to 0.71 of the band across two thirds of the sweep, and the sweep is a CONTOUR AROUND THE
    // SKULL - so long strokes at even depths read as the wraps of a turban, which is what the
    // 2026-09-02 pose bake showed. A strand has to be short enough that the eye reads it as one lock
    // rather than as a band, and shallow enough that it stays in the outer surface of the mass
    // instead of crossing the hairline onto the forehead.
    var _sn = 5;
    var _u0, _u1, _dep, _st, _q;
    for (_i = 0; _i < _sn; _i++) {
        _u0 = 0.10 + (_i * 0.155);
        _u1 = min(0.94, _u0 + 0.13 + (_i mod 3) * 0.045);
        _dep = 0.12 + ((_i mod 4) * 0.075);
        _st = array_create(_n);
        for (_q = 0; _q < _n; _q++) {
            _st[_q] = [lerp(_b.outer[_q][0], _b.inner[_q][0], _dep),
                       lerp(_b.outer[_q][1], _b.inner[_q][1], _dep)];
        }
        array_push(_out, lge_poly(lge_rail_slice(_st, _u0, _u1), false, _arm.span * 0.0028,
                                  ((_i mod 2) == 0) ? _roles.line : "m4"));
    }

    array_push(_out, lge_poly(_b.outer, false, _arm.span * 0.004, _roles.line));

    return _out;
}

/// Hair drawn BEHIND the body - the fall of a long style down the back.
///
/// ⚠️ A SEPARATE FUNCTION RATHER THAN A FLAG, because the caller has to put the two halves in two
/// different places in the part list and a single builder returning both would have to be split
/// by its caller anyway - the same argument lge_wear makes for anything worn behind the body.
///
/// @param {Struct} _arm from lge_armature
/// @param {String} _style one of lge_hair_styles_all()
/// @param {Struct} _roles {face, shade, line}
/// @returns {Array} part list
function lge_hair_back_parts(_arm, _style, _roles) {
    var _sp = lge_hair_spec(_style);
    if (_sp.back <= 0) return [];

    var _r  = _arm.head_r;
    var _y0 = _arm.head[1] - _r * 0.30;
    var _y1 = lerp(_arm.y_shoulder, _arm.y_hip, _sp.back);
    var _w0 = _r * 0.88;
    var _w1 = _arm.w_shoulder * 0.82;
    var _cx = _arm.head[0];
    var _n  = 9;
    var _right = array_create(_n + 1);
    var _left  = array_create(_n + 1);
    var _i;
    for (_i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        var _y = lerp(_y0, _y1, _t);
        // Widens fast at the shoulders and then holds, which is how hair falls; a straight lerp
        // gives a cone and reads as a cape.
        var _w = lerp(_w0, _w1, power(_t, 0.62));
        _right[_i] = [_cx + _w, _y];
        _left[_i]  = [_cx - _w, _y];
    }
    var _ring = [];
    for (_i = 0; _i <= _n; _i++) array_push(_ring, _right[_i]);
    // A rounded fall rather than a cut edge.
    array_push(_ring, [_cx + _w1 * 0.62, _y1 + _r * 0.26]);
    array_push(_ring, [_cx,              _y1 + _r * 0.36]);
    array_push(_ring, [_cx - _w1 * 0.62, _y1 + _r * 0.26]);
    for (_i = _n; _i >= 0; _i--) array_push(_ring, _left[_i]);

    // A shadow down the centre of the fall, where the mass turns away on both sides. Two rails
    // rather than a polyline: a stroke of fixed width would not widen with the hair.
    var _sh0 = array_create(_n + 1);
    var _sh1 = array_create(_n + 1);
    for (_i = 0; _i <= _n; _i++) {
        var _u = _i / _n;
        var _hw = lerp(_w0, _w1, power(_u, 0.62)) * 0.30;
        var _yy = lerp(_y0, _y1, _u);
        _sh0[_i] = [_cx - _hw, _yy];
        _sh1[_i] = [_cx + _hw, _yy];
    }

    return [
        lge_ring_fill(_ring, _roles.face, _cx, lerp(_y0, _y1, 0.5)),
        lge_strip(lge_rail_slice(_sh0, 0.22, 1.00), lge_rail_slice(_sh1, 0.22, 1.00), _roles.shade),
        lge_poly(_ring, true, _arm.span * 0.004, _roles.line)
    ];
}

/// The whole figure as a part list, ready for lge_render.
///
/// ⚠️ THIS IS A SUBSTRATE, NOT A CHARACTER. It exists so lge_wear has something to hang on, and so
/// the demo can show the body under the workwear. On a clothed townsperson most of it is occluded -
/// which is why this file may never be the only thing a store sheet shows.
///
/// @param {Struct} _arm from lge_armature
/// @param {String} _skin_role colour role for flesh, usually "m2"
/// @returns {Array} part list
/// ⭐ ONE SEGMENT OF A LIMB, AS A LIT TUBE RATHER THAN AS A FLAT PATCH.
///
/// ⛔⛔ EVERY LIMB IN THE DONOR PRODUCT WAS A SINGLE FLAT FILL UNTIL 2026-09-02, and it is most of
/// why its Gate 1 answered "the figures are schematic". An arm drawn as one colour is a shape, not a
/// limb: nothing in it says which way the light comes from, so the elbow, the wrist and the hand
/// read as separate stickers laid on the same plane. The relief layer that fixes it - the lamp, the
/// normals, the five-stop ramp - was already in that package and was reaching only its hard-surface
/// layer. It ships here already wired to the limbs, which is one of the reasons to port rather than
/// rewrite.
///
/// ⚠️ BANDS, NOT lge_dome - see lge_tube_bands' header for what the isotropic version does to a
/// long form. Seven bands is where the ramp stops stop being individually countable at hero size
/// and still cost one strip each.
///
/// @param {Array} _a proximal joint
/// @param {Array} _b distal joint
/// @param {Real} _w0 half-width at _a
/// @param {Real} _w1 half-width at _b
/// @param {String} _role the flat field's role
/// @returns {Array} part list
function lge_limb_parts(_a, _b, _w0, _w1, _role) {
    var _ring = lge_limb_ring(_a, _b, _w0, _w1);
    var _out = [lge_fill(_ring, _role)];
    var _r = lge_limb_rails(_ring);
    return lge_append(_out, lge_tube_bands(_r.a, _r.b, 7));
}

/// A JOINT, as a lit ball rather than as a flat disc.
///
/// ⚠️ AN ELLIPSE AND A DOME RATHER THAN lge_dot, AND THE REASON IS THE SEGMENTS EITHER SIDE OF IT.
/// Once a limb is shaded, a flat circle laid over the seam between two shaded tubes is the most
/// visible thing on the figure - a bright coin at every elbow and knee. A dome on the same outline
/// costs a handful of quads and reads as the joint it is standing in for.
///
/// @param {Array} _at [x,y] joint centre
/// @param {Real} _r radius
/// @param {String} _role the flat field's role
/// @returns {Array} part list
function lge_joint_parts(_at, _r, _role) {
    return lge_mass(lge_ellipse_pts(_at[0], _at[1], _r, _r, 10), 0.62, 2, _role);
}

function lge_body_parts(_arm, _skin_role) {
    var _role = is_undefined(_skin_role) ? "m2" : _skin_role;
    var _out = [];
    var _w = _arm.w_limb;
    var _s;

    // Legs first so the torso overlaps them at the hip. The foot is drawn BEFORE its own shin so
    // the shin's distal end covers the ankle join rather than sitting on top of a visible seam.
    for (_s = 0; _s < 2; _s++) {
        lge_append(_out, lge_mass(lge_foot_pts(_arm, _s), 0.52, 2, _role));
        lge_append(_out, lge_limb_parts(_arm.hip[_s], _arm.knee[_s], _w * 1.22, _w * 0.94, _role));
        lge_append(_out, lge_limb_parts(_arm.knee[_s], _arm.ankle[_s], _w * 0.94, _w * 0.70, _role));
        lge_append(_out, lge_joint_parts(_arm.knee[_s], _w * 0.94, _role));
    }

    // Torso.
    //
    // ⚠️ THE FAN APEX IS PASSED EXPLICITLY AND THE DOME IS APPENDED SEPARATELY, rather than going
    // through lge_mass. The torso ring is WAISTED, so it is not convex and its centroid is not a
    // safe fan apex - that is why this call named one in the first place. Scaling about the centroid
    // is still safe (a waisted ring stays star-shaped about it), so the dome itself is fine.
    var _t = lge_torso_ring(_arm);
    array_push(_out, lge_ring_fill(_t, _role, _arm.waist[0], _arm.y_waist));
    lge_append(_out, lge_form_dome(_t, 0.44, 3));

    // Arms.
    for (_s = 0; _s < 2; _s++) {
        lge_append(_out, lge_limb_parts(_arm.shoulder[_s], _arm.elbow[_s], _w * 1.05, _w * 0.86, _role));
        lge_append(_out, lge_limb_parts(_arm.elbow[_s], _arm.wrist[_s], _w * 0.86, _w * 0.66, _role));
        // ⛔ THE SHOULDER CAP SITS BELOW THE SHOULDER LINE, NOT ON IT, AND THAT IS A COVERAGE FACT
        // RATHER THAN AN ANATOMICAL ONE. Everything worn in this package begins at y_shoulder,
        // because lge_body_halfwidth returns 0 above it - so a joint cap CENTRED on that line always
        // puts its top half where nothing worn can ever reach, and it drew two bare skin balls floating
        // above the collar of every clothed figure the DONOR product had produced. Found 2026-09-02
        // by looking at its pose sheet; a suite cannot see it, for the same reason it could not see
        // the floating head.
        // Offsetting the centre down by the cap's own radius makes the cap TANGENT to the shoulder
        // line: the joint is still filled for the arm that starts there, and nothing protrudes into
        // the uncoverable band. On a bare figure this reads as a deltoid rather than a knob.
        lge_append(_out, lge_joint_parts([_arm.shoulder[_s][0], _arm.shoulder[_s][1] + _w * 1.05],
                                         _w * 1.05, _role));
        lge_append(_out, lge_joint_parts(_arm.elbow[_s], _w * 0.86, _role));
        lge_append(_out, lge_joint_parts(_arm.wrist[_s], _w * 0.62, _role));
    }

    // Neck and head.
    //
    // ⛔⛔ THE HEAD FLOATED OFF THE BODY ON EVERY FIGURE THIS PRODUCT HAS EVER DRAWN, AND 890
    // GREEN ASSERTIONS NEVER SAW IT. Found 2026-09-02 by baking the store sheets and LOOKING at
    // them: a tan circle hanging above the shoulders with a band of background between it and the
    // torso, in all five poses and all three cover figures.
    //
    // The arithmetic, and it is exact. The neck JOINT sits at neck_y = top + head_r*2.05, the
    // shoulder line at shl_y = neck_y + span*0.038 (line 139). This ring used to run from the neck
    // JOINT up into the head, so it occupied [head_c + 0.6*head_r, neck_y] and stopped dead at
    // neck_y - while the torso does not begin until shl_y. That leaves exactly `span * 0.038` of
    // nothing between the bottom of the neck and the top of the body: the gap is not an accident of
    // rounding, it is a term in the landmark table being drawn by nobody.
    //
    // ⭐ SO THE NECK IS A COLUMN THAT ENDS INSIDE THE TORSO, NOT AT A JOINT. It runs from BELOW the
    // shoulder line - far enough that the torso ring and any collar overlap it - up into the head.
    // The joint stays where it is because lge_wear samples it for collars; only the drawing changed.
    // A neck that stops at its own joint is anatomically tidy and visibly broken.
    //
    // ⚠️ NOTHING MECHANICAL COULD HAVE CAUGHT THIS, and that is the point. Every assertion in the
    // suite is about turning, containment, distinctness or spacing, and a figure satisfies all four
    // of those while its head is not attached to it. The instrument is the PNG.
    var _neck_base = [_arm.neck[0], _arm.y_shoulder + _arm.span * 0.020];
    lge_append(_out, lge_limb_parts(_neck_base,
                                    [_arm.head[0], _arm.head[1] + _arm.head_r * 0.6],
                                    _arm.w_neck * 1.18, _arm.w_neck * 0.92, _role));
    // Ears BEFORE the skull, so the skull's own fill trims each one to the half that sticks out.
    array_push(_out, lge_ring_fill(lge_ear_pts(_arm, 0), _role, undefined, undefined));
    array_push(_out, lge_ring_fill(lge_ear_pts(_arm, 1), _role, undefined, undefined));
    // ⭐ THE SKULL IS THE ONE MASS THAT MUST READ AS ROUND, and it was a flat oval.
    //
    // ⛔ AND IT IS THE ONE MASS THAT MUST BE SHADED LEAST, WHICH IS THE OPPOSITE OF THE FIRST GUESS.
    // A dome at k 0.66 over 3 steps on a 22-gon puts five hard ramp bands across a face, and the
    // 2026-09-02 bake showed exactly that: a straight-edged shadow wedge down the middle of every
    // head, which reads as damage rather than as form. A face is the one place a viewer knows what
    // the shape is, so it needs the least help and punishes a wrong band the most.
    //
    // 34 points rather than 22 halves the facet size at hero scale; k 0.30 over 2 steps keeps the
    // tone to a rim that turns the oval into a ball and leaves the whole front of the face at the
    // face value, where the brows and eyes are read.
    lge_append(_out, lge_mass(lge_head_pts(_arm, 34), 0.30, 2, _role));

    return _out;
}

/// The hands, as their own part list.
///
/// ⛔ SEPARATE FROM lge_body_parts BECAUSE OF DRAW ORDER, NOT TIDINESS. Everything worn draws over
/// the body, so a hand emitted with the body is UNDER a wrist-length sleeve - and a work smock's
/// sleeve reaches the wrist. The first version of the mitt was therefore invisible on exactly the
/// figures most likely to be on a store sheet, which here is everyone holding a tool.
///
/// Nothing lge_wear puts on a townsperson is a glove, so a hand is never covered and belongs at the
/// very end of the list. If a glove is ever added it becomes an item like any other and takes the
/// slot; that is the same answer, not a different one.
///
/// @param {Struct} _arm from lge_armature
/// @param {String} _skin_role colour role for flesh
/// @returns {Array} part list
function lge_hand_parts(_arm, _skin_role) {
    var _role = is_undefined(_skin_role) ? "m2" : _skin_role;
    var _out = [];
    var _s;
    for (_s = 0; _s < 2; _s++) {
        // The thumb goes down first so the mitt's own fill covers where it joins.
        var _th = lge_thumb_at(_arm, _s);
        lge_append(_out, lge_joint_parts([_th[0], _th[1]], _th[2], _role));
        // ⚠️ THE FAN CENTRE IS THE CENTROID, NOT THE WRIST. The wrist sits ON the mitt's base edge,
        // and a fan from a point on the boundary is only safe while the shape stays convex - which
        // is a promise a later edit to lge_hand_pts would break silently. lge_mass uses the centroid
        // for exactly that reason, so this is the same choice stated once instead of twice.
        lge_append(_out, lge_mass(lge_hand_pts(_arm, _s), 0.58, 2, _role));
    }
    return _out;
}

/// ============================================================================================
/// SAMPLING - what everything worn is built on
/// ============================================================================================

/// The half-width of the BODY at a given height, in unit space.
///
/// ⭐ THIS IS THE FUNCTION THE WHOLE PRODUCT RESTS ON, and it is the one thing a layered PNG cannot
/// do: it lets a worn panel know how wide the body is where it happens to fall, so a hem sits on
/// the figure instead of being pasted at a fixed size. Change the build and the clothes follow,
/// because everything worn asks this.
///
/// Returns 0 above the shoulders and below the sole, so a panel that overshoots degrades to
/// nothing rather than to a spike.
///
/// @param {Struct} _arm from lge_armature
/// @param {Real} _y height in unit space
/// @returns {Real} half-width of the body at that height
function lge_body_halfwidth(_arm, _y) {
    if (_y < _arm.neck[1] || _y > _arm.y_sole) return 0;

    // ⛔⛔ THE BODY HAD NO WIDTH BETWEEN THE NECK AND THE SHOULDER, SO NO GARMENT COULD REACH UP
    // THERE, SO ALL 46 TOWNSPEOPLE WORE THEIR SMOCKS OFF THE SHOULDER.
    //
    // This function used to return 0 above `y_shoulder`, and `lge_wear_smock_parts` starts its panel
    // at exactly `y_shoulder` because anything higher pinched to the width floor and drew a collar as
    // a spike. The two facts together mean the garment's top edge is a straight horizontal cut across
    // the chest at the shoulder line, with the collarbone, the trapezius and the whole upper chest
    // bare above it. MEASURED 2026-09-03 by cropping the cover's left figure to 3x and looking: it is
    // a tabard hung on a mannequin, not a person in clothes, and it is on every figure of every sheet.
    //
    // ⭐ THE NECK IS A PART OF THE BODY AND IT HAS A WIDTH. Between the neck joint and the shoulder
    // line the body runs from about a neck's width out to the full shoulder - that is the trapezius,
    // and it is the shape a collar sits on. Publishing it here lets a garment be cut with a yoke
    // instead of a straight edge, and it is a REAL body fact rather than a number invented to let the
    // clothes move: `lge_torso_ring` already draws the body up to the neck.
    //
    // ⚠️ 1.55 rather than 1.0 because `w_neck` is the neck's own half-width and the base of the neck
    // where it meets the shoulders is wider than the column above it. Sampled at the neck itself the
    // panel is narrow, which is what a collar is.
    if (_y < _arm.y_shoulder) {
        var _tn = (_y - _arm.neck[1]) / max(0.00001, _arm.y_shoulder - _arm.neck[1]);
        return lerp(_arm.w_neck * 1.55, _arm.w_shoulder, _tn);
    }

    if (_y <= _arm.y_waist) {
        var _t = (_y - _arm.y_shoulder) / max(0.00001, _arm.y_waist - _arm.y_shoulder);
        return lerp(_arm.w_shoulder, _arm.w_waist * 1.06, _t);
    }
    // ⛔ `w_hip` IS THE JOINT, `w_pelvis` IS THE BODY, AND THIS FUNCTION WANTS THE BODY. Sampling the
    // joint here made every worn panel 0.027 of stature narrower at the hip than the figure inside it,
    // which is the other half of the pelvis defect: even once the torso ring closes the crotch, a
    // smock cut to w_hip leaves the top of both thighs standing outside its own silhouette. The two
    // numbers now come from one place and the clothes cannot disagree with the body.
    if (_y <= _arm.y_hip) {
        var _t2 = (_y - _arm.y_waist) / max(0.00001, _arm.y_hip - _arm.y_waist);
        return lerp(_arm.w_waist * 1.06, _arm.w_pelvis, _t2);
    }
    // Below the hip the "body" is two legs. A long smock hangs over the PAIR, so the relevant
    // half-width is the outer edge of the outer leg, not one limb.
    var _t3 = (_y - _arm.y_hip) / max(0.00001, _arm.y_sole - _arm.y_hip);
    var _outer = max(abs(_arm.knee[0][0]), abs(_arm.knee[1][0]), abs(_arm.ankle[0][0]), abs(_arm.ankle[1][0]));
    return lerp(_arm.w_pelvis, max(_arm.w_limb * 1.3, _outer + _arm.w_limb), _t3 * 0.72);
}
