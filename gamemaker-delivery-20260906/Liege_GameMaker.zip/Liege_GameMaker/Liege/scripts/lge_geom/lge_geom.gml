/// ============================================================================================
/// LIEGE — GEOMETRY PRIMITIVES
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// The shared drawing vocabulary: every mass, ribbon, ring and outline in this package is built
/// from these, so a fix here reaches the figure, the props and the store sheets at once.
///
/// ⚠️ PORTED FROM THIS WING's `gm-raiment`. The arithmetic has been corrected against baked
/// sheets in five shipped products and every correction is documented in place. Do not "tidy" a
/// comment that names a defect - it is the only thing standing between this file and that defect
/// returning.
///
/// ⛔ `lge_fill` IS A TRIANGLE FAN and requires an outline that is STAR-SHAPED ABOUT pts[0]. Hand
/// it a concave outline - a stall awning, a loom frame, a C-shaped hook - and it spans the
/// concavity silently, with no error and no failed assertion. Use `lge_strip` for a rail pair, or
/// decompose the shape.
///
/// ============================================================================================

#macro LGE_VERSION "1.0.0"

#macro LGE_DOT   0
#macro LGE_ARC   1
#macro LGE_POLY  2
#macro LGE_FILL  3
#macro LGE_STRIP 4

#macro LGE_TAU    6.283185307179586

/// ⛔ THE DONOR'S FLOOR CONSTANTS ARE DELETED HERE, NOT RENAMED, AND THAT IS THE POINT.
/// The two previous products in this line each carried a fixed GROUND constant with a long
/// comment repurposing it: a geological ground in one, a mounting depth for clock furniture in the
/// next. Neither survived contact with this subject, because a FIGURE already owns its own floor -
/// lge_armature's LGE_SOLE is where the feet are, it moves with the build's stature, and a second
/// fixed constant claiming to be the ground could only ever disagree with it.
///
/// Measured before deleting: zero references anywhere in the package. A repurposed constant nobody
/// calls is a comment pretending to be code, and this one was still describing clock furniture.

/// ============================================================================================
/// PART CONSTRUCTORS
/// ============================================================================================

/// A filled circle.
function lge_dot(_cx, _cy, _r, _role) {
    return { kind: LGE_DOT, cx: _cx, cy: _cy, r: _r, role: _role };
}

/// A sampled, stroked arc. Angles in radians, y-down (angle 0 = +x, pi/2 = down).
function lge_arc(_cx, _cy, _r, _a0, _a1, _w, _role) {
    return { kind: LGE_ARC, cx: _cx, cy: _cy, r: _r, a0: _a0, a1: _a1, w: _w, role: _role };
}

/// A stroked polyline. _pts is an array of [x,y].
function lge_poly(_pts, _closed, _w, _role) {
    return { kind: LGE_POLY, pts: _pts, closed: _closed, w: _w, role: _role };
}

/// A triangle FAN. See the header: the outline must be star-shaped about pts[0].
function lge_fill(_pts, _role) {
    return { kind: LGE_FILL, pts: _pts, role: _role };
}

/// A triangle STRIP between two polylines of equal length.
function lge_strip(_a, _b, _role) {
    return { kind: LGE_STRIP, a: _a, b: _b, role: _role };
}

/// A full stroked circle. An arc, not a primitive of its own - GML's draw_circle outline ignores
/// line width, and width carries meaning across this whole corpus.
function lge_ring(_cx, _cy, _r, _w, _role) {
    return lge_arc(_cx, _cy, _r, 0, LGE_TAU, _w, _role);
}

/// An axis-aligned rectangle as a fan. Convex, so star-shaped about any corner.
function lge_rect_fill(_x0, _y0, _x1, _y1, _role) {
    return lge_fill([[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]], _role);
}

/// An axis-aligned rectangle as a stroked outline.
function lge_rect_poly(_x0, _y0, _x1, _y1, _w, _role) {
    return lge_poly([[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]], true, _w, _role);
}

/// Fill a CLOSED ring of points as a fan from an interior point.
///
/// USE THIS AND NEVER HAND-ROLL IT. A fan walks centre -> p0 -> p1 -> ... -> pN and closes from
/// pN straight back to the centre, so the edge from pN back to p0 is never walked and a wedge of
/// the shape is silently missing. The ring's first point is repeated at the end here. That is the
/// whole fix, and it is why every closed outline in this product is closed.
function lge_ring_fill(_pts, _role, _cx, _cy) {
    var _n = array_length(_pts);
    var _ax = _cx, _ay = _cy;
    if (is_undefined(_ax)) {
        _ax = 0; _ay = 0;
        for (var _i = 0; _i < _n; _i++) { _ax += _pts[_i][0]; _ay += _pts[_i][1]; }
        _ax /= _n; _ay /= _n;
    }
    var _out = array_create(_n + 2);
    _out[0] = [_ax, _ay];
    for (var _i = 0; _i < _n; _i++) _out[_i + 1] = _pts[_i];
    _out[_n + 1] = _pts[0];
    return lge_fill(_out, _role);
}

/// ============================================================================================
/// ARRAY HELPERS
/// ============================================================================================

/// Append every element of _src onto _dst, in place. Returns _dst.
/// Used everywhere instead of array_concat so the allocation pattern is one array per form
/// rather than one per composition step - a full form rebuilt every frame is real garbage.
/// ⛔ A SINGLE PART IS ACCEPTED, AND IT IS NOT TIDINESS. Four builders in this layer return ONE
/// part rather than a list - lge_fill, lge_poly, lge_dot and lge_taper_ribbon - and handing one of
/// those to the loop below asks array_length() about a struct, which answers 0. The part is then
/// dropped with no error, no warning and a perfectly clean compile. MEASURED in this studio's shared drawing layer, on the product it was written for: six call sites were computing geometry and throwing it away, and the only thing that noticed was a single assertion about where one form met the ground. Accepting a bare part is the difference between a defect that shouts and one that does
/// not exist as far as any tool can tell.
function lge_append(_dst, _src) {
    if (!is_array(_src)) { array_push(_dst, _src); return _dst; }
    var _n = array_length(_src);
    for (var _i = 0; _i < _n; _i++) array_push(_dst, _src[_i]);
    return _dst;
}

/// ============================================================================================
/// CURVE SAMPLING - everything curved in this corpus is a sampled polyline, because that is the
/// only curved thing GML draws with an honoured line width.
/// ============================================================================================

/// Quadratic bezier, _n segments, inclusive of both ends.
function lge_qbez(_p0, _p1, _p2, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        _out[_i] = [
            _u * _u * _p0[0] + 2 * _u * _t * _p1[0] + _t * _t * _p2[0],
            _u * _u * _p0[1] + 2 * _u * _t * _p1[1] + _t * _t * _p2[1]
        ];
    }
    return _out;
}

/// Points along a circle, inclusive of both ends.
function lge_arc_pts(_cx, _cy, _r, _a0, _a1, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _a = _a0 + (_a1 - _a0) * (_i / _n);
        _out[_i] = [_cx + cos(_a) * _r, _cy + sin(_a) * _r];
    }
    return _out;
}

/// Points along an ellipse, closed (first point NOT repeated).
function lge_ellipse_pts(_cx, _cy, _rx, _ry, _n) {
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = (_i / _n) * LGE_TAU;
        _out[_i] = [_cx + cos(_a) * _rx, _cy + sin(_a) * _ry];
    }
    return _out;
}

/// Points along an ELLIPTICAL arc from _a0 to _a1, endpoints included.
///
/// ⚠️ lge_arc_pts above takes a single radius and is therefore a CIRCULAR arc, and almost nothing
/// in a TOWN is circular in projection. A well's rim, an anvil's face, a churn's mouth, a table
/// top, a stall's counter and a pool of lamplight are all discs seen at an angle, which is an
/// ellipse. Each of those needs BOTH radii, and reaching for lge_arc_pts silently draws a circle
/// where the form is an ellipse - the two agree only when _rx happens to equal _ry.
///
/// ⛔ The visible failure is specific and worth naming, because it is the one a buyer sees first: a
/// circular well mouth is as DEEP on screen as it is WIDE, so it stands up out of the ground like a
/// ring rolled on edge, and every station the figure works AT tips forward with it. Anything that
/// lies flat in the world uses the elliptical form for exactly that reason.
///
/// Angles follow the same convention as lge_ellipse_pts, and y grows DOWNWARD: sin(_a) > 0 is the
/// LOWER half of a shape on screen and sin(_a) < 0 is the upper half. The lamp in lge_relief sits
/// up and to the left, so that sign is what decides which half of a bezel is lit; do not "tidy"
/// it.
function lge_ellipse_arc_pts(_cx, _cy, _rx, _ry, _a0, _a1, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _a = _a0 + (_a1 - _a0) * (_i / _n);
        _out[_i] = [_cx + cos(_a) * _rx, _cy + sin(_a) * _ry];
    }
    return _out;
}

/// Regular polygon / star point ring.
function lge_star_pts(_cx, _cy, _r, _n, _phase) {
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = _phase + (_i / _n) * LGE_TAU;
        _out[_i] = [_cx + cos(_a) * _r, _cy + sin(_a) * _r];
    }
    return _out;
}

/// Offset a polyline sideways by _d, using per-vertex normals.
function lge_offset_pts(_pts, _d) {
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        _out[_i] = [_pts[_i][0] - _dy * _d, _pts[_i][1] + _dx * _d];
    }
    return _out;
}

/// A polyline given real thickness, as a triangle strip. Correct for shapes a fan cannot do.
function lge_ribbon(_pts, _half, _role) {
    return lge_strip(lge_offset_pts(_pts, _half), lge_offset_pts(_pts, -_half), _role);
}

/// A ribbon whose half-width is given PER POINT rather than interpolated between two ends.
///
/// ⛔ THIS IS THE PRIMITIVE THAT MAKES ENGRAVED TONE POSSIBLE, AND ITS ABSENCE IS WHY FOUR ROUNDS
/// OF PARAMETER TUNING FAILED TO FIX THE SHADING. See lge_relief for the argument in
/// full; the short version is that an engraver ramps tone by SWELLING A LINE, not by filling a
/// region and drawing lines of constant weight on top of it. A constant-width stroke can only ever
/// participate in a pattern; a swelling one participates in a gradient. lge_taper_ribbon below is
/// the two-endpoint special case of this and stays because a ribbon tail genuinely does taper
/// monotonically - but tone does not, so it needs the array.
///
/// _w is a half-width per point and must be the same length as _pts. A shorter array is a DEFECT
/// rather than something to pad: it means the caller's two loops disagree, and silently reusing the
/// last width would draw a plausible wrong picture. Asserted rather than tolerated.
function lge_var_ribbon(_pts, _w, _role) {
    var _n = array_length(_pts);
    if (_n < 2 || array_length(_w) != _n) return lge_strip([], [], _role);
    var _a = array_create(_n), _b = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        var _d = _w[_i];
        _a[_i] = [_pts[_i][0] - _dy * _d, _pts[_i][1] + _dx * _d];
        _b[_i] = [_pts[_i][0] + _dy * _d, _pts[_i][1] - _dx * _d];
    }
    return lge_strip(_a, _b, _role);
}

/// A ribbon whose thickness varies along its length, taper from _w0 at the start to _w1 at the
/// end with an optional exponent. A tapered ribbon tail reads as CUT; one of constant width reads
/// as extruded, which is the loudest tell of programmer art.
function lge_taper_ribbon(_pts, _w0, _w1, _role) {
    var _n = array_length(_pts);
    var _a = array_create(_n), _b = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        var _d = lerp(_w0, _w1, _i / max(1, _n - 1));
        _a[_i] = [_pts[_i][0] - _dy * _d, _pts[_i][1] + _dx * _d];
        _b[_i] = [_pts[_i][0] + _dy * _d, _pts[_i][1] - _dx * _d];
    }
    return lge_strip(_a, _b, _role);
}

/// ============================================================================================
/// CLIPPING
///
/// Liang-Barsky: clip a segment to an axis-aligned rectangle. Returns [[x0,y0],[x1,y1]] or
/// undefined. Analytic rather than a scissor rect, because GML's clipping is a surface/viewport
/// operation that does not survive being called from inside a buyer's own draw event - and every
/// wood grain, stone joint, rust streak and plank line must stop at the outline of the prop that
/// owns it. The division is deliberate: a texture program returns marks across a BAND and the caller
/// clips them to the actual object, which is what lets one grain program serve an anvil stump, a
/// loom frame and a market stall. This is the function that does the clipping.
///
/// ⛔ AND CLIPPING IS NOT THE SAME QUESTION AS SPAN (wing CLAUDE.md, inherited): a bounding box is
/// only the shape's true width at ONE height, and on these subjects that gap is enormous rather
/// than marginal. An anvil is at its WIDEST across the face and its narrowest at the waist, so a
/// grain line clipped to its bounding box hangs into open air on both sides of the stem - the
/// texture reads as a rectangle standing behind the prop instead of as the prop's own surface.
/// Clip to the outline's span AT ITS OWN y; lge_span_at_y returns exactly that number, for exactly
/// this reason.
/// ============================================================================================

/// @desc The outline's true half-extent AT ONE HEIGHT: [xmin, xmax] where the horizontal line y = _y
/// crosses the closed polygon _pts, or `undefined` if it does not cross it at all.
///
/// ⛔ THIS IS THE FUNCTION THE CLIPPING HEADER ABOVE POINTS AT, AND IT EXISTS BECAUSE A BOUNDING BOX
/// IS A LIE ABOUT EVERY SHAPE EXCEPT A RECTANGLE. A shape reaches its box width at ONE y; a mark
/// placed anywhere else and clipped to the box hangs outside the object on both sides. This wing has
/// shipped that defect twice - a boulder with two whiskers, and speckle standing off the shoulder of
/// a crystal by 0.063 of the unit box - and both times the geometry, the winding, the ink floor and
/// the whole suite were green, because a mark outside a shape is still a mark.
///
/// ⚠️ IT RETURNS THE OUTERMOST CROSSINGS, WHICH IS THE RIGHT ANSWER FOR A LUMP AND THE WRONG ONE FOR
/// A C-SHAPE - it bridges the opening. Every station in this package is built as a solid mass or as
/// separate solid masses, so the outermost reading is correct for all of them; if a genuinely
/// C-shaped prop is ever added (a horseshoe, an open hoop), it must be clipped per-span instead and
/// this comment is the warning that the two are not the same question.
///
/// ⛔ AND A MARK OCCUPIES A RANGE OF HEIGHTS, SO IT MUST FIT AT ALL OF THEM. Clamping a mark against
/// the span at its CENTRE is correct there and wrong at its top and bottom, because an object
/// narrows as it rises. Callers placing anything with vertical extent clamp PER POINT.
///
/// @param {Array} _pts closed outline, array of [x,y]
/// @param {Real}  _y   the height to measure at
/// @returns {Array|Undefined} [xmin, xmax]
function lge_span_at_y(_pts, _y) {
    var _n = array_length(_pts);
    if (_n < 3) return undefined;
    var _lo = 0, _hi = 0, _any = false;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i];
        var _b = _pts[(_i + 1) % _n];
        var _ay = _a[1], _by = _b[1];
        // A horizontal edge crosses nothing; its endpoints are picked up by the edges either side of
        // it, so skipping it here loses no crossing and avoids a divide by zero.
        if (_ay == _by) continue;
        // Half-open interval so a vertex exactly on the line is counted ONCE rather than twice or
        // not at all. Without it, a polygon whose vertex sits on _y reads as two crossings at the
        // same x and a mark clipped to it collapses to a point.
        var _t0 = min(_ay, _by), _t1 = max(_ay, _by);
        if (_y < _t0 || _y >= _t1) continue;
        var _x = _a[0] + (_b[0] - _a[0]) * ((_y - _ay) / (_by - _ay));
        if (!_any) { _lo = _x; _hi = _x; _any = true; }
        else { _lo = min(_lo, _x); _hi = max(_hi, _x); }
    }
    if (!_any) return undefined;
    return [_lo, _hi];
}

/// @desc Clamp a point to the outline's span at its OWN height, keeping a margin inside.
///
/// The per-point form of lge_span_at_y, which is what almost every caller actually wants: it is the
/// difference between a grain line that stops at the timber and one that runs off it.
///
/// Returns the point unchanged when the height is outside the shape entirely - a caller placing
/// marks above or below an object has a bug this function cannot fix, and silently dragging the mark
/// to the shape's centre would hide it.
function lge_clamp_to_span(_pt, _pts, _margin) {
    var _s = lge_span_at_y(_pts, _pt[1]);
    if (is_undefined(_s)) return _pt;
    var _lo = _s[0] + _margin;
    var _hi = _s[1] - _margin;
    if (_hi < _lo) { var _m = (_s[0] + _s[1]) * 0.5; return [_m, _pt[1]]; }
    return [clamp(_pt[0], _lo, _hi), _pt[1]];
}

function lge_clip_seg(_x0, _y0, _x1, _y1, _rx0, _ry0, _rx1, _ry1) {
    var _t0 = 0, _t1 = 1;
    var _dx = _x1 - _x0, _dy = _y1 - _y0;
    var _p, _q, _r;
    for (var _e = 0; _e < 4; _e++) {
        switch (_e) {
            case 0: _p = -_dx; _q = _x0 - _rx0; break;
            case 1: _p =  _dx; _q = _rx1 - _x0; break;
            case 2: _p = -_dy; _q = _y0 - _ry0; break;
            default: _p = _dy; _q = _ry1 - _y0; break;
        }
        if (_p == 0) {
            if (_q < 0) return undefined;
        } else {
            _r = _q / _p;
            if (_p < 0) {
                if (_r > _t1) return undefined;
                if (_r > _t0) _t0 = _r;
            } else {
                if (_r < _t0) return undefined;
                if (_r < _t1) _t1 = _r;
            }
        }
    }
    return [[_x0 + _t0 * _dx, _y0 + _t0 * _dy], [_x0 + _t1 * _dx, _y0 + _t1 * _dy]];
}

/// ============================================================================================
/// TRANSFORMS
/// ============================================================================================

/// Map one point from unit-box space to form space.
function lge_map_pt(_p, _cx, _cy, _s, _rot) {
    var _x = _p[0] * _s, _y = _p[1] * _s;
    if (_rot != 0) {
        var _c = cos(_rot), _sn = sin(_rot);
        var _nx = _x * _c - _y * _sn;
        _y = _x * _sn + _y * _c;
        _x = _nx;
    }
    return [_cx + _x, _cy + _y];
}

/// Resolve a role through an optional remap struct.
function lge_role(_role, _map) {
    if (is_undefined(_map)) return _role;
    if (variable_struct_exists(_map, _role)) return variable_struct_get(_map, _role);
    return _role;
}

/// Place a unit-box part list at (_cx,_cy) at scale _s.
///
/// STROKE WIDTHS SCALE, WITH A FLOOR IN THE RENDERER. The design corpus originally said the
/// weight was "held constant in screen space rather than scaled" - implemented literally, that
/// makes a card-scale form's strokes 32% of its own width while a hero-scale one's are 6%, so
/// small forms rendered as solid blobs. Constant PROPORTION plus lge_render's 1.0px floor is
/// what the rule was actually reaching for.
function lge_place(_parts, _cx, _cy, _s, _rot, _wscale, _map) {
    var _n = array_length(_parts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        var _r = lge_role(_p.role, _map);
        switch (_p.kind) {
            case LGE_DOT: {
                var _q = lge_map_pt([_p.cx, _p.cy], _cx, _cy, _s, _rot);
                _out[_i] = lge_dot(_q[0], _q[1], _p.r * _s, _r);
            } break;
            case LGE_ARC: {
                var _q = lge_map_pt([_p.cx, _p.cy], _cx, _cy, _s, _rot);
                _out[_i] = lge_arc(_q[0], _q[1], _p.r * _s, _p.a0 + _rot, _p.a1 + _rot,
                                   _p.w * _wscale, _r);
            } break;
            case LGE_STRIP: {
                var _na = array_length(_p.a), _nb = array_length(_p.b);
                var _a = array_create(_na), _b = array_create(_nb);
                for (var _k = 0; _k < _na; _k++) _a[_k] = lge_map_pt(_p.a[_k], _cx, _cy, _s, _rot);
                for (var _k = 0; _k < _nb; _k++) _b[_k] = lge_map_pt(_p.b[_k], _cx, _cy, _s, _rot);
                _out[_i] = lge_strip(_a, _b, _r);
            } break;
            case LGE_FILL: {
                var _np = array_length(_p.pts);
                var _pts = array_create(_np);
                for (var _k = 0; _k < _np; _k++) _pts[_k] = lge_map_pt(_p.pts[_k], _cx, _cy, _s, _rot);
                _out[_i] = lge_fill(_pts, _r);
            } break;
            default: {
                var _np = array_length(_p.pts);
                var _pts = array_create(_np);
                for (var _k = 0; _k < _np; _k++) _pts[_k] = lge_map_pt(_p.pts[_k], _cx, _cy, _s, _rot);
                _out[_i] = lge_poly(_pts, _p.closed, _p.w * _wscale, _r);
            } break;
        }
    }
    return _out;
}

/// @desc Mirror a part list about x = 0, in unit space.
///
/// ⛔⛔ MIRRORING GEOMETRY WITHOUT MIRRORING THE LAMP IS A DEFECT, AND IT IS THE REASON THIS FUNCTION
/// HAS A HEADER THIS LONG. Every ramp role in this package is chosen AT BUILD TIME from a surface
/// normal against a fixed lamp at upper-left (`LGE_LX`, `LGE_LY`). Flip the points and the highlights
/// flip with them, so a townsperson facing left is lit from the right - and a street with people
/// facing both ways has two suns in it. Nothing mechanical can see that; it is a picture.
///
/// ⭐ THE FIX IS AT THE OTHER END AND COSTS NOTHING: build the parts with the lamp mirrored
/// (`lge_lamp_set(-LGE_LX, LGE_LY)`), then mirror the geometry. The two flips cancel and the light
/// stays where it was. `lge_figure_parts` does exactly that and is the only caller that needs to; a
/// caller that mirrors without it gets the two-suns bug and this paragraph is the warning.
///
/// ⚠️ POINT ORDER IS NOT REVERSED, AND THAT IS CORRECT HERE RATHER THAN LAZY. Mirroring flips the
/// winding of every outline, which matters only under face culling - and this renderer never enables
/// it (`pr_trianglefan` and `pr_trianglestrip` are drawn with GameMaker's default `cull_noculling`).
/// Reversing the array would be actively wrong for an LGE_FILL, whose `pts[0]` is the fan APEX and
/// not part of the outline at all.
function lge_mirror_parts(_parts) {
    var _n = array_length(_parts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case LGE_DOT: _out[_i] = lge_dot(-_p.cx, _p.cy, _p.r, _p.role); break;
            case LGE_ARC: {
                // An arc's angles mirror as a0,a1 -> pi-a1, pi-a0. Swapping the ends as well as
                // negating is the half that is easy to miss: mirroring reverses the sweep DIRECTION,
                // and an arc drawn from the new start to the old start covers the complement.
                _out[_i] = lge_arc(-_p.cx, _p.cy, _p.r, pi - _p.a1, pi - _p.a0, _p.w, _p.role);
            } break;
            case LGE_STRIP: {
                var _na = array_length(_p.a), _nb = array_length(_p.b);
                var _a = array_create(_na), _b = array_create(_nb);
                for (var _k = 0; _k < _na; _k++) _a[_k] = [-_p.a[_k][0], _p.a[_k][1]];
                for (var _k = 0; _k < _nb; _k++) _b[_k] = [-_p.b[_k][0], _p.b[_k][1]];
                _out[_i] = lge_strip(_a, _b, _p.role);
            } break;
            case LGE_FILL: {
                var _np = array_length(_p.pts);
                var _q = array_create(_np);
                for (var _k = 0; _k < _np; _k++) _q[_k] = [-_p.pts[_k][0], _p.pts[_k][1]];
                _out[_i] = lge_fill(_q, _p.role);
            } break;
            default: {
                var _np2 = array_length(_p.pts);
                var _q2 = array_create(_np2);
                for (var _k = 0; _k < _np2; _k++) _q2[_k] = [-_p.pts[_k][0], _p.pts[_k][1]];
                _out[_i] = lge_poly(_q2, _p.closed, _p.w, _p.role);
            } break;
        }
    }
    return _out;
}

/// ============================================================================================
/// SEEDED HASH
///
/// Nothing in this product is random at draw time. The only randomness is a seeded hash of the
/// form's id, so two forms that differ in any property look different and the SAME form never
/// flickers between looks. Never call random() anywhere in this package - a jittered edge that
/// re-jitters every frame is the one bug a buyer will notice immediately and cannot work around.
/// ============================================================================================

/// Exact 32-bit unsigned multiply, done in 16-bit halves.
///
/// GML numbers are doubles. A direct h * 16777619 with h near 2^32 reaches 7.2e16, past the 2^53
/// point where doubles stop being exact - so the hash would silently lose its low bits and two
/// different form ids could collide. Splitting the multiply keeps every intermediate under 2^33.
function lge_mul32(_a, _b) {
    var _al = _a & 0xFFFF;
    var _ah = (_a >> 16) & 0xFFFF;
    var _bl = _b & 0xFFFF;
    var _bh = (_b >> 16) & 0xFFFF;
    var _lo = _al * _bl;
    var _mid = ((_al * _bh) + (_ah * _bl)) & 0xFFFF;
    return (_lo + (_mid << 16)) & 0xFFFFFFFF;
}

/// FNV-1a, 32-bit. Same construction as the authoring-side previewer, so a form looks the same
/// in the engine as it did on the corpus sheet.
function lge_hash32(_s) {
    var _h = 2166136261;
    var _n = string_length(_s);
    for (var _i = 1; _i <= _n; _i++) {
        _h = _h ^ ord(string_char_at(_s, _i));
        _h = lge_mul32(_h, 16777619);
    }
    return _h;
}