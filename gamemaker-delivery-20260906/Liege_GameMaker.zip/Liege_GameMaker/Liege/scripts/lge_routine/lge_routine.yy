{
  "$GMScript": "v1",
  "%Name": "lge_routine",
  "name": "lge_routine",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}
