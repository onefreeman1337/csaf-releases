/// ============================================================================================
/// LIEGE — THE ROUTINE, AND THE PURE FUNCTION THAT SOLVES IT
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// This is the spine of the product. Everything visible hangs off it.
///
/// ⭐ A PERSON'S POSITION IS A PURE FUNCTION OF (routine, time). NOTHING IS INTEGRATED, SO THERE IS
/// NO WALK STATE TO CORRUPT, DESYNCHRONISE OR RE-ROLL.
///
/// `lge_where(routine, t)` SOLVES the routine at time `t`. It does not advance anything, it does
/// not read anything it did last frame, and calling it out of order, twice, or after a six-hour gap
/// gives identical answers. Three of the four author-confirmed weaknesses in the incumbent product
/// this competes with are the same bug wearing three coats, and this one decision answers all of
/// them:
///
///   incumbent: "position is re-rolled on map re-entry rather than simulated"
///     -> re-entry evaluates lge_where(routine, now). Exact, and free - there is no catch-up loop,
///        because there was never any state to catch up.
///
///   incumbent: "interaction pauses corrupt movement"
///     -> a pause shifts the routine's time origin (lge_routine_pause / _resume). Resume re-solves.
///        No integrator, so there is nothing to desynchronise.
///
///   incumbent: "night-spanning routines break"
///     -> time is `t mod LGE_DAY` everywhere, and a segment crossing midnight is ONE segment with a
///        wrapped interval, never two. See lge_seg_contains.
///
/// ⚠️ THE HONEST COST, AND IT IS STATED IN THE README TOO. A pure function of time cannot depend on
/// what happened a moment ago, so this product does NOT give you emergent collision avoidance,
/// queueing, or people reacting to each other's paths. It gives determinism, free save/load, free
/// map re-entry, and the ability to scrub the clock to any hour and see the town exactly as it will
/// be. That is the trade. Do not discover it at the gate.
///
/// ============================================================================================

/// A day is 24 units of one hour. Real seconds are the caller's business - a buyer scaling a day to
/// four real minutes passes `lge_clock(...)` its own rate and this module never learns about it.
#macro LGE_DAY 24

/// Positions are in TOWN space, which is whatever unit the buyer's room uses. Nothing here assumes
/// pixels, tiles, or a room size, and there is no hardcoded room or layer index anywhere in this
/// package.

/// ============================================================================================
/// TIME
/// ============================================================================================

/// @desc Wrap any time onto [0, LGE_DAY).
///
/// ⛔ GML's `mod` KEEPS THE SIGN OF THE DIVIDEND, so `-1 mod 24` is -1 and not 23. Every negative
/// time in this product comes from a legitimate place - a pause offset, a routine authored as
/// starting "two hours before dawn", a caller scrubbing backwards - so this is not a defensive
/// nicety, it is the common path.
///
/// @param {real} t
/// @return {real} 0 <= result < LGE_DAY
function lge_wrap(t) {
    var _w = t mod LGE_DAY;
    if (_w < 0) _w += LGE_DAY;
    return _w;
}

/// @desc Forward distance from `a` to `b` around the clock. Always >= 0.
/// @param {real} a
/// @param {real} b
/// @return {real} 0 .. LGE_DAY
function lge_forward(a, b) {
    return lge_wrap(b - a);
}

/// ============================================================================================
/// SEGMENTS
/// ============================================================================================

/// @desc One block of a person's day: be at `work` from `from` until `to`.
///
/// `from` and `to` are hours on [0, LGE_DAY). A segment where `to` <= `from` WRAPS MIDNIGHT and is
/// still exactly one segment - the sleeping segment of almost every routine looks like
/// {from: 22, to: 6}, and splitting it into two is how the incumbent's night bug happens.
///
/// @param {string} work  an id from lge_works_all()
/// @param {real} from    hour, inclusive
/// @param {real} to      hour, exclusive
/// @return {struct}
function lge_seg(work, from, to) {
    return { work : work, from : lge_wrap(from), to : lge_wrap(to) };
}

/// @desc Does this segment cover time `t`?
///
/// ⛔ THE WRAPPING CASE IS THE POINT OF THIS FUNCTION AND IT IS THE ONE A NAIVE `from <= t && t < to`
/// GETS BACKWARDS. For {22, 6}, that test is false at 23:00 and false at 02:00 - i.e. the person is
/// nowhere at all for eight hours every night, which is precisely the shape of "night-spanning
/// routines break".
///
/// @param {struct} seg
/// @param {real} t
/// @return {bool}
function lge_seg_contains(seg, t) {
    var _t = lge_wrap(t);
    if (seg.from == seg.to) return true;          // a full-day segment: one work loop, all day
    if (seg.from < seg.to) return (_t >= seg.from) && (_t < seg.to);
    return (_t >= seg.from) || (_t < seg.to);      // wraps midnight
}

/// @desc How long the segment lasts, in hours. A full-day segment is LGE_DAY, never 0.
/// @param {struct} seg
/// @return {real}
function lge_seg_length(seg) {
    if (seg.from == seg.to) return LGE_DAY;
    return lge_forward(seg.from, seg.to);
}

/// @desc How far into the segment time `t` is, as 0..1.
///
/// ⚠️ Returns 0 rather than undefined for a `t` the segment does not contain. A phase is only ever
/// asked for a segment already selected by lge_routine_at, so an out-of-range answer would be a
/// caller bug - but returning a NUMBER keeps every consumer arithmetic instead of making each one
/// re-handle undefined, and the self-test pins the in-range behaviour rather than this fallback.
///
/// @param {struct} seg
/// @param {real} t
/// @return {real} 0..1
function lge_seg_phase(seg, t) {
    var _len = lge_seg_length(seg);
    if (_len <= 0) return 0;
    return lge_forward(seg.from, lge_wrap(t)) / _len;
}

/// ============================================================================================
/// ROUTINES
/// ============================================================================================

/// @desc Build a person's day from segments.
///
/// ⛔ THE SEGMENTS MUST TILE THE WHOLE DAY WITH NO GAP AND NO OVERLAP, and this constructor does not
/// silently repair a set that does not. A gap means a person who is NOWHERE for part of the day, and
/// an overlap means a person in two places at once; both are defects a buyer would report and
/// neither has a correct automatic fix - shrinking a segment to close a gap invents an intent the
/// author did not have. So it records the verdict on the routine, `lge_routine_check` reports it,
/// and the suite asserts every shipped routine is clean.
///
/// ⚠️ This is deliberately NOT a repair loop. A sibling product in this wing shipped a generator
/// that quietly repaired its own output, and the lesson recorded was that a buyer cannot audit what
/// a generator silently fixed.
///
/// @param {string} name
/// @param {array} segs  array of lge_seg
/// @return {struct}
function lge_routine(name, segs) {
    var _r = {
        name    : name,
        segs    : segs,
        offset  : 0,          // time origin shift, moved by pause/resume. NOT a clock.
        paused  : false,
        pause_t : 0
    };
    return _r;
}

/// @desc Check that a routine tiles the day exactly once.
///
/// Returns a struct rather than a bool, because "it is broken" is not actionable and "there is a
/// 90-minute hole at 14:30 and two segments both claim 06:00" is.
///
/// ⚠️ IT SAMPLES, and says so. An exact interval-algebra proof over wrapped intervals is more code
/// than the check is worth here; sampling at a fixed fine step catches every gap and overlap a
/// human-authored routine can produce, because the authoring unit is a quarter hour at finest. The
/// step is declared so a future author who authors to the minute knows to change it.
///
/// @param {struct} routine
/// @return {struct} {ok, gaps, overlaps, step}
function lge_routine_check(routine) {
    var _step = 0.05;                       // ~3 real minutes; authoring granularity is 0.25
    var _gaps = [];
    var _over = [];
    var _n = array_length(routine.segs);
    for (var _t = 0; _t < LGE_DAY; _t += _step) {
        var _hits = 0;
        for (var _i = 0; _i < _n; _i++) {
            if (lge_seg_contains(routine.segs[_i], _t)) _hits++;
        }
        if (_hits == 0) array_push(_gaps, _t);
        else if (_hits > 1) array_push(_over, _t);
    }
    return {
        ok       : (array_length(_gaps) == 0) && (array_length(_over) == 0),
        gaps     : _gaps,
        overlaps : _over,
        step     : _step
    };
}

/// @desc The segment a person is in at time `t`.
///
/// Returns the FIRST matching segment. An overlapping routine therefore resolves deterministically
/// rather than arbitrarily - but it is still a defect, which is why lge_routine_check exists and why
/// the suite asserts on it instead of relying on this tie-break.
///
/// @param {struct} routine
/// @param {real} t
/// @return {struct|undefined}
function lge_routine_at(routine, t) {
    var _t = lge_routine_time(routine, t);
    var _n = array_length(routine.segs);
    for (var _i = 0; _i < _n; _i++) {
        if (lge_seg_contains(routine.segs[_i], _t)) return routine.segs[_i];
    }
    return undefined;
}

/// @desc The routine's own time: the world clock shifted by however long it has been paused.
/// @param {struct} routine
/// @param {real} t  world time
/// @return {real}
function lge_routine_time(routine, t) {
    if (routine.paused) return lge_wrap(routine.pause_t - routine.offset);
    return lge_wrap(t - routine.offset);
}

/// @desc Freeze a person mid-day - a conversation, a cutscene, a menu.
///
/// ⛔ THE INCUMBENT'S "interaction pauses corrupt movement" IS AN INTEGRATOR BUG AND CANNOT HAPPEN
/// HERE, but only if pause is implemented as a shift of the time ORIGIN rather than as a flag that
/// some other system checks before stepping. Freezing the origin means the solve keeps working and
/// simply keeps answering the same question.
///
/// Idempotent: pausing an already-paused routine does nothing, so a caller that pauses on every
/// frame of a conversation cannot drift the clock.
///
/// @param {struct} routine
/// @param {real} t  world time at the moment of pausing
function lge_routine_pause(routine, t) {
    if (routine.paused) return;
    routine.paused = true;
    routine.pause_t = t;
}

/// @desc Resume. The person picks up exactly where they were, however long the pause lasted.
/// @param {struct} routine
/// @param {real} t  world time at the moment of resuming
function lge_routine_resume(routine, t) {
    if (!routine.paused) return;
    routine.offset = lge_wrap(routine.offset + (t - routine.pause_t));
    routine.paused = false;
}
