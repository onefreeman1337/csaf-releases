/// ============================================================================================
/// LIEGE — THE WORK LOOPS
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// ⭐ THE JOIN, AND THE THIRD CORPUS. `lge_labour` is what a body DOES, `lge_station` is what it does
/// it AT, and this file is the thing a buyer actually names: a WORK LOOP. It also owns the TOOLS,
/// because a tool belongs to neither of the other two - it is held by the figure and it is part of
/// the station's trade, and putting it in either file would make that file the owner of a decision
/// the other half needs.
///
/// A work loop is:
///
///   { labour, station, tool, side, face, hours }
///
/// and the product's whole claim is that there are forty-six of them, each a different picture.
///
/// ============================================================================================
/// ⛔ WHY THE TOOL IS NOT OPTIONAL, AND WHY IT IS NOT A NICETY
/// ============================================================================================
///
/// `lge_station`'s header states the half of this that is about props: a figure swinging its arms in
/// empty air is a person having a fit; the same figure with an anvil under the swing is a smith. The
/// tool is the OTHER half of that sentence and it is the half held in the hand, which is where a
/// viewer looks. Six of the twelve motion archetypes are indistinguishable without one - a
/// `swing_over` with nothing in the hand is the same picture whether the job is a hammer, an axe, a
/// flail or a mallet, and those are four separate work loops in this corpus.
///
/// ⚠️ SO THE TOOL CORPUS IS SIZED AGAINST THE OTHER TWO ON PURPOSE. Forty-one distinct tools built
/// from the SAME eleven mass constructors the stations use - reused rather than re-invented, which is
/// what makes a fix to the shading reach the anvil, the hammer and the smith's apron at once.
///
/// ============================================================================================
/// TOOL SPACE, AND THE ONE CONTRACT THAT KEEPS A TOOL IN A HAND
/// ============================================================================================
///
/// A tool is authored with THE GRIP AT THE ORIGIN and the tool's own axis pointing along -y (up the
/// screen) at zero rotation. `lge_render_work` puts the grip at the wrist and rotates the tool so its
/// axis continues the FOREARM, then adds the tool's own `axis` offset.
///
/// ⛔ THE OBVIOUS ALTERNATIVE - AUTHOR THE TOOL IN WORLD SPACE BESIDE THE STATION - IS THE DEFECT
/// THIS CONTRACT EXISTS TO PREVENT, and it is not a hypothetical. The pose is a continuous function
/// of phase (`lge_labour_pose`), so the wrist moves every frame; a tool placed against the station
/// would be correct at exactly one phase of the cycle and would separate from the hand at every
/// other one. A hammer that leaves the hand at the top of its own swing is worse than no hammer.
///
/// ⚠️ AND A TOOL HAS A DEPTH, LIKE A STATION. `depth: "front"` draws it over the figure (a hammer in
/// the near hand), `"back"` draws it behind (a scythe blade sweeping past the far side of the body).
/// It is one field rather than a split part list because a tool is small enough to be wholly on one
/// side of the body; a station is not, which is why `lge_station_parts` returns two lists and this
/// returns one.
///
/// ============================================================================================

/// ⛔ THE RESERVED OFF-MAP ID. A routine must tile the whole day (`lge_routine_check`), and at 03:00
/// a townsperson is indoors and asleep - they are not standing at a station holding a rake. So a
/// segment may name `LGE_AWAY`, which resolves to a spec whose `visible` is false and whose station
/// is undefined.
///
/// ⚠️ IT IS DELIBERATELY NOT IN `lge_works_all()`. The volume claim in this product's listing copy is
/// a count of work loops that DRAW SOMETHING, and an off-map marker padding that count to 47 would be
/// exactly the kind of number this wing's constitution calls a rename. The suite asserts both halves:
/// every id in `lge_works_all()` is visible, and `LGE_AWAY` resolves.
#macro LGE_AWAY "away"

/// ============================================================================================
/// THE TOOL VOCABULARY
/// ============================================================================================
///
/// Authored in tool space: grip at (0,0), the tool running up the screen along -y. Every constructor
/// returns parts in generic ramp roles (`m0`..`m4`); `lge_tool_parts` maps them into the tool's own
/// material at the end, in one place, exactly as `lge_station_parts` does.

/// @desc A shaft from the grip, running up. The most common single part in the corpus.
///
/// ⚠️ TAPERED, NOT PARALLEL. A parallel-sided stick reads as a drawn line with a thickness; a haft
/// that thins toward the head reads as turned wood, and the taper is most of what separates a
/// hammer's handle from a spear's.
///
/// @param {Real} _len   how far the shaft runs from the grip, up the screen
/// @param {Real} _w0    half-width at the grip
/// @param {Real} _w1    half-width at the far end
function lge_tl_haft(_len, _w0, _w1) {
    return lge_st_taper(0, -_len, 0.010, _w1, _w0, 0, 0.42);
}

/// @desc A head across the far end of a shaft - a hammer, a mallet, an adze, an axe poll.
///
/// @param {Real} _at    how far up the shaft the head sits
/// @param {Real} _half  half-length ACROSS the shaft
/// @param {Real} _th    half-thickness ALONG the shaft
function lge_tl_head(_at, _half, _th) {
    return lge_st_slab(-_half, -_at - _th, _half, -_at + _th, 0.44, 3);
}

/// @desc A blade: a mass that tapers to an edge on one side. Axes, cleavers, scythes, shears.
///
/// ⛔ THE EDGE IS A SEPARATE INCISED LINE, NOT A THIN END OF THE MASS. `draw_line_width` floors at
/// 1.0px in this runtime, so a mass tapering to nothing draws a 1px stub of body colour where the
/// edge should be and the blade reads as blunt. Tone is spacing and length here, never line width -
/// that is a measured row in this wing's constitution, and a knife is where it shows worst.
///
/// @param {Real} _x0,_y0  the spine end (at the haft)
/// @param {Real} _x1,_y1  the tip
/// @param {Real} _back    how deep the blade's back is from the spine
function lge_tl_blade(_x0, _y0, _x1, _y1, _back) {
    var _dx = _x1 - _x0, _dy = _y1 - _y0;
    var _len = point_distance(0, 0, _dx, _dy);
    if (_len < LGE_EPS) return [];
    var _nx = -_dy / _len, _ny = _dx / _len;
    // A curved back rather than a straight one: three sampled points along the spine pushed out by a
    // raised sine, so the blade bellies. A straight-backed blade is a wedge.
    var _pts = [[_x0, _y0]];
    for (var _i = 1; _i <= 4; _i++) {
        var _t = _i / 5;
        var _b = _back * sin(_t * pi) * 1.15;
        array_push(_pts, [_x0 + _dx * _t + _nx * _b, _y0 + _dy * _t + _ny * _b]);
    }
    array_push(_pts, [_x1, _y1]);
    // ⚠️ FILLED FROM ITS OWN CENTROID, NOT FROM A POINT ON THE SPINE. The blade is convex, so a fan
    // is safe - but an apex ON the boundary produces a run of degenerate triangles along the spine,
    // which at a 1px stroke floor is a visible hairline of background through the edge of the blade.
    var _out = [lge_ring_fill(_pts, "m2", undefined, undefined)];
    // The edge, incised along the spine side.
    lge_append(_out, lge_incise([[_x0, _y0], [_x1, _y1]], false, 0.006));
    return _out;
}

/// @desc A curved hook or crook - a shepherd's crook, a dye hook, a rope hook, a goad's tip.
function lge_tl_hook(_at, _r, _a0, _a1) {
    return [lge_poly(lge_arc_pts(0, -_at, _r, _a0, _a1, 12), false, 0.012, "m2")];
}

/// @desc A held vessel - a bucket, a ladle bowl, a pot, a mortar. Tapered with a rim split by depth
/// collapsed into one arc, because a tool this small never has a figure standing inside it.
function lge_tl_bowl(_at, _rtop, _rbot, _h) {
    var _out = [];
    lge_append(_out, lge_st_taper(0, -_at - _h, -_at, _rtop, _rbot, 0.004, 0.34));
    lge_append(_out, [lge_poly(lge_ellipse_pts(0, -_at - _h, _rtop, _rtop * 0.34, 18), true, 0.010, "m1")]);
    return _out;
}

/// @desc A soft slumped mass carried in the hands - a sack, a bundle of fibre, a fleece, a loaf.
///
/// ⚠️ SEEDED, NEVER RANDOM. Same law as `lge_st_pile`: a bundle that re-rolls its own lumps every
/// frame is the defect a buyer reports first and cannot work around.
function lge_tl_bundle(_at, _w, _h, _seed) {
    var _r = lge_rng(_seed);
    var _n = 13;
    var _pts = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = _i / _n * LGE_TAU;
        var _k = lge_rng_range(_r, 0.84, 1.16);
        // Wider than tall and heavier at the bottom: a sack sits on whatever holds it.
        _pts[_i] = [cos(_a) * _w * _k, -_at + sin(_a) * _h * _k + _h * 0.16 * (1 + sin(_a))];
    }
    return lge_mass(_pts, 0.50, 3, "m2");
}

/// @desc A flat panel held or carried - a board, a scroll, a shears' plate, a peel's blade.
function lge_tl_panel(_at, _half, _len, _k) {
    return lge_st_slab(-_half, -_at - _len, _half, -_at, _k, 3);
}

/// @desc Fine parallel tines - a rake, a fork, a comb, a flax heckle.
function lge_tl_tines(_at, _half, _len, _n) {
    var _out = [];
    lge_append(_out, lge_st_beam(-_half, -_at, _half, -_at, 0.010));
    for (var _i = 0; _i < _n; _i++) {
        var _f = (_n == 1) ? 0.5 : _i / (_n - 1);
        var _x = lerp(-_half, _half, _f);
        lge_append(_out, [lge_poly([[_x, -_at], [_x, -_at + _len]], false, 0.007, "m1")]);
    }
    return _out;
}

/// ============================================================================================
/// THE TOOL CORPUS
/// ============================================================================================

/// @desc Every tool id. Forty-one, and the count is the point: `swing_over` alone carries a hammer, a
/// mallet, an axe, a flail, a cleaver, a beetle and a stone mallet, and without the tool those seven
/// work loops are one picture.
function lge_tools_all() {
    return [
        "hammer", "bellowsbar", "tongs", "rasp", "solderiron",
        "saw", "plane", "coopmallet", "turnchisel", "axe",
        "shuttle", "distaff", "dyehook", "ropehook", "needle",
        "peel", "cleaver", "mashpaddle", "dasher", "ladle", "sack",
        "scythe", "flail", "seedbasket", "shears", "hoe", "smoker",
        "stonemallet", "spade", "rake",
        "netneedle", "beetle", "bucket", "crate",
        "quill", "pestle", "wickframe",
        "spear", "scroll", "hoopstick", "staff", "cane",
    ];
}

/// @desc A tool's held facts.
///
/// Fields:
///   mat    material id, resolved by `lge_palette` exactly as a station's is
///   grip   "one" | "two"   - two-handed tools are drawn from the LEADING wrist and the other hand
///                            is placed on the haft by `lge_render_work`
///   axis   radians added to the forearm direction. 0 = the tool continues the forearm, which is
///          correct for a haft; a bucket hangs (pi from the forearm), a panel is carried flat.
///   depth  "front" | "back"
///   reach  how far the tool extends from the grip, in stature units. The containment gate reads
///          this rather than measuring the parts, so a recipe that grows past its declared reach
///          fails by name instead of silently poking through a neighbour's stall.
///
/// @param {String} _id
/// @returns {Struct|Undefined} undefined for an unknown id - never a plausible stand-in
function lge_tool_spec(_id) {
    switch (_id) {
        // ---- metal and fire ---------------------------------------------------------------
        case "hammer":      return { mat: "irn", grip: "one", axis:  0.00, depth: "front", reach: 0.20 };
        // ⛔ EVERY `axis` HERE IS ZERO AS OF 2026-09-04, AND THE OLD VALUES ARE THE EVIDENCE THAT
        // `lge_tool_at` HAD ITS ROTATION BACKWARDS. Four carried objects declared an offset within
        // half a radian of pi - sack 2.60, seedbasket 2.80, bucket 2.90, crate 2.40 - and three
        // flat-held ones sat near -pi/2. Those are not seven independent art decisions; they are
        // seven hand-corrections of one broken base, made one tool at a time by sessions that never
        // asked why so many tools needed turning round. With the base fixed (`_dir + pi/2`), a tool
        // running along the forearm is the default and needs no offset at all.
        // ⚠️ `axis` STAYS IN THE SPEC. A genuine per-tool offset is a real thing - a sickle is held
        // across the body - and the field is how a buyer expresses one. It is simply no longer
        // carrying somebody else's bug.
        case "bellowsbar":  return { mat: "tim", grip: "one", axis:  0.00, depth: "back",  reach: 0.26 };
        case "tongs":       return { mat: "irn", grip: "two", axis:  0.00, depth: "front", reach: 0.30 };
        case "rasp":        return { mat: "irn", grip: "one", axis:  0.00, depth: "front", reach: 0.16 };
        case "solderiron":  return { mat: "irn", grip: "one", axis:  0.00, depth: "front", reach: 0.14 };
        // ---- wood -------------------------------------------------------------------------
        case "saw":         return { mat: "irn", grip: "two", axis:  0.00, depth: "front", reach: 0.34 };
        case "plane":       return { mat: "tim", grip: "two", axis:  0.00, depth: "front", reach: 0.13 };
        case "coopmallet":  return { mat: "tim", grip: "one", axis:  0.00, depth: "front", reach: 0.19 };
        case "turnchisel":  return { mat: "irn", grip: "two", axis:  0.00, depth: "front", reach: 0.24 };
        case "axe":         return { mat: "irn", grip: "two", axis:  0.00, depth: "front", reach: 0.30 };
        // ---- cloth and fibre --------------------------------------------------------------
        case "shuttle":     return { mat: "tim", grip: "one", axis:  0.00, depth: "front", reach: 0.11 };
        case "distaff":     return { mat: "thr", grip: "one", axis:  0.00, depth: "back",  reach: 0.18 };
        case "dyehook":     return { mat: "tim", grip: "two", axis:  0.00, depth: "front", reach: 0.28 };
        case "ropehook":    return { mat: "irn", grip: "two", axis:  0.00, depth: "front", reach: 0.15 };
        case "needle":      return { mat: "irn", grip: "one", axis:  0.00, depth: "front", reach: 0.07 };
        // ---- food -------------------------------------------------------------------------
        case "peel":        return { mat: "tim", grip: "two", axis:  0.00, depth: "front", reach: 0.44 };
        case "cleaver":     return { mat: "irn", grip: "one", axis:  0.00, depth: "front", reach: 0.16 };
        case "mashpaddle":  return { mat: "tim", grip: "two", axis:  0.00, depth: "front", reach: 0.32 };
        case "dasher":      return { mat: "tim", grip: "two", axis:  0.00, depth: "front", reach: 0.26 };
        case "ladle":       return { mat: "tim", grip: "one", axis:  0.00, depth: "front", reach: 0.22 };
        case "sack":        return { mat: "cnv", grip: "two", axis:   0.00, depth: "front", reach: 0.22 };
        // ---- field and beast --------------------------------------------------------------
        // ⛔ THESE THREE `reach` VALUES WERE UNDER-DECLARED AND THE SUITE CAUGHT IT: MEASURED
        // 2026-09-03, scythe declared 0.52 and drew 0.55, seedbasket declared 0.17 and drew 0.20,
        // hoe declared 0.46 and drew 0.48. Written down as what the geometry ACTUALLY is, plus
        // 0.02 for seed variation - `lge_tool_parts` takes a seed and the suite now sweeps several
        // rather than trusting the single sample that produced the numbers above.
        case "scythe":      return { mat: "tim", grip: "two", axis:  0.00, depth: "back",  reach: 0.57 };
        case "flail":       return { mat: "tim", grip: "two", axis:  0.00, depth: "back",  reach: 0.40 };
        case "seedbasket":  return { mat: "thr", grip: "one", axis:   0.00, depth: "front", reach: 0.22 };
        case "shears":      return { mat: "irn", grip: "one", axis:  0.00, depth: "front", reach: 0.15 };
        case "hoe":         return { mat: "tim", grip: "two", axis:  0.00, depth: "front", reach: 0.50 };
        case "smoker":      return { mat: "irn", grip: "one", axis:  0.00, depth: "front", reach: 0.19 };
        // ---- stone and earth --------------------------------------------------------------
        case "stonemallet": return { mat: "tim", grip: "one", axis:  0.00, depth: "front", reach: 0.17 };
        case "spade":       return { mat: "tim", grip: "two", axis:  0.00, depth: "front", reach: 0.42 };
        case "rake":        return { mat: "tim", grip: "two", axis:  0.00, depth: "front", reach: 0.44 };
        // ---- water and trade --------------------------------------------------------------
        case "netneedle":   return { mat: "tim", grip: "one", axis:  0.00, depth: "front", reach: 0.09 };
        case "beetle":      return { mat: "tim", grip: "one", axis:  0.00, depth: "front", reach: 0.21 };
        case "bucket":      return { mat: "tim", grip: "one", axis:   0.00, depth: "front", reach: 0.20 };
        case "crate":       return { mat: "tim", grip: "two", axis:   0.00, depth: "front", reach: 0.20 };
        case "quill":       return { mat: "thr", grip: "one", axis:  0.00, depth: "front", reach: 0.12 };
        case "pestle":      return { mat: "stn", grip: "one", axis:  0.00, depth: "front", reach: 0.13 };
        case "wickframe":   return { mat: "tim", grip: "two", axis:  0.00, depth: "front", reach: 0.24 };
        // ---- the day is not all work ------------------------------------------------------
        case "spear":       return { mat: "tim", grip: "one", axis:  0.00, depth: "back",  reach: 0.56 };
        case "scroll":      return { mat: "cnv", grip: "two", axis:  0.00, depth: "front", reach: 0.15 };
        case "hoopstick":   return { mat: "tim", grip: "one", axis:  0.00, depth: "front", reach: 0.22 };
        // reach 0.38 tracks the recipe's shortened haft (0.340 + the hook). The suite asserts no tool
        // exceeds its DECLARED reach, so leaving 0.48 here would have kept the old claim alive over
        // a shorter tool - a declared fact quietly disagreeing with the drawing, which is the exact
        // defect the station `work` table was just corrected for.
        case "staff":       return { mat: "tim", grip: "one", axis:  0.00, depth: "back",  reach: 0.38 };
        // ⭐ A CANE IS NOT A SHORT STAFF, IT IS A DIFFERENT OBJECT, AND SPLITTING THEM IS THE HONEST
        // FIX FOR A GATE THAT WAS 0.002 FROM PASSING. `elder_sit` and `drover_goad` shared one
        // `staff`, and the containment check measured the seated elder's tip 0.096 below the ground
        // against a tolerance of 0.094. Shaving the shared staff until that number went green would
        // have been fitting the product to the gate AND would have left the drover holding a stub.
        // A seated man's cane rests ON the floor: his wrist sits at y 0.196, the floor at 0.470, so
        // the cane is 0.27 long because that is the distance between them.
        case "cane":        return { mat: "tim", grip: "one", axis:  0.00, depth: "back",  reach: 0.30 };
        // ⛔ NO PLAUSIBLE FALLBACK, for the reason `lge_station_spec` and `lge_labour_spec` both give:
        // a stand-in satisfies the assertion that would otherwise have caught the typo. An unknown id
        // means a work loop names a tool that does not exist, and a generic stick in the hand of a
        // scribe would ship.
        default: return undefined;
    }
}

/// @desc The parts for one tool, in tool space, mapped into its own material.
///
/// @param {String} _id
/// @param {Real} _seed  the tool's own seed. Two sacks in one town differ; the same sack is the same
///                      sack every frame. Nothing here calls random().
/// @returns {Array|Undefined}
function lge_tool_parts(_id, _seed) {
    var _sp = lge_tool_spec(_id);
    if (is_undefined(_sp)) return undefined;
    var _o = [];
    var _i;

    switch (_id) {
        // ---- metal and fire ---------------------------------------------------------------
        // A smith's hammer: a short haft and a head with a WEDGE peen on one side. A symmetric
        // block on a stick is a toy mallet; the asymmetry is what says hammer at 40 pixels.
        case "hammer":
            lge_append(_o, lge_tl_haft(0.185, 0.0115, 0.0090));
            lge_append(_o, lge_tl_head(0.175, 0.030, 0.0195));
            lge_append(_o, lge_tl_blade(0.030, -0.175, 0.062, -0.170, 0.008));
            break;
        case "bellowsbar":
            lge_append(_o, lge_tl_haft(0.245, 0.0105, 0.0075));
            lge_append(_o, [lge_poly(lge_arc_pts(0, -0.245, 0.030, pi * 0.15, pi * 0.85, 9), false, 0.011, "m1")]);
            break;
        // Tongs are TWO arms meeting at a rivet, and the gap between them is the whole read.
        case "tongs":
            lge_append(_o, lge_st_beam(-0.011, 0.010, -0.020, -0.185, 0.0075));
            lge_append(_o, lge_st_beam( 0.011, 0.010,  0.020, -0.185, 0.0075));
            lge_append(_o, lge_st_beam(-0.020, -0.185, -0.008, -0.290, 0.0065));
            lge_append(_o, lge_st_beam( 0.020, -0.185,  0.008, -0.290, 0.0065));
            // ⛔ NOT WRAPPED IN A LIST. `lge_boss` returns a part LIST (it is lge_raise underneath),
            // and `lge_append` pushes a non-array as ONE element - so `[lge_boss(...)]` would push an
            // ARRAY into a part list and the renderer would switch on `.kind` of an array. Four
            // builders in this layer return one part and five return a list, and the two are
            // indistinguishable at a call site; that is a measured, shipped defect in this wing.
            lge_append(_o, lge_boss(0, -0.150, 0.012, 10));
            break;
        case "rasp":
            lge_append(_o, lge_tl_haft(0.052, 0.0130, 0.0105));
            lge_append(_o, lge_tl_panel(0.052, 0.0135, 0.098, 0.30));
            // The file's teeth: short incised strokes, spaced. Tone is spacing, not width.
            for (_i = 0; _i < 7; _i++) {
                var _ry = -0.062 - _i * 0.0125;
                lge_append(_o, lge_incise([[-0.011, _ry], [0.011, _ry - 0.005]], false, 0.005));
            }
            break;
        case "solderiron":
            lge_append(_o, lge_tl_haft(0.070, 0.0125, 0.0090));
            lge_append(_o, lge_st_beam(0, -0.070, 0, -0.126, 0.0055));
            lge_append(_o, lge_mass([[-0.013, -0.126], [0.013, -0.126], [0, -0.145]], 0.30, 2, "m3"));
            break;

        // ---- wood -------------------------------------------------------------------------
        // A two-man saw: a long toothed plate with a handle at each end. The teeth are what make it
        // a saw rather than a plank, and they are drawn as a run of short strokes on the edge.
        case "saw":
            lge_append(_o, lge_st_slab(-0.026, -0.320, 0.026, -0.052, 0.16, 2));
            lge_append(_o, lge_tl_haft(0.052, 0.0140, 0.0125));
            lge_append(_o, [lge_poly([[-0.026, -0.052], [0.026, -0.052]], false, 0.010, "m0")]);
            for (_i = 0; _i < 16; _i++) {
                var _sy = -0.062 - _i * 0.0160;
                lge_append(_o, [lge_poly([[0.026, _sy], [0.036, _sy - 0.006]], false, 0.006, "m1")]);
            }
            break;
        case "plane":
            lge_append(_o, lge_st_slab(-0.058, -0.030, 0.058, 0.006, 0.34, 3));
            lge_append(_o, lge_st_beam(-0.010, -0.030, 0.014, -0.078, 0.0085));
            lge_append(_o, lge_incise([[-0.014, -0.006], [0.030, -0.006]], false, 0.006));
            break;
        case "coopmallet":
            lge_append(_o, lge_tl_haft(0.150, 0.0110, 0.0095));
            lge_append(_o, lge_st_taper(0, -0.208, -0.140, 0.026, 0.030, 0.004, 0.40));
            break;
        case "turnchisel":
            lge_append(_o, lge_tl_haft(0.110, 0.0135, 0.0100));
            lge_append(_o, lge_st_beam(0, -0.110, 0, -0.212, 0.0075));
            lge_append(_o, lge_tl_blade(0, -0.212, 0.006, -0.238, 0.007));
            break;
        // The axe is the biggest tool in the wood group and the head is the silhouette: a
        // crescent bit and a squared poll behind the eye.
        case "axe":
            lge_append(_o, lge_tl_haft(0.250, 0.0130, 0.0100));
            lge_append(_o, lge_st_slab(-0.020, -0.262, 0.014, -0.216, 0.34, 3));
            lge_append(_o, [lge_ring_fill([[0.014, -0.262], [0.070, -0.276], [0.082, -0.238],
                                           [0.066, -0.206], [0.014, -0.216]], "m2", 0.040, -0.240)]);
            lge_append(_o, lge_incise([[0.070, -0.276], [0.082, -0.238], [0.066, -0.206]], false, 0.006));
            break;

        // ---- cloth and fibre --------------------------------------------------------------
        // A shuttle is a POINTED boat with a bobbin showing through its window. Drawn as a plain
        // lozenge it reads as a leaf, which is why the window is not a detail.
        case "shuttle":
            lge_append(_o, [lge_ring_fill([[-0.062, 0], [-0.018, -0.016], [0.018, -0.016],
                                           [0.062, 0], [0.018, 0.016], [-0.018, 0.016]], "m2", 0, 0)]);
            lge_append(_o, lge_sink(lge_ellipse_pts(0, 0, 0.020, 0.010, 12), 0.006, 2, "m1"));
            lge_append(_o, [lge_dot(0, 0, 0.006, "m4")]);
            break;
        case "distaff":
            lge_append(_o, lge_tl_haft(0.120, 0.0090, 0.0070));
            lge_append(_o, lge_tl_bundle(0.150, 0.030, 0.034, _seed + 3));
            break;
        case "dyehook":
            lge_append(_o, lge_tl_haft(0.230, 0.0115, 0.0085));
            lge_append(_o, lge_tl_hook(0.230, 0.030, pi * 0.10, pi * 1.05));
            break;
        case "ropehook":
            lge_append(_o, lge_tl_haft(0.060, 0.0125, 0.0100));
            lge_append(_o, lge_tl_hook(0.060, 0.036, pi * 1.15, LGE_TAU * 0.98));
            break;
        case "needle":
            lge_append(_o, lge_st_beam(0, 0.004, 0, -0.058, 0.0040));
            lge_append(_o, [lge_poly([[0, -0.058], [0.002, -0.070]], false, 0.006, "m0")]);
            break;

        // ---- food -------------------------------------------------------------------------
        // The longest tool in the corpus. The blade is a wide flat panel and the shaft is most of
        // its length, because an oven is deep and the point of a peel is that the baker is not.
        case "peel":
            lge_append(_o, lge_tl_haft(0.300, 0.0120, 0.0090));
            lge_append(_o, lge_tl_panel(0.300, 0.058, 0.130, 0.22));
            lge_append(_o, lge_incise([[-0.040, -0.360], [0.040, -0.360]], false, 0.006));
            break;
        case "cleaver":
            lge_append(_o, lge_tl_haft(0.048, 0.0125, 0.0105));
            lge_append(_o, [lge_ring_fill([[-0.030, -0.048], [0.030, -0.048], [0.034, -0.150],
                                           [-0.026, -0.150]], "m2", 0, -0.100)]);
            lge_append(_o, lge_incise([[-0.030, -0.048], [-0.026, -0.150]], false, 0.006));
            break;
        case "mashpaddle":
            lge_append(_o, lge_tl_haft(0.215, 0.0115, 0.0090));
            lge_append(_o, lge_tl_panel(0.215, 0.038, 0.100, 0.26));
            lge_append(_o, lge_incise([[0, -0.230], [0, -0.305]], false, 0.006));
            break;
        case "dasher":
            lge_append(_o, lge_tl_haft(0.215, 0.0105, 0.0085));
            lge_append(_o, [lge_poly(lge_ellipse_pts(0, -0.238, 0.042, 0.014, 16), true, 0.011, "m1")]);
            lge_append(_o, lge_st_beam(-0.030, -0.238, 0.030, -0.238, 0.0075));
            break;
        case "ladle":
            lge_append(_o, lge_tl_haft(0.155, 0.0100, 0.0080));
            lge_append(_o, lge_tl_bowl(0.155, 0.033, 0.024, 0.032));
            break;
        case "sack":
            lge_append(_o, lge_tl_bundle(0.115, 0.062, 0.086, _seed + 11));
            // The gathered neck: the thing that says sack rather than boulder.
            lge_append(_o, lge_st_taper(0, -0.030, 0.012, 0.014, 0.026, 0, 0.34));
            lge_append(_o, [lge_poly([[-0.016, -0.024], [0.016, -0.024]], false, 0.009, "m0")]);
            break;

        // ---- field and beast --------------------------------------------------------------
        // The scythe is the corpus's largest object and its blade sweeps BEHIND the body, which is
        // why its spec declares depth "back". A curved blade drawn in front crosses the worker's
        // own chest at the working beat.
        case "scythe":
            lge_append(_o, lge_tl_haft(0.400, 0.0130, 0.0100));
            lge_append(_o, lge_st_beam(-0.014, -0.170, -0.060, -0.196, 0.0085));
            // ⛔ THE BLADE IS A STRIP, NOT A FAN, AND THIS IS THE ONE PLACE IN THE TOOL CORPUS WHERE
            // THAT DISTINCTION IS LOAD-BEARING. A scythe blade is a CRESCENT: concave on the cutting
            // side, so it is not star-shaped about any interior point and `pr_trianglefan` would span
            // the concavity and fill in the curve - a scythe drawn as a solid quarter-disc, which is
            // a fan. `lge_strip` walks two rails and handles concavity by construction.
            lge_append(_o, [lge_strip(lge_arc_pts(0.010, -0.400, 0.150, pi * 0.98, pi * 1.62, 14),
                                      lge_arc_pts(0.010, -0.400, 0.118, pi * 0.98, pi * 1.62, 14),
                                      "m2")]);
            lge_append(_o, lge_incise(lge_arc_pts(0.010, -0.400, 0.118, pi * 0.98, pi * 1.62, 14), false, 0.006));
            break;
        case "flail":
            lge_append(_o, lge_tl_haft(0.250, 0.0125, 0.0100));
            // The swingle hangs off the staff on a leather - two masses and a link, which is what
            // makes a flail read as jointed rather than as a long stick.
            lge_append(_o, [lge_poly([[0, -0.250], [0.020, -0.286]], false, 0.008, "m0")]);
            lge_append(_o, lge_st_taper(0.020, -0.404, -0.286, 0.011, 0.016, 0.002, 0.40));
            // The withy binding at the head of the swingle. Two bands, not one: a single band on a
            // stick reads as a mark, two read as a lashing, and the lashing is what says the two
            // pieces are separate objects joined by a leather rather than one bent stick.
            lge_append(_o, lge_st_hoops(0.020, -0.300, -0.286, 0.016, 0.016, 0, 2, 0.008));
            break;
        case "seedbasket":
            lge_append(_o, lge_st_taper(0, -0.140, -0.020, 0.062, 0.042, 0.006, 0.30));
            lge_append(_o, lge_st_hoops(0, -0.140, -0.020, 0.062, 0.042, 0.006, 3, 0.008));
            lge_append(_o, lge_st_pile(0, -0.140, 0.048, 0.026, 5, _seed + 17));
            lge_append(_o, [lge_poly(lge_arc_pts(0, -0.140, 0.052, pi * 1.10, LGE_TAU * 0.95, 10), false, 0.010, "m1")]);
            break;
        case "shears":
            lge_append(_o, lge_tl_blade(-0.006, -0.030, -0.026, -0.146, 0.010));
            lge_append(_o, lge_tl_blade( 0.006, -0.030,  0.026, -0.146, 0.010));
            lge_append(_o, [lge_poly(lge_arc_pts(0, -0.010, 0.024, pi * 1.15, LGE_TAU * 0.85, 10), false, 0.011, "m1")]);
            break;
        case "hoe":
            lge_append(_o, lge_tl_haft(0.420, 0.0125, 0.0095));
            lge_append(_o, lge_st_beam(0, -0.420, 0.030, -0.446, 0.0085));
            lge_append(_o, lge_tl_panel(0.446, 0.040, 0.036, 0.24));
            break;
        case "smoker":
            lge_append(_o, lge_st_taper(0, -0.150, -0.052, 0.030, 0.036, 0.005, 0.34));
            lge_append(_o, lge_st_taper(0, -0.184, -0.150, 0.011, 0.030, 0, 0.34));
            lge_append(_o, lge_tl_bundle(0.052, 0.026, 0.020, _seed + 23));
            break;

        // ---- stone and earth --------------------------------------------------------------
        // A stone mallet is a barrel of wood on a short handle, and the chisel is held in the OTHER
        // hand - which `lge_render_work` places from the off-hand wrist. Two tools, one work loop.
        case "stonemallet":
            lge_append(_o, lge_tl_haft(0.100, 0.0120, 0.0100));
            lge_append(_o, lge_st_taper(0, -0.172, -0.092, 0.030, 0.030, 0.008, 0.42));
            break;
        case "spade":
            lge_append(_o, lge_tl_haft(0.290, 0.0125, 0.0095));
            lge_append(_o, [lge_poly(lge_arc_pts(0, -0.290, 0.030, pi * 0.05, pi * 0.95, 9), false, 0.011, "m1")]);
            lge_append(_o, [lge_ring_fill([[-0.046, 0.010], [0.046, 0.010], [0.038, 0.108],
                                           [0, 0.132], [-0.038, 0.108]], "m2", 0, 0.060)]);
            lge_append(_o, lge_incise([[-0.038, 0.108], [0, 0.132], [0.038, 0.108]], false, 0.006));
            break;
        case "rake":
            lge_append(_o, lge_tl_haft(0.400, 0.0125, 0.0095));
            lge_append(_o, lge_tl_tines(0.400, 0.052, 0.040, 6));
            break;

        // ---- water and trade --------------------------------------------------------------
        case "netneedle":
            lge_append(_o, [lge_ring_fill([[-0.010, 0.020], [0.010, 0.020], [0.014, -0.056],
                                           [0, -0.072], [-0.014, -0.056]], "m2", 0, -0.020)]);
            lge_append(_o, lge_sink(lge_ellipse_pts(0, -0.026, 0.006, 0.018, 10), 0.005, 2, "m1"));
            break;
        case "beetle":
            lge_append(_o, lge_tl_haft(0.120, 0.0115, 0.0095));
            lge_append(_o, lge_st_taper(0, -0.206, -0.112, 0.034, 0.036, 0.006, 0.44));
            break;
        case "bucket":
            lge_append(_o, [lge_poly(lge_arc_pts(0, -0.010, 0.030, pi * 1.05, LGE_TAU * 0.95, 10), false, 0.010, "m1")]);
            lge_append(_o, lge_st_taper(0, 0.010, 0.128, 0.048, 0.036, 0.004, 0.30));
            lge_append(_o, lge_st_hoops(0, 0.010, 0.128, 0.048, 0.036, 0.004, 2, 0.009));
            break;
        case "crate":
            lge_append(_o, lge_st_slab(-0.062, 0.008, 0.062, 0.116, 0.20, 2));
            lge_append(_o, lge_st_frame(-0.062, 0.008, 0.062, 0.116, 0.008));
            lge_append(_o, lge_incise([[-0.062, 0.062], [0.062, 0.062]], false, 0.006));
            break;
        case "quill":
            lge_append(_o, lge_st_beam(0, 0.006, -0.016, -0.058, 0.0045));
            // The vane: a leaf on one side of the shaft. A bare shaft is a stick.
            lge_append(_o, [lge_ring_fill([[-0.016, -0.058], [-0.038, -0.096], [-0.026, -0.116],
                                           [-0.010, -0.084]], "m3", -0.022, -0.090)]);
            break;
        case "pestle":
            lge_append(_o, lge_st_taper(0, -0.118, 0.012, 0.013, 0.022, 0.004, 0.42));
            break;
        case "wickframe":
            lge_append(_o, lge_st_beam(-0.060, -0.010, 0.060, -0.010, 0.0085));
            for (_i = 0; _i < 5; _i++) {
                var _wx = -0.048 + _i * 0.024;
                lge_append(_o, [lge_poly([[_wx, -0.010], [_wx, -0.010 + 0.086]], false, 0.007, "m1")]);
                lge_append(_o, lge_st_taper(_wx, 0.056, 0.086, 0.008, 0.005, 0.002, 0.30));
            }
            break;

        // ---- the day is not all work ------------------------------------------------------
        case "spear":
            lge_append(_o, lge_tl_haft(0.480, 0.0110, 0.0090));
            lge_append(_o, lge_st_taper(0, -0.520, -0.480, 0.014, 0.011, 0.006, 0.34));
            lge_append(_o, [lge_ring_fill([[-0.014, -0.520], [0, -0.562], [0.014, -0.520]], "m1", 0, -0.532)]);
            break;
        case "scroll":
            lge_append(_o, lge_st_slab(-0.070, -0.058, 0.070, 0.020, 0.14, 2));
            lge_append(_o, [lge_poly(lge_ellipse_pts(-0.070, -0.019, 0.011, 0.040, 12), true, 0.009, "m1")]);
            lge_append(_o, [lge_poly(lge_ellipse_pts( 0.070, -0.019, 0.011, 0.040, 12), true, 0.009, "m1")]);
            for (_i = 0; _i < 4; _i++) {
                var _ly = -0.046 + _i * 0.018;
                lge_append(_o, lge_incise([[-0.050, _ly], [0.050, _ly]], false, 0.005));
            }
            break;
        case "hoopstick":
            lge_append(_o, lge_tl_haft(0.200, 0.0100, 0.0080));
            break;
        // ⛔ SHORTENED 0.440 -> 0.340 ON 2026-09-04, AND THE REASON IS ARITHMETIC RATHER THAN TASTE.
        // The staff is held by `elder_sit`, and a seated figure's wrist sits at y 0.173 against a
        // floor at LGE_SOLE = 0.470 - a clearance of 0.297. Any staff longer than that plus the one
        // hand of tolerance the containment check allows (0.094) CANNOT be held vertically without
        // going through the road, whatever the pose does. MEASURED before this edit: the elder's
        // staff reached 0.653, i.e. 0.183 below the ground.
        // ⚠️ IT ONLY BECAME VISIBLE WHEN THE TOOL ROTATION WAS FIXED. While every tool pointed
        // backwards up the arm this staff was drawn rising past the elder's shoulder, where nothing
        // could complain about it. A whole class of length and clearance errors was hidden behind
        // that one sign, and this is the first of them to be measured.
        case "staff":
            lge_append(_o, lge_tl_haft(0.340, 0.0125, 0.0105));
            lge_append(_o, lge_tl_hook(0.340, 0.028, pi * 0.10, pi * 1.10));
            break;
        // A cane is shorter, thinner and carries a knob rather than a shepherd's hook - so it is a
        // DIFFERENT SILHOUETTE beside the drover's staff, not the same stick scaled down. Length
        // 0.250 + the knob puts the tip on the floor under a seated wrist.
        case "cane":
            lge_append(_o, lge_tl_haft(0.250, 0.0105, 0.0088));
            lge_append(_o, [lge_dot(0, -0.250, 0.020, "m2")]);
            lge_append(_o, [lge_dot(0, -0.250, 0.011, "m1")]);
            break;
    }

    // ⛔ MAPPED IN ONE PLACE, AT THE END - the same rule `lge_station_parts` ends on, for the same
    // reason: a recipe that resolved its own colour would need a material parameter threaded through
    // every constructor and would be re-authored per theme.
    return lge_map_roles(_o, lge_mat(_sp.mat));
}

/// ============================================================================================
/// THE WORK LOOP CORPUS
/// ============================================================================================

/// @desc Every work loop id, in the corpus's stable order.
///
/// ⚠️ THE IDS ARE THE LABOUR IDS. Deliberately: a work loop and its pose are one authored thing, and
/// giving them separate id spaces would create a mapping that can go stale in a product whose whole
/// spine is that nothing goes stale. The suite asserts the two arrays are equal element by element,
/// so a loop added to one and not the other fails by name rather than drawing a townsperson at a
/// station with no pose.
function lge_works_all() {
    return lge_labours_all();
}

/// @desc One work loop.
///
/// Fields:
///   labour   the pose id (`lge_labour_spec`)
///   station  the prop id (`lge_station_spec`)
///   tool     the held tool id (`lge_tool_spec`), or "" for a job done bare-handed
///   offhand  a SECOND tool in the other hand, or "". Only three loops use it, and they are the
///            three where the off-hand tool is the job: a mason's chisel, a smith's tongs, a
///            shepherd's held beast.
///   side     0 | 1  which wrist carries the tool. 1 is the near arm.
///   face     "in" (toward the station) | "out" (toward the street)
///   hours    array of [from, to] hour pairs when this loop is worked
///   visible  always true here. `LGE_AWAY` is the only spec with false.
///
/// ⚠️ `hours` IS ADVICE, NOT ENFORCEMENT. `lge_town` builds routines from it, but a buyer assembling
/// their own routines by hand is free to ignore it - a night-shift smith is a legitimate thing to
/// want and nothing here should refuse it. What the hours DO is make `lge_town_default` produce a
/// town that changes plausibly across the day without the buyer authoring a schedule, which is the
/// difference between a demo that sells and a library that needs a day's work before it shows
/// anything.
///
/// @param {String} _id
/// @returns {Struct|Undefined}
function lge_work_spec(_id) {
    if (_id == LGE_AWAY) {
        // Indoors, off-map, asleep. The one spec with no station and no pose.
        return { labour: "", station: "", tool: "", offhand: "", side: 1, face: "in",
                 hours: [[22, 5]], visible: false };
    }
    switch (_id) {
        // ---- metal and fire ---------------------------------------------------------------
        case "smith_strike":    return { labour: "smith_strike",    station: "anvil",        tool: "hammer",      offhand: "tongs", side: 1, face: "in",  hours: [[6.5, 11.5], [13, 18]], visible: true };
        // side 0 -> 1 with lge_labour's `hand` in the same edit: the two tables AGREED with each
        // other (tool in the working wrist) and both disagreed with the STATION, whose work sits at
        // +0.400 in figure space. Only three rows in this file ever used wrist 0 and two of them
        // were this defect; the third (sower_broadcast) is an authored handsoff carry.
        case "smith_bellows":   return { labour: "smith_bellows",   station: "forge",        tool: "bellowsbar",  offhand: "",      side: 1, face: "in",  hours: [[6, 6.5], [12.5, 13]], visible: true };
        case "smith_quench":    return { labour: "smith_quench",    station: "trough",       tool: "tongs",       offhand: "",      side: 1, face: "in",  hours: [[11.5, 12.5]], visible: true };
        case "farrier_rasp":    return { labour: "farrier_rasp",    station: "hoofstand",    tool: "rasp",        offhand: "",      side: 1, face: "in",  hours: [[7, 12], [14, 17.5]], visible: true };
        case "tinker_solder":   return { labour: "tinker_solder",   station: "tinkerbench",  tool: "solderiron",  offhand: "",      side: 1, face: "in",  hours: [[8, 12], [13.5, 18]], visible: true };
        // ---- wood -------------------------------------------------------------------------
        case "sawyer_saw":      return { labour: "sawyer_saw",      station: "sawhorse",     tool: "saw",         offhand: "",      side: 1, face: "in",  hours: [[6, 11], [12.5, 17]], visible: true };
        case "joiner_plane":    return { labour: "joiner_plane",    station: "joinerbench",  tool: "plane",       offhand: "",      side: 1, face: "in",  hours: [[7, 12], [13, 18.5]], visible: true };
        case "cooper_hoop":     return { labour: "cooper_hoop",     station: "barrelcradle", tool: "coopmallet",  offhand: "",      side: 1, face: "in",  hours: [[7.5, 12], [13, 17.5]], visible: true };
        case "turner_lathe":    return { labour: "turner_lathe",    station: "polelathe",    tool: "turnchisel",  offhand: "",      side: 1, face: "in",  hours: [[8, 12], [13.5, 17]], visible: true };
        case "woodward_split":  return { labour: "woodward_split",  station: "chopblock",    tool: "axe",         offhand: "",      side: 1, face: "in",  hours: [[6, 10.5], [15, 18]], visible: true };
        // ---- cloth and fibre --------------------------------------------------------------
        case "weaver_shuttle":  return { labour: "weaver_shuttle",  station: "loom",         tool: "shuttle",     offhand: "",      side: 1, face: "in",  hours: [[7, 12], [13, 19]], visible: true };
        case "spinner_wheel":   return { labour: "spinner_wheel",   station: "spinwheel",    tool: "distaff",     offhand: "",      side: 1, face: "in",  hours: [[8, 12], [14, 19.5]], visible: true };
        case "dyer_vat":        return { labour: "dyer_vat",        station: "dyevat",       tool: "dyehook",     offhand: "",      side: 1, face: "in",  hours: [[6.5, 11], [13, 16.5]], visible: true };
        case "roper_walk":      return { labour: "roper_walk",      station: "ropewalk",     tool: "ropehook",    offhand: "",      side: 1, face: "in",  hours: [[8, 12], [13.5, 17]], visible: true };
        case "tailor_stitch":   return { labour: "tailor_stitch",   station: "cuttingtable", tool: "needle",      offhand: "",      side: 1, face: "out", hours: [[8, 12.5], [13.5, 19]], visible: true };
        // ---- food -------------------------------------------------------------------------
        // A baker's day starts before everyone else's and finishes early, which is the single most
        // legible piece of "the town changes across the day" a buyer sees in the demo.
        case "baker_peel":      return { labour: "baker_peel",      station: "oven",         tool: "peel",        offhand: "",      side: 1, face: "in",  hours: [[4.5, 8]], visible: true };
        case "baker_knead":     return { labour: "baker_knead",     station: "kneadtrough",  tool: "",            offhand: "",      side: 1, face: "in",  hours: [[3, 4.5], [14, 16]], visible: true };
        case "butcher_block":   return { labour: "butcher_block",   station: "butcherblock", tool: "cleaver",     offhand: "",      side: 1, face: "in",  hours: [[6, 10], [12.5, 15.5]], visible: true };
        case "brewer_stir":     return { labour: "brewer_stir",     station: "mashtun",      tool: "mashpaddle",  offhand: "",      side: 1, face: "in",  hours: [[5.5, 10], [13, 17]], visible: true };
        case "dairy_churn":     return { labour: "dairy_churn",     station: "churn",        tool: "dasher",      offhand: "",      side: 1, face: "in",  hours: [[5, 9]], visible: true };
        case "cook_ladle":      return { labour: "cook_ladle",      station: "cookfire",     tool: "ladle",       offhand: "",      side: 1, face: "in",  hours: [[10.5, 13.5], [17, 20]], visible: true };
        case "miller_sack":     return { labour: "miller_sack",     station: "millhopper",   tool: "sack",        offhand: "",      side: 1, face: "in",  hours: [[7, 11.5], [13, 17]], visible: true };
        // ---- field and beast --------------------------------------------------------------
        case "reaper_scythe":   return { labour: "reaper_scythe",   station: "standingcorn", tool: "scythe",      offhand: "",      side: 1, face: "in",  hours: [[5.5, 11], [14, 19]], visible: true };
        case "thresher_flail":  return { labour: "thresher_flail",  station: "threshfloor",  tool: "flail",       offhand: "",      side: 1, face: "in",  hours: [[8, 12], [13.5, 18]], visible: true };
        case "sower_broadcast": return { labour: "sower_broadcast", station: "furrow",       tool: "seedbasket",  offhand: "",      side: 0, face: "out", hours: [[6, 10.5]], visible: true };
        case "shepherd_shear":  return { labour: "shepherd_shear",  station: "shearstool",   tool: "shears",      offhand: "",      side: 1, face: "in",  hours: [[9, 12], [13.5, 17]], visible: true };
        case "gardener_hoe":    return { labour: "gardener_hoe",    station: "gardenbed",    tool: "hoe",         offhand: "",      side: 1, face: "in",  hours: [[6.5, 11], [15.5, 19]], visible: true };
        case "beeward_smoke":   return { labour: "beeward_smoke",   station: "hive",         tool: "smoker",      offhand: "",      side: 1, face: "in",  hours: [[10, 12]], visible: true };
        // ---- stone and earth --------------------------------------------------------------
        case "mason_chisel":    return { labour: "mason_chisel",    station: "bankerstone",  tool: "stonemallet", offhand: "turnchisel", side: 1, face: "in", hours: [[7, 12], [13, 18]], visible: true };
        case "potter_wheel":    return { labour: "potter_wheel",    station: "potterwheel",  tool: "",            offhand: "",      side: 1, face: "in",  hours: [[8, 12], [13.5, 18]], visible: true };
        case "digger_spade":    return { labour: "digger_spade",    station: "trench",       tool: "spade",       offhand: "",      side: 1, face: "in",  hours: [[7, 11.5], [13, 17]], visible: true };
        case "collier_rake":    return { labour: "collier_rake",    station: "charclamp",    tool: "rake",        offhand: "",      side: 1, face: "in",  hours: [[6, 10], [16, 21]], visible: true };
        // ---- water and trade --------------------------------------------------------------
        case "fisher_mend":     return { labour: "fisher_mend",     station: "netframe",     tool: "netneedle",   offhand: "",      side: 1, face: "out", hours: [[13, 18]], visible: true };
        case "washer_beat":     return { labour: "washer_beat",     station: "washstone",    tool: "beetle",      offhand: "",      side: 1, face: "in",  hours: [[7, 12]], visible: true };
        // ⛔⛔ THESE HOURS WERE WIDENED 2026-09-03 TO CLOSE A HOLE IN THE COMMONS' COVERAGE, AND THE
        // HOLE WAS EMPTYING THE STREET AT DINNER TIME. `lge_commons_all`'s header claims the four
        // commons loops are "open across the whole waking day, which is what lets the generator fill
        // any hole without splitting it". MEASURED by `Internal_Ops/_hour_curve.js` against this very
        // table, that claim was FALSE: the union of the four left 5-6, 8-9, 13-14 and 20-21.5
        // uncovered. Anyone whose own trade is shut in one of those windows is handed LGE_AWAY by
        // `lge_routine_for` and goes indoors - and at 13:00 only 14 of 46 trades are open, so up to
        // THIRTY-TWO townspeople vanished from the street at once, on a product whose whole claim is
        // that people are always somewhere. A prose claim outrunning its code, which is exactly what
        // this product's own `claim_scan.js` exists to catch and did not. It is now asserted in
        // `lge_selftest` instead of merely stated here.
        case "waterward_draw":  return { labour: "waterward_draw",  station: "well",         tool: "bucket",      offhand: "",      side: 1, face: "in",  hours: [[5, 9], [11.5, 14], [17, 19]], visible: true };
        case "carter_load":     return { labour: "carter_load",     station: "cart",         tool: "crate",       offhand: "",      side: 1, face: "in",  hours: [[8, 11], [14, 17]], visible: true };
        // The monger faces the STREET, not the stall - the only correct facing for a person calling
        // a price, and the reason `face` is a field rather than a constant.
        case "monger_call":     return { labour: "monger_call",     station: "stall",        tool: "",            offhand: "",      side: 1, face: "out", hours: [[8, 13], [14, 17.5]], visible: true };
        case "scribe_write":    return { labour: "scribe_write",    station: "writingdesk",  tool: "quill",       offhand: "",      side: 1, face: "in",  hours: [[8.5, 12], [13.5, 18]], visible: true };
        case "herbalist_pestle":return { labour: "herbalist_pestle",station: "herbbench",    tool: "pestle",      offhand: "",      side: 1, face: "in",  hours: [[9, 12], [14, 18]], visible: true };
        case "chandler_dip":    return { labour: "chandler_dip",    station: "diprack",      tool: "wickframe",   offhand: "",      side: 1, face: "in",  hours: [[8, 12], [13, 17]], visible: true };
        // ---- the day is not all work ------------------------------------------------------
        // ⚠️ THESE SIX CARRY THE NIGHT. A town whose every loop stops at 19:00 is empty at 20:00, and
        // an empty street is the thing a buyer's player reads as "the schedule broke". The watch works
        // through the dark, the brazier is lit, and that is what makes the night look authored.
        case "watch_stand":     return { labour: "watch_stand",     station: "brazier",      tool: "spear",       offhand: "",      side: 1, face: "out", hours: [[19, 24], [0, 6]], visible: true };
        case "herald_read":     return { labour: "herald_read",     station: "postboard",    tool: "scroll",      offhand: "",      side: 1, face: "out", hours: [[9, 10], [16, 17]], visible: true };
        case "child_hoop":      return { labour: "child_hoop",      station: "hoopring",     tool: "hoopstick",   offhand: "",      side: 1, face: "out", hours: [[10, 12], [15, 19]], visible: true };
        // Second half of the commons-coverage repair above: the afternoon hole ran 12.5-14, and an
        // elder on the village bench through the whole afternoon and into dusk is the natural place
        // for it. Together with waterward_draw's widened windows the four commons now cover 5.0-21.5
        // without a gap, which is what `lge_routine_for` needs to fill anyone's idle slot.
        case "elder_sit":       return { labour: "elder_sit",       station: "villagebench", tool: "cane",        offhand: "",      side: 1, face: "out", hours: [[9, 12.5], [12.5, 21.5]], visible: true };
        case "priest_bless":    return { labour: "priest_bless",    station: "shrine",       tool: "",            offhand: "",      side: 1, face: "in",  hours: [[6, 7], [12, 12.5], [18, 19]], visible: true };
        case "drover_goad":     return { labour: "drover_goad",     station: "pengate",      tool: "staff",       offhand: "",      side: 1, face: "in",  hours: [[5.5, 7], [17.5, 19.5]], visible: true };
        // ⛔ NO PLAUSIBLE FALLBACK. Third time in this package, same reason each time: a stand-in
        // satisfies the assertion that exists to catch the typo.
        default: return undefined;
    }
}

/// @desc Which work loop is worked at station `_station_id`, or "" if none.
///
/// ⚠️ THE REVERSE LOOKUP EXISTS BECAUSE A STATION HAS NO IDEA WHO WORKS AT IT, and that is the right
/// way round: `lge_station` knows about geometry and nothing about trades, which is what lets a buyer
/// place a prop with nobody at it. The one consumer that needs the reverse direction is the suite's
/// depth-ordering gate, which has to know where the worker's body falls before it can ask whether a
/// front-drawn part crosses them.
function lge_station_worker(_station_id) {
    var _all = lge_works_all();
    for (var _i = 0; _i < array_length(_all); _i++) {
        var _w = lge_work_spec(_all[_i]);
        if (!is_undefined(_w) && _w.station == _station_id) return _all[_i];
    }
    return "";
}

/// @desc Is work loop `_id` one of its own working hours at time `_t`?
///
/// ⚠️ WRAP-SAFE, and that is not a nicety - `watch_stand` is authored [[19,24],[0,6]] and a naive
/// `from <= t && t < to` answers "no" for the watch at 23:00 in a product whose Gate 2 evidence is
/// that the incumbent's night-spanning routines break.
///
/// @param {String} _id
/// @param {Real} _t  hour, any sign, wrapped internally
/// @returns {Bool}
function lge_work_open(_id, _t) {
    var _sp = lge_work_spec(_id);
    if (is_undefined(_sp)) return false;
    var _w = lge_wrap(_t);
    var _n = array_length(_sp.hours);
    for (var _i = 0; _i < _n; _i++) {
        var _h = _sp.hours[_i];
        if (_h[0] < _h[1]) { if (_w >= _h[0] && _w < _h[1]) return true; }
        else               { if (_w >= _h[0] || _w < _h[1]) return true; }
    }
    return false;
}

/// @desc How many hours of the day a loop is worked. Used by the coverage gate and by `lge_town`
/// when it decides who is worth putting on a small street.
function lge_work_hours_total(_id) {
    var _sp = lge_work_spec(_id);
    if (is_undefined(_sp)) return 0;
    var _s = 0;
    var _n = array_length(_sp.hours);
    for (var _i = 0; _i < _n; _i++) {
        var _h = _sp.hours[_i];
        _s += (_h[0] < _h[1]) ? (_h[1] - _h[0]) : (LGE_DAY - _h[0] + _h[1]);
    }
    return _s;
}

/// ============================================================================================
/// THE POSE A WORK LOOP IS ACTUALLY DRAWN IN
/// ============================================================================================

/// @desc The armature pose for work loop `_id` at phase `_u`, WITH the station's seat applied.
///
/// ⛔⛔ THIS FUNCTION EXISTS BECAUSE A POSE AND A STATION ARE TWO HALVES OF ONE PICTURE AND NOTHING
/// USED TO JOIN THEM. `lge_labour_pose` knows the SHAPE of sitting and nothing about the height of
/// the thing being sat on; `lge_station_spec` knows the height and nothing about the sitter. Until
/// 2026-09-03 no code owned the join, so eight townspeople were solved into a sitting shape at
/// standing height and drawn standing on their own furniture - a woman on top of a bench with its
/// back rail through her skirt (Internal_Ops/_c_elder.png, cropped and looked at).
///
/// ⭐ AND IT IS A FUNCTION RATHER THAN FOUR LINES INSIDE `lge_figure_parts` FOR ONE REASON: THE SUITE
/// HAS TO BE ABLE TO ASK THE PRODUCT WHAT POSE IT DRAWS. An assertion that rebuilt the join itself
/// would be verifying against something it had just written - this wing's own standing law - and
/// would stay green if the renderer stopped applying the seat tomorrow. One derivation, two readers.
/// A buyer gets the same benefit: this is the documented way to get the exact pose a townsperson is
/// drawn in, for a custom renderer.
///
/// ⚠️ WALKING IS NOT A WORK LOOP. `lge_walk_pose` is used while somebody is crossing the street; they
/// are not at the station and must not be seated by it. `lge_figure_parts` chooses between the two
/// and only ever calls this one for a worker who has arrived.
///
/// @param {String} _id  from lge_works_all()
/// @param {Real} _u     phase, 0..1
/// @returns {Struct|Undefined} undefined for an unknown loop - never a plausible stand-in
/// @param {Struct} [_adj] optional {dh, dlean}. Absent = the SOLVED adjustment from
///                        `lge_work_reach`, which is what every drawing call wants. Supplied = that
///                        exact adjustment, which is how the solver evaluates a candidate without
///                        recursing into its own cache.
function lge_work_pose(_id, _u, _adj = undefined) {
    var _w = lge_work_spec(_id);
    if (is_undefined(_w)) return undefined;
    var _a = is_struct(_adj) ? _adj : lge_work_reach(_id);
    var _pose = lge_labour_pose(_w.labour, _u, _a);
    if (is_undefined(_pose)) return undefined;

    // ⛔ THE TEST IS THE LOOP'S OWN DECLARED STANCE, NEVER "the hip angle looks large". An implicit
    // test would silently start seating any future loop whose thigh happened to pass a threshold,
    // and silently stop seating this one if the stance were ever re-tuned.
    var _lb = lge_labour_spec(_w.labour);
    var _st = lge_station_spec(_w.station);
    if (!is_undefined(_lb) && !is_undefined(_st) && _lb.stance == "seated"
        && variable_struct_exists(_st, "seat") && _st.seat > 0) {
        _pose.hip_h = _st.seat + LGE_SEAT_RISE;
    }
    return _pose;
}

/// ============================================================================================
/// THE REACH SOLVE — putting the hands on the work
/// ============================================================================================

/// @desc How close this loop's hands or tool get to its station's work point, under a given
/// adjustment. Lower is better; 0 means the tool covers the work point.
///
/// ⚠️ THIS IS A SECOND MEASUREMENT OF THE QUANTITY THE SUITE ASSERTS, AND THAT IS DELIBERATE. This
/// wing's law is normally "one derivation, two readers" - two copies of a JOIN drift apart silently.
/// This is the opposite case: one of the two is an OPTIMISER and the other is a JUDGE, and a judge
/// that shares its subject's arithmetic cannot catch an error in it. If they disagree the suite goes
/// red, which is exactly what happened when the suite's own version was found merging both hands'
/// tools into one box. Keep them independent on purpose.
///
/// ⚠️ IT RETURNS THE SIGNED OFFSET, NOT JUST THE DISTANCE, BECAUSE THE SOLVER IS A CORRECTION AND
/// NOT A SEARCH. `d` says how wrong the pose is; `dy` says which WAY, and `-dy / stature` is exactly
/// the change in `height` that closes it, because `height` is defined as how far below the shoulder
/// the hands work. A scalar distance would leave the solver no choice but to try values and compare
/// - which is what the first version of this did, at 119 candidates x 8 phases x 46 loops.
///
/// @param {String} _id  work loop id
/// @param {Struct} _adj {dh, dlean}
/// @param {Real} _wx    the work point in FIGURE space
/// @param {Real} _wy
/// @param {Real} _n     phases to sample
/// @returns {Array} [d, dx, dy, shoulderGap] - the closest approach over the cycle, its signed
///                  offset from the work point, and how far the nearest SHOULDER stayed from the
///                  work at that phase minus everything the arm and tool can span (>0 = the target
///                  is outside the arm's reach and no aim correction can ever land it)
function lge_work_reach_measure(_id, _adj, _wx, _wy, _n) {
    var _ws = lge_work_spec(_id);
    if (is_undefined(_ws)) return [999, 0, 0, 999];
    var _best = 999, _bdx = 0, _bdy = 0, _gap = 999;
    var _span_avg = (LGE_SOLE - LGE_CROWN) * lge_build("average").stature;
    var _armlen = _span_avg * (0.166 + 0.152);
    for (var _i = 0; _i < _n; _i++) {
        var _u = _i / _n;
        var _pose = lge_work_pose(_id, _u, _adj);
        if (is_undefined(_pose)) continue;
        var _arm = lge_armature("average", _pose);
        var _reach_here = _armlen;
        for (var _sd = 0; _sd < 2; _sd++) {
            var _wr = _arm.wrist[_sd];
            var _d = point_distance(_wr[0], _wr[1], _wx, _wy);
            if (_d < _best) { _best = _d; _bdx = _wr[0] - _wx; _bdy = _wr[1] - _wy; }
        }
        var _bx = lge_tool_boxes(_arm, _ws, _u);
        for (var _bi = 0; _bi < array_length(_bx); _bi++) {
            var _tb = _bx[_bi];
            // Signed, matching the wrist branch: where the TOOL is relative to the work.
            var _dx = (_wx < _tb[0]) ? _tb[0] - _wx : ((_wx > _tb[2]) ? _tb[2] - _wx : 0);
            var _dy = (_wy < _tb[1]) ? _tb[1] - _wy : ((_wy > _tb[3]) ? _tb[3] - _wy : 0);
            var _dt = sqrt(_dx * _dx + _dy * _dy);
            if (_dt < _best) { _best = _dt; _bdx = _dx; _bdy = _dy; }
            // How much further than the bare arm this tool lets the holding wrist reach.
            var _tcx = (_tb[0] + _tb[2]) * 0.5, _tcy = (_tb[1] + _tb[3]) * 0.5;
            var _w0 = _arm.wrist[0], _w1 = _arm.wrist[1];
            var _wr2 = (point_distance(_w0[0], _w0[1], _tcx, _tcy)
                      <= point_distance(_w1[0], _w1[1], _tcx, _tcy)) ? _w0 : _w1;
            var _far = max(point_distance(_wr2[0], _wr2[1], _tb[0], _tb[1]),
                           point_distance(_wr2[0], _wr2[1], _tb[2], _tb[3]),
                           point_distance(_wr2[0], _wr2[1], _tb[0], _tb[3]),
                           point_distance(_wr2[0], _wr2[1], _tb[2], _tb[1]));
            if (_armlen + _far > _reach_here) _reach_here = _armlen + _far;
        }
        for (var _sd = 0; _sd < 2; _sd++) {
            var _sh = _arm.shoulder[_sd];
            var _g = point_distance(_sh[0], _sh[1], _wx, _wy) - _reach_here;
            if (_g < _gap) _gap = _g;
        }
    }
    return [_best, _bdx, _bdy, _gap];
}

/// @desc The pose adjustment that puts this loop's hands on its station's work. Solved once, cached.
///
/// ⛔⛔ THE DEFECT THIS EXISTS FOR IS THE ONE FOUR SESSIONS FAILED TO NAME, AND IT IS NOT A POSE BUG:
/// `height` and `lean` are authored per LOOP in `lge_labour_spec`; where the work IS is authored per
/// STATION in `lge_station_spec`. Two tables, one physical quantity, and until 2026-09-04 nothing in
/// the shipped product read the second one at all. So they drifted, 25 of 46 workers were drawn
/// beside work they were not touching, and every attempt to fix it was a human retyping one table to
/// agree with the other - which is why each attempt fixed some loops and broke others.
///
/// ⭐ SOLVING IT IS STRICTLY BETTER THAN RE-AUTHORING IT, because the solve cannot go stale. Move a
/// station, raise a bench, change an arm length or retune a verb, and the hands follow. The suite's
/// reach assertion stops policing 46 typed numbers and starts policing one solver.
///
/// ⚠️ AN ADJUSTMENT, NEVER AN OVERRIDE, AND THE SEARCH IS BIASED TOWARD DOING NOTHING. The authored
/// `height` and `lean` remain the starting point and the score adds a small penalty per unit of
/// correction, so a loop that is already right is left alone to the last bit and a loop that is
/// wrong moves as little as the geometry allows. Two earlier attempts OVERWROTE the shoulder - one
/// collapsed four loops onto the same pose and turned the distinctness gate red, the other threw
/// away the verb's own stroke - and `lge_labour_pose`'s header records both.
///
/// ⛔ ONCE UNDER THE BAR, CLOSER IS NOT BETTER. The bar is one hand, from anatomy; a wrist 0.01 from
/// the work and one 0.09 from it are the same picture, and treating the first as better would spend
/// real stoop on nothing. So the score FLOORS the distance at the bar, which makes the tie-break the
/// size of the correction rather than a meaningless third decimal place.
///
/// ⛔⛔ A CORRECTION, NOT A SEARCH - AND THE SEARCH WAS BUILT FIRST AND MEASURED TOO SLOW TO SHIP.
/// The first version swept 7 lean values x 17 height values x 8 phases = 952 armature-and-tool
/// solves PER LOOP, 44,000 for a town, and the in-engine suite was still grinding through it after
/// ten minutes. That is not merely slow to test: a buyer's first frame pays the same bill, and a
/// townsperson that takes seconds to appear is a product defect however correct the pose is.
///
/// ⭐ THE CLOSED FORM WAS AVAILABLE THE WHOLE TIME AND IT IS IN THIS FILE'S OWN VOCABULARY.
/// `height` is DEFINED as how far below the shoulder the hands work, so a hand `dy` too high is
/// corrected by exactly `-dy / stature` - no comparison of candidates required. The offline tool
/// `Internal_Ops/_join_solve.js` had been doing precisely this arithmetic for two sessions and it
/// was never brought inside. Six measured steps replace 952 guessed ones, a 158x cut, and the loop
/// keeps the best pose it has seen rather than its last one, so a step that overshoots cannot make
/// a loop worse than not solving it at all.
///
/// ⚠️ THE STOOP IS THE SECOND LEVER AND IT IS ONLY REACHED FOR WHEN THE FIRST CANNOT WORK. `gap` is
/// the distance from the nearest shoulder to the work MINUS everything the arm and tool can span:
/// positive means the target is outside the arm's reach and NO aim correction will ever land it -
/// you close that by bending, which is `lean`. Separating the two is the distinction four sessions
/// failed to make, and without it every fix drove the aim harder at a target it could not have hit.
///
/// @param {String} _id work loop id
/// @returns {Struct} {dh, dlean} - {0, 0} for an unknown loop, a missing station, or a loop that
///                   declares `handsoff`
function lge_work_reach(_id) {
    if (!variable_global_exists("lge_reach_cache")) global.lge_reach_cache = {};
    if (variable_struct_exists(global.lge_reach_cache, _id)) {
        return variable_struct_get(global.lge_reach_cache, _id);
    }
    var _zero = { dh: 0, dlean: 0 };
    var _ws = lge_work_spec(_id);
    if (is_undefined(_ws)) return _zero;
    var _lb = lge_labour_spec(_ws.labour);
    var _stn = lge_station_spec(_ws.station);
    if (is_undefined(_lb) || is_undefined(_stn)) return _zero;

    // ⭐ THE LOOPS THAT ARE MEANT TO MISS. Four of the 46 hold their hands away from their station by
    // design - a monger calling a price, a priest blessing, a sower broadcasting seed, a child
    // driving a hoop ahead of itself. Solving those onto their station would be a WORSE picture, so
    // the exemption is a DECLARED FIELD on the labour spec rather than a list of ids here: a list in
    // this file could be padded quietly to silence the gate, which this suite's own station check
    // records as the only way an exemption can be made dishonest.
    if (variable_struct_exists(_lb, "handsoff") && _lb.handsoff) {
        variable_struct_set(global.lge_reach_cache, _id, _zero);
        return _zero;
    }

    // The work point in FIGURE space - the same transform `lge_work_beat` and the suite both use.
    var _wx = _stn.work[0] - _stn.stand;
    var _wy = _stn.work[1];
    var _bar = (LGE_SOLE - LGE_CROWN) * 0.10;

    var _stature = lge_build("average").stature;
    var _dh = 0, _dl = 0;
    var _bh = 0, _bl = 0, _bd = 999;

    // ⚠️ SIX STEPS, AND THE BOUND IS NOT ARBITRARY: each step corrects the whole measured residual,
    // so a well-behaved loop lands on the first or second. Six is head-room for the ones where the
    // aim and the stoop interact (moving the shoulder down changes the aim that was just solved),
    // and a hard bound is what stops an oscillating pair of levers running forever in a buyer's
    // first frame.
    repeat (6) {
        var _m = lge_work_reach_measure(_id, { dh: _dh, dlean: _dl }, _wx, _wy, 8);
        // ⛔ KEEP THE BEST POSE SEEN, NEVER THE LAST ONE. A correction that overshoots would
        // otherwise be shipped simply because it happened to be computed last, which would make the
        // solver capable of being WORSE than not solving at all - the one outcome that would make
        // this whole mechanism a regression.
        if (_m[0] < _bd) { _bd = _m[0]; _bh = _dh; _bl = _dl; }
        if (_m[0] <= _bar) break;

        if (_m[3] > 0) {
            // Out of reach: bend. `LGE_LEAN_RAD` converts lean to radians of stoop and the shoulder
            // drops by (hip - shoulder) * (1 - cos), so the step is deliberately modest and
            // re-measured rather than solved in one jump - the drop is not linear in `lean`.
            _dl = min(_dl + 0.12, 0.60);
        }
        // The aim, in the units `height` is defined in. Clamped per step so one bad measurement
        // cannot throw the arm across the body.
        _dh += clamp(-_m[2] / max(0.0001, _stature), -0.30, 0.30);
        _dh = clamp(_dh, -0.60, 0.90);
    }
    var _out = { dh: _bh, dlean: _bl };
    variable_struct_set(global.lge_reach_cache, _id, _out);
    return _out;
}

/// @desc The phase at which this loop's hands or tool come CLOSEST to the work its station declares
/// — the one frame of the cycle in which the worker is unambiguously doing the job.
///
/// ⛔⛔ THIS EXISTS BECAUSE THE GALLERY WAS DRAWING THE WRONG FRAME, AND IT EXPLAINS THREE SESSIONS
/// OF FAILED FIXES. The suite asserts that every worker's hands reach their work, measured at the
/// CLOSEST APPROACH over the whole cycle - which is the right way to assert it, because a hammer is
/// on the anvil for a fraction of its stroke. But `lge_bk_loops` drew each cell at
/// `((i mod 4) + 1) / 5.5`, an ARBITRARY phase, so the gate was grading the best frame of
/// twenty-four while the store sheet showed one picked by an index.
///
/// MEASURED 2026-09-04 by cropping `cook_ladle` at 12x: the ladle is drawn, correctly, and it points
/// UP AND AWAY from the cauldron - a woman standing beside a pot holding a stick aimed at nothing.
/// That cell's closest approach is 0.099 against a bar of 0.094, i.e. it very nearly passes, and the
/// frame a buyer sees is not the frame that number is about. `smith_strike` CLEARS the gate outright
/// and its cell still shows a smith beside her anvil with the hammer down by her knee.
///
/// ⭐ So the arm angles, the shoulder share and the pose heights were never the whole story: the
/// three previous sessions were optimising a quantity the sheet does not display. Drawing the cell
/// at this phase makes the picture and the instrument finally describe the same moment.
///
/// ⚠️ IT IS A SEARCH, NOT A LOOKUP, AND IT IS NOT FREE - one armature solve per sampled phase. Call
/// it once and cache it; a buyer wanting the hammer-blow frame to hang a sound effect on should do
/// the same. The sample count matches the suite's own sweep so the two cannot disagree about which
/// frames exist.
///
/// ⚠️ AND IT DELIBERATELY DOES NOT ASSERT ANYTHING. A loop whose hands never come near its station
/// (a monger calling a price, a priest blessing) still returns its least-bad phase, because this
/// function's job is to pick a frame, not to grade one. The grading lives in the suite, where it can
/// go red.
///
/// @param {String} _id work loop id
/// @returns {Real} phase in [0, 1), or 0.5 for an unknown loop
function lge_work_beat(_id) {
    var _ws = lge_work_spec(_id);
    if (is_undefined(_ws)) return 0.5;
    var _stn = lge_station_spec(_ws.station);
    if (is_undefined(_stn)) return 0.5;
    // The work point in FIGURE space: the cell offsets the figure by the station's `stand`, so the
    // station's origin sits at -stand from the figure. Same transform the suite uses.
    var _wx = _stn.work[0] - _stn.stand;
    var _wy = _stn.work[1];
    var _best = 999, _beat = 0.5;
    for (var _i = 0; _i < LGE_BEAT_SAMPLES; _i++) {
        var _ph = _i / LGE_BEAT_SAMPLES;
        var _pose = lge_work_pose(_id, _ph);
        if (is_undefined(_pose)) continue;
        var _arm = lge_armature("average", _pose);
        var _d = 999;
        for (var _sd = 0; _sd < 2; _sd++) {
            var _wr = _arm.wrist[_sd];
            _d = min(_d, point_distance(_wr[0], _wr[1], _wx, _wy));
        }
        // Per TOOL, never a box over both hands - see lge_tool_boxes' header for what that cost.
        var _tg = lge_tool_gap(_arm, _ws, _ph, _wx, _wy);
        if (_tg >= 0) _d = min(_d, _tg);
        if (_d < _best) { _best = _d; _beat = _ph; }
    }
    return _beat;
}

/// How many phases `lge_work_beat` samples. Matches the suite's own reach sweep on purpose: two
/// sweeps over different frame sets could disagree about which frame is best, and then the sheet
/// would draw a frame the gate never graded.
#macro LGE_BEAT_SAMPLES 24

/// ============================================================================================
/// THE ENVELOPE — the geometry this work loop PUBLISHES, and the only source for it
/// ============================================================================================

/// @desc How much ground a work loop occupies, in stature units, as [left, right] about the
/// station's own origin: the prop's footprint, the worker's standing room, and the tool's reach.
///
/// ⛔⛔ IT IS ONE FUNCTION BECAUSE TWO CONSUMERS NEED THE SAME ANSWER AND MUST NOT DERIVE IT
/// SEPARATELY. `lge_town_make` spaces the street with it, and `lge_selftest`'s containment gate
/// asserts the DRAWN bounds against it. If the placer computed its own spacing, the gate would be
/// checking one number against a different one and could pass over a stall standing inside its
/// neighbour - this wing's constitution calls that the half-a-field defect, and its own worked
/// example is a checker citing a validation that only ever ran on the failing side of another check.
///
/// ⚠️ AND `ARCHITECTURE.md` §6.5's WORDING WAS WRONG, WHICH IS WHY THIS EXISTS AT ALL. It says
/// "figure + prop + tool stay inside the station's declared FOOTPRINT" - and they demonstrably do
/// not: an anvil's foot is [-0.20, 0.20] and its smith stands at -0.30, i.e. outside it by half a
/// body. Asserting the literal sentence would have produced a gate that fails on 46 of 46 correct
/// stations, and the natural response to a gate that red-lines everything is to delete it. The
/// envelope is the thing that was actually meant.
///
/// ⛔⛔ IT IS MEASURED FROM THE PRODUCT'S OWN GEOMETRY, NOT DECLARED. THE FIRST VERSION DECLARED IT
/// AND THE SUITE FAILED ON 103 OF 184 SAMPLES.
///
/// That version allowed the worker "half a shoulder span either side", 0.26, taken from the widest
/// entry in the build table. MEASURED 2026-09-03: it is wrong by up to 0.30 on `scribe_write`,
/// because a SEATED figure is not shoulder-wide - the seated stance foreshortens the thighs to 2% of
/// their length, which throws both knees out sideways, and `lge_body_halfwidth` correctly takes the
/// below-hip width from the outermost knee. A seated scribe is nearly twice as wide as a standing one.
///
/// ⭐ THE FIX IS NOT A BIGGER NUMBER. Widening the allowance until today's corpus fits is a bar
/// invented to fit the data, and it would be wrong again the first time somebody authors a wider
/// stance. Building the figure and asking how wide it IS makes the street spacing correct BY
/// CONSTRUCTION rather than correct-if-the-guess-holds, and it moves the gate's job from "does the
/// drawing match the declaration" to "do two neighbours overlap" - which is the defect that matters.
///
/// ⚠️ SAMPLED AT FOUR PHASES ON THE WIDEST BUILD. The pose is a continuous function of phase and the
/// tool is placed from the wrist, so the widest moment of a swing is somewhere in the middle of the
/// cycle - measuring at phase 0 would measure the rest position. `broad` is used because the envelope
/// has to hold whoever the buyer puts there, and it is the widest entry in `lge_builds_all`.
///
/// ⚠️ AND IT IS NOT FREE: four figures plus a station, about 4,000 parts. It is called once per place
/// when a town is built, and once per loop by the suite. Do not call it per frame; a buyer never
/// needs to, because the town keeps its places.
///
/// ⭐ MEMOISED, AND THE MEMO IS SAFE BECAUSE THE FUNCTION IS PURE. Measured cost: a town of 46 places
/// asks for 46 envelopes, each of which builds four figures and a prop - about 4,000 parts per call
/// and 180,000 per town. The suite builds several towns and the demo room rebuilds one on every press
/// of R and T. Nothing about the answer can change at run time: the corpus is a switch statement, the
/// geometry is deterministic and nothing here calls `random()`.
///
/// ⚠️ AND THE CACHE IS NAMED `lge_env_cache`, NOT `lge_work_envelope`. GML has ONE namespace for
/// globals and script functions, and naming a cache after the function it caches OVERWRITES that
/// function - measured on this product the same day (`DoDiv :1: Malformed variable`).
function lge_work_envelope(_id) {
    if (!variable_global_exists("lge_env_cache")) global.lge_env_cache = {};
    if (variable_struct_exists(global.lge_env_cache, _id)) {
        return variable_struct_get(global.lge_env_cache, _id);
    }
    var _v = lge_work_envelope_measure(_id);
    variable_struct_set(global.lge_env_cache, _id, _v);
    return _v;
}

/// @desc The measurement itself. Separate from the memo so the suite can call it directly and so the
/// cache cannot be mistaken for the thing it caches.
///
/// @param {String} _id
/// @returns {Array|Undefined} [left, right] in stature units, about the STATION's origin
function lge_work_envelope_measure(_id) {
    var _w = lge_work_spec(_id);
    if (is_undefined(_w) || !_w.visible) return undefined;
    var _st = lge_station_spec(_w.station);
    if (is_undefined(_st)) return undefined;

    var _lo = _st.foot[0];
    var _hi = _st.foot[1];

    // The prop itself, as drawn rather than as declared - a recipe can legitimately overhang its own
    // declared footprint (an awning, a cart's shaft) and the street still has to hold it.
    var _sp = lge_station_parts(_w.station, 1);
    if (!is_undefined(_sp)) {
        var _both = [];
        lge_append(_both, _sp.back);
        lge_append(_both, _sp.front);
        if (array_length(_both) > 0) {
            var _sb = lge_render_bounds(_both);
            _lo = min(_lo, _sb[0]);
            _hi = max(_hi, _sb[2]);
        }
    }

    // The worker, their clothes and everything in their hands.
    //
    // ⛔⛔ TWELVE PHASES AND A MARGIN, AND THE FIRST VERSION HAD FOUR AND NONE - WHICH FAILED ON THE
    // VERY BUILD IT WAS MEASURED FROM. MEASURED 2026-09-03: `sower_broadcast` on `broad` spilled
    // 0.07 past an envelope measured on `broad`, because the envelope sampled phases 0, 0.25, 0.5,
    // 0.75 and the gate sampled 0.12 and 0.62. The widest moment of a swing is wherever it happens
    // to be, and a finite grid cannot see between its own samples.
    //
    // ⭐ THE LESSON IS ABOUT THE SHAPE OF THE CLAIM, not about the number four: a bound derived by
    // sampling a continuous function is only a bound at the sample points, so it needs BOTH a finer
    // grid AND an explicit slack for what falls between. The slack is stated here rather than hidden
    // in the gate's tolerance, because it is a property of this measurement and not of that check.
    //
    // ⛔ AND THE FIXED 0.04 THAT PARAGRAPH INTRODUCED WAS ITSELF WRONG ON THE NEXT RUN - see the
    // note beside `_slack` below, where the allowance is now MEASURED per loop instead of chosen.
    var _who = { name: "envelope", trade: _id, seed: 1, build: "broad", skin: 0,
                 hairstyle: "wild", haircol: 0, jostle: 0, routine: undefined };
    var _phases = 12;
    // ⛔⛔ A FIXED SLACK IS STILL A GUESS, AND THE 0.04 THAT WAS HERE WAS MEASURED WRONG THE VERY
    // NEXT RUN: `sower_broadcast` on `broad` spilled 0.03 PAST an envelope that already carried it,
    // i.e. the true between-sample excursion on that loop is 0.07 at a 12-sample grid. The previous
    // repair had gone 4 -> 12 samples and added the 0.04; going 12 -> 24 and adding 0.08 is the same
    // move again, and it is a bar invented to fit whichever loop failed last.
    //
    // ⭐ THE SLACK IS NOW MEASURED PER LOOP, FROM THE LOOP'S OWN GEOMETRY. Track the largest step
    // between ADJACENT phase samples; for a smooth pose that is an upper bound on the scale of what
    // can hide between two samples, so half of it is a principled allowance and the whole of it is a
    // conservative one. A violently-swinging loop earns a wide allowance and a still one earns
    // almost none, which is the property a constant cannot have. The floor of 0.04 stays as a hand's
    // width of ordinary margin. This is the wing's standing law - a bound derived by sampling a
    // continuous function is only a bound AT the sample points - answered with a number that comes
    // from the function instead of from the last failure.
    // ⛔⛔ BOTH MIRRORS, AND MEASURING ONLY ONE WAS A REAL DEFECT IN THE STREET SPACING.
    //
    // This loop used to pass `(_w.face == "in") ? 1 : -1` - the loop's OWN nominal facing - and so
    // measured a `face: "out"` loop mirrored and nothing else. But a townsperson's mirror is decided
    // at RUN TIME by `lge_where`'s `face`, which flips with the direction they last walked, so the
    // same loop is drawn both ways in a live town. A figure is not left-right symmetric - the tool
    // is in one hand and the lamp is flipped with it - so the extents SWAP between mirrors, and an
    // envelope measured in one of them is not a bound on the other.
    //
    // MEASURED 2026-09-03: `sower_broadcast` (face "out") spilled 0.03 past its own envelope, and
    // the containment gate found it only because the gate happened to sample the UNMIRRORED figure
    // while the envelope sampled the mirrored one. The two disagreeing was the whole tell.
    //
    // ⚠️ THE SEED IS NOT A VARIABLE HERE AND WAS CHECKED BEFORE THIS WAS WRITTEN. The obvious rival
    // explanation was that the gate builds its person with `seed: 3` and this builds one with
    // `seed: 1`; grepping every shipped script for a person's `.seed` returns exactly one use, the
    // routine RNG in `lge_town`, and nothing in the geometry. Figure shape does not depend on it.
    var _prev_lo = 0, _prev_hi = 0, _have_prev = false;
    var _step = 0;
    var _mirrors = [1, -1];
    for (var _mi = 0; _mi < 2; _mi++) {
        _have_prev = false;
        for (var _k = 0; _k < _phases; _k++) {
            var _fig = lge_figure_parts(_who, _id, _k / _phases, false, _mirrors[_mi]);
            var _lst = [];
            lge_append(_lst, _fig.back);
            lge_append(_lst, _fig.main);
            if (array_length(_lst) == 0) continue;
            var _fb = lge_render_bounds(_lst);
            var _sl = _st.stand + _fb[0];
            var _sh = _st.stand + _fb[2];
            _lo = min(_lo, _sl);
            _hi = max(_hi, _sh);
            // ⚠️ ADJACENT ONLY WITHIN ONE MIRROR. The step between the last phase of one mirror and
            // the first of the next is not a step of any continuous function, and letting it into
            // the maximum would inflate every envelope by the mirror gap.
            if (_have_prev) {
                _step = max(_step, abs(_sl - _prev_lo), abs(_sh - _prev_hi));
            }
            _prev_lo = _sl; _prev_hi = _sh; _have_prev = true;
        }
    }
    var _slack = max(0.04, _step);

    // ⛔ AND THE TOOL'S DECLARED REACH IS A FLOOR ON THE ENVELOPE, WHICH IS THE ONLY THING THAT
    // MAKES `reach` A FACT RATHER THAN A COMMENT. MEASURED 2026-09-03 by
    // `Internal_Ops/_field_readers.js`: before this line, `lge_tool_spec().reach` had ZERO readers
    // anywhere in the shipped product - the suite asserted a number that reached no picture, and the
    // suite's own comment claiming "lge_work_envelope spaces the whole street from reach" was simply
    // false. Sampling the DRAWN figure answers "how wide is this pose today"; the declared reach
    // answers "how wide can this tool ever be", which is the question the street actually has to
    // survive when a buyer authors a pose that swings it further than ours do.
    var _rmax = 0;
    var _ids = [_w.tool, _w.offhand];
    for (var _ti = 0; _ti < 2; _ti++) {
        if (_ids[_ti] == "") continue;
        var _tsp = lge_tool_spec(_ids[_ti]);
        if (!is_undefined(_tsp)) _rmax = max(_rmax, _tsp.reach);
    }
    if (_rmax > 0) {
        _lo = min(_lo, _st.stand - _rmax);
        _hi = max(_hi, _st.stand + _rmax);
    }

    return [_lo - _slack, _hi + _slack];
}

/// ============================================================================================
/// WORK-LEVEL DISTINCTNESS - a different question from the pose one, and it needs asking
/// ============================================================================================

/// @desc The identity triple of a work loop: what pose, at what station, with what in hand.
///
/// ⛔ THIS IS NOT THE POSE SIGNATURE AND IT IS NOT REDUNDANT WITH IT. `lge_labour_distance` compares
/// what the BODY does and would happily pass two loops that share a station and a tool, i.e. two
/// listings-worth of "different job" that draw the same picture with a differently-angled elbow. This
/// compares what is ON SCREEN. Both are needed, and this wing's constitution records the general form
/// of the mistake: a check whose scope is narrower than its sentence.
///
/// @param {String} _id
/// @returns {String} "" for an unknown id
function lge_work_signature(_id) {
    var _sp = lge_work_spec(_id);
    if (is_undefined(_sp)) return "";
    return _sp.labour + "|" + _sp.station + "|" + _sp.tool + "|" + _sp.offhand + "|" + _sp.face;
}

/// @desc Every distinct tool actually named by the corpus, including off-hands. The suite compares
/// this against `lge_tools_all()` in BOTH directions.
///
/// ⚠️ BOTH DIRECTIONS IS THE WHOLE POINT. A one-sided check ("every tool the corpus names exists")
/// passes over an authored tool nothing uses, which is dead art in a shipped package; the other side
/// ("every tool that exists is used") passes over a corpus that names none of them. This wing has a
/// measured row on exactly this shape - a one-sided threshold cannot detect drift in its permissive
/// direction, and the permissive direction is the one things rot in.
function lge_work_tools_used() {
    var _seen = {};
    var _out = [];
    var _all = lge_works_all();
    for (var _i = 0; _i < array_length(_all); _i++) {
        var _sp = lge_work_spec(_all[_i]);
        if (is_undefined(_sp)) continue;
        var _pair = [_sp.tool, _sp.offhand];
        for (var _j = 0; _j < 2; _j++) {
            var _t = _pair[_j];
            if (_t == "") continue;
            if (!variable_struct_exists(_seen, _t)) {
                variable_struct_set(_seen, _t, true);
                array_push(_out, _t);
            }
        }
    }
    return _out;
}
