{
  "$GMScript": "v1",
  "%Name": "lge_labour",
  "name": "lge_labour",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}
