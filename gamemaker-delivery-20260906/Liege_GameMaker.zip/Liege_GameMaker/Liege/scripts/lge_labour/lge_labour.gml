/// ============================================================================================
/// LIEGE — THE WORK POSES
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// ⭐ THIS FILE AND `lge_station` ARE THE PRODUCT. Everything else is how they get on screen.
///
/// The gate-1 commitment recorded before a line of this package was written: "the visible half IS
/// the product - 40+ work loops, each with its own generated POSE and its own generated PROP." This
/// is the pose half. `lge_armature` knows how to STAND, WALK and REACH; it knows nothing about
/// striking an anvil, drawing a shuttle across a loom, or leaning on a scythe, and those are the
/// things a buyer is paying for.
///
/// ============================================================================================
/// HOW A WORK POSE IS BUILT, AND WHY IT IS NOT A TABLE OF ANGLES
/// ============================================================================================
///
/// A pose here is a FUNCTION OF PHASE, not a constant. `lge_labour_pose(id, u)` returns the angle
/// set at u in [0,1), so a loop is continuous and a buyer can sample it at any frame rate.
///
/// ⛔ A CYCLE MUST NOT BE A TWO-FRAME FLIP. Two extremes alternating reads as a TWITCH at gallery
/// size, not as work - which is the difference between a store GIF that sells and one that looks
/// broken. Every archetype below eases through its phase with at least three visually distinct
/// stations, and the suite asserts the mid-phase pose is not simply the average of the endpoints
/// (an eased three-phase move has a mid that leaves the line between them; a two-frame flip does
/// not, and that is a property no amount of naming can fake).
///
/// ⛔ AND THE VOLUME MUST BE REAL, NOT A RENAME. `Wings/GameMaker/CLAUDE.md` records a break test on
/// a sibling product that passed at 890/890 because renaming a constant moved BOTH sides of the
/// comparison. So distinctness here is asserted on a SIGNATURE - every joint angle at four phases,
/// 48 numbers - and two loops are distinct only if those numbers differ. A loop that is another
/// loop with a different name fails by name.
///
/// ============================================================================================
/// THE TWELVE ARCHETYPES
/// ============================================================================================
///
/// Forty-six loops are not forty-six unrelated animations, and pretending otherwise would produce
/// forty-six mediocre ones. They are twelve MOTIONS OF THE HUMAN BODY, each parameterised:
///
///   swing_over   a tool raised above the head and driven down      hammer, axe, flail, mattock
///   swing_flat   a sweep across the body at waist height           scythe, broom, sower's arm
///   push_pull    a straight travel along one axis, both hands      saw, plane, rasp, beetle
///   crank        one hand travelling a circle                      lathe, wheel, quern, churn
///   press_down   a downward press from the shoulders               knead, pestle, press
///   lift_carry   stoop, take the weight, straighten                sacks, crates, buckets
///   stoop_gather work done at ground level, back bent              sowing, digging, weeding
///   tend_fine    both hands close together at chest height         stitching, writing, mending
///   reach_place  one arm extended forward and up                   oven peel, shelf, stall
///   stir         one hand circling inside a vessel                 pot, vat, mash tun
///   rock         a two-beat rocking of one arm                     bellows, dipping, spinning
///   hold_still   a near-static stance with a slow sway             watch, herald, elder
///
/// ⚠️ THE ARCHETYPE IS THE VERB AND THE PARAMETERS ARE THE JOB. A smith's strike and a woodcutter's
/// split are both `swing_over` and they are not the same picture: the smith works at anvil height
/// with a short arc and a braced stance, the woodcutter works at block height with a full overhead
/// arc and a wide stance. Those differences are authored per loop, which is why the corpus is a
/// table of jobs rather than a table of verbs.
///
/// ============================================================================================

/// How many phase samples the distinctness signature uses. Four rather than three: an odd count
/// makes a two-beat motion alias against itself, and this is a comparison, not a render.
#macro LGE_SIG_PHASES 4

/// ⭐ THE DISTINCTNESS FLOOR, AND IT IS A NUMBER THE CORPUS CHOSE RATHER THAN A NUMBER SOMEBODY
/// LIKED. This wing's constitution requires a threshold to sit in a MEASURED GAP, and records what
/// to do when there is not one: "a continuous distribution is a finding about the CORPUS, not a
/// threshold problem. Fix the corpus and the gap appears."
///
/// It did, and only after six rounds of fixing. The design probe measures all 1,035 pairs:
///
///   round 1  min 0.0094  - CONTINUOUS from 0.0094 up, no empty bucket anywhere. Six `tend_fine`
///                          jobs sat inside 0.036 of each other: six trades, one pose.
///   round 2  min 0.0241  - after `spread` was added as a field (the hands' distance apart was a
///                          physical property the table had no way to express)
///   round 3  min 0.0252
///   round 4  min 0.0500
///   round 6  min 0.0640  - and every bucket below it EMPTY
///
/// ⚠️ THE DOMINANT TERM WAS THE STANCE, WHICH IS WORTH KNOWING BEFORE AUTHORING THE NEXT JOB. Six of
/// a signature's twelve numbers per phase come from `lge_stance`, so two jobs sharing a stance begin
/// halfway to identical and have to earn the whole separation in the arms. Two of the last four
/// offenders were fixed by asking what the worker's FEET are doing rather than their hands.
///
/// 0.055 rather than the midpoint of the gap, for a checkable reason: it is above EVERY pair the six
/// rounds caught (worst 0.0502) and 0.0138 below the closest surviving pair, so it would have fired
/// on every real defect this corpus has had while leaving headroom for honest drift.
///
/// ⚠️ It is therefore a REGRESSION GUARD, not a live finding - every current pair passes. Say that
/// rather than implying it is doing work every run. Receipts: `Internal_Ops/labour_probe.js`,
/// dataset `Internal_Ops/data_labour_probe.json`; `lge_selftest` re-derives all of it IN ENGINE,
/// which is the authoritative reading.
#macro LGE_SIG_FLOOR 0.055

/// ⛔ NEVER WRITE A TOLERANCE BELOW ~0.0001 IN GML. `math_get_epsilon()` returns 0.00001 on this
/// runtime and PARTICIPATES in comparisons, so `abs(a - b) < 0.000001` is false for every pair of
/// values INCLUDING equal ones, and a duplicate check written that way passes vacuously forever.
/// A sibling product shipped a suite full of assertions that could not go red for exactly this.
#macro LGE_EPS 0.0001

/// What share of a work loop's REACH the shoulder spends, the rest going to the elbow.
///
/// ⛔ THE WHOLE REACH USED TO GO TO THE SHOULDER, AND THAT IS HALF OF WHY THIS CORPUS WAS A FIELD
/// OF SCARECROWS - see the long block in `lge_labour_pose`. A person working at chest height hangs
/// the upper arm and folds the elbow; they do not lift the humerus to shoulder height. 0.40 leaves
/// the shoulder a real but minority say, so a high-working loop still visibly raises its arm
/// without the elbow ending up out at the side.
///
/// ⭐ 0.80 IS THE KNEE OF A MEASURED CURVE, NOT A NUMBER THAT MADE A TEST PASS. Both costs were
/// swept offline (`Internal_Ops/_pose_drawn.js --sig`, which ports `lge_labour_signature` exactly
/// because it reads pose ANGLES rather than joint positions):
///
///     share   worst distinctness   pairs under floor   cells with a WIDE upper arm
///      1.00        0.0672                 0                    14 of 46
///      0.80        0.0603                 0                     4 of 46
///      0.60        0.0560                 0                     3 of 46
///      0.40        0.0529                 2                     1 of 46
///
/// Lowering the share pulls upper arms in; it also compresses the pose space, because the reach is
/// most of what makes one loop's arms differ from another's. 0.80 takes 71% of the benefit (14 wide
/// cells down to 4) for almost none of the cost, and 0.40 buys three more cells at the price of two
/// pairs colliding under LGE_SIG_FLOOR - i.e. at the price of the product's own "46 DIFFERENT work
/// loops" claim.
///
/// ⚠️ I SHIPPED 0.40 FIRST AND THE SUITE REFUSED IT THREE BUILDS RUNNING, each time naming a
/// different colliding pair. Chasing those pairs one build at a time is whack-a-mole and never
/// shows the distribution; porting the sweep and looking at the whole curve answered it in one run.
/// ⚠️ AND THE HEIGHT DATA WAS THE BIGGER CAUSE ANYWAY. Six loops declared hands at or near shoulder
/// height for work done at a bench or in the lap (see `watch_stand`, `fisher_mend`, `scribe_write`,
/// `elder_sit`, `herald_read`, `herbalist_pestle`). Correcting those moved more cells than any value
/// of this constant does - a model correction cannot rescue data that describes the wrong pose.
#macro LGE_SHOULDER_SHARE (0.80)

/// ============================================================================================
/// EASING
/// ============================================================================================

/// @desc A smooth 0..1..0 pulse over the phase. Peaks at `_at`, zero at both ends of the cycle.
///
/// ⚠️ NOT A SINE. A sine spends most of its time near the extremes, which is right for a pendulum
/// and wrong for work: a hammer is at the top of its arc briefly and travels through the middle
/// fast. This is a raised cosine on each side of the peak with independent rise and fall widths, so
/// a stroke can be slow up and fast down - which is what makes a strike read as a strike.
///
/// @param {Real} _u    phase, 0..1
/// @param {Real} _at   where the peak sits, 0..1
/// @param {Real} _rise how much of the cycle the rise takes
/// @param {Real} _fall how much of the cycle the fall takes
/// @returns {Real} 0..1
function lge_pulse(_u, _at, _rise, _fall) {
    var _d = _u - _at;
    // Wrap the difference onto [-0.5, 0.5] so a peak near 0 or 1 is continuous across the seam. A
    // cycle with a discontinuity at u=0 is a visible jerk once per loop, and it is the commonest
    // way a looping animation betrays itself.
    while (_d > 0.5) _d -= 1;
    while (_d < -0.5) _d += 1;
    var _w = (_d < 0) ? _rise : _fall;
    if (_w <= LGE_EPS) return (abs(_d) <= LGE_EPS) ? 1 : 0;
    var _k = abs(_d) / _w;
    if (_k >= 1) return 0;
    return 0.5 + 0.5 * cos(_k * pi);
}

/// @desc A cyclic travel 0..1..0 that returns the SAME value at u=0 and u=1, easing at both ends.
/// Used where a motion goes out and comes back rather than striking.
function lge_swell(_u) {
    return 0.5 - 0.5 * cos(_u * LGE_TAU);
}

/// ============================================================================================
/// THE CORPUS
/// ============================================================================================

/// @desc Every work loop's pose id, in a stable order.
///
/// ⚠️ THE ORDER IS PART OF THE PRODUCT: the store sheets and the demo walk this array, so inserting
/// a loop in the middle reshuffles a baked gallery. Append.
function lge_labours_all() {
    return [
        // metal and fire
        "smith_strike", "smith_bellows", "smith_quench", "farrier_rasp", "tinker_solder",
        // wood
        "sawyer_saw", "joiner_plane", "cooper_hoop", "turner_lathe", "woodward_split",
        // cloth and fibre
        "weaver_shuttle", "spinner_wheel", "dyer_vat", "roper_walk", "tailor_stitch",
        // food
        "baker_peel", "baker_knead", "butcher_block", "brewer_stir", "dairy_churn",
        "cook_ladle", "miller_sack",
        // field and beast
        "reaper_scythe", "thresher_flail", "sower_broadcast", "shepherd_shear", "gardener_hoe",
        "beeward_smoke",
        // stone and earth
        "mason_chisel", "potter_wheel", "digger_spade", "collier_rake",
        // water and trade
        "fisher_mend", "washer_beat", "waterward_draw", "carter_load", "monger_call",
        "scribe_write", "herbalist_pestle", "chandler_dip",
        // the day is not all work
        "watch_stand", "herald_read", "child_hoop", "elder_sit", "priest_bless", "drover_goad",
    ];
}

/// @desc The authored spec for one work loop.
///
/// Fields:
///   verb    one of the twelve archetypes
///   amp     how big the motion is, 0..1 (scales the archetype's own angles)
///   at      where in the cycle the working beat lands, 0..1
///   rise    fraction of the cycle spent winding up
///   fall    fraction spent on the working stroke - SHORTER than rise on a percussive job
///   hand    "both" | "left" | "right"  which side leads
///   height  where the hands work, as a fraction of stature below the shoulder (0 = shoulder
///           height, 1 = the floor). This is what makes an anvil different from a chopping block.
///   spread  how far APART the two hands work, -1 (crossed in front of the sternum) through 0
///           (shoulder width) to +1 (arms wide). See the note below - this field exists because the
///           corpus was measured without it and six jobs came out as the same picture.
///   lean    forward lean at the working beat, radians
///   stance  "square" | "braced" | "wide" | "seated" | "kneel" | "stride"
///   tilt    head tilt at the working beat - a worker looks AT the work
///
/// ⛔⛔ `spread` WAS ADDED AFTER A DESIGN-TIME MEASUREMENT, AND THE MEASUREMENT IS THE REASON THE
/// CORPUS IS WORTH ANYTHING. The first authoring of this table produced 1,035 pair distances running
/// CONTINUOUSLY from 0.0094 upward with no empty bucket anywhere - and this wing's constitution is
/// explicit that a continuous distribution is a finding about the CORPUS, not a threshold problem:
/// "fix the corpus and the gap appears." The six `tend_fine` jobs were the offenders, sitting at
/// 0.009 to 0.036 from each other, i.e. six townspeople in six trades holding the identical pose.
///
/// ⭐ THE FIX WAS NOT A LOWER BAR, IT WAS ASKING WHAT ACTUALLY DIFFERS IN LIFE. A scribe writes with
/// ONE hand and rests the other flat; a fisher works a net stretched WIDE between both hands at eye
/// level; a potter has both hands almost touching, low and centred; a shearer works at the floor. So
/// the thing separating them is how far apart the hands are and at what height - which is a physical
/// property this table simply had no field for, and no amount of tuning `amp` could express.
///
/// @param {String} _id
/// @returns {Struct}
function lge_labour_spec(_id) {
    switch (_id) {
        // ---- metal and fire ---------------------------------------------------------------
        // A smith's strike is SHORT. The hammer comes up to about head height, not overhead - a
        // full overhead swing on an anvil would smash the smith's own knuckles on the horn, and it
        // is the giveaway that an animation was drawn by somebody who has not watched one.
        case "smith_strike":   return { verb: "swing_over", amp: 0.62, at: 0.62, rise: 0.44, fall: 0.16, hand: "right", height: 0.544, spread: 0.05, lean: 0.10, stance: "braced", tilt: 0.13 };

        // ⛔ REVERTED from the reach solver's derived value. This loop sits in the corpus's
        // tightest distinctness cluster, the correction spends headroom the corpus does not have,
        // and it does NOT clear the reach bar either way - so the trade buys nothing and costs the
        // one property the product actually claims. See the 2026-09-04 devlog.
        // ⛔⛔ `hand` WAS "left" AND THE FORGE'S WORK POINT IS AT +0.400 IN FIGURE SPACE, so the
        // smith was pumping a bellows on her right with her LEFT hand, across her own chest. No
        // value of `height` can fix a sidedness error - that is why five sessions of height tuning
        // left this loop the worst offender in the corpus (d0.266 x-0.162 against a 0.094 bar).
        // Found by _hand_side_scan.js, which compares the three tables that independently declare
        // sidedness (station.work-stand, labour.hand, work.side) and which nothing had compared.
        case "smith_bellows": return { verb: "rock",       amp: 0.86, at: 0.50, rise: 0.50, fall: 0.50, hand: "right", height: 0.14, spread: -0.15, lean: 0.06, stance: "stride", tilt: 0.05 };
        // Quenching is a LOWER of a held thing into a trough, then a hold while it hisses: the fall
        // is long and the return quick, which is the reverse of a strike and reads as care.
        // A quench trough stands at about knee height and the work is PLUNGED down into it, so the
        // hands finish low - lower than a smith's other two loops, which is the whole silhouette of
        // a quench. 0.68 held them at hip height, which is a press, not a plunge, and it left this
        // loop 0.05 from `brewer_stir` against a 0.055 distinctness floor once the shoulder split
        // compressed the corpus. Deepening it is what the action actually is, and it separates them.
        case "smith_quench": return { verb: "press_down", amp: 0.62, at: 0.55, rise: 0.20, fall: 0.55, hand: "both",  height: 0.82, spread: -0.45, lean: 0.14, stance: "braced", tilt: 0.16 };
        // A farrier works with the hoof BETWEEN the knees, so the stance is the pose: bent, knees
        // together, both hands low and close. The rasp travel is small and fast.
        case "farrier_rasp":   return { verb: "push_pull",  amp: 0.42, at: 0.50, rise: 0.34, fall: 0.34, hand: "both",  height: 0.74, spread: -0.55, lean: 0.30, stance: "kneel",  tilt: 0.24 };
        // ⛔ Same sidedness defect as `smith_bellows`: the tinker's bench declares its work at
        // +0.300 in figure space and this row soldered at it with the LEFT hand. It cleared the
        // reach bar anyway (a seated figure's hands are close together), which is exactly why a
        // reach gate alone cannot find this class - see _hand_side_scan.js.
        case "tinker_solder":  return { verb: "tend_fine",   amp: 0.34, at: 0.45, rise: 0.40, fall: 0.34, hand: "right", height: 0.212, spread: -0.30, lean: 0.16, stance: "seated", tilt: 0.22 };

        // ---- wood -------------------------------------------------------------------------
        // A two-handed saw is the longest travel in the corpus and the whole body goes with it.
        case "sawyer_saw":     return { verb: "push_pull",  amp: 0.92, at: 0.50, rise: 0.42, fall: 0.42, hand: "both",  height: 0.634, spread: 0.20, lean: 0.18, stance: "stride", tilt: 0.12 };
        // A plane is the same verb with the weight over it: shorter travel, more lean, hands lower.
        case "joiner_plane": return { verb: "push_pull",  amp: 0.44, at: 0.50, rise: 0.26, fall: 0.20, hand: "both",  height: 0.50, spread: -0.55, lean: 0.40, stance: "braced", tilt: 0.16 };
        // Driving a hoop down a barrel: short taps, high tempo, hands at chest height.
        case "cooper_hoop": return { verb: "swing_over", amp: 0.40, at: 0.55, rise: 0.30, fall: 0.20, hand: "right", height: 0.16, spread: -0.05, lean: 0.08, stance: "square", tilt: 0.14 };
        // A pole lathe is worked with a FOOT treadle and both hands steady on the chisel, so the
        // arms barely move and the whole pose lives in the legs. It is the one loop where holding
        // still is the skill.
        case "turner_lathe": return { verb: "rock",       amp: 0.18, at: 0.50, rise: 0.50, fall: 0.50, hand: "both",  height: 0.52, spread: 0.88, lean: 0.24, stance: "stride", tilt: 0.20 };
        // The full overhead arc, the widest stance, the deepest fall. The corpus's biggest motion.
        case "woodward_split": return { verb: "swing_over", amp: 1.00, at: 0.66, rise: 0.48, fall: 0.14, hand: "both",  height: 0.86, spread: -0.45, lean: 0.22, stance: "wide",   tilt: 0.18 };

        // ---- cloth and fibre --------------------------------------------------------------
        // The shuttle crosses the loom: a flat sweep, hand to hand, at chest height, seated.

        // ⛔ REVERTED from the reach solver's derived value. This loop sits in the corpus's
        // tightest distinctness cluster, the correction spends headroom the corpus does not have,
        // and it does NOT clear the reach bar either way - so the trade buys nothing and costs the
        // one property the product actually claims. See the 2026-09-04 devlog.
        //
        // ⛔⛔ `hand` WAS "both" AND `spread` 0.70, AND THIS WAS THE WORST-READING CELL ON THE STORE
        // SHEET. MEASURED 2026-09-04 by cropping it to 4x and looking: `swing_flat` gives BOTH arms
        // the same outward sweep, `at: 0.50` samples them at full extension together, and the result
        // is a figure standing inside its own loom frame with both arms horizontal and both palms
        // open - a scarecrow, not a weaver. Every gate was green on it: it clears the reach bar, it
        // clears distinctness, its ink and density are fine. SYMMETRY IS INVISIBLE TO EVERY
        // MEASUREMENT THIS SUITE MAKES, because each arm is individually correct.
        // The shuttle is in wrist 1 (`side: 1`) and the loom declares its work at +0.19 in figure
        // space, so "right" is also what the sidedness scan wants; the off arm drops to the 0.24
        // weight and the pose becomes one arm throwing across a body instead of two arms held out.
        //
        // ⛔⛔ AND THAT FIX WAS WRONG, WHICH IS THE REAL FINDING HERE. Going one-handed collided with
        // `spinner_wheel` - MEASURED run69 0.046 and run70 0.044 against a 0.060 floor - because the
        // spinner is ALSO right-handed and seated at nearly the same height, and restoring `spread`
        // to 0.70 made it WORSE, not better. So `spread` was never the driver: **the two-armed
        // symmetry IS this loop's distinctness**, and removing it turns the weaver into the spinner.
        // A defect and an identity can be the same property, and the gate that refused the fix was
        // right where my cause story was wrong.
        //
        // ✅ THE LEVER THAT WORKS IS THE ONE THE ARCHETYPE ALREADY NAMED. `swing_flat` is documented
        // at the top of this file as "a sweep across the body AT WAIST HEIGHT", and this row was
        // running it at `height: 0.26` - hands up near the shoulder - which is what made two
        // correct arms read as a scarecrow pinned in its own loom. Dropped to a waist sweep, both
        // arms stay (so the spinner stays far away) and the horizontal T goes.
        case "weaver_shuttle": return { verb: "swing_flat", amp: 0.70, at: 0.50, rise: 0.44, fall: 0.44, hand: "both",  height: 0.44, spread: 0.70, lean: 0.10, stance: "seated", tilt: 0.14 };
        // A spinning wheel is a crank with the OTHER hand feeding fibre - so the two arms do
        // genuinely different things, which is the tell that separates it from a lathe at a glance.
        case "spinner_wheel": return { verb: "crank",      amp: 0.66, at: 0.50, rise: 0.50, fall: 0.50, hand: "right", height: 0.30, spread: 0.62, lean: 0.08, stance: "seated", tilt: 0.18 };
        // Lifting sodden cloth out of a vat: a heavy two-handed haul with real lean.
        case "dyer_vat":       return { verb: "lift_carry", amp: 0.72, at: 0.58, rise: 0.40, fall: 0.26, hand: "both",  height: 0.66, spread: 0.25, lean: 0.28, stance: "wide",   tilt: 0.20 };
        // A rope walk is done WALKING BACKWARDS while twisting - the only loop whose stance is a
        // stride and whose hands stay pinned at one height.

        // ⛔ REVERTED from the reach solver's derived value. This loop sits in the corpus's
        // tightest distinctness cluster, the correction spends headroom the corpus does not have,
        // and it does NOT clear the reach bar either way - so the trade buys nothing and costs the
        // one property the product actually claims. See the 2026-09-04 devlog.
        case "roper_walk": return { verb: "crank",      amp: 0.44, at: 0.50, rise: 0.50, fall: 0.50, hand: "both",  height: 0.26, spread: 0.40, lean: -0.10, stance: "stride", tilt: 0.06 };
        case "tailor_stitch":  return { verb: "tend_fine",   amp: 0.72, at: 0.42, rise: 0.36, fall: 0.30, hand: "right", height: 0.225, spread: 0.80, lean: 0.20, stance: "seated", tilt: 0.26 };

        // ---- food -------------------------------------------------------------------------
        // The peel goes INTO the oven: the longest forward reach in the corpus, and it rises as it
        // goes because an oven floor is above waist height.
        case "baker_peel":     return { verb: "reach_place", amp: 0.88, at: 0.56, rise: 0.40, fall: 0.30, hand: "both", height: 0.16, spread: -0.25, lean: 0.16, stance: "stride", tilt: 0.10 };
        case "baker_knead": return { verb: "press_down",  amp: 0.64, at: 0.54, rise: 0.28, fall: 0.24, hand: "both", height: 0.707, spread: 0.10, lean: 0.30, stance: "stride", tilt: 0.24 };
        // A cleaver is a strike, but the arc is short and the OTHER hand holds the work - so it is
        // asymmetric where the smith's is braced.
        case "butcher_block": return { verb: "swing_over",  amp: 0.54, at: 0.60, rise: 0.36, fall: 0.11, hand: "right", height: 0.52, spread: 0.50, lean: 0.14, stance: "square", tilt: 0.20 };
        // ⚠️ `hand: "both"` IS CORRECT HERE AND I BRIEFLY CHANGED IT TO "right", WHICH THE SUITE
        // REFUSED. The reasoning looked sound - `stir`'s own header says "A hand circling inside a
        // vessel", singular, and the sibling stir loop `cook_ladle` is "right" - but this loop's
        // TOOL is a mashpaddle, which `lge_tool_spec` declares two-handed, and STAGE 8 asserts that
        // a two-handed tool is held by a two-handed pose. It went red naming the row:
        // "brewer_stir(mashpaddle two-handed, pose uses right)".
        // ⭐ Two documents disagreed about one loop and the TOOL was the one telling the truth; a
        // verb header describes the commonest case, an equipment row describes this one. It also
        // did nothing for the distinctness collision it was meant to fix (0.05 either way), so it
        // was wrong on its own terms as well as forbidden.
        case "brewer_stir":    return { verb: "stir",        amp: 0.66, at: 0.50, rise: 0.50, fall: 0.50, hand: "both",  height: 0.44, spread: -0.05, lean: 0.18, stance: "braced", tilt: 0.22 };
        // A churn dasher is a straight vertical plunge - it is `press_down` at full amplitude with
        // almost no lean, because the churn takes the weight and the worker stands over it.
        case "dairy_churn":    return { verb: "press_down",  amp: 0.86, at: 0.52, rise: 0.30, fall: 0.22, hand: "both",  height: 0.48, spread: -0.60, lean: 0.06, stance: "square", tilt: 0.16 };
        case "cook_ladle": return { verb: "stir",        amp: 0.44, at: 0.50, rise: 0.50, fall: 0.50, hand: "right", height: 0.462, spread: 0.30, lean: 0.14, stance: "square", tilt: 0.20 };
        // A sack on the shoulder: the lift is the whole motion and the top of it is a HOLD.
        case "miller_sack":    return { verb: "lift_carry",  amp: 0.94, at: 0.46, rise: 0.34, fall: 0.44, hand: "both",  height: 0.80, spread: 0.40, lean: 0.34, stance: "braced", tilt: 0.14 };

        // ---- field and beast --------------------------------------------------------------
        // The scythe is the corpus's widest flat sweep and its slowest recovery: the cut is fast,
        // the walk back through the arc is not.
        case "reaper_scythe":  return { verb: "swing_flat",  amp: 1.00, at: 0.44, rise: 0.52, fall: 0.20, hand: "both",  height: 0.78, spread: 0.30, lean: 0.24, stance: "stride", tilt: 0.16 };
        case "thresher_flail": return { verb: "swing_over",  amp: 0.90, at: 0.64, rise: 0.46, fall: 0.15, hand: "both",  height: 0.82, spread: -0.35, lean: 0.16, stance: "square", tilt: 0.22 };
        // Broadcasting seed is a flat sweep that OPENS - the hand ends further from the body than
        // it started, and the other hand stays on the basket at the hip.
        case "sower_broadcast":return { verb: "swing_flat",  amp: 0.62, at: 0.58, rise: 0.40, fall: 0.26, hand: "right", height: 0.36, spread: 0.60, lean: 0.04, stance: "stride", tilt: 0.02 , handsoff: true};
        // Shearing: both hands low and together on a beast held between the knees. Small fast bites.
        case "shepherd_shear": return { verb: "tend_fine",   amp: 0.46, at: 0.48, rise: 0.30, fall: 0.26, hand: "both",  height: 0.86, spread: -0.70, lean: 0.34, stance: "kneel",  tilt: 0.28 };
        case "gardener_hoe": return { verb: "push_pull",   amp: 0.82, at: 0.52, rise: 0.38, fall: 0.28, hand: "both",  height: 0.88, spread: 0.52, lean: 0.32, stance: "stride", tilt: 0.26 };
        // A beekeeper's smoker is worked one-handed and SLOWLY, with the other arm out for balance
        // and the head back - the only working pose in the corpus that leans AWAY from its station.
        // ⛔ 0.36 AND NOT THE 0.453 THE REACH SOLVER DERIVED. `_join_solve.js` computes the height
        // that would put this beeward's hands on her hive, and it is correct arithmetic - but at
        // 0.453 this pose collides with `watch_stand` at 0.05 against a distinctness floor of 0.06,
        // MEASURED in engine on 2026-09-04. The corpus's whole claim is that the 46 differ; buying
        // one loop's reach with two loops that look the same is a bad trade, and it is the trade the
        // wing already refused once when the elbow-subtraction fix collapsed the four tend_fine
        // loops. Its reach needs a different lever - `spread` or `lean` - not this one.
        case "beeward_smoke":  return { verb: "rock",        amp: 0.40, at: 0.50, rise: 0.50, fall: 0.50, hand: "right", height: 0.36, spread: 0.50, lean: -0.16, stance: "braced", tilt: -0.10 };

        // ---- stone and earth --------------------------------------------------------------
        // Mallet and chisel: the striking hand taps, the holding hand does not move at all. The
        // stillness of the left hand is what makes it read as precision rather than as demolition.
        case "mason_chisel": return { verb: "swing_over",  amp: 0.24, at: 0.62, rise: 0.32, fall: 0.10, hand: "right", height: 0.30, spread: 0.55, lean: 0.18, stance: "square", tilt: 0.26 };
        // A potter's wheel: both hands INSIDE the work, almost still, while the wheel turns. The
        // motion is a slow rise as the pot is drawn up.
        case "potter_wheel":   return { verb: "tend_fine",   amp: 0.50, at: 0.62, rise: 0.54, fall: 0.30, hand: "both",  height: 0.422, spread: -0.85, lean: 0.30, stance: "seated", tilt: 0.34 };
        case "digger_spade":   return { verb: "stoop_gather",amp: 0.86, at: 0.54, rise: 0.36, fall: 0.30, hand: "both",  height: 0.96, spread: 0.35, lean: 0.40, stance: "stride", tilt: 0.24 };
        case "collier_rake":   return { verb: "push_pull",   amp: 0.80, at: 0.50, rise: 0.44, fall: 0.30, hand: "both",  height: 0.84, spread: 0.40, lean: 0.22, stance: "wide",   tilt: 0.18 };

        // ---- water and trade --------------------------------------------------------------
        // ⛔ height 0.02 + spread 0.95 was the widest row in the corpus: hands at collarbone height,
        // held nearly a metre apart. That is not mending a net, it is a T-pose holding a banner.
        // A seated netsman works the mesh in his LAP with his hands close in front of him.
        case "fisher_mend":    return { verb: "tend_fine",   amp: 0.52, at: 0.44, rise: 0.36, fall: 0.32, hand: "both",  height: 0.116, spread: 0.46, lean: 0.04, stance: "seated", tilt: 0.10 };
        // A washing beetle is a short heavy downward beat onto a stone at the water's edge.
        case "washer_beat":    return { verb: "swing_over",  amp: 0.48, at: 0.62, rise: 0.36, fall: 0.14, hand: "right", height: 0.80, spread: -0.20, lean: 0.36, stance: "kneel",  tilt: 0.22 };
        // Drawing water is a hand-over-hand HAUL: the two arms alternate, which no other loop does.
        case "waterward_draw": return { verb: "crank",       amp: 0.78, at: 0.50, rise: 0.50, fall: 0.50, hand: "both",  height: 0.22, spread: -0.05, lean: 0.10, stance: "braced", tilt: 0.16 };
        case "carter_load":    return { verb: "lift_carry",  amp: 0.82, at: 0.50, rise: 0.38, fall: 0.36, hand: "both",  height: 0.72, spread: 0.55, lean: 0.30, stance: "stride", tilt: 0.12 };
        // Calling a price: one arm up and OUT, palm open, the whole body turned to the street. It
        // is the only loop whose working beat points away from its own station.
        case "monger_call":    return { verb: "reach_place", amp: 0.70, at: 0.48, rise: 0.34, fall: 0.34, hand: "right", height: -0.22, spread: 0.65, lean: -0.08, stance: "square", tilt: -0.14, handsoff: true };
        // A scribe's hands are on the DESK, which is the lowest thing in this list that is still a
        // table: 0.26 put them at upper-chest height, writing on air.
        // ⛔ AND THE SPREAD WAS POSITIVE, WHICH PUT THEM AT OPPOSITE ENDS OF THE DESK. MEASURED
        // 2026-09-04 by cropping this cell to 4x: a seated figure with both arms straight out and a
        // quill at full arm's length, and the join gate reading the nearest hand 0.156 statures wide
        // of the work point. A scribe writes with the pen hand and the other hand ON THE SAME PAGE
        // steadying it - the two hands are a hand's breadth apart, which is what a negative spread
        // is for and what every other fine-work loop in this corpus already declares
        // (`herbalist_pestle` -0.75, `tailor_stitch` -0.90).
        //
        // ⛔ AND THE OBVIOUS VALUE COLLIDED. -0.55 was tried first and the in-engine distinctness
        // sweep went RED at 0.026 against a floor of 0.06 on `potter_wheel vs scribe_write` - both
        // are `tend_fine` + `seated`, so SPREAD is most of what separates them, and moving this one
        // toward the potter's -0.85 collapses the pair. This wing's own constitution records the
        // same outcome from an earlier arm fix: a change that makes two of the forty-six the same
        // picture is worse than the defect it removes. -0.20 brings the hands in front of the body
        // (which is the visual fix) while leaving 0.65 of spread between the two loops.
        case "scribe_write":   return { verb: "tend_fine",   amp: 0.30, at: 0.50, rise: 0.40, fall: 0.36, hand: "right", height: 0.47, spread: -0.20, lean: 0.26, stance: "seated", tilt: 0.34 };
        // A mortar stands on a bench, so the hands grinding in it are at bench height, not chest.
        case "herbalist_pestle": return { verb: "crank",       amp: 0.24, at: 0.50, rise: 0.50, fall: 0.50, hand: "right", height: 0.48, spread: -0.75, lean: 0.08, stance: "square", tilt: 0.32 };
        // Dipping candles: a slow full-arm lower and a long drip-hold at the bottom.
        case "chandler_dip":   return { verb: "press_down", amp: 0.70, at: 0.46, rise: 0.24, fall: 0.48, hand: "both",  height: 0.24, spread: 0.62, lean: 0.10, stance: "square", tilt: 0.18 };

        // ---- the day is not all work ------------------------------------------------------
        // ⚠️ THESE FIVE ARE NOT FILLER. A town where every single person is mid-stroke reads as a
        // factory, and the product's claim is that a town CHANGES ACROSS THE DAY - which needs
        // somewhere for people to be when they are not working. They are also what a buyer's
        // children, guards and idlers use, and those are the NPCs most games have most of.
        // ⛔ `height` WAS 0.10 - HANDS AT SHOULDER HEIGHT - FOR A MAN STANDING STILL WITH A SPEAR.
        // This field's own header says it is measured DOWN from the shoulder as a fraction of
        // stature, so 0.10 claims a watchman holds his hands up level with his collarbones all
        // night. He does not: he grips a grounded spear at about chest-to-waist, which is 0.45-0.55.
        // MEASURED 2026-09-03 by cropping this cell to 4x - it drew a perfect T with a spear
        // floating across the face, and it was one of the six cells that established the corpus-wide
        // scarecrow defect. The arm model was the larger cause and is fixed above, but this row was
        // ALSO wrong, and no model correction can rescue data that describes the wrong pose.
        // ⚠️ It is a DATA fix justified by the field's documented meaning, not a number tuned until
        // a test passed - though it did also resolve a real distinctness collision with
        // `beeward_smoke` (0.03 against a 0.06 floor), which is what surfaced it.
        case "watch_stand":    return { verb: "hold_still",  amp: 0.16, at: 0.50, rise: 0.50, fall: 0.50, hand: "right", height: 0.52, spread: 0.15, lean: 0.02, stance: "braced", tilt: 0.04 };
        // A herald holds the scroll up to READ it - so this one is genuinely high, but 0.10 is
        // shoulder height with a 0.42 spread, which reads as presenting a banner rather than
        // reading. Chest height with the hands closer together is a man reading aloud.
        case "herald_read": return { verb: "hold_still",  amp: 0.26, at: 0.50, rise: 0.50, fall: 0.50, hand: "both",  height: 0.34, spread: 0.22, lean: -0.10, stance: "square", tilt: 0.26 };
        // A child bowling a hoop is the fastest cycle in the corpus and the only one that runs.
        case "child_hoop": return { verb: "swing_flat",  amp: 0.62, at: 0.40, rise: 0.30, fall: 0.20, hand: "right", height: 0.78, spread: 0.05, lean: 0.16, stance: "stride", tilt: 0.06, handsoff: true };
        // A seated elder's hands rest in the LAP, which is the lowest hand position a sitting figure
        // has. 0.34 held them at chest height, unsupported, for the whole day.
        case "elder_sit":      return { verb: "hold_still",  amp: 0.12, at: 0.50, rise: 0.50, fall: 0.50, hand: "both",  height: 0.62, spread: 0.10, lean: 0.10, stance: "seated", tilt: 0.10 };
        // A blessing is a slow raise of both arms - the corpus's only upward-ending motion.
        // ⭐ `handsoff` MARKS THE FOUR LOOPS THAT ARE MEANT TO MISS THEIR STATION. A monger calls a
        // price with an open hand, a priest blesses with both raised, a sower broadcasts seed away
        // from the furrow and a child runs a hoop AHEAD of itself. `lge_work_reach` skips them and
        // the suite excuses them by this field, never by a list of ids - a list can be padded
        // quietly to silence a gate, and this product's station check already records that as the
        // one way an exemption can be made dishonest.
        case "priest_bless":   return { verb: "reach_place", amp: 0.56, at: 0.60, rise: 0.52, fall: 0.34, hand: "both",  height: -0.34, spread: 0.75, lean: -0.06, stance: "square", tilt: -0.18, handsoff: true };
        case "drover_goad": return { verb: "swing_flat",  amp: 0.30, at: 0.60, rise: 0.36, fall: 0.16, hand: "right", height: 0.52, spread: 0.28, lean: 0.10, stance: "stride", tilt: 0.08 };

        // ⛔ NO SILENT FALLBACK TO A PLAUSIBLE POSE. An unknown id here means a work loop names a
        // labour that does not exist, and returning "stand" would draw a townsperson standing
        // politely beside their anvil forever with nothing reporting it. The suite asserts every
        // loop in lge_works_all resolves, and this default is what makes that assertion able to
        // fail rather than being satisfied by a stand-in.
        default: return undefined;
    }
}

/// ============================================================================================
/// THE STANCES
/// ============================================================================================

/// @desc Leg angles for a named stance. Legs are authored separately from arms because a job's
/// footing changes far less often than its hands do - six stances serve forty-six loops.
///
/// ⚠️ Returns the four per-side keys, never the symmetric pair: a mirrored stride swings both knees
/// toward the centre line and produces a person standing with their ankles crossed. The armature's
/// own header records that defect at length.
function lge_stance(_id) {
    switch (_id) {
        // Weight back on one foot, front foot planted - what anyone does when they hit something.
        case "braced": return { hp0: 0.20, kn0: 0.20, hp1: -0.12, kn1: 0.02, splay: 0.09, thigh_k: 0.34 };
        // Feet apart, both flat. A chopping or hauling stance.
        case "wide":   return { hp0: 0.12, kn0: 0.10, hp1: -0.12, kn1: 0.10, splay: 0.20, thigh_k: 0.40 };
        // One foot well forward: sawing, hoeing, walking a rope.
        case "stride": return { hp0: 0.36, kn0: 0.24, hp1: -0.18, kn1: 0.04, splay: 0.04, thigh_k: 0.32 };
        // Seated - the thigh points at the viewer and foreshortens to almost nothing. thigh_k 0.02
        // spends 98% of the drawn thigh, which is what puts the knee just above the crotch where a
        // seated knee is. At 0.60 the figure reads as a short person standing up.
        case "seated": return { hp0: 1.32, kn0: 1.36, hp1: 1.28, kn1: 1.32, splay: 0.15, thigh_k: 0.02 };
        // One knee down. The back leg folds hard, the front thigh is horizontal.
        case "kneel":  return { hp0: 1.24, kn0: 1.30, hp1: 0.30, kn1: 1.46, splay: 0.11, thigh_k: 0.10 };
        default:       return { hp0: 0.05, kn0: 0.05, hp1: -0.045, kn1: -0.04, splay: 0.02, thigh_k: 1.00 };
    }
}

/// ============================================================================================
/// THE SOLVE
/// ============================================================================================

/// @desc The two arms' shoulder and elbow angles for one motion archetype, before the spread,
/// the elbow lift and the aim correction are applied.
///
/// ⛔⛔ THIS IS A SWITCH LIFTED OUT OF lge_labour_pose, AND THE REASON IT WAS LIFTED IS THE ONLY
/// REASON THAT MATTERS: THE POSE HAS TO ASK IT WHAT AN ELBOW DOES AT REST, AND A SECOND TABLE OF
/// THOSE TWELVE CONSTANTS WOULD BE A SECOND DERIVATION OF ONE NUMBER.
///
/// The aim correction - see lge_labour_pose - subtracts the verb's RESTING elbow from the
/// shoulder, so that the verb bends the arm instead of re-aiming it. Calling this function a
/// second time with `_a`, the amplitude, forced to ZERO returns exactly that resting value,
/// because every amplitude term in every branch below is multiplied by `_a`. The constants
/// therefore live here, once, and the resting value is DERIVED from them rather than restated.
/// This wing has a standing row about two copies of one number drifting apart.
///
/// ⚠️ NOTHING ELSE MOVED. The branches below are byte-for-byte what lge_labour_pose ran before the
/// extraction, comments included, so the extraction itself cannot have changed a pose.
///
/// @param {String} _verb  the archetype id
/// @param {Real} _base    the shoulder's share of the reach
/// @param {Real} _a       the loop's amplitude. ZERO returns the resting angles.
/// @param {Real} _w0      viewer-left arm weight
/// @param {Real} _w1      viewer-right arm weight
/// @param {Real} _k       the working-beat pulse, 0..1
/// @param {Real} _s       the smooth there-and-back swell, 0..1
/// @param {Real} _u1      the wrapped phase, 0..1
/// @returns {Array} [sh0, el0, sh1, el1] in radians
function lge_verb_arms(_verb, _base, _a, _w0, _w1, _k, _s, _u1) {
    var _sh0 = _base, _el0 = 0.20, _sh1 = _base, _el1 = 0.20;
    switch (_verb) {
        // Overhead and down. The shoulder swings up through a large arc and the elbow FOLDS at the
        // top - a straight arm at the top of a swing is a signpost, not a person.
        case "swing_over":
            _sh0 = _base + _a * _w0 * (1.55 * _k - 0.55 * (1 - _k));
            _sh1 = _base + _a * _w1 * (1.55 * _k - 0.55 * (1 - _k));
            _el0 = 0.16 + _a * _w0 * 1.15 * _k;
            _el1 = 0.16 + _a * _w1 * 1.15 * _k;
            break;
        // Across the body. Both shoulders travel together, so the pair sweeps rather than opening -
        // the difference between a scythe and a shrug.
        case "swing_flat":
            _sh0 = _base + _a * _w0 * (0.85 * _s - 0.40);
            _sh1 = _base - _a * _w1 * (0.85 * _s - 0.40);
            _el0 = 0.40 + _a * _w0 * 0.55 * (1 - _s);
            _el1 = 0.40 + _a * _w1 * 0.55 * _s;
            break;
        // Straight travel. The shoulder barely moves; the ELBOW does the work, which is what a saw
        // stroke actually looks like and why a version driven from the shoulder reads as rowing.
        case "push_pull":
            _sh0 = _base + _a * _w0 * 0.30 * (_s - 0.5);
            _sh1 = _base + _a * _w1 * 0.30 * (_s - 0.5);
            _el0 = 0.24 + _a * _w0 * 1.05 * _s;
            _el1 = 0.24 + _a * _w1 * 1.05 * _s;
            break;
        // One hand travelling a circle: the shoulder and elbow are 90 degrees out of phase, which is
        // exactly what makes a hand describe a circle rather than an arc.
        case "crank":
            _sh0 = _base + _a * _w0 * 0.52 * sin(_u1 * LGE_TAU);
            _sh1 = _base + _a * _w1 * 0.52 * sin(_u1 * LGE_TAU + pi);
            _el0 = 0.42 + _a * _w0 * 0.62 * (0.5 + 0.5 * cos(_u1 * LGE_TAU));
            _el1 = 0.42 + _a * _w1 * 0.62 * (0.5 + 0.5 * cos(_u1 * LGE_TAU + pi));
            break;
        // Down from the shoulders with the elbows OPENING as the weight goes on. A press with
        // folding elbows is a curl.
        case "press_down":
            _sh0 = _base + _a * _w0 * 0.34 * (1 - _k) + 0.10;
            _sh1 = _base + _a * _w1 * 0.34 * (1 - _k) + 0.10;
            _el0 = 0.78 - _a * _w0 * 0.62 * _k;
            _el1 = 0.78 - _a * _w1 * 0.62 * _k;
            break;
        // Stoop, take it, straighten. The arms stay nearly straight all the way - a lift done with
        // bent arms is a curl, and the whole point of the pose is that the BACK is doing it.
        case "lift_carry":
            _sh0 = _base * (1 - 0.42 * _k) + _a * _w0 * 0.16 * _k;
            _sh1 = _base * (1 - 0.42 * _k) + _a * _w1 * 0.16 * _k;
            _el0 = 0.14 + _a * _w0 * 0.72 * _k;
            _el1 = 0.14 + _a * _w1 * 0.72 * _k;
            break;
        // Ground work. The arms hang and the motion is a small reach forward at the bottom.
        case "stoop_gather":
            _sh0 = _base * 0.55 + _a * _w0 * 0.44 * _s;
            _sh1 = _base * 0.55 + _a * _w1 * 0.44 * _s;
            _el0 = 0.30 + _a * _w0 * 0.50 * (1 - _s);
            _el1 = 0.30 + _a * _w1 * 0.50 * (1 - _s);
            break;
        // Both hands close together in front of the chest. The shoulders are nearly still and the
        // elbows are HIGH - the hands have to meet in front of the sternum, and that is a folded
        // arm, not a lowered one.
        case "tend_fine":
            _sh0 = _base * 0.42 + _a * _w0 * 0.10 * _s;
            _sh1 = _base * 0.42 + _a * _w1 * 0.10 * _s;
            _el0 = 1.02 + _a * _w0 * 0.26 * _s;
            _el1 = 1.02 - _a * _w1 * 0.26 * _s;
            break;
        // One arm out and up, elbow opening as it extends.
        case "reach_place":
            _sh0 = _base + _a * _w0 * 0.92 * _k;
            _sh1 = _base + _a * _w1 * 0.92 * _k;
            _el0 = 0.62 - _a * _w0 * 0.44 * _k;
            _el1 = 0.62 - _a * _w1 * 0.44 * _k;
            break;
        // A hand circling inside a vessel: a small circle, elbow out, shoulder almost fixed.
        case "stir":
            _sh0 = _base + _a * _w0 * 0.26 * sin(_u1 * LGE_TAU);
            _sh1 = _base + _a * _w1 * 0.26 * sin(_u1 * LGE_TAU + 0.9);
            _el0 = 0.66 + _a * _w0 * 0.34 * cos(_u1 * LGE_TAU);
            _el1 = 0.66 + _a * _w1 * 0.34 * cos(_u1 * LGE_TAU + 0.9);
            break;
        // Two-beat rocking. The two arms are in ANTIPHASE, so the figure is always doing something
        // even at the mid-point of the cycle where a single-arm rock would be momentarily still.
        case "rock":
            _sh0 = _base + _a * _w0 * 0.46 * (_s - 0.5);
            _sh1 = _base - _a * _w1 * 0.46 * (_s - 0.5);
            _el0 = 0.48 + _a * _w0 * 0.30 * _s;
            _el1 = 0.48 + _a * _w1 * 0.30 * (1 - _s);
            break;
        // A slow sway. Deliberately tiny: this is somebody NOT working, and if it moves as much as
        // the work loops the town has no visible rhythm.
        default:
            _sh0 = _base + _a * _w0 * 0.14 * (_s - 0.5);
            _sh1 = _base + _a * _w1 * 0.12 * (0.5 - _s);
            _el0 = 0.22 + _a * _w0 * 0.16 * _s;
            _el1 = 0.26 + _a * _w1 * 0.14 * (1 - _s);
            break;
    }
    return [_sh0, _el0, _sh1, _el1];
}

/// @desc The armature pose for work loop `_id` at phase `_u`.
///
/// Returns a struct in exactly the shape `lge_pose` returns, so `lge_armature(build, pose)` takes it
/// directly and there is one solver rather than two.
///
/// ⭐⭐ `_adj` IS HOW A STATION GETS A SAY IN THE POSE, AND IT IS THE ANSWER TO A DEFECT FOUR
/// SESSIONS FAILED TO NAME. `height` and `lean` are authored here, per LOOP; where the work actually
/// is is authored in `lge_station_spec`, per STATION. Two tables for one physical quantity, and
/// nothing joined them - so 25 of 46 workers were drawn beside work they were not touching, and
/// every session that "fixed" it was retyping one table to agree with the other by hand.
///
/// `lge_work_reach` SOLVES the correction instead, against the real armature, and hands it here.
/// This function stays the one place a working pose is built; it just stops being the only place
/// that gets to say where the hands go.
///
/// ⚠️ AN ADJUSTMENT, NEVER AN OVERRIDE. `dh` is added to the authored `height` and `dlean` to the
/// authored `lean`, so a loop's authored character is the starting point and the solve only ever
/// moves it as far as the geometry demands. Two earlier attempts at this OVERWROTE the shoulder and
/// both failed - one collapsed four loops onto the same pose, the other threw away the verb's own
/// stroke - and this file's own header records both.
///
/// @param {String} _id  from lge_labours_all()
/// @param {Real}   _u   phase, 0..1 (wrapped)
/// @param {Struct} [_adj] optional {dh, dlean} from lge_work_reach. Absent = the authored pose,
///                        bit for bit, which is what every existing caller and every buyer gets.
/// @returns {Struct|Undefined} undefined for an unknown id - see lge_labour_spec's default
function lge_labour_pose(_id, _u, _adj = undefined) {
    var _sp = lge_labour_spec(_id);
    if (is_undefined(_sp)) return undefined;
    var _dh = is_struct(_adj) ? _adj.dh : 0;
    var _dl = is_struct(_adj) ? _adj.dlean : 0;

    var _u1 = _u - floor(_u);
    var _k  = lge_pulse(_u1, _sp.at, _sp.rise, _sp.fall);   // 0 at rest, 1 at the working beat
    var _s  = lge_swell(_u1);                               // a smooth there-and-back
    var _st = lge_stance(_sp.stance);
    var _a  = _sp.amp;

    // WHERE THE HANDS ARE. `height` is measured down from shoulder height as a fraction of stature,
    // and it becomes the RESTING shoulder angle: hands at shoulder height means an arm out
    // horizontally (about 1.5 rad from straight down), hands at the floor means an arm straight
    // down (0). Negative heights are above the shoulder, which is what a raised blessing or a
    // called price needs.
    //
    // ⚠️ THIS IS THE NUMBER THAT MAKES AN ANVIL DIFFERENT FROM A CHOPPING BLOCK, and it is why the
    // corpus is not twelve animations in forty-six costumes.
    var _reach = clamp((1 - (_sp.height + _dh)) * 1.35, -0.45, 1.85);

    // ⛔⛔ AND THE SHOULDER MUST NOT SPEND THE WHOLE REACH, OR THE ELBOW ENDS UP OUT AT THE SIDE.
    // The forward rotation above stops a raised hand being a SPREAD hand. This is the other half:
    // it stops a raised hand being a RAISED ELBOW. A person working at a bench hangs the upper arm
    // and folds the elbow; only the elbow's ANGLE buys the height. Spending the whole of `_reach`
    // on the shoulder lifts the humerus itself, which is the wing-out half of the scarecrow and is
    // what survived the forward fix on the 19 low-motion loops (`stir` and `hold_still` at 100%).
    //
    // ⭐ THIS REDISTRIBUTION PROVABLY DOES NOT MOVE THE HAND, which is why it is safe to apply to
    // all 46 loops at once. The shoulder keeps `share` of the reach and the elbow is given the rest,
    // so the forearm's direction - `sh + el`, the thing that decides where the hand points and the
    // quantity `lge_labour_pose`'s own header calls "the TOTAL that points the forearm" - comes to
    // `_reach * share + verbElbow + _reach * (1 - share)` = `_reach + verbElbow`, exactly what it
    // was before. Only the ELBOW moves, inboard and down, which is the joint that was reading wrong.
    //
    // ⚠️ The three verbs that MULTIPLY the base (`tend_fine` 0.42, `stoop_gather` 0.55,
    // `lift_carry` 1-0.42k) do shift slightly, because their multiplier now applies to the
    // shoulder's share rather than the whole reach. That is in the intended direction - all three
    // are close-in jobs - but it is a real change and not a pure redistribution for them.
    var _base = _reach * LGE_SHOULDER_SHARE;
    var _lift = _reach - _base;

    // ⛔⛔ AND THE SAME NUMBER HAS TO SAY HOW FAR IN FRONT OF THE BODY THE WORK IS, OR THE ARM CAN
    // ONLY REACH SIDEWAYS. See the long block in `lge_armature`'s arm solve for the measurement:
    // until 2026-09-03 this armature had no depth term at all, so `_base` was spent entirely on a
    // LATERAL swing and a figure working at chest height was a figure with its arms straight out.
    //
    // ⭐ THE DERIVATION IS THE POINT: a work loop's `height` already says how high the hands work,
    // and for manual labour that is very nearly the same statement as how far FORWARD they are.
    // Hands at the floor are beside you and need no forward rotation; hands at shoulder height are
    // out in front of you at a bench, an anvil or a loom, never out at your sides. So the forward
    // reach is derived from the hand height rather than authored 46 times, and it is a per-loop
    // CONSTANT - it does not vary with the phase, because the bench does not move during the stroke.
    // A phase-varying `fwd` was rejected for exactly that reason: it would swing the arms in and out
    // of the picture plane once per cycle, which is a wobble nothing in the work is doing.
    //
    // 0.78 puts the top of the range (hands at shoulder height, _base 1.35) at 1.05 rad = 60 deg
    // forward, i.e. cos = 0.5 - the arm keeps half its lateral spread. `lge_arm_foreshorten` floors
    // it at LGE_ARM_FS_MIN so the deepest reaches stay legible as arms.
    // ⚠️ FROM `_reach`, NOT FROM `_base`. `_base` is only the shoulder's SHARE of the reach after
    // the split above; how far in front of the body the work sits is a fact about the WORK, and it
    // must not change because the shoulder's bookkeeping share changed.
    var _fwd = max(0, _reach) * 0.78;

    // Per-side working amplitudes. `hand` decides which arm carries the stroke; the other arm gets
    // a fraction of it, never zero - a completely still arm beside a working one reads as a
    // paralysis, and this wing has already shipped a figure whose arms were identical and read as
    // a scarecrow. The asymmetry is the life in the pose.
    var _w0 = 1.0, _w1 = 1.0;
    if (_sp.hand == "right") { _w0 = 0.24; _w1 = 1.0; }
    else if (_sp.hand == "left") { _w0 = 1.0; _w1 = 0.24; }

    // HOW FAR APART THE HANDS WORK. Read `spread` as a shoulder OPENING (both arms swing outward
    // together) plus an elbow UNFOLDING (a wide grip needs a straighter arm; hands that nearly touch
    // need a tightly folded one). Both terms are needed: opening the shoulders alone moves the whole
    // arm sideways and leaves the hands the same distance apart at the wrist, which is a shrug.
    //
    // ⚠️ THE SAME TERM IS ADDED TO BOTH ARMS, AND THAT IS CORRECT HERE ONLY BECAUSE OF THE
    // ARMATURE'S CONVENTION - which is worth stating, because the obvious reading is wrong. A
    // shoulder angle in this package is measured from straight down and opens OUTWARD ON EACH SIDE
    // (lge_pose_arm's header: a positive angle swings the viewer-left arm to -x and the right to
    // +x). So one positive term on both sides WIDENS. Negating one of them would swing both arms
    // the same way and read as a person leaning out of frame.
    var _spr = variable_struct_exists(_sp, "spread") ? _sp.spread : 0;
    var _op  = _spr * 0.42;      // shoulder opening, radians
    var _fold = -_spr * 0.34;    // elbow: wide grip straightens, narrow grip folds

    var _sh0 = _base, _el0 = 0.20, _sh1 = _base, _el1 = 0.20;

    // ⛔⛔ AN AIM CORRECTION WAS BUILT HERE ON 2026-09-03, MEASURED, AND REVERTED. The narrative is
    // kept because the next session will otherwise re-derive it, and because the reason it failed is
    // more useful than the fix would have been.
    //
    // THE OBSERVATION IS REAL. `_reach` is the angle that points the forearm, and the split above
    // says so in its own words: the forearm's direction "comes to `_reach + verbElbow`". Every verb
    // ADDS its resting elbow to a shoulder that already carries the whole pointing angle -
    // `tend_fine` 1.02 rad, `press_down` 0.78, `stir` 0.66 - so a loop that says its hands work at
    // bench height draws them flatter than it asked for. MEASURED by Internal_Ops/_arm_drawn.js
    // (self-test 10/10), which measures the DRAWN segment from elbow to wrist with the foreshortening
    // already in the x: 18 of 46 grid cells have BOTH drawn forearms in the horizontal band, and
    // `cook_ladle` and `beeward_smoke` were cropped to 4x and are plain scarecrows standing beside a
    // pot and a hive they are not touching.
    //
    // ⛔ SUBTRACTING THE RESTING ELBOW FROM THE SHOULDER TOOK 18 FLAT CELLS TO 5 AND WAS STILL WRONG,
    // AND THE SUITE IS WHAT SAID SO. `tend_fine` compresses its base to 0.42 and carries an elbow of
    // 1.02, so all four of its loops drove their shoulders into the behind-the-body floor and came
    // out with IDENTICAL shoulders: the distinctness gate went red at 0.03 against a floor of 0.06
    // on fisher_mend vs scribe_write. A fix that makes two of the 46 the same picture is worse than
    // the defect it removes, because the corpus's entire claim is that they differ.
    //
    // ⛔ AND THE OBVIOUS REPAIR - solve the shoulder so the WRIST lands where a straight arm at
    // `_reach` would put it, which has a closed form - measured WORSE: 18 flat cells became 10, and
    // it moved loops that already read as working (miller_sack 55 -> 16 degrees) because overwriting
    // the shoulder throws away the verb's own stroke.
    //
    // ⭐⭐ WHAT THE INVESTIGATION ACTUALLY ESTABLISHED, AND IT IS ABOUT THE METRIC: A FLAT FOREARM IS
    // NOT THE SAME THING AS A SCARECROW. `tend_fine`'s own header says "both hands close together in
    // front of the chest ... the elbows are HIGH", and a scribe's forearms over a desk ARE roughly
    // horizontal - correctly. The measured tell is that the four tend_fine loops put their wrists
    // 0.118-0.186 statures out while cook_ladle and beeward_smoke put them at 0.213 and 0.219: a
    // scarecrow is flat AND WIDE. ⚠️ That second term is NOT yet a bar - `_pose_drawn.js` records a
    // wrist-spread bar failing its own control, and inventing one here to separate the two cells I
    // happened to crop is a bar fitted to today's data, which this factory rates as costly as a
    // false green. The next pass on the arms needs the two-term measure validated against a dozen
    // cropped cells FIRST, then a fix chosen against it.
    var _va = lge_verb_arms(_sp.verb, _base, _a, _w0, _w1, _k, _s, _u1);
    _sh0 = _va[0]; _el0 = _va[1]; _sh1 = _va[2]; _el1 = _va[3];


    // Apply the spread AFTER the archetype, so every verb gets it and no verb has to remember to.
    // ⛔ THE ELBOW TERM IS THE HALF THAT MATTERS AND IT IS THE HALF THAT LOOKS REDUNDANT. Without it
    // the six fine-work jobs stayed within 0.036 of each other on the design probe even with the
    // shoulders opened, because `tend_fine` compresses its base by 0.42 and a shoulder opening
    // inside that compression is almost nothing. The hands are what a viewer looks at, and the
    // wrist's position comes from the elbow far more than from the shoulder.
    _sh0 += _op;
    _sh1 += _op;
    _el0 += _fold;
    _el1 += _fold;

    // The elbow's share of the reach - see the split at the top of this function. Added AFTER the
    // archetype for the same reason the spread is: every verb gets it and no verb has to remember.
    _el0 += _lift;
    _el1 += _lift;


    // ⭐⭐ THE AIM CORRECTION, THIRD ATTEMPT - AND THE FIRST ONE JUDGED AGAINST WHERE THE WORK
    // ACTUALLY IS RATHER THAN AGAINST HOW FLAT THE FOREARM LOOKS.
    //
    // The two attempts recorded above both failed, and they failed in OPPOSITE directions:
    //   * subtracting the verb's resting elbow from the shoulder over-corrected the verbs that
    //     COMPRESS their base (`tend_fine` 0.42) until four loops came out with identical
    //     shoulders and the corpus distinctness gate went red at 0.03 against a floor of 0.06;
    //   * solving the shoulder outright so the wrist lands where a straight arm would OVERWROTE
    //     the shoulder, which throws the verb's own stroke away - a hammer that no longer travels.
    //
    // ⭐ THIS IS NEITHER. The wrist solve is run ONCE, on the loop's RESTING arm, and only the
    // DIFFERENCE it would make is carried back as a per-side constant. So:
    //   * the arm is aimed where the loop's `height` said the hands work, which is the thing both
    //     earlier attempts were reaching for;
    //   * every phase-varying term - the whole stroke - is untouched, because a constant added to
    //     the shoulder cannot change how much that shoulder MOVES. `miller_sack` keeps its lift.
    //   * the offset is solved from each loop's own resting elbow, so it DIFFERS per loop and per
    //     side, which is why it does not collapse the four `tend_fine` loops onto each other the
    //     way a flat subtraction did.
    //
    // ⚠️ `lge_verb_arms` WITH THE AMPLITUDE FORCED TO ZERO IS THE RESTING ARM, and that is not a
    // trick - the function's own header states it is the reason the switch was lifted out here, so
    // the resting value is DERIVED from the same constants the stroke uses rather than restated.
    //
    // ⚠️ ONE VERB IS NOT PHASE-FREE AT ZERO AMPLITUDE: `lift_carry` scales its base by (1 - 0.42k),
    // so its "resting" arm genuinely changes through the lift and its offset varies a little with
    // phase. That is correct for a lift and is recorded rather than special-cased.
    //
    // ⛔ AND THE ARM MAY NOT SWING BEHIND THE BODY. Past about -0.30 rad the humerus points backward
    // and the shoulder cap detaches from the torso - a different defect wearing the same clothes.
    var _rv   = lge_verb_arms(_sp.verb, _base, 0, _w0, _w1, _k, _s, _u1);
    var _uarm = 0.166, _farm = 0.152;
    var _dtar = cos(_reach) * (_uarm + _farm);
    var _re0  = _rv[1] + _fold + _lift;
    var _re1  = _rv[3] + _fold + _lift;
    var _rr0  = point_distance(0, 0, _uarm + _farm * cos(_re0), _farm * sin(_re0));
    var _rr1  = point_distance(0, 0, _uarm + _farm * cos(_re1), _farm * sin(_re1));
    var _pp0  = arctan2(_farm * sin(_re0), _uarm + _farm * cos(_re0));
    var _pp1  = arctan2(_farm * sin(_re1), _uarm + _farm * cos(_re1));
    var _aim0 = arccos(clamp(_dtar / max(0.00001, _rr0), -1, 1)) - _pp0;
    var _aim1 = arccos(clamp(_dtar / max(0.00001, _rr1), -1, 1)) - _pp1;
    _sh0 = max(-0.30, _sh0 + (_aim0 - (_rv[0] + _op)));
    _sh1 = max(-0.30, _sh1 + (_aim1 - (_rv[2] + _op)));

    // ⚠️ A DEAD-HORIZONTAL FOREARM READS AS A MACHINE. shoulder + elbow = 1.57 rad is exactly 90
    // degrees and turns any pose into a ruled line with a hand on the end; the donor measured it on
    // its `reach` pose and backed off to 1.35. Nudging the total off the horizontal costs nothing
    // and cannot be seen as a deliberate angle, which is the whole point.
    var _t0 = _sh0 + _el0;
    if (abs(_t0 - 1.5708) < 0.08) _el0 -= 0.11;
    var _t1 = _sh1 + _el1;
    if (abs(_t1 - 1.5708) < 0.08) _el1 -= 0.11;

    return {
        sh0 : _sh0, el0 : max(0.02, _el0),
        sh1 : _sh1, el1 : max(0.02, _el1),
        // The symmetric fallback pair, kept truthful rather than zeroed: a caller reading `sh`/`el`
        // on one of these structs gets the average of the two arms, which is the honest answer.
        sh  : (_sh0 + _sh1) * 0.5,
        el  : (max(0.02, _el0) + max(0.02, _el1)) * 0.5,
        // How far the whole arm is rotated in front of the body. Read ONLY by
        // lge_arm_foreshorten(); a pose without it foreshortens by exactly 1.0, which is why the
        // five hand-authored poses in lge_pose are untouched by this.
        fwd : _fwd,
        hp  : _st.hp0, kn : _st.kn0,
        hp0 : _st.hp0, kn0 : _st.kn0,
        hp1 : _st.hp1, kn1 : _st.kn1,
        splay : _st.splay,
        // The lean and the head tilt peak WITH the working beat. A worker who leans on a fixed
        // schedule regardless of what their hands are doing reads as two animations played at once.
        // ⚠️ THE SOLVED STOOP RIDES ON THE BEAT LIKE THE AUTHORED ONE. A stoop that were constant
        // while the authored part pulsed would read as two animations played at once - the exact
        // note this line already carries for `lean` and `tilt`.
        lean  : (_sp.lean + _dl) * (0.45 + 0.55 * _k),
        tilt  : _sp.tilt * (0.55 + 0.45 * _k),
        thigh_k : _st.thigh_k
    };
}

/// ============================================================================================
/// THE WALK
/// ============================================================================================

/// @desc The pose of somebody walking to work, at phase `_u`.
///
/// ⛔ IT LIVES HERE, WITH THE OTHER POSES, AND IT IS A FUNCTION RATHER THAN THE ARMATURE'S NAMED
/// `walk`. `lge_pose("walk")` is ONE angle set - a single frame of a stride - and a townsperson
/// crossing the street in a single frozen frame is a statue on a conveyor belt. The armature's own
/// header records what that frame cost to author (both thighs met at the centre line and the figure
/// walked with its ankles crossed), so it is the right frame; it is just not a cycle.
///
/// ⚠️ NO VERTICAL BOB. A walking figure does rise and fall, and adding it here would be wrong: the
/// figure's POSITION comes from `lge_where`, which solves it from the routine, and a bob added in the
/// pose would be a second thing moving the body that the solve knows nothing about. If a buyer wants
/// one they add it at their draw call, where it belongs.
///
/// @param {Real} _u phase, 0..1
/// @returns {Struct} in exactly the shape lge_pose returns
function lge_walk_pose(_u) {
    var _u1 = _u - floor(_u);
    var _s = sin(_u1 * LGE_TAU);
    var _c = cos(_u1 * LGE_TAU);
    // The legs run in antiphase, and the knee folds on the SWING half only - a knee that bends on the
    // planted leg is a limp. `max(0, ...)` is what makes the fold one-sided.
    var _hp0 =  0.30 * _s;
    var _hp1 = -0.30 * _s;
    return {
        // The arms counter-swing the legs, at about a third of the amplitude, and the near arm leads
        // by a quarter cycle so the two are not a mirror of each other.
        sh0 : 0.16 + 0.20 * (-_s), el0 : 0.18 + 0.10 * max(0, _c),
        sh1 : 0.16 + 0.20 * (_s),  el1 : 0.18 + 0.10 * max(0, -_c),
        sh  : 0.16, el : 0.18,
        hp  : _hp0, kn : 0.06 + 0.30 * max(0, _s),
        hp0 : _hp0, kn0 : 0.06 + 0.30 * max(0, _s),
        hp1 : _hp1, kn1 : 0.06 + 0.30 * max(0, -_s),
        splay : 0.03,
        lean  : 0.045,
        tilt  : 0.010,
        // A walking thigh swings mostly IN the picture plane in a front view, so it foreshortens far
        // less than a seated one. 0.72 rather than 1.0 keeps the stride from reading as a split.
        thigh_k : 0.72
    };
}

/// ============================================================================================
/// DISTINCTNESS - the assertion that keeps the volume honest
/// ============================================================================================

/// @desc A work loop's pose signature: every joint angle at LGE_SIG_PHASES phases, flattened.
///
/// ⛔ THIS IS THE ONLY THING STANDING BETWEEN "46 WORK LOOPS" AND A MARKET CLAIM THAT IS NOT TRUE.
/// A corpus of 46 names over 12 motions is worth exactly as much as the differences between them,
/// and names are free. The signature compares what is DRAWN, so a loop that is another loop with a
/// different id cannot pass.
///
/// ⚠️ It samples the POSE FUNCTION, not the drawn parts, and says so. Two loops with identical poses
/// and different stations are still different pictures - which is why the station corpus carries its
/// own distinctness check rather than this one being asked to cover both.
///
/// @param {String} _id
/// @returns {Array} 12 * LGE_SIG_PHASES reals
function lge_labour_signature(_id) {
    var _out = [];
    for (var _i = 0; _i < LGE_SIG_PHASES; _i++) {
        var _p = lge_labour_pose(_id, _i / LGE_SIG_PHASES);
        if (is_undefined(_p)) return [];
        array_push(_out, _p.sh0, _p.el0, _p.sh1, _p.el1,
                         _p.hp0, _p.kn0, _p.hp1, _p.kn1,
                         _p.splay, _p.lean, _p.tilt, _p.thigh_k);
    }
    return _out;
}

/// @desc Mean absolute difference between two signatures. 0 = identical poses throughout.
function lge_labour_distance(_a, _b) {
    var _n = min(array_length(_a), array_length(_b));
    if (_n == 0) return 0;
    var _s = 0;
    for (var _i = 0; _i < _n; _i++) _s += abs(_a[_i] - _b[_i]);
    return _s / _n;
}

/// @desc How many VISUALLY DISTINCT STATIONS a loop's cycle passes through.
///
/// ⛔⛔ THIS EXISTS BECAUSE THE OBVIOUS TEST FOR "NOT A TWO-FRAME FLIP" IS WRONG, AND IT FALSE-RED 15
/// OF 46 CORRECT LOOPS BEFORE ANYONE NOTICED.
///
/// The obvious test - "the mid-phase pose must leave the straight line between the endpoints" - is a
/// true statement about an eased three-station move and a FALSE statement about a cosine. Sampling a
/// cosine at phases 0, 0.25 and 0.5 gives 1, 0, -1: the middle sample is EXACTLY the average of the
/// endpoints, so a perfectly smooth crank reads as a two-frame flip. Every `crank` and `rock` loop in
/// the corpus failed, and the corpus was not the thing that was wrong.
///
/// ⭐ THE PROPERTY ACTUALLY WANTED IS "THE CYCLE VISITS MORE THAN TWO STATES". So: sample the whole
/// pose at eight phases, find the two furthest apart (the cycle's own amplitude), and COUNT how many
/// of the eight sit meaningfully away from both of them. A two-frame flip has zero such intermediate
/// states by construction, whatever curve it is drawn with; an eased motion through three or more
/// stations has several. The measure does not care about the shape of the easing, which is what makes
/// it a test of the claim rather than a test of one implementation of it.
///
/// @param {String} _id
/// @returns {Real} how many of 8 sampled phases are intermediate states, 0 for a flip
function lge_labour_stations(_id) {
    var _n = 8;
    var _p = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _p[_i] = lge_labour_pose(_id, _i / _n);
    if (is_undefined(_p[0])) return 0;

    // Distance between two poses on the joints a viewer reads: both arms, and the lean.
    var _d = function(_a, _b) {
        return abs(_a.sh0 - _b.sh0) + abs(_a.el0 - _b.el0)
             + abs(_a.sh1 - _b.sh1) + abs(_a.el1 - _b.el1)
             + abs(_a.lean - _b.lean);
    };

    var _amp = 0;
    var _ia = 0, _ib = 0;
    for (var _i = 0; _i < _n; _i++) {
        for (var _j = _i + 1; _j < _n; _j++) {
            var _dd = _d(_p[_i], _p[_j]);
            if (_dd > _amp) { _amp = _dd; _ia = _i; _ib = _j; }
        }
    }
    // ⚠️ A CYCLE WITH NO AMPLITUDE HAS NO STATIONS, and returning a large number here would let a
    // frozen pose pass. The `hold_still` loops are near-static by design and still move: the corpus's
    // smallest amplitude is well above this floor, and the suite asserts that separately.
    if (_amp < 0.0001) return 0;

    var _mid = 0;
    for (var _i = 0; _i < _n; _i++) {
        if (_i == _ia || _i == _ib) continue;
        if (_d(_p[_i], _p[_ia]) > _amp * 0.22 && _d(_p[_i], _p[_ib]) > _amp * 0.22) _mid++;
    }
    return _mid;
}
