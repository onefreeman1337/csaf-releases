/// ============================================================================================
/// LIEGE — COLOUR
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// Oklch to RGB, with a chroma ceiling so a requested colour that does not exist in sRGB is pulled
/// to the nearest one that does instead of clipping to a different hue.
///
/// No colour is hard-coded anywhere else in this package. A theme is a set of Oklch stops, and the
/// whole town re-colours from one struct.
///
/// ⚠️ PORTED FROM `gm-raiment`. The town THEMES themselves are Liege's own and live below the
/// ported core.
///
/// ============================================================================================

#macro LGE_GOLDEN_ANGLE 137.50776405003785
#macro LGE_SAT_FLOOR 0.045

/// Oklab -> linear sRGB. Bjorn Ottosson's matrices.
function lge_oklab_linear(_L, _a, _b) {
    var _l = _L + 0.3963377774 * _a + 0.2158037573 * _b;
    var _m = _L - 0.1055613458 * _a - 0.0638541728 * _b;
    var _s = _L - 0.0894841775 * _a - 1.2914855480 * _b;
    _l = _l * _l * _l; _m = _m * _m * _m; _s = _s * _s * _s;
    return [
         4.0767416621 * _l - 3.3077115913 * _m + 0.2309699292 * _s,
        -1.2684380046 * _l + 2.6097574011 * _m - 0.3413193965 * _s,
        -0.0041960863 * _l - 0.7034186147 * _m + 1.7076147010 * _s
    ];
}

function lge_gamma(_c) {
    return (_c <= 0.0031308) ? (12.92 * _c) : (1.055 * power(_c, 1 / 2.4) - 0.055);
}

/// Chroma ceiling near white and near black.
///
/// Oklab will happily hand back a fully-saturated colour at L 0.95 and sRGB renders it as neon.
/// Real ink gets LESS chromatic as it approaches paper-white or lamp-black; this curve puts that
/// back, and it is what keeps the top two rarities looking expensive instead of radioactive.
function lge_chroma_ceiling(_L, _C) {
    var _hi = max(0, (_L - 0.68) / 0.32);
    var _lo = max(0, (0.22 - _L) / 0.22);
    return _C * (1 - _hi * 0.62) * (1 - _lo * 0.45);
}

/// Oklch -> a GameMaker colour, with GAMUT REDUCTION rather than clipping.
///
/// Clipping an out-of-gamut colour shifts its HUE - a too-saturated blue clips to purple - which
/// would quietly undo the perceptual spacing this whole file exists to provide. Walking chroma
/// down until the colour fits keeps the hue exactly where it was put.
function lge_oklch(_L, _C, _hdeg) {
    var _h = degtorad(_hdeg);
    var _c = lge_chroma_ceiling(_L, _C);
    var _rgb;
    for (var _i = 0; _i < 24; _i++) {
        _rgb = lge_oklab_linear(_L, cos(_h) * _c, sin(_h) * _c);
        if (_rgb[0] >= -0.0015 && _rgb[1] >= -0.0015 && _rgb[2] >= -0.0015
         && _rgb[0] <=  1.0015 && _rgb[1] <=  1.0015 && _rgb[2] <=  1.0015) break;
        _c *= 0.92;
    }
    _rgb = lge_oklab_linear(_L, cos(_h) * _c, sin(_h) * _c);
    return make_colour_rgb(
        round(clamp(lge_gamma(clamp(_rgb[0], 0, 1)), 0, 1) * 255),
        round(clamp(lge_gamma(clamp(_rgb[1], 0, 1)), 0, 1) * 255),
        round(clamp(lge_gamma(clamp(_rgb[2], 0, 1)), 0, 1) * 255)
    );
}

/// ============================================================================================
/// LIEGE'S OWN LAYER — MATERIALS, THEMES, AND THE HOUR OF THE DAY
/// ============================================================================================
///
/// ⭐ THE ONE THING IN THIS FILE THAT IS THE PRODUCT RATHER THAN A UTILITY: the light changes across
/// the day. A town whose people move to different stations at different hours but sits under the same
/// flat noon at 04:00 and 21:00 has told the buyer, in the most visible way available, that the day
/// is a lookup table. `lge_pal(theme, hour)` returns a DIFFERENT palette at every hour, and the "the
/// day" store sheet is four renders of one street that differ in light as well as in who is standing
/// in it.
///
/// ============================================================================================
/// WHY A MATERIAL IS NOT PART OF A THEME
/// ============================================================================================
///
/// Iron is blue-grey, oak is orange-brown, terracotta is red-orange, and a theme cannot change that
/// without producing a town made of the wrong substances. So the ten materials carry their PHYSICAL
/// Oklch anchor here, once, and a theme applies a rotation, a chroma multiplier, an L offset and a
/// small number of named overrides on the materials that actually vary by region - the stone, the
/// vegetation and the dyes.
///
/// ⛔ THE ALTERNATIVE WAS FOUR COPIES OF A SIXTY-ROLE TABLE, and this wing has a measured law against
/// exactly that shape: a fact stored in more than one place is a place a shipped product moves
/// without anyone editing it. Four themes over one anchor table cannot disagree about what iron is.

/// The material anchors: [L, C, hue degrees]. Read as "what this substance looks like in daylight".
///
/// ⚠️ `fir` (fire) IS DELIBERATELY THE ONLY ONE ABOVE L 0.75 AND C 0.15. It is the only emissive
/// material in the corpus - a forge, a cookfire, a brazier - and a flame that sits inside the same
/// range as the timber beside it reads as orange paint.
function lge_mat_anchor(_id) {
    switch (_id) {
        case "tim": return [0.545, 0.062,  58];   // timber: oak, warm brown
        case "irn": return [0.470, 0.020, 250];   // iron: cold grey, barely chromatic
        case "stn": return [0.610, 0.016,  78];   // stone: near-neutral, faintly warm
        case "cnv": return [0.760, 0.036,  82];   // canvas: unbleached linen
        case "cer": return [0.560, 0.098,  38];   // ceramic: terracotta
        case "thr": return [0.700, 0.044,  74];   // thread and basketwork: pale straw
        case "wat": return [0.520, 0.062, 232];   // water
        case "fir": return [0.820, 0.170,  62];   // fire: emissive
        case "grn": return [0.520, 0.086, 132];   // growing green
        case "lea": return [0.440, 0.058,  46];   // leather
        // ⛔ NO FALLBACK MATERIAL. A typo'd material id would otherwise resolve to a plausible grey
        // and every prop built in it would look almost right, which is the hardest defect to see.
        default:    return undefined;
    }
}

/// @desc How dirty, hot or sharp a trade's material is, 0..1.
///
/// ⭐ THIS IS WHY `lge_wear` NEEDS NO PER-TRADE OUTFIT TABLE. A smith wears an apron because iron
/// throws sparks, a mason because stone throws dust, a weaver does not because thread does neither.
/// That is a property of the MATERIAL, which every station already declares - so the clothing is
/// derivable from the trade with no extra authoring, which is the test `ARCHITECTURE.md` §2a sets to
/// stop the worn layer becoming a wardrobe.
function lge_mat_hazard(_id) {
    switch (_id) {
        case "irn": return 1.00;   // sparks and scale
        case "fir": return 1.00;
        case "stn": return 0.80;   // dust and chips
        case "cer": return 0.72;   // wet clay
        case "wat": return 0.62;
        case "lea": return 0.52;
        case "grn": return 0.44;
        case "tim": return 0.34;   // shavings, but nothing that burns or stains
        case "thr": return 0.20;
        case "cnv": return 0.18;
        default:    return 0.30;
    }
}

/// ============================================================================================
/// THEMES
/// ============================================================================================

function lge_themes_all() {
    return ["commons", "saltcoast", "redclay", "frostwold"];
}

/// @desc A theme: a global transform over the anchors plus the region's own stone, green and dyes.
///
/// Fields:
///   rot     hue rotation in degrees applied to every material
///   cmul    chroma multiplier
///   ladd    lightness offset
///   stone   [L,C,H] override for `stn` - the single most region-specific substance in a town
///   green   [L,C,H] override for `grn`
///   dye     base hue for the dye wheel, degrees
///   spread  how far apart the eight dyes sit on the wheel, degrees
///   sky     [L,C,H] for the backdrop at noon
function lge_theme(_id) {
    switch (_id) {
        // The default: an inland English-ish village. Warm oak, grey limestone, madder and woad.
        case "commons":   return { rot:  0, cmul: 1.00, ladd:  0.000, stone: [0.615, 0.014,  84],
                                   green: [0.520, 0.086, 132], dye:  22, spread: 41,
                                   sky: [0.760, 0.040, 232] };
        // Salt-bleached: everything paler and cooler, the stone almost white, the greens grey-green.
        case "saltcoast": return { rot: 14, cmul: 0.78, ladd:  0.045, stone: [0.700, 0.010, 206],
                                   green: [0.560, 0.052, 150], dye: 196, spread: 33,
                                   sky: [0.800, 0.032, 222] };
        // Southern: red earth, terracotta everywhere, hot bright dyes.
        case "redclay":   return { rot: -8, cmul: 1.22, ladd: -0.020, stone: [0.545, 0.062,  40],
                                   green: [0.480, 0.078, 118], dye:  16, spread: 47,
                                   sky: [0.780, 0.052, 246] };
        // Northern: cold light, blue-grey granite, dark firs, indigo and lichen dyes.
        case "frostwold": return { rot: 20, cmul: 0.86, ladd: -0.035, stone: [0.520, 0.014, 250],
                                   green: [0.430, 0.062, 156], dye: 254, spread: 29,
                                   sky: [0.700, 0.030, 240] };
        default:          return undefined;
    }
}

/// ============================================================================================
/// THE HOUR
/// ============================================================================================

/// @desc The light at hour `_t`: a lightness offset, a chroma multiplier and a hue pull.
///
/// ⚠️ CONTINUOUS AND WRAPPED, NOT FOUR NAMED TIMES OF DAY. A buyer scrubbing the clock past midnight
/// must see the light move smoothly, and a four-way `if` produces a visible jump at each boundary -
/// which is the same class of defect as a cycle with a discontinuity at u=0 (`lge_pulse`'s header).
///
/// The curve: a raised cosine on the sun's elevation, warm at both ends of the arc and cool at night.
///
/// @param {Real} _t hour, any sign
/// @returns {Struct} {ladd, cmul, hue, amb} - amb is 0 at deep night, 1 at noon, for the caller's
///                   own use (lamp strength, whether a brazier's glow is worth drawing).
function lge_daylight(_t) {
    var _h = lge_wrap(_t);
    // ⛔⛔ THE ELEVATION MUST BE PERIODIC IN 24 HOURS, AND THE FIRST VERSION WAS NOT. It read
    // `sin((_h - 5.5) / 15.0 * pi)` - a curve fitted to put dawn at 05:30 and dusk at 20:30, which
    // is correct in the middle of the day and DISCONTINUOUS at midnight: measured -0.669 at 23:59
    // and -0.914 at 00:00, so the light jumped every night. The suite caught it
    // (`palette: the light is continuous across midnight`), which is exactly the check that exists
    // because a four-way `if` over named times of day has the same defect at four boundaries instead
    // of one.
    //
    // ⭐ A FULL TURN OVER THE DAY IS PERIODIC BY CONSTRUCTION. `_h - 6` puts the peak at 12:00, and
    // the +0.18 lift raises the horizon crossings to about 04:40 and 19:20 - roughly a fourteen and
    // a half hour day, which is what the fitted curve was reaching for. The lift is the honest way
    // to get a long day out of a sinusoid; stretching the period is what broke it.
    var _e = sin((_h - 6.0) / LGE_DAY * LGE_TAU) + 0.18;
    var _up = clamp(_e, 0, 1);
    // ⚠️ CLAMPED, because the +0.18 lift pushes the peak to 1.18 and `_up * (1 - _up)` goes NEGATIVE
    // above 1 - which would make the light at noon warmer than at dawn and is the "a term added to a
    // value that is then clamped" trap running the other way.
    //
    // ⭐ WARMTH IS KEYED ON THE SUN BEING NEAR THE HORIZON, NOT ON IT BEING UP, and that is the
    // difference between a sunset and a light that turns blue the instant the sun sets. The first
    // version used `_up * (1 - _up)`, which is zero the moment `_e` goes negative - so 19:30 was
    // already a cold night, and the suite's "dawn and dusk pull warm" assertion failed on the dusk
    // half. An afterglow either side of the horizon crossing is both physically right and what the
    // assertion was actually about.
    var _near = max(0, 1 - abs(_e) / 0.45);
    return {
        ladd : -0.150 + 0.150 * _up,
        cmul : 0.62 + 0.38 * _up + 0.30 * _near,
        // Positive pulls toward orange, negative toward blue. Night is a real blue shift, not just
        // darker: a town drawn dark-but-neutral at 02:00 reads as an underexposed photograph.
        // ⚠️ THE TWO TERMS ADD RATHER THAN BRANCHING, so the function is continuous everywhere - a
        // branch on the sign of `_e` puts a step at every horizon crossing.
        hue  : _near * 16.0 + min(0, _e) * 26.0,
        amb  : _up
    };
}

/// ============================================================================================
/// THE PALETTE
/// ============================================================================================

/// @desc Build a five-stop ramp plus an ink for one anchor, under one light.
///
/// ⛔ CHROMA FALLS TOWARD THE LIGHT END, AND THAT IS PHYSICS, NOT TASTE. A highlight is the lamp's
/// own colour reflected off the surface, so it carries less of the surface's hue the brighter it
/// gets; a ramp with constant chroma produces five tints of one crayon and is the single most
/// reliable way to make generated shading look like a recolour.
///
/// ⚠️ AND THE HUE IS PULLED, NOT REPLACED, BY THE HOUR - weighted by the material's own CHROMA
/// CONTRIBUTION. Interpolating the hue of a colour with no chroma is meaningless (a measured row in
/// this wing's constitution): iron at C 0.020 must not swing 26 degrees at dusk, because 26 degrees
/// of nothing is still nothing and the arithmetic would spend its whole budget on the material that
/// cannot show it. Tune on the PALEST material, never the vivid one.
function lge_ramp(_pal, _prefix, _anchor, _light, _rot, _cmul, _ladd) {
    if (is_undefined(_anchor)) return _pal;
    var _L = clamp(_anchor[0] + _ladd + _light.ladd, 0.06, 0.97);
    var _C = max(0, _anchor[1] * _cmul * _light.cmul);
    // The hue pull is scaled by how much chroma there is to carry it.
    var _carry = clamp(_C / 0.10, 0, 1);
    var _H = _anchor[2] + _rot + _light.hue * _carry;
    for (var _i = 0; _i < LGE_RAMP_N; _i++) {
        var _f = _i / (LGE_RAMP_N - 1);            // 0 = shadow, 1 = highlight
        var _l = clamp(_L - 0.155 + _f * 0.300, 0.04, 0.985);
        var _c = _C * (1.10 - 0.55 * _f);
        variable_struct_set(_pal, _prefix + string(_i), lge_oklch(_l, _c, _H));
    }
    // The ink: the outline. Darker than m0 and slightly MORE chromatic, because a neutral black
    // outline around a warm form reads as a sticker cut out of the background.
    variable_struct_set(_pal, _prefix + "ink", lge_oklch(clamp(_L - 0.315, 0.035, 0.5), _C * 1.15, _H));
    return _pal;
}

/// @desc The whole town's colour, for one theme at one hour.
///
/// Roles: `<mat>0..<mat>4` and `<mat>ink` for each of the ten materials · `dy0_0..dy7_4` and
/// `dyN_ink` for the eight-dye wheel `lge_wear` draws garments from · `sk0..sk3` skin families ·
/// `hr0..hr3` hair families · `line`, `sky`, `ground`, `shade`.
///
/// ⚠️ BUILD IT ONCE PER FRAME AT MOST. It resolves about 170 colours through a gamut-reduction loop,
/// which is cheap once and not cheap per prop. `obj_lge_demo` caches it and rebuilds only when the
/// hour has moved by more than a rendering step.
///
/// @param {String} _theme_id
/// @param {Real} _hour
/// @returns {Struct|Undefined} undefined for an unknown theme - never a plausible stand-in
function lge_pal(_theme_id, _hour) {
    // ⛔⛔ AN UNKNOWN THEME ID FALLS BACK, AND THAT IS THE ONE PLACE IN THIS PACKAGE WHERE A
    // FALLBACK IS CORRECT. Everywhere else - `lge_work_spec`, `lge_station_spec`, `lge_labour_spec`
    // - an unknown id returns `undefined` on purpose, because those are CORPUS lookups and a
    // stand-in would satisfy the very assertion that exists to catch a typo. This is not a corpus
    // lookup: it is the function a BUYER calls every frame to get colours, and `undefined` here is
    // not a diagnosis, it is a crash in their draw event on a frame they cannot debug.
    //
    // MEASURED 2026-09-04 by the adversarial buyer pass (`gmtest_freshinstall.js --break`), which
    // is the whole reason that harness exists: `lge_pal("COMMONS", 9)` returned undefined and the
    // buyer's next line - `variable_struct_exists(_p, "sky")` - died with
    // `argument 1 incorrect type (undefined) expecting a Number`. A capitalised theme id is not an
    // exotic attack; it is what somebody types.
    //
    // ⚠️ IT STILL SAYS SO, ONCE. A silent fallback is how a buyer ships a game in the wrong region's
    // palette and never finds out; a debug line in the output log costs nothing and names the id.
    var _th = lge_theme(_theme_id);
    if (is_undefined(_th)) {
        var _all = lge_themes_all();
        show_debug_message("Liege: unknown theme \"" + string(_theme_id) + "\" - falling back to \""
                           + _all[0] + "\". Valid ids: " + string(_all));
        _th = lge_theme(_all[0]);
    }
    if (is_undefined(_th)) return undefined;
    var _lt = lge_daylight(_hour);
    var _p = {};

    var _mats = lge_materials_all();
    for (var _i = 0; _i < array_length(_mats); _i++) {
        var _m = _mats[_i];
        var _a = lge_mat_anchor(_m);
        // The two region-specific substances take the theme's own override rather than the anchor.
        if (_m == "stn") _a = _th.stone;
        if (_m == "grn") _a = _th.green;
        // ⚠️ FIRE IS EXEMPT FROM THE HOUR. It is emissive: a forge at midnight is the same orange it
        // is at noon, and dimming it with the daylight would make the one light source in a night
        // scene darker than the scene it is lighting.
        var _l = (_m == "fir") ? { ladd: 0, cmul: 1, hue: 0, amb: _lt.amb } : _lt;
        lge_ramp(_p, _m, _a, _l, _th.rot, _th.cmul, _th.ladd);
    }

    // The dye wheel. Eight cloth ramps around the theme's own dye hue, spaced by `spread` - so a
    // town's garments are a family rather than a rainbow, and `lge_wear` picks a trade's dye by hash
    // instead of anybody authoring forty-six outfits.
    for (var _d = 0; _d < LGE_DYES; _d++) {
        // Alternating outward from the base hue: the two most common dyes are the closest to it.
        var _k = ((_d + 1) div 2) * ((_d mod 2 == 0) ? 1 : -1);
        var _hd = _th.dye + _k * _th.spread;
        // Dyes vary in depth as well as hue - a town where every garment is the same value is a
        // paper-doll set. Odd indices are dimmer and less saturated: the cheap dyes.
        var _dl = 0.560 - (_d mod 3) * 0.055;
        var _dc = (0.078 - (_d mod 3) * 0.020) * _th.cmul;
        lge_ramp(_p, "dy" + string(_d) + "_", [_dl, _dc, _hd], _lt, 0, 1, 0);
    }

    // Skin. Four families, spaced in lightness along one warm hue band rather than in hue - which is
    // what actual skin does, and the alternative (four different hues) produces four different
    // materials rather than four people.
    for (var _s = 0; _s < 4; _s++) {
        lge_ramp(_p, "sk" + string(_s) + "_", [0.760 - _s * 0.135, 0.052 + _s * 0.014, 46 - _s * 4],
                 _lt, _th.rot * 0.3, _th.cmul, _th.ladd);
    }
    // Hair.
    for (var _r = 0; _r < 4; _r++) {
        lge_ramp(_p, "hr" + string(_r) + "_", [0.300 + _r * 0.155, 0.048 + _r * 0.010, 52 + _r * 6],
                 _lt, _th.rot * 0.3, _th.cmul, _th.ladd);
    }

    // The scene, and the renderer's fallback.
    _p.sky    = lge_oklch(clamp(_th.sky[0] + _lt.ladd * 1.35, 0.06, 0.97),
                          _th.sky[1] * _th.cmul * (0.7 + 0.5 * _lt.amb),
                          _th.sky[2] + _th.rot + _lt.hue * 0.6);
    _p.ground = variable_struct_get(_p, "stn1");
    _p.shade  = lge_oklch(clamp(0.230 + _lt.ladd, 0.04, 0.5), 0.030 * _th.cmul, 250 + _lt.hue);
    // ⛔ `line` IS THE RENDERER'S MISS FALLBACK (lge_render_colour) AND IT IS DELIBERATELY UGLY.
    // A miss means a part asked for a role the palette does not carry, and a plausible grey would
    // hide it; a magenta line is a diagnostic that cannot be mistaken for a design decision. The
    // suite asserts no part in the product ever resolves to it.
    _p.line   = make_colour_rgb(255, 0, 190);
    _p.hour   = lge_wrap(_hour);
    _p.amb    = _lt.amb;
    _p.theme  = _theme_id;
    return _p;
}

/// @desc Which dye index a trade wears. Derived, never authored.
///
/// ⚠️ THE HASH IS OVER THE WORK LOOP ID, so a trade's garment colour is stable for the life of the
/// product and identical in every buyer's build - and adding a work loop cannot re-colour an existing
/// one, which a sequential index assignment would do to every trade after the insertion point. The
/// station corpus's own header makes the same point about array order being part of the product.
function lge_dye_of(_work_id) {
    return lge_hash32(_work_id) mod LGE_DYES;
}

/// How many dyes the wheel carries. Named because `lge_dye_of` takes a modulus of it, `lge_pal`
/// builds exactly this many ramps, and `lge_town_populate` shifts a household member along it - and
/// three separate literal 8s is how one of them silently stops matching the other two.
#macro LGE_DYES 8

