{
  "$GMScript": "v1",
  "%Name": "lge_relief",
  "name": "lge_relief",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}
