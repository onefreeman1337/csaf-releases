/// ============================================================================================
/// LIEGE — RELIEF
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// Shading by SURFACE NORMAL against one fixed lamp: walk a closed outline edge by edge, take
/// each edge's outward normal, and colour the wall under it from a five-stop ramp by how squarely
/// it faces the light. It is what makes a generated prop read as a physical object rather than an
/// icon, and it is the single most reused function in this wing.
///
/// ⚠️ PORTED FROM `gm-raiment`. Five laws are baked into the code below and each cost a shipped
/// defect: a bevel is a property of the EDGE (one wider than the feature turns it inside out); a
/// self-crossing outline fills the wrong region; painter's order IS the gradient when layers are
/// translucent; a recessed field is a circle on every blank; size anything inside a form from its
/// MEASURED profile, never its nominal radius.
///
/// ============================================================================================

#macro LGE_LX -0.7071067811865476
#macro LGE_LY -0.7071067811865476

/// ============================================================================================
/// THE LAMP
///
/// Set once, or once per frame if the buyer's game moves its light. Defaults to the studio's
/// fixed diagonal so that every panel, well, bezel and rim in the package lights the way
/// it always has.
///
/// ⚠️ THESE TWO LINES RUN AT GAME START, not on first use. GML executes top-level script code
/// once when the game boots, before the first room. lge_selftest asserts that it happened.
/// ============================================================================================
global.lge_lx = LGE_LX;
global.lge_ly = LGE_LY;

/// Point the lamp. _lx,_ly is a direction TOWARDS the light; it is normalised here so a caller
/// can hand in the difference between a light position and the part without thinking
/// about it.
///
/// ⛔ A ZERO VECTOR IS NOT AN ERROR AND MUST NOT BE ONE - a caller subtracting two positions
/// gets exactly zero the moment the light passes over the part, and throwing an exception
/// at that one frame is the worst possible failure mode. A zero length falls back to the
/// default diagonal.
function lge_lamp_set(_lx, _ly) {
    var _m = sqrt(_lx * _lx + _ly * _ly);
    if (_m < 0.0001) { global.lge_lx = LGE_LX; global.lge_ly = LGE_LY; return; }
    global.lge_lx = _lx / _m;
    global.lge_ly = _ly / _m;
}

/// Put the lamp back where the rest of the package expects it. Call after any lge_lamp_set and
/// before drawing anything you did not intend to relight, or one panel in a screenful will be
/// lit from below and read as a hole.
function lge_lamp_reset() {
    global.lge_lx = LGE_LX;
    global.lge_ly = LGE_LY;
}

/// The five ramp roles, in order. Named here so nothing else in the package has to know that the
/// material ramp is five stops long.
#macro LGE_RAMP_N 5

/// ============================================================================================
/// FORM SHADING - the switch that decides whether a body is a shape or a silhouette
///
/// ⛔⛔ THE DONOR SHIPPED EVERY MASS AS A FLAT FILL UNTIL 2026-09-02, AND THAT IS WHY ITS FIGURES
/// READ AS SCHEMATIC. The relief layer above - the lamp, the normals, the five-stop ramp, lge_dome -
/// was reaching only the hard-surface layer. The body, the head, the hands and the feet were single
/// flat colours with at most one shade band, so a torso and a forearm were the same rendering
/// object: a coloured region with an outline. Gate 1 called it "flat colour panels with a single
/// shade band" and was right. Every prop this product generates goes through the relief path for
/// that reason, and so does the figure.
///
/// ⚠️ AND IT IS A REAL COST, SO IT IS A SWITCH RATHER THAN AN ASSUMPTION. Form shading roughly
/// doubles a figure's part count, which is free for a hero render and is not free for thirty
/// townspeople on screen at map size - where the shading is sub-pixel anyway and the silhouette is
/// the whole picture. LGE_DETAIL_FLAT is the honest answer for that case and it is one call, and a
/// town of NPCs is precisely the case this product is bought for.
///
/// ⚠️ The global is initialised at top level, like the lamp above, and every reader goes through
/// lge_form_on() so a buyer's older saved code that never calls lge_detail_set still gets the
/// shaded default rather than a crash.
/// ============================================================================================

/// Silhouette and fill only. For crowds drawn at map size, where shading is sub-pixel.
#macro LGE_DETAIL_FLAT 0
/// Fills plus form shading. The default, and what the store sheets are drawn at.
#macro LGE_DETAIL_FORM 1

global.lge_detail = LGE_DETAIL_FORM;

/// Set the drawing detail level for every mass in the package.
/// @param {Real} _n LGE_DETAIL_FLAT or LGE_DETAIL_FORM
function lge_detail_set(_n) {
    global.lge_detail = clamp(_n, LGE_DETAIL_FLAT, LGE_DETAIL_FORM);
}

/// Is form shading on? Every mass builder asks this rather than reading the global.
function lge_form_on() {
    if (!variable_global_exists("lge_detail")) return true;
    return global.lge_detail >= LGE_DETAIL_FORM;
}

/// A rounded MASS: a flat field at _face, curved across its WHOLE width by a lit dome.
///
/// ⚠️ NOT lge_raise, AND THE DIFFERENCE IS THE SUBJECT. lge_raise chamfers the RIM and leaves a
/// broad flat top, which is what a struck coin or a rivet looks like. A skull, a chest or a shoulder
/// has no flat top at all: the tone travels the whole way across, which is lge_dome's own argument
/// in its header. Using the wrong one here reads as a sticker of a body rather than as a body.
///
/// ⛔ CONVEX ONLY, like lge_dome - see that function's warning. The torso ring is mildly waisted and
/// stays star-shaped about its centroid, so it is safe; a crescent is not.
///
/// @param {Array} _pts closed outline
/// @param {Real} _k how far in the dome reaches (0.55 leaves a broad lit crown)
/// @param {Real} _steps how many rings
/// @param {String} _face the flat field's role
/// @returns {Array} part list
function lge_mass(_pts, _k, _steps, _face) {
    var _out = [lge_ring_fill(_pts, is_undefined(_face) ? "m2" : _face, undefined, undefined)];
    if (!lge_form_on()) return _out;
    return lge_append(_out, lge_dome(_pts, _k, _steps));
}

/// ⭐ A TUBE'S SHADING, AS BANDS ACROSS ITS WIDTH - the one thing lge_dome must not be used for.
///
/// ⛔ lge_dome SCALES ABOUT THE CENTROID, WHICH IS ISOTROPIC, AND A LIMB IS NOT. Applied to an arm
/// it shrinks the ring along its LENGTH as fast as across its width, so the top and bottom quads
/// become half the limb each and the segment reads as a bevelled plank with dark ends. The wing's
/// own law, measured on a previous product: a long form is curved across its width and very nearly
/// flat along its length, so a photograph of one has a bright side, a dark side, and no highlight
/// at either end.
///
/// The two rails run proximal-to-distal on both sides and must be the same length. The lateral
/// fraction f runs -1 at rail A to +1 at rail B, and the ramp stop comes from the lamp against the
/// A-to-B direction at tilt f - so a hanging arm, a raised arm and a bent knee are all lit
/// correctly with no per-pose special case.
///
/// ⚠️ THE 1.18 GAIN IS NOT DECORATION. The default lamp is a diagonal, so the lamp dot on a
/// vertical limb is about 0.707 and a band centred at f = 0.89 lands at ramp position 0.186 -
/// just inside m0. Without the gain the outermost bands sit at m1 and m3 and the rim stops of the
/// ramp are never reached on any limb in the product, which is a five-stop ramp rendering as three.
///
/// @param {Array} _ra one rail
/// @param {Array} _rb the other rail, same length
/// @param {Real} _n how many bands
/// @returns {Array} part list
function lge_tube_bands(_ra, _rb, _n) {
    var _out = [];
    var _len = array_length(_ra);
    if (_len < 2 || array_length(_rb) != _len || _n < 2) return _out;
    if (!lge_form_on()) return _out;

    // The A-to-B direction, averaged over the whole rail so a taper cannot swing it.
    var _mx = 0, _my = 0, _i, _k;
    for (_i = 0; _i < _len; _i++) {
        _mx += _rb[_i][0] - _ra[_i][0];
        _my += _rb[_i][1] - _ra[_i][1];
    }
    var _ml = sqrt(_mx * _mx + _my * _my);
    if (_ml < 0.0001) return _out;
    _mx /= _ml;
    _my /= _ml;

    for (_k = 0; _k < _n; _k++) {
        var _t0 = _k / _n;
        var _t1 = (_k + 1) / _n;
        var _f = (_t0 + _t1) - 1.0;          // band centre, -1 at rail A, +1 at rail B
        var _a = array_create(_len);
        var _b = array_create(_len);
        for (_i = 0; _i < _len; _i++) {
            _a[_i] = [lerp(_ra[_i][0], _rb[_i][0], _t0), lerp(_ra[_i][1], _rb[_i][1], _t0)];
            _b[_i] = [lerp(_ra[_i][0], _rb[_i][0], _t1), lerp(_ra[_i][1], _rb[_i][1], _t1)];
        }
        array_push(_out, lge_strip(_a, _b, lge_relief_role(_mx, _my, clamp(_f * 1.18, -1, 1))));
    }
    return _out;
}

/// lge_dome, gated by the detail switch.
///
/// Use it where the flat field cannot go through lge_mass - a concave ring that needs an explicit
/// fan apex, for instance, which is exactly the torso's case.
function lge_form_dome(_pts, _k, _steps) {
    if (!lge_form_on()) return [];
    return lge_dome(_pts, _k, _steps);
}

/// The two rails of a four-point limb ring from lge_limb_ring, as {a, b}.
///
/// ⚠️ IT DEPENDS ON THAT FUNCTION'S POINT ORDER AND SAYS SO: [A+n, B+n, B-n, A-n]. Written as a
/// named reader rather than four subscripts at each call site, because a silent re-ordering there
/// would turn every limb band into a bowtie and the shading would cross the limb.
function lge_limb_rails(_ring) {
    if (array_length(_ring) != 4) return { a: [], b: [] };
    return { a: [_ring[0], _ring[1]], b: [_ring[3], _ring[2]] };
}

/// ============================================================================================
/// OUTLINE GEOMETRY
/// ============================================================================================

/// Twice the signed area of a closed polygon. Sign tells us the winding, which tells us which of
/// the two perpendiculars points OUT.
///
/// ⚠️ THE PACKAGE DOES NOT REQUIRE A WINDING CONVENTION FROM ITS AUTHORS, AND THAT IS DELIBERATE.
/// Every form in the corpus is authored by hand; a rule that says "always list your points clockwise"
/// is a rule that will be broken silently, and the failure mode - a mark lit from the wrong side
/// while everything around it is lit correctly - is subtle enough to ship. Measuring the winding
/// costs one loop and makes the rule unnecessary.
function lge_area2(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return 0;
    var _s = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i], _b = _pts[(_i + 1) % _n];
        _s += _a[0] * _b[1] - _b[0] * _a[1];
    }
    return _s;
}

/// The outward unit normal of the edge leaving vertex _i of a closed polygon.
function lge_edge_normal(_pts, _i, _sign) {
    var _n = array_length(_pts);
    var _a = _pts[_i], _b = _pts[(_i + 1) % _n];
    var _dx = _b[0] - _a[0], _dy = _b[1] - _a[1];
    var _len = point_distance(0, 0, _dx, _dy);
    if (_len == 0) return [0, 0];
    return [(_dy / _len) * _sign, (-_dx / _len) * _sign];
}

/// Move every vertex of a CLOSED polygon inward by _d along its averaged vertex normal.
///
/// Wraps at both ends, unlike the primitive layer's open-polyline offset. A ring whose first and
/// last vertices were offset one-sidedly develops a notch exactly where the seam is, and on a
/// circle - which is most of this product - the seam is at three o'clock, in plain view.
function lge_inset(_pts, _d, _sign) {
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[(_i + _n - 1) % _n], _q = _pts[(_i + 1) % _n];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) { _out[_i] = [_pts[_i][0], _pts[_i][1]]; continue; }
        var _nx = (_dy / _len) * _sign, _ny = (-_dx / _len) * _sign;
        _out[_i] = [_pts[_i][0] - _nx * _d, _pts[_i][1] - _ny * _d];
    }
    return _out;
}

/// The winding sign to pass to lge_edge_normal / lge_inset so that "normal" means OUTWARD.
function lge_out_sign(_pts) {
    return (lge_area2(_pts) > 0) ? 1 : -1;
}

/// Scale a closed outline about its own centroid. Used for nesting rings and for the recessed
/// field inside a mass - the hollow of a bowl, the well of a soup, a thumbprint in a bun.
function lge_scale_pts(_pts, _k) {
    var _n = array_length(_pts);
    var _cx = 0, _cy = 0;
    for (var _i = 0; _i < _n; _i++) { _cx += _pts[_i][0]; _cy += _pts[_i][1]; }
    _cx /= _n; _cy /= _n;
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        _out[_i] = [_cx + (_pts[_i][0] - _cx) * _k, _cy + (_pts[_i][1] - _cy) * _k];
    }
    return _out;
}

/// Translate a closed outline.
function lge_move_pts(_pts, _dx, _dy) {
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _out[_i] = [_pts[_i][0] + _dx, _pts[_i][1] + _dy];
    return _out;
}

/// ============================================================================================
/// THE RAMP LOOKUP
/// ============================================================================================

/// Which of the five material stops a wall with this outward normal shows.
///
/// _tilt is how far the wall leans away from the face: 1.0 is a vertical wall that swings across
/// the whole ramp, 0.0 is flat and always shows the face value. See the header for why nesting
/// rings at constant tilt draws a target.
///
/// ⚠️ THE BANDS ARE HARD, NOT INTERPOLATED, AND THAT IS THE CORRECT CHOICE HERE rather than a
/// limitation. Five discrete values around a rim is what a made coin photographs like, and it is
/// what makes the material readable - a continuous gradient would need hundreds of colours and would
/// average out to a flat disc at inventory size, which is precisely where the tier has to read.
function lge_relief_role(_nx, _ny, _tilt) {
    var _d = _nx * global.lge_lx + _ny * global.lge_ly;
    var _t = 0.5 + 0.5 * _d * _tilt;
    if (_t < 0.190) return "m0";
    if (_t < 0.385) return "m1";
    if (_t < 0.615) return "m2";
    if (_t < 0.810) return "m3";
    return "m4";
}

/// ============================================================================================
/// THE BEVEL
/// ============================================================================================

/// The axis-aligned bounds of a point list, as [x0, y0, x1, y1].
function lge_pts_bounds(_pts) {
    var _n = array_length(_pts);
    if (_n == 0) return [0, 0, 0, 0];
    var _x0 = _pts[0][0], _y0 = _pts[0][1], _x1 = _x0, _y1 = _y0;
    for (var _i = 1; _i < _n; _i++) {
        _x0 = min(_x0, _pts[_i][0]); _x1 = max(_x1, _pts[_i][0]);
        _y0 = min(_y0, _pts[_i][1]); _y1 = max(_y1, _pts[_i][1]);
    }
    return [_x0, _y0, _x1, _y1];
}

/// ⛔ A SAFETY BOUND EVALUATED EXACTLY IS NOT A SAFETY BOUND. The arc bound below approximates a
/// continuous curve by its samples, so it carries a factor; the vertex bound measures an actual
/// notch and does not. Averaging the two into one multiplier protects against neither - the donor
/// tried it and starved a square corner while the cove still failed.
#macro LGE_REFLEX_SAFETY 0.45

/// @desc The largest inset a bevel may use without turning this outline inside out.
///
/// ⛔ THE ARCHITECTURE NAMES THIS AS THE HIGHEST-RISK DRAWING DECISION IN THE PRODUCT AND IT IS WHY
/// THE CAP LIVES INSIDE `lge_bevel` RATHER THAN AT ITS CALL SITES. A bevel is bounded by the
/// outline's SHORTEST EDGE, not by the shape's smaller dimension: a barrel body 0.22 by 0.36 is
/// allowed 0.048 by the dimension rule while the edges between its 26 sampled points are about 0.03
/// long, so insetting by 0.048 swaps consecutive inset points and every wall quad becomes a BOWTIE -
/// silently, with the outline, the winding and the ink all still correct. Eight fills across a
/// barrel, a cauldron and a sack failed exactly this way on a sibling product. This package draws a
/// barrel, a churn, a tub, a sack, a vat and a mash tun, so it is not a hypothetical shape here.
///
/// ⚠️ Also capped at 35% of the smaller bounding dimension: beyond that a bevel has eaten the face it
/// is supposed to be a border on, which is a design failure rather than a geometric one.
///
/// Ported from the donor's `rai_inset_limit`, whose two-bound structure is the part worth keeping.
function lge_inset_limit(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return 0;
    var _bb = lge_pts_bounds(_pts);
    var _limit = min(_bb[2] - _bb[0], _bb[3] - _bb[1]) * 0.35;
    var _wind = (lge_area2(_pts) >= 0) ? 1 : -1;

    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[(_i + _n - 1) % _n];
        var _b = _pts[_i];
        var _c = _pts[(_i + 1) % _n];
        var _ux = _b[0] - _a[0], _uy = _b[1] - _a[1];
        var _vx = _c[0] - _b[0], _vy = _c[1] - _b[1];
        var _lu = point_distance(0, 0, _ux, _uy);
        var _lv = point_distance(0, 0, _vx, _vy);
        // A zero-length edge must be SKIPPED, not measured: a duplicated point otherwise caps every
        // bevel in the package to nothing, and the picture goes flat with no assertion firing.
        if (_lu <= 0.0001 || _lv <= 0.0001) continue;
        var _turn = arctan2(_ux * _vy - _uy * _vx, _ux * _vx + _uy * _vy);

        // A SHARP CONVEX VERTEX IS NOT UNCONSTRAINED, because lge_inset's normal is only as good as
        // the two edges it is averaged from: where a long straight run meets a short chamfer, the
        // computed normal is dominated by the long edge and points the wrong way. Bounding by the
        // SHORT adjacent edge bounds how far that error can travel. Scoped to turns above 30
        // degrees, so a sampled curve (5 to 15 degrees per vertex) is untouched.
        var _sharp = 0.5236;
        if (_turn * _wind > 0 && abs(_turn) > _sharp) {
            _limit = min(_limit, min(_lu, _lv) * 0.45);
        }
        // Same sign as the winding is a CONVEX vertex: the inset edges diverge, no reflex limit.
        if (_turn * _wind >= 0) continue;
        var _half = abs(_turn) * 0.5;
        // A full reversal (a spike) has tan -> infinity and the limit correctly goes to zero.
        var _t = tan(min(_half, LGE_TAU * 0.25 - 0.0001));
        if (_t <= 0.0001) continue;
        // (a) The VERTEX bound: where this one notch's two inset edges meet.
        _limit = min(_limit, (min(_lu, _lv) * 0.5) / _t);
        // (b) The ARC bound: a run of consecutive reflex vertices is a concave CURVE, and a concave
        //     curve of radius R collapses to a point when inset by R however short its segments are.
        var _sinHalf = sin(_half);
        if (_sinHalf > 0.0001) {
            _limit = min(_limit, (min(_lu, _lv) / (2 * _sinHalf)) * LGE_REFLEX_SAFETY);
        }
    }
    return max(0, _limit);
}

/// @desc How much of a requested bevel depth this outline can actually take, 0..1.
///
/// ⚠️ EXPOSED SEPARATELY BECAUSE `lge_bevel` NOW CAPS ITSELF, WHICH MAKES "the bevel never turns the
/// outline inside out" TRUE BY CONSTRUCTION - and an assertion that can never go red is the vacuous
/// green a suite exists to prevent. The suite asserts THIS instead: a builder whose requested depth
/// is genuinely wrong for its shape still fires BY NAME, as a correction factor well below 1,
/// instead of being silently shrunk to nothing and rendering flat.
function lge_bevel_ratio(_pts, _want) {
    if (_want <= 0) return 1;
    return min(1, lge_inset_limit(_pts) / _want);
}

/// A domed wall running inward from a closed outline, as normal-shaded quads.
///
/// _b      how far in the wall reaches, in unit-box units (CAPPED - see lge_inset_limit)
/// _steps  how many nested rings (1 = a flat chamfer, 3 = a convincing dome)
/// _invert true for a SUNKEN shape, where the wall faces inward and the lit side swaps
///
/// Each quad is [outer_i, outer_i+1, inner_i+1, inner_i] - convex, so the fan primitive draws it
/// correctly with no special casing.
function lge_bevel(_pts, _b, _steps, _invert) {
    var _n = array_length(_pts);
    var _out = [];
    if (_n < 3 || _b <= 0) return _out;
    // ⛔ THE CAP IS HERE, NOT AT THE CALL SITES THAT HAPPEN TO FAIL. Tuning three constants at three
    // call sites makes a suite green and leaves the next sampled curve to rediscover the bowtie.
    _b = min(_b, lge_inset_limit(_pts));
    if (_b <= 0) return _out;
    var _st = max(1, _steps);
    var _sign = lge_out_sign(_pts) * (_invert ? -1 : 1);
    var _geo = lge_out_sign(_pts);

    var _rings = array_create(_st + 1);
    for (var _s = 0; _s <= _st; _s++) _rings[_s] = lge_inset(_pts, _b * (_s / _st), _geo);

    for (var _s = 0; _s < _st; _s++) {
        // Outer walls are steep, inner walls are nearly flat. 0.30 rather than 0 at the innermost
        // ring because a wall that shows exactly the face value is a wall you cannot see, and the
        // dome then ends in a visible step instead of easing into the field.
        var _tilt = lerp(1.0, 0.30, (_s + 0.5) / _st);
        var _a = _rings[_s], _c = _rings[_s + 1];
        for (var _i = 0; _i < _n; _i++) {
            var _k = (_i + 1) % _n;
            var _nm = lge_edge_normal(_pts, _i, _sign);
            array_push(_out, lge_fill([_a[_i], _a[_k], _c[_k], _c[_i]],
                                      lge_relief_role(_nm[0], _nm[1], _tilt)));
        }
    }
    return _out;
}

/// ⛔⛔ A DOME ON A LARGE CONVEX MASS CANNOT BE BUILT WITH lge_bevel, AND THE REASON IS THE INSET
/// LIMITER DOING ITS JOB CORRECTLY. Measured 2026-09-01 on a sibling product in this wing, not here.
///
/// lge_bevel insets by a DISTANCE, and lge_inset_limit refuses a distance that would swap
/// consecutive inset points and turn a wall quad into a bowtie. On a densely sampled curve the
/// edges are short, so the legal distance is small: MEASURED on the donor's body outline (the same
/// one this package ports), 192 points, shortest edge 0.00885, limit 0.00497 - a 3 px shell on a
/// 700 px figure. The limiter
/// is right, the request is right, and the picture is flat. Sampling the curve MORE finely makes it
/// worse, which is the trap: two quality knobs that both look like "more is better" pull against
/// each other and nothing reports the trade.
///
/// ⭐ SCALING CANNOT SELF-INTERSECT A CONVEX RING, SO IT IS NOT BOUND BY THAT LIMIT AT ALL. Shrink
/// the outline about its own centroid instead of insetting it by a distance, and the rings nest
/// safely all the way to the centroid whatever the sampling density is. That is also the physically
/// right model for these subjects: a chest, a shoulder, a sack of grain, a churn and a barrel are
/// not flat panels with a chamfer round the edge, they are surfaces that curve across their WHOLE
/// width, so the tone has to travel the whole way. A mass shaded only at its rim reads as a cut-out.
///
/// ⚠️ IT IS THE WRONG TOOL FOR A CONCAVE OR RING-SHAPED OUTLINE - scaling a crescent about its
/// centroid moves the arms through each other - and it is the wrong tool for a SMALL detail, where
/// a physical chamfer of a fixed depth is exactly what is wanted. Use lge_bevel there. This is for
/// one thing: a big convex mass that needs to read as ROUND.
///
/// _k is how far in the dome reaches as a fraction of the shape (0.55 leaves a broad lit crown);
/// _steps is how many rings. The shading is identical to lge_bevel's - each quad takes its stop
/// from its own edge normal against the lamp - so a domed mass and a bevelled one are lit
/// consistently, which is what stops an animal looking assembled from two rendering styles.
function lge_dome(_pts, _k, _steps) {
    var _n = array_length(_pts);
    var _out = [];
    if (_n < 3 || _k <= 0) return _out;
    var _st = max(1, _steps);
    var _sign = lge_out_sign(_pts);

    var _rings = array_create(_st + 1);
    for (var _s = 0; _s <= _st; _s++) {
        _rings[_s] = lge_scale_pts(_pts, 1 - clamp(_k, 0, 0.98) * (_s / _st));
    }

    for (var _s = 0; _s < _st; _s++) {
        // The tilt falls off toward the middle: the rim of a shell is nearly edge-on to the viewer
        // and its centre is nearly flat, which is what makes a dome read as a dome rather than as a
        // set of concentric bands. Ending at 0.22 rather than 0 keeps the innermost ring faintly
        // shaded - a ring that shows exactly the face value is a visible step, not an easing.
        var _tilt = lerp(1.0, 0.22, (_s + 0.5) / _st);
        var _a = _rings[_s], _c = _rings[_s + 1];
        for (var _i = 0; _i < _n; _i++) {
            var _j = (_i + 1) % _n;
            var _nm = lge_edge_normal(_pts, _i, _sign);
            array_push(_out, lge_fill([_a[_i], _a[_j], _c[_j], _c[_i]],
                                      lge_relief_role(_nm[0], _nm[1], _tilt)));
        }
    }
    return _out;
}

/// ============================================================================================
/// THE TWO COMPOSITES EVERYTHING ELSE IS BUILT FROM
/// ============================================================================================

/// A RAISED shape: a flat top at _face, walled all round by a lit dome.
///
/// ⛔ THE FACE IS DRAWN FIRST AND THE WALL SECOND, AND SWAPPING THEM COSTS THE WHOLE EFFECT. The
/// wall's inner ring and the face overlap by design - the fan that fills the face is star-shaped
/// about its centroid and cannot be trusted to land exactly on the wall's inner edge on a
/// concave outline, so the wall is painted over the face rather than butted against it. Drawn the
/// other way round, every concave mark grows a hairline of face colour outside its own bevel.
function lge_raise(_pts, _b, _steps, _face) {
    var _out = [lge_ring_fill(_pts, is_undefined(_face) ? "m2" : _face, undefined, undefined)];
    return lge_append(_out, lge_bevel(_pts, _b, _steps, false));
}

/// A SUNKEN shape: a recessed floor, walled by a dome lit from the opposite side.
function lge_sink(_pts, _b, _steps, _face) {
    var _out = [lge_ring_fill(_pts, is_undefined(_face) ? "m1" : _face, undefined, undefined)];
    return lge_append(_out, lge_bevel(_pts, _b, _steps, true));
}

/// ============================================================================================
/// STROKES - a line that is a groove, and a line that is a wire
/// ============================================================================================

/// An INCISED line: a groove cut into the metal.
///
/// Physically there are two walls. The one on the far side of the groove from the lamp faces the
/// lamp and is lit; the one on the near side is turned away and is dark. Offsetting one copy of
/// the stroke toward the lamp and darkening it, and one away and lightening it, is the whole trick
/// - and the order matters, because getting it backwards produces a line that reads as RAISED,
/// which is a real and useful effect and the wrong one here.
///
/// ⚠️ THE OFFSET IS A FRACTION OF THE STROKE WIDTH AND HAS A FLOOR IN THE RENDERER. lge_render
/// floors every stroke at 1 px, so at inventory size the three strokes of a groove collapse onto
/// each other and the groove becomes a plain line. That is correct behaviour and not a defect: a
/// groove 0.4 px wide is not visible on any monitor, and the alternative - scaling the offset up so
/// it survives - would draw a groove three pixels wide on a form twenty pixels across.
function lge_incise(_pts, _closed, _w) {
    var _o = _w * 0.55;
    return [
        lge_poly(lge_shift(_pts, LGE_LX * _o, LGE_LY * _o), _closed, _w, "m0"),
        lge_poly(lge_shift(_pts, -LGE_LX * _o, -LGE_LY * _o), _closed, _w, "m3"),
        lge_poly(_pts, _closed, _w * 0.8, "m1")
    ];
}

/// A RAISED line: a wire laid on the field. The same three strokes with the two walls swapped.
function lge_ridge(_pts, _closed, _w) {
    var _o = _w * 0.55;
    return [
        lge_poly(lge_shift(_pts, -LGE_LX * _o, -LGE_LY * _o), _closed, _w, "m0"),
        lge_poly(lge_shift(_pts, LGE_LX * _o, LGE_LY * _o), _closed, _w, "m4"),
        lge_poly(_pts, _closed, _w * 0.8, "m3")
    ];
}

/// Translate a polyline. Separate from lge_move_pts only so that reading a call site tells you
/// whether the thing being moved is an outline or a stroke path.
function lge_shift(_pts, _dx, _dy) {
    return lge_move_pts(_pts, _dx, _dy);
}

/// ============================================================================================
/// SMALL RAISED DETAIL
/// ============================================================================================

/// A raised dome - a screw head, a rivet, a jewel setting, a boss on a bridge, a click spring's
/// stud, one bead of a beaded bezel.
///
/// Sampled at 12 points at the size these are used, which is 3 to 10 px on screen; a smoother
/// circle is invisible and this product draws a lot of them (a beaded bezel carries up to 96 of
/// these and a full plate movement a few dozen screws and jewels).
function lge_boss(_cx, _cy, _r, _segs) {
    var _n = is_undefined(_segs) ? 12 : _segs;
    var _pts = lge_ellipse_pts(_cx, _cy, _r, _r, _n);
    return lge_raise(_pts, _r * 0.62, 2, "m3");
}

/// A sunken pit - a punch mark, a countersink.
function lge_pit(_cx, _cy, _r, _segs) {
    var _n = is_undefined(_segs) ? 12 : _segs;
    var _pts = lge_ellipse_pts(_cx, _cy, _r, _r, _n);
    return lge_sink(_pts, _r * 0.62, 2, "m1");
}

/// ============================================================================================
/// UI FURNITURE - the same relief engine, pointed at a rectangle
///
/// ⭐ THIS SECTION IS THE SEED THE WHOLE PRODUCT GREW FROM, AND IT IS KEPT VERBATIM BECAUSE IT
/// ARGUES THE CASE BETTER THAN ANY MARKETING COPY WOULD: a panel and a well, bevelled by the same
/// function against the same lamp as everything else, is the whole reason this catalogue's work
/// does not look like a recoloured sprite. There is no atlas here and no palette swap, only an
/// authored outline handed to lge_bevel.
///
/// lge_armature, lge_wear and lge_station build every component in this product on top of these two.
/// They are the floor of the product, not a convenience.
///
/// ⚠️ AND THAT LIST HAS NOW NAMED MODULES THAT DO NOT EXIST TWICE, ON TWO DIFFERENT PRODUCTS, FOR
/// THE SAME REASON - a port that renames identifiers and leaves prose alone. The donor recorded the
/// defect in this very header and the port re-introduced it verbatim two lines below the warning,
/// which is exactly how much a warning in prose is worth. A buyer reading a shipped header and going
/// to look for a function that is not there is a support ticket manufactured by documentation, and it
/// is worse than a wrong noun: it is a false statement about the package's own contents.
///
/// ⭐ SO IT IS MECHANISED NOW INSTEAD OF WARNED ABOUT: `Internal_Ops/claim_scan.js` resolves every
/// `lge_*` name mentioned in any shipped comment against what the package actually defines, and
/// fails on the first one that does not exist.
/// ============================================================================================

/// A rounded rectangle as a closed outline. _seg is the points per corner.
///
/// ⛔ THE CORNERS ARE WALKED TOP-RIGHT, BOTTOM-RIGHT, BOTTOM-LEFT, TOP-LEFT, AND THE FIRST VERSION
/// WALKED THEM TR, TL, BL, BR. MEASURED 2026-08-25 in this studio's shared layer by opening a store sheet and looking at
/// it: every panel, well and progress bar in the product had little hooks at its corners, a bright
/// bar across it, and no proper fill.
///
/// The order is not cosmetic. Each corner arc ENDS pointing at where the next one must BEGIN - the
/// top-right arc finishes on the right edge, so the next corner has to be the bottom-right. Walked
/// TR then TL, the outline jumps back across the top of the rectangle, the polygon self-intersects
/// into a bowtie, and two things go wrong at once: the fan fill covers the wrong region, and
/// lge_inset - which offsets along vertex normals - throws points a long way outside the shape,
/// which is why the ink check reported the sheet clipped at x=0 when nothing was drawn there.
///
/// ⚠️ AND NOTHING MECHANICAL CAUGHT IT. The gate compiled, 711 assertions passed, the containment
/// checks passed because they test the form corpus rather than the UI furniture, and the ink check
/// reported "clipped" - true, but pointing at a symptom two steps downstream. It was found by
/// opening the PNG, which remains the only way.
function lge_round_rect_pts(_x0, _y0, _x1, _y1, _r, _seg) {
    var _s = max(1, is_undefined(_seg) ? 4 : _seg);
    var _rr = min(_r, min(abs(_x1 - _x0), abs(_y1 - _y0)) * 0.5);
    var _out = [];
    var _cx = [_x1 - _rr, _x1 - _rr, _x0 + _rr, _x0 + _rr];
    var _cy = [_y0 + _rr, _y1 - _rr, _y1 - _rr, _y0 + _rr];
    var _a0 = [-LGE_TAU * 0.25, 0, LGE_TAU * 0.25, LGE_TAU * 0.5];
    for (var _c = 0; _c < 4; _c++) {
        for (var _i = 0; _i <= _s; _i++) {
            var _a = _a0[_c] + (_i / _s) * (LGE_TAU * 0.25);
            array_push(_out, [_cx[_c] + cos(_a) * _rr, _cy[_c] + sin(_a) * _rr]);
        }
    }
    return _out;
}

/// A raised panel: a rounded rectangle with a lit dome all round it.
function lge_ui_panel(_x0, _y0, _x1, _y1, _r, _b, _face) {
    return lge_raise(lge_round_rect_pts(_x0, _y0, _x1, _y1, _r, 4), _b, 3,
                     is_undefined(_face) ? "panel" : _face);
}

/// A sunken well - a recess a form sits in, or a progress track.
function lge_ui_well(_x0, _y0, _x1, _y1, _r, _b, _face) {
    return lge_sink(lge_round_rect_pts(_x0, _y0, _x1, _y1, _r, 4), _b, 2,
                    is_undefined(_face) ? "felt" : _face);
}

/// ============================================================================================
/// PART-LIST UTILITIES
/// ============================================================================================

/// Translate a whole part list. Used by the drop shadow a modal casts onto the scrim behind it,
/// by the shadow a wheel casts onto the plate behind it, and by the one-pixel offset that turns
/// an incised line into a line that has actually been cut into the metal.
function lge_offset_parts(_parts, _dx, _dy) {
    var _n = array_length(_parts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case LGE_DOT: _out[_i] = lge_dot(_p.cx + _dx, _p.cy + _dy, _p.r, _p.role); break;
            case LGE_ARC: _out[_i] = lge_arc(_p.cx + _dx, _p.cy + _dy, _p.r, _p.a0, _p.a1,
                                             _p.w, _p.role); break;
            case LGE_STRIP: {
                _out[_i] = lge_strip(lge_move_pts(_p.a, _dx, _dy),
                                     lge_move_pts(_p.b, _dx, _dy), _p.role);
            } break;
            case LGE_FILL: _out[_i] = lge_fill(lge_move_pts(_p.pts, _dx, _dy), _p.role); break;
            default: _out[_i] = lge_poly(lge_move_pts(_p.pts, _dx, _dy), _p.closed,
                                         _p.w, _p.role); break;
        }
    }
    return _out;
}

/// Rewrite every role in a part list through a lookup struct, permanently.
///
/// ⚠️ NOT THE SAME AS THE RENDERER'S role map, and both exist on purpose. The renderer's map is
/// applied at DRAW time and is right for "draw this mark in the locked palette just this once".
/// This one produces a new part list and is right for building a thing whose roles are decided at
/// construction - a prop built in a SECOND material's roles, so an anvil's iron face on its oak
/// stump, or a stall's canvas awning over its timber frame, is resolved ONCE when the station is
/// built and then never changes for as long as that station exists.
/// ⛔ IT ACCEPTS A SINGLE PART AS WELL AS A LIST, AND THAT IS A FIX, NOT A CONVENIENCE.
///
/// MEASURED 2026-08-28 on the donor's first headless run. Most of the constructors in this layer
/// return a LIST (lge_raise, lge_sink, lge_bevel, lge_incise, lge_ridge) but three return ONE PART
/// (lge_ring_fill, lge_dot, lge_ring), and the two are indistinguishable at a call site. Handed a
/// single part, `array_length` gave 0 and this function returned an EMPTY LIST - so the caller's
/// mark was silently DELETED FROM THE PICTURE with no error, no warning and nothing to grep for.
///
/// Two call sites had it, and on this subject the loss lands on exactly the wrong marks: the solid
/// mass of every prop - an anvil's body, a barrel's staves, a sack - is built by lge_ring_fill, so a
/// silent deletion takes the OBJECT and leaves its bands, hoops and outline hanging in the air over
/// nothing. It surfaced only because the empty
/// list was then pushed as if it were a part and lge_render_bounds tried to `switch` on an
/// array - a type error two steps downstream of
/// a defect that was otherwise perfectly silent, and the wing's own catalogue is full of exactly
/// this shape. Wrapping here removes the trap for every future call site instead of documenting it.
function lge_map_roles(_parts_in, _map) {
    var _parts = is_array(_parts_in) ? _parts_in : [_parts_in];
    var _n = array_length(_parts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        var _r = variable_struct_exists(_map, _p.role) ? variable_struct_get(_map, _p.role) : _p.role;
        switch (_p.kind) {
            case LGE_DOT: _out[_i] = lge_dot(_p.cx, _p.cy, _p.r, _r); break;
            case LGE_ARC: _out[_i] = lge_arc(_p.cx, _p.cy, _p.r, _p.a0, _p.a1, _p.w, _r); break;
            case LGE_STRIP: _out[_i] = lge_strip(_p.a, _p.b, _r); break;
            case LGE_FILL: _out[_i] = lge_fill(_p.pts, _r); break;
            default: _out[_i] = lge_poly(_p.pts, _p.closed, _p.w, _r); break;
        }
    }
    return _out;
}

/// Every distinct role a part list asks for, as an array of strings.
///
/// Exists for lge_selftest, which asserts that no part in the whole product ever asks for a role
/// the surface does not carry. The renderer falls back to `line` on a miss - loudly wrong rather
/// than invisible - and that fallback is a diagnostic, not a licence to leave one in.
function lge_roles_used(_parts) {
    var _seen = {};
    var _out = [];
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _r = _parts[_i].role;
        if (!variable_struct_exists(_seen, _r)) {
            variable_struct_set(_seen, _r, true);
            array_push(_out, _r);
        }
    }
    return _out;
}
