/// ============================================================================================
/// LIEGE — RENDER
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// The only file that talks to the GPU. Everything above it emits PARTS - plain structs describing
/// geometry and a role - and this turns a part list into pixels against a palette.
///
/// That split is what makes the package testable at all: a suite can assert what a station or a
/// pose PRODUCES without a surface, a window or a running game.
///
/// ⚠️ PORTED FROM `gm-raiment`. `LGE_MIN_STROKE` is 1.0 because `draw_line_width` floors there on
/// this hardware with no antialiasing - tone is SPACING and LENGTH here, never line width.
///
/// ============================================================================================

#macro LGE_MIN_STROKE 1.0

/// How many segments an arc is sampled at per full turn.
#macro LGE_ARC_SEGS 48

/// ============================================================================================
/// SURFACE LOOKUP
/// ============================================================================================

function lge_render_colour(_pal, _role) {
    if (variable_struct_exists(_pal, _role)) return variable_struct_get(_pal, _role);
    return _pal.line;
}

/// ============================================================================================
/// FITTING
/// ============================================================================================

/// Where to put the unit box so it fits (_x,_y,_w,_h) without distortion.
///
/// UNIFORM SCALE, ALWAYS. Mapping x by width and y by height independently would fill an oblong
/// slot exactly and turn every circle in the package into an ellipse - which on a product whose
/// forms are told apart by their outlines is not a cosmetic problem. A rim curve IS the
/// difference between a shallow bowl and a deep one, and a non-uniform scale changes every
/// curve in the corpus by the slot it happened to be drawn into. A form that does not fill
/// its slot is correct; a stretched one is a defect.
function lge_render_fit(_x, _y, _w, _h) {
    var _s = min(_w, _h);
    return { cx: _x + _w * 0.5, cy: _y + _h * 0.5, s: _s };
}

/// ============================================================================================
/// THE FIVE PRIMITIVES
/// ============================================================================================

function lge_render_poly(_pts, _closed, _w) {
    var _n = array_length(_pts);
    if (_n < 2) return;
    var _ww = max(LGE_MIN_STROKE, _w);
    for (var _i = 0; _i < _n - 1; _i++) {
        draw_line_width(_pts[_i][0], _pts[_i][1], _pts[_i + 1][0], _pts[_i + 1][1], _ww);
    }
    if (_closed) draw_line_width(_pts[_n - 1][0], _pts[_n - 1][1], _pts[0][0], _pts[0][1], _ww);
}

/// Fill a triangle fan. The caller is responsible for the outline being star-shaped about pts[0];
/// lge_ring_fill is the helper that guarantees it and closes the final wedge.
/// ⛔⛔ THE FAN IS CHUNKED, AND WITHOUT THAT A LARGE FILL LOSES A WEDGE OF ITSELF SILENTLY.
///
/// ⚠️ THE RECEIPT BELOW IS THE DONOR PRODUCT'S AND IS ATTRIBUTED RATHER THAN RESTATED. This
/// drawing layer is carried between products in this wing, and a comment claiming a measurement the
/// CURRENT product never made is the stale-receipt defect the wing constitution records: the next
/// session trusts it and goes hunting a defect that was never here.
///
/// MEASURED in the donor product: a fill of about 1,350 points came out with an eighth of its
/// interior missing - a hard straight edge, page showing through, and the outline stroke drawn
/// correctly right across the gap. A single draw_primitive batch does not carry that many vertices
/// and the tail is dropped, with no error. The geometry was correct, the suite was green, and the
/// ink and extent floors passed, because the missing wedge is INTERIOR and a bounding box cannot
/// see the space inside itself.
///
/// ⚠️ NO POINT COUNT IS CLAIMED FOR THIS PRODUCT. The header this was ported from named its own
/// largest fan and concluded the chunking was "insurance rather than a live fix" - a conclusion
/// that is only as good as the number under it, and that number was a DIFFERENT product's. A
/// working station stacks a prop mass, its bands and its tool, and a street stacks a dozen of them,
/// so whether anything here approaches the limit is an open question until lge_selftest measures it.
/// The chunking stays either way: the limit is a property of the driver, not of the subject.
///
/// A triangle fan splits exactly: every sub-fan shares the apex and repeats one boundary point, so
/// chunking changes nothing about the shape. 256 is well inside any batch and the extra
/// begin/end pairs cost nothing measurable next to the vertex count itself.
///
/// ⭐ The general form: A PRIMITIVE BATCH HAS A CEILING AND EXCEEDING IT IS NOT AN ERROR. Any
/// generator that scales a point count with a user-supplied number can reach it, and the failure
/// looks like a modelling bug in a completely different file.
#macro LGE_FAN_CHUNK 256

function lge_render_fill(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return;
    if (_n <= LGE_FAN_CHUNK) {
        draw_primitive_begin(pr_trianglefan);
        for (var _i = 0; _i < _n; _i++) draw_vertex(_pts[_i][0], _pts[_i][1]);
        draw_primitive_end();
        return;
    }
    // pts[0] is the apex; pts[1..n-1] is the boundary. Walk the boundary in runs, repeating the
    // last point of each run as the first of the next so no triangle is skipped at a seam.
    var _i = 1;
    while (_i < _n - 1) {
        var _end = min(_n - 1, _i + LGE_FAN_CHUNK - 2);
        draw_primitive_begin(pr_trianglefan);
        draw_vertex(_pts[0][0], _pts[0][1]);
        for (var _j = _i; _j <= _end; _j++) draw_vertex(_pts[_j][0], _pts[_j][1]);
        draw_primitive_end();
        _i = _end;
    }
}

/// Fill a triangle strip between two rails. A rail-length mismatch draws NOTHING rather than the
/// overlapping part: a strip whose rails disagree means the producer's two loops disagree, and
/// drawing the common prefix would render a plausible half-shape and hide the defect.
/// A triangle strip between two polylines. CHUNKED for the same reason as the fan above - see that
/// comment. A strip emits TWO vertices per step, so it reaches the ceiling in half as many points,
/// and this product's annular wheel rims are the longest strips in the catalogue.
function lge_render_strip(_a, _b) {
    var _n = array_length(_a);
    if (_n < 2 || array_length(_b) != _n) return;
    var _step = floor(LGE_FAN_CHUNK * 0.5);
    var _i = 0;
    while (_i < _n - 1) {
        var _end = min(_n - 1, _i + _step);
        draw_primitive_begin(pr_trianglestrip);
        for (var _j = _i; _j <= _end; _j++) {
            draw_vertex(_a[_j][0], _a[_j][1]);
            draw_vertex(_b[_j][0], _b[_j][1]);
        }
        draw_primitive_end();
        _i = _end;
    }
}

function lge_render_arc(_cx, _cy, _r, _a0, _a1, _w) {
    var _sweep = abs(_a1 - _a0);
    var _segs = max(3, ceil(LGE_ARC_SEGS * _sweep / LGE_TAU));
    var _ww = max(LGE_MIN_STROKE, _w);
    var _px = _cx + cos(_a0) * _r, _py = _cy + sin(_a0) * _r;
    for (var _i = 1; _i <= _segs; _i++) {
        var _a = _a0 + (_a1 - _a0) * (_i / _segs);
        var _qx = _cx + cos(_a) * _r, _qy = _cy + sin(_a) * _r;
        draw_line_width(_px, _py, _qx, _qy, _ww);
        _px = _qx; _py = _qy;
    }
}

/// ============================================================================================
/// THE DRAW LOOP
/// ============================================================================================

function lge_render_part(_p, _pal) {
    draw_set_colour(lge_render_colour(_pal, _p.role));
    switch (_p.kind) {
        case LGE_DOT:   draw_circle(_p.cx, _p.cy, max(0.5, _p.r), false);       break;
        case LGE_ARC:   lge_render_arc(_p.cx, _p.cy, _p.r, _p.a0, _p.a1, _p.w); break;
        case LGE_FILL:  lge_render_fill(_p.pts);                                break;
        case LGE_STRIP: lge_render_strip(_p.a, _p.b);                           break;
        default:        lge_render_poly(_p.pts, _p.closed, _p.w);               break;
    }
}

function lge_render_parts_raw(_parts, _pal) {
    var _n = array_length(_parts);
    for (var _i = 0; _i < _n; _i++) lge_render_part(_parts[_i], _pal);
}

/// Place a unit-box part list at (_cx,_cy) at scale _s and draw it.
///
/// _rot, _wscale and _map are optional. _wscale defaults to _s, which is the constant-PROPORTION
/// rule the primitive layer's header argues for: holding stroke weight constant in screen space
/// instead made a thumbnail-scale form's incisions 32% of its own width while a hero-scale one's were
/// 6%, so small forms rendered as solid blobs.
function lge_render_parts(_parts, _pal, _cx, _cy, _s, _rot, _wscale, _map) {
    var _r  = is_undefined(_rot)    ? 0  : _rot;
    var _ws = is_undefined(_wscale) ? _s : _wscale;
    lge_render_parts_raw(lge_place(_parts, _cx, _cy, _s, _r, _ws, _map), _pal);
}

function lge_render_in_rect(_parts, _pal, _x, _y, _w, _h, _rot, _map) {
    var _fit = lge_render_fit(_x, _y, _w, _h);
    lge_render_parts(_parts, _pal, _fit.cx, _fit.cy, _fit.s, _rot, _fit.s, _map);
}

/// ============================================================================================
/// MEASUREMENT - what the self-test asserts against
/// ============================================================================================

/// ⛔⛔ WOULD lge_render_part ACTUALLY PUT INK DOWN FOR THIS PART?
///
/// The three primitives above each RETURN EARLY on a degenerate input, silently and by design: a
/// fill of fewer than three points, a strip whose two rails disagree in length, a polyline of fewer
/// than two points. That is the right behaviour - drawing the plausible half of a broken shape hides
/// the defect - but it splits this file in two, because lge_render_bounds walks the SAME part and
/// measures its vertices whether or not anything was drawn.
///
/// ⭐ A BOUNDING BOX THAT INCLUDES GEOMETRY THE RENDERER REFUSES IS NOT A BOUNDING BOX OF THE
/// PICTURE, and every consumer of it - fitters, layout, the self-test's containment assertions -
/// believes it is. The failure mode is dead space: a sheet lays a figure out against a box that is
/// taller than the drawing, and the difference becomes empty page that no ink floor can see,
/// because a bounding box has no opinion about the space inside itself.
///
/// This predicate is deliberately CONSERVATIVE. It returns false only for the three cases the
/// primitives above measurably refuse; a dot always draws (the renderer floors its radius at 0.5)
/// and an arc always emits at least three segments, so both stay true.
///
/// @param {Struct} _p one part
/// @returns {Bool} whether lge_render_part would draw it
function lge_part_draws(_p) {
    switch (_p.kind) {
        case LGE_DOT:   return true;
        case LGE_ARC:   return true;
        case LGE_FILL:  return array_length(_p.pts) >= 3;
        case LGE_STRIP: return array_length(_p.a) >= 2 && array_length(_p.b) == array_length(_p.a);
        default:        return array_length(_p.pts) >= 2;
    }
}

/// How many parts in a list are measured by lge_render_bounds but drawn by nothing.
///
/// Zero is the only correct answer for any part list this package builds, and lge_selftest asserts
/// it: a silent no-draw is a producer whose two loops disagree, and it is invisible in the picture
/// by construction.
function lge_render_nodraw_count(_parts) {
    var _n = array_length(_parts);
    var _c = 0;
    for (var _i = 0; _i < _n; _i++) if (!lge_part_draws(_parts[_i])) _c++;
    return _c;
}

/// The bounding box of a part list in unit-box space, as [x0, y0, x1, y1].
///
/// It walks the ACTUAL VERTICES rather than a form's declared extents, and that is the point: a
/// declared extent is a claim and the vertices are evidence. Containment failures in this wing have
/// twice been a builder whose stated half width was right and whose geometry had drifted.
///
/// ⚠️ AND IT SKIPS PARTS THE RENDERER WOULD REFUSE - see lge_part_draws directly above.
function lge_render_bounds(_parts) {
    var _n = array_length(_parts);
    var _x0 = 999, _y0 = 999, _x1 = -999, _y1 = -999;
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        if (!lge_part_draws(_p)) continue;
        switch (_p.kind) {
            case LGE_DOT: {
                _x0 = min(_x0, _p.cx - _p.r); _x1 = max(_x1, _p.cx + _p.r);
                _y0 = min(_y0, _p.cy - _p.r); _y1 = max(_y1, _p.cy + _p.r);
            } break;
            case LGE_ARC: {
                _x0 = min(_x0, _p.cx - _p.r - _p.w); _x1 = max(_x1, _p.cx + _p.r + _p.w);
                _y0 = min(_y0, _p.cy - _p.r - _p.w); _y1 = max(_y1, _p.cy + _p.r + _p.w);
            } break;
            case LGE_STRIP: {
                for (var _k = 0; _k < array_length(_p.a); _k++) {
                    _x0 = min(_x0, _p.a[_k][0]); _x1 = max(_x1, _p.a[_k][0]);
                    _y0 = min(_y0, _p.a[_k][1]); _y1 = max(_y1, _p.a[_k][1]);
                }
                for (var _k = 0; _k < array_length(_p.b); _k++) {
                    _x0 = min(_x0, _p.b[_k][0]); _x1 = max(_x1, _p.b[_k][0]);
                    _y0 = min(_y0, _p.b[_k][1]); _y1 = max(_y1, _p.b[_k][1]);
                }
            } break;
            case LGE_FILL: {
                for (var _k = 0; _k < array_length(_p.pts); _k++) {
                    _x0 = min(_x0, _p.pts[_k][0]); _x1 = max(_x1, _p.pts[_k][0]);
                    _y0 = min(_y0, _p.pts[_k][1]); _y1 = max(_y1, _p.pts[_k][1]);
                }
            } break;
            default: {
                var _hw = _p.w * 0.5;
                for (var _k = 0; _k < array_length(_p.pts); _k++) {
                    _x0 = min(_x0, _p.pts[_k][0] - _hw); _x1 = max(_x1, _p.pts[_k][0] + _hw);
                    _y0 = min(_y0, _p.pts[_k][1] - _hw); _y1 = max(_y1, _p.pts[_k][1] + _hw);
                }
            } break;
        }
    }
    return [_x0, _y0, _x1, _y1];
}

/// One part's own bounding box, on exactly the rules lge_render_bounds uses.
function lge_part_bounds(_p) {
    return lge_render_bounds([_p]);
}

/// ⭐ WHICH PART SETS THE TOP OF THE BOX, AS A NAME A HUMAN CAN ACT ON.
///
/// ⛔ WRITTEN BECAUSE FOUR HYPOTHESES DIED GUESSING AT ONE. The pose sheet carried 34-40% dead air
/// above every figure's head, and three sessions proposed causes - the widest pose setting the
/// shared scale, the width-driven shrink branch, a part escaping the unit box - all of which were
/// falsified in the source, and a fourth (a part drawn at almost exactly the well tone, invisible to
/// the ink threshold) was falsified from the baked PNG: the band above every head is pure well fill
/// and carries no ink at any tone.
///
/// The role strings in this package are NAMESPACED by what owns them ("sk_" the figure's own body,
/// "st_" the station it works at, "tl_" the tool in its hand), so the role alone says which object
/// is responsible. Printing the answer costs nothing and ends the guessing.
///
/// @param {Array} _parts a part list
/// @returns {Struct} {y, index, kind, role} for the drawn part with the smallest y0
function lge_render_top_part(_parts) {
    var _n = array_length(_parts);
    var _best = { y: 999, index: -1, kind: -1, role: "none" };
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        if (!lge_part_draws(_p)) continue;
        var _b = lge_part_bounds(_p);
        if (_b[1] < _best.y) _best = { y: _b[1], index: _i, kind: _p.kind, role: _p.role };
    }
    return _best;
}

/// Fit a part list's ACTUAL CONTENT into a rectangle rather than fitting the unit box.
///
/// ⚠️ USE IT FOR A DETACHED MARK - one cursor on a swatch sheet, a single check tick in a
/// catalogue cell, a lone chevron. A ROW OF MARKS must go through lge_render_in_rect, because the
/// unit box is the frame the mark corpus is authored in and the BASELINE inside it is shared.
/// Tight fitting each one makes a full stop and a chevron the same height on screen and stands
/// them on different lines, which is exactly how a set of icons stops reading as a set.
///
/// ⛔ AND IT IS THE WRONG FUNCTION FOR A SHEET GRID, ALWAYS. A catalogue cell is laid out in
/// pixel space to the
/// rectangle it was given (see lge_geom's COORDINATES header); handing one to a fitter asks the
/// fitter to rescale geometry that was already correct, and the first thing that breaks is the
/// corner radius.
function lge_render_fit_parts(_parts, _x, _y, _w, _h) {
    var _bb = lge_render_bounds(_parts);
    var _bw = max(0.0001, _bb[2] - _bb[0]);
    var _bh = max(0.0001, _bb[3] - _bb[1]);
    var _s = min(_w / _bw, _h / _bh);
    var _mx = (_bb[0] + _bb[2]) * 0.5;
    var _my = (_bb[1] + _bb[3]) * 0.5;
    return { cx: _x + _w * 0.5 - _mx * _s, cy: _y + _h * 0.5 - _my * _s, s: _s };
}

function lge_render_in_rect_tight(_parts, _pal, _x, _y, _w, _h, _map) {
    var _f = lge_render_fit_parts(_parts, _x, _y, _w, _h);
    lge_render_parts(_parts, _pal, _f.cx, _f.cy, _f.s, 0, _f.s, _map);
}

/// ============================================================================================
/// MADE LETTERING
///
/// ⛔ TEXT IS THE ONE THING IN THIS PACKAGE THAT IS NOT GEOMETRY, and it still has to look made.
/// The trick is the same two-pass emboss the relief engine uses on a groove: draw the string once
/// offset AWAY from the lamp in the material's deepest stop, then again in place in its brightest.
/// Two draw calls, and the label reads as metal rather than as a caption laid over a picture of
/// metal.
///
/// ⚠️ EVERY STRING IN THIS FILE IS MEASURED AND SCALED TO ITS SPACE. Wings/GameMaker/CLAUDE.md
/// records this wing shipping the SAME overflow defect twice - "WickthorSt Cuthman's" on one
/// product and "HEDGEHOG FUNGUSCAULIFLOWER FUNGUS" on the next - because the first fix shortened
/// the DATA instead of making the caption honest about its width. Form names come from the
/// BUYER's game and cannot be shortened by us at all, so nothing here is allowed to assume a
/// length. No ink check will ever catch an overflow: overprinted text is ink exactly where ink
/// belongs.
/// ============================================================================================

/// The emboss offset for lettering, in pixels, at a given nominal size.
function lge_text_relief(_px) {
    return max(1, round(_px * 0.085));
}

/// One line of made text, centred at (_x,_y), scaled DOWN if it will not fit _maxw.
///
/// Returns the scale actually used, so a caller that cares can notice it was shrunk.
/// ⛔ _x AND _y ARE THE CENTRE OF THE STRING, NOT ITS TOP LEFT, AND THREE CALL SITES IN THIS
/// PACKAGE GOT THAT WRONG AT ONCE. halign is CENTRE and valign is MIDDLE below - which is right for
/// a title, and is the opposite convention to lge_text_line and lge_text_body two functions away.
/// Passing a left edge to it centres the string ON that edge, so half of it leaves the frame: a
/// product cover lost its first letter, a wordmark hung off its header panel, and a plate heading
/// floated over the top of a recessed well. All three looked like layout arithmetic
/// and all three were this. If you are passing a left edge, you want lge_text_line.
/// ⛔⛔ ALIGNMENT CORRECTED 2026-09-03 - IT WAS CENTRED, AND EVERY CALLER PASSES A LEFT MARGIN.
///
/// This drew with `fa_center` / `fa_middle`, so `_x` was the text's CENTRE and `_y` its MIDDLE. All
/// three call sites pass a left margin and a top: `lge_bk_head(..., 54, ...)`, the hero's
/// `("LIEGE - THE NPC DAY", 54, 22, ...)` and the cover's `("LIEGE", 26, 12, ...)`. So every title
/// in the store gallery was drawn half off the left edge and cut off at the top.
///
/// MEASURED on the first baked gallery: the cover title read **"IEGE"**, the hero read
/// "THE NPC DAY" with its top sliced off, and the day sheet read "T, FOUR HOURS" where the source
/// string is "ONE STREET, FOUR HOURS". The bake's own `clipped` flag was TRUE on all nine sheets and
/// had been dismissed as a full-bleed artefact - it was a true positive, and the picture said so.
///
/// ⭐ The rule this pays for: A FUNCTION THAT TAKES AN ORIGIN MUST SAY WHICH CORNER IT IS. `_x, _y,
/// _maxw` reads as a box everywhere else in this file, and one `draw_set_halign` turned it into a
/// centre without changing the signature. Left/top now matches how it is called and how it reads.
function lge_text_fit(_text, _x, _y, _maxw, _px, _col_shadow, _col_face) {
    draw_set_font(fnt_liege_title);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    var _o = lge_text_relief(_px);
    draw_set_colour(_col_shadow);
    draw_text_transformed(_x - LGE_LX * _o, _y - LGE_LY * _o, _text, _sc, _sc, 0);
    draw_set_colour(_col_face);
    draw_text_transformed(_x, _y, _text, _sc, _sc, 0);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    return _sc;
}

/// A label made around an arc, one glyph at a time.
///
/// _a_mid is the angle the middle of the string sits at (-LGE_TAU/4 is the top of the form) and
/// _sweep is how much of the circle the whole string may occupy. The string is laid out by ADVANCE
/// so that letter spacing is even in ARC LENGTH - spacing the glyphs evenly in ANGLE instead
/// bunches the narrow letters and was the first thing this looked wrong doing.
///
/// ⚠️ THE ROTATION IS DERIVED, NOT GUESSED. GML's draw_text_transformed takes DEGREES and rotates
/// counter-clockwise on a y-DOWN screen, so a glyph's own x-axis lands at (cos t, -sin t). The
/// tangent to the circle at angle a is (-sin a, cos a). Solving the two gives
/// t = atan2(-cos a, -sin a), which is checkable in one place: at the top of the form a is
/// -TAU/4, the tangent is (1,0), and t comes out 0.
function lge_text_arc(_text, _cx, _cy, _r, _a_mid, _sweep, _px, _col_shadow, _col_face) {
    var _n = string_length(_text);
    if (_n <= 0 || _r <= 0) return 0;
    draw_set_font(fnt_liege_title);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _total = 0;
    for (var _i = 1; _i <= _n; _i++) _total += string_width(string_char_at(_text, _i)) * _sc;
    var _arc = _r * _sweep;
    if (_total > _arc && _total > 0) {
        _sc *= _arc / _total;
        _total = _arc;
    }

    var _o = lge_text_relief(_px);
    var _run = 0;
    for (var _i = 1; _i <= _n; _i++) {
        var _ch = string_char_at(_text, _i);
        var _cw = string_width(_ch) * _sc;
        // Centre of this glyph along the run, converted to an angle about the form's centre.
        var _a = _a_mid + ((_run + _cw * 0.5) - _total * 0.5) / _r;
        var _t = radtodeg(arctan2(-cos(_a), -sin(_a)));
        var _px2 = _cx + cos(_a) * _r, _py2 = _cy + sin(_a) * _r;
        draw_set_colour(_col_shadow);
        draw_text_transformed(_px2 - LGE_LX * _o, _py2 - LGE_LY * _o, _ch, _sc, _sc, _t);
        draw_set_colour(_col_face);
        draw_text_transformed(_px2, _py2, _ch, _sc, _sc, _t);
        _run += _cw;
    }
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    return _sc;
}

/// A wrapped block of body copy, in the plain face, left aligned. No emboss: paragraph text made
/// in relief is unreadable, and the panels this appears on are paper, not metal.
function lge_text_body(_text, _x, _y, _w, _px, _col) {
    draw_set_font(fnt_liege);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_colour(_col);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    draw_text_ext_transformed(_x, _y, _text, _base * 1.34, _w / _sc, _sc, _sc, 0);
    return string_height_ext(_text, _base * 1.34, _w / _sc) * _sc;
}

/// One line of plain text, left aligned, scaled to fit.
/// A LEFT-ANCHORED label drawn as a light face over a dark shadow.
///
/// ⛔ THIS EXISTS BECAUSE lge_text_fit IS CENTRE-ANCHORED AND lge_text_line IS LEFT-ANCHORED, AND
/// SWAPPING ONE FOR THE OTHER SILENTLY MOVES EVERY CAPTION BY HALF ITS OWN WIDTH.
/// MEASURED 2026-08-28 on a sibling product in this series (the receipt is kept verbatim rather
/// than reworded, because a defect this quiet is only believable with its evidence attached): a fix
/// for caption CONTRAST swapped lge_text_line for lge_text_fit, which solved the contrast and
/// clipped every left-edge caption on the store sheets off the page - the hero sheet read
/// "atch, cob, one storey". The two functions differ in two ways at once and only one of them is
/// in their names, so the trap is in the API, not in the caller.
///
/// The shadow is offset along the same lamp vector as every bevel in the package, so a label reads
/// as struck into the page rather than as text with a drop shadow bolted on.
function lge_text_label(_text, _x, _y, _maxw, _px, _col_shadow, _col_face) {
    draw_set_font(fnt_liege_title);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    var _o = lge_text_relief(_px);
    draw_set_colour(_col_shadow);
    draw_text_transformed(_x - LGE_LX * _o, _y - LGE_LY * _o, _text, _sc, _sc, 0);
    draw_set_colour(_col_face);
    draw_text_transformed(_x, _y, _text, _sc, _sc, 0);
    return _sc;
}

function lge_text_line(_text, _x, _y, _maxw, _px, _col, _bold) {
    draw_set_font(_bold ? fnt_liege_title : fnt_liege);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_colour(_col);
    var _base = max(1, string_height("M"));
    var _sc = _px / _base;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    draw_text_transformed(_x, _y, _text, _sc, _sc, 0);
    return _sc;
}

/// ============================================================================================
/// SCREEN EFFECTS - the only alpha-blended draws in the package, and they live here
///
/// ⚠️ THE PART PATH DELIBERATELY HAS NO ALPHA. A role resolves to a colour, and that is the whole
/// contract - it is what lets the relief engine reason about five discrete values and what stops a
/// buyer's own blend mode changing what a form looks like. The readout flash and the shock ring
/// genuinely need blending, so they are written here as two named functions that set alpha and put
/// it back, rather than as loose draw calls in the toast where the next edit would forget the
/// second half.
/// ============================================================================================

/// A soft radial flash, drawn as a few nested discs of falling alpha.
///
/// Nested discs rather than a gradient sprite, because this package ships no sprite of any kind
/// and a genuine radial gradient in GML needs a texture or a shader. Six rings is enough that the
/// banding is invisible at the sizes this is used, and it is checked by looking.
/// ⛔ LARGEST DISC FIRST, SMALLEST LAST, AND THE FIRST VERSION HAD IT BACKWARDS. MEASURED BY LOOKING
/// at the strike sheet: drawn smallest-first, every dim outer disc is painted straight over the
/// bright core, so the whole thing flattens into a uniform grey donut - the exact opposite of a
/// flash. Painter's order is not a detail when the layers are translucent; it IS the gradient.
/// ⚠️ TWELVE DISCS, AND SIX LEFT VISIBLE BANDING. On a near-black page each step in the stack shows
/// as a concentric ring, and six of them read as a target rather than as a glow. Doubling the count
/// and halving the per-disc alpha costs nothing measurable and the banding goes. It is still a step
/// function - a true radial gradient needs a texture or a shader, and this package ships neither -
/// but at twelve steps the step is under two per cent of the range and invisible at any size the
/// flash is drawn at.
function lge_render_flash(_cx, _cy, _r, _col, _alpha) {
    if (_alpha <= 0 || _r <= 0) return;
    var _old = draw_get_alpha();
    draw_set_colour(_col);
    for (var _i = 11; _i >= 0; _i--) {
        var _t = _i / 11;
        draw_set_alpha(_alpha * (1 - _t) * 0.155);
        draw_circle(_cx, _cy, _r * (0.22 + _t * 0.78), false);
    }
    draw_set_alpha(_old);
}

/// An expanding shock ring.
function lge_render_ring(_cx, _cy, _r, _w, _col, _alpha) {
    if (_alpha <= 0 || _r <= 0) return;
    var _old = draw_get_alpha();
    draw_set_alpha(_alpha);
    draw_set_colour(_col);
    lge_render_arc(_cx, _cy, _r, 0, LGE_TAU, _w);
    draw_set_alpha(_old);
}

/// A SMOOTH VERTICAL GRADIENT between two colours.
///
/// ⛔ THIS IS THE ONE DRAW CALL IN THE PACKAGE THAT IS NOT A PART, and it lives here rather than
/// in the module that wants it (lge_bake, for a sheet ground) so that the claim at the top of this
/// file stays literally true: this is still the only file that talks to the GPU.
///
/// draw_rectangle_colour takes FOUR corner colours and interpolates across the quad in
/// hardware. Passing the same colour to both top corners and both bottom corners gives a pure
/// vertical ramp with no banding at any resolution - which a stack of flat bands cannot do
/// without hundreds of them.
///
/// ⚠️ THE ALPHA IS SET AND RESTORED. A gradient drawn at whatever alpha the caller happened to
/// leave behind is the kind of defect that only appears when a fade runs at the same time.
function lge_render_vgrad(_x, _y, _w, _h, _top, _bot) {
    if (_h <= 0 || _w <= 0) return;
    var _old = draw_get_alpha();
    draw_set_alpha(1.0);
    draw_rectangle_colour(_x, _y, _x + _w, _y + _h, _top, _top, _bot, _bot, false);
    draw_set_alpha(_old);
}

/// A whole ramp of stops as a stack of gradient bands.
///
/// _stops is an array of colours, top of the frame first. Each adjacent pair becomes one
/// hardware-interpolated band, so five stops cost four draw calls for a whole backdrop.
///
/// ⚠️ THE BANDS ARE NOT EVENLY SPACED, AND THAT IS THE WHOLE POINT OF _weights. The backdrop
/// behind a table spends most of its height on the upper stops and compresses the pale band
/// where the cloth meets it into the last tenth of the frame; spacing them evenly puts that pale
/// colour a third of the way up the picture and the backdrop reads as a beach towel. The same
/// weighting draws a tall backdrop that lightens toward its top without banding.
function lge_render_ramp(_x, _y, _w, _h, _stops, _weights) {
    var _n = array_length(_stops);
    if (_n < 2) return;
    var _total = 0;
    for (var _i = 0; _i < _n - 1; _i++) _total += _weights[_i];
    if (_total <= 0) return;
    var _yy = _y;
    for (var _i = 0; _i < _n - 1; _i++) {
        var _bh = _h * (_weights[_i] / _total);
        lge_render_vgrad(_x, _yy, _w, _bh + 1, _stops[_i], _stops[_i + 1]);
        _yy += _bh;
    }
}

/// A flat filled rectangle at an alpha - the scrim behind a modal panel, and the night wash over
/// the dimming wash over an interface that has lost focus.
/// ⛔⛔ IT WRITES COLOUR ONLY. DRAWING A SCRIM ONTO A SURFACE ALSO BLENDS ITS ALPHA CHANNEL, AND
/// THAT SHIPPED A SEMI-TRANSPARENT STORE COVER.
///
/// MEASURED 2026-08-31 by decoding the baked PNG (Internal_Ops/png_alpha_probe.js): the cover's
/// top-left pixel was RGB 7,8,11 - the dark page, exactly right - at ALPHA 206, with only 49,339
/// of its 315,000 pixels fully opaque. The picture was never grey. It was 81% opaque, and every
/// viewer composited it over its own light background, so it LOOKED like a flat grey card.
///
/// ⚠️ TWO WRONG DIAGNOSES CAME FIRST AND BOTH WERE REASONED, NOT MEASURED: the scrim's alpha was
/// blamed and raised, then the background machine's frame was blamed for painting the canvas and
/// swapped. Neither changed anything, because the RGB was correct the whole time. A picture that
/// looks wrong in a viewer is not evidence about the bytes in the file - that is CLAUDE.md §2b's
/// "look at the rendered output" rule meeting its own limit, and the answer was to decode the file.
///
/// The default blend mode computes dst.a = src.a + dst.a * (1 - src.a), so an alpha-0.74 rectangle
/// over an opaque surface leaves it at 0.74 no matter what colour it was. Turning off the alpha
/// write leaves the surface's own alpha alone, which is what a scrim means.
function lge_render_scrim(_x, _y, _w, _h, _col, _alpha) {
    if (_alpha <= 0) return;
    var _old = draw_get_alpha();
    gpu_set_colorwriteenable(true, true, true, false);
    draw_set_alpha(_alpha);
    draw_set_colour(_col);
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);
    draw_set_alpha(_old);
    gpu_set_colorwriteenable(true, true, true, true);
}

/// Force a surface fully opaque.
///
/// ⚠️ BELT AND BRACES, AND WORTH BOTH. lge_render_scrim above no longer punches holes in the alpha
/// channel, but it was not the only thing that could: any draw at an alpha below one does the same,
/// and this package's own text shadows and flashes do exactly that. A store image with an alpha
/// channel is a store image that looks different on every page it is shown on, so the bake calls
/// this before every save rather than trusting that nothing new will ever draw translucently.
function lge_render_opaque(_w, _h) {
    gpu_set_colorwriteenable(false, false, false, true);
    var _old = draw_get_alpha();
    draw_set_alpha(1);
    draw_set_colour(c_white);
    draw_rectangle(0, 0, _w, _h, false);
    draw_set_alpha(_old);
    gpu_set_colorwriteenable(true, true, true, true);
}

/// ============================================================================================
/// CACHING - the path a buyer's game should actually use
/// ============================================================================================

/// Render a part list once into a sprite and hand it back.
///
/// A figure at a station is several hundred primitives - a body, its limbs, the prop it works at and
/// the tool in its hand, each a part in the list. ⚠️ AND THIS PRODUCT'S WHOLE PREMISE IS A TOWN, i.e.
/// the crowded case, redrawn every frame: thirty people at thirty stations is tens of thousands of
/// draw calls and it WILL show up in a buyer's profiler. Shipping the cache is not an optimisation
/// note here, it is part of the product working at the scale it is sold for.
///
/// ⛔⛔ AND TWO EARLIER PRODUCTS' JUSTIFICATIONS FOR THIS CACHE ARE BOTH FALSE HERE, WHICH IS WORTH
/// SAYING OUT LOUD BECAUSE EACH ONE WAS INHERITED SILENTLY BY THE NEXT PORT.
///
/// The first donor's argument ran: a wheel's shape is constant and only its ANGLE moves, and a
/// turned wheel's finish is RADIAL, so its highlight is a function of radius and survives rotation.
/// True of wheel-work. The second donor corrected it for a subject shaded as a TUBE lit from one
/// fixed side, where a baked body turned ninety degrees ends up lit from below.
///
/// ⇒ A FIGURE IS LIT FROM ONE FIXED SIDE TOO, SO THE ROTATION HALF CARRIES OVER - BUT ROTATION IS
/// NOT THE OPERATION A BUYER WILL ACTUALLY APPLY TO A CHARACTER. MIRRORING IS. A character sprite
/// drawn facing the other way is the single commonest thing a game does with one, and
/// `draw_sprite_ext` with a negative xscale flips the LIGHTING with the figure: the lit shoulder
/// becomes the shadowed one and every fold on the body reverses. The figure will look subtly wrong
/// in a way that is hard to name and impossible to fix downstream.
///
/// ⇒ USE THE CACHE FOR FIGURES DRAWN AT A FIXED ORIENTATION AND A FIXED FACING - a portrait, a
/// paper-doll panel, an inventory preview, a dialogue bust - which is where the counts are large
/// anyway. For a character that FACES BOTH WAYS, bake TWO sprites by generating the figure mirrored
/// and re-rendering it, rather than flipping one at draw time.
///
/// ⛔ THE SENTENCE THAT USED TO END THIS PARAGRAPH WAS FALSE AND IS CORRECTED HERE RATHER THAN
/// CARRIED FORWARD AGAIN. It read "that is the whole reason lge_place takes a signed side term
/// instead of leaving the flip to the caller" - and `lge_place` has no signed side term. Its
/// parameters are (parts, cx, cy, s, rot, wscale, map); nothing in it can mirror anything. The claim
/// was inherited from a donor two ports back and describes a function that does not exist in that
/// shape, which is this wing's standing defect class: a port renames identifiers and leaves prose
/// alone, and a buyer reading a shipped header goes looking for a parameter that is not there.
///
/// ⭐ THE REAL MECHANISM IS `lge_mirror_parts` PLUS A MIRRORED LAMP, and `lge_figure_parts` below is
/// the one caller that uses it. Mirroring geometry alone flips the lighting with the figure - exactly
/// the defect three paragraphs above describes for `draw_sprite_ext` - so the parts are BUILT under
/// `lge_lamp_set(-LGE_LX, LGE_LY)` and then mirrored, and the two flips cancel.
///
/// ⚠️ THE CALLER OWNS THE SPRITE AND MUST sprite_delete IT. A generator that hands out sprites with
/// no stated ownership is a leak with a nice API on top; the demo object's Clean Up event deletes
/// every sprite it made, and the Readme says this in the same words.
///
/// ⚠️ AND IT MUST NOT BE CALLED FROM A DRAW EVENT. surface_set_target inside a draw event nests
/// render targets, and on some drivers that silently produces an empty sprite rather than an error
/// - the exact shape of failure this wing keeps recording. Build in Create, draw in Draw.
/// ⛔⛔ ON THE DONOR THIS FUNCTION HAD NEVER ONCE BEEN CALLED, AND IT CRASHED ON ITS FIRST CALL. It
/// cleared the surface with `draw_clear_alpha(_pal.ground, 0)` - and a figure's palette is
/// NAMESPACED by what owns each role (`sk_` the body, one prefix per worn item), so it has no bare
/// `ground` key at all. A buyer following the Readme's own advice for crowds got
///     Variable <unknown_object>.ground(100817, -2147483648) not set before reading it
/// on the first frame. MEASURED 2026-09-02 by a fresh-install harness that imports the shipped
/// .yymps into a blank project and calls the documented API; nothing else in the package calls this
/// function, so the gate, the 1,660-assertion suite and the demo room all passed straight over it.
/// A dead reader is not a missing feature, it is an UNTESTED CODE PATH.
///
/// ⭐ And the read was pointless as well as wrong: the second argument to draw_clear_alpha is the
/// ALPHA, it is 0 here, and a fully transparent clear does not care what colour it is. The palette
/// is still needed - lge_render_in_rect below uses it - but not for this.
function lge_render_to_sprite(_parts, _pal, _w, _h, _pad) {
    var _pd = is_undefined(_pad) ? 0 : _pad;
    var _surf = surface_create(_w, _h);
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 0);
    lge_render_in_rect(_parts, _pal, _pd, _pd, _w - _pd * 2, _h - _pd * 2, 0, undefined);
    surface_reset_target();
    var _spr = sprite_create_from_surface(_surf, 0, 0, _w, _h, false, false, _w * 0.5, _h * 0.5);
    surface_free(_surf);
    return _spr;
}

/// ============================================================================================
/// THE COMPOSITION — the one function that assembles a townsperson at work
/// ============================================================================================
///
/// ⛔⛔ THE DRAW ORDER IS THE PRODUCT, AND SEVERAL OF THE TEN STEPS BELOW ARE DEFECTS SOMEBODY IN
/// THIS CATALOGUE HAS ALREADY SHIPPED.
///
///    1  station BACK      the far side of a rim, a counter, a vat's mouth
///    2  tool, depth back  a scythe blade sweeping past the far side of the body
///    3  hair BACK         behind the skull
///    4  body              legs, torso, arms, neck, head
///    5  hair FRONT        over the skull
///    6  face              brows, eyes, mouth
///    7  worn set          smock, sleeves, apron, belt, cap
///    8  hands             ⚠️ AFTER the worn set: a wrist-length sleeve drawn over a hand is a
///                         mitten, and the armature's own header records that the donor's mitt was
///                         invisible on exactly the figures most likely to be on a store sheet
///    9  tool, depth front the hammer in the near hand
///   10  station FRONT     the NEAR side of every rim the figure stands inside
///
/// ⭐ STEPS 1 AND 10 ARE WHY `lge_station_parts` RETURNS TWO LISTS. A well's rim, a vat, a trough, a
/// churn, a counter, a cart's side and a hive all half-enclose the worker; drawn as one ring after
/// the figure, each would paint a band across the worker's own body, and this wing has that exact
/// defect on a shipped listing (a gilt rim across the food on every rimmed plate).
///
/// ============================================================================================

/// @desc A work loop's tool (and off-hand tool) placed in the figure's hands, split by depth.
///
/// ⛔⛔ THE TOOL IS PLACED FROM THE WRIST AND ROTATED ONTO THE FOREARM, WHICH IS THE WHOLE CONTRACT
/// AND THE ONE THING A WORLD-SPACE PROP CANNOT DO. `lge_labour_pose` is a continuous function of
/// phase, so the wrist moves every frame; a tool authored beside the station would be correct at
/// exactly one phase of the cycle and would separate from the hand at every other one. A hammer that
/// leaves the hand at the top of its own swing is worse than no hammer.
///
/// ⛔⛔ THE ROTATION WAS A QUARTER TURN THE WRONG WAY, ON EVERY TOOL, SINCE THIS FILE WAS WRITTEN -
/// AND IT IS THE SCARECROW. Four sessions were spent tuning arm angles, shoulder shares, pose
/// heights and stoops because the workers read as people standing beside their work holding a stick
/// at nothing. They were: the stick was pointing BACKWARDS ALONG THE ARM.
///
/// THE ARITHMETIC, worked rather than asserted. A tool is authored along -y from its grip, so its
/// tip sits at (0, -L). `lge_map_pt` applies the standard matrix, so after a rotation of `t` the tip
/// is at (L*sin t, -L*cos t). For that to point along the forearm direction `d` - i.e. along
/// (cos d, sin d) - we need sin t = cos d and cos t = -sin d, so t = atan2(cos d, -sin d) = d + pi/2.
/// The line below read `d - pi/2`, which is exactly pi away: it points the tool at the ELBOW.
///
/// ⭐ THE CONTROL IS ONE CASE AND IT TAKES A SECOND. A forearm hanging straight down is d = +pi/2
/// (y grows downward). The old expression gives t = 0, which leaves the tool in its authored
/// orientation - tip at (0, -L), i.e. STRAIGHT UP out of the hand. A spade held blade-upward.
///
/// ⭐ AND THE TOOL TABLE ITSELF WAS THE STANDING EVIDENCE, unread for as long as the bug existed:
/// every CARRIED object - sack 2.60, seedbasket 2.80, bucket 2.90, crate 2.40 - declared an `axis`
/// within half a radian of pi. Four independent hand-tunings all landing on "add half a turn" is not
/// four coincidences, it is four people correcting the same broken base one tool at a time. Those
/// offsets are now zero, because with the base right a hafted tool along the forearm IS the default.
///
/// MEASURED, in the picture, before the arithmetic was done: `gardener_hoe` cropped to 4x shows the
/// hoe's haft running from her hand UP ACROSS HER CHEST TO HER CHIN, and `cook_ladle` shows the
/// ladle pointing up and away from the cauldron - which the previous session recorded as a puzzle
/// about phase, having found the ladle "drawn, correctly".
///
/// @param {Struct} _arm   from lge_armature
/// @param {Struct} _w     a work spec from lge_work_spec
/// @param {Real} _phase   0..1, unused directly - the wrist already carries it
/// @returns {Struct} {back, front}, both in UNIT space beside the figure
function lge_tool_at(_arm, _w, _phase) {
    var _back = [];
    var _front = [];
    var _pairs = [[_w.tool, _w.side], [_w.offhand, 1 - _w.side]];
    for (var _i = 0; _i < 2; _i++) {
        var _id = _pairs[_i][0];
        if (_id == "") continue;
        var _side = _pairs[_i][1];
        var _sp = lge_tool_spec(_id);
        if (is_undefined(_sp)) continue;
        var _parts = lge_tool_parts(_id, lge_hash32(_id) + _side);
        if (is_undefined(_parts)) continue;

        var _wr = _arm.wrist[_side];
        var _elb = _arm.elbow[_side];
        var _dir = arctan2(_wr[1] - _elb[1], _wr[0] - _elb[0]);
        // ⚠️ THE TOOL IS SCALED TO THE BUILD, NOT LEFT AT UNIT SIZE. Tool space and figure space are
        // both stature units, so the naive scale is 1 - but `_arm.span` is the figure's ACTUAL
        // stature after the build multiplier, and a hammer that stays the same size on a `short` and
        // a `tall` build is a hammer that changes hands between two people in the same street.
        // Dividing by the canonical span makes the tool follow the build exactly as the clothes do.
        var _s = _arm.span / (LGE_SOLE - LGE_CROWN);
        // ⛔ `+ pi/2`, NOT `- pi/2`. See the long block in this function's header for the worked
        // derivation and the control. THE SAME EXPRESSION APPEARS IN `lge_tool_boxes` BELOW AND THE
        // TWO MUST MOVE TOGETHER - one measuring a rotation the other does not draw is precisely the
        // defect class this product has now hit four times.
        var _rot = _dir + pi * 0.5 + _sp.axis;
        var _placed = lge_place(_parts, _wr[0], _wr[1], _s, _rot, _s, undefined);
        if (_sp.depth == "back") lge_append(_back, _placed);
        else lge_append(_front, _placed);
    }
    return { back: _back, front: _front };
}

/// @desc Each held tool's OWN drawn bounding box, as an array of [x0, y0, x1, y1].
///
/// ⛔⛔ THIS EXISTS BECAUSE A BOX OVER BOTH HANDS IS NOT A MEASUREMENT OF EITHER TOOL, AND THE REACH
/// GATE WAS BUILT ON ONE. `lge_tool_at` merges the main tool and the offhand into two depth lists,
/// so `lge_render_bounds(back + front)` returns a single axis-aligned box spanning FROM ONE HAND TO
/// THE OTHER. On a figure whose arms are out, that box covers the whole space between the hands -
/// and the station sits in the middle of it.
///
/// MEASURED 2026-09-04: `smith_strike` PASSES "every worker's hands reach the work their station
/// declares", and its store cell shows the smith standing beside the anvil with the hammer down by
/// her knee. The anvil's work point was inside the hammer-to-tongs box the whole time. A green gate
/// and a wrong picture, both honest, because the gate was measuring the gap between two tools.
///
/// ⭐ Same family as the signed/unsigned defect in the same assertion, and the same lesson: when a
/// check aggregates several objects into one shape, it stops being a check about any of them.
/// Measure each tool separately and take the nearest.
///
/// @param {Struct} _arm from lge_armature
/// @param {Struct} _w work spec
/// @param {Real} _phase
/// @returns {Array} one [x0,y0,x1,y1] per tool actually drawn - empty for a bare-handed loop
function lge_tool_boxes(_arm, _w, _phase) {
    var _out = [];
    var _pairs = [[_w.tool, _w.side], [_w.offhand, 1 - _w.side]];
    for (var _i = 0; _i < 2; _i++) {
        var _id = _pairs[_i][0];
        if (_id == "") continue;
        var _sp = lge_tool_spec(_id);
        if (is_undefined(_sp)) continue;
        var _parts = lge_tool_parts(_id, lge_hash32(_id) + _pairs[_i][1]);
        if (is_undefined(_parts)) continue;
        var _side = _pairs[_i][1];
        var _wr = _arm.wrist[_side];
        var _elb = _arm.elbow[_side];
        var _dir = arctan2(_wr[1] - _elb[1], _wr[0] - _elb[0]);
        var _s = _arm.span / (LGE_SOLE - LGE_CROWN);
        // ⛔ MUST MATCH `lge_tool_at` EXACTLY - this is the box the reach gate grades, and if it is
        // built from a different rotation than the one drawn, the gate is measuring a tool that is
        // not on screen.
        var _placed = lge_place(_parts, _wr[0], _wr[1], _s, _dir + pi * 0.5 + _sp.axis, _s, undefined);
        if (array_length(_placed) > 0) array_push(_out, lge_render_bounds(_placed));
    }
    return _out;
}

/// @desc Distance from a point to the NEAREST held tool's box; 0 when a tool covers it, -1 when the
/// loop holds nothing. Signed components are the caller's job - see the reach assertion.
///
/// @param {Struct} _arm from lge_armature
/// @param {Struct} _w work spec
/// @param {Real} _phase
/// @param {Real} _px
/// @param {Real} _py
/// @returns {Real} distance, or -1 if no tool is held
function lge_tool_gap(_arm, _w, _phase, _px, _py) {
    var _bx = lge_tool_boxes(_arm, _w, _phase);
    var _n = array_length(_bx);
    if (_n == 0) return -1;
    var _best = 999;
    for (var _i = 0; _i < _n; _i++) {
        var _b = _bx[_i];
        var _dx = max(_b[0] - _px, 0, _px - _b[2]);
        var _dy = max(_b[1] - _py, 0, _py - _b[3]);
        _best = min(_best, sqrt(_dx * _dx + _dy * _dy));
    }
    return _best;
}

/// @desc Everything one townsperson is, at one instant, in unit space.
///
/// Returns {back, main}: `back` is the part of the figure that belongs BEHIND them (a back-depth
/// tool), `main` is everything else. The station's own two lists stay the caller's, because a station
/// is shared furniture and is worth caching while a figure is not.
///
/// ⚠️ MIRRORED FIGURES ARE BUILT UNDER A MIRRORED LAMP. See lge_render_to_sprite's header: mirroring
/// the geometry alone reverses the shading, so a street with people facing both ways has two suns in
/// it. The lamp is set, the parts are built, the lamp is RESET, and only then is the geometry
/// mirrored - and the reset is on EVERY exit path, because `lge_lamp_set` is global state and a lamp
/// left flipped would silently mis-shade every prop built after this call. That is the shape of
/// defect this wing keeps recording: a guard whose failure branch encodes a decision nobody made.
///
/// @param {Struct} _person from lge_person
/// @param {String} _work   a work loop id, or LGE_AWAY
/// @param {Real} _phase    0..1
/// @param {Bool} _moving   true while walking to work
/// @param {Real} _face     +1 or -1
/// @returns {Struct} {back, main}
function lge_figure_parts(_person, _work, _phase, _moving, _face) {
    var _w = lge_work_spec(_work);
    if (is_undefined(_w) || !_w.visible) return { back: [], main: [] };

    var _flip = (_face < 0);
    if (_flip) lge_lamp_set(-LGE_LX, LGE_LY);

    // ⛔ A WORKER GETS `lge_work_pose`, WHICH APPLIES THE STATION'S SEAT; A WALKER GETS THE WALK CYCLE
    // AND NO SEAT. Somebody crossing the street is not at the station, and seating them by it would
    // have every passer-by crouch as they went past a loom. The join between a pose and the thing it
    // is sat on lives in `lge_work_pose` rather than here so that the SUITE can ask the product what
    // pose it draws instead of rebuilding the join and then verifying against its own copy.
    var _pose = _moving ? lge_walk_pose(_phase) : lge_work_pose(_work, _phase);
    // ⛔ NO PLAUSIBLE FALLBACK POSE, AND THE LAMP IS RESET BEFORE THIS EARLY RETURN. An unknown
    // labour is a corpus defect the suite asserts against; drawing the figure standing politely would
    // hide it, and returning without resetting the lamp would move the defect into the next prop.
    if (is_undefined(_pose)) { if (_flip) lge_lamp_reset(); return { back: [], main: [] }; }

    var _arm = lge_armature(_person.build, _pose);
    var _skin = "sk" + string(_person.skin) + "_";
    var _hcol = "hr" + string(_person.haircol) + "_";
    var _skin_map = { m0: _skin + "0", m1: _skin + "1", m2: _skin + "2",
                      m3: _skin + "3", m4: _skin + "4", ink: _skin + "ink" };
    // ⛔⛔ THE HAIR IS BUILT IN GENERIC ROLES AND MAPPED AFTERWARDS, LIKE EVERYTHING ELSE - AND THE
    // FIRST VERSION PASSED PALETTE ROLE NAMES STRAIGHT IN, WHICH LEFT 84 PARTS ASKING FOR A ROLE THE
    // PALETTE DOES NOT CARRY.
    //
    // MEASURED 2026-09-03 by the suite's role-miss gate. `lge_hair_parts` takes {face, shade, line}
    // for its own three strokes, but it builds its mass through the shared relief engine - and
    // `lge_form_dome` emits GENERIC `m0`..`m4` from the surface normal no matter what face role it
    // was handed. Those five roles were never in the hair struct, so every one of them missed and
    // fell through to `_pal.line`, which is deliberately magenta. Every townsperson in the product
    // would have had a magenta-shaded head.
    //
    // ⭐ The lesson generalises past hair: ANY builder in this package that goes through the relief
    // engine emits generic roles as well as the ones it was given, so a caller that maps only the
    // named ones has mapped half a figure. Build generic, map at the end, once - which is the rule
    // `lge_station_parts`, `lge_tool_parts` and `lge_wear_parts` all end on.
    var _hair_map = { m0: _hcol + "0", m1: _hcol + "1", m2: _hcol + "2",
                      m3: _hcol + "3", m4: _hcol + "4", ink: _hcol + "0" };
    var _hair_roles = { face: "m2", shade: "m1", line: "m0" };

    var _back = [];
    var _main = [];

    var _tp = lge_tool_at(_arm, _w, _phase);
    lge_append(_back, _tp.back);

    lge_append(_main, lge_map_roles(lge_hair_back_parts(_arm, _person.hairstyle, _hair_roles), _hair_map));
    lge_append(_main, lge_map_roles(lge_body_parts(_arm, "m2"), _skin_map));
    lge_append(_main, lge_map_roles(lge_hair_parts(_arm, _person.hairstyle, _hair_roles), _hair_map));
    lge_append(_main, lge_face_parts(_arm, _skin + "ink"));
    // ⚠️ THE PERSON'S OWN DYE IF THEY CARRY ONE, read defensively: this package's catalogue plates
    // and any buyer's cast build their own person structs, and a person with no dye wears the
    // trade's. See `lge_wear_parts`' header for why a household needs to differ at all.
    lge_append(_main, lge_wear_parts(_arm, _work,
        variable_struct_exists(_person, "dye") ? _person.dye : undefined));
    lge_append(_main, lge_map_roles(lge_hand_parts(_arm, "m2"), _skin_map));
    lge_append(_main, _tp.front);

    // ⛔⛔ THE FIGURE IS PUT ON THE FLOOR BY ITS OWN SOLE, NOT BY A SHARED CONSTANT, AND THAT IS A
    // DEFECT THE SUITE FOUND ON 35 OF 46 FIGURES.
    //
    // `lge_armature` CENTRES the figure in the unit box: `_span = 0.94 * stature` and the sole lands
    // at `_span * 0.5`. So a `tall` build (stature 1.055) has its sole at 0.4959 and a `short` one
    // (0.930) at 0.4371, while `lge_render_work` maps the GROUND to LGE_SOLE = 0.470. Drawn at a
    // 168px stature that is a tall townsperson with their feet 4px INTO the road standing beside a
    // short one floating 5px above it - on a street whose whole subject is people standing at props.
    //
    // ⭐ One offset fixes every build at once and it is derived, not tuned: shift the whole figure so
    // its own `y_sole` lands exactly on LGE_SOLE. The armature's own header records the related
    // measurement (the margin to the unit box is 0.030 and `tall` spends all but 0.004 of it), which
    // is why the sole cannot simply be moved in the armature instead - a figure has to fit its box.
    var _drop = LGE_SOLE - _arm.y_sole;
    if (abs(_drop) > 0.00001) {
        _back = lge_offset_parts(_back, 0, _drop);
        _main = lge_offset_parts(_main, 0, _drop);
    }

    if (_flip) {
        lge_lamp_reset();
        return { back: lge_mirror_parts(_back), main: lge_mirror_parts(_main) };
    }
    return { back: _back, main: _main };
}

/// @desc Draw one townsperson at their station, in the ten-step order this section opens with.
///
/// @param {Struct} _pal   from lge_pal
/// @param {Struct} _st    {back, front} from lge_station_parts, or undefined for no prop
/// @param {Struct} _fig   {back, main} from lge_figure_parts
/// @param {Real} _sx      where the STATION stands, screen x
/// @param {Real} _sy      the GROUND line, screen y - both the station and the figure sit on it
/// @param {Real} _fx      where the FIGURE stands, screen x
/// @param {Real} _s       one stature, in screen pixels
function lge_render_work(_pal, _st, _fig, _sx, _sy, _fx, _s) {
    // ⚠️ ONE GROUND LINE FOR BOTH, AND IT IS A PARAMETER RATHER THAN TWO. Both the station and the
    // figure are authored against `LGE_SOLE`, and `lge_geom`'s header records that the two previous
    // products in this line each carried a SEPARATE fixed ground constant - both deleted here,
    // because a station standing on a different floor from the person working at it is exactly the
    // defect a second constant produces. Passing one `_sy` makes that impossible rather than unlikely.
    //
    // ⛔ AND `_sy` IS THE GROUND, NOT THE UNIT BOX'S CENTRE. `lge_render_parts` centres the unit box
    // on the y it is given, and the sole line sits at LGE_SOLE (0.470) BELOW that centre - so passing
    // the ground straight through would bury every figure and every prop in this product to just
    // above the knee. The conversion belongs here, once, rather than at each of the four calls.
    var _cy = _sy - LGE_SOLE * _s;
    if (!is_undefined(_st)) lge_render_parts(_st.back, _pal, _sx, _cy, _s, 0, _s, undefined);
    lge_render_parts(_fig.back, _pal, _fx, _cy, _s, 0, _s, undefined);
    lge_render_parts(_fig.main, _pal, _fx, _cy, _s, 0, _s, undefined);
    if (!is_undefined(_st)) lge_render_parts(_st.front, _pal, _sx, _cy, _s, 0, _s, undefined);
}
