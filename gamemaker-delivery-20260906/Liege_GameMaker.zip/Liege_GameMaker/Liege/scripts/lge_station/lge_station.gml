/// ============================================================================================
/// LIEGE — THE STATIONS
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// ⭐ THE OTHER HALF OF THE PRODUCT. `lge_labour` is what a townsperson DOES; this is what they do
/// it AT. Forty-six props, every one generated from the shared mass vocabulary below and shaded by
/// the same lamp as the figure standing at it - no sprite, no atlas, no PNG anywhere in the package.
///
/// ⚠️ THE PROP IS WHY THE WORK READS. A figure swinging its arms in empty air is a person having a
/// fit; the same figure with an anvil under the swing is a smith. That is not a nicety about polish,
/// it is the whole reason the pose corpus is worth authoring, and it is why these two files are
/// sized against each other rather than one being a garnish on the other.
///
/// ============================================================================================
/// ⛔⛔ THE DEPTH SPLIT. THE SINGLE HIGHEST-RISK DECISION IN THIS FILE, AND IT IS ALREADY A
/// MEASURED, SHIPPED DEFECT IN THIS WING.
/// ============================================================================================
///
/// A station is not ONE part list, it is TWO: `back` and `front`, with the figure drawn between
/// them. Every recipe returns both, even when `front` is empty.
///
/// The reason, from `Wings/GameMaker/CLAUDE.md`, on a sibling product that reached a built listing:
/// a rimmed plate emitted ONE closed ellipse for its rim and appended it LAST, under a comment
/// saying "so it sits over anything that overhangs the plate edge". That intent is right about the
/// NEAR edge of the rim and FALSE about the FAR one - the back arc of a rim is BEHIND anything
/// standing on the plate. One ring drawn last cannot be both, so a gilt band ran across the food on
/// every rimmed plate the product could produce.
///
/// ⛔ THIS PRODUCT HAS THAT SHAPE ON A DOZEN STATIONS AT ONCE, and worse, because the thing standing
/// inside the ring is a PERSON. A well's rim, a vat's mouth, a trough, a mash tun, a churn, a
/// counter, a cart's side and a hive all enclose or half-enclose the figure working at them. Drawn
/// as one ring after the figure, each would paint a band across the worker's own body.
///
/// ⚠️ NOTHING MECHANICAL IN THIS WING CAN SEE IT, and that is structural rather than a tuning
/// problem: the ink box passes (a rim is ink exactly where a rim belongs), the extent check passes
/// (nothing is clipped), the density floor passes, and the geometry is correct. It is found by
/// baking the sheet, cropping the region and LOOKING.
///
/// ⭐ SO THE SUITE TESTS THE ORDERING CONTRACT INSTEAD, since the picture is unreachable from a
/// test: a station that declares a `front` list must emit geometry in BOTH lists, and every point in
/// `front` must lie BELOW the station's own working height (a front half is the NEAR side, and the
/// near side of anything seen from slightly above is the lower half). A recipe that puts its whole
/// rim in one list fails by name.
///
/// ============================================================================================
/// GROUND, AND WHY THERE IS NO GROUND CONSTANT
/// ============================================================================================
///
/// Stations are authored in the SAME unit space as the figure, with the floor at `LGE_SOLE` - the
/// armature's own sole line. `lge_geom`'s header records that the two previous products in this line
/// each carried a separate fixed ground constant and that both were deleted here: a figure already
/// owns its floor, it moves with the build's stature, and a second constant claiming to be the
/// ground could only ever disagree with it. A station standing on a different floor from the person
/// working at it is the defect that constant would produce.
///
/// ============================================================================================

/// The materials a station can be built in. A material is a NAME, and `lge_palette` resolves it to
/// five ramp stops plus an ink - so a theme re-colours every prop in the town from one struct and
/// nothing here knows a colour.
function lge_materials_all() {
    return ["tim", "irn", "stn", "cnv", "cer", "thr", "wat", "fir", "grn", "lea"];
}

/// @desc The role map that builds a part list in a named material.
///
/// Relief emits generic `m0`..`m4` (see lge_relief_role), and this rewrites them to a material's own
/// roles. Building generic and mapping afterwards is what lets ONE anvil recipe be iron here and
/// bronze in a different theme without a second recipe.
function lge_mat(_id) {
    return {
        m0 : _id + "0", m1 : _id + "1", m2 : _id + "2", m3 : _id + "3", m4 : _id + "4",
        ink: _id + "ink"
    };
}

/// ============================================================================================
/// THE MASS VOCABULARY
/// ============================================================================================
///
/// Eleven constructors. Forty-six props are built from them, which is what makes the corpus a
/// GENERATOR rather than forty-six hand-drawn things - and what makes a fix to the shading reach
/// every prop at once.
///
/// ⚠️ EVERY ONE RETURNS PARTS IN GENERIC RAMP ROLES. The caller maps them into a material. A
/// constructor that resolved its own colour would need a parameter for it and would be re-authored
/// per material, which is the shape of an atlas with extra steps.

/// @desc A rectangular mass with a domed face. The workhorse: benches, blocks, stones, chests.
///
/// ⚠️ `_k` IS A FRACTION OF THE SHORTER SIDE AND IS CAPPED INSIDE lge_bevel, so a long thin plank
/// cannot be handed a dome deeper than its own thickness. See lge_inset_limit for why that cap lives
/// in the constructor and not here.
function lge_st_slab(_x0, _y0, _x1, _y1, _k, _steps) {
    var _pts = [[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]];
    return lge_mass(_pts, _k, _steps, "m2");
}

/// @desc A mass tapering between two widths - a post, a stump, a tub wall, a chimney.
///
/// Sampled down the sides rather than built as a trapezium so the sides can BOW: `_bulge` pushes the
/// waist outward, which is the difference between a barrel and a bucket. A straight-sided vessel
/// with hoops on it reads as a bin.
function lge_st_taper(_cx, _ytop, _ybot, _wtop, _wbot, _bulge, _k) {
    var _n = 9;
    var _l = array_create(_n + 1);
    var _r = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        var _y = lerp(_ytop, _ybot, _t);
        // A raised sine so the bulge is zero at both ends and maximal at the waist - a bulge added
        // as a constant makes the ends flare, which is a spool, not a barrel.
        var _w = lerp(_wtop, _wbot, _t) + _bulge * sin(_t * pi);
        _l[_i] = [_cx - _w, _y];
        _r[_i] = [_cx + _w, _y];
    }
    var _pts = [];
    for (var _i = 0; _i <= _n; _i++) array_push(_pts, _l[_i]);
    for (var _i = _n; _i >= 0; _i--) array_push(_pts, _r[_i]);
    return lge_mass(_pts, _k, 3, "m2");
}

/// @desc An ellipse mass - anything round seen at an angle. Wheels, mouths, plates, millstones.
///
/// ⛔ AN ELLIPSE, NEVER A CIRCLE, AND THE HEADER OF lge_ellipse_arc_pts EXPLAINS WHY AT LENGTH: a
/// circular well mouth is as deep on screen as it is wide, so it stands up out of the ground like a
/// ring rolled on edge and every station the figure works AT tips forward with it.
function lge_st_disc(_cx, _cy, _rx, _ry, _k) {
    return lge_mass(lge_ellipse_pts(_cx, _cy, _rx, _ry, 26), _k, 3, "m2");
}

/// @desc A beam of a given thickness between two points. Rails, shafts, handles, trestle legs.
function lge_st_beam(_x0, _y0, _x1, _y1, _t) {
    var _dx = _x1 - _x0, _dy = _y1 - _y0;
    var _len = point_distance(0, 0, _dx, _dy);
    if (_len < LGE_EPS) return [];
    var _nx = -_dy / _len * _t, _ny = _dx / _len * _t;
    var _pts = [[_x0 + _nx, _y0 + _ny], [_x1 + _nx, _y1 + _ny],
                [_x1 - _nx, _y1 - _ny], [_x0 - _nx, _y0 - _ny]];
    return lge_mass(_pts, 0.42, 2, "m2");
}

/// @desc Cut a straight segment down to the part of it that lies between two x bounds.
///
/// ⛔⛔ WHY THIS EXISTS. A mesh drawn as a loop of OFFSET diagonals is not contained by the frame it
/// is meant to fill, and nothing noticed for as long as `netframe` existed. Its frame spans
/// -0.26..+0.26; its diagonals were laid at offsets of -0.44..+0.44 over a segment whose own x-run is
/// 0.30, so the drawn mesh spanned -0.68..+0.68 - 2.6 times its own frame. MEASURED 2026-09-04 off
/// the store sheet: the net ran clear out of its cell and over both neighbours.
///
/// ⭐ AND THE DAMAGE WAS NOT ONLY THE SPILL. `lge_bk_cell` fits the union of the parts into the cell,
/// so an over-wide prop does not overflow - it SHRINKS THE PERSON. The fisher was drawn noticeably
/// smaller than the 45 people beside her and the cause was a loop bound two files away.
///
/// The honest primitive is a clip, not a smaller loop bound: a net is woven INSIDE its frame, so each
/// strand is cut at the frame's edge. Returns `undefined` when the segment lies wholly outside, so a
/// caller cannot silently draw a degenerate zero-length poly.
function lge_st_clip_x(_x0, _y0, _x1, _y1, _lo, _hi) {
    var _dx = _x1 - _x0;
    if (abs(_dx) < LGE_EPS) {
        // Vertical: it is either in or out, and there is nothing to interpolate.
        if (_x0 < _lo || _x0 > _hi) return undefined;
        return [[_x0, _y0], [_x1, _y1]];
    }
    var _ta = (_lo - _x0) / _dx;
    var _tb = (_hi - _x0) / _dx;
    var _t0 = min(_ta, _tb);
    var _t1 = max(_ta, _tb);
    _t0 = max(_t0, 0);
    _t1 = min(_t1, 1);
    if (_t1 - _t0 < LGE_EPS) return undefined;
    return [[_x0 + _dx * _t0, _y0 + (_y1 - _y0) * _t0],
            [_x0 + _dx * _t1, _y0 + (_y1 - _y0) * _t1]];
}

/// @desc An open rectangular frame - looms, net frames, drying racks, hive fronts.
function lge_st_frame(_x0, _y0, _x1, _y1, _t) {
    var _out = [];
    lge_append(_out, lge_st_beam(_x0, _y0, _x1, _y0, _t));
    lge_append(_out, lge_st_beam(_x0, _y1, _x1, _y1, _t));
    lge_append(_out, lge_st_beam(_x0, _y0, _x0, _y1, _t));
    lge_append(_out, lge_st_beam(_x1, _y0, _x1, _y1, _t));
    return _out;
}

/// @desc Splayed legs under a work surface. A trestle, a bench, a stool, a cart's axle stand.
///
/// ⚠️ SPLAYED, NOT VERTICAL. Vertical legs under a plank read as a table icon; real trestles splay,
/// and the splay is most of what makes a bench look built rather than drawn.
function lge_st_trestle(_cx, _ytop, _ybot, _half, _splay, _t) {
    var _out = [];
    lge_append(_out, lge_st_beam(_cx - _half, _ytop, _cx - _half - _splay, _ybot, _t));
    lge_append(_out, lge_st_beam(_cx + _half, _ytop, _cx + _half + _splay, _ybot, _t));
    // A stretcher between them. Without it the two legs read as two separate posts.
    lge_append(_out, lge_st_beam(_cx - _half - _splay * 0.55, lerp(_ytop, _ybot, 0.66),
                                 _cx + _half + _splay * 0.55, lerp(_ytop, _ybot, 0.66), _t * 0.62));
    return _out;
}

/// @desc A heap of lumps - grain, coal, produce, cut wood, wool.
///
/// ⚠️ THE LUMPS ARE SEEDED, NOT RANDOM. Nothing in this package calls `random()`: a heap that
/// re-rolls every frame is the one defect a buyer notices immediately and cannot work around.
function lge_st_pile(_cx, _ybase, _w, _h, _n, _seed) {
    var _r = lge_rng(_seed);
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _t = (_i + 0.5) / _n;
        // Lumps sit on a shallow arch, wider at the base and lower at the edges, so the heap has a
        // silhouette rather than being a row of circles.
        var _x = _cx + (_t - 0.5) * 2 * _w * 0.86;
        var _prof = 1 - (2 * _t - 1) * (2 * _t - 1);
        var _ry = _h * (0.30 + 0.70 * _prof) * lge_rng_range(_r, 0.82, 1.14);
        var _rx = _ry * lge_rng_range(_r, 1.05, 1.45);
        lge_append(_out, lge_mass(lge_ellipse_pts(_x, _ybase - _ry * 0.72, _rx, _ry, 12), 0.55, 2, "m2"));
    }
    return _out;
}

/// @desc Fire. Tongues rising from a base, seeded.
///
/// ⚠️ DRAWN AS TAPERED MASSES, NOT AS A GLOW. A translucent blob reads as a smudge at gallery size
/// and a bloom drawn over the work obscures the thing it exists to light. A flame's SHAPE is what
/// says fire, and this wing has already recorded that painter's order IS the gradient when layers
/// are translucent.
function lge_st_flame(_cx, _ybase, _w, _h, _seed) {
    var _r = lge_rng(_seed);
    var _out = [];
    for (var _i = 0; _i < 5; _i++) {
        var _t = (_i + 0.5) / 5;
        var _x = _cx + (_t - 0.5) * 2 * _w;
        var _hh = _h * (0.42 + 0.58 * (1 - abs(_t - 0.5) * 2)) * lge_rng_range(_r, 0.80, 1.18);
        var _lean = lge_rng_range(_r, -0.30, 0.30) * _hh;
        var _bw = _w * 0.34 * lge_rng_range(_r, 0.7, 1.2);
        // A tongue is a curve, not a triangle: the tip trails and the waist pinches.
        var _pts = [[_x - _bw, _ybase],
                    [_x - _bw * 0.42, _ybase - _hh * 0.48],
                    [_x + _lean, _ybase - _hh],
                    [_x + _bw * 0.52, _ybase - _hh * 0.42],
                    [_x + _bw, _ybase]];
        array_push(_out, lge_ring_fill(_pts, (_i mod 2 == 0) ? "m4" : "m3", _x, _ybase - _hh * 0.34));
    }
    return _out;
}

/// @desc Hanging cloth with a sag - awnings, sheets on a line, a hive veil, a sack's slump.
function lge_st_sheet(_x0, _x1, _ytop, _sag, _drop) {
    var _n = 11;
    var _top = array_create(_n + 1);
    var _bot = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        var _x = lerp(_x0, _x1, _t);
        var _s = sin(_t * pi);
        _top[_i] = [_x, _ytop + _sag * _s];
        // The hem sags MORE than the top edge, which is what gives cloth its weight. Equal sag on
        // both edges is a ribbon.
        _bot[_i] = [_x, _ytop + _drop + _sag * _s * 1.55];
    }
    var _pts = [];
    for (var _i = 0; _i <= _n; _i++) array_push(_pts, _top[_i]);
    for (var _i = _n; _i >= 0; _i--) array_push(_pts, _bot[_i]);
    var _out = [lge_ring_fill(_pts, "m2", undefined, undefined)];
    lge_append(_out, lge_tube_bands(_top, _bot, 5));
    return _out;
}

/// @desc Bands around a vessel - barrel hoops, a churn's withies, a tub's iron.
function lge_st_hoops(_cx, _ytop, _ybot, _wtop, _wbot, _bulge, _n, _t) {
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _f = (_i + 1) / (_n + 1);
        var _y = lerp(_ytop, _ybot, _f);
        var _w = lerp(_wtop, _wbot, _f) + _bulge * sin(_f * pi);
        array_push(_out, lge_poly([[_cx - _w, _y], [_cx + _w, _y]], false, _t, "m0"));
    }
    return _out;
}

/// @desc ⛔ A RIM SPLIT BY DEPTH. Returns {back, front} - the far arc and the near arc of one
/// ellipse, so the caller can put the figure between them.
///
/// This is the function the file header is about. y grows DOWNWARD, so `sin > 0` is the LOWER half
/// of the ellipse on screen, which is the NEAR side of anything seen from slightly above - and
/// therefore the half that belongs in FRONT of whatever stands in the vessel.
function lge_st_rim(_cx, _cy, _rx, _ry, _t) {
    return {
        back  : [lge_poly(lge_ellipse_arc_pts(_cx, _cy, _rx, _ry, pi, LGE_TAU, 14), false, _t, "m1")],
        front : [lge_poly(lge_ellipse_arc_pts(_cx, _cy, _rx, _ry, 0, pi, 14), false, _t, "m3")]
    };
}

/// ============================================================================================
/// THE STATION CORPUS
/// ============================================================================================

/// @desc Every station id, in the same order as the work loops that use them.
function lge_stations_all() {
    return [
        "anvil", "forge", "trough", "hoofstand", "tinkerbench",
        "sawhorse", "joinerbench", "barrelcradle", "polelathe", "chopblock",
        "loom", "spinwheel", "dyevat", "ropewalk", "cuttingtable",
        "oven", "kneadtrough", "butcherblock", "mashtun", "churn",
        "cookfire", "millhopper",
        "standingcorn", "threshfloor", "furrow", "shearstool", "gardenbed",
        "hive",
        "bankerstone", "potterwheel", "trench", "charclamp",
        "netframe", "washstone", "well", "cart", "stall",
        "writingdesk", "herbbench", "diprack",
        "brazier", "postboard", "hoopring", "villagebench", "shrine", "pengate",
    ];
}

/// @desc A station's placement facts: where the worker stands, where their hands go, how much
/// ground it occupies, and what it is made of.
///
/// ⚠️ `work` IS IN THE STATION'S OWN SPACE AND IS THE CONTRACT BETWEEN THIS FILE AND lge_labour.
/// A pose's `height` says how far below the shoulder the hands work; this says where that is in the
/// world. They have to agree or the smith hammers the air beside the anvil, and the suite asserts
/// the agreement rather than trusting two tables to stay in step.
///
/// ⛔⛔ `seat` IS THE SECOND HALF OF THAT CONTRACT AND IT DID NOT EXIST UNTIL 2026-09-03, WHICH IS WHY
/// EIGHT TOWNSPEOPLE WORKED THEIR WHOLE DAY SITTING ON NOTHING. `lge_labour_spec` has always been
/// able to say a job is done `stance: "seated"` - eight of the 46 do - and no station in this file
/// carried anywhere to sit. Seven of those eight stations had no seat drawn in them AT ALL (the
/// village bench was the exception), so even once the figure was solved into a sitting shape it was
/// a sitting shape in mid air. The height of the seat is a fact about the FURNITURE, so it lives
/// here with the furniture, and `lge_figure_parts` hands it to the pose - which is what stops the
/// weaver's bench and the weaver's hips being two numbers that can drift apart.
///
/// `seat` is the height of the seat SURFACE above the floor, in the same unit space every recipe
/// below is authored in. Absent or 0 means nobody sits here. `seatdrawn: true` means the recipe
/// already builds its own seat and the generic one must not be added on top of it.
///
/// @param {String} _id
/// @returns {Struct|Undefined} undefined for an unknown id - never a plausible stand-in
function lge_station_spec(_id) {
    switch (_id) {
        // ---- metal and fire ---------------------------------------------------------------
        case "anvil":        return { mat: "irn", work: [ 0.00,  0.13], stand: -0.30, foot: [-0.20, 0.20], h: 0.34 };
        case "forge":        return { mat: "stn", work: [ 0.02, 0.15], stand: -0.38, foot: [-0.30, 0.30], h: 0.52 };
        // ⭐ `work[0]` IS WHERE ALONG THE STATION THE JOB HAPPENS, AND UNTIL 2026-09-04 EVERY STATION
        // DECLARED ITS CENTRE. A trough is 0.5 wide and its centre is a quarter of a stature further
        // from the worker's shoulder than its near end - which on `kneadtrough` was enough to make
        // the job GEOMETRICALLY IMPOSSIBLE (measured need 0.343 against an arm of 0.299). Nothing
        // read this field either, so the centre was never a decision, only a default.
        case "trough":       return { mat: "stn", work: [-0.06,  0.25], stand: -0.32, foot: [-0.26, 0.26], h: 0.24 };
        case "hoofstand":    return { mat: "tim", work: [ 0.00,  0.29], stand: -0.24, foot: [-0.14, 0.14], h: 0.18 };
        case "tinkerbench":  return { mat: "tim", work: [ 0.00,  0.13], stand: -0.30, foot: [-0.28, 0.28], h: 0.30, seat: 0.22 };
        // ---- wood -------------------------------------------------------------------------
        case "sawhorse":     return { mat: "tim", work: [ 0.00,  0.20], stand: -0.30, foot: [-0.26, 0.26], h: 0.28 };
        case "joinerbench":  return { mat: "tim", work: [ 0.00,  0.05], stand: -0.32, foot: [-0.34, 0.34], h: 0.30 };
        case "barrelcradle": return { mat: "tim", work: [ 0.00, 0.04], stand: -0.30, foot: [-0.22, 0.22], h: 0.44 };
        case "polelathe":    return { mat: "tim", work: [ 0.00,  0.08], stand: -0.30, foot: [-0.32, 0.32], h: 0.46 };
        case "chopblock":    return { mat: "tim", work: [ 0.00,  0.24], stand: -0.28, foot: [-0.16, 0.16], h: 0.20 };
        // ---- cloth and fibre --------------------------------------------------------------
        case "loom":         return { mat: "tim", work: [ 0.17, -0.06], stand: -0.02, foot: [-0.30, 0.30], h: 0.62, seat: 0.22 };
        case "spinwheel":    return { mat: "tim", work: [ 0.10,  0.13], stand: -0.22, foot: [-0.24, 0.24], h: 0.40, seat: 0.21 };
        case "dyevat":       return { mat: "stn", work: [ 0.00,  0.02], stand: -0.32, foot: [-0.22, 0.22], h: 0.40 };
        // work[0] -0.10: measured GEOMETRICALLY IMPOSSIBLE at the centre (need 0.456 against 0.418 of
        // arm and tool). A rope walk is 0.64 wide and is twisted from the end you are standing at.
        case "ropewalk":     return { mat: "tim", work: [-0.10,  0.21], stand: -0.30, foot: [-0.34, 0.34], h: 0.30 };
        case "cuttingtable": return { mat: "tim", work: [ 0.14,  0.05], stand: -0.02, foot: [-0.32, 0.32], h: 0.26, seat: 0.20 };
        // ---- food -------------------------------------------------------------------------
        case "oven":         return { mat: "stn", work: [ 0.00, -0.08], stand: -0.42, foot: [-0.32, 0.32], h: 0.58 };
        case "kneadtrough":  return { mat: "tim", work: [-0.25,  0.06], stand: -0.30, foot: [-0.28, 0.28], h: 0.28 };
        case "butcherblock": return { mat: "tim", work: [ 0.00,  0.13], stand: -0.28, foot: [-0.20, 0.20], h: 0.32 };
        case "mashtun":      return { mat: "tim", work: [ 0.00, -0.04], stand: -0.34, foot: [-0.24, 0.24], h: 0.46 };
        case "churn":        return { mat: "tim", work: [ 0.00, 0.03], stand: -0.24, foot: [-0.14, 0.14], h: 0.42 };
        case "cookfire":     return { mat: "stn", work: [ 0.00,  0.075], stand: -0.30, foot: [-0.24, 0.24], h: 0.34 };
        case "millhopper":   return { mat: "tim", work: [ 0.00,  0.10], stand: -0.32, foot: [-0.26, 0.26], h: 0.54 };
        // ---- field and beast --------------------------------------------------------------
        case "standingcorn": return { mat: "grn", work: [ 0.00,  0.40], stand: -0.34, foot: [-0.36, 0.36], h: 0.40 };
        case "threshfloor":  return { mat: "stn", work: [ 0.00,  0.40], stand: -0.20, foot: [-0.34, 0.34], h: 0.08 };
        case "furrow":       return { mat: "stn", work: [ 0.00,  0.44], stand: -0.18, foot: [-0.36, 0.36], h: 0.06 };
        case "shearstool":   return { mat: "tim", work: [ 0.04,  0.30], stand: -0.10, foot: [-0.20, 0.20], h: 0.20 };
        case "gardenbed":    return { mat: "grn", work: [ 0.00,  0.36], stand: -0.24, foot: [-0.32, 0.32], h: 0.12 };
        case "hive":         return { mat: "thr", work: [-0.10,  0.17], stand: -0.28, foot: [-0.16, 0.16], h: 0.34 };
        // ---- stone and earth --------------------------------------------------------------
        case "bankerstone":  return { mat: "stn", work: [ 0.00,  0.11], stand: -0.28, foot: [-0.22, 0.22], h: 0.36 };
        case "potterwheel":  return { mat: "tim", work: [ 0.00,  0.17], stand: -0.02, foot: [-0.18, 0.18], h: 0.30, seat: 0.22 };
        case "trench":       return { mat: "stn", work: [ 0.06,  0.38], stand: -0.22, foot: [-0.30, 0.30], h: 0.06 };
        case "charclamp":    return { mat: "stn", work: [ 0.00,  0.28], stand: -0.36, foot: [-0.30, 0.30], h: 0.30 };
        // ---- water and trade --------------------------------------------------------------
        case "netframe":     return { mat: "thr", work: [ 0.11, -0.10], stand: -0.04, foot: [-0.28, 0.28], h: 0.52, seat: 0.20 };
        case "washstone":    return { mat: "stn", work: [ 0.00,  0.36], stand: -0.24, foot: [-0.24, 0.24], h: 0.14 };
        case "well":         return { mat: "stn", work: [ 0.00, -0.10], stand: -0.34, foot: [-0.26, 0.26], h: 0.56 };
        case "cart":         return { mat: "tim", work: [ 0.00,  0.09], stand: -0.40, foot: [-0.38, 0.38], h: 0.40 };
        case "stall":        return { mat: "cnv", work: [ 0.00,  0.05], stand: -0.02, foot: [-0.36, 0.36], h: 0.62 };
        case "writingdesk":  return { mat: "tim", work: [ 0.00,  0.21], stand: -0.02, foot: [-0.24, 0.24], h: 0.30, seat: 0.23 };
        case "herbbench":    return { mat: "tim", work: [ 0.00,  0.02], stand: -0.28, foot: [-0.26, 0.26], h: 0.32 };
        case "diprack":      return { mat: "tim", work: [ 0.00, -0.04], stand: -0.30, foot: [-0.26, 0.26], h: 0.50 };
        // ---- the day is not all work ------------------------------------------------------
        case "brazier":      return { mat: "irn", work: [ 0.00,  0.05], stand: -0.28, foot: [-0.16, 0.16], h: 0.40 };
        case "postboard":    return { mat: "tim", work: [ 0.00, -0.06], stand: -0.26, foot: [-0.14, 0.14], h: 0.58 };
        case "hoopring":     return { mat: "tim", work: [ 0.06,  0.28], stand: -0.20, foot: [-0.16, 0.16], h: 0.16 };
        // ⚠️ `seatdrawn` - the bench builds its own seat slab at `_g - 0.19` below, and the two
        // numbers are the same number on purpose. The generic seat is skipped here rather than the
        // recipe's own slab being deleted, because a bench with a back rail is a specific piece of
        // furniture and the generic one is a stool.
        case "villagebench": return { mat: "tim", work: [ 0.00,  0.16], stand: -0.02, foot: [-0.30, 0.30], h: 0.22, seat: 0.19, seatdrawn: true };
        case "shrine":       return { mat: "stn", work: [ 0.00, 0.25], stand: -0.30, foot: [-0.20, 0.20], h: 0.54 };
        case "pengate":      return { mat: "tim", work: [ 0.00,  0.04], stand: -0.32, foot: [-0.30, 0.30], h: 0.44 };
        // ⛔ NO PLAUSIBLE FALLBACK. An unknown id means a work loop names a station that does not
        // exist; returning a generic bench would draw a smith hammering a table forever with nothing
        // reporting it. The suite asserts every station named by lge_works_all resolves, and this is
        // what lets that assertion fail instead of being satisfied by a stand-in.
        default: return undefined;
    }
}

/// ============================================================================================
/// THE RECIPES
/// ============================================================================================
///
/// Each returns {back, front}. Built in generic ramp roles and mapped into the station's material at
/// the END, in ONE place - so a recipe never names a colour and a theme change reaches all 46.
///
/// ⚠️ EVERY RECIPE IS AUTHORED AGAINST THE FLOOR, `LGE_SOLE`, not against its own height. A prop
/// sized from its own bounding box floats when its height changes; a prop built up from the ground
/// stands on it. This is the local form of a law this wing has paid for twice - a vertical dimension
/// derived from a horizontal one, and a declared extent the builder reads as its own scale.
///
/// @param {String} _id
/// @param {Real} _seed  the station's own seed. The same station in the same town always looks the
///                      same; two anvils in one town differ. Nothing here calls random().
/// @returns {Struct|Undefined} {back, front}
function lge_station_parts(_id, _seed) {
    var _sp = lge_station_spec(_id);
    if (is_undefined(_sp)) return undefined;
    var _g = LGE_SOLE;
    var _r = lge_rng(_seed);
    var _b = [];      // behind the figure
    var _f = [];      // in front of the figure
    var _h = _sp.h;
    var _top = _g - _h;
    var _i, _t, _a;

    switch (_id) {
        // ---- metal and fire ---------------------------------------------------------------
        // An anvil is a WAISTED mass on a stump, and the waist is the whole silhouette: a plain
        // block on a post reads as a mailbox. The horn is the second half of the read.
        case "anvil":
            lge_append(_b, lge_st_taper(0, _g - 0.14, _g, 0.075, 0.11, -0.02, 0.40));
            lge_append(_b, lge_st_taper(0, _top + 0.055, _g - 0.14, 0.085, 0.055, -0.028, 0.40));
            lge_append(_b, lge_st_slab(-0.15, _top, 0.15, _top + 0.055, 0.44, 3));
            lge_append(_b, lge_mass([[0.14, _top + 0.006], [0.29, _top + 0.028],
                                     [0.14, _top + 0.050]], 0.30, 2, "m2"));
            break;
        case "forge":
            lge_append(_b, lge_st_slab(-0.28, _g - 0.30, 0.28, _g, 0.30, 3));
            lge_append(_b, lge_mass([[-0.24, _top], [0.24, _top],
                                     [0.16, _g - 0.34], [-0.16, _g - 0.34]], 0.34, 3, "m2"));
            lge_append(_b, lge_st_slab(-0.30, _g - 0.34, 0.30, _g - 0.28, 0.42, 2));
            lge_append(_f, lge_st_flame(0, _g - 0.30, 0.13, 0.13, _seed + 11));
            break;
        case "trough":
            lge_append(_b, lge_st_slab(-0.24, _g - 0.20, 0.24, _g, 0.26, 3));
            var _rim_tr = lge_st_rim(0, _g - 0.20, 0.24, 0.062, 0.010);
            lge_append(_b, _rim_tr.back);
            lge_append(_f, _rim_tr.front);
            break;
        case "hoofstand":
            lge_append(_b, lge_st_trestle(0, _g - 0.16, _g, 0.07, 0.045, 0.020));
            lge_append(_b, lge_st_slab(-0.12, _g - 0.18, 0.12, _g - 0.155, 0.40, 2));
            break;
        case "tinkerbench":
            lge_append(_b, lge_st_trestle(-0.17, _g - 0.26, _g, 0.05, 0.030, 0.017));
            lge_append(_b, lge_st_trestle(0.17, _g - 0.26, _g, 0.05, 0.030, 0.017));
            lge_append(_b, lge_st_slab(-0.27, _g - 0.29, 0.27, _g - 0.255, 0.44, 2));
            lge_append(_f, lge_st_pile(0.15, _g - 0.29, 0.07, 0.030, 4, _seed + 3));
            break;

        // ---- wood -------------------------------------------------------------------------
        case "sawhorse":
            lge_append(_b, lge_st_beam(-0.15, _g, 0.09, _g - 0.24, 0.017));
            lge_append(_b, lge_st_beam(0.15, _g, -0.09, _g - 0.24, 0.017));
            lge_append(_b, lge_st_beam(-0.11, _g - 0.19, 0.11, _g - 0.19, 0.013));
            lge_append(_b, lge_st_slab(-0.25, _g - 0.27, 0.25, _g - 0.235, 0.40, 2));
            break;
        // ⛔ RAISED 0.12 ON 2026-09-04. A joiner's bench is HIP HEIGHT - you put your weight over a
        // plane - and this one presented its top at 0.170, which is 32% of a stature above the floor
        // = mid-thigh. MEASURED by cropping `baker_knead` at 4x and reading the figure's own
        // landmarks off the pixels: crown 62px, sole 560px, hip 291px, that bench class's rim 395px.
        // A worker cannot get their hands onto a surface at mid-thigh without a stoop nobody asked
        // for, and the previous four sessions all read the resulting gap as a POSE defect.
        // 0.45 of stature above the floor is the measured human bench height and puts the top at
        // y = 0.470 - 0.45*0.94 = 0.047.
        case "joinerbench":
            lge_append(_b, lge_st_trestle(-0.22, _g - 0.38, _g, 0.055, 0.026, 0.020));
            lge_append(_b, lge_st_trestle(0.22, _g - 0.38, _g, 0.055, 0.026, 0.020));
            lge_append(_b, lge_st_slab(-0.33, _g - 0.42, 0.33, _g - 0.378, 0.40, 3));
            // A shaving heap under the bench - the one detail that says the bench is USED.
            lge_append(_f, lge_st_pile(-0.12, _g, 0.11, 0.032, 6, _seed + 5));
            break;
        case "barrelcradle":
            lge_append(_b, lge_st_beam(-0.19, _g, -0.13, _g - 0.14, 0.018));
            lge_append(_b, lge_st_beam(0.19, _g, 0.13, _g - 0.14, 0.018));
            lge_append(_b, lge_st_taper(0, _top, _g - 0.10, 0.10, 0.10, 0.055, 0.34));
            lge_append(_f, lge_st_hoops(0, _top, _g - 0.10, 0.10, 0.10, 0.055, 3, 0.010));
            break;
        case "polelathe":
            lge_append(_b, lge_st_beam(-0.28, _g, -0.28, _top, 0.020));
            lge_append(_b, lge_st_beam(0.28, _g, 0.28, _top, 0.020));
            // The springy pole across the top, BOWED - a straight one reads as a lintel.
            lge_append(_b, [lge_var_ribbon(lge_qbez([-0.28, _top], [0, _top - 0.07], [0.28, _top], 8),
                                           [0.010, 0.011, 0.012, 0.013, 0.013, 0.012, 0.011, 0.010, 0.009], "m1")]);
            lge_append(_b, lge_st_slab(-0.24, _g - 0.12, 0.24, _g - 0.09, 0.40, 2));
            lge_append(_f, lge_st_taper(0, _g - 0.135, _g - 0.09, 0.030, 0.026, 0.006, 0.40));
            break;
        case "chopblock":
            lge_append(_b, lge_st_taper(0, _top, _g, 0.135, 0.155, 0.008, 0.30));
            lge_append(_b, [lge_ring_fill(lge_ellipse_pts(0, _top, 0.135, 0.036, 16), "m3", 0, _top)]);
            lge_append(_f, [lge_poly([[-0.05, _top - 0.004], [0.045, _top + 0.006]], false, 0.008, "m0")]);
            break;

        // ---- cloth and fibre --------------------------------------------------------------
        // A loom is a tall frame with WARP running down it. Seventeen threads is the one place in
        // this package where a repeated straight line reads as craft rather than as programmer art,
        // because that is genuinely what a warp is.
        case "loom":
            lge_append(_b, lge_st_frame(-0.26, _top, 0.26, _g, 0.022));
            for (_i = 0; _i < 17; _i++) {
                var _warpx = lerp(-0.225, 0.225, _i / 16);
                lge_append(_b, [lge_poly([[_warpx, _top + 0.04], [_warpx, _g - 0.10]], false, 0.0035, "m1")]);
            }
            lge_append(_b, lge_st_slab(-0.225, _g - 0.20, 0.225, _g - 0.10, 0.24, 2));
            lge_append(_f, lge_st_beam(-0.26, _g - 0.10, 0.26, _g - 0.10, 0.020));
            break;
        case "spinwheel":
            lge_append(_b, lge_st_trestle(0, _g - 0.14, _g, 0.14, 0.05, 0.016));
            lge_append(_b, lge_st_beam(-0.14, _g - 0.15, 0.20, _g - 0.24, 0.014));
            lge_append(_b, lge_st_disc(-0.10, _g - 0.22, 0.135, 0.135, 0.16));
            // Spokes are what stop a wheel reading as a plate.
            for (_i = 0; _i < 8; _i++) {
                _a = _i * (LGE_TAU / 8);
                lge_append(_b, [lge_poly([[-0.10, _g - 0.22],
                                          [-0.10 + cos(_a) * 0.125, _g - 0.22 + sin(_a) * 0.125]],
                                         false, 0.006, "m0")]);
            }
            lge_append(_f, [lge_dot(-0.10, _g - 0.22, 0.020, "m4")]);
            break;
        case "dyevat":
            lge_append(_b, lge_st_taper(0, _top, _g, 0.155, 0.125, 0.022, 0.32));
            lge_append(_b, lge_st_hoops(0, _top, _g, 0.155, 0.125, 0.022, 2, 0.011));
            var _rim_dv = lge_st_rim(0, _top, 0.155, 0.048, 0.011);
            lge_append(_b, _rim_dv.back);
            lge_append(_f, _rim_dv.front);
            break;
        case "ropewalk":
            lge_append(_b, lge_st_beam(-0.32, _g, -0.32, _g - 0.26, 0.018));
            lge_append(_b, lge_st_beam(0.32, _g, 0.32, _g - 0.26, 0.018));
            // Three strands TWISTING into one. The twist is the product of the job, so the strands
            // cross rather than running parallel - three parallel lines are a fence.
            for (_i = 0; _i < 3; _i++) {
                var _ph = _i * (LGE_TAU / 3);
                var _strand = array_create(13);
                for (var _j = 0; _j <= 12; _j++) {
                    _t = _j / 12;
                    _strand[_j] = [lerp(-0.32, 0.32, _t),
                                   _g - 0.24 + sin(_t * 7.2 + _ph) * 0.016 * (1 - _t * 0.7)];
                }
                lge_append(_b, [lge_poly(_strand, false, 0.008, (_i == 1) ? "m3" : "m1")]);
            }
            break;
        // ⛔ RAISED 0.17 ON 2026-09-04, same measurement as `joinerbench` above. A tailor's cutting
        // table presented its top at 0.220 - 27% of a stature, below mid-thigh - and a tailor
        // stitches at it standing.
        case "cuttingtable":
            lge_append(_b, lge_st_trestle(-0.21, _g - 0.39, _g, 0.05, 0.024, 0.018));
            lge_append(_b, lge_st_trestle(0.21, _g - 0.39, _g, 0.05, 0.024, 0.018));
            lge_append(_b, lge_st_slab(-0.31, _g - 0.42, 0.31, _g - 0.388, 0.40, 2));
            lge_append(_f, lge_st_sheet(-0.24, 0.10, _g - 0.42, 0.022, 0.13));
            break;

        // ---- food -------------------------------------------------------------------------
        // A bread oven is a DOME with a black mouth, and the mouth is the whole read: without it a
        // dome is a rock.
        case "oven":
            lge_append(_b, lge_st_slab(-0.30, _g - 0.16, 0.30, _g, 0.24, 2));
            lge_append(_b, lge_mass(lge_ellipse_arc_pts(0, _g - 0.16, 0.28, 0.42, pi, LGE_TAU, 18), 0.30, 3, "m2"));
            lge_append(_b, [lge_ring_fill(lge_ellipse_arc_pts(0, _g - 0.16, 0.115, 0.155, pi, LGE_TAU, 12),
                                          "m0", 0, _g - 0.17)]);
            lge_append(_f, lge_st_flame(0, _g - 0.17, 0.07, 0.07, _seed + 7));
            break;
        // ⛔ RAISED 0.13 ON 2026-09-04. This is the station the measurement was taken on: its rim sat
        // at 395px against a hip at 291px in a 498px figure - a baker kneading at mid-thigh. You put
        // your body weight into a knead, which needs the trough at hip height.
        case "kneadtrough":
            lge_append(_b, lge_st_trestle(-0.19, _g - 0.37, _g, 0.05, 0.024, 0.018));
            lge_append(_b, lge_st_trestle(0.19, _g - 0.37, _g, 0.05, 0.024, 0.018));
            lge_append(_b, lge_mass([[-0.26, _g - 0.41], [0.26, _g - 0.41],
                                     [0.20, _g - 0.33], [-0.20, _g - 0.33]], 0.30, 3, "m2"));
            var _rim_kt = lge_st_rim(0, _g - 0.41, 0.26, 0.052, 0.010);
            lge_append(_b, _rim_kt.back);
            lge_append(_f, _rim_kt.front);
            break;
        case "butcherblock":
            lge_append(_b, lge_st_taper(0, _g - 0.30, _g, 0.175, 0.195, 0.006, 0.28));
            lge_append(_b, [lge_ring_fill(lge_ellipse_pts(0, _g - 0.30, 0.175, 0.044, 16), "m3", 0, _g - 0.30)]);
            for (_i = 0; _i < 5; _i++) {
                var _cutx = lerp(-0.11, 0.11, _i / 4);
                lge_append(_f, [lge_poly([[_cutx - 0.02, _g - 0.302], [_cutx + 0.03, _g - 0.294]],
                                         false, 0.005, "m0")]);
            }
            break;
        case "mashtun":
            lge_append(_b, lge_st_taper(0, _top, _g, 0.18, 0.145, 0.028, 0.30));
            lge_append(_b, lge_st_hoops(0, _top, _g, 0.18, 0.145, 0.028, 3, 0.012));
            var _rim_mt = lge_st_rim(0, _top, 0.18, 0.055, 0.012);
            lge_append(_b, _rim_mt.back);
            lge_append(_f, _rim_mt.front);
            break;
        case "churn":
            lge_append(_b, lge_st_taper(0, _top, _g, 0.085, 0.062, 0.014, 0.34));
            lge_append(_b, lge_st_hoops(0, _top, _g, 0.085, 0.062, 0.014, 3, 0.009));
            var _rim_ch = lge_st_rim(0, _top, 0.085, 0.028, 0.009);
            lge_append(_b, _rim_ch.back);
            lge_append(_f, _rim_ch.front);
            break;
        // ⛔ THE POT HUNG AT ANKLE HEIGHT AND A COOK WAS DRAWN STIRRING IT WITH HER ARMS BY HER
        // SIDES. MEASURED 2026-09-04 by cropping `cook_ladle` at 4x: the rim sat at y = 0.270, which
        // is 21% of a stature above the floor - lower than the figure's own knee. The tripod is
        // taller and the pot hangs from it at 0.075, which is 42% up: a cauldron you stir standing.
        case "cookfire":
            lge_append(_b, lge_st_pile(0, _g, 0.20, 0.045, 7, _seed + 2));
            lge_append(_b, lge_st_beam(-0.21, _g, -0.05, _g - 0.50, 0.011));
            lge_append(_b, lge_st_beam(0.21, _g, 0.05, _g - 0.50, 0.011));
            lge_append(_b, lge_st_flame(0, _g - 0.02, 0.10, 0.15, _seed + 13));
            // The pot hangs from the tripod IN FRONT of the fire, which is where a pot on a fire is.
            lge_append(_f, lge_st_taper(0, _g - 0.395, _g - 0.285, 0.070, 0.052, 0.020, 0.34));
            lge_append(_f, [lge_poly(lge_ellipse_arc_pts(0, _g - 0.395, 0.070, 0.024, 0, pi, 10),
                                     false, 0.008, "m3")]);
            // The hook and chain the pot hangs BY - a pot floating under an apex is the tell that
            // nothing is holding it, and raising the tripod made that gap visible for the first time.
            lge_append(_b, lge_st_beam(0, _g - 0.50, 0, _g - 0.395, 0.007));
            break;
        case "millhopper":
            lge_append(_b, lge_st_trestle(0, _g - 0.20, _g, 0.20, 0.05, 0.020));
            // An INVERTED pyramid: wide at the top, narrow at the spout. The taper IS the object.
            lge_append(_b, lge_mass([[-0.24, _top], [0.24, _top],
                                     [0.06, _g - 0.20], [-0.06, _g - 0.20]], 0.26, 3, "m2"));
            lge_append(_b, lge_st_disc(0, _g - 0.16, 0.19, 0.052, 0.20));
            lge_append(_f, lge_st_pile(0.14, _g, 0.09, 0.055, 3, _seed + 17));
            break;

        // ---- field and beast --------------------------------------------------------------
        // Standing corn: stalks with heavy heads. The BEND is what makes it corn and not grass.
        case "standingcorn":
            for (_i = 0; _i < 26; _i++) {
                var _stalkx = lerp(-0.34, 0.34, _i / 25);
                var _stalkh = 0.30 + lge_rng_range(_r, -0.05, 0.07);
                var _bend = lge_rng_range(_r, -0.05, 0.05);
                lge_append(_b, [lge_poly(lge_qbez([_stalkx, _g],
                                                  [_stalkx + _bend * 0.5, _g - _stalkh * 0.6],
                                                  [_stalkx + _bend, _g - _stalkh], 6), false, 0.004, "m1")]);
                lge_append(_b, [lge_dot(_stalkx + _bend, _g - _stalkh, 0.014, "m3")]);
            }
            break;
        case "threshfloor":
            lge_append(_b, [lge_ring_fill(lge_ellipse_pts(0, _g - 0.01, 0.34, 0.085, 20), "m2", 0, _g - 0.01)]);
            lge_append(_b, lge_st_pile(-0.18, _g - 0.01, 0.11, 0.055, 5, _seed + 21));
            lge_append(_f, lge_st_pile(0.18, _g, 0.12, 0.048, 5, _seed + 22));
            break;
        case "furrow":
            for (_i = 0; _i < 5; _i++) {
                var _fy = _g - 0.035 + _i * 0.016;
                lge_append(_b, [lge_poly([[-0.36, _fy], [0.36, _fy]], false, 0.010,
                                         (_i mod 2 == 0) ? "m1" : "m3")]);
            }
            break;
        case "shearstool":
            lge_append(_b, lge_st_trestle(0, _g - 0.15, _g, 0.10, 0.045, 0.017));
            lge_append(_b, lge_st_slab(-0.16, _g - 0.17, 0.16, _g - 0.148, 0.40, 2));
            // The fleece, in front: the shearer leans OVER it.
            lge_append(_f, lge_st_pile(0.05, _g - 0.17, 0.13, 0.075, 5, _seed + 31));
            break;
        case "gardenbed":
            lge_append(_b, lge_st_frame(-0.30, _g - 0.06, 0.30, _g, 0.014));
            for (_i = 0; _i < 9; _i++) {
                var _plantx = lerp(-0.25, 0.25, _i / 8);
                lge_append(_b, [lge_poly(lge_qbez([_plantx, _g - 0.05],
                                                  [_plantx - 0.012, _g - 0.10],
                                                  [_plantx + 0.018, _g - 0.14], 5), false, 0.005, "m3")]);
            }
            break;
        case "hive":
            // A skep: stacked coils, narrowing. The COILS are the object; a plain dome is a haystack.
            for (_i = 0; _i < 6; _i++) {
                _t = _i / 5;
                var _coily = _g - 0.02 - _t * 0.28;
                var _coilw = 0.145 * (1 - _t * _t * 0.72);
                lge_append(_b, lge_mass(lge_ellipse_pts(0, _coily, _coilw, 0.030, 14), 0.42, 2, "m2"));
            }
            lge_append(_f, [lge_ring_fill(lge_ellipse_pts(0, _g - 0.03, 0.028, 0.016, 10), "m0", 0, _g - 0.03)]);
            break;

        // ---- stone and earth --------------------------------------------------------------
        case "bankerstone":
            lge_append(_b, lge_st_trestle(0, _g - 0.24, _g, 0.16, 0.04, 0.022));
            lge_append(_b, lge_st_slab(-0.20, _g - 0.34, 0.20, _g - 0.24, 0.26, 3));
            // The carving in progress: a recessed line, not a scratched outline.
            lge_append(_f, lge_incise([[-0.10, _g - 0.335], [0.02, _g - 0.355], [0.11, _g - 0.330]],
                                      false, 0.008));
            break;
        case "potterwheel":
            lge_append(_b, lge_st_beam(0, _g, 0, _g - 0.22, 0.026));
            lge_append(_b, lge_st_disc(0, _g - 0.08, 0.155, 0.042, 0.22));
            // ⛔ THE WHEEL HEAD GOES IN FRONT, NOT JUST ITS RIM. MEASURED 2026-09-04 by cropping this
            // cell to 4x twice. The wheel is a VERTICAL COLUMN at x=0 and the potter sits astride it
            // (`stand: -0.02`), so with every part in `_b` her smock covered the entire machine and
            // the cell read as a woman sitting on a stool with a lump of clay in her lap. A near-rim
            // beam in `_f` was tried first and moved almost nothing - a 0.012 rail is not a wheel.
            // The HEAD is what a potter works over, so it belongs over the lap, and it is what makes
            // the cell read as a wheel at all. The kick-wheel below stays BEHIND deliberately: a
            // potter kicks that with their feet, which is what `elder_sit` shows against its
            // trestles.
            lge_append(_f, lge_st_disc(0, _g - 0.24, 0.105, 0.030, 0.24));
            lge_append(_f, lge_st_taper(0, _g - 0.30, _g - 0.245, 0.048, 0.062, 0.014, 0.34));
            break;
        case "trench":
            lge_append(_b, lge_mass([[-0.28, _g], [-0.12, _g - 0.05],
                                     [0.14, _g - 0.05], [0.30, _g]], 0.24, 2, "m0"));
            lge_append(_f, lge_st_pile(-0.24, _g, 0.10, 0.055, 4, _seed + 41));
            break;
        case "charclamp":
            lge_append(_b, lge_mass(lge_ellipse_arc_pts(0, _g, 0.29, 0.29, pi, LGE_TAU, 18), 0.34, 3, "m2"));
            // Smoke leaking through the turf: three thin trails, not a cloud. A translucent blob
            // reads as a smudge at gallery size and this wing has recorded that twice.
            for (_i = 0; _i < 3; _i++) {
                var _smokex = lerp(-0.12, 0.12, _i / 2);
                lge_append(_f, [lge_poly(lge_qbez([_smokex, _g - 0.26],
                                                  [_smokex + 0.03, _g - 0.34],
                                                  [_smokex - 0.02, _g - 0.44], 6), false, 0.006, "m3")]);
            }
            break;

        // ---- water and trade --------------------------------------------------------------
        case "netframe":
            lge_append(_b, lge_st_frame(-0.26, _top, 0.26, _g - 0.06, 0.020));
            // DIAGONALS both ways. A square grid reads as a window; diagonals read as a net.
            // ⛔⛔ CLIPPED TO THE FRAME'S INSIDE EDGE. These offsets run past the frame by design -
            // that is how a diagonal mesh fills a rectangle - and until 2026-09-04 they were drawn
            // WHOLE, so the net spanned -0.68..+0.68 inside a frame of -0.26..+0.26. See
            // `lge_st_clip_x` for the measurement and for why the fix is a clip rather than a
            // smaller loop bound. Offsets that fall entirely outside now draw nothing.
            var _nx0 = -0.24, _nx1 = 0.24;
            var _nyt = _top + 0.03, _nyb = _g - 0.09;
            for (_i = -4; _i <= 4; _i++) {
                var _off = _i * 0.11;
                var _seg = lge_st_clip_x(-0.24 + _off, _nyt, 0.06 + _off, _nyb, _nx0, _nx1);
                if (!is_undefined(_seg)) lge_append(_b, [lge_poly(_seg, false, 0.0035, "m1")]);
                _seg = lge_st_clip_x(0.24 + _off, _nyt, -0.06 + _off, _nyb, _nx0, _nx1);
                if (!is_undefined(_seg)) lge_append(_b, [lge_poly(_seg, false, 0.0035, "m1")]);
            }
            break;
        case "washstone":
            lge_append(_b, lge_mass([[-0.22, _g], [-0.19, _g - 0.13],
                                     [0.19, _g - 0.11], [0.22, _g]], 0.30, 3, "m2"));
            lge_append(_f, [lge_poly(lge_ellipse_arc_pts(-0.02, _g - 0.02, 0.30, 0.045, 0, pi, 12),
                                     false, 0.010, "m4")]);
            break;
        case "well":
            lge_append(_b, lge_st_taper(0, _g - 0.20, _g, 0.24, 0.26, 0.010, 0.26));
            lge_append(_b, lge_st_beam(-0.19, _g - 0.20, -0.19, _top, 0.019));
            lge_append(_b, lge_st_beam(0.19, _g - 0.20, 0.19, _top, 0.019));
            lge_append(_b, lge_st_beam(-0.22, _top, 0.22, _top, 0.017));
            lge_append(_b, [lge_poly([[0, _top], [0, _g - 0.30]], false, 0.005, "m1")]);
            lge_append(_b, lge_st_taper(0, _g - 0.30, _g - 0.24, 0.045, 0.038, 0.006, 0.34));
            var _rim_wl = lge_st_rim(0, _g - 0.20, 0.24, 0.070, 0.013);
            lge_append(_b, _rim_wl.back);
            lge_append(_f, _rim_wl.front);
            break;
        case "cart":
            lge_append(_b, lge_mass([[-0.34, _g - 0.30], [0.34, _g - 0.30],
                                     [0.30, _g - 0.13], [-0.30, _g - 0.13]], 0.26, 3, "m2"));
            lge_append(_b, lge_st_beam(-0.34, _g - 0.16, -0.52, _g - 0.22, 0.014));
            lge_append(_b, lge_st_pile(-0.10, _g - 0.30, 0.16, 0.06, 4, _seed + 51));
            lge_append(_f, lge_st_disc(0.15, _g - 0.13, 0.135, 0.135, 0.16));
            for (_i = 0; _i < 6; _i++) {
                _a = _i * (LGE_TAU / 6);
                lge_append(_f, [lge_poly([[0.15, _g - 0.13],
                                          [0.15 + cos(_a) * 0.125, _g - 0.13 + sin(_a) * 0.125]],
                                         false, 0.007, "m0")]);
            }
            break;
        case "stall":
            lge_append(_b, lge_st_beam(-0.34, _g, -0.34, _top, 0.018));
            lge_append(_b, lge_st_beam(0.34, _g, 0.34, _top, 0.018));
            lge_append(_b, lge_st_sheet(-0.38, 0.38, _top, 0.045, 0.10));
            // ⛔ RAISED 0.18 ON 2026-09-04. A market counter at 26% of a stature is a footstool with
            // goods on it; a stallkeeper leans on one at hip height. Same measurement as the three
            // benches above.
            lge_append(_b, lge_st_slab(-0.32, _g - 0.42, 0.32, _g - 0.39, 0.40, 2));
            lge_append(_b, lge_st_pile(-0.14, _g - 0.42, 0.12, 0.05, 5, _seed + 61));
            lge_append(_b, lge_st_pile(0.16, _g - 0.42, 0.10, 0.045, 4, _seed + 62));
            // The counter's NEAR edge crosses in front of the stallkeeper standing behind it. This
            // is the depth split doing exactly what the file header is about.
            lge_append(_f, lge_st_beam(-0.34, _g - 0.39, 0.34, _g - 0.39, 0.014));
            break;
        case "writingdesk":
            lge_append(_b, lge_st_trestle(0, _g - 0.20, _g, 0.15, 0.045, 0.018));
            // A SLOPED desk, which is what a writing desk is. A flat one is a table.
            lge_append(_b, lge_mass([[-0.22, _g - 0.30], [0.22, _g - 0.22],
                                     [0.22, _g - 0.195], [-0.22, _g - 0.275]], 0.34, 3, "m2"));
            lge_append(_f, [lge_poly([[-0.16, _g - 0.272], [0.14, _g - 0.218]], false, 0.006, "m4")]);
            // ⛔ THE NEAR EDGE GOES IN FRONT, OR A SEATED SCRIBE SITS ON THEIR OWN DESK. MEASURED
            // 2026-09-04 by cropping this cell to 4x: every part of the desk was in `_b`, so the
            // figure was painted over all of it and the cell read as a woman sitting on a trestle
            // with a stick across her lap. `villagebench` gets this right (its seat slab is in `_f`,
            // which is why `elder_sit` reads as somebody sitting ON a bench) and `stall` states the
            // rule in its own comment - the counter's near edge crosses in front of the keeper.
            // ⚠️ THE EDGE, NOT THE WHOLE TOP. Putting the sloped surface in front would hide the
            // hands and the quill, which are the only things on this cell that say "writing"; a thin
            // near rail gives the depth cue and leaves the work visible above it.
            lge_append(_f, lge_st_beam(-0.22, _g - 0.198, 0.22, _g - 0.198, 0.013));
            break;
        case "herbbench":
            lge_append(_b, lge_st_trestle(-0.20, _g - 0.26, _g, 0.05, 0.026, 0.018));
            lge_append(_b, lge_st_trestle(0.20, _g - 0.26, _g, 0.05, 0.026, 0.018));
            // Hanging bunches ABOVE the bench - the thing that says apothecary rather than joiner.
            for (_i = 0; _i < 5; _i++) {
                var _hangx = lerp(-0.20, 0.20, _i / 4);
                lge_append(_b, [lge_poly([[_hangx, _g - 0.52], [_hangx, _g - 0.42]], false, 0.004, "m1")]);
                lge_append(_b, lge_mass(lge_ellipse_pts(_hangx, _g - 0.395, 0.026, 0.038, 10), 0.50, 2, "m3"));
            }
            lge_append(_b, lge_st_slab(-0.26, _g - 0.30, 0.26, _g - 0.262, 0.40, 2));
            break;
        case "diprack":
            lge_append(_b, lge_st_beam(-0.24, _g, -0.24, _top, 0.017));
            lge_append(_b, lge_st_beam(0.24, _g, 0.24, _top, 0.017));
            lge_append(_b, lge_st_beam(-0.26, _top, 0.26, _top, 0.014));
            for (_i = 0; _i < 9; _i++) {
                var _wickx = lerp(-0.21, 0.21, _i / 8);
                var _wickl = 0.10 + lge_rng_range(_r, -0.015, 0.015);
                lge_append(_b, [lge_poly([[_wickx, _top + 0.01], [_wickx, _top + 0.01 + _wickl]],
                                         false, 0.0035, "m1")]);
                lge_append(_b, lge_mass(lge_ellipse_pts(_wickx, _top + 0.02 + _wickl, 0.011, 0.024, 8),
                                        0.50, 2, "m3"));
            }
            lge_append(_f, lge_st_taper(0, _g - 0.14, _g, 0.11, 0.09, 0.012, 0.32));
            break;

        // ---- the day is not all work ------------------------------------------------------
        case "brazier":
            lge_append(_b, lge_st_trestle(0, _g - 0.22, _g, 0.09, 0.04, 0.013));
            lge_append(_b, lge_st_taper(0, _g - 0.30, _g - 0.20, 0.135, 0.085, 0.010, 0.32));
            lge_append(_b, lge_st_flame(0, _g - 0.30, 0.09, 0.13, _seed + 71));
            var _rim_bz = lge_st_rim(0, _g - 0.30, 0.135, 0.040, 0.010);
            lge_append(_b, _rim_bz.back);
            lge_append(_f, _rim_bz.front);
            break;
        case "postboard":
            lge_append(_b, lge_st_beam(0, _g, 0, _top, 0.024));
            lge_append(_b, lge_st_slab(-0.13, _top, 0.13, _top + 0.19, 0.30, 3));
            for (_i = 0; _i < 4; _i++) {
                var _liney = _top + 0.045 + _i * 0.035;
                lge_append(_f, [lge_poly([[-0.10, _liney], [0.10, _liney]], false, 0.005, "m0")]);
            }
            break;
        case "hoopring":
            lge_append(_b, [lge_poly(lge_ellipse_pts(0, _g - 0.11, 0.105, 0.105, 22), true, 0.010, "m2")]);
            break;
        case "villagebench":
            lge_append(_b, lge_st_trestle(-0.22, _g - 0.16, _g, 0.05, 0.030, 0.017));
            lge_append(_b, lge_st_trestle(0.22, _g - 0.16, _g, 0.05, 0.030, 0.017));
            lge_append(_b, lge_st_slab(-0.30, _g - 0.40, 0.30, _g - 0.36, 0.40, 2));
            lge_append(_f, lge_st_slab(-0.30, _g - 0.19, 0.30, _g - 0.163, 0.40, 2));
            break;
        case "shrine":
            lge_append(_b, lge_st_slab(-0.18, _g - 0.10, 0.18, _g, 0.24, 2));
            lge_append(_b, lge_mass([[-0.15, _g - 0.44], [0.15, _g - 0.44],
                                     [0.13, _g - 0.10], [-0.13, _g - 0.10]], 0.26, 3, "m2"));
            lge_append(_b, lge_mass([[-0.19, _g - 0.44], [0, _g - 0.54], [0.19, _g - 0.44]], 0.30, 2, "m2"));
            // The niche: a recessed AREA, which this wing lists as a third primitive distinct from a
            // drilled pit and an incised line. An outline scratched inside a small mass is a scribble.
            lge_append(_f, lge_sink(lge_ellipse_arc_pts(0, _g - 0.22, 0.070, 0.115, pi, LGE_TAU, 12),
                                    0.020, 2, "m1"));
            break;
        case "pengate":
            lge_append(_b, lge_st_beam(-0.30, _g, -0.30, _top, 0.020));
            lge_append(_b, lge_st_beam(0.30, _g, 0.30, _top, 0.020));
            for (_i = 0; _i < 3; _i++) {
                var _raily = _g - 0.10 - _i * 0.13;
                lge_append(_b, lge_st_beam(-0.30, _raily, 0.30, _raily, 0.011));
            }
            lge_append(_f, lge_st_beam(-0.26, _g - 0.06, 0.26, _g - 0.36, 0.010));
            break;
    }

    // ⛔⛔ THE SEAT IS DRAWN FROM THE SPEC, NOT INSIDE THE RECIPES, AND THAT IS THE WHOLE POINT.
    // Seven of the eight stations somebody SITS at had no seat in them: the weaver, the spinner, the
    // tailor, the potter, the scribe, the tinker and the net-mender all worked a full day balanced on
    // nothing (MEASURED 2026-09-03, and visible on the grid sheet the moment the figures stopped
    // standing on their furniture). Adding a stool to seven recipes by hand would have left the
    // eighth station a different shape from the other seven and the NEXT seated station one edit away
    // from the same defect. Reading it off `seat` means a station cannot declare somewhere to sit and
    // fail to draw it - the declaration IS the drawing - and `lge_figure_parts` solves the hip
    // against the same number, so the furniture and the hips cannot drift apart.
    //
    // ⚠️ IN THE BACK LIST, ALWAYS. A stool drawn in front would be a plank painted across the sitter's
    // shins, and the suite's front-half rule would rightly go red. What a viewer sees is the seat
    // edge either side of the hips, which is the whole cue that says seated.
    if (variable_struct_exists(_sp, "seat") && _sp.seat > 0
        && !(variable_struct_exists(_sp, "seatdrawn") && _sp.seatdrawn)) {
        var _sy = _g - _sp.seat;
        var _sx = _sp.stand;
        lge_append(_b, lge_st_trestle(_sx, _sy + 0.012, _g, 0.085, 0.030, 0.016));
        lge_append(_b, lge_st_slab(_sx - 0.135, _sy, _sx + 0.135, _sy + 0.026, 0.38, 2));
    }

    // ⛔ MAPPED INTO THE MATERIAL IN ONE PLACE, AT THE END. A recipe that resolved its own colours
    // would need a material parameter threaded through every constructor and would be re-authored
    // per theme - which is an atlas with extra steps. This is also why `lge_map_roles` accepting a
    // single part as well as a list matters here: three of the constructors above return one part.
    var _map = lge_mat(_sp.mat);
    return { back : lge_map_roles(_b, _map), front : lge_map_roles(_f, _map) };
}
