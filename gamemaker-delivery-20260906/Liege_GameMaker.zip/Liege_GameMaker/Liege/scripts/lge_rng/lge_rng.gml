/// ============================================================================================
/// LIEGE — DETERMINISTIC RANDOM
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// Every generator in this package is seeded and deterministic: the same seed always produces the
/// same town, the same routines and the same work. That is not a nicety here, it is the product's
/// spine - `lge_where` is a PURE FUNCTION of (routine, time), so a buyer's save file needs to hold
/// a seed and a clock and nothing else.
///
/// ⛔ EVERY GLOBAL AND MACRO IN THIS PACKAGE IS NAMESPACED `lge_` / `LGE_`. GML's global namespace
/// is flat, and a collision inside a buyer's project is a support ticket that cannot be debugged
/// remotely.
///
/// ============================================================================================

#macro LGE_RNG_MASK 0xFFFFFFFF

/// ⛔ THE FIRST DRAW OF A FRESHLY SEEDED GENERATOR IS NOT UNIFORM ACROSS NEARBY SEEDS, AND THAT HAS
/// ALREADY COST THIS WING A SHIPPED DEFECT.
///
/// A sibling product (Lode) seeded a Lehmer generator and spent its first draw on a rare-event roll
/// - a 30% chance of a barren result. MEASURED across the 440 nearby seeds its suite used, the
/// first draw spanned only 0.5102 to 0.7358, and the 30% event fired EXACTLY 0 times in 440 trials.
/// Nothing looked wrong: every determinism assertion passed and the picture was unaffected. Only an
/// assertion saying "the rare thing must be POSSIBLE" could see it.
///
/// The cause is structural rather than specific to Lehmer: callers in this catalogue seed as
/// `base + index`, so a run of nearby seeds is a run of nearby STATES, and any generator needs a
/// few rounds before nearby states decorrelate.
///
/// ⛔ WARM UP AT THE SEEDING, NEVER AT THE CALL SITE. A discard at the call site is a discard the
/// next caller has to remember, and the next caller is a buyer.
#macro LGE_RNG_WARMUP 3

/// @desc Seed a generator. Deterministic for a given seed, forever.
///
/// xorshift32 rather than Lehmer: it decorrelates nearby seeds faster, and its only pathology is a
/// single fixed point rather than a near-linear first draw.
///
/// @param {real} seed  any integer; 0 is remapped because xorshift is stuck at zero
/// @return {struct}
function lge_rng(seed) {
    var _s = int64(seed) & LGE_RNG_MASK;
    // xorshift32 has exactly one fixed point, 0, where it emits zeros forever. A caller passing
    // seed 0 is not an error and must not silently produce a degenerate town, so remap it to a
    // constant with a well-mixed bit pattern rather than rejecting it.
    if (_s == 0) _s = 0x9E3779B9;
    var _r = { s : _s };
    repeat (LGE_RNG_WARMUP) lge_rng_next(_r);
    return _r;
}

/// @desc Next raw 32-bit value. Advances the generator.
/// @param {struct} r
/// @return {real} 0 .. 4294967295
function lge_rng_next(r) {
    var _x = r.s;
    _x = (_x ^ (_x << 13)) & LGE_RNG_MASK;
    _x = (_x ^ (_x >> 17)) & LGE_RNG_MASK;
    _x = (_x ^ (_x << 5))  & LGE_RNG_MASK;
    r.s = _x;
    return _x;
}

/// @desc Uniform real in [0,1). Never returns 1.
/// @param {struct} r
/// @return {real}
function lge_rng_float(r) {
    return lge_rng_next(r) / 4294967296;
}

/// @desc Uniform integer in [lo,hi] INCLUSIVE of both ends.
///
/// Inclusive because every caller here wants "a person index" or "an hour", and a half-open range
/// is where off-by-one bugs come from. If hi <= lo the range is empty or degenerate and there is no
/// correct answer, so it returns lo rather than inventing one - and the self-test asserts that case
/// explicitly instead of leaving it to chance.
///
/// @param {struct} r
/// @param {real} lo
/// @param {real} hi
/// @return {real}
function lge_rng_int(r, lo, hi) {
    if (hi <= lo) return lo;
    var _n = (hi - lo) + 1;
    return lo + (lge_rng_next(r) % _n);
}

/// @desc Pick one element of an array. Returns undefined for an empty array.
/// @param {struct} r
/// @param {array} arr
function lge_rng_pick(r, arr) {
    var _n = array_length(arr);
    if (_n == 0) return undefined;
    return arr[lge_rng_next(r) % _n];
}

/// @desc True with probability p.
///
/// ⚠️ `<` and not `<=`: at p = 0 this must be impossible, and lge_rng_float can return exactly 0.
/// The self-test pins both ends - p=0 never fires and p=1 always does - because a probability
/// helper that is wrong at its endpoints is wrong in exactly the cases a caller reaches for it.
///
/// @param {struct} r
/// @param {real} p  0..1
/// @return {bool}
function lge_rng_chance(r, p) {
    return lge_rng_float(r) < p;
}

/// @desc Uniform real in [lo,hi).
/// @param {struct} r
/// @param {real} lo
/// @param {real} hi
/// @return {real}
function lge_rng_range(r, lo, hi) {
    return lo + lge_rng_float(r) * (hi - lo);
}

/// @desc Fisher-Yates shuffle, in place. Returns the same array for chaining.
///
/// ⚠️ Walks DOWNWARD and picks from [0,i] inclusive. The upward variant that picks from [i,n-1] is
/// the one that is subtly non-uniform when written with an exclusive bound, and both read the same
/// at a glance.
///
/// @param {struct} r
/// @param {array} arr
/// @return {array}
function lge_rng_shuffle(r, arr) {
    for (var _i = array_length(arr) - 1; _i > 0; _i--) {
        var _j = lge_rng_next(r) % (_i + 1);
        var _t = arr[_i];
        arr[@ _i] = arr[_j];
        arr[@ _j] = _t;
    }
    return arr;
}
