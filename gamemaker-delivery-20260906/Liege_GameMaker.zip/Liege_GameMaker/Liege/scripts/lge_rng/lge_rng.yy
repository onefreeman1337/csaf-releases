{
  "$GMScript": "v1",
  "%Name": "lge_rng",
  "name": "lge_rng",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}
