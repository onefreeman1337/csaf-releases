/// ============================================================================================
/// LIEGE — THE TOWN
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// ⭐ THE SPINE, AND THE PRODUCT'S ONE STRUCTURAL CLAIM. Everything else in this package draws; this
/// file answers WHERE SOMEBODY IS. It answers it by SOLVING, never by integrating:
///
///   `lge_where(person, t)` returns {x, y, face, work, phase, moving, visible}
///
/// computed from the routine and `t` alone. There is no per-frame step, no stored position, no
/// velocity and no arrival test.
///
/// ============================================================================================
/// ⛔ WHY THAT IS THE WHOLE ARCHITECTURE AND NOT A STYLE CHOICE
/// ============================================================================================
///
/// The Gate 2 evidence for this product is four author-confirmed defects in the incumbent, and three
/// of them are one bug:
///
///   "position is re-rolled on map re-entry"     an integrator has nowhere to catch up FROM, so the
///                                               only cheap answer is to re-roll. Here, re-entry is
///                                               `lge_where(person, now)` and costs nothing.
///   "interaction pauses corrupt movement"       a pause shifts the routine's time ORIGIN
///                                               (`lge_routine_pause`) and the solve keeps answering
///                                               the same question. There is no integrator to
///                                               desynchronise.
///   "night-spanning routines break"             time is `t mod LGE_DAY` throughout and a segment
///                                               that wraps midnight is ONE segment with a wrapped
///                                               interval, never two.
///
/// ⚠️ AND THE HONEST COST, STATED HERE RATHER THAN DISCOVERED AT THE GATE: a position that cannot
/// depend on what happened at `t-1` cannot avoid a collision, jostle in a doorway, or queue. A buyer
/// gets determinism, free save/load, free map re-entry and free time-scrubbing, and does NOT get
/// townspeople who walk around each other. That is in the Readme, in these words.
///
/// ============================================================================================
/// TRAVEL, WHICH IS THE ONE PLACE THE SOLVE HAS TO WORK FOR ITS LIVING
/// ============================================================================================
///
/// People must be SEEN to walk to work, or the town teleports at every shift change - which is the
/// single most visible way a schedule system betrays itself. But walking is exactly the thing a pure
/// function is supposed to be bad at.
///
/// ⭐ THE ANSWER IS THAT TRAVEL IS THE HEAD OF A SEGMENT, NOT A STATE BETWEEN SEGMENTS. A segment
/// spends its first `travel` hours walking from the PREVIOUS segment's station to its own, and the
/// position during that window is a straight interpolation between two places both of which are
/// known from the routine. So "walking" is still a closed-form function of (routine, t), and the
/// arrival time is a property of the segment rather than an event anybody has to notice.
///
/// ⚠️ IT IS CAPPED AT A FRACTION OF THE SEGMENT so a five-minute errand cannot be all walk, and it is
/// ZERO when the previous segment is the same place - a person who has not moved does not walk.
///
/// ============================================================================================

/// The LONGEST a walk to work may take, in town hours, however far it is.
#macro LGE_TRAVEL 0.55

/// A walk may never eat more than this fraction of the segment it heads.
#macro LGE_TRAVEL_MAX_FRAC 0.34

/// ⛔⛔ HOW FAST A PERSON WALKS, IN STATURES PER TOWN HOUR - AND ITS ABSENCE WAS A REAL DEFECT.
///
/// Until 2026-09-03 travel time was `min(LGE_TRAVEL, seglen * LGE_TRAVEL_MAX_FRAC)` and took NO
/// ACCOUNT OF DISTANCE, so a two-unit hop to the next stall and a trek across the whole street were
/// allotted exactly the same time. MEASURED on the shipped build: a 76-unit walk was crushed into
/// 0.085 town-hours - **1,343 statures per hour**, a sprint - because the segment heading it was one
/// 15-minute slot. The suite reported it as `nobody teleports inside a segment`, which is what a
/// mis-specified check looks like: `lge_where` returns `lerp(fx, hx, smoothstep(el/travel))` with
/// fx, hx and travel all CONSTANT inside a segment, so position is continuous BY CONSTRUCTION and
/// no teleport was possible. The check was measuring SPEED and calling it discontinuity.
///
/// ⭐ This is the wing's "a physical detail bounded only as a proportion is wrong on the largest
/// thing you draw" law, arriving in the time axis instead of the space axis: a WALK is a physical
/// distance at a physical speed, and expressing its duration as a fraction of a SEGMENT is the same
/// category error as expressing a moulding as a fraction of a door.
///
/// ⛔ CORRECTED 2026-09-03. THIS HEADER USED TO CALL 4.0 "a walk a person can hold all day". THAT IS
/// FALSE, AND THE TOWN'S OWN GEOMETRY REFUTES IT. A stature is a body height, so at 1.7 m a stature:
///
///     4.0 statures/hour = 6.8 METRES an hour      <- not a walk; a snail
///     a human walk      = 5 km/h = 2,941 statures/hour
///
/// This town is about 140 statures end to end, so at 4.0 a cross-town errand would take THIRTY-FIVE
/// HOURS and nobody would ever arrive anywhere. The old text was reasoning about the ON-SCREEN rate
/// at a 60:1 day ("four body-lengths a minute") and then stating it as an IN-FICTION speed. Those
/// are different frames, and mixing them put a false ceiling into the suite: a "nobody gallops"
/// check was set at 600 statures/hour, which is 1.0 km/h - a fifth of an amble - and it failed a
/// perfectly ordinary town on 2026-09-03. See the long note beside that assertion.
///
/// ⭐ WHAT THIS CONSTANT ACTUALLY IS: a DAWDLE FLOOR, and a useful one. It sits inside a `min`, so
/// it can only ever SHORTEN a walk, never lengthen one - it is an upper bound on duration, i.e. a
/// LOWER bound on speed. It binds only under about 2.2 statures (beyond that `dist / 4.0` exceeds
/// the 0.55 h cap and drops out of the `min`), so its whole job is stopping a two-step hop from
/// being allotted a long segment's worth of strolling. That job is real and this value does it.
///
/// ⚠️ DO NOT "FIX" IT BY RAISING IT TO A REAL WALKING SPEED. Because it sits in a `min`, raising it
/// makes EVERY walk shorter, not just the short ones: at 2,941 a 76-stature errand collapses from
/// five town-minutes to ninety seconds, people teleport onto their stations, and the street empties
/// of the walking figures that are half of what this product SHOWS (measured at 11 of 46 walking at
/// 13:24). The visible half is the product. The slow in-fiction speeds are a deliberate consequence
/// and the honest limits section of the Readme is where a buyer is told about the trade.
#macro LGE_WALK_SPEED 4.0

/// The street: stations are placed along x in this band, in town units, with a shallow depth in y.
#macro LGE_STREET_W 12.0

/// ⛔⛔ HOW DEEP THE STREET IS, AND IT WAS 1.6 UNTIL 2026-09-03, WHICH PUT TOWNSPEOPLE IN THE SKY.
///
/// The depth was `LGE_STREET_D * scale * rng(-0.5, +0.5)` - a band CENTRED ON THE HORIZON - and both
/// readers add it straight to the ground line (`_gy = ground_y + _pl.y` in the demo object, and the
/// same line in `lge_bk_street`). So any place that drew a NEGATIVE offset was rendered ABOVE the
/// horizon, standing on nothing. MEASURED on the baked store sheets: at stature 168 the band was
/// +/-134 px against a 200 px ground band, and the hero sheet shipped three stalls and their workers
/// floating a hundred pixels up in the sky. A buyer pressing Play in `rm_lge_demo` saw the same
/// thing, so this was not a store-art bug - it was the product.
///
/// ⭐ THE CATEGORY ERROR: DEPTH IS A WORLD QUANTITY AND THIS RENDERER HAS NO PERSPECTIVE. Nothing
/// scales with distance and nothing recedes, so a world depth of 1.6 statures (about 2.7 m, quite
/// reasonable for a street) can only arrive as raw screen pixels. Expressed that way it is not
/// depth at all, it is a vertical displacement - which is exactly this wing's standing law that a
/// physical detail bounded only as a proportion is wrong on the largest thing you draw, arriving in
/// the depth axis.
///
/// So the depth now HANGS BELOW THE HORIZON (`rng(0, 1)`, never negative - see `lge_town_make`) and
/// is small enough to read as a stagger rather than a displacement. 0.14 statures is about an eighth
/// of a body height: 13 px at the store day-strip's stature of 92, 18 px in the demo room at 132,
/// 23 px on the hero sheet at 168. It fits inside the shallowest ground band any reader draws (the
/// day strip's, 14 px), which is the constraint that sets it - a larger value puts feet through the
/// bottom of a strip, and this file cannot see how tall its readers' bands are.
#macro LGE_STREET_D 0.14

/// The authoring resolution of a generated routine, in hours. Coarser than `lge_routine_check`'s own
/// 0.05 sampling step on purpose: a routine authored to the minute would need that check's step
/// changed, and its header says so.
#macro LGE_SLOT 0.25

/// ============================================================================================
/// THE CYCLE RATE
/// ============================================================================================

/// @desc How many town-hours one work stroke takes. A buyer scaling a day to four real minutes wants
/// a different number from one scaling it to a real day, so it is settable rather than a macro.
///
/// ⚠️ THE PHASE COMES FROM ROUTINE TIME, NOT FROM `current_time`, AND THAT IS DELIBERATE. Driving the
/// pose cycle off the wall clock would leave a paused townsperson hammering on the spot during a
/// conversation - the pause would freeze their position and not their arms, which is worse than not
/// pausing at all.
///
/// ⛔⛔ THE GLOBAL IS `lge_cycle_span` AND THE FUNCTION IS `lge_cycle_hours`, AND THE FIRST DRAFT GAVE
/// THEM THE SAME NAME. In GML a script function and a global variable live in ONE namespace, so
/// `global.lge_cycle_hours = 0.02` OVERWROTE the function with a number, and the next
/// `lge_cycle_hours()` divided by a value that was no longer callable:
///
///     DoDiv :1: Malformed variable   at gml_Script_lge_where
///
/// MEASURED 2026-09-03 by the headless suite, which named stage 85 and the function in a crash file
/// because a GML runtime error otherwise opens a modal nobody can dismiss. ⭐ Note what did NOT catch
/// it: `gm_gate.ps1` compiled all 561 resources with 0 errors and 0 warnings, twice. A name collision
/// between a global and a function is not a compile error in GML - it is a silent overwrite at run
/// time, and the only instrument that can see it is running the thing.
///
/// ⚠️ This is the SECOND collision in this file (the first was `lge_place` against `lge_geom`'s own),
/// and together they are the argument for the namespace rule being mechanical rather than tidy: one
/// was caught by the compiler in seven seconds and one only by executing the product.
function lge_cycle_set(_hours_per_cycle) {
    global.lge_cycle_span = max(0.0005, _hours_per_cycle);
}

function lge_cycle_hours() {
    if (!variable_global_exists("lge_cycle_span")) global.lge_cycle_span = 0.02;
    return global.lge_cycle_span;
}

/// ============================================================================================
/// PLACES
/// ============================================================================================

/// @desc A station standing somewhere. The town's furniture.
///
/// ⛔ NAMED `lge_town_place`, NOT `lge_place`, AND THE FIRST DRAFT WAS THE SHORTER NAME. It failed the
/// engine gate with `duplicate script name found gml_Script_lge_place` in seven seconds - because
/// `lge_geom` already owns `lge_place`, the transform that maps a unit-box part list into form space.
/// ⭐ GML'S FUNCTION NAMESPACE IS FLAT, and that is exactly why this package namespaces everything to
/// `lge_`: a collision inside a BUYER'S project produces the same error in their build, on a name
/// they did not write, and it cannot be debugged remotely. Here the gate caught it in one run; in a
/// buyer's project it is a support ticket. The namespace rule is not tidiness.
function lge_town_place(_work, _x, _y, _seed) {
    var _w = lge_work_spec(_work);
    var _st = is_undefined(_w) ? undefined : lge_station_spec(_w.station);
    return {
        work    : _work,
        station : is_undefined(_w) ? "" : _w.station,
        x       : _x,
        y       : _y,
        seed    : _seed,
        // The ground the prop occupies, in station units, straight from the station's own spec. Kept
        // on the place so the overlap check reads ONE source rather than re-deriving it.
        foot    : is_undefined(_st) ? [0, 0] : _st.foot,
        stand   : is_undefined(_st) ? 0 : _st.stand
    };
}

/// The clear ground between two neighbouring places, in statures, on top of each one's own
/// envelope. It is a STREET, not a museum: village workplaces crowd against each other.
///
/// ⛔ IT IS A COMPOSITION CONSTANT, NOT A SAFETY ONE - places are spaced by their own published
/// envelopes (`lge_work_envelope`), so nothing overlaps at any value of this and the suite's
/// overlap gate is unaffected. **AND NARROWING IT WAS TRIED, MEASURED AND REVERTED 2026-09-04.**
///
/// The reasoning was that a ten-place street runs about 5,100px at the hero's stature while the
/// shot is 1,600px, so tightening the gap would put more trades in the same frame. Baked at 0.14
/// it made the hero WORSE: `lge_bk_street` centres the town in the rect
/// (`_pan = width*0.5 - w*0.5`), so shrinking the town does not pull the far places INTO the shot,
/// it pulls the whole street away from both edges - the frame came back with a group at the left, a
/// group right of centre and empty road across the right third.
///
/// ⭐ The general form: **on a CENTRED pan, the town's width sets the MARGINS, not the density.**
/// A street WIDER than its frame is the correct configuration, which is what `lge_bk_hero`'s own
/// header concluded from the other direction - every pixel of the frame has something in it, and
/// the picture reads as a slice of a longer town rather than a diorama.
#macro LGE_PLACE_GAP 0.30

/// How far apart the members of one household stand at their shared place, in statures.
///
/// ⛔ IT IS A SEPARATE TERM FROM `jostle` AND THAT SEPARATION IS THE POINT. `jostle` is a RANDOM
/// +/-0.16 statures that keeps two people from occupying the same pixel; it is deliberately small,
/// because a lone smith standing half a body-width off their own anvil does not read as working at
/// it. A HOUSEHOLD needs a much bigger spread and a DETERMINISTIC one - three people evenly spaced
/// rather than three random numbers that can land on top of each other - and stretching `jostle` to
/// do both jobs would have moved every lone worker in every buyer's town to fix a picture in ours.
///
/// ⚠️ MEASURED 2026-09-04, which is why there is a number here at all: with `_per_place` raised to 3
/// and only `jostle` spreading them, the hero baked FOUR figures inside one body width at the well -
/// the "one person with four arms" failure `lge_person`'s own jostle comment names, arriving because
/// the offset that prevents it was sized for a pair and not for a household. A figure is about 0.30
/// statures wide, so the slots have to be wider than that or they are not slots.
#macro LGE_HOUSEHOLD_SPREAD 0.44

/// @desc How far off their place's stand point this person stands, in town units.
///
/// ⚠️ `slot` IS READ DEFENSIVELY. A buyer builds their own cast, and this package's own bake sheets
/// build ad-hoc person structs for the catalogue plates; a hard read would throw on every one of
/// them. A person with no slot is a person standing alone, which is the honest default.
function lge_person_offset(_person, _scale) {
    var _slot = variable_struct_exists(_person, "slot") ? _person.slot : 0;
    return (_person.jostle * 0.18 + _slot) * _scale;
}

/// @desc Where a worker stands at a place, in town coordinates.
///
/// ⚠️ THE SCALE FACTOR IS THE FIGURE'S OWN STATURE IN TOWN UNITS, and it is a parameter rather than a
/// constant because a buyer's tile size is not this package's business. `lge_town_make` records it on
/// the town so nothing downstream has to guess.
function lge_place_stand(_place, _scale) {
    return [_place.x + _place.stand * _scale, _place.y];
}

/// ============================================================================================
/// PEOPLE
/// ============================================================================================

/// @desc One townsperson. `trade` is the work loop that defines their day; the routine is generated
/// from it and from the communal loops that fill the gaps.
///
/// ⚠️ BUILD, SKIN AND HAIR ARE DERIVED FROM THE PERSON'S SEED, not authored. Forty-six trades over
/// five builds, four skins and four hair styles is what makes a street look populated rather than
/// cloned, and none of it is a table anybody maintains.
function lge_person(_name, _trade, _seed, _town) {
    var _r = lge_rng(_seed);
    var _builds = lge_builds_all();
    var _hair = lge_hair_styles_all();
    var _p = {
        name    : _name,
        trade   : _trade,
        seed    : _seed,
        build   : lge_rng_pick(_r, _builds),
        skin    : lge_rng_int(_r, 0, 3),
        hairstyle : lge_rng_pick(_r, _hair),
        haircol : lge_rng_int(_r, 0, 3),
        // Where this person stands when they share a station with somebody else. Without it, two
        // people at one well occupy the same pixel and read as one person with four arms.
        jostle  : lge_rng_range(_r, -0.9, 0.9),
        // Which slot of their household they stand in, in statures, 0 for somebody who works their
        // place alone. Set by `lge_town_populate`, which is the only thing that knows how many share
        // a place; see `LGE_HOUSEHOLD_SPREAD`.
        slot    : 0,
        routine : undefined
    };
    _p.routine = lge_routine_for(_p, _town);
    return _p;
}

/// The loops anybody can be doing when their own trade is shut. Every one is a real work loop from
/// the corpus, so nothing here is a special case in the renderer.
///
/// ⚠️ CHOSEN FOR HOUR COVERAGE, NOT FOR VARIETY. Between them these four are open across the whole
/// waking day, which is what lets the generator fill any hole without splitting it.
///
/// ⛔ THAT SENTENCE WAS FALSE FOR THE PRODUCT'S WHOLE LIFE AND IS NOW ASSERTED RATHER THAN ASSUMED.
/// MEASURED 2026-09-03: the union of the four left 5-6, 8-9, 13-14 and 20-21.5 uncovered, and
/// `lge_routine_for` sends an idle slot with no open commons to LGE_AWAY - so at 13:00, with only
/// fourteen of forty-six trades open, up to thirty-two people went indoors at once. The hours of
/// `waterward_draw` and `elder_sit` were widened to close it; `lge_selftest`'s
/// "a commons is open at every waking hour" now fails the build if it reopens. Adding a commons
/// loop, or narrowing one's hours, is therefore a change this suite will check.
function lge_commons_all() {
    return ["waterward_draw", "elder_sit", "herald_read", "priest_bless"];
}

/// @desc Build a routine that tiles the whole day, from a person's trade and the commons.
///
/// ⭐ IT IS BUILT SLOT BY SLOT AND THEN COALESCED, WHICH IS WHY IT CANNOT HAVE A GAP OR AN OVERLAP.
/// The obvious alternative - lay the trade's windows down and then patch the holes - has to reason
/// about wrapped intervals, and `lge_routine`'s own header refuses to silently repair a set that does
/// not tile. Assigning every one of the 96 slots exactly once makes the tiling a property of the
/// construction rather than something to check afterwards. `lge_selftest` checks it anyway, because a
/// property of the construction is a property of THIS construction and a buyer may write their own.
///
/// @param {Struct} _person
/// @param {Struct} _town  may be undefined. When given, a commons loop with no PLACE in this town is
///                        not offered - see the filter below; this is not decoration.
/// @returns {Struct} an lge_routine
function lge_routine_for(_person, _town) {
    var _n = LGE_DAY / LGE_SLOT;
    var _slot = array_create(_n, LGE_AWAY);
    var _r = lge_rng(_person.seed + 977);

    // ⛔ THE COMMONS ARE FILTERED AGAINST THE TOWN, AND THIS IS A REAL DEFECT PREVENTED RATHER THAN A
    // TIDINESS. A buyer placing eight of the forty-six loops gets a town with no well and no shrine;
    // an unfiltered generator would still send people to draw water at 11:30, `lge_where` would find
    // no place for it, and the honest answer it returns is `visible: false` - so a third of the cast
    // would VANISH in the middle of the day, on a product whose whole claim is that people are always
    // somewhere. The parameter existed before the filter did, which is how a prose claim outruns its
    // code; `Internal_Ops/claim_scan.js` is the standing check for that.
    var _commons = [];
    var _cand = lge_commons_all();
    for (var _c = 0; _c < array_length(_cand); _c++) {
        if (is_undefined(_town) || !is_undefined(lge_town_place_of(_town, _cand[_c]))) {
            array_push(_commons, _cand[_c]);
        }
    }

    for (var _i = 0; _i < _n; _i++) {
        var _t = _i * LGE_SLOT;
        if (lge_work_open(_person.trade, _t)) { _slot[_i] = _person.trade; continue; }
        // Night belongs to sleep even when a commons loop is technically open - the watch's brazier
        // burns all night and a town where everyone loiters at it until dawn is not a town.
        if (_t >= 21.5 || _t < 5.0) { _slot[_i] = LGE_AWAY; continue; }
        // Otherwise the first commons loop open at this hour, chosen from a per-person rotation so
        // two people with the same trade do not shadow each other all day.
        //
        // ⚠️ THE EMPTY CASE IS REAL AND IS HANDLED HERE RATHER THAN INSIDE THE RNG. A town placing
        // only trades the buyer cares about can filter every commons loop away, and
        // `lge_rng_int(r, 0, -1)` on an empty list is a silent nonsense index rather than an error.
        // The honest answer with nowhere to go is to be indoors.
        var _ncom = array_length(_commons);
        if (_ncom == 0) { _slot[_i] = LGE_AWAY; continue; }
        // ⛔⛔ THE NEAREST OPEN COMMONS, NOT A RANDOM ONE - AND THE RANDOM VERSION WAS MAKING PEOPLE
        // SPRINT.
        //
        // This used to pick a per-person rotation offset and take the first open loop from there,
        // which sends somebody to whichever commons the dice named however far away it is. A commons
        // slot is one quarter-hour, and `lge_where` caps a walk at a third of the segment it heads,
        // so an errand to the far end of the street had 0.085 town-hours to cover it. MEASURED
        // 2026-09-03: 1,410 statures per hour, on a corpus whose people are supposed to be walking.
        //
        // ⚠️ AND KEYING THE WALK'S DURATION ON DISTANCE DID NOT FIX IT, WHICH IS THE USEFUL PART.
        // `LGE_WALK_SPEED` correctly stops a two-step hop taking five minutes, but the segment-length
        // cap still binds on a long walk, so the sprint survived and the suite's speed assertion said
        // so. The distance had to stop being long: a person goes to the well they are NEXT TO.
        //
        // The rotation is kept as a TIE-BREAK so two people who share a nearest commons do not shadow
        // each other all day, which is what it was there for. Distance is measured to the person's
        // own trade place, because that is where they are coming from.
        var _off = lge_rng_int(_r, 0, _ncom - 1);
        var _got = LGE_AWAY;
        var _best = 999999;
        var _home = is_undefined(_town) ? undefined : lge_town_place_of(_town, _person.trade);
        for (var _j = 0; _j < _ncom; _j++) {
            var _c = _commons[(_off + _j) mod _ncom];
            if (!lge_work_open(_c, _t)) continue;
            // With no town to measure against, the rotation alone decides - the old behaviour, and
            // the only honest answer when there are no places to be near.
            if (is_undefined(_home)) { _got = _c; break; }
            var _cp = lge_town_place_of(_town, _c);
            if (is_undefined(_cp)) continue;
            var _d = abs(_cp.x - _home.x);
            if (_d < _best) { _best = _d; _got = _c; }
        }
        _slot[_i] = _got;
    }

    // Coalesce equal adjacent runs, then close the wrap: if the last run and the first run are the
    // same loop they are ONE segment spanning midnight, which is precisely the shape the incumbent
    // gets wrong and the shape `lge_seg` is built for.
    var _segs = [];
    var _start = 0;
    for (var _i = 1; _i <= _n; _i++) {
        if (_i == _n || _slot[_i] != _slot[_start]) {
            array_push(_segs, lge_seg(_slot[_start], _start * LGE_SLOT, (_i mod _n) * LGE_SLOT));
            _start = _i;
        }
    }
    if (array_length(_segs) > 1) {
        var _first = _segs[0];
        var _last = _segs[array_length(_segs) - 1];
        if (_first.work == _last.work) {
            _last.to = _first.to;
            array_delete(_segs, 0, 1);
        }
    }
    return lge_routine(_person.name, _segs);
}

/// ============================================================================================
/// THE TOWN
/// ============================================================================================

/// @desc Build a town: place stations along the street, then put people in it.
///
/// ⛔ THE PLACES ARE SPREAD BY THEIR OWN FOOTPRINTS, NOT BY AN EVEN DIVISION OF THE STREET. A stall
/// occupies 0.72 of a stature and a churn 0.28; an even spread either overlaps the wide ones or
/// leaves the narrow ones stranded in a gap. Walking the list and advancing by each prop's declared
/// footprint plus a gap is what makes the street look built. The overlap gate in `lge_selftest`
/// asserts the result rather than trusting this loop.
///
/// @param {Real} _seed
/// @param {String} _theme     an id from lge_themes_all()
/// @param {Real} _scale       one stature, in the buyer's town units
/// @param {Array} _works      which work loops to place, in order. Undefined = the whole corpus.
/// @returns {Struct}
function lge_town_make(_seed, _theme, _scale, _works) {
    var _list = is_undefined(_works) ? lge_works_all() : _works;
    var _r = lge_rng(_seed);
    var _places = [];
    var _x = 0;
    for (var _i = 0; _i < array_length(_list); _i++) {
        var _w = lge_work_spec(_list[_i]);
        if (is_undefined(_w)) continue;
        var _st = lge_station_spec(_w.station);
        if (is_undefined(_st)) continue;
        // ⛔ SPACED BY THE PUBLISHED ENVELOPE, NOT BY A LOCAL RE-DERIVATION. `lge_work_envelope` is
        // the single source for how much ground a work loop occupies, and the containment gate in
        // `lge_selftest` asserts the DRAWN bounds against the same function. A local `max(foot,
        // stand)` here - which is what the first version did - would mean the placer and the gate
        // were checking two different numbers, so a tool reaching past its neighbour's stall could
        // satisfy both. One function, two readers.
        var _env = lge_work_envelope(_list[_i]);
        if (is_undefined(_env)) continue;
        var _halfw = max(abs(_env[0]), abs(_env[1]));
        _x += _halfw * _scale;
        // ⛔ PUSHED, NEVER ASSIGNED BY INDEX. `_places[_i] = ...` after a `continue` leaves GML's own
        // fill value (0, not undefined) in the skipped slots, so every downstream `is_undefined`
        // guard reads false and the next line dereferences a number. Pushing removes the hole class
        // instead of guarding against it, and the index is no longer load-bearing anyway - places are
        // found by their work loop (`lge_town_place_of`), not by position.
        // ⛔ `lge_rng_range(_r, 0, 1)`, NEVER `-0.5, 0.5`. A place's y is added to the caller's
        // GROUND LINE, so a negative offset is a station standing above the horizon. See
        // LGE_STREET_D's note: that is exactly what shipped in the first bake of this product.
        // The far edge of the street is y = 0, the near edge is y = LGE_STREET_D * scale, and the
        // depth sort in every reader still works because it only compares these values to each other.
        array_push(_places, lge_town_place(_list[_i], _x,
                                      LGE_STREET_D * _scale * lge_rng_range(_r, 0, 1),
                                      _seed + _i * 131 + 7));
        _x += (_halfw + LGE_PLACE_GAP) * _scale;
    }
    var _town = {
        seed   : _seed,
        theme  : _theme,
        scale  : _scale,
        places : _places,
        width  : _x,
        people : []
    };
    return _town;
}

/// @desc Put people into the town: `_per_place` of them at each placed trade.
///
/// ⚠️ SEPARATE FROM `lge_town_make` because a buyer with their own cast wants the places and not the
/// people, and a demo wants both. Returns the town so a caller can chain.
///
/// ⛔⛔ `_per_place` EXISTS BECAUSE ONE-WORKER-PER-STATION IS NOT A TOWN, AND THE HERO SHEET SPENT
/// FOUR BAKES PROVING IT. MEASURED 2026-09-04: with exactly one person per place, the number of
/// people in a street is FIXED BY ITS FURNITURE, so density can only be bought by adding places -
/// which widens the street and shrinks the figures, which is what made the shipped hero 70% empty
/// sky. Every other lever was tried and none of them is the lever: the hour was swept over 5..20
/// against four different objectives (a typed hour, open trades, workers anywhere, workers in
/// frame), the trade list was re-picked twice, and the stature was moved three times. The previous
/// session recorded the diagnosis in `lge_bk_hero`'s own header and stopped there, because it is a
/// PRODUCT change rather than a bake change: *"making the street genuinely busy needs a denser town
/// - more people than places, which lge_town_populate cannot currently express."*
///
/// ⭐ IT IS A HOUSEHOLD, WHICH IS WHY IT NEEDS NO NEW MACHINERY AT ALL. A village trade is worked by
/// a family: a smith and two who fetch and hold. They share the trade, so they share its routine and
/// its opening hours; they differ by seed, so `lge_person` already gives them their own build, skin,
/// hair, dye and - decisively - their own `jostle`, the lateral offset that field's own header says
/// exists "when they share a station with somebody else". The capability was in the person and only
/// the population was capped.
///
/// ⚠️ THE DEFAULT IS 1 AND THE ONE-PER-PLACE PATH IS BIT-FOR-BIT UNCHANGED - `_ix` collapses to `_i`,
/// so the names and the seeds are identical numbers, not merely equivalent ones. Every existing
/// caller, every assertion about a 46-person town, and every sheet that draws one is untouched.
///
/// @param {Struct} _town
/// @param {Array|Undefined} _names   optional names, indexed over the whole cast
/// @param {Real|Undefined} _per_place  household size; undefined or <1 means 1
function lge_town_populate(_town, _names, _per_place) {
    var _k = is_undefined(_per_place) ? 1 : max(1, floor(_per_place));
    var _n = array_length(_town.places);
    for (var _i = 0; _i < _n; _i++) {
        var _pl = _town.places[_i];
        if (is_undefined(_pl)) continue;
        for (var _h = 0; _h < _k; _h++) {
            var _ix = _i * _k + _h;
            var _nm = (!is_undefined(_names) && _ix < array_length(_names)) ? _names[_ix]
                                                                           : (_pl.work + "#" + string(_ix));
            var _pp = lge_person(_nm, _pl.work, _town.seed + _ix * 7919 + 31, _town);
            // ⛔⛔ THE SLOT CYCLES OVER THE WHOLE CAST, NOT OVER THE HOUSEHOLD, AND THE FIRST VERSION
            // KEYED IT ON THE HOUSEHOLD AND WAS WRONG FOR THE CASE THAT ACTUALLY BITES.
            //
            // A household's members are only together at their OWN place. The crowd that has to be
            // separated is the one at a COMMONS: `lge_routine_for` sends everybody whose trade is
            // shut to the well or the bench, so at 05:30 people from four different trades converge
            // on one prop. Keyed on `_h`, all the first-borns shared one offset and all the seconds
            // another - MEASURED 2026-09-04 on `sheet_1_the_day`, eight figures stacked in two
            // columns at the well. An offset that separates a group only separates the group it is
            // KEYED ON, and this one was keyed on the group that is never the problem.
            //
            // ⚠️ FIVE SLOTS RATHER THAN A HASH: a hash gives collisions, and two people at exactly
            // the same offset is the failure this exists to prevent. Cycling guarantees that any run
            // of five consecutive people occupies five distinct positions.
            // ⚠️ STILL EXACTLY 0 WHEN `_k` IS 1, which is what keeps the one-per-place path
            // bit-for-bit identical for every buyer and every existing sheet.
            _pp.slot = (_k > 1) ? (((_ix mod 5) - 2) * LGE_HOUSEHOLD_SPREAD * 0.55) : 0;
            // ...and they do not all dye their cloth in the same pot. Member 0 keeps the trade's own
            // dye, so the one-per-place path is unchanged here too; the rest step along the wheel.
            _pp.dye = (lge_dye_of(_pl.work) + _h) mod LGE_DYES;
            array_push(_town.people, _pp);
        }
    }
    return _town;
}

/// @desc The place a work loop stands at in this town, or undefined.
///
/// ⚠️ LINEAR, AND THAT IS A DELIBERATE REFUSAL TO CACHE. A lookup struct built at town creation would
/// be a second copy of the places array, and this wing has a measured law about a fact stored twice.
/// Forty-six places scanned once per person per frame is nothing; if a buyer ever places thousands,
/// the honest fix is for THEM to index it, and the Readme says so.
function lge_town_place_of(_town, _work) {
    for (var _i = 0; _i < array_length(_town.places); _i++) {
        var _p = _town.places[_i];
        if (!is_undefined(_p) && _p.work == _work) return _p;
    }
    return undefined;
}

/// ============================================================================================
/// THE SOLVE
/// ============================================================================================

/// @desc Which segment precedes segment `_i` in a routine, wrap-safe.
function lge_seg_prev(_routine, _i) {
    var _n = array_length(_routine.segs);
    if (_n == 0) return undefined;
    // The segments are built in clock order by `lge_routine_for`, but a buyer's hand-authored routine
    // need not be - so the predecessor is found by WHOSE `to` MATCHES THIS `from`, not by index.
    // ⛔ An index-based predecessor is correct for our generator and silently wrong for theirs, which
    // is the shape of defect that only ever shows up in a buyer's project.
    var _me = _routine.segs[_i];
    for (var _j = 0; _j < _n; _j++) {
        if (_j == _i) continue;
        if (abs(_routine.segs[_j].to - _me.from) < 0.0001) return _routine.segs[_j];
    }
    // No exact predecessor: a routine with a gap, which `lge_routine_check` reports. Falling back to
    // the index before keeps the solve total rather than returning undefined into a renderer.
    return _routine.segs[(_i - 1 + _n) mod _n];
}

/// @desc WHERE SOMEBODY IS. The product's one structural claim, in one function.
///
/// @param {Struct} _town
/// @param {Struct} _person
/// @param {Real} _t   world time in hours, any sign
/// @returns {Struct} {x, y, face, work, phase, moving, visible, seg}
///          face   -1 or +1: which way the figure looks along x
///          phase  0..1 into the work cycle, or into the walk when `moving`
///          visible false when the person is off-map (`LGE_AWAY`)
function lge_where(_town, _person, _t) {
    var _rt = _person.routine;
    var _tt = lge_routine_time(_rt, _t);
    var _n = array_length(_rt.segs);
    var _idx = -1;
    for (var _i = 0; _i < _n; _i++) {
        if (lge_seg_contains(_rt.segs[_i], _tt)) { _idx = _i; break; }
    }
    if (_idx < 0) {
        // A routine with a hole. Reported by `lge_routine_check` and asserted against in the suite;
        // here the honest answer is "off map", not a plausible position.
        return { x: 0, y: 0, face: 1, work: LGE_AWAY, phase: 0, moving: false, visible: false, seg: undefined };
    }
    var _seg = _rt.segs[_idx];
    var _w = lge_work_spec(_seg.work);
    var _el = lge_forward(_seg.from, _tt);              // hours into the segment
    var _len = lge_seg_length(_seg);

    if (is_undefined(_w) || !_w.visible) {
        return { x: 0, y: 0, face: 1, work: LGE_AWAY, phase: 0, moving: false, visible: false, seg: _seg };
    }

    var _pl = lge_town_place_of(_town, _seg.work);
    if (is_undefined(_pl)) {
        return { x: 0, y: 0, face: 1, work: _seg.work, phase: 0, moving: false, visible: false, seg: _seg };
    }
    var _here = lge_place_stand(_pl, _town.scale);
    var _off = lge_person_offset(_person, _town.scale);
    var _hx = _here[0] + _off;
    var _hy = _here[1];

    // The walk. Zero when the previous segment is the same place, and capped so a short errand is
    // not all travel.
    var _prev = lge_seg_prev(_rt, _idx);
    var _travel = 0;
    var _fx = _hx, _fy = _hy;
    if (!is_undefined(_prev) && _prev.work != _seg.work) {
        var _pw = lge_work_spec(_prev.work);
        if (!is_undefined(_pw) && _pw.visible) {
            var _ppl = lge_town_place_of(_town, _prev.work);
            if (!is_undefined(_ppl)) {
                var _from = lge_place_stand(_ppl, _town.scale);
                _fx = _from[0] + lge_person_offset(_person, _town.scale);
                _fy = _from[1];
            }
        } else {
            // Coming from off-map: walk in from the near end of the street, so a morning shift
            // change reads as people ARRIVING rather than appearing.
            _fx = (_hx < _town.width * 0.5) ? -_town.scale * 1.5 : _town.width + _town.scale * 1.5;
            _fy = _hy;
        }

        // ⛔ THE WALK'S DURATION COMES FROM ITS DISTANCE. See LGE_WALK_SPEED's note: this line used
        // to read `min(LGE_TRAVEL, _len * LGE_TRAVEL_MAX_FRAC)` and never looked at how far the
        // person had to go, so a two-unit hop and a 76-unit trek were allotted the same time - the
        // hop crawled and the trek sprinted at 1,343 statures an hour. It MUST be computed here,
        // after `_fx`/`_fy` are resolved, because until then there is no distance to key on.
        //
        // The two caps still bind and are still the right shape: a walk may not exceed LGE_TRAVEL in
        // absolute terms, nor eat more than LGE_TRAVEL_MAX_FRAC of the segment it heads. A distance
        // of zero yields a travel of zero, so "a person who has not moved does not walk" is now a
        // property of the arithmetic rather than a separate branch.
        var _dist = point_distance(_fx, _fy, _hx, _hy) / max(0.0001, _town.scale);
        _travel = min(LGE_TRAVEL, _len * LGE_TRAVEL_MAX_FRAC, _dist / LGE_WALK_SPEED);
    }

    if (_travel > 0 && _el < _travel) {
        var _u = _el / _travel;
        // Eased at both ends: a walk that starts and stops at full speed is a slide. `lge_swell`
        // is the corpus's own there-and-back easing; here only its first half is wanted, so the
        // smoothstep is written out.
        var _e = _u * _u * (3 - 2 * _u);
        var _wx = lerp(_fx, _hx, _e);
        var _wy = lerp(_fy, _hy, _e);
        return {
            x: _wx, y: _wy,
            face: (_hx >= _fx) ? 1 : -1,
            work: _seg.work,
            // The walk's own cycle, so a stride can be driven from it.
            phase: lge_frac(_el / max(0.0001, lge_cycle_hours() * 2.0)),
            moving: true, visible: true, seg: _seg
        };
    }

    // At the station.
    var _wt = _el - _travel;
    return {
        x: _hx, y: _hy,
        // `face` is which way the figure looks along x. A worker facing "in" turns toward the
        // station, which is at the place's own x; the sign of the stand offset therefore decides it.
        face: (_w.face == "in") ? ((_pl.stand <= 0) ? 1 : -1) : ((_pl.stand <= 0) ? -1 : 1),
        work: _seg.work,
        phase: lge_frac(_wt / lge_cycle_hours()),
        moving: false, visible: true, seg: _seg
    };
}

/// @desc Fractional part, always in [0,1).
///
/// ⛔ NOT `frac()`. GML's `frac` keeps the sign of its argument, so `frac(-0.25)` is -0.25 and a
/// phase derived from it indexes the far end of a cycle - the same trap `lge_wrap` exists for one
/// level up. Every phase in this product goes through here.
///
/// ⚠️ AND IT IS NAMESPACED, like every other function, macro and global in this package. GML's
/// function namespace is FLAT: a helper called `frac_pos` in a shipped asset is a name a buyer cannot
/// use in their own project, and a collision inside somebody else's game is a support ticket that
/// cannot be debugged remotely. The first draft of this file called it `frac_pos`.
function lge_frac(_v) {
    var _f = _v - floor(_v);
    return (_f < 0) ? (_f + 1) : _f;
}

/// @desc Everybody who is visible at time `_t`, with their solved position. The function a buyer's
/// draw event calls once per frame.
///
/// ⚠️ RETURNS A NEW ARRAY EVERY CALL and says so, because the alternative is a cached list that goes
/// stale exactly when the clock is scrubbed - which is the one thing this product is for.
function lge_town_visible(_town, _t) {
    var _out = [];
    for (var _i = 0; _i < array_length(_town.people); _i++) {
        var _p = _town.people[_i];
        var _at = lge_where(_town, _p, _t);
        if (_at.visible) array_push(_out, { person: _p, at: _at });
    }
    return _out;
}

/// @desc How many people are at each place at time `_t`. Used by the coverage gate, and by the demo's
/// caption - "nine of twenty-two working" is the sentence the whole product exists to make true.
function lge_town_census(_town, _t) {
    var _working = 0;
    var _walking = 0;
    var _away = 0;
    for (var _i = 0; _i < array_length(_town.people); _i++) {
        var _at = lge_where(_town, _town.people[_i], _t);
        if (!_at.visible) _away++;
        else if (_at.moving) _walking++;
        else _working++;
    }
    return { working: _working, walking: _walking, away: _away,
             total: array_length(_town.people) };
}
