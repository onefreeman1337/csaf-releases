/// ============================================================================================
/// LIEGE — THE STORE SHEETS, BAKED BY THE PRODUCT
/// ============================================================================================
///
/// Liege - The NPC Day. Copyright (c) 2026 Core Systems Asset Factory.
///
/// ⛔⛔ EVERY IMAGE IN THE GALLERY IS RENDERED THROUGH THE PRODUCT'S OWN PUBLIC DRAW FUNCTIONS, AND
/// THAT IS A CORRECTNESS RULE RATHER THAN A CONVENIENCE. A gallery rendered by a side previewer is a
/// picture of a re-implementation: this wing has a measured, shipped case where a defect was
/// invisible in a JavaScript previewer and plainly visible in engine. So `Liege.exe -bake` runs the
/// real thing, calls `lge_station_parts`, `lge_figure_parts`, `lge_render_work` and `lge_pal` exactly
/// as a buyer's game would, and `surface_save`s the result.
///
/// ⚠️ AND WHAT THAT STILL CANNOT DO IS JUDGE THE PICTURE. Each sheet is measured for INK COVERAGE and
/// for CLIPPING, which catches an empty plate and a sheet that ran off its own edge - both real
/// defects, neither of them beauty. A sibling product in this wing shipped 689 green assertions over
/// six defects that were found only by opening the PNGs and looking at them, and one of those was a
/// head not attached to a body. **Bake, then open every file and look.**
///
/// ============================================================================================
/// WHY THE SHEETS ARE THESE SHEETS
/// ============================================================================================
///
/// The product's claim has three parts and the gallery has to carry all three, because a buyer
/// scrolling a store page reads pictures and not paragraphs:
///
///   "a town of people at work"      -> hero, the street
///   "the day CHANGES the town"      -> the day (one street at four hours), routine (one person's
///                                      whole day as a track)
///   "forty-six of them, generated"  -> the work loops grid, the stations grid, poses, builds, themes
///
/// ⭐ THE VOLUME SHEETS ARE THE ONES THAT SELL THIS CATEGORY AND THEY ARE THE EASIEST TO GET WRONG.
/// Wing doctrine: the volume IS the moat, and a grid of forty-six cells that all look alike argues
/// the opposite of what it is there to prove. So the grid sheets draw the REAL corpus, one cell per
/// entry, at a size where a buyer can tell them apart - and the suite's distinctness gates exist so
/// that picture is not a coincidence.
///
/// ============================================================================================

#macro LGE_SHEET_W 1600
#macro LGE_SHEET_H 1000
#macro LGE_STRIP_H 1120
#macro LGE_COVER_W  630
#macro LGE_COVER_H  500

/// ⛔ THE SCENE SHEETS ARE SHORTER THAN THE GRID SHEETS, AND THAT IS THE FIX FOR A REAL DEFECT.
///
/// A street is a horizontal subject about one stature tall; a 46-cell grid is a tall one. They were
/// sharing `LGE_SHEET_H` / `LGE_STRIP_H`, so the first baked gallery gave the hero a 1600x1000 frame
/// in which the town occupied the bottom fifth and roughly SIXTY PERCENT of the image was blank sky
/// gradient - on the sheet whose whole job is to say "this is a town of people at work". The four
/// theme strips and the four day strips had the same hole in each band.
///
/// ⚠️ THE OBVIOUS FIX - bigger figures - IS MEASURABLY WRONG HERE, which is why these are heights and
/// not statures. Town width scales with stature, and `lge_bk_street` shows a fixed 1600 px window of
/// it: at the current 168 the window holds about five trades, and at 240 it holds fewer than three.
/// Raising the stature to fill the frame EMPTIES the street, so the sky is removed by cropping the
/// frame instead.
///
/// ⛔ Do NOT point the grid sheets at these. `sheet_2_work_loops` and `sheet_3_stations` need every
/// one of their 46 cells legible, and that is what the taller `LGE_STRIP_H` buys.
///
/// ⛔⛔ 660 WAS STILL 40% SKY AND THE CROP WAS NOT TAKEN FAR ENOUGH. MEASURED 2026-09-04 off the
/// shipped `sheet_0_hero.png` by arithmetic against this file's own layout, not by eye:
///
///     caption band          0 .. 120
///     horizon    0.88 * 660 = 581
///     heads      581 - LGE_HERO_STATURE = 381
///     ⇒ EMPTY SKY 120 .. 381 = 261px = 40% of the frame, in one unbroken band
///
/// The Gate 1 review called this "the worst sheet in the set ... roughly 70% flat sky and flat
/// ground". The block above already names the correct lever and gives the reason the obvious one is
/// wrong: raising the stature widens the town and EMPTIES the street, so the sky comes off by
/// cropping the frame. It was cropped 1000 -> 660 and the band above is what was left.
///
/// At 470 the same arithmetic gives horizon 414, heads 214, and 94px of sky - which is the sky a
/// photograph of a street actually has. The figures go from 30% of the frame's height to 43% without
/// one pixel of the town changing, because nothing here touches the street at all.
///
/// ⚠️ 94px IS A FLOOR, NOT SLACK. The props are taller than the people (an oven is 0.58 statures
/// over its own base) and the caption band is fixed, so cropping further starts cutting roofs into
/// the title. The bake's ink-bounds check reports the real extent every run - read it, do not
/// re-derive this by eye.
/// ⛔⛔ AND THE "BIGGER FIGURES ARE MEASURABLY WRONG" ARGUMENT ABOVE IS NOW STALE, WHICH IS WHY THE
/// STATURE MOVED 200 -> 300 IN THE SAME EDIT AS THIS HEIGHT. That argument is exact and it rests on
/// one premise: *"raising the stature widens the town and EMPTIES the street"* - true when
/// `lge_town_populate` seated exactly ONE person per place, because then the number of people in a
/// window was the number of PROPS in it and a wider town put fewer of both in frame. With a
/// household at each place (and the one-actor-per-prop cap gone from `lge_bk_street`'s draw loop) a
/// narrower window still has people in it, so the trade is no longer size-against-population - it is
/// size against how many TRADES are shown, and three trades drawn large is a better photograph than
/// five drawn small. The old reasoning is kept above because it was correct against its own model
/// and because the next session will otherwise re-derive it.
///
/// ⚠️ AT 560 WITH A 300 STATURE the arithmetic this file insists on runs: horizon 0.88*560 = 493,
/// heads 493-300 = 193, caption band ends at 120 ⇒ 73px of sky. That is a FLOOR and the props are
/// what will hit it first (an oven is 0.58 statures over its base = 174px), so read the bake's
/// ink-bounds row rather than re-deriving this by eye.
#macro LGE_HERO_H   560
#macro LGE_SCENE_H  860

/// The plate. A dark page rather than white: every material in this product is a mid-value mass, and
/// on white the whole corpus reads as a set of silhouettes.
function lge_bk_page() { return lge_oklch(0.150, 0.012, 262); }
function lge_bk_ink()  { return lge_oklch(0.910, 0.010, 262); }
function lge_bk_dim()  { return lge_oklch(0.580, 0.013, 262); }
function lge_bk_rule() { return lge_oklch(0.305, 0.015, 262); }
function lge_bk_well_col() { return lge_oklch(0.196, 0.011, 262); }

/// ============================================================================================
/// PLATE FURNITURE
/// ============================================================================================

/// @desc The title block. Returns the y below it.
function lge_bk_head(_title, _sub, _y, _w) {
    lge_text_fit(_title, 54, _y, _w - 108, 62, lge_bk_rule(), lge_bk_ink());
    var _y2 = _y + 72;
    lge_text_line(_sub, 56, _y2, _w - 112, 24, lge_bk_dim(), false);
    var _y3 = _y2 + 38;
    draw_set_colour(lge_bk_rule());
    draw_rectangle(54, _y3, _w - 54, _y3 + 2, false);
    return _y3 + 20;
}

/// @desc A recessed panel for a group of cells.
function lge_bk_well(_x, _y, _w, _h) {
    draw_set_colour(lge_bk_well_col());
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);
    draw_set_colour(lge_bk_rule());
    draw_rectangle(_x, _y, _x + _w, _y + 1, false);
    draw_rectangle(_x, _y + _h - 1, _x + _w, _y + _h, false);
}

/// @desc A caption under a cell. Returns the y below it.
function lge_bk_caption(_text, _x, _y, _w) {
    lge_text_line(_text, _x, _y, _w, 17, lge_bk_dim(), false);
    return _y + 22;
}

/// @desc A contact shadow, so a figure stands on the plate rather than floating over it.
///
/// ⚠️ THREE FLATTENED ELLIPSES, NOT AN ALPHA BLOB. `draw_vertex_colour` carries its own alpha and
/// ignores `draw_set_alpha` (a measured row in this wing), and a translucent blob reads as a smudge
/// at gallery size anyway. Three opaque ellipses at descending lightness ARE the gradient - painter's
/// order is the gradient when the layers are opaque.
function lge_bk_shadow(_cx, _y, _w) {
    var _t = [0.130, 0.165, 0.205];
    var _k = [1.00, 0.68, 0.40];
    for (var _i = 0; _i < 3; _i++) {
        draw_set_colour(lge_oklch(_t[_i], 0.010, 262));
        draw_ellipse(_cx - _w * _k[_i], _y - _w * _k[_i] * 0.17,
                     _cx + _w * _k[_i], _y + _w * _k[_i] * 0.17, false);
    }
}

/// @desc The ink bounding box over the current render target.
///
/// ⛔ THE ROW STEP IS 1 AND THE COLUMN STEP IS 2. A stride-2 scan in BOTH axes cannot see a 1px
/// horizontal hairline on an odd row, and this product draws a lot of them - every incised line, every
/// hoop and every rule on these plates is one. Halving the work in the axis where it is safe and not
/// in the axis where it is not is the whole reason the steps differ.
function lge_bk_ink_bounds(_w, _h, _contentY, _reuse) {
    var _own = is_undefined(_reuse) || !buffer_exists(_reuse);
    var _buf = _own ? buffer_create(_w * _h * 4, buffer_fixed, 1) : _reuse;
    buffer_get_surface(_buf, surface_get_target(), 0);
    var _pg = lge_bk_page();
    var _pr = colour_get_red(_pg), _pgn = colour_get_green(_pg), _pb = colour_get_blue(_pg);

    var _fx0 = _w, _fy0 = _h, _fx1 = -1, _fy1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;
    var _ink = 0;

    for (var _y = 0; _y < _h; _y++) {
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = (_y * _w + _x) * 4;
            var _r = buffer_peek(_buf, _o, buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_r - _pr) <= 10 && abs(_g - _pgn) <= 10 && abs(_b - _pb) <= 10) continue;
            _ink += 1;
            if (_x < _fx0) _fx0 = _x;
            if (_x > _fx1) _fx1 = _x;
            if (_y < _fy0) _fy0 = _y;
            if (_y > _fy1) _fy1 = _y;
            if (_y >= _contentY) {
                if (_x < _cx0) _cx0 = _x;
                if (_x > _cx1) _cx1 = _x;
                if (_y < _cy0) _cy0 = _y;
                if (_y > _cy1) _cy1 = _y;
            }
        }
    }
    if (_own) buffer_delete(_buf);
    return { full: [_fx0, _fy0, _fx1, _fy1], content: [_cx0, _cy0, _cx1, _cy1], ink: _ink };
}

/// ============================================================================================
/// A WORK LOOP INTO A CELL
/// ============================================================================================

/// @desc One work loop - prop, worker, tool, clothes - as ONE part list in station space.
///
/// ⛔ THE FIGURE IS OFFSET BY THE STATION'S OWN `stand`, WHICH IS THE ONLY THING THAT MAKES THESE
/// CELLS TRUE. Every station in the corpus declares where the worker stands, and all forty-six of
/// those numbers are negative - the worker is to the LEFT of their prop. A cell that centred both on
/// the same point would draw a smith standing inside his anvil, which is not a picture of this
/// product.
///
/// ⚠️ AND THE ORDER IS THE TEN-STEP ORDER `lge_render_work` DOCUMENTS, flattened: station back, the
/// whole figure, station front. Flattening is safe here and only here, because a cell is a single
/// static composition rather than a moving scene.
///
/// @param {String} _work
/// @param {Real} _phase
/// @param {Real} _seed
/// @param {Struct} _person   may be undefined; a default average townsperson is used
/// @returns {Array} part list in station space
function lge_bk_pair_parts(_work, _phase, _seed, _person) {
    var _w = lge_work_spec(_work);
    if (is_undefined(_w) || !_w.visible) return [];
    var _sp = lge_station_spec(_w.station);
    if (is_undefined(_sp)) return [];
    var _who = is_undefined(_person)
        ? { name: "bake", trade: _work, seed: _seed, build: "average", skin: 1,
            hairstyle: "crop", haircol: 1, jostle: 0, routine: undefined }
        : _person;

    var _st = lge_station_parts(_w.station, _seed);
    var _fig = lge_figure_parts(_who, _work, _phase, false, (_w.face == "in") ? 1 : -1);

    var _out = [];
    lge_append(_out, _st.back);
    lge_append(_out, lge_offset_parts(_fig.back, _sp.stand, 0));
    lge_append(_out, lge_offset_parts(_fig.main, _sp.stand, 0));
    lge_append(_out, _st.front);
    return _out;
}

/// @desc Draw one work loop into a rect, tight to its own bounds. Returns the part count.
///
/// ⛔ RETURNS A COUNT, NOT A VERDICT (master §2b rule 2). A bake report that says "drew 46 cells"
/// while every cell drew zero parts is the exact shape this wing keeps recording; a count is the only
/// thing that tells the two apart, and the report prints it.
function lge_bk_cell(_pal, _work, _phase, _seed, _x, _y, _w, _h, _person) {
    var _parts = lge_bk_pair_parts(_work, _phase, _seed, _person);
    if (array_length(_parts) == 0) return 0;
    var _b = lge_render_bounds(_parts);
    var _fit = lge_render_fit_parts(_parts, _x, _y, _w, _h);
    // The contact shadow goes under the prop's own floor line, mapped through the same fit the parts
    // will use - so it lands on the ground rather than at the bottom of the cell.
    var _gy = _fit.cy + (LGE_SOLE - (_b[1] + _b[3]) * 0.5) * _fit.s;
    lge_bk_shadow(_fit.cx, _gy, _w * 0.30);
    lge_render_in_rect_tight(_parts, _pal, _x, _y, _w, _h, undefined);
    global.lge_bk_drawn += array_length(_parts);
    return array_length(_parts);
}

/// ============================================================================================
/// A STREET
/// ============================================================================================

/// @desc Draw a real town, at a real hour, into a rect. The function the hero, the day and the theme
/// sheets all share.
///
/// ⭐ IT BUILDS A TOWN AND CALLS `lge_where`, rather than posing figures by hand. A hero image posed
/// by the bake would be a picture of the bake's opinion of the product; this one is a picture of what
/// a buyer's game does at 07:00, including who is walking and who has gone indoors.
///
/// @returns {Struct} {parts, census}
/// ⛔ CLIPPED TO ITS OWN RECT SINCE 2026-09-03. This function draws a street in ABSOLUTE surface
/// coordinates and the town is far wider than any panel it is asked to fill, so on every sheet that
/// puts the street inside a well - the day strips, the cycle sheet - the leftmost oven and the
/// rightmost stalls were painted OUTSIDE the panel, over the page margin and off the sheet edge.
/// MEASURED on the first baked gallery: `sheet_1_the_day.png` carried a half-drawn oven at x=0 in
/// all four strips, 54 px left of the panel that was supposed to contain it.
///
/// `_clipY` / `_clipH` are the caller's band. They are passed explicitly rather than inferred from
/// the surface, because a scene that legitimately bleeds (the hero) and one that must be contained
/// (a strip) differ only in what the CALLER intends, and this function cannot read intent.
/// @desc Where to aim the camera along a street, for a rect `_w` wide starting at `_x`.
///
/// ⛔⛔ IT AIMS AT THE PEOPLE, NOT AT THE TOWN'S GEOMETRIC CENTRE, AND THAT IS THE FIX FOR THE
/// HERO'S EMPTY ROAD. A street is far wider than any frame it is drawn into, so the pan chooses
/// which slice is photographed - and centring the TOWN photographs the middle of the FURNITURE,
/// which at any given hour is not where the cast is. MEASURED 2026-09-04: at 09:45 the hero's ten
/// places held six people, all in the left half of the town, and the centred shot spent its right
/// third on empty road.
///
/// ⚠️ A RELATED CHANGE WAS TRIED FIRST AND WAS MEASURED WRONG - see `LGE_PLACE_GAP`. Narrowing the
/// spacing between places does not pull the far ones into the shot; on a centred pan it pulls the
/// whole street away from both edges. The town's width sets the MARGINS; the pan sets the SUBJECT.
///
/// ⛔ CLAMPED SO THE STREET STILL COVERS THE FRAME. Aiming at the cast can otherwise walk the town
/// off an edge and put bare plate where a road should be, which is worse than the empty road it was
/// written to remove. A town narrower than the rect falls back to centring, because then there is
/// no slice to choose.
///
/// ⚠️ ONE FUNCTION, TWO READERS - the draw below and `lge_bk_hero_hour`'s scan. That scan counts
/// who lands inside the rect, so a scan panning differently from the draw would optimise a shot
/// nobody takes; its own header records that exact defect from an earlier attempt.
function lge_bk_street_pan(_town, _hour, _x, _w) {
    var _centre = _town.width * 0.5 - _w * 0.5 - _x;
    if (_town.width <= _w) return _centre;
    // ⚠️ THE MIDPOINT OF THE CAST'S SPAN, NOT ITS MEAN. A mean is dragged by whichever end of the
    // street happens to hold more people, so a group of four and a lone worker put the frame on the
    // group and cut the fifth person in half at the edge - MEASURED 2026-09-04, exactly that. The
    // midpoint of (leftmost, rightmost) frames everybody who can be framed and is what a
    // photographer does.
    var _lo = 999999, _hi = -999999, _n = 0;
    var _xs = [];
    for (var _i = 0; _i < array_length(_town.people); _i++) {
        var _at = lge_where(_town, _town.people[_i], _hour);
        if (!_at.visible) continue;
        _lo = min(_lo, _at.x);
        _hi = max(_hi, _at.x);
        array_push(_xs, _at.x);
        _n++;
    }
    if (_n == 0) return _centre;
    var _mid = clamp((_lo + _hi) * 0.5 - _w * 0.5 - _x, -_x, _town.width - _w - _x);
    // ⛔⛔ THE MIDPOINT IS ONLY RIGHT WHILE THE CAST FITS. MEASURED 2026-09-04 on the shipped hero:
    // the cast spanned wider than the 1600px frame, so centring on (lo+hi)/2 pushed BOTH ends out of
    // shot AND kept a 370px hole in the middle - two figures clipped at the left edge, five clumped
    // on the right, ~35% of the plate empty. The header above is still correct about why a MEAN is
    // wrong; it is the case it did not cover that bites.
    //
    // ⭐ WHEN THE SUBJECT IS WIDER THAN THE FRAME A PHOTOGRAPHER DOES NOT CENTRE IT, THEY CHOOSE THE
    // WINDOW. So slide a frame-wide window across the town and take the position holding the most
    // people, with how much of the FRAME they cover as the tiebreak and the midpoint as the final
    // tiebreak - so a street that fits, or one with no better window than its centre, behaves
    // exactly as before. This is the same correction the hour objective in this file records four
    // times over: every earlier version scored something ADJACENT to the picture.
    //
    // ⚠️ AND THE HOUR SCAN CALLS THIS FUNCTION, so the two stay in step by construction - an
    // objective that scored one framing while the draw used another is precisely the defect
    // `lge_bk_hero_hour` was rewritten to remove.
    if (_hi - _lo <= _w) return _mid;
    var _panLo = max(-_x, _lo - _w * 0.5);
    var _panHi = min(_town.width - _w - _x, _hi - _w * 0.5);
    var _best = _mid, _bscore = -1;
    var _step = max(24, _w / 40);
    for (var _p = _panLo; _p <= _panHi; _p += _step) {
        var _in = 0;
        var _bin = array_create(8, 0);
        for (var _k = 0; _k < array_length(_xs); _k++) {
            var _fx = _xs[_k] - _p - _x;
            if (_fx < 0 || _fx > _w) continue;
            _in++;
            _bin[clamp(floor(_fx / _w * 8), 0, 7)] = 1;
        }
        var _cover = 0;
        for (var _bj = 0; _bj < 8; _bj++) _cover += _bin[_bj];
        // People dominate; coverage breaks ties; distance from the midpoint breaks those, so the
        // answer is deterministic and does not depend on scan direction.
        var _sc = _in * 100 + _cover * 10 - abs(_p - _mid) / max(_w, 1);
        if (_sc > _bscore) { _bscore = _sc; _best = _p; }
    }
    return clamp(_best, -_x, _town.width - _w - _x);
}

/// ⛔⛔ AND IT DREW AT MOST ONE PERSON PER PLACE, WHICH IS THE REAL CEILING THE HERO KEPT HITTING.
/// The loop below used to walk the PLACES and, for each, scan the cast for the first person whose
/// current work matched - then `break`. So the number of people a street could ever show was the
/// number of PROPS in it, whatever the population was, and the second, third and fourth person at
/// a well or a bench were silently not drawn.
///
/// ⭐ IT FAILS SILENTLY, WHICH IS WHY FOUR BAKES WENT LOOKING SOMEWHERE ELSE. A place whose extra
/// people are dropped still paints its prop and still looks like a finished part of the street; the
/// only symptom is that the town is emptier than the model says, which reads as a POPULATION problem
/// and sent three sessions to the hour scan, the trade list and the stature. The census disagreed
/// with the picture the whole time and the disagreement was read as a captioning bug.
///
/// ⇒ THE GENERAL FORM, worth carrying to any renderer in this wing: **iterating the FURNITURE and
/// hanging one actor off each caps the cast at the furniture count.** Draw the props, then draw
/// EVERY visible person, and keep the back/front split that puts a worker inside their own station.
function lge_bk_street(_pal, _works, _seed, _hour, _x, _ground, _w, _stature, _clipY, _clipH, _household) {
    var _scissorWas = undefined;
    if (!is_undefined(_clipY)) {
        _scissorWas = gpu_get_scissor();
        gpu_set_scissor(_x, _clipY, _w, _clipH);
    }
    var _town = lge_town_populate(lge_town_make(_seed, _pal.theme, _stature, _works), undefined,
                                  is_undefined(_household) ? LGE_STREET_HOUSEHOLD : _household);
    var _pan = lge_bk_street_pan(_town, _hour, _x, _w);

    // Back to front by depth, exactly as the demo room does and for the same reason: every place
    // carries a shallow y offset and a street drawn in list order paints a near stall behind a far one.
    var _order = [];
    for (var _i = 0; _i < array_length(_town.places); _i++) array_push(_order, _i);
    for (var _i = 1; _i < array_length(_order); _i++) {
        var _j = _i;
        while (_j > 0 && _town.places[_order[_j - 1]].y > _town.places[_order[_j]].y) {
            var _tmp = _order[_j - 1]; _order[_j - 1] = _order[_j]; _order[_j] = _tmp;
            _j--;
        }
    }

    var _drawn = 0;
    // ⛔⛔ HOW MANY FIGURES ARE ACTUALLY IN THE FRAME, WHICH IS NOT WHAT THE CENSUS COUNTS.
    //
    // `lge_town_census` counts the whole TOWN. This function pans a street that is routinely wider
    // than the rect it is asked to fill, so places off either end are never painted - and the hero
    // sheet captioned itself from the census. MEASURED 2026-09-04 on the shipped gallery: the hero
    // read "7 at work, 3 walking to it" over a picture containing four people. That is a false
    // statement on a store image, which is a constitution 2 problem and not a composition one, so it
    // is fixed by COUNTING WHAT WAS DRAWN rather than by rewording the caption.
    var _vis_work = 0, _vis_walk = 0;
    var _none = { back: [], main: [] };
    for (var _k = 0; _k < array_length(_order); _k++) {
        var _pl = _town.places[_order[_k]];
        var _sx = _pl.x - _pan;
        var _gy = _ground + _pl.y;
        var _stp = lge_station_parts(_pl.station, _pl.seed);
        // The prop's two halves, so that N workers can be drawn BETWEEN them. Splitting the struct
        // rather than reaching into `lge_render_parts` keeps the ground-line conversion (`LGE_SOLE`)
        // in the one function that owns it - see `lge_render_work`'s header.
        var _stBack  = { back: _stp.back, front: [] };
        var _stFront = { back: [],        front: _stp.front };

        var _stand = [], _walk = [];
        for (var _p = 0; _p < array_length(_town.people); _p++) {
            var _at = lge_where(_town, _town.people[_p], _hour);
            if (!_at.visible || _at.work != _pl.work) continue;
            var _e = { fig: lge_figure_parts(_town.people[_p], _at.work, _at.phase, _at.moving, _at.face),
                       fx: _at.x - _pan };
            if (_at.moving) array_push(_walk, _e); else array_push(_stand, _e);
        }

        _drawn += array_length(_stp.back) + array_length(_stp.front);
        lge_render_work(_pal, _stBack, _none, _sx, _gy, _sx, _stature);
        var _q;
        for (_q = 0; _q < array_length(_stand); _q++) {
            lge_render_work(_pal, undefined, _stand[_q].fig, _sx, _gy, _stand[_q].fx, _stature);
            _drawn += array_length(_stand[_q].fig.main) + array_length(_stand[_q].fig.back);
            // Counted against the rect this street was asked to fill, and only when a figure was
            // really built - an empty part list is a place whose worker has gone home.
            if (array_length(_stand[_q].fig.main) > 0 &&
                _stand[_q].fx >= _x && _stand[_q].fx <= _x + _w) _vis_work++;
        }
        lge_render_work(_pal, _stFront, _none, _sx, _gy, _sx, _stature);
        // A passer-by is not a worker at this prop, so the prop's near half must not be painted over
        // them - the depth split is a fact about somebody STANDING at a station, so walkers go last.
        for (_q = 0; _q < array_length(_walk); _q++) {
            lge_render_work(_pal, undefined, _walk[_q].fig, _sx, _gy, _walk[_q].fx, _stature);
            _drawn += array_length(_walk[_q].fig.main) + array_length(_walk[_q].fig.back);
            if (array_length(_walk[_q].fig.main) > 0 &&
                _walk[_q].fx >= _x && _walk[_q].fx <= _x + _w) _vis_walk++;
        }
    }
    global.lge_bk_drawn += _drawn;
    // Restore, always - a scissor left set would silently crop every later sheet on this surface.
    // Restored through the four-argument setter (rather than handing the struct back) because that
    // overload is the one every runtime has, and a bake that dies here costs a ten-minute rebuild.
    if (!is_undefined(_scissorWas)) {
        gpu_set_scissor(_scissorWas.x, _scissorWas.y, _scissorWas.w, _scissorWas.h);
    }
    return { parts: _drawn, census: lge_town_census(_town, _hour), town: _town,
             // What is IN THE PICTURE. Any caption making a claim about this image must use these
             // two and never the census - see the block above.
             visWorking: _vis_work, visWalking: _vis_walk };
}

/// The twelve loops the street sheets use: enough to fill a plate legibly, chosen so the hour
/// visibly matters (the baker finishes at 08:00, the watch works the night, the children appear
/// mid-morning, the reaper is out at dawn).
function lge_bk_street_works() {
    return ["baker_peel", "smith_strike", "sawyer_saw", "monger_call", "waterward_draw",
            "potter_wheel", "child_hoop", "elder_sit", "watch_stand", "scribe_write"];
}

/// ============================================================================================
/// SHEET 0 — THE HERO
/// ============================================================================================
/// ⛔ THE HERO HAS ITS OWN, SHORTER STREET, AND THAT IS THE WHOLE FIX FOR THE EMPTIEST SHEET IN THE
/// GALLERY. `lge_bk_street_works` is TEN loops, and ten places at a legible stature are far wider
/// than 1600px - so the hero panned a street whose ends fell off both sides of the frame, drew four
/// people in the middle of it, and left the rest of a 1600x660 plate as flat sky.
///
/// MEASURED 2026-09-04 by opening the shipped sheet: roughly 70% of the hero was empty, nothing at
/// all in the upper two thirds, and the six visible figures were strung along a single line.
///
/// ⭐ FEWER PLACES IS WHAT BUYS BIGGER ONES. Seven loops at stature 232 fill the same frame with
/// people you can actually read - a smith at an anvil, a baker at an oven, a potter at a wheel - and
/// because the street is now narrower than the rect, nothing is panned out of shot and the caption
/// below can tell the truth about the picture. The ten-loop list stays exactly as it is for the day
/// and theme sheets, which draw the street into CLIPPED strips where the extra places are the point.
/// ⛔⛔ THREE PLACES, DRAWN LARGE - AND THE ROUTE HERE WAS FOUR BAKES, TWO OF WHICH MADE IT WORSE.
/// The numbers are worth keeping because they are the argument.
///
/// `lge_town_make` spaces places by their published envelope, about `(2 * halfwidth + 0.30) * scale`
/// px each, and `lge_town_populate` gives each place EXACTLY ONE person. So a street trades density
/// against size on one axis and against population on the other:
///
///   10 places @ 168  ~2200px wide  - a third panned off a 1600px frame, four people visible
///    7 places @ 232  ~2100px wide  - same defect, and the ends still fell out of shot
///    5 places @ 232  ~1500px fits  - but five people is a small sample of a day, and the busiest
///                                    hour in the whole town had only TWO of them at a bench
///
/// ⭐ The ceiling is the population, not the frame: with one worker per place, a SHORT street is a
/// street where almost nobody is in. The full 46-place town runs 35 at work at noon (76%); five
/// places peaked at 40%. Chasing density by adding places only works if the figures shrink, which is
/// what produced the original 70%-empty hero in the first place.
///
/// ⭐ So the hero stops arguing about volume - `sheet_2_work_loops` shows all 46 and is where that
/// claim belongs - and becomes a PHOTOGRAPH: three all-day trades at stature 340, which is about
/// 1430px of street inside a 1600px frame with nobody panned out, and heads about 120px below the
/// caption band instead of 460px below it.
/// ⛔⛔ AND THE REAL CEILING WAS NOT THE FRAME OR THE TRADES - IT IS THAT A SHORT STREET HAS NO
/// COMMONS AND ALMOST NOBODY IN IT.
///
/// `lge_routine_for` gives everyone their trade PLUS idle time at the town's common places, and
/// `lge_town_populate` puts exactly ONE person at each place. So cutting places cuts the population
/// twice over: fewer workers, and no bench or hoop ring for anyone to be at when they are not
/// working - they are simply `away`, which is invisible. Three day-trades baked as ONE person beside
/// two bare props, and swapping WHICH trades changed nothing, because the missing people were never
/// at a trade to begin with.
///
/// ⭐⭐ THE RESOLUTION IS THAT A STREET WIDER THAN ITS FRAME IS CORRECT, AND ONLY THE OLD CAPTION
/// MADE IT WRONG. The original defect was never that places fell off the ends - it was that the
/// sheet then CLAIMED them ("7 at work" over a picture of four). With the caption counting what is
/// actually drawn, a street that runs past both edges is the better photograph: it reads as a slice
/// of a longer town instead of a diorama with tidy empty margins, and every pixel of the frame has
/// something in it.
///
/// So: the full ten-place street, at stature 260 rather than 168. About 3,400px of town, of which
/// the middle 1,600 is the shot - dense edge to edge - with figures half again as tall as the ones
/// on the sheet this replaced.
/// ⛔⛔ AND THE HERO NOW HAS ITS OWN TEN, CHOSEN AGAINST TWO MEASURED PROPERTIES RATHER THAN TASTE.
/// MEASURED 2026-09-04 by `Internal_Ops/_street_pick.js` (self-test 8/8, hours parsed out of
/// `lge_work.gml` rather than retyped) and by `Internal_Ops/_pose_drawn.js`:
///
///   1. HOW MANY OF THE LIST ARE OPEN AT ONCE. `lge_bk_street_works` peaks at **7 of 10** - and the
///      three that are shut at its best hour include `waterward_draw`, which is a COMMONS. So the
///      idle third of the cast was sent to the one well in the list and stood there in a heap: the
///      06:45 bake put TWELVE people inside one well's footprint. A street whose trades are open
///      together does not need a commons to absorb its own cast. These ten are **10 of 10 open at
///      10:00**, with `elder_sit` (open 09:00-21:30) as the single commons, so anybody genuinely
///      idle sits on the village bench, which is a true picture rather than a queue.
///
///   2. WHETHER THE LOOP DRAWS AS A SCARECROW. `_pose_drawn.js` names fifteen loops whose forearms
///      are both horizontal at EVERY phase - `weaver_shuttle`, `spinner_wheel`, `scribe_write`,
///      `potter_wheel`, `roper_walk`, `herald_read` and the rest. Four of those were in the shipped
///      hero list. They stay in `sheet_2_work_loops`, where the claim is the CORPUS and a flat
///      forearm over a desk is honest; none of them is in the photograph.
///
/// ⚠️ IT IS A CASTING DECISION, NOT A FIX. The spread reading is a real defect in those fifteen
/// loops and choosing around it on one sheet does not repair it - see the arm-solve block in
/// `lge_labour_pose`, which records three attempted corrections and why each was reverted. What
/// this does is stop the product's FIRST image being made of its weakest cases.
function lge_bk_hero_works() {
    return ["smith_strike", "sawyer_saw", "cooper_hoop", "miller_sack", "shepherd_shear",
            "carter_load", "digger_spade", "reaper_scythe", "child_hoop", "elder_sit"];
}

/// The stature the hero draws its townspeople at. Named because the hour scan below and the draw
/// call must use the SAME one - `lge_town_make` spaces places by it, so two different values would
/// have the scan measuring a different street from the one that gets photographed.
#macro LGE_HERO_STATURE 300

/// How many people live at each placed trade on the STORE SHEETS. Not a product default: every
/// buyer-facing entry point still populates one per place, and this is the bake's own casting
/// decision, in one place so the hour scan and the draw cannot disagree about it.
///
/// ⛔ TWO, AND THE UPPER BOUND WAS MEASURED RATHER THAN GUESSED. Below it the street is furniture
/// with the occasional person beside it - the 70%-empty hero this replaced. Above it the extra
/// people pile up at the two COMMONS places in `lge_bk_street_works` (the well and the bench),
/// because `lge_routine_for` sends everybody whose own trade is shut to a commons and there is no
/// cap on how many a commons holds.
///
/// MEASURED 2026-09-04 at 3: the hero baked TWELVE people inside one well's footprint at 06:45,
/// against five at the two open trades. That is not a denser street, it is one blob and two gaps -
/// and it is worse than the sparse sheet it replaced, because a crowd of near-identical figures
/// reads as a rendering fault rather than as a town. At 2 the same street carries people at more
/// places and no pile.
#macro LGE_STREET_HOUSEHOLD 2

/// The hero's own household size. LARGER than the strips', and the reason is the same argument in
/// reverse: the cap above exists because the day and theme strips draw hours at which most trades
/// are SHUT, so extra people pile onto a commons. `lge_bk_hero_works` is ten trades chosen to be
/// open together at mid-morning (`_street_pick.js`), so on that street nobody is idle and a third
/// worker joins their own trade's station instead of a queue.
#macro LGE_HERO_HOUSEHOLD 3

/// @desc The hour of the day that puts the most people in the hero's frame.
///
/// ⛔⛔ MEASURED, AND THE FIRST TWO ATTEMPTS KEYED ON THE WRONG QUANTITY - which is the whole reason
/// this is a named function with its reasoning attached rather than four lines inline.
///
///   1. a typed 8.25          -> baked "1 at work, 3 walking to it": a true caption, a weak picture
///   2. max `lge_work_open`   -> chose 08:00 and drew the same thing. A trade being OPEN is not a
///                               person standing at it; at opening time everyone is still walking.
///   3. max workers only      -> indifferent between "two at a bench and a third walking past" and
///                               "two at a bench and empty road", and it kept picking the empty one.
///
/// ⭐ So it counts what the photograph is actually made of, weighted: a worker is worth two and a
/// walker is worth one. Both are reported SEPARATELY in the caption, so the weighting chooses the
/// shot and never launders one into the other.
///
///   4. max people ANYWHERE IN THE TOWN -> and this one is the instructive failure, because it looks
///      right and is not. The street is deliberately wider than the frame, so "how many people are
///      in this town at 05:45" and "how many are in this PHOTOGRAPH" are different questions. The
///      scan maximised the first, picked an hour with eight people spread across 3,400px of town,
///      and the shot - the middle 1,600 - contained exactly one of them. The caption said so.
///
/// ⭐ So the scan applies the SAME PAN the draw does and counts only what lands inside the rect. The
/// objective and the caption now measure the identical quantity, which is the property that was
/// missing from all four earlier attempts: each of them optimised something adjacent to the picture
/// instead of the picture.
///
/// ⚠️ THE TOWN IS BUILT HERE AND AGAIN INSIDE `lge_bk_street`, AND THAT IS ONLY SAFE BECAUSE IT IS
/// DETERMINISTIC - same seed, theme, stature and works, and nothing in the town builder calls
/// `random()`. If that ever stops being true, this scan silently measures a different street from
/// the one it draws. Ties go to the earliest hour, so the answer does not depend on scan order.
///
/// @param {Array} _works the hero's works list
/// @param {Real}  _w     the width of the rect the street will be drawn into
function lge_bk_hero_hour(_works, _w) {
    var _scan = lge_town_populate(
        lge_town_make(4242, "commons", LGE_HERO_STATURE, _works), undefined, LGE_HERO_HOUSEHOLD);
    var _np = array_length(_scan.places);
    var _hour = 8.25, _hbest = -1;
    // ⚠️ THE SWEEP IS BOUNDED TO FULL DAYLIGHT, AND THAT IS A PRESENTATION CHOICE STATED RATHER
    // THAN HIDDEN. `lge_pal` dims and warms the whole palette toward dusk, so an objective that
    // only counts heads will happily choose 18:00 - MEASURED 2026-09-04, it did, and returned a
    // genuinely busier street (11 at work against 6) rendered in low grey-brown light. That is a
    // true picture of the town and a poor first image. The hour is still MEASURED inside this band;
    // what is authored is only the refusal to photograph the place at dusk.
    for (var _th = 8; _th <= 16.5; _th += 0.25) {
        // The pan `lge_bk_street` will apply AT THIS HOUR, so the window below is the shot it will
        // actually take. It is inside the loop because the pan now follows the cast, so it moves
        // with the hour - hoisting it out would score every hour against one hour's framing.
        var _pan = lge_bk_street_pan(_scan, _th, 0, _w);
        var _score = 0;
        var _at = array_create(_np, 0);
        // ⛔⛔ THE FIFTH THING THIS OBJECTIVE HAS BEEN KEYED ON, AND THE FOUR ABOVE ALL SHARE THE
        // DEFECT: they count PEOPLE and PLACES, and a photograph is made of neither - it is made of
        // FRAME. MEASURED 2026-09-04 by opening the shipped hero: the chosen hour put 8 of 10 at
        // work and scored top of this sweep, and the picture was two figures at the left edge, a
        // 370px hole, five figures overlapping in one clump, and 200px of empty sky at the right -
        // about 35% of a 1600px plate with nothing in it, against §4.2b's 20% bar. Ten occupied
        // places score identically whether they are spread across the shot or stacked in a third of
        // it, so the objective was indifferent to the one property that was wrong.
        // ⭐ So the frame is binned and an occupied bin scores. The place term still dominates
        // (10 places x 12 = 120 against 8 bins x 6 = 48), so this is a strong TIEBREAK and never a
        // reason to prefer a thin street - which is the trap every earlier version fell into from
        // the other direction.
        var _bins = 8;
        var _bin = array_create(_bins, 0);
        for (var _hp = 0; _hp < array_length(_scan.people); _hp++) {
            var _ha = lge_where(_scan, _scan.people[_hp], _th);
            if (!_ha.visible) continue;
            var _fx = _ha.x - _pan;
            if (_fx < 0 || _fx > _w) continue;
            _bin[clamp(floor(_fx / _w * _bins), 0, _bins - 1)] = 1;
            if (_ha.moving) { _score += 1; continue; }
            for (var _pi = 0; _pi < _np; _pi++) {
                if (_scan.places[_pi].work == _ha.work) { _at[_pi]++; break; }
            }
        }
        for (var _bj = 0; _bj < _bins; _bj++) _score += _bin[_bj] * 6;
        // ⛔⛔ OCCUPIED PLACES DOMINATE, AND A CROWD AT ONE OF THEM IS ONLY A TIEBREAK. A straight
        // head-count is what chose 06:45 - an hour with twelve people stacked at a single well and
        // two open trades - because it is indifferent between "people at eight benches" and "a mob
        // at one". Both are the same number and only one is a photograph of a town.
        //
        // ⭐ THE SAME SHAPE AS THIS FILE'S FOUR EARLIER HOUR OBJECTIVES: each optimised something
        // ADJACENT to the picture. This one counts the thing the picture is made of - how much of
        // the street has somebody in it - and caps any one place's contribution so it cannot buy
        // the shot by stacking.
        for (var _pj = 0; _pj < _np; _pj++) {
            if (_at[_pj] > 0) _score += 12 + min(_at[_pj], 3);
        }
        if (_score > _hbest) { _hbest = _score; _hour = _th; }
    }
    return _hour;
}

function lge_bk_hero(_w, _h) {
    // ⛔ THE HOUR IS SOLVED BEFORE THE PALETTE, AND THE ORDER IS LOAD-BEARING. `lge_pal` takes the
    // hour and returns that hour's LIGHT, so a palette built at a typed 8.25 while the street is
    // drawn at a measured hour paints a dawn scene under a mid-morning sky. The two were briefly
    // out of step here while the hour was being made measurable, which is a picture nobody would
    // read as a bug - it just looks slightly wrong - and that is exactly why it is worth a comment.
    // ⛔ THE HOUR WAS PINNED TO A FIXED 8.25 AND IS MEASURED AGAIN, AND THE HISTORY IS THE ARGUMENT.
    // `lge_bk_hero_hour` is correct as written and it USED to be useless: swept over 5..20 it kept
    // answering 05:45 and the shot it chose held ONE worker. The previous session concluded from
    // that - correctly - that the hour was not the lever and the STREET was, and pinned the hour
    // rather than keep tuning an objective over a population that could not vary.
    //
    // ⭐ THE POPULATION CAP IS NOW GONE (`lge_town_populate`'s `_per_place`, and the one-actor-per-
    // prop cap in `lge_bk_street`'s own draw loop), so an hour scan is measuring a street that can
    // actually be busy, and it goes back to choosing the shot. The pinned constant would now be a
    // number chosen against a model that no longer exists.
    var _hw = lge_bk_hero_works();
    var _hour = lge_bk_hero_hour(_hw, _w);
    var _pal = lge_pal("commons", _hour);
    // The sky and ground first: this is the one sheet that is a SCENE rather than a catalogue, and a
    // street standing on the plate colour reads as a row of cut-outs.
    // ⚠️ THE HORIZON SITS AT 0.88, NOT 0.80. The figures stand ON this line, so every pixel between
    // the caption band and their heads is dead sky; dropping the horizon and raising the stature
    // together is what closes that gap without cropping anybody's head into the caption.
    var _ground = _h * 0.88;
    lge_render_vgrad(0, 0, _w, _ground, _pal.sky, merge_colour(_pal.sky, _pal.ground, 0.62));
    draw_set_colour(_pal.ground);
    draw_rectangle(0, _ground, _w, _h, false);
    draw_set_colour(_pal.shade);
    draw_rectangle(0, _ground, _w, _ground + 3, false);

    // ⚠️ THE SAME HOUSEHOLD THE HOUR SCAN USED. Two different values would have the scan choosing a
    // shot from a town with a different population from the one photographed - the defect
    // `LGE_HERO_STATURE`'s own comment records for the stature.
    var _r = lge_bk_street(_pal, _hw, 4242, _hour, 0, _ground, _w, LGE_HERO_STATURE,
                           undefined, undefined, LGE_HERO_HOUSEHOLD);

    // The caption band, over the scene rather than above it - the sheet is a photograph and a header
    // strip above it would waste a fifth of the hero image.
    draw_set_colour(lge_bk_page());
    draw_rectangle(0, 0, _w, 118, false);
    draw_set_colour(lge_bk_rule());
    draw_rectangle(0, 118, _w, 120, false);
    lge_text_fit("LIEGE - THE NPC DAY", 54, 22, _w - 108, 56, lge_bk_rule(), lge_bk_ink());
    // ⛔ FROM `visWorking`/`visWalking`, NEVER FROM THE CENSUS. The census counts the whole town and
    // this is a photograph of part of it; captioning a picture with a number it does not show is a
    // false claim on a store page. See the counting block in `lge_bk_street`.
    // ⚠️ THE HOUR IN THE CAPTION IS THE HOUR THAT WAS DRAWN, formatted from `_hour` rather than
    // typed - the two were separate strings once and a sheet that labels itself with a time it did
    // not render is the same class of false claim as the count below.
    lge_text_line(string(floor(_hour)) + ":"
                + string_replace(string_format(floor(frac(_hour) * 60), 2, 0), " ", "0")
                + ". " + string(_r.visWorking) + " at work, "
                + string(_r.visWalking) + " walking to it, in one unposed frame. "
                + "Every position solved from the routine and the clock - no walk state, no re-roll.",
                56, 84, _w - 112, 22, lge_bk_dim(), false);
    return _h - 4;
}

/// ============================================================================================
/// SHEET 1 — THE DAY
/// ============================================================================================
///
/// ⭐ THE SHEET THE WHOLE PRODUCT IS FOR. Four renders of ONE street at four hours: the same twelve
/// trades, the same twelve props, and a visibly different town in each strip - different people at
/// different stations under different light. If this sheet does not read at a glance, the product's
/// headline claim is not on the store page.
function lge_bk_day(_w, _h) {
    var _y = lge_bk_head("ONE STREET, FOUR HOURS",
        "The same town at 05:30, 09:00, 17:00 and 23:00. Nothing is placed by hand: who is standing "
      + "where comes from lge_where, and the light comes from the hour.", 40, _w);

    var _hours = [5.5, 9.0, 17.0, 23.0];
    var _labels = ["05:30  the bakers and the reapers", "09:00  the full working town",
                   "17:00  the second shift and the idlers", "23:00  the watch, and nobody else"];
    var _sh = floor((_h - _y - 30) / 4);
    for (var _i = 0; _i < 4; _i++) {
        var _sy = _y + _i * _sh;
        var _pal = lge_pal("commons", _hours[_i]);
        var _g = _sy + _sh - 40;
        lge_render_vgrad(54, _sy, _w - 108, _g - _sy, _pal.sky,
                         merge_colour(_pal.sky, _pal.ground, 0.62));
        draw_set_colour(_pal.ground);
        draw_rectangle(54, _g, _w - 54, _sy + _sh - 26, false);
        var _r = lge_bk_street(_pal, lge_bk_street_works(), 4242, _hours[_i], 54, _g, _w - 108, 92, _sy, _sh - 26);
        lge_bk_caption(_labels[_i] + "   |   " + string(_r.census.working) + " at work, "
                     + string(_r.census.walking) + " walking, " + string(_r.census.away) + " indoors",
                     56, _sy + _sh - 24, _w - 112);
    }
    return _y + 4 * _sh;
}

/// ============================================================================================
/// SHEET 2 — THE WORK LOOPS
/// ============================================================================================
///
/// ⛔ THE VOLUME SHEET, AND IT DRAWS THE REAL CORPUS. Every cell is `lge_bk_pair_parts` on a
/// different work loop id, at a different phase, with that trade's own dye - so the sheet cannot
/// flatter the corpus. Wing doctrine: the volume IS the moat, and a grid of forty-six cells that all
/// look alike would argue the opposite of what it is here to prove.
function lge_bk_loops(_w, _h) {
    var _all = lge_works_all();
    var _y = lge_bk_head(string(array_length(_all)) + " WORK LOOPS, EVERY ONE GENERATED",
        // ⛔ THE SUBTITLE HAD TO CHANGE WITH THE CODE. It read "Cells are shown at four different
        // phases of their cycles", which was true of `(i mod 4)` and is now false - and a false
        // sentence on a store image is a market claim the picture does not support (master §2).
        "Each cell is a pose, a prop, a tool and a worn set, drawn from numbers. No sprite, no atlas, "
      + "no PNG anywhere in the package. Every cell is drawn at that loop's own working beat.", 40, _w);

    var _pal = lge_pal("commons", 11);
    var _cols = 8;
    var _rows = ceil(array_length(_all) / _cols);
    var _cw = floor((_w - 108) / _cols);
    var _ch = floor((_h - _y - 24) / _rows);
    lge_bk_well(54, _y, _cols * _cw, _rows * _ch);

    for (var _i = 0; _i < array_length(_all); _i++) {
        var _cx = 54 + (_i mod _cols) * _cw;
        var _cy = _y + (_i div _cols) * _ch;
        // ⛔⛔ THE PHASE IS THE LOOP'S OWN WORKING BEAT, SOLVED - NOT `((i mod 4) + 1) / 5.5`.
        //
        // The old comment here was right about the rest position and wrong about the remedy: it
        // varied the phase by CELL INDEX, which is four arbitrary moments sprinkled over forty-six
        // different cycles. So the suite graded each loop at its CLOSEST APPROACH to the work while
        // this sheet drew whatever `i mod 4` happened to land on - the instrument and the picture
        // describing different frames, which is how a cell can very nearly pass the reach bar and
        // still show a cook standing beside a pot with her ladle pointing at the sky. MEASURED
        // 2026-09-04 by cropping that cell to 12x; `smith_strike` PASSES the bar outright and still
        // drew its hammer down by the smith's knee.
        //
        // ⭐ `lge_work_beat` returns the frame the gate is actually about, so the two finally agree.
        // The variety the old comment wanted is not lost: forty-six loops at their own beats are
        // forty-six different pictures, which is the honest version of the same idea.
        lge_bk_cell(_pal, _all[_i], lge_work_beat(_all[_i]), 900 + _i * 17,
                    _cx + 4, _cy + 4, _cw - 8, _ch - 24, undefined);
        lge_bk_caption(_all[_i], _cx + 6, _cy + _ch - 20, _cw - 12);
    }
    return _y + _rows * _ch;
}

/// ============================================================================================
/// SHEET 3 — THE STATIONS
/// ============================================================================================
function lge_bk_stations(_w, _h) {
    var _all = lge_stations_all();
    var _y = lge_bk_head(string(array_length(_all)) + " PROPS, FROM ELEVEN CONSTRUCTORS",
        "The stations alone. Anvils, looms, ovens, wells, stalls and shrines - each built from the "
      + "same shared mass vocabulary and shaded by the same lamp as the people who work at them.", 40, _w);

    var _pal = lge_pal("commons", 11);
    var _cols = 8;
    var _rows = ceil(array_length(_all) / _cols);
    var _cw = floor((_w - 108) / _cols);
    var _ch = floor((_h - _y - 24) / _rows);
    lge_bk_well(54, _y, _cols * _cw, _rows * _ch);

    for (var _i = 0; _i < array_length(_all); _i++) {
        var _cx = 54 + (_i mod _cols) * _cw;
        var _cy = _y + (_i div _cols) * _ch;
        var _pt = lge_station_parts(_all[_i], 500 + _i * 31);
        if (is_undefined(_pt)) continue;
        var _both = [];
        lge_append(_both, _pt.back);
        lge_append(_both, _pt.front);
        if (array_length(_both) == 0) continue;
        var _b = lge_render_bounds(_both);
        var _fit = lge_render_fit_parts(_both, _cx + 4, _cy + 4, _cw - 8, _ch - 26);
        lge_bk_shadow(_fit.cx, _fit.cy + (LGE_SOLE - (_b[1] + _b[3]) * 0.5) * _fit.s, _cw * 0.28);
        lge_render_in_rect_tight(_both, _pal, _cx + 4, _cy + 4, _cw - 8, _ch - 26, undefined);
        global.lge_bk_drawn += array_length(_both);
        lge_bk_caption(_all[_i], _cx + 6, _cy + _ch - 20, _cw - 12);
    }
    return _y + _rows * _ch;
}

/// ============================================================================================
/// SHEET 4 — ONE CYCLE
/// ============================================================================================
///
/// ⭐ THE SHEET THAT PROVES A LOOP IS A LOOP RATHER THAN A FRAME. Eight phases of one work cycle in a
/// row: a viewer can see the hammer come up, the elbow fold at the top, and the stroke come down.
/// `ARCHITECTURE.md` §3 forbids a two-frame flip and the suite asserts against one; this is where a
/// buyer can check that for themselves.
function lge_bk_cycle(_w, _h) {
    var _y = lge_bk_head("A POSE IS A FUNCTION OF PHASE, NOT A TABLE OF FRAMES",
        "One cycle of three work loops, sampled at eight phases. The pose is computed at any phase "
      + "you ask for, so it is smooth at every frame rate and loops without a seam.", 40, _w);

    var _pal = lge_pal("commons", 11);
    // ⚠️ `spinner_wheel` IS OUT AND `miller_sack` IS IN. This sheet's claim is that a pose is a
    // FUNCTION of phase, so a row whose eight frames look alike argues against its own title -
    // MEASURED 2026-09-04 by opening the sheet: the spinner's eight cells differ mostly in the far
    // hand and read as one picture repeated, and `_pose_drawn.js` names that loop as one of the
    // fifteen whose forearms are both horizontal at EVERY phase. Three different VERBS with visible
    // travel: an overhead swing, a flat sweep and a lift.
    var _rows = ["smith_strike", "reaper_scythe", "miller_sack"];
    var _n = 8;
    var _cw = floor((_w - 108) / _n);
    var _ch = floor((_h - _y - 24) / array_length(_rows));

    for (var _r = 0; _r < array_length(_rows); _r++) {
        var _ry = _y + _r * _ch;
        lge_bk_well(54, _ry, _n * _cw, _ch - 8);
        // ⚠️ ONE DYE PER ROW, SET ON THE PERSON RATHER THAN LEFT TO THE TRADE. `lge_dye_of` hashes
        // the work id, and these three trades happen to land close together on the wheel - MEASURED
        // 2026-09-04 by opening the sheet: three rows of twenty-four figures, all the same teal, on
        // a plate whose whole job is to let a reader tell three cycles apart at a glance. The dye is
        // a property of the person (`lge_wear_parts`' `_dye`), so this is the product's own feature
        // used for a presentation choice, not a special case in the renderer.
        var _rowdye = (_r * 3) mod LGE_DYES;
        for (var _i = 0; _i < _n; _i++) {
            var _rw = { name: "c", trade: _rows[_r], seed: 4242, build: "average", skin: 1,
                        hairstyle: "crop", haircol: 1, jostle: 0, dye: _rowdye, routine: undefined };
            lge_bk_cell(_pal, _rows[_r], _i / _n, 4242,
                        54 + _i * _cw + 3, _ry + 4, _cw - 6, _ch - 34, _rw);
        }
        lge_bk_caption(_rows[_r] + "   |   phase 0 to " + string_format((_n - 1) / _n, 1, 3),
                       56, _ry + _ch - 26, _w - 112);
    }
    return _y + array_length(_rows) * _ch;
}

/// ============================================================================================
/// SHEET 5 — ONE PERSON'S DAY
/// ============================================================================================
///
/// ⛔ A TIMELINE AGAINST POSITIONS, WHICH IS THE ONE CLAIM NO SINGLE MOMENT CAN SHOW. The strip is
/// twenty-four hours of one townsperson's routine, drawn from the routine itself: the coloured bands
/// are the segments, the track under them is their solved x position across the day, and the cells
/// below are what they are actually doing at six of those hours.
/// @desc The six moments of `_who`'s day worth showing, in clock order.
///
/// ⛔ THE HOURS ARE SAMPLED WHERE THE WORK CHANGES, NOT ON A FIXED GRID. [6,9,12,15,18,22] is a
/// grid, and a grid lands on whatever the person happens to be doing at those six moments - twice on
/// the same job as often as not, which is half of how a six-panel sheet came out showing two loops.
/// Walking the day and taking the MIDDLE of each distinct run shows six different things when six
/// exist. ⚠️ The captions are read back out of `lge_where` at the hour actually drawn, so this can
/// change WHICH moment is shown and can never make a panel's label untrue.
///
/// ⚠️ LIFTED OUT OF `lge_bk_routine` 2026-09-04 because that function now has to MEASURE the
/// composites it is about to draw before it can lay the sheet out, and the measurement needs the
/// hours. One derivation, two readers - the layout and the draw - rather than two lists that can
/// disagree about which six moments the sheet is about.
function lge_bk_routine_hours(_town, _who) {
    var _hours = [];
    var _run_work = "", _run_from = 0;
    for (var _t1 = 0; _t1 <= LGE_DAY; _t1 += 0.25) {
        var _a1 = lge_where(_town, _who, min(_t1, LGE_DAY - 0.01));
        var _wk1 = _a1.visible ? _a1.work : LGE_AWAY;
        if (_wk1 != _run_work) {
            if (_run_work != "" && _run_work != LGE_AWAY && array_length(_hours) < 6) {
                array_push(_hours, floor((_run_from + _t1) * 0.5));
            }
            _run_work = _wk1;
            _run_from = _t1;
        }
    }
    if (_run_work != "" && _run_work != LGE_AWAY && array_length(_hours) < 6) {
        array_push(_hours, floor((_run_from + LGE_DAY) * 0.5));
    }
    // ⚠️ BACKFILL, so the row is always six panels rather than ragged. An `away` panel is legitimate
    // content on a sheet about a whole day - somebody IS indoors at 22:00 - it just must not be the
    // only thing distinguishing two cells.
    var _fill = [7, 10, 13, 16, 19, 22];
    var _fi = 0;
    while (array_length(_hours) < 6 && _fi < array_length(_fill)) {
        if (!array_contains(_hours, _fill[_fi])) array_push(_hours, _fill[_fi]);
        _fi++;
    }
    // Left to right in time, so the row reads as a day.
    for (var _s1 = 1; _s1 < array_length(_hours); _s1++) {
        var _j1 = _s1;
        while (_j1 > 0 && _hours[_j1 - 1] > _hours[_j1]) {
            var _tm = _hours[_j1 - 1]; _hours[_j1 - 1] = _hours[_j1]; _hours[_j1] = _tm;
            _j1--;
        }
    }
    return _hours;
}

function lge_bk_routine(_w, _h) {
    var _y = lge_bk_head("ONE PERSON, TWENTY-FOUR HOURS",
        "A routine is a day, not a loop. The bands are the segments, the line is the position "
      + "lge_where returns at every hour, and the flat runs are the walks between stations.", 40, _w);

    var _pal = lge_pal("commons", 11);
    // ⛔ THIS SHEET'S TOWN CARRIES ALL FOUR COMMONS, AND THAT IS WHAT BOUNDS ITS VARIETY. A person's
    // day is their own trade plus whichever COMMONS places exist in their town (`lge_routine_for`
    // filters the commons against the town, deliberately - see its header). `lge_bk_street_works`
    // holds only two of the four, so the most varied day anybody in it can have is THREE distinct
    // loops, and the shipped sheet duly baked `waterward_draw` three times and `elder_sit` twice.
    // The `_who` scan below was already asking for the most varied day and getting the best one
    // available; the ceiling was the town, not the scan. ⚠️ Only this sheet's town changes - the day
    // and theme strips still use the street list, where the point is the street rather than one
    // person's routine.
    var _works = ["baker_peel", "smith_strike", "sawyer_saw", "monger_call", "potter_wheel",
                  "child_hoop", "scribe_write", "watch_stand",
                  "waterward_draw", "elder_sit", "herald_read", "priest_bless"];
    var _town = lge_town_populate(lge_town_make(4242, "commons", 1, _works), undefined);

    // ⛔⛔ THE PERSON IS MEASURED, NOT INDEXED. This read `_town.people[1]` - an arbitrary
    // townsperson - and the shipped sheet baked as waterward_draw, smith_strike, waterward_draw,
    // smith_strike, waterward_draw, away: SIX panels showing TWO loops, on the sheet whose entire
    // argument is that a routine is a DAY rather than a cycle. Nothing was wrong with the routine
    // generator; the sample was. Recorded as a Gate 1 failure 2026-09-04 by opening the sheet.
    //
    // ⭐ Asking the town who has the most varied day makes the sheet argue its own point BY
    // CONSTRUCTION, and it keeps doing so if the corpus or the routine table ever changes - which a
    // hand-picked index cannot.
    var _who = _town.people[0];
    var _best_n = -1;
    for (var _p = 0; _p < array_length(_town.people); _p++) {
        var _seen = {}, _cnt = 0;
        for (var _t0 = 0; _t0 < LGE_DAY; _t0 += 0.5) {
            var _a0 = lge_where(_town, _town.people[_p], _t0);
            if (!_a0.visible) continue;
            if (!variable_struct_exists(_seen, _a0.work)) {
                variable_struct_set(_seen, _a0.work, 1);
                _cnt++;
            }
        }
        if (_cnt > _best_n) { _best_n = _cnt; _who = _town.people[_p]; }
    }

    // ⛔⛔ THE PANEL ROW IS SOLVED FIRST AND THE POSITION TRACK IS GIVEN WHAT IS LEFT, RATHER THAN
    // THE OTHER WAY ROUND. The track used to take a fixed 128px and the panels took ALL the rest -
    // about 530px for six cells 234px wide. `lge_render_in_rect_tight` fits by whichever axis binds,
    // these composites run wider than they are tall, so every panel was WIDTH-bound and drew a
    // ~200px figure in a 530px well: 60% of the biggest band on the sheet was empty, which is what
    // the Gate 1 review recorded as "every panel mostly empty around one small figure".
    //
    // ⭐ The panel height is therefore DERIVED from the cell width and the composites' own measured
    // aspect (the wing constitution's Horologe law, same as the cover), and the slack goes to the
    // position track - which is the part of this sheet the review called "genuinely unusual and
    // worth showing". Space moves from the half that was wasting it to the half that earns it.
    //
    // ⚠️ THE HOUR LIST HAS TO BE SOLVED BEFORE THE LAYOUT because the layout measures the composites
    // it is going to draw, so the "what are they doing at six hours" block below runs up here now.
    var _bx = 54, _bw = _w - 108;
    var _hours = lge_bk_routine_hours(_town, _who);
    var _cw = floor(_bw / 6);
    var _cellW = _cw - 14;
    var _aspMax = 0.60;
    var _ncell = min(6, array_length(_hours));
    for (var _m = 0; _m < _ncell; _m++) {
        var _am = lge_where(_town, _who, _hours[_m]);
        if (!_am.visible) continue;
        var _mp = lge_bk_pair_parts(_am.work, _am.phase, 4242, _who);
        if (array_length(_mp) == 0) continue;
        var _mb = lge_render_bounds(_mp);
        _aspMax = max(_aspMax, (_mb[2] - _mb[0]) / max(0.0001, _mb[3] - _mb[1]));
    }

    // ---- the bands -----------------------------------------------------------------------------
    var _by = _y + 8, _bh = 44;
    draw_set_colour(lge_bk_well_col());
    draw_rectangle(_bx, _by, _bx + _bw, _by + _bh, false);
    for (var _i = 0; _i < array_length(_who.routine.segs); _i++) {
        var _sg = _who.routine.segs[_i];
        var _len = lge_seg_length(_sg);
        // A wrapping segment is drawn as its two visible pieces on a linear axis - the segment is
        // still ONE segment, and a band split across the ends of the strip is what wrapping LOOKS
        // like on a straight line.
        var _x0 = _sg.from / LGE_DAY * _bw;
        var _x1 = _x0 + _len / LGE_DAY * _bw;
        var _col = (_sg.work == LGE_AWAY)
            ? lge_bk_rule()
            : variable_struct_get(_pal, "dy" + string(lge_dye_of(_sg.work)) + "_2");
        draw_set_colour(_col);
        draw_rectangle(_bx + _x0, _by, _bx + min(_bw, _x1), _by + _bh, false);
        if (_x1 > _bw) draw_rectangle(_bx, _by, _bx + (_x1 - _bw), _by + _bh, false);
    }
    // Hour rules and labels.
    for (var _hh = 0; _hh <= 24; _hh += 3) {
        var _hx = _bx + _hh / LGE_DAY * _bw;
        draw_set_colour(lge_bk_ink());
        draw_rectangle(_hx, _by + _bh, _hx + 1, _by + _bh + 8, false);
        if (_hh < 24) lge_text_line(string(_hh) + ":00", _hx + 4, _by + _bh + 10, 90, 15, lge_bk_dim(), false);
    }

    // ---- the position track --------------------------------------------------------------------
    // The panel row's height, solved from the cell width and the widest composite, plus the caption
    // strip and the well's own inset. Everything above it belongs to the track.
    var _ch = min(_h - (_by + _bh + 68) - 30, floor(_cellW / _aspMax) + 36);
    var _cy = _h - 30 - _ch;
    var _ty = _by + _bh + 34;
    var _th = _cy - 34 - _ty;
    lge_bk_well(_bx, _ty, _bw, _th);
    // ⛔⛔ THE TRACK IS SCALED TO THE RANGE THIS PERSON ACTUALLY WALKS, NOT TO THE WHOLE TOWN, AND
    // THE CAPTION SAYS SO. Against the town's full width the line occupied the top fifth of the well
    // and the other four fifths were empty - a graph of one person's day is a graph of the part of
    // the street they use, and normalising to a width they never reach is what made a 430px band
    // look like a rendering fault. ⚠️ THE CAPTION IS PART OF THE CHANGE: "position along the street"
    // over an axis that is not the street is a false statement on a store image, which is the same
    // class of defect as the hero's old census caption.
    var _lo = 999999, _hi = -999999;
    for (var _s0 = 0; _s0 <= 480; _s0++) {
        var _a0 = lge_where(_town, _who, _s0 / 480 * LGE_DAY);
        if (!_a0.visible) continue;
        _lo = min(_lo, _a0.x);
        _hi = max(_hi, _a0.x);
    }
    // A person who never moves would give a zero range and divide the whole track by nothing; fall
    // back to the town's width, which is the honest axis for somebody who stands in one place.
    if (_hi - _lo < 0.0001) { _lo = 0; _hi = max(1, _town.width); }
    var _px = -1, _py = -1;
    for (var _s = 0; _s <= 480; _s++) {
        var _t = _s / 480 * LGE_DAY;
        var _at = lge_where(_town, _who, _t);
        var _sx = _bx + _t / LGE_DAY * _bw;
        if (!_at.visible) { _px = -1; continue; }
        var _sy = _ty + _th - 10 - ((_at.x - _lo) / (_hi - _lo)) * (_th - 20);
        if (_px >= 0) {
            draw_set_colour(_at.moving ? lge_bk_ink() : lge_bk_dim());
            draw_line_width(_px, _py, _sx, _sy, _at.moving ? 3 : 2);
        }
        _px = _sx; _py = _sy;
    }
    lge_bk_caption("position, over the stretch of street this person uses  |  bright = walking, "
                 + "dim = at a station, gaps = indoors", _bx + 2, _ty + _th + 6, _bw);

    // ---- what they are doing at six hours ------------------------------------------------------
    // The hours and the row's geometry were both solved above, before the track, so that the track
    // could be given whatever the panels did not need.
    for (var _i = 0; _i < _ncell; _i++) {
        var _at2 = lge_where(_town, _who, _hours[_i]);
        var _cx2 = _bx + _i * _cw;
        lge_bk_well(_cx2, _cy, _cw - 6, _ch);
        if (_at2.visible) {
            lge_bk_cell(_pal, _at2.work, _at2.phase, 4242,
                        _cx2 + 4, _cy + 4, _cw - 14, _ch - 26, _who);
        } else {
            lge_text_line("indoors", _cx2 + 10, _cy + _ch * 0.45, _cw - 20, 20, lge_bk_rule(), false);
        }
        lge_bk_caption(string(_hours[_i]) + ":00  " + (_at2.visible ? _at2.work : "away"),
                       _cx2 + 6, _cy + _ch - 20, _cw - 14);
    }
    return _cy + _ch;
}

/// ============================================================================================
/// SHEET 6 — BUILDS
/// ============================================================================================
function lge_bk_builds(_w, _h) {
    var _builds = lge_builds_all();
    var _y = lge_bk_head("THE CLOTHES FOLLOW THE BODY",
        "The same three trades on all " + string(array_length(_builds)) + " builds. Nothing is "
      + "re-authored per build: every garment samples the body's width at its own height, so a smock "
      + "cut for a slight frame and one cut for a broad one are the same code.", 40, _w);

    var _pal = lge_pal("commons", 11);
    // ⛔ THE THREE ROWS ARE CHOSEN FOR THE GARMENT AND FOR THE POSE, AND THE OLD SET FAILED ON BOTH.
    // MEASURED 2026-09-04 by opening the sheet: `monger_call` baked as five figures with both arms
    // STRAIGHT UP, which reads as surrender rather than as a called price, and `scribe_write` as
    // five seated figures with both arms straight out over a desk their smock hides. Neither row
    // showed the thing the sheet's own title claims - that a garment is cut to the body underneath.
    //
    // ⭐ These three differ in exactly the axes `lge_wear_spec` DERIVES, which is what makes the row
    // an argument rather than a picture: a hazard trade with rolled sleeves, a bib apron and a cap
    // (smith), a standing long-sleeved trade carrying a load so the whole smock is visible (miller),
    // and a stooped ground trade whose hem, cap and hose all follow a bent body (digger). All three
    // were cropped from `sheet_2_work_loops` and looked at in the session that picked them.
    var _rows = ["smith_strike", "miller_sack", "digger_spade"];
    var _cw = floor((_w - 108) / array_length(_builds));
    var _ch = floor((_h - _y - 24) / array_length(_rows));

    for (var _r = 0; _r < array_length(_rows); _r++) {
        var _ry = _y + _r * _ch;
        lge_bk_well(54, _ry, array_length(_builds) * _cw, _ch - 8);
        for (var _i = 0; _i < array_length(_builds); _i++) {
            // One dye per ROW, for the same reason as the cycle sheet: these trades hash close
            // together on the wheel and three same-coloured rows make the comparison harder to read.
            // Constant DOWN a row, so nothing about the build comparison changes with the colour.
            var _who = { name: "b", trade: _rows[_r], seed: 7 + _i, build: _builds[_i], skin: _i mod 4,
                         hairstyle: lge_hair_styles_all()[_i mod 8], haircol: (_i + 1) mod 4,
                         jostle: 0, dye: (_r * 3 + 1) mod LGE_DYES, routine: undefined };
            // ⚠️ AT THE LOOP'S OWN WORKING BEAT, NOT AT A TYPED 0.55. `lge_bk_loops`' header records
            // why: the rest position is the one moment of a cycle that says least about the work,
            // and a hand-typed phase is a second place this sheet can drift away from the grid it is
            // supposed to be showing the same corpus as.
            lge_bk_cell(_pal, _rows[_r], lge_work_beat(_rows[_r]), 4242,
                        54 + _i * _cw + 4, _ry + 4, _cw - 8, _ch - 34, _who);
            if (_r == array_length(_rows) - 1) {
                lge_bk_caption(_builds[_i], 54 + _i * _cw + 6, _ry + _ch - 26, _cw - 12);
            }
        }
        if (_r < array_length(_rows) - 1) {
            lge_bk_caption(_rows[_r], 56, _ry + _ch - 26, _w - 112);
        }
    }
    return _y + array_length(_rows) * _ch;
}

/// ============================================================================================
/// SHEET 7 — THEMES
/// ============================================================================================
function lge_bk_themes(_w, _h) {
    var _themes = lge_themes_all();
    var _y = lge_bk_head("ONE TOWN, " + string(array_length(_themes)) + " REGIONS",
        "The same street under every theme. A theme is one struct: it rotates the materials, moves "
      + "the stone and the vegetation, and re-dyes every garment in the town. Nothing is re-imported.",
        40, _w);

    var _sh = floor((_h - _y - 26) / array_length(_themes));
    for (var _i = 0; _i < array_length(_themes); _i++) {
        var _sy = _y + _i * _sh;
        var _pal = lge_pal(_themes[_i], 10.5);
        var _g = _sy + _sh - 40;
        lge_render_vgrad(54, _sy, _w - 108, _g - _sy, _pal.sky,
                         merge_colour(_pal.sky, _pal.ground, 0.62));
        draw_set_colour(_pal.ground);
        draw_rectangle(54, _g, _w - 54, _sy + _sh - 26, false);
        lge_bk_street(_pal, lge_bk_street_works(), 4242, 10.5, 54, _g, _w - 108, 92, _sy, _sh - 26);
        lge_bk_caption(_themes[_i], 56, _sy + _sh - 24, _w - 112);
    }
    return _y + array_length(_themes) * _sh;
}

/// ============================================================================================
/// THE COVER
/// ============================================================================================
///
/// ⛔ A DESIGNED PLATE, NOT A SCREENSHOT. Master §4.2c: the cover is the only image most buyers see
/// and it is generated illustration, never a capture of the demo room. This one is three workers at
/// hero scale over a title block, composed for 630x500 rather than cropped down from a sheet.
function lge_bk_cover() {
    var _w = LGE_COVER_W, _h = LGE_COVER_H;
    var _pal = lge_pal("commons", 7.5);
    // ⚠️ 0.945, NOT 0.86. At 0.86 the horizon sat 70px above the bottom edge and everything below it
    // was flat unbroken ground - a dead band across the bottom seventh of the ONE image every buyer
    // sees, recorded as a Gate 1 failure on 2026-09-04 by opening the shipped cover and looking at
    // it. Dropping the horizon spends that band on the figures instead: the three cells below are
    // sized from `_ground`, so they grow by the same 42px and the faces gain with them.
    var _ground = _h * 0.945;
    lge_render_vgrad(0, 0, _w, _ground, _pal.sky, merge_colour(_pal.sky, _pal.ground, 0.58));
    draw_set_colour(_pal.ground);
    draw_rectangle(0, _ground, _w, _h, false);

    // ⛔⛔ THE PICKS AND THE PHASE ARE BOTH DELIBERATE, AND BOTH WERE WRONG UNTIL 2026-09-03.
    //
    // This read `["smith_strike", "baker_peel", "monger_call"]` at phases `0.58 + i*0.06`, and the
    // baked cover showed three figures with their arms flung straight out sideways - a row of
    // scarecrows on the one image every buyer sees. Neither half was a rendering bug:
    //
    //   * THE PICKS. A pose's resting shoulder angle is `(1 - height) * 1.35` radians from straight
    //     down, so a LOW `height` is a WIDE arm. Measured across the shipped table
    //     (`Internal_Ops/_arm_angles.js`), only 6 of 46 loops rest at or above 65 degrees - and this
    //     cover had picked TWO of those six: `baker_peel` (height 0.16, 65 deg) and `monger_call`
    //     (height -0.22, above horizontal, because a called price IS a raised arm). The corpus was
    //     fine; the sample was the worst three-of-46 available.
    //   * THE PHASE. 0.58 is an arbitrary number. Every spec already declares `at` - the phase of its
    //     WORKING BEAT - and `lge_bk_loops` states the principle in its own comment: the rest
    //     position is the one moment of a work cycle that says least about the work. The cover was
    //     not drawing the beat it exists to advertise.
    //
    // So: three loops with DIFFERENT silhouettes (an overhead swing, a seated fine-work hunch, a low
    // flat sweep), each drawn at its own declared beat rather than at a number typed here.
    // ⚠️ AND THE FIRST REPLACEMENT SET WAS ALSO WRONG, FOR THE OPPOSITE REASON - PICKED, NOT MEASURED.
    // `potter_wheel` and `reaper_scythe` carry the two largest leans in the corpus (0.30 and 0.22),
    // and at their working beat a big lean throws the whole upper body sideways: correct for the
    // pose, and on a 630x500 shop window it reads as two people falling over. Baked and looked at.
    //
    // ⭐ These three are the output of a MEASUREMENT, not a preference:
    // `Internal_Ops/_arm_angles.js` ranks the corpus by |lean|, filters to a mid resting arm height
    // (12-58 degrees, so neither a T-pose at rest nor arms pinned to the sides) and takes one per
    // VERB, so the three silhouettes cannot be mistaken for each other:
    //
    //   smith_strike   lean 0.10  base 41.8 deg  swing_over  braced   - anvil, hammer overhead
    //   spinner_wheel  lean 0.08  base 54.1 deg  crank       seated   - a seated figure at a wheel
    //   dairy_churn    lean 0.06  base 40.2 deg  press_down  square   - both arms driving a churn
    //
    // A standing brace, a seated crank and a square press: three different actions at three
    // different heights, each still drawn at its own declared beat.
    // ⛔⛔ AND THAT SET WAS WRONG TOO. `spinner_wheel` and `dairy_churn` baked with BOTH ARMS
    // STRAIGHT OUT - scarecrows again - because I kept ranking on a number that does not predict the
    // picture. Three attempts, three metrics, all inferred from the table:
    //
    //   1. an arbitrary phase 0.58            -> picked two of the six widest-armed loops in 46
    //   2. lowest |lean| + mid RESTING angle  -> the rest angle says nothing about the BEAT, where
    //                                            the verb adds up to amp * 1.55 rad on top of it
    //   3. + `hand != "both"`                 -> `spinner_wheel` is hand "left" and STILL symmetric,
    //                                            because `crank` drives both shoulders anyway
    //
    // ⭐ THE LESSON IS THE ONE THE FACTORY KEEPS PAYING FOR: when a heuristic is caught choosing
    // wrongly, the answer is not a better heuristic over the same table - it is to look at the
    // OUTPUT. These three were each rendered, cropped to 3x and LOOKED AT before being written here:
    //
    //   smith_strike   standing, braced, hammer raised over an anvil   (verified, cover + grid)
    //   digger_spade   bent double, driving a spade into the ground    (verified, 3x crop)
    //   watch_stand    upright at a brazier with a staff, night watch  (verified, grid)
    //
    // ⚠️ AND THEY ARE DRAWN AT THE PHASE EACH WAS VERIFIED AT, not at `spec.at`. The working beat is
    // the right idea in general - it is what the grid sheet argues for - but for several verbs it is
    // also the moment of maximum arm extension, which is precisely the silhouette a cover must not
    // have. A phase somebody has actually looked at beats a phase derived from a field.
    // ⛔ FOURTH SET, AND THE RULE THAT FINALLY HELD IS ABOUT THE BODY, NOT THE ARMS. Set three
    // (smith_strike @0.18, digger_spade @0.55, watch_stand @0.36) baked with digger_spade excellent
    // - bent double, driving a spade, unmistakably working - and the two UPRIGHT figures beside it
    // arms-out again. That is the whole pattern across four bakes: this corpus draws front-on, and
    // an UPRIGHT figure with any arm extension reads as a scarecrow at cover size, while a figure
    // whose SPINE is bent cannot, whatever its arms are doing.
    //
    // ⛔⛔ THE "BENT SPINE" RULE ABOVE IS FALSIFIED AND MUST NOT BE APPLIED AGAIN. It is a true
    // observation about five bakes and a WRONG explanation of them, and acting on it cost four
    // sessions and five cover attempts.
    //
    // The figures did not read as scarecrows because they were upright. They read as scarecrows
    // because `lge_tool_at` rotated every tool a quarter turn the WRONG WAY (`_dir - pi/2` where the
    // derivation gives `_dir + pi/2`), so every tool in the corpus pointed BACK ALONG THE ARM at the
    // elbow instead of out of the hand. An upright figure holding a hammer that points at its own
    // shoulder is a person standing with their arms out; the same figure with the hammer ON THE
    // ANVIL is a smith. Bending the spine "worked" only because a bent figure hides its own tool.
    //
    // MEASURED 2026-09-04 after the sign was fixed: `smith_strike` - the upright, braced loop this
    // comment twice rejected as arms-out - cropped at 4x shows the hammer resting on the anvil face
    // and the tongs hanging in the other hand. The corpus was never the problem and neither was the
    // sample; four of these five "sets" were re-sampling around a rendering bug.
    //
    // ⇒ THE PICKS ARE NOW OPEN AGAIN, and the ONE rule that survives is the last line of the block
    // below, which was right for a reason that has nothing to do with spines: choose a phase and a
    // loop you have BAKED AND LOOKED AT, never one ranked out of the table.
    //
    // ⭐ So the cover uses three loops with a bent or kneeling body, each at the phase its cell used
    // on `sheet_2_work_loops` - a phase I have looked at rather than one I derived. The grid's phase
    // is `((i mod 4) + 1) / 5.5`, which is why these are the numbers they are.
    //
    //   shepherd_shear  0.364  kneel   bent over the animal, shears in hand
    //   digger_spade    0.545  stride  bent double, spade into the ground   (verified twice)
    //   thresher_flail  0.727  square  flail up, body coiled                (base 13.9 deg, arms low)
    //
    // ⚠️ This is a COMPOSITION decision for one 630x500 image and nothing else. The grid sheet still
    // shows all 46 loops at four phases each, upright ones included, because there the variety IS
    // the argument.
    // ⛔ FIFTH SET, AND `thresher_flail` IS OUT BECAUSE IT WAS PICKED FROM A TABLE AGAIN. It was
    // chosen on "base 13.9 deg, arms low" - a number - and baked upright, arms out, with no flail
    // visible anywhere. A two-handed tool that does not appear is worse than a plain pose on the
    // one image that has to prove this product draws 42 tools.
    // ⭐ `miller_sack` was chosen the way the four failed sets were not: by cropping candidates out
    // of the baked grid at 3x and LOOKING. It is bent over a hopper tipping a sack of grain - a
    // clear action, a visible prop, a visible load, and a `lift_carry` silhouette that cannot be
    // confused with the shear or the spade beside it. `reaper_scythe` was the other candidate and
    // was rejected on the same evidence: its scythe floats behind the shoulder and the body is
    // nearly upright.
    // ⭐ SIXTH SET, THE FIRST CHOSEN AFTER THE TOOL ROTATION WAS FIXED, AND THE FIRST WHOSE THREE
    // MEMBERS WERE EACH CROPPED TO 4x AND LOOKED AT IN THE SAME SESSION THAT PICKED THEM:
    //
    //   smith_strike   standing at an anvil, hammer resting ON THE FACE, tongs in the other hand
    //   cook_ladle     standing at a tripod cauldron hung at her waist, ladle in the pot, fire under
    //   gardener_hoe   hoe running DOWN from her hands into the garden bed
    //
    // Three tools, three props, three working heights (anvil, waist, ground), three verbs. Two of
    // the three are UPRIGHT, which the five sets above spent four sessions avoiding on a rule that
    // is now known to be a workaround for the rotation bug rather than a fact about the corpus.
    //
    // ⛔ THE PHASE IS `lge_work_beat`, NOT A TYPED NUMBER, AND THAT IS THE POINT OF THE WHOLE BLOCK
    // ABOVE. Every earlier set carried three hand-typed phases, which is a second place the cover
    // can drift away from the sheet it was verified against. The grid draws each cell at
    // `lge_work_beat`, so the cover asking for the same function is the only way "I looked at this"
    // stays true after the next retune - a number I looked at once is a number that goes stale
    // silently, and this file has five commented-out attempts proving it.
    // ⛔⛔ THE CELLS ARE CUT TO THE SPECIMEN, NOT TO AN EVEN THIRD - AND THAT IS THE FIX FOR THE
    // COVER'S DEAD SKY AND FOR ITS THREE FIGURES BEING THREE DIFFERENT SIZES.
    //
    // `lge_render_in_rect_tight` fits a composite by whichever axis binds first. On three equal
    // 210px cells the WIDE composites (a smith beside an anvil, a gardener with a hoe running along
    // the ground) are width-bound and therefore render SHORT, leaving vertical slack above them,
    // while a narrow one renders tall. MEASURED 2026-09-04 by opening the shipped cover: the smith
    // stood about two thirds the height of the figure beside him, under ~90px of empty sky.
    //
    // ⭐ This is the wing constitution's Horologe law verbatim - "MEASURE THE SPECIMEN FIRST, THEN
    // CUT THE CELL TO IT" - and it was recorded there for the identical symptom on a corpus of
    // different-shaped machines. Give every pick the SAME height by handing it a cell as wide as its
    // own bounding box needs, and the row fills the frame by construction.
    //
    // ⚠️ THE ASPECT IS CLAMPED, and the reason is typographic in the donor and geometric here: an
    // unclamped extreme takes so much of the row that its neighbours are squeezed below legibility.
    // The parts are built ONCE and measured, then `lge_bk_cell` rebuilds them from the same seed and
    // person - deterministic by construction, and the alternative (passing the list in) would put a
    // second entry point on a function whose whole contract is "draw this loop in this rect".
    // ⛔⛔ TWO, NOT THREE, AND THE REASON IS ARITHMETIC RATHER THAN TASTE - CUTTING THE CELLS TO THE
    // SPECIMENS IS NECESSARY AND NOT SUFFICIENT.
    //
    // MEASURED 2026-09-04 on the bake immediately after the aspect fix below landed: the three
    // figures came out the same height as each other (which is what that fix buys) and still only
    // ~230px tall under ~65px of empty sky, because every cell was still WIDTH-bound. The arithmetic
    // is forced: these composites run about 1.0-1.6 wide for every 1.0 tall, so three of them side
    // by side at a common height H need about 3.8H of width, and the cover has 598px to give ⇒
    // H <= 157. That is SMALLER than the 346px band, so no allocation of a 630px row can make three
    // of these tall. Two need about 2.2H ⇒ H <= 272, which fills the band.
    //
    // ⭐ The general form, and it is the sibling of the Horologe law this file already applies: on a
    // fixed-width plate the number of specimens and their drawn size are the SAME KNOB. Cutting the
    // cells to the specimens equalises them; only dropping one makes them big.
    //
    // ⚠️ THE VOLUME CLAIM DOES NOT LIVE HERE. `sheet_2_work_loops` shows all 46 and
    // `sheet_3_stations` all 46 props; the cover is the one image a buyer sees before they care how
    // many there are, so it is the one place that trades count for size.
    var _picks = ["smith_strike", "cook_ladle"];
    var _np = array_length(_picks);
    var _who = array_create(_np, undefined);
    var _asp = array_create(_np, 1);
    var _sum = 0;
    var _i;
    for (_i = 0; _i < _np; _i++) {
        _who[_i] = { name: "c", trade: _picks[_i], seed: 31 + _i, build: lge_builds_all()[_i + 1],
                     skin: (_i * 2) mod 4, hairstyle: lge_hair_styles_all()[_i * 3 mod 8],
                     haircol: _i mod 4, jostle: 0, routine: undefined };
        var _pp = lge_bk_pair_parts(_picks[_i], lge_work_beat(_picks[_i]), 4242 + _i, _who[_i]);
        var _bb = lge_render_bounds(_pp);
        _asp[_i] = clamp((_bb[2] - _bb[0]) / max(0.0001, _bb[3] - _bb[1]), 0.55, 2.10);
        _sum += _asp[_i];
    }
    // ⭐ SOLVE THE COMMON HEIGHT, THEN CUT THE WIDTHS FROM IT - the other way round is what left the
    // cells width-bound. `_ch` is the largest height at which every specimen fits its own share of
    // the row, capped by the band between the title and the ground. The row is then CENTRED, because
    // a height-bound row is narrower than the plate and pinning it left would put all the slack on
    // one side.
    var _gap = 10;
    var _band = _ground - 130;
    var _avail = _w - _gap * (_np + 1);
    var _ch = min(_band, floor(_avail / max(0.0001, _sum)));
    var _rowW = _gap * (_np - 1);
    for (_i = 0; _i < _np; _i++) _rowW += floor(_asp[_i] * _ch);
    // Sat on the ground rather than centred in the band: these composites stand on a floor line and
    // a row floating in the middle of the sky reads as a sticker sheet.
    var _cy = _ground - 6 - _ch;
    var _cx = floor((_w - _rowW) * 0.5);
    for (_i = 0; _i < _np; _i++) {
        var _cwi = floor(_asp[_i] * _ch);
        lge_bk_cell(_pal, _picks[_i], lge_work_beat(_picks[_i]), 4242 + _i,
                    _cx, _cy, _cwi, _ch, _who[_i]);
        _cx += _cwi + _gap;
    }

    // The title block over the sky, not under the figures.
    draw_set_colour(lge_bk_page());
    draw_rectangle(0, 0, _w, 116, false);
    draw_set_colour(lge_bk_rule());
    draw_rectangle(0, 116, _w, 118, false);
    lge_text_fit("LIEGE", 26, 12, _w - 52, 58, lge_bk_rule(), lge_bk_ink());
    lge_text_line("The NPC day, generated", 28, 74, _w - 56, 26, lge_bk_ink(), true);
    return _h - 4;
}

/// ============================================================================================
/// THE RUN
/// ============================================================================================

/// @desc Render one sheet, measure it, save it, and return its JSON row.
///
/// ⛔ ONE SURFACE AND ONE BUFFER FOR THE WHOLE GALLERY, RE-MADE ONLY WHEN THE SHEET SIZE CHANGES. A
/// sibling product in this wing crashed mid-gallery on the first bake after a ninth sheet was added:
/// a 6.4 MB surface plus a 6.4 MB buffer created and freed per sheet is 12.8 MB of churn, and the
/// runtime ran out of memory. ⚠️ AND IT FAILED ALMOST SILENTLY - the runner printed `EXIT 0` and
/// collected four fresh sheets beside five stale ones, with nothing red anywhere. That is why the
/// report below carries `sheetsExpected` and why the runner asserts the COUNT before collecting.
/// `_bleed` - this sheet is a PHOTOGRAPH and its sky and ground are MEANT to reach all four edges.
///
/// ⛔ WITHOUT IT THE CLIPPING TEST IS UNSATISFIABLE ON THOSE SHEETS, AND AN UNSATISFIABLE TEST GETS
/// IGNORED - which is exactly what happened. `clipped` is derived from the ink bounding box touching
/// an edge, so a full-bleed scene reports `clipped: true` BY CONSTRUCTION. The first baked gallery
/// came back `ok: false` on all nine sheets; the flag was written off as that artefact, and it was
/// in fact a TRUE POSITIVE on every one of them - the titles really were running off the left edge
/// ("IEGE" on the cover). A flag that cannot be false teaches its reader to discount it, and then it
/// cannot be believed on the day it is right.
///
/// So a bleeding sheet is judged only on whether its CONTENT ran past the bottom (`_endY > _h`),
/// which is a real overflow, and the edge terms are dropped for it alone.
function lge_bk_one(_name, _w, _h, _fn, _contentY, _pool, _bleed) {
    if (_pool.w != _w || _pool.h != _h || !surface_exists(_pool.surf)) {
        if (surface_exists(_pool.surf)) surface_free(_pool.surf);
        if (buffer_exists(_pool.buf)) buffer_delete(_pool.buf);
        _pool.surf = surface_create(_w, _h);
        _pool.buf  = buffer_create(_w * _h * 4, buffer_fixed, 1);
        _pool.w = _w;
        _pool.h = _h;
    }
    var _surf = _pool.surf;
    var _buf = _pool.buf;

    surface_set_target(_surf);
    draw_clear(lge_bk_page());
    // ⚠️ THE LAMP IS RESET BEFORE EVERY SHEET. `lge_figure_parts` flips it for a mirrored figure and
    // puts it back on every exit path - but a sheet that begins with a flipped lamp because of some
    // future caller would be shaded wrong in a way no measurement here can see.
    lge_lamp_reset();
    global.lge_bk_drawn = 0;

    var _endY = _fn();
    var _drawn = global.lge_bk_drawn;
    var _ib = lge_bk_ink_bounds(_w, _h, _contentY, _buf);
    lge_render_opaque(_w, _h);

    surface_reset_target();
    surface_save(_surf, _name + ".png");

    var _isBleed = !is_undefined(_bleed) && _bleed;
    var _clipped = _isBleed
                 ? (_endY > _h)
                 : ((_endY > _h) || (_ib.full[3] >= _h - 6) || (_ib.full[2] >= _w - 6)
                    || (_ib.full[0] <= 5) || (_ib.full[1] <= 5));
    var _cw = (_ib.content[2] - _ib.content[0]) / _w;
    var _chh = (_ib.content[3] - _ib.content[1]) / max(1, _h - _contentY);

    // ⛔ THE INK FLOOR IS A FRACTION OF THE SHEET, NOT A COUNT. A count calibrated for a 1600x1000
    // plate asks the wrong question of a 630x500 cover: the same DENSITY of ink on a sheet with a
    // fifth of the pixels scores a fifth of the count and fails.
    //
    // ⚠️ AND `parts` IS IN THE ROW BECAUSE THE INK CHECK CANNOT SEE AN EMPTY GENERATOR. A sheet whose
    // cells all drew zero parts still carries a title, a rule and forty-six captions - which is ink,
    // in the right places, passing every threshold here. Count the work, not the verdict.
    return "{\"name\":\"" + _name + "\""
         + ",\"endY\":" + string(round(_endY))
         + ",\"parts\":" + string(_drawn)
         + ",\"ink\":" + string(_ib.ink)
         + ",\"fullBox\":[" + string(_ib.full[0]) + "," + string(_ib.full[1]) + ","
                            + string(_ib.full[2]) + "," + string(_ib.full[3]) + "]"
         + ",\"contentW\":" + string_format(_cw, 1, 3)
         + ",\"contentH\":" + string_format(_chh, 1, 3)
         + ",\"clipped\":" + (_clipped ? "true" : "false")
         + ",\"ok\":" + ((!_clipped && _cw >= 0.86 && _chh >= 0.80
                          && _ib.ink > 0.0075 * _w * _h && _drawn > 200) ? "true" : "false")
         + "}";
}

/// @desc Render the whole store gallery and write the report.
function lge_bake_store() {
    var _res = [];
    var _pool = { w: -1, h: -1, surf: -1, buf: -1 };

    array_push(_res, lge_bk_one("cover", LGE_COVER_W, LGE_COVER_H,
        function() { return lge_bk_cover(); }, 120, _pool, true));
    array_push(_res, lge_bk_one("sheet_0_hero", LGE_SHEET_W, LGE_HERO_H,
        function() { return lge_bk_hero(LGE_SHEET_W, LGE_HERO_H); }, 120, _pool, true));
    array_push(_res, lge_bk_one("sheet_1_the_day", LGE_SHEET_W, LGE_SCENE_H,
        function() { return lge_bk_day(LGE_SHEET_W, LGE_SCENE_H); }, 150, _pool));
    array_push(_res, lge_bk_one("sheet_2_work_loops", LGE_SHEET_W, LGE_STRIP_H,
        function() { return lge_bk_loops(LGE_SHEET_W, LGE_STRIP_H); }, 150, _pool));
    array_push(_res, lge_bk_one("sheet_3_stations", LGE_SHEET_W, LGE_STRIP_H,
        function() { return lge_bk_stations(LGE_SHEET_W, LGE_STRIP_H); }, 150, _pool));
    array_push(_res, lge_bk_one("sheet_4_one_cycle", LGE_SHEET_W, LGE_SHEET_H,
        function() { return lge_bk_cycle(LGE_SHEET_W, LGE_SHEET_H); }, 150, _pool));
    array_push(_res, lge_bk_one("sheet_5_one_day", LGE_SHEET_W, LGE_SHEET_H,
        function() { return lge_bk_routine(LGE_SHEET_W, LGE_SHEET_H); }, 150, _pool));
    array_push(_res, lge_bk_one("sheet_6_builds", LGE_SHEET_W, LGE_SHEET_H,
        function() { return lge_bk_builds(LGE_SHEET_W, LGE_SHEET_H); }, 150, _pool));
    array_push(_res, lge_bk_one("sheet_7_themes", LGE_SHEET_W, LGE_SCENE_H,
        function() { return lge_bk_themes(LGE_SHEET_W, LGE_SCENE_H); }, 150, _pool));

    if (surface_exists(_pool.surf)) surface_free(_pool.surf);
    if (buffer_exists(_pool.buf)) buffer_delete(_pool.buf);

    var _s = "{\"mode\":\"store\",\"sheetsExpected\":9"
           + ",\"works\":" + string(array_length(lge_works_all()))
           + ",\"stations\":" + string(array_length(lge_stations_all()))
           + ",\"tools\":" + string(array_length(lge_tools_all()))
           + ",\"themes\":" + string(array_length(lge_themes_all()))
           + ",\"builds\":" + string(array_length(lge_builds_all()))
           + ",\"sheets\":[";
    for (var _k = 0; _k < array_length(_res); _k++) {
        if (_k > 0) _s += ",";
        _s += _res[_k];
    }
    _s += "]}";
    var _f = file_text_open_write("lge_bake.json");
    file_text_write_string(_f, _s);
    file_text_close(_f);
}
