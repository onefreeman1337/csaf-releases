# LIEGE — The NPC Day

**A GameMaker town-life system, written in pure GML. No sprites, no atlas, no PNG.**

Your townspeople walk to a station, adopt a real work pose there with a generated tool in hand, and
the town visibly changes shift across the day. A smith swings a hammer at an anvil at 07:00 and is
gone by 19:00; the watch is at the brazier all night; the baker starts at 04:30 and has finished
before most of the street has begun.

Every one of those pictures is drawn from numbers. There is no sprite sheet in this package.

- **GameMaker 2024.14+.** Built and gated against runtime `2024.14.4.268`.
- **46 work loops** · **46 stations** · **42 tools** · **10 materials** · **4 themes** · **5 builds**.
- **Everything is `lge_`-prefixed.** Nine globals, every one of them namespaced —
  `lge_bk_drawn`, `lge_cycle_hours`, `lge_cycle_span`, `lge_detail`, `lge_env_cache`, `lge_lx`,
  `lge_ly`, `lge_reach_cache`, `lge_stage`. Nothing this package defines can collide with anything
  in your project.

---

## What this is, and what it is not

**It is** a runtime generator and a scheduler in one. The scheduler is the substrate; the visible
half is the product. Every figure on the store page was drawn by the same code you are importing, in
engine, by `lge_bake` — which ships with the package, so you can re-render those sheets yourself.

**It is not** a sprite pack. It will not give you pixel-art characters in someone else's style. The
look is the product's own: flat masses with a drawn relief pass, lit from one fixed lamp.

**It is not** a pathfinder, and it will not make your NPCs walk around each other. See the honest
limits below — that one is a deliberate trade and it is the first thing you should read.

---

## ⚠️ The honest limits, before you buy

**1. Position is a pure function of time, so nothing here is path-dependent.**

`lge_where(town, person, hour)` *solves* where somebody is at that hour. It does not integrate
movement frame by frame. That buys you a great deal:

- Re-entering a map is exact and free — there is nothing to catch up.
- Save and load are free: a routine is a few numbers, and the clock is yours.
- Scrubbing the clock backwards works, at any speed, including past midnight.
- A conversation can pause a person for as long as you like and they resume exactly where they were.

And it costs you this: **a townsperson cannot avoid a collision, jostle in a doorway, or queue**,
because the answer at time `t` cannot depend on what happened at `t-1`. If your game needs NPCs that
push past each other, this is the wrong architecture and you should not buy it for that.

**2. The figures are drawn front-on.** There is no side or three-quarter view. A figure facing the
other way is mirrored (correctly — the lighting is mirrored with it, so you do not get two suns in
one street).

**3. Work poses are authored, not motion-captured or interpolated from a rig.** Each loop is a
continuous function of its phase, so it is smooth at any frame rate and loops without a seam, but the
motions are the 46 in this package.

**4. It draws a lot of primitives.** One townsperson at a station is roughly a thousand drawing
records. See *Performance*, below — the cache is part of the product, not an afterthought.

---

## Quickstart

1. In GameMaker: **Tools → Import Local Package**, pick `Liege.yymps`, **Add All**, import.
2. Open **`rm_lge_demo`** and press Play. That room is the whole product driven by one object, and
   its source is written the way you would write it — every call in it is public API.
3. In your own code, the whole integration is four lines:

```gml
// Create
town = lge_town_populate(
           lge_town_make(seed, "commons", 132, undefined),   // undefined = all 46 trades
           undefined);                                       // undefined = generated names
pal  = lge_pal("commons", 8.0);

// Draw
var _at  = lge_where(town, town.people[i], hour);
if (_at.visible) {
    var _pl  = lge_town_place_of(town, _at.work);
    var _fig = lge_figure_parts(town.people[i], _at.work, _at.phase, _at.moving, _at.face);
    lge_render_work(pal, lge_station_parts(_pl.station, _pl.seed), _fig,
                    _pl.x, ground_y, _at.x, 132);
}
```

`lge_where` returns `{x, y, face, work, phase, moving, visible, seg}`.
`lge_figure_parts` returns `{back, main}` — two part lists, because the station is drawn around the
figure and not behind it.

### The demo room's controls

| key | does |
| --- | --- |
| `Space` | pause the **people** — the clock keeps running, and nobody drifts |
| `Left` / `Right` | scrub the clock, at any speed, in either direction |
| `Up` / `Down` | faster / slower day |
| `Enter` | stop and start the clock |
| `Tab` | follow one person through their whole day |
| `T` | next theme — one struct re-colours the entire town |
| `R` | new town from a new seed |
| `F1` | run the in-engine self-test and print the result |
| `F2` | show / hide the caption |

---

## The three corpora

A work loop is a **pose**, a **prop** and a **tool**, joined:

```gml
lge_work_spec("smith_strike")
// { labour: "smith_strike", station: "anvil", tool: "hammer", offhand: "tongs",
//   side: 1, face: "in", hours: [[6.5, 11.5], [13, 18]], visible: true }
```

- **`lge_labour`** — 46 work poses over 12 motion archetypes (`swing_over`, `swing_flat`,
  `push_pull`, `crank`, `press_down`, `lift_carry`, `stoop_gather`, `tend_fine`, `reach_place`,
  `stir`, `rock`, `hold_still`). A pose is `lge_labour_pose(id, phase)` — a function, not a table of
  frames.
- **`lge_station`** — 46 props built from 11 shared mass constructors. Each returns `{back, front}`
  so the figure can stand *inside* a well, a vat or a stall counter without the near rim being
  painted across their body.
- **`lge_work`** — the join, plus 42 tools built from the same constructors and held at the wrist.

Everything is authored generically and mapped into a material at the very end, which is why a theme
change reaches all 46 props, all 42 tools and every garment at once.

---

## Clothing

`lge_wear` puts one worn set on each trade, and **there is no outfit table** — every slot is derived:

| slot | derived from |
| --- | --- |
| smock length | the labour's stance (a seated trade's is caught up) |
| sleeves | the station material's hazard (a fire trade rolls them back) |
| apron, and whether it has a bib | the same hazard |
| belt | whether the smock is long |
| cap | hazard, or working at ground level |
| colour | a hash of the work loop id, into the theme's own eight-dye wheel |

Add a work loop and it is dressed. That is the whole point, and it is why this is not a wardrobe
system.

---

## Time

```gml
lge_wrap(t)                        // any hour onto [0, 24), negatives included
lge_seg(work, from, to)            // one block of a day; to <= from WRAPS MIDNIGHT, correctly
lge_routine(name, segs)            // a whole day
lge_routine_check(routine)         // -> {ok, gaps, overlaps, step}
lge_routine_pause(routine, t)      // freeze the person; the world clock keeps running
lge_routine_resume(routine, t)
```

A segment that spans midnight is **one segment with a wrapped interval**, never two. If you author
your own routines, `lge_routine_check` tells you where the gaps and the double-bookings are — it
reports them rather than silently repairing them, because a generator that quietly fixes its own
output is one you cannot audit.

---

## Colour and the hour

```gml
var _pal = lge_pal("commons", 17.5);   // theme, hour
```

`lge_pal` returns a flat struct of about 170 colours: `<material>0..4` and `<material>ink` for each
of ten materials, an eight-ramp dye wheel, four skins, four hair colours, plus `sky`, `ground` and
`shade`. Build it **once a frame at most** — it resolves every colour through a gamut-reduction loop.

The light moves continuously with the hour and wraps correctly at midnight: dawn and dusk pull warm,
night is a real blue shift rather than the same picture dimmed, and **fire is exempt** — a forge at
midnight is the same orange it is at noon.

Four themes ship (`commons`, `saltcoast`, `redclay`, `frostwold`). A theme is one struct: a hue
rotation, a chroma multiplier, a lightness offset, the region's own stone and vegetation, and a dye
hue. The ten material anchors are physical facts and are shared, so no theme can make iron look like
oak.

---

## Performance

One townsperson at a station is roughly **1,000 drawing records**. Thirty of them redrawn every frame
is tens of thousands of draw calls and it **will** show up in your profiler.

- **Stations never change.** Build their part lists once (`lge_station_parts(id, seed)`) and keep
  them. The demo room does exactly this.
- **Figures do change** — the pose is a function of phase — so they are rebuilt per frame.
- For crowds at a fixed facing, `lge_render_to_sprite(parts, pal, w, h, pad)` renders a part list into
  a sprite once. **You own that sprite and must `sprite_delete` it.**
  ⚠️ Do not call it from a Draw event (nested render targets), and for a character that faces both
  ways, bake **two** sprites by generating the figure mirrored — flipping one at draw time flips the
  lighting with it.
- `lge_work_envelope(id)` measures how much ground a loop needs. It is memoised, because it builds
  four figures to answer; call it at load, never per frame.

---

## Verifying it yourself

```gml
var _r = lge_selftest();   // or press F1 in the demo room
// -> { pass, fail, notes, stage, suites }
```

The suite runs 12 gate families in engine: the RNG's seeding warm-up, wrapped time, wrapped segments,
routine tiling, pose distinctness over all 1,035 pairs, the station depth-split contract, tool reach
against declared reach, the corpus join in both directions, the clothing derivation, palette role
coverage, the town spine (purity, pause, coverage, travel continuity) and containment.

**It cannot see a picture.** It computes points and numbers; it cannot see a fill rule, a draw order
or a colour. Passing it is necessary and nowhere near sufficient, and the store sheets were checked
by opening them and looking.

---

## Files

| | |
| --- | --- |
| `lge_rng` | seeded Lehmer generator with a warm-up |
| `lge_geom` | primitives, transforms, span clipping, the seeded hash |
| `lge_relief` | the shading engine: domes, bevels, incised and raised lines |
| `lge_palette` | Oklch, the material anchors, the themes, the hour |
| `lge_armature` | the figure: joints, body, hands, head, hair |
| `lge_labour` | the 46 work poses |
| `lge_station` | the 46 props |
| `lge_work` | the join, the 42 tools, the envelope |
| `lge_wear` | the derived worn set |
| `lge_routine` | time, segments, routines, pause |
| `lge_town` | placement, people, and `lge_where` |
| `lge_render` | the only file that talks to the GPU |
| `lge_bake` | the store sheets, rendered by the product |
| `lge_selftest` | the in-engine suite |

Every public script carries a documented header block. There are no absolute paths, no hardcoded room
or layer indices, and nothing in the package calls `random()`.

---

## Licence

See `LICENSE.txt`. The two bundled fonts are Open Sans under the Apache License 2.0; their notice
travels with them in `fonts/THIRD-PARTY-NOTICES.txt`.

**Code and graphics in this package are AI-generated.** Copyright © 2026 Core Systems Asset Factory.
