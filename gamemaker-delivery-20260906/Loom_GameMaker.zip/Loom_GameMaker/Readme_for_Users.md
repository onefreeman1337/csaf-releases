# Loom — Secondary Animation for GameMaker

**Version 1.0.0 · GameMaker 2024.x (legacy runtime) · pure GML, no native extension**

Capes, hair, tails, ropes, chains and pennants that follow your character with physical lag —
the "expensive game" motion layer, attached to an ordinary animated sprite in three lines.

```gml
// Create
rig = new LoomRig(loom_preset_cape());

// Step
rig.step(x, y, image_index, image_xscale, delta_time);

// Draw
rig.draw();
```

That is the whole integration. No physics room, no instances, no fixtures.

---

## Why not GameMaker's built-in physics?

The engine's own route to a rope is Box2D: **one instance plus one fixture per link, inside a
physics room** (see the manual's Rope example). Twenty links is twenty instances before your
game's own objects, in a room that must be physics-enabled whether the rest of your game wants
that or not.

Loom is instance-free and room-agnostic. A rig is a struct; a chain is arrays of numbers. Attach
one to any object in any room, or fifty of them, and delete them with the struct. Nothing else in
your project changes.

## What makes the motion hold up

- **A verlet core with a fixed-substep accumulator.** The same wall-clock time produces the same
  substep sequence at 30, 60, 144 or 240 Hz — behaviour is identical on every display, and capes
  do not explode on high-refresh monitors. Under extreme load the sim slows instead of spiralling.
- **A collision-aware final constraint pass.** Segment length and body-collider contact are
  resolved *together* (closed-form circle-circle intersection), not sequentially — so the cloth
  neither stretches when it drapes over a torso nor sinks into it. Most hand-rolled verlet does
  one after the other and lives with whichever artefact ran last.
- **A deterministic wind field.** Layered sinusoids of (time, position) — no randomness. Gusts
  travel spatially along the cloth, and two identical runs produce identical motion, which
  matters for replays and for capture.

## The pieces

| Script | What it is |
| --- | --- |
| `loom_core` | Pure simulation. Zero engine calls — worlds, chains, integration, constraints, colliders, the substep clock. |
| `loom_bind` | `LoomRig`: owner binding, per-sprite-frame anchors, facing mirror, teleport guard, the one `delta_time` conversion. |
| `loom_render` | Tapered gradient-shaded ribbons, real chain links, multi-strand hair, and a texture-page-safe textured mode. |
| `loom_preset` | `loom_preset_cape / hair / tail / rope / chain / pennant` — complete tuned configs, all plain data. |

## Per-frame anchors — the detail that sells the effect

A run cycle bobs. If the cape anchor does not bob with the shoulder, the cloth floats. Author the
offsets once per animation frame and the rig tracks them, mirrored automatically when the
character turns:

```gml
rig = new LoomRig(loom_preset_cape(100));
rig.anchor_frames(0, [[-12, -68], [-12, -72], [-12, -68], [-12, -72]]);  // one [dx,dy] per frame
```

## Colliders and floor

```gml
torso = rig.add_collider(x, y - 60, 22);   // circle the cape drapes around
rig.move_collider(torso, x, y - 58);       // ride it on the owner each Step
rig.set_floor(560, 0.5);                   // fabric piles onto the ground with friction
```

## Hang things off a chain

```gml
var tip = rig.tip(0);                      // [x, y] of the last node
draw_sprite(spr_lantern, 0, tip[0], tip[1]);
```

`rig.grab(chain, node, mx, my)` pins any node to the mouse (or a hand bone) while held.

## Textured cloth — your sprite, safely

`LOOM_RENDER.TEXTURED` maps any sprite along the ribbon using `sprite_get_uvs()`, so a sprite that
shares a texture page maps correctly — the classic full-page-UV bug is handled for you.

## The demo room

Run the project and press **1–5**: HERO (cape + plume on a running knight), GALLERY (all six
presets), ROPE & CHAIN (drag with the mouse), WIND (calm → breeze → gale cycle), TEXTURED. Every
rig call in the demo is exactly the API above; the rest of `obj_loom_demo` is scaffolding marked
delete-me.

## Install

- **Import the `.yymps`** (Tools → Import Local Package), or copy the four script folders plus —
  optionally — the demo object/room/fonts from the raw project included alongside it.
- Requires a GameMaker 2024.x legacy runtime. Pure GML: every export platform works.

## What was verified, honestly

The package was built and compiled headlessly by GameMaker's own Igor on runtime 2024.14.4.268
(exit 0, 0 errors, 75 resources). The solver's constants were validated in a numerical mirror of
the core (frame-rate independence, no-explosion at 30–240 Hz, exact segment lengths at rest and
in gale). The demo was run and every page visually inspected before release. GML cannot be
unit-tested outside the engine; no claim is made beyond the verification actually performed.

## Licence

Commercial asset licence — unlimited games, no royalties, no resale of the tool itself. See
`LICENSE.txt`. The GML source in this package is AI-written, disclosed on the storefront and here.
