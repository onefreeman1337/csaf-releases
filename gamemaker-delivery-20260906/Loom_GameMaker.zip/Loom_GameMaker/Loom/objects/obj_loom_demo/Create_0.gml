/// LOOM demo — Create.
/// ============================================================================================
/// DEMO SCAFFOLDING, NOT PRODUCT. Everything in obj_loom_demo exists so the product can be
/// seen: a runtime-generated knight sprite, five showcase pages, a self-drive block so an
/// unattended recording has something to record, and a command-line parser for deterministic
/// captures. Copy the RIG CALLS into your game; delete the rest. A game that copies the
/// self-drive will have a character that walks by itself.
///
/// Pages (keys 1-5, or launch with -page N):
///   0 HERO      cape + plume on a running, turning knight — the money shot
///   1 GALLERY   all six presets side by side on stands
///   2 ROPE      grabbable rope + chain-and-lantern (drag with the mouse)
///   3 WIND      pennants and a cape under a travelling gust cycle
///   4 TEXTURED  your sprite on the cloth — texture-page-safe
/// Other args: -still (freeze self-drive input variation), -quit N (exit after N frames).
/// ============================================================================================

window_set_caption("Loom — secondary animation for GameMaker");

// --- command line ---------------------------------------------------------------------------
page = 0;
still_mode = false;
quit_after = -1;
var _pc = parameter_count();
for (var _i = 1; _i < _pc; _i++) {
    var _p = parameter_string(_i);
    if (_p == "-page" && _i + 1 < _pc) { page = clamp(real(parameter_string(_i + 1)), 0, 4); _i++; }
    else if (_p == "-still") still_mode = true;
    else if (_p == "-quit" && _i + 1 < _pc) { quit_after = real(parameter_string(_i + 1)); _i++; }
}

frame_count = 0;
sim_t = 0;               // demo clock, seconds — drives every self-drive schedule (deterministic)

// --- palette (demo chrome only; product colours live in loom_preset) ------------------------
col_bg_top    = make_colour_rgb(24, 20, 44);
col_bg_mid    = make_colour_rgb(16, 13, 30);
col_bg_bot    = make_colour_rgb(8, 6, 16);
col_ground    = make_colour_rgb(30, 26, 52);
col_ground_hi = make_colour_rgb(52, 46, 86);
col_text      = make_colour_rgb(226, 226, 240);
col_text_dim  = make_colour_rgb(126, 126, 156);
col_accent    = make_colour_rgb(89, 214, 210);
col_post      = make_colour_rgb(58, 50, 92);
col_lantern   = make_colour_rgb(255, 196, 92);

// --- runtime-generated knight sprite (4-frame run cycle, 48x64, origin mid-feet) ------------
// Generated art keeps the package free of shipped sprites while still demonstrating the REAL
// per-sprite-frame anchor API on a REAL animated sprite.
/// Two-segment limb (hip->knee->foot) as thick strokes with joint caps. Demo art only.
__loom_demo_limb = function (_x1, _y1, _x2, _y2, _x3, _y3, _w) {
    draw_line_width(_x1, _y1, _x2, _y2, _w);
    draw_line_width(_x2, _y2, _x3, _y3, _w);
    draw_circle(_x2, _y2, _w * 0.5, false);
    draw_circle(_x3, _y3, _w * 0.55, false);
};
spr_knight = -1;
var _fw = 48;
var _fh = 64;
var _surf = surface_create(_fw, _fh);
var _steel_l = make_colour_rgb(184, 196, 212);
var _steel_m = make_colour_rgb(118, 132, 160);
var _steel_d = make_colour_rgb(58, 66, 88);
var _gold = make_colour_rgb(224, 180, 90);
// Per-frame leg poses: [front dx1,dy1(knee) dx2,dy2(foot)], [back ...] relative to hip (24,46).
// Frame order: contact, up, contact-opposite, up-opposite.
var _legs = [
    [ 6, 8, 9, 16,   -6, 8, -10, 15 ],
    [ 2, 7, 4, 16,   -2, 8, -3, 16 ],
    [ -6, 8, -10, 15,  6, 8, 9, 16 ],
    [ -2, 8, -3, 16,   2, 7, 4, 16 ],
];
// The shoulder BOBS through the cycle — this is what anchor_frames exists to track.
knight_bob = [0, -2, 0, -2];

for (var _f = 0; _f < 4; _f++) {
    surface_set_target(_surf);
    draw_clear_alpha(c_black, 0);
    var _cx = _fw * 0.5;
    var _hipy = 46;
    var _bob = knight_bob[_f];
    var _lg = _legs[_f];
    // back leg (darker)
    draw_set_colour(_steel_d);
    __loom_demo_limb(_cx, _hipy, _cx + _lg[4], _hipy + _lg[5], _cx + _lg[6], _hipy + _lg[7], 5);
    // torso
    draw_set_colour(_steel_m);
    draw_ellipse(_cx - 9, 20 + _bob, _cx + 9, _hipy + 2, false);
    draw_set_colour(_steel_l);
    draw_ellipse(_cx - 9, 20 + _bob, _cx + 3, 34 + _bob, false);   // chest highlight
    // belt
    draw_set_colour(_gold);
    draw_rectangle(_cx - 8, 41 + _bob, _cx + 8, 44 + _bob, false);
    // front leg
    draw_set_colour(_steel_m);
    __loom_demo_limb(_cx, _hipy, _cx + _lg[0], _hipy + _lg[1], _cx + _lg[2], _hipy + _lg[3], 5);
    // pauldron + arm
    draw_set_colour(_steel_l);
    draw_circle(_cx - 6, 24 + _bob, 5, false);
    draw_set_colour(_steel_m);
    __loom_demo_limb(_cx - 6, 26 + _bob, _cx - 7, 34 + _bob, _cx - 5, 40 + _bob, 3);
    // helmet
    draw_set_colour(_steel_l);
    draw_ellipse(_cx - 7, 6 + _bob, _cx + 7, 22 + _bob, false);
    draw_set_colour(_steel_d);
    draw_rectangle(_cx + 0, 12 + _bob, _cx + 7, 15 + _bob, false);   // visor slit
    draw_set_colour(_gold);
    draw_rectangle(_cx - 2, 4 + _bob, _cx + 2, 8 + _bob, false);     // crest mount
    surface_reset_target();
    if (_f == 0) {
        spr_knight = sprite_create_from_surface(_surf, 0, 0, _fw, _fh, false, false, _fw div 2, _fh - 2);
    } else {
        sprite_add_from_surface(spr_knight, _surf, 0, 0, _fw, _fh, false, false);
    }
}

// --- striped banner sprite for the TEXTURED page (also runtime-generated) -------------------
var _bw = 64;
var _bh = 96;
surface_resize(_surf, _bw, _bh);
surface_set_target(_surf);
draw_clear_alpha(c_black, 0);
var _band_a = make_colour_rgb(70, 130, 158);
var _band_b = make_colour_rgb(226, 226, 240);
for (var _y = 0; _y < _bh; _y += 16) {
    draw_set_colour(((_y div 16) mod 2 == 0) ? _band_a : _band_b);
    draw_rectangle(0, _y, _bw, _y + 16, false);
}
// heraldic diamond
draw_set_colour(make_colour_rgb(184, 50, 62));
draw_triangle(_bw * 0.5, 18, _bw * 0.78, 48, _bw * 0.5, 78, false);
draw_triangle(_bw * 0.5, 18, _bw * 0.22, 48, _bw * 0.5, 78, false);
surface_reset_target();
spr_banner = sprite_create_from_surface(_surf, 0, 0, _bw, _bh, false, false, 0, 0);
surface_free(_surf);

// --- page 0: HERO ---------------------------------------------------------------------------
ground_y = 560;
knight_x = 400;
knight_dir = 1;
knight_img = 0;
knight_speed = 150;      // px/s
hero_cape = new LoomRig(loom_preset_cape(100));
// Shoulder anchors PER SPRITE FRAME, at the 2x draw scale: the cape rides the run-cycle bob.
hero_cape.anchor_frames(0, [[-12, -68], [-12, -72], [-12, -68], [-12, -72]]);
hero_cape.set_floor(ground_y, 0.5);
// r=14 centred low on the torso: the shoulder ANCHOR (-12,-68) must stay OUTSIDE the circle.
// At the original r=22 @ (x, ground-60) the anchor sat 12.8px INSIDE it - the solver's
// degenerate case - and at calm the cape wrapped the collider ball instead of draping
// (caught by looking at a capture; gusts masked it in motion).
hero_torso_col = hero_cape.add_collider(knight_x, ground_y - 52, 14);
hero_plume = new LoomRig(loom_preset_hair(40));
// One chain kept: re-anchor all three locks to the helmet crest.
hero_plume.anchor_frames(0, [[-4, -116], [-4, -120], [-4, -116], [-4, -120]]);
hero_plume.anchor_frames(1, [[-1, -117], [-1, -121], [-1, -117], [-1, -121]]);
hero_plume.anchor_frames(2, [[2, -117], [2, -121], [2, -117], [2, -121]]);
gust_timer = 0;

// --- page 1: GALLERY ------------------------------------------------------------------------
// Six stands, one preset each. Anchors sway gently so every exhibit is alive.
gallery = [];
var _labels = ["CAPE", "HAIR", "TAIL", "ROPE", "CHAIN", "PENNANT"];
var _gx = 170;
for (var _i = 0; _i < 6; _i++) {
    var _r;
    var _x = _gx + _i * 190;
    var _y = 210;
    switch (_i) {
        case 0: _r = new LoomRig(loom_preset_cape(96)); break;
        case 1: _r = new LoomRig(loom_preset_hair(60)); break;
        case 2: _r = new LoomRig(loom_preset_tail(76)); break;
        case 3: _r = new LoomRig(loom_preset_rope(180)); _r.set_floor(520, 0.6); break;
        case 4: _r = new LoomRig(loom_preset_chain(170)); break;
        default:
            // Length > pin span (190 over 150): a banner strung TIGHTER than its rest length
            // cannot billow at any wind value — the slack is what the wind has to work with.
            _r = new LoomRig(loom_preset_pennant(190));
            _r.pin_tail_at(0, _x + 150, _y + 10);
            _r.set_wind(0, 0, 260, 1);
            break;
    }
    array_push(gallery, { rig: _r, x: _x, y: _y, label: _labels[_i] });
}

// --- page 2: ROPE ---------------------------------------------------------------------------
rope_a = new LoomRig(loom_preset_rope(300));
rope_a.set_floor(600, 0.65);
chain_a = new LoomRig(loom_preset_chain(210));
grab_active = false;     // mouse grab
drive_grab_t = -1;       // self-drive hand state

// --- page 3: WIND ---------------------------------------------------------------------------
wind_pennants = [];
for (var _i = 0; _i < 3; _i++) {
    // 230px of cloth across a 172px span: the ~1.34 slack ratio is what lets a gale actually
    // lift the banner into an arc. At the old 170/172 the cloth was strung TAUT and "GALE"
    // looked identical to calm — caught by looking at the capture, not by any gate.
    var _r = new LoomRig(loom_preset_pennant(230));
    var _x = 200 + _i * 340;
    var _y = 190 + (_i mod 2) * 60;
    _r.pin_tail_at(0, _x + 172, _y + 8);
    array_push(wind_pennants, { rig: _r, x: _x, y: _y });
}
wind_cape = new LoomRig(loom_preset_cape(120));
// Anchored at the top of its stand (640,460) in Step; ground is at 560, so a 120px cape
// reaches it at calm — the floor makes it drape ON the ground rather than hang through it.
wind_cape.set_floor(560, 0.5);
wind_level = 0;          // 0 calm, 1 breeze, 2 gale — self-drives through the cycle

// --- page 4: TEXTURED -----------------------------------------------------------------------
tex_solid = new LoomRig(loom_preset_cape(140));
var _tex_preset = loom_preset_cape(140);
_tex_preset.chains[0].render = LOOM_RENDER.TEXTURED;
_tex_preset.chains[0].sprite = spr_banner;
_tex_preset.chains[0].width = 34;
_tex_preset.chains[0].taper = 0.3;
_tex_preset.chains[0].trim = 0;
tex_banner = new LoomRig(_tex_preset);

page_names = ["HERO", "GALLERY", "ROPE & CHAIN", "WIND", "TEXTURED"];
page_hints = [
    "the cape rides per-frame shoulder anchors  ·  colliders keep it off the body",
    "six presets, one core  ·  every exhibit is plain data you can copy",
    "drag the rope with the mouse  ·  links are drawn geometry, not a polyline",
    "one deterministic wind field, sampled per node  ·  gusts travel along the cloth",
    "your sprite on the cloth via sprite_get_uvs()  ·  safe on shared texture pages",
];
