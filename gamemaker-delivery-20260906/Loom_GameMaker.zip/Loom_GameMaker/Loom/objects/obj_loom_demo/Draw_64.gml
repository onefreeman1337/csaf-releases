/// LOOM demo — Draw GUI. Backdrop + per-page composition + footer chrome.
/// Product calls in here: rig.draw() and rig.tip(). Everything else is demo scenery.

var _w = display_get_gui_width();
var _h = display_get_gui_height();

// --- backdrop: night gradient with a low horizon glow ---------------------------------------
draw_rectangle_colour(0, 0, _w, _h * 0.55, col_bg_top, col_bg_top, col_bg_mid, col_bg_mid, false);
draw_rectangle_colour(0, _h * 0.55, _w, _h, col_bg_mid, col_bg_mid, col_bg_bot, col_bg_bot, false);
// distant hills (two soft silhouettes)
draw_set_colour(make_colour_rgb(14, 11, 26));
draw_ellipse(-200, _h * 0.62, _w * 0.55, _h * 1.25, false);
draw_ellipse(_w * 0.45, _h * 0.66, _w + 200, _h * 1.3, false);
// faint stars, deterministic grid-jitter (demo scenery)
draw_set_alpha(0.5);
for (var _i = 0; _i < 40; _i++) {
    var _sx = (_i * 97) mod _w;
    var _sy = ((_i * 53) mod floor(_h * 0.45));
    var _tw = 0.35 + 0.65 * abs(sin(sim_t * 0.8 + _i));
    draw_set_alpha(0.18 + 0.3 * _tw);
    draw_set_colour(c_white);
    draw_rectangle(_sx, _sy, _sx + 1, _sy + 1, false);
}
draw_set_alpha(1);

switch (page) {
    // --- 0 · HERO ---------------------------------------------------------------------------
    case 0: {
        // ground platform
        draw_rectangle_colour(0, ground_y, _w, ground_y + 6, col_ground_hi, col_ground_hi, col_ground, col_ground, false);
        draw_rectangle_colour(0, ground_y + 6, _w, _h, col_ground, col_ground, col_bg_bot, col_bg_bot, false);
        // moon
        draw_set_colour(make_colour_rgb(226, 226, 240));
        draw_set_alpha(0.9);
        draw_circle(_w - 190, 120, 44, false);
        draw_set_colour(col_bg_top);
        draw_circle(_w - 174, 108, 40, false);
        draw_set_alpha(1);

        var _img = floor(knight_img) mod 4;
        // CAPE BEHIND, knight, PLUME IN FRONT — draw order is the layering API.
        hero_cape.draw();
        draw_sprite_ext(spr_knight, _img, knight_x, ground_y, 2 * knight_dir, 2, 0, c_white, 1);
        hero_plume.draw();
        break;
    }

    // --- 1 · GALLERY ------------------------------------------------------------------------
    case 1: {
        draw_set_font(fnt_loom);
        draw_set_halign(fa_center);
        for (var _i = 0; _i < array_length(gallery); _i++) {
            var _g = gallery[_i];
            var _sway = still_mode ? 0 : sin(sim_t * 1.1 + _i * 1.7) * 14;
            var _ax = _g.x + _sway;
            // stand: post + hook
            draw_set_colour(col_post);
            draw_rectangle(_g.x - 2, 120, _g.x + 2, _g.y, false);
            draw_circle(_ax, _g.y, 4, false);
            _g.rig.draw();
            // label plate
            draw_set_colour(col_text_dim);
            draw_text(_g.x, 96, _g.label);
        }
        draw_set_halign(fa_left);
        break;
    }

    // --- 2 · ROPE & CHAIN -------------------------------------------------------------------
    case 2: {
        // beam the rope and chain hang from
        draw_rectangle_colour(160, 96, _w - 160, 112, col_ground_hi, col_ground_hi, col_ground, col_ground, false);
        draw_set_colour(col_post);
        draw_rectangle(430 - 5, 108, 430 + 5, 124, false);
        draw_rectangle(850 - 5, 108, 850 + 5, 124, false);
        // floor line the rope piles onto
        draw_set_colour(col_ground);
        draw_rectangle(0, 600, _w, _h, false);

        rope_a.draw();
        chain_a.draw();
        // lantern on the chain tip — rig.tip() is the attachment-point API
        var _tip = chain_a.tip(0);
        draw_set_alpha(0.16);
        draw_set_colour(col_lantern);
        draw_circle(_tip[0], _tip[1] + 10, 46, false);
        draw_set_alpha(0.32);
        draw_circle(_tip[0], _tip[1] + 10, 24, false);
        draw_set_alpha(1);
        draw_set_colour(make_colour_rgb(70, 62, 48));
        draw_rectangle(_tip[0] - 7, _tip[1], _tip[0] + 7, _tip[1] + 20, false);
        draw_set_colour(col_lantern);
        draw_rectangle(_tip[0] - 5, _tip[1] + 3, _tip[0] + 5, _tip[1] + 17, false);
        draw_set_colour(make_colour_rgb(255, 240, 200));
        draw_rectangle(_tip[0] - 2, _tip[1] + 7, _tip[0] + 2, _tip[1] + 13, false);
        // hand cursor when grabbing
        if (grab_active || drive_grab_t >= 0) {
            var _gx = grab_active ? mouse_x : 0;
            var _gy = grab_active ? mouse_y : 0;
            if (!grab_active) {
                var _phase = drive_grab_t;
                _gx = 430 + sin(_phase * 2.6) * 240;
                _gy = 330 + cos(_phase * 1.9) * 90;
            }
            draw_set_colour(col_accent);
            draw_circle(_gx, _gy, 7, true);
            draw_circle(_gx, _gy, 2, false);
        }
        break;
    }

    // --- 3 · WIND ---------------------------------------------------------------------------
    case 3: {
        // posts for the pennants
        for (var _i = 0; _i < array_length(wind_pennants); _i++) {
            var _wp = wind_pennants[_i];
            draw_set_colour(col_post);
            draw_rectangle(_wp.x - 3, _wp.y, _wp.x + 3, _wp.y + 330, false);
            draw_rectangle(_wp.x + 172 - 3, _wp.y + 8, _wp.x + 172 + 3, _wp.y + 330 + 8, false);
            draw_set_colour(col_ground_hi);
            draw_circle(_wp.x, _wp.y, 5, false);
            draw_circle(_wp.x + 172, _wp.y + 8, 5, false);
        }
        // ground
        draw_rectangle_colour(0, 560, _w, _h, col_ground, col_ground, col_bg_bot, col_bg_bot, false);
        // cape on a stand
        draw_set_colour(col_post);
        draw_rectangle(640 - 2, 460, 640 + 2, 560, false);
        for (var _i = 0; _i < array_length(wind_pennants); _i++) {
            wind_pennants[_i].rig.draw();
        }
        wind_cape.draw();
        // wind meter
        draw_set_font(fnt_loom);
        draw_set_colour(col_text_dim);
        draw_text(64, 140, "WIND");
        var _names = ["CALM", "BREEZE", "GALE"];
        draw_set_colour(col_accent);
        draw_text(64, 162, _names[wind_level]);
        for (var _i = 0; _i < 3; _i++) {
            draw_set_colour((_i <= wind_level) ? col_accent : col_post);
            draw_rectangle(64 + _i * 26, 190, 84 + _i * 26, 196, false);
        }
        break;
    }

    // --- 4 · TEXTURED -----------------------------------------------------------------------
    default: {
        draw_set_colour(col_post);
        draw_rectangle(430 - 3, 120, 430 + 3, 200, false);
        draw_rectangle(830 - 3, 120, 830 + 3, 200, false);
        draw_set_colour(col_ground_hi);
        draw_circle(430, 200, 5, false);
        draw_circle(830, 200, 5, false);
        tex_solid.draw();
        tex_banner.draw();
        draw_set_font(fnt_loom);
        draw_set_halign(fa_center);
        draw_set_colour(col_text_dim);
        draw_text(430, 590, "solid ribbon — vertex colour");
        draw_text(830, 590, "YOUR SPRITE — sprite_get_uvs()");
        // the source sprite, shown small
        draw_sprite_ext(spr_banner, 0, 1120, 480, 1, 1, 0, c_white, 1);
        draw_set_colour(col_text_dim);
        draw_text(1152, 590, "source");
        draw_set_halign(fa_left);
        break;
    }
}

// --- footer chrome --------------------------------------------------------------------------
draw_set_alpha(0.82);
draw_set_colour(col_bg_bot);
draw_rectangle(0, _h - 54, _w, _h, false);
draw_set_alpha(1);
draw_set_colour(col_accent);
draw_rectangle(0, _h - 54, _w, _h - 52, false);
draw_set_font(fnt_loom_title);
draw_set_colour(col_text);
draw_set_valign(fa_middle);
draw_text(24, _h - 27, "LOOM");
draw_set_font(fnt_loom);
draw_set_colour(col_accent);
draw_text(134, _h - 34, page_names[page]);
draw_set_colour(col_text_dim);
draw_text(134, _h - 16, page_hints[page]);
draw_set_halign(fa_right);
draw_text(_w - 24, _h - 27, "1-5 pages  ·  secondary animation for GameMaker");
draw_set_halign(fa_left);
draw_set_valign(fa_top);
