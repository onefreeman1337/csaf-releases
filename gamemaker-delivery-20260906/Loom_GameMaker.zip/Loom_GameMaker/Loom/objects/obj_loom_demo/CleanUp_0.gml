/// LOOM demo — Clean Up. Free the runtime-generated sprites.
/// The rigs themselves are plain structs and arrays; GameMaker garbage-collects them. The only
/// manually-managed resources in the whole demo are the two sprites built from surfaces.

if (sprite_exists(spr_knight)) sprite_delete(spr_knight);
if (sprite_exists(spr_banner)) sprite_delete(spr_banner);
