/// LOOM demo — Step. Self-drive + input + per-page rig updates.
/// The ONLY product calls in here are rig.step(...), rig.set_wind(...), rig.grab(...),
/// rig.move_collider(...) — everything else is demo scaffolding.

var _dt_s = delta_time / 1000000;   // demo's own clock; the RIG takes raw delta_time below
sim_t += _dt_s;
frame_count++;
if (quit_after > 0 && frame_count >= quit_after) game_end();

// Page switching (capture uses -page; a human uses the keys).
for (var _k = 0; _k < 5; _k++) {
    if (keyboard_check_pressed(ord(string(_k + 1)))) page = _k;
}

switch (page) {
    // --- 0 · HERO ---------------------------------------------------------------------------
    case 0: {
        // Self-drive: the knight runs, turns at the edges. -still pins him mid-run for stills.
        if (!still_mode) {
            knight_x += knight_dir * knight_speed * _dt_s;
            if (knight_x > 1020) { knight_x = 1020; knight_dir = -1; }
            if (knight_x < 260)  { knight_x = 260;  knight_dir = 1; }
            knight_img += 9 * _dt_s;                    // run cycle at 9 fps
        }
        var _img = floor(knight_img) mod 4;
        // Wind: calm with a gust every few seconds so the cape answers.
        gust_timer += _dt_s;
        var _gust = (sin(sim_t * 0.35) > 0.55) ? 420 : 90;
        hero_cape.set_wind(-knight_dir * 40, 0, _gust, 1);
        hero_plume.set_wind(-knight_dir * 40, 0, _gust * 0.8, 1.4);
        // Torso collider rides the knight so the cape drapes around the body, not through it.
        // Centre/radius must keep the shoulder anchor OUTSIDE the circle (see Create).
        hero_cape.move_collider(hero_torso_col, knight_x - knight_dir * 2, ground_y - 52);
        hero_cape.step(knight_x, ground_y, _img, knight_dir, delta_time);
        hero_plume.step(knight_x, ground_y, _img, knight_dir, delta_time);
        break;
    }

    // --- 1 · GALLERY ------------------------------------------------------------------------
    case 1: {
        for (var _i = 0; _i < array_length(gallery); _i++) {
            var _g = gallery[_i];
            // Gentle deterministic sway per stand so every exhibit moves.
            var _sway = still_mode ? 0 : sin(sim_t * 1.1 + _i * 1.7) * 14;
            var _rise = still_mode ? 0 : cos(sim_t * 0.7 + _i * 0.9) * 5;
            _g.rig.set_wind(0, 0, 150 + 60 * sin(sim_t * 0.5 + _i), 1);
            _g.rig.step(_g.x + _sway, _g.y + _rise, 0, 1, delta_time);
        }
        break;
    }

    // --- 2 · ROPE & CHAIN -------------------------------------------------------------------
    case 2: {
        rope_a.set_wind(0, 0, 60, 1);
        rope_a.step(430, 120, 0, 1, delta_time);
        chain_a.step(850, 110, 0, 1, delta_time);

        // Mouse grab: hold LMB near the rope and it follows the hand.
        var _mx = mouse_x;
        var _my = mouse_y;
        grab_active = false;
        if (mouse_check_button(mb_left)) {
            grab_active = true;
            rope_a.grab(0, 14, _mx, _my);
        } else if (!still_mode) {
            // Self-drive hand: seize the rope on a cycle, sweep it, let go. Deterministic.
            var _phase = (sim_t mod 7);
            if (_phase < 2.6) {
                var _hx = 430 + sin(_phase * 2.6) * 240;
                var _hy = 330 + cos(_phase * 1.9) * 90;
                rope_a.grab(0, 14, _hx, _hy);
                drive_grab_t = _phase;
            } else {
                drive_grab_t = -1;
            }
        }
        break;
    }

    // --- 3 · WIND ---------------------------------------------------------------------------
    case 3: {
        // Self-drive the weather: calm -> breeze -> gale, 4 s each. Deterministic.
        // GALE must DOMINATE gravity (900 px/s^2) or the label contradicts the picture: at the
        // old steady 300, a pennant (wind 1.6) felt 480 px/s^2 sideways vs 900 down and sagged
        // through "GALE" exactly as it sagged through calm — caught by looking at the capture.
        wind_level = floor((sim_t mod 12) / 4);
        if (still_mode) wind_level = 2;
        var _steady_tab = [0, 140, 700];
        var _gust_tab = [70, 280, 1000];
        var _steady = _steady_tab[wind_level];
        var _gust2 = _gust_tab[wind_level];
        for (var _i = 0; _i < array_length(wind_pennants); _i++) {
            var _wp = wind_pennants[_i];
            _wp.rig.set_wind(_steady, 0, _gust2, 1);
            _wp.rig.step(_wp.x, _wp.y, 0, 1, delta_time);
        }
        wind_cape.set_wind(_steady, 0, _gust2, 1);
        // Anchored at the TOP of its stand (the post runs 460..560); the floor set in Create
        // means the calm cape drapes onto the ground instead of hanging through it.
        wind_cape.step(640, 460, 0, 1, delta_time);
        break;
    }

    // --- 4 · TEXTURED -----------------------------------------------------------------------
    default: {
        var _g4 = 200 + 180 * (0.5 + 0.5 * sin(sim_t * 0.6));
        tex_solid.set_wind(60, 0, _g4, 1);
        tex_banner.set_wind(60, 0, _g4, 1);
        tex_solid.step(430, 200, 0, 1, delta_time);
        tex_banner.step(830, 200, 0, 1, delta_time);
        break;
    }
}
