/// ============================================================================================
/// LOOM · loom_bind — the engine binding. The ONLY layer that reads engine state.
///
/// A LoomRig owns one world plus one or more chains (a cape is one chain; hair is several) and
/// exposes the whole product as three calls:
///
///     // Create event
///     rig = new LoomRig(loom_preset_cape());
///
///     // Step event
///     rig.step(x, y, image_index, image_xscale, delta_time);
///
///     // Draw event
///     rig.draw();
///
/// THE MICROSECONDS TRAP, closed here and only here: GameMaker's delta_time is MICROSECONDS.
/// rig.step() divides by 1,000,000 exactly once. No other file touches delta_time — a routine
/// source of off-by-1000 bugs in hand-rolled GameMaker physics (LOOM_DT_DIVISOR below).
///
/// ANCHORS. Node 0 of every chain rides an anchor point derived from the owner:
///   - Each chain config carries a static offset [dx, dy] from the owner position (preset default).
///   - rig.anchor_frames(chain_index, frames) upgrades that to PER-SPRITE-FRAME offsets:
///     frames is an array of [dx, dy] pairs indexed by floor(image_index) — author it once per
///     animation so the cape rides the shoulder through a run cycle's bob instead of floating.
///   - dx is mirrored automatically by the sign of image_xscale, so a character that turns
///     around carries the adornment to the correct side with no extra authoring.
///
/// TELEPORTS. If the owner moves further in one frame than LOOM_TELEPORT_FACTOR times the chain
/// length, the rig snaps every chain to rest at the new anchor instead of dragging it across
/// the room. Room transitions and respawns therefore read as "appeared", never as "fired".
/// Call rig.teleport(x, y) yourself to force it (e.g. after a cutscene camera jump).
/// ============================================================================================

// delta_time arrives in MICROSECONDS. This is the single place Loom converts it.
#macro LOOM_DT_DIVISOR 1000000

// Owner displacement (in chain lengths, per frame) beyond which step() treats the move as a
// teleport rather than motion.
#macro LOOM_TELEPORT_FACTOR 3

/// @function LoomRig(preset)
/// @description Build a rig from a preset struct (see loom_preset.gml, or build the struct by
///              hand — every field is plain data). Chains start unplaced; the first step()
///              places them at rest so there is no first-frame snap.
function LoomRig(_preset) constructor {
    preset = _preset;
    world = loom_world_create(
        variable_struct_exists(_preset, "fixed_dt") ? _preset.fixed_dt : 1 / 120,
        variable_struct_exists(_preset, "max_steps") ? _preset.max_steps : 8
    );
    if (variable_struct_exists(_preset, "gravity_y")) world.gy = _preset.gravity_y;

    chains = [];      // loom_chain structs
    cfgs = [];        // per-chain config structs (the preset's chain entries)
    frames = [];      // per-chain: undefined, or array of [dx,dy] per sprite frame
    placed = false;
    facing = 1;
    last_x = 0;
    last_y = 0;
    // Sub-frame anchor interpolation state: where the anchor was at the previous step() call.
    prev_ax = array_create(array_length(_preset.chains), 0);
    prev_ay = array_create(array_length(_preset.chains), 0);

    var _nc = array_length(_preset.chains);
    for (var _i = 0; _i < _nc; _i++) {
        var _cc = _preset.chains[_i];
        array_push(chains, loom_chain_create(_cc.n, _cc.seg));
        array_push(cfgs, _cc);
        array_push(frames, undefined);
    }

    /// Is this a chain index this rig actually has? Every public accessor below takes one,
    /// and before this guard existed they indexed `chains`/`cfgs` directly - so `tip(1)` on a
    /// one-chain rig threw "Variable Index [1] out of range [1]" rather than refusing.
    static __ok_chain = function (_ci) {
        return is_real(_ci) && _ci >= 0 && _ci < array_length(chains);
    };

    /// @function anchor_frames(chain_index, frame_offsets)
    /// @description Give one chain per-sprite-frame anchor offsets: an array of [dx, dy]
    ///              pairs, one per image_index (floor(image_index) mod array length is used,
    ///              so a 4-entry table serves any image_speed). dx flips with facing.
    ///
    /// ⛔ THE SHAPE IS VALIDATED HERE, NOT TRUSTED. Before this check, a table of the wrong shape
    /// (an array of numbers rather than of [dx, dy] pairs) was stored happily and then crashed
    /// LATER inside step(), as "trying to index a variable which is not an array" — a message
    /// naming neither this function nor the table. Storing an unusable table and failing somewhere
    /// else is the worst of both: the caller gets no signal at the point of the mistake, and the
    /// crash arrives with no way back to it.
    static anchor_frames = function (_ci, _frames) {
        if (!__ok_chain(_ci)) return self;
        if (!is_array(_frames)) return self;
        var _n = array_length(_frames);
        for (var _i = 0; _i < _n; _i++) {
            var _e = _frames[_i];
            // Every entry must be an [dx, dy] pair of numbers, or the table is refused WHOLE —
            // a half-accepted table would put the same crash one frame further away.
            if (!is_array(_e) || array_length(_e) < 2 || !is_real(_e[0]) || !is_real(_e[1])) return self;
        }
        frames[_ci] = _frames;
        return self;
    };

    /// @function set_wind(wx, wy, gust, [turbulence])
    /// @description Set the shared wind field for every chain in this rig.
    static set_wind = function (_wx, _wy, _gust, _turb = 1) {
        loom_world_set_wind(world, _wx, _wy, _gust, _turb);
        return self;
    };

    /// @function set_floor(y, [friction])
    /// @description World floor plane — fabric piles up on it instead of falling through.
    ///              Pass -1 to disable.
    static set_floor = function (_y, _friction = 0.6) {
        world.floor_y = _y;
        world.floor_friction = _friction;
        return self;
    };

    /// @function add_collider(x, y, r)
    /// @description Add a circle collider (returns its index). Move it each step with
    ///              move_collider — e.g. keep it on the wearer's torso so the cape drapes
    ///              around the body.
    static add_collider = function (_x, _y, _r) {
        return loom_world_add_collider(world, _x, _y, _r);
    };

    /// @function move_collider(index, x, y)
    static move_collider = function (_i, _x, _y) {
        loom_world_move_collider(world, _i, _x, _y);
        return self;
    };

    /// @function pin_tail_at(chain_index, x, y)
    /// @description For pin_tail chains (pennants): set the tail pin in WORLD coordinates.
    ///              Static posts set it once; a moving endpoint sets it every step.
    static pin_tail_at = function (_ci, _x, _y) {
        if (!__ok_chain(_ci) || !is_real(_x) || !is_real(_y)) return self;
        cfgs[_ci].tail_x = _x;
        cfgs[_ci].tail_y = _y;
        return self;
    };

    /// @function tip(chain_index)
    /// @description World position of a chain's last node — hang a lantern, a key, a fish off
    ///              it. Returns [x, y].
    static tip = function (_ci) {
        if (!__ok_chain(_ci)) return [0, 0];   // a missing chain has no tip, it is not an error
        var _c = chains[_ci];
        return [_c.px[_c.n - 1], _c.py[_c.n - 1]];
    };

    /// @function node_count(chain_index)
    static node_count = function (_ci) {
        if (!__ok_chain(_ci)) return 0;
        return chains[_ci].n;
    };

    /// @function grab(chain_index, node_index, x, y)
    /// @description Externally constrain one node this frame (a hand seizing the rope): the
    ///              node moves to (x, y) with zero velocity and the rest of the chain follows
    ///              on the next steps. Call every frame while held.
    static grab = function (_ci, _ni, _x, _y) {
        if (!__ok_chain(_ci) || !is_real(_x) || !is_real(_y)) return self;
        var _c = chains[_ci];
        _ni = clamp(_ni, 1, _c.n - 1);
        _c.px[_ni] = _x;
        _c.py[_ni] = _y;
        _c.ox[_ni] = _x;
        _c.oy[_ni] = _y;
        return self;
    };

    /// @function anchor_of(chain_index, owner_x, owner_y, image_index, face)
    /// @description Resolve one chain's anchor position for the given owner state.
    static anchor_of = function (_ci, _ox, _oy, _img, _face) {
        // Returns a POSITION, so the refusal has to be a position: the owner's own point is
        // the honest answer for a chain that does not exist.
        if (!__ok_chain(_ci)) return [is_real(_ox) ? _ox : 0, is_real(_oy) ? _oy : 0];
        var _cc = cfgs[_ci];
        var _dx = _cc.anchor[0];
        var _dy = _cc.anchor[1];
        var _tab = frames[_ci];
        if (!is_undefined(_tab)) {
            var _len = array_length(_tab);
            if (_len > 0) {
                var _f = _tab[floor(_img) mod _len];
                _dx = _f[0];
                _dy = _f[1];
            }
        }
        return [_ox + _dx * _face, _oy + _dy];
    };

    /// @function teleport(owner_x, owner_y, [image_index], [image_xscale])
    /// @description Snap every chain to rest at the owner's position. Zero velocity, no drag
    ///              streak. Called automatically when a step displacement exceeds
    ///              LOOM_TELEPORT_FACTOR chain lengths.
    static teleport = function (_ox, _oy, _img = 0, _xscale = 1) {
        // An owner with no position cannot be teleported to. Refusing leaves the rig exactly
        // where it was, which is what a caller with a stale reference wants to see.
        if (!is_real(_ox) || !is_real(_oy)) return self;
        if (!is_real(_img)) _img = 0;
        if (!is_real(_xscale)) _xscale = 1;
        facing = (_xscale < 0) ? -1 : 1;
        var _nc = array_length(chains);
        for (var _i = 0; _i < _nc; _i++) {
            var _a = anchor_of(_i, _ox, _oy, _img, facing);
            // Hang direction: straight down for rope-like, behind the facing for cloth —
            // the preset's hang field ([dx, dy], facing-relative) decides.
            var _cc = cfgs[_i];
            var _hx = _cc.hang[0] * facing;
            var _hy = _cc.hang[1];
            loom_chain_place(chains[_i], _a[0], _a[1], _hx, _hy);
            prev_ax[_i] = _a[0];
            prev_ay[_i] = _a[1];
        }
        last_x = _ox;
        last_y = _oy;
        placed = true;
        return self;
    };

    /// @function step(owner_x, owner_y, image_index, image_xscale, dt)
    /// @description Advance the rig. Call once per Step event, passing delta_time as dt —
    ///              IN MICROSECONDS, exactly as GameMaker hands it to you; the conversion is
    ///              Loom's job, not yours. Anchor motion is interpolated across substeps, so
    ///              a fast dash smears into curved cloth motion instead of stair-stepping.
    static step = function (_ox, _oy, _img, _xscale, _dt) {
        // ⛔ THE PER-FRAME CALL, SO THIS IS THE GUARD THAT EARNS ITS KEEP. An owner destroyed
        // mid-frame gives undefined x/y (DoSub) and a caller-supplied dt can be undefined
        // (DoDiv); both are ordinary game states rather than abuse, and both used to throw
        // inside a bought library in the buyer's Step event.
        if (!is_real(_ox) || !is_real(_oy)) return self;
        if (!is_real(_dt)) return self;
        if (!is_real(_img)) _img = 0;
        if (!is_real(_xscale)) _xscale = 1;
        if (!placed) {
            teleport(_ox, _oy, _img, _xscale);
            return self;
        }
        facing = (_xscale < 0) ? -1 : 1;

        // Teleport guard: one-frame displacement measured against the longest chain.
        var _dx = _ox - last_x;
        var _dy = _oy - last_y;
        var _dist2 = _dx * _dx + _dy * _dy;
        var _nc = array_length(chains);
        var _longest = 0;
        for (var _i = 0; _i < _nc; _i++) _longest = max(_longest, loom_chain_len(chains[_i]));
        var _tp = _longest * LOOM_TELEPORT_FACTOR;
        if (_dist2 > _tp * _tp) {
            teleport(_ox, _oy, _img, _xscale);
            return self;
        }

        var _dt_s = _dt / LOOM_DT_DIVISOR;   // <- microseconds -> seconds, the ONE conversion
        var _steps = loom_world_steps(world, _dt_s);
        if (_steps > 0) {
            // Substeps OUTER, chains inner: the world clock advances once per substep, so the
            // wind field ripples at substep granularity and every chain sees the same time.
            // Each chain's anchor is interpolated from its previous position to the current
            // one across the substeps — a fast dash smears into curved cloth motion.
            for (var _s = 1; _s <= _steps; _s++) {
                loom_world_advance(world);
                var _u = _s / _steps;
                for (var _i = 0; _i < _nc; _i++) {
                    var _a = anchor_of(_i, _ox, _oy, _img, facing);
                    loom_chain_step(chains[_i], cfgs[_i], world,
                        lerp(prev_ax[_i], _a[0], _u), lerp(prev_ay[_i], _a[1], _u));
                }
            }
            for (var _i = 0; _i < _nc; _i++) {
                var _a = anchor_of(_i, _ox, _oy, _img, facing);
                prev_ax[_i] = _a[0];
                prev_ay[_i] = _a[1];
            }
        }
        last_x = _ox;
        last_y = _oy;
        return self;
    };

    /// @function draw()
    /// @description Draw every chain with its configured renderer (see loom_render.gml).
    ///              Draw order is chain order in the preset — capes list body-behind layers first.
    static draw = function () {
        var _nc = array_length(chains);
        for (var _i = 0; _i < _nc; _i++) {
            loom_render_chain(chains[_i], cfgs[_i], facing);
        }
        return self;
    };
}
