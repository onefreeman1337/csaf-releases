/// ============================================================================================
/// LOOM · loom_preset — the finished adornments. Six one-line products:
///
///   loom_preset_cape([length], [col], [trim])     one cloth ribbon, trimmed edge, colliders on
///   loom_preset_hair([length], [col])             five phase-spread strands, springy
///   loom_preset_tail([length], [col])             one thick springy strand pair
///   loom_preset_rope([length], [col])             heavy, no stiffness, floor-aware
///   loom_preset_chain([length], [col])            forged links, heavy sway
///   loom_preset_pennant([length], [col], [tail_x], [tail_y])
///                                                 cloth strung between TWO points (pin_tail)
///
/// Every preset returns plain data: a struct with a chains[] array whose every field is
/// documented in loom_core.gml. Nothing is hidden — copy one, change three numbers, and it is
/// your own preset. Colours are optional; pass undefined (or nothing) for the house palette.
///
/// A NOTE ON SCALE. Lengths are in pixels and default to a 2x-pixel-art scale (a 96px-tall
/// character). For HD scenes multiply length and width; the physics is resolution-agnostic.
/// ============================================================================================

/// Base chain config — every field present, so core and render never probe for missing keys.
/// Presets override what they need. See loom_core.gml for field meanings.
function __loom_chain_defaults() {
    return {
        // sim
        n: 14,
        seg: 7,
        gravity: 1,
        drag: 2.2,
        stiffness: 0,
        wind: 1,
        iters: 3,
        pin_tail: false,
        tail_x: 0,
        tail_y: 0,
        collide: false,
        // binding
        anchor: [0, 0],      // offset from owner, +x = facing direction (mirrored automatically)
        hang: [0, 1],        // rest direction on placement, facing-relative
        // render
        render: LOOM_RENDER.RIBBON,
        width: 16,
        width_min: 2,
        taper: 0.85,         // width exponent along length (higher = faster narrowing)
        shading: 0.7,        // 0 = flat, 1 = full light response
        shadow: 3,           // drop-shadow offset px, 0 = off
        trim: 0,             // edge trim thickness px, 0 = off
        strands: 5,          // STRANDS mode only
        sprite: -1,          // TEXTURED mode only
        // palette (house defaults set per preset)
        col_root: 0,
        col_tip: 0,
        col_shade: 0,
        col_trim: 0,
        col_shadow: 0,
    };
}

/// House palette. GML colour literals are BGR ($BBGGRR) — a measured trap from Kinetic UI —
/// so every colour in Loom is declared with make_colour_rgb(r, g, b), where the ambiguity
/// cannot arise.
function __loom_col_crimson()      { return make_colour_rgb(184, 50, 62); }
function __loom_col_crimson_deep() { return make_colour_rgb(94, 21, 32); }
function __loom_col_gold()         { return make_colour_rgb(224, 180, 90); }
function __loom_col_amber()        { return make_colour_rgb(214, 148, 62); }
function __loom_col_amber_deep()   { return make_colour_rgb(122, 70, 28); }
function __loom_col_hemp()         { return make_colour_rgb(169, 138, 94); }
function __loom_col_hemp_deep()    { return make_colour_rgb(96, 74, 46); }
function __loom_col_steel()        { return make_colour_rgb(154, 164, 178); }
function __loom_col_steel_deep()   { return make_colour_rgb(66, 74, 88); }
function __loom_col_night()        { return make_colour_rgb(10, 8, 18); }

/// @function loom_preset_cape([length_px], [col], [col_trim])
/// @description A hero cape: one cloth ribbon, root at the shoulders, gold-trimmed edge,
///              body collider ON so it drapes around the wearer. Attach with anchor_frames()
///              for shoulder-accurate riding through a run cycle.
function loom_preset_cape(_len = 92, _col = undefined, _trim_col = undefined) {
    if (is_undefined(_col)) _col = __loom_col_crimson();
    if (is_undefined(_trim_col)) _trim_col = __loom_col_gold();
    var _c = __loom_chain_defaults();
    _c.n = 16;
    _c.seg = _len / (_c.n - 1);
    _c.drag = 2.6;
    _c.stiffness = 0.32;      // cloth body: folds, does not noodle
    _c.wind = 1.25;
    _c.collide = true;
    _c.anchor = [-6, -30];    // behind the shoulder of a ~96px character
    _c.hang = [-0.35, 1];     // rests trailing slightly behind the facing
    _c.width = 26;
    _c.width_min = 7;
    _c.taper = 0.55;          // capes stay broad, then round off
    _c.trim = 3;
    _c.col_root = _col;
    _c.col_tip = merge_colour(_col, __loom_col_night(), 0.35);
    _c.col_shade = __loom_col_crimson_deep();
    _c.col_trim = _trim_col;
    _c.col_shadow = __loom_col_night();
    return { chains: [_c], fixed_dt: 1 / 120, max_steps: 8, gravity_y: 900 };
}

/// @function loom_preset_hair([length_px], [col])
/// @description Long hair: three chains (back sheet + two side locks), each rendered as
///              phase-spread strands. Springy — holds an arc instead of hanging dead.
function loom_preset_hair(_len = 54, _col = undefined) {
    if (is_undefined(_col)) _col = __loom_col_amber();
    var _mk = function (_len, _col, _n, _w, _ax, _ay, _strands) {
        var _c = __loom_chain_defaults();
        _c.n = _n;
        _c.seg = _len / (_c.n - 1);
        _c.drag = 3.2;
        _c.stiffness = 0.55;
        _c.wind = 1.1;
        _c.anchor = [_ax, _ay];
        _c.hang = [-0.2, 1];
        _c.render = LOOM_RENDER.STRANDS;
        _c.strands = _strands;
        _c.width = _w;
        _c.width_min = 1.5;
        _c.taper = 0.7;
        _c.shadow = 2;
        _c.col_root = _col;
        _c.col_tip = merge_colour(_col, __loom_col_amber_deep(), 0.6);
        _c.col_shade = __loom_col_amber_deep();
        _c.col_trim = _col;
        _c.col_shadow = __loom_col_night();
        return _c;
    };
    return {
        chains: [
            _mk(_len,        _col, 10, 13, -7, -40, 5),   // back sheet
            _mk(_len * 0.72, _col, 8,  7,  -2, -42, 3),   // side lock
            _mk(_len * 0.5,  _col, 7,  5,   3, -43, 3),   // front wisp
        ],
        fixed_dt: 1 / 120, max_steps: 8, gravity_y: 900,
    };
}

/// @function loom_preset_tail([length_px], [col])
/// @description A creature tail: thick, springy, carries momentum. STRANDS with a tight
///              bundle so it reads as one muscled shape with fur direction, not a noodle.
function loom_preset_tail(_len = 66, _col = undefined) {
    if (is_undefined(_col)) _col = __loom_col_amber();
    var _c = __loom_chain_defaults();
    _c.n = 12;
    _c.seg = _len / (_c.n - 1);
    _c.drag = 2.8;
    _c.stiffness = 0.68;      // the spring: a tail holds its curl
    _c.wind = 0.5;
    _c.gravity = 0.55;        // muscle carries some of its own weight
    _c.anchor = [-10, -8];
    _c.hang = [-0.8, 0.45];
    _c.render = LOOM_RENDER.STRANDS;
    _c.strands = 3;
    _c.width = 12;
    _c.width_min = 2.5;
    _c.taper = 0.8;
    _c.shadow = 2;
    _c.col_root = _col;
    _c.col_tip = merge_colour(_col, c_white, 0.45);   // pale tail tip
    _c.col_shade = __loom_col_amber_deep();
    _c.col_trim = _col;
    _c.col_shadow = __loom_col_night();
    return { chains: [_c], fixed_dt: 1 / 120, max_steps: 8, gravity_y: 900 };
}

/// @function loom_preset_rope([length_px], [col])
/// @description Hanging rope: zero stiffness, high sag, floor-aware (set_floor on the rig to
///              let slack pile up). Grab any node and the rest follows — see the demo's
///              rope page for the drag pattern.
function loom_preset_rope(_len = 150, _col = undefined) {
    if (is_undefined(_col)) _col = __loom_col_hemp();
    var _c = __loom_chain_defaults();
    _c.n = 22;
    _c.seg = _len / (_c.n - 1);
    _c.drag = 1.6;
    _c.stiffness = 0;
    _c.wind = 0.8;
    _c.collide = true;
    _c.anchor = [0, 0];
    _c.hang = [0, 1];
    _c.width = 7;
    _c.width_min = 5;
    _c.taper = 0.08;          // ropes do not taper; the tiny value rounds the tip
    _c.shading = 0.85;
    _c.shadow = 2;
    _c.col_root = _col;
    _c.col_tip = merge_colour(_col, __loom_col_hemp_deep(), 0.4);
    _c.col_shade = __loom_col_hemp_deep();
    _c.col_trim = _col;
    _c.col_shadow = __loom_col_night();
    return { chains: [_c], fixed_dt: 1 / 120, max_steps: 8, gravity_y: 900 };
}

/// @function loom_preset_chain([length_px], [col])
/// @description Forged chain: real alternating links (rings and edge-on bars), heavy — low
///              drag, high gravity, no wind response worth noting. Hang a lantern off the
///              last node (chain.px[chain.n-1]) as the demo does.
function loom_preset_chain(_len = 130, _col = undefined) {
    if (is_undefined(_col)) _col = __loom_col_steel();
    var _c = __loom_chain_defaults();
    _c.n = 14;
    _c.seg = _len / (_c.n - 1);
    _c.drag = 0.9;            // metal swings long
    _c.stiffness = 0;
    _c.wind = 0.25;
    _c.gravity = 1.35;        // heavy
    _c.anchor = [0, 0];
    _c.hang = [0, 1];
    _c.render = LOOM_RENDER.CHAIN;
    _c.width = 13;            // link diameter
    _c.shadow = 2;
    _c.col_root = _col;
    _c.col_tip = _col;
    _c.col_shade = __loom_col_steel_deep();
    _c.col_trim = merge_colour(_col, c_white, 0.5);   // specular ping on ring tops
    _c.col_shadow = __loom_col_night();
    return { chains: [_c], fixed_dt: 1 / 120, max_steps: 10, gravity_y: 900 };
}

/// @function loom_preset_pennant([length_px], [col], [tail_dx], [tail_dy])
/// @description A banner strung between TWO points: the anchor and a tail pin offset
///              (tail_dx, tail_dy) from it. The cloth billows between them in the wind —
///              set a gust on the rig and it breathes.
function loom_preset_pennant(_len = 120, _col = undefined, _tail_dx = 110, _tail_dy = 6) {
    if (is_undefined(_col)) _col = make_colour_rgb(70, 130, 158);
    var _c = __loom_chain_defaults();
    _c.n = 18;
    _c.seg = _len / (_c.n - 1);
    _c.drag = 2.4;
    _c.stiffness = 0.18;
    _c.wind = 1.6;
    _c.pin_tail = true;
    // tail_x/y are set ABSOLUTELY each frame by the caller (they are world coords); the demo
    // updates them relative to the anchor. Stored here as the initial offset.
    _c.tail_x = _tail_dx;
    _c.tail_y = _tail_dy;
    _c.anchor = [0, 0];
    _c.hang = [1, 0.05];
    _c.width = 30;
    _c.width_min = 24;
    _c.taper = 0.12;
    _c.trim = 3;
    _c.col_root = _col;
    _c.col_tip = merge_colour(_col, __loom_col_night(), 0.3);
    _c.col_shade = merge_colour(_col, __loom_col_night(), 0.55);
    _c.col_trim = __loom_col_gold();
    _c.col_shadow = __loom_col_night();
    return { chains: [_c], fixed_dt: 1 / 120, max_steps: 8, gravity_y: 900 };
}
