/// ============================================================================================
/// LOOM · loom_render — the draw layer. This is the half of the product a buyer SEES.
///
/// Loom never draws debug line segments unless you ask it to (loom_render_debug). Every preset
/// renders finished geometry:
///
///   LOOM_RENDER.RIBBON    Tapered triangle-strip ribbon. The centreline is Catmull-Rom
///                         smoothed (render-only — the sim stays untouched), width follows a
///                         taper curve, colour ramps root->tip, and a directional light term
///                         shades each face by its normal, so folds read as folds. Optional
///                         edge trim line (a cape's gold border) and drop shadow.
///   LOOM_RENDER.STRANDS   The same ribbon drawn as several thin phase-offset strands — hair
///                         and tails with visual body instead of one noodle.
///   LOOM_RENDER.CHAIN     Real chain links: alternating shaded rings (annulus geometry) and
///                         edge-on bars oriented along each segment. Not a polyline.
///   LOOM_RENDER.TEXTURED  The ribbon mapped with YOUR sprite, texture-page-safe: UVs come
///                         from sprite_get_uvs(), so a sprite that shares a texture page maps
///                         correctly. Shading still applies via vertex colour.
///
/// Everything here draws in whatever coordinate space you call it from (room or GUI); Loom
/// itself references no rooms, no layers, no cameras.
/// ============================================================================================

enum LOOM_RENDER {
    RIBBON,
    STRANDS,
    CHAIN,
    TEXTURED,
    DEBUG_LINES,
}

/// @function loom_render_chain(chain, cfg, facing)
/// @description Draw one chain with its configured renderer. Called by LoomRig.draw(); call it
///              directly only if you are compositing manually.
function loom_render_chain(_c, _cfg, _facing) {
    switch (_cfg.render) {
        case LOOM_RENDER.RIBBON:   __loom_draw_ribbon(_c, _cfg, _facing); break;
        case LOOM_RENDER.STRANDS:  __loom_draw_strands(_c, _cfg, _facing); break;
        case LOOM_RENDER.CHAIN:    __loom_draw_links(_c, _cfg); break;
        case LOOM_RENDER.TEXTURED: __loom_draw_textured(_c, _cfg); break;
        default:                   loom_render_debug(_c); break;
    }
}

/// @function loom_render_debug(chain)
/// @description Bare polyline + node dots. For development only; no preset uses it.
function loom_render_debug(_c) {
    draw_set_colour(c_lime);
    for (var _i = 0; _i < _c.n - 1; _i++) {
        draw_line(_c.px[_i], _c.py[_i], _c.px[_i + 1], _c.py[_i + 1]);
    }
    for (var _i = 0; _i < _c.n; _i++) {
        draw_circle(_c.px[_i], _c.py[_i], 2, false);
    }
}

/// --------------------------------------------------------------------------------------------
/// Internal: resampled, smoothed centreline.
/// Catmull-Rom through the sim nodes, LOOM_SMOOTH_SUB points per segment. Render-only: the
/// physics never sees these points, so smoothing costs nothing in behaviour. Returns
/// [xs, ys, count] as a struct of arrays.
/// --------------------------------------------------------------------------------------------

#macro LOOM_SMOOTH_SUB 3

function __loom_smooth(_c) {
    var _n = _c.n;
    var _out_n = (_n - 1) * LOOM_SMOOTH_SUB + 1;
    var _xs = array_create(_out_n, 0);
    var _ys = array_create(_out_n, 0);
    var _k = 0;
    for (var _i = 0; _i < _n - 1; _i++) {
        // Catmull-Rom needs p(i-1), p(i), p(i+1), p(i+2); clamp at the ends.
        var _i0 = max(_i - 1, 0);
        var _i2 = _i + 1;
        var _i3 = min(_i + 2, _n - 1);
        var _x0 = _c.px[_i0]; var _y0 = _c.py[_i0];
        var _x1 = _c.px[_i];  var _y1 = _c.py[_i];
        var _x2 = _c.px[_i2]; var _y2 = _c.py[_i2];
        var _x3 = _c.px[_i3]; var _y3 = _c.py[_i3];
        for (var _s = 0; _s < LOOM_SMOOTH_SUB; _s++) {
            var _t = _s / LOOM_SMOOTH_SUB;
            var _t2 = _t * _t;
            var _t3 = _t2 * _t;
            _xs[_k] = 0.5 * ((2 * _x1) + (-_x0 + _x2) * _t
                + (2 * _x0 - 5 * _x1 + 4 * _x2 - _x3) * _t2
                + (-_x0 + 3 * _x1 - 3 * _x2 + _x3) * _t3);
            _ys[_k] = 0.5 * ((2 * _y1) + (-_y0 + _y2) * _t
                + (2 * _y0 - 5 * _y1 + 4 * _y2 - _y3) * _t2
                + (-_y0 + 3 * _y1 - 3 * _y2 + _y3) * _t3);
            _k++;
        }
    }
    _xs[_k] = _c.px[_n - 1];
    _ys[_k] = _c.py[_n - 1];
    return { xs: _xs, ys: _ys, n: _out_n };
}

/// Width at parameter t (0 root -> 1 tip): base width shaped by the taper exponent, with a
/// soft nose so the root does not start as a hard rectangle edge.
function __loom_width_at(_cfg, _t) {
    var _w = _cfg.width * power(1 - _t, _cfg.taper);
    return max(_w, _cfg.width_min);
}

/// Shade a base colour by the ribbon face normal against a fixed key light from upper-left.
/// merge toward white on lit faces, toward the shade colour on away faces — vertex-colour
/// shading, no shaders, so it runs identically on every export target.
function __loom_shade(_col, _shade_col, _nx, _ny, _amount) {
    // Light direction ~ (-0.55, -0.83) normalised; lit = dot(normal, -light)
    var _lit = _nx * 0.55 + _ny * 0.83;   // -1 .. 1
    if (_lit >= 0) {
        return merge_colour(_col, c_white, min(_lit * _amount * 0.55, 0.5));
    }
    return merge_colour(_col, _shade_col, min(-_lit * _amount, 1));
}

/// Core ribbon strip drawer used by RIBBON, STRANDS and (with a texture) TEXTURED.
/// Draws the smoothed centreline as a triangle strip with per-vertex colour.
///   _sm       smoothed centreline from __loom_smooth
///   _cfg      chain config
///   _wscale   width multiplier (strands pass <1)
///   _ox,_oy   positional offset (shadow pass, strand spread)
///   _col_mul  colour multiplier merge target and factor, or -1 for none (shadow pass uses flat colour)
function __loom_strip(_sm, _cfg, _wscale, _ox, _oy, _flat_col, _flat_alpha) {
    var _n = _sm.n;
    if (_n < 2) return;
    var _flat = (_flat_col >= 0);
    draw_primitive_begin(pr_trianglestrip);
    for (var _i = 0; _i < _n; _i++) {
        var _t = _i / (_n - 1);
        // Tangent from neighbours; normal is its perpendicular.
        var _ia = max(_i - 1, 0);
        var _ib = min(_i + 1, _n - 1);
        var _tx = _sm.xs[_ib] - _sm.xs[_ia];
        var _ty = _sm.ys[_ib] - _sm.ys[_ia];
        var _tl = sqrt(_tx * _tx + _ty * _ty);
        if (_tl < 0.0001) { _tx = 0; _ty = 1; } else { _tx /= _tl; _ty /= _tl; }
        var _nx = -_ty;
        var _ny = _tx;
        var _w = __loom_width_at(_cfg, _t) * 0.5 * _wscale;
        var _x = _sm.xs[_i] + _ox;
        var _y = _sm.ys[_i] + _oy;
        var _col, _alpha;
        if (_flat) {
            _col = _flat_col;
            _alpha = _flat_alpha;
        } else {
            var _base = merge_colour(_cfg.col_root, _cfg.col_tip, _t);
            _col = __loom_shade(_base, _cfg.col_shade, _nx, _ny, _cfg.shading);
            _alpha = 1;
        }
        draw_vertex_colour(_x + _nx * _w, _y + _ny * _w, _col, _alpha);
        draw_vertex_colour(_x - _nx * _w, _y - _ny * _w, _col, _alpha);
    }
    draw_primitive_end();
}

function __loom_draw_ribbon(_c, _cfg, _facing) {
    var _sm = __loom_smooth(_c);
    // Drop shadow first: same geometry, flat dark, offset down-right.
    if (_cfg.shadow > 0) {
        __loom_strip(_sm, _cfg, 1, _cfg.shadow, _cfg.shadow * 1.4, _cfg.col_shadow, 0.28);
    }
    __loom_strip(_sm, _cfg, 1, 0, 0, -1, 1);
    // Edge trim: a thin bright band along one edge — the cape's gold border. Drawn as its own
    // narrow strip offset to the edge, so it follows every fold.
    if (_cfg.trim > 0) {
        var _n = _sm.n;
        draw_primitive_begin(pr_trianglestrip);
        for (var _i = 0; _i < _n; _i++) {
            var _t = _i / (_n - 1);
            var _ia = max(_i - 1, 0);
            var _ib = min(_i + 1, _n - 1);
            var _tx = _sm.xs[_ib] - _sm.xs[_ia];
            var _ty = _sm.ys[_ib] - _sm.ys[_ia];
            var _tl = sqrt(_tx * _tx + _ty * _ty);
            if (_tl < 0.0001) { _tx = 0; _ty = 1; } else { _tx /= _tl; _ty /= _tl; }
            var _nx = -_ty * _facing;
            var _ny = _tx * _facing;
            var _w = __loom_width_at(_cfg, _t) * 0.5;
            var _x = _sm.xs[_i];
            var _y = _sm.ys[_i];
            var _col = merge_colour(_cfg.col_trim, _cfg.col_tip, _t * 0.35);
            draw_vertex_colour(_x + _nx * _w, _y + _ny * _w, _col, 1);
            draw_vertex_colour(_x + _nx * max(_w - _cfg.trim, 0), _y + _ny * max(_w - _cfg.trim, 0), _col, 1);
        }
        draw_primitive_end();
    }
}

function __loom_draw_strands(_c, _cfg, _facing) {
    var _sm = __loom_smooth(_c);
    var _k = _cfg.strands;
    if (_cfg.shadow > 0) {
        __loom_strip(_sm, _cfg, 0.9, _cfg.shadow, _cfg.shadow * 1.4, _cfg.col_shadow, 0.22);
    }
    // Back-to-front: widest strand first, then thinner brighter strands fanned across the
    // width, each with a deterministic lateral sway offset so the bundle has body.
    for (var _s = 0; _s < _k; _s++) {
        var _u = (_k == 1) ? 0 : (_s / (_k - 1)) * 2 - 1;   // -1 .. 1 across the bundle
        var _wscale = lerp(1, 0.34, abs(_u));
        var _spread = _cfg.width * 0.36 * _u * _facing;
        // Slight per-strand tint: outer strands darker, centre strand brightest.
        var _tint = 0.18 * abs(_u);
        var _n = _sm.n;
        draw_primitive_begin(pr_trianglestrip);
        for (var _i = 0; _i < _n; _i++) {
            var _t = _i / (_n - 1);
            var _ia = max(_i - 1, 0);
            var _ib = min(_i + 1, _n - 1);
            var _tx = _sm.xs[_ib] - _sm.xs[_ia];
            var _ty = _sm.ys[_ib] - _sm.ys[_ia];
            var _tl = sqrt(_tx * _tx + _ty * _ty);
            if (_tl < 0.0001) { _tx = 0; _ty = 1; } else { _tx /= _tl; _ty /= _tl; }
            var _nx = -_ty;
            var _ny = _tx;
            var _w = __loom_width_at(_cfg, _t) * 0.5 * _wscale;
            // Strands separate toward the tip (spread grows with t) — a brushed look instead
            // of one solid sheet.
            var _x = _sm.xs[_i] + _nx * _spread * _t;
            var _y = _sm.ys[_i] + _ny * _spread * _t;
            var _base = merge_colour(_cfg.col_root, _cfg.col_tip, _t);
            _base = merge_colour(_base, _cfg.col_shade, _tint);
            var _col = __loom_shade(_base, _cfg.col_shade, _nx, _ny, _cfg.shading);
            draw_vertex_colour(_x + _nx * _w, _y + _ny * _w, _col, 1);
            draw_vertex_colour(_x - _nx * _w, _y - _ny * _w, _col, 1);
        }
        draw_primitive_end();
    }
}

/// Chain links: alternating face-on rings (annulus fan) and edge-on bars (rounded quads),
/// each oriented along its segment and top-lit. Reads as forged metal, not as a polyline.
function __loom_draw_links(_c, _cfg) {
    var _n = _c.n;
    var _r = _cfg.width * 0.5;
    for (var _i = 0; _i < _n - 1; _i++) {
        var _x1 = _c.px[_i];     var _y1 = _c.py[_i];
        var _x2 = _c.px[_i + 1]; var _y2 = _c.py[_i + 1];
        var _mx = (_x1 + _x2) * 0.5;
        var _my = (_y1 + _y2) * 0.5;
        var _dx = _x2 - _x1;
        var _dy = _y2 - _y1;
        var _sl = sqrt(_dx * _dx + _dy * _dy);
        if (_sl < 0.0001) { _dx = 0; _dy = 1; _sl = 1; }
        _dx /= _sl; _dy /= _sl;
        if (_cfg.shadow > 0) {
            draw_set_colour(_cfg.col_shadow);
            draw_set_alpha(0.25);
            draw_circle(_mx + _cfg.shadow, _my + _cfg.shadow * 1.4, _r * 0.9, false);
            draw_set_alpha(1);
        }
        if (_i mod 2 == 0) {
            __loom_annulus(_mx, _my, _r, _r * 0.52, _cfg.col_root, _cfg.col_shade, _cfg.col_trim);
        } else {
            // Edge-on link: a bar along the segment, slightly narrower than the ring.
            var _hw = _r * 0.34;
            var _hl = _sl * 0.52;
            var _nx = -_dy; var _ny = _dx;
            var _cl = merge_colour(_cfg.col_root, c_white, 0.18);
            var _cd = _cfg.col_shade;
            draw_primitive_begin(pr_trianglestrip);
            draw_vertex_colour(_mx - _dx * _hl + _nx * _hw, _my - _dy * _hl + _ny * _hw, _cl, 1);
            draw_vertex_colour(_mx - _dx * _hl - _nx * _hw, _my - _dy * _hl - _ny * _hw, _cd, 1);
            draw_vertex_colour(_mx + _dx * _hl + _nx * _hw, _my + _dy * _hl + _ny * _hw, _cl, 1);
            draw_vertex_colour(_mx + _dx * _hl - _nx * _hw, _my + _dy * _hl - _ny * _hw, _cd, 1);
            draw_primitive_end();
        }
    }
}

/// Solid annulus (ring with a hole) as one triangle strip around the circle, top-lit: the
/// upper arc leans toward the highlight colour, the lower toward shade.
#macro LOOM_RING_SEGS 14
function __loom_annulus(_x, _y, _ro, _ri, _col, _shade, _hi) {
    draw_primitive_begin(pr_trianglestrip);
    for (var _s = 0; _s <= LOOM_RING_SEGS; _s++) {
        var _a = (_s / LOOM_RING_SEGS) * 2 * pi;
        var _ca = cos(_a);
        var _sa = sin(_a);
        // Top-lit: -sin(a) is 1 at the top of the ring.
        var _lit = -_sa;
        var _c = (_lit >= 0)
            ? merge_colour(_col, _hi, _lit * 0.45)
            : merge_colour(_col, _shade, -_lit * 0.6);
        draw_vertex_colour(_x + _ca * _ro, _y + _sa * _ro, _c, 1);
        draw_vertex_colour(_x + _ca * _ri, _y + _sa * _ri, merge_colour(_c, _shade, 0.35), 1);
    }
    draw_primitive_end();
}

/// Textured ribbon — the buyer's sprite along the chain. TEXTURE-PAGE-SAFE: the UV rectangle
/// comes from sprite_get_uvs(), so this works whether the sprite is on a shared page or
/// "Separate Texture Page". Vertex colour still carries the shading term.
function __loom_draw_textured(_c, _cfg) {
    var _spr = _cfg.sprite;
    if (_spr < 0 || !sprite_exists(_spr)) {
        // No sprite assigned: fall back to the solid ribbon rather than drawing nothing —
        // a buyer mid-setup should see geometry, not an invisible cape.
        __loom_draw_ribbon(_c, _cfg, 1);
        return;
    }
    var _sm = __loom_smooth(_c);
    var _n = _sm.n;
    if (_n < 2) return;
    var _tex = sprite_get_texture(_spr, 0);
    var _uvs = sprite_get_uvs(_spr, 0);   // [x1, y1, x2, y2, ...] on the PAGE — the safety
    var _u0 = _uvs[0]; var _v0 = _uvs[1];
    var _u1 = _uvs[2]; var _v1 = _uvs[3];
    if (_cfg.shadow > 0) {
        __loom_strip(_sm, _cfg, 1, _cfg.shadow, _cfg.shadow * 1.4, _cfg.col_shadow, 0.28);
    }
    draw_primitive_begin_texture(pr_trianglestrip, _tex);
    for (var _i = 0; _i < _n; _i++) {
        var _t = _i / (_n - 1);
        var _ia = max(_i - 1, 0);
        var _ib = min(_i + 1, _n - 1);
        var _tx = _sm.xs[_ib] - _sm.xs[_ia];
        var _ty = _sm.ys[_ib] - _sm.ys[_ia];
        var _tl = sqrt(_tx * _tx + _ty * _ty);
        if (_tl < 0.0001) { _tx = 0; _ty = 1; } else { _tx /= _tl; _ty /= _tl; }
        var _nx = -_ty;
        var _ny = _tx;
        var _w = __loom_width_at(_cfg, _t) * 0.5;
        var _x = _sm.xs[_i];
        var _y = _sm.ys[_i];
        var _col = __loom_shade(c_white, _cfg.col_shade, _nx, _ny, _cfg.shading);
        var _v = lerp(_v0, _v1, _t);   // sprite V runs root -> tip along the chain
        draw_vertex_texture_colour(_x + _nx * _w, _y + _ny * _w, _u0, _v, _col, 1);
        draw_vertex_texture_colour(_x - _nx * _w, _y - _ny * _w, _u1, _v, _col, 1);
    }
    draw_primitive_end();
}
