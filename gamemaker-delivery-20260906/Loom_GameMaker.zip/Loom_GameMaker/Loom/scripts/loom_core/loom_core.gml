/// ============================================================================================
/// LOOM · loom_core — the pure simulation core.
///
/// ZERO engine calls. Nothing in this file reads an instance variable, a room, a sprite, the
/// clock or the renderer; the only built-ins used are pure maths (sin/cos/sqrt/min/max/abs/
/// clamp/lerp/floor/power). That is deliberate: GML cannot be unit-tested outside GameMaker,
/// so the entire behaviour of Loom lives where it can at least be read, reasoned about and
/// mirrored numerically in isolation. Everything impure sits in loom_bind (input) and
/// loom_render (output).
///
/// MODEL — position-based verlet chains.
///   A chain is N nodes. Velocity is implicit (current minus previous position), which makes
///   the integrator unconditionally stable: nodes can never gain energy from the integration
///   step itself. Constraints (segment length, stiffness, colliders) are enforced by iterative
///   relaxation after integration — then a single root-down COLLISION-AWARE projection makes
///   every segment exactly rest length while keeping every node outside every collider.
///   "At distance seg from my parent" is a circle and "outside this collider" removes an arc
///   from it; the nearest point satisfying both is a closed-form circle-circle intersection,
///   so neither constraint is traded against the other. Measured across a 7-scene matrix
///   (Internal_Ops/probe_order_matrix.js): 0.00% stretch AND 0.00px penetration in every
///   scene where the anchor itself is outside the body; sequential orderings left one or the
///   other violated in every colliding scene (up to 5.34px persistent penetration or 680%
///   stretch). Chains with a pinned tail (banners) skip the projection — it would break the
///   tail pin — and use the plain push-out collider pass instead.
///
/// FRAME-RATE INDEPENDENCE — the fixed-substep accumulator.
///   loom_world_steps() converts real elapsed seconds into a whole number of fixed-size
///   substeps (default 1/120 s), carrying the remainder. The same wall-clock time therefore
///   produces the same substep sequence at 30, 60, 144 or 240 Hz — behaviour is identical on
///   every display, and a run of the demo is deterministic end to end (the wind field below is
///   a pure function of time, never random). The substep count is capped; under extreme load
///   Loom slows down rather than exploding.
///
/// Public API (everything else in this file is internal and prefixed __loom_):
///   loom_world_create([fixed_dt], [max_steps])          -> world struct
///   loom_world_steps(world, dt_seconds)                 -> substeps to run this frame
///   loom_world_set_wind(world, wx, wy, gust, turbulence)
///   loom_wind_at(world, x, y)                           -> [wx, wy] at a point, now
///   loom_chain_create(n, seg)                           -> chain struct
///   loom_chain_place(chain, x, y, dx, dy)               -> lay chain out straight, at rest
///   loom_chain_step(chain, cfg, world, ax, ay)          -> one fixed substep
///   loom_chain_len(chain)                               -> total rest length
///
/// cfg is a plain struct read via cfg.field. ⚠️ THE loom_preset_* FUNCTIONS DO NOT RETURN ONE —
/// they return a RIG preset, `{ chains: [cfg, ...], fixed_dt, max_steps, gravity_y }`, because a
/// rig can carry several chains. So when driving the core directly, the cfg is INSIDE it:
///
///   var _cfg = loom_preset_rope().chains[0];        // <- the chain cfg
///   loom_chain_step(_chain, _cfg, _world, _ax, _ay);
///
/// Passing the preset itself fails as `<unknown_object>.drag not set before reading it`, which
/// names a field rather than the mistake. LoomRig does this unwrapping for you (loom_bind builds
/// `cfgs` from `preset.chains`), so this only bites callers using the pure core — which is exactly
/// what this section is for. Fields:
///   gravity     px/s^2 scale applied to world gravity (1 = full, 0 = weightless)
///   drag        per-second velocity damping, 0..~8. Higher = heavier air.
///   stiffness   0..1 bending resistance. 0 = rope, ~0.35 = cloth, ~0.7 = springy tail.
///   wind        0..~2 how much the world wind field moves this chain.
///   iters       constraint relaxation passes per substep (2..4; presets choose).
///   pin_tail    bool — pin the last node too (banners strung between two points).
///   tail_x/y    where the tail pin sits (world space), when pin_tail is true.
///   collide     bool — run collider pass.
/// ============================================================================================

/// @function loom_world_create([fixed_dt], [max_steps])
/// @description Create a Loom world: the fixed-substep clock plus the global fields (gravity,
///              wind) every chain in a rig shares. One world per rig; worlds are cheap.
/// @param {real} [fixed_dt]  Substep size in seconds. Default 1/120.
/// @param {real} [max_steps] Substep cap per frame (spiral-of-death guard). Default 8.
function loom_world_create(_fixed_dt = 1 / 120, _max_steps = 8) {
    return {
        fixed_dt: _fixed_dt,
        max_steps: _max_steps,
        accum: 0,          // unconsumed real time, seconds
        t: 0,              // simulation time, seconds — advances only by whole substeps
        gx: 0,
        gy: 900,           // px/s^2. Tuned for pixel scenes; presets scale per chain.
        wind_x: 0,         // steady wind, px/s^2
        wind_y: 0,
        gust: 0,           // gust amplitude, px/s^2 (0 = still air)
        turb: 1,           // spatial turbulence frequency multiplier
        floor_y: -1,       // world floor plane; -1 = none
        floor_friction: 0.6,
        colliders: [],     // flat array [x, y, r, x, y, r, ...] — see loom_world_add_collider
    };
}

/// @function loom_world_steps(world, dt_seconds)
/// @description Feed real elapsed time in; get back how many fixed substeps to run now. The
///              remainder stays in the accumulator, so timing error never accumulates across
///              frames. The sim clock is NOT advanced here — call loom_world_advance() once
///              per substep you actually run, so the wind field sees substep-granular time.
/// @param {struct} world
/// @param {real}   dt_seconds  Real seconds since last call. THE CALLER converts engine time;
///                             GameMaker's delta_time is MICROSECONDS and that division lives
///                             in loom_bind, in exactly one place.
function loom_world_steps(_world, _dt_s) {
    if (is_undefined(_world) || !is_struct(_world) || !variable_struct_exists(_world, "accum")) return 0;
    if (!is_real(_dt_s)) return 0;
    // Clamp a single pathological frame (debugger pause, window drag) to something sane
    // before it enters the accumulator: 0.25 s of catch-up at most.
    _world.accum += min(max(_dt_s, 0), 0.25);
    var _steps = floor(_world.accum / _world.fixed_dt);
    if (_steps > _world.max_steps) {
        // Under load: run the cap, DROP the remainder. The sim slows instead of spiralling —
        // dropped time is forgotten, not owed.
        _steps = _world.max_steps;
        _world.accum = 0;
    } else {
        _world.accum -= _steps * _world.fixed_dt;
    }
    return _steps;
}

/// @function loom_world_advance(world)
/// @description Advance the sim clock by one fixed substep. Call exactly once per substep,
///              before stepping the chains of that substep (loom_bind does this).
function loom_world_advance(_world) {
    if (is_undefined(_world) || !is_struct(_world)) return;
    _world.t += _world.fixed_dt;
}

/// @function loom_world_set_wind(world, wx, wy, gust, turbulence)
/// @description Set the wind field. Steady component plus a gust amplitude; gusts are a pure
///              deterministic function of (time, position) — two identical runs produce
///              identical motion, which is what makes captures and replays repeatable.
function loom_world_set_wind(_world, _wx, _wy, _gust, _turb = 1) {
    if (is_undefined(_world) || !is_struct(_world) || !variable_struct_exists(_world, "wind_x")) return;
    // Refuse the whole call rather than storing a non-number: see the note under this function.
    if (!is_real(_wx) || !is_real(_wy) || !is_real(_gust) || !is_real(_turb)) return;
    _world.wind_x = _wx;
    _world.wind_y = _wy;
    _world.gust = _gust;
    _world.turb = _turb;
}

/// ⛔ THE GUARD ABOVE IS INSIDE loom_world_set_wind BECAUSE A POISONED WORLD FAILS ELSEWHERE.
/// Setting any wind field to undefined does not fail at the call - it fails on the next substep,
/// inside the integrator, as a bare "undefined value" with no mention of wind. That is the third
/// member of this file's silent-corruption family (the others: an out-of-range collider index
/// auto-EXTENDING the flat triple array, and a wrong-shaped anchor-frame table). All three share a
/// shape worth naming: A SETTER THAT ACCEPTS RUBBISH TURNS ONE BAD CALL INTO A CRASH SOMEWHERE
/// ELSE, and the somewhere-else is what makes it expensive for a buyer to diagnose in a library
/// they did not write.

/// @function loom_world_add_collider(world, x, y, r)
/// @description Add a circle collider (e.g. the wearer's torso, so a cape drapes around the
///              body instead of through it). Returns the collider index for loom_world_move_collider.
function loom_world_add_collider(_world, _x, _y, _r) {
    // Refuse rather than throw, and keep the triple array WELL FORMED at all costs: every
    // reader below assumes length is a multiple of 3.
    if (is_undefined(_world) || !is_struct(_world) || !variable_struct_exists(_world, "colliders")) return -1;
    if (!is_real(_x) || !is_real(_y) || !is_real(_r)) return -1;
    array_push(_world.colliders, _x, _y, max(0, _r));
    return (array_length(_world.colliders) div 3) - 1;
}

/// @function loom_world_move_collider(world, index, x, y)
/// @description Reposition a collider each step (colliders usually ride the owner instance).
function loom_world_move_collider(_world, _i, _x, _y) {
    // ⛔ THE BOUNDS CHECK IS LOAD-BEARING, NOT DEFENSIVE POLISH. GML arrays AUTO-EXTEND on
    // write, so without this a stale index does not fail here - it grows `colliders` to a
    // length that is not a multiple of 3, pads it with undefined, and the crash surfaces
    // later inside the chain-step collider loop, naming an array index rather than this call.
    if (is_undefined(_world) || !is_struct(_world) || !variable_struct_exists(_world, "colliders")) return;
    if (!is_real(_i) || !is_real(_x) || !is_real(_y)) return;
    var _n = array_length(_world.colliders) div 3;
    if (_i < 0 || _i >= _n) return;                 // a stale index is a no-op, never a resize
    _world.colliders[_i * 3] = _x;
    _world.colliders[_i * 3 + 1] = _y;
}

/// @function loom_wind_at(world, x, y)
/// @description Sample the wind field at a point, at the current sim time. Pure and
///              deterministic: layered sinusoids, no randomness. Gusts travel spatially
///              (the phase depends on x/y), so a long cape ripples instead of shifting
///              rigidly — that travelling wave is most of what reads as "expensive".
/// @returns {array} [wx, wy] in px/s^2
function loom_wind_at(_world, _x, _y) {
    if (is_undefined(_world) || !is_struct(_world) || !variable_struct_exists(_world, "gust")) return [0, 0];
    var _g = _world.gust;
    if (_g == 0 && _world.wind_x == 0 && _world.wind_y == 0) return [0, 0];
    var _t = _world.t;
    var _f = _world.turb;
    // Three incommensurate frequencies so the pattern never visibly loops.
    var _phase = _x * 0.011 * _f + _y * 0.007 * _f;
    var _wx = _world.wind_x
        + _g * (0.62 * sin(_t * 1.7 + _phase)
              + 0.27 * sin(_t * 4.3 + _phase * 2.1 + 1.3)
              + 0.11 * sin(_t * 9.1 + _phase * 3.7 + 4.1));
    var _wy = _world.wind_y
        + _g * 0.22 * (0.7 * sin(_t * 2.3 + _phase * 1.4 + 2.2)
                     + 0.3 * sin(_t * 6.1 + _phase * 2.8 + 0.7));
    return [_wx, _wy];
}

/// @function loom_chain_create(n, seg)
/// @description Create a chain of n nodes with segment rest length seg (px). Node 0 is the
///              anchor and is always driven, never simulated. The chain starts collapsed at
///              the origin; call loom_chain_place before first use (loom_bind does this).
function loom_chain_create(_n, _seg) {
    var _c = {
        n: _n,
        seg: _seg,
        px: array_create(_n, 0),
        py: array_create(_n, 0),
        ox: array_create(_n, 0),
        oy: array_create(_n, 0),
    };
    return _c;
}

/// @function loom_chain_place(chain, x, y, dx, dy)
/// @description Lay the chain out straight from (x,y) along the normalised direction (dx,dy),
///              at rest (zero velocity). Used on creation and on teleport — never let a room
///              transition read as the cape being fired across the screen.
function loom_chain_place(_c, _x, _y, _dx, _dy) {
    if (is_undefined(_c) || !is_struct(_c) || !variable_struct_exists(_c, "n")) return;
    if (!is_real(_x) || !is_real(_y)) return;
    var _len = sqrt(_dx * _dx + _dy * _dy);
    if (_len < 0.0001) { _dx = 0; _dy = 1; } else { _dx /= _len; _dy /= _len; }
    for (var _i = 0; _i < _c.n; _i++) {
        var _nx = _x + _dx * _c.seg * _i;
        var _ny = _y + _dy * _c.seg * _i;
        _c.px[_i] = _nx; _c.py[_i] = _ny;
        _c.ox[_i] = _nx; _c.oy[_i] = _ny;
    }
}

/// @function loom_chain_len(chain)
/// @description Total rest length in px.
function loom_chain_len(_c) {
    if (is_undefined(_c) || !is_struct(_c) || !variable_struct_exists(_c, "seg")) return 0;
    return _c.seg * (_c.n - 1);
}

/// @function loom_chain_step(chain, cfg, world, ax, ay)
/// @description One fixed substep: integrate, relax constraints, then the final pass — a
///              collision-aware length projection (free tail) or a plain collider pass
///              (pinned tail; the projection would tear the tail off its pin).
///              (ax, ay) is where the anchor (node 0) is this substep — loom_bind interpolates
///              the owner's motion across substeps so fast movement stays smooth.
function loom_chain_step(_c, _cfg, _world, _ax, _ay) {
    // Refuse the three shapes a direct core caller actually gets wrong. The middle one is the
    // documented trap: loom_preset_* returns a RIG preset, and the chain cfg is preset.chains[i].
    if (is_undefined(_c) || !is_struct(_c) || !variable_struct_exists(_c, "n")) return;
    if (is_undefined(_world) || !is_struct(_world) || !variable_struct_exists(_world, "fixed_dt")) return;
    if (is_undefined(_cfg) || !is_struct(_cfg) || !variable_struct_exists(_cfg, "drag")) return;
    var _h = _world.fixed_dt;
    var _n = _c.n;
    var _damp = max(0, 1 - _cfg.drag * _h);
    var _gsx = _world.gx * _cfg.gravity;
    var _gsy = _world.gy * _cfg.gravity;
    var _wscale = _cfg.wind;
    var _hh = _h * _h;

    // --- integrate (verlet) — node 0 is the anchor, never integrated -----------------------
    for (var _i = 1; _i < _n; _i++) {
        var _x = _c.px[_i];
        var _y = _c.py[_i];
        var _vx = (_x - _c.ox[_i]) * _damp;
        var _vy = (_y - _c.oy[_i]) * _damp;
        var _fx = _gsx;
        var _fy = _gsy;
        if (_wscale != 0) {
            var _w = loom_wind_at(_world, _x, _y);
            _fx += _w[0] * _wscale;
            _fy += _w[1] * _wscale;
        }
        _c.ox[_i] = _x;
        _c.oy[_i] = _y;
        _c.px[_i] = _x + _vx + _fx * _hh;
        _c.py[_i] = _y + _vy + _fy * _hh;
    }

    // --- constraints ------------------------------------------------------------------------
    var _seg = _c.seg;
    var _iters = _cfg.iters;
    var _stiff = _cfg.stiffness;
    // Stiffness is applied per relaxation pass; scale so the LOOK is independent of iters.
    var _stiff_pass = (_stiff > 0) ? 1 - power(1 - _stiff, 1 / _iters) : 0;
    var _pin_tail = _cfg.pin_tail;

    for (var _pass = 0; _pass < _iters; _pass++) {
        // Anchor pin.
        _c.px[0] = _ax;
        _c.py[0] = _ay;

        // Distance constraints. Node 0 immovable: its neighbour takes the full correction.
        // The sweep DIRECTION alternates between passes: a root-ward sweep propagates the
        // anchor's authority tip-ward, a tip-ward sweep carries the tip's position back toward
        // the root. Measured on the 16-node cape (Internal_Ops/probe_solver.js): settle time
        // 3.87 s one-directional vs 3.22 s alternating, same everything else.
        var _down = ((_pass & 1) == 0);

        for (var _k = 0; _k < _n - 1; _k++) {
            var _i = _down ? _k : (_n - 2 - _k);
            var _x1 = _c.px[_i];     var _y1 = _c.py[_i];
            var _x2 = _c.px[_i + 1]; var _y2 = _c.py[_i + 1];
            var _dx = _x2 - _x1;
            var _dy = _y2 - _y1;
            var _d = sqrt(_dx * _dx + _dy * _dy);
            if (_d < 0.0001) { _dx = 0; _dy = 0.0001; _d = 0.0001; }
            var _diff = (_d - _seg) / _d;
            if (_i == 0) {
                // First segment: anchor cannot move.
                _c.px[1] = _x2 - _dx * _diff;
                _c.py[1] = _y2 - _dy * _diff;
            } else {
                var _half = 0.5 * _diff;
                _c.px[_i]     = _x1 + _dx * _half;
                _c.py[_i]     = _y1 + _dy * _half;
                _c.px[_i + 1] = _x2 - _dx * _half;
                _c.py[_i + 1] = _y2 - _dy * _half;
            }
        }

        // Optional tail pin (banners): snap the last node back after relaxation.
        if (_pin_tail) {
            _c.px[_n - 1] = _cfg.tail_x;
            _c.py[_n - 1] = _cfg.tail_y;
        }

        // Bending stiffness: pull each node toward the straight continuation of its parent
        // segment. Cheap (no trig), stable, and reads as cloth body / hair spring.
        if (_stiff_pass > 0) {
            for (var _i = 2; _i < _n; _i++) {
                var _bx = _c.px[_i - 1]; var _by = _c.py[_i - 1];
                var _dx2 = _bx - _c.px[_i - 2];
                var _dy2 = _by - _c.py[_i - 2];
                var _d2 = sqrt(_dx2 * _dx2 + _dy2 * _dy2);
                if (_d2 < 0.0001) continue;
                var _tx = _bx + (_dx2 / _d2) * _seg;
                var _ty = _by + (_dy2 / _d2) * _seg;
                _c.px[_i] = lerp(_c.px[_i], _tx, _stiff_pass);
                _c.py[_i] = lerp(_c.py[_i], _ty, _stiff_pass);
            }
        }
    }

    // --- final pass -------------------------------------------------------------------------
    // Free-tailed chains get the collision-aware projection: exact segment lengths AND no
    // node inside any collider, in one root-down sweep (see header). Pinned-tail chains keep
    // the plain push-out pass — a root-down projection would tear the tail off its pin.
    if (!_pin_tail) {
        __loom_project_aware(_c, _cfg, _world, _ax, _ay);
    } else if (_cfg.collide) {
        __loom_collide(_c, _cfg, _world);
    }
}

/// @function __loom_collide(chain, cfg, world)
/// @description INTERNAL. Plain push-out collider pass: any node inside a circle collider is
///              moved radially to its surface; any node below the floor is clamped to it with
///              tangential friction. Used for pinned-tail chains only — free-tailed chains go
///              through __loom_project_aware, which resolves contact and length together.
function __loom_collide(_c, _cfg, _world) {
    var _n = _c.n;
    var _cols = _world.colliders;
    var _nc = array_length(_cols);
    if (_nc > 0) {
        for (var _i = 1; _i < _n; _i++) {
            var _x = _c.px[_i];
            var _y = _c.py[_i];
            for (var _k = 0; _k < _nc; _k += 3) {
                var _cx = _cols[_k];
                var _cy = _cols[_k + 1];
                var _r = _cols[_k + 2];
                var _ddx = _x - _cx;
                var _ddy = _y - _cy;
                var _dd = _ddx * _ddx + _ddy * _ddy;
                if (_dd < _r * _r && _dd > 0.000001) {
                    var _dl = sqrt(_dd);
                    _x = _cx + (_ddx / _dl) * _r;
                    _y = _cy + (_ddy / _dl) * _r;
                    _c.px[_i] = _x;
                    _c.py[_i] = _y;
                }
            }
        }
    }
    var _fy = _world.floor_y;
    if (_fy >= 0) {
        var _fr = _world.floor_friction;
        for (var _i = 1; _i < _n; _i++) {
            if (_c.py[_i] > _fy) {
                _c.py[_i] = _fy;
                // Ground friction: bleed tangential velocity so fabric settles, not skates.
                _c.ox[_i] = lerp(_c.ox[_i], _c.px[_i], _fr);
            }
        }
    }
}

/// @function __loom_project_aware(chain, cfg, world, ax, ay)
/// @description INTERNAL. Root-down projection satisfying BOTH the segment-length and the
///              collider constraint exactly, instead of letting whichever pass ran last win.
///              For each node in root-to-tip order: place it at exactly seg from its (already
///              resolved) parent along its current direction; if that point is inside a
///              collider, move it to the nearest circle-circle intersection of the seg-circle
///              and the collider surface — closed form, no iteration, no tuning constant.
///              Root-down order is what makes this safe: the parent is already on-or-outside
///              every collider, so the degenerate "whole seg-circle swallowed" case only
///              arises when the OWNER drives the anchor inside its own collider; the fallback
///              (radial push, accept the stretch) keeps that case penetration-free, and the
///              stretched segment is hidden inside the body it emerges from.
///              When cfg.collide is false this degrades to a pure length projection, which is
///              what removes the ~6% sag-stretch a relax-only solver leaves at rest.
function __loom_project_aware(_c, _cfg, _world, _ax, _ay) {
    _c.px[0] = _ax;
    _c.py[0] = _ay;
    var _seg = _c.seg;
    var _n = _c.n;
    var _use_cols = _cfg.collide;
    var _cols = _world.colliders;
    var _nc = _use_cols ? array_length(_cols) : 0;
    var _fy = _use_cols ? _world.floor_y : -1;

    for (var _i = 1; _i < _n; _i++) {
        var _ppx = _c.px[_i - 1];
        var _ppy = _c.py[_i - 1];
        var _dx = _c.px[_i] - _ppx;
        var _dy = _c.py[_i] - _ppy;
        var _d = sqrt(_dx * _dx + _dy * _dy);
        if (_d < 0.0001) { _dx = 0; _dy = 1; _d = 1; }
        var _tx = _ppx + (_dx / _d) * _seg;
        var _ty = _ppy + (_dy / _d) * _seg;

        // Two sweeps: with overlapping colliders, escaping one can enter another.
        for (var _rep = 0; _rep < 2; _rep++) {
            var _moved = false;
            for (var _k = 0; _k < _nc; _k += 3) {
                var _cx = _cols[_k];
                var _cy = _cols[_k + 1];
                var _r = _cols[_k + 2];
                var _vx = _tx - _cx;
                var _vy = _ty - _cy;
                if (_vx * _vx + _vy * _vy >= _r * _r) continue;   // already clear of this one
                var _ux = _cx - _ppx;
                var _uy = _cy - _ppy;
                var _dist = sqrt(_ux * _ux + _uy * _uy);
                if (_dist < 0.000001 || _dist > _seg + _r || _dist < abs(_seg - _r)) {
                    // No circle-circle solution (anchor driven inside the body): radial push,
                    // accept the stretch — it stays hidden inside the collider.
                    var _vl = max(sqrt(_vx * _vx + _vy * _vy), 0.000001);
                    _tx = _cx + (_vx / _vl) * _r;
                    _ty = _cy + (_vy / _vl) * _r;
                    _moved = true;
                    continue;
                }
                var _a = (_seg * _seg - _r * _r + _dist * _dist) / (2 * _dist);
                var _hh2 = sqrt(max(0, _seg * _seg - _a * _a));
                var _bx = _ppx + (_ux / _dist) * _a;
                var _by = _ppy + (_uy / _dist) * _a;
                var _perpx = -_uy / _dist;
                var _perpy = _ux / _dist;
                var _s1x = _bx + _perpx * _hh2;
                var _s1y = _by + _perpy * _hh2;
                var _s2x = _bx - _perpx * _hh2;
                var _s2y = _by - _perpy * _hh2;
                var _q1 = (_s1x - _tx) * (_s1x - _tx) + (_s1y - _ty) * (_s1y - _ty);
                var _q2 = (_s2x - _tx) * (_s2x - _tx) + (_s2y - _ty) * (_s2y - _ty);
                if (_q1 <= _q2) { _tx = _s1x; _ty = _s1y; } else { _tx = _s2x; _ty = _s2y; }
                _moved = true;
            }
            if (!_moved) break;
        }

        // Floor plane, same idea: slide along the seg-circle to y = floor rather than clamping
        // y, which would shorten the segment.
        if (_fy >= 0 && _ty > _fy) {
            var _dyf = _fy - _ppy;
            if (abs(_dyf) <= _seg) {
                var _dxf = sqrt(max(0, _seg * _seg - _dyf * _dyf));
                var _c1 = _ppx + _dxf;
                var _c2 = _ppx - _dxf;
                _tx = (abs(_c1 - _tx) <= abs(_c2 - _tx)) ? _c1 : _c2;
                _ty = _fy;
            } else {
                _ty = _fy;   // parent further than seg above the floor: clamp, accept stretch
            }
            _c.ox[_i] = lerp(_c.ox[_i], _tx, _world.floor_friction);
        }

        _c.px[_i] = _tx;
        _c.py[_i] = _ty;
    }
}
