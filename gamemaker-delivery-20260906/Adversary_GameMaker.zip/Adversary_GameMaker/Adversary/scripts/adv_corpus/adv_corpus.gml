/// adv_corpus.gml — THE BOSS PLANS. Fourteen archetypes, three phases each.
///
/// ============================================================================================
/// WHAT THIS FILE IS, AND WHY THE TELL LIVES IN THE SAME RECORD AS THE LIMB
/// ============================================================================================
/// The GameMaker asset shelf sells boss products in two halves and never couples them: the ART
/// half ships a fixed boss you cannot alter, and the WIRING half ships behaviour with no body.
/// Buy both and you still have to keep them in sync by hand, forever - because the telegraph a
/// player reads ("the left arm is winding up") is authored in one place and the arm is drawn in
/// another.
///
/// So in this package a limb record is the ONLY source of truth for both. `adv_body` draws the
/// limb from it; `adv_tell` derives the telegraph arc from it. Neither holds its own copy of the
/// reach, the pivot or the sweep. That is the whole product, and it is asserted rather than
/// claimed: adv_selftest sweeps every plan, phase and limb and requires the telegraph's radius to
/// equal the limb's DRAWN reach. Lengthen an arm and its tell grows on the next frame; you cannot
/// get them out of step without failing the suite.
///
/// ⚠️ A LIMB RECORD IS READ BY TWO CONSUMERS, SO ITS UNITS ARE STATED ONCE, HERE, AND NEVER
/// RE-DERIVED. Wing CLAUDE.md carries this as a law with a receipt: `pas_ring` took a radius in
/// board space and a band thickness in pixels, seven callers passed pixels for both, and one
/// filled annulus painted over an entire store sheet while 689 in-engine assertions stayed green.
/// Every field below therefore names its unit in its comment.
///
///   at      - attachment station along the core, 0 at the crown end, 1 at the tail end. UNITLESS.
///   ang     - rest angle from the core's outward normal, RADIANS, signed, positive = toward the
///             tail. It is mirrored by side, so `adv_body` multiplies by side and must not negate
///             it again (wing CLAUDE.md: "an angle that is already signed must not be negated by
///             the mirror" - that shipped an entire corpus built upside down).
///   segs    - number of rigid segments. INTEGER >= 1.
///   len     - TOTAL limb length as a fraction of the core's height. UNITLESS, so it scales.
///   taper   - width at the tip as a fraction of width at the root. UNITLESS, 0..1.
///   term    - the terminal form (see ADV_TERM_*), which is what a player actually reads.
///   role    - what the limb DOES. Only ADV_ROLE_STRIKE limbs generate a telegraph; a support
///             leg that never attacks must not draw one, and the suite asserts that.
///
/// And on the core and shell, both of which are read by adv_body:
///
///   core.form     - which of the eight silhouettes in `adv_core_forms` this body is. UNITLESS
///                   INDEX. ⛔ Added after the first contact sheet was baked and looked at: the
///                   half-width function had been a symmetric lens, so `profile` was the only
///                   shape control and every one of these fourteen rows drew THE SAME EGG. See
///                   adv_limb's form-family header for why no parameter could have fixed it.
///   core.profile  - FULLNESS within that form, 0 gaunt .. 1 full. UNITLESS. Applied as an
///                   exponent, so it cannot saturate at either end of its range.
///   armour.plates - number of plate seams the shell shows. INTEGER >= 1, capped by
///                   ADV_PLATE_MIN_PITCH so a large count cannot become hatching.
///   armour.coverage - fraction of the core's length, from the crown down, that the plating runs
///                   over. UNITLESS 0..1.
///   armour.weight - how heavy the shell reads: deeper lip, stronger bow. UNITLESS 0..1.
///
/// ⛔ THE ARMOUR BLOCK HAD NO READER FOR THE WHOLE OF THIS PRODUCT'S FIRST BUILD. All three fields
/// were authored per row, differing genuinely across the corpus, and nothing drew them - so the
/// corpus's own answer to "what makes these fourteen different" was spent and then discarded.
///
/// ⛔ SEEDS ARE WARMED, NOT USED RAW. `adv_hash`/`adv_rng` is a Lehmer generator, so its FIRST
/// draw is very nearly a straight line in the seed across any run of nearby seeds - and every
/// caller in this catalogue seeds as `base + index`. Wing CLAUDE.md records Lode measuring a first
/// draw spanning only 0.5102..0.7358 across 440 consecutive seeds, which took a 30%-chance rare
/// event to a MEASURED 0% over 440 trials with every determinism assertion passing. Anything here
/// that rolls a rare event must go through adv_rng_warm, never a bare first draw.

#macro ADV_SYM_BILATERAL 0
#macro ADV_SYM_RADIAL    1

#macro ADV_TERM_CLAW   0
#macro ADV_TERM_BLADE  1
#macro ADV_TERM_MAW    2
#macro ADV_TERM_HOOF   3
#macro ADV_TERM_FIST   4
#macro ADV_TERM_STINGER 5
#macro ADV_TERM_FIN    6
#macro ADV_TERM_TALON  7

#macro ADV_ROLE_STRIKE  0   // swings at the player - GENERATES A TELEGRAPH
#macro ADV_ROLE_SUPPORT 1   // holds the body up - never telegraphs
#macro ADV_ROLE_FLY     2   // wing or fin - telegraphs only a lift, not a strike
#macro ADV_ROLE_GRASP   3   // reaches and holds - telegraphs

/// Phase count is fixed at three across the corpus ON PURPOSE. It is the shape a player learns
/// (whole / broken / exposed), and a variable count would make the phase index mean something
/// different per boss - which is precisely the kind of drift the coupling above exists to stop.
#macro ADV_PHASES 3

#macro ADV_PHASE_WHOLE   0
#macro ADV_PHASE_BROKEN  1
#macro ADV_PHASE_EXPOSED 2

/// A limb record. Every field's unit is fixed by the header block above.
function adv_limb(_at, _ang, _segs, _len, _taper, _term, _role) {
    return {
        at:    _at,
        ang:   _ang,
        segs:  _segs,
        len:   _len,
        taper: _taper,
        term:  _term,
        role:  _role
    };
}

/// The fourteen plans.
///
/// ⚠️ THESE ARE SILHOUETTES FIRST. A boss is recognised at a glance and usually against a bright
/// backdrop, so what separates these rows is the OUTLINE - limb count, limb length against core
/// height, and where the mass sits - not surface detail. adv_selftest sweeps all 91 plan pairs for
/// silhouette distinctness for that reason, and the distinctness floor is picked from a measured
/// gap in the corpus rather than chosen (wing CLAUDE.md, the Lode/Chitin threshold law).
///
/// ⚠️ `core.h` is the unit every limb length is expressed against, so it is 1.0 for most plans and
/// the WIDTH carries the difference. A plan that changed both would make `len` mean something
/// different per row, and the tell's reach is computed from `len` - see the units block above.
function adv_corpus() {
    static _c = undefined;
    if (!is_undefined(_c)) return _c;

    _c = [
    {
        id: "colossus", name: "Colossus",
        sym: ADV_SYM_BILATERAL,
        core:  { w: 0.62, h: 1.00, profile: 0.72, lean: 0.06, form: ADV_FORM_ANVIL },
        crown: { count: 1, scale: 0.26, sunken: 0.35, form: ADV_CROWN_HORNED },
        limbs: [
            adv_limb(0.18, -0.30, 3, 0.92, 0.62, ADV_TERM_FIST, ADV_ROLE_STRIKE),
            adv_limb(0.78,  0.10, 3, 0.74, 0.70, ADV_TERM_HOOF, ADV_ROLE_SUPPORT)
        ],
        armour: { plates: 7, coverage: 0.86, weight: 0.90 },
        mass: 1.00
    },
    {
        id: "wyrm", name: "Wyrm",
        sym: ADV_SYM_BILATERAL,
        core:  { w: 0.26, h: 1.00, profile: 0.34, lean: 0.42, form: ADV_FORM_SPINDLE },
        crown: { count: 1, scale: 0.30, sunken: 0.10, form: ADV_CROWN_CREST },
        limbs: [
            adv_limb(0.30, -0.62, 2, 0.44, 0.40, ADV_TERM_CLAW, ADV_ROLE_STRIKE),
            adv_limb(0.62,  0.48, 4, 1.30, 0.18, ADV_TERM_FIN,  ADV_ROLE_FLY)
        ],
        armour: { plates: 11, coverage: 0.72, weight: 0.44 },
        mass: 0.72
    },
    {
        id: "arachnid", name: "Arachnid",
        sym: ADV_SYM_RADIAL,
        core:  { w: 0.88, h: 1.00, profile: 0.94, lean: 0.00, form: ADV_FORM_CARAPACE },
        crown: { count: 4, scale: 0.12, sunken: 0.55, form: ADV_CROWN_CLUSTER },
        limbs: [
            adv_limb(0.42, -0.86, 3, 1.24, 0.16, ADV_TERM_TALON, ADV_ROLE_SUPPORT),
            adv_limb(0.52, -0.34, 3, 1.10, 0.16, ADV_TERM_TALON, ADV_ROLE_STRIKE),
            adv_limb(0.62,  0.22, 3, 1.02, 0.16, ADV_TERM_TALON, ADV_ROLE_SUPPORT),
            adv_limb(0.72,  0.70, 3, 0.90, 0.16, ADV_TERM_TALON, ADV_ROLE_SUPPORT)
        ],
        armour: { plates: 5, coverage: 0.58, weight: 0.36 },
        mass: 0.66
    },
    {
        id: "leviathan", name: "Leviathan",
        sym: ADV_SYM_BILATERAL,
        core:  { w: 0.54, h: 1.00, profile: 0.50, lean: 0.24, form: ADV_FORM_HOURGLASS },
        crown: { count: 1, scale: 0.34, sunken: 0.16, form: ADV_CROWN_MAW },
        limbs: [
            adv_limb(0.34, -0.18, 2, 0.62, 0.30, ADV_TERM_FIN, ADV_ROLE_FLY),
            adv_limb(0.86,  0.34, 3, 0.96, 0.22, ADV_TERM_FIN, ADV_ROLE_FLY),
            adv_limb(0.22, -0.52, 1, 0.40, 0.48, ADV_TERM_MAW, ADV_ROLE_STRIKE)
        ],
        armour: { plates: 9, coverage: 0.64, weight: 0.52 },
        mass: 0.88
    },
    {
        id: "golem", name: "Golem",
        sym: ADV_SYM_BILATERAL,
        core:  { w: 0.74, h: 1.00, profile: 0.88, lean: 0.00, form: ADV_FORM_DRUM },
        crown: { count: 1, scale: 0.20, sunken: 0.62, form: ADV_CROWN_FACETED },
        limbs: [
            adv_limb(0.24, -0.16, 2, 0.80, 0.86, ADV_TERM_FIST, ADV_ROLE_STRIKE),
            adv_limb(0.80,  0.06, 2, 0.56, 0.90, ADV_TERM_HOOF, ADV_ROLE_SUPPORT)
        ],
        armour: { plates: 6, coverage: 0.94, weight: 1.00 },
        mass: 1.06
    },
    {
        id: "chimera", name: "Chimera",
        sym: ADV_SYM_BILATERAL,
        core:  { w: 0.58, h: 1.00, profile: 0.62, lean: 0.18, form: ADV_FORM_LOBED },
        crown: { count: 3, scale: 0.24, sunken: 0.12, form: ADV_CROWN_ANTLERED },
        limbs: [
            adv_limb(0.30, -0.40, 3, 0.72, 0.40, ADV_TERM_CLAW, ADV_ROLE_STRIKE),
            adv_limb(0.74,  0.16, 3, 0.68, 0.44, ADV_TERM_TALON, ADV_ROLE_SUPPORT),
            adv_limb(0.90,  0.60, 2, 0.66, 0.26, ADV_TERM_STINGER, ADV_ROLE_STRIKE)
        ],
        armour: { plates: 8, coverage: 0.54, weight: 0.48 },
        mass: 0.82
    },
    {
        id: "sentinel", name: "Sentinel",
        sym: ADV_SYM_RADIAL,
        core:  { w: 0.66, h: 1.00, profile: 0.80, lean: 0.00, form: ADV_FORM_WEDGE },
        crown: { count: 1, scale: 0.38, sunken: 0.00, form: ADV_CROWN_OCULUS },
        limbs: [
            adv_limb(0.46, -0.70, 2, 0.86, 0.34, ADV_TERM_BLADE, ADV_ROLE_STRIKE),
            adv_limb(0.46,  0.00, 2, 0.86, 0.34, ADV_TERM_BLADE, ADV_ROLE_STRIKE),
            adv_limb(0.46,  0.70, 2, 0.86, 0.34, ADV_TERM_BLADE, ADV_ROLE_STRIKE)
        ],
        armour: { plates: 4, coverage: 0.70, weight: 0.62 },
        mass: 0.74
    },
    {
        id: "hollow", name: "Hollow",
        sym: ADV_SYM_BILATERAL,
        core:  { w: 0.44, h: 1.00, profile: 0.40, lean: 0.30, form: ADV_FORM_ANVIL },
        crown: { count: 1, scale: 0.22, sunken: 0.72, form: ADV_CROWN_HOODED },
        limbs: [
            adv_limb(0.26, -0.54, 4, 1.06, 0.12, ADV_TERM_CLAW, ADV_ROLE_GRASP),
            adv_limb(0.44, -0.10, 4, 0.94, 0.12, ADV_TERM_CLAW, ADV_ROLE_STRIKE)
        ],
        armour: { plates: 3, coverage: 0.22, weight: 0.14 },
        mass: 0.48
    },
    {
        id: "broodmother", name: "Broodmother",
        sym: ADV_SYM_RADIAL,
        core:  { w: 1.00, h: 1.00, profile: 0.98, lean: 0.00, form: ADV_FORM_BULB },
        crown: { count: 2, scale: 0.14, sunken: 0.48, form: ADV_CROWN_CLUSTER },
        limbs: [
            adv_limb(0.56, -0.60, 2, 0.52, 0.22, ADV_TERM_TALON, ADV_ROLE_SUPPORT),
            adv_limb(0.66, -0.10, 2, 0.48, 0.22, ADV_TERM_TALON, ADV_ROLE_SUPPORT),
            adv_limb(0.76,  0.40, 2, 0.44, 0.22, ADV_TERM_TALON, ADV_ROLE_SUPPORT),
            adv_limb(0.30, -0.34, 3, 0.70, 0.26, ADV_TERM_MAW, ADV_ROLE_STRIKE)
        ],
        armour: { plates: 5, coverage: 0.40, weight: 0.30 },
        mass: 0.94
    },
    {
        id: "titanid", name: "Titanid",
        sym: ADV_SYM_BILATERAL,
        core:  { w: 0.52, h: 1.00, profile: 0.66, lean: 0.10, form: ADV_FORM_SPINDLE },
        crown: { count: 1, scale: 0.24, sunken: 0.20, form: ADV_CROWN_ANTLERED },
        limbs: [
            adv_limb(0.22, -0.36, 3, 0.84, 0.52, ADV_TERM_BLADE, ADV_ROLE_STRIKE),
            adv_limb(0.76,  0.12, 3, 0.72, 0.60, ADV_TERM_HOOF, ADV_ROLE_SUPPORT),
            adv_limb(0.30, -0.96, 3, 1.34, 0.20, ADV_TERM_FIN, ADV_ROLE_FLY)
        ],
        armour: { plates: 10, coverage: 0.66, weight: 0.56 },
        mass: 0.86
    },
    {
        id: "crawler", name: "Crawler",
        sym: ADV_SYM_BILATERAL,
        core:  { w: 0.22, h: 1.00, profile: 0.30, lean: 0.56, form: ADV_FORM_LOBED },
        crown: { count: 1, scale: 0.18, sunken: 0.30, form: ADV_CROWN_MAW },
        limbs: [
            adv_limb(0.20, -0.72, 2, 0.36, 0.20, ADV_TERM_TALON, ADV_ROLE_SUPPORT),
            adv_limb(0.40, -0.72, 2, 0.36, 0.20, ADV_TERM_TALON, ADV_ROLE_SUPPORT),
            adv_limb(0.60, -0.72, 2, 0.36, 0.20, ADV_TERM_TALON, ADV_ROLE_SUPPORT),
            adv_limb(0.80, -0.72, 2, 0.36, 0.20, ADV_TERM_TALON, ADV_ROLE_SUPPORT),
            adv_limb(0.08, -0.24, 2, 0.44, 0.30, ADV_TERM_MAW, ADV_ROLE_STRIKE)
        ],
        armour: { plates: 14, coverage: 0.78, weight: 0.42 },
        mass: 0.58
    },
    {
        id: "ogre", name: "Ogre",
        sym: ADV_SYM_BILATERAL,
        core:  { w: 0.70, h: 1.00, profile: 0.76, lean: 0.22, form: ADV_FORM_BULB },
        crown: { count: 1, scale: 0.28, sunken: 0.26, form: ADV_CROWN_HORNED },
        limbs: [
            adv_limb(0.20, -0.44, 3, 1.02, 0.66, ADV_TERM_FIST, ADV_ROLE_STRIKE),
            adv_limb(0.26,  0.04, 2, 0.58, 0.58, ADV_TERM_CLAW, ADV_ROLE_GRASP),
            adv_limb(0.80,  0.14, 2, 0.62, 0.74, ADV_TERM_HOOF, ADV_ROLE_SUPPORT)
        ],
        armour: { plates: 4, coverage: 0.36, weight: 0.44 },
        mass: 0.98
    },
    {
        id: "seraph", name: "Seraph",
        sym: ADV_SYM_RADIAL,
        core:  { w: 0.40, h: 1.00, profile: 0.56, lean: 0.00, form: ADV_FORM_WEDGE },
        crown: { count: 1, scale: 0.32, sunken: 0.00, form: ADV_CROWN_OCULUS },
        limbs: [
            adv_limb(0.36, -1.10, 3, 1.18, 0.24, ADV_TERM_FIN, ADV_ROLE_FLY),
            adv_limb(0.50, -0.52, 3, 1.06, 0.24, ADV_TERM_FIN, ADV_ROLE_FLY),
            adv_limb(0.64,  0.06, 3, 0.94, 0.24, ADV_TERM_FIN, ADV_ROLE_FLY),
            adv_limb(0.28, -0.14, 2, 0.72, 0.36, ADV_TERM_BLADE, ADV_ROLE_STRIKE)
        ],
        armour: { plates: 6, coverage: 0.48, weight: 0.28 },
        mass: 0.62
    },
    {
        id: "abomination", name: "Abomination",
        sym: ADV_SYM_BILATERAL,
        core:  { w: 0.80, h: 1.00, profile: 0.68, lean: 0.34, form: ADV_FORM_HOURGLASS },
        crown: { count: 2, scale: 0.16, sunken: 0.44, form: ADV_CROWN_HOODED },
        limbs: [
            adv_limb(0.16, -0.66, 4, 1.16, 0.14, ADV_TERM_CLAW, ADV_ROLE_STRIKE),
            adv_limb(0.34, -0.12, 2, 0.50, 0.52, ADV_TERM_FIST, ADV_ROLE_STRIKE),
            adv_limb(0.58,  0.36, 3, 0.78, 0.24, ADV_TERM_STINGER, ADV_ROLE_GRASP),
            adv_limb(0.86,  0.80, 2, 0.54, 0.40, ADV_TERM_HOOF, ADV_ROLE_SUPPORT)
        ],
        armour: { plates: 7, coverage: 0.44, weight: 0.50 },
        mass: 0.92
    }
    ];
    return _c;
}

function adv_corpus_count() { return array_length(adv_corpus()); }

/// Look a plan up by id. Returns undefined rather than throwing, because a caller with a bad id
/// wants to say so in its own words.
function adv_plan(_id) {
    var _c = adv_corpus();
    for (var _i = 0; _i < array_length(_c); _i++) {
        if (_c[_i].id == _id) return _c[_i];
    }
    return undefined;
}

/// How many distinct BODIES the corpus can draw. Quoted on the store listing, so it is DERIVED
/// here and never typed anywhere else.
///
/// ⛔ Wing CLAUDE.md: "when a count is derived rather than assembled, the honest number is usually
/// the bigger one" - and the corollary that bit Chitin is that a name array summed into a market
/// claim must be index-parallel with a real switch, or the listing quotes forms the package does
/// not have. adv_selftest asserts this against the arrays it actually walks.
function adv_corpus_bodies() {
    return adv_corpus_count() * ADV_PHASES;
}

/// Every limb in the corpus that will generate a telegraph. This is the other half of the volume
/// claim and is likewise derived, never typed.
function adv_corpus_tells() {
    var _c = adv_corpus();
    var _n = 0;
    for (var _i = 0; _i < array_length(_c); _i++) {
        var _l = _c[_i].limbs;
        for (var _j = 0; _j < array_length(_l); _j++) {
            if (adv_role_telegraphs(_l[_j].role)) _n++;
        }
    }
    return _n * ADV_PHASES;
}

/// ⛔ ONE PREDICATE, TWO READERS. `adv_body` uses this to decide whether to draw a wind-up pose and
/// `adv_tell` uses it to decide whether to emit an arc. If each had its own test, a limb could
/// wind up without a telegraph - which is the exact desync this package exists to prevent, and it
/// would be invisible in any still image.
function adv_role_telegraphs(_role) {
    return (_role == ADV_ROLE_STRIKE) || (_role == ADV_ROLE_GRASP);
}

function adv_term_names() {
    return ["claw", "blade", "maw", "hoof", "fist", "stinger", "fin", "talon"];
}

function adv_phase_names() {
    return ["whole", "broken", "exposed"];
}

function adv_name_of(_arr, _i) {
    if (_i < 0 || _i >= array_length(_arr)) return "?";
    return _arr[_i];
}
