{
  "$GMScript": "v1",
  "%Name": "adv_corpus",
  "name": "adv_corpus",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}