/// adv_bake.gml — render sheets from the product's own draw code, and MEASURE THE INK.
///
/// ⛔ A GALLERY RENDERED BY A SIDE PREVIEWER IS A PICTURE OF A RE-IMPLEMENTATION. This wing has a
/// receipt: a JS previewer carried a defect that was invisible in the previewer and plainly
/// visible in engine. Baking through the real executable is what lets the listing truthfully say
/// every image was rendered by the product itself.
///
/// ⛔ AND THE EXTENT CHECK IS ONE NUMBER, BLIND IN TWO DIRECTIONS. A returned `y` only answers
/// "did the LAST thing drawn fall off the BOTTOM" - it cannot see horizontal overflow and it
/// cannot see emptiness. On one product both blind spots shipped while it reported ok: body copy
/// ran off the RIGHT EDGE cut mid-word, and ~35% of a surface was bare. So this measures the
/// RENDERED PIXELS and returns an ink bounding box.
///
/// ⚠️ STRIDE Y BY 1. A stride of 2 walks straight past a 1px feature on an odd row - including a
/// title rule, which is precisely the shape that lands on one row. Stepping x by 2 is safe because
/// nothing here draws a 1px-wide vertical feature.
///
/// ⚠️ AND THE INK BOX HAS A PERMANENT BLIND SPOT OF ITS OWN: a bounding box cannot see the space
/// INSIDE itself, so three small figures adrift on a large page score well and look empty. The
/// floor catches an EMPTY sheet and a CLIPPED one. It is not a judge of taste and must never be
/// tuned to make a sheet pass - the only instrument for sparseness is opening the file.

function adv_bk_ink_bounds(_surf, _bg) {
    var _w = surface_get_width(_surf);
    var _h = surface_get_height(_surf);
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _surf, 0);

    var _br = colour_get_red(_bg), _bg2 = colour_get_green(_bg), _bb = colour_get_blue(_bg);
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1;
    var _ink = 0;

    for (var _y = 0; _y < _h; _y += 1) {          // stride 1 - see the header
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = ((_y * _w) + _x) * 4;
            var _r = buffer_peek(_buf, _o,     buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b2 = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_r - _br) > 10 || abs(_g - _bg2) > 10 || abs(_b2 - _bb) > 10) {
                _ink += 1;
                if (_x < _x0) _x0 = _x;
                if (_x > _x1) _x1 = _x;
                if (_y < _y0) _y0 = _y;
                if (_y > _y1) _y1 = _y;
            }
        }
    }
    buffer_delete(_buf);
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1, ink: _ink, w: _w, h: _h };
}

/// The pixel extent a telegraph occupies, in UNIT coordinates, as [x0, y0, x1, y1].
///
/// ⚠️ THE SECTOR IS SAMPLED, NOT BOXED BY ITS RADIUS. `[cx - r, cy - r, cx + r, cy + r]` is the
/// extent of a whole DISC, and these arcs are typically a third of one - boxing them would reserve
/// space nothing is ever drawn in and shrink every figure on the sheet to fit it. Wing CLAUDE.md
/// carries the general form from Liege: "a bounding box over several objects is not a measurement
/// of any of them, it is a measurement of the space they enclose, and that space is mostly empty."
///
/// ⚠️ Sampled at ADV_SWEEP_N, which is the SAME count the arc is drawn with and the same count the
/// reach measurement sweeps. Two sweeps over different sample sets can disagree about where the arc
/// reaches, and then the layout would be reserving space for a frame nobody draws.
function adv_bk_tell_bounds(_tell) {
    var _d = _tell.a1 - _tell.a0;
    while (_d >  pi) _d -= (2 * pi);
    while (_d < -pi) _d += (2 * pi);
    var _x0 = _tell.cx, _y0 = _tell.cy, _x1 = _tell.cx, _y1 = _tell.cy;
    for (var _q = 0; _q <= ADV_SWEEP_N; _q++) {
        var _a  = _tell.a0 + (_d * (_q / ADV_SWEEP_N));
        var _px = _tell.cx + (cos(_a) * _tell.r);
        var _py = _tell.cy + (sin(_a) * _tell.r);
        _x0 = min(_x0, _px); _x1 = max(_x1, _px);
        _y0 = min(_y0, _py); _y1 = max(_y1, _py);
    }
    return [_x0, _y0, _x1, _y1];
}

/// Where a telegraph's INK actually lands, as opposed to where its arc could reach.
///
/// ⛔ THE DIFFERENCE IS THE WHOLE POINT AND IT COST A BAKE. `adv_bk_tell_bounds` boxes the SECTOR -
/// correct for reserving layout space, because a swept band really does span it. But three of the
/// four telegraph kinds draw nothing across that sector at all: an impact is a disc at the leading
/// end, a close is a pair of jaws at the leading end, a thrust is a lance along the leading bearing.
/// Using the sector box to FOCUS a zoom therefore centred the camera on empty space and sized it to
/// a region two thirds of which had no ink in it - which is how the tells plate came back with the
/// chimera's stinger mark in the bottom-left corner of a cell that had zoomed 1.75x to frame it.
///
/// ⭐ The general form is one this wing keeps re-learning: a bounding box answers the question it
/// was built for and nothing else, so ask which question you are asking before reusing one.
function adv_bk_tell_ink_bounds(_tell) {
    var _ae = _tell.a0 + adv_tell_span_signed(_tell);
    var _hx = _tell.cx + (cos(_ae) * _tell.r);
    var _hy = _tell.cy + (sin(_ae) * _tell.r);
    var _pad = _tell.r * 0.34;
    var _b = [_hx - _pad, _hy - _pad, _hx + _pad, _hy + _pad];

    // Every kind ghosts the striking end along its path, so the path is always in frame.
    for (var _g = 0; _g < array_length(_tell.path); _g++) {
        var _p = _tell.path[_g];
        _b[0] = min(_b[0], min(_p[0], _p[2])); _b[1] = min(_b[1], min(_p[1], _p[3]));
        _b[2] = max(_b[2], max(_p[0], _p[2])); _b[3] = max(_b[3], max(_p[1], _p[3]));
    }
    // ...and only a SWEEP actually paints the sector.
    if (_tell.kind == ADV_TELL_SWEEP) {
        var _s = adv_bk_tell_bounds(_tell);
        _b[0] = min(_b[0], _s[0]); _b[1] = min(_b[1], _s[1]);
        _b[2] = max(_b[2], _s[2]); _b[3] = max(_b[3], _s[3]);
    }
    return _b;
}

/// Everything a plan draws at this phase and wind - body AND every telegraph - as one unit-space
/// box. This is what a cell has to hold.
///
/// ⛔ THE TELLS MUST BE IN HERE. The previous layout measured nothing at all and scaled by the unit
/// box, so limbs reaching 1.63 ran a full 63% outside their cells and bosses crossed into their
/// neighbours on the sheet whose whole job is to show fourteen SEPARATE creatures.
/// The telegraphs a sheet will ACTUALLY DRAW for a plan.
///
/// ⛔ ONE FUNCTION, TWO READERS, and it exists because the alternative bit immediately. The LAYOUT
/// measures these and the DRAW loop draws these. When the contact sheet stopped mirroring its arcs,
/// the extent function was still unioning both sides, so the layout reserved space for arcs nobody
/// draws and shrank every figure on the sheet to fit it. Same class as Liege's work-beat defect in
/// wing CLAUDE.md: when a measurement aggregates over a dimension, the artefact a buyer sees must be
/// sampled at the SAME point the aggregate selected, or the gate is grading a frame nobody looks at.
///
/// It is deliberately the same shape as adv_role_telegraphs - one predicate, two consumers - which
/// is the pattern the whole package is built on.
/// ⛔ ONE LIMB, ONE SIDE, ON EVERY SHEET - AND THE MIRRORED VERSION IS GONE RATHER THAN OPTIONAL.
///
/// This started as a `_firstOnly` flag so the contact sheet could unmirror while the coupling
/// sheets kept both sides. Baking sheet 2 settled it: the mirrored pair is a CAPE. The two arcs
/// meet behind the body, the concentric range rings become the lining, and a boss captioned
/// "THE TELL BELONGS TO THE ARM" is wearing a cloak. The mirroring was the cause the whole time -
/// three passes were spent on colour, alpha and texture, which are all downstream of it.
///
/// ⭐ It also costs nothing to fix and PAYS: the mirrored pair is roughly twice as wide as the
/// figure, so WIDTH bound the layout scale and 34% of that sheet was empty. Unmirroring shrinks the
/// measured extent, the shared scale grows, and the dead space closes without moving a pad value.
///
/// ⚠️ The flag is DELETED rather than defaulted, because the both-sides branch would then be a path
/// nothing calls - and this wing has just paid for a dead reader on the `armour` block, which sat
/// authored and undrawn through a whole build.
function adv_bk_tells_for(_plan, _phase) {
    var _out = [];
    for (var _j = 0; _j < array_length(_plan.limbs); _j++) {
        var _t = adv_tell_arc(_plan, _j, -1, _phase);
        if (is_undefined(_t)) continue;
        array_push(_out, _t);
        break;
    }
    return _out;
}

/// ⚠️ `_withTell` IS NOT A CONVENIENCE FLAG. The layout must reserve space for exactly what the draw
/// loop will put there: reserving for an arc nobody draws leaves a hole, and drawing an arc nobody
/// reserved for clips it. Both have happened on this product's sheets, so the flag is passed from
/// the same expression that decides the draw, on every caller.
function adv_bk_plan_extent(_plan, _phase, _wind, _withTell) {
    var _bb = adv_render_bounds(adv_body_parts(_plan, _phase, _wind));
    if (!_withTell) return _bb;
    var _tl = adv_bk_tells_for(_plan, _phase);
    for (var _i = 0; _i < array_length(_tl); _i++) {
        var _tb = adv_bk_tell_bounds(_tl[_i]);
        _bb[0] = min(_bb[0], _tb[0]); _bb[1] = min(_bb[1], _tb[1]);
        _bb[2] = max(_bb[2], _tb[2]); _bb[3] = max(_bb[3], _tb[3]);
    }
    return _bb;
}

/// The telegraph, drawn the way a player has to be able to read it.
///
/// ⛔ THIS FUNCTION USED TO BE 85 LINES OF DRAW CALLS AND IT WAS THE SECOND COPY OF THEM. The demo
/// room a buyer opens carried the first, older, rejected version. The renderer now lives in
/// `adv_tell` beside the geometry it draws, it SHIPS as part of the public surface, and both the
/// demo and these sheets call it - so the picture on the store page and the picture in the buyer's
/// hands cannot diverge again. The four-wrong-answers history that produced this render is kept in
/// full at the function itself; it is doctrine, not a changelog.
function adv_bk_draw_tell(_tell, _pal, _ox, _oy, _s) {
    return adv_tell_draw(_tell, _pal, _ox, _oy, _s);
}

/// The corpus contact sheet: every plan, drawn by the product, at its own material, with the
/// telegraph the package derives for it.
///
/// ⛔ THIS FUNCTION'S OWN HEADER USED TO CLAIM "CELL ASPECT IS MEASURED, NOT ASSUMED ... each row
/// here is sized from the widest body it holds", AND NOTHING IN IT MEASURED ANYTHING. The cells
/// were `(_w - pad) / 5` by `(_h - pad) / 3` and every body was fitted by its UNIT BOX, so the
/// arachnid's 1.24-length talons ran clean through the wyrm's cell and the abomination sat on the
/// seraph. Wing CLAUDE.md's law is exact here: "a constraint that lives only in prose is enforced
/// by whoever last read the prose" - make it structural instead.
///
/// ⭐ THE LAYOUT IS THE ONE THIS WING ALREADY PAID FOR, on Horologe: MEASURE THE SPECIMEN FIRST,
/// THEN CUT THE CELL TO IT. Twelve machines running 0.49 to 1.80 wide-to-tall were each fitted into
/// one landscape cell and ten of them left two thirds of theirs black, at `contentW 0.92` with every
/// floor green.
///
/// ⛔ BUT NOT `adv_render_in_rect_tight` PER CELL, AND adv_render's own header says why: these
/// fourteen share a frame BY CONSTRUCTION - `core.h` is 1.00 on every row precisely so that `len`
/// means the same thing everywhere - so tight-fitting each cell would draw the crawler (core.w 0.22)
/// at the same size as the broodmother (1.00) and destroy the only size comparison the sheet has.
/// ONE scale for the whole sheet, and the CELLS vary. That keeps the comparison and fills the page.
function adv_bake_corpus(_surf, _pal_bg) {
    var _w = surface_get_width(_surf);
    var _h = surface_get_height(_surf);
    var _n = adv_corpus_count();
    var _cols = 5;
    var _rows = ceil(_n / _cols);

    draw_set_font(fnt_adversary_title);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_colour(c_white);
    draw_text(_w * 0.018, _h * 0.020, "ADVERSARY");
    draw_set_font(fnt_adversary);
    // ⛔ DERIVED, NEVER TYPED. A caption naming a count the package does not have is a market
    // claim the picture cannot support, and this wing has shipped one.
    draw_text(_w * 0.018, _h * 0.056, string(adv_corpus_count()) + " bosses x "
        + string(ADV_PHASES) + " phases = " + string(adv_corpus_bodies())
        + " bodies, " + string(adv_corpus_tells()) + " telegraphs, "
        + string(adv_palette_count()) + " palettes. No sprites.");

    var _padx  = _w * 0.016;
    var _top   = _h * 0.105;
    var _gapx  = _w * 0.006;
    var _gapy  = _h * 0.012;
    var _labH  = _h * 0.034;
    var _availW = _w - (_padx * 2);
    var _availH = _h - _top - (_h * 0.015);

    // ---- 1. MEASURE, before anything is placed.
    var _bb = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        // Measured through the SAME function the draw loop below selects with, so the layout cannot
        // reserve space for an arc nobody draws.
        _bb[_i] = adv_bk_plan_extent(adv_corpus()[_i], ADV_PHASE_WHOLE, 0.45, false);
    }

    // ---- 2. ONE scale, the largest at which every row fits both ways.
    var _S = 1000000;
    var _sumRowH = 0;
    for (var _r = 0; _r < _rows; _r++) {
        var _c0 = _r * _cols;
        var _c1 = min(_n, _c0 + _cols);
        var _sumW = 0, _maxH = 0;
        for (var _i = _c0; _i < _c1; _i++) {
            _sumW += max(0.0001, _bb[_i][2] - _bb[_i][0]);
            _maxH = max(_maxH, _bb[_i][3] - _bb[_i][1]);
        }
        var _rowW = _availW - (_gapx * ((_c1 - _c0) - 1));
        _S = min(_S, _rowW / _sumW);
        _sumRowH += _maxH;
    }
    var _vBudget = _availH - (_labH * _rows) - (_gapy * (_rows - 1));
    _S = min(_S, _vBudget / max(0.0001, _sumRowH));

    // ---- 3. PLACE. Leftover space becomes air, never overlap.
    var _y = _top;
    for (var _r = 0; _r < _rows; _r++) {
        var _c0 = _r * _cols;
        var _c1 = min(_n, _c0 + _cols);
        var _cnt = _c1 - _c0;
        var _sumW = 0, _maxH = 0;
        for (var _i = _c0; _i < _c1; _i++) {
            _sumW += max(0.0001, _bb[_i][2] - _bb[_i][0]);
            _maxH = max(_maxH, _bb[_i][3] - _bb[_i][1]);
        }
        var _rowPx = _maxH * _S;
        var _slack = _availW - (_sumW * _S);
        var _gap   = _slack / (_cnt + 1);
        var _x = _padx + _gap;

        for (var _i = _c0; _i < _c1; _i++) {
            var _plan = adv_corpus()[_i];
            var _hide = adv_hides()[_i mod adv_hide_count()];
            var _pal  = adv_palette_for(_hide, 0);
            var _bw   = (_bb[_i][2] - _bb[_i][0]) * _S;
            var _bh   = (_bb[_i][3] - _bb[_i][1]) * _S;

            // Where unit-space (0,0) lands: the measured box centred in its own cell, and STOOD ON
            // the row's baseline rather than centred vertically, so fourteen creatures of different
            // heights share a floor instead of floating at fourteen different altitudes.
            var _ox = _x - (_bb[_i][0] * _S);
            var _oy = _y + _rowPx - _bh - (_bb[_i][1] * _S);

            // ⛔ ONE SIDE, ONE LIMB - AND THIS IS A CORRECTION, NOT A SIMPLIFICATION.
            //
            // The first version of this sheet drew every telegraphing limb on BOTH sides, and the
            // result was that ten of the fourteen bosses grew a matched pair of pink fans, level
            // with each other, either side of the body. They read as BUTTERFLY WINGS - Hollow and
            // Sentinel were moths - and the rim added to make an arc legible is exactly what made
            // the wing shape crisp. A bilaterally symmetric pair of shapes flanking a body IS a
            // wing silhouette; no colour or alpha fixes that, because the read comes from the
            // SYMMETRY rather than from the shading.
            //
            // ⭐ An arc on ONE side is an attack. The same geometry, unmirrored, reads as "this one
            // is winding up", which is the thing the sheet is trying to say in the first place. So
            // the fix keeps the coupling visible on all fourteen cells - the product's whole claim -
            // and removes only the mirroring that was fighting it.
            //
            // ⚠️ THIS PARAGRAPH USED TO END "sheets 2 and 3 still draw both sides, and should" -
            // written before either had been baked, and false within the hour. Sheet 2's mirrored
            // pair was the clearest cape of the lot. A comment is part of the change; wing
            // CLAUDE.md records a subtitle left describing a sampling rule the code no longer used.
            //
            // ⛔⛔ AND THE FINAL ANSWER WAS TO TAKE THE TELEGRAPH OFF THIS PLATE ALTOGETHER. Five
            // renders were rejected here for reading as anatomy - solid sector, unmirrored sector,
            // radial hatch, concentric arcs, leading-edge gradient - and the sixth (banded arcs plus
            // a ghost of the striking limb) is genuinely good on sheets 2, 3 and 5, where the arm
            // MOVES between frames and the mark reads as the motion it is. On a static portrait
            // grid there is no motion to read it against, so the eye falls back on the only prior
            // it has for a large mark attached at a shoulder, and that prior is a wing. The
            // property that was missing was never texture or outline; it was CONTEXT.
            //
            // ⭐ And the plate is better for it on its own terms. This one's claim is FOURTEEN
            // DISTINCT BODIES, and a mark of identical construction repeated in every cell argues
            // against that claim no matter how it is drawn. sheet_5_tells now owns the telegraph
            // and shows all four of its shapes, which is a stronger argument than fourteen copies
            // of one of them.
            adv_render_parts(adv_body_parts(_plan, ADV_PHASE_WHOLE, 0.45), _pal,
                _ox, _oy, _S, 0, _S, undefined);

            draw_set_colour(c_white);
            draw_set_halign(fa_center);
            adv_text_fit(_plan.name, _x + (_bw * 0.5), _y + _rowPx + (_labH * 0.10),
                max(_bw, _w * 0.06), 18, c_black, c_white);
            draw_set_halign(fa_left);

            _x += _bw + _gap;
        }
        _y += _rowPx + _labH + _gapy;
    }
}

/// The coupling sheet: one boss, one limb, four moments of one attack, with the telegraph the
/// package DERIVED for it. This is the sheet that has to sell the product, so it shows the thing
/// no competitor can offer rather than the thing every competitor shows.
function adv_bake_coupling(_surf, _plan_index) {
    var _w = surface_get_width(_surf);
    var _h = surface_get_height(_surf);
    var _plan = adv_corpus()[_plan_index];
    var _hide = adv_hides()[_plan_index mod adv_hide_count()];
    var _pal  = adv_palette_for(_hide, 0);

    var _cols = 4;
    var _padx = _w * 0.02;
    var _top  = _h * 0.135;
    var _labH = _h * 0.045;
    var _cw = (_w - (_padx * 2)) / _cols;
    var _ch = _h - _top - _labH - (_h * 0.02);

    draw_set_font(fnt_adversary_title);
    draw_set_colour(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    // ⛔ THE TWO COUPLING PLATES CARRIED THE SAME TITLE AND THE SAME STRAPLINE, WORD FOR WORD.
    // Master CLAUDE.md §4.2b: every gallery image must show something DIFFERENT, and two plates
    // captioned identically argue that the second one is a duplicate even when the picture is not -
    // these two are a FIST and a CLAW, which is the whole reason the second exists.
    var _isFirst = (_plan_index == 0);
    draw_text(_padx, _h * 0.03,
        _isFirst ? "THE TELL BELONGS TO THE ARM" : "SAME CODE, A DIFFERENT ANIMAL");
    draw_set_font(fnt_adversary);
    draw_text(_padx, _h * 0.082, _isFirst
        ? ("The mark is not drawn by hand. Its pivot, radius and both angles come from the same "
           + "solved limb the body is drawn from, so it cannot drift. This one ends in a fist, so "
           + "the warning is where the blow lands.")
        : ("Nothing was re-authored for this boss. A different plan, a different terminal, and the "
           + "package derives a swept arc instead - with the claw itself ghosted along the path it "
           + "will travel."));

    // ---- MEASURE ALL FOUR FRAMES, THEN PICK ONE SCALE FOR ALL FOUR.
    //
    // ⛔ The scale here used to be `min(_cw, _ch) * 0.40` - a constant nobody had measured against
    // anything. On a 1600x900 sheet that drew a 307px figure into a 684px band and left 55% of the
    // sheet black on the coupling sheet and 65% on the wyrm one, while the ink floor passed, because
    // a bounding box cannot see the space inside itself.
    //
    // ⚠️ ONE scale across the four cells, not four fitted cells, and this is not a style choice: the
    // sheet's entire claim is that the arc tracks the arm across a wind-up. Four frames at four
    // scales would make the arc appear to change size between them, which is precisely the drift
    // the product exists to disprove. Wing CLAUDE.md, Liege: when a gate aggregates over a
    // dimension, the artefact a buyer sees must be sampled at the same point the aggregate selected.
    var _bb = [999, 999, -999, -999];
    for (var _k = 0; _k < _cols; _k++) {
        var _e = adv_bk_plan_extent(_plan, ADV_PHASE_WHOLE, _k / (_cols - 1), true);
        _bb[0] = min(_bb[0], _e[0]); _bb[1] = min(_bb[1], _e[1]);
        _bb[2] = max(_bb[2], _e[2]); _bb[3] = max(_bb[3], _e[3]);
    }
    var _bw = max(0.0001, _bb[2] - _bb[0]);
    var _bh = max(0.0001, _bb[3] - _bb[1]);
    var _sc = min((_cw * 0.92) / _bw, _ch / _bh);
    var _cyTop = _top + ((_ch - (_bh * _sc)) * 0.5);

    for (var _k = 0; _k < _cols; _k++) {
        var _wind = _k / (_cols - 1);
        var _x = _padx + (_k * _cw);
        // Unit-space origin for this cell: the SHARED measured box centred horizontally in the
        // cell and pinned to a SHARED top, so the four frames sit on one line and only the pose
        // moves between them.
        var _ox = _x + (_cw * 0.5) - (((_bb[0] + _bb[2]) * 0.5) * _sc);
        var _oy = _cyTop - (_bb[1] * _sc);

        // Telegraph under the body - painter's order is load-bearing here.
        var _tl = adv_bk_tells_for(_plan, ADV_PHASE_WHOLE);
        for (var _q2 = 0; _q2 < array_length(_tl); _q2++) {
            adv_bk_draw_tell(_tl[_q2], _pal, _ox, _oy, _sc);
        }
        adv_render_parts(adv_body_parts(_plan, ADV_PHASE_WHOLE, _wind), _pal,
            _ox, _oy, _sc, 0, _sc, undefined);

        draw_set_colour(c_white);
        draw_set_halign(fa_center);
        adv_text_fit("wind " + string_format(_wind, 1, 2), _x + (_cw * 0.5),
            _cyTop + (_bh * _sc) + (_h * 0.012), _cw * 0.9, 18, c_black, c_white);
        draw_set_halign(fa_left);
    }
}

/// The phases sheet: one boss, three phases, its own material dulling as it breaks.
///
/// ⛔ THE PRODUCT'S SUMMARY LEADS WITH "MULTI-PHASE BOSSES" AND THE GALLERY SHOWED NO PHASE AT ALL.
/// Every other sheet draws ADV_PHASE_WHOLE, so the listing's derived "42 bodies" - fourteen plans
/// times three phases - was a number with no picture behind it. Wing CLAUDE.md is explicit that a
/// caption naming something the image does not support is a market claim the picture cannot carry,
/// and this wing has shipped one before.
///
/// ⚠️ THE PALETTE IS PASSED THE PHASE'S DAMAGE, WHICH NO OTHER SHEET DOES. adv_palette_for has
/// always taken a `_damage` term that dulls and darkens, and every caller passed 0 - so the
/// package's own claim of `hides x phases` palettes had never been rendered either.
function adv_bake_phases(_surf, _plan_index) {
    var _w = surface_get_width(_surf);
    var _h = surface_get_height(_surf);
    var _pi = (_plan_index < 0) ? adv_bk_best_phase_plan() : _plan_index;
    var _plan = adv_corpus()[_pi];
    var _hide = adv_hides()[_pi mod adv_hide_count()];

    // ⛔ THE HEADER BAND IS IN PIXELS, NOT IN FRACTIONS OF THE CANVAS, AND THAT IS A BUG FIX. These
    // offsets were `_h * 0.03` and `_h * 0.082`, which scales the GAP between the title and the
    // strapline with the sheet height while the FONTS stay a fixed size - so shortening this canvas
    // to remove dead space (which is what the sheet needed) would have walked the strapline up into
    // the title, and the failure would have arrived one bake after the change that caused it. At
    // 560 tall the old fractions gave 16.8 / 45.9 / 75.6, so these numbers are that layout pinned.
    var _cols = ADV_PHASES;
    var _padx = _w * 0.02;
    var _top  = 92;
    var _labH = 26;
    var _cw = (_w - (_padx * 2)) / _cols;
    var _ch = _h - _top - _labH - 14;

    draw_set_font(fnt_adversary_title);
    draw_set_colour(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_text(_padx, 16, "THREE PHASES, ONE SET OF NUMBERS");
    draw_set_font(fnt_adversary);
    draw_text(_padx, 46,
        "As it breaks, the shell peels back from the tail, the limbs fold, and the material dulls. "
        + "Nothing here is a second sprite.");

    // ONE scale across the three, measured over all of them - the sheet's claim is a COMPARISON, so
    // three fitted cells would make the boss appear to change size as it takes damage.
    //
    // ⛔ NO TELEGRAPH ON THIS SHEET, MEASURED AND DELIBERATE. This plate's claim is about the BODY,
    // and the arc was actively costing it twice: the phase fold swings the striking limb round until
    // the arc is nearly edge-on, so frame 1 grew a small orange rectangle with no readable shape
    // while frames 2 and 3 had none at all - and the bounding box still reserved the arc's full
    // reach in every frame, which shrank all three bosses to make room for a mark that was not
    // information. Sheets 2 and 3 are where the telegraph is argued; this one is where the shell is.
    var _bb = [999, 999, -999, -999];
    for (var _k = 0; _k < _cols; _k++) {
        var _e = adv_bk_plan_extent(_plan, _k, 0.45, false);
        _bb[0] = min(_bb[0], _e[0]); _bb[1] = min(_bb[1], _e[1]);
        _bb[2] = max(_bb[2], _e[2]); _bb[3] = max(_bb[3], _e[3]);
    }
    var _bw = max(0.0001, _bb[2] - _bb[0]);
    var _bh = max(0.0001, _bb[3] - _bb[1]);
    var _sc = min((_cw * 0.90) / _bw, _ch / _bh);
    var _cyTop = _top + ((_ch - (_bh * _sc)) * 0.5);

    for (var _k = 0; _k < _cols; _k++) {
        var _pal = adv_palette_for(_hide, adv_phase_damage(_k));
        var _x = _padx + (_k * _cw);
        var _ox = _x + (_cw * 0.5) - (((_bb[0] + _bb[2]) * 0.5) * _sc);
        var _oy = _cyTop - (_bb[1] * _sc);

        adv_render_parts(adv_body_parts(_plan, _k, 0.45), _pal, _ox, _oy, _sc, 0, _sc, undefined);

        draw_set_colour(c_white);
        draw_set_halign(fa_center);
        // ⛔ DERIVED FROM THE PACKAGE'S OWN NAME ARRAY, never typed. A hard-coded caption is how a
        // plate in this wing came to describe a species it was no longer drawing.
        adv_text_fit(adv_name_of(adv_phase_names(), _k) + " - "
            + string(adv_armour_drawn_count(_plan, _k)) + " plates",
            _x + (_cw * 0.5), _cyTop + (_bh * _sc) + 8, _cw * 0.9, 18, c_black, c_white);
        draw_set_halign(fa_left);
    }
}

/// The first plan+limb in the corpus that produces each telegraph kind.
///
/// ⛔ SEARCHED, NEVER TYPED. A hand-written table of "which boss shows a thrust" is a caption that
/// goes wrong the first time a limb's terminal changes, and this wing has shipped a plate that
/// described a species it was no longer drawing. Returns `undefined` for a kind the corpus does not
/// contain, and the caller must SAY SO rather than draw something else - adv_selftest separately
/// asserts that at least three of the four are reachable.
/// The plan whose shell peels back the MOST across its phases.
///
/// ⛔ SEARCHED, BECAUSE THE PLATE'S CAPTION IS A CLAIM AND THE PICTURE HAS TO SUPPORT IT. The phases
/// sheet is headed "the shell peels back from the tail", and it was drawing a hand-picked boss whose
/// own derived caption read `whole - 5 plates` / `broken - 5 plates` / `exposed - 3 plates`: for that
/// creature the first transition is a limb fold and a dulling, and nothing peels until the last
/// phase. The strapline was a true statement about the SYSTEM over a picture that did not show it,
/// which is the shape of every store claim this wing has had to withdraw.
///
/// ⚠️ TWO CRITERIA, IN ORDER, AND THE ORDER IS THE WHOLE DESIGN. First filter to the plans that
/// actually step at BOTH transitions - those are the ones whose picture supports the caption, and
/// nothing else is eligible at any size. THEN, among those, take the one with the most visual mass,
/// because a plate that is honest and also impressive beats one that is only honest. The first
/// version scored on drop alone and picked a fourteen-segment worm: it demonstrated the claim
/// perfectly and looked like three sticks.
function adv_bk_best_phase_plan() {
    var _c = adv_corpus();
    var _best = -1;
    var _bestArea = -1;
    var _fallback = 0;
    var _fallbackDrop = -1;
    for (var _i = 0; _i < array_length(_c); _i++) {
        var _a = adv_armour_drawn_count(_c[_i], ADV_PHASE_WHOLE);
        var _mid = adv_armour_drawn_count(_c[_i], min(1, ADV_PHASES - 1));
        var _b = adv_armour_drawn_count(_c[_i], ADV_PHASES - 1);

        if ((_a - _b) > _fallbackDrop) { _fallback = _i; _fallbackDrop = _a - _b; }
        if (!(_mid < _a && _b < _mid)) continue;   // does not step twice: cannot carry the caption

        var _bb = adv_render_bounds(adv_body_parts(_c[_i], ADV_PHASE_WHOLE, 0.45));
        var _area = (_bb[2] - _bb[0]) * (_bb[3] - _bb[1]);
        if (_area > _bestArea) { _best = _i; _bestArea = _area; }
    }
    // ⛔ A NAMED FALLBACK RATHER THAN A CRASH OR A SILENT ZERO. If no plan steps twice the caption is
    // wrong about the whole corpus, not about the plate - and the best available picture is still
    // the biggest drop. adv_selftest asserts separately that the shell peels on most of the corpus.
    return (_best >= 0) ? _best : _fallback;
}

/// How far the tells plate may zoom past whole-boss fit.
///
/// ⛔⛔ 1.75 -> 1.30 -> 1.00, i.e. THE ZOOM IS OFF, AND THREE BAKES WENT INTO LEARNING THAT IT WAS
/// THE WRONG LEVER. The complaint it was reaching for was real - the close and thrust marks were
/// too small to read - but a crop cannot fix a mark that is quiet, it can only make the animal
/// unrecognisable at the same time. What actually fixed it was making those two RENDERS louder
/// (their alphas had been scaled off the SWEEP's substrate constant, so they were tuned for a role
/// they do not play) and widening the lance. With that done the plate reads at plain whole-boss fit,
/// with no cropping and no clipped limbs.
///
/// ⭐ Kept as a macro at 1.00 rather than deleted: the ink-bounds measurement it forced
/// (adv_bk_tell_ink_bounds) is correct and load-bearing, and a future kind whose mark really is
/// tiny may want this. It is a knob with a written history, which is cheaper than re-deriving it.
#macro ADV_BK_TELL_ZOOM 1.00

function adv_bk_first_of_kind(_kind) {
    var _c = adv_corpus();
    for (var _i = 0; _i < array_length(_c); _i++) {
        for (var _j = 0; _j < array_length(_c[_i].limbs); _j++) {
            var _limb = _c[_i].limbs[_j];
            if (!adv_role_telegraphs(_limb.role)) continue;
            if (adv_tell_kind(_limb) != _kind) continue;
            return { plan: _c[_i], planIndex: _i, limbIndex: _j, limb: _limb };
        }
    }
    return undefined;
}

/// The telegraph sheet: all four shapes of tell, each on a boss that really produces it.
///
/// ⭐ THIS PLATE EXISTS BECAUSE THE CORPUS PLATE COULD NOT CARRY IT. The telegraph was drawn in all
/// fourteen corpus cells for five bakes and read as anatomy in every one of them, because a static
/// portrait gives the eye no motion to read a mark against. Here each cell is ONE attack, the
/// striking limb is ghosted along its own path, and the caption names the terminal that decided the
/// shape - so the mark has something to be about.
function adv_bake_tells(_surf) {
    var _w = surface_get_width(_surf);
    var _h = surface_get_height(_surf);
    var _cols = 4;
    var _padx = _w * 0.02;
    var _top  = 92;
    var _labH = 30;
    var _cw = (_w - (_padx * 2)) / _cols;
    var _ch = _h - _top - _labH - 14;

    draw_set_font(fnt_adversary_title);
    draw_set_colour(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_text(_padx, 16, "THE TERMINAL DECIDES THE WARNING");
    draw_set_font(fnt_adversary);
    draw_text(_padx, 46,
        "A blade sweeps, a fist lands, a maw closes, a stinger stabs. None of these is authored per "
        + "boss - the shape is read off the limb's terminal, and the striking end is ghosted along "
        + "the path it will really travel.");

    var _kindNames = adv_tell_kind_names();

    // ⛔ THIS PLATE FITS THE TELL, NOT THE BOSS, AND THE FIRST VERSION DID THE OPPOSITE. Fitting the
    // whole creature into each cell drew four correct telegraphs at about 5% of the cell each - the
    // thrust on the chimera was a scuff by its foot - on the sheet whose entire job is to make the
    // four shapes legible. Wing CLAUDE.md's Horologe law again, one turn further round: measure the
    // SUBJECT and cut the frame to it, and here the subject is the mark, not the animal.
    //
    // ⚠️ WHICH MEANS THE BODY RUNS OUT OF ITS CELL, so each one is drawn into its own surface and
    // clipped by it. `surface_reset_target` is called BEFORE targeting the cell rather than nesting:
    // stacked targets are documented but this way uses nothing that could be version-dependent, and
    // the sheet's own pixels survive because a surface holds its contents while it is not the target.
    var _hit = array_create(_cols, undefined);
    var _focus = array_create(_cols, undefined);
    for (var _k = 0; _k < _cols; _k++) {
        _hit[_k] = adv_bk_first_of_kind(_k);
        if (is_undefined(_hit[_k])) continue;
        var _t = adv_tell_arc(_hit[_k].plan, _hit[_k].limbIndex, -1, ADV_PHASE_WHOLE);
        if (is_undefined(_t)) { _hit[_k] = undefined; continue; }
        // The focus box is where the telegraph's INK lands - not where its arc could reach. See the
        // note on adv_bk_tell_ink_bounds; using the sector box here centred three of these four
        // cells on empty space.
        var _e = adv_bk_tell_ink_bounds(_t);
        var _mx = (_e[2] - _e[0]) * 0.38;
        var _my = (_e[3] - _e[1]) * 0.38;
        _focus[_k] = [_e[0] - _mx, _e[1] - _my, _e[2] + _mx, _e[3] + _my];
    }

    // ⛔ EACH CELL FITS ITSELF, AND THIS IS A CORRECTION OF A RULE COPIED FROM THE WRONG PLATE.
    // Every other sheet here shares ONE scale across its cells, correctly: they compare one boss
    // across winds or across phases, so a changing size would be a lie about the thing under test.
    // This plate compares FOUR DIFFERENT BOSSES with four different reaches, and there is no size
    // claim in it at all - its whole job is to make four SHAPES legible. Sharing a scale here meant
    // the largest reach (the colossus's fist) set it and the smallest (the chimera's stinger) drew
    // its mark at about 2% of the cell: MEASURED by baking it and looking. A rule is only right for
    // the claim it was written for.
    //
    // ⚠️ AND IT IS BOUNDED, BECAUSE THE UNBOUNDED VERSION WAS ALSO WRONG. A close and a thrust have
    // SHORT reaches, so fitting their focus box alone put the zoom at 5-6x and turned two of the
    // four cells into unreadable slabs of limb - the caption said "maw" over an abstraction. A mark
    // means nothing without the animal it belongs to, so the zoom may not exceed ADV_BK_TELL_ZOOM
    // times the scale that fits the whole boss. Measured by baking it both ways and looking.
    var _sc = array_create(_cols, 100);
    var _ctr = array_create(_cols, undefined);
    for (var _k = 0; _k < _cols; _k++) {
        if (is_undefined(_focus[_k])) continue;
        var _wb = adv_render_bounds(adv_body_parts(_hit[_k].plan, ADV_PHASE_WHOLE, 1));
        _wb[0] = min(_wb[0], _focus[_k][0]); _wb[1] = min(_wb[1], _focus[_k][1]);
        _wb[2] = max(_wb[2], _focus[_k][2]); _wb[3] = max(_wb[3], _focus[_k][3]);
        _sc[_k] = min((_cw * 0.90) / max(0.0001, _wb[2] - _wb[0]),
                      (_ch * 0.92) / max(0.0001, _wb[3] - _wb[1])) * ADV_BK_TELL_ZOOM;
        _ctr[_k] = [(_wb[0] + _wb[2]) * 0.5, (_wb[1] + _wb[3]) * 0.5];
    }

    for (var _k = 0; _k < _cols; _k++) {
        var _x = _padx + (_k * _cw);
        if (is_undefined(_hit[_k])) {
            // ⛔ A NAMED ABSENCE. Drawing a substitute boss here would put a picture under a caption
            // the package cannot support, which is the one failure this plate is built to avoid.
            draw_set_colour(c_white);
            draw_set_halign(fa_center);
            adv_text_fit("no " + adv_name_of(_kindNames, _k) + " in the corpus",
                _x + (_cw * 0.5), _top + (_ch * 0.5), _cw * 0.9, 18, c_black, c_white);
            draw_set_halign(fa_left);
            continue;
        }
        var _plan = _hit[_k].plan;
        var _pal  = adv_palette_for(adv_hides()[_hit[_k].planIndex mod adv_hide_count()], 0);
        var _tell = adv_tell_arc(_plan, _hit[_k].limbIndex, -1, ADV_PHASE_WHOLE);

        var _cellW = floor(_cw * 0.96);
        var _cellH = floor(_ch);
        var _s1 = _sc[_k];
        var _ox = (_cellW * 0.5) - (_ctr[_k][0] * _s1);
        var _oy = (_cellH * 0.5) - (_ctr[_k][1] * _s1);

        surface_reset_target();
        var _cell = surface_create(_cellW, _cellH);
        surface_set_target(_cell);
        draw_clear_alpha(c_black, 0);
        adv_bk_draw_tell(_tell, _pal, _ox, _oy, _s1);
        adv_render_parts(adv_body_parts(_plan, ADV_PHASE_WHOLE, 1), _pal, _ox, _oy, _s1, 0, _s1,
            undefined);
        surface_reset_target();

        surface_set_target(_surf);
        draw_surface(_cell, _x + ((_cw - _cellW) * 0.5), _top);
        surface_free(_cell);

        draw_set_colour(c_white);
        draw_set_halign(fa_center);
        // Both halves DERIVED - the terminal off the limb record and the kind off the same switch
        // the renderer dispatched on, so the caption cannot describe a shape that was not drawn.
        adv_text_fit(adv_name_of(adv_term_names(), _hit[_k].limb.term) + " -> "
            + adv_name_of(_kindNames, _k) + "   (" + _plan.name + ")",
            _x + (_cw * 0.5), _h - _labH - 6, _cw * 0.94, 18, c_black, c_white);
        draw_set_halign(fa_left);
    }
}

/// THE HERO PLATE: one boss, mid wind-up, inside the encounter frame the package ships.
///
/// ⛔ THIS SHEET EXISTS BECAUSE OF A GAP THAT WAS ONLY VISIBLE BESIDE THE GATE 1 REFERENCES. Master
/// CLAUDE.md names four pictures as the bar and the two from this factory a buyer has actually paid
/// for - Sigil Core and Meridian - are both SCREENS. Every plate this product had was a CATALOGUE:
/// a specimen on black with a caption. A catalogue says what is in the box; a screen says what the
/// buyer's game will look like, and that is the thing being sold.
///
/// ⚠️ THE HUD IS NOT DECORATION ADDED FOR THE PHOTOGRAPH. `adv_hud` ships, the demo room draws it,
/// and every number in it is read off the same plan and the same wind the boss is drawn from - so
/// this plate is a photograph of the product rather than a mock-up of one. A store image assembled
/// out of parts the buyer does not receive is the oldest lie in this business.
function adv_bake_encounter(_surf) {
    var _w = surface_get_width(_surf);
    var _h = surface_get_height(_surf);
    var _plan = adv_corpus()[13];                  // abomination - the heaviest silhouette we have
    var _hide = adv_hides()[13 mod adv_hide_count()];
    var _phase = 1;                                // mid-fight: the shell has already opened once
    var _wind = 0.72;
    var _pal = adv_palette_for(_hide, adv_phase_damage(_phase));

    var _st = adv_hud_floor(0, 0, _w, _h, _pal);

    // The telegraph goes UNDER the boss, as it does everywhere else in this package.
    var _bb = adv_render_bounds(adv_body_parts(_plan, _phase, _wind));
    var _sc = min(_st.scale * 2.0 / max(0.0001, _bb[2] - _bb[0]),
                  _st.scale * 2.1 / max(0.0001, _bb[3] - _bb[1]));
    var _ox = _st.cx - (((_bb[0] + _bb[2]) * 0.5) * _sc);
    var _oy = _st.floorY - (_bb[3] * _sc);
    var _tl = adv_bk_tells_for(_plan, _phase);
    for (var _q = 0; _q < array_length(_tl); _q++) {
        adv_bk_draw_tell(_tl[_q], _pal, _ox, _oy, _sc);
    }
    adv_render_parts(adv_body_parts(_plan, _phase, _wind), _pal, _ox, _oy, _sc, 0, _sc, undefined);

    // ⛔ HEALTH IS DERIVED FROM THE PHASE, NOT INVENTED FOR THE PICTURE. A bar showing a value the
    // phase pips contradict would be an interface arguing with itself in the product's own hero
    // image. This is the same expression the demo room uses.
    adv_hud_draw(_plan, _hide, _pal, _phase, adv_hud_demo_health(_phase, _wind), _wind,
                 0, 0, _w, _h);

    draw_set_font(fnt_adversary);
    draw_set_colour(adv_oklch(0.58, 0.012, 258));
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_text(_w * 0.035, _h - (_h * 0.042),
        "Body, phase, damage state, telegraph and interface colour - all from one plan. No sprites.");
}

/// The demo's health model, shared by the demo room and the hero plate so the two cannot disagree.
///
/// ⚠️ IT IS A DEMO VALUE AND THE PACKAGE SAYS SO. Adversary does not own combat: `adv_hud_draw`
/// takes health as an argument and a buyer's own fight drives it. This exists so the shipped demo
/// and the store image show the SAME number, not so anybody ships this curve.
function adv_hud_demo_health(_phase, _wind) {
    var _per = 1 / ADV_PHASES;
    return clamp(1 - (_per * (_phase + clamp(_wind, 0, 1))), 0, 1);
}

/// The store cover, 630x500, rendered by the product out of its own corpus.
///
/// ⛔ NOT AN ILLUSTRATION AND NOT A SCREENSHOT. Master CLAUDE.md §4.2c bars a screenshot-as-cover;
/// this wing's shipped answer is the third option that section names - a DESIGNED typographic plate
/// - and here the pictures in it are the product's real output, so the page's claim that nothing on
/// it is a sprite is a claim the cover itself demonstrates rather than describes.
///
/// ⚠️ THREE BOSSES CHOSEN FOR MATERIAL SPREAD, and it matters more than which archetypes they are:
/// the corpus's darkest hides (obsidian, carapace) vanish against this background, so a cover built
/// from "the three coolest" would have shipped a black rectangle. Stone, ember and frost are the
/// pale/warm/cool triple.
function adv_bake_cover(_surf) {
    var _w = surface_get_width(_surf);
    var _h = surface_get_height(_surf);
    var _pick = [0, 8, 9];

    draw_set_font(fnt_adversary_title);
    draw_set_colour(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_text(_w * 0.055, _h * 0.055, "ADVERSARY");
    draw_set_font(fnt_adversary);
    draw_text(_w * 0.055, _h * 0.165,
        "multi-phase bosses that draw their own bodies and their own tells");

    draw_set_colour(adv_oklch(0.42, 0.010, 250));
    draw_set_alpha(1);
    draw_line_width(_w * 0.055, _h * 0.225, _w * 0.945, _h * 0.225, 2);

    var _px = _w * 0.055;
    var _gap = _w * 0.018;
    var _pw = (_w * 0.89 - (2 * _gap)) / 3;
    var _phMax = _h * 0.575;

    // ⛔ THE PANEL HEIGHT IS MEASURED FROM WHAT GOES IN IT. It was a flat 0.545 of the cover, and
    // these three bosses are all WIDER than they are tall, so every panel was width-bound and each
    // one left a third of itself black under a creature floating in the middle of it. Same law as
    // the sheets: measure the specimen, then cut the frame to it. Bound above so a freak aspect
    // cannot push the count line off the bottom of the cover.
    var _need = 0;
    var _bbs = array_create(3, undefined);
    for (var _i = 0; _i < 3; _i++) {
        _bbs[_i] = adv_render_bounds(adv_body_parts(adv_corpus()[_pick[_i]], ADV_PHASE_WHOLE, 0.45));
        var _bw = max(0.0001, _bbs[_i][2] - _bbs[_i][0]);
        var _bh = max(0.0001, _bbs[_i][3] - _bbs[_i][1]);
        _need = max(_need, ((_pw * 0.88) / _bw) * _bh);
    }
    var _ph = min(_phMax, (_need / 0.88) + (_h * 0.02));

    // ⚠️ AND THE TEXT BLOCK IS BOTTOM-ANCHORED, NOT PUSHED DOWN BY THE PANELS. The first version
    // measured the panels and then placed the count line right under them, which moved BOTH up and
    // left 18% of the cover black along the bottom edge - the dead space was not removed, it was
    // relocated. Fixed layout landmarks, panels centred in what is left between them.
    var _bandTop = _h * 0.245;
    var _bandBot = _h * 0.745;
    var _py = _bandTop + (((_bandBot - _bandTop) - _ph) * 0.5);

    for (var _i = 0; _i < 3; _i++) {
        var _x = _px + (_i * (_pw + _gap));
        var _plan = adv_corpus()[_pick[_i]];
        var _pal  = adv_palette_for(adv_hides()[_pick[_i] mod adv_hide_count()], 0);
        draw_set_colour(adv_oklch(0.22, 0.010, 250));
        draw_rectangle(_x, _py, _x + _pw, _py + _ph, false);
        draw_set_colour(adv_oklch(0.36, 0.010, 250));
        draw_rectangle(_x, _py, _x + _pw, _py + _ph, true);
        // TIGHT here and not on the corpus sheet, deliberately: that plate compares fourteen bosses
        // and needs one shared scale, this one is three portraits and each should fill its frame.
        adv_render_in_rect_tight(adv_body_parts(_plan, ADV_PHASE_WHOLE, 0.45), _pal,
            _x + (_pw * 0.06), _py + (_ph * 0.06), _pw * 0.88, _ph * 0.88, undefined);
    }

    // ⛔ DERIVED, NEVER TYPED - this is the line a buyer prices the product against.
    draw_set_colour(c_white);
    draw_set_font(fnt_adversary_title);
    draw_text(_w * 0.055, _h * 0.775, string(adv_corpus_count()) + " bosses  x  "
        + string(ADV_PHASES) + " phases  x  " + string(adv_hide_count()) + " materials");
    draw_set_font(fnt_adversary);
    draw_set_colour(adv_oklch(0.62, 0.012, 250));
    draw_text(_w * 0.055, _h * 0.870, "pure GML, no sprites, no atlas");
}

/// The demo GIF's frames, rendered THROUGH THE PRODUCT.
///
/// ⭐ THE GIF MATTERS MORE ON THIS PRODUCT THAN ON ANY OTHER IN THIS WING, and it is worth saying
/// why rather than shipping one because the checklist asks for one. Every sheet here is a STILL of
/// a thing whose entire claim is about TIME - a warning that arrives before a blow. Five successive
/// telegraph renders were rejected for reading as anatomy on a static plate, and the sixth was only
/// legible once the arm MOVED between frames. A still picture is the medium in which this product
/// is hardest to understand; the loop is the one in which it explains itself.
///
/// The sequence is the whole product in four seconds: the tell appears, the arm winds into it, the
/// blow lands - then the same boss again with its shell broken, and again exposed, the material
/// dulling each time. One set of numbers throughout.
///
/// ⛔ ONE SURFACE, REUSED. Wing CLAUDE.md, from Raiment: a per-frame surface_create/surface_free
/// pair killed a bake on its fifth sheet with "Memory allocation failed", because GameMaker does not
/// release a surface's texture synchronously and the pool never catches up. At forty-odd frames that
/// failure mode is certain rather than likely.
///
/// ⛔ AND THE SCALE IS FIXED, NOT FITTED. `adv_render_in_rect_tight` fits each frame to its OWN
/// bounding box - right for a catalogue cell, catastrophic for an animation, because the boss would
/// grow and shrink as the arm swings and the loop would breathe instead of striking.
function adv_gif_all() {
    var _W = 520;
    var _H = 400;
    var _plan = adv_corpus()[0];                       // colossus - a fist, so an IMPACT tell
    var _hide = adv_hides()[0];
    var _surf = surface_create(_W, _H);
    var _bg = adv_oklch(0.16, 0.012, 250);

    // Wind samples per phase: a slow wind-up, a hold on the landing, a quick recovery. The hold is
    // what lets a reader SEE the fist arrive inside the mark that was there before it.
    var _winds = [];
    var _k;
    for (_k = 0; _k <= 12; _k++) array_push(_winds, _k / 12);
    for (_k = 0; _k < 4; _k++)   array_push(_winds, 1);
    for (_k = 3; _k >= 1; _k--)  array_push(_winds, _k / 4);

    // ONE scale and ONE origin for the whole loop, measured over every phase AND every wind so
    // nothing can leave the frame at a pose the measurement never saw.
    var _bb = [999, 999, -999, -999];
    var _ph;
    for (_ph = 0; _ph < ADV_PHASES; _ph++) {
        for (_k = 0; _k < array_length(_winds); _k++) {
            var _e = adv_render_bounds(adv_body_parts(_plan, _ph, _winds[_k]));
            _bb[0] = min(_bb[0], _e[0]); _bb[1] = min(_bb[1], _e[1]);
            _bb[2] = max(_bb[2], _e[2]); _bb[3] = max(_bb[3], _e[3]);
        }
        var _t0 = adv_bk_tells_for(_plan, _ph);
        for (_k = 0; _k < array_length(_t0); _k++) {
            var _tb = adv_bk_tell_bounds(_t0[_k]);
            _bb[0] = min(_bb[0], _tb[0]); _bb[1] = min(_bb[1], _tb[1]);
            _bb[2] = max(_bb[2], _tb[2]); _bb[3] = max(_bb[3], _tb[3]);
        }
    }
    var _sc = min((_W * 0.86) / max(0.0001, _bb[2] - _bb[0]),
                  (_H * 0.76) / max(0.0001, _bb[3] - _bb[1]));
    var _ox = (_W * 0.5) - (((_bb[0] + _bb[2]) * 0.5) * _sc);
    var _oy = (_H * 0.46) - (((_bb[1] + _bb[3]) * 0.5) * _sc);

    var _n = 0;
    for (_ph = 0; _ph < ADV_PHASES; _ph++) {
        var _pal = adv_palette_for(_hide, adv_phase_damage(_ph));
        var _tl = adv_bk_tells_for(_plan, _ph);
        for (_k = 0; _k < array_length(_winds); _k++) {
            surface_set_target(_surf);
            draw_clear(_bg);
            for (var _q = 0; _q < array_length(_tl); _q++) {
                adv_bk_draw_tell(_tl[_q], _pal, _ox, _oy, _sc);
            }
            adv_render_parts(adv_body_parts(_plan, _ph, _winds[_k]), _pal, _ox, _oy, _sc, 0, _sc,
                undefined);

            draw_set_font(fnt_adversary);
            draw_set_colour(c_white);
            draw_set_halign(fa_left);
            draw_set_valign(fa_top);
            // ⛔ DERIVED. The phase name and the plate count come off the package's own arrays, so a
            // frame cannot caption a state the boss is not in.
            draw_text(16, 14, string_upper(_plan.name) + "  -  "
                + adv_name_of(adv_phase_names(), _ph) + ", "
                + string(adv_armour_drawn_count(_plan, _ph)) + " plates");
            draw_set_colour(adv_oklch(0.60, 0.012, 250));
            draw_text(16, _H - 30, "one set of numbers - the body, the phase and the warning");
            surface_reset_target();

            // Zero-padded to three digits by ARITHMETIC: GML's string_format pads with SPACES, and a
            // filename with a space in it is not a sequence ffmpeg can read.
            var _num = string(_n);
            while (string_length(_num) < 3) _num = "0" + _num;
            surface_save(_surf, "gif_" + _num + ".png");
            _n += 1;
        }
    }
    surface_free(_surf);

    var _f = file_text_open_write("adv_gif.json");
    file_text_write_string(_f, "{\"ran\":true,\"frames\":" + string(_n)
        + ",\"phases\":" + string(ADV_PHASES)
        + ",\"winds\":" + string(array_length(_winds))
        + ",\"w\":" + string(_W) + ",\"h\":" + string(_H) + "}");
    file_text_close(_f);
}

/// Drive the whole bake. Called from the demo object when the exe is run with -bake.
function adv_bake_all() {
    // ⚠️ THE COUPLING SHEETS ARE 560 TALL, NOT 900, AND THE CANVAS IS THE FIX RATHER THAN THE PADS.
    // Four figures side by side, each about 1.4 times as wide as it is tall, is a band roughly 5.5:1
    // - so on a 16:9 canvas the layout is WIDTH-bound by construction and no padding value can
    // recover the vertical space. It measured 34% of the sheet empty above and below the row while
    // every floor passed, because a bounding box cannot see the space inside itself. Wing CLAUDE.md
    // records the same conclusion on Horologe: when a specimen's aspect and its cell's aspect
    // disagree, fix the CELL - and here the cell is the whole canvas.
    var _sheets = [
        // ⛔ `bleed` IS A DECLARATION, NOT A LOOSENED THRESHOLD. The clipped test asks "does ink
        // touch the frame edge", which is the right question for a specimen on a background and the
        // WRONG one for a full-bleed game screen, whose ground and sky are supposed to reach every
        // edge - it fired on this plate the first time it was baked. Master CLAUDE.md is explicit
        // that a threshold must never be raised to make a check pass, so the check is unchanged and
        // this sheet states which question applies to it. Every other sheet still answers the strict
        // one, and a specimen plate that starts bleeding still goes red.
        { name: "sheet_0_encounter", w: 1280, h: 720, kind: 5, arg: 0, bleed: true },
        { name: "sheet_1_corpus",   w: 1600, h: 1000, kind: 0, arg: 0 },
        { name: "sheet_2_coupling", w: 1600, h:  560, kind: 1, arg: 0 },
        { name: "sheet_3_coupling_wyrm", w: 1600, h: 560, kind: 1, arg: 1 },
        // ⚠️ 620 -> 500 FOR THE SAME REASON, RE-DERIVED RATHER THAN GUESSED. Three bosses side by
        // side is a band about 4.3:1, and with the telegraph taken off this plate (see the note in
        // adv_bake_phases) the bodies got wider relative to their height, so 620 left 127 px of
        // black under the captions - MEASURED as fillH 0.78 while every floor passed, because an ink
        // BOX cannot see the space inside itself. This is the third sheet on this product to be
        // fixed at the canvas rather than at the pads.
        // ⛔ arg -1 = "pick the boss that actually demonstrates this plate's caption". A hand-picked
        // index put a creature on it whose shell does not peel until the final phase.
        { name: "sheet_4_phases", w: 1600, h: 500, kind: 2, arg: -1 },
        { name: "sheet_5_tells", w: 1600, h: 620, kind: 3, arg: 0 },
        { name: "cover", w: 630, h: 500, kind: 4, arg: 0 }
    ];
    var _bg = adv_oklch(0.16, 0.012, 250);
    var _report = [];

    for (var _i = 0; _i < array_length(_sheets); _i++) {
        var _s = _sheets[_i];
        var _surf = surface_create(_s.w, _s.h);
        surface_set_target(_surf);
        draw_clear(_bg);

        global.adv_stage = 200 + _i;
        switch (_s.kind) {
            case 0: adv_bake_corpus(_surf, _bg); break;
            case 1: adv_bake_coupling(_surf, _s.arg); break;
            case 2: adv_bake_phases(_surf, _s.arg); break;
            case 3: adv_bake_tells(_surf); break;
            case 4: adv_bake_cover(_surf); break;
            case 5: adv_bake_encounter(_surf); break;
        }

        var _ib = adv_bk_ink_bounds(_surf, _bg);
        surface_reset_target();
        surface_save(_surf, _s.name + ".png");
        surface_free(_surf);

        // Coverage as a FRACTION OF THE SHEET, reported per sheet so a sparse one is visible in
        // the numbers as well as in the picture.
        var _fw = (_ib.x1 - _ib.x0) / _s.w;
        var _fh = (_ib.y1 - _ib.y0) / _s.h;
        array_push(_report, {
            name: _s.name, w: _s.w, h: _s.h,
            x0: _ib.x0, y0: _ib.y0, x1: _ib.x1, y1: _ib.y1,
            fillW: _fw, fillH: _fh, ink: _ib.ink,
            clipped: (variable_struct_exists(_s, "bleed") && _s.bleed)
                     ? false
                     : ((_ib.x0 <= 1) || (_ib.y0 <= 1) || (_ib.x1 >= _s.w - 2)
                        || (_ib.y1 >= _s.h - 2))
        });
    }

    var _f = file_text_open_write("adv_bake.json");
    file_text_write_string(_f, "[");
    for (var _i = 0; _i < array_length(_report); _i++) {
        var _r = _report[_i];
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "{\"name\":\"" + _r.name + "\",\"w\":" + string(_r.w)
            + ",\"h\":" + string(_r.h) + ",\"x0\":" + string(_r.x0) + ",\"y0\":" + string(_r.y0)
            + ",\"x1\":" + string(_r.x1) + ",\"y1\":" + string(_r.y1)
            + ",\"fillW\":" + string(_r.fillW) + ",\"fillH\":" + string(_r.fillH)
            + ",\"ink\":" + string(_r.ink) + ",\"clipped\":" + (_r.clipped ? "true" : "false") + "}");
    }
    file_text_write_string(_f, "]");
    file_text_close(_f);
}
