/// adv_limb.gml — THE CHAIN SOLVER. The single source of truth for where a limb actually is.
///
/// ============================================================================================
/// THIS FILE IS THE COUPLING. READ THIS BEFORE CHANGING ANY NUMBER IN IT.
/// ============================================================================================
/// `adv_body` draws a limb by asking this file for its joints. `adv_tell` draws that limb's
/// telegraph by asking this file for its reach. Neither keeps its own copy of either. That is why
/// a tell in this package cannot drift from the arm it belongs to, and it is the one thing the
/// two halves of the shelf (a fixed boss you cannot alter / behaviour with no body) cannot offer.
///
/// ⛔ THE INVARIANT IS ASSERTED AGAINST THE DRAWN GEOMETRY, NOT AGAINST THE DECLARATION.
/// `adv_limb_reach_declared` sums the segment lengths - a DECLARATION, and the number the
/// telegraph is drawn from. `adv_limb_reach_drawn` measures the distance from the pivot to the
/// SOLVED tip of the actual joint chain - a MEASUREMENT. adv_selftest requires them to agree.
///
/// Asserting the telegraph's radius against `adv_limb_reach_declared` would be verifying the field
/// just written (CLAUDE.md §2b, seventh of that family: a re-rank "verified" itself by sorting on
/// the field it had set). Wing CLAUDE.md records the correct form from Liege: compare the head to
/// the ACTUAL TORSO OUTLINE, not to the function that leans it, "because that asks the question a
/// viewer asks". So the two paths here are deliberately independent computations of the same
/// physical quantity, and the day somebody adds a foreshortening term to the solver without
/// telling the telegraph, the suite goes red by name.
///
/// ⚠️ ANGLE CONVENTION, STATED ONCE, AND IT CHANGED ONCE THE FIRST SHEET WAS LOOKED AT.
/// The whole chain is solved in the RIGHT-SIDE FRAME and mirrored ONLY by the `_side` factor on x.
/// `limb.ang` is an offset from HANGING STRAIGHT DOWN (ADV_REST_ANG): negative swings the limb
/// forward and up, positive swings it back toward the tail. No angular term is multiplied by
/// `_side` - doing so mirrors the left limb twice and runs its bend and wind-up backwards.
/// Wing CLAUDE.md carries an entire corpus built upside down from exactly that double reversal,
/// with 1,482 assertions green over it, because every part was individually correct and only the
/// assembly was wrong. Nothing mechanical catches it; the instrument is opening the PNG - and that
/// is precisely how both halves of this were found here.

/// Total reach of a limb, DECLARED. Fraction of core height, matching `limb.len`'s stated unit.
///
/// ⚠️ This is the number the telegraph is drawn from. It is deliberately the simplest possible
/// expression of "how far can this thing hit from its own pivot", so that the solver is free to
/// get more sophisticated without silently redefining what a tell means.
function adv_limb_reach_declared(_limb) {
    return _limb.len;
}

/// Segment lengths down the chain. The chain shortens toward the tip in the same proportion as it
/// narrows, which is what makes a limb read as a LIMB rather than as a row of equal sticks.
///
/// ⚠️ The weights are NORMALISED so they sum to `limb.len` exactly. That matters: the declared
/// reach above is `limb.len`, so any weighting scheme that did not normalise would make the
/// declaration and the drawing disagree by however much the weights happened to sum to - and the
/// disagreement would scale with segment count, so it would look like a bug in the longest limbs.
function adv_limb_segments(_limb) {
    var _n = max(1, _limb.segs);
    var _w = array_create(_n, 0);
    var _sum = 0;
    for (var _i = 0; _i < _n; _i++) {
        // Later segments are shorter. 1.0 down to the taper fraction, linearly.
        var _t = (_n <= 1) ? 0 : (_i / (_n - 1));
        _w[_i] = lerp(1.0, max(0.35, _limb.taper), _t);
        _sum += _w[_i];
    }
    // ⛔ NORMALISE BEFORE SCALING, never after, and guard the zero. Wing CLAUDE.md records a
    // p-norm over sub-unit values landing under GML's 0.00001 default epsilon and discarding
    // EVERY BODY IN A 48-SPECIES CORPUS while the gate stayed clean, so a sum that could be small
    // is normalised rather than divided into blindly.
    if (_sum < 0.0001) {
        for (var _i = 0; _i < _n; _i++) _w[_i] = _limb.len / _n;
        return _w;
    }
    for (var _i = 0; _i < _n; _i++) _w[_i] = (_w[_i] / _sum) * _limb.len;
    return _w;
}

/// How much each phase folds the chain. A boss that has lost a phase does not stand as tall.
///
/// ⚠️ Returns a FOLD, applied per joint, not a length change: a broken boss still has the same
/// arm, it just carries it differently. Shortening `len` per phase instead would make the
/// telegraph shrink, which would tell the player the attack is safer when it is not.
function adv_limb_phase_fold(_phase) {
    switch (_phase) {
        case ADV_PHASE_WHOLE:   return 0.00;
        case ADV_PHASE_BROKEN:  return 0.22;
        case ADV_PHASE_EXPOSED: return 0.40;
    }
    return 0.00;
}

/// Solve the joint chain. Returns an array of `[x, y]` points in core-relative units, with
/// joints[0] = the pivot (the limb's attachment on the core's own surface).
///
/// `_wind` is the wind-up parameter, 0 at rest and 1 at full extension toward the strike. It is
/// the SAME parameter the telegraph's arc is swept by, so a tell at `_wind` and a limb at `_wind`
/// describe one moment.
///
/// ⛔ THE ARM ROTATES ABOUT THE BODY'S VERTICAL AXIS AS WELL AS IN THE PICTURE PLANE. Wing
/// CLAUDE.md records 61% of a 46-figure corpus rendering as SCARECROWS because a 2D limb chain can
/// only reach sideways, so the only way to put a hand high was to swing the whole arm out
/// horizontally. Four sessions were spent re-picking which figures to show before anyone noticed
/// no parameter could fix it. The fix is one term: foreshorten the in-plane extent by cos(fwd) so
/// the limb reaches IN FRONT of the body, which shrinks the lateral spread and leaves the reach
/// alone.
///
/// ⚠️ AND THAT IS EXACTLY WHY THE TELL IS ASSERTED AGAINST THE DRAWN TIP. Foreshortening changes
/// where the limb LOOKS like it ends without changing how far it can HIT. `adv_limb_reach_drawn`
/// measures the unforeshortened chain for that reason, and says so.
function adv_limb_joints(_plan, _limb, _side, _phase, _wind) {
    var _seg  = adv_limb_segments(_limb);
    var _n    = array_length(_seg);
    var _fold = adv_limb_phase_fold(_phase);

    // Attachment point on the core. `at` runs 0 (crown end) to 1 (tail end).
    var _px = _side * (_plan.core.w * 0.5) * adv_core_halfwidth_at(_plan, _limb.at);
    var _py = lerp(-_plan.core.h * 0.5, _plan.core.h * 0.5, _limb.at);

    // ⛔⛔ ANGLES ARE SOLVED IN THE RIGHT-SIDE FRAME AND MIRRORED ONLY BY THE `_side` ON X.
    //
    // The first version worked in world angles and multiplied EVERY angular term by `_side`. Two
    // separate defects came out of that, and the sheet showed both at once:
    //
    //  1. THE SCARECROW. `_a = 0` points along +x, i.e. HORIZONTAL, so a rest angle of -0.30 rad
    //     was an arm held out sideways. Every limb in the corpus splayed, on all fourteen bosses,
    //     which is exactly the failure wing CLAUDE.md records costing four sessions on a 46-figure
    //     corpus - "a 2D limb chain can only reach sideways, so every raised hand is a spread arm",
    //     and four different figure PICKS all failed the same way before anyone asked whether any
    //     parameter could fix it. ✅ Rest is now DOWN (ADV_REST_ANG), which is where a limb hangs,
    //     and `limb.ang` is an offset from it.
    //  2. THE DOUBLE MIRROR. Because x is already multiplied by `_side`, multiplying the ANGLE by
    //     `_side` as well reverses the left limb twice - so bend and wind-up ran BACKWARDS on one
    //     side of every boss. That is the same double-reversal wing CLAUDE.md records shipping an
    //     entire corpus built upside down under 1,482 green assertions, because each part was
    //     individually correct and only the assembly was wrong.
    //
    // ⚠️ So `limb.ang` is an offset from HANGING DOWN: negative swings the limb FORWARD/UP,
    // positive swings it back toward the tail. It is applied unmirrored, in this frame, once.
    var _base = ADV_REST_ANG + _limb.ang;

    // The wind-up raises the chain toward the strike; the fold drops it back.
    var _swing = _base - (_wind * ADV_WIND_ARC) + (_fold * 0.5);

    var _pts = array_create(_n + 1);
    _pts[0] = [_px, _py];

    var _a = _swing;
    var _x = _px;
    var _y = _py;
    for (var _i = 0; _i < _n; _i++) {
        // Each joint bends a little further than the last - that is what makes a chain read as
        // jointed rather than as one curved horn. The fold deepens the bend per phase.
        _a += (ADV_JOINT_BEND * (_i / max(1, _n))) + _fold;
        var _fwd = _wind * ADV_FWD_ROT;
        var _fs  = max(ADV_FS_MIN, cos(_fwd));      // foreshortening, floored
        _x += cos(_a) * _seg[_i] * _side * _fs;
        _y += sin(_a) * _seg[_i];
        _pts[_i + 1] = [_x, _y];
    }
    return _pts;
}

/// The MEASURED reach of the drawn chain: the furthest the tip actually gets from its own pivot
/// at any point in the swing. Swept over the wind-up, taken off the SOLVED joints.
///
/// ⛔⛔ THE FIRST VERSION OF THIS FUNCTION SUMMED `adv_limb_segments` AND WAS WORTHLESS. Those
/// weights are normalised to sum to `limb.len`, which is the declaration, so it returned the
/// declared value back and any assertion against it would have passed BY CONSTRUCTION - the exact
/// "verifying against the field you wrote" trap this file's own header warns about, written into
/// the file three minutes after writing the warning. It would have been a permanently green gate
/// over the one claim the product is sold on.
///
/// ✅ What makes this independent is the BEND. The chain accumulates `ADV_JOINT_BEND` per joint,
/// so a solved limb reaches materially LESS far than the sum of its segments, and by an amount
/// nothing here declares. The suite therefore compares two genuinely different computations, and
/// the day somebody tunes the bend, adds a joint or reweights the segments, the telegraph's
/// promise stops matching the limb and the suite says so by name.
///
/// ⛔ UNFORESHORTENED ON PURPOSE, AND THIS IS THE SUBTLE PART. Foreshortening is a PICTORIAL
/// effect - it changes where the tip appears, not how far the boss can hit. A telegraph is a
/// promise about DANGER, so it must describe the reach, not the projection. Measuring the
/// projected tip would make the tell SHRINK as the arm swung forward, i.e. signal that the attack
/// is getting safer at exactly the moment it is getting more dangerous.
///
/// ⚠️ Swept, not sampled at full extension. A chain that bends as it winds does not necessarily
/// reach furthest at `_wind == 1` - and this wing has already paid for the difference: a gate that
/// aggregated over a cycle while the store sheet drew an arbitrary frame cost three sessions of
/// work on the wrong quantity. ADV_SWEEP_N is shared with the telegraph for the same reason.
function adv_limb_reach_drawn(_plan, _limb, _side, _phase) {
    var _best = 0;
    for (var _s = 0; _s <= ADV_SWEEP_N; _s++) {
        var _w  = _s / ADV_SWEEP_N;
        var _p  = adv_limb_joints(_plan, _limb, _side, _phase, _w);
        var _n  = array_length(_p);
        var _px = _p[0][0];
        var _py = _p[0][1];
        // Undo the foreshortening applied by the solver, so this measures DANGER not projection.
        var _fs = max(ADV_FS_MIN, cos(_w * ADV_FWD_ROT));
        var _dx = (_p[_n - 1][0] - _px) / _fs;
        var _dy = (_p[_n - 1][1] - _py);
        var _d  = sqrt((_dx * _dx) + (_dy * _dy));
        if (_d > _best) _best = _d;
    }
    return _best;
}

/// Where the limb's tip is right now, for the terminal form to be drawn at.
///
/// ⚠️ POINTS ARE `[x, y]` ARRAYS THROUGHOUT THIS PACKAGE, matching every primitive in adv_geom
/// (adv_var_ribbon, adv_qbez, adv_arc_pts all take and return them). The first draft of this file
/// returned `{x, y}` structs and would have needed a conversion at the one boundary where parts
/// are built - which is precisely the kind of two-representations-of-one-thing seam this product's
/// own units law exists to forbid.
function adv_limb_tip(_plan, _limb, _side, _phase, _wind) {
    var _p = adv_limb_joints(_plan, _limb, _side, _phase, _wind);
    return _p[array_length(_p) - 1];
}

/// ============================================================================================
/// THE CORE FORM FAMILY. Eight silhouettes, not one lens with a knob on it.
/// ============================================================================================
/// ⛔ THE FIRST VERSION OF `adv_core_halfwidth_at` WAS `power(sin(pi * u), e)`, AND EVERY BOSS IN
/// THE CORPUS CAME OUT THE SAME EGG. `sin(pi * u)` is symmetric about u = 0.5, and raising a
/// symmetric function to a power leaves it symmetric - so no value of `profile` could ever produce
/// a wide-shouldered anvil, a low-slung bulb, a flat-based carapace or a wedge. Fourteen archetypes
/// were being told apart by COLOUR and LIMB COUNT alone, on the contact sheet whose entire job is to
/// prove the corpus is a corpus, and the store copy's "42 bodies" was not true of the picture.
///
/// Wing CLAUDE.md carries this as a law, from Chitin's Lepidoptera: "when a shape is wrong in a way
/// no parameter reaches, the defect is in the MODEL and every hour spent on its numbers is wasted.
/// The test is cheap: name the feature that makes the subject recognisable, then ask whether the
/// function can express it AT ALL." A lens cannot express shoulders.
///
/// ⭐ THE FIX KEEPS THE SIGNATURE, WHICH IS WHY IT IS CHEAP. Chitin's wing rewrite kept
/// `cht_wing_pt(w, s, c)` so every band, spot and vein authored against it carried over untouched.
/// `adv_core_halfwidth_at(_plan, _t)` is read by the core outline, by all eleven tube bands, by the
/// armour plating and by every limb's attachment point - and not one of those readers changed.
///
/// A form is a GIRTH PROGRAM: seven control half-widths from crown (t = 0) to tail (t = 1).
#macro ADV_FORM_SPINDLE   0
#macro ADV_FORM_ANVIL     1
#macro ADV_FORM_BULB      2
#macro ADV_FORM_DRUM      3
#macro ADV_FORM_CARAPACE  4
#macro ADV_FORM_WEDGE     5
#macro ADV_FORM_HOURGLASS 6
#macro ADV_FORM_LOBED     7

function adv_core_forms() {
    static _f = undefined;
    if (!is_undefined(_f)) return _f;
    _f = [
        [0.30, 0.68, 0.93, 1.00, 0.90, 0.64, 0.32],  // SPINDLE   - tapered both ends, serpentine
        [0.50, 0.96, 1.00, 0.82, 0.68, 0.64, 0.58],  // ANVIL     - shoulders high, narrowing down
        [0.24, 0.34, 0.54, 0.80, 1.00, 0.96, 0.58],  // BULB      - small crown over a heavy abdomen
        [0.80, 0.97, 1.00, 1.00, 1.00, 0.97, 0.84],  // DRUM      - near-constant, constructed
        [0.30, 0.68, 0.90, 1.00, 1.00, 0.95, 0.88],  // CARAPACE  - domed top, broad flat base
        [0.97, 1.00, 0.86, 0.70, 0.52, 0.32, 0.14],  // WEDGE     - broad crown tapering to a point
        [0.58, 0.92, 0.66, 0.44, 0.70, 0.94, 0.54],  // HOURGLASS - waisted
        [0.38, 0.86, 0.56, 0.92, 0.58, 0.88, 0.42]   // LOBED     - visibly segmented
    ];
    return _f;
}

/// Names, index-parallel with the table above.
///
/// ⛔ Wing CLAUDE.md, from Chitin: a name array summed into a market claim must be index-parallel
/// with a real switch, or the listing quotes forms the package does not have - twelve materials in
/// that product were all captioned "structural" because an 18-case switch was indexed into a
/// 6-entry array with the overflow clamped away. adv_selftest asserts these two lengths agree.
function adv_core_form_names() {
    return ["spindle", "anvil", "bulb", "drum", "carapace", "wedge", "hourglass", "lobed"];
}

function adv_core_form_count() { return array_length(adv_core_forms()); }

/// Half-width of the core at station `_t` (0 crown .. 1 tail), as a fraction of core.w * 0.5.
///
/// ⚠️ A SHAPE IS ONLY AS WIDE AS ITS SPAN AT THAT HEIGHT. Wing CLAUDE.md carries this twice - a
/// boulder's cleavage planes clipped to its BOUNDING BOX grew whiskers, and marks placed by the
/// span at their CENTRE poked out of a narrowing crystal. A limb attaches to the core's surface,
/// so it must attach at the width the core actually has THERE, or every limb on a tapering body
/// floats off it.
///
/// ⚠️ SMOOTHSTEP BETWEEN ADJACENT KNOTS, NOT CATMULL-ROM, AND THE REASON IS A DECLARED EXTENT.
/// A Catmull-Rom through alternating control values OVERSHOOTS them, and the LOBED program above
/// alternates hard on purpose - an overshoot would push the drawn body wider than `core.w`, which
/// this product DECLARES and asserts against. Smoothstep between two knots is bounded by those two
/// knots by construction, so the interpolator cannot violate the declaration at any control values
/// a future row picks. It is also C1 at the knots, so a seam does not show as a crease.
function adv_core_halfwidth_at(_plan, _t) {
    var _forms = adv_core_forms();
    var _fi = clamp(_plan.core.form, 0, array_length(_forms) - 1);
    var _g  = _forms[_fi];
    var _n  = array_length(_g);

    var _u = clamp(_t, 0, 1) * (_n - 1);
    var _i = clamp(floor(_u), 0, _n - 2);
    var _k = _u - _i;
    _k = _k * _k * (3 - (2 * _k));
    var _w = lerp(_g[_i], _g[_i + 1], _k);

    // `profile` is FULLNESS, and it is applied as an EXPONENT so that it maps into the range rather
    // than adding into it. Wing CLAUDE.md, from Muster: "a term added to a value that is then
    // clamped silently does nothing at the top of its range, which is usually where it was needed"
    // - a mottle term was discarded entirely on exactly the high plateaux that most needed it.
    // An exponent on a value in (0, 1] cannot saturate and preserves the form's own shape.
    // ⚠️ Bounded far above GML's 0.00001 comparison epsilon: the smallest case in the table is
    // 0.14 ^ 1.55 = 0.045, and the floor below is 0.16 anyway.
    var _e = lerp(1.55, 0.70, clamp(_plan.core.profile, 0, 1));
    // Never returns 0 in the interior - a limb attached at exactly the tip would otherwise start at
    // the centre line and read as growing out of thin air.
    var _prof = power(_w, _e);

    // ⛔ THE END CAPS, AND WITHOUT THEM EVERY WIDE-TAILED FORM IS SAWN OFF. adv_core_outline walks
    // the right flank to t = 1 and then back up the left, so it CLOSES WITH A STRAIGHT CHORD - and
    // the eleven tube bands each run the full length too, so the mass ends flat as well as the
    // outline. On a form that is still wide at its end that is a hard horizontal cut across the
    // body: measured on the phases sheet as a flat base under the broodmother (BULB, 0.58 at the
    // tail) and visible on the golem (DRUM, 0.84) and arachnid (CARAPACE, 0.88), plus a flat wide
    // TOP on the sentinel (WEDGE, 0.97 at the crown).
    //
    // ⭐ IT GOES HERE, AFTER THE FLOOR, FOR THE SAME REASON THE FORM FAMILY WENT HERE: one function,
    // every reader. The outline, all eleven bands, the plate seams and the limb attachments each ask
    // this one question, so capping the profile rounds the mass and the rim TOGETHER. Capping only
    // adv_core_outline would have rounded the rim line around a still-flat body.
    //
    // ⚠️ IT CANNOT DISTURB A LIMB. The envelope bites only inside the outer 6% of the core, and the
    // corpus's most extreme attachment stations are 0.08 (abomination) and 0.90 (chimera) - so no
    // limb in the package sits in the capped region.
    //
    // ⛔ AND IT IS APPLIED **INSIDE** THE FLOOR, WHICH IS THE WHOLE DIFFERENCE BETWEEN A ROUNDED END
    // AND A BROKEN ONE. Applied after the floor it drives the half-width to exactly 0 at t = 0 and
    // t = 1, and the suite went RED 28 times - stage 6 asserts the profile never collapses below
    // 0.05, for the stated reason that a limb attaching at the centre line reads as growing out of
    // thin air. That assertion is protecting a real property and was right to fire. Inside the
    // floor, the PROFILE rounds off and the FLOOR catches it, so a wide-tailed form tapers to a
    // small blunt end instead of being sawn square across - which is what a body actually does.
    var _u2 = clamp(_t, 0, 1);
    var _cap = 0.06;
    if (_u2 < _cap)          _prof *= sin((_u2 / _cap) * pi * 0.5);
    else if (_u2 > 1 - _cap) _prof *= sin(((1 - _u2) / _cap) * pi * 0.5);
    return max(0.16, _prof);
}

/// ⛔ REST IS DOWN, NOT ALONG +X. `_a = 0` in this solver points horizontally, which made every
/// rest pose a spread arm - the scarecrow defect. pi/2 is straight down in screen coordinates
/// (y grows downward), i.e. where a limb actually hangs.
#macro ADV_REST_ANG  1.5707963267948966
#macro ADV_WIND_ARC  1.05   // radians a striking limb travels between rest and full extension
#macro ADV_JOINT_BEND 0.34  // radians of extra bend per joint down the chain
#macro ADV_FWD_ROT   0.62   // radians the limb rotates out of the picture plane at full wind-up
#macro ADV_FS_MIN    0.42   // floor on foreshortening - a fully foreshortened limb draws as a dot
#macro ADV_SWEEP_N   24     // wind-up samples. SHARED by the reach measurement and the telegraph,
                            // deliberately: two sweeps over different frame sets can disagree
                            // about which frame is furthest, and then the tell would be drawn for
                            // a moment the gate never graded (wing CLAUDE.md, Liege's work-beat).

/// ============================================================================================
/// THE TWO-SIDED TELEGRAPH BOUND. This is the product's central safety property.
/// ============================================================================================
/// A telegraph is a PROMISE to the player about where it is dangerous to stand. It can fail in two
/// directions and they are not symmetric:
///
///   UNDER-DRAWN - the limb reaches PAST its own telegraph. The player stands where the game told
///                 them it was safe and is hit. This is the unforgivable one.
///   OVER-DRAWN  - the telegraph claims ground the limb cannot touch. The player dodges something
///                 that was never there, and learns to distrust every tell in the game.
///
/// ⛔ SO BOTH BOUNDS ARE ASSERTED, NOT JUST THE OBVIOUS ONE. Wing CLAUDE.md records a one-sided
/// threshold letting a final boss drift to a 100% win rate with every check green - "a one-sided
/// threshold cannot detect drift in its permissive direction, and that is the direction things rot
/// in". The floor here is the permissive direction: without it, the honest way to satisfy
/// COVERAGE is to draw an enormous arc round the whole boss.
///
/// The tightness floor is a PRE-REGISTERED design decision, not a bar fitted to today's numbers:
/// a telegraph may be up to a third larger than the reach it describes, because a player needs
/// margin to read it, and no larger.
#macro ADV_TELL_COVER_MIN 1.00   // tell radius >= drawn reach. Under-drawing is never acceptable.
#macro ADV_TELL_COVER_MAX 1.34   // and no more than a third of margin over it.
