{
  "$GMScript": "v1",
  "%Name": "adv_limb",
  "name": "adv_limb",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}