{
  "$GMScript": "v1",
  "%Name": "adv_relief",
  "name": "adv_relief",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}