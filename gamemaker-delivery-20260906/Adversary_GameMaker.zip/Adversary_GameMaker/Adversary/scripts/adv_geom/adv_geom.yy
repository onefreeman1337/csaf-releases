{
  "$GMScript": "v1",
  "%Name": "adv_geom",
  "name": "adv_geom",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}