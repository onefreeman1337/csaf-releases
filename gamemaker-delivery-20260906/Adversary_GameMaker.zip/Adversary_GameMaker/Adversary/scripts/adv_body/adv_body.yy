{
  "$GMScript": "v1",
  "%Name": "adv_body",
  "name": "adv_body",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}