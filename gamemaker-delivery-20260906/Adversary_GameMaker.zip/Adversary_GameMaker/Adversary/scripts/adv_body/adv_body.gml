/// adv_body.gml — THE MASSES. Turns a plan into a drawn boss.
///
/// Everything here reads `adv_limb`'s solved chain. Nothing re-derives where a limb is, so the
/// body and its telegraph cannot disagree — that is the package's whole claim.
///
/// ============================================================================================
/// THE FOUR LAWS THIS FILE IS BUILT AROUND, every one paid for by a shipped defect in this wing
/// ============================================================================================
/// 1. A LIMB IS **ONE MASS**, NOT A CHAIN OF MASSES. Faking a curve with three tapers end to end
///    bevels each on its OWN outline, so every join gets a lit edge running across the object and
///    a war horn read as three chevrons. The chain is resampled into a smooth spine and a single
///    variable-width ribbon is built from it.
/// 2. A LONG BODY IS A **TUBE**, NOT A DOME. Scaling a long waisted shape about one centroid is
///    not a dome, it is a collapse toward the middle, and it renders as a pale puzzle-piece.
///    Shade from the LATERAL coordinate alone, as longitudinal strips clipped per row to the
///    body's own span. Adding an along-axis term to "make it more three-dimensional" is exactly
///    what produced the blotches.
/// 3. A SHAPE IS ONLY AS WIDE AS ITS SPAN **AT THAT HEIGHT**. A limb attaches to the core's
///    surface, so it must attach at the width the core actually has THERE. Clipping to a bounding
///    box instead is what grew whiskers on a boulder.
/// 4. A VERTICAL DIMENSION MUST NOT BE DERIVED FROM A HORIZONTAL ONE. Borough shipped an eaves
///    shadow a fifth of a wall deep and a roof crossing a facade diagonally, both because a
///    number scaled by half-WIDTH landed on something sized by HEIGHT — and the error was largest
///    exactly on the widest, lowest form, where the product could least afford it.

#macro ADV_TUBE_BANDS 11    // longitudinal shading strips across the core's width
#macro ADV_SPINE_N    18    // resampled points along a limb spine

/// The core's outline: a closed spindle, sampled from the SAME half-width function the limbs use
/// to find their attachment points. A limb can therefore never float off a body that is narrower
/// there than the limb thought.
function adv_core_outline(_plan, _n) {
    var _steps = is_undefined(_n) ? 30 : _n;
    var _pts = [];
    var _hw = _plan.core.w * 0.5;
    var _y0 = -_plan.core.h * 0.5;
    var _y1 =  _plan.core.h * 0.5;
    // Down the right flank...
    for (var _i = 0; _i <= _steps; _i++) {
        var _t = _i / _steps;
        var _y = lerp(_y0, _y1, _t);
        array_push(_pts, [ adv_core_halfwidth_at(_plan, _t) * _hw + adv_core_lean_at(_plan, _t), _y ]);
    }
    // ...and back up the left.
    for (var _i = _steps; _i >= 0; _i--) {
        var _t = _i / _steps;
        var _y = lerp(_y0, _y1, _t);
        array_push(_pts, [ -adv_core_halfwidth_at(_plan, _t) * _hw + adv_core_lean_at(_plan, _t), _y ]);
    }
    return _pts;
}

/// How far the core's centre line has shifted at station `_t`.
///
/// ⛔ A LEAN IS A GRADIENT AND EVERY DRAWN THING MUST READ IT. Wing CLAUDE.md records a corpus in
/// which the skeleton leaned properly while the drawn torso stood bolt upright, because only the
/// armature knew about the gradient — the result was a DETACHED HEAD floating beside a headless
/// smock, on the sheet whose entire job was to show the corpus off, through three baked galleries
/// and 164 green assertions. One function, every reader.
///
/// ⚠️ Vertical station in, horizontal offset out — the lean scales with core HEIGHT (law 4).
function adv_core_lean_at(_plan, _t) {
    var _u = clamp(_t, 0, 1);
    // Strongest at the crown end, zero at the base, so the boss leans rather than topples.
    return _plan.core.lean * _plan.core.h * 0.5 * power(1 - _u, 1.6);
}

/// The core as a shaded tube.
///
/// Each band is a longitudinal strip between two lateral positions, and both of its rails follow
/// the core's own half-width — so the strip is clipped to the body's span AT EVERY ROW by
/// construction rather than by a test that could be wrong (law 3).
function adv_core_parts(_plan, _phase) {
    var _parts = [];
    var _hw = _plan.core.w * 0.5;
    var _y0 = -_plan.core.h * 0.5;
    var _y1 =  _plan.core.h * 0.5;
    var _rows = 26;

    for (var _b = 0; _b < ADV_TUBE_BANDS; _b++) {
        var _u0 = -1 + (2 * _b / ADV_TUBE_BANDS);
        var _u1 = -1 + (2 * (_b + 1) / ADV_TUBE_BANDS);
        var _a = array_create(_rows + 1);
        var _c = array_create(_rows + 1);
        for (var _r = 0; _r <= _rows; _r++) {
            var _t  = _r / _rows;
            var _y  = lerp(_y0, _y1, _t);
            var _w  = adv_core_halfwidth_at(_plan, _t) * _hw;
            var _lx = adv_core_lean_at(_plan, _t);
            _a[_r] = [_lx + _u0 * _w, _y];
            _c[_r] = [_lx + _u1 * _w, _y];
        }
        array_push(_parts, adv_strip(_a, _c, adv_tube_role((_u0 + _u1) * 0.5)));
    }

    adv_append(_parts, adv_armour_parts(_plan, _phase));

    // A rim line, so the silhouette reads against a bright backdrop. A boss is recognised at a
    // glance and usually against sky or fire.
    array_push(_parts, adv_poly(adv_core_outline(_plan, 30), true, 0.012, "line"));
    return _parts;
}

/// The minimum vertical pitch a plate seam may be drawn at, as a fraction of core height.
///
/// ⚠️ THIS IS A LEGIBILITY BOUND, NOT A LEVEL-OF-DETAIL RULE, AND SAYING SO MATTERS. Wing CLAUDE.md
/// records `cht_wing_fit`'s vein reducer, whose condition could only fire below a size its own
/// cutoff already rejected - so it had never executed once in the product's life and returned SEVEN
/// veins at every size. This is a plain cap on the corpus's own declared counts and it does not
/// respond to drawn size, because parts here are built in unit space before any rect is known.
/// At the shipped corpus's widest count (crawler, 14 plates over 0.78 of the core) it binds at
/// exactly 14, i.e. it costs the corpus nothing today and stops a buyer authoring 40 plates from
/// getting the hatching Chitin shipped when nineteen shading bands landed on a 28-pixel chord.
#macro ADV_PLATE_MIN_PITCH 0.055

/// The armour plating.
///
/// ⛔ THIS FIELD HAD NO READER AT ALL. Every one of the fourteen plans authors
/// `armour: { plates, coverage, weight }` with hand-differentiated values - 3 to 14 plates,
/// coverage 0.22 to 0.94, weight 0.14 to 1.00 - and until this was written NOTHING in the package
/// drew a single one of them. Wing CLAUDE.md names the shape from Lanternbound: "a dead reader is
/// not a missing feature, it is an untested code path"; here it was a whole authored DIMENSION of
/// the corpus sitting unspent while the contact sheet told fourteen bosses apart by COLOUR.
///
/// A plate seam is a transverse curve whose every sample takes the core's OWN half-width at the
/// station that sample sits at, so it is clipped to the body at every point by construction and can
/// never overhang (law 3). It bows toward the tail in the middle, which is what an overlapping
/// shell edge does when seen from the front.
///
/// ⚠️ THE LIP IS `m4` AND THE SHADOW IS `m0` - THE CUT-EDGE RAMP, NOT THE SHELL RAMP. adv_hide's
/// own header fixes that convention: the twelve-stop ramp describes how a smooth SURFACE turns in
/// the light, and five hard bands across one is five stripes; the five-stop ramp is for a CUT EDGE,
/// which is exactly what the leading edge of a plate is. Wing CLAUDE.md also records a gradient
/// "improvement" that put an opaque white slab across two rooms, so the lit lip is a thin line in
/// the cut ramp's top stop rather than anything additive.
/// How far through its fight a boss at this phase is, 0 whole .. 1 exposed.
///
/// ⛔ `_phase` WAS A PARAMETER `adv_core_parts` AND `adv_crown_parts` BOTH TOOK AND NEITHER USED.
/// Only the limb solver read it, as a fold — so across the three phases a boss changed its POSE and
/// nothing else. The core, the crown, the plating and the palette were byte-identical, which makes
/// the listing's derived "42 bodies" fourteen bodies in three poses, and leaves the product's own
/// headline ("multi-phase bosses") with nothing to show. A parameter that every caller passes and no
/// body reads is the `armour` defect again, one file over.
function adv_phase_damage(_phase) {
    if (ADV_PHASES <= 1) return 0;
    return clamp(_phase / (ADV_PHASES - 1), 0, 1);
}

function adv_armour_parts(_plan, _phase) {
    var _parts = [];
    var _dmg = adv_phase_damage(is_undefined(_phase) ? ADV_PHASE_WHOLE : _phase);
    // A broken boss has SHED PLATES. Coverage retreats from the tail end, so the shell peels back
    // toward the crown and the bare body is exposed where the limbs do the work.
    // ⚠️ The plate COUNT is left alone and the coverage carries it: dropping the count instead would
    // re-space the surviving seams, so the same shell would appear to re-form at a coarser pitch
    // rather than to break. What is lost has to stay lost in the places it was.
    var _cov = clamp(_plan.armour.coverage * (1 - (_dmg * 0.55)), 0.05, 1.0);
    var _wt  = clamp(_plan.armour.weight, 0, 1);
    var _n   = clamp(_plan.armour.plates, 1, max(1, floor(_cov / ADV_PLATE_MIN_PITCH)));

    var _hw = _plan.core.w * 0.5;
    var _y0 = -_plan.core.h * 0.5;
    var _y1 =  _plan.core.h * 0.5;

    // A heavier shell carries a deeper lip. ⚠️ Bounded at BOTH ends: wing CLAUDE.md's Livery entry
    // records four physical details written as bare proportions, all correct going down and all
    // grotesque going up - a 112px cove read as damage on an 840px frame.
    var _lip = 0.005 + (_wt * 0.012);
    var _bow = 0.030 + (_wt * 0.022);
    var _m   = 12;

    // ⛔ A SEAM THAT REACHES THE SILHOUETTE IS A SEGMENT BOUNDARY. ONE THAT STOPS SHORT IS RELIEF.
    // The first version ran every seam edge to edge at |u| = 1, and the corpus came back as stacked
    // tyres - the golem in particular read as six rings on a spindle rather than as a plated body,
    // because a line crossing a silhouette from rim to rim is exactly how an insect abdomen or a
    // worm is drawn. Ending the seam inside the outline leaves the silhouette unbroken and the
    // plate reads as sitting ON the shell. Found by baking and looking; no ink, extent or
    // distinctness check can see it, because a seam is ink exactly where a seam belongs.
    var _span = 0.82;

    for (var _i = 0; _i < _n; _i++) {
        var _t = ((_i + 1) / _n) * _cov;
        var _seam = array_create(_m + 1);
        var _lit  = array_create(_m + 1);
        for (var _k = 0; _k <= _m; _k++) {
            var _u  = (-1 + (2 * _k / _m)) * _span;
            var _tl = clamp(_t + (_bow * (1 - (_u * _u))), 0, 1);
            var _w  = adv_core_halfwidth_at(_plan, _tl) * _hw;
            var _lx = adv_core_lean_at(_plan, _tl);
            var _y  = lerp(_y0, _y1, _tl);
            _seam[_k] = [_lx + (_u * _w), _y];
            // The lit lip sits just ABOVE the seam - it is the leading edge of the plate below the
            // shadow, so it is offset in y, not along the station.
            _lit[_k]  = [_lx + (_u * _w * 0.985), _y - (_lip * 1.25)];
        }
        array_push(_parts, adv_poly(_seam, false, _lip, "m0"));
        array_push(_parts, adv_poly(_lit,  false, _lip * 0.62, "m4"));
    }
    return _parts;
}

/// How many plate seams a plan actually DRAWS, after the pitch cap.
///
/// ⛔ DERIVED, AND IT EXISTS SO THE CAP HAS A READER THAT CAN DISAGREE WITH THE DECLARATION. Wing
/// CLAUDE.md, Liege: "this is the fourth time this suite's answer to a wrong declared fact has been
/// give it a reader that can disagree with it." A silent cap is the Lexicon defect - most of a
/// corpus quietly drawn smaller than its script asked for, with nothing in the output saying so.
function adv_armour_drawn_count(_plan, _phase) {
    var _dmg = adv_phase_damage(is_undefined(_phase) ? ADV_PHASE_WHOLE : _phase);
    var _cov = clamp(_plan.armour.coverage * (1 - (_dmg * 0.55)), 0.05, 1.0);
    return clamp(_plan.armour.plates, 1, max(1, floor(_cov / ADV_PLATE_MIN_PITCH)));
}

/// Resample a solved joint chain into a smooth spine.
///
/// ⚠️ A quadratic through each joint triple, not a polyline: the ribbon built on this is ONE mass
/// (law 1), and a mass built over hard corners shows a lit edge at every corner.
function adv_limb_spine(_plan, _limb, _side, _phase, _wind) {
    var _j = adv_limb_joints(_plan, _limb, _side, _phase, _wind);
    var _n = array_length(_j);
    if (_n < 3) {
        // A one-segment limb is already straight; just densify it so the ribbon has points to work
        // with. ⚠️ Not a special case in the DRAWING - only in the sampling.
        var _o = array_create(ADV_SPINE_N);
        for (var _i = 0; _i < ADV_SPINE_N; _i++) {
            var _t = _i / (ADV_SPINE_N - 1);
            _o[_i] = [lerp(_j[0][0], _j[_n - 1][0], _t), lerp(_j[0][1], _j[_n - 1][1], _t)];
        }
        return _o;
    }
    var _out = [];
    var _per = max(2, floor(ADV_SPINE_N / (_n - 1)));
    for (var _k = 0; _k < _n - 1; _k++) {
        var _p0 = _j[_k];
        var _p2 = _j[_k + 1];
        // Control point pulled off the midpoint toward the previous joint's direction, which is
        // what rounds the corner rather than cutting it.
        var _prev = _j[max(0, _k - 1)];
        var _mx = (_p0[0] + _p2[0]) * 0.5;
        var _my = (_p0[1] + _p2[1]) * 0.5;
        var _c  = [_mx + (_p0[0] - _prev[0]) * 0.18, _my + (_p0[1] - _prev[1]) * 0.18];
        var _seg = adv_qbez(_p0, _c, _p2, _per);
        for (var _i = (_k == 0 ? 0 : 1); _i < array_length(_seg); _i++) array_push(_out, _seg[_i]);
    }
    return _out;
}

/// A limb as ONE continuous mass, plus its terminal.
function adv_limb_parts(_plan, _limb, _side, _phase, _wind) {
    var _spine = adv_limb_spine(_plan, _limb, _side, _phase, _wind);
    var _n = array_length(_spine);

    // Root thickness scales with the CORE's width (a thick body carries thick limbs) and the
    // limb's own length (a long thin limb is not a short fat one).
    var _root = _plan.core.w * 0.16 * (0.7 + (0.3 * _plan.mass));
    var _tip  = _root * clamp(_limb.taper, 0.08, 1.0);

    var _w = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _t = _i / max(1, _n - 1);
        // Slight swell just past the root reads as musculature rather than as a cone.
        var _swell = 1 + (0.18 * sin(pi * clamp(_t * 1.6, 0, 1)));
        _w[_i] = lerp(_root, _tip, power(_t, 0.85)) * _swell;
    }

    // ⛔ A LIMB IS A TUBE, AND IT WAS BEING DRAWN AS A FLAT SAUSAGE. The first version was ONE
    // ribbon at a single constant role plus one darker offset rail — so a limb had a colour and a
    // stripe, and no cross-section at all. adv_hide's own header states the model the CORE uses and
    // the reason for it: an animal seen from the side is a half-cylinder, shaded from the LATERAL
    // coordinate alone, as longitudinal strips. The body had eleven of those bands. The limbs, which
    // are most of the silhouette on nine of the fourteen plans, had none.
    //
    // ⚠️ THE LAMP IS FIXED, SO THE LATERAL TERM CANNOT BE THE PARAMETRIC ONE. The core's lateral
    // axis is screen-x and never moves; a limb's rotates as it swings, so lighting purely by the
    // band index would carry the highlight around with the limb and a raised arm would be lit from
    // underneath. `_lam` projects the limb's own tangent against the lamp (up and to the left) and
    // is what decides which flank is lit — and it correctly goes to ZERO for a limb running along
    // the lamp direction, where both flanks really are lit the same.
    var _parts = [];
    var _bands = 7;

    var _tx = _spine[_n - 1][0] - _spine[0][0];
    var _ty = _spine[_n - 1][1] - _spine[0][1];
    var _tl = max(0.0001, point_distance(0, 0, _tx, _ty));
    var _lam = clamp(((_ty / _tl) - (_tx / _tl)) * 1.2, -1, 1);

    for (var _b = 0; _b < _bands; _b++) {
        var _u0 = -1 + (2 * _b / _bands);
        var _u1 = -1 + (2 * (_b + 1) / _bands);
        array_push(_parts, adv_strip(
            adv_limb_rail(_spine, _w, _u0),
            adv_limb_rail(_spine, _w, _u1),
            adv_tube_role(-_lam * (_u0 + _u1) * 0.5)));
    }

    // A rim, for the same reason the core has one: a boss is read at a glance and usually against
    // sky or fire, and on most of this corpus the limbs ARE the silhouette.
    var _rimA = adv_limb_rail(_spine, _w, 1);
    var _rimB = adv_limb_rail(_spine, _w, -1);
    var _rim = [];
    for (var _i = 0; _i < _n; _i++) array_push(_rim, _rimA[_i]);
    for (var _i = _n - 1; _i >= 0; _i--) array_push(_rim, _rimB[_i]);
    array_push(_parts, adv_poly(_rim, true, 0.008, "line"));

    adv_append(_parts, adv_terminal_parts(_limb, _spine, _tip, _side));
    return _parts;
}

/// The rail at lateral fraction `_u` across a limb: -1 at one flank, 0 on the spine, +1 at the other.
///
/// ⚠️ IT REPEATS adv_var_ribbon's PERPENDICULAR DELIBERATELY, rather than calling adv_offset_pts.
/// adv_offset_pts takes ONE distance for the whole polyline, and a limb's half-width varies per
/// point — an offset built from a single number would drift off the outline exactly where the limb
/// tapers, which is the tip, which is where a player is looking. Sharing the tangent computation is
/// what guarantees a band edge and the limb's own outline agree at every point.
function adv_limb_rail(_spine, _w, _u) {
    var _n = array_length(_spine);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _spine[max(0, _i - 1)], _q = _spine[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        var _d = _u * _w[_i];
        _out[_i] = [_spine[_i][0] - (_dy * _d), _spine[_i][1] + (_dx * _d)];
    }
    return _out;
}

/// The terminal form — the thing a player actually reads, and the thing that decides the shape of
/// the telegraph (see adv_tell_kind). Eight forms, all built from the spine's own direction so a
/// terminal always points where its limb points.
function adv_terminal_parts(_limb, _spine, _tip, _side) {
    var _n = array_length(_spine);
    var _p = _spine[_n - 1];
    var _q = _spine[max(0, _n - 3)];
    var _ang = arctan2(_p[1] - _q[1], _p[0] - _q[0]);
    var _r = max(_tip, 0.012);
    var _parts = [];

    switch (_limb.term) {
        case ADV_TERM_CLAW:
        case ADV_TERM_TALON: {
            var _count = (_limb.term == ADV_TERM_CLAW) ? 3 : 1;
            for (var _i = 0; _i < _count; _i++) {
                var _spread = (_count == 1) ? 0 : ((_i / (_count - 1)) - 0.5) * 0.9;
                var _a = _ang + _spread;
                var _mid = [_p[0] + cos(_a) * _r * 2.0, _p[1] + sin(_a) * _r * 2.0];
                var _end = [_p[0] + cos(_a + 0.7) * _r * 3.2, _p[1] + sin(_a + 0.7) * _r * 3.2];
                var _cv = adv_qbez(_p, _mid, _end, 8);
                array_push(_parts, adv_taper_ribbon(_cv, _r * 0.7, _r * 0.06, "m1"));
            }
        } break;

        case ADV_TERM_BLADE: {
            var _end = [_p[0] + cos(_ang) * _r * 6.0, _p[1] + sin(_ang) * _r * 6.0];
            var _cv = [_p, [_p[0] + cos(_ang) * _r * 3.0, _p[1] + sin(_ang) * _r * 3.0], _end];
            array_push(_parts, adv_taper_ribbon(_cv, _r * 1.15, _r * 0.05, "m4"));
            array_push(_parts, adv_poly(_cv, false, _r * 0.16, "line"));
        } break;

        case ADV_TERM_MAW: {
            // Two converging jaws. ⚠️ The gap between them IS the read, so they are drawn as two
            // masses with clear air between, never as one blob with a line across it.
            for (var _s2 = -1; _s2 <= 1; _s2 += 2) {
                var _a = _ang + (_s2 * 0.42);
                var _end = [_p[0] + cos(_a) * _r * 3.4, _p[1] + sin(_a) * _r * 3.4];
                var _cv = adv_qbez(_p, [_p[0] + cos(_a) * _r * 1.8, _p[1] + sin(_a) * _r * 1.8], _end, 6);
                array_push(_parts, adv_taper_ribbon(_cv, _r * 1.0, _r * 0.10, "m2"));
                // Teeth, as short spikes off the inner edge.
                for (var _t2 = 1; _t2 <= 3; _t2++) {
                    var _u2 = _t2 / 4;
                    var _bx = lerp(_p[0], _end[0], _u2);
                    var _by = lerp(_p[1], _end[1], _u2);
                    var _ta = _a - (_s2 * 1.4);
                    array_push(_parts, adv_poly(
                        [[_bx, _by], [_bx + cos(_ta) * _r * 0.8, _by + sin(_ta) * _r * 0.8]],
                        false, _r * 0.22, "bright"));
                }
            }
        } break;

        case ADV_TERM_STINGER: {
            var _end = [_p[0] + cos(_ang + 0.5) * _r * 5.0, _p[1] + sin(_ang + 0.5) * _r * 5.0];
            var _cv = adv_qbez(_p, [_p[0] + cos(_ang) * _r * 2.6, _p[1] + sin(_ang) * _r * 2.6], _end, 9);
            array_push(_parts, adv_taper_ribbon(_cv, _r * 0.95, _r * 0.03, "deep"));
        } break;

        case ADV_TERM_FIST: {
            array_push(_parts, adv_fill(adv_ellipse_pts(
                _p[0] + cos(_ang) * _r * 0.9, _p[1] + sin(_ang) * _r * 0.9,
                _r * 1.9, _r * 1.7, 16), "m3"));
            // Knuckles: a row of small domes across the front, so the mass reads as a hand and not
            // as a ball.
            for (var _k = -1; _k <= 1; _k++) {
                var _ka = _ang + (_k * 0.55);
                array_push(_parts, adv_dot(_p[0] + cos(_ka) * _r * 2.0,
                                           _p[1] + sin(_ka) * _r * 2.0, _r * 0.52, "m4"));
            }
        } break;

        case ADV_TERM_HOOF: {
            var _c2 = [_p[0] + cos(_ang) * _r * 1.1, _p[1] + sin(_ang) * _r * 1.1];
            array_push(_parts, adv_fill(adv_ellipse_pts(_c2[0], _c2[1], _r * 1.7, _r * 1.2, 14), "m1"));
            array_push(_parts, adv_poly(adv_ellipse_pts(_c2[0], _c2[1], _r * 1.7, _r * 1.2, 14),
                true, _r * 0.18, "line"));
        } break;

        case ADV_TERM_FIN: {
            // A fan of rays with a membrane behind them.
            var _rays = 5;
            var _outer = [];
            for (var _i = 0; _i <= _rays; _i++) {
                var _a = _ang + (((_i / _rays) - 0.5) * 1.5);
                array_push(_outer, [_p[0] + cos(_a) * _r * 5.5, _p[1] + sin(_a) * _r * 5.5]);
            }
            var _mem = [_p];
            for (var _i = 0; _i < array_length(_outer); _i++) array_push(_mem, _outer[_i]);
            array_push(_parts, adv_fill(_mem, "s3"));
            for (var _i = 0; _i < array_length(_outer); _i++) {
                array_push(_parts, adv_poly([_p, _outer[_i]], false, _r * 0.28, "m2"));
            }
        } break;
    }
    return _parts;
}

/// ============================================================================================
/// THE CROWN FORM FAMILY. Eight heads.
/// ============================================================================================
/// ⛔ THE SAME MODEL DEFECT THE CORE HAD, ONE LEVEL UP, AND IT SURVIVED THE CORE'S FIX. The first
/// version of `adv_crown_parts` drew ONE shape - an ellipse, a rim, and a dark/bright dot - for
/// every plan in the corpus. `crown.count` and `crown.sunken` varied how MANY and how DEEP, and
/// nothing varied WHAT. So once the fourteen bodies had genuinely different silhouettes, the sheet
/// still showed the identical donut eye on the colossus, the golem, the ogre, the titanid, the
/// wyrm, the hollow, the seraph and the sentinel - and a head is the first thing a player reads.
///
/// The test is the one wing CLAUDE.md prescribes and it is cheap: name the feature that makes the
/// subject recognisable, then ask whether the function can express it AT ALL. A single ellipse
/// cannot express a horn, a jaw, a crest or a hood at any parameter value.
///
/// ⚠️ THE EYE STAYS A PAIR IN EVERY FORM. `ink` alone cannot express a fixed internal order and
/// resolves PALE on a mid-dark hide - wing CLAUDE.md records a whole corpus of ocelli coming out
/// pale-on-red for exactly that reason. Dark rim, bright centre, from the ramp's own two ends.
#macro ADV_CROWN_OCULUS   0
#macro ADV_CROWN_HORNED   1
#macro ADV_CROWN_CLUSTER  2
#macro ADV_CROWN_MAW      3
#macro ADV_CROWN_CREST    4
#macro ADV_CROWN_FACETED  5
#macro ADV_CROWN_HOODED   6
#macro ADV_CROWN_ANTLERED 7

/// Index-parallel with the switch in `adv_crown_head_parts`. adv_selftest asserts that, because a
/// name array that outruns its switch is how a listing comes to quote forms the package lacks.
function adv_crown_form_names() {
    return ["oculus", "horned", "cluster", "maw", "crest", "faceted", "hooded", "antlered"];
}

function adv_crown_form_count() { return array_length(adv_crown_form_names()); }

/// ONE head, centred at (_hx, _hy) with radius _r.
///
/// ⚠️ Every form draws its own skull mass rather than sharing one and decorating it: a hood and a
/// jaw are not an ellipse with something added, and this wing's Vestige entry records ten devices
/// reading as the wrong object because a shape was assembled from a chain of generic masses.
function adv_crown_head_parts(_hx, _hy, _r, _form) {
    var _p = [];
    var _eye = _r * 0.30;

    switch (_form) {
        case ADV_CROWN_HORNED: {
            array_push(_p, adv_fill(adv_ellipse_pts(_hx, _hy, _r * 0.92, _r * 0.80, 16), "s7"));
            array_push(_p, adv_poly(adv_ellipse_pts(_hx, _hy, _r * 0.92, _r * 0.80, 16), true, _r * 0.09, "line"));
            for (var _s = -1; _s <= 1; _s += 2) {
                var _b = [_hx + (_s * _r * 0.62), _hy - (_r * 0.46)];
                var _c = [_hx + (_s * _r * 1.50), _hy - (_r * 1.25)];
                var _e = [_hx + (_s * _r * 1.30), _hy - (_r * 2.15)];
                array_push(_p, adv_taper_ribbon(adv_qbez(_b, _c, _e, 8), _r * 0.34, _r * 0.05, "m1"));
            }
            for (var _s2 = -1; _s2 <= 1; _s2 += 2) {
                array_push(_p, adv_dot(_hx + (_s2 * _r * 0.38), _hy + (_r * 0.06), _eye * 0.80, "deep"));
                array_push(_p, adv_dot(_hx + (_s2 * _r * 0.38), _hy + (_r * 0.06), _eye * 0.38, "bright"));
            }
        } break;

        case ADV_CROWN_CLUSTER: {
            array_push(_p, adv_fill(adv_ellipse_pts(_hx, _hy, _r * 1.05, _r * 0.72, 18), "s7"));
            array_push(_p, adv_poly(adv_ellipse_pts(_hx, _hy, _r * 1.05, _r * 0.72, 18), true, _r * 0.09, "line"));
            // Two rows of small eyes. The COUNT is what a cluster is; one big eye with friends is
            // not a cluster, it is an oculus with decoration.
            for (var _row = 0; _row < 2; _row++) {
                var _ry = _hy - (_r * 0.20) + (_row * _r * 0.36);
                var _cnt = (_row == 0) ? 3 : 2;
                for (var _k = 0; _k < _cnt; _k++) {
                    var _ex = _hx + ((((_k + 0.5) / _cnt) - 0.5) * _r * 1.30);
                    array_push(_p, adv_dot(_ex, _ry, _eye * 0.52, "deep"));
                    array_push(_p, adv_dot(_ex, _ry, _eye * 0.24, "bright"));
                }
            }
        } break;

        case ADV_CROWN_MAW: {
            // Mostly jaw. The upper skull is a wedge and the GAP is the read, so the two jaws are
            // separate masses with air between them, never one blob with a line across it.
            var _up = [[_hx - _r * 1.00, _hy - _r * 0.20], [_hx + _r * 1.00, _hy - _r * 0.20],
                       [_hx + _r * 0.70, _hy - _r * 0.92], [_hx - _r * 0.70, _hy - _r * 0.92]];
            array_push(_p, adv_fill(_up, "s7"));
            array_push(_p, adv_poly(_up, true, _r * 0.09, "line"));
            var _lo = [[_hx - _r * 0.92, _hy + _r * 0.10], [_hx + _r * 0.92, _hy + _r * 0.10],
                       [_hx + _r * 0.58, _hy + _r * 0.78], [_hx - _r * 0.58, _hy + _r * 0.78]];
            array_push(_p, adv_fill(_lo, "s5"));
            array_push(_p, adv_poly(_lo, true, _r * 0.09, "line"));
            for (var _t = 0; _t < 5; _t++) {
                var _tx = _hx + ((((_t + 0.5) / 5) - 0.5) * _r * 1.70);
                array_push(_p, adv_fill([[_tx - _r * 0.12, _hy - _r * 0.20],
                                         [_tx + _r * 0.12, _hy - _r * 0.20],
                                         [_tx, _hy + _r * 0.12]], "bright"));
            }
            for (var _s3 = -1; _s3 <= 1; _s3 += 2) {
                array_push(_p, adv_dot(_hx + (_s3 * _r * 0.46), _hy - (_r * 0.58), _eye * 0.60, "deep"));
                array_push(_p, adv_dot(_hx + (_s3 * _r * 0.46), _hy - (_r * 0.58), _eye * 0.26, "bright"));
            }
        } break;

        case ADV_CROWN_CREST: {
            array_push(_p, adv_fill(adv_ellipse_pts(_hx, _hy, _r * 0.80, _r * 0.86, 16), "s7"));
            array_push(_p, adv_poly(adv_ellipse_pts(_hx, _hy, _r * 0.80, _r * 0.86, 16), true, _r * 0.09, "line"));
            var _rays = 5;
            var _outer = [];
            for (var _i2 = 0; _i2 <= _rays; _i2++) {
                var _a = -pi * 0.5 + ((((_i2 / _rays) - 0.5)) * 1.9);
                array_push(_outer, [_hx + cos(_a) * _r * 2.0, _hy + sin(_a) * _r * 2.0]);
            }
            var _mem = [[_hx, _hy]];
            for (var _i3 = 0; _i3 < array_length(_outer); _i3++) array_push(_mem, _outer[_i3]);
            array_push(_p, adv_fill(_mem, "s3"));
            for (var _i4 = 0; _i4 < array_length(_outer); _i4++) {
                array_push(_p, adv_poly([[_hx, _hy], _outer[_i4]], false, _r * 0.13, "m2"));
            }
            array_push(_p, adv_dot(_hx, _hy + _r * 0.10, _eye * 0.90, "deep"));
            array_push(_p, adv_dot(_hx, _hy + _r * 0.10, _eye * 0.44, "bright"));
        } break;

        case ADV_CROWN_FACETED: {
            var _hex = [];
            for (var _i5 = 0; _i5 < 6; _i5++) {
                var _a2 = (_i5 / 6) * 2 * pi + 0.52;
                array_push(_hex, [_hx + cos(_a2) * _r * 0.98, _hy + sin(_a2) * _r * 0.92]);
            }
            array_push(_p, adv_fill(_hex, "s8"));
            array_push(_p, adv_poly(_hex, true, _r * 0.10, "line"));
            // Facet lines from the centre, which is what makes it read as cut rather than round.
            for (var _i6 = 0; _i6 < 6; _i6 += 2) {
                array_push(_p, adv_poly([[_hx, _hy], _hex[_i6]], false, _r * 0.07, "m1"));
            }
            array_push(_p, adv_fill([[_hx - _r * 0.52, _hy], [_hx + _r * 0.52, _hy - _r * 0.14],
                                     [_hx + _r * 0.52, _hy + _r * 0.14]], "deep"));
            array_push(_p, adv_dot(_hx + _r * 0.20, _hy, _eye * 0.30, "bright"));
        } break;

        case ADV_CROWN_HOODED: {
            // A broad hood behind a small face. The hood is the silhouette; the face is the detail.
            var _hood = [];
            for (var _i7 = 0; _i7 <= 14; _i7++) {
                var _u = _i7 / 14;
                var _a3 = pi * (1.0 + _u);
                array_push(_hood, [_hx + cos(_a3) * _r * 1.55, _hy + sin(_a3) * _r * 1.35]);
            }
            array_push(_hood, [_hx + _r * 0.55, _hy + _r * 0.45]);
            array_push(_hood, [_hx - _r * 0.55, _hy + _r * 0.45]);
            array_push(_p, adv_fill(_hood, "s4"));
            array_push(_p, adv_poly(_hood, true, _r * 0.09, "line"));
            array_push(_p, adv_fill(adv_ellipse_pts(_hx, _hy + _r * 0.10, _r * 0.52, _r * 0.60, 14), "s8"));
            for (var _s4 = -1; _s4 <= 1; _s4 += 2) {
                array_push(_p, adv_dot(_hx + (_s4 * _r * 0.24), _hy + (_r * 0.02), _eye * 0.52, "deep"));
                array_push(_p, adv_dot(_hx + (_s4 * _r * 0.24), _hy + (_r * 0.02), _eye * 0.24, "bright"));
            }
        } break;

        case ADV_CROWN_ANTLERED: {
            array_push(_p, adv_fill(adv_ellipse_pts(_hx, _hy, _r * 0.74, _r * 0.88, 16), "s7"));
            array_push(_p, adv_poly(adv_ellipse_pts(_hx, _hy, _r * 0.74, _r * 0.88, 16), true, _r * 0.09, "line"));
            for (var _s5 = -1; _s5 <= 1; _s5 += 2) {
                var _b2 = [_hx + (_s5 * _r * 0.34), _hy - (_r * 0.62)];
                var _e2 = [_hx + (_s5 * _r * 1.05), _hy - (_r * 2.30)];
                var _beam = adv_qbez(_b2, [_hx + (_s5 * _r * 1.10), _hy - (_r * 1.30)], _e2, 9);
                array_push(_p, adv_taper_ribbon(_beam, _r * 0.20, _r * 0.05, "m1"));
                // Tines off the beam - a branch is what separates an antler from a horn.
                for (var _t2 = 1; _t2 <= 2; _t2++) {
                    var _bp = _beam[floor(array_length(_beam) * (0.30 + (_t2 * 0.22)))];
                    var _tp = [_bp[0] + (_s5 * _r * 0.62), _bp[1] - (_r * 0.66)];
                    array_push(_p, adv_taper_ribbon([_bp, [(_bp[0] + _tp[0]) * 0.5, _bp[1] - _r * 0.42], _tp],
                        _r * 0.13, _r * 0.04, "m1"));
                }
            }
            array_push(_p, adv_dot(_hx, _hy + _r * 0.14, _eye * 0.76, "deep"));
            array_push(_p, adv_dot(_hx, _hy + _r * 0.14, _eye * 0.36, "bright"));
        } break;

        default: {   // ADV_CROWN_OCULUS - one proud eye, and the sentinel's declared identity.
            array_push(_p, adv_fill(adv_ellipse_pts(_hx, _hy, _r, _r * 0.86, 18), "s7"));
            array_push(_p, adv_poly(adv_ellipse_pts(_hx, _hy, _r, _r * 0.86, 18), true, _r * 0.10, "line"));
            array_push(_p, adv_dot(_hx, _hy - _r * 0.10, _r * 0.42, "deep"));
            array_push(_p, adv_dot(_hx, _hy - _r * 0.10, _r * 0.22, "bright"));
        } break;
    }
    return _p;
}

/// Heads. `crown.count` of them, `sunken` deciding how far they sit into the mass — a sentinel's
/// single eye stands proud, a broodmother's cluster is set deep — and `crown.form` deciding WHAT
/// each one is.
function adv_crown_parts(_plan, _phase) {
    var _parts = [];
    var _hw = _plan.core.w * 0.5;
    var _cy = -_plan.core.h * 0.5;
    var _lx = adv_core_lean_at(_plan, 0);
    var _r  = _plan.crown.scale * _plan.core.h * 0.5;
    var _n  = max(1, _plan.crown.count);
    var _f  = clamp(_plan.crown.form, 0, adv_crown_form_count() - 1);

    for (var _i = 0; _i < _n; _i++) {
        var _spread = (_n == 1) ? 0 : (((_i / (_n - 1)) - 0.5) * _hw * 1.5);
        adv_append(_parts, adv_crown_head_parts(_lx + _spread,
            _cy + (_r * _plan.crown.sunken), _r, _f));
    }
    return _parts;
}

/// The whole boss, in the unit box.
///
/// ⛔ PAINTER'S ORDER IS LOAD-BEARING. Far-side limbs go down FIRST, then the core, then near-side
/// limbs, then the crown. A limb drawn over the core it hangs behind reads as growing out of the
/// front of the chest; and this wing has recorded a glow drawn smallest-first flattening to a
/// uniform donut, and a flash drawn OVER the thing it illuminated.
function adv_body_parts(_plan, _phase, _wind) {
    var _parts = [];

    // Far side (drawn behind the core).
    for (var _j = 0; _j < array_length(_plan.limbs); _j++) {
        adv_append(_parts, adv_limb_parts(_plan, _plan.limbs[_j], 1, _phase, _wind));
    }
    adv_append(_parts, adv_core_parts(_plan, _phase));
    // Near side.
    for (var _j = 0; _j < array_length(_plan.limbs); _j++) {
        adv_append(_parts, adv_limb_parts(_plan, _plan.limbs[_j], -1, _phase, _wind));
    }
    adv_append(_parts, adv_crown_parts(_plan, _phase));
    return _parts;
}

/// How many parts a plan draws. Used by the suite to prove a body is not empty, and by the store
/// copy — DERIVED, never typed.
function adv_body_part_count(_plan, _phase, _wind) {
    return array_length(adv_body_parts(_plan, _phase, _wind));
}
