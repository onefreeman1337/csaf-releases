/// adv_hide.gml — MATERIALS. What a boss is made of, and the ramps its surfaces are lit through.
///
/// ============================================================================================
/// TWO RAMPS, ON PURPOSE, AND MIXING THEM UP IS A KNOWN DEFECT IN THIS WING
/// ============================================================================================
///   m0..m4  - FIVE discrete stops. Correct for a CUT EDGE: a bevel, a chamfer, a plate lip, the
///             wall of a socket. Five hard bands is what a struck surface photographs like, and
///             this catalogue's relief layer is built on it.
///   s0..s11 - TWELVE stops read as a CONTINUOUS ramp. Correct for a SHELL: a carapace, a flank,
///             a limb. Wing CLAUDE.md is explicit that the five-stop ramp on a smooth surface a
///             third of the picture wide "is five stripes", and that a long body is a TUBE, not a
///             dome - curved ACROSS its width, nearly flat ALONG its length, which is why a
///             photograph of one has a bright side, a dark side and no highlight at either end.
///
/// ⛔ AND `ink` IS NOT `m0`. On a light material every ramp stop is light: a caption set in a pale
/// material's darkest stop is not dark, it is merely less pale, and this wing shipped an invisible
/// caption on parchment that way. `ink` is defined RELATIVE TO the material's own ground with an
/// asserted contrast floor, and anything WRITTEN on a surface goes there.
///
/// ⚠️ AND A STRUCTURE NEEDS A PAIR, NOT AN INK. An eye, a socket or a glowing vent has a fixed
/// internal order (dark rim, bright centre) which `ink` alone cannot express - on a mid-dark hide
/// `ink` resolves PALE, so all three rings of a Chitin ocellus came out pale on red. Use `m0` and
/// `ink` together as a dark/bright PAIR.
///
/// ⛔ RAMPS SLIDE, THEY NEVER CLAMP. A material near the top of the lightness range whose ramp is
/// clamped puts its two brightest stops on the SAME colour, and a bevel whose two lit walls are
/// identical reads as a flat fill with a line round it. Slide the whole ramp to fit.

#macro ADV_RAMP_STOPS 12

/// A material. `L` is the ground lightness, `C` the chroma, `h` the hue in degrees.
///
/// ⚠️ TUNE ON THE PALEST AND MOST NEUTRAL MATERIAL, NEVER THE VIVID ONE. Wing CLAUDE.md records a
/// browning model tuned entirely on beef - the one substance that starts red AND chromatic, and
/// therefore the only one on which an additive-hue multiplicative-chroma model looks perfect -
/// while dough ran cream to GREY and poultry to swamp-green. Bone and iron are this corpus's
/// pale/neutral pair; check any ramp change against those two first.
function adv_hides() {
    static _h = undefined;
    if (!is_undefined(_h)) return _h;
    _h = [
        { id: "stone",   name: "Stone",    L: 0.52, C: 0.018, h:  74, rough: 0.85 },
        { id: "iron",    name: "Iron",     L: 0.44, C: 0.010, h: 250, rough: 0.42 },
        { id: "bronze",  name: "Bronze",   L: 0.58, C: 0.086, h:  78, rough: 0.36 },
        // ⚠️ Named `carapace`, not by the donor product's name. The donor-name guard in
        // make_project.js flagged the original spelling — correctly. It is a real material word
        // and the temptation is to exempt it, but a buyer opening this file in a BOSS package and
        // reading another product's name has no way to know which it is, and every survivor wing
        // CLAUDE.md records shipping (a licence headed with a third product's name on five live
        // products, "THIRD-PARTY NOTICES - Pliant" on nine of ten) looked equally defensible at
        // the time it was written.
        { id: "carapace", name: "Carapace", L: 0.34, C: 0.058, h:  32, rough: 0.28 },
        { id: "bone",    name: "Bone",     L: 0.82, C: 0.030, h:  92, rough: 0.50 },
        { id: "hide",    name: "Hide",     L: 0.40, C: 0.044, h:  46, rough: 0.70 },
        { id: "obsidian",name: "Obsidian", L: 0.20, C: 0.028, h: 292, rough: 0.18 },
        { id: "verdigris",name:"Verdigris",L: 0.60, C: 0.072, h: 168, rough: 0.62 },
        { id: "ember",   name: "Ember",    L: 0.46, C: 0.130, h:  38, rough: 0.55 },
        { id: "frost",   name: "Frost",    L: 0.76, C: 0.048, h: 224, rough: 0.30 }
    ];
    return _h;
}

function adv_hide_count() { return array_length(adv_hides()); }

/// Build a palette for a material.
///
/// ⛔ THE RAMP SLIDES TO FIT RATHER THAN CLAMPING AT EITHER END. `_lo`/`_hi` are computed from the
/// ground and then SHIFTED as a pair if either runs past the legal range, so the spacing between
/// adjacent stops is preserved. A clamped ramp silently collapses its top two stops into one
/// colour, and the worst adjacent gap becomes exactly 0.000.
function adv_palette_for(_hide, _damage) {
    var _dmg = is_undefined(_damage) ? 0 : clamp(_damage, 0, 1);

    // Damage dulls and darkens: a broken boss is not a repainted one.
    var _L = _hide.L * (1 - (_dmg * 0.18));
    var _C = _hide.C * (1 - (_dmg * 0.42));

    var _span = 0.30 + (_hide.rough * 0.10);
    var _lo = _L - (_span * 0.5);
    var _hi = _L + (_span * 0.5);
    // Slide, never clamp.
    if (_lo < 0.06) { _hi += (0.06 - _lo); _lo = 0.06; }
    if (_hi > 0.97) { _lo -= (_hi - 0.97); _hi = 0.97; }
    _lo = max(0.04, _lo);

    var _pal = {};

    // The twelve-stop shell ramp.
    for (var _i = 0; _i < ADV_RAMP_STOPS; _i++) {
        var _t = _i / (ADV_RAMP_STOPS - 1);
        variable_struct_set(_pal, "s" + string(_i),
            adv_oklch(lerp(_lo, _hi, _t), _C, _hide.h));
    }
    // The five-stop cut-edge ramp, sampled from the SAME endpoints so a bevel cut into a shell
    // cannot disagree with the shell it is cut into.
    for (var _i = 0; _i < 5; _i++) {
        var _t = _i / 4;
        variable_struct_set(_pal, "m" + string(_i),
            adv_oklch(lerp(_lo, _hi, _t), _C, _hide.h));
    }

    _pal.ground = adv_oklch(_L, _C * 0.7, _hide.h);
    _pal.line   = adv_oklch(max(0.05, _lo - 0.06), _C * 0.8, _hide.h);

    // ⛔ `ink` IS DEFINED AGAINST THE GROUND, NOT TAKEN FROM THE RAMP. On a pale hide (bone at
    // L 0.82) the ramp's darkest stop is still pale, so text set in it is invisible. This flips to
    // the far side of the ground and is asserted for contrast by adv_selftest.
    _pal.ink = (_L > 0.55) ? adv_oklch(max(0.06, _L - 0.46), _C * 0.5, _hide.h)
                           : adv_oklch(min(0.97, _L + 0.44), _C * 0.4, _hide.h);

    // The dark/bright PAIR a structure needs. See the header: `ink` alone cannot express a fixed
    // internal order, because on a mid-dark hide it resolves pale.
    _pal.deep  = adv_oklch(max(0.04, _lo - 0.03), _C, _hide.h);
    _pal.bright = adv_oklch(min(0.98, _hi + 0.03), _C * 0.6, _hide.h);

    // Warning colour for a telegraph. Deliberately NOT derived from the hide: a danger arc that
    // changed colour with the boss's material would be unreadable on the one material closest to
    // it, which is the material that boss is made of.
    //
    // ⚠️ CHROMA RAISED 0.170 -> 0.205 AFTER LOOKING AT A BAKE. At 0.170, over a dark ground and
    // behind a body, the arc resolved to a soft SALMON that sat in the same register as the hides -
    // so it read as a membrane rather than as an instruction. This is a UI colour and it is allowed
    // to be louder than anything grown.
    //
    // ⚠️ THIS COMMENT USED TO END "the structural half is the hatch in adv_bk_draw_tell, and the
    // hatch is the half that matters" - and the hatch was DELETED two bakes later, because radial
    // hatching about a joint is a wing's most recognisable feature rather than its opposite. The
    // structural half now lives in `adv_tell_draw`, which no longer hatches at all. A cross-file
    // pointer to a rationale is a pointer that goes stale when the rationale loses an argument.
    _pal.tell = adv_oklch(0.56, 0.205, 28);
    _pal.tellcore = adv_oklch(0.78, 0.180, 52);

    return _pal;
}

/// Continuous shell shading: map a lateral coordinate to a ramp role.
///
/// ⛔ SHADE FROM THE LATERAL COORDINATE ALONE. Wing CLAUDE.md, from Chitin: adding an along-axis
/// term "to make it more three-dimensional" is what produced blotches - scaling a long waisted
/// shape about ONE centroid is not a dome, it is a collapse toward the middle. An animal seen from
/// above is a half-cylinder whose axis runs head to tail: curved across its width, nearly flat
/// along its length, and with NO highlight at either end.
///
/// `_u` is -1 at one flank, 0 at the spine, +1 at the other flank.
function adv_tube_role(_u) {
    // The lamp sits up and to the left, so the lit flank is the negative side.
    var _k = 0.5 - (clamp(_u, -1, 1) * 0.5);
    var _i = clamp(floor(_k * (ADV_RAMP_STOPS - 1) + 0.5), 0, ADV_RAMP_STOPS - 1);
    return "s" + string(_i);
}

/// A ramp role from a plain 0..1 position, for anything that is not a tube.
function adv_ramp_role(_t) {
    var _i = clamp(floor(clamp(_t, 0, 1) * (ADV_RAMP_STOPS - 1) + 0.5), 0, ADV_RAMP_STOPS - 1);
    return "s" + string(_i);
}

function adv_hide_names() {
    var _h = adv_hides();
    var _o = array_create(array_length(_h));
    for (var _i = 0; _i < array_length(_h); _i++) _o[_i] = _h[_i].name;
    return _o;
}

/// Every distinct palette this package can produce: one per material per phase, since damage
/// dulls and darkens. DERIVED - it is part of the volume claim and must never be typed into copy.
function adv_palette_count() {
    return adv_hide_count() * ADV_PHASES;
}
