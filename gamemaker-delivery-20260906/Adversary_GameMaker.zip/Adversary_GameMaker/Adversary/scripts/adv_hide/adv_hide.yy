{
  "$GMScript": "v1",
  "%Name": "adv_hide",
  "name": "adv_hide",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}