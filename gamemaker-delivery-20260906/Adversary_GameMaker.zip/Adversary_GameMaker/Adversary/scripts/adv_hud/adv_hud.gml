/// adv_hud.gml — THE ENCOUNTER FRAME. The interface a boss is fought inside.
///
/// ================================================================================================
/// WHY A BOSS ASSET SHIPS A HUD
/// ================================================================================================
/// ⛔ THIS EXISTS BECAUSE OF A GAP THAT WAS ONLY VISIBLE BESIDE THE REFERENCE IMAGES. Master
/// CLAUDE.md's Gate 1 names four pictures as the bar, and the two from this factory that a buyer has
/// actually paid for - Sigil Core and Meridian - are both SCREENS: a designed interface with
/// generated artwork inside it. Every plate this product had was a CATALOGUE: correct, dense,
/// well-composed, and showing a specimen on black. A catalogue tells a buyer what is in the box. A
/// screen tells them what their game will look like, and that is the thing being sold.
///
/// ⭐ AND IT IS THE ONE CONTEXT IN WHICH THE TELEGRAPH CANNOT BE MISREAD. Five renders of the tell
/// were rejected for reading as anatomy on a static portrait; the sixth only became legible once the
/// arm moved between frames. Inside an encounter frame - a name plate, a health bar with phase pips,
/// a wind-up meter counting the same number the arc is swept by - the mark is obviously an
/// instrument reading, because everything around it is one too.
///
/// ⚠️ WHAT IT IS NOT. This package does not own combat, and nothing here decides damage, timing or
/// state. `adv_hud_draw` takes health and wind as ARGUMENTS and draws them; a buyer's own fight
/// drives them. A HUD that owned the numbers would be a combat framework wearing an asset's name,
/// and it would fight whatever the buyer already has.
///
/// ⭐ THE COLOUR IS THE BOSS'S OWN. Every plate, rule, pip and bar takes its ink from the palette of
/// the creature being fought, so the interface changes with the encounter for free - which is a
/// thing a hand-drawn HUD sprite cannot do at all, and is the same argument as the rest of the
/// package one layer up.

/// A chamfered plate. Chamfers, not rounded corners: GML has no cheap rounded rect, a plain
/// rectangle is the engine's default look, and a cut corner is a decision anybody can see was made.
function adv_hud_plate(_x1, _y1, _x2, _y2, _cut, _col, _alpha) {
    draw_set_colour(_col);
    draw_set_alpha(_alpha);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex(_x1 + _cut, _y1);
    draw_vertex(_x2 - _cut, _y1);
    draw_vertex(_x2, _y1 + _cut);
    draw_vertex(_x2, _y2 - _cut);
    draw_vertex(_x2 - _cut, _y2);
    draw_vertex(_x1 + _cut, _y2);
    draw_vertex(_x1, _y2 - _cut);
    draw_vertex(_x1, _y1 + _cut);
    draw_primitive_end();
    draw_set_alpha(1);
}

/// The same outline, as a stroke.
function adv_hud_plate_edge(_x1, _y1, _x2, _y2, _cut, _col, _alpha, _w) {
    draw_set_colour(_col);
    draw_set_alpha(_alpha);
    var _pts = [[_x1 + _cut, _y1], [_x2 - _cut, _y1], [_x2, _y1 + _cut], [_x2, _y2 - _cut],
                [_x2 - _cut, _y2], [_x1 + _cut, _y2], [_x1, _y2 - _cut], [_x1, _y1 + _cut]];
    for (var _i = 0; _i < 8; _i++) {
        var _a = _pts[_i];
        var _b = _pts[(_i + 1) mod 8];
        draw_line_width(_a[0], _a[1], _b[0], _b[1], _w);
    }
    draw_set_alpha(1);
}

/// Small-caps label with letter tracking, drawn a character at a time.
///
/// ⚠️ GML HAS NO LETTER-SPACING AT ALL, and tracking is most of what makes a small label read as
/// designed rather than as debug output. Drawn per character because there is no other way; the cost
/// is a handful of draw calls on a string nobody makes long.
///
/// ⛔ ASCII ONLY. The shipped fonts declare 32..127, and a glyph outside that range draws NOTHING -
/// no error and no missing-glyph box, just a gap that reads as a deliberate space. This wing has
/// shipped exactly that on a cover.
function adv_hud_label(_text, _x, _y, _track) {
    var _t = string_upper(_text);
    var _cx = _x;
    for (var _i = 1; _i <= string_length(_t); _i++) {
        var _c = string_char_at(_t, _i);
        draw_text(_cx, _y, _c);
        _cx += string_width(_c) + _track;
    }
    return _cx - _x - _track;
}

/// Width of what adv_hud_label would draw, so a caller can right-align or centre it.
function adv_hud_label_width(_text, _track) {
    var _t = string_upper(_text);
    var _w = 0;
    for (var _i = 1; _i <= string_length(_t); _i++) {
        _w += string_width(string_char_at(_t, _i)) + _track;
    }
    return max(0, _w - _track);
}

/// The health bar: ONE bar cut into ADV_PHASES segments, because that is what the boss actually is.
///
/// ⭐ THE SEGMENT COUNT IS `ADV_PHASES`, NOT A NUMBER TYPED HERE. A bar that showed four segments on
/// a three-phase boss would be an interface lying about the creature it is attached to, and this
/// wing has shipped a caption describing a species it was no longer drawing. Add a phase to the
/// package and the bar grows a notch on the next frame.
///
/// `_health` is 1 at full and 0 at dead. The segment boundaries are where the phases change, so a
/// player learns to read the notches as "it is about to become something else".
function adv_hud_health_bar(_x1, _y1, _x2, _y2, _health, _pal) {
    var _cut = (_y2 - _y1) * 0.42;
    adv_hud_plate(_x1, _y1, _x2, _y2, _cut, _pal.deep, 0.85);

    var _h = clamp(_health, 0, 1);
    var _in = 2;
    var _fx = _x1 + _in + ((_x2 - _x1 - (_in * 2)) * _h);
    if (_h > 0.001) {
        adv_hud_plate(_x1 + _in, _y1 + _in, _fx, _y2 - _in, max(1, _cut - _in), _pal.s8, 0.95);
        // A brighter leading edge, so the bar has a direction and reads as draining rather than as
        // a coloured rectangle.
        draw_set_colour(_pal.bright);
        draw_set_alpha(0.95);
        draw_line_width(_fx, _y1 + _in, _fx, _y2 - _in, 2);
        draw_set_alpha(1);
    }

    // The notches. Drawn OVER the fill, in the background colour, so a segment boundary is a gap in
    // the bar rather than a line on top of it.
    for (var _p = 1; _p < ADV_PHASES; _p++) {
        var _nx = _x1 + ((_x2 - _x1) * (_p / ADV_PHASES));
        draw_set_colour(_pal.deep);
        draw_set_alpha(1);
        draw_line_width(_nx, _y1 - 1, _nx, _y2 + 1, 3);
    }
    adv_hud_plate_edge(_x1, _y1, _x2, _y2, _cut, _pal.line, 0.9, 2);
}

/// The phase pips: one chamfered diamond per phase, filled up to and including the current one.
function adv_hud_pips(_x, _y, _r, _phase, _pal) {
    for (var _p = 0; _p < ADV_PHASES; _p++) {
        var _cx = _x + (_p * (_r * 2.9));
        var _on = (_p <= _phase);
        draw_set_colour(_on ? _pal.bright : _pal.deep);
        draw_set_alpha(_on ? 0.95 : 0.75);
        draw_primitive_begin(pr_trianglefan);
        draw_vertex(_cx, _y - _r);
        draw_vertex(_cx + _r, _y);
        draw_vertex(_cx, _y + _r);
        draw_vertex(_cx - _r, _y);
        draw_primitive_end();
        draw_set_alpha(1);
        if (!_on) {
            draw_set_colour(_pal.line);
            draw_line_width(_cx, _y - _r, _cx + _r, _y, 1);
            draw_line_width(_cx + _r, _y, _cx, _y + _r, 1);
            draw_line_width(_cx, _y + _r, _cx - _r, _y, 1);
            draw_line_width(_cx - _r, _y, _cx, _y - _r, 1);
        }
    }
}

/// The wind-up meter, in the TELEGRAPH's own colour.
///
/// ⭐ It reads the same `_wind` the limb is solved at and the arc is swept by, so a player watching
/// this bar and a player watching the arc are watching one number. That is the product's whole claim
/// restated as an instrument: there is nothing here to keep in step, because there is only one of it.
function adv_hud_wind(_x1, _y1, _x2, _y2, _wind, _pal) {
    var _cut = (_y2 - _y1) * 0.5;
    adv_hud_plate(_x1, _y1, _x2, _y2, _cut, _pal.deep, 0.80);
    var _w = clamp(_wind, 0, 1);
    if (_w > 0.001) {
        adv_hud_plate(_x1 + 2, _y1 + 2, _x1 + 2 + ((_x2 - _x1 - 4) * _w), _y2 - 2,
                      max(1, _cut - 2), _pal.tell, 0.55 + (0.40 * _w));
    }
    // A tick at full wind: the instant the blow lands.
    draw_set_colour(_pal.tellcore);
    draw_set_alpha(0.9);
    draw_line_width(_x2 - 2, _y1 - 3, _x2 - 2, _y2 + 3, 2);
    draw_set_alpha(1);
    adv_hud_plate_edge(_x1, _y1, _x2, _y2, _cut, _pal.line, 0.85, 1);
}

/// The whole encounter frame, drawn around a rect the boss is standing in.
///
/// `_x, _y, _w, _h` is the SCREEN, not the boss. The boss is drawn by the caller, between the floor
/// pass and the chrome pass, so the shadow lands under it and the plates land over it.
///
/// Returns a struct naming where the boss should stand and how big it may be, so a caller never
/// has to re-derive the layout this function already chose.
function adv_hud_stage(_x, _y, _w, _h) {
    return {
        cx: _x + (_w * 0.5),
        cy: _y + (_h * 0.60),
        // ⚠️ 0.30 -> 0.35 AFTER LOOKING AT THE BAKE: at 0.30 the boss stood in the lower half of a
        // 720-line frame with a third of the picture empty above it, which reads as a creature that
        // is not very big rather than as a boss.
        scale: _h * 0.35,
        floorY: _y + (_h * 0.855)
    };
}

/// Everything BEHIND the boss: the ground, the horizon and the shadow.
function adv_hud_floor(_x, _y, _w, _h, _pal) {
    var _st = adv_hud_stage(_x, _y, _w, _h);
    // A vertical wash from the top, so the frame has depth rather than a flat backdrop.
    //
    // ⛔ THE GROUND IS DELIBERATELY LIGHTER THAN THE AIR, AND THAT IS THE FIX FOR A DEFECT THAT COST
    // FIVE BAKES. It used to run 0.11 -> 0.07, i.e. almost pure black - and a SHADOW CANNOT EXIST ON
    // A BLACK FLOOR. Every attempt to make the shadow darker was therefore unfalsifiable by
    // construction: it was already invisible, and the pale ellipse the eye kept reporting was the
    // shadow's own soft rim against a lighter band above the horizon, read as a highlight because
    // there was nothing darker anywhere near it to compare against. The positive control settled it -
    // the same fan in bright green rendered green, at the right place and size, so the code and the
    // colour were never the problem.
    //
    // ⭐ The general form, and it is the fourth time this wing has paid for a version of it: BEFORE
    // TUNING A MARK, CHECK THAT ITS BACKGROUND CAN SHOW IT. A dark mark on a black ground and a
    // bright mark on a white one are both invisible for reasons no amount of tuning the MARK can
    // reach.
    adv_render_vgrad(_x, _y, _w, _h * 0.86, adv_oklch(0.12, 0.014, 262),
                     adv_oklch(0.17, 0.020, 258));
    adv_render_vgrad(_x, _st.floorY, _w, _y + _h - _st.floorY,
                     adv_oklch(0.30, 0.014, 252), adv_oklch(0.20, 0.012, 252));
    // ⚠️ THE HORIZON IS A SEAM IF IT IS A LINE ACROSS THE WHOLE FRAME. First version drew
    // `_pal.line` at 0.55 over the full width and it read as a rendering artefact rather than as
    // ground - the eye takes a hard uninterrupted horizontal at one value as a tear. Kept, because
    // the floor needs an edge, but quiet and dark.
    // The horizon. Quiet: a hard uninterrupted horizontal at one value reads as a tear rather than
    // as ground, and the gradient step across it is doing most of the work already.
    draw_set_colour(adv_oklch(0.38, 0.014, 252));
    draw_set_alpha(0.55);
    draw_line_width(_x, _st.floorY, _x + _w, _st.floorY, 2);
    draw_set_alpha(1);

    // The shadow: a boss reads as standing on the floor only if something on the floor says so.
    //
    // ⛔⛔⛔ A COLOUR VALUE OF ZERO DRAWS AS **WHITE** HERE, AND IT COST THREE BAKES BECAUSE ALL
    // THREE "DIFFERENT" FIXES WERE THE SAME INPUT.
    //
    //   bake 1: draw_set_colour(adv_oklch(0.05, 0.008, 258)) + draw_ellipse
    //           -> a pale ellipse, LIGHTER than the ground it was cast on.
    //   bake 2: draw_set_colour(c_black) + draw_ellipse, alpha 0.50
    //           -> pixel-identical. Which "proved" the colour was not the problem, since c_black
    //              cannot be lighter than anything, and sent me after the drawing STATE instead.
    //   bake 3: per-vertex draw_vertex_colour(..., c_black, a), the exact path the telegraph fill
    //           uses and which demonstrably renders what it is told
    //           -> pixel-identical AGAIN.
    //
    // ⭐ THREE IMPLEMENTATIONS AND ONE RESULT IS NOT THREE FAILURES, IT IS ONE VARIABLE HELD FIXED.
    // `c_black` IS 0, and `adv_oklch(0.05, 0.008, 258)` rounds to 0 as well - so every attempt
    // passed the same value, and the thing they had in common was the only thing never tested.
    // Measured by cropping the region out of the bake at 3x and looking at it, after the eye had
    // already reported "lighter" twice and been talked out of it by an argument about blend modes.
    //
    // ⇒ NEVER PASS 0 AS A COLOUR IN THIS PACKAGE. Anything genuinely near black is spelled with a
    // non-zero component, and this one is `make_colour_rgb(3, 4, 8)` - visually black, arithmetically
    // not zero. Wing CLAUDE.md carries the general form.
    //
    // ⚠️ The MECHANISM is not claimed: what is measured is that 0 renders pale on this path and that
    // a near-zero non-zero value renders correctly. A fan of segments rather than an ellipse because
    // it can FADE at the rim, which is what a ground shadow wants.
    var _shadow = make_colour_rgb(3, 4, 8);
    var _sx = _st.scale * 0.98;
    var _sy = _st.scale * 0.125;
    draw_set_alpha(1);
    draw_primitive_begin(pr_trianglelist);
    var _seg = 40;
    for (var _i = 0; _i < _seg; _i++) {
        var _a0 = (_i / _seg) * 2 * pi;
        var _a1 = ((_i + 1) / _seg) * 2 * pi;
        draw_vertex_colour(_st.cx, _st.floorY, _shadow, 0.72);
        draw_vertex_colour(_st.cx + (cos(_a0) * _sx), _st.floorY + (sin(_a0) * _sy), _shadow, 0);
        draw_vertex_colour(_st.cx + (cos(_a1) * _sx), _st.floorY + (sin(_a1) * _sy), _shadow, 0);
    }
    draw_primitive_end();
    draw_set_alpha(1);
    return _st;
}

/// Everything IN FRONT of the boss: the name plate, the bar, the pips, the wind meter.
function adv_hud_draw(_plan, _hide, _pal, _phase, _health, _wind, _x, _y, _w, _h) {
    var _pad = _w * 0.035;
    var _plateW = _w * 0.46;
    var _top = _y + (_h * 0.055);

    // ---- the name plate ------------------------------------------------------------------------
    adv_hud_plate(_x + _pad, _top, _x + _pad + _plateW, _top + (_h * 0.155),
                  _h * 0.030, _pal.deep, 0.86);
    adv_hud_plate_edge(_x + _pad, _top, _x + _pad + _plateW, _top + (_h * 0.155),
                       _h * 0.030, _pal.line, 0.95, 2);

    draw_set_valign(fa_top);
    draw_set_halign(fa_left);
    draw_set_font(fnt_adversary_title);
    draw_set_colour(_pal.bright);
    var _nx = _x + _pad + (_w * 0.022);
    adv_hud_label(_plan.name, _nx, _top + (_h * 0.022), 2);

    draw_set_font(fnt_adversary);
    draw_set_colour(_pal.s6);
    // ⛔ DERIVED, both halves. The material and the phase come off the package's own arrays, so the
    // plate cannot describe a state the boss is not in.
    adv_hud_label(_hide.name + "  /  " + adv_name_of(adv_phase_names(), _phase),
                  _nx, _top + (_h * 0.095), 1);

    // ---- the health bar and the pips -----------------------------------------------------------
    var _barY = _top + (_h * 0.175);
    adv_hud_health_bar(_x + _pad, _barY, _x + _pad + _plateW, _barY + (_h * 0.030), _health, _pal);
    adv_hud_pips(_x + _pad + (_h * 0.020), _barY + (_h * 0.062), _h * 0.012, _phase, _pal);

    // ---- the wind-up meter, over on the boss's side ---------------------------------------------
    var _mW = _w * 0.20;
    var _mX = _x + _w - _pad - _mW;
    draw_set_colour(_pal.s7);
    draw_set_font(fnt_adversary);
    var _lw = adv_hud_label_width("wind-up", 2);
    adv_hud_label("wind-up", _mX + _mW - _lw, _top + (_h * 0.010), 2);
    adv_hud_wind(_mX, _top + (_h * 0.058), _mX + _mW, _top + (_h * 0.082), _wind, _pal);

    // ---- the footer rule -----------------------------------------------------------------------
    draw_set_colour(_pal.line);
    draw_set_alpha(0.5);
    draw_line_width(_x + _pad, _y + _h - (_h * 0.052), _x + _w - _pad, _y + _h - (_h * 0.052), 1);
    draw_set_alpha(1);
    draw_set_halign(fa_left);
}
