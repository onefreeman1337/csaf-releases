{
  "$GMScript": "v1",
  "%Name": "adv_hud",
  "name": "adv_hud",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}