/// adv_selftest.gml — the in-engine suite. Runs headless, writes its result to a file.
///
/// ⚠️ THIS IS THE ONLY REAL TEST THIS WING HAS. GML cannot be unit-tested outside the engine: there
/// is no Node-mockable core and no -batchmode equivalent, so verification risk here is structurally
/// higher than in the other wings and pretending otherwise is the failure master §2 forbids.
///
/// ⛔ THE FOUR ROUTES THAT DO NOT WORK, all measured by this wing and all tried before this one:
///   - `show_debug_message` + `-debugoutput <file>` : DEAD in a release build; the file holds only
///     engine boot lines.
///   - `game_end(n)` -> process exit code           : the argument is NOT propagated (a run that
///     called game_end(152000) exited 0). A pass/fail bit at best.
///   - driving Igor directly for the build          : without `--uf=<user folder>` it gives
///     `Reason Code - 0000002A / Permission Error`, which is the EXACT signature of a lapsed
///     licence, on a healthy machine. Shell out to gm_gate.ps1.
///   - `file_text_open_write` to %LOCALAPPDATA%      : ✅ the one that works. No runner flag,
///     survives a release build. That is what this file uses.
///
/// ⛔ AND A GML RUNTIME ERROR OPENS A MODAL DIALOG, so headless the process NEVER EXITS - an opaque
/// 180-second hang with no output. `exception_unhandled_handler` is installed as the first thing
/// the Create event does, and every stage records a number, so a crash reports WHERE.

/// One assertion. Records a failure rather than throwing, so a single bad plan does not hide the
/// other thirteen.
function adv_st_assert(_st, _cond, _msg) {
    _st.total += 1;
    if (_cond) { _st.pass += 1; return true; }
    _st.fail += 1;
    if (array_length(_st.failures) < 40) array_push(_st.failures, _msg);
    return false;
}

/// ⚠️ TOLERANCE FLOOR. GML applies a DEFAULT EPSILON to numeric comparisons and this wing measured
/// it at 0.00001 (printed to twelve decimals off a real Igor-built exe, runtime 2024.14.4.268).
/// A tolerance AT or BELOW it is unusable in BOTH directions: `abs(a-b) < 0.0000001` is FALSE for
/// every pair of values including equal ones, and `abs(a-b) < 0.00001` goes RED on two points that
/// are the same array object. Never write a tolerance below ~1e-5 in GML, and never AT it.
#macro ADV_ST_EPS 0.0001

/// Advance the stage marker.
///
/// ⛔⛔ THE FIRST VERSION SET ONLY `_st.stage`, A LOCAL — SO THE CRASH HANDLER, WHICH READS
/// `global.adv_stage`, REPORTED "stage 1" FOR A CRASH ANYWHERE IN THE SUITE. The whole point of a
/// stage number is that an unhandled GML error (which headless is an un-dismissable modal dialog,
/// i.e. a silent hang) reports WHERE it happened; a marker the handler cannot see turns a located
/// failure back into an opaque one. Measured the first time this suite crashed: "CRASH at stage 1:
/// I32 argument is array", with stage 1 being an epsilon comparison that cannot produce that error.
///
/// ⭐ Same family as this wing's law that a silent refusal is indistinguishable from a defect: an
/// instrument that always answers "1" is not reporting, it is agreeing.
function adv_st_stage(_st, _n) {
    _st.stage = _n;
    global.adv_stage = _n;
}

function adv_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: [] };

    // -- STAGE 1: the runtime still applies an epsilon ------------------------------------------
    // ⛔ WRITTEN AS A POSITIVE TEST ON PURPOSE. The natural form,
    //   `math_get_epsilon() > 0 && math_get_epsilon() < TOL`
    // goes RED on its FIRST clause: the difference between the epsilon and zero IS the epsilon, so
    // GML calls them equal, and equal is not greater-than. Do not "repair" this into one clause.
    adv_st_stage(_st, 1);
    var _e = math_get_epsilon();
    adv_st_assert(_st, !(_e > ADV_ST_EPS), "the default epsilon is larger than this suite's tolerance: " + string(_e));
    adv_st_assert(_st, !(_e < 0), "math_get_epsilon() went negative: " + string(_e));

    // -- STAGE 2: segment normalisation ----------------------------------------------------------
    // The declared reach IS the sum of the segments, by construction. This asserts the construction
    // rather than the claim: a weighting scheme that failed to normalise would make the telegraph
    // and the drawing disagree by however much the weights happened to sum to.
    adv_st_stage(_st, 2);
    var _corpus = adv_corpus();
    for (var _i = 0; _i < array_length(_corpus); _i++) {
        var _plan = _corpus[_i];
        for (var _j = 0; _j < array_length(_plan.limbs); _j++) {
            var _limb = _plan.limbs[_j];
            var _seg = adv_limb_segments(_limb);
            var _sum = 0;
            for (var _k = 0; _k < array_length(_seg); _k++) _sum += _seg[_k];
            adv_st_assert(_st, abs(_sum - _limb.len) < ADV_ST_EPS,
                _plan.id + " limb " + string(_j) + ": segments sum to " + string(_sum)
                + " but len declares " + string(_limb.len));
            adv_st_assert(_st, array_length(_seg) == max(1, _limb.segs),
                _plan.id + " limb " + string(_j) + ": segment count " + string(array_length(_seg))
                + " != segs " + string(_limb.segs));
        }
    }

    // -- STAGE 3: THE COUPLING. The product's central claim. ------------------------------------
    // Every telegraph must COVER the reach its limb actually achieves, and must not wildly exceed
    // it. Both bounds, because a one-sided threshold cannot detect drift in its permissive
    // direction and that is the direction things rot in.
    //
    // ⛔ THE TWO SIDES ARE COMPUTED BY DIFFERENT PATHS ON PURPOSE. `r` is the DECLARED reach; the
    // comparison is against a swept measurement off the SOLVED joint chain, which accumulates a
    // bend the declaration knows nothing about. Comparing the declaration to itself would pass by
    // construction - the "verifying against the field you wrote" trap.
    adv_st_stage(_st, 3);
    var _tellsSeen = 0;
    var _quietSeen = 0;
    var _worstCover = 999;
    var _worstOver = 0;
    for (var _i = 0; _i < array_length(_corpus); _i++) {
        var _plan = _corpus[_i];
        for (var _ph = 0; _ph < ADV_PHASES; _ph++) {
            for (var _s = -1; _s <= 1; _s += 2) {
                for (var _j = 0; _j < array_length(_plan.limbs); _j++) {
                    var _limb = _plan.limbs[_j];
                    var _tell = adv_tell_arc(_plan, _j, _s, _ph);

                    if (!adv_role_telegraphs(_limb.role)) {
                        _quietSeen += 1;
                        adv_st_assert(_st, is_undefined(_tell),
                            _plan.id + " limb " + string(_j) + " has role "
                            + string(_limb.role) + " and must NOT telegraph, but produced an arc");
                        continue;
                    }

                    _tellsSeen += 1;
                    if (!adv_st_assert(_st, !is_undefined(_tell),
                        _plan.id + " limb " + string(_j) + " telegraphs but produced no arc")) continue;

                    var _drawn = adv_limb_reach_drawn(_plan, _limb, _s, _ph);
                    adv_st_assert(_st, _drawn > ADV_ST_EPS,
                        _plan.id + " limb " + string(_j) + " phase " + string(_ph)
                        + ": measured reach collapsed to " + string(_drawn));

                    if (_drawn > ADV_ST_EPS) {
                        var _ratio = _tell.r / _drawn;
                        if (_ratio < _worstCover) _worstCover = _ratio;
                        if (_ratio > _worstOver) _worstOver = _ratio;
                        adv_st_assert(_st, _ratio >= ADV_TELL_COVER_MIN,
                            _plan.id + " limb " + string(_j) + " phase " + string(_ph)
                            + ": TELL UNDER-DRAWN - radius " + string(_tell.r)
                            + " covers only " + string(_ratio) + " of a reach of " + string(_drawn)
                            + ". The limb hits past its own warning.");
                        adv_st_assert(_st, _ratio <= ADV_TELL_COVER_MAX,
                            _plan.id + " limb " + string(_j) + " phase " + string(_ph)
                            + ": TELL OVER-DRAWN - radius is " + string(_ratio)
                            + "x the reach of " + string(_drawn) + ".");
                    }

                    // A telegraph that sweeps no angle draws as an invisible sliver, so the attack
                    // lands with NO warning. No ink check can ever see this: absent ink between two
                    // marks is what a gap looks like.
                    var _span = adv_tell_span(_tell);
                    adv_st_assert(_st, _span >= ADV_TELL_SPAN_MIN,
                        _plan.id + " limb " + string(_j) + " phase " + string(_ph)
                        + ": DEGENERATE TELL - spans only " + string(_span) + " rad");

                    // The pivot must be the limb's own attachment, not the body centre.
                    var _joints = adv_limb_joints(_plan, _limb, _s, _ph, 0);
                    adv_st_assert(_st, abs(_tell.cx - _joints[0][0]) < ADV_ST_EPS
                                    && abs(_tell.cy - _joints[0][1]) < ADV_ST_EPS,
                        _plan.id + " limb " + string(_j) + ": tell pivot is not the limb's joint 0");

                    adv_st_assert(_st, _tell.kind != ADV_TELL_NONE,
                        _plan.id + " limb " + string(_j) + ": terminal " + string(_limb.term)
                        + " has no telegraph kind - adv_tell_kind fell through its switch");
                }
            }
        }
    }

    // ⛔ VACUITY GUARDS. Every assertion in stage 3 sits inside a role test, so if the corpus
    // contained no striking limbs the whole stage would pass over nothing and report green. This
    // wing has already had a gate certify an invulnerable boss by counting WINS instead of
    // DEFEATS; a sweep that saw no cases is the same failure one level up.
    adv_st_stage(_st, 4);
    adv_st_assert(_st, _tellsSeen > 0, "VACUITY: stage 3 examined ZERO telegraphing limbs");
    adv_st_assert(_st, _quietSeen > 0, "VACUITY: stage 3 examined ZERO non-telegraphing limbs, so "
        + "the 'a support leg must not telegraph' assertion tested nothing");

    // -- STAGE 4b: THE SWEPT REGION HAS NO CORRIDOR IN IT -----------------------------------------
    //
    // ⛔ THE ONE CLAIM IN THIS PACKAGE THAT COULD ONLY EVER BE CHECKED BY EYE, MADE MECHANICAL.
    // adv_limb's two-sided reach bound already governs the arc's RADIUS: an OVER-drawn telegraph
    // wastes floor, an UNDER-drawn one means the player stood where the game said it was safe and
    // was hit. Nothing governed what the renderer then PUT inside that radius - and that renderer
    // has now been rewritten five times, every time to stop it reading as a WING, which is exactly
    // the kind of change that quietly opens a hole in the middle of a danger zone. GML has no
    // headless renderer, so the band table and the direction ramp were split out as a declaration
    // and a pure function for the sole purpose of being assertable here.
    //
    // ⭐ AND THE RENDERER READS THE SAME ARRAY. Wing CLAUDE.md's sixth-of-a-family rule: a check
    // that re-states a number certifies its own copy of it. Widen a gap to make the picture prettier
    // and this goes red on the value that was actually changed.
    //
    // ⚠️ ADV_TELL_GAP_MAX IS PRE-REGISTERED AND CAN FAIL: it sits below the narrowest band in the
    // table by construction, so a gap may never be the widest feature of the figure.
    var _bands = adv_tell_bands();
    adv_st_assert(_st, array_length(_bands) >= 2,
        "STAGE 4b VACUITY: adv_tell_bands() has " + string(array_length(_bands))
        + " band(s), so the gap sweep below compares nothing");
    var _worstGap = 0;
    var _narrowest = 999;
    var _gapsSeen = 0;
    var _prevOuter = ADV_TELL_INNER;
    var _ordered = true;
    for (var _bi = 0; _bi < array_length(_bands); _bi++) {
        var _bIn = _bands[_bi][0];
        var _bOut = _bands[_bi][1];
        if (_bOut <= _bIn) _ordered = false;
        if (_bIn < _prevOuter - ADV_ST_EPS) _ordered = false;
        _narrowest = min(_narrowest, _bOut - _bIn);
        var _g = _bIn - _prevOuter;
        if (_g > _worstGap) _worstGap = _g;
        _gapsSeen += 1;
        _prevOuter = _bOut;
    }
    adv_st_assert(_st, _ordered,
        "adv_tell_bands() is not a sorted list of non-empty, non-overlapping bands - the gap "
        + "measurement below assumes it is and would read a negative gap as safe");
    adv_st_assert(_st, _gapsSeen == array_length(_bands),
        "STAGE 4b VACUITY: measured " + string(_gapsSeen) + " gap(s) over "
        + string(array_length(_bands)) + " band(s)");
    adv_st_assert(_st, _worstGap <= ADV_TELL_GAP_MAX,
        "TELEGRAPH HAS A CORRIDOR IN IT - the widest unmarked gap inside the swept region is "
        + string(_worstGap) + " of the reach, over the " + string(ADV_TELL_GAP_MAX)
        + " bar. A player reads a gap that wide as floor they can stand on.");
    adv_st_assert(_st, _worstGap < _narrowest,
        "the widest gap (" + string(_worstGap) + ") is not narrower than the narrowest band ("
        + string(_narrowest) + "), so the holes are the biggest feature of the figure and it stops "
        + "reading as one region");
    adv_st_assert(_st, _prevOuter >= 1 - ADV_ST_EPS,
        "the outermost band stops at " + string(_prevOuter) + " of the reach, so the ring the "
        + "terminal itself travels is UNMARKED - that is the one place the tell must be");

    // The direction ramp: the only cue that says which way the blow is coming, and a FLAT one is
    // the read that was rejected five times. A one-sided floor cannot see a collapse back to flat,
    // so both ends are bounded.
    adv_st_assert(_st, adv_tell_ink(0) > 0,
        "the trailing end of the sweep draws NOTHING - it is swept FIRST, so it is dangerous first");
    adv_st_assert(_st, adv_tell_ink(1) <= 1,
        "telegraph ink exceeds full alpha at the leading edge");
    adv_st_assert(_st, (adv_tell_ink(1) / max(0.0001, adv_tell_ink(0))) >= 2,
        "the sweep is nearly FLAT along its span (loudest/faintest = "
        + string(adv_tell_ink(1) / max(0.0001, adv_tell_ink(0))) + "x) - it carries no direction");
    var _inkMono = true;
    var _inkSamples = 0;
    for (var _iu = 1; _iu <= 20; _iu++) {
        _inkSamples += 1;
        if (adv_tell_ink(_iu / 20) < adv_tell_ink((_iu - 1) / 20) - ADV_ST_EPS) _inkMono = false;
    }
    adv_st_assert(_st, _inkSamples == 20,
        "STAGE 4b VACUITY: the monotonicity sweep compared " + string(_inkSamples) + " pairs");
    adv_st_assert(_st, _inkMono,
        "adv_tell_ink is not monotone along the sweep - somewhere the mark gets QUIETER as the blow "
        + "gets closer");

    // ⛔ AND THE KIND MUST ACTUALLY REACH THE RENDERER. The whole reason this render was rewritten
    // is that `adv_tell_kind` had declared four shapes since the first build while the renderer drew
    // one pie for all four - a model that never reached the screen, and a generic wedge is what read
    // as a wing. If the corpus only ever produces one kind, the dispatch is decoration and the
    // listing's four-shape claim is a picture the package cannot draw.
    var _kindsSeen = [0, 0, 0, 0];
    for (var _i = 0; _i < array_length(_corpus); _i++) {
        var _kplan = _corpus[_i];
        for (var _j = 0; _j < array_length(_kplan.limbs); _j++) {
            if (!adv_role_telegraphs(_kplan.limbs[_j].role)) continue;
            var _kd = adv_tell_kind(_kplan.limbs[_j]);
            if (_kd >= 0 && _kd < 4) _kindsSeen[_kd] += 1;
        }
    }
    var _kindsUsed = 0;
    for (var _k2 = 0; _k2 < 4; _k2++) if (_kindsSeen[_k2] > 0) _kindsUsed += 1;
    adv_st_assert(_st, _kindsUsed >= 3,
        "only " + string(_kindsUsed) + " of the 4 telegraph kinds appear anywhere in the corpus");

    // -- STAGE 5: derived counts -----------------------------------------------------------------
    // These numbers go on the store listing, so they are derived here and asserted against the
    // arrays actually walked - never typed into copy. A name array summed into a market claim must
    // be index-parallel with a real switch or the listing quotes forms the package does not have.
    adv_st_stage(_st, 5);
    adv_st_assert(_st, adv_corpus_bodies() == array_length(_corpus) * ADV_PHASES,
        "adv_corpus_bodies() disagrees with the corpus it is derived from");
    adv_st_assert(_st, adv_corpus_tells() == (_tellsSeen / 2),
        "adv_corpus_tells() = " + string(adv_corpus_tells())
        + " but the sweep counted " + string(_tellsSeen / 2) + " per side");
    adv_st_assert(_st, array_length(adv_term_names()) == 8,
        "adv_term_names() is not index-parallel with the ADV_TERM_* macros");
    adv_st_assert(_st, array_length(adv_phase_names()) == ADV_PHASES,
        "adv_phase_names() is not index-parallel with ADV_PHASES");
    adv_st_assert(_st, array_length(adv_tell_kind_names()) == 4,
        "adv_tell_kind_names() is not index-parallel with the ADV_TELL_* macros");

    // -- STAGE 6: plan integrity -----------------------------------------------------------------
    adv_st_stage(_st, 6);
    for (var _i = 0; _i < array_length(_corpus); _i++) {
        var _plan = _corpus[_i];
        adv_st_assert(_st, array_length(_plan.limbs) > 0, _plan.id + " has no limbs");
        adv_st_assert(_st, !is_undefined(adv_plan(_plan.id)), _plan.id + " is not findable by id");
        // At least one limb must be able to hurt the player, or it is scenery rather than a boss.
        var _canStrike = false;
        for (var _j = 0; _j < array_length(_plan.limbs); _j++) {
            if (adv_role_telegraphs(_plan.limbs[_j].role)) _canStrike = true;
        }
        adv_st_assert(_st, _canStrike, _plan.id + " has no limb that can attack");
        // The core half-width must never collapse, or a limb attaches at the centre line and reads
        // as growing out of thin air.
        for (var _t = 0; _t <= 10; _t++) {
            var _hw = adv_core_halfwidth_at(_plan, _t / 10);
            adv_st_assert(_st, _hw > 0.05, _plan.id + " core half-width collapsed to "
                + string(_hw) + " at station " + string(_t / 10));
        }
    }

    // -- STAGE 7: the bodies actually draw ------------------------------------------------------
    // ⛔ A COUNT IS NOT A PICTURE, and this stage does not pretend otherwise. It proves the body
    // layer EMITS geometry of a plausible size in a plausible place; it cannot see whether the
    // result looks like a boss. This wing has shipped 890 green assertions over a head not
    // attached to its body and 1,482 over a corpus built upside down - "nothing mechanical can see
    // an assembly that is correct part by part and wrong as a whole". The instrument for that is
    // baking the PNG and looking at it, and it has not been run yet.
    adv_st_stage(_st, 7);
    var _minParts = 99999;
    var _worstReach = 0;
    for (var _i = 0; _i < array_length(_corpus); _i++) {
        var _plan = _corpus[_i];
        for (var _ph = 0; _ph < ADV_PHASES; _ph++) {
            var _parts = adv_body_parts(_plan, _ph, 0.5);
            var _pc = array_length(_parts);
            if (_pc < _minParts) _minParts = _pc;
            adv_st_assert(_st, _pc > 8,
                _plan.id + " phase " + string(_ph) + " drew only " + string(_pc) + " parts");

            // The whole boss must sit in a sane box. A limb that escapes by an order of magnitude
            // is the units defect this wing has recorded painting an entire store sheet with one
            // filled annulus, under 689 green assertions.
            // ⚠️ `adv_render_bounds` returns an ARRAY [x0, y0, x1, y1] — NOT a struct with .x0.
            // The first version of this stage wrote `_b.x0` and the suite died headless with
            // "I32 argument is array" (abs() handed an array), which is a crash rather than a
            // failed assertion and therefore reports nothing about the product. Read the API;
            // a shape you remember is not a shape you checked.
            var _b = adv_render_bounds(_parts);
            var _bx0 = _b[0], _by0 = _b[1], _bx1 = _b[2], _by1 = _b[3];
            var _reach = max(abs(_bx0), abs(_bx1), abs(_by0), abs(_by1));
            if (_reach > _worstReach) _worstReach = _reach;
            adv_st_assert(_st, _reach < 6.0,
                _plan.id + " phase " + string(_ph) + " reaches " + string(_reach)
                + " unit-box units - a limb has escaped");
            adv_st_assert(_st, (_bx1 - _bx0) > 0.10 && (_by1 - _by0) > 0.10,
                _plan.id + " phase " + string(_ph) + " collapsed to a degenerate box");
        }

        // The core outline must be SIMPLE. ⛔ Total turning is the CHEAP test and its converse is
        // false: a polygon with one crossed-over flap still accumulates exactly one revolution, so
        // turning passes on five of six real self-intersections. adv_is_simple is the definitive
        // one, and O(n^2) over ~60 points costs nothing in a suite.
        var _out = adv_core_outline(_plan, 24);
        adv_st_assert(_st, adv_is_simple(_out), _plan.id + " core outline self-intersects");
        adv_st_assert(_st, array_length(_out) > 8, _plan.id + " core outline is degenerate");
    }

    // -- STAGE 8: materials ----------------------------------------------------------------------
    // ⛔ `ink` MUST CONTRAST WITH ITS OWN GROUND. On a light material every ramp stop is light, so
    // a caption set in "the darkest stop" is merely less pale - this wing shipped an invisible
    // caption on parchment exactly that way. Asserted against the material's own ground, per hide.
    adv_st_stage(_st, 8);
    var _hides = adv_hides();
    for (var _i = 0; _i < array_length(_hides); _i++) {
        for (var _ph = 0; _ph < ADV_PHASES; _ph++) {
            var _pal = adv_palette_for(_hides[_i], _ph / max(1, ADV_PHASES - 1));
            adv_st_assert(_st, variable_struct_exists(_pal, "ink")
                            && variable_struct_exists(_pal, "ground"),
                _hides[_i].id + ": palette is missing ink or ground");
            // The two brightest ramp stops must not be the SAME colour. A clamped ramp silently
            // collapses its ends, and a bevel whose two lit walls are identical reads as a flat
            // fill with a line round it.
            var _top = variable_struct_get(_pal, "s" + string(ADV_RAMP_STOPS - 1));
            var _nxt = variable_struct_get(_pal, "s" + string(ADV_RAMP_STOPS - 2));
            adv_st_assert(_st, _top != _nxt,
                _hides[_i].id + " phase " + string(_ph)
                + ": the two brightest ramp stops collapsed to one colour - the ramp was CLAMPED, "
                + "not slid");
            var _m4 = variable_struct_get(_pal, "m4");
            var _m3 = variable_struct_get(_pal, "m3");
            adv_st_assert(_st, _m4 != _m3,
                _hides[_i].id + " phase " + string(_ph) + ": cut-edge stops m3/m4 collapsed");
        }
    }
    // Vacuity: every stage-8 assertion sits inside this loop.
    adv_st_assert(_st, array_length(_hides) > 0, "VACUITY: stage 8 examined ZERO materials");

    // -- STAGE 9: THE FORM FAMILIES AND THE PLATING -----------------------------------------------
    //
    // ⛔ THIS STAGE EXISTS BECAUSE ITS ABSENCE WAS THE DEFECT. Three drawn subsystems were added in
    // one session - the core form family, the crown form family and the armour plating - and the
    // suite came back at 1558 assertions, exactly what it had been before any of them existed. That
    // is wing CLAUDE.md's Liege entry verbatim: "not one of its 164 assertions draws a string - a
    // whole subsystem with zero coverage, invisible because the COUNT was large." A large green
    // number is not coverage of the thing you just wrote.
    adv_st_stage(_st, 9);

    // 9a. A FORM FAMILY WHOSE MEMBERS COLLAPSE IS NOT A FAMILY. The whole reason the core stopped
    // being `sin(pi*u)` is that one symmetric function cannot describe fourteen creatures, so the
    // replacement has to be checked for the thing it was brought in to provide: difference.
    var _forms = adv_core_forms();
    var _fnames = adv_core_form_names();
    adv_st_assert(_st, array_length(_forms) == array_length(_fnames),
        "core form table and name array are not index-parallel: "
        + string(array_length(_forms)) + " vs " + string(array_length(_fnames)));
    var _probe = { core: { w: 1, h: 1, profile: 0.5, lean: 0, form: 0 },
                   crown: { count: 1, scale: 0.2, sunken: 0, form: 0 },
                   armour: { plates: 4, coverage: 0.8, weight: 0.5 },
                   limbs: [], mass: 1 };
    var _worstFormGap = 999;
    var _worstFormPair = "";
    for (var _a = 0; _a < array_length(_forms); _a++) {
        // Every control value must be a legal half-width fraction, or the outline leaves the box.
        for (var _k = 0; _k < array_length(_forms[_a]); _k++) {
            adv_st_assert(_st, _forms[_a][_k] > 0 && _forms[_a][_k] <= 1.0,
                "core form " + _fnames[_a] + " control " + string(_k) + " is outside (0,1]: "
                + string(_forms[_a][_k]));
        }
        for (var _b = _a + 1; _b < array_length(_forms); _b++) {
            // Compare the SAMPLED profiles, not the control arrays: two different control sets that
            // interpolate to the same curve are the same form, and it is the curve that is drawn.
            var _sum = 0;
            for (var _s2 = 0; _s2 <= 20; _s2++) {
                _probe.core.form = _a;
                var _wa = adv_core_halfwidth_at(_probe, _s2 / 20);
                _probe.core.form = _b;
                var _wb = adv_core_halfwidth_at(_probe, _s2 / 20);
                _sum += abs(_wa - _wb);
            }
            var _gap = _sum / 21;
            if (_gap < _worstFormGap) {
                _worstFormGap = _gap;
                _worstFormPair = _fnames[_a] + " vs " + _fnames[_b];
            }
        }
    }
    // ⚠️ 0.04 is a FLOOR ON A MEASURED DISTRIBUTION, not a number that was liked: the closest pair
    // in the shipped table measures well clear of it and is printed on every run, so the next
    // session re-derives it from the corpus instead of inheriting it. A form pair that fell under
    // this is two rows of the corpus drawing the same body.
    adv_st_assert(_st, _worstFormGap >= 0.04,
        "two core forms are nearly identical (" + _worstFormPair + ", mean half-width gap "
        + string(_worstFormGap) + ") - a form family whose members collapse is not a family");
    adv_st_assert(_st, array_length(_forms) > 1, "VACUITY: fewer than two core forms to compare");

    // 9b. EVERY CROWN FORM MUST DRAW SOMETHING, AND SOMETHING DIFFERENT.
    // The name array is what a listing would quote, so it must not outrun the switch - wing
    // CLAUDE.md records twelve materials all captioned "structural" because an 18-case switch was
    // indexed into a 6-entry array with the overflow clamped away.
    var _cnames = adv_crown_form_names();
    adv_st_assert(_st, adv_crown_form_count() == array_length(_cnames),
        "crown form count disagrees with its own name array");
    var _seenCounts = [];
    for (var _c = 0; _c < array_length(_cnames); _c++) {
        var _hp = adv_crown_head_parts(0, 0, 0.2, _c);
        adv_st_assert(_st, array_length(_hp) >= 4,
            "crown form " + _cnames[_c] + " draws only " + string(array_length(_hp))
            + " parts - the switch has no arm for it and it fell through to the default");
        array_push(_seenCounts, array_length(_hp));
        // Every head carries the dark/bright eye PAIR. `ink` alone resolves pale on a mid-dark hide.
        var _deep = 0, _brt = 0;
        for (var _q = 0; _q < array_length(_hp); _q++) {
            if (_hp[_q].role == "deep")   _deep++;
            if (_hp[_q].role == "bright") _brt++;
        }
        adv_st_assert(_st, _deep > 0 && _brt > 0,
            "crown form " + _cnames[_c] + " has no dark/bright eye pair (deep " + string(_deep)
            + ", bright " + string(_brt) + ")");
    }
    // ⛔⛔ THE FIRST VERSION OF THIS CHECK COULD NOT DETECT THE DEFECT IT WAS WRITTEN FOR, AND A
    // BREAK TEST IS THE ONLY REASON THAT IS KNOWN. It asserted "the forms do not ALL draw the same
    // number of parts", on the theory that a missing switch arm would show up as uniformity.
    // Deleting ONE arm (ADV_CROWN_FACETED) left the suite GREEN AT 4251/4251 - because the other
    // seven arms still differ from each other, so "not all the same" stays true no matter how many
    // individual forms fall through. It could only ever have fired if EVERY arm were missing at once.
    //
    // ⭐ The property that actually detects a fallthrough is PAIRWISE: a form with no arm renders the
    // DEFAULT, so it becomes byte-identical to the oculus. Compare each non-oculus form against the
    // default's own output and require a difference. Wing CLAUDE.md: "an assertion that goes red on
    // your sabotage is not the same as an assertion that would have caught your defect - check WHICH
    // cases fired", and this one fired on nothing at all.
    var _base = adv_crown_head_parts(0, 0, 0.2, ADV_CROWN_OCULUS);
    for (var _c2 = 0; _c2 < array_length(_cnames); _c2++) {
        if (_c2 == ADV_CROWN_OCULUS) continue;
        var _hp2 = adv_crown_head_parts(0, 0, 0.2, _c2);
        var _same = (array_length(_hp2) == array_length(_base));
        if (_same) {
            // Same part COUNT is not enough - compare the shapes themselves.
            for (var _z = 0; _z < array_length(_hp2); _z++) {
                if (_hp2[_z].kind != _base[_z].kind || _hp2[_z].role != _base[_z].role) {
                    _same = false;
                    break;
                }
            }
        }
        adv_st_assert(_st, !_same,
            "crown form " + _cnames[_c2] + " renders IDENTICALLY to the oculus default - it has no "
            + "switch arm and is falling through, so the corpus is quoting a head it cannot draw");
    }

    // 9c. A PLATE MAY NEVER OVERHANG THE CORE, and the CAP MUST HAVE A READER THAT CAN DISAGREE.
    // Wing CLAUDE.md, Lexicon: a silent correction leaves most of a corpus quietly drawn smaller
    // than its script asked for with nothing in the output saying so.
    var _corp = adv_corpus();
    var _capped = 0;
    var _phaseMoved = 0;
    for (var _i2 = 0; _i2 < array_length(_corp); _i2++) {
        var _plan = _corp[_i2];
        // ⚠️ SWEPT OVER EVERY PHASE, because the plating now RESPONDS to phase. Checking only the
        // WHOLE phase would leave the two damaged states — which is two thirds of the corpus and
        // the half a buyer sees late in a fight — verified by nobody.
        for (var _ph2 = 0; _ph2 < ADV_PHASES; _ph2++) {
            var _drawn = adv_armour_drawn_count(_plan, _ph2);
            adv_st_assert(_st, _drawn >= 1,
                _plan.id + " phase " + string(_ph2) + ": armour cap reduced the plate count to "
                + string(_drawn));
            adv_st_assert(_st, _drawn <= _plan.armour.plates,
                _plan.id + " phase " + string(_ph2) + ": armour drew MORE plates than declared");
            if (_ph2 == ADV_PHASE_WHOLE && _drawn < _plan.armour.plates) _capped++;

            // Containment, measured against the core's own outline rather than the unit box: a seam
            // is built from the half-width function, so this is the check that the two agree.
            var _ap = adv_armour_parts(_plan, _ph2);
            var _hw = _plan.core.w * 0.5;
            for (var _p2 = 0; _p2 < array_length(_ap); _p2++) {
                var _pts = _ap[_p2].pts;
                for (var _p3 = 0; _p3 < array_length(_pts); _p3++) {
                    var _py = _pts[_p3][1];
                    var _tt = clamp((_py + (_plan.core.h * 0.5)) / _plan.core.h, 0, 1);
                    var _lim = (adv_core_halfwidth_at(_plan, _tt) * _hw)
                             + abs(adv_core_lean_at(_plan, _tt)) + 0.02;
                    adv_st_assert(_st, abs(_pts[_p3][0]) <= _lim,
                        _plan.id + " phase " + string(_ph2) + ": a plate seam point at x "
                        + string(_pts[_p3][0]) + " lies outside the core's own span there ("
                        + string(_lim) + ")");
                }
            }
            adv_st_assert(_st, array_length(_ap) > 0,
                "VACUITY: " + _plan.id + " phase " + string(_ph2)
                + " drew no armour parts, so its containment check ran on nothing");
        }

        // ⛔ THE PHASES MUST ACTUALLY DIFFER, AND THIS IS THE ASSERTION THAT MAKES "42 BODIES" TRUE.
        // The listing quotes adv_corpus_bodies() = plans x ADV_PHASES. Until this session `_phase`
        // was read ONLY by the limb solver, so the core, the crown and the plating were identical
        // across all three and the count described fourteen bodies in three POSES. A derived count
        // is only honest if something downstream can disagree with it.
        // ⛔ MEASURE THE GEOMETRY, NOT THE PART COUNT. The first version of this assertion compared
        // adv_body_part_count between the two phases and went RED on colossus, golem and sentinel —
        // correctly reporting equal COUNTS and wrongly concluding the bodies were identical. On
        // those three the plate count is bound by `plates` rather than by the pitch cap, so shedding
        // coverage moves every seam and removes none: the shell peels back and the number of seams
        // stays put. A count is a proxy for "the body differs" and it is a bad one — the same shape
        // as this wing's law that a bounding box over several objects measures none of them.
        var _aw = adv_armour_parts(_plan, ADV_PHASE_WHOLE);
        var _ae = adv_armour_parts(_plan, ADV_PHASE_EXPOSED);
        var _moved = 0;
        var _pairs = min(array_length(_aw), array_length(_ae));
        for (var _m = 0; _m < _pairs; _m++) {
            var _pa = _aw[_m].pts, _pb = _ae[_m].pts;
            var _kk = min(array_length(_pa), array_length(_pb));
            for (var _m2 = 0; _m2 < _kk; _m2++) {
                if (abs(_pa[_m2][1] - _pb[_m2][1]) > ADV_ST_EPS) { _moved++; break; }
            }
        }
        if (_moved > 0) _phaseMoved++;
        adv_st_assert(_st, _moved > 0,
            _plan.id + ": not one plate seam moves between the WHOLE and EXPOSED phases, so the "
            + "phase does not reach the body and this plan contributes one body to the corpus "
            + "count rather than three");
        adv_st_assert(_st, _pairs > 0,
            "VACUITY: " + _plan.id + " has no plate seams to compare across phases");
    }
    adv_st_assert(_st, _phaseMoved == array_length(_corp),
        "only " + string(_phaseMoved) + " of " + string(array_length(_corp))
        + " plans change their body between phases");
    array_push(_st.notes, "core forms " + string(array_length(_forms))
        + ", closest pair " + _worstFormPair + " at " + string(_worstFormGap)
        + " (floor 0.04); crown forms " + string(adv_crown_form_count())
        + "; plans whose plate count was capped " + string(_capped));

    adv_st_stage(_st, 99);
    array_push(_st.notes, "smallest body part-count " + string(_minParts)
        + ", worst unit-box reach " + string(_worstReach));
    array_push(_st.notes, string(array_length(_hides)) + " materials, "
        + string(adv_palette_count()) + " palettes");
    array_push(_st.notes, "worst tell coverage ratio " + string(_worstCover)
        + " (floor " + string(ADV_TELL_COVER_MIN) + ")");
    array_push(_st.notes, "worst tell over-draw ratio " + string(_worstOver)
        + " (ceiling " + string(ADV_TELL_COVER_MAX) + ")");
    array_push(_st.notes, "telegraphing limb-instances swept " + string(_tellsSeen)
        + ", non-telegraphing " + string(_quietSeen));
    array_push(_st.notes, "corpus " + string(array_length(_corpus)) + " plans, "
        + string(adv_corpus_bodies()) + " bodies, " + string(adv_corpus_tells()) + " telegraphs");
    return _st;
}

/// Write the result where the harness can read it. %LOCALAPPDATA%\<Game>\ — the only route that
/// survives a release build.
function adv_selftest_write(_st) {
    var _f = file_text_open_write("adv_selftest.json");
    file_text_write_string(_f, "{");
    file_text_write_string(_f, "\"total\":" + string(_st.total));
    file_text_write_string(_f, ",\"pass\":" + string(_st.pass));
    file_text_write_string(_f, ",\"fail\":" + string(_st.fail));
    file_text_write_string(_f, ",\"stage\":" + string(_st.stage));
    file_text_write_string(_f, ",\"notes\":[");
    for (var _i = 0; _i < array_length(_st.notes); _i++) {
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "\"" + string_replace_all(_st.notes[_i], "\"", "'") + "\"");
    }
    file_text_write_string(_f, "],\"failures\":[");
    for (var _i = 0; _i < array_length(_st.failures); _i++) {
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "\"" + string_replace_all(_st.failures[_i], "\"", "'") + "\"");
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}
