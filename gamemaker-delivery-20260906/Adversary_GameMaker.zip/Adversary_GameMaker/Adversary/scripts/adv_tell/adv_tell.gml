/// adv_tell.gml — THE TELEGRAPHS. Every arc is derived from the limb that will swing.
///
/// ============================================================================================
/// NOTHING IN THIS FILE AUTHORS A NUMBER ABOUT WHERE AN ATTACK GOES.
/// ============================================================================================
/// The pivot, the radius and BOTH arc angles are read out of `adv_limb`'s solved chain. There is
/// no table of attack shapes anywhere in this package, and that absence is the product: a boss
/// asset that ships a telegraph as ART has to be re-drawn every time the arm changes, and a boss
/// asset that ships behaviour has no telegraph at all. Here, lengthen an arm and its tell grows on
/// the next frame, because the tell never knew the old length.
///
/// ⚠️ THE ARC ANGLES COME FROM THE SOLVER, NOT FROM `limb.ang`. Reading the rest angle out of the
/// limb record would be authoring the tell from the same field the body is authored from - which
/// sounds like the same thing and is not. The body applies the mirror, the phase fold and the
/// joint bend on top of `ang`, so the tip's actual bearing is nowhere in the record. Taking the
/// bearing of the SOLVED TIP is what makes the arc describe the limb that will really move.
///
/// ⛔ A LIMB THAT DOES NOT ATTACK MUST NOT TELEGRAPH. `adv_role_telegraphs` is the single
/// predicate, shared with `adv_body` - see the note on it in adv_corpus. A support leg drawing a
/// danger arc teaches the player to ignore danger arcs.

/// The telegraph for one limb, in core-relative units.
///
/// Returns `undefined` for a limb that does not telegraph. ⚠️ NAMED REFUSAL, not a silent zero:
/// wing CLAUDE.md records a bare `null` on eight distinct conditions making a hostile input, a
/// legitimate version skew and an outright defect indistinguishable. A caller that gets
/// `undefined` here knows exactly one thing is true, and `adv_tell_reason` will say which.
function adv_tell_arc(_plan, _limbIndex, _side, _phase) {
    var _limb = _plan.limbs[_limbIndex];
    if (!adv_role_telegraphs(_limb.role)) return undefined;

    // Pivot: joint 0 of the solved chain. Taken from the solver so it cannot drift from where the
    // limb is actually drawn attached.
    var _rest = adv_limb_joints(_plan, _limb, _side, _phase, 0);
    var _full = adv_limb_joints(_plan, _limb, _side, _phase, 1);
    var _cx = _rest[0][0];
    var _cy = _rest[0][1];

    // Both bearings are MEASURED off the solved tips.
    var _a0 = adv_tell_bearing(_cx, _cy, _rest[array_length(_rest) - 1]);
    var _a1 = adv_tell_bearing(_cx, _cy, _full[array_length(_full) - 1]);

    // Radius is the DECLARED reach. Independent of the swept measurement the suite checks it
    // against - see the two-sided bound in adv_limb.
    var _r = adv_limb_reach_declared(_limb);

    // ⭐ THE SWEPT PATH OF THE TERMINAL ITSELF, and this is the field that finally made the
    // telegraph stop reading as anatomy. `path[i]` is the limb's LAST SEGMENT - the claw, the fist,
    // the maw - solved at wind i/(n-1) and given in the same core-relative units as everything
    // else, so a renderer can ghost the striking end along the arc it will travel.
    //
    // ⛔ FIVE RENDERS OF THIS TELEGRAPH WERE REJECTED FOR READING AS A WING and every one of them
    // was an attempt to shade a REGION into looking like motion: a solid sector, an unmirrored
    // sector, radial hatching, concentric arcs, and a leading-edge gradient which turned out to be
    // the anatomy of a bat wing exactly. What none of them could do is show the THING THAT MOVES.
    // A repetition of the boss's own claw along a path cannot be read as a membrane, because it is
    // visibly the same claw four times.
    //
    // ⭐ AND IT IS THE PRODUCT'S OWN ARGUMENT MADE VISIBLE. Only a package that GENERATES the limb
    // can ghost that limb along its arc; a boss shipped as sprites has one image of the claw and
    // nowhere to put it. This is the coupling, drawn.
    var _path = [];
    for (var _g = 0; _g < ADV_TELL_GHOSTS; _g++) {
        var _js = adv_limb_joints(_plan, _limb, _side, _phase,
                                  _g / (ADV_TELL_GHOSTS - 1));
        var _nj = array_length(_js);
        array_push(_path, [_js[_nj - 2][0], _js[_nj - 2][1], _js[_nj - 1][0], _js[_nj - 1][1]]);
    }

    return {
        cx: _cx, cy: _cy, r: _r,
        a0: _a0, a1: _a1,
        limb: _limbIndex,
        role: _limb.role,
        term: _limb.term,
        kind: adv_tell_kind(_limb),
        path: _path
    };
}

/// Why a limb has no telegraph. Exists so a refusal can be reported rather than guessed at.
function adv_tell_reason(_plan, _limbIndex) {
    var _limb = _plan.limbs[_limbIndex];
    if (adv_role_telegraphs(_limb.role)) return "telegraphs";
    if (_limb.role == ADV_ROLE_SUPPORT) return "support limb - holds the body up, never strikes";
    if (_limb.role == ADV_ROLE_FLY)     return "wing or fin - moves the boss, does not strike";
    return "unknown role";
}

/// Bearing from the pivot to a solved joint.
///
/// ⚠️ `arctan2` and not a hand-rolled quadrant test. GML has no exponent-literal syntax and this
/// wing has burned two builds on tolerance arithmetic; the built-in is exact at the poles where a
/// hand-rolled version is not.
function adv_tell_bearing(_cx, _cy, _pt) {
    return arctan2(_pt[1] - _cy, _pt[0] - _cx);
}

/// What SHAPE of tell this is - and it is decided by the terminal form, so the shape of the
/// warning matches the thing that is about to hit you.
///
/// ⭐ This is the coupling at the level a player actually perceives it. A blade sweeps, so its tell
/// is a swept band. A fist lands, so its tell is an impact disc at the tip. A maw closes, so its
/// tell is a converging pair. A stinger stabs, so its tell is a line. None of these is authored
/// per boss: add a new plan whose arm ends in a blade and it sweeps, for free.
function adv_tell_kind(_limb) {
    switch (_limb.term) {
        case ADV_TERM_BLADE:   return ADV_TELL_SWEEP;
        case ADV_TERM_CLAW:    return ADV_TELL_SWEEP;
        case ADV_TERM_TALON:   return ADV_TELL_SWEEP;
        case ADV_TERM_FIST:    return ADV_TELL_IMPACT;
        case ADV_TERM_HOOF:    return ADV_TELL_IMPACT;
        case ADV_TERM_MAW:     return ADV_TELL_CLOSE;
        case ADV_TERM_STINGER: return ADV_TELL_THRUST;
        case ADV_TERM_FIN:     return ADV_TELL_SWEEP;
    }
    // ⛔ NO CLAMP HERE. Wing CLAUDE.md: "a clamp inside a lookup is a lookup that has given up" -
    // twelve materials above index 4 were all captioned "structural" because an 18-case switch was
    // indexed into a 6-entry array with the overflow clamped away. An unknown terminal is a defect
    // in the corpus, so it returns a value the suite tests for BY NAME rather than a plausible one.
    return ADV_TELL_NONE;
}

#macro ADV_TELL_NONE   -1
#macro ADV_TELL_SWEEP   0
#macro ADV_TELL_IMPACT  1
#macro ADV_TELL_CLOSE   2
#macro ADV_TELL_THRUST  3

function adv_tell_kind_names() {
    return ["sweep", "impact", "close", "thrust"];
}

/// Every telegraph a plan produces in a given phase. The count is DERIVED, never typed - it is
/// part of the volume claim on the store listing.
function adv_tell_all(_plan, _side, _phase) {
    var _out = [];
    for (var _i = 0; _i < array_length(_plan.limbs); _i++) {
        var _t = adv_tell_arc(_plan, _i, _side, _phase);
        if (!is_undefined(_t)) array_push(_out, _t);
    }
    return _out;
}

/// The angular width the tell sweeps through, always positive and always the SHORT way round.
///
/// ⛔ THE SHORT WAY IS NOT A DETAIL. A limb swinging through 0.4 radians and one swinging through
/// 5.9 radians the other way are the same two endpoints; drawing the wrong one paints a danger
/// band across ground the boss will never reach, on the side the player is standing on.
function adv_tell_span(_tell) {
    var _d = _tell.a1 - _tell.a0;
    while (_d >  pi) _d -= (2 * pi);
    while (_d < -pi) _d += (2 * pi);
    return abs(_d);
}

/// ⚠️ A DEGENERATE TELL IS A REAL FAILURE AND IT LOOKS LIKE NOTHING AT ALL. If a limb's rest and
/// wound tips land on the same bearing, the arc has zero span and draws as an invisible sliver -
/// so the attack lands with NO warning, which is the worst outcome this package can produce, and
/// no ink check can see it because absent ink between two marks is what a gap looks like. The
/// suite asserts a floor on every telegraph's span for that reason.
#macro ADV_TELL_SPAN_MIN 0.18


/// ================================================================================================
/// DRAWING THE TELL. ONE renderer, shipped, used by the demo room and by the store bakes alike.
/// ================================================================================================
///
/// ⛔ THIS FUNCTION EXISTS BECAUSE THERE WERE TWO OF IT, AND THE ONE A BUYER RUNS WAS THE REJECTED
/// ONE. `adv_bake` carried a four-layer renderer that three separate bakes had been spent tuning,
/// and `obj_adv_demo`'s Draw event - the room a buyer actually opens - carried a private copy that
/// was still the FIRST version: a flat 0.16 sector from the pivot plus a bright rim, which is
/// precisely the read this wing measured as A CAPE and then fixed, twice. The demo's own header
/// opens "THE DEMO DOES NOT RE-DERIVE ANYTHING ... one reader, one truth", so the file was
/// asserting the rule in prose while breaking it four lines down. Nothing could see it: both
/// copies drew a correct arc from correct geometry, and the sheets a review opens are baked by the
/// GOOD copy. Found by reading the demo while fixing the bake.
///
/// ⭐ AND IT MAKES THIS A MORE COMPLETE PRODUCT, WHICH IS THE REASON IT LIVES HERE RATHER THAN IN
/// THE BAKE. `adv_tell_arc` handed a buyer four numbers and left them to write their own draw call
/// - so the half of the coupling a PLAYER sees was the half this package did not ship. Now the
/// telegraph draws itself, in the same ink the store images show.
///
/// ================================================================================================
/// ⛔⛔ FIVE RENDERS OF THIS THING WERE REJECTED FOR READING AS A WING, AND EVERY ONE OF THE FIVE
/// FIXES CHANGED THE INTERIOR OF A FILLED SECTOR. THE SECTOR WAS THE PROBLEM.
/// ================================================================================================
///   (a) a solid sector mirrored to both sides   -> a CAPE, then a pair of BUTTERFLY WINGS;
///   (b) the same sector unmirrored              -> ONE folded wing, on nine of fourteen;
///   (c) RADIAL hatching, on the theory that "nothing grown is hatched"
///                                               -> a PLEATED FAN. Falsified by the next bake and
///       falsifiable before it was written: an insect wing IS radially veined from its base;
///   (d) concentric arcs across the span, over a flat 0.12 fill  -> still a fan on all fourteen;
///   (e) a GRADIENT, loudest at the leading edge and dissolving backward, on the theory that "a
///       membrane is a UNIFORM fill bounded by two radial edges"  -> A BAT WING. Worse than (d),
///       and worse for the most instructive reason in the series: a hard bright LEADING EDGE with
///       a soft trailing membrane is not merely compatible with a wing, it is the anatomy of one.
///
/// ⭐ WHAT ALL FIVE SHARE IS THE SILHOUETTE, AND THE ANSWER WAS ALREADY WRITTEN IN THIS FILE.
/// `adv_tell_kind` has said since the first build that there are FOUR shapes of tell and that the
/// shape is decided by the TERMINAL - a blade sweeps, a fist lands, a maw closes, a stinger stabs -
/// with the comment "this is the coupling at the level a player actually perceives it". Nothing
/// ever read it. The renderer drew one pie for all four, so the product's own model reached the
/// screen as a single generic wedge, and the wedge was a wing. Fixing the render and honouring the
/// model turn out to be the same edit.
///
/// ⛔ AND THE SAFETY POSITION HAS TO BE RESTATED HONESTLY RATHER THAN ASSUMED, because the earlier
/// version of this header called a hollow arc "a lie about safety" and used that to justify keeping
/// the fill. The promise a telegraph makes is about GROUND THE PLAYER MIGHT STAND ON. Inside
/// ADV_TELL_INNER of the pivot is the boss's own torso and the root of its own limb - both DRAWN,
/// both opaque, both visible - so marking it tells a player nothing they cannot already see, and
/// the swept region outside it is covered by bands whose radial gaps are asserted to stay under
/// ADV_TELL_GAP_MAX. That is a narrower claim than "the whole sector is tinted" and it is one the
/// suite can actually check; the old one was checkable by nobody.
///
/// Returns the number of layers drawn, so a caller can assert it drew something.
function adv_tell_draw(_tell, _pal, _ox, _oy, _s) {
    var _tr = _tell.r * _s;
    // ⚠️ NOT a silent early return on a degenerate radius - a sub-pixel arc is a real defect
    // upstream and the suite tests for it by name. This only avoids dividing by it.
    if (_tr <= 1) return 0;

    switch (_tell.kind) {
        case ADV_TELL_SWEEP:  return adv_tell_draw_sweep(_tell, _pal, _ox, _oy, _s);
        case ADV_TELL_IMPACT: return adv_tell_draw_impact(_tell, _pal, _ox, _oy, _s);
        case ADV_TELL_CLOSE:  return adv_tell_draw_close(_tell, _pal, _ox, _oy, _s);
        case ADV_TELL_THRUST: return adv_tell_draw_thrust(_tell, _pal, _ox, _oy, _s);
    }
    // ⛔ NO FALLBACK SHAPE. Drawing a plausible default for an unknown kind is how a generic wedge
    // came to stand in for four distinct tells in the first place. ADV_TELL_NONE is a corpus defect
    // and adv_selftest fails on it by name.
    return 0;
}

/// SWEEP - a blade, claw, talon or fin travelling through an arc.
///
/// Concentric BANDS with radial gaps between them, and nothing at all inside ADV_TELL_INNER. A
/// membrane cannot have holes across its own span and cannot be detached from the joint it hangs
/// from, so this is the one construction none of (a)-(e) could reach.
function adv_tell_draw_sweep(_tell, _pal, _ox, _oy, _s) {
    var _tx = _ox + (_tell.cx * _s);
    var _ty = _oy + (_tell.cy * _s);
    var _tr = _tell.r * _s;
    var _d  = adv_tell_span_signed(_tell);
    var _bands = adv_tell_bands();

    draw_set_alpha(1);
    draw_primitive_begin(pr_trianglelist);
    for (var _bi = 0; _bi < array_length(_bands); _bi++) {
        var _ra = _tr * _bands[_bi][0];
        var _rb = _tr * _bands[_bi][1];
        // The outermost band is where the terminal itself travels, so it is the loudest.
        var _base = ADV_TELL_FILL * lerp(0.72, 1.0, _bi / max(1, array_length(_bands) - 1));
        for (var _q = 0; _q < ADV_SWEEP_N; _q++) {
            var _u0 = _q / ADV_SWEEP_N;
            var _u1 = (_q + 1) / ADV_SWEEP_N;
            var _c0 = cos(_tell.a0 + (_d * _u0)), _n0 = sin(_tell.a0 + (_d * _u0));
            var _c1 = cos(_tell.a0 + (_d * _u1)), _n1 = sin(_tell.a0 + (_d * _u1));
            var _k0 = _base * adv_tell_ink(_u0);
            var _k1 = _base * adv_tell_ink(_u1);
            draw_vertex_colour(_tx + _c0 * _ra, _ty + _n0 * _ra, _pal.tell, _k0);
            draw_vertex_colour(_tx + _c0 * _rb, _ty + _n0 * _rb, _pal.tell, _k0);
            draw_vertex_colour(_tx + _c1 * _rb, _ty + _n1 * _rb, _pal.tell, _k1);
            draw_vertex_colour(_tx + _c0 * _ra, _ty + _n0 * _ra, _pal.tell, _k0);
            draw_vertex_colour(_tx + _c1 * _rb, _ty + _n1 * _rb, _pal.tell, _k1);
            draw_vertex_colour(_tx + _c1 * _ra, _ty + _n1 * _ra, _pal.tell, _k1);
        }
    }
    draw_primitive_end();

    adv_tell_ghost(_tell, _pal, _ox, _oy, _s, _tr);
    adv_tell_landing(_tell, _pal, _tx, _ty, _tr, _d);
    draw_set_alpha(1);
    return 3;
}

/// The onion-skin: the limb's own striking end, drawn along the path it will travel.
///
/// ⚠️ THE BANDS UNDER THIS ARE THE SAFETY REGION AND THIS IS THE FIGURE. Their alphas are set on
/// that split - the bands say WHERE, quietly and completely, and the ghosts say WHAT IS COMING and
/// carry the read. Raising the bands to compete with the ghosts is how a swept region became a
/// striped wing on the fourth attempt.
function adv_tell_ghost(_tell, _pal, _ox, _oy, _s, _tr) {
    var _n = array_length(_tell.path);
    if (_n < 2) return 0;
    var _w = max(2, _tr * 0.055);
    for (var _g = 0; _g < _n; _g++) {
        var _t = _g / (_n - 1);
        var _p = _tell.path[_g];
        draw_set_colour((_g == _n - 1) ? _pal.tellcore : _pal.tell);
        draw_set_alpha(0.14 + (0.80 * _t * _t));
        draw_line_width(_ox + (_p[0] * _s), _oy + (_p[1] * _s),
                        _ox + (_p[2] * _s), _oy + (_p[3] * _s), _w * (0.55 + (0.45 * _t)));
    }
    draw_set_alpha(1);
    return _n;
}

/// IMPACT - a fist or a hoof. It does not sweep ground, it ARRIVES somewhere, so the mark is at the
/// place it lands and the arc is reduced to the short trail that says where it came in from.
function adv_tell_draw_impact(_tell, _pal, _ox, _oy, _s) {
    var _tx = _ox + (_tell.cx * _s);
    var _ty = _oy + (_tell.cy * _s);
    var _tr = _tell.r * _s;
    var _d  = adv_tell_span_signed(_tell);
    var _ae = _tell.a0 + _d;
    var _hx = _tx + cos(_ae) * _tr;
    var _hy = _ty + sin(_ae) * _tr;
    var _hr = _tr * 0.26;
    var _lw = max(2, _tr * 0.022);

    // Where it comes in from: the fist itself, ghosted along its travel.
    adv_tell_ghost(_tell, _pal, _ox, _oy, _s, _tr);

    // The landing itself: two rings and a core, centred where the terminal ends up.
    draw_set_colour(_pal.tell);
    draw_set_alpha(0.30);
    draw_circle(_hx, _hy, _hr, false);
    draw_set_colour(_pal.tellcore);
    draw_set_alpha(0.95);
    draw_circle(_hx, _hy, _hr, true);
    draw_circle(_hx, _hy, _hr * 0.55, true);
    draw_set_alpha(1);
    draw_line_width(_hx - _hr * 0.30, _hy, _hx + _hr * 0.30, _hy, _lw);
    draw_line_width(_hx, _hy - _hr * 0.30, _hx, _hy + _hr * 0.30, _lw);
    draw_set_alpha(1);
    return 3;
}

/// CLOSE - a maw. Two jaws converging on one point, so the mark is a PAIR that meets.
function adv_tell_draw_close(_tell, _pal, _ox, _oy, _s) {
    var _tx = _ox + (_tell.cx * _s);
    var _ty = _oy + (_tell.cy * _s);
    var _tr = _tell.r * _s;
    var _d  = adv_tell_span_signed(_tell);
    var _ae = _tell.a0 + _d;
    var _lw = max(2, _tr * 0.024);
    var _gape = abs(_d) * 0.5 + 0.16;

    // ⚠️ ALPHAS RAISED AFTER LOOKING AT THE TELLS PLATE. Scaled off ADV_TELL_FILL they came out at
    // 0.17-0.38 - correct for a SWEEP, where the bands are a substrate under a ghost trail, and
    // wrong here, where these ticks ARE the figure. A constant reused across two roles is a constant
    // tuned for one of them.
    draw_set_colour(_pal.tell);
    for (var _jaw = -1; _jaw <= 1; _jaw += 2) {
        // Each jaw is a chord of ticks that narrows as it approaches the closing line.
        for (var _q = 0; _q < 7; _q++) {
            var _t = _q / 6;
            var _a = _ae + (_jaw * _gape * (1 - _t));
            var _r0 = _tr * lerp(0.40, 0.94, _t);
            draw_set_alpha(0.42 + (0.50 * _t));
            draw_line_width(_tx + cos(_a) * _r0, _ty + sin(_a) * _r0,
                            _tx + cos(_a) * (_r0 + _tr * 0.13),
                            _ty + sin(_a) * (_r0 + _tr * 0.13), _lw * 1.25);
        }
    }
    // The jaws themselves, ghosted in along the arc, so the mark belongs to a thing that moves.
    adv_tell_ghost(_tell, _pal, _ox, _oy, _s, _tr);
    // Where the two jaws meet is the only place a player is bitten.
    draw_set_colour(_pal.tellcore);
    draw_set_alpha(1);
    var _hx = _tx + cos(_ae) * _tr;
    var _hy = _ty + sin(_ae) * _tr;
    draw_circle(_hx, _hy, _tr * 0.075, false);
    draw_set_alpha(0.90);
    draw_line_width(_tx + cos(_ae) * (_tr * 0.40), _ty + sin(_ae) * (_tr * 0.40), _hx, _hy,
                    _lw * 1.2);
    draw_set_alpha(1);
    return 4;
}

/// THRUST - a stinger. It goes in a straight line and it goes THERE, so the mark is a lance with
/// chevrons pointing the way, and it has no width to dodge sideways out of.
function adv_tell_draw_thrust(_tell, _pal, _ox, _oy, _s) {
    var _tx = _ox + (_tell.cx * _s);
    var _ty = _oy + (_tell.cy * _s);
    var _tr = _tell.r * _s;
    var _d  = adv_tell_span_signed(_tell);
    var _ae = _tell.a0 + _d;
    var _ca = cos(_ae), _na = sin(_ae);
    var _px = -_na, _py = _ca;        // unit normal to the thrust line
    var _lw = max(2, _tr * 0.022);

    draw_set_alpha(1);
    draw_primitive_begin(pr_trianglelist);
    var _n0 = ADV_TELL_INNER, _n1 = 1.0;
    for (var _q = 0; _q < 8; _q++) {
        var _t0 = _q / 8, _t1 = (_q + 1) / 8;
        var _u0 = lerp(_n0, _n1, _t0) * _tr, _u1 = lerp(_n0, _n1, _t1) * _tr;
        // ⚠️ 0.085 -> 0.125 AND 1.5x -> 2.4x AFTER LOOKING AT THE TELLS PLATE, for the same reason
        // as the jaw ticks above: a width and an alpha derived from the SWEEP's substrate constant
        // are wrong wherever the mark is the figure rather than the ground under one.
        var _w0 = _tr * 0.125 * (1 - (_t0 * 0.85)), _w1 = _tr * 0.125 * (1 - (_t1 * 0.85));
        var _k0 = ADV_TELL_FILL * 2.4 * adv_tell_ink(_t0);
        var _k1 = ADV_TELL_FILL * 2.4 * adv_tell_ink(_t1);
        var _ax = _tx + _ca * _u0, _ay = _ty + _na * _u0;
        var _bx = _tx + _ca * _u1, _by = _ty + _na * _u1;
        draw_vertex_colour(_ax + _px * _w0, _ay + _py * _w0, _pal.tell, _k0);
        draw_vertex_colour(_bx + _px * _w1, _by + _py * _w1, _pal.tell, _k1);
        draw_vertex_colour(_bx - _px * _w1, _by - _py * _w1, _pal.tell, _k1);
        draw_vertex_colour(_ax + _px * _w0, _ay + _py * _w0, _pal.tell, _k0);
        draw_vertex_colour(_bx - _px * _w1, _by - _py * _w1, _pal.tell, _k1);
        draw_vertex_colour(_ax - _px * _w0, _ay - _py * _w0, _pal.tell, _k0);
    }
    draw_primitive_end();

    draw_set_colour(_pal.tellcore);
    for (var _c = 0; _c < 3; _c++) {
        var _u = lerp(ADV_TELL_INNER + 0.08, 0.86, _c / 2) * _tr;
        var _wv = _tr * 0.105;
        draw_set_alpha(0.55 + (0.20 * _c));
        draw_line_width(_tx + _ca * _u + _px * _wv, _ty + _na * _u + _py * _wv,
                        _tx + _ca * (_u + _tr * 0.10), _ty + _na * (_u + _tr * 0.10), _lw);
        draw_line_width(_tx + _ca * _u - _px * _wv, _ty + _na * _u - _py * _wv,
                        _tx + _ca * (_u + _tr * 0.10), _ty + _na * (_u + _tr * 0.10), _lw);
    }
    draw_set_alpha(1);
    draw_circle(_tx + _ca * _tr, _ty + _na * _tr, _tr * 0.055, false);
    draw_set_alpha(1);
    return 3;
}

/// The landing mark shared by the swept kinds: a bright tick across the outer band exactly where
/// the terminal ends up, plus the radial line that says which end of the arc is the end.
///
/// ⚠️ RADIAL, AND ONLY AT THE LEADING END. A radial line at BOTH ends closes the region into a
/// wedge, which is the outline this whole file exists to avoid; one of them is a direction.
function adv_tell_landing(_tell, _pal, _tx, _ty, _tr, _d) {
    var _ae = _tell.a0 + _d;
    var _lw = max(2, _tr * 0.022);
    var _bands = adv_tell_bands();
    var _in = _bands[array_length(_bands) - 1][0];
    draw_set_colour(_pal.tellcore);
    draw_set_alpha(1);
    draw_line_width(_tx + cos(_ae) * (_tr * _in), _ty + sin(_ae) * (_tr * _in),
                    _tx + cos(_ae) * (_tr * 1.02), _ty + sin(_ae) * (_tr * 1.02), _lw * 1.5);
    draw_circle(_tx + cos(_ae) * _tr, _ty + sin(_ae) * _tr, _tr * 0.045, false);
}

/// The signed sweep, short way round. `adv_tell_span` returns the magnitude because that is what a
/// bound is tested against; drawing needs the DIRECTION, and three call sites had their own copy of
/// this six-line normalisation.
function adv_tell_span_signed(_tell) {
    var _d = _tell.a1 - _tell.a0;
    while (_d >  pi) _d -= (2 * pi);
    while (_d < -pi) _d += (2 * pi);
    return _d;
}

/// The radial bands a SWEEP is drawn as, in fractions of the reach, inner..outer.
///
/// ⛔ THE RENDERER AND THE SAFETY ASSERTION READ THIS SAME ARRAY. Wing CLAUDE.md's sixth-of-a-family
/// rule: a check that re-states a number instead of re-deriving it certifies the copy it holds, not
/// the thing it is about. If someone widens a gap here to make the picture prettier, the coverage
/// assertion in adv_selftest goes red on the value that was actually changed.
/// ⭐ AND THE ASSERTION CAUGHT THIS TABLE, WHICH IS THE ONLY REASON IT IS WORTH HAVING. The first
/// version was `[[0.34,0.47],[0.55,0.68],[0.76,0.89],[0.94,1.00]]` and the suite went RED on it: the
/// rim band was 0.06 wide while the widest gap was 0.08, so the HOLES were the biggest feature of
/// the figure and the run of bands stopped reading as one region. Three bands instead of four, and
/// the outermost is now the widest - which is also where it belongs, because that is the ring the
/// terminal itself travels. ⛔ The bar was not moved to fit the table; the table was moved to fit
/// the bar, and the bar was pre-registered before either.
function adv_tell_bands() {
    static _b = undefined;
    if (!is_undefined(_b)) return _b;
    _b = [[0.34, 0.48], [0.56, 0.70], [0.78, 1.00]];
    return _b;
}

/// How loud the mark is at angular position `_u` along the sweep: 0 at the trailing bearing (where
/// the limb is now) and 1 at the leading one (where it lands).
///
/// ⛔ A PURE FUNCTION SO THAT THE ONE CLAIM THAT MATTERS CAN BE ASSERTED AT ALL. Everything else in
/// this file is a draw call the suite cannot see - GML has no headless renderer, so a property that
/// exists only inside a Draw event is a property only a human eye can check, and there is no human.
///
/// ⚠️ THE TRAILING END IS SWEPT FIRST, SO IT IS DANGEROUS FIRST. It may be QUIETER than the leading
/// end - that is the direction cue, and the only cue that says which way the blow is coming - and
/// it may never be ABSENT.
function adv_tell_ink(_u) {
    var _a = clamp(_u, 0, 1);
    return ADV_TELL_INK_FLOOR + ((1 - ADV_TELL_INK_FLOOR) * (_a * _a));
}

/// ⚠️ 0.46 -> 0.24 AFTER LOOKING AT A BAKE. At 0.46 the bands were the loudest thing in the figure
/// and fourteen bosses grew a STRIPED wing - the fourth of five rejected reads, and the reason the
/// ghost trail exists. The bands are the safety substrate; the ghosts are the figure.
#macro ADV_TELL_FILL   0.24   // alpha of a band at its LOUDEST point (the leading end of the sweep).
#macro ADV_TELL_INK_FLOOR 0.34
#macro ADV_TELL_GHOSTS 5      // onion-skin samples of the striking end along its own path.
/// Nothing is marked inside this fraction of the reach. It is the boss's own torso and the root of
/// its own limb: drawn, opaque, and visible, so a mark there tells a player nothing new.
#macro ADV_TELL_INNER  0.34

/// ⛔ THE SAFETY BAR, AND IT IS PRE-REGISTERED RATHER THAN FITTED. A player reads a run of bands as
/// one region only while the gaps stay small against the bands; a gap wider than this is a corridor
/// they will believe is safe. 0.12 of the reach is under the narrowest band (0.13) BY CONSTRUCTION,
/// so a gap can never be the widest thing in the figure. The measured worst gap in
/// `adv_tell_bands` is 0.08, so the bar can fail and currently does not.
#macro ADV_TELL_GAP_MAX 0.12
