{
  "$GMScript": "v1",
  "%Name": "adv_shape",
  "name": "adv_shape",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}