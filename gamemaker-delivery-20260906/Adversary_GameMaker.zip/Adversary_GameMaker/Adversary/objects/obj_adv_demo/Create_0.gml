/// @description Adversary demo — and the headless self-test entry point.
///
/// ⛔ TWO ORDERING TRAPS, BOTH MEASURED BY THIS WING, BOTH FIXED HERE BY THE FIRST TEN LINES.
///
/// 1. A GML RUNTIME ERROR OPENS A MODAL DIALOG. Headless, nothing dismisses it, so the process
///    NEVER EXITS - an opaque 180-second hang with no output and no clue. The handler below turns
///    that into a recorded stage number and a clean exit, which is what took one such hang from
///    "the build is broken somehow" to "CRASH at stage 5: Variable Index [25] out of range [25]".
///
/// 2. AN EARLY EXIT IN Create SKIPS SETUP THAT Clean Up STILL DEPENDS ON - AND CLEAN UP ALWAYS
///    RUNS. The -selftest path calls game_end() partway down this event, and GameMaker fires
///    CleanUp on the way out anyway. A variable declared BELOW the early exit but read in CleanUp
///    reports "not set before reading it" against THE LAST STAGE THE SUITE REACHED, i.e. a crash
///    attributed to code that had already finished and passed. So every variable any later event
///    reads is declared ABOVE the early exit, and CleanUp guards with variable_instance_exists.

exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("adv_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.adv_stage) + ": " + _ex.message);
    file_text_close(_f);
    game_end();
});

global.adv_stage = 0;

// ⛔ DECLARED ABOVE THE EARLY EXIT. See trap 2 in the header.
demo_plan  = 0;
demo_phase = ADV_PHASE_WHOLE;
demo_wind  = 0;
demo_dir   = 1;
demo_paused = false;

// ---------------------------------------------------------------------------------------------
// Headless self-test: `Adversary.exe -selftest`
// ---------------------------------------------------------------------------------------------
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";

if (string_pos("-bake", _args) > 0) {
    global.adv_stage = 200;
    adv_bake_all();
    game_end();
    exit;
}

if (string_pos("-gif", _args) > 0) {
    global.adv_stage = 300;
    adv_gif_all();
    game_end();
    exit;
}

if (string_pos("-selftest", _args) > 0) {
    global.adv_stage = 1;
    var _st = adv_selftest_run();
    global.adv_stage = _st.stage;
    adv_selftest_write(_st);
    game_end();
    exit;
}

// ---------------------------------------------------------------------------------------------
// Interactive demo. A runnable demo room is MANDATORY in this wing: it is the buyer's quickstart,
// the GIF source, and the only real smoke test a GML product has.
// ---------------------------------------------------------------------------------------------
window_set_caption("Adversary — boss bodies and the telegraphs that belong to them");
