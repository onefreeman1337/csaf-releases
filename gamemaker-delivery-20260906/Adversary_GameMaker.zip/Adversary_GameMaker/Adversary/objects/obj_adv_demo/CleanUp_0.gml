/// @description Teardown.
///
/// ⛔ CLEAN UP ALWAYS RUNS, INCLUDING AFTER AN EARLY `exit` IN Create. The -selftest path calls
/// game_end() partway down Create, and GameMaker fires this event on the way out regardless. This
/// wing has already paid for that: a cache variable declared below the early exit and freed here
/// reported "not set before reading it" AGAINST THE LAST STAGE THE SUITE HAD REACHED - a crash
/// attributed to code that had already finished and passed, sending the next session to the wrong
/// file entirely.
///
/// So: guard everything, even though Create currently declares these above its early exit. The
/// guard costs nothing and it survives somebody moving a declaration later.

if (variable_instance_exists(id, "demo_plan"))  demo_plan  = 0;
if (variable_instance_exists(id, "demo_phase")) demo_phase = 0;
if (variable_instance_exists(id, "demo_wind"))  demo_wind  = 0;
