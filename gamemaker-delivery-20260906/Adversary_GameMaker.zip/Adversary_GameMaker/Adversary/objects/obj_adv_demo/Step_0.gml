/// @description Drive the wind-up cycle and the demo controls.
///
/// The wind parameter is the SAME `_wind` the telegraph is swept by, so what is on screen at any
/// instant is one moment of one attack: the limb at `demo_wind` and its tell at `demo_wind`
/// describe the same instant BY CONSTRUCTION, not by two animations somebody keeps in step.

if (keyboard_check_pressed(vk_space)) demo_paused = !demo_paused;

if (keyboard_check_pressed(vk_right)) demo_plan  = (demo_plan + 1) mod adv_corpus_count();
if (keyboard_check_pressed(vk_left))  demo_plan  = (demo_plan + adv_corpus_count() - 1) mod adv_corpus_count();
if (keyboard_check_pressed(vk_up))    demo_phase = (demo_phase + 1) mod ADV_PHASES;
if (keyboard_check_pressed(vk_down))  demo_phase = (demo_phase + ADV_PHASES - 1) mod ADV_PHASES;

if (!demo_paused) {
    demo_wind += demo_dir * 0.014;
    if (demo_wind >= 1) { demo_wind = 1; demo_dir = -1; }
    if (demo_wind <= 0) { demo_wind = 0; demo_dir =  1; }
}
