/// @description Draw the current boss and its telegraphs.
///
/// ⚠️ THE DEMO DOES NOT RE-DERIVE ANYTHING. An earlier version of this event sampled the core
/// spindle itself, with its own loop — and it was already wrong within the hour, because
/// `adv_core_lean_at` was added to the body layer and the demo's private copy knew nothing about
/// it. That is the exact defect this package exists to prevent, committed in the demo that
/// advertises the fix: wing CLAUDE.md records a corpus whose skeleton leaned while the drawn torso
/// stood upright, producing a detached head through three baked galleries. One reader, one truth.
///
/// ⛔ `draw_line_width` FLOORS EVERY STROKE AT 1.0 px WITH NO ANTIALIASING on this hardware, so a
/// sub-pixel width rasterises to dashes. Tone is carried by stroke COUNT and LENGTH, never width.

var _plan = adv_corpus()[demo_plan];
var _hide = adv_hides()[demo_plan mod adv_hide_count()];
var _pal  = adv_palette_for(_hide, demo_phase / max(1, ADV_PHASES - 1));

// ⛔ THE DEMO ROOM DRAWS THE SHIPPED ENCOUNTER FRAME, AND THAT IS A CORRECTION. This event used to
// put four lines of white debug text in the top-left corner over a boss on a flat background - i.e.
// the room a buyer opens first, and the room this wing's constitution calls "the buyer's quickstart,
// the GIF source, and the only real smoke test a GML product has", looked like coder art. Master
// CLAUDE.md §1.1a is explicit that the visual layer is a GATE and that the product must not look
// like the engine. `adv_hud` ships, so this is not dressing for a screenshot: it is the same code
// the buyer gets, drawing the same numbers the boss is drawn from.
var _st = adv_hud_floor(0, 0, room_width, room_height, _pal);
var _cx = _st.cx;
var _cy = _st.cy;
var _sc = _st.scale;

draw_set_font(fnt_adversary);
draw_set_halign(fa_left);
draw_set_valign(fa_top);

// -- telegraphs FIRST, under the body ------------------------------------------------------------
// ⛔ Painter's order is not a detail when the layers are translucent. A danger arc drawn OVER the
// boss obscures the thing the player is trying to read, which is the same defect as a flash drawn
// over the object it illuminates.
//
// ⛔⛔ THIS BLOCK USED TO BE FORTY LINES OF DRAW CALLS OF ITS OWN, AND THAT IS THE DEFECT THIS
// FILE'S HEADER SIX LINES ABOVE SAYS IT DOES NOT HAVE. `adv_bake` had spent three separate bakes
// tuning the telegraph render away from a flat sector that measured as A CAPE; this event kept a
// private copy of the flat sector, so the room a BUYER opens showed the version we rejected while
// the store sheets showed the version we shipped. The two could never disagree loudly - both drew
// a correct arc from correct geometry - and no gate in this wing can see a draw call at all. The
// renderer now lives in `adv_tell` beside `adv_tell_arc`, it is part of the public surface a buyer
// calls, and there is exactly one of it.
for (var _s = -1; _s <= 1; _s += 2) {
    for (var _j = 0; _j < array_length(_plan.limbs); _j++) {
        var _tell = adv_tell_arc(_plan, _j, _s, demo_phase);
        if (is_undefined(_tell)) continue;
        adv_tell_draw(_tell, _pal, _cx, _cy, _sc);
    }
}

// -- the boss ------------------------------------------------------------------------------------
var _parts = adv_body_parts(_plan, demo_phase, demo_wind);
adv_render_parts(_parts, _pal, _cx, _cy, _sc, 0, _sc, undefined);

// -- the encounter frame ---------------------------------------------------------------------
// ⛔ ASCII ONLY. The shipped fonts declare range 32..127, so any non-ASCII glyph draws as NOTHING
// AT ALL — no error, no missing-glyph box, just absence, which reads as a deliberate space. This
// wing shipped exactly that on a cover.
adv_hud_draw(_plan, _hide, _pal, demo_phase, adv_hud_demo_health(demo_phase, demo_wind), demo_wind,
             0, 0, room_width, room_height);

// The only debug text left, and it is the CONTROLS - which a demo room genuinely needs.
draw_set_font(fnt_adversary);
draw_set_colour(adv_oklch(0.58, 0.012, 258));
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_text(room_width * 0.035, room_height - (room_height * 0.042),
    "LEFT / RIGHT boss  (" + string(demo_plan + 1) + " of " + string(adv_corpus_count())
    + ")     UP / DOWN phase     SPACE pause     -     "
    + string(adv_corpus_bodies()) + " bodies, " + string(adv_corpus_tells())
    + " telegraphs, " + string(adv_palette_count()) + " palettes, "
    + string(array_length(_parts)) + " parts on screen, no sprites");
