# ADVERSARY — Multi-Phase Bosses That Draw Their Own Bodies And Their Own Tells

**A GameMaker boss system, written in pure GML. No sprites, no atlas, no PNG.**

A boss is a body plan: a core silhouette, a shell, a crown, and a list of limbs. Hand Adversary a
plan, a phase and a wind-up value and it returns the geometry for a whole creature — a core with a
real profile, plated armour that peels back as it breaks, limbs solved down a joint chain, and a
terminal on each one. Then it derives the **attack telegraph from the same limb record**, so the
warning always belongs to the arm that is about to swing.

- **GameMaker 2024.14+.** Built and gated against runtime `2024.14.4.268`.
- **Everything is `adv_`-prefixed.** No globals but the two documented knobs.

---

## The one thing this does that nothing else on the shelf does

The GameMaker asset shelf sells bosses in two halves and never couples them. The **art** half ships
a fixed boss you cannot alter. The **wiring** half ships behaviour with no body. Buy both and you
still keep them in sync by hand, forever — because the telegraph a player reads ("the left arm is
winding up") is authored in one place and the arm is drawn in another.

Here, a limb record is the only source of truth for both:

```gml
var _plan = adv_plan("colossus");
var _arc  = adv_tell_arc(_plan, 2, -1, ADV_PHASE_WHOLE);   // limb 2, left side, phase 0
```

`_arc` is `{ cx, cy, r, a0, a1, limb, role, term, kind }`. Its **pivot** is joint 0 of the solved
chain. Its **radius** is that limb's declared reach. Both **bearings** are measured off the solved
tip at rest and at full wind. Nothing in the package holds a second copy of any of it.

**Lengthen an arm and its tell grows on the next frame, because the tell never knew the old length.**
That is asserted, not claimed: the self-test sweeps every plan, phase, side and limb and requires
the telegraph radius to match the limb's **drawn** reach within a two-sided bound.

---

## Quickstart

1. In GameMaker: **Tools → Import Local Package**, pick `Adversary.yymps`, **Add All**, import.
2. Open **`rm_adv_demo`** and press Play. That room is the whole product driven by one object.
3. In your own code:

```gml
// Create
plan  = adv_plan("arachnid");
hide  = adv_hides()[3];
phase = ADV_PHASE_WHOLE;
wind  = 0;

// Step - drive `wind` 0 -> 1 over your wind-up, then fire
wind = min(1, wind + 0.04);

// Draw
var _pal = adv_palette_for(hide, adv_phase_damage(phase));

// Telegraphs first, under the body.
for (var _s = -1; _s <= 1; _s += 2) {
    for (var _j = 0; _j < array_length(plan.limbs); _j++) {
        var _t = adv_tell_arc(plan, _j, _s, phase);
        if (is_undefined(_t)) continue;              // this limb does not strike
        adv_tell_draw(_t, _pal, x, y, 160);          // 160 px = the boss's core height
    }
}
adv_render_parts(adv_body_parts(plan, phase, wind), _pal, x, y, 160, 0, 160, undefined);
```

Everything is in **core-relative units** — a limb's `len` is a fraction of the core's height — so
one scale argument sizes the whole creature and nothing needs re-authoring per resolution.

### The demo room's controls

| key | does |
| --- | --- |
| `Left` / `Right` | previous / next boss |
| `Up` / `Down` | previous / next phase |
| `Space` | pause the wind-up |

---

## The telegraph has four shapes, and the terminal decides which

This is the coupling at the level a player actually perceives it. `adv_tell_kind` reads the limb's
terminal form and the renderer draws that shape — none of it authored per boss:

| terminal | tell | what a player sees |
| --- | --- | --- |
| blade · claw · talon · fin | **sweep** | banded arcs through the ground the tip will cross, brightening toward the leading edge |
| fist · hoof | **impact** | a ringed landing mark where the blow arrives, with the last of its travel dashed in |
| maw | **close** | two jaws of ticks converging on the one point that bites |
| stinger | **thrust** | a tapering lance with chevrons, along the line it will go |

Add a plan whose arm ends in a blade and it sweeps, for free. A limb whose role is `SUPPORT` or
`FLY` draws **no** telegraph at all — `adv_tell_arc` returns `undefined` and `adv_tell_reason` says
why — because a support leg drawing a danger arc teaches the player to ignore danger arcs.

⚠️ **On the safety of the mark, stated plainly.** The swept region is drawn as bands with gaps
between them, and nothing is drawn inside 34% of the reach. That inner region is the boss's own
torso and the root of its own limb, both of which are drawn and opaque, so a mark there tells a
player nothing they cannot see. Outside it, the self-test asserts that no unmarked radial gap
exceeds 12% of the reach — narrower than the narrowest band, so a gap can never be the widest
feature of the figure and read as a corridor.

---

## The encounter frame

The package also ships the interface a boss is fought inside — `adv_hud`. A name plate, a health bar
**cut into `ADV_PHASES` segments** so the notches are where the boss becomes something else, phase
pips, a wind-up meter reading the same number the telegraph is swept by, a floor and a shadow.

```gml
var _st = adv_hud_floor(0, 0, room_width, room_height, _pal);   // ground + shadow, behind the boss
// ... draw telegraphs, then the boss, at _st.cx / _st.cy / _st.scale ...
adv_hud_draw(_plan, _hide, _pal, phase, health, wind, 0, 0, room_width, room_height);
```

**Every plate, rule, pip and bar takes its ink from the palette of the creature being fought**, so
the interface recolours per encounter for free — which a hand-drawn HUD sprite cannot do at all.

⚠️ **This package does not own combat.** `adv_hud_draw` takes health and wind as arguments; your
fight drives them. Nothing here decides damage, timing or state, because a HUD that owned the numbers
would be a combat framework wearing an asset's name and it would fight whatever you already have.

---

## Three phases, one set of numbers

`ADV_PHASES` is 3 and it is fixed on purpose: it is the shape a player learns. As a boss breaks,
the same numbers produce a different creature — the shell **peels back** from the tail so fewer
plates are drawn, the limbs fold, and `adv_palette_for` is passed the phase's damage so the
material itself dulls and darkens.

```gml
adv_armour_drawn_count(_plan, ADV_PHASE_WHOLE);   // e.g. 5
adv_armour_drawn_count(_plan, 2);                 // e.g. 3 — the shell has opened
```

It is not a palette swap and it is not a second sprite. There is no sprite.

---

## What is in the box

Every number below is returned by a function at run time, counted from the declarations rather than
typed into this file:

| | |
| --- | --- |
| boss plans | **14** — `adv_corpus_count()` |
| phases each | **3** — `ADV_PHASES` |
| distinct bodies | **42** — `adv_corpus_bodies()` |
| telegraphing limbs | **63** — `adv_corpus_tells()`, per side |
| materials | **10**, each a 12-stop ramp at absolute lightness |
| palettes | **30** — `adv_palette_count()`, materials × damage states |
| core silhouettes | **8** — spindle, anvil, bulb, drum, carapace, wedge, hourglass, lobed |
| terminal forms | **8** — claw, blade, maw, hoof, fist, stinger, fin, talon |
| telegraph shapes | **4** — sweep, impact, close, thrust |
| limb roles | **4** — strike, support, fly, grasp |

### The scripts

| script | what it owns |
| --- | --- |
| `adv_corpus` | the 14 plans, limb records, roles, terminals, and the derived counts |
| `adv_limb` | the joint solver, the eight core forms, reach declared vs reach drawn |
| `adv_body` | assembling a plan into a part list: core, shell, crown, limbs, phase fold |
| `adv_tell` | `adv_tell_arc`, the four tell kinds, and `adv_tell_draw` |
| `adv_hud` | the encounter frame: name plate, phase-segmented health bar, pips, wind meter, floor |
| `adv_hide` | the 10 materials, the ramp construction, damage dulling |
| `adv_palette` | Oklch colour |
| `adv_relief` | the lighting pass that makes a mass read as a surface |
| `adv_shape` · `adv_geom` | outlines, bevels, and the geometry predicates |
| `adv_render` | drawing part lists, fitting them to rects, baking to a sprite, text |
| `adv_bake` | the store sheets, rendered in engine — ships, so you can re-render them |
| `adv_selftest` | the assertion suite (see below) |

---

## Performance

Building a boss is geometry, not drawing, so build the part list **once** per pose and keep it.
`adv_render_to_sprite(parts, palette, w, h, pad)` bakes a part list to a real sprite you can draw
with `draw_sprite_ext` at no per-frame cost.

⚠️ The baked sprite is lit from the product's own fixed lamp, so rotating it rotates the lighting
with it. For a boss that turns, re-render rather than rotate the bake.

⚠️ **Do not bake the telegraph into a sprite.** It moves with the wind-up and it is drawn under the
body; it costs one `adv_tell_draw` call per striking limb per frame, which is a few dozen primitives.

---

## Namespacing

Every function, macro and asset begins with `adv_`, `ADV_`, `obj_adv_`, `rm_adv_` or `fnt_adversary`.
GML's global namespace is flat and a collision in your project is a support ticket nobody can debug
remotely, so nothing here is spelled in a way that could collide with yours.

It declares exactly **three globals**, all `adv_`-prefixed, and two of them are the documented lamp
knob meant for you:

| global | what it is |
| --- | --- |
| `global.adv_lx` · `global.adv_ly` | the lamp direction. Set with `adv_lamp_set(lx, ly)`, put back with `adv_lamp_reset()` |
| `global.adv_stage` | the self-test's progress marker |

⚠️ Counted with `grep -rhoE "global\.[A-Za-z_][A-Za-z0-9_]*"` over the shipped `.gml`, not from
memory. `variable_instance_get_names(global)` cannot answer this question — in GML 2.3+ every script
function is a global entry, so that list holds every `adv_` function too.

⚠️ `adv_lamp_set` changes the lighting for **everything** drawn afterwards. Call `adv_lamp_reset()`
before drawing anything you did not mean to relight, or one boss in a screenful is lit from below
and reads as a hole.

---

## Verification, stated honestly

GML cannot be unit-tested outside the engine, so this package tests itself **inside** it.
`adv_selftest` runs its assertions on a real Igor-built executable and writes the result to a file.
The engine gate is a real Igor package build: exit 0, 0 errors.

What that does and does not prove:

- ✅ It proves the geometry is well-formed — outlines simple and wound one way, every part inside
  the unit box, the core half-width never collapsing, every limb reaching what its telegraph
  promises, no telegraph degenerate to an invisible sliver, no support limb drawing a danger arc,
  and every count on this page derived from the arrays actually walked.
- ⛔ **It does not prove the picture is good.** Several defects in this package's history passed
  every assertion and were found only by rendering a sheet and looking at it — a whole corpus of
  fourteen creatures that were all the same egg, an armour block with no reader at all, and five
  successive telegraph renders that read as a wing. The assertions that would have caught each of
  those were written afterwards and are in the suite now.

---

## Translating it

Everything a player would read is in the demo and in `adv_bake`, not in the drawing code. Plan
names, material names, phase names and terminal names are **ids**, not display strings — map them
to your own language at your UI layer and nothing in the package needs editing.

⚠️ The two shipped fonts carry ASCII 32–126 only. A character outside that range draws **nothing**,
silently. If you need accented or non-Latin text, replace the font resources.

---

## Licence

See `LICENSE.txt`. Third-party font licences are in `fonts/THIRD-PARTY-NOTICES.txt` inside the
package — Open Sans, Apache-2.0.

**AI disclosure:** this product's code and graphics were produced with AI assistance. It is
disclosed on the store listing and stated here.

© Core Systems Asset Factory
