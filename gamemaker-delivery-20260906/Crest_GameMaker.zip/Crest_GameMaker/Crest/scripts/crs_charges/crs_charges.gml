/// ============================================================================================
/// CREST - crs_charges: THE CORPUS. 44 charges, authored in six orders.
///
/// This file is the product. Everything else in the package composes, colours or draws what is
/// authored here, and the volume of it is deliberate: 44 charges x 8 shields x 14 ordinaries is
/// 4,928 distinct arms before a single tincture is chosen, and none of it is a PNG.
///
/// -- READ Internal_Ops/Motif_Corpus.md FIRST ---------------------------------------------------
/// Every charge below has a SILHOUETTE NOTE in §3 of that document, and the note is the acceptance
/// criterion, not decoration: a charge is finished when, filled solid at 20 px inside a shield, it
/// is not confusable with any other charge in the corpus. The document was written before this file
/// existed. Amend it in the same edit when a charge changes.
///
/// -- WHY THESE ARE MASSES AND NOT LINE DRAWINGS ------------------------------------------------
/// ⛔ This is the single most expensive lesson this wing has paid for, and it is structural rather
/// than stylistic. The previous product authored its corpus as stroked outlines, passed 369
/// in-engine assertions, passed an extent check and passed an ink-bounds check - and the marks
/// rendered as GREY DUST at small sizes, because a stroke thinner than a pixel is drawn at partial
/// coverage and the shape never resolves. It was found by opening the PNG and looking.
///
/// So a charge here is built from FILLED MASSES - ellipses, fans and triangle strips - with at most
/// one interior line for the second read. A filled mass has no minimum width to lose. crs_selftest
/// asserts that every charge emits at least one solid op, so the corpus cannot regress to outlines
/// without the suite going red.
///
/// -- THE THREE DRAWING RULES (Motif_Corpus.md §1) -----------------------------------------------
///   1. Silhouette before detail. A lion at 20 px is a POSTURE, not a mane texture.
///   2. At most three levels of detail: contour -> one structural interior line -> texture.
///   3. Distinguish by POSTURE and PROFILE, never by species detail. lion/wolf/bear is the hardest
///      cluster in this corpus and it is resolved by three different silhouettes.
///
/// COORDINATES. Unit box [-0.5, 0.5] on both axes, y DOWN, origin at the charge's optical centre.
/// Nothing here flips an axis. The coordinate contract lives directly below and is re-checked by
/// Internal_Ops/check_charges.js (statically, before the engine will build) and by crs_selftest
/// (exactly, over the ops these functions actually return).
/// ============================================================================================

/// -- THE COORDINATE CONTRACT -------------------------------------------------------------------
///
/// CRS_CHARGE_BOX is a DISC, not a square: the extent test is hypot(x, y) <= BOX. A charge is placed
/// on shields of eight different outlines, and a square budget lets a corner escape a rounded one.
///
/// ⛔ AND THE CONTRACT MUST INCLUDE EVERY TERM THAT GROWS THE ART. The previous product's contract
/// counted one term and silently omitted the larger one, and PASSED the whole time - a checker that
/// omits a term does not report a smaller violation, it reports none at all. The terms here are
/// stated in full, and the third one is the one an inherited contract would have missed: a shield is
/// not a circle, so the space available to a charge is the largest disc that fits inside the
/// SHIELD'S OWN OUTLINE about the charge anchor, and that differs per shield. crs_shields declares
/// it per shape and crs_selftest measures the declaration against the real outline.
#macro CRS_CHARGE_BOX   0.50
#macro CRS_CHARGE_FIT   0.58
#macro CRS_FIELD_INSET  0.06

/// -- ROLES -------------------------------------------------------------------------------------
/// A part carries a role, never a colour. crs_tincture resolves a role against the arms being drawn,
/// which is what lets one charge appear in seven tinctures without the geometry knowing about any of
/// them - and what makes the rule of tincture enforceable in ONE place.
#macro CRS_R_FIELD   0
#macro CRS_R_ORD     1
#macro CRS_R_CHARGE  2
#macro CRS_R_DETAIL  3
#macro CRS_R_EDGE    4

/// ============================================================================================
/// THE CORPUS TABLE
/// ============================================================================================

/// The 44 charge ids, in order. Order boundaries: 0-9 / 9-15 / 15-23 / 23-31 / 31-38 / 38-44.
function crs_charge_ids() {
    return [
        // beast (9)
        "lion", "wolf", "bear", "boar", "stag", "horse", "serpent", "hound", "ram",
        // bird (6)
        "eagle", "raven", "falcon", "swan", "owl", "crane",
        // arms (8)
        "sword", "axe", "hammer", "arrow", "bow", "shieldwall", "helm", "caltrop",
        // craft (8)
        "anvil", "key", "wheel", "anchor", "ship", "chalice", "scales", "sheaf",
        // sacred (7)
        "sun", "crescent", "mullet", "flame", "eye", "tree", "lily",
        // land (6)
        "tower", "gate", "mount", "river", "bridge", "well"
    ];
}

/// The six orders. These are the buyer-facing grouping - a designer picks "a beast" before they
/// pick which beast - and they are what makes 44 charges navigable in a Readme.
function crs_order_ids() {
    return ["beast", "bird", "arms", "craft", "sacred", "land"];
}

/// What an order SAYS about a faction. Used by the panel and by crs_arms when deriving a charge
/// from a faction's traits, so the derivation is meaningful rather than a hash of the name.
function crs_order_meaning(_order) {
    switch (_order) {
        case "beast":  return "how it fights";
        case "bird":   return "what it watches";
        case "arms":   return "what it does to its enemies";
        case "craft":  return "what it makes";
        case "sacred": return "what it believes";
        default:       return "where it is from";
    }
}

/// The order an index belongs to. Boundaries are declared ONCE, here.
function crs_charge_order(_i) {
    if (_i <  9) return "beast";
    if (_i < 15) return "bird";
    if (_i < 23) return "arms";
    if (_i < 31) return "craft";
    if (_i < 38) return "sacred";
    return "land";
}

function crs_charge_count() {
    return array_length(crs_charge_ids());
}

/// Index of an id, or -1. Linear over 44 entries, called once per faction at registration, never
/// per frame - crs_arms caches the composed arms on the faction itself.
function crs_charge_index(_id) {
    var _ids = crs_charge_ids();
    for (var _i = 0; _i < array_length(_ids); _i++) if (_ids[_i] == _id) return _i;
    return -1;
}

/// The display name of a charge, in the heraldic register a buyer can put straight on screen.
function crs_charge_name(_id) {
    switch (_id) {
        case "lion":       return "Lion Rampant";
        case "wolf":       return "Wolf Courant";
        case "bear":       return "Bear Statant";
        case "boar":       return "Boar Charging";
        case "stag":       return "Stag at Gaze";
        case "horse":      return "Horse Forcene";
        case "serpent":    return "Serpent Nowed";
        case "hound":      return "Hound Sejant";
        case "ram":        return "Ram Statant";
        case "eagle":      return "Eagle Displayed";
        case "raven":      return "Raven Close";
        case "falcon":     return "Falcon Rising";
        case "swan":       return "Swan Naiant";
        case "owl":        return "Owl Affronty";
        case "crane":      return "Crane in its Vigilance";
        case "sword":      return "Sword Erect";
        case "axe":        return "War Axe";
        case "hammer":     return "War Hammer";
        case "arrow":      return "Arrow";
        case "bow":        return "Longbow Strung";
        case "shieldwall": return "Three Shields";
        case "helm":       return "Great Helm";
        case "caltrop":    return "Caltrop";
        case "anvil":      return "Anvil";
        case "key":        return "Key";
        case "wheel":      return "Cartwheel";
        case "anchor":     return "Anchor";
        case "ship":       return "Cog";
        case "chalice":    return "Chalice";
        case "scales":     return "Balance";
        case "sheaf":      return "Garb";
        case "sun":        return "Sun in Splendour";
        case "crescent":   return "Crescent";
        case "mullet":     return "Mullet Pierced";
        case "flame":      return "Flame";
        case "eye":        return "Open Eye";
        case "tree":       return "Tree Eradicated";
        case "lily":       return "Fleur-de-Lis";
        case "tower":      return "Tower";
        case "gate":       return "Gate";
        case "mount":      return "Mount";
        case "river":      return "Barrulet Wavy";
        case "bridge":     return "Bridge";
        case "well":       return "Wellhead";
        default:           return "";
    }
}

/// Build one charge's parts, in the unit box. THE dispatcher.
function crs_charge(_id) {
    switch (_id) {
        case "lion":       return crs_ch_lion();
        case "wolf":       return crs_ch_wolf();
        case "bear":       return crs_ch_bear();
        case "boar":       return crs_ch_boar();
        case "stag":       return crs_ch_stag();
        case "horse":      return crs_ch_horse();
        case "serpent":    return crs_ch_serpent();
        case "hound":      return crs_ch_hound();
        case "ram":        return crs_ch_ram();
        case "eagle":      return crs_ch_eagle();
        case "raven":      return crs_ch_raven();
        case "falcon":     return crs_ch_falcon();
        case "swan":       return crs_ch_swan();
        case "owl":        return crs_ch_owl();
        case "crane":      return crs_ch_crane();
        case "sword":      return crs_ch_sword();
        case "axe":        return crs_ch_axe();
        case "hammer":     return crs_ch_hammer();
        case "arrow":      return crs_ch_arrow();
        case "bow":        return crs_ch_bow();
        case "shieldwall": return crs_ch_shieldwall();
        case "helm":       return crs_ch_helm();
        case "caltrop":    return crs_ch_caltrop();
        case "anvil":      return crs_ch_anvil();
        case "key":        return crs_ch_key();
        case "wheel":      return crs_ch_wheel();
        case "anchor":     return crs_ch_anchor();
        case "ship":       return crs_ch_ship();
        case "chalice":    return crs_ch_chalice();
        case "scales":     return crs_ch_scales();
        case "sheaf":      return crs_ch_sheaf();
        case "sun":        return crs_ch_sun();
        case "crescent":   return crs_ch_crescent();
        case "mullet":     return crs_ch_mullet();
        case "flame":      return crs_ch_flame();
        case "eye":        return crs_ch_eye();
        case "tree":       return crs_ch_tree();
        case "lily":       return crs_ch_lily();
        case "tower":      return crs_ch_tower();
        case "gate":       return crs_ch_gate();
        case "mount":      return crs_ch_mount();
        case "river":      return crs_ch_river();
        case "bridge":     return crs_ch_bridge();
        case "well":       return crs_ch_well();
        default:           return [];
    }
}

/// ============================================================================================
/// AUTHORING HELPERS
///
/// Six shapes, and every charge in the corpus is built from them. That is deliberate: a corpus
/// assembled from a small shared vocabulary coheres, and a corpus where every entry invents its own
/// construction does not - which is the difference between 44 charges and 44 doodles.
/// ============================================================================================

/// A filled elliptical mass. The workhorse: a body, a head, a bowl, a canopy.
function crs_c_mass(_cx, _cy, _rx, _ry, _role) {
    return crs_ring_fill(crs_ellipse_pts(_cx, _cy, _rx, _ry, 24), _role, _cx, _cy);
}

/// A limb, haft, neck or stem: a tapered band along a point list. Tapering matters - a band of
/// constant width reads as extruded, which is the loudest tell of programmer art.
function crs_c_limb(_pts, _w0, _w1, _role) {
    return crs_taper_ribbon(_pts, _w0, _w1, _role);
}

/// A straight tapered limb between two points.
function crs_c_seg(_x0, _y0, _x1, _y1, _w0, _w1, _role) {
    var _p = array_create(3);
    for (var _i = 0; _i < 3; _i++) {
        var _t = _i / 2;
        _p[_i] = [lerp(_x0, _x1, _t), lerp(_y0, _y1, _t)];
    }
    return crs_taper_ribbon(_p, _w0, _w1, _role);
}

/// A triangular spike: a tooth, a ray, a tusk, an antler tine, an ear.
function crs_c_spike(_bx, _by, _tx, _ty, _half, _role) {
    var _dx = _tx - _bx, _dy = _ty - _by;
    var _l = point_distance(0, 0, _dx, _dy);
    if (_l == 0) _l = 1;
    var _nx = -_dy / _l * _half, _ny = _dx / _l * _half;
    return crs_fill([[_bx + _nx, _by + _ny], [_tx, _ty], [_bx - _nx, _by - _ny]], _role);
}

/// A ring of spikes over an angular span: a mane, a sun's rays, a crown of antlers.
/// Appends to _dst and returns it.
function crs_c_ruff(_dst, _cx, _cy, _r0, _r1, _a0, _a1, _n, _half, _role) {
    for (var _i = 0; _i < _n; _i++) {
        var _t = (_n == 1) ? 0.5 : (_i / (_n - 1));
        var _a = lerp(_a0, _a1, _t);
        array_push(_dst, crs_c_spike(_cx + cos(_a) * _r0, _cy + sin(_a) * _r0,
                                     _cx + cos(_a) * _r1, _cy + sin(_a) * _r1, _half, _role));
    }
    return _dst;
}

/// A quadrupedal stance: four legs from a body line down to a ground line. Shared by wolf, bear,
/// boar, stag, horse and ram, which is exactly why those six read as one family of animals rather
/// than six unrelated drawings - and why they can then be separated by POSTURE alone.
function crs_c_legs(_dst, _x0, _x1, _ytop, _ybot, _w, _splay, _role) {
    var _xs = [_x0, _x0 + (_x1 - _x0) * 0.22, _x1 - (_x1 - _x0) * 0.22, _x1];
    for (var _i = 0; _i < 4; _i++) {
        var _lean = ((_i < 2) ? -_splay : _splay);
        array_push(_dst, crs_c_seg(_xs[_i], _ytop, _xs[_i] + _lean, _ybot, _w, _w * 0.72, _role));
    }
    return _dst;
}

/// A sampled wave band: a river, a chief wavy, a streaming tail.
function crs_c_wave(_x0, _x1, _y, _amp, _cycles, _half, _role) {
    var _n = 40;
    var _p = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        _p[_i] = [lerp(_x0, _x1, _t), _y + sin(_t * CRS_TAU * _cycles) * _amp];
    }
    return crs_ribbon(_p, _half, _role);
}

/// ============================================================================================
/// 3.1  beast - 9
/// The hardest cluster in the corpus. lion / wolf / bear are separated by POSTURE, never by fur:
/// rampant-and-maned, low-and-long, heavy-with-round-ears.
/// ============================================================================================

/// lion - rampant, forepaws raised, maned head in profile.
/// 20px: a tall S-curve with a spiked collar of mane. The only rampant beast with a mane.
function crs_ch_lion() {
    // ⛔ REDRAWN 2026-08-22 AFTER LOOKING AT THE BAKED SHEET. The previous lion READ AS A RAT, at
    // 1600px, on the store's own hero image - and every mechanical check passed it, because the
    // silhouette suite measures whether the 44 marks are DISTINCT FROM EACH OTHER and has no
    // opinion on whether a mark is the animal it is named after. This wing has the identical
    // precedent on record from Charter, where `spring` and `geyser` satisfied their corpus notes
    // to the letter and read as a frying pan and a wine glass.
    //
    // What was actually wrong, and it was proportion rather than concept: a 0.095 skull against a
    // 0.14 body, and a MANE of 7 spikes reaching 0.155 - barely past the skull it is meant to
    // frame. A lion is a mane. It is drawn here as 15 spikes reaching 0.205, so the mane is the
    // largest single feature of the charge and is wider than the head by half again.
    var _p = [];
    array_push(_p, crs_c_mass(0.16, 0.21, 0.160, 0.180, CRS_R_CHARGE));          // haunch, heavier
    array_push(_p, crs_c_seg(0.18, 0.30, 0.19, 0.42, 0.064, 0.036, CRS_R_CHARGE)); // hind leg
    array_push(_p, crs_c_seg(0.19, 0.42, 0.07, 0.45, 0.036, 0.030, CRS_R_CHARGE)); // hind paw
    // The rearing body as ONE tapered S from haunch to shoulder, rather than a separate oval:
    // an oval chest reads as a second lump, which is most of why the old drawing looked rodent.
    array_push(_p, crs_c_limb(crs_qbez([0.15, 0.20], [0.03, 0.06], [-0.05, -0.10], 12),
                              0.175, 0.130, CRS_R_CHARGE));
    array_push(_p, crs_c_seg(-0.05, -0.07, -0.30, -0.14, 0.058, 0.032, CRS_R_CHARGE)); // upper paw
    array_push(_p, crs_c_seg(-0.04, 0.04, -0.27, 0.14, 0.054, 0.030, CRS_R_CHARGE));   // lower paw
    // THE MANE, drawn BEFORE the skull so the skull sits inside it as one silhouette.
    //
    // ⛔ SHORT TEETH ON A BIG HEAD, NOT LONG RAYS. The first redraw took "the mane must dominate"
    // literally and used 15 spikes running from 0.090 out to 0.205 - more than doubling the skull's
    // radius - and the baked sheet came back with A SUNBURST WHERE THE HEAD SHOULD BE. It was
    // worse than the rat it replaced, and it collided conceptually with `sun in splendour`, which
    // is exactly that shape on purpose.
    //
    // A lion's mane in silhouette is a ROUNDED RAGGED MASS. So: a large skull (0.135), and teeth
    // that project only ~0.04 past it. The mane still dominates - it is the widest thing in the
    // charge - but it dominates by AREA rather than by reach, which is the distinction the first
    // attempt missed.
    crs_c_ruff(_p, -0.15, -0.235, 0.115, 0.176, pi * 0.24, pi * 1.99, 20, 0.042, CRS_R_CHARGE);
    array_push(_p, crs_c_mass(-0.15, -0.235, 0.135, 0.124, CRS_R_CHARGE));      // skull
    array_push(_p, crs_c_seg(-0.23, -0.225, -0.33, -0.205, 0.058, 0.036, CRS_R_CHARGE)); // muzzle
    array_push(_p, crs_c_spike(-0.25, -0.165, -0.34, -0.135, 0.032, CRS_R_CHARGE));      // open jaw
    // Tail thrown up behind, with a TUFT - the second-cheapest lion cue after the mane.
    // ⚠️ The tuft is at 0.31/-0.25 r=0.075, i.e. reach 0.473. At 0.32/-0.27 r=0.085 it measured
    // 0.504 and would have failed the suite's 0.50 charge-box budget.
    array_push(_p, crs_c_limb(crs_qbez([0.28, 0.17], [0.44, 0.02], [0.32, -0.22], 12),
                              0.042, 0.020, CRS_R_CHARGE));
    // The tuft is a small MASS with three short teeth, not a fan - a fan here reads as a second
    // little sunburst and repeats the mistake the mane just had corrected.
    array_push(_p, crs_c_mass(0.315, -0.235, 0.048, 0.044, CRS_R_CHARGE));
    crs_c_ruff(_p, 0.315, -0.235, 0.040, 0.082, pi * 1.15, pi * 1.85, 3, 0.028, CRS_R_CHARGE);
    array_push(_p, crs_dot(-0.19, -0.258, 0.024, CRS_R_DETAIL));                // eye
    return _p;
}

/// wolf - courant, low and stretched, long muzzle.
/// 20px: a long horizontal - the lowest silhouette of the beasts.
function crs_ch_wolf() {
    // ⚠️ DEEPENED 2026-08-22. The old wolf was arithmetically a wolf - long body, long muzzle,
    // lowest silhouette in the order - and READ AS A HOUSE CAT, because a 0.24 x 0.10 body on
    // 0.036 legs with a thin tail is a small animal whatever its proportions say. Three changes,
    // all mass rather than shape: a deeper chest, thicker legs, and a BRUSH tail. The tail is the
    // one that carries it - a wolf's tail is thick along its whole length and a cat's is not.
    var _p = [];
    array_push(_p, crs_c_mass(0.02, 0.05, 0.245, 0.135, CRS_R_CHARGE));         // long, deeper body
    array_push(_p, crs_c_mass(-0.13, 0.05, 0.130, 0.150, CRS_R_CHARGE));        // chest
    crs_c_legs(_p, -0.16, 0.20, 0.14, 0.38, 0.048, 0.07, CRS_R_CHARGE);
    array_push(_p, crs_c_seg(-0.20, 0.01, -0.34, -0.03, 0.086, 0.048, CRS_R_CHARGE)); // neck
    array_push(_p, crs_c_mass(-0.355, -0.035, 0.086, 0.068, CRS_R_CHARGE));     // skull
    array_push(_p, crs_c_seg(-0.39, -0.015, -0.465, 0.025, 0.044, 0.026, CRS_R_CHARGE)); // long muzzle
    array_push(_p, crs_c_spike(-0.34, -0.085, -0.305, -0.175, 0.032, CRS_R_CHARGE));     // ear
    array_push(_p, crs_c_limb(crs_qbez([0.24, 0.04], [0.36, 0.01], [0.42, -0.09], 10),
                              0.062, 0.030, CRS_R_CHARGE));                     // BRUSH tail
    array_push(_p, crs_dot(-0.375, -0.055, 0.018, CRS_R_DETAIL));
    return _p;
}

/// bear - statant, massive shoulder, small round ears.
/// 20px: a heavy block with two round bumps on top.
function crs_ch_bear() {
    var _p = [];
    // ⛔ REDRAWN 2026-09-06 AFTER LOOKING AT THE BAKED SHEET AT 2x. The bear READ AS AN ELEPHANT,
    // and so did `ram` two charges later — so the corpus contained TWO different charges evoking
    // the SAME animal. ⚠️ The silhouette suite cannot see that class at all: it measures whether
    // the 44 marks are geometrically DISTINCT FROM EACH OTHER, and bear-as-elephant and
    // ram-as-elephant are distinct marks. "Distinct" and "reads as the right animal" are different
    // claims and only the first one is gated.
    //
    // The cause was a PAIR of features that happen to spell elephant, and it is the same pair in
    // both charges: a long DOWN-SLOPING snout (0.089 long, dropping 27 degrees) plus a big ROUND
    // ear disc (r 0.045, nearly the skull's own 0.095 radius) sitting beside the eye. That is a
    // trunk and an ear. Neither feature is wrong on its own, which is why one careful redraw of
    // each in isolation did not fix it.
    //
    // Three changes, all subtractive, because a bear is a MASS and the detail was fighting it:
    //   1. the snout is SHORT, THICK and nearly level (0.056 long, 8 degrees) — a bear muzzle is a
    //      blunt stub, and length is the entire trunk cue.
    //   2. the ears are SMALL (0.045 -> 0.032) and sit clearly ON TOP of the skull as two bumps
    //      rather than beside it as discs. Position carries this, not size alone.
    //   3. the shoulder HUMP is enlarged so it is unambiguously the highest point of the animal.
    //      That hump is the one silhouette cue no elephant has, and it was previously only 0.035
    //      above the skull line.
    array_push(_p, crs_c_mass(0.02, 0.02, 0.23, 0.17, CRS_R_CHARGE));          // deep barrel body
    array_push(_p, crs_c_mass(-0.11, -0.105, 0.150, 0.115, CRS_R_CHARGE));     // the shoulder hump, dominant
    crs_c_legs(_p, -0.14, 0.18, 0.14, 0.40, 0.052, 0.02, CRS_R_CHARGE);
    array_push(_p, crs_c_mass(-0.30, -0.07, 0.095, 0.085, CRS_R_CHARGE));      // blunt head
    array_push(_p, crs_c_seg(-0.36, -0.045, -0.415, -0.035, 0.052, 0.042, CRS_R_CHARGE)); // SHORT blunt muzzle
    array_push(_p, crs_dot(-0.340, -0.155, 0.032, CRS_R_CHARGE));              // small round ear, ON TOP
    array_push(_p, crs_dot(-0.260, -0.145, 0.032, CRS_R_CHARGE));              // small round ear, ON TOP
    array_push(_p, crs_dot(-0.33, -0.08, 0.018, CRS_R_DETAIL));
    return _p;
}

/// boar - charging, head down, tusks up, bristled spine.
/// 20px: a wedge, low at the front, with a saw-tooth back.
function crs_ch_boar() {
    var _p = [];
    // THE WEDGE: heavy at the shoulder, tapering to the rump. Drawn as a fan so the profile is one
    // clean mass rather than an outline that has to survive being scaled down.
    array_push(_p, crs_fill([[-0.06, 0.00], [-0.30, 0.14], [-0.10, 0.22],
                             [0.22, 0.20], [0.28, 0.02], [0.12, -0.14]], CRS_R_CHARGE));
    crs_c_legs(_p, -0.14, 0.20, 0.18, 0.38, 0.034, 0.04, CRS_R_CHARGE);
    array_push(_p, crs_c_mass(-0.32, 0.14, 0.098, 0.082, CRS_R_CHARGE));       // low head, heavier
    array_push(_p, crs_c_seg(-0.36, 0.16, -0.43, 0.19, 0.048, 0.028, CRS_R_CHARGE)); // blunt snout
    array_push(_p, crs_c_spike(-0.41, 0.17, -0.45, 0.05, 0.026, CRS_R_CHARGE));  // TUSK, up
    array_push(_p, crs_c_spike(-0.33, 0.14, -0.36, 0.03, 0.022, CRS_R_CHARGE));  // TUSK, up
    // THE BRISTLED SPINE - the saw-tooth back, and the only serrated contour in the order.
    //
    // ⛔ SHORTER AND DENSER, 2026-08-22. Six spikes running from r=0.13 out to r=0.24 are longer
    // than the head and stand off a rounded body, so the charge READ AS A HEDGEHOG on the baked
    // corpus sheet. A boar's bristles are a serrated EDGE along the spine, not a halo of quills:
    // nine short teeth from 0.15 to 0.205 keep the saw-tooth contour that separates this from
    // every other beast while leaving the wedge of the body as the dominant mass.
    crs_c_ruff(_p, 0.00, 0.02, 0.150, 0.205, pi * 1.14, pi * 1.86, 9, 0.024, CRS_R_CHARGE);
    return _p;
}

/// stag - at gaze, antlers dominating the silhouette.
/// 20px: a branching crown over a slim body - antlers are more than half the mark.
function crs_ch_stag() {
    var _p = [];
    array_push(_p, crs_c_mass(0.00, 0.18, 0.16, 0.10, CRS_R_CHARGE));          // slim body
    crs_c_legs(_p, -0.11, 0.13, 0.24, 0.44, 0.024, 0.02, CRS_R_CHARGE);
    array_push(_p, crs_c_seg(-0.04, 0.12, -0.06, -0.04, 0.052, 0.038, CRS_R_CHARGE)); // upright neck
    array_push(_p, crs_c_mass(-0.06, -0.09, 0.070, 0.058, CRS_R_CHARGE));      // head
    array_push(_p, crs_c_seg(-0.09, -0.09, -0.19, -0.06, 0.032, 0.022, CRS_R_CHARGE)); // muzzle
    // THE ANTLERS. Two beams with three tines each. More than half the charge's height, which is
    // what the silhouette note demands and what makes this unmistakable at 20px.
    //
    // ⚠️ THE HEAD SITS AT x = -0.06, NOT -0.11, AND THAT IS THE ANTLERS' DOING. The crown spreads
    // symmetrically about the head, so an off-centre head throws its far beam out along a diagonal:
    // at x = -0.11 the dexter beam tip landed at r=0.55 against a 0.50 budget, and only the ENGINE
    // suite could see it - every coordinate here is computed from `_dx`, so the static checker
    // skips the whole loop and says so.
    for (var _s = 0; _s < 2; _s++) {
        var _dx = (_s == 0) ? -1 : 1;
        var _beam = crs_qbez([-0.06 + _dx * 0.04, -0.14],
                             [-0.06 + _dx * 0.15, -0.28],
                             [-0.06 + _dx * 0.19, -0.38], 8);
        array_push(_p, crs_c_limb(_beam, 0.026, 0.012, CRS_R_CHARGE));
        array_push(_p, crs_c_spike(-0.06 + _dx * 0.09, -0.24, -0.06 + _dx * 0.05, -0.36, 0.017, CRS_R_CHARGE));
        array_push(_p, crs_c_spike(-0.06 + _dx * 0.14, -0.30, -0.06 + _dx * 0.11, -0.41, 0.015, CRS_R_CHARGE));
        array_push(_p, crs_c_spike(-0.06 + _dx * 0.17, -0.35, -0.06 + _dx * 0.26, -0.37, 0.014, CRS_R_CHARGE));
    }
    array_push(_p, crs_dot(-0.08, -0.11, 0.016, CRS_R_DETAIL));
    return _p;
}

/// horse - forcene, rearing, mane and tail streaming.
/// 20px: an S-curve like `lion` but SMOOTH - no mane collar, and a streaming tail.
function crs_ch_horse() {
    // ⛔ REDRAWN 2026-08-22. The old horse READ AS A GOAT FALLING OVER, and the cause was that its
    // body had no clear axis: a haunch oval at (0.13, 0.21) and a barrel oval at (-0.02, 0.00) put
    // the mass on a DIAGONAL, while both forelegs curled down-left and the neck went up-left. Every
    // limb pointed the same way and nothing said "rearing".
    //
    // Forcene means reared onto the hind legs, so the fix is postural: the barrel is now a single
    // tapered column standing almost VERTICALLY over the planted hind legs, the forelegs strike
    // FORWARD and DOWN from a high chest, and the neck continues the column's line instead of
    // branching off it.
    var _p = [];
    array_push(_p, crs_c_mass(0.15, 0.24, 0.150, 0.155, CRS_R_CHARGE));        // haunch, planted
    array_push(_p, crs_c_seg(0.16, 0.32, 0.18, 0.43, 0.056, 0.026, CRS_R_CHARGE)); // hind leg
    array_push(_p, crs_c_seg(0.22, 0.30, 0.25, 0.40, 0.046, 0.024, CRS_R_CHARGE)); // hind leg
    // THE COLUMN: haunch -> chest, near-vertical. This is the whole read.
    array_push(_p, crs_c_limb(crs_qbez([0.13, 0.24], [0.04, 0.06], [-0.02, -0.12], 12),
                              0.155, 0.105, CRS_R_CHARGE));
    array_push(_p, crs_c_limb(crs_qbez([-0.04, -0.06], [-0.18, 0.02], [-0.24, 0.16], 8),
                              0.044, 0.020, CRS_R_CHARGE));                    // foreleg, striking
    array_push(_p, crs_c_limb(crs_qbez([-0.03, 0.04], [-0.15, 0.14], [-0.17, 0.28], 8),
                              0.042, 0.019, CRS_R_CHARGE));
    // THE SMOOTH NECK - one clean taper, and the whole separation from `lion`, which has a mane.
    array_push(_p, crs_c_limb(crs_qbez([-0.02, -0.13], [-0.11, -0.25], [-0.21, -0.32], 10),
                              0.070, 0.038, CRS_R_CHARGE));
    // ⚠️ A BIGGER HEAD, because at 0.076 x 0.056 on a 0.155 body it was a knob on a rope and the
    // charge lost its species at gallery size. A horse's head is long and deep, so it grows along
    // the muzzle axis rather than becoming a circle.
    array_push(_p, crs_c_mass(-0.245, -0.335, 0.096, 0.070, CRS_R_CHARGE));    // head
    array_push(_p, crs_c_seg(-0.28, -0.325, -0.355, -0.283, 0.046, 0.028, CRS_R_CHARGE)); // muzzle
    array_push(_p, crs_c_spike(-0.235, -0.385, -0.215, -0.445, 0.020, CRS_R_CHARGE));    // ear
    // STREAMING mane and tail: waves, not spikes.
    array_push(_p, crs_c_limb(crs_qbez([-0.16, -0.28], [-0.06, -0.36], [0.02, -0.30], 8),
                              0.030, 0.012, CRS_R_CHARGE));
    array_push(_p, crs_c_limb(crs_qbez([0.25, 0.16], [0.42, 0.10], [0.44, -0.10], 10),
                              0.036, 0.014, CRS_R_CHARGE));
    array_push(_p, crs_dot(-0.27, -0.34, 0.016, CRS_R_DETAIL));
    return _p;
}

/// serpent - nowed (knotted), head raised from the coil.
/// 20px: a knot - the only closed loop in the order.
function crs_ch_serpent() {
    var _p = [];
    // THE KNOT. A closed loop is the identification, so it is drawn as one continuous tapered band
    // rather than as a ring: a ring is a `wheel` and a knot is a serpent.
    // ⛔ THICKER, AND TAPERED ALONG ITS LENGTH, 2026-08-22. At 0.055 the band was a thin outline and
    // the charge READ AS AN INFINITY SYMBOL rather than as an animal - a knot drawn in wire is a
    // mathematical sign, a knot drawn in flesh is a snake. Two changes carry the read:
    //   1. the body is 0.082 at the coil and tapers to 0.022, so it is plainly a TAIL at one end.
    //   2. the loop is walked from the tail END rather than the middle, so the taper runs along the
    //      creature instead of being symmetrical about the crossing.
    var _n = 56;
    var _loop = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n * CRS_TAU;
        // A lemniscate-ish figure: two lobes that cross, which is what "nowed" means.
        _loop[_i] = [sin(_t) * 0.30, sin(_t * 2) * 0.20 + 0.10];
    }
    array_push(_p, crs_c_limb(_loop, 0.082, 0.022, CRS_R_CHARGE));
    // head raised OUT of the coil, up and to the left
    array_push(_p, crs_c_limb(crs_qbez([-0.16, -0.02], [-0.27, -0.18], [-0.20, -0.32], 10),
                              0.070, 0.052, CRS_R_CHARGE));
    array_push(_p, crs_c_mass(-0.19, -0.36, 0.086, 0.062, CRS_R_CHARGE));          // wedge head
    array_push(_p, crs_c_spike(-0.235, -0.375, -0.335, -0.345, 0.020, CRS_R_CHARGE)); // jaw, forward
    array_push(_p, crs_c_spike(-0.19, -0.335, -0.15, -0.21, 0.016, CRS_R_CHARGE));    // forked tongue
    array_push(_p, crs_dot(-0.215, -0.385, 0.018, CRS_R_DETAIL));
    return _p;
}

/// hound - sejant, upright, collared, alert ears.
/// 20px: a seated triangle, pointed ears - the only sitting beast.
function crs_ch_hound() {
    var _p = [];
    // ⛔ REDRAWN 2026-08-22. The old fan was a near-symmetrical triangle 0.42 wide at the base and
    // the two ears stood straight up off the top of the skull - so the charge READ AS A TENT WITH A
    // CROWN ON IT, which is not a near miss, it is a different object. Two changes fix it and both
    // are about breaking symmetry, because a symmetrical animal profile is a shape, not an animal:
    //   1. the seat is now DEEPER AT THE BACK and cut in at the chest, so the body has a front.
    //   2. the ears LIE BACK along the skull instead of standing vertically. Vertical ears on a
    //      triangle are read as a roofline ornament; swept ears are read as a dog.
    array_push(_p, crs_fill([[-0.02, -0.08], [-0.13, 0.16], [-0.17, 0.41],
                             [0.24, 0.43], [0.26, 0.20], [0.12, -0.02]], CRS_R_CHARGE));
    array_push(_p, crs_c_seg(-0.09, 0.20, -0.15, 0.41, 0.050, 0.036, CRS_R_CHARGE));   // foreleg, straight
    array_push(_p, crs_c_seg(-0.15, 0.41, -0.23, 0.40, 0.038, 0.026, CRS_R_CHARGE));   // forepaw out
    array_push(_p, crs_c_seg(-0.02, -0.10, -0.07, -0.25, 0.076, 0.052, CRS_R_CHARGE)); // upright neck
    array_push(_p, crs_c_mass(-0.09, -0.29, 0.082, 0.068, CRS_R_CHARGE));      // head
    array_push(_p, crs_c_seg(-0.13, -0.28, -0.25, -0.245, 0.038, 0.026, CRS_R_CHARGE)); // long muzzle
    array_push(_p, crs_c_spike(-0.06, -0.34, 0.03, -0.41, 0.034, CRS_R_CHARGE));       // ear, SWEPT BACK
    array_push(_p, crs_c_spike(-0.12, -0.34, -0.05, -0.43, 0.030, CRS_R_CHARGE));      // ear, swept back
    // THE COLLAR - the second read, and what says this beast is owned.
    array_push(_p, crs_c_seg(-0.13, -0.16, 0.02, -0.19, 0.030, 0.030, CRS_R_DETAIL));
    array_push(_p, crs_dot(-0.11, -0.29, 0.016, CRS_R_DETAIL));
    return _p;
}

/// ram - statant, spiral horns curling forward.
/// 20px: two spirals either side of a blunt head.
function crs_ch_ram() {
    var _p = [];
    // ⛔⛔ REWRITTEN 2026-09-06 (fourth attempt), TO THE SPEC THE THIRD ATTEMPT LEFT BEHIND.
    // The three failed attempts recorded below all changed DETAIL. Their own closing lesson was
    // that the cause is PROPORTION — "a large smooth ovoid on four short stubby legs with the head
    // at body height IS an elephant" — and that the fix had to be costed as a rewrite. This is
    // that rewrite: all four proportions move together, because changing one of them at a time is
    // exactly what the earlier attempts did.
    //
    //   1. BODY: the smooth ovoid is gone. A ram has a LEVEL BACK, a deep chest and a tucked rump,
    //      so the body is a polygon (as `boar` already is) rather than an ellipse. An ellipse can
    //      only ever be a rounded mass, which is the elephant cue itself.
    //   2. LEGS: longer and thinner (0.20 -> 0.25 long, 0.042 -> 0.032 wide). Leg-to-body ratio is
    //      most of what separates an ungulate from a pachyderm at 20px.
    //   3. HEAD: lifted CLEAR of the back on a real neck (y 0.02 -> -0.165, i.e. 0.155 above the
    //      withers) and made smaller (0.098 -> 0.078). An elephant's head merges into its shoulder;
    //      a ram carries its head high and separate.
    //   4. MUZZLE: short and nearly level (length 0.103 -> 0.067, slope 29deg -> 13deg). This is the
    //      one change shared with the bear's fix, and it is included because the reverted geometry
    //      still carried a long DROOPING snout — but it is deliberately NOT relied on alone, since
    //      attempt 1 proved it is not sufficient here.
    //
    // ⚠️ The horn coil is REDUCED 0.132 -> 0.112 outer radius, purely for the extent budget: the
    // head moved up, so the coil moved up with it, and at the old radius the authored reach broke
    // the 0.5 charge box. The horn is still proportionally MORE dominant than before because the
    // head shrank at the same time (ratio 1.35 -> 1.44), so "a ram is its horns" is not weakened.
    array_push(_p, crs_fill([[-0.12, -0.01], [0.22, 0.01], [0.26, 0.10],
                             [0.20, 0.17], [-0.04, 0.18], [-0.13, 0.11]], CRS_R_CHARGE)); // level back, deep chest
    crs_c_legs(_p, -0.06, 0.18, 0.15, 0.40, 0.032, 0.02, CRS_R_CHARGE);        // longer, finer legs
    array_push(_p, crs_c_limb([[-0.11, 0.06], [-0.155, -0.01], [-0.20, -0.085]], 0.070, 0.052, CRS_R_CHARGE)); // NECK: short, and thin enough not to fuse with the horn
    // ⛔⛔ REVERTED TO THE 2026-08-22 GEOMETRY ON 2026-09-06 AFTER THREE FAILED ATTEMPTS.
    // The charge below is byte-for-byte the version that was shipping. What follows is the record
    // of what was tried, because the next session must not spend another three Igor bakes on it.
    //
    // THE DEFECT, still live and still real: `ram` reads as an ELEPHANT on the baked sheet, and so
    // did `bear` — two charges in a 44-mark corpus evoking the SAME animal. ⚠️ The silhouette suite
    // is structurally blind to this: it measures whether the marks are geometrically DISTINCT FROM
    // EACH OTHER, and bear-as-elephant and ram-as-elephant are perfectly distinct marks.
    // "Distinct" and "reads as the right animal" are different claims and only the first is gated.
    //
    //   attempt 1 — shorten/flatten the muzzle, move the horn coil back off the face. This is
    //               EXACTLY the fix that WORKED on `bear`. Baked, stacked 3x against the control:
    //               the two ram silhouettes are near-indistinguishable. FAILED.
    //   attempt 2 — muzzle onto the head centre line, both coils onto the crown, add a neck. The
    //               elephant read weakened, but the charge became an indistinct lump with a hook
    //               and the spiral — previously legible — was cramped. Not an improvement. FAILED.
    //   attempt 3 — fleece: a ring of overlapping discs to scallop the body outline. ⛔ INVALID,
    //               NOT FAILED, and the difference matters. Its own comment asserted "the head is
    //               REVERTED to original so this tests the fleece ALONE" — and that was FALSE. The
    //               head mass had been deleted in attempt 2 and never restored, so the bake drew a
    //               HEADLESS ram and the result says nothing about fleece. I asserted a property
    //               instead of checking it (master §2b), and `check_charges.js` passed it because
    //               it gates contract, extent and non-triviality, never "does this charge still
    //               have a head". The dots were also only ~11% of the body radius, i.e. below the
    //               threshold where an outline change is visible at gallery scale.
    //
    // ⇒ TWO LESSONS FOR THE NEXT ATTEMPT, both paid for.
    //   1. A SHARED SYMPTOM IS NOT A SHARED CAUSE. `bear` and `ram` presented identically and the
    //      bear's cause (drooping snout + big round ear) was simply not the ram's. One confirming
    //      case is not evidence about the other, and two bakes were spent inheriting a diagnosis
    //      rather than re-deriving one.
    //   2. THE RAM'S PROBLEM IS PROPORTION, NOT DETAIL. A large smooth ovoid on four short stubby
    //      legs with the head at body height IS an elephant, and every attempt above changed
    //      DETAIL while leaving those proportions untouched. The fix is a rewrite — smaller body,
    //      longer legs, head lifted clear on a neck — and it must be costed as one, not as a
    //      coordinate nudge. Do not attempt it with anything less.
    array_push(_p, crs_c_mass(-0.230, -0.135, 0.078, 0.070, CRS_R_CHARGE));    // smaller head, lifted clear
    array_push(_p, crs_c_seg(-0.280, -0.120, -0.345, -0.105, 0.044, 0.030, CRS_R_CHARGE)); // SHORT, near-level muzzle
    // THE SPIRALS. Two turns each, drawn as a tapering band along a spiral path - the only spiral
    // in the corpus, and the whole identification.
    //
    // ⛔ THICKER BANDS AND A TIGHTER OUTER RADIUS, 2026-08-22. At 0.034 wide on a 0.155 radius the
    // horns were long thin curls on thin legs and the whole charge READ AS A SPIDER on the baked
    // corpus sheet. The fix is the same one the lion needed: a ram is its horns, so the horn has to
    // carry weight rather than length. Radius 0.155 -> 0.132, band 0.034 -> 0.050.
    // ⛔ COIL CENTRE MOVED BACK AND UP, 2026-09-06. At x = -0.20 the coils sat on top of the FACE
    // (head centre -0.22), so the outer turn swept down across the muzzle and the two features
    // fused. A ram's horn springs from BEHIND and ABOVE the eye and curls down past it, so the
    // centre moves toward the body (-0.20 -> -0.175) and the pair tightens upward. The coil
    // geometry itself is unchanged — this is placement, not a redraw, because the spiral was
    // already the right shape and was simply in the wrong place.
    for (var _s = 0; _s < 2; _s++) {
        // ⛔ COIL PULLED BACK OFF THE FACE, 2026-09-06 (attempt 6). At centre x -0.188 with radius
        // 0.128 the coil's front edge reached -0.316 while the muzzle spans -0.280..-0.345, so the
        // horn lay ON the muzzle and the horn, head and neck fused into ONE front-heavy blob. At
        // 20px that read acceptably; at corpus size it read as a shaggy-headed animal, not a ram.
        // A ram's horn springs from behind the eye and curls DOWN BESIDE the face, leaving the
        // muzzle projecting clear in front of it. Centre -0.188 -> -0.155 and radius 0.128 -> 0.112
        // puts the coil's front edge at -0.267, i.e. BEHIND where the muzzle begins, and the band
        // thins so the spiral reads as a coil rather than a filled mass.
        var _oy = (_s == 0) ? -0.185 : -0.092;
        var _n = 26;
        var _sp = array_create(_n + 1);
        for (var _i = 0; _i <= _n; _i++) {
            var _t = _i / _n;
            var _a = pi * 0.4 + _t * CRS_TAU * 0.92;
            var _r = lerp(0.112, 0.034, _t);
            _sp[_i] = [-0.155 + cos(_a) * _r, _oy + sin(_a) * _r * 0.92];
        }
        array_push(_p, crs_c_limb(_sp, 0.042, 0.018, CRS_R_CHARGE));
    }
    array_push(_p, crs_dot(-0.252, -0.148, 0.014, CRS_R_DETAIL));
    return _p;
}

/// ============================================================================================
/// 3.2  bird - 6
/// ============================================================================================

/// eagle - displayed, wings spread and raised, head sinister.
/// 20px: a broad symmetrical X - the widest mark in the corpus.
function crs_ch_eagle() {
    var _p = [];
    // THE X. Two raised wings as filled fans, wide and symmetrical. `falcon` is the same bird drawn
    // NARROW, so the width here has to be unambiguous.
    for (var _s = 0; _s < 2; _s++) {
        var _dx = (_s == 0) ? -1 : 1;
        array_push(_p, crs_fill([[_dx * 0.04, -0.02],
                                 [_dx * 0.26, -0.34], [_dx * 0.42, -0.24],
                                 [_dx * 0.46, -0.05], [_dx * 0.30, 0.08]], CRS_R_CHARGE));
        // the flight feathers, as three deep notches read from the wing's trailing edge
        array_push(_p, crs_c_spike(_dx * 0.36, 0.02, _dx * 0.42, 0.16, 0.030, CRS_R_CHARGE));
        array_push(_p, crs_c_spike(_dx * 0.24, 0.05, _dx * 0.28, 0.19, 0.030, CRS_R_CHARGE));
    }
    array_push(_p, crs_c_mass(0.00, 0.06, 0.085, 0.17, CRS_R_CHARGE));         // body
    // ⛔ THE HEAD MUST CLEAR THE WINGS. At y=-0.20 against wings reaching y=-0.34 the head sat in
    // the notch BETWEEN the two fans and the charge READ AS A BAT - two masses and no bird - which
    // matters more than most because `eagle` is the charge these store sheets draw most often.
    // An eagle displayed shows its head against the sky above the shoulder line, so it is raised
    // clear and enlarged, and the beak projects past the wing's leading edge rather than into it.
    array_push(_p, crs_c_mass(-0.05, -0.295, 0.086, 0.073, CRS_R_CHARGE));     // head, sinister
    array_push(_p, crs_c_spike(-0.09, -0.295, -0.20, -0.265, 0.026, CRS_R_CHARGE)); // beak
    array_push(_p, crs_fill([[-0.05, 0.20], [0.05, 0.20], [0.03, 0.40], [-0.03, 0.40]], CRS_R_CHARGE));
    array_push(_p, crs_dot(-0.075, -0.315, 0.017, CRS_R_DETAIL));
    return _p;
}

/// raven - close, perched, beak heavy, tail long.
/// 20px: a compact hunched wedge, no spread.
function crs_ch_raven() {
    var _p = [];
    // COMPACT AND HUNCHED. The whole identification is that nothing sticks out sideways - this is
    // the only bird in the order with its wings closed against the body.
    array_push(_p, crs_fill([[-0.02, -0.14], [-0.16, 0.06], [-0.12, 0.24],
                             [0.14, 0.22], [0.18, -0.02]], CRS_R_CHARGE));
    array_push(_p, crs_c_mass(-0.10, -0.20, 0.085, 0.072, CRS_R_CHARGE));      // hunched head
    // HEAVY BEAK - deep and wedge-shaped, not the fine point of `crane`.
    array_push(_p, crs_fill([[-0.16, -0.24], [-0.36, -0.19], [-0.16, -0.14]], CRS_R_CHARGE));
    // LONG TAIL, down and back
    array_push(_p, crs_fill([[0.10, 0.10], [0.20, 0.06], [0.38, 0.28], [0.24, 0.30]], CRS_R_CHARGE));
    array_push(_p, crs_c_seg(-0.02, 0.24, -0.04, 0.38, 0.020, 0.016, CRS_R_CHARGE));  // perching leg
    array_push(_p, crs_c_seg(-0.04, 0.38, -0.14, 0.41, 0.016, 0.012, CRS_R_CHARGE));
    array_push(_p, crs_dot(-0.13, -0.22, 0.018, CRS_R_DETAIL));
    return _p;
}

/// falcon - rising, wings addorsed and swept back.
/// 20px: a narrow V opening upward.
function crs_ch_falcon() {
    var _p = [];
    // THE NARROW V. Both wings sweep UP and BACK from a single point, so the enclosed angle is
    // small - against `eagle`, whose wings reach sideways to fill the shield.
    // ⛔ BROADER WINGS AND A REAL BODY, 2026-08-22. The old fans were 0.11-wide strips either side
    // of a 0.075 body, which READ AS A TUNING FORK - two prongs and a stem, with nothing in the
    // middle heavy enough to be a bird. Widening the wing at the shoulder and deepening the breast
    // keeps the narrow enclosed V that separates this from `eagle` while giving the mark a centre.
    for (var _s = 0; _s < 2; _s++) {
        var _dx = (_s == 0) ? -1 : 1;
        array_push(_p, crs_fill([[_dx * 0.02, 0.16],
                                 [_dx * 0.16, -0.18], [_dx * 0.25, -0.42],
                                 [_dx * 0.33, -0.20], [_dx * 0.20, 0.08]], CRS_R_CHARGE));
    }
    array_push(_p, crs_c_mass(0.00, 0.11, 0.105, 0.185, CRS_R_CHARGE));        // deep breast
    array_push(_p, crs_c_mass(-0.05, -0.10, 0.078, 0.066, CRS_R_CHARGE));      // head
    array_push(_p, crs_c_spike(-0.09, -0.09, -0.17, -0.06, 0.020, CRS_R_CHARGE)); // hooked beak
    array_push(_p, crs_fill([[-0.04, 0.24], [0.04, 0.24], [0.02, 0.42], [-0.02, 0.42]], CRS_R_CHARGE));
    array_push(_p, crs_dot(-0.07, -0.11, 0.015, CRS_R_DETAIL));
    return _p;
}

/// swan - naiant, neck in a full curve, wings closed.
/// 20px: a question-mark neck over a low hull.
function crs_ch_swan() {
    var _p = [];
    array_push(_p, crs_c_mass(0.04, 0.22, 0.26, 0.11, CRS_R_CHARGE));          // the low hull
    // THE QUESTION-MARK NECK. One long S, and the only charge in the corpus whose identification is
    // a single curve rather than a mass.
    var _neck = crs_qbez([-0.06, 0.16], [-0.30, -0.06], [-0.14, -0.30], 14);
    array_push(_p, crs_c_limb(_neck, 0.048, 0.026, CRS_R_CHARGE));
    array_push(_p, crs_c_mass(-0.11, -0.35, 0.062, 0.048, CRS_R_CHARGE));      // small head
    array_push(_p, crs_c_spike(-0.15, -0.34, -0.25, -0.30, 0.020, CRS_R_CHARGE)); // bill
    // closed wing, a raised scallop on the back
    array_push(_p, crs_fill([[0.02, 0.14], [0.20, 0.06], [0.30, 0.18], [0.10, 0.22]], CRS_R_CHARGE));
    array_push(_p, crs_dot(-0.13, -0.37, 0.015, CRS_R_DETAIL));
    return _p;
}

/// owl - affronty, facing forward, two huge eye-discs.
/// 20px: a wide round head - the only bird facing the viewer.
function crs_ch_owl() {
    var _p = [];
    array_push(_p, crs_c_mass(0.00, 0.14, 0.20, 0.24, CRS_R_CHARGE));          // body, seen head-on
    array_push(_p, crs_c_mass(0.00, -0.16, 0.26, 0.21, CRS_R_CHARGE));         // THE WIDE HEAD
    array_push(_p, crs_c_spike(-0.16, -0.30, -0.22, -0.42, 0.045, CRS_R_CHARGE));  // ear tuft
    array_push(_p, crs_c_spike(0.16, -0.30, 0.22, -0.42, 0.045, CRS_R_CHARGE));    // ear tuft
    // THE TWO HUGE EYE-DISCS. Detail role, so they read as a hole punched in the mass rather than
    // as more of it - this is the only charge whose second read is load-bearing, and it is why the
    // owl is unmistakable even when the body is lost.
    array_push(_p, crs_dot(-0.11, -0.17, 0.082, CRS_R_DETAIL));
    array_push(_p, crs_dot(0.11, -0.17, 0.082, CRS_R_DETAIL));
    array_push(_p, crs_c_spike(0.00, -0.10, 0.00, 0.02, 0.030, CRS_R_DETAIL));     // beak
    array_push(_p, crs_c_seg(-0.09, 0.36, -0.14, 0.42, 0.018, 0.014, CRS_R_CHARGE));
    array_push(_p, crs_c_seg(0.09, 0.36, 0.14, 0.42, 0.018, 0.014, CRS_R_CHARGE));
    return _p;
}

/// crane - in its vigilance, one leg raised holding a stone.
/// 20px: a tall thin stilt with a bend - the tallest, thinnest bird.
function crs_ch_crane() {
    var _p = [];
    array_push(_p, crs_c_mass(0.02, -0.02, 0.13, 0.17, CRS_R_CHARGE));         // narrow body
    array_push(_p, crs_c_limb(crs_qbez([-0.02, -0.14], [-0.14, -0.28], [-0.06, -0.38], 10),
                              0.034, 0.022, CRS_R_CHARGE));                    // long neck
    array_push(_p, crs_c_mass(-0.05, -0.41, 0.052, 0.040, CRS_R_CHARGE));      // small head
    array_push(_p, crs_c_spike(-0.09, -0.41, -0.22, -0.39, 0.017, CRS_R_CHARGE)); // fine long bill
    // THE STANDING STILT - one leg, straight and very long, which is the whole silhouette.
    array_push(_p, crs_c_seg(0.02, 0.14, 0.02, 0.44, 0.020, 0.016, CRS_R_CHARGE));
    array_push(_p, crs_c_seg(0.02, 0.44, 0.12, 0.46, 0.016, 0.012, CRS_R_CHARGE));
    // THE RAISED LEG WITH THE STONE - the "vigilance": a sleeping crane drops the stone and wakes.
    array_push(_p, crs_c_seg(0.06, 0.12, 0.22, 0.24, 0.018, 0.014, CRS_R_CHARGE));
    array_push(_p, crs_dot(0.25, 0.28, 0.040, CRS_R_DETAIL));                  // THE STONE
    array_push(_p, crs_fill([[0.12, 0.02], [0.30, 0.10], [0.20, 0.16]], CRS_R_CHARGE)); // closed wing
    return _p;
}

/// ============================================================================================
/// 3.3  arms - 8
/// ============================================================================================

/// sword - erect, point up, plain cross-guard, round pommel.
/// 20px: a vertical cross with a round foot.
function crs_ch_sword() {
    var _p = [];
    // Blade as ONE tapering mass to a point. Against `arrow`, whose head is a separate V.
    array_push(_p, crs_fill([[-0.055, 0.06], [0.055, 0.06], [0.030, -0.34],
                             [0.000, -0.46], [-0.030, -0.34]], CRS_R_CHARGE));
    array_push(_p, crs_rect_fill(-0.30, 0.06, 0.30, 0.13, CRS_R_CHARGE));      // STRAIGHT WIDE GUARD
    array_push(_p, crs_rect_fill(-0.035, 0.13, 0.035, 0.34, CRS_R_CHARGE));    // grip
    array_push(_p, crs_dot(0.00, 0.40, 0.070, CRS_R_CHARGE));                  // ROUND POMMEL
    array_push(_p, crs_c_seg(0.00, -0.30, 0.00, 0.05, 0.010, 0.010, CRS_R_DETAIL)); // fuller
    return _p;
}

/// axe - single-bladed war axe, haft vertical, blade sinister.
/// 20px: asymmetric - mass on one side only.
function crs_ch_axe() {
    var _p = [];
    array_push(_p, crs_rect_fill(-0.035, -0.42, 0.035, 0.44, CRS_R_CHARGE));   // haft
    // THE ASYMMETRY. All the mass on the sinister side, with a crescent bit - that one-sidedness IS
    // the identification, and it is what separates this from `hammer`.
    array_push(_p, crs_fill([[-0.02, -0.36], [-0.34, -0.26], [-0.42, -0.04],
                             [-0.30, 0.06], [-0.02, 0.02]], CRS_R_CHARGE));
    array_push(_p, crs_c_spike(-0.02, -0.36, 0.10, -0.32, 0.030, CRS_R_CHARGE)); // small back spur
    array_push(_p, crs_c_limb(crs_arc_pts(-0.10, -0.17, 0.24, pi * 0.72, pi * 1.30, 10),
                              0.020, 0.020, CRS_R_DETAIL));                    // the bit's edge
    array_push(_p, crs_rect_fill(-0.06, 0.34, 0.06, 0.44, CRS_R_CHARGE));      // butt binding
    return _p;
}

/// hammer - war hammer, square head, langets down the haft.
/// 20px: a T with a rectangular bar.
function crs_ch_hammer() {
    var _p = [];
    array_push(_p, crs_rect_fill(-0.040, -0.26, 0.040, 0.45, CRS_R_CHARGE));   // haft
    // THE RECTANGULAR BAR - symmetrical, square-ended, and deliberately NOT a crescent. The `axe`
    // is one-sided and curved; this is two-sided and straight.
    array_push(_p, crs_rect_fill(-0.29, -0.39, 0.29, -0.22, CRS_R_CHARGE));
    array_push(_p, crs_rect_fill(-0.11, -0.22, -0.06, 0.06, CRS_R_CHARGE));    // LANGET
    array_push(_p, crs_rect_fill(0.06, -0.22, 0.11, 0.06, CRS_R_CHARGE));      // LANGET
    array_push(_p, crs_c_seg(-0.25, -0.305, 0.25, -0.305, 0.012, 0.012, CRS_R_DETAIL));
    return _p;
}

/// arrow - one arrow, point up, fletched.
/// 20px: a thin vertical with a V head and a fletched foot.
function crs_ch_arrow() {
    var _p = [];
    array_push(_p, crs_rect_fill(-0.028, -0.28, 0.028, 0.34, CRS_R_CHARGE));   // shaft
    // THE V HEAD - barbed, an open V rather than the closed taper of `sword`.
    array_push(_p, crs_fill([[0.00, -0.46], [0.14, -0.20], [0.00, -0.27], [-0.14, -0.20]], CRS_R_CHARGE));
    // THE FLETCHING - three vanes, which no other charge in the order has.
    array_push(_p, crs_fill([[-0.03, 0.20], [-0.20, 0.30], [-0.20, 0.44], [-0.03, 0.36]], CRS_R_CHARGE));
    array_push(_p, crs_fill([[0.03, 0.20], [0.20, 0.30], [0.20, 0.44], [0.03, 0.36]], CRS_R_CHARGE));
    array_push(_p, crs_c_seg(0.00, 0.36, 0.00, 0.46, 0.024, 0.024, CRS_R_DETAIL)); // nock
    return _p;
}

/// bow - strung longbow, curved, string vertical.
/// 20px: a D on its back - the only closed-string shape.
function crs_ch_bow() {
    var _p = [];
    // THE D. The stave bows out to the DEXTER and the string closes it dead straight - which is the
    // separation from `crescent`, an open arc with its horns UP and no chord at all.
    var _stave = crs_qbez([0.06, -0.44], [-0.44, 0.00], [0.06, 0.44], 20);
    array_push(_p, crs_c_limb(_stave, 0.024, 0.024, CRS_R_CHARGE));
    array_push(_p, crs_c_seg(0.06, -0.44, 0.06, 0.44, 0.014, 0.014, CRS_R_CHARGE)); // THE STRING
    array_push(_p, crs_dot(0.06, -0.44, 0.030, CRS_R_CHARGE));                 // nock
    array_push(_p, crs_dot(0.06, 0.44, 0.030, CRS_R_CHARGE));                  // nock
    array_push(_p, crs_c_seg(-0.30, -0.06, -0.30, 0.06, 0.034, 0.034, CRS_R_DETAIL)); // grip
    return _p;
}

/// shieldwall - three overlapping round shields.
/// 20px: three overlapping discs, offset.
function crs_ch_shieldwall() {
    // ⛔ REDRAWN 2026-08-22. Three DISCS with a gold boss in the middle of each READ AS THREE EGGS,
    // and the caption "Three Shields" underneath did not rescue it - a round shield is only legible
    // as a shield when you already know that is what you are looking at. It was also the third
    // circular mark in the corpus, against `roundel`, `cartwheel` and `mullet pierced`.
    //
    // These are HEATER shields - flat top, straight shoulders, tapering to a point. That outline is
    // unmistakable and it is the same silhouette the product's own shield layer draws, so the mark
    // now says "shields" in the package's own visual language rather than borrowing a circle.
    var _p = [];
    var _cx = [-0.21, 0.00, 0.21];
    var _cy = [0.08, -0.05, 0.08];
    var _w = 0.185, _h = 0.235;
    for (var _i = 0; _i < 3; _i++) {
        var _x = _cx[_i], _y = _cy[_i];
        array_push(_p, crs_fill([[_x - _w, _y - _h],
                                 [_x + _w, _y - _h],
                                 [_x + _w, _y + _h * 0.16],
                                 [_x,      _y + _h],
                                 [_x - _w, _y + _h * 0.16]], CRS_R_CHARGE));
        // A short pale down each shield: it separates the three where they overlap, and it is the
        // cheapest mark that says "this is a device, not a blank plate".
        array_push(_p, crs_c_seg(_x, _y - _h * 0.72, _x, _y + _h * 0.46, 0.036, 0.036, CRS_R_DETAIL));
    }
    return _p;
}

/// helm - closed great helm, visor slit, no crest.
/// 20px: a rounded box with a slot.
function crs_ch_helm() {
    var _p = [];
    // A rounded box: flat-topped, straight-sided, tapering slightly to a flat chin. Deliberately
    // NOT a dome, so it cannot be read as `well` or as a plain roundel.
    array_push(_p, crs_fill([[-0.28, -0.30], [0.28, -0.30], [0.30, 0.08],
                             [0.20, 0.36], [-0.20, 0.36], [-0.30, 0.08]], CRS_R_CHARGE));
    array_push(_p, crs_rect_fill(-0.30, -0.36, 0.30, -0.28, CRS_R_CHARGE));    // crown band
    // THE SLOT - one wide horizontal void. It is the identification and it must stay wide.
    array_push(_p, crs_rect_fill(-0.24, -0.14, 0.24, -0.04, CRS_R_DETAIL));
    // breaths, a row of small voids on the chin
    for (var _i = 0; _i < 4; _i++) {
        array_push(_p, crs_dot(-0.12 + _i * 0.08, 0.18, 0.028, CRS_R_DETAIL));
    }
    return _p;
}

/// caltrop - four-spiked caltrop.
/// 20px: a four-point star, squat, no shaft.
function crs_ch_caltrop() {
    var _p = [];
    // FOUR points, thick at the root, and NO shaft - that absence is what separates it from
    // `mullet` (six thin points, pierced) and from every hafted charge in the order.
    var _a = [pi * 1.5, pi * 0.28, pi * 0.72, pi * 1.5];
    for (var _i = 0; _i < 3; _i++) {
        array_push(_p, crs_c_spike(0.00, 0.02, cos(_a[_i]) * 0.42, 0.02 + sin(_a[_i]) * 0.42,
                                   0.090, CRS_R_CHARGE));
    }
    array_push(_p, crs_c_spike(0.00, 0.02, -0.30, 0.30, 0.085, CRS_R_CHARGE));
    array_push(_p, crs_dot(0.00, 0.02, 0.115, CRS_R_CHARGE));                  // the squat hub
    array_push(_p, crs_dot(0.00, 0.02, 0.040, CRS_R_DETAIL));
    return _p;
}

/// ============================================================================================
/// 3.4  craft - 8
/// ============================================================================================

/// anvil - horned anvil on a block.
/// 20px: an asymmetric T - the horn breaks the symmetry.
function crs_ch_anvil() {
    var _p = [];
    // THE HORN, on the dexter only. Symmetry here would make it a `hammer` head on a plinth.
    array_push(_p, crs_fill([[-0.44, -0.14], [-0.14, -0.22], [0.34, -0.22],
                             [0.34, -0.02], [-0.14, -0.02]], CRS_R_CHARGE));
    array_push(_p, crs_fill([[-0.14, -0.02], [0.28, -0.02], [0.18, 0.16], [-0.06, 0.16]], CRS_R_CHARGE)); // waist
    array_push(_p, crs_rect_fill(-0.26, 0.16, 0.34, 0.34, CRS_R_CHARGE));      // the block
    array_push(_p, crs_c_seg(-0.30, -0.12, 0.30, -0.12, 0.014, 0.014, CRS_R_DETAIL)); // face line
    return _p;
}

/// key - one key, ward down, bow a trefoil.
/// 20px: a loop on a stem with teeth on one side.
function crs_ch_key() {
    var _p = [];
    array_push(_p, crs_rect_fill(-0.035, -0.16, 0.035, 0.38, CRS_R_CHARGE));   // stem
    // THE TREFOIL BOW - three lobes, so the head is unmistakably a KEY's bow and not the plain ring
    // of `wheel` or the annulet of a cadency mark.
    for (var _i = 0; _i < 3; _i++) {
        var _a = pi * 1.5 + (_i - 1) * pi * 0.60;
        array_push(_p, crs_dot(cos(_a) * 0.14, -0.20 + sin(_a) * 0.14, 0.105, CRS_R_CHARGE));
    }
    array_push(_p, crs_dot(0.00, -0.22, 0.062, CRS_R_DETAIL));                 // the bow's eye
    // THE WARDS, on ONE side only - the asymmetry is the identification.
    array_push(_p, crs_rect_fill(0.035, 0.20, 0.24, 0.28, CRS_R_CHARGE));
    array_push(_p, crs_rect_fill(0.035, 0.32, 0.18, 0.40, CRS_R_CHARGE));
    return _p;
}

/// wheel - spoked cartwheel, six spokes, thick felloe.
/// 20px: a spoked circle.
function crs_ch_wheel() {
    var _p = [];
    // THE THICK FELLOE. Against `mullet`, whose points BREAK the outline: this outline is unbroken
    // and heavy, which is the whole separation.
    array_push(_p, crs_dot(0.00, 0.00, 0.46, CRS_R_CHARGE));
    array_push(_p, crs_dot(0.00, 0.00, 0.365, CRS_R_FIELD));                   // the rim's inside
    for (var _i = 0; _i < 6; _i++) {
        var _a = _i / 6 * CRS_TAU;
        array_push(_p, crs_c_seg(0.00, 0.00, cos(_a) * 0.40, sin(_a) * 0.40, 0.038, 0.030, CRS_R_CHARGE));
    }
    array_push(_p, crs_dot(0.00, 0.00, 0.115, CRS_R_CHARGE));                  // hub
    array_push(_p, crs_dot(0.00, 0.00, 0.048, CRS_R_DETAIL));                  // axle
    return _p;
}

/// anchor - anchor with stock and ring, flukes curved.
/// 20px: an inverted T with hooked feet and a ring.
function crs_ch_anchor() {
    var _p = [];
    array_push(_p, crs_rect_fill(-0.045, -0.28, 0.045, 0.26, CRS_R_CHARGE));   // shank
    array_push(_p, crs_rect_fill(-0.26, -0.30, 0.26, -0.22, CRS_R_CHARGE));    // THE STOCK
    // THE HOOKED FEET - two curved arms sweeping UP from the crown. `anvil` has a flat foot;
    // the hook is what makes this an anchor.
    for (var _s = 0; _s < 2; _s++) {
        var _dx = (_s == 0) ? -1 : 1;
        var _arm = crs_qbez([0.00, 0.24], [_dx * 0.30, 0.42], [_dx * 0.38, 0.14], 12);
        array_push(_p, crs_c_limb(_arm, 0.048, 0.020, CRS_R_CHARGE));
        array_push(_p, crs_c_spike(_dx * 0.34, 0.24, _dx * 0.44, 0.06, 0.045, CRS_R_CHARGE)); // fluke
    }
    array_push(_p, crs_dot(0.00, -0.38, 0.105, CRS_R_CHARGE));                 // THE RING
    array_push(_p, crs_dot(0.00, -0.38, 0.055, CRS_R_DETAIL));
    return _p;
}

/// ship - single-masted cog, hull deep, sail furled.
/// 20px: a deep crescent hull with one vertical.
function crs_ch_ship() {
    var _p = [];
    // THE DEEP CRESCENT HULL. Deep is the point: a shallow one reads as `crescent` or `chalice`.
    array_push(_p, crs_fill([[-0.42, -0.02], [-0.30, 0.26], [0.30, 0.26], [0.42, -0.02],
                             [0.26, 0.10], [-0.26, 0.10]], CRS_R_CHARGE));
    array_push(_p, crs_fill([[-0.42, -0.02], [-0.26, 0.10], [0.26, 0.10], [0.42, -0.02],
                             [0.34, 0.20], [-0.34, 0.20]], CRS_R_CHARGE));
    array_push(_p, crs_rect_fill(-0.030, -0.44, 0.030, 0.02, CRS_R_CHARGE));   // THE ONE MAST
    array_push(_p, crs_rect_fill(-0.24, -0.40, 0.24, -0.33, CRS_R_CHARGE));    // yard
    array_push(_p, crs_fill([[-0.20, -0.33], [0.20, -0.33], [0.14, -0.20], [-0.14, -0.20]], CRS_R_CHARGE)); // furled sail
    array_push(_p, crs_c_seg(-0.34, 0.02, 0.34, 0.02, 0.014, 0.014, CRS_R_DETAIL)); // gunwale
    return _p;
}

/// chalice - footed cup, wide bowl, knopped stem.
/// 20px: a wide bowl on a narrow stem on a foot.
function crs_ch_chalice() {
    var _p = [];
    // THREE STACKED WIDTHS - wide, narrow, wide - and that rhythm is the identification. `ship`
    // is one wide mass, `tree` is a mass on a stem with no foot.
    array_push(_p, crs_fill([[-0.34, -0.30], [0.34, -0.30], [0.22, 0.00], [-0.22, 0.00]], CRS_R_CHARGE));
    array_push(_p, crs_rect_fill(-0.055, 0.00, 0.055, 0.28, CRS_R_CHARGE));    // narrow stem
    array_push(_p, crs_dot(0.00, 0.14, 0.090, CRS_R_CHARGE));                  // THE KNOP
    // The foot's outer corners are the charge's furthest points, so they sit at r=0.485 rather than
    // wherever a wider foot would have landed: the checker measured 0.505 for a 0.28 half-width and
    // the answer is a redrawn foot, not a bigger budget (Motif_Corpus.md §2).
    array_push(_p, crs_fill([[-0.26, 0.41], [0.26, 0.41], [0.16, 0.28], [-0.16, 0.28]], CRS_R_CHARGE)); // foot
    array_push(_p, crs_c_seg(-0.30, -0.24, 0.30, -0.24, 0.014, 0.014, CRS_R_DETAIL)); // rim line
    return _p;
}

/// scales - balance, beam level, two shallow pans.
/// 20px: a horizontal beam with two hanging arcs.
function crs_ch_scales() {
    var _p = [];
    array_push(_p, crs_rect_fill(-0.38, -0.20, 0.38, -0.12, CRS_R_CHARGE));    // THE LEVEL BEAM
    array_push(_p, crs_rect_fill(-0.035, -0.34, 0.035, -0.16, CRS_R_CHARGE));  // post
    array_push(_p, crs_dot(0.00, -0.38, 0.060, CRS_R_CHARGE));                 // suspension ring
    for (var _s = 0; _s < 2; _s++) {
        var _x = (_s == 0) ? -0.30 : 0.30;
        array_push(_p, crs_c_seg(_x, -0.12, _x, 0.14, 0.012, 0.012, CRS_R_CHARGE)); // cord
        // THE SHALLOW PAN - an open arc, hanging. Shallow, so it cannot be read as a `chalice` bowl.
        array_push(_p, crs_c_limb(crs_arc_pts(_x, 0.06, 0.140, 0.10 * pi, 0.90 * pi, 12),
                                  0.032, 0.032, CRS_R_CHARGE));
    }
    return _p;
}

/// sheaf - wheatsheaf (garb), bound at the waist.
/// 20px: a bundle - widest at both ends, pinched in the middle.
function crs_ch_sheaf() {
    var _p = [];
    // THE PINCH. Wide, narrow, wide - top to bottom. Against `tree`, which is a mass ON a stem with
    // a root fringe and is therefore NOT pinched.
    array_push(_p, crs_fill([[-0.30, -0.36], [0.30, -0.36], [0.09, -0.02], [-0.09, -0.02]], CRS_R_CHARGE));
    array_push(_p, crs_fill([[-0.09, 0.02], [0.09, 0.02], [0.30, 0.38], [-0.30, 0.38]], CRS_R_CHARGE));
    // ears of wheat splaying at the top - the second read
    for (var _i = 0; _i < 5; _i++) {
        var _x = -0.26 + _i * 0.13;
        array_push(_p, crs_c_spike(_x * 0.6, -0.30, _x * 0.85, -0.42, 0.038, CRS_R_CHARGE));
    }
    array_push(_p, crs_rect_fill(-0.16, -0.06, 0.16, 0.06, CRS_R_DETAIL));     // THE BINDING
    return _p;
}

/// ============================================================================================
/// 3.5  sacred - 7
/// ============================================================================================

/// sun - sun in splendour, straight and wavy rays alternating.
/// 20px: a disc with a full ray ring.
function crs_ch_sun() {
    var _p = [];
    array_push(_p, crs_dot(0.00, 0.00, 0.235, CRS_R_CHARGE));                  // the disc
    // A FULL RING of rays, alternating straight and wavy - the "splendour". Against `mullet`, which
    // is six DISCRETE points and no disc at all.
    for (var _i = 0; _i < 16; _i++) {
        var _a = _i / 16 * CRS_TAU;
        var _len = ((_i % 2) == 0) ? 0.47 : 0.40;
        array_push(_p, crs_c_spike(cos(_a) * 0.22, sin(_a) * 0.22,
                                   cos(_a) * _len, sin(_a) * _len, 0.042, CRS_R_CHARGE));
    }
    array_push(_p, crs_dot(0.00, 0.00, 0.115, CRS_R_DETAIL));                  // the face
    return _p;
}

/// crescent - moon, horns up.
/// 20px: an open crescent - horns UP separates it from `bow`.
/// ⛔ A TRUE LUNE, NOT A DISC WITH A FIELD-COLOURED BITE OUT OF IT. The first version was the
/// obvious construction - draw a big disc, then draw a smaller offset disc in the FIELD's colour
/// over it - and it is wrong twice over:
///
///   1. The bite disc reached r=0.64 against a 0.50 budget. It is not ink, so it does not put the
///      CHARGE outside the shield - but it still PAINTS, in the field's colour, and at that radius
///      it would have scrubbed a field-coloured hole through whatever ordinary lay underneath. The
///      in-engine extent measurement caught it because that measurement counts every part that
///      paints, not only the ones that read as the charge.
///   2. It only ever looked right on a plain field. On a bend or a quarterly, the "bite" would have
///      been the wrong colour - the same class of mistake as the mask-by-painting fix that
///      crs_shields' clipping note rejects, arriving from a different direction.
///
/// So the crescent is the actual geometric shape: the band between two circles of equal radius,
/// offset vertically, drawn as ONE triangle strip. It is a single solid mass, it composes over any
/// ordinary, and its horns are the natural cusps where the two arcs meet.
function crs_ch_crescent() {
    var _p = [];
    // Outer circle centre (0, 0.06); inner circle centre (0, -0.10); both r = 0.40. The inner one
    // sits ABOVE, so the bite is taken out of the top and the horns point UP - which is the whole
    // separation from `bow`, a vertical arc closed by a straight string.
    //
    // They intersect at x = +-sqrt(r^2 - (dy/2)^2) = +-0.3919, y = -0.02. Both arcs are walked from
    // the SINISTER horn to the DEXTER one so the strip's two rails start together; reversing one
    // would connect each horn to the opposite horn and produce a bow tie.
    var _n = 44;
    var _outer = crs_arc_pts(0.00,  0.06, 0.40, -0.2018, 3.3434, _n);
    var _inner = crs_arc_pts(0.00, -0.10, 0.40,  0.2018, 2.9398, _n);
    array_push(_p, crs_strip(_outer, _inner, CRS_R_CHARGE));
    // The cusps, thickened very slightly so the horns do not taper to an invisible point at 20px -
    // a cusp that vanishes turns a crescent back into a plain arc.
    array_push(_p, crs_dot( 0.3919, -0.02, 0.030, CRS_R_CHARGE));
    array_push(_p, crs_dot(-0.3919, -0.02, 0.030, CRS_R_CHARGE));
    return _p;
}

/// mullet - six-pointed star, pierced.
/// 20px: a six-point star with a hole.
function crs_ch_mullet() {
    var _p = [];
    // SIX DISCRETE POINTS that break the outline, and a PIERCING. Both facts separate it from
    // `sun` (a disc with a ring of rays) and from `wheel` (an unbroken heavy rim).
    for (var _i = 0; _i < 6; _i++) {
        var _a = pi * 1.5 + _i / 6 * CRS_TAU;
        array_push(_p, crs_c_spike(cos(_a) * 0.10, sin(_a) * 0.10,
                                   cos(_a) * 0.47, sin(_a) * 0.47, 0.115, CRS_R_CHARGE));
    }
    array_push(_p, crs_dot(0.00, 0.00, 0.175, CRS_R_CHARGE));                  // the star's body
    array_push(_p, crs_dot(0.00, 0.00, 0.085, CRS_R_FIELD));                   // THE PIERCING
    return _p;
}

/// flame - a single flame, three tongues.
/// 20px: a teardrop with a notched top.
function crs_ch_flame() {
    var _p = [];
    // THE TEARDROP - broad and round at the foot, drawn to a point at the head. One mass.
    var _body = [];
    crs_append(_body, crs_qbez([0.00, -0.46], [0.26, -0.10], [0.24, 0.14], 10));
    crs_append(_body, crs_qbez([0.24, 0.14], [0.18, 0.42], [0.00, 0.44], 8));
    crs_append(_body, crs_qbez([0.00, 0.44], [-0.18, 0.42], [-0.24, 0.14], 8));
    crs_append(_body, crs_qbez([-0.24, 0.14], [-0.26, -0.10], [0.00, -0.46], 10));
    array_push(_p, crs_ring_fill(_body, CRS_R_CHARGE, 0.00, 0.10));
    // THE NOTCH - two side tongues rising beside the main one, which is what makes it read as fire
    // rather than as a leaf.
    array_push(_p, crs_c_spike(-0.16, 0.10, -0.24, -0.24, 0.070, CRS_R_CHARGE));
    array_push(_p, crs_c_spike(0.16, 0.10, 0.24, -0.24, 0.070, CRS_R_CHARGE));
    array_push(_p, crs_c_limb(crs_qbez([0.00, 0.30], [0.10, 0.06], [0.00, -0.16], 10),
                              0.055, 0.020, CRS_R_DETAIL));                    // the inner heart
    return _p;
}

/// eye - the open eye, lashes as rays below.
/// 20px: a lens shape with a central disc.
function crs_ch_eye() {
    var _p = [];
    // THE LENS - two arcs meeting at points. Deliberately pointed at both ends, so it cannot be
    // read as the plain ellipse of a body mass.
    var _lens = [];
    crs_append(_lens, crs_qbez([-0.46, 0.00], [0.00, -0.30], [0.46, 0.00], 14));
    crs_append(_lens, crs_qbez([0.46, 0.00], [0.00, 0.30], [-0.46, 0.00], 14));
    array_push(_p, crs_ring_fill(_lens, CRS_R_CHARGE, 0.00, 0.00));
    array_push(_p, crs_dot(0.00, 0.00, 0.175, CRS_R_DETAIL));                  // iris
    array_push(_p, crs_dot(0.00, 0.00, 0.075, CRS_R_CHARGE));                  // pupil
    // LASHES AS RAYS BELOW - the corpus says below, and putting them below is what stops this
    // reading as a `sun`.
    for (var _i = 0; _i < 7; _i++) {
        var _t = (_i / 6 - 0.5) * 1.5;
        array_push(_p, crs_c_spike(_t * 0.40, 0.18 - abs(_t) * 0.10,
                                   _t * 0.46, 0.42 - abs(_t) * 0.12, 0.026, CRS_R_CHARGE));
    }
    return _p;
}

/// tree - tree eradicated, roots showing, round canopy.
/// 20px: a lollipop with a root fringe.
function crs_ch_tree() {
    // ⛔ REDRAWN 2026-08-22. A SINGLE round canopy on a straight stalk READ AS A BALLOON, or as the
    // lollipop the old comment was explicitly worried about - and the root fringe it relied on to
    // prevent that is at the BOTTOM of the mark, far too small to change what the eye settles on
    // first. Two changes, and the first matters more:
    //   1. the canopy is THREE overlapping masses instead of one ellipse. A lobed outline is the
    //      difference between foliage and a sphere, and no amount of root detail substitutes for it.
    //   2. the roots SPLAY WIDER than the trunk and are drawn as tapered limbs rather than as a
    //      spike fan, so they read as torn-up roots rather than as a brush.
    var _p = [];
    array_push(_p, crs_c_mass(0.00, -0.22, 0.235, 0.205, CRS_R_CHARGE));       // crown lobe
    array_push(_p, crs_c_mass(-0.185, -0.10, 0.175, 0.155, CRS_R_CHARGE));     // dexter lobe
    array_push(_p, crs_c_mass(0.185, -0.10, 0.175, 0.155, CRS_R_CHARGE));      // sinister lobe
    array_push(_p, crs_c_mass(0.00, -0.05, 0.200, 0.145, CRS_R_CHARGE));       // the mass beneath
    array_push(_p, crs_c_seg(0.00, 0.02, 0.00, 0.30, 0.078, 0.060, CRS_R_CHARGE)); // trunk
    // THE ROOTS - "eradicated" means torn up out of the ground, roots showing.
    array_push(_p, crs_c_limb(crs_qbez([-0.03, 0.26], [-0.13, 0.33], [-0.26, 0.36], 8),
                              0.044, 0.014, CRS_R_CHARGE));
    array_push(_p, crs_c_limb(crs_qbez([0.03, 0.26], [0.13, 0.33], [0.26, 0.36], 8),
                              0.044, 0.014, CRS_R_CHARGE));
    array_push(_p, crs_c_limb(crs_qbez([-0.01, 0.28], [-0.05, 0.37], [-0.12, 0.44], 8),
                              0.038, 0.012, CRS_R_CHARGE));
    array_push(_p, crs_c_limb(crs_qbez([0.01, 0.28], [0.05, 0.37], [0.12, 0.44], 8),
                              0.038, 0.012, CRS_R_CHARGE));
    array_push(_p, crs_c_seg(0.00, 0.06, 0.00, 0.28, 0.014, 0.014, CRS_R_DETAIL));
    return _p;
}

/// lily - fleur-de-lis, banded, with a tail.
///
/// ⛔ THE ONE CHARGE IN THIS CORPUS WITH A MEASURED PRIOR FAILURE. The previous product drew its
/// fleur with the side lobes RISING and curling OUTWARD, and it read as A PAIR OF DEVIL HORNS on
/// that product's hero image - while passing part count, north-is-up, distinctness and ink bounds.
/// A fleur reads from exactly three facts, and all three are enforced below:
///   1. the side lobes' tips HANG DOWN,
///   2. the lobes are FILLED MASSES, never open curls,
///   3. there is a BAND with a TAIL below it.
/// crs_selftest asserts fact 1 numerically, because it is the one that failed.
/// 20px: the lily - side lobes hang DOWN.
function crs_ch_lily() {
    var _p = [];
    // The central petal: a tall leaf, pointed at the top, widening to the band.
    array_push(_p, crs_fill([[0.00, -0.46], [0.11, -0.18], [0.10, 0.06],
                             [-0.10, 0.06], [-0.11, -0.18]], CRS_R_CHARGE));
    array_push(_p, crs_fill(crs_lily_lobe(-1), CRS_R_CHARGE));
    array_push(_p, crs_fill(crs_lily_lobe(1), CRS_R_CHARGE));
    array_push(_p, crs_rect_fill(-0.28, 0.06, 0.28, 0.17, CRS_R_CHARGE));      // THE BAND
    array_push(_p, crs_fill([[-0.11, 0.17], [0.11, 0.17], [0.07, 0.44], [-0.07, 0.44]], CRS_R_CHARGE)); // THE TAIL
    array_push(_p, crs_c_seg(-0.24, 0.115, 0.24, 0.115, 0.014, 0.014, CRS_R_DETAIL));
    return _p;
}

/// One side lobe of the fleur, for _dx = -1 (dexter) or +1 (sinister).
///
/// ⛔ A NAMED FUNCTION RATHER THAN AN INLINE LOOP, AND THAT IS ENTIRELY FOR THE TEST. The lobes'
/// tips must hang DOWN - it is the fact whose absence made a previous product's fleur read as a
/// pair of devil horns - and crs_selftest has to be able to check it. Its first attempt FOUND the
/// lobes heuristically, by looking for filled polygons that sit off the centre line, and that
/// picked up the band and the tail as well: it reported "expected 2 side lobes, found 4" and its
/// "the lobe hangs down" assertion had been passing against the TAIL.
///
/// A test that has to guess which part of a drawing it is looking at is a test that will eventually
/// assert something true about the wrong part. Naming the lobe removes the guess: the suite calls
/// this function directly and checks the actual claim.
///
/// The points are ordered start -> outward -> tip, so pts[0] is the lobe's root at the band and the
/// LAST point is its tip. The suite reads exactly those two.
function crs_lily_lobe(_dx) {
    return [[_dx * 0.06, 0.02],       // root, at the band
            [_dx * 0.24, -0.22],      // sweeps up and OUT
            [_dx * 0.40, -0.06],      // the outer shoulder
            [_dx * 0.30, 0.10],
            [_dx * 0.34, 0.16]];      // THE TIP - below the root. This is the whole fleur.
}

/// ============================================================================================
/// 3.6  land - 6
/// ============================================================================================

/// tower - single crenellated tower, one arched door.
/// 20px: a narrow block with a toothed top.
function crs_ch_tower() {
    var _p = [];
    // ONE MASS. Against `gate`, which is TWO masses with a grid between them - that count is the
    // entire separation and it must survive at 20px, so this one stays narrow and undivided.
    array_push(_p, crs_rect_fill(-0.20, -0.26, 0.20, 0.44, CRS_R_CHARGE));
    for (var _i = 0; _i < 3; _i++) {
        array_push(_p, crs_rect_fill(-0.22 + _i * 0.16, -0.42, -0.10 + _i * 0.16, -0.26, CRS_R_CHARGE));
    }
    // the arched door: a void, so it reads as an opening
    array_push(_p, crs_dot(0.00, 0.26, 0.085, CRS_R_DETAIL));
    array_push(_p, crs_rect_fill(-0.085, 0.26, 0.085, 0.44, CRS_R_DETAIL));
    array_push(_p, crs_c_seg(-0.18, -0.06, 0.18, -0.06, 0.014, 0.014, CRS_R_DETAIL));
    return _p;
}

/// gate - twin towers with a portcullis between.
/// 20px: two verticals joined by a grid.
function crs_ch_gate() {
    var _p = [];
    for (var _s = 0; _s < 2; _s++) {
        var _x = (_s == 0) ? -0.30 : 0.16;
        array_push(_p, crs_rect_fill(_x, -0.24, _x + 0.14, 0.36, CRS_R_CHARGE));
        for (var _i = 0; _i < 2; _i++) {
            array_push(_p, crs_rect_fill(_x + _i * 0.08, -0.38, _x + 0.06 + _i * 0.08, -0.24, CRS_R_CHARGE));
        }
    }
    // THE PORTCULLIS GRID - the second mass and the second read at once. A gate with no grid is
    // two towers, which is not a charge in this corpus.
    array_push(_p, crs_rect_fill(-0.18, -0.19, 0.18, -0.11, CRS_R_CHARGE));    // the arch head
    for (var _i = 0; _i < 4; _i++) {
        array_push(_p, crs_rect_fill(-0.17 + _i * 0.10, -0.11, -0.13 + _i * 0.10, 0.28, CRS_R_CHARGE));
    }
    for (var _i = 0; _i < 2; _i++) {
        array_push(_p, crs_rect_fill(-0.18, 0.00 + _i * 0.13, 0.18, 0.04 + _i * 0.13, CRS_R_CHARGE));
    }
    return _p;
}

/// mount - three-peaked mountain, the classic heraldic mount.
/// 20px: three joined triangles.
function crs_ch_mount() {
    var _p = [];
    // THREE peaks sharing one base, the centre highest. The count is the identification: two would
    // be a chevron, one would be a pile.
    // ⚠️ The base corners are a DIAGONAL from the origin, so a wide low mount spends its whole
    // budget on them: the first draft reached 0.572 at (±0.46, 0.34) against a limit of 0.50. The
    // mount is narrower AND shallower here, which is a redraw - the alternative, raising the limit
    // to whatever got drawn, is the move master CLAUDE.md §4.2b forbids by name.
    array_push(_p, crs_fill([[-0.36, 0.30], [-0.19, -0.06], [-0.02, 0.30]], CRS_R_CHARGE));
    array_push(_p, crs_fill([[0.02, 0.30], [0.19, -0.06], [0.36, 0.30]], CRS_R_CHARGE));
    array_push(_p, crs_fill([[-0.21, 0.30], [0.00, -0.34], [0.21, 0.30]], CRS_R_CHARGE));
    array_push(_p, crs_rect_fill(-0.36, 0.26, 0.36, 0.34, CRS_R_CHARGE));      // the joined base
    array_push(_p, crs_c_spike(0.00, -0.16, 0.00, -0.36, 0.075, CRS_R_DETAIL)); // the snow cap
    return _p;
}

/// river - a barrulet wavy, two undulations.
/// 20px: a horizontal wave band.
function crs_ch_river() {
    var _p = [];
    // ONE heavy band and two lighter ones. A single wave reads as a stray line at 20px; three
    // stacked waves read as water, which is the point.
    array_push(_p, crs_c_wave(-0.40, 0.40, 0.00, 0.115, 2, 0.070, CRS_R_CHARGE));
    array_push(_p, crs_c_wave(-0.40, 0.40, -0.22, 0.085, 2, 0.035, CRS_R_CHARGE));
    array_push(_p, crs_c_wave(-0.40, 0.40, 0.22, 0.085, 2, 0.035, CRS_R_CHARGE));
    array_push(_p, crs_c_wave(-0.36, 0.36, 0.00, 0.115, 2, 0.020, CRS_R_DETAIL));
    return _p;
}

/// bridge - arched bridge of two spans on piers.
/// 20px: two arches on a base line.
function crs_ch_bridge() {
    var _p = [];
    array_push(_p, crs_rect_fill(-0.40, -0.24, 0.40, -0.10, CRS_R_CHARGE));    // the deck
    array_push(_p, crs_rect_fill(-0.36, -0.10, -0.24, 0.24, CRS_R_CHARGE));    // abutment
    array_push(_p, crs_rect_fill(-0.05, -0.10, 0.05, 0.24, CRS_R_CHARGE));     // centre pier
    array_push(_p, crs_rect_fill(0.24, -0.10, 0.36, 0.24, CRS_R_CHARGE));      // abutment
    // TWO ARCHES, as filled haunches over voids. Two, not one: one span is a `gate` arch.
    for (var _s = 0; _s < 2; _s++) {
        var _cx = (_s == 0) ? -0.15 : 0.15;
        array_push(_p, crs_c_limb(crs_arc_pts(_cx, 0.02, 0.125, pi, CRS_TAU, 14),
                                  0.050, 0.050, CRS_R_CHARGE));
    }
    array_push(_p, crs_rect_fill(-0.36, 0.24, 0.36, 0.32, CRS_R_CHARGE));      // the base line
    array_push(_p, crs_c_seg(-0.36, -0.175, 0.36, -0.175, 0.014, 0.014, CRS_R_DETAIL));
    return _p;
}

/// well - round wellhead with a roof on two posts.
/// 20px: a circle under a gable.
function crs_ch_well() {
    var _p = [];
    array_push(_p, crs_fill([[0.00, -0.46], [0.38, -0.18], [-0.38, -0.18]], CRS_R_CHARGE)); // THE GABLE
    array_push(_p, crs_rect_fill(-0.30, -0.20, -0.22, 0.12, CRS_R_CHARGE));    // post
    array_push(_p, crs_rect_fill(0.22, -0.20, 0.30, 0.12, CRS_R_CHARGE));      // post
    // THE CIRCLE - a round wellhead, drawn as a mass so it survives being small.
    array_push(_p, crs_c_mass(0.00, 0.22, 0.30, 0.21, CRS_R_CHARGE));
    array_push(_p, crs_c_mass(0.00, 0.06, 0.30, 0.10, CRS_R_DETAIL));          // the mouth
    array_push(_p, crs_c_seg(0.00, -0.18, 0.00, 0.02, 0.016, 0.016, CRS_R_DETAIL)); // the rope
    return _p;
}
