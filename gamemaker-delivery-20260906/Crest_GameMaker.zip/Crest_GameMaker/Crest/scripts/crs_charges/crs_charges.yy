{
  "$GMScript": "v1",
  "%Name": "crs_charges",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_charges",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}