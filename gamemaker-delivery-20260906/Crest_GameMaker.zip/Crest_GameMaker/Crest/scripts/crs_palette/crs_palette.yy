{
  "$GMScript": "v1",
  "%Name": "crs_palette",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_palette",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}