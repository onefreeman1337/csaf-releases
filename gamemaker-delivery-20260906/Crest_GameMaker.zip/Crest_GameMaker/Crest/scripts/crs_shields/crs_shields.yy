{
  "$GMScript": "v1",
  "%Name": "crs_shields",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_shields",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}