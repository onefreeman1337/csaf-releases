/// ============================================================================================
/// CREST - crs_shields: the eight shield shapes, and the third term of the coordinate contract.
///
/// A shield is an OUTLINE plus three declarations: where a charge sits on it, how much of the
/// charge's authored size it can carry, and how much room there actually is. The first two are
/// design; the third is the number that keeps a charge inside the field, and it is per-shape
/// because a shield is not a disc.
///
/// -- WHY THE FIT IS PER-SHIELD, AND NOT ONE GLOBAL NUMBER --------------------------------------
/// ⛔ This is the term an inherited contract would have missed, and it fails in the direction that
/// ships. A lozenge is a diamond: the largest disc that fits inside it about its centre has radius
/// a*b/hypot(a,b), which for this corpus's proportions is 0.32 - against 0.48 for a roundel of the
/// same overall size. With one global fit sized for the roundel, every charge placed on a lozenge
/// or a kite would hang out over the edge, and a contract check written as
/// `BOX * FIT + INSET <= 0.5` would report NO violation at all, because 0.5 is a number about a
/// circle and none of these shapes is one.
///
/// It is also what real heraldry does: a charge on a lozenge IS drawn smaller. So the contract is
/// checked eight times, once per shape:
///
///     CRS_CHARGE_BOX * CRS_CHARGE_FIT * crs_shield_fit(id) + CRS_FIELD_INSET
///         <= crs_shield_inradius(id)
///
/// Internal_Ops/check_charges.js re-does that arithmetic for all eight from the source. It CANNOT
/// check that the declared inradius is true of the outline - that needs the real polygon - so
/// crs_selftest measures each declaration against crs_shield_pts() point by point. A declared
/// number nobody measures is a guess wearing a constant's clothes.
/// ============================================================================================

/// The eight shapes. Order is the buyer-facing order in the Readme and in the panel's picker.
function crs_shield_ids() {
    return ["heater", "kite", "oval", "lozenge", "banner", "pennon", "roundel", "targe"];
}

function crs_shield_name(_id) {
    switch (_id) {
        case "heater":  return "Heater";
        case "kite":    return "Kite";
        case "oval":    return "Oval";
        case "lozenge": return "Lozenge";
        case "banner":  return "Banner";
        case "pennon":  return "Pennon";
        case "roundel": return "Roundel";
        default:        return "Targe";
    }
}

/// Where the charge sits. Heraldry calls it the fess point and it is ABOVE the geometric centre on
/// any shield that tapers downward - a charge centred in the bounding box of a heater looks like it
/// is sliding off the bottom, because the mass of the shape is above it.
function crs_shield_anchor(_id) {
    switch (_id) {
        case "heater":  return [0.00, -0.10];
        case "kite":    return [0.00, -0.22];
        case "pennon":  return [-0.14, 0.00];
        default:        return [0.00, 0.00];
    }
}

/// How much of a charge's authored size this shape can carry, as a factor on CRS_CHARGE_FIT.
/// Derived from the inradius below, not chosen: see the header.
function crs_shield_fit(_id) {
    switch (_id) {
        case "heater":  return 0.95;
        case "kite":    return 0.60;
        case "oval":    return 0.95;
        case "lozenge": return 0.82;
        case "banner":  return 1.00;
        case "pennon":  return 0.72;
        case "roundel": return 1.00;
        default:        return 0.96;    // targe - a rim is left clear of the boss
    }
}

/// The radius of the largest disc centred on the anchor that fits inside this outline.
///
/// ⚠️ DECLARED HERE, MEASURED IN crs_selftest. Each of these is a claim about the polygon returned
/// by crs_shield_pts(), and a claim is not evidence. The suite walks every outline segment and
/// fails if the true distance is below the number stated here - so a shape edited without updating
/// its radius goes red, which is the only way this stays true.
function crs_shield_inradius(_id) {
    switch (_id) {
        case "heater":  return 0.36;
        case "kite":    return 0.26;
        case "oval":    return 0.399;
        case "lozenge": return 0.32;
        case "banner":  return 0.44;
        case "pennon":  return 0.30;
        case "roundel": return 0.478;
        default:        return 0.478;   // targe
    }
}

/// The outline of a shield, as a closed ring of points (the first point is NOT repeated).
/// Unit space, [-0.5, 0.5] on both axes, y down.
function crs_shield_pts(_id) {
    var _p = [];
    switch (_id) {

        case "heater": {
            // Flat top, straight sides, then two curves meeting at a point. The archetype.
            array_push(_p, [-0.42, -0.46], [0.42, -0.46], [0.42, -0.06]);
            crs_append(_p, crs_qbez([0.42, -0.06], [0.40, 0.30], [0.00, 0.50], 12));
            crs_append(_p, crs_qbez([0.00, 0.50], [-0.40, 0.30], [-0.42, -0.06], 12));
            return _p;
        }

        case "kite": {
            // Norman: a rounded head and a long taper. Half the shape is below the anchor, which is
            // why its fit factor is the smallest in the set.
            crs_append(_p, crs_qbez([-0.30, -0.34], [-0.30, -0.50], [0.00, -0.50], 8));
            crs_append(_p, crs_qbez([0.00, -0.50], [0.30, -0.50], [0.30, -0.34], 8));
            crs_append(_p, crs_qbez([0.30, -0.34], [0.26, 0.16], [0.00, 0.50], 14));
            crs_append(_p, crs_qbez([0.00, 0.50], [-0.26, 0.16], [-0.30, -0.34], 14));
            return _p;
        }

        case "oval":    return crs_ellipse_pts(0.00, 0.00, 0.40, 0.48, 48);
        case "lozenge": return [[0.00, -0.50], [0.42, 0.00], [0.00, 0.50], [-0.42, 0.00]];
        case "banner":  return [[-0.44, -0.44], [0.44, -0.44], [0.44, 0.44], [-0.44, 0.44]];

        case "pennon": {
            // Swallow-tailed: a flag with a V cut into the fly. The notch is why its anchor sits to
            // the dexter rather than at the centre - a charge on the middle of a pennon would be
            // half in the notch.
            return [[-0.46, -0.36], [0.46, -0.36], [0.16, 0.00], [0.46, 0.36], [-0.46, 0.36]];
        }

        case "roundel": return crs_ellipse_pts(0.00, 0.00, 0.48, 0.48, 48);
        default:        return crs_ellipse_pts(0.00, 0.00, 0.48, 0.48, 48);   // targe
    }
}

/// ============================================================================================
/// PLACEMENT
/// ============================================================================================

/// The field: the shield's whole area, filled. Drawn first, under everything.
function crs_shield_field(_id) {
    var _pts = crs_shield_pts(_id);
    return crs_ring_fill(_pts, CRS_R_FIELD, 0.00, 0.00);
}

/// The shield's own edge, as a closed stroke. Optional - some arms read better without it - so it
/// is returned separately rather than baked into the field.
function crs_shield_edge(_id, _w) {
    return crs_poly(crs_shield_pts(_id), true, _w, CRS_R_EDGE);
}

/// Furniture that belongs to one shape only. Kept out of crs_shield_pts because a boss is not part
/// of the outline and must never affect the inradius.
function crs_shield_furniture(_id) {
    var _p = [];
    if (_id == "targe") {
        // The boss and its rivets. This is what makes a targe read as a different object from a
        // roundel rather than as the same circle with a different name.
        array_push(_p, crs_dot(0.00, 0.00, 0.115, CRS_R_EDGE));
        array_push(_p, crs_dot(0.00, 0.00, 0.062, CRS_R_DETAIL));
        for (var _i = 0; _i < 8; _i++) {
            var _a = _i / 8 * CRS_TAU;
            array_push(_p, crs_dot(cos(_a) * 0.40, sin(_a) * 0.40, 0.028, CRS_R_EDGE));
        }
    }
    return _p;
}

/// Place a charge's unit-box parts onto a shield drawn at (_cx, _cy) with half-extent _size.
///
/// The whole coordinate contract lands here in one expression, and there is deliberately nowhere
/// else in the package that maps a charge onto a shield - a second copy of this arithmetic is how
/// the contract stops being one.
function crs_place_charge(_parts, _shield, _cx, _cy, _size, _map, _hasCadency) {
    var _a = crs_charge_anchor(_shield, _hasCadency);
    var _s = _size * 2 * CRS_CHARGE_FIT * crs_shield_fit(_shield) * crs_charge_squeeze(_hasCadency);
    return crs_place(_parts, _cx + _a[0] * _size * 2, _cy + _a[1] * _size * 2, _s, 0,
                     _s / (_size * 2), _map);
}

/// The scale a charge is drawn at. One factor, and it is 1 unless the arms bear a mark of cadency.
function crs_charge_squeeze(_hasCadency) {
    return (is_undefined(_hasCadency) || !_hasCadency) ? 1 : CRS_CAD_SQUEEZE;
}

/// Where a charge is actually centred, which is NOT always the shield's fess point.
///
/// ⛔ A charge sharing its shield with a mark of cadency is drawn smaller AND pushed down, because
/// there is no height at which a full-size charge and a mark both fit - the in-engine suite proved
/// that on all eight shields at once. The shift is DERIVED from the mark's own measured extent
/// rather than tabulated per shape, so it stays correct if a mark is redrawn or a shield is added.
///
/// max() rather than a fixed offset: most shields anchor at the centre and need no shift at all,
/// and pushing those down would move a charge for no reason.
function crs_charge_anchor(_shield, _hasCadency) {
    var _a = crs_shield_anchor(_shield);
    if (is_undefined(_hasCadency) || !_hasCadency) return _a;
    var _reach = CRS_CHARGE_BOX * CRS_CHARGE_FIT * crs_shield_fit(_shield) * CRS_CAD_SQUEEZE;
    return [_a[0], max(_a[1], CRS_CAD_LOW + _reach)];
}

/// Place any unit-box part list onto the shield's own space - used for ordinaries and cadency
/// marks, which are authored in the SHIELD's box rather than the charge's.
function crs_place_shieldwise(_parts, _cx, _cy, _size, _map) {
    return crs_place(_parts, _cx, _cy, _size * 2, 0, 1, _map);
}

/// ============================================================================================
/// CLIPPING - how an ordinary stops at the shield's edge
///
/// ⛔ THE OBVIOUS SOLUTION IS WRONG AND IT IS WORTH SAYING WHY, BECAUSE IT LOOKS RIGHT.
///
/// The first implementation drew the ordinary over the field and then painted everything OUTSIDE
/// the shield in the field's own colour, "masking" the overflow. It clips perfectly - and it also
/// paints a shield-coloured slab over whatever the buyer had drawn behind it. It only looks correct
/// on a page whose background happens to match the field, which is exactly the condition a store
/// screenshot is taken under. It would have shipped and broken in every real game.
///
/// A renderer cannot mask by painting, because it does not know what is behind it. So the clip
/// happens in GEOMETRY, here, where it belongs: every ordinary is reduced to triangles and each
/// triangle is intersected with the shield's outline. Exact for all 8 x 14 pairs, no surface, no
/// shader, and nothing that can leak GPU state into a buyer's Draw event.
///
/// ⚠️ THE CHARGE IS NOT CLIPPED, AND THAT IS THE POINT OF THE CONTRACT. The per-shield inradius
/// above guarantees a charge is already inside the field, so clipping it would be work that can
/// never change a pixel. Everything the contract buys is spent right here.
/// ============================================================================================

/// A shield as one or more CONVEX rings whose union is the whole shape.
///
/// Seven of the eight are convex already. The pennon is not - its swallow-tail notch is a reflex
/// vertex - and Sutherland-Hodgman against a concave clipper produces degenerate edges rather than
/// an error, so it would have silently drawn a pennon's ordinaries with a wedge glued across the
/// notch. It is split at the notch into two convex halves instead.
function crs_shield_convex_pieces(_id) {
    if (_id == "pennon") {
        return [
            [[-0.46, -0.36], [0.46, -0.36], [0.16, 0.00], [-0.46, 0.00]],
            [[-0.46, 0.00], [0.16, 0.00], [0.46, 0.36], [-0.46, 0.36]]
        ];
    }
    return [crs_shield_pts(_id)];
}

/// The signed area of a ring, by the shoelace formula. Its SIGN is the ring's winding.
function crs_ring_area2(_ring) {
    var _n = array_length(_ring);
    var _a = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _p = _ring[_i], _q = _ring[(_i + 1) % _n];
        _a += _p[0] * _q[1] - _q[0] * _p[1];
    }
    return _a;
}

/// Sutherland-Hodgman: clip a polygon to a CONVEX ring. Returns the clipped polygon, possibly empty.
///
/// ⛔ THE WINDING IS MEASURED, NOT ASSUMED, AND ASSUMING IT CLIPPED EVERYTHING TO NOTHING.
/// The first version's comment said "the ring must be counter-clockwise in y-down space, which
/// every ring produced above is" - and then hard-coded `inside = cross <= 0`. It was backwards for
/// the rings this file actually produces, so the interior tested as OUTSIDE and every polygon was
/// clipped away completely. The in-engine suite reported "clipping a bend to <shield> produced
/// nothing" for all EIGHT shields, which is the whole ordinary system silently drawing nothing.
///
/// A comment claiming a winding is a claim. The shoelace sign is a measurement, it costs one pass
/// over the ring, and it makes this function correct for any ring anybody adds later.
function crs_clip_poly(_poly, _ring) {
    var _out = _poly;
    var _rn = array_length(_ring);
    var _sign = (crs_ring_area2(_ring) >= 0) ? 1 : -1;
    for (var _e = 0; _e < _rn; _e++) {
        var _n = array_length(_out);
        if (_n == 0) return _out;
        var _a = _ring[_e], _b = _ring[(_e + 1) % _rn];
        var _ex = _b[0] - _a[0], _ey = _b[1] - _a[1];
        var _next = [];
        for (var _i = 0; _i < _n; _i++) {
            var _p = _out[_i], _q = _out[(_i + 1) % _n];
            // Cross product sign decides which side of an edge a point is on; multiplying by the
            // ring's own winding sign makes "inside" mean inside regardless of how it was wound.
            var _dp = (_ex * (_p[1] - _a[1]) - _ey * (_p[0] - _a[0])) * _sign;
            var _dq = (_ex * (_q[1] - _a[1]) - _ey * (_q[0] - _a[0])) * _sign;
            var _pin = (_dp >= 0), _qin = (_dq >= 0);
            if (_pin) array_push(_next, _p);
            if (_pin != _qin) {
                var _den = _dp - _dq;
                // Guard the divide: a segment exactly ON the edge gives _den == 0, and in GML a
                // divide by zero does not throw - it produces a value that silently corrupts the
                // polygon. Skipping the intersection is correct here: both endpoints are on the
                // boundary, so the edge is already represented.
                if (_den != 0) {
                    var _t = _dp / _den;
                    array_push(_next, [_p[0] + (_q[0] - _p[0]) * _t, _p[1] + (_q[1] - _p[1]) * _t]);
                }
            }
        }
        _out = _next;
    }
    return _out;
}

/// Reduce a part list to flat triangles, keeping each part's role. Every kind this package emits
/// is covered; a DOT becomes a 16-gon, which is indistinguishable at the sizes an ordinary is drawn.
function crs_parts_to_tris(_parts) {
    var _tris = [];
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case CRS_DOT: {
                var _ring = crs_ellipse_pts(_p.cx, _p.cy, _p.r, _p.r, 16);
                for (var _k = 1; _k < 15; _k++) {
                    array_push(_tris, { role: _p.role, t: [_ring[0], _ring[_k], _ring[_k + 1]] });
                }
            } break;
            case CRS_FILL: {
                for (var _k = 1; _k + 1 < array_length(_p.pts); _k++) {
                    array_push(_tris, { role: _p.role, t: [_p.pts[0], _p.pts[_k], _p.pts[_k + 1]] });
                }
            } break;
            case CRS_STRIP: {
                var _n = min(array_length(_p.a), array_length(_p.b));
                for (var _k = 0; _k + 1 < _n; _k++) {
                    array_push(_tris, { role: _p.role, t: [_p.a[_k], _p.b[_k], _p.a[_k + 1]] });
                    array_push(_tris, { role: _p.role, t: [_p.b[_k], _p.a[_k + 1], _p.b[_k + 1]] });
                }
            } break;
            default: break;   // stroked polylines and arcs are never used by an ordinary
        }
    }
    return _tris;
}

/// Clip a shield-space part list to a shield, returning FILL parts ready to draw.
function crs_clip_parts_to_shield(_parts, _shield) {
    var _tris = crs_parts_to_tris(_parts);
    var _pieces = crs_shield_convex_pieces(_shield);
    var _out = [];
    for (var _i = 0; _i < array_length(_tris); _i++) {
        for (var _k = 0; _k < array_length(_pieces); _k++) {
            var _c = crs_clip_poly(_tris[_i].t, _pieces[_k]);
            if (array_length(_c) >= 3) array_push(_out, crs_fill(_c, _tris[_i].role));
        }
    }
    return _out;
}

/// Clipped geometry, cached.
///
/// Clipping a bordure is ~160 triangles against a 48-gon, which is real work to repeat 60 times a
/// second for something that never changes. The result depends only on (shield, key), so it is
/// computed once and kept. crs_faction_reset does not clear this - the geometry is not world state,
/// and re-deriving it after a new game would be work with no observable effect.
function crs_clipped_cached(_shield, _key, _parts) {
    if (!variable_global_exists("__crs_geo")) global.__crs_geo = {};
    var _ck = _shield + ":" + _key;
    if (variable_struct_exists(global.__crs_geo, _ck)) {
        return variable_struct_get(global.__crs_geo, _ck);
    }
    var _v = crs_clip_parts_to_shield(_parts, _shield);
    variable_struct_set(global.__crs_geo, _ck, _v);
    return _v;
}

/// The true inradius of a shape, measured over its real outline. Used by crs_selftest to check the
/// declaration above, and available to a buyer who edits a shield and needs the new number.
///
/// Distance from the anchor to every SEGMENT of the ring, not to every vertex: a polygon's nearest
/// point is almost never a vertex, and measuring vertices alone reports a radius larger than the
/// truth - which would make this check pass exactly when it matters.
function crs_shield_measure_inradius(_id) {
    var _a = crs_shield_anchor(_id);
    return crs_shield_measure_inradius_at(_id, _a[0], _a[1]);
}

/// The same measurement about an ARBITRARY point. Needed because a charge bearing a mark of cadency
/// is pushed down off the fess point, so the room available to it is not the room at the anchor.
function crs_shield_measure_inradius_at(_id, _ax, _ay) {
    var _pts = crs_shield_pts(_id);
    var _a = [_ax, _ay];
    var _n = array_length(_pts);
    var _best = 999999;
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[_i], _q = _pts[(_i + 1) % _n];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len2 = _dx * _dx + _dy * _dy;
        var _t = 0;
        if (_len2 > 0) _t = clamp(((_a[0] - _p[0]) * _dx + (_a[1] - _p[1]) * _dy) / _len2, 0, 1);
        var _d = point_distance(_a[0], _a[1], _p[0] + _dx * _t, _p[1] + _dy * _t);
        if (_d < _best) _best = _d;
    }
    return _best;
}
