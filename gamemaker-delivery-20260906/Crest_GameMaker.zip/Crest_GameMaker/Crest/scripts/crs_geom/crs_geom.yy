{
  "$GMScript": "v1",
  "%Name": "crs_geom",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_geom",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}