{
  "$GMScript": "v1",
  "%Name": "crs_render",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_render",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}