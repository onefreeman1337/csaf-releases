/// ============================================================================================
/// CREST - crs_render: the ONLY file in this package that talks to the GPU.
///
/// Everything above this file produces DATA. crs_charges returns arrays of structs, crs_faction
/// keeps a registry, crs_arms returns a struct describing a coat of arms. None of them can draw and
/// none knows what a surface is. This file turns all of it into draw calls and knows nothing about
/// what a `lion`, a `saltire` or a schism means.
///
/// That split is not tidiness. It is what lets crs_selftest assert the entire corpus, the whole
/// coordinate contract and the whole faction system HEADLESSLY, on a machine with no window - and
/// this wing's constitution is explicit that GML has no other route to an automated test.
///
/// -- STATE IS SAVED AND RESTORED AT EVERY ENTRY POINT ------------------------------------------
/// Colour, alpha, font, halign, valign. A renderer that leaks GPU state into a buyer's Draw event
/// produces a bug three files away from its cause, in their code, which they cannot reproduce and
/// we cannot debug remotely. Every public function here puts back what it found.
/// ============================================================================================

/// The stroke floor. NOT a rounding tweak and NOT tunable per call.
///
/// ⛔ THIS CONSTANT EXISTS BECAUSE OF A MEASURED SHIPPING FAILURE. Stroke widths in this package are
/// a PROPORTION of the shield, so a charge drawn at 20px has a detail line of 0.014 * 20 = 0.28px,
/// and GameMaker draws that at roughly a quarter coverage - a grey smear rather than a line. A
/// previous product in this wing shipped a whole corpus that way: 369 in-engine assertions passed,
/// the extent check passed, the ink-bounds check passed, and the marks were grey dust. It took
/// opening the PNG and looking.
///
/// Crest's charges are FILLED MASSES precisely so they do not depend on this, and the floor covers
/// what is left: the detail lines and the shield edge.
#macro CRS_W_FLOOR 1.00

/// Resolve a part's role to a colour, against the arms being drawn.
///
/// One function, and it is the only place in the package that turns a role into a colour. That is
/// what lets the same 44 charges appear in every legal tincture pair without the geometry knowing
/// anything about colour, and what makes the rule of tincture enforceable in one place.
function crs_role_colour(_role, _arms) {
    switch (_role) {
        case CRS_R_FIELD:  return crs_tincture_colour(_arms.field);
        case CRS_R_ORD:    return crs_tincture_colour(_arms.ord_t);
        case CRS_R_CHARGE: return crs_tincture_colour(_arms.charge_t);
        case CRS_R_DETAIL: return crs_tincture_detail_colour(_arms.charge_t);
        default:           return crs_tincture_detail_colour(_arms.field);
    }
}

/// ============================================================================================
/// FONTS - the only two places either font resource is named
/// ============================================================================================

/// The body font, used for faction names, blazons, relation rows and standing figures.
///
/// ⛔ SUBSTITUTING A FONT IS A ONE-LINE EDIT, AND THAT IS THE ENTIRE POINT OF THIS FUNCTION.
/// Before it existed, fnt_crest and fnt_crest_title were named directly at seven call sites inside
/// crs_panel, which made the licence's "you may substitute your own font freely" true only in the
/// sense that a buyer could run a find-and-replace across the package. A buyer changing the look of
/// their own UI should not have to touch seven lines of somebody else's drawing code.
///
/// Return any font resource you like from these two. Nothing else in the package names a font.
function crs_font() {
    return fnt_crest;
}

/// The display font, used for panel titles and tier headings.
function crs_font_title() {
    return fnt_crest_title;
}

/// ============================================================================================
/// PRIMITIVES
/// ============================================================================================

/// Draw one placed part. Internal - call crs_draw_parts.
function crs_draw_part(_p, _arms) {
    draw_set_colour(crs_role_colour(_p.role, _arms));

    switch (_p.kind) {

        case CRS_DOT:
            draw_circle(_p.cx, _p.cy, max(0.4, _p.r), false);
            return;

        case CRS_ARC: {
            // Sampled, not draw_circle's outline: an arc here may be partial, and GameMaker's
            // circle outline ignores line width entirely.
            var _sweep = abs(_p.a1 - _p.a0);
            var _steps = max(10, ceil(_sweep * 14));
            var _w = max(CRS_W_FLOOR, _p.w);
            var _px = _p.cx + cos(_p.a0) * _p.r;
            var _py = _p.cy + sin(_p.a0) * _p.r;
            for (var _i = 1; _i <= _steps; _i++) {
                var _a = lerp(_p.a0, _p.a1, _i / _steps);
                var _nx = _p.cx + cos(_a) * _p.r;
                var _ny = _p.cy + sin(_a) * _p.r;
                draw_line_width(_px, _py, _nx, _ny, _w);
                _px = _nx; _py = _ny;
            }
            return;
        }

        case CRS_FILL: {
            var _n = array_length(_p.pts);
            if (_n < 3) return;
            draw_primitive_begin(pr_trianglefan);
            for (var _i = 0; _i < _n; _i++) draw_vertex(_p.pts[_i][0], _p.pts[_i][1]);
            draw_primitive_end();
            return;
        }

        case CRS_STRIP: {
            // ONE primitive, not N quads. Adjacent triangles in a strip share their edges; drawing
            // the same band as separate quads leaves a hairline of field showing through every
            // join, which on a bend reads as a dotted line rather than as a line.
            var _n = min(array_length(_p.a), array_length(_p.b));
            if (_n < 2) return;
            draw_primitive_begin(pr_trianglestrip);
            for (var _i = 0; _i < _n; _i++) {
                draw_vertex(_p.a[_i][0], _p.a[_i][1]);
                draw_vertex(_p.b[_i][0], _p.b[_i][1]);
            }
            draw_primitive_end();
            return;
        }

        default: {
            var _n = array_length(_p.pts);
            if (_n < 2) return;
            var _w = max(CRS_W_FLOOR, _p.w);
            for (var _i = 1; _i < _n; _i++) {
                draw_line_width(_p.pts[_i - 1][0], _p.pts[_i - 1][1],
                                _p.pts[_i][0], _p.pts[_i][1], _w);
            }
            if (_p.closed) {
                draw_line_width(_p.pts[_n - 1][0], _p.pts[_n - 1][1],
                                _p.pts[0][0], _p.pts[0][1], _w);
            }
            return;
        }
    }
}

/// Draw a placed part list.
function crs_draw_parts(_parts, _arms, _alpha) {
    if (is_undefined(_alpha)) _alpha = 1;
    var _oldC = draw_get_colour(), _oldA = draw_get_alpha();
    if (_alpha != 1) draw_set_alpha(_alpha);
    for (var _i = 0; _i < array_length(_parts); _i++) crs_draw_part(_parts[_i], _arms);
    draw_set_colour(_oldC);
    draw_set_alpha(_oldA);
}

/// ============================================================================================
/// THE ARMS
/// ============================================================================================

/// Draw a full coat of arms at (_cx, _cy) with half-extent _size.
///
/// The ordinary and the fur are authored PAST the shield's outline and are clipped to it in
/// GEOMETRY, by crs_shields - see the long note there for why the obvious "paint over the outside"
/// mask is wrong in a way that only shows up in a real game. This file just draws what it is given.
///
/// _opts is an optional struct: { edge, cadency, furs } - all default ON.
function crs_arms_draw(_arms, _cx, _cy, _size, _opts) {
    if (is_undefined(_opts)) _opts = {};
    var _oldC = draw_get_colour(), _oldA = draw_get_alpha();

    var _shield = _arms.shield;
    var _field = crs_place_shieldwise([crs_shield_field(_shield)], _cx, _cy, _size, undefined);

    // 1. the field
    crs_draw_parts(_field, _arms, 1);

    // 2. the fur pattern, if the field is a fur
    if (crs_opt_on(_opts, "furs") && crs_tincture_is_fur(_arms.field)) {
        crs_draw_clipped(crs_clipped_cached(_shield, "fur:" + _arms.field,
                                            crs_tincture_fur_parts(_arms.field)),
                         _cx, _cy, _size, crs_tincture_fur_pattern_colour(_arms.field));
    }

    // 3. the ordinary, clipped to the shield
    if (_arms.ordinary != "plain") {
        crs_draw_clipped(crs_clipped_cached(_shield, "ord:" + _arms.ordinary,
                                            crs_ordinary(_arms.ordinary)),
                         _cx, _cy, _size, crs_tincture_colour(_arms.ord_t));
    }

    // 4. the charge
    var _charge = crs_place_charge(crs_charge(_arms.charge), _shield, _cx, _cy, _size, undefined,
                                   (_arms.cadency != ""));
    crs_draw_parts(_charge, _arms, 1);

    // 5. the mark of cadency, in chief, above every anchor
    if (crs_opt_on(_opts, "cadency") && _arms.cadency != "") {
        var _cad = crs_place_shieldwise(crs_cadency(_arms.cadency), _cx, _cy, _size, undefined);
        crs_draw_parts(_cad, _arms, 1);
    }

    // 6. the shield's own edge
    if (crs_opt_on(_opts, "edge")) {
        var _edge = crs_place_shieldwise([crs_shield_edge(_shield, 0.012)], _cx, _cy, _size, undefined);
        crs_draw_parts(_edge, _arms, 1);
    }

    // 7. shape-specific furniture (the targe's boss)
    var _furn = crs_shield_furniture(_shield);
    if (array_length(_furn) > 0) {
        crs_draw_parts(crs_place_shieldwise(_furn, _cx, _cy, _size, undefined), _arms, 1);
    }

    draw_set_colour(_oldC);
    draw_set_alpha(_oldA);
}

/// Read a boolean out of an options struct, defaulting to ON.
///
/// ⚠️ A TOP-LEVEL FUNCTION, NOT A LOCAL `var _f = function(...)`. A function literal assigned to a
/// local is a METHOD in GML, bound to whatever `self` was where it was created - and this file is
/// called from a script, from the demo object's Draw GUI event and from the headless bake entry
/// point, which are three different selves. crs_geom's header records the session this wing lost
/// to exactly that binding rule. Four lines at file scope are cheaper than rediscovering it.
function crs_opt_on(_o, _k) {
    if (!variable_struct_exists(_o, _k)) return true;
    return variable_struct_get(_o, _k);
}

/// Draw already-clipped shield-space parts in one flat colour.
///
/// The parts arriving here are FILL fans produced by crs_clip_parts_to_shield and cached, so this
/// function has exactly one job: place and fill. It deliberately does not resolve roles - the
/// caller has already decided the colour, and looking the role up again would undo that.
function crs_draw_clipped(_parts, _cx, _cy, _size, _colour) {
    var _placed = crs_place_shieldwise(_parts, _cx, _cy, _size, undefined);
    var _oldC = draw_get_colour();
    draw_set_colour(_colour);
    for (var _i = 0; _i < array_length(_placed); _i++) {
        var _p = _placed[_i];
        if (_p.kind != CRS_FILL || array_length(_p.pts) < 3) continue;
        draw_primitive_begin(pr_trianglefan);
        for (var _k = 0; _k < array_length(_p.pts); _k++) draw_vertex(_p.pts[_k][0], _p.pts[_k][1]);
        draw_primitive_end();
    }
    draw_set_colour(_oldC);
}

/// ============================================================================================
/// CONVENIENCE - one call, from a buyer's Draw event
/// ============================================================================================

/// Draw a registered faction's arms. The single function most buyers will use.
function crs_faction_draw(_id, _cx, _cy, _size, _opts) {
    // `_opts` is OPTIONAL and is guarded here rather than only in crs_arms_draw. Behaviour is
    // identical (the callee does the same thing with undefined), but this is a PUBLIC entry point
    // and a public function should declare its own signature rather than borrow optionality from a
    // private callee. It also makes the contract true STATICALLY: gmtest_docsmatch reads each
    // function's own body, so a forwarded guard read as an arity mismatch against the Readme's
    // documented 4-argument call — a correct doc line flagged because the guard lived one level down.
    if (is_undefined(_opts)) _opts = {};
    var _a = crs_faction_arms(_id);
    if (is_undefined(_a)) return false;
    crs_arms_draw(_a, _cx, _cy, _size, _opts);
    return true;
}

/// Draw one charge on its own, with no shield - for an icon, a quest log, a map pin.
function crs_charge_draw(_charge_id, _cx, _cy, _size, _colour, _detail_colour) {
    var _parts = crs_place(crs_charge(_charge_id), _cx, _cy, _size * 2, 0, 1, undefined);
    var _oldC = draw_get_colour();
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        draw_set_colour((_p.role == CRS_R_DETAIL) ? _detail_colour : _colour);
        crs_draw_part_flat(_p);
    }
    draw_set_colour(_oldC);
}

/// Draw a part in whatever colour is already set. Split out of crs_draw_part so the two callers
/// that supply their own colour do not have to construct a fake arms struct to get one.
function crs_draw_part_flat(_p) {
    switch (_p.kind) {
        case CRS_DOT: draw_circle(_p.cx, _p.cy, max(0.4, _p.r), false); return;
        case CRS_FILL: {
            if (array_length(_p.pts) < 3) return;
            draw_primitive_begin(pr_trianglefan);
            for (var _i = 0; _i < array_length(_p.pts); _i++) draw_vertex(_p.pts[_i][0], _p.pts[_i][1]);
            draw_primitive_end();
            return;
        }
        case CRS_STRIP: {
            var _n = min(array_length(_p.a), array_length(_p.b));
            if (_n < 2) return;
            draw_primitive_begin(pr_trianglestrip);
            for (var _i = 0; _i < _n; _i++) {
                draw_vertex(_p.a[_i][0], _p.a[_i][1]);
                draw_vertex(_p.b[_i][0], _p.b[_i][1]);
            }
            draw_primitive_end();
            return;
        }
        case CRS_ARC: {
            var _steps = max(10, ceil(abs(_p.a1 - _p.a0) * 14));
            var _w = max(CRS_W_FLOOR, _p.w);
            var _px = _p.cx + cos(_p.a0) * _p.r, _py = _p.cy + sin(_p.a0) * _p.r;
            for (var _i = 1; _i <= _steps; _i++) {
                var _a = lerp(_p.a0, _p.a1, _i / _steps);
                var _nx = _p.cx + cos(_a) * _p.r, _ny = _p.cy + sin(_a) * _p.r;
                draw_line_width(_px, _py, _nx, _ny, _w);
                _px = _nx; _py = _ny;
            }
            return;
        }
        default: {
            var _w = max(CRS_W_FLOOR, _p.w);
            for (var _i = 1; _i < array_length(_p.pts); _i++) {
                draw_line_width(_p.pts[_i - 1][0], _p.pts[_i - 1][1],
                                _p.pts[_i][0], _p.pts[_i][1], _w);
            }
            if (_p.closed && array_length(_p.pts) > 2) {
                var _n = array_length(_p.pts);
                draw_line_width(_p.pts[_n - 1][0], _p.pts[_n - 1][1], _p.pts[0][0], _p.pts[0][1], _w);
            }
            return;
        }
    }
}
