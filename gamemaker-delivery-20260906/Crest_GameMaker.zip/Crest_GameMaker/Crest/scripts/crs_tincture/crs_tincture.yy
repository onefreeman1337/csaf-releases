{
  "$GMScript": "v1",
  "%Name": "crs_tincture",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_tincture",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}