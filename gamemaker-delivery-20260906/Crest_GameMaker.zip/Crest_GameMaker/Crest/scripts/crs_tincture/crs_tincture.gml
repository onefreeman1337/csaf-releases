/// ============================================================================================
/// CREST - crs_tincture: seven tinctures, two furs, and THE RULE OF TINCTURE.
///
/// -- WHY THIS FILE IS THE REASON GENERATED ARMS LOOK DESIGNED -----------------------------------
/// Heraldry divides its colours into two classes - METALS (or, argent) and COLOURS (gules, azure,
/// vert, sable, purpure) - and forbids putting metal on metal or colour on colour. That is not
/// etiquette. It is a legibility rule, arrived at by people whose lives depended on identifying a
/// banner at the range you can see one from, and it is the same problem this product's 20px
/// silhouette criterion is about.
///
/// It is also the entire difference between "generated" and "random". A generator that picks two
/// tinctures uniformly produces azure-on-vert about a third of the time, and azure on vert is mud.
/// Obeying one 800-year-old rule removes every muddy pair in the space, for free, and the result
/// reads as though somebody chose it.
///
/// crs_rule_of_tincture_ok() is the enforcement point, crs_arms never emits a violating pair, and
/// crs_selftest asserts it over EVERY faction the demo can produce rather than over a sample.
///
/// -- WHAT IS NOT CLAIMED HERE ------------------------------------------------------------------
/// ⚠️ The rule is a CLASS rule, not a contrast measurement, and the two are not the same thing:
/// sable on gules obeys nothing and azure on sable is a legal-but-dark pair. So this file ALSO
/// measures real perceptual lightness separation in Oklab and refuses a pair that passes the
/// class rule and still cannot be read. Saying "it obeys heraldry" and leaving it there would be a
/// claim about legibility backed by tradition rather than by measurement.
/// ============================================================================================

/// The two classes. A tincture is one or the other, and a fur counts as neither - which is exactly
/// why furs exist in heraldry: they are the legal escape from a blazon that would otherwise break
/// the rule.
#macro CRS_T_METAL  0
#macro CRS_T_COLOUR 1
#macro CRS_T_FUR    2

/// The minimum Oklab lightness separation between a charge and the field it sits on. Measured
/// rather than inherited: below this two tinctures of different CLASS still read as one mass at
/// banner size, which the class rule alone does not prevent.
///
/// ⛔ Never write a tolerance below ~1e-5 anywhere in this package - GML's default epsilon is 1e-6
/// and a comparison under it can never fire in either direction. 0.18 is far above that, but the
/// rule is stated here because this is the file where a "just tighten the threshold" edit is most
/// tempting.
#macro CRS_T_MIN_L_GAP 0.18

/// The nine tinctures: five colours, two metals, two furs.
function crs_tincture_ids() {
    return ["or", "argent", "gules", "azure", "vert", "sable", "purpure", "ermine", "vair"];
}

/// Class of a tincture.
function crs_tincture_class(_t) {
    switch (_t) {
        case "or": case "argent":  return CRS_T_METAL;
        case "ermine": case "vair": return CRS_T_FUR;
        default:                    return CRS_T_COLOUR;
    }
}

function crs_tincture_name(_t) {
    switch (_t) {
        case "or":      return "Or";
        case "argent":  return "Argent";
        case "gules":   return "Gules";
        case "azure":   return "Azure";
        case "vert":    return "Vert";
        case "sable":   return "Sable";
        case "purpure": return "Purpure";
        case "ermine":  return "Ermine";
        default:        return "Vair";
    }
}

/// The plain-English name, because a buyer's players do not read blazon.
function crs_tincture_plain(_t) {
    switch (_t) {
        case "or":      return "gold";
        case "argent":  return "silver";
        case "gules":   return "red";
        case "azure":   return "blue";
        case "vert":    return "green";
        case "sable":   return "black";
        case "purpure": return "purple";
        case "ermine":  return "ermine";
        default:        return "vair";
    }
}

/// -- THE COLOUR ITSELF, IN OKLCH ---------------------------------------------------------------
/// Lightness, chroma and hue per tincture. These are not sampled from a reference image and not
/// picked in RGB: they are placed by hand in a perceptual space so that the lightness column below
/// is directly comparable between rows, which is what makes CRS_T_MIN_L_GAP a meaningful test
/// rather than an arbitrary number.
///
/// A fur returns the colour of its GROUND; its pattern is drawn on top by crs_tincture_fur_parts.
function crs_tincture_L(_t) {
    switch (_t) {
        case "or":      return 0.82;
        case "argent":  return 0.90;
        case "gules":   return 0.52;
        case "azure":   return 0.46;
        case "vert":    return 0.50;
        case "sable":   return 0.24;
        case "purpure": return 0.44;
        case "ermine":  return 0.90;   // ermine is argent powdered with sable
        default:        return 0.72;   // vair is argent and azure
    }
}

function crs_tincture_C(_t) {
    switch (_t) {
        case "or":      return 0.135;
        case "argent":  return 0.010;
        case "gules":   return 0.165;
        case "azure":   return 0.135;
        case "vert":    return 0.115;
        case "sable":   return 0.020;
        case "purpure": return 0.130;
        case "ermine":  return 0.010;
        default:        return 0.045;
    }
}

function crs_tincture_H(_t) {
    switch (_t) {
        case "or":      return 88.0;
        case "argent":  return 250.0;
        case "gules":   return 28.0;
        case "azure":   return 252.0;
        case "vert":    return 148.0;
        case "sable":   return 270.0;
        case "purpure": return 320.0;
        case "ermine":  return 250.0;
        default:        return 252.0;
    }
}

/// A tincture as a drawable colour.
function crs_tincture_colour(_t) {
    return crs_oklch(crs_tincture_L(_t), crs_tincture_C(_t), crs_tincture_H(_t));
}

/// The colour of a tincture's DETAIL - the interior line inside a charge. Derived, never declared:
/// it steps away from the tincture's own lightness in whichever direction has room, so a detail
/// line stays visible on `sable` (step up) and on `argent` (step down) with no per-tincture table
/// to keep in sync.
function crs_tincture_detail_colour(_t) {
    var _L = crs_tincture_L(_t);
    var _to = (_L > 0.55) ? max(0.06, _L - 0.34) : min(0.96, _L + 0.34);
    return crs_oklch(_to, crs_tincture_C(_t) * 0.5, crs_tincture_H(_t));
}

/// ============================================================================================
/// THE RULE
/// ============================================================================================

/// May _charge sit on _field?
///
/// Two conditions, and the second is ours:
///   1. THE RULE OF TINCTURE. Not metal on metal; not colour on colour. A FUR may sit on anything
///      and anything may sit on a fur - that is what furs are for.
///   2. A MEASURED LIGHTNESS GAP, because the class rule is about CATEGORIES and a category is a
///      proxy for legibility rather than a measurement of it. The gap is where the furs get caught:
///      a fur may legally carry anything, so `or` on `vair` obeys the rule of tincture completely -
///      and gold on a silver-and-blue ground is a 0.10 lightness step, which at the size a banner
///      is actually seen is one mass, not two. The class rule cannot see that. Oklab can.
function crs_rule_of_tincture_ok(_charge, _field) {
    var _cc = crs_tincture_class(_charge);
    var _fc = crs_tincture_class(_field);
    if (_cc != CRS_T_FUR && _fc != CRS_T_FUR && _cc == _fc) return false;
    return (abs(crs_tincture_L(_charge) - crs_tincture_L(_field)) >= CRS_T_MIN_L_GAP);
}

/// Why a pair was refused, for the demo's own explanatory panel and for a buyer debugging a blazon
/// they wrote by hand. A boolean that cannot say why is a boolean somebody will work around.
function crs_rule_of_tincture_why(_charge, _field) {
    var _cc = crs_tincture_class(_charge);
    var _fc = crs_tincture_class(_field);
    if (_cc != CRS_T_FUR && _fc != CRS_T_FUR && _cc == _fc) {
        return (_cc == CRS_T_METAL) ? "metal on metal" : "colour on colour";
    }
    var _gap = abs(crs_tincture_L(_charge) - crs_tincture_L(_field));
    if (_gap < CRS_T_MIN_L_GAP) {
        return "too close in lightness (" + string_format(_gap, 1, 2) + " of "
            + string_format(CRS_T_MIN_L_GAP, 1, 2) + ")";
    }
    return "";
}

/// Every tincture that may legally sit on _field, in the corpus's own order. crs_arms picks from
/// this list rather than picking and re-rolling, so a faction's arms are derived deterministically
/// from its properties in one pass and can never fail to converge.
function crs_tinctures_allowed_on(_field) {
    var _all = crs_tincture_ids();
    var _out = [];
    for (var _i = 0; _i < array_length(_all); _i++) {
        if (crs_rule_of_tincture_ok(_all[_i], _field)) array_push(_out, _all[_i]);
    }
    return _out;
}

/// The same set with the FURS removed - the legal tinctures for an ORDINARY or a CHARGE.
///
/// ⛔ THIS EXISTS BECAUSE THE BLAZON WAS DESCRIBING SOMETHING THE PICTURE DID NOT SHOW, which is
/// the one defect this product cannot afford: its whole pitch is that the heraldry is composed
/// correctly rather than decoratively. MEASURED on the baked hero sheet, 2026-08-22 - The
/// Thornwilds read "Purpure, a fess Ermine, Bear Statant Vair" over a PLAIN WHITE band and a FLAT
/// BLUE bear, and The Salt Guild read "a bordure Vair, Cog Ermine" over a plain border and a plain
/// cog. Four fur claims on one image, none of them visible.
///
/// The cause is in crs_arms_draw: the fur PATTERN is drawn at step 2 and only when the FIELD is a
/// fur, because an ordinary or a charge would need the pattern clipped to its own outline rather
/// than to the shield's. Rather than claim a fur and not draw it, derivation stops choosing one -
/// which is also closer to real practice, where furs overwhelmingly dress fields and ordinaries
/// and rarely tincture a beast.
///
/// ⚠️ The FIELD is untouched and still draws ermine and vair as real patterns. This narrows what
/// the generator may say, not what the package can draw.
function crs_tinctures_solid_on(_field) {
    var _all = crs_tinctures_allowed_on(_field);
    var _out = [];
    for (var _i = 0; _i < array_length(_all); _i++) {
        if (!crs_tincture_is_fur(_all[_i])) array_push(_out, _all[_i]);
    }
    return _out;
}

/// ============================================================================================
/// FURS - the two patterned tinctures, drawn rather than declared
/// ============================================================================================

/// Ermine: argent powdered with sable spots. Vair: interlocking argent and azure bells.
///
/// Authored in SHIELD space, [-0.5, 0.5], because a fur covers the field rather than sitting on it.
/// Returns parts with role CRS_R_DETAIL, so the renderer resolves them against the fur's own
/// pattern colour without the pattern code knowing what colour that is.
function crs_tincture_fur_parts(_t) {
    var _p = [];

    if (_t == "ermine") {
        // The ermine spot: three dots over a tail. Six rows, offset alternately, which is how a
        // powdering is actually laid out - a square grid reads as wallpaper.
        for (var _r = 0; _r < 5; _r++) {
            var _y = -0.40 + _r * 0.20;
            var _off = ((_r % 2) == 0) ? 0 : 0.12;
            for (var _c = 0; _c < 5; _c++) {
                var _x = -0.44 + _off + _c * 0.24;
                if (abs(_x) > 0.48) continue;
                array_push(_p, crs_fill([[_x, _y + 0.05], [_x - 0.035, _y - 0.05],
                                         [_x + 0.035, _y - 0.05]], CRS_R_DETAIL));
                array_push(_p, crs_dot(_x, _y - 0.075, 0.016, CRS_R_DETAIL));
                array_push(_p, crs_dot(_x - 0.040, _y - 0.055, 0.013, CRS_R_DETAIL));
                array_push(_p, crs_dot(_x + 0.040, _y - 0.055, 0.013, CRS_R_DETAIL));
            }
        }
        return _p;
    }

    // Vair: rows of bells, alternate rows inverted, which is what makes them interlock rather than
    // stack. Drawn as filled bells so the pattern survives being small - the same reason every
    // charge in this package is a mass.
    for (var _r = 0; _r < 5; _r++) {
        var _y = -0.44 + _r * 0.19;
        var _up = ((_r % 2) == 0);
        for (var _c = 0; _c < 5; _c++) {
            var _x = -0.44 + _c * 0.22 + (_up ? 0 : 0.11);
            if (abs(_x) > 0.50) continue;
            var _h = 0.17;
            if (_up) {
                array_push(_p, crs_fill([[_x - 0.09, _y], [_x + 0.09, _y],
                                         [_x + 0.05, _y + _h], [_x - 0.05, _y + _h]], CRS_R_DETAIL));
            } else {
                array_push(_p, crs_fill([[_x - 0.05, _y], [_x + 0.05, _y],
                                         [_x + 0.09, _y + _h], [_x - 0.09, _y + _h]], CRS_R_DETAIL));
            }
        }
    }
    return _p;
}

/// The colour the fur's pattern is drawn in. Sable spots on ermine; azure bells on vair.
function crs_tincture_fur_pattern_colour(_t) {
    return (_t == "ermine") ? crs_tincture_colour("sable") : crs_tincture_colour("azure");
}

function crs_tincture_is_fur(_t) {
    return (crs_tincture_class(_t) == CRS_T_FUR);
}
