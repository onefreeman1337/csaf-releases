{
  "$GMScript": "v1",
  "%Name": "crs_arms",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_arms",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}