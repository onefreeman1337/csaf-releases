/// ============================================================================================
/// CREST - crs_arms: a faction's own properties become its coat of arms.
///
/// -- DERIVED, NEVER RANDOM ---------------------------------------------------------------------
/// Every choice below comes from a seeded hash of the faction's id, filtered through its traits.
/// That is the whole design and it has three consequences a buyer will care about:
///
///   1. A faction looks the SAME every time the game runs, and the same on every player's machine,
///      with nothing stored in the save file. There is no arms table to migrate and no id to keep.
///   2. Two factions never collide, because the id is the seed.
///   3. Arms are MEANINGFUL rather than arbitrary: a martial faction gets a beast or a weapon, a
///      seafaring one gets a ship or an anchor. The trait does the choosing; the hash only breaks
///      ties within what the trait already allowed.
///
/// ⛔ Nothing here calls random(). A faction whose banner re-rolled itself between two draws in the
/// same frame is the one bug a buyer notices instantly and cannot work around, and it is exactly
/// what a `random()` inside a draw path produces.
///
/// -- THE RULE OF TINCTURE IS ENFORCED AT THE POINT OF DERIVATION -------------------------------
/// Not checked afterwards, not re-rolled until it passes. crs_tinctures_allowed_on() returns the
/// legal set and the hash picks WITHIN it, so derivation is one pass, always terminates, and cannot
/// emit a violating pair. A retry loop would have been three lines shorter and would have had a
/// worst case nobody would ever have hit in testing.
/// ============================================================================================

/// Which orders a trait points at. A buyer passes plain words - ["martial", "coastal"] - and gets
/// arms that mean something. Unknown traits are ignored rather than rejected: a faction system a
/// designer has to look words up for is a faction system a designer stops using.
///
/// The vocabulary is deliberately small and documented in the Readme. Extending it is one case each.
function crs_trait_orders(_trait) {
    switch (string_lower(_trait)) {
        case "martial": case "warlike": case "militant": return ["beast", "arms"];
        case "noble":   case "royal":   case "highborn": return ["beast", "bird"];
        case "wild":    case "feral":   case "savage":   return ["beast"];
        case "watchful": case "scholar": case "arcane":  return ["bird", "sacred"];
        case "pious":   case "holy":    case "zealous":  return ["sacred"];
        case "merchant": case "guild":  case "wealthy":  return ["craft"];
        case "coastal": case "seafaring": case "naval":  return ["craft", "land"];
        case "rustic":  case "agrarian": case "settled": return ["craft", "land"];
        case "ancient": case "fallen":  case "ruined":   return ["land", "sacred"];
        default: return [];
    }
}

/// Every trait vocabulary word this file understands, so the Readme and the demo can print the
/// real list instead of a hand-copied one that drifts.
function crs_trait_words() {
    return ["martial", "warlike", "militant", "noble", "royal", "highborn",
            "wild", "feral", "savage", "watchful", "scholar", "arcane",
            "pious", "holy", "zealous", "merchant", "guild", "wealthy",
            "coastal", "seafaring", "naval", "rustic", "agrarian", "settled",
            "ancient", "fallen", "ruined"];
}

/// Pick one element of an array using a generator. One place, so "how a choice is made" is one
/// line rather than a pattern repeated eight times with one of them subtly different.
function crs_pick(_arr, _rng) {
    var _n = array_length(_arr);
    if (_n == 0) return undefined;
    return _arr[min(_n - 1, floor(crs_rng_next(_rng) * _n))];
}

/// The charge ids belonging to one order.
function crs_charges_in_order(_order) {
    var _ids = crs_charge_ids();
    var _out = [];
    for (var _i = 0; _i < array_length(_ids); _i++) {
        if (crs_charge_order(_i) == _order) array_push(_out, _ids[_i]);
    }
    return _out;
}

/// Derive a full coat of arms from an id and a trait list.
///
/// _traits may be undefined or empty - a faction with no traits still gets coherent arms, drawn
/// from the whole corpus instead of from a subset. That matters more than it sounds: it means a
/// buyer can register twenty factions with nothing but names on day one, see the whole system
/// working, and add traits later without any arms they liked changing... except the ones whose
/// traits they changed, which is the behaviour they would expect.
function crs_arms_derive(_id, _traits) {
    var _rng = crs_rng(crs_hash32("crs:" + string(_id)));

    // -- the order, from the traits ------------------------------------------------------------
    var _orders = [];
    if (!is_undefined(_traits)) {
        for (var _i = 0; _i < array_length(_traits); _i++) {
            var _o = crs_trait_orders(_traits[_i]);
            for (var _k = 0; _k < array_length(_o); _k++) {
                var _dup = false;
                for (var _m = 0; _m < array_length(_orders); _m++) if (_orders[_m] == _o[_k]) _dup = true;
                if (!_dup) array_push(_orders, _o[_k]);
            }
        }
    }
    if (array_length(_orders) == 0) _orders = crs_order_ids();

    var _order = crs_pick(_orders, _rng);
    var _charge = crs_pick(crs_charges_in_order(_order), _rng);
    var _shield = crs_pick(crs_shield_ids(), _rng);
    var _ord = crs_pick(crs_ordinary_ids(), _rng);

    // -- the tinctures, in dependency order ----------------------------------------------------
    // The field first, then the ordinary against the field, then the charge against WHATEVER IT
    // ACTUALLY SITS ON - which is the ordinary when the ordinary passes under the charge anchor,
    // and the field when it does not. Checking the charge against the field regardless is the
    // subtle version of this bug: it passes every assertion and produces a lion the same class as
    // the bend it is lying across.
    // ⚠️ THE FIELD MAY BE A FUR; THE ORDINARY AND THE CHARGE MAY NOT. See crs_tinctures_solid_on -
    // the fur PATTERN is only rendered for the field, so allowing one here produced blazons that
    // named a fur over a flat shape. The rule of tincture still governs all three.
    var _field = crs_pick(crs_tincture_ids(), _rng);
    var _ordT = _field;
    if (_ord != "plain") _ordT = crs_pick(crs_tinctures_solid_on(_field), _rng);

    // ⛔ THE CHARGE IS TINCTURED AGAINST THE FIELD, NOT AGAINST THE ORDINARY. This was the other way
    // round and it put an INVISIBLE EAGLE on a store sheet: "Vert, a saltire Or, Eagle Displayed
    // Vert" - legal, because the eagle was checked against the Or saltire it nominally sits on, and
    // unreadable, because a saltire is a thin X and the eagle's actual background is the Vert field
    // it matches exactly. Every assertion passed; the bird was green on green.
    //
    // The old reasoning ("if a bend runs under the charge, the charge is sitting on the BEND's
    // tincture") is true of the few pixels where they cross and false of the charge as a whole. For
    // thirteen of the fourteen ordinaries the FIELD is the majority of what a charge covers, so the
    // field is what legibility depends on.
    //
    // ⚠️ AND IT CANNOT BE BOTH. With only metals and colours, "contrasts with the field AND with
    // the ordinary" is unsatisfiable whenever the ordinary passes under: the ordinary already
    // contrasts with the field, so the two of them occupy both classes and nothing is left for the
    // charge. Real heraldry answers that with counterchanging, which this package does not draw.
    // So the field is a HARD constraint and the ordinary is a PREFERENCE - taken when some legal
    // tincture happens to satisfy both, dropped rather than made unsatisfiable when none does.
    var _fieldOk = crs_tinctures_solid_on(_field);
    var _chargeT = crs_pick(_fieldOk, _rng);
    if (_ord != "plain" && crs_ordinary_under_charge(_ord)) {
        var _both = [];
        for (var _i = 0; _i < array_length(_fieldOk); _i++) {
            if (crs_rule_of_tincture_ok(_fieldOk[_i], _ordT)) array_push(_both, _fieldOk[_i]);
        }
        if (array_length(_both) > 0) _chargeT = crs_pick(_both, _rng);
    }
    var _under = _field;    // what the charge is actually read against - kept for the selftest

    return {
        shield:   _shield,
        ordinary: _ord,
        charge:   _charge,
        order:    _order,
        field:    _field,
        ord_t:    _ordT,
        charge_t: _chargeT,
        under:    _under,     // what the charge is actually resting on - kept for the selftest
        cadency:  "",         // set by crs_arms_cadet
        parent:   ""
    };
}

/// The arms of a cadet branch: the parent's arms, unchanged, plus one mark of difference.
///
/// ⛔ THIS IS THE PRODUCT'S GATE 2 ANSWER AND IT IS THREE LINES LONG. Everything that makes it
/// work is the fact that arms are a STRUCT derived from a faction rather than a picture: inheriting
/// them is a copy, and the difference is one field. A generator that returns an image cannot do
/// this at all, which is the whole argument for shipping the system rather than the generator.
function crs_arms_cadet(_parentArms, _parentId, _branchIndex) {
    var _a = {
        shield:   _parentArms.shield,
        ordinary: _parentArms.ordinary,
        charge:   _parentArms.charge,
        order:    _parentArms.order,
        field:    _parentArms.field,
        ord_t:    _parentArms.ord_t,
        charge_t: _parentArms.charge_t,
        under:    _parentArms.under,
        cadency:  crs_cadency_for_branch(_branchIndex),
        parent:   _parentId
    };
    return _a;
}

/// ============================================================================================
/// BLAZON - the arms, described in words
/// ============================================================================================

/// The heraldic blazon: "Azure, a bend Or, a lion Argent." Real blazon order - field first, then
/// the ordinary, then the charge - because a buyer who knows heraldry will notice if it is wrong,
/// and one who does not gets a phrase that sounds right either way.
///
/// This is free UI. A faction panel with a blazon under the shield reads as a considered game; one
/// with "Faction 3" under it reads as a placeholder.
function crs_arms_blazon(_arms) {
    var _s = crs_tincture_name(_arms.field);
    if (_arms.ordinary != "plain") {
        _s += ", " + string_lower(crs_ordinary_name(_arms.ordinary)) + " "
            + crs_tincture_name(_arms.ord_t);
    }
    _s += ", " + crs_charge_name(_arms.charge) + " " + crs_tincture_name(_arms.charge_t);
    if (_arms.cadency != "") _s += ", differenced by " + crs_cadency_name(_arms.cadency);
    return _s + ".";
}

/// The same thing in plain English, for a game that does not want to sound like a herald.
function crs_arms_describe(_arms) {
    var _s = crs_charge_name(_arms.charge) + " in " + crs_tincture_plain(_arms.charge_t)
        + " on " + crs_tincture_plain(_arms.field);
    if (_arms.ordinary != "plain") {
        _s += " with " + string_lower(crs_ordinary_name(_arms.ordinary)) + " in "
            + crs_tincture_plain(_arms.ord_t);
    }
    return _s;
}

/// ============================================================================================
/// VALIDATION - available to the buyer, not only to the test suite
/// ============================================================================================

/// Is this arms struct legal? Returns "" when it is, or the reason when it is not.
///
/// Exposed publicly on purpose. A buyer WILL hand-write arms for their three story factions and
/// generate the other forty, and when their hand-written one looks muddy this is the function that
/// tells them why, in one call, instead of leaving them to compare hex values.
function crs_arms_problem(_arms) {
    if (crs_charge_index(_arms.charge) < 0) return "unknown charge \"" + string(_arms.charge) + "\"";
    // ⚠️ THE FIELD, matching crs_arms_derive - see the long note there. This function used to test
    // the charge against the ORDINARY when one passed under it, which is what let "Eagle Displayed
    // Vert" on a Vert field be reported as legal. A validator that disagrees with the generator is
    // worse than either being wrong alone: it makes the wrong answer look independently confirmed.
    if (!crs_rule_of_tincture_ok(_arms.charge_t, _arms.field)) {
        return "charge on field: " + crs_rule_of_tincture_why(_arms.charge_t, _arms.field);
    }
    // A fur on an ordinary or a charge is not illegal heraldry - it is a claim this renderer cannot
    // draw, because the fur PATTERN is only applied to the field. Reported here so a buyer writing
    // arms by hand is told, rather than getting a blazon that describes a flat shape.
    if (_arms.ordinary != "plain" && crs_tincture_is_fur(_arms.ord_t)) {
        return "ordinary is " + string(_arms.ord_t) + ": furs are only patterned on the field";
    }
    if (crs_tincture_is_fur(_arms.charge_t)) {
        return "charge is " + string(_arms.charge_t) + ": furs are only patterned on the field";
    }
    if (_arms.ordinary != "plain" && !crs_rule_of_tincture_ok(_arms.ord_t, _arms.field)) {
        return "ordinary on field: " + crs_rule_of_tincture_why(_arms.ord_t, _arms.field);
    }
    return "";
}
