/// ============================================================================================
/// CREST - crs_panel: the faction panel, ready to drop into a buyer's game.
///
/// -- WHY A UI SHIPS WITH A SYSTEMS PACKAGE -----------------------------------------------------
/// Because a buyer who has to build one before they can see anything has not bought a faction
/// system, they have bought a faction library plus a weekend. Every complete system this wing has
/// sold ships its own interface, and this one has a second reason: the arms ARE the product's face,
/// and a package that generates 4,928 coats of arms and then leaves the buyer to figure out how to
/// show them has hidden the thing it is selling.
///
/// -- IT MUST NOT LOOK LIKE THE ENGINE ----------------------------------------------------------
/// ⛔ Gate 1, and it is not a style preference: a panel drawn in GameMaker's default font on a grey
/// box tells a buyer "you could have made this", and that is the two seconds they spend deciding.
/// So everything here is drawn - the plate, the rules, the standing bar, the tier pips - in a
/// palette derived from the same Oklch layer the tinctures use, with the package's own shipped
/// fonts. There is no sprite in this file and no rectangle left at a default colour.
///
/// -- EVERY NUMBER IS DERIVED FROM ONE SCALE ----------------------------------------------------
/// The panel takes a width and computes everything else from it. That is what lets it be drawn at
/// 260px in a corner and at 900px on a store sheet and look deliberate at both - which is exactly
/// the test this wing's constitution records failing on a previous product, where margins that were
/// generous at sheet size clipped their labels at GIF size.
/// ============================================================================================

/// The panel's own palette. Not tinctures - this is furniture, and furniture that used the
/// heraldic palette would compete with the arms it is framing.
function crs_ui_colour(_k) {
    switch (_k) {
        case "plate":   return crs_oklch(0.18, 0.014, 265);   // the dark ground
        case "plate2":  return crs_oklch(0.23, 0.016, 265);   // the raised row
        case "rule":    return crs_oklch(0.38, 0.020, 265);   // hairlines
        case "ink":     return crs_oklch(0.92, 0.008, 265);   // primary text
        case "ink2":    return crs_oklch(0.66, 0.012, 265);   // secondary text
        case "gild":    return crs_oklch(0.80, 0.100, 88);    // the accent, matched to `or`
        case "good":    return crs_oklch(0.68, 0.105, 148);
        default:        return crs_oklch(0.58, 0.150, 28);    // "bad"
    }
}

/// The colour of a tier, for the standing bar and the pips. Runs red through neutral to green, in
/// Oklch, so the six steps are perceptually even - in HSV they are not, and the middle two look
/// like the same colour.
function crs_tier_colour(_t) {
    var _r = crs_tier_rank(_t);
    if (_r < 0) _r = 2;
    var _tt = _r / 5;
    return crs_oklch(lerp(0.54, 0.72, _tt), lerp(0.150, 0.105, abs(_tt - 0.5) * 2 * 0.4 + 0.6),
                     lerp(28, 148, _tt));
}

/// A filled rounded plate, drawn rather than sprited.
function crs_ui_plate(_x0, _y0, _x1, _y1, _r, _colour) {
    var _oldC = draw_get_colour();
    draw_set_colour(_colour);
    draw_rectangle(_x0 + _r, _y0, _x1 - _r, _y1, false);
    draw_rectangle(_x0, _y0 + _r, _x1, _y1 - _r, false);
    draw_circle(_x0 + _r, _y0 + _r, _r, false);
    draw_circle(_x1 - _r, _y0 + _r, _r, false);
    draw_circle(_x0 + _r, _y1 - _r, _r, false);
    draw_circle(_x1 - _r, _y1 - _r, _r, false);
    draw_set_colour(_oldC);
}

/// A hairline rule with a diamond at its centre - the one piece of ornament in the panel, and the
/// cheapest thing that makes a UI read as designed rather than as boxes.
function crs_ui_rule(_x0, _x1, _y, _colour) {
    var _oldC = draw_get_colour();
    draw_set_colour(_colour);
    var _cx = (_x0 + _x1) * 0.5;
    var _g = (_x1 - _x0) * 0.035;
    draw_line_width(_x0, _y, _cx - _g, _y, 1);
    draw_line_width(_cx + _g, _y, _x1, _y, 1);
    draw_primitive_begin(pr_trianglefan);
    draw_vertex(_cx, _y - _g * 0.42); draw_vertex(_cx + _g * 0.42, _y);
    draw_vertex(_cx, _y + _g * 0.42); draw_vertex(_cx - _g * 0.42, _y);
    draw_primitive_end();
    draw_set_colour(_oldC);
}

/// The standing bar: a track, a fill from the centre, and six tier pips.
///
/// From the CENTRE, not from the left. Standing is signed, and a bar that fills from the left makes
/// "hated" look like "nearly empty" instead of like "far in the wrong direction" - which is the one
/// thing the bar exists to communicate.
function crs_ui_standing_bar(_x0, _y0, _x1, _y1, _standing) {
    var _oldC = draw_get_colour();
    var _mid = (_x0 + _x1) * 0.5;
    var _h = _y1 - _y0;

    draw_set_colour(crs_ui_colour("plate"));
    draw_rectangle(_x0, _y0, _x1, _y1, false);

    var _t = clamp(_standing / CRS_STANDING_MAX, -1, 1);
    draw_set_colour(crs_tier_colour(crs_tier_of_value(_standing)));
    if (_t >= 0) draw_rectangle(_mid, _y0, _mid + (_x1 - _mid) * _t, _y1, false);
    else         draw_rectangle(_mid + (_mid - _x0) * _t, _y0, _mid, _y1, false);

    // the centre mark, always visible, so "zero" is a place rather than an absence
    draw_set_colour(crs_ui_colour("rule"));
    draw_line_width(_mid, _y0 - _h * 0.25, _mid, _y1 + _h * 0.25, 1);
    draw_rectangle(_x0, _y0, _x1, _y1, true);
    draw_set_colour(_oldC);
}

/// ============================================================================================
/// THE ROW - one faction
/// ============================================================================================

/// Draw one faction as a row: arms, name, tier, standing bar.
///
/// _w is the row's width and EVERYTHING else is derived from it. Returns the height it used, so a
/// caller can stack rows without knowing the panel's internal metrics - a caller that has to know
/// them is a caller that breaks when they change.
function crs_panel_row(_id, _x, _y, _w, _selected) {
    var _f = crs_faction_get(_id);
    if (is_undefined(_f)) return 0;

    var _h = _w * 0.20;
    var _pad = _w * 0.030;
    var _shield = _h * 0.38;

    var _oldC = draw_get_colour(), _oldF = draw_get_font();
    var _oldH = draw_get_halign(), _oldV = draw_get_valign();

    crs_ui_plate(_x, _y, _x + _w, _y + _h, _h * 0.10,
                 _selected ? crs_ui_colour("plate2") : crs_ui_colour("plate"));
    if (_selected) {
        draw_set_colour(crs_ui_colour("gild"));
        draw_rectangle(_x, _y, _x + _w * 0.008, _y + _h, false);
    }

    // THE ARMS, at the size a faction list actually shows them - which is where the corpus's 20px
    // acceptance criterion comes from in the first place.
    crs_faction_draw(_id, _x + _pad + _shield, _y + _h * 0.5, _shield, undefined);

    var _tx = _x + _pad * 2 + _shield * 2;
    draw_set_halign(fa_left);
    draw_set_valign(fa_middle);

    draw_set_font(crs_font_title());
    draw_set_colour(crs_ui_colour("ink"));
    draw_text_transformed(_tx, _y + _h * 0.32, _f.name, _w / 620, _w / 620, 0);

    draw_set_font(crs_font());
    var _tier = crs_tier(_id);
    draw_set_colour(crs_tier_colour(_tier));
    draw_text_transformed(_tx, _y + _h * 0.62, crs_tier_name(_tier), _w / 900, _w / 900, 0);

    draw_set_colour(crs_ui_colour("ink2"));
    draw_set_halign(fa_right);
    draw_text_transformed(_x + _w - _pad, _y + _h * 0.62,
                          string(round(_f.standing)), _w / 900, _w / 900, 0);

    crs_ui_standing_bar(_tx, _y + _h * 0.76, _x + _w - _pad, _y + _h * 0.86, _f.standing);

    draw_set_colour(_oldC); draw_set_font(_oldF);
    draw_set_halign(_oldH); draw_set_valign(_oldV);
    return _h;
}

/// ============================================================================================
/// THE PANEL
/// ============================================================================================

/// Draw the whole faction list. Returns the height used.
/// How tall crs_panel_draw will be, for a given width and number of factions.
///
/// ⛔ PUBLIC, AND IT EXISTS BECAUSE THE HEIGHT WAS ONLY KNOWABLE AFTER DRAWING. crs_panel_draw
/// returns its height, which is useless to anyone deciding whether the panel FITS - and the store
/// sheet proved it: a 660-wide panel is 812 tall, it was placed at y=226 on a 1000px surface, and
/// it ran 38px off the bottom. Worse, nothing caught it. The bake's ink-bounds check measures
/// pixels that differ from the page, and the panel PLATE is crs_ui_colour("plate") at L=0.18
/// against an L=0.15 page - under the detector's 10-per-channel tolerance - so the clipped plate is
/// invisible to the very check written to catch clipping.
///
/// A buyer laying this out beside their own UI needs the same answer for the same reason.
/// crs_panel_draw now derives its height from this function, so the two cannot disagree.
function crs_panel_height(_w, _count) {
    var _pad = _w * 0.030;
    var _gap = _w * 0.014;
    var _rowH = _w * 0.20;
    return _pad * 2 + _w * 0.10 + _count * (_rowH + _gap);
}

/// The widest panel that fits in a given height - the inverse of crs_panel_height.
function crs_panel_width_for_height(_h, _count) {
    var _per = 0.030 * 2 + 0.10 + _count * (0.20 + 0.014);
    return (_per <= 0) ? 0 : _h / _per;
}

function crs_panel_draw(_x, _y, _w, _selectedId) {
    var _ids = crs_faction_ids();
    var _pad = _w * 0.030;
    var _gap = _w * 0.014;

    var _oldC = draw_get_colour(), _oldF = draw_get_font();
    var _oldH = draw_get_halign(), _oldV = draw_get_valign();

    var _rowH = _w * 0.20;
    var _h = crs_panel_height(_w, array_length(_ids));

    crs_ui_plate(_x, _y, _x + _w, _y + _h, _w * 0.020, crs_ui_colour("plate"));

    draw_set_font(crs_font_title());
    draw_set_colour(crs_ui_colour("gild"));
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_text_transformed(_x + _w * 0.5, _y + _pad + _w * 0.022, "STANDING", _w / 700, _w / 700, 0);
    crs_ui_rule(_x + _pad, _x + _w - _pad, _y + _pad + _w * 0.058, crs_ui_colour("rule"));

    var _cy = _y + _pad + _w * 0.085;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        crs_panel_row(_ids[_i], _x + _pad, _cy, _w - _pad * 2,
                      (!is_undefined(_selectedId) && _ids[_i] == _selectedId));
        _cy += _rowH + _gap;
    }

    draw_set_colour(_oldC); draw_set_font(_oldF);
    draw_set_halign(_oldH); draw_set_valign(_oldV);
    return _h;
}

/// The detail card: one faction, large, with its blazon, its lineage and its relations.
///
/// This is where the product argues for itself. The blazon under the shield says the arms were
/// composed rather than picked; the "descended from" line says the cadency mark means something;
/// the relations row says the number above it is part of a model rather than a variable.
function crs_panel_detail(_id, _x, _y, _w) {
    var _f = crs_faction_get(_id);
    if (is_undefined(_f)) return 0;

    var _pad = _w * 0.045;
    var _shield = _w * 0.20;
    var _h = _w * 0.86;
    var _s = _w / 560;

    var _oldC = draw_get_colour(), _oldF = draw_get_font();
    var _oldH = draw_get_halign(), _oldV = draw_get_valign();

    crs_ui_plate(_x, _y, _x + _w, _y + _h, _w * 0.024, crs_ui_colour("plate"));
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    crs_faction_draw(_id, _x + _w * 0.5, _y + _pad + _shield, _shield, undefined);

    var _cy = _y + _pad * 1.4 + _shield * 2;
    draw_set_font(crs_font_title());
    draw_set_colour(crs_ui_colour("ink"));
    draw_text_transformed(_x + _w * 0.5, _cy, _f.name, _s * 1.25, _s * 1.25, 0);

    _cy += _w * 0.058;
    draw_set_font(crs_font());
    draw_set_colour(crs_ui_colour("gild"));
    // The blazon can be long, so it wraps rather than running off the plate. A label that only fits
    // at one panel width is the defect this wing's constitution records finding at GIF size.
    draw_text_ext_transformed(_x + _w * 0.5, _cy, crs_arms_blazon(_f.arms),
                              _w * 0.062, (_w - _pad * 2) / _s, _s * 0.92, _s * 0.92, 0);

    _cy += _w * 0.115;
    crs_ui_rule(_x + _pad, _x + _w - _pad, _cy, crs_ui_colour("rule"));

    _cy += _w * 0.055;
    var _tier = crs_tier(_id);
    draw_set_font(crs_font_title());
    draw_set_colour(crs_tier_colour(_tier));
    draw_text_transformed(_x + _w * 0.5, _cy, string_upper(crs_tier_name(_tier)), _s, _s, 0);

    _cy += _w * 0.048;
    crs_ui_standing_bar(_x + _pad, _cy, _x + _w - _pad, _cy + _w * 0.026, _f.standing);

    _cy += _w * 0.072;
    draw_set_font(crs_font());
    draw_set_colour(crs_ui_colour("ink2"));

    if (_f.parent != "" && crs_faction_exists(_f.parent)) {
        var _p = crs_faction_get(_f.parent);
        draw_text_transformed(_x + _w * 0.5, _cy,
            "a cadet branch of " + _p.name, _s * 0.88, _s * 0.88, 0);
        _cy += _w * 0.042;
    }

    var _rel = crs_relations_of(_id);
    for (var _i = 0; _i < array_length(_rel); _i++) {
        var _o = crs_faction_get(_rel[_i][0]);
        if (is_undefined(_o)) continue;
        draw_set_colour((_rel[_i][1] == "rival") ? crs_ui_colour("bad") : crs_ui_colour("good"));
        draw_text_transformed(_x + _w * 0.5, _cy,
            ((_rel[_i][1] == "rival") ? "rival of " : "ally of ") + _o.name,
            _s * 0.88, _s * 0.88, 0);
        _cy += _w * 0.040;
    }

    draw_set_colour(_oldC); draw_set_font(_oldF);
    draw_set_halign(_oldH); draw_set_valign(_oldV);
    return _h;
}

/// Which row is under a point, or "". The panel is drawing code, so hit-testing lives beside it -
/// a buyer re-deriving the row pitch to make a list clickable is a buyer whose UI breaks the next
/// time these metrics change.
function crs_panel_hit(_px, _py, _x, _y, _w) {
    var _ids = crs_faction_ids();
    var _pad = _w * 0.030;
    var _gap = _w * 0.014;
    var _rowH = _w * 0.20;
    var _cy = _y + _pad + _w * 0.085;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        if (_px >= _x + _pad && _px <= _x + _w - _pad && _py >= _cy && _py <= _cy + _rowH) {
            return _ids[_i];
        }
        _cy += _rowH + _gap;
    }
    return "";
}
