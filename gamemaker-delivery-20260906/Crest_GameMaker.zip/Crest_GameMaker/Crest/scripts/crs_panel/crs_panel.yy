{
  "$GMScript": "v1",
  "%Name": "crs_panel",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_panel",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}