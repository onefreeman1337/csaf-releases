/// ============================================================================================
/// CREST - crs_bake: the store gallery, rendered by the product itself.
///
/// -- WHY THE SHEETS ARE BAKED IN-ENGINE AND NOT DRAWN BY A PREVIEWER ---------------------------
/// Because a gallery rendered by a side previewer is a picture of a RE-IMPLEMENTATION. This wing
/// measured that exactly: a previous product's JS previewer had a defect plainly visible in the
/// engine and invisible in the previewer, and a store page built from it would have been selling
/// pixels the shipped GML does not produce. Every image on Crest's store page is drawn by
/// crs_charges, crs_shields, crs_tincture and crs_render - the same functions a buyer gets.
///
/// It also lets the listing say "every image on this page was rendered by the product itself" and
/// have that be true.
///
/// -- THE EXTENT CHECK IS ONE NUMBER AND IT IS BLIND IN TWO DIRECTIONS --------------------------
/// ⛔ A returned `y` answers exactly one question: did the LAST thing drawn fall off the BOTTOM. It
/// is blind to horizontal overflow and blind to emptiness, and this wing shipped BOTH defects at
/// once while the extent check reported every sheet fine - a sheet with two lines of body copy
/// running off the right edge cut mid-word, and another with 35% of the surface left as bare page,
/// arguing the product has six things in it.
///
/// So every sheet is judged on its INK BOUNDING BOX, measured from the rendered pixels with
/// buffer_get_surface. That one measurement answers clipping AND emptiness.
///
/// ⚠️ AND ITS OWN HONEST LIMIT: the x-axis fill floor is largely neutralised by the full-width rule
/// under each title - one line satisfies the x span whatever the content is. The x floor earns its
/// keep through the EDGE-CLIP test, not through the coverage figure, and this comment exists so
/// nobody quotes the width number as if it measured coverage.
/// ============================================================================================

#macro CRS_BK_W 1600
#macro CRS_BK_H 1000

/// The floors. Measured against the previous product's real defects rather than chosen.
#macro CRS_BK_MIN_W_FRAC 0.86
#macro CRS_BK_MIN_H_FRAC 0.80
#macro CRS_BK_EDGE       6

/// The page. A dark plate rather than white, because every sheet is showing colour and a white
/// page makes `argent` and `or` disappear into it.
function crs_bk_page() { return crs_oklch(0.15, 0.012, 265); }

/// The ink bounds of a surface. Returns a struct of TWO boxes, each [x0, y0, x1, y1] or undefined:
///
///   .full     every inked pixel on the sheet, including the title block.  -> the CLIP test
///   .content  only ink BELOW the title rule.                              -> the COVERAGE tests
///
/// ⛔ STRIDE 1 IN Y, AND THE REASON IS MEASURED. This function used to step y by 2 "which quarters
/// the work and cannot miss anything wider than a pixel - and nothing this package draws at sheet
/// scale is one pixel wide". BOTH HALVES OF THAT WERE FALSE. crs_ui_rule draws its hairline with
/// draw_line_width(..., 1), on every sheet, under every title. Measured on sheet_8_system by
/// dumping the rendered PNG: the rule occupies EXACTLY ONE ROW, at y=165 - an ODD row - in
/// (61,66,77) against a (9,11,16) page. That is five times the tolerance below and unmistakably
/// ink, and the even-only scan walked straight past it.
///
/// A blind spot at 1px is not academic here: the whole point of the edge test is to catch something
/// touching the border, and a clipped hairline is exactly the shape that would land on one row.
///
/// X still steps by 2. Nothing in this package draws a one-pixel-wide VERTICAL feature, and the
/// consequence of being wrong about that is an x extent off by one, not a missed rule.
///
/// ⛔ AND THE TWO BOXES EXIST BECAUSE ONE NUMBER CANNOT DO BOTH JOBS. The wing constitution warns
/// that a full-width rule under the title "largely neutralises" the x-coverage floor - one line
/// satisfies the x span whatever the content is. Now that the scan can actually SEE that rule, that
/// warning would have come true here and the coverage floor would have become decoration. So
/// coverage is measured over the CONTENT box, which starts below the rule, and the clip test keeps
/// the full one. The floor then measures what it claims to measure.
function crs_bk_ink_bounds(_surf, _w, _h) {
    var _ground = crs_bk_page();
    var _gr = colour_get_red(_ground), _gg = colour_get_green(_ground), _gb = colour_get_blue(_ground);
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _surf, 0);

    var _top = variable_global_exists("__crs_bk_top") ? global.__crs_bk_top : 0;

    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;
    for (var _y = 0; _y < _h; _y += 1) {
        var _isContent = (_y >= _top);
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = (_y * _w + _x) * 4;
            var _r = buffer_peek(_buf, _o, buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b = buffer_peek(_buf, _o + 2, buffer_u8);
            // A tolerance of 10 per channel, not 0: the page is drawn once and then everything else
            // is composited over it, and a fill's own edge antialiasing lands a value or two off
            // the ground. Zero tolerance would report the page itself as ink.
            if (abs(_r - _gr) > 10 || abs(_g - _gg) > 10 || abs(_b - _gb) > 10) {
                if (_x < _x0) _x0 = _x;
                if (_x > _x1) _x1 = _x;
                if (_y < _y0) _y0 = _y;
                if (_y > _y1) _y1 = _y;
                if (_isContent) {
                    if (_x < _cx0) _cx0 = _x;
                    if (_x > _cx1) _cx1 = _x;
                    if (_y < _cy0) _cy0 = _y;
                    if (_y > _cy1) _cy1 = _y;
                }
            }
        }
    }
    buffer_delete(_buf);
    return {
        full:    (_x1 < 0)  ? undefined : [_x0, _y0, _x1, _y1],
        content: (_cx1 < 0) ? undefined : [_cx0, _cy0, _cx1, _cy1]
    };
}

/// A sheet's title block. Returns the y to carry on drawing from.
function crs_bk_title(_t, _sub, _y) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_font(crs_font_title());
    draw_set_colour(crs_ui_colour("ink"));
    draw_text_transformed(CRS_BK_W * 0.5, _y, _t, 3.0, 3.0, 0);
    draw_set_font(crs_font());
    draw_set_colour(crs_ui_colour("ink2"));
    draw_text_transformed(CRS_BK_W * 0.5, _y + 46, _sub, 1.5, 1.5, 0);
    crs_ui_rule(90, CRS_BK_W - 90, _y + 82, crs_ui_colour("rule"));
    // Where the CONTENT starts, for the coverage box in crs_bk_ink_bounds. Recorded here rather
    // than passed around because every sheet calls this first and nothing else may draw above it,
    // so this is the one place that knows. A few pixels below the rule, so the rule itself is
    // excluded from the figure it would otherwise satisfy single-handed.
    global.__crs_bk_top = _y + 90;
    return _y + 118;
}

function crs_bk_caption(_t, _x, _y, _scale) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_font(crs_font());
    draw_set_colour(crs_ui_colour("ink2"));
    draw_text_transformed(_x, _y, _t, _scale, _scale, 0);
}

/// ============================================================================================
/// THE SHEETS
///
/// Each returns the y it finished at. The runner compares that against the ink box; when the two
/// disagree, THE INK BOX IS RIGHT - a hand-maintained arithmetic expression about where drawing got
/// to is a claim, and the pixels are evidence. This wing has two sheets on record where the
/// returned y reported a clip that did not exist because a row pitch was multiplied by the row
/// COUNT instead of count - 1.
/// ============================================================================================

/// 1 - the hero. Six coats of arms, large, and nothing else. It is the thumbnail, so it has one job.
function crs_bk_sheet_hero() {
    // MEASURED: at title y=96 with a 380 row pitch the lower blazon line inked to y=998 on a 1000px
    // sheet - 2px of air, against a 6px edge floor. The title comes up and the pitch comes in; both
    // numbers are here rather than spread through the loop so the next edit can see the budget.
    var _y = crs_bk_title("CREST", "faction, reputation and composed heraldry for GameMaker", 78);
    crs_faction_reset();
    var _ids = ["ironcrown", "saltguild", "ashenorder", "thornwild", "greycollege", "seahold"];
    var _names = ["The Iron Crown", "The Salt Guild", "The Ashen Order",
                  "The Thornwilds", "The Grey College", "The Seahold"];
    var _traits = [["noble", "martial"], ["merchant", "coastal"], ["pious"],
                   ["wild"], ["scholar"], ["coastal", "martial"]];
    for (var _i = 0; _i < 6; _i++) crs_faction_add(_ids[_i], _names[_i], _traits[_i]);

    var _s = 150;
    for (var _i = 0; _i < 6; _i++) {
        // ⛔ THE PITCH IS BOUNDED FROM BELOW, NOT JUST FROM ABOVE, AND THE FIRST FIX BROKE IT.
        // Cutting the pitch to 364 to buy bottom margin closed the gap between row 0's blazon and
        // row 1's shield, and the caption was drawn THROUGH by the next shield - the same overprint
        // this wing recorded on Charter as "WickthorSt Cuthman's". The budget, written out:
        //   row 0 caption bottom = cy + s + 76 + 8   = cy + 234
        //   row 1 shield top     = cy + PITCH - s    = cy + PITCH - 150
        //   no overprint  =>  PITCH > 384
        //   bottom ink    =>  158 + PITCH + 234 <= 994 - _y(196)  =>  PITCH <= 564 - 158
        // 400 sits inside both. Neither bound is obvious from looking at one row, which is why they
        // are written here rather than rediscovered.
        var _cx = CRS_BK_W * (0.19 + (_i % 3) * 0.31);
        var _cy = _y + 140 + floor(_i / 3) * 400;
        crs_faction_draw(_ids[_i], _cx, _cy, _s, undefined);
        draw_set_font(crs_font_title());
        draw_set_halign(fa_center); draw_set_valign(fa_middle);
        draw_set_colour(crs_ui_colour("ink"));
        draw_text_transformed(_cx, _cy + _s + 44, _names[_i], 1.5, 1.5, 0);
        crs_bk_caption(crs_arms_blazon(crs_faction_arms(_ids[_i])), _cx, _cy + _s + 76, 1.0);
    }
    return _y + 140 + 400 + 150 + 80;
}

/// 2 - the corpus. All 44 charges, named. This is the volume argument, and it is made by showing
/// the volume rather than by claiming it.
function crs_bk_sheet_corpus() {
    var _y = crs_bk_title("FORTY-FOUR CHARGES", "in six orders, drawn in GML - no sprite, no atlas, no texture page", 78);
    var _ids = crs_charge_ids();
    var _cols = 9;
    var _cw = (CRS_BK_W - 160) / _cols;
    var _ink = crs_ui_colour("ink");
    var _det = crs_ui_colour("gild");
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _cx = 80 + _cw * ((_i % _cols) + 0.5);
        var _cy = _y + 62 + floor(_i / _cols) * 158;
        crs_charge_draw(_ids[_i], _cx, _cy, 52, _ink, _det);
        crs_bk_caption(crs_charge_name(_ids[_i]), _cx, _cy + 76, 0.86);
    }
    return _y + 62 + 5 * 158 + 40;
}

/// 3 - the acceptance criterion, shown honestly. The same 44 at the size a faction list uses.
function crs_bk_sheet_silhouettes() {
    var _y = crs_bk_title("AT TWENTY PIXELS", "the size a charge is actually seen at, inside a shield in a faction list", 78);
    var _ids = crs_charge_ids();
    crs_faction_reset();
    var _cols = 11;
    var _cw = (CRS_BK_W - 160) / _cols;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _cx = 80 + _cw * ((_i % _cols) + 0.5);
        var _cy = _y + 70 + floor(_i / _cols) * 170;
        // A real coat of arms, at real list size, then the SAME arms magnified beside it - so a
        // buyer can see that the small one is the large one and not a simplified stand-in.
        var _arms = {
            shield: "heater", ordinary: "plain", charge: _ids[_i], order: "",
            field: "sable", ord_t: "sable", charge_t: "or", under: "sable",
            cadency: "", parent: ""
        };
        crs_arms_draw(_arms, _cx - 34, _cy, 17, { edge: true, cadency: true, furs: true });
        crs_arms_draw(_arms, _cx + 26, _cy, 46, { edge: true, cadency: true, furs: true });
        crs_bk_caption(crs_charge_name(_ids[_i]), _cx, _cy + 74, 0.78);
    }
    return _y + 70 + 4 * 170 + 60;
}

/// 4 - the multipliers. One charge, every shield and a run of ordinaries, so the combinatorics are
/// visible rather than asserted.
function crs_bk_sheet_variety() {
    var _y = crs_bk_title("4,928 COATS OF ARMS", "44 charges x 8 shields x 14 ordinaries, before a tincture is chosen", 78);
    var _sh = crs_shield_ids();
    var _ords = crs_ordinary_ids();
    var _s = 62;

    draw_set_halign(fa_center); draw_set_valign(fa_middle);
    for (var _i = 0; _i < array_length(_sh); _i++) {
        var _cx = 130 + _i * ((CRS_BK_W - 260) / 7);
        var _arms = { shield: _sh[_i], ordinary: "plain", charge: "lion", order: "",
                      field: "azure", ord_t: "azure", charge_t: "or", under: "azure",
                      cadency: "", parent: "" };
        crs_arms_draw(_arms, _cx, _y + 70, _s, undefined);
        crs_bk_caption(crs_shield_name(_sh[_i]), _cx, _y + 70 + _s + 26, 0.92);
    }

    var _y2 = _y + 230;
    draw_set_font(crs_font_title());
    draw_set_colour(crs_ui_colour("gild"));
    draw_text_transformed(CRS_BK_W * 0.5, _y2, "AND FOURTEEN ORDINARIES", 1.6, 1.6, 0);
    _y2 += 56;
    for (var _i = 0; _i < array_length(_ords); _i++) {
        var _cx = 130 + (_i % 7) * ((CRS_BK_W - 260) / 6);
        var _cy = _y2 + 70 + floor(_i / 7) * 210;
        var _arms = { shield: "heater", ordinary: _ords[_i], charge: "eagle", order: "",
                      field: "argent", ord_t: "gules", charge_t: "sable", under: "gules",
                      cadency: "", parent: "" };
        crs_arms_draw(_arms, _cx, _cy, _s, undefined);
        crs_bk_caption(crs_ordinary_name(_ords[_i]), _cx, _cy + _s + 26, 0.92);
    }
    return _y2 + 70 + 210 + _s + 60;
}

/// 5 - the rule of tincture. The product's best small idea, explained in pictures.
function crs_bk_sheet_tincture() {
    var _y = crs_bk_title("THE RULE OF TINCTURE",
        "no metal on metal, no colour on colour - enforced, not decorative", 84);

    draw_set_halign(fa_center); draw_set_valign(fa_middle);
    draw_set_font(crs_font());
    draw_set_colour(crs_ui_colour("ink2"));
    draw_text_ext_transformed(CRS_BK_W * 0.5, _y + 30,
        "An 800-year-old legibility rule, obeyed by the generator. It is the whole difference "
        + "between arms that look composed and arms that look random - and it is why no two "
        + "tinctures in this package ever meet as mud.",
        34, 1180, 1.15, 1.15, 0);

    var _s = 96;
    var _refused = [["or", "argent"], ["gules", "azure"], ["or", "vair"]];
    var _allowed = [["or", "azure"], ["sable", "argent"], ["argent", "gules"]];

    for (var _i = 0; _i < 3; _i++) {
        var _cx = CRS_BK_W * (0.22 + _i * 0.14);
        var _a = { shield: "heater", ordinary: "plain", charge: "lion", order: "",
                   field: _refused[_i][1], ord_t: _refused[_i][1], charge_t: _refused[_i][0],
                   under: _refused[_i][1], cadency: "", parent: "" };
        crs_arms_draw(_a, _cx, _y + 230, _s, undefined);
        draw_set_colour(crs_ui_colour("bad"));
        crs_bk_caption(crs_tincture_name(_refused[_i][0]) + " on "
            + crs_tincture_name(_refused[_i][1]), _cx, _y + 230 + _s + 30, 0.95);
        draw_set_colour(crs_ui_colour("bad"));
        crs_bk_caption(crs_rule_of_tincture_why(_refused[_i][0], _refused[_i][1]),
                       _cx, _y + 230 + _s + 58, 0.86);
    }
    draw_set_font(crs_font_title());
    draw_set_colour(crs_ui_colour("bad"));
    draw_text_transformed(CRS_BK_W * 0.115, _y + 230, "REFUSED", 1.4, 1.4, 0);

    for (var _i = 0; _i < 3; _i++) {
        var _cx = CRS_BK_W * (0.22 + _i * 0.14);
        var _a = { shield: "heater", ordinary: "plain", charge: "lion", order: "",
                   field: _allowed[_i][1], ord_t: _allowed[_i][1], charge_t: _allowed[_i][0],
                   under: _allowed[_i][1], cadency: "", parent: "" };
        crs_arms_draw(_a, _cx, _y + 500, _s, undefined);
        draw_set_colour(crs_ui_colour("good"));
        crs_bk_caption(crs_tincture_name(_allowed[_i][0]) + " on "
            + crs_tincture_name(_allowed[_i][1]), _cx, _y + 500 + _s + 30, 0.95);
    }
    draw_set_font(crs_font_title());
    draw_set_colour(crs_ui_colour("good"));
    draw_text_transformed(CRS_BK_W * 0.115, _y + 500, "ALLOWED", 1.4, 1.4, 0);

    // the nine tinctures themselves, as a swatch row
    // ⛔ THE SWATCH ROW OVERPRINTED THE "ALLOWED" CAPTIONS AT 660, and no mechanical check could see
    // it: an ink bounding box is a RECTANGLE AROUND EVERYTHING and says nothing about two elements
    // inside it landing on each other. The ALLOWED captions bottom out at _y+634 (500 + 96 + 30 + 8)
    // and a 42-radius roundel at _ty reaches up to _ty-42, so the row must start below _y+676.
    // Bottom stays inside: 696 + 62 + 8 = 766, against 994 - _y(202) = 792.
    var _ts = crs_tincture_ids();
    var _ty = _y + 696;
    for (var _i = 0; _i < array_length(_ts); _i++) {
        var _cx = CRS_BK_W * (0.62 + 0) + 0;
        _cx = 250 + _i * ((CRS_BK_W - 500) / 8);
        var _a = { shield: "roundel", ordinary: "plain", charge: "mullet", order: "",
                   field: _ts[_i], ord_t: _ts[_i],
                   charge_t: crs_tinctures_allowed_on(_ts[_i])[0],
                   under: _ts[_i], cadency: "", parent: "" };
        crs_arms_draw(_a, _cx, _ty, 42, undefined);
        crs_bk_caption(crs_tincture_name(_ts[_i]), _cx, _ty + 62, 0.86);
    }
    return _ty + 100;
}

/// 6 - the schism. The mechanic that makes this a faction system rather than a picture-maker.
function crs_bk_sheet_schism() {
    // ⛔ THE TITLE WAS THE CLIP, NOT THE CAPTIONS. At 40 characters and scale 3.0 "WHEN A HOUSE
    // SPLITS, THE BANNER SHOWS IT" inked from x=0 to x=1598 - centred, so it ran off BOTH edges -
    // while the content underneath sat comfortably at 198..1414. The first fix pulled the child
    // columns in, which was the wrong half of the sheet entirely and made the real defect worse by
    // narrowing content that was already too narrow. A title is content too, and scale 3.0 buys
    // about 20 characters on a 1600px sheet.
    var _y = crs_bk_title("WHEN A HOUSE SPLITS",
        "a cadet branch inherits its parent's arms and adds a mark of difference", 84);

    crs_faction_reset();
    crs_faction_add("crown", "The Iron Crown", ["noble", "martial"]);
    crs_faction_schism("crown", "c1", "The Dissent", 0.5);
    crs_faction_schism("crown", "c2", "The Broken Oath", 0.5);
    crs_faction_schism("crown", "c3", "The Lesser Seat", 0.5);
    crs_faction_schism("crown", "c4", "The Exiles", 0.5);
    crs_faction_schism("crown", "c5", "The Remnant", 0.5);

    crs_faction_draw("crown", CRS_BK_W * 0.5, _y + 190, 148, undefined);
    draw_set_font(crs_font_title());
    draw_set_halign(fa_center); draw_set_valign(fa_middle);
    draw_set_colour(crs_ui_colour("ink"));
    draw_text_transformed(CRS_BK_W * 0.5, _y + 370, "The Iron Crown", 2.0, 2.0, 0);
    crs_bk_caption(crs_arms_blazon(crs_faction_arms("crown")), CRS_BK_W * 0.5, _y + 404, 1.05);

    var _kids = ["c1", "c2", "c3", "c4", "c5"];
    for (var _i = 0; _i < 5; _i++) {
        // MEASURED, after the title turned out to be the real overflow: the widest thing under a
        // column is about 168px at scale 0.84, i.e. 84px either side of the centre - NOT the ~436px
        // first estimated. So the columns can spread nearly to the margins, and they need to: at
        // 270 + i*265 the content spanned only 1216 of 1600 (76%). 170 + i*315 puts the outer
        // captions at roughly x=78 and x=1522 against a 6px floor.
        var _cx = 170 + _i * ((CRS_BK_W - 340) / 4);
        var _cy = _y + 590;
        draw_set_colour(crs_ui_colour("rule"));
        draw_line_width(CRS_BK_W * 0.5, _y + 430, _cx, _cy - 96, 2);
        crs_faction_draw(_kids[_i], _cx, _cy, 88, undefined);
        var _f = crs_faction_get(_kids[_i]);
        draw_set_font(crs_font());
        draw_set_colour(crs_ui_colour("ink"));
        draw_text_transformed(_cx, _cy + 112, _f.name, 1.2, 1.2, 0);
        draw_set_colour(crs_ui_colour("gild"));
        crs_bk_caption("differenced by " + crs_cadency_name(_f.arms.cadency), _cx, _cy + 140, 0.84);
    }
    return _y + 590 + 180;
}

/// 7 - the panel, in situ. A buyer sees the thing they get, not a mock-up of it.
function crs_bk_sheet_panel() {
    var _y = crs_bk_title("A FACTION PANEL, INCLUDED",
        "drawn in GML from the same palette layer - no sprite, no windowskin, no font from the IDE", 78);

    crs_faction_reset();
    crs_faction_add("crown",  "The Iron Crown",   ["noble", "martial"]);
    crs_faction_add("guild",  "The Salt Guild",   ["merchant", "coastal"]);
    crs_faction_add("order",  "The Ashen Order",  ["pious"]);
    crs_faction_add("wilds",  "The Thornwilds",   ["wild"]);
    crs_faction_add("college","The Grey College", ["scholar"]);
    crs_relation_set("crown", "guild", "ally");
    crs_relation_set("crown", "wilds", "rival");
    crs_standing_set("crown", 35);  crs_standing_set("guild", 62);
    crs_standing_set("order", -18); crs_standing_set("wilds", -55);
    crs_standing_set("college", 8);

    // MEASURED at the previous geometry (panel 120 w620, detail 880 w520): ink ran 140..1452, i.e.
    // 82% of the width, with 148px of dead page down the right side. The mapping is exact and worth
    // recording - ink_left = panelX + 20, ink_right = detailX + detailW + 52 - so both columns just
    // grow into the margin rather than being nudged and re-measured.
    // ⚠️ AND THE SECOND MEASUREMENT CORRECTED THE FIRST. ink_right is NOT detailX + detailW + 52; it
    // is detailX + detailW - pad, i.e. detailX + 0.955 * detailW. The reason is worth keeping: the
    // detail PLATE is crs_ui_colour("plate") at L=0.18 against an L=0.15 page, which is under the
    // ink detector's 10-per-channel tolerance, so the plate itself is not counted as ink at all.
    // The coverage figure therefore measures the TEXT INSIDE the panels, not the panels.
    //
    // ⛔ AND THAT BLIND SPOT LET A CLIPPED PANEL SHIP-READY. At 660 wide the list panel is 812 tall,
    // which from y+30 ran 38px off the bottom of the sheet - and the ink check called it fine,
    // because the part hanging over the edge was plate rather than text. So the width is no longer
    // a chosen number: it is SOLVED from the space available, and it cannot clip by construction.
    var _top = _y + 30;
    var _avail = (CRS_BK_H - CRS_BK_EDGE) - _top;
    var _n = crs_faction_count();
    var _pw = min(620, crs_panel_width_for_height(_avail, _n));
    crs_panel_draw(90, _top, _pw, "crown");

    // The detail card is sized the same way - its height is 0.86 of its width - and then placed so
    // that ink_right clears the 86% coverage floor: 110 + 0.86*1600 = 1486 is the target.
    // 730 rather than 760: at 760 the plate's right edge lands at 1570 on a 1600 sheet, which
    // clears the 6px floor and still LOOKS crowded. The floor is a minimum, not a margin.
    var _dw = min(730, _avail / 0.86);
    var _dx = 90 + _pw + 100;
    crs_panel_detail("crown", _dx, _top, _dw);
    return _top + max(crs_panel_height(_pw, _n), _dw * 0.86) + 60;
}

/// 8 - what is in the box, built from the package's OWN data rather than from a hand-typed list.
function crs_bk_sheet_system() {
    var _y = crs_bk_title("WHAT IS IN THE BOX",
        "a complete faction layer - the heraldry is its face, not its whole", 84);

    var _rows = [
        [string(crs_charge_count()) + " charges", "in six orders, every one drawn from data"],
        [string(array_length(crs_shield_ids())) + " shield shapes",
         "each with its own charge placement and its own measured room"],
        [string(array_length(crs_ordinary_ids())) + " ordinaries",
         "clipped to the shield in geometry, exact for all 112 pairs"],
        [string(array_length(crs_tincture_ids())) + " tinctures",
         "including two drawn furs, in Oklch, under the rule of tincture"],
        [string(array_length(crs_cadency_ids())) + " marks of cadency",
         "wired to schism, so a splinter's banner shows where it came from"],
        ["Standing and tiers", "six named tiers, renameable, with gates and price multipliers"],
        ["Allies and rivals", "a gain with one house spills to the houses around it"],
        ["Schism and merge", "factions split and absorb, and the arms follow the history"],
        ["Save and load", "one string, and it refuses a mismatched registry rather than half-loading"],
        ["A faction panel", "list, detail card, blazon and hit-testing, ready to drop in"],
        // ⚠️ NOT A HAND-TYPED EXAMPLE. This row used to quote "Azure, a bend Or, a lion Argent",
        // which is NOT what crs_arms_blazon emits - it writes the charge name capitalised and with
        // no article ("Azure, a bend Or, Lion Argent."). A fabricated sample of your own output, on
        // your own store page, is the cheapest possible way to be caught not running your product.
        ["Blazon", "the heraldic description of any arms, composed for you"],
        ["Raw readable GML", "every global and macro namespaced crs_ / CRS_, header on every script"]
    ];

    // MEASURED: left-aligning both columns at 150 and 620 inked only 150..1260 - 69% of the width,
    // with 340px of bare page down the right-hand side. That is the defect this wing shipped before
    // ("35% of the surface left as bare page, arguing the product has six things in it").
    //
    // The label stays left and the description is set FLUSH RIGHT to a 1500 margin, which is an
    // ordinary specification-table setting and spans the sheet with real text.
    //
    // ⛔ AND DELIBERATELY WITHOUT LEADER RULES between the two columns. A hairline leader per row
    // would look smart and would ALSO span the full width in ink - which, now that the scan reads
    // 1px features and the coverage box is the content area, would satisfy the width floor on its
    // own and quietly turn the check back into decoration. Ornament that defeats a measurement is
    // not worth the measurement.
    draw_set_valign(fa_middle);
    var _cy = _y + 40;
    for (var _i = 0; _i < array_length(_rows); _i++) {
        draw_set_halign(fa_left);
        draw_set_colour(crs_ui_colour("gild"));
        draw_set_font(crs_font_title());
        draw_text_transformed(100, _cy, _rows[_i][0], 1.35, 1.35, 0);

        draw_set_halign(fa_right);
        draw_set_colour(crs_ui_colour("ink2"));
        draw_set_font(crs_font());
        draw_text_transformed(1500, _cy, _rows[_i][1], 1.15, 1.15, 0);
        _cy += 62;
    }
    draw_set_halign(fa_center);
    return _cy + 40;
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

function crs_bake_sheet_ids() {
    return ["sheet_1_hero", "sheet_2_corpus", "sheet_3_silhouettes", "sheet_4_variety",
            "sheet_5_tincture", "sheet_6_schism", "sheet_7_panel", "sheet_8_system"];
}

function crs_bake_one(_i) {
    switch (_i) {
        case 0: return crs_bk_sheet_hero();
        case 1: return crs_bk_sheet_corpus();
        case 2: return crs_bk_sheet_silhouettes();
        case 3: return crs_bk_sheet_variety();
        case 4: return crs_bk_sheet_tincture();
        case 5: return crs_bk_sheet_schism();
        case 6: return crs_bk_sheet_panel();
        default: return crs_bk_sheet_system();
    }
}

/// Render every sheet, save the PNGs, and report each one's ink box.
///
/// ⛔ The crash handler goes in FIRST, same as the self-test: a GML runtime error opens a modal
/// dialog nobody is there to dismiss, and the runner would report a timeout naming nothing.
function crs_bake_main() {
    global.__crs_stage = 0;
    exception_unhandled_handler(function(_ex) {
        var _f = file_text_open_write("crs_bake.json");
        file_text_write_string(_f, "{\"crash\":true,\"stage\":" + string(global.__crs_stage)
            + ",\"message\":\"" + string_replace_all(string(_ex.message), "\"", "'") + "\"}");
        file_text_close(_f);
        game_end();
        return true;
    });

    var _names = crs_bake_sheet_ids();
    var _report = "";

    for (var _i = 0; _i < array_length(_names); _i++) {
        global.__crs_stage = _i + 1;
        var _surf = surface_create(CRS_BK_W, CRS_BK_H);
        surface_set_target(_surf);
        draw_clear(crs_bk_page());
        // Reset per sheet. Inheriting the PREVIOUS sheet's content top would silently measure this
        // sheet's coverage from the wrong line - a stale global is the same class of defect as a
        // stale gate result, and costs the same way.
        global.__crs_bk_top = 0;
        var _bottom = crs_bake_one(_i);
        surface_reset_target();

        var _boxes = crs_bk_ink_bounds(_surf, CRS_BK_W, CRS_BK_H);
        var _box = _boxes.full;
        var _con = _boxes.content;
        surface_save(_surf, _names[_i] + ".png");
        surface_free(_surf);

        var _ok = true, _why = "";
        if (is_undefined(_box)) {
            _ok = false; _why = "EMPTY - nothing was drawn";
        } else if (is_undefined(_con)) {
            // A sheet that drew a title and nothing under it. The old single-box check could not
            // tell this from a full sheet, because the title alone satisfies both spans.
            _ok = false; _why = "EMPTY BELOW THE TITLE - the sheet is a heading and no content";
        } else {
            // CLIP on the FULL box: a hairline touching the border is exactly what this must catch.
            // COVERAGE on the CONTENT box: see the note in crs_bk_ink_bounds - the title rule spans
            // 1420 of 1600 by itself, so measuring coverage on the full box would pass every sheet
            // no matter how little was on it.
            var _iw = _con[2] - _con[0], _ih = _con[3] - _con[1];
            if (_box[0] < CRS_BK_EDGE || _box[1] < CRS_BK_EDGE
             || _box[2] > CRS_BK_W - CRS_BK_EDGE || _box[3] > CRS_BK_H - CRS_BK_EDGE) {
                _ok = false;
                _why = "CLIPPED - ink at x " + string(_box[0]) + ".." + string(_box[2])
                     + ", y " + string(_box[1]) + ".." + string(_box[3]);
            } else if (_iw < CRS_BK_W * CRS_BK_MIN_W_FRAC) {
                _ok = false; _why = "too narrow - content spans " + string(_iw) + " of " + string(CRS_BK_W);
            } else if (_ih < CRS_BK_H * CRS_BK_MIN_H_FRAC * 0.82) {
                // The content box excludes the title block, so it cannot be judged against the same
                // fraction of the FULL sheet height the old check used - that would fail every
                // sheet by construction. 0.82 of the old floor is the same absolute band measured
                // against the content area rather than the page.
                _ok = false; _why = "too empty - content spans " + string(_ih) + " of " + string(CRS_BK_H);
            }
        }

        if (_report != "") _report += ",";
        _report += "{\"sheet\":\"" + _names[_i] + "\",\"ok\":" + (_ok ? "true" : "false")
            + ",\"reason\":\"" + _why + "\",\"returned_y\":" + string(round(_bottom))
            + ",\"ink\":" + (is_undefined(_box) ? "null"
                : ("[" + string(_box[0]) + "," + string(_box[1]) + ","
                   + string(_box[2]) + "," + string(_box[3]) + "]"))
            + ",\"content\":" + (is_undefined(_con) ? "null"
                : ("[" + string(_con[0]) + "," + string(_con[1]) + ","
                   + string(_con[2]) + "," + string(_con[3]) + "]")) + "}";
    }

    var _f = file_text_open_write("crs_bake.json");
    file_text_write_string(_f, "{\"crash\":false,\"w\":" + string(CRS_BK_W) + ",\"h\":"
        + string(CRS_BK_H) + ",\"sheets\":[" + _report + "]}");
    file_text_close(_f);
    game_end();
}

/// ============================================================================================
/// THE DEMO GIF
///
/// ⛔ THERE IS NO ANIMATION CODE HERE, AND THAT IS THE POINT. The motion is the SYSTEM RUNNING: a
/// house is registered, its arms are composed, it splinters, and each cadet branch's banner is
/// derived from its parent's. Every frame is drawn by the same public functions a buyer calls.
/// Nothing is tweened, keyframed or faked, so a viewer is watching the product work.
///
/// ⚠️ IT RENDERS AT 900x560, NOT AT SHEET SIZE, DELIBERATELY. This wing's constitution: "DRAW THE
/// SAME THING SMALLER TO FIND THE LAYOUT BUGS". Charter's place names ran off the page at 900px
/// while composing perfectly at 1600px, because margins that are generous at one size are not at
/// another. A product that only composes correctly at store-sheet size fails in the buyer's game.
/// ============================================================================================

#macro CRS_GIF_W      900
#macro CRS_GIF_H      560
#macro CRS_GIF_CYCLE  48
#macro CRS_GIF_FRAMES 96

/// The houses the GIF cycles through. TWO, so a viewer sees the arms are DERIVED rather than one
/// lucky drawing - the second cycle is a different house, a different coat and different marks.
function crs_gif_houses() {
    return [["ironcrown", "The Iron Crown", ["noble", "martial"]],
            ["saltguild", "The Salt Guild", ["merchant", "coastal"]]];
}

function crs_gif_children() {
    return ["The Dissent", "The Broken Oath", "The Lesser Seat", "The Exiles", "The Remnant"];
}

/// Draw one frame. PURE: the same _n always produces the same picture, so the runner can re-render
/// a single frame to inspect it without reproducing a sequence.
function crs_gif_frame(_n) {
    var _cycle = (_n div CRS_GIF_CYCLE) % 2;
    var _t = _n % CRS_GIF_CYCLE;
    var _h = crs_gif_houses()[_cycle];

    crs_faction_reset();
    crs_faction_add(_h[0], _h[1], _h[2]);

    // How many cadet branches exist BY THIS FRAME: one every 6 frames from frame 12.
    var _shown = clamp((_t - 12) div 6 + 1, 0, 5);
    var _kids = crs_gif_children();
    for (var _i = 0; _i < _shown; _i++) {
        crs_faction_schism(_h[0], _h[0] + "_c" + string(_i), _kids[_i], 0.5);
    }

    draw_clear(crs_bk_page());
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    var _px = CRS_GIF_W * 0.5, _py = 150;
    crs_faction_draw(_h[0], _px, _py, 96, undefined);
    draw_set_font(crs_font_title());
    draw_set_colour(crs_ui_colour("ink"));
    draw_text_transformed(_px, _py + 132, _h[1], 1.5, 1.5, 0);
    draw_set_font(crs_font());
    draw_set_colour(crs_ui_colour("ink2"));
    draw_text_transformed(_px, _py + 162, crs_arms_blazon(crs_faction_arms(_h[0])), 0.92, 0.92, 0);

    for (var _i = 0; _i < _shown; _i++) {
        var _cx = 130 + _i * ((CRS_GIF_W - 260) / 4);
        var _cy = 420;
        draw_set_colour(crs_ui_colour("rule"));
        draw_line_width(_px, _py + 186, _cx, _cy - 64, 2);
        var _id = _h[0] + "_c" + string(_i);
        crs_faction_draw(_id, _cx, _cy, 58, undefined);
        var _f = crs_faction_get(_id);
        draw_set_font(crs_font());
        draw_set_colour(crs_ui_colour("gild"));
        draw_text_transformed(_cx, _cy + 86, crs_cadency_name(_f.arms.cadency), 0.86, 0.86, 0);
    }

    draw_set_font(crs_font());
    draw_set_colour(crs_ui_colour("ink2"));
    var _cap = (_shown == 0)
        ? "one house, and its arms were composed - not drawn"
        : "a cadet branch inherits its parent's arms and adds a mark of difference";
    draw_text_transformed(CRS_GIF_W * 0.5, CRS_GIF_H - 26, _cap, 0.95, 0.95, 0);
}

/// ⛔ THE CRASH HANDLER GOES IN FIRST, same as the other two entry points: a GML runtime error opens
/// a MODAL dialog headless has nobody to dismiss, and the runner would report a meaningless timeout
/// naming nothing at all.
function crs_gif_main() {
    global.__crs_stage = 0;
    exception_unhandled_handler(function(_ex) {
        var _f = file_text_open_write("crs_gif.json");
        file_text_write_string(_f, "{\"ran\":false,\"blocked\":true,\"frames\":0,\"bad\":0,\"reason\":\"CRASH at frame "
            + string(global.__crs_stage) + ": "
            + string_replace_all(string(_ex.message), "\"", "'") + "\"}");
        file_text_close(_f);
        game_end();
        return true;
    });

    var _bad = 0, _firstBad = "";
    for (var _n = 0; _n < CRS_GIF_FRAMES; _n++) {
        global.__crs_stage = _n;
        var _surf = surface_create(CRS_GIF_W, CRS_GIF_H);
        surface_set_target(_surf);
        global.__crs_bk_top = 0;      // the GIF has no title rule; content is the whole frame
        crs_gif_frame(_n);
        surface_reset_target();

        // EVERY frame is ink-checked for a clip. Cheap, and it is the check that catches a layout
        // that only works at 1600px - which is the entire reason this renders at 900.
        var _box = crs_bk_ink_bounds(_surf, CRS_GIF_W, CRS_GIF_H).full;
        if (is_undefined(_box)) {
            _bad++;
            if (_firstBad == "") _firstBad = "frame " + string(_n) + " is EMPTY";
        } else if (_box[0] < CRS_BK_EDGE || _box[1] < CRS_BK_EDGE
                || _box[2] > CRS_GIF_W - CRS_BK_EDGE || _box[3] > CRS_GIF_H - CRS_BK_EDGE) {
            _bad++;
            if (_firstBad == "") _firstBad = "frame " + string(_n) + " CLIPPED - ink at x "
                + string(_box[0]) + ".." + string(_box[2]) + ", y "
                + string(_box[1]) + ".." + string(_box[3]);
        }

        // Zero-padded so the encoder globs them in ORDER. "gifframe_9" sorts after "gifframe_10".
        var _lbl = string(_n);
        while (string_length(_lbl) < 3) _lbl = "0" + _lbl;
        surface_save(_surf, "gifframe_" + _lbl + ".png");
        surface_free(_surf);
    }

    var _f = file_text_open_write("crs_gif.json");
    file_text_write_string(_f, "{\"ran\":true,\"blocked\":false,\"w\":" + string(CRS_GIF_W)
        + ",\"h\":" + string(CRS_GIF_H) + ",\"frames\":" + string(CRS_GIF_FRAMES)
        + ",\"bad\":" + string(_bad) + ",\"firstBad\":\"" + _firstBad + "\"}");
    file_text_close(_f);
    game_end();
}
