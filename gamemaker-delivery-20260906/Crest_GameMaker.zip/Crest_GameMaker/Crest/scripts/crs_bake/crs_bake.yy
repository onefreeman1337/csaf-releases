{
  "$GMScript": "v1",
  "%Name": "crs_bake",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_bake",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}