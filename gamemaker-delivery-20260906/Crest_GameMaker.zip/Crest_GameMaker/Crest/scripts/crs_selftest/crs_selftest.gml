/// ============================================================================================
/// CREST - crs_selftest: the headless in-engine suite.
///
/// -- WHY THIS EXISTS, AND WHAT IT IS THE ONLY WAY TO CATCH -------------------------------------
/// GML cannot be unit-tested outside the engine. That is true and it does not follow that the
/// engine cannot test itself unattended: Internal_Ops/run_selftest.ps1 builds the project through
/// the real Igor gate, runs the executable with `-selftest`, and reads the result file back. No
/// human in the loop.
///
/// Internal_Ops/check_charges.js already checks the corpus statically, and it is genuinely useful -
/// it runs in a second and it caught two real out-of-budget charges the first time it executed. But
/// it parses TEXT. It cannot evaluate a loop, cannot see the geometry a helper actually returns,
/// and cannot know whether a struct method kept its own state. Every assertion below is over values
/// the shipped functions really produced.
///
/// -- THE FOUR TRAPS THIS WING PAID FOR, ALL OF THEM ENCODED HERE -------------------------------
///   1. ⛔ A GML RUNTIME ERROR OPENS A MODAL DIALOG. Headless there is nobody to dismiss it, so the
///      process never exits and the runner reports a meaningless timeout. The FIRST line of the
///      entry point installs exception_unhandled_handler with a stage number, which turns an opaque
///      180-second hang into "CRASH at stage 7: <the real message>".
///   2. ⛔ show_debug_message is DEAD in a release build - the runner's -debugoutput file gets the
///      engine's boot lines and nothing from our code. Results go through file_text_open_write.
///   3. ⛔ game_end(n) does NOT propagate its argument to the process exit code. A run that should
///      have exited 152000 exited 0. The result FILE is the evidence; the exit code is not.
///   4. ⛔ GML APPLIES A DEFAULT EPSILON OF 1e-6 TO NUMERIC COMPARISONS. A tolerance below ~1e-5 can
///      never fire in either direction, so an assertion written that way passes VACUOUSLY forever.
///      This wing shipped a whole distinctness suite that way. CRS_EPS is far above it and is the
///      only tolerance in this file.
/// ============================================================================================

/// The one tolerance in the suite. See trap 4 above: never write a smaller one anywhere in GML.
#macro CRS_EPS 0.00002

/// The 20px silhouette grid. The acceptance criterion in Motif_Corpus.md §1 is a claim about how a
/// charge reads at 20 pixels, so the test rasterises at exactly that.
#macro CRS_SIL_N 20

/// Minimum number of differing cells between any two charges' 20px silhouettes, out of 400.
///
/// ⚠️ A DELIBERATELY LOW FLOOR, AND THE REPORT IS THE REAL OUTPUT. This number cannot decide whether
/// two shapes look like different THINGS - only that their filled areas differ - so setting it high
/// would produce false reds on pairs that are genuinely distinct to an eye. It is set where it
/// catches a true collapse (two charges that have become nearly the same drawing) and the suite
/// prints the ten closest pairs every run, which is the output a human actually acts on.
#macro CRS_SIL_MIN 10

function crs_test_state() {
    return {
        pass: 0,
        fail: 0,
        failures: [],
        notes: []
    };
}

function crs_ok(_st, _cond, _what) {
    if (_cond) { _st.pass += 1; return true; }
    _st.fail += 1;
    array_push(_st.failures, _what);
    return false;
}

function crs_note(_st, _line) {
    array_push(_st.notes, _line);
}

/// True when two point arrays are the same polygon, point for point.
///
/// ⚠️ THE TOLERANCE IS 1e-4 AND MUST NOT BE TIGHTENED. GML applies math_get_epsilon (default 1e-6)
/// to numeric comparisons, so a tolerance at or below it makes the comparison meaningless in BOTH
/// directions - this wing has already shipped a suite whose duplicate-detection could never fire
/// for exactly that reason. 1e-4 is comfortably above the epsilon and far below any real difference
/// between two distinct charge polygons.
function crs_st_pts_match(_a, _b) {
    if (array_length(_a) != array_length(_b)) return false;
    for (var _i = 0; _i < array_length(_a); _i++) {
        if (abs(_a[_i][0] - _b[_i][0]) > 0.0001) return false;
        if (abs(_a[_i][1] - _b[_i][1]) > 0.0001) return false;
    }
    return true;
}

/// ============================================================================================
/// SILHOUETTE RASTERISER - the acceptance criterion, mechanised
/// ============================================================================================

/// Rasterise a charge's parts into a CRS_SIL_N x CRS_SIL_N boolean occupancy grid over the unit box.
///
/// Roles are honoured the way an eye honours them: CHARGE and DETAIL are ink, and CRS_R_FIELD is a
/// VOID - it is how `crescent` gets its bite and how `mullet` gets its piercing. Ignoring that would
/// measure a crescent as a full disc and report a collision with `sun` that a viewer would never
/// see, which is a false red on the one test whose whole job is judging shapes.
function crs_silhouette(_id) {
    var _n = CRS_SIL_N;
    var _grid = array_create(_n * _n, false);
    var _tris = crs_parts_to_tris(crs_charge(_id));

    for (var _t = 0; _t < array_length(_tris); _t++) {
        var _tri = _tris[_t].t;
        var _ink = (_tris[_t].role != CRS_R_FIELD);
        // Bounding box in cell space, so a small charge does not cost a full grid scan per triangle.
        var _minx = min(_tri[0][0], _tri[1][0], _tri[2][0]);
        var _maxx = max(_tri[0][0], _tri[1][0], _tri[2][0]);
        var _miny = min(_tri[0][1], _tri[1][1], _tri[2][1]);
        var _maxy = max(_tri[0][1], _tri[1][1], _tri[2][1]);
        var _c0 = max(0, floor((_minx + 0.5) * _n)), _c1 = min(_n - 1, ceil((_maxx + 0.5) * _n));
        var _r0 = max(0, floor((_miny + 0.5) * _n)), _r1 = min(_n - 1, ceil((_maxy + 0.5) * _n));
        for (var _r = _r0; _r <= _r1; _r++) {
            for (var _c = _c0; _c <= _c1; _c++) {
                var _px = (_c + 0.5) / _n - 0.5;
                var _py = (_r + 0.5) / _n - 0.5;
                if (crs_point_in_tri(_px, _py, _tri)) _grid[_r * _n + _c] = _ink;
            }
        }
    }
    return _grid;
}

function crs_point_in_tri(_px, _py, _t) {
    var _d1 = (_px - _t[1][0]) * (_t[0][1] - _t[1][1]) - (_t[0][0] - _t[1][0]) * (_py - _t[1][1]);
    var _d2 = (_px - _t[2][0]) * (_t[1][1] - _t[2][1]) - (_t[1][0] - _t[2][0]) * (_py - _t[2][1]);
    var _d3 = (_px - _t[0][0]) * (_t[2][1] - _t[0][1]) - (_t[2][0] - _t[0][0]) * (_py - _t[0][1]);
    var _neg = (_d1 < 0) || (_d2 < 0) || (_d3 < 0);
    var _pos = (_d1 > 0) || (_d2 > 0) || (_d3 > 0);
    return !(_neg && _pos);
}

/// ============================================================================================
/// EXACT EXTENT - over the ops the functions actually return
/// ============================================================================================

/// The furthest any point of a part list reaches from the origin. Sampled arcs are walked, strips
/// are walked on both rails, and a dot counts centre PLUS radius. This is the measurement
/// check_charges.js can only approximate.
function crs_parts_reach(_parts) {
    var _r = 0;
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case CRS_DOT:
                _r = max(_r, point_distance(0, 0, _p.cx, _p.cy) + _p.r);
                break;
            case CRS_ARC: {
                var _steps = 48;
                for (var _k = 0; _k <= _steps; _k++) {
                    var _a = lerp(_p.a0, _p.a1, _k / _steps);
                    _r = max(_r, point_distance(0, 0, _p.cx + cos(_a) * _p.r,
                                                     _p.cy + sin(_a) * _p.r) + _p.w * 0.5);
                }
            } break;
            case CRS_STRIP:
                for (var _k = 0; _k < array_length(_p.a); _k++) {
                    _r = max(_r, point_distance(0, 0, _p.a[_k][0], _p.a[_k][1]));
                }
                for (var _k = 0; _k < array_length(_p.b); _k++) {
                    _r = max(_r, point_distance(0, 0, _p.b[_k][0], _p.b[_k][1]));
                }
                break;
            default:
                for (var _k = 0; _k < array_length(_p.pts); _k++) {
                    _r = max(_r, point_distance(0, 0, _p.pts[_k][0], _p.pts[_k][1]));
                }
                break;
        }
    }
    return _r;
}

/// A part list flattened to a comparable string, for determinism checks. Rounded to 6 places
/// because the question is "did this produce the same geometry", not "are two doubles bit-equal".
function crs_parts_signature(_parts) {
    var _s = "";
    for (var _i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        _s += string(_p.kind) + ":" + string(_p.role) + ":";
        switch (_p.kind) {
            case CRS_DOT: _s += string_format(_p.cx, 1, 6) + "," + string_format(_p.cy, 1, 6)
                              + "," + string_format(_p.r, 1, 6); break;
            case CRS_ARC: _s += string_format(_p.cx, 1, 6) + "," + string_format(_p.cy, 1, 6)
                              + "," + string_format(_p.r, 1, 6) + "," + string_format(_p.a0, 1, 6)
                              + "," + string_format(_p.a1, 1, 6); break;
            case CRS_STRIP:
                for (var _k = 0; _k < array_length(_p.a); _k++) {
                    _s += string_format(_p.a[_k][0], 1, 6) + "," + string_format(_p.a[_k][1], 1, 6) + ";";
                }
                break;
            default:
                for (var _k = 0; _k < array_length(_p.pts); _k++) {
                    _s += string_format(_p.pts[_k][0], 1, 6) + "," + string_format(_p.pts[_k][1], 1, 6) + ";";
                }
                break;
        }
        _s += "|";
    }
    return _s;
}

/// ============================================================================================
/// THE SUITE
/// ============================================================================================

/// Run every stage. Returns the state struct.
///
/// _stage is written into a global before each stage so the crash handler can name where it died.
function crs_selftest_run() {
    var _st = crs_test_state();
    var _ids = crs_charge_ids();

    /* -- 1. CORPUS PARITY ------------------------------------------------------------------- */
    global.__crs_stage = 1;
    crs_ok(_st, array_length(_ids) == 44, "expected 44 charges, got " + string(array_length(_ids)));
    crs_ok(_st, array_length(crs_order_ids()) == 6, "expected 6 orders");
    crs_ok(_st, array_length(crs_shield_ids()) == 8, "expected 8 shields");
    crs_ok(_st, array_length(crs_ordinary_ids()) == 14, "expected 14 ordinaries");
    crs_ok(_st, array_length(crs_tincture_ids()) == 9, "expected 9 tinctures");
    crs_ok(_st, array_length(crs_cadency_ids()) == 6, "expected 6 cadency marks");
    for (var _i = 0; _i < array_length(_ids); _i++) {
        crs_ok(_st, crs_charge_index(_ids[_i]) == _i, "index mismatch for " + _ids[_i]);
        crs_ok(_st, crs_charge_name(_ids[_i]) != "", "no display name for " + _ids[_i]);
    }

    /* -- 2. EVERY CHARGE IS A REAL DRAWING, AND HAS SOLID MASS ------------------------------ */
    // ⛔ The solid-mass assertion is the one this wing did not have. A previous product's corpus
    // was stroked outlines: it passed 369 assertions and rendered as grey dust at small sizes,
    // because a sub-pixel stroke draws at partial coverage. A fill has no width to lose.
    global.__crs_stage = 2;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _p = crs_charge(_ids[_i]);
        crs_ok(_st, array_length(_p) >= 3, _ids[_i] + " has only " + string(array_length(_p)) + " ops");
        var _solid = 0;
        for (var _k = 0; _k < array_length(_p); _k++) {
            if (_p[_k].kind == CRS_FILL || _p[_k].kind == CRS_STRIP || _p[_k].kind == CRS_DOT) _solid++;
        }
        crs_ok(_st, _solid >= 1, _ids[_i] + " emits no solid op - it will dissolve when small");
    }

    /* -- 3. DETERMINISM --------------------------------------------------------------------- */
    // Two identical calls must produce identical geometry. This is the assertion that caught a
    // struct-with-a-method rng whose state did not stay with the generator - a defect no static
    // check and no JavaScript preview could have found, because JS closures capture correctly.
    global.__crs_stage = 3;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _a = crs_parts_signature(crs_charge(_ids[_i]));
        var _b = crs_parts_signature(crs_charge(_ids[_i]));
        crs_ok(_st, _a == _b, _ids[_i] + " geometry differs between identical calls");
    }
    var _r1 = crs_rng(12345), _r2 = crs_rng(12345);
    for (var _k = 0; _k < 8; _k++) {
        crs_ok(_st, abs(crs_rng_next(_r1) - crs_rng_next(_r2)) < CRS_EPS,
               "two rngs seeded alike diverged at draw " + string(_k));
    }

    /* -- 4. EXACT EXTENT -------------------------------------------------------------------- */
    global.__crs_stage = 4;
    var _worst = 0, _worstId = "";
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _r = crs_parts_reach(crs_charge(_ids[_i]));
        if (_r > _worst) { _worst = _r; _worstId = _ids[_i]; }
        crs_ok(_st, _r <= CRS_CHARGE_BOX + CRS_EPS,
               _ids[_i] + " reaches r=" + string_format(_r, 1, 4)
               + " > CRS_CHARGE_BOX " + string(CRS_CHARGE_BOX));
    }
    crs_note(_st, "worst exact reach " + string_format(_worst, 1, 4) + " (" + _worstId + ")");

    /* -- 5. THE SHIELD INRADIUS IS TRUE, NOT DECLARED --------------------------------------- */
    // crs_shields declares a number per shape. A declared number nobody measures is a guess wearing
    // a constant's clothes, so every one is checked against its own real outline here.
    global.__crs_stage = 5;
    var _sh = crs_shield_ids();
    for (var _i = 0; _i < array_length(_sh); _i++) {
        var _declared = crs_shield_inradius(_sh[_i]);
        var _measured = crs_shield_measure_inradius(_sh[_i]);
        crs_ok(_st, _measured >= _declared - CRS_EPS,
               _sh[_i] + " declares inradius " + string_format(_declared, 1, 4)
               + " but measures " + string_format(_measured, 1, 4));
        crs_note(_st, "shield " + _sh[_i] + ": declared " + string_format(_declared, 1, 3)
                 + ", measured " + string_format(_measured, 1, 3));
    }

    /* -- 6. THE CONTRACT HOLDS ON EVERY SHIELD, AGAINST THE MEASURED RADIUS ------------------ */
    global.__crs_stage = 6;
    for (var _i = 0; _i < array_length(_sh); _i++) {
        var _placed = CRS_CHARGE_BOX * CRS_CHARGE_FIT * crs_shield_fit(_sh[_i]) + CRS_FIELD_INSET;
        var _room = crs_shield_measure_inradius(_sh[_i]);
        crs_ok(_st, _placed <= _room + CRS_EPS,
               "contract broken on " + _sh[_i] + ": placed " + string_format(_placed, 1, 4)
               + " > measured inradius " + string_format(_room, 1, 4));
    }

    /* -- 7. A CADENCY MARK NEVER LANDS ON THE CHARGE ---------------------------------------- */
    // crs_cadency's header claims the mark sits above every anchor. This is that claim measured,
    // over the real geometry of all six marks and all eight shields.
    global.__crs_stage = 7;
    var _lowest = crs_cadency_lowest();

    // The DECLARED bound first. crs_charge_anchor derives the charge's whole placement from
    // CRS_CAD_LOW, so if a mark is ever redrawn lower than the constant claims, every clearance
    // below is computed from a lie. This is the assertion that keeps the constant honest.
    crs_ok(_st, _lowest <= CRS_CAD_LOW + CRS_EPS,
           "a cadency mark reaches y=" + string_format(_lowest, 1, 4)
           + ", below the declared CRS_CAD_LOW " + string(CRS_CAD_LOW));

    for (var _i = 0; _i < array_length(_sh); _i++) {
        var _anchor = crs_charge_anchor(_sh[_i], true);
        var _reach = CRS_CHARGE_BOX * CRS_CHARGE_FIT * crs_shield_fit(_sh[_i]) * CRS_CAD_SQUEEZE;
        var _chargeTop = _anchor[1] - _reach;
        crs_ok(_st, _lowest <= _chargeTop + CRS_EPS,
               "cadency reaches y=" + string_format(_lowest, 1, 4) + " but the charge on "
               + _sh[_i] + " starts at y=" + string_format(_chargeTop, 1, 4));

        // ...and the squeezed, shifted charge must still FIT. Clearing the mark by sliding the
        // charge off the bottom of the shield would satisfy the assertion above and be worse than
        // the collision it fixed, so the room is re-measured about the anchor actually used.
        var _room = crs_shield_measure_inradius_at(_sh[_i], _anchor[0], _anchor[1]);
        crs_ok(_st, _reach + CRS_FIELD_INSET <= _room + CRS_EPS,
               "a differenced charge on " + _sh[_i] + " needs "
               + string_format(_reach + CRS_FIELD_INSET, 1, 4) + " but has "
               + string_format(_room, 1, 4));
    }
    crs_note(_st, "cadency lowest y " + string_format(_lowest, 1, 4)
             + ", declared " + string(CRS_CAD_LOW) + ", squeeze " + string(CRS_CAD_SQUEEZE));

    /* -- 8. THE LILY'S SIDE LOBES HANG DOWN ------------------------------------------------- */
    // ⛔ THE ONE CHARGE WITH A MEASURED PRIOR FAILURE. A previous product's fleur-de-lis had its
    // side lobes rising and curling outward; it read as A PAIR OF DEVIL HORNS on that product's
    // hero image, and it passed part count, north-is-up, distinctness and ink bounds. The three
    // facts that make a fleur are asserted here rather than trusted to the drawing.
    global.__crs_stage = 8;
    {
        /* ⛔ THIS STAGE USED TO GUESS WHICH POLYGON WAS A LOBE, AND THE GUESS WAS WRONG BOTH WAYS.
           It selected fills whose every point sits off the centre line (min |x| >= 0.04). The lily
           has FOUR such fills - the two lobes, the BAND (x = +/-0.28) and the TAIL (x = +/-0.07..11)
           - so it reported "expected 2 side lobes, found 4" against a drawing that is correct.

           The silent half was worse than the noisy half. Band and tail both start at a NEGATIVE x,
           so both were classed as the dexter side, and the tail was written LAST - which means
           "the dexter lobe does not hang DOWN" was asserting a true fact about THE TAIL and had
           never once looked at a lobe. The recorded note read "lily lobes end at y 0.440 / 0.160";
           0.440 is the tail's low point. A test that guesses which part of a drawing it is looking
           at eventually asserts something true about the wrong part.

           crs_lily_lobe() exists precisely so this guess is unnecessary - see its header in
           crs_charges. The suite now reads the lobe from the same function the drawing calls. */
        var _lobeL = crs_lily_lobe(-1);
        var _lobeR = crs_lily_lobe(1);

        // (a) THE FACT THAT MAKES A FLEUR A FLEUR: each lobe's tip hangs BELOW its root. Its
        //     absence is what made a previous product's fleur read as a pair of devil horns.
        var _rootL = _lobeL[0][1], _tipL = _lobeL[array_length(_lobeL) - 1][1];
        var _rootR = _lobeR[0][1], _tipR = _lobeR[array_length(_lobeR) - 1][1];
        crs_ok(_st, _tipL > _rootL, "lily: the dexter lobe tip (y " + string_format(_tipL, 1, 3)
               + ") does not hang BELOW its root (y " + string_format(_rootL, 1, 3) + ")");
        crs_ok(_st, _tipR > _rootR, "lily: the sinister lobe tip (y " + string_format(_tipR, 1, 3)
               + ") does not hang BELOW its root (y " + string_format(_rootR, 1, 3) + ")");

        // (b) each lobe sweeps OUTWARD, away from the centre line, and they mirror each other.
        var _reachL = 0, _reachR = 0;
        for (var _k = 0; _k < array_length(_lobeL); _k++) {
            _reachL = max(_reachL, -_lobeL[_k][0]);
            _reachR = max(_reachR,  _lobeR[_k][0]);
        }
        crs_ok(_st, _reachL > 0.20 && _reachR > 0.20,
               "lily: a lobe does not sweep outward (dexter " + string_format(_reachL, 1, 3)
               + ", sinister " + string_format(_reachR, 1, 3) + ")");
        crs_ok(_st, abs(_reachL - _reachR) < 0.0001, "lily: the lobes are not mirrored");

        // (c) ⛔ AND THE DRAWING MUST ACTUALLY USE THEM. (a) and (b) test a FUNCTION; without this
        //     they would keep passing if crs_ch_lily stopped calling it, which is the same
        //     wrong-part vacuity in a new place.
        var _lily = crs_charge("lily");
        var _usedL = false, _usedR = false;
        for (var _i = 0; _i < array_length(_lily); _i++) {
            var _p = _lily[_i];
            if (_p.kind != CRS_FILL) continue;
            if (crs_st_pts_match(_p.pts, _lobeL)) _usedL = true;
            if (crs_st_pts_match(_p.pts, _lobeR)) _usedR = true;
        }
        crs_ok(_st, _usedL && _usedR,
               "lily: crs_ch_lily does not draw both crs_lily_lobe() lobes (dexter " + string(_usedL)
               + ", sinister " + string(_usedR) + ")");

        crs_note(_st, "lily lobe tips y " + string_format(_tipL, 1, 3) + " / "
                 + string_format(_tipR, 1, 3) + " from roots y " + string_format(_rootL, 1, 3)
                 + ", outward reach " + string_format(_reachL, 1, 3) + ", drawn " + string(_usedL && _usedR));
    }

    /* -- 9. THE 20px SILHOUETTE CRITERION, MECHANISED --------------------------------------- */
    // Motif_Corpus.md §1 says a charge is finished when it is not confusable with any other at
    // 20px. That is a claim about pictures, so it is measured on pictures: every charge is
    // rasterised to a 20x20 occupancy grid and every pair is compared.
    //
    // ⚠️ ITS HONEST LIMIT: this can tell that two filled areas differ. It CANNOT tell that two
    // shapes read as different things - a saucepan and a spring have very different grids. The
    // closest pairs are reported every run because THAT is the output a human acts on; §7 of the
    // corpus document is still the acceptance step.
    global.__crs_stage = 9;
    {
        var _n = array_length(_ids);
        var _grids = array_create(_n);
        for (var _i = 0; _i < _n; _i++) _grids[_i] = crs_silhouette(_ids[_i]);

        // Any charge whose silhouette is EMPTY is a charge that draws nothing at the size it is
        // judged at - a defect that no op count can see.
        for (var _i = 0; _i < _n; _i++) {
            var _ink = 0;
            for (var _c = 0; _c < CRS_SIL_N * CRS_SIL_N; _c++) if (_grids[_i][_c]) _ink++;
            crs_ok(_st, _ink >= 12, _ids[_i] + " has only " + string(_ink)
                   + " lit cells at " + string(CRS_SIL_N) + "px - it vanishes when small");
        }

        var _bestA = array_create(10, ""), _bestB = array_create(10, "");
        var _bestD = array_create(10, 99999);
        for (var _i = 0; _i < _n; _i++) {
            for (var _k = _i + 1; _k < _n; _k++) {
                var _d = 0;
                for (var _c = 0; _c < CRS_SIL_N * CRS_SIL_N; _c++) {
                    if (_grids[_i][_c] != _grids[_k][_c]) _d++;
                }
                crs_ok(_st, _d >= CRS_SIL_MIN, "\"" + _ids[_i] + "\" and \"" + _ids[_k]
                       + "\" differ in only " + string(_d) + " cells at "
                       + string(CRS_SIL_N) + "px");
                // keep the ten closest, insertion-sorted
                if (_d < _bestD[9]) {
                    var _at = 9;
                    while (_at > 0 && _bestD[_at - 1] > _d) {
                        _bestD[_at] = _bestD[_at - 1]; _bestA[_at] = _bestA[_at - 1];
                        _bestB[_at] = _bestB[_at - 1]; _at--;
                    }
                    _bestD[_at] = _d; _bestA[_at] = _ids[_i]; _bestB[_at] = _ids[_k];
                }
            }
        }
        for (var _i = 0; _i < 10; _i++) {
            if (_bestA[_i] == "") continue;
            crs_note(_st, "closest pair " + string(_i + 1) + ": " + _bestA[_i] + " / "
                     + _bestB[_i] + " = " + string(_bestD[_i]) + " cells");
        }
    }

    /* -- 10. ORDINARIES ARE AUTHORED IN SHIELD SPACE, AND CLIP INSIDE THE SHIELD ------------- */
    // The easiest mistake in this package is authoring an ordinary in the CHARGE's box: it does not
    // throw, it silently draws a bend at 58% of its size tucked inside the middle of the shield.
    // An ordinary must reach past the unit box, and after clipping must be inside the outline.
    global.__crs_stage = 10;
    {
        var _ords = crs_ordinary_ids();
        for (var _i = 0; _i < array_length(_ords); _i++) {
            if (_ords[_i] == "plain") continue;
            var _reach = crs_parts_reach(crs_ordinary(_ords[_i]));
            crs_ok(_st, _reach > 0.5,
                   "ordinary \"" + _ords[_i] + "\" only reaches " + string_format(_reach, 1, 3)
                   + " - it was authored in the charge's box, not the shield's");
        }
        // and the clip actually contains them
        for (var _s = 0; _s < array_length(_sh); _s++) {
            var _clipped = crs_clip_parts_to_shield(crs_ordinary("bend"), _sh[_s]);
            crs_ok(_st, array_length(_clipped) > 0,
                   "clipping a bend to " + _sh[_s] + " produced nothing");
            var _rr = crs_parts_reach(_clipped);
            // The clipped result must sit inside the shield's own outline, whose furthest point is
            // its circumradius. Measured, not assumed to be 0.5 - the banner's corner is 0.622.
            var _circ = 0;
            var _pts = crs_shield_pts(_sh[_s]);
            for (var _k = 0; _k < array_length(_pts); _k++) {
                _circ = max(_circ, point_distance(0, 0, _pts[_k][0], _pts[_k][1]));
            }
            crs_ok(_st, _rr <= _circ + CRS_EPS,
                   "a bend clipped to " + _sh[_s] + " reaches " + string_format(_rr, 1, 4)
                   + " past its circumradius " + string_format(_circ, 1, 4));
        }
    }

    /* -- 11. THE RULE OF TINCTURE, OVER EVERY DERIVED COAT OF ARMS -------------------------- */
    // Not over a sample. 400 ids is enough to exercise every branch of the derivation, and the
    // point of deriving-within-the-legal-set rather than rolling-and-retrying is that this can
    // never fail - which is only worth anything if somebody checks.
    global.__crs_stage = 11;
    {
        var _bad = 0, _firstBad = "";
        for (var _i = 0; _i < 400; _i++) {
            var _a = crs_arms_derive("house_" + string(_i), undefined);
            var _why = crs_arms_problem(_a);
            if (_why != "") { _bad++; if (_firstBad == "") _firstBad = "house_" + string(_i) + ": " + _why; }
        }
        crs_ok(_st, _bad == 0, string(_bad) + " of 400 derived arms break the rule of tincture ("
               + _firstBad + ")");

        // ⛔ AND A BLAZON MAY NOT NAME A FUR THE DRAWING CANNOT SHOW. crs_arms_draw renders the fur
        // PATTERN only for the field; an ordinary or charge tinctured Ermine or Vair came out as
        // flat colour while the blazon still said "a fess Ermine". Four such claims shipped on one
        // baked hero sheet before anybody read a blazon against its own picture.
        var _furOrd = 0, _furCharge = 0, _furField = 0, _firstFur = "";
        for (var _i = 0; _i < 400; _i++) {
            var _a2 = crs_arms_derive("fur_" + string(_i), undefined);
            if (crs_tincture_is_fur(_a2.field)) _furField++;
            if (_a2.ordinary != "plain" && crs_tincture_is_fur(_a2.ord_t)) {
                _furOrd++; if (_firstFur == "") _firstFur = "fur_" + string(_i) + " ordinary";
            }
            if (crs_tincture_is_fur(_a2.charge_t)) {
                _furCharge++; if (_firstFur == "") _firstFur = "fur_" + string(_i) + " charge";
            }
        }
        crs_ok(_st, _furOrd == 0 && _furCharge == 0,
               string(_furOrd) + " ordinaries and " + string(_furCharge)
               + " charges were tinctured with a fur the renderer cannot pattern (" + _firstFur + ")");
        // ...and the FIELD must still reach them, or the restriction has quietly removed the furs
        // from the product altogether - which would be a worse fix than the defect.
        crs_ok(_st, _furField > 0, "no derived arms use a fur as the FIELD - the furs are unreachable");
        crs_note(_st, "furs: " + string(_furField) + "/400 fields, 0 ordinaries, 0 charges");

        // and the rule itself is not vacuous in EITHER direction - a predicate that always returns
        // true is exactly the shape of the epsilon failure this suite's header warns about.
        crs_ok(_st, !crs_rule_of_tincture_ok("or", "argent"), "metal on metal was allowed");
        crs_ok(_st, !crs_rule_of_tincture_ok("gules", "azure"), "colour on colour was allowed");
        crs_ok(_st, crs_rule_of_tincture_ok("or", "azure"), "metal on colour was refused");
        crs_ok(_st, crs_rule_of_tincture_ok("sable", "argent"), "colour on metal was refused");
        crs_ok(_st, !crs_rule_of_tincture_ok("or", "vair"),
               "or on vair passed - the lightness gap is not being applied");
    }

    /* -- 12. DERIVATION IS STABLE AND TRAIT-SENSITIVE --------------------------------------- */
    global.__crs_stage = 12;
    {
        var _x = crs_arms_derive("stable_test", ["martial"]);
        var _y = crs_arms_derive("stable_test", ["martial"]);
        crs_ok(_st, _x.charge == _y.charge && _x.shield == _y.shield && _x.field == _y.field,
               "the same id and traits produced different arms");
        // a martial faction must land in `beast` or `arms`, never in `craft`
        var _o = crs_arms_derive("martial_test", ["martial"]).order;
        crs_ok(_st, _o == "beast" || _o == "arms",
               "a martial faction got order \"" + _o + "\"");
        var _p = crs_arms_derive("pious_test", ["pious"]).order;
        crs_ok(_st, _p == "sacred", "a pious faction got order \"" + _p + "\"");
    }

    /* -- 13. THE FACTION SYSTEM ------------------------------------------------------------- */
    global.__crs_stage = 13;
    {
        crs_faction_reset();
        crs_faction_add("crown", "The Crown", ["noble"]);
        crs_faction_add("guild", "The Guild", ["merchant"]);
        crs_faction_add("wilds", "The Wilds", ["wild"]);
        crs_ok(_st, crs_faction_count() == 3, "expected 3 factions after registration");

        // ⛔ reset must actually work. Setting the global to undefined leaves it EXISTING, which
        // made the first implementation of crs_faction_reset crash every call after it.
        crs_faction_reset();
        crs_ok(_st, crs_faction_count() == 0, "reset left factions behind");
        crs_faction_add("crown", "The Crown", ["noble"]);
        crs_faction_add("guild", "The Guild", ["merchant"]);
        crs_faction_add("wilds", "The Wilds", ["wild"]);

        crs_relation_set("crown", "guild", "ally");
        crs_relation_set("crown", "wilds", "rival");
        crs_ok(_st, crs_relation("guild", "crown") == "ally", "relations are not symmetric");

        // standing, tiers and clamping
        crs_standing_set("crown", 0);
        crs_ok(_st, crs_tier("crown") == "neutral", "0 is not neutral");
        crs_standing_set("crown", 500);
        crs_ok(_st, crs_standing("crown") == CRS_STANDING_MAX, "standing did not clamp high");
        crs_standing_set("crown", -500);
        crs_ok(_st, crs_standing("crown") == CRS_STANDING_MIN, "standing did not clamp low");
        crs_ok(_st, crs_tier("crown") == "hated", "the floor is not the worst tier");

        // THE SPILL - the thing that makes this a model rather than a variable
        crs_standing_set("crown", 0); crs_standing_set("guild", 0); crs_standing_set("wilds", 0);
        var _res = crs_standing_add("crown", 40, true);
        crs_ok(_st, _res.direct == 40, "direct standing change was " + string(_res.direct));
        crs_ok(_st, crs_standing("guild") > 0, "an ally did not gain from the spill");
        crs_ok(_st, crs_standing("wilds") < 0, "a rival did not lose from the spill");
        crs_ok(_st, array_length(_res.spilled) == 2,
               "the spill report named " + string(array_length(_res.spilled)) + " factions, not 2");

        // ⛔ ONE HOP. The Guild is the Crown's ally; if spill cascaded, helping the Crown would move
        // the Guild AND everything related to the Guild. That is the design decision most likely to
        // be "improved" by a later edit, so it is pinned here.
        crs_faction_reset();
        crs_faction_add("a", "A", undefined);
        crs_faction_add("b", "B", undefined);
        crs_faction_add("c", "C", undefined);
        crs_relation_set("a", "b", "ally");
        crs_relation_set("b", "c", "ally");
        crs_standing_add("a", 40, true);
        crs_ok(_st, crs_standing("b") > 0, "the first hop did not apply");
        crs_ok(_st, crs_standing("c") == 0,
               "spill CASCADED to a second hop - c moved to " + string(crs_standing("c")));

        // spill can be switched off
        crs_faction_reset();
        crs_faction_add("a", "A", undefined); crs_faction_add("b", "B", undefined);
        crs_relation_set("a", "b", "rival");
        crs_standing_add("a", 30, false);
        crs_ok(_st, crs_standing("b") == 0, "spill was applied when it was switched off");

        // gates
        crs_faction_reset();
        crs_faction_add("crown", "The Crown", ["noble"]);
        crs_standing_set("crown", 70);
        crs_ok(_st, crs_tier("crown") == "honoured", "70 is not honoured");
        crs_ok(_st, crs_gate("crown", "friendly"), "a gate refused a BETTER tier");
        crs_ok(_st, crs_gate("crown", "honoured"), "a gate refused an exact tier");
        crs_ok(_st, !crs_gate("crown", "exalted"), "a gate allowed a tier not yet reached");
        crs_ok(_st, crs_price_mult("crown") < 1.0, "an honoured faction is not charging less");
        crs_standing_set("crown", -80);
        crs_ok(_st, crs_price_mult("crown") > 1.0, "a hated faction is not charging more");
    }

    /* -- 14. SCHISM: THE ARMS FOLLOW THE HISTORY -------------------------------------------- */
    // This is the product's Gate 2 answer, so it gets asserted rather than described.
    global.__crs_stage = 14;
    {
        crs_faction_reset();
        crs_faction_add("crown", "The Crown", ["noble"]);
        crs_standing_set("crown", 60);
        var _parent = crs_faction_arms("crown");

        var _cadet = crs_faction_schism("crown", "rebels", "The Rebel Court", 0.5);
        crs_ok(_st, !is_undefined(_cadet), "schism returned nothing");
        crs_ok(_st, _cadet.arms.charge == _parent.charge, "a cadet branch changed its charge");
        crs_ok(_st, _cadet.arms.shield == _parent.shield, "a cadet branch changed its shield");
        crs_ok(_st, _cadet.arms.field == _parent.field, "a cadet branch changed its field");
        crs_ok(_st, _cadet.arms.cadency == "label", "the first cadet mark is not a label");
        crs_ok(_st, _parent.cadency == "", "the schism marked the PARENT's arms");
        crs_ok(_st, abs(crs_standing("rebels") - 30) < 0.5,
               "carried standing was " + string(crs_standing("rebels")) + ", expected 30");
        crs_ok(_st, crs_relation("crown", "rebels") == "rival",
               "a splinter and its parent are not rivals");

        var _second = crs_faction_schism("crown", "exiles", "The Exiles", 0);
        crs_ok(_st, _second.arms.cadency == "crescent", "the second cadet mark is not a crescent");
        crs_ok(_st, crs_standing("exiles") == 0, "a clean-break schism carried standing anyway");

        var _line = crs_faction_lineage("rebels");
        crs_ok(_st, array_length(_line) == 2 && _line[1] == "crown",
               "lineage did not resolve to the parent");

        // every one of the six marks is reachable, and they wrap rather than crashing at seven
        for (var _i = 0; _i < 8; _i++) {
            crs_ok(_st, crs_cadency_for_branch(_i) != "", "branch " + string(_i) + " has no mark");
        }
        crs_ok(_st, crs_cadency_for_branch(6) == crs_cadency_for_branch(0),
               "cadency marks do not wrap at six");
    }

    /* -- 15. MERGE AVERAGES, IT DOES NOT ADD ------------------------------------------------ */
    global.__crs_stage = 15;
    {
        crs_faction_reset();
        crs_faction_add("a", "A", undefined);
        crs_faction_add("b", "B", undefined);
        crs_standing_set("a", 50);
        crs_standing_set("b", 30);
        crs_ok(_st, crs_faction_merge("a", "b"), "merge refused a legal merge");
        crs_ok(_st, abs(crs_standing("a") - 40) < 0.5,
               "merged standing was " + string(crs_standing("a")) + ", expected the average 40");
        crs_ok(_st, crs_faction_count() == 1, "an absorbed faction is still listed as live");
        crs_ok(_st, array_length(crs_faction_ids_all()) == 2,
               "an absorbed faction was removed from the registry entirely");
        crs_ok(_st, !crs_faction_merge("a", "b"), "a faction was merged twice");
    }

    /* -- 16. SAVE AND LOAD ------------------------------------------------------------------ */
    global.__crs_stage = 16;
    {
        crs_faction_reset();
        crs_faction_add("crown", "The Crown", ["noble"]);
        crs_faction_add("guild", "The Guild", ["merchant"]);
        crs_relation_set("crown", "guild", "rival");
        crs_standing_set("crown", 44);
        crs_standing_set("guild", -22);
        crs_faction_schism("crown", "rebels", "The Rebel Court", 0.5);
        var _saved = crs_save_string();
        var _cadetMark = crs_faction_arms("rebels").cadency;

        crs_standing_set("crown", 0);
        crs_standing_set("guild", 0);
        crs_relation_set("crown", "guild", "neutral");

        var _err = crs_load_string(_saved);
        crs_ok(_st, _err == "", "load failed: " + _err);
        crs_ok(_st, crs_standing("crown") == 44, "crown standing did not restore");
        crs_ok(_st, crs_standing("guild") == -22, "guild standing did not restore");
        crs_ok(_st, crs_relation("crown", "guild") == "rival", "relations did not restore");
        // ⛔ the positional-parse trap: most factions have EMPTY parent and merged fields, so a
        // split that removes empty entries shifts every later field by one and restores a
        // working-looking world with the lineage wrong.
        crs_ok(_st, crs_faction_get("rebels").parent == "crown",
               "lineage did not restore - the save row parsed positionally wrong");
        crs_ok(_st, crs_faction_arms("rebels").cadency == _cadetMark,
               "the cadet's mark of difference did not survive a save/load");

        // it REFUSES rather than half-applying
        crs_ok(_st, crs_load_string("") != "", "an empty string was accepted");
        crs_ok(_st, crs_load_string("nonsense") != "", "a non-save string was accepted");
        crs_ok(_st, crs_load_string("CRS99|0") != "", "a wrong version was accepted");
        crs_faction_reset();
        crs_faction_add("crown", "The Crown", ["noble"]);
        var _err2 = crs_load_string(_saved);
        crs_ok(_st, _err2 != "", "a save naming unregistered factions was accepted");
        crs_ok(_st, crs_standing("crown") == 0,
               "a REFUSED load still wrote to the world - it is not atomic");
    }

    /* -- 17. BLAZON ------------------------------------------------------------------------- */
    global.__crs_stage = 17;
    {
        crs_faction_reset();
        crs_faction_add("crown", "The Crown", ["noble"]);
        var _b = crs_arms_blazon(crs_faction_arms("crown"));
        crs_ok(_st, string_length(_b) > 12, "the blazon is too short to be one");
        crs_ok(_st, string_char_at(_b, string_length(_b)) == ".", "the blazon does not end in a stop");
        crs_ok(_st, string_length(crs_arms_describe(crs_faction_arms("crown"))) > 12,
               "the plain-English description is too short");
    }

    global.__crs_stage = 0;
    return _st;
}

/// ============================================================================================
/// THE HEADLESS ENTRY POINT
/// ============================================================================================

/// Called from the demo object's Create event when the game is launched with `-selftest`.
///
/// ⛔ THE CRASH HANDLER IS THE FIRST THING INSTALLED, BEFORE ANY TEST RUNS. Without it a GML
/// runtime error opens a modal dialog that nobody is there to dismiss, the process never exits, and
/// the runner reports a timeout that names nothing. With it, the same failure writes
/// "CRASH at stage 9: <message>" and the game ends.
function crs_selftest_main() {
    global.__crs_stage = 0;
    // The field names below (ran / blocked / passed / total / failed) are the shape
    // Internal_Ops/run_selftest.ps1 reads. They are NOT arbitrary: a crash reports `ran:false` so
    // the runner can tell "the suite failed" from "the suite never got to run", which are different
    // problems with different next steps and look identical in a bare pass count.
    exception_unhandled_handler(function(_ex) {
        var _f = file_text_open_write("crs_selftest.json");
        file_text_write_string(_f, "{\"ran\":false,\"blocked\":true,\"passed\":0,\"total\":0,"
            + "\"failed\":0,\"reason\":\"CRASH at stage " + string(global.__crs_stage) + ": "
            + string_replace_all(string(_ex.message), "\"", "'") + "\"}");
        file_text_close(_f);
        game_end();
        return true;
    });

    var _st = crs_selftest_run();

    var _f = file_text_open_write("crs_selftest.json");
    file_text_write_string(_f, "{\"ran\":true,\"blocked\":false,\"passed\":" + string(_st.pass)
        + ",\"total\":" + string(_st.pass + _st.fail)
        + ",\"failed\":" + string(_st.fail) + ",\"failures\":[");
    for (var _i = 0; _i < array_length(_st.failures); _i++) {
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "\"" + string_replace_all(_st.failures[_i], "\"", "'") + "\"");
    }
    file_text_write_string(_f, "],\"notes\":[");
    for (var _i = 0; _i < array_length(_st.notes); _i++) {
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "\"" + string_replace_all(_st.notes[_i], "\"", "'") + "\"");
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);

    game_end();
}
