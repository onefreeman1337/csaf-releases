{
  "$GMScript": "v1",
  "%Name": "crs_selftest",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_selftest",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}