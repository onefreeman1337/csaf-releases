{
  "$GMScript": "v1",
  "%Name": "crs_ordinaries",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_ordinaries",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}