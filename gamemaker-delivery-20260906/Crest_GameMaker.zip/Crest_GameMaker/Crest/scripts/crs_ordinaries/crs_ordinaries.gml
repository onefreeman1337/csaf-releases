/// ============================================================================================
/// CREST - crs_ordinaries: the fourteen ways a field is divided, drawn UNDER the charge.
///
/// An ordinary is the geometry of the field itself - a band, a cross, a quartering. It is what
/// turns 44 charges into 616 visibly different arms before a tincture is chosen, and it is the
/// cheapest variety in the whole product: the same lion on a bend and on a chevron reads as two
/// different houses.
///
/// -- AUTHORED IN SHIELD SPACE, NOT CHARGE SPACE ------------------------------------------------
/// ⚠️ These are the one part list in the package that is NOT in the charge's unit box. An ordinary
/// belongs to the FIELD, so it is authored in the shield's own [-0.5, 0.5] and placed with
/// crs_place_shieldwise. Mixing the two spaces is the single easiest mistake to make here, and it
/// does not throw - it silently draws a bend at 58% of its size, tucked inside the charge's box.
/// crs_selftest asserts every ordinary reaches the shield edge for exactly that reason.
///
/// -- THEY OVERFLOW ON PURPOSE, AND THE SHIELD CLIPS THEM ---------------------------------------
/// A bend runs corner to corner and a bordure follows the rim, so both are authored PAST the unit
/// box and clipped to the shield's outline by the renderer. That is why nothing here is inside a
/// 0.5 budget and why the extent contract in crs_charges deliberately does not apply to this file:
/// an ordinary that stopped short of the edge would read as a stripe painted on a shield rather
/// than as the shield's own division.
/// ============================================================================================

/// The fourteen. Order is the Readme's order and the panel's picker order.
function crs_ordinary_ids() {
    return ["plain", "fess", "pale", "bend", "bend-sinister", "chevron", "cross", "saltire",
            "chief", "pile", "bordure", "per-pale", "per-fess", "quarterly"];
}

function crs_ordinary_name(_id) {
    switch (_id) {
        case "plain":         return "Plain";
        case "fess":          return "A Fess";
        case "pale":          return "A Pale";
        case "bend":          return "A Bend";
        case "bend-sinister": return "A Bend Sinister";
        case "chevron":       return "A Chevron";
        case "cross":         return "A Cross";
        case "saltire":       return "A Saltire";
        case "chief":         return "A Chief";
        case "pile":          return "A Pile";
        case "bordure":       return "A Bordure";
        case "per-pale":      return "Party per Pale";
        case "per-fess":      return "Party per Fess";
        default:              return "Quarterly";
    }
}

/// Does this ordinary pass BEHIND the charge anchor?
///
/// It matters for the rule of tincture and nothing else in the package uses it: if a bend runs
/// under the charge, the charge is sitting on the BEND's tincture, not on the field's, so that is
/// the pair crs_arms must check. Getting this wrong produces arms that pass every assertion and
/// look muddy - a charge the same class as the band it lies across.
///
/// ⛔ `chief` and `bordure` are FALSE deliberately. A chief is the top strip and a bordure is the
/// rim; a centred charge touches neither, so checking the charge against them would reject legal
/// arms. `pile` IS true - it is a wedge from the chief down through the centre.
function crs_ordinary_under_charge(_id) {
    switch (_id) {
        case "plain": case "chief": case "bordure":
            return false;
        default:
            return true;
    }
}

/// The parts of an ordinary, in SHIELD space. Role CRS_R_ORD throughout - one role, because an
/// ordinary is one tincture by definition, and a two-tone ordinary is a different ordinary.
function crs_ordinary(_id) {
    var _p = [];
    var _w = 0.20;         // the standard third-of-the-field band width, near enough
    var _far = 0.90;       // authored past the edge; the shield clips it

    switch (_id) {

        case "plain": return _p;                                    // the field, undivided

        case "fess":  array_push(_p, crs_rect_fill(-_far, -_w / 2, _far, _w / 2, CRS_R_ORD)); return _p;
        case "pale":  array_push(_p, crs_rect_fill(-_w / 2, -_far, _w / 2, _far, CRS_R_ORD)); return _p;

        case "bend":
            // Dexter chief to sinister base: top-left down to bottom-right.
            array_push(_p, crs_ribbon([[-_far, -_far], [_far, _far]], _w * 0.72, CRS_R_ORD));
            return _p;

        case "bend-sinister":
            array_push(_p, crs_ribbon([[_far, -_far], [-_far, _far]], _w * 0.72, CRS_R_ORD));
            return _p;

        case "chevron":
            // An inverted V with its point in chief. Two bands so the apex is a real mitre rather
            // than a gap - a single polyline ribbon leaves a notch at the turn, which at banner
            // size reads as a broken chevron.
            array_push(_p, crs_ribbon([[-_far, _far], [0.00, -0.16]], _w * 0.72, CRS_R_ORD));
            array_push(_p, crs_ribbon([[0.00, -0.16], [_far, _far]], _w * 0.72, CRS_R_ORD));
            array_push(_p, crs_dot(0.00, -0.16, _w * 0.72, CRS_R_ORD));
            return _p;

        case "cross":
            array_push(_p, crs_rect_fill(-_far, -_w / 2, _far, _w / 2, CRS_R_ORD));
            array_push(_p, crs_rect_fill(-_w / 2, -_far, _w / 2, _far, CRS_R_ORD));
            return _p;

        case "saltire":
            array_push(_p, crs_ribbon([[-_far, -_far], [_far, _far]], _w * 0.62, CRS_R_ORD));
            array_push(_p, crs_ribbon([[_far, -_far], [-_far, _far]], _w * 0.62, CRS_R_ORD));
            return _p;

        case "chief":
            // The top third. Sits ABOVE every charge anchor in crs_shields, which is why
            // crs_ordinary_under_charge reports false for it.
            array_push(_p, crs_rect_fill(-_far, -_far, _far, -0.28, CRS_R_ORD));
            return _p;

        case "pile":
            // A wedge from the chief, narrowing to a point in base.
            array_push(_p, crs_fill([[-0.30, -_far], [0.30, -_far], [0.00, 0.44]], CRS_R_ORD));
            return _p;

        case "bordure": {
            // A band following the rim. Authored as a wide ring the shield clips to its own
            // outline, which is what makes one bordure work for all eight shapes - a per-shape
            // bordure would be eight more shapes to keep in sync with eight outlines.
            var _n = 40;
            var _out = crs_ellipse_pts(0.00, 0.00, _far, _far, _n);
            var _in  = crs_ellipse_pts(0.00, 0.00, 0.42, 0.46, _n);
            array_push(_out, _out[0]);
            array_push(_in, _in[0]);
            array_push(_p, crs_strip(_out, _in, CRS_R_ORD));
            return _p;
        }

        case "per-pale":  array_push(_p, crs_rect_fill(0.00, -_far, _far, _far, CRS_R_ORD)); return _p;
        case "per-fess":  array_push(_p, crs_rect_fill(-_far, 0.00, _far, _far, CRS_R_ORD)); return _p;

        default:
            // quarterly - two opposite quarters in the ordinary's tincture, which is what makes the
            // division read as four rather than as two.
            array_push(_p, crs_rect_fill(-_far, -_far, 0.00, 0.00, CRS_R_ORD));
            array_push(_p, crs_rect_fill(0.00, 0.00, _far, _far, CRS_R_ORD));
            return _p;
    }
}
