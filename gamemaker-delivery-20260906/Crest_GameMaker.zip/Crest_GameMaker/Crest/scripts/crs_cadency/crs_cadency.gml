/// ============================================================================================
/// CREST - crs_cadency: the six marks of difference, and the product's best idea.
///
/// -- WHY THIS FILE IS THE ANSWER TO "WHY NOT JUST USE A FREE HERALDRY GENERATOR" ----------------
/// Free standalone heraldry generators exist, several of them, and they are good. A generator-only
/// product competes with free and loses - that measurement is in this product's Gate 2 evidence and
/// it is the reason Crest ships as a FACTION SYSTEM whose banners are its face.
///
/// This file is where the difference stops being a positioning claim and becomes a mechanic.
///
/// In real heraldry a cadet branch does not invent new arms. It inherits its parent's arms and adds
/// a small MARK OF DIFFERENCE - a label for the eldest son, a crescent for the second, a mullet for
/// the third, and so on. Wired to crs_faction's schism, that means:
///
///     when a faction splits, the splinter keeps the parent's shield, charge, ordinary and
///     tinctures, and adds one mark. The player SEES that the rebels came from the crown
///     before a single line of dialogue explains it.
///
/// No standalone generator can do that, because it requires the faction model underneath - which
/// is exactly the thing this package sells and a picture-maker does not have.
///
/// -- WHERE THE MARK GOES -----------------------------------------------------------------------
/// In chief, centred, small. That position is not decoration: it is above the charge anchor on
/// every shield in crs_shields, so a mark never collides with the charge no matter which of the 44
/// is on the field. crs_selftest asserts that separation rather than trusting this comment.
/// ============================================================================================

/// How far a cadency mark sits above the shield's centre, and how big it is, in SHIELD space.
///
/// ⛔ THESE ARE A CONTRACT WITH crs_shields, NOT STYLING - AND THE FIRST VERSION OF THAT CONTRACT
/// WAS SIMPLY UNSATISFIABLE. It put the mark at y = -0.36 and asserted it cleared the charge; the
/// in-engine suite reported a collision on ALL EIGHT shields, because a full-size charge centred on
/// the fess point of a heater already occupies y = -0.376 upward. There is no height at which a
/// mark clears a full-size charge and still fits on the shield. The geometry says so.
///
/// The answer is the one real heraldry uses: WHEN A HOUSE BEARS A MARK OF DIFFERENCE, ITS CHARGE IS
/// DRAWN SMALLER. crs_charge_anchor applies both parts - the squeeze, and a downward shift for the
/// shields whose anchor sits high (the kite's is at -0.22) - and derives the shift rather than
/// tabulating it, so adding a ninth shield needs no edit here.
///
/// CRS_CAD_LOW is DECLARED and MEASURED: crs_selftest walks all six marks' real geometry and fails
/// if any of them reaches below it. That is what stops a redrawn mark quietly breaking the clearance
/// it is the whole basis of.
#macro CRS_CAD_Y   -0.42
#macro CRS_CAD_R    0.075
#macro CRS_CAD_LOW -0.31
#macro CRS_CAD_SQUEEZE 0.78

/// The six traditional marks, in birth order - which is also the order a schism uses, so the first
/// splinter of a faction is always `label` and the sixth is always `annulet`.
function crs_cadency_ids() {
    return ["label", "crescent", "mullet", "martlet", "annulet", "fleur"];
}

function crs_cadency_name(_id) {
    switch (_id) {
        case "label":    return "a Label";
        case "crescent": return "a Crescent";
        case "mullet":   return "a Mullet";
        case "martlet":  return "a Martlet";
        case "annulet":  return "an Annulet";
        default:         return "a Fleur-de-Lis";
    }
}

/// The mark for the _n-th cadet branch of a house, 0-based. Wraps, because a faction that schisms
/// seven times is unusual but not impossible, and returning undefined at seven would be a crash in
/// a buyer's game a year after they shipped.
function crs_cadency_for_branch(_n) {
    var _ids = crs_cadency_ids();
    return _ids[(_n % array_length(_ids) + array_length(_ids)) % array_length(_ids)];
}

/// The parts of a mark, in SHIELD space, already positioned in chief.
///
/// Every one is a filled mass, for the same reason the whole charge corpus is: these are the
/// smallest things this product draws, so they are the first to dissolve if drawn as strokes.
function crs_cadency(_id) {
    var _p = [];
    var _y = CRS_CAD_Y;
    var _r = CRS_CAD_R;

    switch (_id) {

        case "label": {
            // A horizontal bar with three pendant points. The eldest son's mark, and the only one
            // that is wider than it is tall - which is how it reads at a glance against the others.
            array_push(_p, crs_rect_fill(-_r * 2.1, _y - _r * 0.34, _r * 2.1, _y + _r * 0.06, CRS_R_DETAIL));
            for (var _i = 0; _i < 3; _i++) {
                var _x = -_r * 1.4 + _i * _r * 1.4;
                array_push(_p, crs_rect_fill(_x - _r * 0.30, _y + _r * 0.06, _x + _r * 0.30,
                                             _y + _r * 0.86, CRS_R_DETAIL));
            }
            return _p;
        }

        case "crescent":
            // Horns up, exactly as the charge of the same name - a bite taken out of a disc, so it
            // is a mass rather than an arc.
            array_push(_p, crs_dot(0.00, _y + _r * 0.10, _r, CRS_R_DETAIL));
            array_push(_p, crs_dot(0.00, _y + _r * 0.52, _r * 0.94, CRS_R_FIELD));
            array_push(_p, crs_c_spike(-_r * 0.86, _y + _r * 0.04, -_r * 0.72, _y - _r * 0.78,
                                       _r * 0.20, CRS_R_DETAIL));
            array_push(_p, crs_c_spike(_r * 0.86, _y + _r * 0.04, _r * 0.72, _y - _r * 0.78,
                                       _r * 0.20, CRS_R_DETAIL));
            return _p;

        case "mullet":
            for (var _i = 0; _i < 5; _i++) {
                var _a = pi * 1.5 + _i / 5 * CRS_TAU;
                array_push(_p, crs_c_spike(cos(_a) * _r * 0.24, _y + sin(_a) * _r * 0.24,
                                           cos(_a) * _r, _y + sin(_a) * _r, _r * 0.34, CRS_R_DETAIL));
            }
            array_push(_p, crs_dot(0.00, _y, _r * 0.40, CRS_R_DETAIL));
            return _p;

        case "martlet":
            // A footless bird - the fourth son's mark, and traditionally footless because a fourth
            // son had no land to stand on. The heraldry is the joke; the silhouette is a wedge with
            // a tail, which is what makes it distinct at this size.
            array_push(_p, crs_fill([[-_r * 0.20, _y - _r * 0.70], [_r * 0.90, _y - _r * 0.10],
                                     [_r * 0.30, _y + _r * 0.70], [-_r * 0.60, _y + _r * 0.20]],
                                    CRS_R_DETAIL));
            array_push(_p, crs_c_spike(-_r * 0.50, _y - _r * 0.30, -_r * 1.10, _y - _r * 0.44,
                                       _r * 0.22, CRS_R_DETAIL));
            return _p;

        case "annulet": {
            // A plain ring, drawn as a strip between two circles rather than as a stroked circle -
            // GameMaker's circle outline ignores line width, and this is the smallest ring in the
            // package.
            var _n = 28;
            var _o = crs_ellipse_pts(0.00, _y, _r, _r, _n);
            var _i2 = crs_ellipse_pts(0.00, _y, _r * 0.58, _r * 0.58, _n);
            array_push(_o, _o[0]);
            array_push(_i2, _i2[0]);
            array_push(_p, crs_strip(_o, _i2, CRS_R_DETAIL));
            return _p;
        }

        default: {
            // fleur - the same three facts as the `lily` charge, at a sixth of the size: the side
            // lobes' tips HANG DOWN, they are filled masses, and there is a band with a tail. It is
            // written out here rather than scaled from crs_ch_lily because a lily at this size needs
            // fewer parts, not smaller ones.
            array_push(_p, crs_fill([[0.00, _y - _r], [_r * 0.26, _y - _r * 0.10],
                                     [-_r * 0.26, _y - _r * 0.10]], CRS_R_DETAIL));
            for (var _s = 0; _s < 2; _s++) {
                var _dx = (_s == 0) ? -1 : 1;
                array_push(_p, crs_fill([[_dx * _r * 0.16, _y - _r * 0.14],
                                         [_dx * _r * 0.72, _y - _r * 0.40],
                                         [_dx * _r * 0.86, _y + _r * 0.22]], CRS_R_DETAIL));
            }
            array_push(_p, crs_rect_fill(-_r * 0.66, _y + _r * 0.10, _r * 0.66, _y + _r * 0.38,
                                         CRS_R_DETAIL));
            array_push(_p, crs_rect_fill(-_r * 0.22, _y + _r * 0.38, _r * 0.22, _y + _r * 1.00,
                                         CRS_R_DETAIL));
            return _p;
        }
    }
}

/// The lowest point any cadency mark reaches, in shield space. Used by crs_selftest to prove the
/// mark never overlaps the charge - a number derived from the geometry, not asserted about it.
function crs_cadency_lowest() {
    var _ids = crs_cadency_ids();
    var _low = -999999;
    for (var _k = 0; _k < array_length(_ids); _k++) {
        var _parts = crs_cadency(_ids[_k]);
        for (var _i = 0; _i < array_length(_parts); _i++) {
            var _q = _parts[_i];
            switch (_q.kind) {
                case CRS_DOT: case CRS_ARC:
                    _low = max(_low, _q.cy + _q.r);
                    break;
                case CRS_STRIP:
                    for (var _j = 0; _j < array_length(_q.a); _j++) _low = max(_low, _q.a[_j][1]);
                    for (var _j = 0; _j < array_length(_q.b); _j++) _low = max(_low, _q.b[_j][1]);
                    break;
                default:
                    for (var _j = 0; _j < array_length(_q.pts); _j++) _low = max(_low, _q.pts[_j][1]);
                    break;
            }
        }
    }
    return _low;
}
