{
  "$GMScript": "v1",
  "%Name": "crs_cadency",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_cadency",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}