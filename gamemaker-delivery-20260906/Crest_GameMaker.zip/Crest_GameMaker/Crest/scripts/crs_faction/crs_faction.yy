{
  "$GMScript": "v1",
  "%Name": "crs_faction",
  "isCompatibility": false,
  "isDnD": false,
  "name": "crs_faction",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}