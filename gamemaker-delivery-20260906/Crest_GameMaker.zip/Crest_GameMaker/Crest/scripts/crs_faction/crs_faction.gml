/// ============================================================================================
/// CREST - crs_faction: the system the banners are the face of.
///
/// -- WHY THIS FILE EXISTS AT ALL ---------------------------------------------------------------
/// Free standalone heraldry generators exist and they are good. A product that only made pictures
/// would be competing with free. What is NOT free is the layer underneath: a reputation model with
/// tiers, a relation matrix so a gain with one house is a loss with its rivals, gates so content
/// code never reads a raw number, and a schism that produces a NEW faction whose arms visibly
/// descend from its parent's.
///
/// A reputation number that only ever moves alone is a variable. One that propagates is a political
/// model, and that is the difference this file is.
///
/// -- STATE LIVES IN ONE GLOBAL, NAMESPACED --------------------------------------------------
/// GML's global namespace is flat and a collision inside a buyer's project is a support ticket
/// nobody can debug remotely, so everything is under `global.__crs`. Nothing else in this package
/// writes it and no name here is shorter than `crs_`.
/// ============================================================================================

/// Standing runs -100 to +100. Chosen rather than 0..1 because designers type these numbers into
/// event code by hand, and "+15 with the Guild" is a sentence a person can hold in their head.
#macro CRS_STANDING_MIN -100
#macro CRS_STANDING_MAX  100

/// How far a change spills to a faction's rivals and allies, as a fraction of the original delta.
/// Defaults, overridable per call and globally.
#macro CRS_SPILL_RIVAL 0.50
#macro CRS_SPILL_ALLY  0.25

/// Create the registry if it does not exist. Every public function calls this, so a buyer never has
/// to remember an init step - a package whose first call must be an init is a package whose issue
/// tracker is full of "nothing happens".
function crs_faction_init() {
    if (!variable_global_exists("__crs")) {
        global.__crs = {
            f: {},              // id -> faction struct
            order: [],          // registration order, so iteration is stable
            tiers: {},          // tier id -> display name, buyer-renameable
            spill_rival: CRS_SPILL_RIVAL,
            spill_ally:  CRS_SPILL_ALLY
        };
        var _t = crs_tier_ids();
        for (var _i = 0; _i < array_length(_t); _i++) {
            variable_struct_set(global.__crs.tiers, _t[_i], crs_tier_default_name(_t[_i]));
        }
    }
    return global.__crs;
}

/// Wipe everything. Exposed because a buyer's "new game" needs it, and because a test suite that
/// cannot reset is a test suite whose cases depend on each other.
///
/// ⚠️ IT REBUILDS THE STRUCT RATHER THAN CLEARING THE GLOBAL. The obvious version -
/// `variable_global_set("__crs", undefined)` then re-init - does NOT work: setting a global to
/// undefined leaves it EXISTING, so crs_faction_init's `variable_global_exists` guard sees it,
/// declines to rebuild, and every call after the reset dereferences undefined. That is a crash in
/// a buyer's "new game" path, which is the one path every player takes.
function crs_faction_reset() {
    crs_faction_init();
    global.__crs.f = {};
    global.__crs.order = [];
    global.__crs.tiers = {};
    global.__crs.spill_rival = CRS_SPILL_RIVAL;
    global.__crs.spill_ally = CRS_SPILL_ALLY;
    var _t = crs_tier_ids();
    for (var _i = 0; _i < array_length(_t); _i++) {
        variable_struct_set(global.__crs.tiers, _t[_i], crs_tier_default_name(_t[_i]));
    }
    return global.__crs;
}

/// ============================================================================================
/// TIERS
/// ============================================================================================

/// The six standing tiers, worst to best.
function crs_tier_ids() {
    return ["hated", "hostile", "neutral", "friendly", "honoured", "exalted"];
}

function crs_tier_default_name(_t) {
    switch (_t) {
        case "hated":    return "Hated";
        case "hostile":  return "Hostile";
        case "neutral":  return "Neutral";
        case "friendly": return "Friendly";
        case "honoured": return "Honoured";
        default:         return "Exalted";
    }
}

/// The tier a raw standing value falls in. THE single place the thresholds live.
function crs_tier_of_value(_v) {
    if (_v <= -60) return "hated";
    if (_v <= -20) return "hostile";
    if (_v <   20) return "neutral";
    if (_v <   60) return "friendly";
    if (_v <   90) return "honoured";
    return "exalted";
}

/// Rank of a tier, 0 (hated) to 5 (exalted). Comparisons between tiers go through this rather than
/// through string equality, so `crs_gate(id, "friendly")` means "friendly OR BETTER" - which is what
/// a designer means every single time.
function crs_tier_rank(_t) {
    var _ids = crs_tier_ids();
    for (var _i = 0; _i < array_length(_ids); _i++) if (_ids[_i] == _t) return _i;
    return -1;
}

/// The display name of a tier. Buyer-renameable, because "Exalted" belongs to somebody else's game.
function crs_tier_name(_t) {
    crs_faction_init();
    if (variable_struct_exists(global.__crs.tiers, _t)) {
        return variable_struct_get(global.__crs.tiers, _t);
    }
    return crs_tier_default_name(_t);
}

function crs_tier_rename(_t, _name) {
    crs_faction_init();
    variable_struct_set(global.__crs.tiers, _t, _name);
}

/// ============================================================================================
/// THE REGISTRY
/// ============================================================================================

/// Register a faction. Its arms are derived here, once, and cached on the struct - deriving them
/// per frame would be correct and wasteful, and deriving them per draw is how a "why is my game
/// slow" thread starts.
///
/// _traits is an optional array of plain words (crs_trait_words() lists the vocabulary).
function crs_faction_add(_id, _name, _traits) {
    var _g = crs_faction_init();
    if (variable_struct_exists(_g.f, _id)) return variable_struct_get(_g.f, _id);

    // ⛔ REFUSED AT REGISTRATION, NOT AT SAVE TIME. The save format is delimited, so an id
    // containing one of its delimiters would produce a string that round-trips into a DIFFERENT
    // world - silently, and only for the buyer who happened to name a faction "house|stark". The
    // failure would surface hours later as a corrupt save with no way back. Failing here means they
    // find it the first time they run the line.
    if (string_pos("|", _id) > 0 || string_pos(";", _id) > 0
     || string_pos(",", _id) > 0 || string_pos(">", _id) > 0) {
        show_error("Crest: faction id \"" + string(_id)
            + "\" contains one of  |  ;  ,  >  which the save format reserves. "
            + "Use letters, digits, dashes or underscores.", true);
    }

    var _f = {
        id:       _id,
        name:     is_undefined(_name) ? _id : _name,
        traits:   is_undefined(_traits) ? [] : _traits,
        standing: 0,
        arms:     crs_arms_derive(_id, _traits),
        rel:      {},           // other id -> "ally" | "rival"
        parent:   "",
        branches: 0,
        merged:   ""            // set when this faction is absorbed by another
    };
    variable_struct_set(_g.f, _id, _f);
    array_push(_g.order, _id);
    return _f;
}

function crs_faction_exists(_id) {
    var _g = crs_faction_init();
    return variable_struct_exists(_g.f, _id);
}

/// The faction struct, or undefined. Undefined rather than a crash: a buyer's event code will ask
/// about a faction that has not been registered yet, and taking down their game for it is a worse
/// answer than letting them check.
function crs_faction_get(_id) {
    var _g = crs_faction_init();
    if (!variable_struct_exists(_g.f, _id)) return undefined;
    return variable_struct_get(_g.f, _id);
}

/// Every registered id, in registration order. LIVE ones only - a faction absorbed by a merge is
/// still in the registry (its standing is still readable, its history still resolves) but it is no
/// longer a player in the world, and a panel that lists it alongside the living is wrong.
function crs_faction_ids() {
    var _g = crs_faction_init();
    var _out = [];
    for (var _i = 0; _i < array_length(_g.order); _i++) {
        var _f = variable_struct_get(_g.f, _g.order[_i]);
        if (_f.merged == "") array_push(_out, _f.id);
    }
    return _out;
}

/// Every id including absorbed ones. Save/load uses this; a panel should not.
function crs_faction_ids_all() {
    var _g = crs_faction_init();
    return variable_clone(_g.order);
}

function crs_faction_count() {
    return array_length(crs_faction_ids());
}

/// The arms of a faction, or undefined.
function crs_faction_arms(_id) {
    var _f = crs_faction_get(_id);
    return is_undefined(_f) ? undefined : _f.arms;
}

/// ============================================================================================
/// STANDING
/// ============================================================================================

function crs_standing(_id) {
    var _f = crs_faction_get(_id);
    return is_undefined(_f) ? 0 : _f.standing;
}

function crs_standing_set(_id, _v) {
    var _f = crs_faction_get(_id);
    if (is_undefined(_f)) return 0;
    _f.standing = clamp(_v, CRS_STANDING_MIN, CRS_STANDING_MAX);
    return _f.standing;
}

function crs_tier(_id) {
    return crs_tier_of_value(crs_standing(_id));
}

/// Change a faction's standing, and let it SPILL to that faction's rivals and allies.
///
/// ⛔ ONE HOP, DELIBERATELY, AND THIS IS THE MOST IMPORTANT DECISION IN THE FILE. Spill does not
/// cascade: helping A hurts A's rivals and helps A's allies, and stops. Letting it propagate
/// transitively is the obvious "more realistic" version and it is unshippable - in any densely
/// connected world it either oscillates or drives every faction to a rail, and it makes a single
/// +5 quest reward an unbounded computation whose result a designer cannot predict or test. A
/// designer who wants a second hop can call this again with the ids they mean, which is a decision
/// they can see in their own code.
///
/// Returns a struct: { direct, spilled } where `spilled` is an array of [id, delta] actually
/// applied - so a buyer can print "The Guild is displeased" without re-deriving who was affected.
function crs_standing_add(_id, _delta, _spill) {
    var _g = crs_faction_init();
    var _f = crs_faction_get(_id);
    if (is_undefined(_f)) return { direct: 0, spilled: [] };

    var _do_spill = is_undefined(_spill) ? true : _spill;
    var _before = _f.standing;
    _f.standing = clamp(_f.standing + _delta, CRS_STANDING_MIN, CRS_STANDING_MAX);
    var _direct = _f.standing - _before;

    var _out = [];
    if (_do_spill) {
        var _others = variable_struct_get_names(_f.rel);
        for (var _i = 0; _i < array_length(_others); _i++) {
            var _oid = _others[_i];
            var _o = crs_faction_get(_oid);
            if (is_undefined(_o) || _o.merged != "") continue;
            var _kind = variable_struct_get(_f.rel, _oid);
            var _k = (_kind == "rival") ? -_g.spill_rival : _g.spill_ally;
            if (_kind != "rival" && _kind != "ally") continue;
            var _d = _delta * _k;
            // A spill that rounds to nothing is not applied AND not reported. Reporting a zero
            // would put "The Guild is displeased" on screen for a change that did not happen.
            if (abs(_d) < 0.5) continue;
            var _b2 = _o.standing;
            _o.standing = clamp(_o.standing + _d, CRS_STANDING_MIN, CRS_STANDING_MAX);
            if (_o.standing != _b2) array_push(_out, [_oid, _o.standing - _b2]);
        }
    }
    return { direct: _direct, spilled: _out };
}

/// Set the spill fractions globally. Rival spill is negative in effect, not in sign - pass 0.5.
function crs_spill_set(_rival, _ally) {
    var _g = crs_faction_init();
    _g.spill_rival = _rival;
    _g.spill_ally = _ally;
}

/// ============================================================================================
/// RELATIONS
/// ============================================================================================

/// Declare a relation. SYMMETRIC, both directions written, because a one-way rivalry is almost
/// always a bug rather than a design - and when it is a design, a buyer can write the two calls
/// themselves with crs_relation_set_oneway.
function crs_relation_set(_a, _b, _kind) {
    var _fa = crs_faction_get(_a), _fb = crs_faction_get(_b);
    if (is_undefined(_fa) || is_undefined(_fb) || _a == _b) return false;
    crs_relation_set_oneway(_a, _b, _kind);
    crs_relation_set_oneway(_b, _a, _kind);
    return true;
}

function crs_relation_set_oneway(_a, _b, _kind) {
    var _fa = crs_faction_get(_a);
    if (is_undefined(_fa)) return false;
    if (_kind == "neutral" || _kind == "") {
        if (variable_struct_exists(_fa.rel, _b)) variable_struct_remove(_fa.rel, _b);
    } else {
        variable_struct_set(_fa.rel, _b, _kind);
    }
    return true;
}

/// "ally", "rival" or "neutral".
function crs_relation(_a, _b) {
    var _fa = crs_faction_get(_a);
    if (is_undefined(_fa)) return "neutral";
    if (!variable_struct_exists(_fa.rel, _b)) return "neutral";
    return variable_struct_get(_fa.rel, _b);
}

/// Every declared relation of a faction, as an array of [id, kind]. Feeds the panel's relation row.
function crs_relations_of(_id) {
    var _f = crs_faction_get(_id);
    if (is_undefined(_f)) return [];
    var _names = variable_struct_get_names(_f.rel);
    var _out = [];
    for (var _i = 0; _i < array_length(_names); _i++) {
        var _o = crs_faction_get(_names[_i]);
        if (is_undefined(_o) || _o.merged != "") continue;
        array_push(_out, [_names[_i], variable_struct_get(_f.rel, _names[_i])]);
    }
    return _out;
}

/// ============================================================================================
/// GATES - so a buyer's content code never reads a raw number
/// ============================================================================================

/// Is this faction at _minTier or better? "friendly" means friendly OR BETTER, every time.
function crs_gate(_id, _minTier) {
    var _have = crs_tier_rank(crs_tier(_id));
    var _need = crs_tier_rank(_minTier);
    if (_need < 0) return false;
    return (_have >= _need);
}

/// The price a faction charges, as a multiplier on a base price. The gate that answers a NUMBER
/// rather than a boolean, because "do they let me in" and "what do they charge" are the two
/// questions a reputation system is actually asked, and only one of them is a door.
///
/// Exalted 0.80 to hated 1.60, and hated is deliberately not "refuses to trade" - a shop that
/// closes is content the player cannot reach, and a designer who wants that can gate it with
/// crs_gate. This function's job is the smooth part.
function crs_price_mult(_id) {
    switch (crs_tier(_id)) {
        case "hated":    return 1.60;
        case "hostile":  return 1.30;
        case "neutral":  return 1.00;
        case "friendly": return 0.94;
        case "honoured": return 0.88;
        default:         return 0.80;
    }
}

/// A greeting line keyed to tier. Six strings a designer will replace, and that is fine: the point
/// is that the wiring already exists on day one, so the system is demonstrably working in their
/// game before they have written any content for it.
function crs_greeting(_id) {
    var _f = crs_faction_get(_id);
    var _n = is_undefined(_f) ? "they" : _f.name;
    switch (crs_tier(_id)) {
        case "hated":    return "You are not welcome in " + _n + ".";
        case "hostile":  return _n + " watches you, and says nothing.";
        case "neutral":  return _n + " has no quarrel with you.";
        case "friendly": return _n + " greets you warmly.";
        case "honoured": return _n + " names you a friend of the house.";
        default:         return _n + " opens every door to you.";
    }
}

/// ============================================================================================
/// SCHISM AND MERGE - where the arms follow the history
/// ============================================================================================

/// Split a faction. The splinter INHERITS its parent's arms and adds the next mark of cadency, so
/// the player sees where it came from before anyone explains it.
///
/// Standing carries over at a fraction: people who liked the crown do not automatically like the
/// rebels, but they do not start from nothing either. 0.5 by default, and a caller who wants a
/// clean break passes 0.
function crs_faction_schism(_parentId, _newId, _newName, _carry) {
    var _p = crs_faction_get(_parentId);
    if (is_undefined(_p)) return undefined;
    if (crs_faction_exists(_newId)) return crs_faction_get(_newId);

    var _f = crs_faction_add(_newId, _newName, _p.traits);
    _f.arms = crs_arms_cadet(_p.arms, _parentId, _p.branches);
    _f.parent = _parentId;
    _p.branches += 1;

    var _c = is_undefined(_carry) ? 0.5 : _carry;
    _f.standing = clamp(_p.standing * _c, CRS_STANDING_MIN, CRS_STANDING_MAX);

    // A splinter and its parent are rivals by default. That is the whole reason a schism happened,
    // and it means the spill model starts doing something interesting the moment one occurs.
    crs_relation_set(_parentId, _newId, "rival");
    return _f;
}

/// Absorb _fromId into _intoId. The absorbed faction stays in the registry - its standing is still
/// readable and any save that references it still loads - but it drops out of crs_faction_ids().
///
/// Standing is combined by WEIGHTED AVERAGE, not by addition: two factions the player is friendly
/// with should not merge into one the player is exalted with. Addition is the obvious version and
/// it is a reputation exploit a player finds in an afternoon.
function crs_faction_merge(_intoId, _fromId) {
    var _a = crs_faction_get(_intoId), _b = crs_faction_get(_fromId);
    if (is_undefined(_a) || is_undefined(_b) || _intoId == _fromId) return false;
    if (_b.merged != "") return false;

    _a.standing = clamp((_a.standing + _b.standing) * 0.5, CRS_STANDING_MIN, CRS_STANDING_MAX);

    // The absorbed faction's relations transfer, except any with the absorber itself.
    var _names = variable_struct_get_names(_b.rel);
    for (var _i = 0; _i < array_length(_names); _i++) {
        if (_names[_i] == _intoId) continue;
        if (!variable_struct_exists(_a.rel, _names[_i])) {
            crs_relation_set(_intoId, _names[_i], variable_struct_get(_b.rel, _names[_i]));
        }
    }
    crs_relation_set_oneway(_intoId, _fromId, "neutral");
    crs_relation_set_oneway(_fromId, _intoId, "neutral");
    _b.merged = _intoId;
    return true;
}

/// The chain of descent: this faction, its parent, its parent's parent. Feeds the panel's
/// "descended from" line and proves the cadency mark is not decoration.
function crs_faction_lineage(_id) {
    var _out = [];
    var _cur = _id;
    var _guard = 0;
    // A cycle here would hang a buyer's game on a draw call. It cannot happen through the public
    // API - a schism always creates a NEW id - but a hand-edited save could, so the walk is bounded.
    while (_cur != "" && _guard < 64) {
        array_push(_out, _cur);
        var _f = crs_faction_get(_cur);
        if (is_undefined(_f)) break;
        _cur = _f.parent;
        _guard++;
    }
    return _out;
}

/// ============================================================================================
/// SAVE AND LOAD
/// ============================================================================================

/// The save format version. Bump it when the field list changes; crs_load_string refuses anything
/// it does not recognise rather than reading a v1 save as a v2 one and getting silent nonsense.
#macro CRS_SAVE_VERSION 1

/// Serialise the whole standing model to one string.
///
/// Only what CHANGES is saved: standing, relations, lineage, merges. Arms are DERIVED from the id
/// and the traits, so they are not in the save at all - which means a buyer can re-tune a tincture
/// or redraw a charge in an update and every existing save picks up the new art with no migration.
/// That is the practical payoff of deriving instead of storing, and it is worth the paragraph.
function crs_save_string() {
    var _g = crs_faction_init();
    var _ids = crs_faction_ids_all();
    var _s = "CRS" + string(CRS_SAVE_VERSION) + "|" + string(array_length(_ids));
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _f = variable_struct_get(_g.f, _ids[_i]);
        var _rel = "";
        var _names = variable_struct_get_names(_f.rel);
        for (var _k = 0; _k < array_length(_names); _k++) {
            if (_rel != "") _rel += ",";
            _rel += _names[_k] + ">" + variable_struct_get(_f.rel, _names[_k]);
        }
        _s += "|" + _f.id + ";" + string(_f.standing) + ";" + _f.parent + ";"
            + string(_f.branches) + ";" + _f.merged + ";" + _rel;
    }
    return _s;
}

/// Restore from a string.
///
/// ⛔ IT PARSES EVERYTHING BEFORE IT WRITES ANYTHING, AND REFUSES A MISMATCHED REGISTRY. Applying
/// as it goes is the obvious way and it is the one that loses a player's game: a save naming a
/// faction this build no longer registers would leave the world half-restored, with the first half
/// of the factions at their saved standing and the rest at zero, and no error anywhere. So the
/// whole string is validated first and either all of it lands or none of it does.
///
/// Returns "" on success, or a human-readable reason.
function crs_load_string(_s) {
    if (!is_string(_s) || _s == "") return "empty save string";
    var _parts = string_split(_s, "|");
    if (array_length(_parts) < 2) return "not a Crest save";
    if (_parts[0] != "CRS" + string(CRS_SAVE_VERSION)) {
        return "save version \"" + string(_parts[0]) + "\" is not CRS" + string(CRS_SAVE_VERSION);
    }
    var _n = real(_parts[1]);
    if (array_length(_parts) - 2 != _n) {
        return "save says " + string(_n) + " factions but carries " + string(array_length(_parts) - 2);
    }

    // -- pass one: parse and validate. Nothing is written in this loop. -------------------------
    var _staged = [];
    for (var _i = 0; _i < _n; _i++) {
        // ⛔ NO `remove_empty` ARGUMENT. string_split's third parameter drops empty fields, and this
        // format is POSITIONAL: a faction with no parent and no merge - which is most of them - has
        // two empty fields in the middle, so removing them shifts `merged` into `parent` and the
        // row silently parses as something else entirely. It would have restored a working-looking
        // world with the lineage wrong.
        var _row = string_split(_parts[_i + 2], ";");
        if (array_length(_row) < 5) return "row " + string(_i) + " is malformed";
        var _id = _row[0];
        if (!crs_faction_exists(_id)) {
            return "save names faction \"" + _id + "\", which this build does not register";
        }
        array_push(_staged, {
            id: _id, standing: real(_row[1]), parent: _row[2],
            branches: real(_row[3]), merged: _row[4],
            rel: (array_length(_row) > 5) ? _row[5] : ""
        });
    }

    // -- pass two: commit. Every id was proven to exist above, so nothing here can fail. --------
    for (var _i = 0; _i < array_length(_staged); _i++) {
        var _r = _staged[_i];
        var _f = crs_faction_get(_r.id);
        _f.standing = clamp(_r.standing, CRS_STANDING_MIN, CRS_STANDING_MAX);
        _f.parent = _r.parent;
        _f.branches = _r.branches;
        _f.merged = _r.merged;
        _f.rel = {};
        if (_r.rel != "") {
            var _pairs = string_split(_r.rel, ",");
            for (var _k = 0; _k < array_length(_pairs); _k++) {
                var _kv = string_split(_pairs[_k], ">");
                if (array_length(_kv) == 2) variable_struct_set(_f.rel, _kv[0], _kv[1]);
            }
        }
        // A cadet faction's arms depend on its parent and branch index, both of which have just
        // been restored, so they are re-derived here rather than saved. Same argument as above.
        if (_f.parent != "" && crs_faction_exists(_f.parent)) {
            var _p = crs_faction_get(_f.parent);
            var _branch = 0;
            var _all = crs_faction_ids_all();
            for (var _m = 0; _m < array_length(_all); _m++) {
                if (_all[_m] == _f.id) break;
                var _o = crs_faction_get(_all[_m]);
                if (!is_undefined(_o) && _o.parent == _f.parent) _branch++;
            }
            _f.arms = crs_arms_cadet(_p.arms, _f.parent, _branch);
        }
    }
    return "";
}
