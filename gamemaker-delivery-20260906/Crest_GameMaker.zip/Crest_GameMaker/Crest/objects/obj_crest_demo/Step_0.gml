/// CREST demo - input.
///
/// Everything here goes through the PUBLIC api, deliberately. A demo that reaches into the
/// registry's internals to make something happen is a demo that does not show a buyer how to make
/// it happen in their own game.

gui_w = display_get_gui_width();
gui_h = display_get_gui_height();
if (flash > 0) flash -= 1;

var _panelW = min(gui_w * 0.40, 470);
var _panelX = gui_w * 0.055;
var _panelY = gui_h * 0.13;

/* -- select a house -------------------------------------------------------------------------- */
if (mouse_check_button_pressed(mb_left)) {
    var _hit = crs_panel_hit(device_mouse_x_to_gui(0), device_mouse_y_to_gui(0),
                             _panelX, _panelY, _panelW);
    if (_hit != "") {
        selected = _hit;
        var _f = crs_faction_get(selected);
        last_event = crs_greeting(selected);
        flash = 40;
    }
}

var _ids = crs_faction_ids();
if (keyboard_check_pressed(vk_down) || keyboard_check_pressed(vk_up)) {
    var _at = 0;
    for (var _i = 0; _i < array_length(_ids); _i++) if (_ids[_i] == selected) _at = _i;
    _at += keyboard_check_pressed(vk_down) ? 1 : -1;
    _at = (_at + array_length(_ids)) % array_length(_ids);
    selected = _ids[_at];
    flash = 20;
}

/* -- move standing, and WATCH IT SPILL ------------------------------------------------------- */
// The whole argument for this being a system rather than a variable is visible in three keypresses:
// help one house and its rivals lose, its allies gain, and every bar on the panel moves at once.
if (keyboard_check_pressed(vk_right) || keyboard_check_pressed(vk_left)) {
    var _d = keyboard_check_pressed(vk_right) ? 12 : -12;
    var _res = crs_standing_add(selected, _d, true);
    var _f = crs_faction_get(selected);
    last_event = _f.name + " " + ((_d > 0) ? "+" : "") + string(round(_res.direct));
    for (var _i = 0; _i < array_length(_res.spilled); _i++) {
        var _o = crs_faction_get(_res.spilled[_i][0]);
        if (is_undefined(_o)) continue;
        last_event += "   " + _o.name + " "
            + ((_res.spilled[_i][1] > 0) ? "+" : "") + string(round(_res.spilled[_i][1]));
    }
    flash = 40;
}

/* -- SCHISM: the product's best idea, on one key ---------------------------------------------- */
// The splinter inherits its parent's arms and adds a mark of cadency, so the relationship is
// visible on the banner before any dialogue explains it.
if (keyboard_check_pressed(ord("S"))) {
    var _p = crs_faction_get(selected);
    var _newId = selected + "_cadet" + string(_p.branches);
    var _names = ["The Dissent", "The Broken Oath", "The Second House",
                  "The Lesser Seat", "The Exiles", "The Remnant"];
    var _new = crs_faction_schism(selected, _newId,
                                  _p.name + " - " + _names[_p.branches % array_length(_names)], 0.5);
    if (!is_undefined(_new)) {
        last_event = _new.name + " breaks away, bearing " + crs_cadency_name(_new.arms.cadency)
            + " on its father's arms.";
        selected = _newId;
        flash = 60;
    }
}

/* -- reset ------------------------------------------------------------------------------------ */
if (keyboard_check_pressed(ord("R"))) {
    event_perform(ev_create, 0);
}
