/// CREST demo - Draw GUI.
///
/// Draw GUI rather than Draw, so the demo is resolution-independent and the same code produces the
/// same layout on the store sheet, in the GIF and in a buyer's window.

var _panelW = min(gui_w * 0.40, 470);
var _panelX = gui_w * 0.055;
var _panelY = gui_h * 0.13;

var _detailW = min(gui_w * 0.32, 380);
var _detailX = gui_w - _detailW - gui_w * 0.055;
var _detailY = _panelY;

/* -- the title ------------------------------------------------------------------------------- */
draw_set_font(crs_font_title());
draw_set_halign(fa_left);
draw_set_valign(fa_middle);
draw_set_colour(crs_ui_colour("ink"));
draw_text_transformed(_panelX, gui_h * 0.062, "CREST", gui_w / 900, gui_w / 900, 0);

draw_set_font(crs_font());
draw_set_colour(crs_ui_colour("ink2"));
draw_text_transformed(_panelX + gui_w * 0.085, gui_h * 0.066,
    "faction, reputation and composed heraldry", gui_w / 1500, gui_w / 1500, 0);

/* -- the two panels -------------------------------------------------------------------------- */
crs_panel_draw(_panelX, _panelY, _panelW, selected);
crs_panel_detail(selected, _detailX, _detailY, _detailW);

/* -- the event line -------------------------------------------------------------------------- */
// It flashes gold on a change and settles to grey, so a reader's eye is taken to the thing that
// just happened rather than to a line of text that is always there.
var _t = flash / 60;
draw_set_colour(merge_colour(crs_ui_colour("ink2"), crs_ui_colour("gild"), clamp(_t, 0, 1)));
draw_set_font(crs_font());
draw_text_ext_transformed(_panelX, gui_h * 0.915, last_event, gui_h * 0.030,
                          (gui_w - _panelX * 2) * 900 / gui_w, gui_w / 1200, gui_w / 1200, 0);

/* -- the controls, so a buyer who opens the room knows what to press -------------------------- */
draw_set_colour(crs_ui_colour("rule"));
draw_text_transformed(_panelX, gui_h * 0.962,
    "UP / DOWN  select     LEFT / RIGHT  change standing (watch the allies and rivals move)"
    + "     S  schism     R  reset",
    gui_w / 1500, gui_w / 1500, 0);

draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_colour(c_white);
