/// CREST demo - Clean Up.
///
/// Crest allocates no surfaces, no buffers, no data structures and no dynamic resources: the whole
/// package is structs and arrays, which the garbage collector owns. There is deliberately nothing
/// to free here, and this event exists to SAY so - an empty Clean Up event a buyer finds is a
/// question answered before it is asked ("what do I have to tear down?" - nothing).
///
/// The one cache the package keeps, global.__crs_geo in crs_shields, holds clipped ordinary
/// geometry. It is not world state and is not per-instance, so it deliberately outlives this
/// object; clearing it here would only make the next room re-do work whose result is identical.
