/// CREST - the demo room.
///
/// This object is the buyer's quickstart, the GIF source and the only real smoke test this engine
/// offers, all at once. It is also the FIRST thing a buyer opens, so it is written to be read: a
/// dozen lines of setup that show every part of the system working together.
///
/// ⛔ IT IS ALSO THE HEADLESS ENTRY POINT. Two command-line flags divert it before any demo state
/// is built:
///     Crest.exe -selftest   run the in-engine suite, write crs_selftest.json, exit
///     Crest.exe -bake       render the store sheets, write PNGs, exit
///     Crest.exe -gif        render the demo GIF frames, write PNGs, exit
/// All three are driven unattended by Internal_Ops/run_selftest.ps1, run_bake.ps1 and run_gif.ps1.
/// None ships as a feature; they are why this package can be verified at all.

var _mode = "";
for (var _i = 0; _i < parameter_count(); _i++) {
    var _p = string_lower(parameter_string(_i));
    if (_p == "-selftest") _mode = "selftest";
    if (_p == "-bake") _mode = "bake";
    if (_p == "-gif") _mode = "gif";
}
if (_mode == "selftest") { crs_selftest_main(); exit; }
if (_mode == "bake") { crs_bake_main(); exit; }
if (_mode == "gif") { crs_gif_main(); exit; }

/* -- THE DEMO WORLD ---------------------------------------------------------------------------
 * Five houses, registered with nothing but a name and a trait or two. Their arms are DERIVED -
 * there is no art file in this package and no table of who looks like what.
 * ------------------------------------------------------------------------------------------- */
crs_faction_reset();

crs_faction_add("crown",  "The Iron Crown",    ["noble", "martial"]);
crs_faction_add("guild",  "The Salt Guild",    ["merchant", "coastal"]);
crs_faction_add("order",  "The Ashen Order",   ["pious"]);
crs_faction_add("wilds",  "The Thornwilds",    ["wild"]);
crs_faction_add("college","The Grey College",  ["scholar"]);

/* -- and a politics, so the spill model has something to do ---------------------------------- */
crs_relation_set("crown",   "guild",   "ally");
crs_relation_set("crown",   "wilds",   "rival");
crs_relation_set("order",   "college", "rival");
crs_relation_set("guild",   "college", "ally");

crs_standing_set("crown",   35);
crs_standing_set("guild",   62);
crs_standing_set("order",  -18);
crs_standing_set("wilds",  -55);
crs_standing_set("college",  8);

selected = "crown";
last_event = "Five houses registered. Their arms were composed, not chosen.";
flash = 0;

/* -- layout, derived from the window so the demo reads at any size --------------------------- */
gui_w = display_get_gui_width();
gui_h = display_get_gui_height();
