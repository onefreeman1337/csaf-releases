# Crest — Faction, Reputation and Composed Heraldry for GameMaker

**GameMaker 2024.14+ · pure GML · no sprites, no atlas, no texture page.**

Every shield, ordinary, charge, fur and mark of cadency in this package is drawn at run time from
authored geometry. There is no `sprites/` directory, because there is nothing to put in one.

---

## Why this exists

You can already download a free coat-of-arms generator. It gives you a picture. Then you still owe
your game everything that makes a faction a faction: who likes whom, what your standing with them
is, what that unlocks, what happens when one splits in two — and a *new picture*, drawn by hand, for
every house you add after launch.

**Crest is the faction system, and the heraldry is what it looks like.** Register a house with a
name and a trait or two; its arms are *composed* from its identity, not chosen from a list and not
loaded from a file:

```gml
crs_faction_add("guild", "The Salt Guild", ["merchant", "coastal"]);
```

That house now has a banner, a standing, a tier, relations, and a seat in the panel. You drew
nothing.

### The part a generator structurally cannot do

When a house splinters, the cadet branch inherits its parent's arms **unchanged** and adds one mark
of difference — the way real heraldry says "this is the same blood, junior line". The player reads
the relationship off the banner before a line of dialogue explains it.

```gml
crs_faction_schism("crown", "crown_cadet0", "The Iron Crown - The Exiles", 0.5);
```

That works because arms here are a **struct derived from a faction**, not an image. Inheriting them
is a copy and the difference is one field. A generator that hands you a PNG cannot do this at all.

---

## What is in the box

| | count |
| --- | --- |
| **Charges**, hand-authored in six orders — beast 9 · bird 6 · arms 8 · craft 8 · sacred 7 · land 6 | **44** |
| **Shield shapes** — heater, kite, oval, lozenge, banner, pennon, roundel, targe | **8** |
| **Ordinaries and divisions** — fess, pale, bend, chevron, cross, saltire, chief, pile, bordure, per-pale, per-fess, quarterly, bend sinister, plain | **14** |
| **Tinctures** — 2 metals, 5 colours, and the 2 furs **ermine** and **vair**, both drawn as real patterns | **9** |
| **Marks of cadency** — label, crescent, mullet, martlet, annulet, fleur | **6** |

> 44 charges × 8 shields × 14 ordinaries = **4,928 distinct shield layouts** before a single
> tincture is chosen, and before cadency.

Every charge is authored against a **20-pixel silhouette criterion** — it has to still be
identifiable as *that animal, that tool, that symbol* at the size a faction list actually renders
it. The in-engine suite rasterises all 44 and measures the closest pair, so this is a checked
property and not a claim.

---

## The rule of tincture is enforced by construction

Real heraldry forbids metal on metal and colour on colour, because it does not read. Crest never
rolls a combination and retries — it picks the field first, then picks each subsequent tincture
**from the set that is legal against what that element actually sits on**, including the case where
a charge lies across an ordinary rather than on the field.

The suite derives 400 coats of arms and asserts that **none** breaks the rule, then asserts the
predicate itself refuses metal-on-metal and colour-on-colour — because a check that can only ever
say yes is not a check.

---

## Install (2 minutes)

1. In GameMaker: **Tools → Import Local Package**, choose `Crest.yymps`, **Add All**.
2. Open `rm_crest_demo` and press **Run**.

Nothing to configure, no texture group to set up, no sprite to import.

**In the demo:** `↑ ↓` select a house · `← →` move your standing with it · `S` splinter the selected
house into a cadet branch and watch the banner inherit · `R` reset.

---

## The whole integration

```gml
// -- register houses. Traits steer which order of charge they draw from; omit them for any order.
crs_faction_reset();
crs_faction_add("crown", "The Iron Crown", ["noble", "martial"]);
crs_faction_add("guild", "The Salt Guild", ["merchant", "coastal"]);

// -- politics. Standing changes SPILL along these: help an ally, annoy their rival.
crs_relation_set("crown", "guild", "ally");
crs_standing_add("crown", 12);          // spill is applied for you

// -- read it back
crs_standing("crown");                  // -100 .. 100
crs_tier("crown");                      // hated · hostile · neutral · friendly · honoured · exalted
crs_gate("crown", "honoured");          // true once they are at least that tier
crs_price_mult("crown");                // a shop multiplier that follows standing
crs_greeting("crown");                  // tier-appropriate line

// -- draw it
crs_faction_draw("crown", x, y, 64);    // the banner, at any size
crs_panel_draw(px, py, pw, selected);   // the whole faction panel - it derives its own height

// -- persist it
var _s = crs_save_string();             // one string; hand it to your own save
crs_load_string(_s);
```

Three more you will want:

- **`crs_arms_blazon(arms)`** returns the proper heraldic description — field, then ordinary, then
  charge, each with its tincture, and *"differenced by a Crescent"* on a cadet branch. A ready-made
  codex line you did not have to write.
- **`crs_arms_describe(arms)`** is the same thing in plain English, for a game that would rather not
  sound like a herald.
- **`crs_arms_problem(arms)`** tells you *why* a coat of arms is illegal, in one call. It is public
  on purpose: you will hand-write arms for your three story factions and generate the other forty,
  and when the hand-written one looks muddy this answers it instead of leaving you comparing hex.

---

## Determinism

Arms are seeded from the faction's **id**, so `"guild"` composes the same banner on every machine,
every run, and every save. Rename the house freely; change the id and you get a different house.
Nothing is stored in the save file except standing and relations — the artwork is re-derived.

---

## Namespacing

Every function, macro and global in this package is prefixed `crs_` / `CRS_`. GML's global namespace
is flat, and a collision inside your project is a support ticket nobody can debug remotely. Two font
resources (`fnt_crest`, `fnt_crest_title`) and one demo object (`obj_crest_demo`) are the only
non-`crs_` names, and the demo is safe to delete once you have read it.

**Substituting your own font is a one-line edit.** `crs_font()` and `crs_font_title()` in
`crs_render` are the *only* places in the package where a font resource is named.

---

## What it does not do

- It does not draw your UI for you beyond the faction panel — `crs_faction_draw` gives you the
  banner at any size and you put it where you like.
- It has no opinion about your dialogue system. `crs_greeting` returns a string; what you do with
  it is yours.
- It does not do quests. Standing is a number and a tier, and gates read it.

---

## Verification

This package ships with an in-engine self-test — **1,403 assertions** covering the corpus counts,
the 20px silhouette separation, per-shield geometry contracts, the rule of tincture over 400 derived
coats, cadency placement, derivation stability and save/load round-trips. It runs against a real
compiled build, not a mock.

---

Core Systems Asset Factory — Crest v1.0.0
Licence: see `LICENSE.txt`. Third-party font notices: `Crest/fonts/THIRD-PARTY-NOTICES.txt`.
