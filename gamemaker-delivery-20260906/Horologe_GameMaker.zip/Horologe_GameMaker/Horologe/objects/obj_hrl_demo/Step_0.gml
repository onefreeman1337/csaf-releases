/// @description Step - run the machine and take input

if (is_undefined(mach)) exit;

// ⛔ delta_time, NOT A FIXED INCREMENT. delta_time is MICROSECONDS since the last step, so the
// division is by a million. A machine advanced by a constant per step keeps a different time at 30
// fps and at 144 fps, and drops frames as a clock running slow - which is a bug a buyer would
// report as "your clock loses time on my laptop" and would be right about.
hrl_machine_step(mach, (delta_time / 1000000) * rate);

// -- input -------------------------------------------------------------------------------------
var _rebuild = false;

if (keyboard_check_pressed(vk_right)) { kind = (kind + 1) mod HRL_MACHINE_N; _rebuild = true; }
if (keyboard_check_pressed(vk_left))  { kind = (kind + HRL_MACHINE_N - 1) mod HRL_MACHINE_N; _rebuild = true; }
if (keyboard_check_pressed(vk_up))    { material = (material + 1) mod HRL_MATERIAL_N; _rebuild = true; }
if (keyboard_check_pressed(vk_down))  { material = (material + HRL_MATERIAL_N - 1) mod HRL_MATERIAL_N; _rebuild = true; }
if (keyboard_check_pressed(ord("S"))) { seed += 1; _rebuild = true; }
if (keyboard_check_pressed(ord("D"))) { show_dial = !show_dial; }
if (keyboard_check_pressed(ord("L"))) { show_labels = !show_labels; }

// Time control. A mechanism at real speed is the honest default and a slow one is unwatchable at
// a demo's scale, so the speed is a control rather than a constant.
if (keyboard_check_pressed(ord("1"))) rate = 1;
if (keyboard_check_pressed(ord("2"))) rate = 60;
if (keyboard_check_pressed(ord("3"))) rate = 600;

if (_rebuild) {
    var _t = mach.train.t;
    mach = hrl_machine_new(kind, material, seed);
    // Keep the time across a rebuild. A demo that resets the clock every time you press a key
    // makes it impossible to see that two machines at the same moment agree.
    hrl_machine_set(mach, _t);
}
