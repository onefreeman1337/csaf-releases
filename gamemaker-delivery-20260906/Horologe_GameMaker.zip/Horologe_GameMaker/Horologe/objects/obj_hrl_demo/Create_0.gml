/// @description Create

// ⛔ THE FIRST LINE OF ANY HEADLESS ENTRY POINT, AND IT IS NOT OPTIONAL.
// A GML runtime error opens a MODAL DIALOG. Headless, nothing dismisses it and the process never
// exits - a build robot then reports a timeout instead of a defect. Installing a handler that
// records the stage number and ends the game turns an opaque hang into a named line in a result
// file. This wing measured that exact conversion on a previous product: an opaque 180 s hang
// became "CRASH at stage 5: Variable Index [25] out of range [25]", a real bug.
//
// ⛔ AND IT RECORDS THE STACKTRACE, NOT JUST THE MESSAGE. A stage is a whole block calling
// hundreds of functions, so the message alone sends you guessing through the call graph.
//
// ⛔ THIS IS THE ONLY exception_unhandled_handler IN THE PACKAGE. Whichever is installed last
// silently wins, so two handlers is a coin toss over how much you learn from a crash.
global.hrl_stage = -1;
exception_unhandled_handler(function(_ex) {
    var _st = "";
    try {
        var _tr = _ex.stacktrace;
        for (var _i = 0; _i < array_length(_tr); _i++) {
            if (_i > 0) _st += " <- ";
            _st += string(_tr[_i]);
        }
    } catch (_e) { _st = "(no stacktrace)"; }
    var _f = file_text_open_write("hrl_crash.json");
    file_text_write_string(_f, "{\"stage\":" + string(global.hrl_stage)
        + ",\"message\":\"" + string_replace_all(string(_ex.message), "\"", "'") + "\""
        + ",\"where\":\"" + string_replace_all(_st, "\"", "'") + "\"}");
    file_text_close(_f);
    game_end(1);
});

// ⛔ EVERY VARIABLE A LATER EVENT READS IS DECLARED ABOVE THE EARLY EXITS. The headless branches
// below leave Create part way through, and GameMaker fires Clean Up at game end regardless - a
// sibling product in this wing threw "variable not set before reading it" AFTER a fully green
// self-test, and a crash after the work is done still fails the run and still hides the result.
kind = 0;
material = 0;
seed = 1;
show_dial = true;
show_labels = true;
rate = 1;
mach = undefined;
last_read = "";

// -- headless modes: run, write the result file, exit -------------------------------------------
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i + 1) + " ";

if (string_pos("-selftest", _args) > 0) {
    var _r = hrl_selftest_run();
    hrl_selftest_write(_r);
    game_end(0);
    exit;
}

if (string_pos("-bake", _args) > 0) {
    hrl_bake_all();
    game_end(0);
    exit;
}

// -- the interactive demo -----------------------------------------------------------------------
hrl_lamp_reset();
mach = hrl_machine_new(kind, material, seed);

// ⚠️ THE CLOCK STARTS AT A TIME, NOT AT ZERO. A movement at t = 0 has every hand at twelve, which
// is the one configuration where a viewer cannot tell whether the hands are attached to anything.
// Ten past ten is the position every watch advertisement uses, for the same reason.
hrl_machine_set_time(mach, 10, 9, 36);
