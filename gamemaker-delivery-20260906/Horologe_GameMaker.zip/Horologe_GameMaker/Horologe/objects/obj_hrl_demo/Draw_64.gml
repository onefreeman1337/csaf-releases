/// @description Draw GUI - the demo

// ⛔ DRAWN IN THE GUI EVENT so the demo is resolution-independent and a buyer resizing the window
// does not have to reason about views to see the product.

if (is_undefined(mach)) exit;

var _W = display_get_gui_width();
var _H = display_get_gui_height();

var _page  = hrl_oklch(0.135, 0.008, 258);
var _ink   = hrl_oklch(0.900, 0.010, 258);
var _dim   = hrl_oklch(0.560, 0.010, 258);
var _warm  = hrl_oklch(0.760, 0.075, 70);
var _panel = hrl_oklch(0.190, 0.009, 258);

draw_set_colour(_page);
draw_rectangle(0, 0, _W, _H, false);

hrl_lamp_reset();

// -- the machine ---------------------------------------------------------------------------------
var _mw = _W * 0.60;
draw_set_colour(_panel);
draw_rectangle(20, 20, 20 + _mw, _H - 20, false);

var _parts = hrl_machine_parts(mach, show_dial);
hrl_render_in_rect_tight(_parts, mach.pal, 34, 34, _mw - 28, _H - 116, undefined);

hrl_text_line(hrl_machine_label(mach), 34, _H - 74, _mw - 28, 21, _ink, true);
hrl_text_line(hrl_machine_train_line(mach), 34, _H - 46, _mw - 28, 15, _dim, false);

// -- the readout ---------------------------------------------------------------------------------
// ⭐ THE NUMBERS ON THE RIGHT ARE READ OFF THE ARBORS, NOT OFF A CLOCK VARIABLE. That is the whole
// argument of the product in one panel: the hands and the figures come from the same place.
var _rx = 20 + _mw + 20;
var _rw = _W - _rx - 20;
draw_set_colour(_panel);
draw_rectangle(_rx, 20, _rx + _rw, _H - 20, false);

var _y = 42;
hrl_text_line("READOUT", _rx + 16, _y, _rw - 32, 15, _warm, true);
_y += 30;

var _read = hrl_machine_read(mach);
var _names = variable_struct_get_names(_read);
for (var _i = 0; _i < array_length(_names); _i++) {
    var _v = variable_struct_get(_read, _names[_i]);
    hrl_text_line(_names[_i], _rx + 16, _y, _rw * 0.5, 15, _dim, false);
    hrl_text_line(string_format(_v, 1, 2), _rx + _rw * 0.55, _y, _rw * 0.42, 15, _ink, true);
    _y += 24;
}

_y += 16;
hrl_text_line("MOVEMENT", _rx + 16, _y, _rw - 32, 15, _warm, true);
_y += 30;

var _rows = [
    ["beat",       (mach.train.beat > 0) ? (string_format(mach.train.beat, 1, 3) + " s") : "none"],
    ["beats",      string(mach.train.beats)],
    ["escapement", hrl_name_of(hrl_escapement_names(), mach.escapement)],
    ["oscillator", hrl_name_of(hrl_osc_names(), mach.osc)],
    ["frame",      hrl_name_of(hrl_frame_names(), mach.frame)],
    ["drive",      hrl_name_of(hrl_drive_names(), mach.drive)],
    ["dial",       hrl_name_of(hrl_dial_names(), mach.dial)],
    ["teeth",      hrl_name_of(hrl_profile_names(), mach.spec.profile)],
    ["crossings",  hrl_name_of(hrl_crossing_names(), mach.spec.crossing)],
    ["wind",       string_format(mach.wind * 100, 1, 0) + "%"],
];
for (var _i = 0; _i < array_length(_rows); _i++) {
    hrl_text_line(_rows[_i][0], _rx + 16, _y, _rw * 0.5, 14, _dim, false);
    hrl_text_line(_rows[_i][1], _rx + _rw * 0.48, _y, _rw * 0.50, 14, _ink, false);
    _y += 22;
}

if (show_labels) {
    _y = _H - 168;
    hrl_text_line("CONTROLS", _rx + 16, _y, _rw - 32, 15, _warm, true);
    _y += 28;
    var _keys = [
        "left / right   machine",
        "up / down      material",
        "S              new example",
        "D              dial on / off",
        "1 2 3          real / x60 / x600",
        "L              hide this",
    ];
    for (var _i = 0; _i < array_length(_keys); _i++) {
        hrl_text_line(_keys[_i], _rx + 16, _y, _rw - 32, 13, _dim, false);
        _y += 20;
    }
}

hrl_text_line(hrl_corpus_line(), 34, 8, _W - 60, 13, _dim, false);
