/// @description Clean Up

// ⚠️ NOTHING TO FREE, AND THAT IS WORTH SAYING RATHER THAN LEAVING THE EVENT EMPTY.
//
// This demo draws the machine from GEOMETRY every frame rather than from a cached sprite, because
// a mechanism at demo scale is one machine on screen and the geometry path is the one that shows
// the product honestly - every wheel rebuilt from its tooth count, no baked picture in the way.
//
// A buyer's GAME should NOT do that: hrl_render's caching header explains why, and
// hrl_render_to_sprite hands back a sprite the CALLER OWNS AND MUST sprite_delete. If you copy the
// demo as a starting point and add caching, this is the event where the delete goes. It is empty
// here because nothing was allocated, not because cleanup was forgotten.
//
// ⛔ AND THIS EVENT RUNS EVEN WHEN CREATE EXITED EARLY. The headless -selftest and -bake branches
// leave Create part way through, and GameMaker fires Clean Up at game end regardless - so anything
// read here must have been declared ABOVE those exits. A sibling product in this wing threw
// "variable not set before reading it" AFTER a fully green self-test, and a crash after the work
// is done still fails the run and still hides the result.
