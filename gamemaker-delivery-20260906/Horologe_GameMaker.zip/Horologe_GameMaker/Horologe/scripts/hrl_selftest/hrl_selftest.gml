/// HOROLOGE - hrl_selftest. The in-engine suite.
///
/// ============================================================================================
/// ⛔ GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE. There is no headless runner, no mock, no
/// assertion library. This wing's answer is to build the product through Igor, run the executable
/// with `-selftest`, and have it write a JSON result file - the one route that survives a release
/// build (show_debug_message is dead in one, and game_end's argument is not propagated).
///
/// ⛔ AND A SUITE FULL OF GREEN ASSERTIONS PROVES NOTHING UNTIL ONE OF THEM HAS BEEN MADE TO FAIL.
/// Two of this wing's worst incidents were suites that could never have gone red: a duplicate
/// check written with a tolerance below GML's default epsilon passed VACUOUSLY for every input,
/// and a containment assertion passed on 216 letters while most of them were silently shrunk.
/// Where an assertion here could be vacuous it is PAIRED with one proving the fixture is in the
/// state it needs, and those pairs are marked VACUITY GUARD.
///
/// ⛔ THE DEFAULT EPSILON. math_get_epsilon() returns 0.00001 on this runtime and it PARTICIPATES
/// IN COMPARISONS, so `abs(a - b) < 0.0000001` is FALSE for every pair including equal ones, and
/// `abs(a - b) < 0.00001` is RED for two values that are the same object. Never write a tolerance
/// below or at about 1e-5. HRL_ST_EPS is the one this file uses. And GML has no exponent literal:
/// `1e-5` is a lexer error that reads like a bracket bug.
///
/// ============================================================================================
/// WHAT THIS SUITE IS FOR, ON THIS PRODUCT SPECIFICALLY
///
/// The claim Horologe makes is that the picture and the mechanism come from the same numbers. Two
/// assertions carry that claim and everything else supports them:
///
///   STAGE 2  COUNT THE TEETH IN THE DRAWING. hrl_wheel_count_tips walks the OUTLINE and counts
///            radial runs. It never looks at N. A wheel that declares 96 and draws 95 fires here.
///   STAGE 4  MEASURE EVERY MESH AT ARBITRARY TIMES. For each mesh of each machine, at twelve
///            different moments, the driver's nearest tooth and the driven wheel's nearest gap are
///            measured against the line of centres IN ARC LENGTH, and they must cancel. A phase
///            solver that is right at t=0 and drifts fires here.
///
/// ⚠️ WHAT THIS SUITE CANNOT SEE, STATED HERE RATHER THAN LEFT FOR A BUYER TO DISCOVER: it
/// computes POINTS and NUMBERS. It cannot see a FILL RULE, a DRAW ORDER or a PICTURE. This wing
/// has shipped a crescent moon rendered as a quarter, a rainbow that never drew at all and a gilt
/// rim across twelve plates, all with the geometry suite fully green. The instrument for those is
/// opening the baked sheet and LOOKING, and that step is not optional because this file exists.
/// ============================================================================================

#macro HRL_ST_EPS 0.0001

function hrl_st_new() {
    return { pass: 0, fail: 0, notes: [] };
}

function hrl_st_ok(_r, _cond, _what) {
    if (_cond) { _r.pass += 1; return; }
    _r.fail += 1;
    // Cap the note list. A systemic failure can fire thousands of times and a result file that
    // cannot be written is a result file nobody reads.
    if (array_length(_r.notes) < 60) array_push(_r.notes, _what);
}

/// ============================================================================================
/// THE SUITE
/// ============================================================================================

function hrl_selftest_run() {
    var _r = hrl_st_new();

    // -- STAGE 0: the runtime still behaves the way this package assumes -----------------------
    global.hrl_stage = 0;
    var _e = math_get_epsilon();
    // ⛔ TWO CLAUSES, AND THE SECOND IS `!(_e > 0)` ON PURPOSE. The natural single expression
    // `_e > 0 && _e < TOL` goes RED on its first clause forever: the difference between the
    // epsilon and zero IS the epsilon, so GML calls them equal, and equal is not greater-than.
    // Written this way it is a POSITIVE test that the runtime still applies an epsilon, and it
    // goes red the day a release stops - which this package would need to know.
    hrl_st_ok(_r, !(_e > 0), "epsilon: expected (_e > 0) to be FALSE - the epsilon trap is gone");
    hrl_st_ok(_r, _e < 0.001, "epsilon: " + string_format(_e, 1, 12) + " is larger than assumed");

    // -- STAGE 1: THE CORPUS IS COUNTABLE AND EVERY FORM HAS A NAME -----------------------------
    // ⛔ THE NAME ARRAYS AND THE SWITCHES ARE ONE FACT WITH TWO DECLARATIONS (CLAUDE.md §2b, six
    // recorded instances). Adding a tooth profile and forgetting its name would draw an unlabelled
    // tooth on a store sheet; this is what makes that fire by name.
    global.hrl_stage = 1;
    hrl_st_ok(_r, array_length(hrl_finish_names())     == HRL_FINISH_N,     "names: finishes");
    hrl_st_ok(_r, array_length(hrl_material_names())   == HRL_MATERIAL_N,   "names: materials");
    hrl_st_ok(_r, array_length(hrl_profile_names())    == HRL_PROFILE_N,    "names: profiles");
    hrl_st_ok(_r, array_length(hrl_crossing_names())   == HRL_CROSSING_N,   "names: crossings");
    hrl_st_ok(_r, array_length(hrl_escapement_names()) == HRL_ESCAPEMENT_N, "names: escapements");
    hrl_st_ok(_r, array_length(hrl_osc_names())        == HRL_OSC_N,        "names: oscillators");
    hrl_st_ok(_r, array_length(hrl_dial_names())       == HRL_DIAL_N,       "names: dials");
    hrl_st_ok(_r, array_length(hrl_hand_names())       == HRL_HAND_N,       "names: hands");
    hrl_st_ok(_r, array_length(hrl_frame_names())      == HRL_FRAME_N,      "names: frames");
    hrl_st_ok(_r, array_length(hrl_drive_names())      == HRL_DRIVE_N,      "names: drives");
    hrl_st_ok(_r, array_length(hrl_machine_names())    == HRL_MACHINE_N,    "names: machines");
    // The operator's volume floor: 40+ distinct generated forms.
    hrl_st_ok(_r, hrl_corpus_forms() >= 40,
              "corpus: " + string(hrl_corpus_forms()) + " forms is below the volume floor of 40");

    // -- STAGE 2: THE DRAWING CARRIES THE TOOTH COUNT IT DECLARES -------------------------------
    global.hrl_stage = 2;
    var _counts = [7, 8, 10, 12, 15, 20, 24, 30, 36, 48, 60, 78, 90, 96];
    for (var _p = 0; _p < HRL_PROFILE_N; _p++) {
        // The lantern profile has no toothed outline - its pins are separate parts - so the
        // outline counter is not the instrument for it. It gets its own check below.
        if (_p == 3) continue;
        for (var _ci = 0; _ci < array_length(_counts); _ci++) {
            var _N = _counts[_ci];
            var _w = hrl_wheel_new(_N, 1.0, _p, 1);
            var _o = hrl_wheel_outline(_w);
            var _tips = hrl_wheel_count_tips(_o);
            hrl_st_ok(_r, _tips == _N,
                      hrl_name_of(hrl_profile_names(), _p) + " N=" + string(_N)
                      + ": drew " + string(_tips) + " tips");
            // The tooth lattice must be centred on local zero, or hrl_train's phase solver is
            // solving for a tooth that is not where it thinks.
            hrl_st_ok(_r, _hrl_st_tip_on_zero(_o, _N),
                      hrl_name_of(hrl_profile_names(), _p) + " N=" + string(_N)
                      + ": tooth lattice is not centred on local zero");
        }
    }

    // VACUITY GUARD. A plain circle has no teeth, and the counter must SAY SO. Without this, a
    // counter that returned "one run" for everything would pass every assertion above on the
    // profiles it happened to agree with, and the whole stage would be measuring nothing.
    var _circle = hrl_ellipse_pts(0, 0, 10, 10, 64);
    hrl_st_ok(_r, hrl_wheel_count_tips(_circle) == 0,
              "VACUITY: a plain circle counted " + string(hrl_wheel_count_tips(_circle)) + " teeth");
    // And the counter must be able to reach a number OTHER than the one it was handed - proved by
    // a hand-built outline with a known, different count.
    var _six = _hrl_st_star(6, 10, 7);
    hrl_st_ok(_r, hrl_wheel_count_tips(_six) == 6,
              "VACUITY: a 6-point star counted " + string(hrl_wheel_count_tips(_six)));

    // ⛔ THE LANTERN IS COUNTED TOO, AND THE FIRST VERSION ONLY CHECKED THAT IT HAD "more than 8
    // parts" - which a single bevelled disc satisfies. That weak assertion is why a store sheet
    // was free to print a hard-coded pin count for years' worth of sessions; the general tooth
    // counter cannot see pins, so this is the one profile whose central claim had no instrument.
    for (var _ln = 0; _ln < array_length(_counts); _ln++) {
        var _N3 = _counts[_ln];
        if (_N3 > 30) continue;                    // a lantern pinion is a pinion
        var _lw = hrl_wheel_new(_N3, 1.0, 3, 0);
        var _lp = hrl_wheel_parts(_lw, undefined);
        var _pins = hrl_wheel_count_pins(_lp, hrl_wheel_pitch_r(_lw), _N3);
        hrl_st_ok(_r, _pins == _N3,
                  "lantern N=" + string(_N3) + ": drew " + string(_pins) + " pins");
    }
    // ⛔ THE FIRST VACUITY GUARD HERE WAS ASKING THE WRONG QUESTION AND IT WENT RED ON CORRECT
    // CODE. It asserted that the pin counter finds no pins on a TOOTHED wheel - and it found
    // twelve, on a twelve-tooth wheel, because a toothed rim's bevel quads are also N radial
    // features at the pitch circle. That is not a defect in the counter; it is the counter doing
    // exactly what it does, on a fixture whose answer I had assumed rather than reasoned about.
    //
    // ⭐ WHAT THE COUNTER ACTUALLY COUNTS IS RADIAL FEATURES AT A GIVEN RADIUS, and for a lantern
    // those are its pins. So the thing that could be vacuous is the RADIUS FILTER: if it were
    // ignored, the count would come out the same wherever you looked. Pointing the counter at a
    // radius where the wheel has nothing must therefore return zero, and that is what this asks.
    var _lw2 = hrl_wheel_new(10, 1.0, 3, 0);
    var _lp2 = hrl_wheel_parts(_lw2, undefined);
    hrl_st_ok(_r, hrl_wheel_count_pins(_lp2, hrl_wheel_pitch_r(_lw2) * 2.5, 10) == 0,
              "VACUITY: the pin counter found pins at two and a half times the pitch radius, "
              + "so it is not looking at the radius at all");
    hrl_st_ok(_r, hrl_wheel_count_pins([], 10, 10) == 0,
              "VACUITY: the pin counter found pins in an empty part list");

    // -- STAGE 3: THE MESH ARITHMETIC ------------------------------------------------------------
    global.hrl_stage = 3;
    for (var _ci = 0; _ci < array_length(_counts); _ci++) {
        var _N2 = _counts[_ci];
        var _w2 = hrl_wheel_new(_N2, 1.0, 0, 1);
        hrl_st_ok(_r, abs(hrl_wheel_pitch_r(_w2) - _N2 * 0.5) < HRL_ST_EPS,
                  "pitch radius wrong for N=" + string(_N2));
        // ⛔ THE MESH CONDITION: circular pitch does NOT depend on N. This is why a 96 and a 12
        // can run together, and it is the one number that must match across a mesh.
        hrl_st_ok(_r, abs(hrl_wheel_pitch(_w2) - pi) < HRL_ST_EPS,
                  "circular pitch depends on N, which would make meshing impossible");
    }

    // -- STAGE 4: EVERY MACHINE, EVERY MESH, AT TWELVE ARBITRARY TIMES ---------------------------
    global.hrl_stage = 4;
    var _times = [0, 0.37, 1.0, 2.718, 7.5, 13.31, 60, 137.035, 600, 1801.7, 3600, 43200];
    for (var _k = 0; _k < HRL_MACHINE_N; _k++) {
        var _mach = hrl_machine_new(_k, _k mod HRL_MATERIAL_N, 11 + _k);
        var _tr = _mach.train;
        var _nm = array_length(_tr.meshes);
        hrl_st_ok(_r, _nm >= 2, hrl_name_of(hrl_machine_names(), _k)
                  + ": only " + string(_nm) + " meshes");

        for (var _mi = 0; _mi < _nm; _mi++) {
            var _me0 = hrl_mesh_error(_tr, _mi, 0);
            hrl_st_ok(_r, _me0.pitch_err < HRL_ST_EPS,
                      hrl_name_of(hrl_machine_names(), _k) + " mesh " + string(_mi)
                      + ": pitches differ by " + string(_me0.pitch_err) + " - they cannot mesh");
            hrl_st_ok(_r, abs(_me0.centre_dist - _me0.centre_want) < 0.002,
                      hrl_name_of(hrl_machine_names(), _k) + " mesh " + string(_mi)
                      + ": centre distance " + string(_me0.centre_dist)
                      + " but the pitch circles want " + string(_me0.centre_want));

            for (var _ti = 0; _ti < array_length(_times); _ti++) {
                var _me = hrl_mesh_error(_tr, _mi, _times[_ti]);
                hrl_st_ok(_r, abs(_me.err) < 0.02,
                          hrl_name_of(hrl_machine_names(), _k) + " mesh " + string(_mi)
                          + " at t=" + string(_times[_ti]) + ": teeth out of phase by "
                          + string(_me.err));
            }
        }

        // Every declared output must name an arbor that exists. An output on a missing arbor is a
        // struct read off `undefined`, which in GML is a CRASH and not a wrong number.
        var _no = array_length(_tr.outputs);
        hrl_st_ok(_r, _no > 0, hrl_name_of(hrl_machine_names(), _k) + ": no outputs declared");
        for (var _oi = 0; _oi < _no; _oi++) {
            var _ai = _tr.outputs[_oi].arbor;
            hrl_st_ok(_r, _ai >= 0 && _ai < array_length(_tr.arbors),
                      hrl_name_of(hrl_machine_names(), _k) + " output "
                      + _tr.outputs[_oi].label + ": arbor " + string(_ai) + " does not exist");
        }

        // Every arbor must be carried. hrl_frame emits a bearing per arbor whatever the frame is,
        // so a frame that forgot one draws a wheel floating in air.
        var _fp = hrl_frame_parts(_mach.frame, _tr, undefined);
        hrl_st_ok(_r, array_length(_fp) >= array_length(_tr.arbors) * 2,
                  hrl_name_of(hrl_machine_names(), _k) + ": frame has only "
                  + string(array_length(_fp)) + " parts for " + string(array_length(_tr.arbors))
                  + " arbors");

        // And the whole machine must draw something substantial.
        var _all = hrl_machine_parts(_mach, true);
        hrl_st_ok(_r, array_length(_all) > 200,
                  hrl_name_of(hrl_machine_names(), _k) + ": only "
                  + string(array_length(_all)) + " parts in the whole machine");
    }

    // -- STAGE 5: THE REGULATOR'S NUMBERS, WHICH ARE THE PRODUCT'S HEADLINE CLAIM ----------------
    // 96/12 - 96/12 - 90/12 with a 30-tooth escape wheel. Nobody typed "one second" anywhere.
    global.hrl_stage = 5;
    var _reg = hrl_machine_new(0, 0, 1);
    var _rt = _reg.train;
    // ⛔⛔ COMPARED IN TURNS PER HOUR, NOT IN TURNS PER SECOND, AND THAT IS THE EPSILON TRAP
    // CATCHING A BRAND NEW ASSERTION. One turn per hour is 0.000278 rev/s, so the natural way to
    // write this - `abs(turns - 1/3600) < 0.0000002` - puts BOTH the quantity and the tolerance
    // below GML's default epsilon of 0.00001. Below that, `<` reports FALSE for values the runtime
    // considers equal, so the assertion could never pass no matter how correct the train was. It
    // went red on a regulator that was running at exactly one turn per hour, and the printed value
    // said "0.00" because string() rounds - two instruments hiding the same thing.
    //
    // ⭐ The fix is to move the comparison into a range where the epsilon is not the whole
    // quantity: multiply by 3600 first and compare against 1. Same assertion, same tolerance in
    // relative terms, and it can actually fire in both directions.
    hrl_st_ok(_r, abs(_rt.arbors[_reg.centre].turns * 3600 - 1) < HRL_ST_EPS,
              "regulator: centre arbor is " + string(_rt.arbors[_reg.centre].turns * 3600)
              + " turns per hour, not one");
    hrl_st_ok(_r, abs(abs(_rt.arbors[_reg.escape].turns) - 1 / 60) < HRL_ST_EPS,
              "regulator: escape arbor is " + string(_rt.arbors[_reg.escape].turns)
              + " rev/s, not one turn per minute");
    hrl_st_ok(_r, abs(_rt.beat - 1.0) < HRL_ST_EPS,
              "regulator: the derived beat is " + string(_rt.beat) + " s, not 1.000 s");
    hrl_st_ok(_r, _reg.hour >= 0, "regulator: no motion work, so no hour hand");
    if (_reg.hour >= 0) {
        var _ratio = hrl_train_ratio(_rt, _reg.centre, _reg.hour);
        hrl_st_ok(_r, abs(abs(_ratio) - 1.0 / 12.0) < HRL_ST_EPS,
                  "regulator: hour arbor runs at " + string(_ratio) + " of the centre, not 1/12");
        // ⭐ THE MOTION WORK CLOSES. Cannon pinion 10 -> minute wheel 30 -> pinion 8 -> hour wheel
        // 32, both centre distances 20 modules, so the hour wheel comes back ONTO the centre
        // arbor. If it did not, the hour hand would be somewhere else on the dial from the minute
        // hand - which is exactly the sort of thing that looks like a drawing offset and is
        // actually arithmetic.
        var _d = point_distance(_rt.arbors[_reg.centre].x, _rt.arbors[_reg.centre].y,
                                _rt.arbors[_reg.hour].x, _rt.arbors[_reg.hour].y);
        hrl_st_ok(_r, _d < 0.002,
                  "regulator: the hour wheel landed " + string(_d)
                  + " modules from the centre arbor - the motion work does not close");
    }

    // The seconds hand steps, and it steps SIXTY times per revolution.
    hrl_machine_set(_reg, 10.0);
    var _a0 = hrl_arbor_angle(_rt, _reg.escape);
    hrl_machine_set(_reg, 10.4);
    var _a1 = hrl_arbor_angle(_rt, _reg.escape);
    hrl_machine_set(_reg, 11.0);
    var _a2 = hrl_arbor_angle(_rt, _reg.escape);
    hrl_st_ok(_r, abs(_a1 - _a0) < HRL_ST_EPS,
              "regulator: the escape wheel moved between beats - it is not being gated");
    hrl_st_ok(_r, abs(abs(_a2 - _a0) - HRL_TAU / 60) < HRL_ST_EPS,
              "regulator: one beat moved the escape wheel " + string(_a2 - _a0)
              + " rad, not one sixtieth of a turn");

    // Setting the time puts the TRAIN where a real clock's would be.
    hrl_machine_set_time(_reg, 3, 0, 0);
    var _rd = hrl_machine_read(_reg);
    hrl_st_ok(_r, abs(_rd.hours - 3) < 0.01,
              "regulator: set to 3:00:00 and reads " + string(_rd.hours) + " hours");
    hrl_st_ok(_r, _rd.minutes < 0.05 || _rd.minutes > 59.95,
              "regulator: set to 3:00:00 and reads " + string(_rd.minutes) + " minutes");
    hrl_machine_set_time(_reg, 9, 45, 30);
    var _rd2 = hrl_machine_read(_reg);
    // ⚠️ 45.5, NOT 45, AND THE FIRST VERSION OF THIS ASSERTION WAS THE THING THAT WAS WRONG. A
    // minute hand does not jump from minute to minute - it is fixed to the centre arbor and moves
    // continuously, so at thirty seconds past the minute it is genuinely half a division on. The
    // suite read 45.50 and was correct; the expected value was written by somebody thinking about
    // a digital display. Asserting 45 would have been asserting a defect.
    hrl_st_ok(_r, abs(_rd2.minutes - 45.5) < 0.05,
              "regulator: set to 9:45:30 and reads " + string(_rd2.minutes)
              + " minutes, not 45.5");
    hrl_st_ok(_r, abs(_rd2.hours - 9.7583) < 0.02,
              "regulator: set to 9:45:30 and the hour hand reads " + string(_rd2.hours));

    // -- STAGE 6: SETTING AND STEPPING MUST AGREE ------------------------------------------------
    // ⛔ A SET/STEP DISAGREEMENT ONLY SHOWS UP AFTER A SAVE AND LOAD, which is the worst place to
    // find it. A buyer's game steps the machine while it runs and SETS it when the save is loaded.
    global.hrl_stage = 6;
    var _m1 = hrl_machine_new(0, 0, 3);
    var _m2 = hrl_machine_new(0, 0, 3);
    var _total = 0;
    for (var _i = 0; _i < 37; _i++) { hrl_machine_step(_m1, 0.137); _total += 0.137; }
    hrl_machine_set(_m2, _total);
    hrl_st_ok(_r, abs(_m1.train.tick_t - _m2.train.tick_t) < HRL_ST_EPS,
              "step and set disagree on tick_t: " + string(_m1.train.tick_t)
              + " vs " + string(_m2.train.tick_t));
    for (var _i = 0; _i < array_length(_m1.train.arbors); _i++) {
        hrl_st_ok(_r, abs(hrl_arbor_angle(_m1.train, _i) - hrl_arbor_angle(_m2.train, _i)) < HRL_ST_EPS,
                  "step and set disagree on arbor " + string(_i));
    }

    // -- STAGE 7: THE MATERIAL MODEL --------------------------------------------------------------
    global.hrl_stage = 7;
    for (var _i = 0; _i < HRL_MATERIAL_N; _i++) {
        var _sp = hrl_material_spec(_i);
        var _nm2 = hrl_name_of(hrl_material_names(), _i);
        // Relief is only visible if adjacent ramp stops differ. Hearth shipped a dome as a flat
        // fill because two stops collapsed onto each other.
        hrl_st_ok(_r, hrl_mat_min_step(_sp) > 0.020,
                  _nm2 + ": adjacent ramp stops differ by only "
                  + string(hrl_mat_min_step(_sp)));
        // A dial exists to be read.
        hrl_st_ok(_r, hrl_mat_ink_sep(_sp) > 0.30,
                  _nm2 + ": ink sits only " + string(hrl_mat_ink_sep(_sp)) + " from its ground");
        hrl_st_ok(_r, _sp.finish >= 0 && _sp.finish < HRL_FINISH_N, _nm2 + ": finish out of range");
        hrl_st_ok(_r, _sp.corner >= 0, _nm2 + ": corner out of range");
    }

    // ⛔ THE AGEING LAW, AND IT IS THE ONE TWO PRODUCTS IN THIS WING GOT WRONG.
    // Polished steel has chroma 0.006 - it does not HAVE a visible hue - so tarnishing it must
    // move it STRAIGHT to the tarnish hue rather than sweeping halfway round the circle through
    // colours nobody wants. Armoury shipped magenta swords on exactly this.
    var _steel = hrl_material_spec(6);
    var _st_aged = hrl_mat_aged(_steel, 0.5);
    var _delta = abs(_st_aged.hue - _steel.tarnish);
    if (_delta > 180) _delta = 360 - _delta;
    hrl_st_ok(_r, _delta < 30,
              "ageing: half-tarnished steel is at hue " + string(_st_aged.hue)
              + ", " + string(_delta) + " degrees from the tarnish target - it is sweeping");
    // VACUITY GUARD, and it is the important half: a CHROMATIC material must NOT snap to the
    // target, or the weighting is not weighting anything and the assertion above is meaningless.
    var _copper = hrl_material_spec(3);
    var _cu_aged = hrl_mat_aged(_copper, 0.5);
    var _cd = abs(_cu_aged.hue - _copper.tarnish);
    if (_cd > 180) _cd = 360 - _cd;
    hrl_st_ok(_r, _cd > 20,
              "VACUITY: half-tarnished copper snapped straight to its tarnish hue ("
              + string(_cd) + " degrees away) - the chroma weighting is doing nothing");
    // And the blend takes the SHORT way round the circle.
    hrl_st_ok(_r, abs(hrl_hue_mix(350, 10, 0.5) - 0) < 0.001
                  || abs(hrl_hue_mix(350, 10, 0.5) - 360) < 0.001,
              "hue_mix(350,10,0.5) = " + string(hrl_hue_mix(350, 10, 0.5)) + ", not 0");
    hrl_st_ok(_r, abs(hrl_hue_mix(10, 350, 0.5) - 0) < 0.001
                  || abs(hrl_hue_mix(10, 350, 0.5) - 360) < 0.001,
              "hue_mix(10,350,0.5) = " + string(hrl_hue_mix(10, 350, 0.5)) + ", not 0");

    // -- STAGE 8: DIALS, FIGURES AND HANDS --------------------------------------------------------
    global.hrl_stage = 8;
    for (var _i = 0; _i < HRL_DIAL_N; _i++) {
        var _dp = hrl_dial_parts(_i, 20, 1.0, undefined);
        hrl_st_ok(_r, array_length(_dp) > 20,
                  "dial " + hrl_name_of(hrl_dial_names(), _i) + ": only "
                  + string(array_length(_dp)) + " parts");
    }
    for (var _i = 0; _i < HRL_HAND_N; _i++) {
        var _hp = hrl_hand_parts(_i, 10, 1.0, undefined);
        hrl_st_ok(_r, array_length(_hp) > 1,
                  "hand " + hrl_name_of(hrl_hand_names(), _i) + ": only "
                  + string(array_length(_hp)) + " parts");
        // ⛔ A HAND MUST NOT OVERRUN ITS OWN LENGTH. It is handed the radius it has to fit inside,
        // and a hand that reaches past the chapter ring is the single most obvious drawing defect
        // a clock can have.
        //
        // ⛔ hrl_render_bounds RETURNS AN ARRAY [x0,y0,x1,y1], NOT A STRUCT, and the first version
        // of these three assertions read `.y0` off it. MEASURED: the suite crashed at stage 8 with
        // "I32 argument is array" - which is not a message that points anywhere near the mistake.
        // It was found in seconds only because obj_hrl_demo installs an unhandled-exception handler
        // that writes the STAGE NUMBER; without it this is a headless process that never exits.
        // The general form: a helper's RETURN SHAPE is not guessable from its name, and a struct
        // access on an array does not fail where you wrote it.
        var _b = hrl_render_bounds(_hp);
        hrl_st_ok(_r, _b[1] > -10.9,
                  "hand " + hrl_name_of(hrl_hand_names(), _i) + " reaches to "
                  + string(_b[1]) + " when it was given 10");
    }
    for (var _i = 0; _i < 10; _i++) {
        hrl_st_ok(_r, array_length(hrl_glyph_digit(_i)) > 0, "digit " + string(_i) + " is empty");
    }
    for (var _i = 1; _i <= 12; _i++) {
        hrl_st_ok(_r, array_length(hrl_glyph_roman(_i)) > 0, "roman " + string(_i) + " is empty");
    }
    // ⭐ IIII, NOT IV. Four is drawn as four I's, so it carries four times the stroke count of one
    // I. This asserts a CONVENTION rather than a bug, and it is the sort of thing a generator gets
    // to be right about permanently.
    var _one = array_length(hrl_glyph_roman(1));
    var _four = array_length(hrl_glyph_roman(4));
    hrl_st_ok(_r, _four == _one * 4,
              "roman 4 has " + string(_four) + " strokes, not four I's worth (" + string(_one * 4) + ")");
    // VACUITY GUARD, AND THE FIRST ONE WAS A FALSE RED FROM A COINCIDENCE. It asserted that IX is
    // not three I's, by stroke count: I is 3 strokes, X is 6, so IX is 9 - and III is also 9. The
    // guard was comparing two different numerals that happen to cost the same, and it fired on a
    // package that was drawing IX correctly. A false red costs exactly what a false green does.
    //
    // ⭐ THE RIGHT GUARD COMPARES THE TWO NUMERALS THE CONVENTION IS ACTUALLY ABOUT. Four drawn as
    // IIII is 12 strokes; four drawn as IV would be I + V = 6 strokes, which is exactly what VI
    // costs. So if this package ever switched to IV, roman(4) and roman(6) would collide - and
    // nothing else would. The guard now tests the distinction it claims to test.
    hrl_st_ok(_r, array_length(hrl_glyph_roman(4)) != array_length(hrl_glyph_roman(6)),
              "VACUITY: roman 4 costs the same as roman 6, which is what IV would cost");
    hrl_st_ok(_r, array_length(hrl_glyph_roman(10)) != array_length(hrl_glyph_roman(5)),
              "VACUITY: X and V are drawn with the same number of strokes - the letters are not "
              + "being told apart, so the IIII check above proves nothing");

    // -- STAGE 9: ESCAPEMENTS AND OSCILLATORS ------------------------------------------------------
    global.hrl_stage = 9;
    var _ew = hrl_wheel_new(30, 1.0, 5, 0);
    var _swings = [-1, -0.5, 0, 0.5, 1];
    for (var _i = 0; _i < HRL_ESCAPEMENT_N; _i++) {
        for (var _si = 0; _si < array_length(_swings); _si++) {
            var _ep = hrl_esc_parts(_i, _ew, _swings[_si], undefined);
            hrl_st_ok(_r, array_length(_ep) > 3,
                      "escapement " + hrl_name_of(hrl_escapement_names(), _i)
                      + " at swing " + string(_swings[_si]) + ": only "
                      + string(array_length(_ep)) + " parts");
        }
        // The pallets must actually MOVE with the swing, or the escapement is a picture.
        //
        // ⛔ MEASURED AGAINST SWING 0, NOT AGAINST THE OPPOSITE SWING, AND THE FIRST VERSION GOT
        // THAT WRONG. Comparing the bounding box at -1 with the box at +1 fires on a MIRROR
        // SYMMETRIC assembly even though it is moving perfectly: rotating a symmetric shape by
        // -a and by +a gives boxes that are reflections of each other, so x0 and x1 simply swap
        // and every number in the box is the same. The verge - a vertical staff through the wheel
        // centre - is exactly that shape, and it reported "does not move" while swinging half a
        // radian each way. Comparing a swung state against the CENTRED state has no such blind
        // spot, because the centred state is the one configuration a mirror cannot produce.
        var _p0 = hrl_render_bounds(hrl_esc_parts(_i, _ew, 0, undefined));
        var _p1 = hrl_render_bounds(hrl_esc_parts(_i, _ew, 1, undefined));
        hrl_st_ok(_r, abs(_p0[0] - _p1[0]) > 0.004 || abs(_p0[1] - _p1[1]) > 0.004
                   || abs(_p0[2] - _p1[2]) > 0.004 || abs(_p0[3] - _p1[3]) > 0.004,
                  "escapement " + hrl_name_of(hrl_escapement_names(), _i)
                  + ": the assembly is identical at rest and at full swing");
    }
    for (var _i = 0; _i < HRL_OSC_N; _i++) {
        var _op = hrl_osc_parts(_i, 0, 0, 9, 1.0, 0.4, undefined);
        hrl_st_ok(_r, array_length(_op) > 3,
                  "oscillator " + hrl_name_of(hrl_osc_names(), _i) + ": only "
                  + string(array_length(_op)) + " parts");
    }
    // ⭐ A PENDULUM'S PERIOD IS A LENGTH, AND IT GOES AS THE SQUARE OF THE BEAT. A half-seconds
    // pendulum is a QUARTER of a seconds pendulum, not a half. The drawing is derived from that,
    // so this asserts the physics rather than a magic number.
    hrl_st_ok(_r, abs(hrl_osc_length(0, 1.0) / max(0.0001, hrl_osc_length(0, 0.5)) - 4.0) < 0.001,
              "pendulum length does not go as the square of the beat");

    // -- STAGE 10: THE ROTATIONAL SYMMETRY DECLARATION IS TRUE -------------------------------------
    // ⛔ hrl_render's cache bakes a wheel once and draws it ROTATED, which is only honest if the
    // wheel really does map onto itself. hrl_wheel_rot_sym DECLARES how many times; this checks
    // the declaration against the geometry, which is the same shape as the donor's declared-
    // openness table: make the fast path a declaration and make the test verify it, rather than
    // shipping a cheap proxy that is wrong invisibly.
    global.hrl_stage = 10;
    for (var _c = 0; _c < HRL_CROSSING_N; _c++) {
        var _w3 = hrl_wheel_new(48, 1.0, 0, _c);
        _w3.crossN = 6;
        var _sym = hrl_wheel_rot_sym(_w3);
        var _parts = hrl_crossing_parts(_w3, "m3", "m1");
        if (array_length(_parts) == 0) continue;    // a solid web has nothing to check
        hrl_st_ok(_r, _hrl_st_rot_sym(_parts, _sym),
                  "crossing " + hrl_name_of(hrl_crossing_names(), _c)
                  + " declares " + string(_sym) + "-fold symmetry and does not have it");
    }
    // VACUITY GUARD: the checker must be able to say NO. A deliberately asymmetric part list must
    // fail a 6-fold claim, or stage 10 is measuring nothing.
    var _lop = [hrl_dot(3, 0, 1, "m2"), hrl_dot(0, 5, 1, "m2")];
    hrl_st_ok(_r, !_hrl_st_rot_sym(_lop, 6),
              "VACUITY: the symmetry checker accepted an obviously asymmetric part list");

    // -- STAGE 11: NOTHING ESCAPES THE MOVEMENT ----------------------------------------------------
    // The wheels and the frame must sit inside the layout the solver produced. The DRIVE and the
    // OSCILLATOR are excluded on purpose and it is not a loophole: a hanging weight and a
    // pendulum are SUPPOSED to reach outside the plate, and asserting otherwise would be
    // asserting that a longcase clock is the size of its movement.
    global.hrl_stage = 11;
    for (var _k = 0; _k < HRL_MACHINE_N; _k++) {
        var _mm = hrl_machine_new(_k, 0, 40 + _k);
        var _bb = hrl_train_bounds(_mm.train);
        var _fp2 = hrl_frame_parts(_mm.frame, _mm.train, undefined);
        var _fb = hrl_render_bounds(_fp2);
        var _mx = max(_bb.x1 - _bb.x0, _bb.y1 - _bb.y0);
        // _bb is a STRUCT (hrl_train_bounds) and _fb is an ARRAY (hrl_render_bounds). Two
        // neighbouring functions, two shapes, and only one of them says so in its name.
        hrl_st_ok(_r, _fb[0] > _bb.x0 - _mx * 0.45 && _fb[2] < _bb.x1 + _mx * 0.45,
                  hrl_name_of(hrl_machine_names(), _k)
                  + ": the frame runs well outside the movement it carries");
    }

    global.hrl_stage = 99;
    return _r;
}

/// ============================================================================================
/// SUITE HELPERS
/// ============================================================================================

/// Does this outline's tooth lattice sit on multiples of the angular pitch, starting at zero?
///
/// Finds the point at maximum radius and asks how far its angle is from the nearest multiple of
/// the pitch. Anything past a fifth of a pitch means the teeth are not where hrl_train's phase
/// solver assumes, which meshes the whole train half a tooth out.
function _hrl_st_tip_on_zero(_pts, _N) {
    var _n = array_length(_pts);
    if (_n < 3 || _N < 3) return false;
    var _best = -1, _bi = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _d = point_distance(0, 0, _pts[_i][0], _pts[_i][1]);
        if (_d > _best) { _best = _d; _bi = _i; }
    }
    var _a = arctan2(_pts[_bi][1], _pts[_bi][0]);
    var _pa = HRL_TAU / _N;
    var _off = _a;
    while (_off >= _pa * 0.5) _off -= _pa;
    while (_off < -_pa * 0.5) _off += _pa;
    return abs(_off) < _pa * 0.20;
}

/// A star outline with a known number of points, for the counter's vacuity guard.
function _hrl_st_star(_n, _r_out, _r_in) {
    var _pts = [];
    for (var _i = 0; _i < _n; _i++) {
        var _a = HRL_TAU * _i / _n;
        var _b = HRL_TAU * (_i + 0.5) / _n;
        array_push(_pts, [cos(_a) * _r_out, sin(_a) * _r_out]);
        array_push(_pts, [cos(_b) * _r_in, sin(_b) * _r_in]);
    }
    return _pts;
}

/// Does this part list map onto itself when rotated by one _sym-th of a turn?
///
/// ⛔ THE FIRST VERSION MATCHED PART CENTROIDS AND IT WAS DEFEATED BY A DISC. Rotate the list, and
/// require every rotated centroid to land on an original one within a tolerance: correct in
/// principle, and it reported three of ten crossing patterns as asymmetric when all three were
/// perfectly symmetric. The reason is worth writing down, because it is a whole class of trap.
///
/// A pierced web is drawn as ONE disc plus N holes. The disc is a triangle fan built as
/// [centre, p0, p1 ... pN, p0] - the first rim point is REPEATED to close the fan, which is a
/// correctness fix this drawing layer already carries - so its centroid is not at the origin, it
/// is one forty-second of the way out toward p0. Rotating that tiny offset by sixty degrees moves
/// it half a unit, there is nothing for it to land on, and the check fails on a DISC, which is the
/// most rotationally symmetric object there is.
///
/// ⭐ SO IT IS DONE IN THE FREQUENCY DOMAIN INSTEAD, which has no such special cases. For a shape
/// with n-fold symmetry every angular Fourier harmonic that is NOT a multiple of n must vanish. So
/// accumulate sum(r * cos(m * theta)) and sum(r * sin(m * theta)) over every point, for m = 1 to
/// n-1, and require each to be small against the total. It is one pass, it has no tolerance to
/// tune per shape, and a part sitting exactly on the axis contributes nothing to any harmonic -
/// which is the correct answer rather than a special case.
function _hrl_st_rot_sym(_parts, _sym) {
    if (_sym < 2) return true;
    var _n = array_length(_parts);
    if (_n == 0) return false;

    var _sum_r = 0;
    var _cm = array_create(_sym, 0);
    var _sm = array_create(_sym, 0);

    for (var _i = 0; _i < _n; _i++) {
        var _pts = _hrl_st_points(_parts[_i]);
        for (var _j = 0; _j < array_length(_pts); _j++) {
            var _x = _pts[_j][0], _y = _pts[_j][1];
            var _rr = sqrt(_x * _x + _y * _y);
            if (_rr < 0.0001) continue;
            var _th = arctan2(_y, _x);
            _sum_r += _rr;
            for (var _m = 1; _m < _sym; _m++) {
                _cm[_m] += _rr * cos(_m * _th);
                _sm[_m] += _rr * sin(_m * _th);
            }
        }
    }
    if (_sum_r <= 0) return false;
    for (var _m = 1; _m < _sym; _m++) {
        var _mag = sqrt(_cm[_m] * _cm[_m] + _sm[_m] * _sm[_m]) / _sum_r;
        if (_mag > 0.06) return false;
    }
    return true;
}

/// Every point of a part, as one flat list.
function _hrl_st_points(_p) {
    switch (_p.kind) {
        case HRL_DOT: return [[_p.cx, _p.cy]];
        case HRL_ARC: return [[_p.cx, _p.cy]];
        case HRL_STRIP: {
            var _out = [];
            for (var _i = 0; _i < array_length(_p.a); _i++) array_push(_out, _p.a[_i]);
            for (var _i = 0; _i < array_length(_p.b); _i++) array_push(_out, _p.b[_i]);
            return _out;
        }
        default: return _p.pts;
    }
}

/// ============================================================================================
/// THE RESULT FILE
///
/// ⛔ A SANDBOXED FILE WRITE IS THE ONLY ROUTE THAT SURVIVES A RELEASE BUILD. show_debug_message
/// plus -debugoutput writes only engine boot lines, and game_end(n) does not propagate n to the
/// process exit code. Both were measured in this wing.
/// ============================================================================================

function hrl_selftest_write(_r) {
    var _f = file_text_open_write("hrl_selftest.json");
    var _notes = "";
    for (var _i = 0; _i < array_length(_r.notes); _i++) {
        if (_i > 0) _notes += " | ";
        _notes += string_replace_all(string(_r.notes[_i]), "\"", "'");
    }
    var _reg = hrl_machine_new(0, 0, 1);
    file_text_write_string(_f,
        "{\"pass\":" + string(_r.pass)
        + ",\"fail\":" + string(_r.fail)
        + ",\"stage\":" + string(global.hrl_stage)
        + ",\"epsilon\":" + string_format(math_get_epsilon(), 1, 12)
        + ",\"forms\":" + string(hrl_corpus_forms())
        + ",\"materials\":" + string(HRL_MATERIAL_N)
        + ",\"machines\":" + string(HRL_MACHINE_N)
        + ",\"regulatorBeat\":" + string_format(_reg.train.beat, 1, 6)
        + ",\"regulatorTrain\":\"" + hrl_machine_train_line(_reg) + "\""
        + ",\"version\":\"" + HRL_VERSION + "\""
        + ",\"notes\":\"" + _notes + "\"}");
    file_text_close(_f);
}
