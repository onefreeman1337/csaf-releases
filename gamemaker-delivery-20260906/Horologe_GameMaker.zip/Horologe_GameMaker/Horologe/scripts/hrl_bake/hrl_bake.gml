/// HOROLOGE - hrl_bake. The store sheets, rendered BY THE PRODUCT.
///
/// ============================================================================================
/// ⛔ WHY THE GALLERY IS BAKED IN ENGINE AND NOT DRAWN BY A PREVIEWER.
/// A gallery rendered by a side previewer is a picture of a RE-IMPLEMENTATION. This wing measured
/// exactly that on a sibling product: the JavaScript previewer had a defect that was invisible in
/// the previewer and plainly visible in engine. Baking through Igor lets the listing say,
/// truthfully, that every image on the page was rendered by the code in the package.
///
/// ⛔ AND EVERY SHEET IS MEASURED, NOT EYEBALLED. hrl_bk_one runs an INK BOUNDING BOX over the
/// finished surface and reports it. That catches an EMPTY sheet and a CLIPPED one - and it cannot
/// catch a SPARSE one, a wrongly-ordered one, or one where the picture is simply bad. The wing's
/// standing law: a bounding box cannot see the space inside itself, and the only instrument for
/// that is opening the PNG and LOOKING at it. This file does not replace that step.
///
/// ⚠️ THE INK CHECK'S KNOWN BLIND SPOTS, carried forward because they are still true here:
///   - stride: y steps by 1, because a 1px hairline lands on one row and an even-only scan walks
///     past it. x may step by 2.
///   - a flat fill close to the page colour is NOT counted as ink, so a large panel at low
///     contrast can run off the bottom and still report ok.
///   - two boxes, not one: `full` for the clip test and `content`, measured below the title rule,
///     for the coverage floors, so the rule cannot satisfy them by itself.
///
/// ⚠️ AND ONE THAT IS NEW ON THIS PRODUCT: A MECHANISM IS MOSTLY HOLES. A wheel with six crossings
/// is more page than metal, so the ink COUNT floor has to be lower here than on a product that
/// draws solid objects, and a low count is not evidence of a defect. The coverage boxes still
/// apply - what matters is that the drawing reaches the edges of its area, not that it fills it.
/// ============================================================================================

#macro HRL_SHEET_W 1600
#macro HRL_SHEET_H 1000

function hrl_bk_page()  { return hrl_oklch(0.135, 0.008, 258); }
function hrl_bk_ink()   { return hrl_oklch(0.900, 0.010, 258); }
function hrl_bk_dim()   { return hrl_oklch(0.555, 0.010, 258); }
function hrl_bk_rule()  { return hrl_oklch(0.300, 0.012, 258); }
function hrl_bk_warm()  { return hrl_oklch(0.760, 0.075, 70);  }

/// A sheet heading.
///
/// ⛔ hrl_text_label DRAWS AT THE x IT IS GIVEN (fa_left) - it does NOT centre on it. A donor
/// shipped titles running off the right edge by passing the page midpoint here, and the short
/// titles looked deliberately centred and hid it. Pass a LEFT edge.
function hrl_bk_head(_title, _sub, _y) {
    hrl_text_label(_title, 60, _y, HRL_SHEET_W - 120, 46, hrl_bk_page(), hrl_bk_ink());
    var _yy = _y + 58;
    if (_sub != "") {
        hrl_text_body(_sub, 60, _yy, HRL_SHEET_W - 420, 19, hrl_bk_dim());
        _yy += 30;
    }
    draw_set_colour(hrl_bk_rule());
    draw_rectangle(60, _yy + 14, HRL_SHEET_W - 60, _yy + 15, false);
    return _yy + 40;
}

/// A caption under a cell, measured and scaled to its cell.
///
/// ⛔ THIS WING SHIPPED THE SAME OVERFLOW DEFECT TWICE because the first fix shortened the DATA
/// rather than making the caption honest about its width. No ink check will ever catch it:
/// overprinted text is ink exactly where ink belongs. Found only by reading the sheet.
function hrl_bk_caption(_text, _cx, _y, _maxw, _px, _col) {
    hrl_text_line(_text, _cx - _maxw * 0.5, _y, _maxw, _px, _col, false);
}

/// A recessed well for a specimen cell.
function hrl_bk_well(_x, _y, _w, _h) {
    draw_set_colour(hrl_oklch(0.180, 0.009, 258));
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);
    draw_set_colour(hrl_bk_rule());
    draw_rectangle(_x, _y, _x + _w, _y + _h, true);
}

/// The ink bounding box over the current render target.
function hrl_bk_ink_bounds(_w, _h, _contentY) {
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, surface_get_target(), 0);
    var _pg = hrl_bk_page();
    var _pr = colour_get_red(_pg), _pgn = colour_get_green(_pg), _pb = colour_get_blue(_pg);

    var _fx0 = _w, _fy0 = _h, _fx1 = -1, _fy1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;
    var _ink = 0;

    for (var _y = 0; _y < _h; _y++) {
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = (_y * _w + _x) * 4;
            var _r = buffer_peek(_buf, _o, buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_r - _pr) <= 10 && abs(_g - _pgn) <= 10 && abs(_b - _pb) <= 10) continue;
            _ink += 1;
            if (_x < _fx0) _fx0 = _x;
            if (_x > _fx1) _fx1 = _x;
            if (_y < _fy0) _fy0 = _y;
            if (_y > _fy1) _fy1 = _y;
            if (_y >= _contentY) {
                if (_x < _cx0) _cx0 = _x;
                if (_x > _cx1) _cx1 = _x;
                if (_y < _cy0) _cy0 = _y;
                if (_y > _cy1) _cy1 = _y;
            }
        }
    }
    buffer_delete(_buf);
    return { full: [_fx0, _fy0, _fx1, _fy1], content: [_cx0, _cy0, _cx1, _cy1], ink: _ink };
}

/// ============================================================================================
/// THE SHEETS
/// ============================================================================================

/// HERO. The regulator's movement, dial off, as large as the page allows.
///
/// ⛔ CHOSEN BY BAKING THE CANDIDATES AT HERO SIZE AND LOOKING (wing CLAUDE.md, Lode): a form can
/// work small and fail large, which is the opposite of what a hero needs. A whole clock with its
/// dial ON is the obvious hero and it is the wrong one - the dial covers the machine, so the image
/// becomes a picture of a clock face, which is a thing anybody can draw. The movement UNCOVERED is
/// the thing this package makes that a picture cannot.
/// ⛔⛔ TWO PANELS, AND THE ONE-PANEL VERSION IS WHY. The first hero put a single wide well across
/// the page and dropped one movement into it. hrl_render_in_rect_tight scales UNIFORMLY - which is
/// correct and must not change, because a non-uniform scale turns every circle in this package
/// into an ellipse and a wheel's rim curve IS its identity. A movement is taller than it is wide,
/// so it fitted by height and left four fifths of the frame empty.
///
/// ⚠️ AND THE INK CHECK PASSED IT, at contentW 0.924 and contentH 0.913, because the TITLE and the
/// CAPTION span the full width and the box measures INK rather than SUBJECT. The wing's standing
/// law says a bounding box cannot see the space inside itself; this is the version of that where
/// the typography satisfies the floor on the picture's behalf. Found by opening the file.
///
/// ⭐ The fix is also the better image: the MOVEMENT beside the DIAL, same machine, same moment.
/// It fills two portrait panels honestly, and it makes the product's argument in one glance - the
/// face and the works are the same object, and the hands are where the wheels put them.
function hrl_bk_hero() {
    var _y = hrl_bk_head("HOROLOGE",
        "Mechanisms that draw themselves from their own tooth counts, and turn.", 56);
    var _mach = hrl_machine_new(0, 0, 5);
    hrl_machine_set_time(_mach, 10, 9, 36);

    var _h = HRL_SHEET_H - _y - 128;
    var _pw = (HRL_SHEET_W - 140) * 0.5;

    hrl_bk_well(60, _y, _pw, _h);
    hrl_render_in_rect_tight(hrl_machine_movement_parts(_mach), _mach.pal,
                             76, _y + 16, _pw - 32, _h - 56, undefined);
    hrl_bk_caption("the movement", 60 + _pw * 0.5, _y + _h - 32, _pw - 40, 19, hrl_bk_dim());

    var _x2 = 80 + _pw;
    hrl_bk_well(_x2, _y, _pw, _h);
    hrl_render_in_rect_tight(hrl_machine_dial_parts(_mach), _mach.pal,
                             _x2 + 16, _y + 16, _pw - 32, _h - 56, undefined);
    hrl_bk_caption("the same machine, from the front", _x2 + _pw * 0.5, _y + _h - 32,
                   _pw - 40, 19, hrl_bk_dim());

    var _cy = _y + _h + 24;
    hrl_text_line("longcase regulator, polished brass, deadbeat escapement",
                  60, _cy, 900, 22, hrl_bk_ink(), true);
    hrl_text_line("train " + hrl_machine_train_line(_mach)
                  + "   centre 1 turn/hour   escape 1 turn/minute   beat "
                  + string_format(_mach.train.beat, 1, 3) + " s, derived from the tooth counts",
                  60, _cy + 32, HRL_SHEET_W - 120, 18, hrl_bk_dim(), false);
    return _cy + 62;
}

/// MESH. The sheet that makes the argument. Two wheels, large, teeth interleaving, with the
/// numbers that produced them printed beside.
///
/// ⭐ IF A BUYER LOOKS AT ONE IMAGE ON THE PAGE IT SHOULD BE THIS ONE. Everything else in the
/// gallery is a catalogue; this is the claim.
function hrl_bk_mesh() {
    var _y = hrl_bk_head("THE TEETH MESH BECAUSE THE NUMBERS SAY SO",
        "Centre distance, ratio and phase are all computed from the two tooth counts. "
        + "Nothing here is placed by eye.", 56);

    var _pairs = [[96, 12], [64, 8], [30, 10]];
    var _cw = (HRL_SHEET_W - 140) / 3;
    var _ch = HRL_SHEET_H - _y - 150;

    for (var _i = 0; _i < 3; _i++) {
        var _x = 60 + _i * (_cw + 10);
        hrl_bk_well(_x, _y, _cw - 10, _ch);

        var _tr = hrl_train_new(1.0);
        var _wa = hrl_wheel_new(_pairs[_i][0], 1.0, 0, 3); _wa.crossN = 6;
        var _wb = hrl_wheel_new(_pairs[_i][1], 1.0, 0, 0);
        var _ia = hrl_train_add(_tr, _wa, undefined, "driver");
        var _ib = hrl_train_add(_tr, undefined, _wb, "driven");
        hrl_train_root(_tr, _ia, 0, 0, 1 / 40, 0.31);
        hrl_train_mesh(_tr, _ia, "wheel", _ib, "pinion", -0.45, HRL_MESH_EXTERNAL);
        hrl_train_set(_tr, 3.7);

        var _pal = {};
        hrl_mat_into(_pal, "s", hrl_material_spec(0));
        hrl_mat_into(_pal, "j", hrl_material_spec(12));
        _pal.line = hrl_mat_ink(hrl_material_spec(0));

        var _parts = [];
        hrl_append(_parts, hrl_place(hrl_wheel_parts(_wa, undefined),
                                     _tr.arbors[_ia].x, _tr.arbors[_ia].y, 1,
                                     hrl_arbor_angle(_tr, _ia), 1, undefined));
        hrl_append(_parts, hrl_place(hrl_wheel_parts(_wb, undefined),
                                     _tr.arbors[_ib].x, _tr.arbors[_ib].y, 1,
                                     hrl_arbor_angle(_tr, _ib), 1, undefined));
        hrl_render_in_rect_tight(hrl_map_roles(_parts, hrl_mat_map("s")), _pal,
                                 _x + 16, _y + 16, _cw - 42, _ch - 90, undefined);

        var _me = hrl_mesh_error(_tr, 0, 3.7);
        var _tx = _x + 20;
        var _ty = _y + _ch - 62;
        hrl_text_line(string(_pairs[_i][0]) + " / " + string(_pairs[_i][1]),
                      _tx, _ty, _cw - 50, 26, hrl_bk_warm(), true);
        hrl_text_line("ratio " + string_format(_pairs[_i][0] / _pairs[_i][1], 1, 3)
                      + " : 1    centres " + string_format(_me.centre_want, 1, 1) + " modules",
                      _tx, _ty + 32, _cw - 50, 15, hrl_bk_dim(), false);
    }

    var _cy = _y + _ch + 26;
    hrl_text_line("Both wheels of a pair share one circular pitch, pi x module, so their teeth are "
                  + "the same size. The centre distance is the sum of the pitch radii. The driven "
                  + "wheel's phase is solved so a tooth of the driver lands in a gap of the driven "
                  + "wheel at the line of centres, at every moment and not only at the start.",
                  60, _cy, HRL_SHEET_W - 120, 18, hrl_bk_dim());
    return _cy + 70;
}

/// TEETH. The eight profiles, and the fact that the pitch does not change with the count.
///
/// ⛔⛔ A WHOLE WHEEL IS TOO SMALL TO SHOW A TOOTH, WHICH MADE THIS SHEET UNABLE TO PROVE ITS OWN
/// CAPTION. Eight 24-tooth wheels in a 4x2 grid draw each tooth about eleven pixels wide. At that
/// size a cycloidal flank, an involute flank and a club tooth are the same three pixels of bevel,
/// so the sheet titled EIGHT TOOTH PROFILES showed eight wheels that a buyer could not tell apart
/// - and the four that ARE obvious small (ratchet, lantern pin, crown, sprocket) were carrying the
/// whole page. It also read as the same picture as the escapements sheet to the gallery variety
/// check, at Hamming 6 then 8, which is the same fact arriving from the other direction: two grids
/// of round brass things.
///
/// ⭐ SO EACH CELL IS TWO PICTURES OF ONE WHEEL. The top band is a detail crop of the rim - about
/// four and a half teeth at roughly nineteen times the area, where the flank shape is the subject -
/// and the bottom band is the whole wheel, small, which is what keeps the counted caption honest
/// and lets the eye check that the crop came off the thing underneath it. Neither alone is the
/// sheet: the crop cannot show a count and the wheel cannot show a profile.
function hrl_bk_teeth() {
    var _y = hrl_bk_head("EIGHT TOOTH PROFILES",
        "Each drawn from a tooth count, not from a picture of a gear. The rim is shown close, "
        + "because at whole-wheel size every profile looks like every other profile.", 56);
    var _names = hrl_profile_names();
    var _cols = 4, _rows = 2;
    var _cw = (HRL_SHEET_W - 120) / _cols;
    var _ch = (HRL_SHEET_H - _y - 120) / _rows;

    for (var _i = 0; _i < HRL_PROFILE_N; _i++) {
        var _cx = 60 + (_i mod _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        var _wx = _cx + 6, _wy = _cy + 6, _ww = _cw - 18, _wh = _ch - 44;
        hrl_bk_well(_wx, _wy, _ww, _wh);

        var _w = hrl_wheel_new(24, 1.0, _i, 3);
        _w.crossN = 5;
        var _pal = {};
        hrl_mat_into(_pal, "s", hrl_material_spec((_i mod 3 == 0) ? 0 : ((_i mod 3 == 1) ? 6 : 2)));
        _pal.line = hrl_bk_ink();
        var _wp = hrl_map_roles(hrl_wheel_parts(_w, undefined), hrl_mat_map("s"));

        var _bb  = hrl_render_bounds(_wp);
        var _mx  = (_bb[0] + _bb[2]) * 0.5;
        var _my  = (_bb[1] + _bb[3]) * 0.5;
        var _r   = (_bb[3] - _bb[1]) * 0.5;      // outer radius, at the tooth tips

        // -- top band: the rim, close. The framed region is a horizontal slice from just above the
        // tooth tips down into the rim. ⚠️ THE SCALE IS TAKEN FROM THE BAND'S HEIGHT ALONE and the
        // sides are left to the scissor, deliberately: solving it for width as well would be a
        // NON-UNIFORM fit, and a wheel drawn on a non-uniform scale is an ellipse. A rim curve is
        // the one thing on this sheet that has to stay true. How many teeth land in the band is
        // therefore an OUTPUT of the cell's aspect, not a number chosen here - about four and a
        // half at this geometry.
        var _th = _wh * 0.58;
        var _ry0 = _my - _r * 1.05, _ry1 = _my - _r * 0.45;
        var _s   = (_th - 20) / (_ry1 - _ry0);
        gpu_set_scissor(_wx + 1, _wy + 1, _ww - 2, _th);
        hrl_render_parts(_wp, _pal,
                         _wx + _ww * 0.5 - _mx * _s,
                         _wy + _th * 0.5 - (_ry0 + _ry1) * 0.5 * _s,
                         _s, 0, _s, undefined);
        gpu_set_scissor(0, 0, HRL_SHEET_W, HRL_SHEET_H);
        draw_set_colour(hrl_bk_rule());
        draw_rectangle(_wx + 14, _wy + _th, _wx + _ww - 14, _wy + _th + 1, false);

        // -- bottom band: the same wheel, whole, which is what the count is counted off.
        hrl_render_in_rect_tight(_wp, _pal, _wx + 16, _wy + _th + 10, _ww - 32, _wh - _th - 20,
                                 undefined);

        hrl_bk_caption(_names[_i], _cx + _cw * 0.5, _cy + _ch - 34, _cw - 24, 19, hrl_bk_ink());
        // ⛔ COUNTED, NOT ASSUMED. This caption used to read a literal 8 for the lantern because
        // the outline counter cannot see pins - and it printed "24 declared, 8 drawn" on a store
        // sheet, over a picture of twenty-four pins. A caption that asserts a count must count
        // something; see hrl_wheel_count_pins.
        var _drawn = (_i == 3)
            ? hrl_wheel_count_pins(hrl_wheel_parts(_w, undefined), hrl_wheel_pitch_r(_w), _w.N)
            : hrl_wheel_count_tips(hrl_wheel_outline(_w));
        hrl_bk_caption("24 declared, " + string(_drawn) + " drawn",
                       _cx + _cw * 0.5, _cy + _ch - 12, _cw - 24, 14, hrl_bk_dim());
    }
    return _y + _rows * _ch + 10;
}

/// CROSSINGS. Ten openwork patterns, which is the half of a wheel a buyer looks at.
function hrl_bk_crossings() {
    var _y = hrl_bk_head("TEN CROSSING PATTERNS",
        "The rim and the hub are the same on every wheel. The openings are what tell a French "
        + "carriage clock from an English turret clock.", 56);
    var _names = hrl_crossing_names();
    var _cols = 5, _rows = 2;
    var _cw = (HRL_SHEET_W - 120) / _cols;
    var _ch = (HRL_SHEET_H - _y - 110) / _rows;

    for (var _i = 0; _i < HRL_CROSSING_N; _i++) {
        var _cx = 60 + (_i mod _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        hrl_bk_well(_cx + 6, _cy + 6, _cw - 16, _ch - 40);
        var _w = hrl_wheel_new(60, 1.0, 0, _i);
        _w.crossN = 5 + (_i mod 2);
        var _pal = {};
        hrl_mat_into(_pal, "s", hrl_material_spec(0));
        _pal.line = hrl_bk_ink();
        hrl_render_in_rect_tight(hrl_map_roles(hrl_wheel_parts(_w, undefined), hrl_mat_map("s")),
                                 _pal, _cx + 20, _cy + 20, _cw - 44, _ch - 72, undefined);
        hrl_bk_caption(_names[_i], _cx + _cw * 0.5, _cy + _ch - 30, _cw - 20, 17, hrl_bk_ink());
    }
    return _y + _rows * _ch + 10;
}

/// ESCAPEMENTS. The gate, eight ways, each on its own escape wheel.
/// ⛔⛔ THE WHOLE ESCAPE WHEEL IS THE WRONG SUBJECT FOR THIS SHEET, and fitting it is what made the
/// sheet weak. An escapement is a CONTACT: two pallet faces meeting two teeth. Fitting the anchor
/// AND the entire escape wheel into a cell made the wheel the picture and shrank the contact - the
/// thing the sheet is named after - to about twenty pixels, while the middle of every cell was the
/// wheel's own empty crossing. Eight cells of "a gear with something small above it".
///
/// ⭐ So the cell is framed on the WORK instead: from the top of the escapement down through the
/// pallets to just past the escape wheel's centre, and the rest of the wheel is allowed to run out
/// of the bottom of the frame. That is a DETAIL CROP, which is one of the three things a gallery
/// is allowed to do with a subject it has already shown whole (the crossings and mesh sheets both
/// show complete wheels), and it roughly doubles the size of every escapement on the page.
///
/// ⚠️ gpu_set_scissor IS NOT STACKED - the runtime resets it per surface and per viewport, and it
/// is not restored for you. Every cell resets it to the whole sheet before the next thing draws,
/// because hrl_bk_ink_bounds reads this surface back and hrl_render_opaque paints all of it.
function hrl_bk_escapements() {
    var _y = hrl_bk_head("EIGHT ESCAPEMENTS",
        "The part that decides when, framed on the pallets where the work happens. Each is drawn "
        + "at mid swing on the escape wheel it works against, and that wheel runs on below the "
        + "frame.", 56);
    var _names = hrl_escapement_names();
    var _cols = 4, _rows = 2;
    var _cw = (HRL_SHEET_W - 120) / _cols;
    var _ch = (HRL_SHEET_H - _y - 110) / _rows;
    // Crossed out, like the escape wheel hrl_machine builds. A solid one reads as a dark hole in
    // the middle of the cell, which is exactly where the escapement is.
    var _ew = hrl_wheel_new(30, 1.0, 5, 3);
    _ew.crossN = 4;
    _ew.rimw = 0.20;
    // The escape wheel ALONE, measured once: the crop is anchored on the wheel rather than on the
    // combined bounding box, because the combined box moves with the escapement - a foliot bar
    // reaches sideways, a grasshopper's arms reach both ways, a detent reaches down and right - and
    // a frame that moved with it would put the contact somewhere different in all eight cells.
    var _ewp = hrl_wheel_parts(_ew, undefined);
    var _wb  = hrl_render_bounds(_ewp);
    var _wcy = (_wb[1] + _wb[3]) * 0.5;
    var _wr  = (_wb[3] - _wb[1]) * 0.5;

    for (var _i = 0; _i < HRL_ESCAPEMENT_N; _i++) {
        var _cx = 60 + (_i mod _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        var _wx = _cx + 6, _wy = _cy + 6, _ww = _cw - 18, _wh = _ch - 40;
        hrl_bk_well(_wx, _wy, _ww, _wh);

        var _pal = {};
        hrl_mat_into(_pal, "s", hrl_material_spec((_i mod 2 == 0) ? 0 : 7));
        hrl_mat_into(_pal, "j", hrl_material_spec(12));
        _pal.line = hrl_bk_ink();

        var _parts = [];
        hrl_append(_parts, _ewp);
        hrl_append(_parts, hrl_esc_parts(_i, _ew, 0.55, undefined));
        var _mapped = hrl_map_roles(_parts, hrl_mat_map("s"));

        // The framed region, in model space: full width of whatever this escapement reaches to,
        // from its highest point down to a little past the escape wheel's centre.
        var _bb  = hrl_render_bounds(_mapped);
        var _rx0 = _bb[0], _rx1 = _bb[2];
        var _ry0 = min(_bb[1], _wcy - _wr * 1.10);
        var _ry1 = min(_bb[3], _wcy + _wr * 0.34);
        var _s   = min((_ww - 26) / max(0.0001, _rx1 - _rx0),
                       (_wh - 26) / max(0.0001, _ry1 - _ry0));
        gpu_set_scissor(_wx + 1, _wy + 1, _ww - 2, _wh - 2);
        hrl_render_parts(_mapped, _pal,
                         _wx + _ww * 0.5 - (_rx0 + _rx1) * 0.5 * _s,
                         _wy + _wh * 0.5 - (_ry0 + _ry1) * 0.5 * _s,
                         _s, 0, _s, undefined);
        gpu_set_scissor(0, 0, HRL_SHEET_W, HRL_SHEET_H);

        hrl_bk_caption(_names[_i], _cx + _cw * 0.5, _cy + _ch - 30, _cw - 22, 17, hrl_bk_ink());
    }
    return _y + _rows * _ch + 10;
}

/// DIALS. Ten faces, every figure drawn as strokes rather than typeset.
function hrl_bk_dials() {
    var _y = hrl_bk_head("TEN DIALS",
        "Every figure is drawn, not typeset, so it stands up to the centre the way a real dial's "
        + "does and takes the same relief as the metal round it.", 56);
    var _names = hrl_dial_names();
    var _cols = 5, _rows = 2;
    var _cw = (HRL_SHEET_W - 120) / _cols;
    var _ch = (HRL_SHEET_H - _y - 110) / _rows;

    for (var _i = 0; _i < HRL_DIAL_N; _i++) {
        var _cx = 60 + (_i mod _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        hrl_bk_well(_cx + 6, _cy + 6, _cw - 16, _ch - 40);
        var _mat = (_i == 9) ? 0 : ((_i mod 3 == 0) ? 10 : ((_i mod 3 == 1) ? 9 : 0));
        var _pal = {};
        hrl_mat_into(_pal, "s", hrl_material_spec(_mat));
        _pal.line = hrl_bk_ink();
        hrl_render_in_rect_tight(hrl_map_roles(hrl_dial_parts(_i, 20, 1.0, undefined),
                                               hrl_mat_map("s")),
                                 _pal, _cx + 20, _cy + 20, _cw - 44, _ch - 72, undefined);
        hrl_bk_caption(_names[_i], _cx + _cw * 0.5, _cy + _ch - 30, _cw - 20, 17, hrl_bk_ink());
    }
    return _y + _rows * _ch + 10;
}

/// HANDS. Ten forms, large, because a hand is what a player looks directly at.
///
/// ⛔ ONE HAND PER CELL IS A CELL THAT IS EMPTY, and the arithmetic says so before you look. A hand
/// is about twelve to one, and drawing it straight up in a 260x300 cell fits it by HEIGHT: 300
/// tall, forty wide, and the other 85% of the cell is page. Ten of those is a sheet of blue
/// scratches. The density floor cannot object - ink where ink belongs is exactly what it measures -
/// and the sheet was passed by it twice.
///
/// ⭐ SO THE CELL SHOWS THE SET, WHICH IS ALSO HOW HANDS ARE ACTUALLY SOLD AND FITTED. Hour, minute
/// and second of the same form, from one pivot, at 7:06:20 - an angle chosen because those three
/// directions box in a shape about as wide as it is tall, which is the shape of the cell. It fills
/// the frame with the SUBJECT rather than with decoration, and it makes a claim the single hand
/// could not: the form is a program, so it re-derives at any length, and the short hour hand is the
/// same drawing as the long minute hand rather than a scaled copy of it.
function hrl_bk_hands() {
    var _y = hrl_bk_head("TEN HANDS, AS SETS",
        "Hour, minute and second of one form, from one pivot, at 7:06:20. Each is drawn at its own "
        + "length rather than scaled, so the taper and the counterpoise are re-derived every time.",
        56);
    var _names = hrl_hand_names();
    var _cols = 5, _rows = 2;
    var _cw = (HRL_SHEET_W - 120) / _cols;
    var _ch = (HRL_SHEET_H - _y - 110) / _rows;
    // 7:06:20, in degrees clockwise from twelve. hrl_map_pt rotates by RADIANS and screen y runs
    // down, so a positive rotation is the way a clock actually goes.
    var _ang = [213.17, 38.00, 120.00];
    var _len = [6.40, 10.00, 10.80];

    for (var _i = 0; _i < HRL_HAND_N; _i++) {
        var _cx = 60 + (_i mod _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        hrl_bk_well(_cx + 6, _cy + 6, _cw - 16, _ch - 40);
        // ⚠️ BLUED, NOT BLACK-POLISHED. Both are real finishes for a hand and hrl_machine uses
        // blued; drawing this sheet in black polish put ten near-black shapes on a near-black page
        // and the forms could not be told apart. A comparison sheet's job is to make the
        // difference between the ten legible, which is a different job from being representative.
        var _pal = {};
        hrl_mat_into(_pal, "s", hrl_material_spec(7));   // blued steel, as hrl_machine uses
        _pal.line = hrl_bk_ink();
        var _set = [];
        for (var _k = 0; _k < 3; _k++) {
            hrl_append(_set, hrl_place(hrl_hand_parts(_i, _len[_k], 1.0, undefined),
                                       0, 0, 1, degtorad(_ang[_k]), 1, undefined));
        }
        hrl_render_in_rect_tight(hrl_map_roles(_set, hrl_mat_map("s")),
                                 _pal, _cx + 22, _cy + 20, _cw - 48, _ch - 72, undefined);
        hrl_bk_caption(_names[_i], _cx + _cw * 0.5, _cy + _ch - 30, _cw - 20, 17, hrl_bk_ink());
    }
    return _y + _rows * _ch + 10;
}

/// MATERIALS. Fourteen, on one wheel each, so the comparison is controlled.
function hrl_bk_materials() {
    var _y = hrl_bk_head("FOURTEEN MATERIALS",
        "One wheel, fourteen times. Colour is a five stop ramp shaped by a finish program, not a "
        + "tint - so a steel wheel and a brass one shade differently as well as reading "
        + "differently.", 56);
    var _names = hrl_material_names();
    var _cols = 7, _rows = 2;
    var _cw = (HRL_SHEET_W - 120) / _cols;
    var _ch = (HRL_SHEET_H - _y - 110) / _rows;
    var _w = hrl_wheel_new(48, 1.0, 0, 3);
    _w.crossN = 5;
    var _parts = hrl_wheel_parts(_w, undefined);

    for (var _i = 0; _i < HRL_MATERIAL_N; _i++) {
        var _cx = 60 + (_i mod _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        hrl_bk_well(_cx + 4, _cy + 6, _cw - 12, _ch - 40);
        var _pal = {};
        hrl_mat_into(_pal, "s", hrl_material_spec(_i));
        _pal.line = hrl_bk_ink();
        hrl_render_in_rect_tight(hrl_map_roles(_parts, hrl_mat_map("s")), _pal,
                                 _cx + 16, _cy + 18, _cw - 36, _ch - 70, undefined);
        hrl_bk_caption(_names[_i], _cx + _cw * 0.5, _cy + _ch - 30, _cw - 12, 14, hrl_bk_ink());
    }
    return _y + _rows * _ch + 10;
}

/// AGE. The same machine at five ages, which is the transform two products in this wing got wrong.
function hrl_bk_age() {
    var _y = hrl_bk_head("AGE IS A TRANSFORM, NOT A SECOND SET OF ART",
        "One movement at five ages. Tarnish pulls toward a target hue weighted by chroma, so "
        + "near-neutral steel goes straight to brown instead of sweeping through violet.", 56);
    // ⚠️ TWO ROWS, AND THE ONE-ROW VERSION FAILED ITS OWN FLOOR HONESTLY. Five wide cells over the
    // full page height gave each machine a 296x680 slot; a movement is about 6:7, so it fitted by
    // WIDTH and filled half the available height. contentH read 0.712 against a floor of 0.80 and
    // the sheet was correctly marked not ok. Splitting into a row of machines and a row of single
    // wheels at large scale fills the page AND says more: the top row shows what age does to a
    // whole movement, the bottom shows what it does to the metal.
    var _ages = [0.0, 0.25, 0.5, 0.75, 1.0];
    var _cw = (HRL_SHEET_W - 120) / 5;
    var _avail = HRL_SHEET_H - _y - 60;
    var _h1 = _avail * 0.58;
    var _h2 = _avail * 0.42;

    for (var _i = 0; _i < 5; _i++) {
        var _cx = 60 + _i * _cw;
        hrl_bk_well(_cx + 6, _y + 4, _cw - 16, _h1 - 34);
        var _mach = hrl_machine_new(2, 0, 9);
        _mach.age = _ages[_i];
        _hrl_mach_palette(_mach);
        hrl_machine_set_time(_mach, 10, 9, 36);
        hrl_render_in_rect_tight(hrl_machine_movement_parts(_mach), _mach.pal,
                                 _cx + 18, _y + 16, _cw - 40, _h1 - 62, undefined);
        hrl_bk_caption("age " + string_format(_ages[_i], 1, 2),
                       _cx + _cw * 0.5, _y + _h1 - 26, _cw - 16, 17, hrl_bk_ink());
    }

    var _y2 = _y + _h1;
    var _w = hrl_wheel_new(48, 1.0, 0, 3);
    _w.crossN = 5;
    var _parts = hrl_wheel_parts(_w, undefined);
    for (var _i = 0; _i < 5; _i++) {
        var _cx = 60 + _i * _cw;
        hrl_bk_well(_cx + 6, _y2 + 4, _cw - 16, _h2 - 34);
        var _pal = {};
        hrl_mat_into(_pal, "s", hrl_mat_aged(hrl_material_spec(0), _ages[_i]));
        _pal.line = hrl_bk_ink();
        hrl_render_in_rect_tight(hrl_map_roles(_parts, hrl_mat_map("s")), _pal,
                                 _cx + 18, _y2 + 14, _cw - 40, _h2 - 60, undefined);
        hrl_bk_caption("polished brass, aged " + string_format(_ages[_i] * 100, 1, 0) + "%",
                       _cx + _cw * 0.5, _y2 + _h2 - 26, _cw - 14, 15, hrl_bk_dim());
    }
    return _y2 + _h2 + 6;
}

/// One band of machines, laid out so that EVERY CELL IS THE WIDTH OF THE THING INSIDE IT.
///
/// ⛔⛔ A UNIFORM GRID IS THE WRONG CONTAINER FOR A CORPUS OF DIFFERENT SHAPES, and this sheet was
/// the proof. Twelve machines in a 4x3 grid gave every one of them a 334x187 LANDSCAPE cell. Ten of
/// the twelve are PORTRAIT - a longcase regulator with its pendulum hung is about 0.65 wide to
/// tall, a turret clock about 0.49 - so hrl_render_in_rect_tight, which scales uniformly and must,
/// fitted them BY HEIGHT to 187px and left two thirds of every cell black. The sheet that exists to
/// show how much is in the package showed twelve small machines in a lot of dark, and two of them
/// (marine chronometer, turret clock) were barely findable at all. Wings/GameMaker/CLAUDE.md
/// already carries the law - a specimen's aspect must match its cell, or a tight fit manufactures
/// dead space - and a fixed grid cannot obey it because the cell is decided before the specimen is
/// measured.
///
/// ⭐ So the specimen is measured FIRST and the cell is cut to it. Every machine in a band is drawn
/// at the SAME HEIGHT (which is what makes it a comparison) and given exactly the width its own
/// bounding box needs, so the widths across the row spell out the shapes of the machines. The row
/// then fills the page by construction rather than by luck.
///
/// _asp is CLAMPED, and the clamp is a typography constraint rather than a drawing one: an
/// unclamped 0.49 turret clock takes a 130px cell, and its caption is wider than that.
/// The height every machine in a band is drawn at: as tall as the band allows, unless the row
/// would then be wider than the page - in which case the WIDTH is what binds. Split out from the
/// drawing pass because the layout has to know both band heights BEFORE it places the first one:
/// on this corpus the width binds both bands, so the bands are shorter than their allowance and
/// the leftover has to be shared out as space rather than left in a heap at the bottom of the page.
function _hrl_bk_mach_band_draw_h(_from, _n, _asp, _maxDrawH) {
    var _sum = 0;
    for (var _k = 0; _k < _n; _k++) _sum += _asp[_from + _k];
    return min(_maxDrawH, ((HRL_SHEET_W - 120) - 18 * _n) / _sum);
}
function _hrl_bk_mach_band_h(_from, _n, _asp, _maxDrawH) {
    return 26 + _hrl_bk_mach_band_draw_h(_from, _n, _asp, _maxDrawH) + 18 + 26;
}

function _hrl_bk_mach_band(_from, _n, _parts, _pals, _asp, _names, _label, _top, _maxDrawH) {
    var _availW = HRL_SHEET_W - 120;
    var _gut    = 18;
    var _sum    = 0;
    for (var _k = 0; _k < _n; _k++) _sum += _asp[_from + _k];
    var _h   = _hrl_bk_mach_band_draw_h(_from, _n, _asp, _maxDrawH);
    var _tot = _h * _sum + _gut * _n;

    hrl_text_line(_label, 60, _top, _availW, 17, hrl_bk_warm(), true);
    var _cy = _top + 26;
    var _x  = 60 + (_availW - _tot) * 0.5;
    for (var _k = 0; _k < _n; _k++) {
        var _i  = _from + _k;
        var _cw = _h * _asp[_i] + _gut;
        hrl_bk_well(_x + 4, _cy, _cw - 8, _h + 18);
        hrl_render_in_rect_tight(_parts[_i], _pals[_i], _x + 12, _cy + 9, _cw - 24, _h, undefined);
        hrl_bk_caption(_names[_i], _x + _cw * 0.5, _cy + _h + 26, _cw - 12, 15, hrl_bk_ink());
        _x += _cw;
    }
    return 26 + _h + 18 + 26;
}

/// MACHINES. All twelve, so the page shows how much is in the package.
function hrl_bk_machines() {
    var _y = hrl_bk_head("TWELVE MACHINES",
        "Each one is a train of real tooth counts, and each cell below is cut to the width of the "
        + "machine standing in it.", 56);
    var _names = hrl_machine_names();

    // ⛔ THE MATERIAL PER MACHINE IS CHOSEN, NOT `_i mod 14`. The modulo version gave the automaton
    // BLACK POLISH and the music box GREY CAST IRON, and on a dark page both machines simply
    // vanished - two of twelve cells were empty-looking on the sheet that exists to show how much
    // is in the package. It also handed a marine chronometer a VERDIGRIS finish, which is a
    // corroded copper patina on the one instrument in the corpus that was kept in a sealed box.
    // The materials below are what each machine would actually have been made of.
    // ⚠️ RE-CHOSEN AFTER LOOKING. Rosewood on the music box and copper on the automaton both came
    // out near-black against a dark page - rosewood because it IS dark, and copper because that
    // machine ages at 0.45 and copper's tarnish target is verdigris green, so it arrived as olive
    // mud. A music box MOVEMENT is brass; the rosewood is its case, which this sheet does not
    // draw. An automaton's jackwork is iron or steel.
    // ⚠️ RE-CHOSEN A SECOND TIME, 2026-09-01, AND FOR THE SAME REASON ONE STEP FURTHER IN. Two
    // cells were still the two hardest to find on the page: the MARINE CHRONOMETER at polished
    // steel and the TURRET CLOCK at grey cast iron are both near-neutral greys sitting on a
    // near-neutral grey well, so they had colour contrast against the page but almost none against
    // their own cell. Both replacements are MORE accurate to the real instrument, not less - a
    // marine chronometer movement is gilt brass in a sealed bowl, and a turret clock's going train
    // is brass wheelwork in an iron frame, which the frame builder already draws.
    var _mats = [0, 5, 1, 0, 1, 5, 1, 2, 0, 6, 7, 6];

    // ---- measure every machine before cutting a single cell -------------------------------------
    // Built ONCE and kept. hrl_machine_new is the expensive call on this sheet, and building each
    // machine twice - once to measure, once to draw - would double the slowest bake in the product.
    var _parts = array_create(HRL_MACHINE_N);
    var _pals  = array_create(HRL_MACHINE_N);
    var _asp   = array_create(HRL_MACHINE_N);
    for (var _i = 0; _i < HRL_MACHINE_N; _i++) {
        var _mach = hrl_machine_new(_i, _mats[_i], 20 + _i);
        hrl_machine_set(_mach, 1234.5);
        _parts[_i] = hrl_machine_movement_parts(_mach);
        _pals[_i]  = _mach.pal;
        var _bb = hrl_render_bounds(_parts[_i]);
        _asp[_i] = clamp((_bb[2] - _bb[0]) / max(0.0001, _bb[3] - _bb[1]), 0.58, 1.90);
    }

    // ---- two bands, because the corpus really is two halves and the subtitle used to say so ------
    // The first six keep time and are tall; the second six do something else with the same wheels
    // and are wide. Giving them separate bands lets each band find its own drawing height instead
    // of averaging the two shapes into one bad compromise.
    var _avail = HRL_SHEET_H - _y - 40;
    var _m1 = _avail * 0.56 - 70;
    var _m2 = _avail * 0.44 - 70;
    var _b1 = _hrl_bk_mach_band_h(0, 6, _asp, _m1);
    var _b2 = _hrl_bk_mach_band_h(6, 6, _asp, _m2);
    // ⚠️ THE SLACK IS SHARED OUT, NOT LEFT AT THE BOTTOM. Both bands come out width-bound on this
    // corpus (six machines side by side is a lot of width), so together they are about 150px
    // shorter than the page allows. Left alone that is one dead strip under the second band - and
    // the ink floor reads it exactly that way, at contentH 0.788 against a floor of 0.80. Pushing
    // most of it between the bands is also the better page: two bands with air between them read
    // as two statements rather than as one block that ran out.
    var _gap = max(8, _avail - _b1 - _b2);
    _hrl_bk_mach_band(0, 6, _parts, _pals, _asp, _names, "SIX THAT KEEP TIME", _y, _m1);
    var _y2 = _y + _b1 + _gap * 0.60;
    _hrl_bk_mach_band(6, 6, _parts, _pals, _asp, _names,
                      "SIX THAT DO SOMETHING ELSE WITH THE SAME WHEELS", _y2, _m2);
    return _y2 + _b2;
}

/// SYSTEM. The arithmetic, printed, beside the machine it produced.
///
/// ⭐ A STORE SHEET THAT PRINTS ITS OWN NUMBERS IS A BETTER INSTRUMENT THAN THE SUITE (wing
/// CLAUDE.md, Muster): the suite asserts what somebody thought to ask, and a printed figure is
/// read by every person who looks at the page. This sheet reads the values back out of the built
/// train rather than restating the spec.
function hrl_bk_system() {
    var _y = hrl_bk_head("THE NUMBERS ARE THE PRODUCT",
        "Read out of a built machine, not typed onto the page.", 56);
    var _mach = hrl_machine_new(0, 0, 1);
    hrl_machine_set_time(_mach, 10, 9, 36);
    var _tr = _mach.train;

    var _lw = HRL_SHEET_W * 0.44;
    hrl_bk_well(60, _y, _lw, HRL_SHEET_H - _y - 90);
    hrl_render_in_rect_tight(hrl_machine_parts(_mach, true), _mach.pal,
                             80, _y + 20, _lw - 40, HRL_SHEET_H - _y - 130, undefined);

    var _tx = 60 + _lw + 50;
    var _ty = _y + 10;
    var _tw = HRL_SHEET_W - _tx - 60;

    hrl_text_line("THE TRAIN", _tx, _ty, _tw, 20, hrl_bk_warm(), true);
    _ty += 36;
    var _na = array_length(_tr.arbors);
    for (var _i = 0; _i < _na; _i++) {
        var _a = _tr.arbors[_i];
        var _parts_s = "";
        if (!is_undefined(_a.pinion)) _parts_s += "pinion " + string(_a.pinion.N) + "   ";
        if (!is_undefined(_a.wheel))  _parts_s += "wheel " + string(_a.wheel.N) + "   ";
        if (!is_undefined(_a.extra))  _parts_s += "cannon " + string(_a.extra.N);
        hrl_text_line(_a.label, _tx, _ty, _tw * 0.30, 16, hrl_bk_ink(), false);
        hrl_text_line(_parts_s, _tx + _tw * 0.30, _ty, _tw * 0.40, 16, hrl_bk_dim(), false);
        hrl_text_line(_hrl_bk_rate(_a.turns), _tx + _tw * 0.70, _ty, _tw * 0.30, 16,
                      hrl_bk_ink(), false);
        _ty += 26;
    }

    _ty += 24;
    hrl_text_line("WHAT FOLLOWS", _tx, _ty, _tw, 20, hrl_bk_warm(), true);
    _ty += 36;
    var _rows = [
        ["escape wheel", string(_tr.arbors[_mach.escape].wheel.N) + " teeth"],
        ["beat", string_format(_tr.beat, 1, 3) + " s  (derived, not chosen)"],
        ["pendulum", "seconds pendulum, because the beat is one second"],
        ["hour : minute", string_format(1 / max(0.000001, abs(hrl_train_ratio(_tr, _mach.centre, _mach.hour))), 1, 1) + " : 1"],
        ["motion work", "10 / 30 then 8 / 32, both centres 20 modules"],
    ];
    for (var _i = 0; _i < array_length(_rows); _i++) {
        hrl_text_line(_rows[_i][0], _tx, _ty, _tw * 0.36, 16, hrl_bk_dim(), false);
        hrl_text_line(_rows[_i][1], _tx + _tw * 0.36, _ty, _tw * 0.64, 16, hrl_bk_ink(), false);
        _ty += 26;
    }

    _ty += 24;
    hrl_text_line("READ OFF THE ARBORS", _tx, _ty, _tw, 20, hrl_bk_warm(), true);
    _ty += 36;
    var _read = hrl_machine_read(_mach);
    var _names = variable_struct_get_names(_read);
    for (var _i = 0; _i < array_length(_names); _i++) {
        hrl_text_line(_names[_i], _tx, _ty, _tw * 0.36, 16, hrl_bk_dim(), false);
        hrl_text_line(string_format(variable_struct_get(_read, _names[_i]), 1, 2),
                      _tx + _tw * 0.36, _ty, _tw * 0.64, 16, hrl_bk_ink(), false);
        _ty += 26;
    }
    return max(_ty, _y + HRL_SHEET_H - _y - 80);
}

/// A rate, in whatever unit reads best for its magnitude.
function _hrl_bk_rate(_turns) {
    var _t = abs(_turns);
    if (_t <= 0) return "-";
    var _period = 1 / _t;
    if (_period < 90) return string_format(_period, 1, 2) + " s / turn";
    if (_period < 5400) return string_format(_period / 60, 1, 2) + " min / turn";
    return string_format(_period / 3600, 1, 2) + " h / turn";
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

function hrl_bk_one(_name, _fn, _contentY) {
    var _surf = surface_create(HRL_SHEET_W, HRL_SHEET_H);
    surface_set_target(_surf);
    draw_clear(hrl_bk_page());
    hrl_lamp_reset();

    var _endY = _fn();
    var _ib = hrl_bk_ink_bounds(HRL_SHEET_W, HRL_SHEET_H, _contentY);
    hrl_render_opaque(HRL_SHEET_W, HRL_SHEET_H);

    surface_reset_target();
    surface_save(_surf, "sheet_" + _name + ".png");
    surface_free(_surf);

    var _clipped = (_endY > HRL_SHEET_H) || (_ib.full[3] >= HRL_SHEET_H - 6)
                || (_ib.full[2] >= HRL_SHEET_W - 6) || (_ib.full[0] <= 5) || (_ib.full[1] <= 5);
    var _cw = (_ib.content[2] - _ib.content[0]) / HRL_SHEET_W;
    var _chh = (_ib.content[3] - _ib.content[1]) / max(1, HRL_SHEET_H - _contentY);

    return "{\"name\":\"" + _name + "\""
         + ",\"endY\":" + string(round(_endY))
         + ",\"ink\":" + string(_ib.ink)
         + ",\"fullBox\":[" + string(_ib.full[0]) + "," + string(_ib.full[1]) + ","
                            + string(_ib.full[2]) + "," + string(_ib.full[3]) + "]"
         + ",\"contentW\":" + string_format(_cw, 1, 3)
         + ",\"contentH\":" + string_format(_chh, 1, 3)
         + ",\"clipped\":" + (_clipped ? "true" : "false")
         // ⚠️ THE INK FLOOR IS 12000 HERE AND IT IS 40000 ON A PRODUCT THAT DRAWS SOLID OBJECTS.
         // A movement is mostly holes: six crossings, a skeleton frame and a pierced dial are more
         // page than metal, and that is what the subject LOOKS LIKE. Keeping the donor's floor
         // would have made every correct sheet red, and a floor tuned until the right answers
         // appear is not a floor - so it is set from what the subject can physically produce and
         // said out loud rather than quietly lowered.
         + ",\"ok\":" + ((!_clipped && _cw >= 0.86 && _chh >= 0.80 && _ib.ink > 12000)
                         ? "true" : "false")
         + "}";
}

/// ============================================================================================
/// THE COVER
///
/// ⚠️ 630x500 IS ITCH'S COVER SIZE and the cover is the only image most buyers ever see. It is
/// baked at its own size rather than cropped out of a sheet, because a cropped sheet is exactly
/// what a cover must not be.
///
/// ⭐ ONE SUBJECT, LARGE, WITH THE REST SUPPORTING IT. A row of small wheels reads as a shelf of
/// unrelated things and goes to mud at the 315 px thumbnail itch actually shows. So: one large
/// meshing PAIR takes the frame - a big wheel and its pinion, teeth engaged, which is unmistakably
/// CLOCKWORK at any size - with the movement behind it out of focus by being smaller and darker,
/// and the title over the frame's own dark corner rather than on a band.
/// ============================================================================================

#macro HRL_COVER_W 630
#macro HRL_COVER_H 500

function hrl_bk_cover() {
    var _pal = {};
    hrl_mat_into(_pal, "s", hrl_material_spec(0));
    hrl_mat_into(_pal, "j", hrl_material_spec(12));
    _pal.line = hrl_bk_ink();

    // ⛔ THE BACKGROUND MOVEMENT USES A SKELETON FRAME AND A HEAVY SCRIM, AND THE FIRST VERSION
    // USED NEITHER. It drew a full-plate movement blown up past the frame edges, so a large flat
    // brass PLATE filled the whole cover and a 0.52 scrim over it produced a uniform mid grey - the
    // dark page never appeared at all, the title band read as a grey sticker, and the foreground
    // wheel sat on cardboard. A skeleton frame is mostly holes, so the page shows through it, and
    // 0.80 pushes what is left back where a background belongs.
    // ⛔ FRAME 2, THE PILLAR FRAME, BECAUSE IT IS THE ONLY ONE THAT IS GENUINELY OPEN. The previous
    // attempt used the SKELETON frame on the reasoning that "a skeleton frame is mostly holes" -
    // and that was wrong about this package's own code: hrl_frame case 3 fills a shaped plate and
    // then sinks a panel into it, so it is a solid, and blown up past the cover's edges it painted
    // the entire canvas. A 0.80 scrim over a full-canvas brass plate is not a dark page, it is a
    // grey one, which is exactly what the cover came back as - twice, because the first diagnosis
    // blamed the scrim without reading the frame it was scrimming.
    //
    // ⭐ The lesson is small and general: BEFORE BLAMING THE THING ON TOP, CHECK WHAT IS
    // UNDERNEATH. The scrim was correct in both versions.
    var _bg = hrl_machine_new(0, 5, 7);
    _bg.frame = 2;
    hrl_machine_set(_bg, 900);
    hrl_render_in_rect_tight(hrl_machine_movement_parts(_bg), _bg.pal,
                             -70, 30, HRL_COVER_W + 140, HRL_COVER_H + 30, undefined);
    hrl_render_scrim(0, 0, HRL_COVER_W, HRL_COVER_H, hrl_bk_page(), 0.74);

    // The meshing pair in front.
    var _tr = hrl_train_new(1.0);
    var _wa = hrl_wheel_new(72, 1.0, 0, 3); _wa.crossN = 6;
    var _wb = hrl_wheel_new(12, 1.0, 0, 0);
    var _ia = hrl_train_add(_tr, _wa, undefined, "a");
    var _ib = hrl_train_add(_tr, undefined, _wb, "b");
    hrl_train_root(_tr, _ia, 0, 0, 1 / 30, 0.22);
    hrl_train_mesh(_tr, _ia, "wheel", _ib, "pinion", -0.72, HRL_MESH_EXTERNAL);
    hrl_train_set(_tr, 2.4);

    var _parts = [];
    hrl_append(_parts, hrl_place(hrl_wheel_parts(_wa, undefined),
                                 _tr.arbors[_ia].x, _tr.arbors[_ia].y, 1,
                                 hrl_arbor_angle(_tr, _ia), 1, undefined));
    hrl_append(_parts, hrl_place(hrl_wheel_parts(_wb, undefined),
                                 _tr.arbors[_ib].x, _tr.arbors[_ib].y, 1,
                                 hrl_arbor_angle(_tr, _ib), 1, undefined));
    hrl_render_in_rect_tight(hrl_map_roles(_parts, hrl_mat_map("s")), _pal,
                             36, 24, HRL_COVER_W - 72, HRL_COVER_H - 150, undefined);

    // One scrim at the bottom only, so the title sits on the picture rather than on a sticker.
    hrl_render_scrim(0, HRL_COVER_H - 132, HRL_COVER_W, 132, hrl_bk_page(), 0.80);
    hrl_text_label("HOROLOGE", 34, HRL_COVER_H - 116, HRL_COVER_W - 68, 54,
                   hrl_bk_page(), hrl_bk_ink());
    hrl_text_line("Clockwork that draws itself from its own tooth counts",
                  36, HRL_COVER_H - 52, HRL_COVER_W - 72, 20, hrl_bk_dim(), false);
    hrl_text_line("GameMaker  .  GML  .  no sprites",
                  36, HRL_COVER_H - 26, HRL_COVER_W - 72, 15, hrl_bk_warm(), false);
}

function hrl_bake_cover() {
    var _surf = surface_create(HRL_COVER_W, HRL_COVER_H);
    surface_set_target(_surf);
    draw_clear(hrl_bk_page());
    hrl_lamp_reset();
    hrl_bk_cover();
    var _ib = hrl_bk_ink_bounds(HRL_COVER_W, HRL_COVER_H, 0);
    hrl_render_opaque(HRL_COVER_W, HRL_COVER_H);
    surface_reset_target();
    surface_save(_surf, "cover.png");
    surface_free(_surf);
    return "{\"name\":\"cover\",\"ink\":" + string(_ib.ink)
         + ",\"ok\":" + ((_ib.ink > 12000) ? "true" : "false") + "}";
}

/// ============================================================================================
/// THE ANIMATION
///
/// ⭐ THIS PRODUCT IS THE ONE IN THE CATALOGUE THAT MOST NEEDS A MOVING IMAGE, AND THE WING'S OWN
/// devlog records a demo GIF as owed. Every other product here draws a still object; this one
/// draws a machine, and a still picture of a machine is exactly the thing it is sold against.
///
/// Frames are baked at a FIXED time step rather than at whatever the runtime managed, so the GIF
/// is deterministic and the seconds hand steps on the frame it should.
/// ============================================================================================

#macro HRL_GIF_W      520
#macro HRL_GIF_H      520
#macro HRL_GIF_FRAMES 72
#macro HRL_GIF_STEP   0.125

/// ⛔ FRAMED ON THE ESCAPEMENT, NOT ON THE WHOLE MOVEMENT, AND THE WHOLE-MOVEMENT VERSION WAS A
/// PICTURE OF NOTHING HAPPENING. Nine seconds of simulated time is what 72 frames at an eighth of
/// a second covers, and in nine seconds a regulator's great wheel turns 0.03 of a revolution. The
/// GIF was a still photograph with a faint wobble at the bottom.
///
/// ⭐ ALL THE MOTION IN A CLOCK IS AT THE ESCAPEMENT, and that is not a limitation of this product
/// - it is what a clock is. The escape wheel steps one half tooth every second, the pallets rock,
/// the pendulum sweeps between them. Framed on those, nine seconds is nine visible ticks, which is
/// the single most recognisable motion in horology. The great wheels stay in shot at the edges and
/// creep, which is correct and is worth seeing.
///
/// ⚠️ The view is placed by hand rather than by hrl_render_in_rect_tight, because "fit everything"
/// is exactly the wrong instruction here: it is what produced the still photograph.
function hrl_bake_frames() {
    var _mach = hrl_machine_new(0, 0, 5);
    hrl_machine_set_time(_mach, 10, 9, 36);
    var _t0 = _mach.train.t;

    var _tr = _mach.train;
    var _b = hrl_train_bounds(_tr);
    var _span = max(_b.x1 - _b.x0, _b.y1 - _b.y0);
    var _ea = _tr.arbors[_mach.escape];
    // Scale so a little over a third of the movement fills the frame, centred a touch below the
    // escape arbor so the anchor, the escape wheel and the wheel driving it are all in shot.
    var _sc = HRL_GIF_W / (_span * 0.52);
    var _vx = HRL_GIF_W * 0.5 - _ea.x * _sc;
    var _vy = HRL_GIF_H * 0.44 - _ea.y * _sc;

    for (var _i = 0; _i < HRL_GIF_FRAMES; _i++) {
        hrl_machine_set(_mach, _t0 + _i * HRL_GIF_STEP);
        var _surf = surface_create(HRL_GIF_W, HRL_GIF_H);
        surface_set_target(_surf);
        draw_clear(hrl_bk_page());
        hrl_lamp_reset();
        hrl_render_parts(hrl_machine_movement_parts(_mach), _mach.pal,
                         _vx, _vy, _sc, 0, _sc, undefined);
        hrl_render_opaque(HRL_GIF_W, HRL_GIF_H);
        surface_reset_target();
        // ⛔ PAD BY ARITHMETIC, NEVER BY REPLACING WHITESPACE IN A FORMATTED STRING (wing
        // CLAUDE.md §4). string_replace(string_format(i,3,0), " ", "0") replaces ONE space, so
        // "  0" becomes "0 0" and ffmpeg finds no sequence - while a frame-count check upstream
        // still reads the right number, because it globs and counts and every name is wrong.
        var _n = string(_i);
        while (string_length(_n) < 3) _n = "0" + _n;
        surface_save(_surf, "frame_" + _n + ".png");
        surface_free(_surf);
    }
    return "{\"name\":\"frames\",\"count\":" + string(HRL_GIF_FRAMES)
         + ",\"step\":" + string_format(HRL_GIF_STEP, 1, 3) + "}";
}

/// ============================================================================================
/// BAKE EVERYTHING
///
/// ⛔ THE REPORT IS WRITTEN EVEN WHEN A SHEET FAILS ITS OWN CHECK. A baker that stops on the first
/// failure tells you about one defect per build, and an Igor build is not free - so a package with
/// six clipped sheets would cost six builds to find. All of them, every run.
/// ============================================================================================

function hrl_bake_all() {
    global.hrl_stage = 200;
    var _out = [];
    array_push(_out, hrl_bk_one("hero",        hrl_bk_hero,        150));
    array_push(_out, hrl_bk_one("mesh",        hrl_bk_mesh,        170));
    array_push(_out, hrl_bk_one("teeth",       hrl_bk_teeth,       160));
    array_push(_out, hrl_bk_one("crossings",   hrl_bk_crossings,   180));
    array_push(_out, hrl_bk_one("escapements", hrl_bk_escapements, 170));
    array_push(_out, hrl_bk_one("dials",       hrl_bk_dials,       180));
    array_push(_out, hrl_bk_one("hands",       hrl_bk_hands,       160));
    array_push(_out, hrl_bk_one("materials",   hrl_bk_materials,   190));
    array_push(_out, hrl_bk_one("age",         hrl_bk_age,         190));
    array_push(_out, hrl_bk_one("machines",    hrl_bk_machines,    160));
    array_push(_out, hrl_bk_one("system",      hrl_bk_system,      140));
    array_push(_out, hrl_bake_cover());
    array_push(_out, hrl_bake_frames());

    var _f = file_text_open_write("hrl_bake.json");
    var _s = "{\"sheets\":[";
    for (var _i = 0; _i < array_length(_out); _i++) {
        if (_i > 0) _s += ",";
        _s += _out[_i];
    }
    _s += "],\"version\":\"" + HRL_VERSION + "\"}";
    file_text_write_string(_f, _s);
    file_text_close(_f);
    global.hrl_stage = 299;
}
