{
  "$GMScript": "v1",
  "%Name": "hrl_escapement",
  "name": "hrl_escapement",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}