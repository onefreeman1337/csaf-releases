/// HOROLOGE - hrl_escapement. The part that decides WHEN, and the oscillator that tells it.
///
/// ============================================================================================
/// AN ESCAPEMENT IS A GATE, AND IT IS WHY A MECHANISM LOOKS ALIVE
///
/// The weight or the spring pulls all the time. The escapement lets the train forward one half
/// tooth per beat and holds it the rest of the time. Everything a viewer recognises as clockwork
/// comes from that one fact: the seconds hand JUMPS, the wheels advance in steps, and the
/// pendulum swings smoothly through it all.
///
/// ⭐ SO THE PENDULUM AND THE TRAIN ARE DRIVEN FROM THE SAME CLOCK AND MOVE DIFFERENTLY, and that
/// is the single most valuable line in this file. hrl_train quantises `tick_t` to the beat, and
/// every wheel is a function of it. The oscillator here reads the CONTINUOUS `t` instead, so it
/// sweeps. Both come from the same number, so they cannot drift apart:
///
///     swing = sin(pi * t / beat)
///
/// which is zero exactly when t is a whole number of beats - i.e. the pendulum is passing through
/// the bottom of its arc at the instant the train is released, which is where a real escapement
/// gives its impulse. The relationship is not decoration; it is what makes the picture legible as
/// a machine rather than as two animations playing near each other.
///
/// ⛔ A SEPARATE `pendulum_angle` VARIABLE ACCUMULATING ITS OWN PHASE WOULD DRIFT, and it would
/// take hours of play to show. See hrl_train's header: one quantity, derived everywhere, because
/// two copies of one fact is the trap this wing keeps paying for.
/// ============================================================================================

#macro HRL_ESCAPEMENT_N 8
#macro HRL_OSC_N        6

/// ============================================================================================
/// THE EIGHT ESCAPEMENTS
///
/// ⚠️ ALL EIGHT ADVANCE THE ESCAPE WHEEL BY HALF A TOOTH PER BEAT, and that uniformity is a
/// SIMPLIFICATION which is stated rather than hidden. It is exactly right for the verge, the
/// anchor, the deadbeat, the cylinder, the lever and the pin-pallet - two beats per tooth, one at
/// each pallet. The grasshopper and the chronometer detent are more complicated in ways that do
/// not change the count over a full vibration, so the rate is honest even where the mechanism is
/// abbreviated. The duplex genuinely locks twice per tooth on two different tooth sets, which this
/// draws but does not separately time. A buyer counting teeth against seconds will find the
/// arithmetic correct in every case; a horologist looking closely at the duplex will find it
/// simplified, and this comment is here so they know it was a choice.
/// ============================================================================================

/// What fraction of a full turn of the escape wheel the two pallets embrace.
///
/// ⚠️ RE-TUNED AFTER THE FIRST BAKE. These read three times too large: 0.34 of a turn is 122
/// degrees, which put the pallets at almost the full width of the wheel and made every anchor an
/// enormous chevron. A recoil anchor embraces about a quarter of the wheel and a deadbeat a fifth,
/// which is what these are now - and the difference between the two is now visible on the sheet,
/// which is the whole reason both are in the corpus.
function hrl_esc_span(_kind) {
    switch (clamp(_kind, 0, HRL_ESCAPEMENT_N - 1)) {
        case 0: return 0.44;   // verge: flags either side of a crown wheel, so genuinely wide
        case 1: return 0.25;   // anchor: the classic clock embrace
        case 2: return 0.19;   // deadbeat: tighter, with dead faces
        case 3: return 0.30;   // grasshopper: two long arms
        case 4: return 0.06;   // cylinder: tiny, right on the wheel
        case 5: return 0.08;   // duplex
        case 6: return 0.10;   // detent
        default: return 0.21;  // pin-pallet lever
    }
}

/// How far the pallet assembly swings, in radians, at full amplitude.
function hrl_esc_amplitude(_kind) {
    switch (clamp(_kind, 0, HRL_ESCAPEMENT_N - 1)) {
        case 0: return 0.52;
        case 1: return 0.13;
        case 2: return 0.10;
        case 3: return 0.16;
        case 4: return 0.90;
        case 5: return 0.80;
        case 6: return 0.35;
        default: return 0.17;
    }
}

/// Whether the escapement sits ABOVE the escape wheel (a clock anchor) or ON it (a cylinder).
function hrl_esc_offset(_kind) {
    switch (clamp(_kind, 0, HRL_ESCAPEMENT_N - 1)) {
        case 4: return 0.00;   // cylinder: the balance staff is the escapement
        case 5: return 0.00;
        default: return 1.00;  // a fraction of the escape wheel's tip radius, above the centre
    }
}

/// The pallet assembly, in machine units, positioned relative to the escape wheel's arbor at
/// (0,0). `_swing` runs -1 to 1.
///
/// ⚠️ EVERY ARM IS BUILT AS A CLOSED OUTLINE AND RAISED, never as a stroked line. A stroked arm
/// has no lit side, and hrl_render floors strokes at one pixel, so at HUD size a stroked
/// escapement would be a tangle of identical hairlines while a raised one still reads as a
/// mechanism. This is the same reason hrl_wheel builds one closed ring instead of N teeth.
function hrl_esc_parts(_kind, _esc_wheel, _swing, _map) {
    if (!hrl_is_wheel(_esc_wheel)) return [];
    if (is_undefined(_kind) || !is_real(_kind)) { _kind = 0; }
    if (is_undefined(_swing) || !is_real(_swing)) { _swing = 0; }
    var _rt = hrl_wheel_tip_r(_esc_wheel);
    var _m = _esc_wheel.module;
    var _k = clamp(_kind, 0, HRL_ESCAPEMENT_N - 1);
    var _sw = clamp(_swing, -1, 1) * hrl_esc_amplitude(_k);
    var _piv_y = -_rt * (1 + hrl_esc_offset(_k) * 0.62);
    var _out = [];

    // ⛔⛔ `_u` IS THE ESCAPEMENT'S UNIT AND IT COMES FROM THE WHEEL, NOT FROM THE MODULE. Every
    // size in this function was originally a multiple of `_m`, the tooth size, and that is the
    // wrong ruler: an escape wheel of thirty teeth is thirty modules across, so a part measured in
    // tenths of a module is a hairline on it. The first bake showed it on six of eight cells - a
    // verge whose flags were invisible, a cylinder smaller than the collet it sat on, a detent
    // that read as a stray pencil line beside the wheel, and a grasshopper with two hairs where
    // its arms should be. An escapement is proportioned against the WHEEL IT WORKS ON, which is
    // also why a turret clock's anchor is a foot long and a watch's is four millimetres.
    var _u = _rt * 0.085;

    switch (_k) {

        // -- 0. VERGE AND FOLIOT. The oldest of them: a vertical staff crossing the crown wheel,
        // with two flag pallets set about a right angle apart. It is a bad timekeeper and a
        // wonderful thing to look at, which is exactly the trade a game wants.
        // ⚠️ THE FLAGS SIT AT THE RIM, NOT NEAR THE CENTRE, AND THE FIRST VERSION PUT THEM AT 0.62
        // OF THE TIP RADIUS - well inside the wheel, where there are no teeth to engage and where
        // the collet hides them. A verge's flags work against the crown wheel's TEETH, so that is
        // where they are drawn, and the whole assembly is now legible as an escapement rather than
        // as a line ruled across a gear.
        case 0: {
            var _staff = hrl_bar_pts(0, -_rt * 1.45, 0, _rt * 1.45, _u * 0.55, _sw, 0, 0);
            hrl_append(_out, hrl_raise(_staff, _u * 0.30, 2, "m3"));
            var _f1 = _hrl_esc_flag(0, -_rt * 0.92, _rt * 0.34, _u * 0.62, _sw + 0.20);
            var _f2 = _hrl_esc_flag(0,  _rt * 0.92, _rt * 0.34, _u * 0.62, _sw - 1.37);
            hrl_append(_out, hrl_raise(_f1, _u * 0.34, 2, "m4"));
            hrl_append(_out, hrl_raise(_f2, _u * 0.34, 2, "m4"));
            hrl_append(_out, hrl_boss(0, 0, _u * 1.1, 12));
        } break;

        // -- 1. ANCHOR, RECOIL. The shape everyone recognises from a longcase clock. Its pallets
        // embrace several teeth and each entering tooth pushes the anchor BACKWARDS slightly
        // before it drops - the recoil, which you can see in the seconds hand of a real one.
        case 1: {
            var _span1 = HRL_TAU * hrl_esc_span(_k);
            hrl_append(_out, _hrl_esc_anchor(_piv_y, _rt, _m, _span1, _sw, 0.0, "m3", "m0"));
        } break;

        // -- 2. DEADBEAT (GRAHAM). An anchor whose pallet faces are cut as arcs about the pivot,
        // so a locked tooth slides on a face that does not move it - no recoil at all. The visible
        // difference is a seconds hand that stops DEAD instead of shivering back.
        case 2: {
            var _span2 = HRL_TAU * hrl_esc_span(_k);
            hrl_append(_out, _hrl_esc_anchor(_piv_y, _rt, _m, _span2, _sw, 1.0, "m3", "m0"));
        } break;

        // -- 3. GRASSHOPPER. Harrison's: two pivoted arms that catch the wheel in turn and are
        // thrown clear by it, so nothing ever slides and it needs no oil. Drawn as the anchor's
        // frame with two hinged arms hanging from it.
        case 3: {
            var _span3 = HRL_TAU * hrl_esc_span(_k);
            hrl_append(_out, _hrl_esc_anchor(_piv_y, _rt, _m, _span3, _sw * 0.5, 0.4, "m2", "m1"));
            // The two pivoted catches. They hang from the frame and are thrown clear by the
            // wheel, which is why they are drawn as separate arms with their own pivots rather
            // than as part of the body.
            var _ax = sin(_sw) * _rt * 0.55;
            var _a1 = hrl_bar_pts(-_rt * 0.60 + _ax, _piv_y + _u * 1.6,
                                  -_rt * 0.46, -_rt * 0.98, _u * 0.42, 0, 0, 0);
            var _a2 = hrl_bar_pts(_rt * 0.60 + _ax, _piv_y + _u * 1.6,
                                  _rt * 0.46, -_rt * 0.98, _u * 0.42, 0, 0, 0);
            hrl_append(_out, hrl_raise(_a1, _u * 0.26, 2, "m4"));
            hrl_append(_out, hrl_raise(_a2, _u * 0.26, 2, "m4"));
            hrl_append(_out, hrl_boss(-_rt * 0.60 + _ax, _piv_y + _u * 1.6, _u * 0.6, 10));
            hrl_append(_out, hrl_boss(_rt * 0.60 + _ax, _piv_y + _u * 1.6, _u * 0.6, 10));
        } break;

        // -- 4. CYLINDER. No lever and no pallets: the balance staff itself is a hollow steel
        // cylinder with a slot cut in it, and the escape teeth pass through the slot one at a
        // time. Drawn ON the wheel, because that is where it is.
        // ⚠️ ON THE RIM, NOT AT THE ARBOR. The first version put the cylinder at the wheel's
        // centre, where the collet drew straight over it and the whole escapement was invisible.
        // A cylinder escapement's staff stands beside the escape wheel and its teeth pass THROUGH
        // the slot, so it belongs where the teeth are.
        case 4: {
            var _cr = _rt * 0.26;
            var _cyy = -_rt - _cr * 0.30;
            var _ring = hrl_ellipse_pts(0, _cyy, _cr, _cr, 30);
            hrl_append(_out, hrl_raise(_ring, _cr * 0.34, 3, "m3"));
            // The slot, cut across the cylinder and turning with the balance. It is what the
            // escape teeth pass through, so it is drawn as a real opening rather than a scratch.
            var _slot = hrl_bar_pts(cos(_sw - pi * 0.5) * _cr * 1.15, _cyy + sin(_sw - pi * 0.5) * _cr * 1.15,
                                    cos(_sw + pi * 0.5) * _cr * 1.15, _cyy + sin(_sw + pi * 0.5) * _cr * 1.15,
                                    _cr * 0.30, 0, 0, 0);
            hrl_append(_out, hrl_sink(_slot, _cr * 0.16, 2, "m0"));
            hrl_append(_out, hrl_dot(0, _cyy, _cr * 0.20, "m0"));
        } break;

        // -- 5. DUPLEX. Two sets of teeth on one wheel - long locking teeth on the rim and short
        // impulse teeth on the face - and a ruby roller that takes both. Drawn as the roller and
        // its notch.
        // Beside the wheel, for the same reason as the cylinder above.
        case 5: {
            var _rr = _rt * 0.23;
            var _ry = -_rt - _rr * 0.35;
            var _rl = hrl_ellipse_pts(0, _ry, _rr, _rr, 26);
            hrl_append(_out, hrl_raise(_rl, _rr * 0.32, 3, "m2"));
            var _nx = cos(_sw + pi * 0.5) * _rr, _ny = _ry + sin(_sw + pi * 0.5) * _rr;
            hrl_append(_out, hrl_pit(_nx, _ny, _rr * 0.30, 12));
            // The impulse roller: a small jewelled pallet on the same staff, half a turn away.
            hrl_append(_out, hrl_boss(-_nx * 0.55, _ry - (_ny - _ry) * 0.55, _rr * 0.24, 10));
            hrl_append(_out, hrl_dot(0, _ry, _rr * 0.18, "m0"));
        } break;

        // -- 6. DETENT (CHRONOMETER). A spring-mounted detent with a locking stone, unlocked once
        // per double vibration by a passing spring. The most accurate of the eight, and the most
        // fragile - which is a nice thing for a game to know about an object.
        // ⚠️ REDRAWN. The first version ran the blade between two points chosen off the pivot
        // height, which put it up and to the RIGHT of the wheel touching nothing - on the sheet it
        // read as a stray pencil line beside a gear. A detent is a spring blade FIXED TO THE PLATE
        // that reaches in and locks a tooth, so it is drawn from a foot to a point on the wheel's
        // own rim, and the locking stone sits where it actually locks.
        case 6: {
            var _fx = _rt * 1.55, _fy = _rt * 0.35;
            var _la = -1.05;                                   // where on the rim it locks
            var _lx6 = cos(_la) * _rt * 0.99, _ly6 = sin(_la) * _rt * 0.99;
            var _blade = hrl_bar_pts(_fx, _fy, _lx6, _ly6, _u * 0.34, _sw * 0.30, _fx, _fy);
            hrl_append(_out, hrl_raise(_blade, _u * 0.22, 2, "m4"));
            // The passing spring: a finer blade alongside, which is the part that unlocks it.
            var _pass = hrl_bar_pts(_fx, _fy, _lx6 * 0.86, _ly6 * 0.86 + _u * 0.9,
                                    _u * 0.16, _sw * 0.30, _fx, _fy);
            hrl_append(_out, hrl_raise(_pass, _u * 0.12, 2, "m0"));
            var _st6 = hrl_rot_pt(_lx6, _ly6, _fx, _fy, _sw * 0.30);
            hrl_append(_out, hrl_boss(_st6[0], _st6[1], _u * 0.55, 10));
            // The foot, screwed to the plate.
            hrl_append(_out, hrl_boss(_fx, _fy, _u * 1.0, 12));
            hrl_append(_out, hrl_dot(_fx, _fy, _u * 0.34, "m0"));
        } break;

        // -- 7. PIN-PALLET (ROSKOPF). A lever escapement with upright steel PINS instead of jewel
        // pallets. Cheap, robust, and the escapement of every alarm clock ever thrown at a wall.
        // -- 7. PIN-PALLET. The lever body, with upright steel PINS where a jewelled lever would
        // have pallet stones. The pins are placed at the same two points the arms reach, computed
        // the same way, rather than at hand-tuned coordinates - the first version guessed them and
        // put both pins in the same place, which is exactly the kind of thing that survives every
        // assertion and is obvious in a picture.
        default: {
            var _span7 = HRL_TAU * hrl_esc_span(_k);
            hrl_append(_out, _hrl_esc_anchor(_piv_y, _rt, _m, _span7, _sw, 0.2, "m2", "m1"));
            var _px7 = sin(_span7 * 0.5) * _rt * 1.02;
            var _py7 = -cos(_span7 * 0.5) * _rt * 1.02;
            for (var _i = 0; _i < 2; _i++) {
                var _q = hrl_rot_pt((_i == 0) ? -_px7 : _px7, _py7, 0, _piv_y, _sw);
                hrl_append(_out, hrl_boss(_q[0], _q[1], _u * 0.70, 10));
            }
        } break;
    }

    if (is_undefined(_map)) return _out;
    return hrl_map_roles(_out, _map);
}

/// The anchor body: two pallet arms reaching down to the escape wheel from a pivot above it.
///
/// `_dead` runs 0 (recoil, flat impulse faces) to 1 (deadbeat, faces struck as arcs about the
/// pivot). It changes the SHAPE, which is the honest way to show the difference between the two
/// escapements: a deadbeat's pallet faces are concentric with its own pivot and a recoil anchor's
/// are not, and that is the entire mechanical distinction.
/// ⛔⛔ TWO SLIM ARMS, NOT A FILLED TRIANGLE, AND THE TRIANGLE IS WHAT SHIPPED TO THE FIRST BAKE.
///
/// The first version built the body as one closed outline running pivot -> right pallet -> back
/// through the middle -> left pallet -> pivot, and filled it. Every assertion passed: it had parts,
/// it moved with the swing, it sat on the escape wheel. Opening the sheet showed eight escapements
/// drawn as an enormous solid chevron - a paper dart sitting on a gear - because the region between
/// the two arms IS NOT METAL. An anchor is two arms and a boss; the space between them is where
/// you can see the wheel through it, and that space is most of the shape.
///
/// ⚠️ THE SPAN WAS ALSO WRONG BY ABOUT THREE TIMES. hrl_esc_span was read as a fraction of a full
/// turn, so 0.34 embraced 122 degrees of the wheel and the pallets reached almost its full width.
/// A recoil anchor embraces about a quarter of the wheel and a deadbeat rather less. Both numbers
/// are now the arc the pallets actually span, and the difference is visible: a deadbeat looks
/// tighter than an anchor, which is the thing the two sheets are there to show.
function _hrl_esc_anchor(_piv_y, _rt, _m, _span, _swing, _dead, _role_body, _role_pallet) {
    var _out = [];
    // Where the two pallets meet the wheel.
    var _lx = -sin(_span * 0.5) * _rt * 1.02;
    var _rx =  sin(_span * 0.5) * _rt * 1.02;
    var _py = -cos(_span * 0.5) * _rt * 1.02;

    // ⚠️ THE ARMS ARE SIZED FROM THE WHEEL, NOT FROM THE MODULE, AND THE FIRST VERSION USED THE
    // MODULE. An anchor arm at a third of a tooth width is a hairline against a wheel thirty
    // modules across, and on the hero sheet the escapement read as a pencil outline of a triangle.
    // The wheel is the thing an escapement is proportioned against - a big wheel gets a heavy
    // anchor - so that is what it measures itself in.
    var _aw = _rt * 0.085;
    for (var _i = 0; _i < 2; _i++) {
        var _px = (_i == 0) ? _lx : _rx;
        var _arm = [
            [_px + _aw * 0.85, _py + _aw * 0.6],
            [_px - _aw * 0.85, _py + _aw * 0.6],
            [-_aw * 0.9 + _px * 0.10, _piv_y + _aw * 0.5],
            [ _aw * 1.5 + _px * 0.10, _piv_y + _aw * 0.5],
        ];
        var _moved = array_create(4);
        for (var _j = 0; _j < 4; _j++) {
            _moved[_j] = hrl_rot_pt(_arm[_j][0], _arm[_j][1], 0, _piv_y, _swing);
        }
        hrl_append(_out, hrl_raise(_moved, _aw * 0.42, 3, _role_body));
    }

    // The boss the two arms spring from, and its cock.
    var _b = hrl_rot_pt(0, _piv_y, 0, _piv_y, _swing);
    hrl_append(_out, hrl_boss(_b[0], _b[1], _aw * 2.0, 14));

    // The two pallet faces themselves, in hardened steel or jewel, drawn proud of the arms.
    // At _dead = 1 they are struck as arcs about the pivot - the locking face does not move the
    // wheel at all - and at 0 they are angled into it, which is what produces recoil. The SHAPE
    // carries the difference, which is the honest way to draw two escapements that differ in one
    // geometric property and in nothing else.
    for (var _i = 0; _i < 2; _i++) {
        var _px = (_i == 0) ? _lx : _rx;
        var _tilt = ((_i == 0) ? 1 : -1) * lerp(0.55, 0.02, _dead);
        var _face = _hrl_esc_flag(_px, _py, _aw * 2.6, _aw * 0.62, _swing + _tilt);
        var _mv = array_create(array_length(_face));
        for (var _j = 0; _j < array_length(_face); _j++) {
            _mv[_j] = hrl_rot_pt(_face[_j][0], _face[_j][1], 0, _piv_y, _swing);
        }
        hrl_append(_out, hrl_raise(_mv, _aw * 0.34, 2, _role_pallet));
    }

    // The pivot itself, which does NOT move - it is a hole in the plate, and every point above
    // was rotated about it.
    hrl_append(_out, hrl_dot(0, _piv_y, _aw * 0.75, "m0"));
    return _out;
}

/// A pallet flag: a short blade of length _len and half-width _hw, centred at (_cx,_cy), lying at
/// angle _ang.
function _hrl_esc_flag(_cx, _cy, _len, _hw, _ang) {
    var _c = cos(_ang), _s = sin(_ang);
    var _hx = _c * _len * 0.5, _hy = _s * _len * 0.5;
    var _nx = -_s * _hw, _ny = _c * _hw;
    return [
        [_cx - _hx + _nx, _cy - _hy + _ny],
        [_cx + _hx + _nx, _cy + _hy + _ny],
        [_cx + _hx - _nx, _cy + _hy - _ny],
        [_cx - _hx - _nx, _cy - _hy - _ny],
    ];
}

// hrl_rot_pt and hrl_bar_pts live in hrl_wheel - see the note in that file's SHARED MACHINE
// GEOMETRY section. GML scripts are global, so a duplicate definition here would be a compile
// error, and a SECOND copy under a different name would be the shared-fact-with-two-declarations
// trap CLAUDE.md §2b records shipping an out-of-bounds read into four sold cartridges.

/// ============================================================================================
/// THE OSCILLATOR - the thing that actually keeps the time
///
/// ⚠️ A PENDULUM'S PERIOD IS A LENGTH, AND THAT IS A FACT THE PRODUCT CAN SHOW RATHER THAN STATE.
/// A seconds pendulum is about 994 mm; a half-seconds one is a QUARTER of that, not a half,
/// because the period goes as the square root of the length. So the two are drawn at a real 4:1
/// ratio and a player who has seen a longcase clock will find the short one looks right. Nothing
/// in the code needs this - it is drawing - but it is the sort of thing that makes a generated
/// object feel like an object.
/// ============================================================================================

/// Relative length of an oscillator, from its beat, in machine units per unit of drawing scale.
function hrl_osc_length(_osc, _beat) {
    var _b = max(0.02, _beat);
    switch (clamp(_osc, 0, HRL_OSC_N - 1)) {
        case 0: case 1: case 2:
            // l proportional to beat squared. A 1 s beat is the reference length.
            return _b * _b;
        default:
            return 0;   // a balance, a foliot and a fly have no length in this sense
    }
}

/// The oscillator's parts, hanging from (_x, _y), at swing -1..1.
function hrl_osc_parts(_osc, _x, _y, _len, _m, _swing, _map) {
    var _o = clamp(_osc, 0, HRL_OSC_N - 1);
    var _a = clamp(_swing, -1, 1) * 0.16;
    var _out = [];

    switch (_o) {

        // -- 0. SECONDS PENDULUM, brass-faced bob on a wooden rod.
        case 0: {
            hrl_append(_out, _hrl_pend(_x, _y, _len, _m, _a, 1.00, 0));
        } break;

        // -- 1. HALF-SECONDS PENDULUM, lenticular bob. A quarter the length, see the header.
        case 1: {
            hrl_append(_out, _hrl_pend(_x, _y, _len, _m, _a, 0.78, 1));
        } break;

        // -- 2. GRIDIRON. Nine alternating brass and steel rods whose different expansions cancel,
        // so the bob stays put as the room warms. It is the most ornamental-looking thing in
        // horology that exists for a purely physical reason.
        case 2: {
            var _bx = _x + sin(_a) * _len, _by = _y + cos(_a) * _len;
            for (var _i = -4; _i <= 4; _i++) {
                var _fx = _i * _m * 0.42;
                var _t = 1 - abs(_i) * 0.10;
                var _rod = hrl_bar_pts(_x + _fx * 0.3, _y, _bx + _fx, _by * _t, _m * 0.10,
                                        0, 0, 0);
                hrl_append(_out, hrl_raise(_rod, _m * 0.05, 1, (_i mod 2 == 0) ? "m3" : "m1"));
            }
            var _bob = hrl_ellipse_pts(_bx, _by, _m * 2.6, _m * 2.6, 30);
            hrl_append(_out, hrl_raise(_bob, _m * 0.7, 3, "m3"));
            hrl_append(_out, hrl_ring(_bx, _by, _m * 1.7, _m * 0.14, "m1"));
        } break;

        // -- 3. BALANCE WHEEL AND HAIRSPRING. A watch's oscillator: a three-armed wheel with
        // timing screws round its rim, and a flat spiral spring that returns it. The spiral is
        // drawn as a real Archimedean spiral, so its turns are evenly spaced the way a hairspring's
        // are, rather than as a decorative squiggle.
        case 3: {
            var _br = _m * 3.4;
            hrl_append(_out, hrl_ring(_x, _y, _br, _m * 0.30, "m3"));
            for (var _i = 0; _i < 3; _i++) {
                var _ang = HRL_TAU * _i / 3 + _a * 3;
                var _arm = hrl_bar_pts(_x, _y, _x + cos(_ang) * _br, _y + sin(_ang) * _br,
                                        _m * 0.16, 0, 0, 0);
                hrl_append(_out, hrl_raise(_arm, _m * 0.08, 2, "m3"));
            }
            for (var _i = 0; _i < 8; _i++) {
                var _ang2 = HRL_TAU * _i / 8 + _a * 3;
                hrl_append(_out, hrl_boss(_x + cos(_ang2) * _br, _y + sin(_ang2) * _br,
                                          _m * 0.22, 8));
            }
            // The hairspring: r grows linearly with angle, which is what "flat spiral" means.
            var _sp = [];
            var _turns = 4.5;
            var _steps = 64;
            for (var _i = 0; _i <= _steps; _i++) {
                var _u = _i / _steps;
                var _th = _u * HRL_TAU * _turns + _a * 3;
                var _rr2 = _m * 0.5 + _u * _m * 2.1;
                array_push(_sp, [_x + cos(_th) * _rr2, _y + sin(_th) * _rr2]);
            }
            hrl_append(_out, hrl_poly(_sp, false, _m * 0.07, "m0"));
            hrl_append(_out, hrl_dot(_x, _y, _m * 0.30, "m0"));
        } break;

        // -- 4. FOLIOT. A plain bar with two weights that slide along it to regulate. The whole
        // of medieval timekeeping, and it looks exactly as approximate as it was.
        case 4: {
            var _hl = _m * 4.2;
            var _bar = hrl_bar_pts(_x - _hl, _y, _x + _hl, _y, _m * 0.20, _a * 2, _x, _y);
            hrl_append(_out, hrl_raise(_bar, _m * 0.10, 2, "m2"));
            for (var _i = -1; _i <= 1; _i += 2) {
                var _p = hrl_rot_pt(_x + _i * _hl * 0.82, _y, _x, _y, _a * 2);
                hrl_append(_out, hrl_boss(_p[0], _p[1], _m * 0.62, 12));
            }
            hrl_append(_out, hrl_dot(_x, _y, _m * 0.26, "m0"));
        } break;

        // -- 5. FLY. Not a timekeeper at all: two vanes on an arbor that spin fast and are slowed
        // by the air, used to govern a STRIKING train so the hammer blows are evenly spaced. It
        // belongs here because it is the same kind of part - the thing that decides the rate.
        default: {
            var _fl = _m * 3.0;
            for (var _i = 0; _i < 2; _i++) {
                var _ang3 = pi * _i + _swing * pi;
                var _v = [
                    [_x, _y],
                    [_x + cos(_ang3) * _fl, _y + sin(_ang3) * _fl - _m * 0.9],
                    [_x + cos(_ang3) * _fl, _y + sin(_ang3) * _fl + _m * 0.9],
                ];
                hrl_append(_out, hrl_raise(_v, _m * 0.09, 2, "m2"));
            }
            hrl_append(_out, hrl_dot(_x, _y, _m * 0.28, "m0"));
        } break;
    }

    if (is_undefined(_map)) return _out;
    return hrl_map_roles(_out, _map);
}

/// A rod-and-bob pendulum. `_bob_shape` 0 = round brass-faced, 1 = lenticular.
function _hrl_pend(_x, _y, _len, _m, _a, _scale, _bob_shape) {
    var _out = [];
    var _bx = _x + sin(_a) * _len, _by = _y + cos(_a) * _len;
    var _rod = hrl_bar_pts(_x, _y, _bx, _by, _m * 0.13, 0, 0, 0);
    hrl_append(_out, hrl_raise(_rod, _m * 0.06, 2, "m1"));

    var _br = _m * 2.4 * _scale;
    var _bob;
    if (_bob_shape == 0) {
        _bob = hrl_ellipse_pts(_bx, _by, _br, _br, 30);
    } else {
        // Lenticular: a flattened lens, wider than it is deep.
        _bob = hrl_ellipse_pts(_bx, _by, _br * 1.15, _br * 0.62, 30);
    }
    hrl_append(_out, hrl_raise(_bob, _br * 0.30, 3, "m3"));
    hrl_append(_out, hrl_ring(_bx, _by, _br * 0.62, _m * 0.12, "m1"));
    // The rating nut under the bob - how a pendulum is actually adjusted.
    hrl_append(_out, hrl_boss(_bx, _by + _br * 1.16, _m * 0.34, 8));
    return _out;
}
