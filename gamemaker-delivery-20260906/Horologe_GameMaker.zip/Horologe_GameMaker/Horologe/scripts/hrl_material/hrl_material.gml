/// HOROLOGE - hrl_material. What a part is MADE of, expressed as a five-stop ramp.
///
/// ============================================================================================
/// FINISH IS THE SHADING PROGRAM. IT IS NOT A GLOSS SLIDER.
///
/// Every material here carries a COLOUR (hue, saturation, value) and, independently, a FINISH -
/// how the surface answers light. Those are genuinely independent in a workshop and they are kept
/// independent here: brass and steel can both be MIRROR polished at completely different hues, and
/// cast bronze and cast iron are both `cast`. That independence is the whole reason fourteen
/// materials do not collapse into fourteen recolours of one wheel.
///
/// A finish changes FOUR things about the ramp and nothing about the hue:
///
///   span    how far the five stops travel in apparent lightness. Mirror polish swings almost the
///           whole axis, which is why a polished steel plate has a white glint and a near-black
///           shadow on the same surface. Frosted travels 0.18, which is why a matted dial reads as
///           powder however you light it.
///   spec    how the stops are DISTRIBUTED across that span. A distribution warp, never an
///           addition - see the warning below.
///   chroma  how saturation moves from the shadow stop to the lit stop. METALS LOSE chroma as they
///           brighten (a lit brass face goes white, not more yellow); DIELECTRICS GAIN it (a lit
///           face of a ruby jewel is more red than its shadow, because you are seeing through more
///           of it). Getting this backwards is what makes rendered metal look like plastic.
///   drift   a per-stop hue rotation. It is why blued steel and fire-gilt read as having colour IN
///           them rather than being merely dark or merely bright - a blued spring really does run
///           from straw through purple to blue across its own curvature.
///
/// ⛔⛔ `spec` IS A DISTRIBUTION WARP AND NOT A TERM ADDED TO THE TOP STOP, AND THE DIFFERENCE IS A
/// LAW THIS WING PAID FOR (CLAUDE.md, Muster): A TERM ADDED TO A VALUE THAT IS THEN CLAMPED
/// SILENTLY DOES NOTHING AT THE TOP OF ITS RANGE, WHICH IS USUALLY WHERE IT WAS NEEDED. The obvious
/// way to write a specular highlight is to add to stop 4 and clamp to the ceiling; on every bright
/// material in this corpus - white enamel at L 0.93, silvered dial at 0.88, polished steel at 0.72 -
/// stop 4 is already at the ceiling, so the highlight would be arithmetically discarded on exactly
/// the surfaces whose entire identity is that they catch the light. Warping `u` moves the stops
/// apart instead, and cannot be clamped away.
///
/// ⛔ AND THE RAMP SLIDES TO FIT. IT IS NEVER CLAMPED AT ITS ENDS (CLAUDE.md, Hearth): a limewash
/// put its top two stops above the ceiling, both clamped to the same value, and drew a dome as a
/// flat fill with a line round it. White enamel at high `val` is one line of clamping away from the
/// same collapse here, and an enamel dial that reads as a flat white disc is the single most
/// visible way this product could fail.
///
/// ⚠️ TUNED ON THE PALEST AND MOST NEUTRAL MATERIALS, NEVER THE VIVID ONE (CLAUDE.md, Repast). A
/// colour model tuned on the one substance that did not need the missing term looks perfect on that
/// substance and wrong on four others. The reference materials for this table are WHITE ENAMEL
/// (sat 0.03, val 0.96 - almost colourless and almost white) and POLISHED STEEL (sat 0.04, val 0.66
/// - neutral grey), because anything that reads on those reads on brass for free.
/// ============================================================================================

/// ⚠️ HRL_RAMP_N IS DEFINED IN hrl_relief, NOT HERE, AND THAT IS CORRECT RATHER THAN AWKWARD.
/// The number of stops is a property of the RELIEF model - it is how many bands hrl_relief_role
/// quantises a surface normal into - and this file merely produces that many colours. Defining it
/// again here costs an Igor build ("macro HRL_RAMP_N is already defined"), and the fix is not to
/// rename it: two macros with the same meaning is exactly the shared-fact-with-two-declarations
/// trap that CLAUDE.md §2b records shipping an out-of-bounds read into four sold cartridges.

#macro HRL_FINISH_N   8
#macro HRL_MATERIAL_N 14

/// The finish programs. Index-parallel with hrl_finish_names() in hrl_corpus.
function hrl_finish_spec(_finish) {
    switch (clamp(_finish, 0, HRL_FINISH_N - 1)) {
        //                span  spec  cLo   cHi   drift
        case 0: return { span: 0.66, spec: 0.58, cLo: 0.62, cHi: 0.30, drift:   0 };  // mirror
        case 1: return { span: 0.44, spec: 0.24, cLo: 0.80, cHi: 0.60, drift:   0 };  // grained
        case 2: return { span: 0.18, spec: 0.00, cLo: 0.98, cHi: 1.00, drift:   0 };  // frosted
        case 3: return { span: 0.30, spec: 0.10, cLo: 1.00, cHi: 0.86, drift:   0 };  // cast
        case 4: return { span: 0.42, spec: 0.34, cLo: 0.78, cHi: 1.22, drift:   0 };  // lacquered
        // ⚠️ THE BLUED DRIFT WAS 46 AND IT CAME OUT LAVENDER. Bluing really does run straw ->
        // purple -> blue as the steel heats, and putting the whole of that range into one part's
        // ramp means the LIT stops drift 23 degrees past the base hue, which lands a deep navy
        // squarely in violet. A finished blued hand is one temperature, not a scale of them: the
        // colour that survives is the blue, with only a trace of the purple it passed through.
        case 5: return { span: 0.60, spec: 0.40, cLo: 0.70, cHi: 1.05, drift:  18 };  // blued
        case 6: return { span: 0.70, spec: 0.66, cLo: 0.58, cHi: 0.40, drift:  11 };  // gilt
        default: return { span: 0.74, spec: 0.70, cLo: 0.60, cHi: 1.45, drift:   6 }; // jewelled
    }
}

/// ============================================================================================
/// THE FOURTEEN MATERIALS
///
/// ⛔ `corner` IS A PROPERTY OF THE MATERIAL AND NOT OF THE COMPONENT, and hrl_shape's header
/// argues why: if every builder picked its own corner, two machines would differ in colour alone
/// and the whole product would be a palette swap. The corner records how the part was WORKED, and
/// how a part is worked follows from what it is made of and by whom. Cast iron gets square,
/// unbroken edges because a casting is not filed; hand-finished brass gets a chamfer because
/// every hand-finished plate in the world has one.
///
/// `tarnish` is the hue and chroma this material AGES TOWARD, and `ageC` how much chroma it picks
/// up on the way. Copper goes green and gains chroma; steel goes brown-grey and loses it; enamel
/// does not tarnish at all and yellows a little.
/// ============================================================================================

/// One material's specification. Index-parallel with hrl_material_names() in hrl_corpus.
function hrl_material_spec(_m) {
    if (is_undefined(_m) || !is_real(_m)) { _m = 0; }   // clamp() THROWS on undefined
    switch (clamp(_m, 0, HRL_MATERIAL_N - 1)) {
        case  0: return { hue:  86, sat: 0.62, val: 0.66, finish: 0, corner: 1,
                          tarnish:  56, ageC: 0.70, name_i:  0 };  // polished brass
        case  1: return { hue:  78, sat: 0.74, val: 0.72, finish: 6, corner: 1,
                          tarnish:  62, ageC: 0.55, name_i:  1 };  // fire-gilt
        case  2: return { hue:  62, sat: 0.48, val: 0.48, finish: 3, corner: 0,
                          tarnish: 140, ageC: 1.30, name_i:  2 };  // cast bronze
        case  3: return { hue:  38, sat: 0.66, val: 0.56, finish: 0, corner: 1,
                          tarnish: 166, ageC: 1.60, name_i:  3 };  // copper
        case  4: return { hue: 168, sat: 0.44, val: 0.46, finish: 2, corner: 3,
                          tarnish: 168, ageC: 1.00, name_i:  4 };  // verdigris
        case  5: return { hue:  70, sat: 0.30, val: 0.44, finish: 2, corner: 1,
                          tarnish:  52, ageC: 0.80, name_i:  5 };  // patinated brass
        case  6: return { hue: 250, sat: 0.04, val: 0.66, finish: 0, corner: 2,
                          tarnish:  44, ageC: 1.10, name_i:  6 };  // polished steel
        case  7: return { hue: 252, sat: 0.62, val: 0.26, finish: 5, corner: 2,
                          tarnish:  40, ageC: 0.90, name_i:  7 };  // blued steel
        case  8: return { hue: 248, sat: 0.05, val: 0.40, finish: 3, corner: 0,
                          tarnish:  36, ageC: 1.20, name_i:  8 };  // grey cast iron
        case  9: return { hue:  92, sat: 0.06, val: 0.88, finish: 1, corner: 4,
                          tarnish:  74, ageC: 0.85, name_i:  9 };  // silvered dial
        case 10: return { hue:  80, sat: 0.03, val: 0.96, finish: 4, corner: 5,
                          tarnish:  76, ageC: 0.60, name_i: 10 };  // white enamel
        case 11: return { hue: 252, sat: 0.06, val: 0.13, finish: 0, corner: 2,
                          tarnish: 250, ageC: 0.30, name_i: 11 };  // black polish
        case 12: return { hue:  22, sat: 0.95, val: 0.44, finish: 7, corner: 5,
                          tarnish:  22, ageC: 0.10, name_i: 12 };  // ruby jewel
        default: return { hue:  34, sat: 0.60, val: 0.34, finish: 4, corner: 3,
                          tarnish:  30, ageC: 0.50, name_i: 13 };  // figured rosewood
    }
}

/// A material's base colour in Oklch, before the finish shapes it into a ramp.
///
/// ⚠️ THE CORPUS STORES HSV-SHAPED NUMBERS AND THIS IS THE ONE PLACE THEY BECOME PERCEPTUAL. A
/// workshop describes metal in hue/saturation/value terms, so the corpus is authored that way and
/// converted here rather than being authored in a space nobody writes in. The conversion is
/// deliberately compressive at both ends: no material here is pure black or pure white, because no
/// real surface is.
function hrl_mat_base(_sp) {
    return {
        L: 0.09 + 0.82 * clamp(_sp.val, 0, 1),
        C: 0.155 * clamp(_sp.sat, 0, 1),
        h: _sp.hue
    };
}

/// ============================================================================================
/// AGE - the transform that must PULL TOWARD A TARGET, never scale what was there
///
/// ⛔⛔ THIS IS THE FUNCTION TWO PRIOR PRODUCTS IN THIS WING GOT WRONG, IN TWO DIFFERENT WAYS, AND
/// BOTH SHIPPED TO A STORE SHEET BEFORE ANYONE LOOKED.
///
/// (1) Repast browned food by ADDING a hue displacement. For a red meat that lands on amber and
///     looks perfect; for a pale bird it lands on YELLOW-GREEN, and four of twelve dishes came out
///     the colour of a swamp. A transformative process MANUFACTURES its own colour, so it needs a
///     TARGET hue, a TARGET chroma and a strength - never a displacement.
///
/// (2) Armoury implemented the pull correctly and rusting steel still came out MAGENTA, because
///     steel sits at hue 250 and rust at 44, more than half the circle apart. Going the long way
///     runs through green; going the short way runs through violet. There is no third direction.
///     THE ERROR IS UPSTREAM OF THE DIRECTION: polished steel's chroma is 0.006 and does not HAVE a
///     hue anyone can see, so sweeping from it treats an invisible number as a starting appearance
///     while the chroma climbs and makes every intermediate hue visible.
///
/// ⇒ The hue is weighted by CHROMA CONTRIBUTION, never by the transform's own progress. Where the
/// source brings no chroma the target hue applies immediately, which is exactly right: a steel
/// arbor does not pass through violet on its way to brown, it simply starts to look brown.
///
/// ⚠️ THIS PRODUCT HAS THE WORST VERSION OF THAT PROBLEM IN THE CATALOGUE, which is why the law is
/// restated here in full rather than cited. Half these materials are near-neutral (steel C 0.006,
/// enamel C 0.005, silvered C 0.009, iron C 0.008) and half are strongly chromatic (copper C 0.102,
/// gilt C 0.115, ruby C 0.147), and EVERY ageing transform blends between exactly such a pair.
function hrl_mat_aged(_sp, _age) {
    var _a = is_undefined(_age) ? 0 : clamp(_age, 0, 1);
    if (_a <= 0) return _sp;

    var _b = hrl_mat_base(_sp);
    var _Ct = _b.C * _sp.ageC;                 // the chroma the tarnish itself carries

    // ⛔⛔ THE WEIGHTING IS BY *PERCEPTIBLE* CHROMA, AND THE FIRST VERSION WEIGHTED BY RAW CHROMA
    // AND WAS STILL WRONG IN EXACTLY THE WAY THIS FUNCTION EXISTS TO PREVENT.
    //
    // MEASURED by the suite: half-tarnished polished steel came out at hue 330.7 - VIOLET - which
    // is 73 degrees from its brown target and most of the way round the wrong side of the circle.
    // Raw chroma weighting had given it k = 0.52, i.e. a near-perfect half-and-half blend, because
    // steel's chroma (0.006) and its tarnish's (0.007) are COMPARABLE TO EACH OTHER. Both are
    // invisible; the ratio between two invisible quantities is not a fact about appearance.
    //
    // ⭐ Subtracting a visibility floor first is what makes the weighting mean what its comment
    // says. Below about 0.012 in Oklab chroma a hue is not a colour anyone can see, it is a
    // direction the ramp leans - so it contributes NOTHING to where the blend should sit, and when
    // neither side contributes the target simply applies. Steel does not pass through violet on
    // its way to brown; it just starts to look brown.
    var _floor = 0.012;
    var _cs = max(0, _b.C - _floor) * (1 - _a);   // what the source still visibly brings
    var _ct = max(0, _Ct - _floor) * _a;          // what the target visibly brings
    var _sum = _cs + _ct;

    var _k = (_sum > 0.0008) ? (_ct / _sum) : 1.0;
    var _h = hrl_hue_mix(_b.h, _sp.tarnish, _k);

    // Ageing DARKENS and MATTES: a tarnished surface scatters instead of reflecting.
    var _val = clamp(_sp.val * (1 - 0.30 * _a), 0.02, 1);
    var _sat = clamp((_cs + _ct) / 0.155, 0, 1);
    var _fin = (_a > 0.55 && _sp.finish != 7) ? 2 : _sp.finish;   // heavy tarnish is frosted

    return {
        hue: _h, sat: _sat, val: _val, finish: _fin, corner: _sp.corner,
        tarnish: _sp.tarnish, ageC: _sp.ageC, name_i: _sp.name_i
    };
}

/// The same material, seen in shadow.
///
/// ⛔⛔ THIS EXISTS BECAUSE A MOVEMENT DRAWN IN ONE MATERIAL IS A PILE OF BRASS WITH NO DEPTH, AND
/// IT TOOK OPENING THE HERO SHEET TO SEE IT. The plate, the wheels, the bridges and the barrel are
/// all made of the same metal - which is true, and drawing them all from the same ramp is still
/// wrong, because the PLATE IS BEHIND EVERYTHING. Real wheel-work stands a few millimetres proud
/// of its plate and the plate is in its shadow; render both from the identical ramp and a
/// six-wheel movement reads as one flat khaki shape with lines on it.
///
/// ⚠️ IT IS A SHADOW, NOT A DIFFERENT MATERIAL. Only the lightness moves, and the chroma moves
/// with it the way chroma does in shade - slightly down, not toward grey, because a brass plate in
/// shadow is still brass. Handing the frame a genuinely different material would be a lie about
/// what the machine is made of, and it would look like one.
function hrl_mat_shaded(_sp, _k) {
    var _kk = clamp(is_undefined(_k) ? 0.45 : _k, 0, 0.9);
    return {
        hue: _sp.hue,
        sat: clamp(_sp.sat * (1 - _kk * 0.30), 0, 1),
        val: clamp(_sp.val * (1 - _kk), 0.02, 1),
        finish: _sp.finish,
        corner: _sp.corner,
        tarnish: _sp.tarnish,
        ageC: _sp.ageC,
        name_i: _sp.name_i
    };
}

/// Shortest-path hue blend, in degrees, on the hue circle.
///
/// ⚠️ SPLIT OUT SO THE SUITE CAN ASSERT IT SEPARATELY FROM THE AGEING MODEL. The Armoury defect was
/// two mistakes stacked - a wrong direction on top of a wrong weighting - and with one function
/// doing both there is no assertion that can tell you which half is broken.
function hrl_hue_mix(_h0, _h1, _k) {
    var _d = _h1 - _h0;
    while (_d > 180) _d -= 360;
    while (_d < -180) _d += 360;
    var _h = _h0 + _d * _k;
    while (_h < 0) _h += 360;
    while (_h >= 360) _h -= 360;
    return _h;
}

/// ============================================================================================
/// THE RAMP
/// ============================================================================================

/// Five stops for one material.
function hrl_mat_ramp(_sp) {
    var _b = hrl_mat_base(_sp);
    var _fs = hrl_finish_spec(_sp.finish);

    // Slide, never clamp. See the header.
    var _floor = 0.055, _ceil = 0.920;
    var _span = min(_fs.span, _ceil - _floor);
    var _lo = _b.L - _span * 0.5;
    var _hi = _b.L + _span * 0.5;
    if (_hi > _ceil) { _lo -= (_hi - _ceil); _hi = _ceil; }
    if (_lo < _floor) { _hi += (_floor - _lo); _lo = _floor; }
    _hi = min(_hi, _ceil);

    var _out = array_create(HRL_RAMP_N);
    for (var _i = 0; _i < HRL_RAMP_N; _i++) {
        var _t = _i / (HRL_RAMP_N - 1);
        // THE WARP. power > 1 holds the low stops down and leaves a wide gap to the top stop,
        // which is what a specular highlight IS. At spec 0 it is the identity and the stops are
        // evenly spaced, which is what a frosted surface wants.
        var _u = power(_t, 1 + _fs.spec * 1.6);
        var _Li = _lo + (_hi - _lo) * _u;
        var _Ci = _b.C * lerp(_fs.cLo, _fs.cHi, _u);
        _out[_i] = hrl_oklch(_Li, max(0, _Ci), _b.h + _fs.drift * (_u - 0.5) * 2);
    }
    return _out;
}

/// The role map that points hrl_relief's m0..m4 at a named ramp in the palette.
///
/// Returned fresh every call rather than cached, because hrl_map_roles reads it once and a shared
/// mutable map is the kind of thing that works until two machines are built in the same frame.
function hrl_mat_map(_prefix) {
    return {
        m0: _prefix + "0", m1: _prefix + "1", m2: _prefix + "2",
        m3: _prefix + "3", m4: _prefix + "4",
    };
}

/// Write one material's five stops into a palette struct under a prefix.
function hrl_mat_into(_pal, _prefix, _sp) {
    var _r = hrl_mat_ramp(_sp);
    for (var _i = 0; _i < HRL_RAMP_N; _i++) {
        variable_struct_set(_pal, _prefix + string(_i), _r[_i]);
    }
    return _pal;
}

/// ⛔ THE THING YOU WRITE ON A SURFACE IS NOT THAT SURFACE'S DARKEST STOP (CLAUDE.md, Lexicon).
///
/// This corpus contains WHITE ENAMEL at L 0.88 and BLACK POLISH at L 0.20 and puts numerals on
/// both. A numeral set in m0 on enamel is "merely less pale" and vanishes; the same numeral in m0
/// on black polish is invisible for the opposite reason. An ink is defined RELATIVE to its own
/// ground and goes the other way from it, by an asserted minimum - which is not a nicety on a
/// product whose central object is a DIAL, i.e. a surface that exists to be read.
function hrl_mat_ink(_sp) {
    var _b = hrl_mat_base(_sp);
    var _sep = 0.36;
    var _L = (_b.L > 0.5) ? max(0.045, _b.L - _sep) : min(0.960, _b.L + _sep);
    return hrl_oklch(_L, _b.C * 0.50, _b.h);
}

/// How far a material's ink sits from its own base, in Oklab lightness. Exists so the suite can
/// assert the separation rather than trust the arithmetic above, and so a material added at an
/// awkward lightness fires BY NAME instead of shipping an unreadable dial.
function hrl_mat_ink_sep(_sp) {
    var _b = hrl_mat_base(_sp);
    var _L = (_b.L > 0.5) ? max(0.045, _b.L - 0.36) : min(0.960, _b.L + 0.36);
    return abs(_L - _b.L);
}

/// The smallest surface detail this material may carry, in pixels.
///
/// ⛔ A MATERIAL WHOSE ENTIRE IDENTITY IS A 0.4 px HATCH IS A MATERIAL THAT DOES NOT EXIST AT THE
/// SIZE IT SHIPS AT. hrl_render's HRL_MIN_STROKE floors every stroke at 1.0 px because GML has no
/// sub-pixel line, so a detail authored below that does not get thinner - it gets DASHED, or it
/// disappears, depending on where it falls. Every surface character in this file is authored to
/// survive this and hrl_selftest asserts it.
function hrl_material_min_px() {
    return HRL_MIN_STROKE;
}

/// ============================================================================================
/// SEPARATION - the assertion that makes the ramp mean something
/// ============================================================================================

/// The smallest gap between adjacent stops of a material's ramp, in Oklab L.
///
/// ⛔ THIS IS THE NUMBER THAT DECIDES WHETHER RELIEF IS VISIBLE AT ALL. hrl_relief quantises a
/// surface normal into five bands; if two adjacent bands are the same colour then a bevel with a
/// lit side and a shadowed side draws as a flat fill, which is exactly the failure Hearth shipped.
/// The suite asserts a floor across all fourteen materials BY NAME, so a material added at an
/// awkward lightness fires as itself rather than quietly flattening one component.
function hrl_mat_min_step(_sp) {
    var _r = hrl_mat_ramp(_sp);
    var _min = 999;
    for (var _i = 1; _i < HRL_RAMP_N; _i++) {
        var _d = abs(hrl_oklch_L_of(_r[_i]) - hrl_oklch_L_of(_r[_i - 1]));
        if (_d < _min) _min = _d;
    }
    return _min;
}

/// Recover an approximate Oklab lightness from a packed BGR colour.
///
/// ⚠️ APPROXIMATE ON PURPOSE, AND THE SUITE KNOWS IT. The exact inverse would need the full sRGB
/// -> linear -> LMS -> Oklab chain, and the only thing this is used for is comparing two stops of
/// the SAME ramp against each other. A monotone approximation is sufficient for an ordering and
/// for a separation floor, and it is honest to say so rather than to imply a precision the
/// function does not have.
function hrl_oklch_L_of(_col) {
    var _r = colour_get_red(_col)   / 255;
    var _g = colour_get_green(_col) / 255;
    var _b = colour_get_blue(_col)  / 255;
    // Rec.709 luma on gamma-encoded values, then de-gamma'd once. Monotone in each channel.
    var _y = 0.2126 * _r + 0.7152 * _g + 0.0722 * _b;
    return power(_y, 1 / 2.2);
}
