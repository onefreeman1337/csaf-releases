{
  "$GMScript": "v1",
  "%Name": "hrl_material",
  "name": "hrl_material",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}