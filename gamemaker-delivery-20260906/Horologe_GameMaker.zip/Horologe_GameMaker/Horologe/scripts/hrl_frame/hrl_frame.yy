{
  "$GMScript": "v1",
  "%Name": "hrl_frame",
  "name": "hrl_frame",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}