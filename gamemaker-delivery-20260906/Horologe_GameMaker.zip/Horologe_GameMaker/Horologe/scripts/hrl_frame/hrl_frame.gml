/// HOROLOGE - hrl_frame. What holds the wheels, and it is DERIVED FROM WHERE THEY ARE.
///
/// ============================================================================================
/// THE FRAME IS NOT A BACKGROUND
///
/// Every function here is handed the TRAIN and reads the arbor positions out of it. A bridge is
/// drawn between the two pivots it actually carries; a plate is shaped to enclose the wheels that
/// are actually there; a pillar stands where there is room for one. Change a tooth count, the
/// solver moves an arbor, and the frame follows it without anybody editing the frame.
///
/// ⛔ THAT IS THE DIFFERENCE BETWEEN A GENERATOR AND A PICTURE WITH VARIABLES IN IT, and it is
/// where a naive version of this product would have stopped. A hand-drawn plate with holes in it
/// looks identical on the machine it was drawn for and is WRONG on every other one - and wrong
/// invisibly, because a pivot hole three pixels from its arbor still looks like a pivot hole. The
/// suite asserts that every arbor of every machine has a bearing within a tolerance of it.
///
/// ⚠️ FRAMES ARE DRAWN FIRST AND THE WHEELS GO ON TOP, which is painter's order and also the order
/// a movement is assembled in. The one exception is the FRONT bridges of a bar movement, which sit
/// over the wheels and are returned separately by hrl_frame_front_parts - a bar movement whose
/// bridges are all behind the wheels is not a bar movement, it is a full plate.
/// ============================================================================================

#macro HRL_FRAME_N 8

/// The frame's parts, behind the wheels.
function hrl_frame_parts(_kind, _tr, _map) {
    if (is_undefined(_tr) || !is_struct(_tr)) return [];
    if (is_undefined(_kind) || !is_real(_kind)) { _kind = 0; }
    var _k = clamp(_kind, 0, HRL_FRAME_N - 1);
    var _m = _tr.module;
    var _b = hrl_train_bounds(_tr);
    // ⚠️ THE PLATE MUST CLEAR THE WHEELS AND THE FIRST VERSION DID NOT. A pad of 1.6 modules is
    // about a tooth and a half, so on a movement whose wheels reach 48 modules the plate stopped
    // INSIDE the wheels and the teeth hung over its edge. Found by opening the hero sheet: it read
    // as a small rectangle behind a pile of discs. A frame is sized against the thing it carries,
    // so the pad scales with the movement and keeps an absolute floor for tiny ones.
    var _span = max(_b.x1 - _b.x0, _b.y1 - _b.y0);
    var _pad = max(_m * 1.6, _span * 0.055);
    var _x0 = _b.x0 - _pad, _y0 = _b.y0 - _pad;
    var _x1 = _b.x1 + _pad, _y1 = _b.y1 + _pad;
    // ⚠️ BAR AND PILLAR THICKNESS SCALES WITH THE MOVEMENT, not with the tooth. A birdcage's iron
    // bars at three quarters of a module were hairlines round a movement a hundred and sixty
    // modules across, so the turret clock and the lantern clock read as wheels floating in front
    // of a faint pencil rectangle. Frame stock is sized to the forces it carries, which scale with
    // the machine and not with its tooth pitch.
    var _bar = max(_m * 0.6, _span * 0.022);
    var _out = [];

    switch (_k) {

        // -- 0. FULL PLATE. One brass plate behind everything, with a pivot hole per arbor. The
        // English watchmaker's standard for two centuries, and the simplest thing to service.
        case 0: {
            var _p = hrl_pts_round(_x0, _y0, _x1, _y1, _m * 2.2, 8);
            hrl_append(_out, hrl_ring_fill(_p, "m2", (_x0 + _x1) * 0.5, (_y0 + _y1) * 0.5));
            hrl_append(_out, hrl_bevel(_p, _m * 0.5, 2, false));
        } break;

        // -- 1. THREE-QUARTER PLATE. The same, cut away over the balance so the escapement can be
        // seen and adjusted. The cut-away is placed at the LAST arbor in the train, which is
        // where the escapement is by construction.
        case 1: {
            var _p1 = hrl_pts_round(_x0, _y0, _x1, _y1, _m * 2.2, 8);
            hrl_append(_out, hrl_ring_fill(_p1, "m2", (_x0 + _x1) * 0.5, (_y0 + _y1) * 0.5));
            hrl_append(_out, hrl_bevel(_p1, _m * 0.5, 2, false));
            var _last = _tr.arbors[array_length(_tr.arbors) - 1];
            var _cut = hrl_ellipse_pts(_last.x, _last.y, _m * 4.6, _m * 4.6, 30);
            hrl_append(_out, hrl_sink(_cut, _m * 0.6, 2, "m0"));
        } break;

        // -- 2. PILLAR (POSTED) FRAME. Two plates held apart by turned pillars at the corners.
        // Seen from the front it is the pillars you see, and the wheels run between them.
        case 2: {
            var _cx = [_x0, _x1, _x1, _x0];
            var _cy = [_y0, _y0, _y1, _y1];
            for (var _i = 0; _i < 4; _i++) {
                hrl_append(_out, _hrl_pillar(_cx[_i], _cy[_i], _bar));
            }
            hrl_append(_out, hrl_raise(hrl_bar_pts(_x0, _y0, _x1, _y0, _bar, 0, 0, 0),
                                       _bar * 0.48, 2, "m2"));
            hrl_append(_out, hrl_raise(hrl_bar_pts(_x0, _y1, _x1, _y1, _bar, 0, 0, 0),
                                       _bar * 0.48, 2, "m2"));
        } break;

        // -- 3. SKELETON FRAME. Shaped and pierced to almost nothing, so the movement is the
        // ornament. Built as an outline through every arbor, offset outward - so the frame's SHAPE
        // is the train's shape, which is what a real skeleton clock's frame is.
        case 3: {
            var _hull = _hrl_arbor_hull(_tr, _m * 2.4);
            hrl_append(_out, hrl_ring_fill(_hull, "m2", (_x0 + _x1) * 0.5, (_y0 + _y1) * 0.5));
            hrl_append(_out, hrl_bevel(_hull, _m * 0.45, 2, false));
            var _inner = hrl_scale_pts(_hull, 0.60);
            hrl_append(_out, hrl_sink(_inner, _m * 0.4, 2, "m0"));
        } break;

        // -- 4. BAR MOVEMENT. No plate at all: each wheel gets its own bridge, screwed down at
        // one end. Swiss, and the reason a good watch movement looks like a piece of architecture.
        case 4: {
            hrl_append(_out, hrl_raise(hrl_pts_round(_x0, _y0, _x1, _y1, _m * 2.0, 6),
                                       _m * 0.30, 2, "m1"));
        } break;

        // -- 5. BIRDCAGE. A turret clock: a cube of iron bars with the wheels inside it. Heavy,
        // square, and built by a blacksmith rather than a watchmaker.
        case 5: {
            var _bw = _bar * 1.25;
            hrl_append(_out, hrl_raise(hrl_bar_pts(_x0, _y0, _x1, _y0, _bw, 0, 0, 0), _bw * 0.42, 2, "m2"));
            hrl_append(_out, hrl_raise(hrl_bar_pts(_x0, _y1, _x1, _y1, _bw, 0, 0, 0), _bw * 0.42, 2, "m2"));
            hrl_append(_out, hrl_raise(hrl_bar_pts(_x0, _y0, _x0, _y1, _bw, 0, 0, 0), _bw * 0.42, 2, "m2"));
            hrl_append(_out, hrl_raise(hrl_bar_pts(_x1, _y0, _x1, _y1, _bw, 0, 0, 0), _bw * 0.42, 2, "m2"));
            // The diagonal braces that make a birdcage rigid.
            hrl_append(_out, hrl_raise(hrl_bar_pts(_x0, _y0, _x1, _y1, _bw * 0.42, 0, 0, 0),
                                       _bw * 0.20, 2, "m1"));
            hrl_append(_out, hrl_raise(hrl_bar_pts(_x1, _y0, _x0, _y1, _bw * 0.42, 0, 0, 0),
                                       _bw * 0.20, 2, "m1"));
        } break;

        // -- 6. LANTERN FRAME. Corner posts with turned finials and feet, the seventeenth-century
        // brass lantern clock.
        case 6: {
            var _lx = [_x0, _x1];
            for (var _i = 0; _i < 2; _i++) {
                hrl_append(_out, hrl_raise(hrl_bar_pts(_lx[_i], _y0 - _bar, _lx[_i], _y1 + _bar,
                                                       _bar * 0.8, 0, 0, 0), _bar * 0.36, 2, "m3"));
                hrl_append(_out, hrl_boss(_lx[_i], _y0 - _bar * 1.6, _bar * 1.5, 14));
                hrl_append(_out, hrl_boss(_lx[_i], _y1 + _bar * 1.6, _bar * 1.5, 14));
            }
            hrl_append(_out, hrl_raise(hrl_bar_pts(_x0, _y0, _x1, _y0, _bar * 0.9, 0, 0, 0),
                                       _bar * 0.40, 2, "m3"));
            hrl_append(_out, hrl_raise(hrl_bar_pts(_x0, _y1, _x1, _y1, _bar * 0.9, 0, 0, 0),
                                       _bar * 0.40, 2, "m3"));
        } break;

        // -- 7. ENGRAVED BACKPLATE. A shaped plate with a border of engraved scrollwork - the
        // back of an English bracket clock, which was decorated because it was meant to be seen.
        default: {
            var _p7 = hrl_pts_cove(_x0, _y0, _x1, _y1, _m * 2.6, 8);
            hrl_append(_out, hrl_ring_fill(_p7, "m2", (_x0 + _x1) * 0.5, (_y0 + _y1) * 0.5));
            hrl_append(_out, hrl_bevel(_p7, _m * 0.5, 2, false));
            var _bord = hrl_scale_pts(_p7, 0.88);
            hrl_append(_out, hrl_incise(_bord, true, max(HRL_MIN_STROKE * 0.5, _m * 0.07)));
            // Scroll engraving: a chain of small arcs following the border, cut into the plate.
            var _n = array_length(_bord);
            for (var _i = 0; _i < _n; _i += 3) {
                var _q = _bord[_i];
                hrl_append(_out, hrl_arc(_q[0], _q[1], _m * 0.55,
                                         HRL_TAU * (_i / _n), HRL_TAU * (_i / _n) + pi * 1.2,
                                         max(HRL_MIN_STROKE * 0.5, _m * 0.06), "m1"));
            }
        } break;
    }

    // -- THE BEARINGS. Every arbor gets one, whatever the frame is, and this is the loop the
    // suite checks against: a frame that forgot an arbor draws a wheel floating in air.
    var _na = array_length(_tr.arbors);
    for (var _i = 0; _i < _na; _i++) {
        var _a = _tr.arbors[_i];
        hrl_append(_out, _hrl_bearing(_a.x, _a.y, _m, _k));
    }

    if (is_undefined(_map)) return _out;
    return hrl_map_roles(_out, _map);
}

/// The bridges that sit IN FRONT of the wheels. Only a bar movement has them.
function hrl_frame_front_parts(_kind, _tr, _map) {
    if (clamp(_kind, 0, HRL_FRAME_N - 1) != 4) return [];
    var _m = _tr.module;
    var _out = [];
    var _n = array_length(_tr.arbors);
    for (var _i = 1; _i < _n; _i++) {
        var _a = _tr.arbors[_i];
        var _p = _tr.arbors[_i - 1];
        // A bridge runs from a screwed foot near the previous arbor to the pivot it carries.
        var _fx = _p.x + (_a.x - _p.x) * 1.55;
        var _fy = _p.y + (_a.y - _p.y) * 1.55;
        var _bar = hrl_bar_pts(_fx, _fy, _a.x, _a.y, _m * 0.95, 0, 0, 0);
        hrl_append(_out, hrl_raise(_bar, _m * 0.30, 3, "m3"));
        hrl_append(_out, hrl_boss(_fx, _fy, _m * 0.42, 10));
        hrl_append(_out, _hrl_bearing(_a.x, _a.y, _m, 4));
    }
    if (is_undefined(_map)) return _out;
    return hrl_map_roles(_out, _map);
}

/// A pivot hole, and on the better frames a jewel set in it.
///
/// ⚠️ A JEWEL IS A SEPARATE MATERIAL AND IT IS NOT DRAWN WITH THE FRAME'S RAMP. hrl_machine
/// re-maps these to the ruby ramp; here they are emitted with role names that the caller can
/// redirect. Drawing a ruby in brass would be a palette swap, which is the failure the whole
/// material model exists to prevent.
function _hrl_bearing(_x, _y, _m, _frame_kind) {
    var _out = [];
    hrl_append(_out, hrl_pit(_x, _y, _m * 0.78, 14));
    // Bar movements and three-quarter plates are the jewelled ones in this corpus.
    if (_frame_kind == 4 || _frame_kind == 1) {
        hrl_append(_out, hrl_dot(_x, _y, _m * 0.50, "j2"));
        hrl_append(_out, hrl_ring(_x, _y, _m * 0.50, _m * 0.10, "j0"));
        // Three screws round a chaton, which is how a jewel is actually held.
        for (var _i = 0; _i < 3; _i++) {
            var _a = HRL_TAU * _i / 3 + 0.4;
            hrl_append(_out, hrl_boss(_x + cos(_a) * _m * 0.86, _y + sin(_a) * _m * 0.86,
                                      _m * 0.20, 8));
        }
    } else {
        hrl_append(_out, hrl_dot(_x, _y, _m * 0.34, "m0"));
    }
    return _out;
}

/// A turned pillar seen end on: a disc with two collars. `_u` is the frame's own bar thickness.
function _hrl_pillar(_x, _y, _u) {
    var _out = [];
    hrl_append(_out, hrl_boss(_x, _y, _u * 2.0, 16));
    hrl_append(_out, hrl_ring(_x, _y, _u * 1.35, _u * 0.22, "m1"));
    hrl_append(_out, hrl_ring(_x, _y, _u * 0.80, _u * 0.18, "m1"));
    return _out;
}

/// A convex outline that encloses every arbor, offset outward by _pad.
///
/// ⛔ NOT A CONVEX HULL, AND THE DIFFERENCE IS DELIBERATE. A true hull of three nearly collinear
/// arbors is a sliver, and a skeleton frame built on it would be a splinter of brass. This walks
/// the arbors by ANGLE about their own centroid and takes a radius from the furthest one at each
/// step, which gives a rounded, plate-like shape that still follows the layout. It is a
/// simplification and it is named as one, because "hull" would have implied a guarantee it does
/// not make: this outline is not guaranteed to contain every arbor for a wildly scattered layout,
/// so hrl_selftest checks containment per machine rather than assuming it.
function _hrl_arbor_hull(_tr, _pad) {
    var _n = array_length(_tr.arbors);
    var _cx = 0, _cy = 0;
    for (var _i = 0; _i < _n; _i++) { _cx += _tr.arbors[_i].x; _cy += _tr.arbors[_i].y; }
    _cx /= _n; _cy /= _n;

    var _steps = 40;
    var _pts = array_create(_steps);
    for (var _s = 0; _s < _steps; _s++) {
        var _a = HRL_TAU * _s / _steps;
        var _r = 0;
        for (var _i = 0; _i < _n; _i++) {
            var _ab = _tr.arbors[_i];
            var _dx = _ab.x - _cx, _dy = _ab.y - _cy;
            var _d = sqrt(_dx * _dx + _dy * _dy);
            var _wr = 0;
            if (!is_undefined(_ab.wheel))  _wr = max(_wr, hrl_wheel_extent(_ab.wheel));
            if (!is_undefined(_ab.pinion)) _wr = max(_wr, hrl_wheel_extent(_ab.pinion));
            if (!is_undefined(_ab.extra))  _wr = max(_wr, hrl_wheel_extent(_ab.extra));
            // Cosine falloff so an arbor pushes the outline out near its own direction only.
            var _th = (_d < 0.0001) ? 0 : arctan2(_dy, _dx);
            var _w = max(0, cos(_a - _th));
            _r = max(_r, (_d * _w * _w) + _wr * 0.55 + _pad);
        }
        _pts[_s] = [_cx + cos(_a) * _r, _cy + sin(_a) * _r];
    }
    return _pts;
}
