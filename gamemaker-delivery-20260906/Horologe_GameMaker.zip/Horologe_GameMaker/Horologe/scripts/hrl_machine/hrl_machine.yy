{
  "$GMScript": "v1",
  "%Name": "hrl_machine",
  "name": "hrl_machine",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}