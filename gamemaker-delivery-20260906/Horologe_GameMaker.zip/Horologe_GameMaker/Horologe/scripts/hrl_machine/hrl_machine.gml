/// HOROLOGE - hrl_machine. Twelve machines, each one a train plus the parts that make it a thing.
///
/// ============================================================================================
/// THE BEAT IS NOT CHOSEN. IT FALLS OUT OF THE TOOTH COUNTS.
///
/// The most important line in this file is hrl_mach_beat below, and it is four lines of
/// arithmetic. An escapement lets the escape wheel forward HALF A TOOTH per beat, so:
///
///     beat_seconds = 1 / (2 * N_escape * revolutions_per_second_of_the_escape_arbor)
///
/// and the revolutions per second came out of hrl_train's ratio chain, which came out of the
/// tooth counts. So the beat is DERIVED. Nobody types "1.0 seconds" anywhere in this package.
///
/// ⭐ THAT IS WHAT MAKES THE LONGCASE REGULATOR BELOW WORTH LOOKING AT. Its train is 96/12, 96/12,
/// 90/12 with a 30-tooth escape wheel - real English counts - and those numbers alone produce a
/// centre arbor at exactly one turn per hour, an escape arbor at exactly one turn per minute, and
/// a beat of exactly 1.000 seconds. A seconds pendulum, because the wheels say so. Change the 90
/// to an 80 and the pendulum gets shorter, the seconds hand steps faster, and the clock still
/// works - it is just a different clock. hrl_selftest asserts all three numbers.
///
/// ⛔ AND A MACHINE WITH beat = 0 IS NOT A BROKEN CLOCK, IT IS A DIFFERENT KIND OF MACHINE. An
/// orrery, a music box and a counting machine have no escapement and genuinely turn smoothly. The
/// code path is the same; only the quantiser is off. Saying "no escapement" out loud is better
/// than a special case that reads like an oversight.
/// ============================================================================================

#macro HRL_MACHINE_N 12

/// ============================================================================================
/// THE TWELVE SPECIFICATIONS
///
/// Each stage is { w: driving tooth count, p: driven tooth count, beta: layout angle }.
/// `root` is the driving arbor's speed in revolutions per second.
///
/// ⚠️ THE LAYOUT ANGLES ARE THE ONE FREE PARAMETER AND THEY ARE PURELY VISUAL. Everything else
/// here is mechanics; beta only decides where on the plate the next arbor goes. That is exactly
/// how a real movement is laid out too - the counts fix the sizes, the maker fixes the shape.
/// ============================================================================================


/// ============================================================================================
/// REFUSE, NEVER THROW — the public surface, guarded at the door.
/// ============================================================================================
/// MEASURED 2026-09-06: 104 hostile calls against the shipped package produced 36 crashes, all of
/// one shape — an entry point reading through an argument it never checked. A buyer integrating a
/// clock passes an uninitialised struct or a stale index exactly as readily as a correct one, and
/// a throw inside a bought library is a support ticket the seller cannot debug remotely.
///
/// ⛔ NOTE FOR ANY FUTURE GUARD IN THIS PACKAGE: `clamp(undefined, lo, hi)` THROWS. Several
/// entry points here open with `switch (clamp(_kind, 0, N - 1))` on the reasonable assumption
/// that clamping makes a bad index safe. It does not — a clamp is not a coercion, and it is the
/// reason hrl_machine_spec(undefined) and hrl_material_spec(undefined) both died.
function hrl_is_num(_v)   { return !is_undefined(_v) && is_real(_v); }
function hrl_is_mach(_v)  { return !is_undefined(_v) && is_struct(_v) && variable_struct_exists(_v, "train"); }
function hrl_is_wheel(_v) { return !is_undefined(_v) && is_struct(_v) && variable_struct_exists(_v, "N") && variable_struct_exists(_v, "module"); }
function hrl_is_train(_v) { return !is_undefined(_v) && is_struct(_v) && variable_struct_exists(_v, "arbors"); }

function hrl_machine_spec(_kind) {
    if (!hrl_is_num(_kind)) { _kind = 0; }   // clamp() THROWS on undefined; it is not a coercion
    switch (clamp(_kind, 0, HRL_MACHINE_N - 1)) {

        // -- 0. LONGCASE REGULATOR. The reference machine, and the one the suite checks hardest.
        // 96/12 - 96/12 - 90/12 with a 30-tooth escape wheel: centre 1 rev/hour, escape 1
        // rev/minute, beat exactly 1.000 s. A seconds pendulum, derived.
        case 0: return {
            root: 1 / 28800,
            stages: [ { w: 96, p: 12, beta: -2.35 },
                      { w: 96, p: 12, beta: -0.62 },
                      { w: 90, p: 12, beta: -2.60 } ],
            esc_teeth: 30, esc_profile: 5,
            centre: 1, motion: true,
            escapement: 2, osc: 0, dial: 2, frame: 0, drive: 0,
            hand_h: 2, hand_m: 2, hand_s: 9,
            profile: 0, crossing: 3, crossN: 6, material: 0, age: 0.10,
        };

        // -- 1. LANTERN CLOCK. Verge and foliot, weight driven, thirty hour. The oldest domestic
        // clock, and a bad timekeeper by construction - the foliot has no natural period at all,
        // so it keeps whatever time the weight and the friction agree on that day.
        case 1: return {
            root: 1 / (13 * 3600),
            stages: [ { w: 78, p: 6, beta: -2.20 },
                      { w: 96, p: 12, beta: -0.75 },
                      { w: 75, p: 8, beta: -2.45 } ],
            esc_teeth: 20, esc_profile: 4,
            centre: 1, motion: true,
            escapement: 0, osc: 4, dial: 0, frame: 6, drive: 0,
            hand_h: 4, hand_m: 4, hand_s: -1,
            profile: 0, crossing: 1, crossN: 4, material: 5, age: 0.55,
        };

        // -- 2. CARRIAGE CLOCK. Eight day, spring driven, platform escapement. Made to travel, so
        // it beats fast and has no pendulum to upset.
        case 2: return {
            root: 1 / 28800,
            stages: [ { w: 96, p: 12, beta: -2.40 },
                      { w: 80, p: 10, beta: -0.55 },
                      { w: 75, p: 10, beta: -2.55 },
                      { w: 80, p: 8, beta: -0.70 } ],
            esc_teeth: 15, esc_profile: 5,
            centre: 1, motion: true,
            escapement: 7, osc: 3, dial: 1, frame: 2, drive: 1,
            hand_h: 0, hand_m: 0, hand_s: -1,
            profile: 1, crossing: 2, crossN: 4, material: 1, age: 0.05,
        };

        // -- 3. POCKET WATCH. Fusee driven, cylinder escapement, three quarter plate. The English
        // watch of about 1830, which is when the fusee finally lost to the going barrel.
        case 3: return {
            root: 1 / 28800,
            stages: [ { w: 96, p: 12, beta: -2.50 },
                      { w: 72, p: 9, beta: -0.60 },
                      { w: 60, p: 10, beta: -2.35 },
                      { w: 60, p: 8, beta: -0.80 } ],
            esc_teeth: 20, esc_profile: 5,
            centre: 1, motion: true,
            escapement: 4, osc: 3, dial: 0, frame: 1, drive: 2,
            hand_h: 1, hand_m: 1, hand_s: 2,
            profile: 1, crossing: 6, crossN: 5, material: 0, age: 0.20,
        };

        // -- 4. MARINE CHRONOMETER. Detent escapement, fusee, and the whole thing in gimbals. The
        // instrument that solved longitude, and the reason a ship's clock is a different object
        // from a house's clock.
        case 4: return {
            root: 1 / 28800,
            stages: [ { w: 96, p: 12, beta: -2.30 },
                      { w: 80, p: 10, beta: -0.70 },
                      { w: 75, p: 10, beta: -2.50 },
                      { w: 64, p: 8, beta: -0.55 } ],
            esc_teeth: 15, esc_profile: 5,
            centre: 1, motion: true,
            escapement: 6, osc: 3, dial: 2, frame: 1, drive: 2,
            hand_h: 2, hand_m: 2, hand_s: 9,
            profile: 1, crossing: 8, crossN: 5, material: 6, age: 0.05,
        };

        // -- 5. TURRET CLOCK. Cast iron, birdcage frame, gridiron pendulum beating one and a half
        // seconds - which makes it about two and a quarter metres long, and is why the clock is in
        // the tower and the pendulum is in the stairwell.
        case 5: return {
            root: 1 / 28800,
            stages: [ { w: 96, p: 12, beta: -2.25 },
                      { w: 96, p: 12, beta: -0.80 },
                      { w: 60, p: 12, beta: -2.40 } ],
            esc_teeth: 30, esc_profile: 5,
            centre: 1, motion: true,
            escapement: 1, osc: 2, dial: 0, frame: 5, drive: 0,
            hand_h: 3, hand_m: 3, hand_s: -1,
            profile: 0, crossing: 1, crossN: 6, material: 8, age: 0.70,
        };

        // -- 6. ORRERY. No escapement: it is turned by hand and the planets move because the
        // wheels say how far. The outputs are longitudes in degrees, which is what an orrery is
        // FOR - it answers "where is Venus" without anybody computing anything.
        case 6: return {
            root: 1 / 90,
            stages: [ { w: 72, p: 30, beta: -2.55 },
                      { w: 64, p: 25, beta: -0.55 },
                      { w: 60, p: 19, beta: -2.70 } ],
            esc_teeth: 0, esc_profile: 0,
            centre: 1, motion: false,
            escapement: -1, osc: 5, dial: 7, frame: 3, drive: 5,
            hand_h: 6, hand_m: 6, hand_s: -1,
            profile: 0, crossing: 5, crossN: 6, material: 1, age: 0.15,
        };

        // -- 7. TELLURION. The orrery's smaller cousin: sun, earth and moon only, so it can show
        // the seasons and the phases rather than the whole system.
        case 7: return {
            root: 1 / 120,
            stages: [ { w: 60, p: 20, beta: -2.45 },
                      { w: 56, p: 14, beta: -0.65 } ],
            esc_teeth: 0, esc_profile: 0,
            centre: 1, motion: false,
            escapement: -1, osc: 5, dial: 4, frame: 3, drive: 5,
            hand_h: 8, hand_m: 8, hand_s: -1,
            profile: 0, crossing: 4, crossN: 5, material: 2, age: 0.35,
        };

        // -- 8. MUSIC BOX. A pinned barrel and a fly to keep the tune even. The barrel is drawn
        // with the LANTERN profile, which is not a substitution - a music box barrel really is a
        // cylinder studded with pins.
        case 8: return {
            root: 1 / 30,
            stages: [ { w: 60, p: 12, beta: -2.55 },
                      { w: 48, p: 10, beta: -0.60 } ],
            esc_teeth: 0, esc_profile: 0,
            centre: 0, motion: false,
            escapement: -1, osc: 5, dial: 8, frame: 4, drive: 3,
            hand_h: 6, hand_m: 6, hand_s: -1,
            profile: 3, crossing: 9, crossN: 3, material: 13, age: 0.25,
        };

        // -- 9. COUNTING MACHINE. Three ten-to-one reductions, so the last arbor turns once for a
        // thousand of the first. An odometer, a tally, a shop till - and the one machine here
        // whose output is just a number.
        case 9: return {
            root: 1 / 6,
            stages: [ { w: 60, p: 6, beta: 0.00 },
                      { w: 60, p: 6, beta: 0.00 },
                      { w: 60, p: 6, beta: 0.00 } ],
            esc_teeth: 0, esc_profile: 0,
            centre: 0, motion: false,
            escapement: -1, osc: -1, dial: 8, frame: 4, drive: 5,
            hand_h: 6, hand_m: 6, hand_s: -1,
            profile: 1, crossing: 5, crossN: 6, material: 6, age: 0.10,
        };

        // -- 10. COMBINATION LOCK. The one machine that uses an INTERNAL mesh: a pinion running
        // inside a toothed ring, which is what a lock's driver and its wheel pack actually are.
        // It turns the same way as its driver instead of the opposite way, and that is a visible
        // difference a player can learn.
        case 10: return {
            root: 1 / 12,
            stages: [ { w: 12, p: 72, beta: 0.00, internal: true },
                      { w: 72, p: 24, beta: -1.05 },
                      { w: 24, p: 30, beta: -2.30 } ],
            esc_teeth: 0, esc_profile: 0,
            centre: 0, motion: false,
            escapement: -1, osc: -1, dial: 5, frame: 0, drive: 5,
            hand_h: 6, hand_m: 6, hand_s: -1,
            profile: 1, crossing: 7, crossN: 4, material: 7, age: 0.30,
        };

        // -- 11. AUTOMATON DRIVE. A ratchet-fed train with a fly, the thing behind a moving figure
        // or a striking jack. Its output is a gesture count rather than a time.
        default: return {
            root: 1 / 240,
            stages: [ { w: 64, p: 16, beta: -2.40 },
                      { w: 48, p: 12, beta: -0.65 },
                      { w: 36, p: 12, beta: -2.55 } ],
            esc_teeth: 0, esc_profile: 0,
            centre: 0, motion: false,
            escapement: -1, osc: 5, dial: 9, frame: 7, drive: 3,
            hand_h: 7, hand_m: 7, hand_s: -1,
            profile: 2, crossing: 0, crossN: 4, material: 3, age: 0.45,
        };
    }
}

/// ============================================================================================
/// BUILDING ONE
/// ============================================================================================

/// Build a machine. `_seed` varies nothing mechanical - it perturbs the layout angles slightly and
/// picks the wind, so two of the same kind are recognisably the same machine by two hands.
///
/// ⚠️ THE SEED DOES NOT TOUCH THE TOOTH COUNTS, AND THAT IS A DELIBERATE LIMIT ON THE GENERATOR.
/// A clock whose wheel counts were randomised would keep random time, and "this clock runs at
/// 1.03 seconds per beat" is not a feature, it is a bug with a story. The mechanism is authored;
/// the finish, the wear and the layout are generated.
function hrl_machine_new(_kind, _material, _seed) {
    if (!hrl_is_num(_kind))     { _kind = 0; }
    if (!hrl_is_num(_material)) { _material = 0; }
    if (!hrl_is_num(_seed))     { _seed = 0; }
    var _sp = hrl_machine_spec(_kind);
    var _rng = hrl_rng(1 + _seed * 7919);
    var _m = 1.0;

    var _tr = hrl_train_new(_m);

    // -- the wheels ---------------------------------------------------------------------------
    var _n = array_length(_sp.stages);
    var _idx = array_create(_n + 1);

    // The root arbor carries only a driving wheel.
    var _root_w = hrl_wheel_new(_sp.stages[0].w, _m, _sp.profile, _sp.crossing);
    _root_w.crossN = _sp.crossN;
    _idx[0] = hrl_train_add(_tr, _root_w, undefined, "great");

    for (var _i = 0; _i < _n; _i++) {
        var _st = _sp.stages[_i];
        var _pin = hrl_wheel_new(_st.p, _m, _sp.profile, 0);
        var _whl = undefined;
        if (_i + 1 < _n) {
            _whl = hrl_wheel_new(_sp.stages[_i + 1].w, _m, _sp.profile, _sp.crossing);
            _whl.crossN = _sp.crossN;
        } else if (_sp.esc_teeth > 0) {
            // The last arbor carries the ESCAPE WHEEL, which is a different profile from the rest
            // of the train because it does a different job.
            //
            // ⚠️ IT IS CROSSED OUT LIKE ANY OTHER WHEEL, AND THE FIRST VERSION LEFT IT SOLID. An
            // escape wheel is crossed for the same reason every other wheel is - weight is
            // inertia, and inertia at the escapement is the one place a clockmaker cares about it
            // most. Drawn as a solid disc it also read as a dark hole in the middle of every
            // escapement cell on the sheet, which is where the eye is supposed to go.
            _whl = hrl_wheel_new(_sp.esc_teeth, _m, _sp.esc_profile, 3);
            _whl.crossN = 4;
            _whl.rimw = 0.20;
        }
        // The centre arbor also carries the cannon pinion for the motion work.
        var _extra = undefined;
        if (_sp.motion && (_i + 1) == _sp.centre) _extra = hrl_wheel_new(10, _m, _sp.profile, 0);
        _idx[_i + 1] = hrl_train_add(_tr, _whl, _pin, "arbor" + string(_i + 1), _extra);
    }

    hrl_train_root(_tr, _idx[0], 0, 0, _sp.root, 0);

    for (var _i = 0; _i < _n; _i++) {
        var _st2 = _sp.stages[_i];
        var _jit = (hrl_rng_next(_rng) - 0.5) * 0.14;
        var _kind_m = (variable_struct_exists(_st2, "internal") && _st2.internal)
            ? HRL_MESH_INTERNAL : HRL_MESH_EXTERNAL;
        // ⚠️ THE COUNTING MACHINE AND THE LOCK USE beta 0 AND MUST NOT BE JITTERED APART: their
        // arbors are meant to lie on one straight line, which is what an odometer looks like.
        var _b = _st2.beta + ((_st2.beta == 0) ? 0 : _jit);
        hrl_train_mesh(_tr, _idx[_i], (_i == 0) ? "wheel" : "wheel", _idx[_i + 1], "pinion",
                       _b, _kind_m);
    }

    // -- the motion work ----------------------------------------------------------------------
    // Cannon pinion 10 -> minute wheel 30 -> minute pinion 8 -> hour wheel 32. Both centre
    // distances are 20 modules, so the hour wheel comes back exactly onto the centre arbor - which
    // is what a real motion work does, and is asserted rather than assumed.
    var _hour = -1;
    if (_sp.motion) {
        var _mw = hrl_wheel_new(30, _m, _sp.profile, 0);
        var _mp = hrl_wheel_new(8, _m, _sp.profile, 0);
        var _mi = hrl_train_add(_tr, _mp, _mw, "minute wheel");
        var _hw = hrl_wheel_new(32, _m, _sp.profile, 2);
        _hw.crossN = 4;
        _hour = hrl_train_add(_tr, undefined, _hw, "hour wheel");
        var _mb = 1.30;
        hrl_train_mesh(_tr, _idx[_sp.centre], "extra", _mi, "pinion", _mb, HRL_MESH_EXTERNAL);
        hrl_train_mesh(_tr, _mi, "wheel", _hour, "pinion", _mb + pi, HRL_MESH_EXTERNAL);
    }

    // -- which way round does it run? ----------------------------------------------------------
    // ⛔ EVERY EXTERNAL MESH REVERSES, so whether the hands go clockwise depends on whether the
    // number of meshes between the drive and the centre arbor is even - which is an accident of
    // the train, not a decision. The regulator has one mesh from the great wheel to the centre, so
    // it came out running BACKWARDS and the suite caught it reading "set to 3:00:00, reads 9
    // hours". Reversing the whole train is what a clockmaker does by winding the other way, and it
    // provably preserves every mesh (see hrl_train_reverse).
    //
    // ⚠️ Only the timekeepers are normalised. A mill, a music box and a counting machine have no
    // opinion about which way round they go, and forcing one would be inventing a convention.
    if (_sp.centre > 0 && _tr.arbors[_idx[_sp.centre]].turns < 0) hrl_train_reverse(_tr);

    // -- the beat, DERIVED --------------------------------------------------------------------
    var _esc = _idx[_n];
    _tr.beat = 0;
    if (_sp.esc_teeth > 0) _tr.beat = hrl_mach_beat(_tr, _esc, _sp.esc_teeth);

    var _mach = {
        kind: clamp(_kind, 0, HRL_MACHINE_N - 1),
        material: clamp(_material, 0, HRL_MATERIAL_N - 1),
        age: _sp.age,
        seed: _seed,
        spec: _sp,
        train: _tr,
        centre: (_sp.centre > 0) ? _idx[_sp.centre] : _idx[0],
        escape: _esc,
        hour: _hour,
        escapement: _sp.escapement,
        osc: _sp.osc,
        dial: _sp.dial,
        frame: _sp.frame,
        drive: _sp.drive,
        wind: 0.35 + hrl_rng_next(_rng) * 0.60,
        pal: {},
        map: hrl_mat_map("s"),
    };

    _hrl_mach_palette(_mach);
    _hrl_mach_outputs(_mach);
    return _mach;
}

/// What each machine's dial is made of.
///
/// ⚠️ AUTHORED PER MACHINE RATHER THAN DERIVED, because it is a fact about the object and not a
/// consequence of anything. A regulator gets a silvered dial because that is what an observatory
/// clock had; a carriage clock gets white enamel; a turret clock's dial is a painted iron sheet;
/// an orrery has no dial in the ordinary sense and its plate is brass. Nothing computes these and
/// nothing should.
function hrl_machine_dial_material(_kind) {
    switch (clamp(_kind, 0, HRL_MACHINE_N - 1)) {
        case 0: return 9;    // regulator: silvered
        case 1: return 9;    // lantern clock: silvered chapter ring on brass
        case 2: return 10;   // carriage clock: white enamel
        case 3: return 10;   // pocket watch: white enamel
        case 4: return 10;   // marine chronometer: white enamel
        case 5: return 10;   // turret clock: painted sheet, read as enamel white
        case 6: return 0;    // orrery: engraved brass plate
        case 7: return 0;    // tellurion: engraved brass plate
        case 8: return 13;   // music box: figured rosewood lid
        case 9: return 9;    // counting machine: silvered register
        case 10: return 11;  // combination lock: black polished dial
        default: return 2;   // automaton: cast bronze
    }
}

/// The beat, in seconds, from the escape wheel's tooth count and its arbor's speed.
///
/// ⭐ FOUR LINES, AND THEY ARE THE REASON THIS PRODUCT IS A SYSTEM. An escapement passes half a
/// tooth per beat. So one revolution of an N-tooth escape wheel is 2N beats, and the time for one
/// revolution is 1/turns. Divide.
function hrl_mach_beat(_tr, _esc_arbor, _esc_teeth) {
    var _turns = abs(_tr.arbors[_esc_arbor].turns);
    if (_turns < 0.000000001 || _esc_teeth <= 0) return 0;
    return 1 / (2 * _esc_teeth * _turns);
}

/// The palette: the machine's own material, plus steel for the arbors and ruby for the jewels.
///
/// ⛔ THREE MATERIALS IN ONE PALETTE, NOT ONE TINTED THREE WAYS. A movement is not made of one
/// metal, and a jewel drawn in brass is the palette swap this catalogue's whole material model
/// exists to avoid. The role names are prefixed: `s` for the machine's own metal, `j` for the
/// jewels. Anything not in the map falls through to the machine's metal, which is correct - it is
/// what most of a movement is made of.
function _hrl_mach_palette(_mach) {
    var _sp = hrl_mat_aged(hrl_material_spec(_mach.material), _mach.age);
    hrl_mat_into(_mach.pal, "s", _sp);                          // the wheel-work
    hrl_mat_into(_mach.pal, "p", hrl_mat_shaded(_sp, 0.46));    // the plate, behind and in shadow
    hrl_mat_into(_mach.pal, "j", hrl_material_spec(12));        // ruby jewels
    // ⭐ THE HANDS ARE BLUED STEEL AND THAT IS NOT A STYLE CHOICE. A hand has to be read against
    // its own dial from across a room, so clockmakers blue them or black-polish them - a brass
    // hand on a brass dial is invisible, which is exactly what this package drew until the hero
    // sheet was opened and the hands could not be found on it.
    hrl_mat_into(_mach.pal, "h", hrl_material_spec(7));         // blued steel
    // ⛔ THE DIAL IS NOT MADE OF THE MOVEMENT'S METAL, AND DRAWING IT THAT WAY MADE EVERY CLOCK IN
    // THE PACKAGE LOOK LIKE ONE PIECE OF BRASS. Real dials are silvered, or enamelled, or painted:
    // whatever is behind them, the face is chosen to be READ. Four materials in one machine -
    // brass wheel-work, its own shadow on the plate, a silvered or enamelled dial and blued steel
    // hands - is what a clock actually is, and it is what the material model exists to allow.
    hrl_mat_into(_mach.pal, "d", hrl_material_spec(hrl_machine_dial_material(_mach.kind)));
    _mach.pal.line = hrl_mat_ink(_sp);
    _mach.pal.ink = hrl_mat_ink(_sp);
    return _mach;
}

/// What this machine tells you.
function _hrl_mach_outputs(_mach) {
    var _tr = _mach.train;
    switch (_mach.kind) {
        case 0: case 1: case 2: case 3: case 4: case 5: {
            hrl_train_output(_tr, _mach.centre, "minutes", 60, "min", 60);
            if (_mach.hour >= 0) hrl_train_output(_tr, _mach.hour, "hours", 12, "h", 12);
            hrl_train_output(_tr, _mach.escape, "seconds", 60, "s", 60);
        } break;
        // ⚠️ ARBOR INDICES 1..3 ARE SAFE HERE ONLY BECAUSE THIS MACHINE DECLARES THREE STAGES,
        // which produce four arbors. That is a coupling between two places in this file, so
        // hrl_selftest checks every declared output's arbor index against the train it was
        // declared on rather than trusting it - an output on an arbor that does not exist reads a
        // struct field off undefined, which in GML is a crash and not a wrong number.
        case 6: {
            hrl_train_output(_tr, 1, "mercury", 360, "deg", 360);
            hrl_train_output(_tr, 2, "venus", 360, "deg", 360);
            hrl_train_output(_tr, 3, "earth", 360, "deg", 360);
        } break;
        case 7: {
            hrl_train_output(_tr, 1, "earth", 360, "deg", 360);
            hrl_train_output(_tr, 2, "moon", 360, "deg", 360);
        } break;
        case 8: {
            hrl_train_output(_tr, 1, "barrel turns", 1, "turns", 0);
        } break;
        case 9: {
            hrl_train_output(_tr, 1, "tens", 10, "", 10);
            hrl_train_output(_tr, 2, "hundreds", 10, "", 10);
            hrl_train_output(_tr, 3, "thousands", 10, "", 10);
        } break;
        case 10: {
            hrl_train_output(_tr, 1, "ring", 100, "", 100);
            hrl_train_output(_tr, 2, "ward A", 100, "", 100);
            hrl_train_output(_tr, 3, "ward B", 100, "", 100);
        } break;
        default: {
            hrl_train_output(_tr, array_length(_tr.arbors) - 1, "gestures", 1, "", 0);
        } break;
    }
    return _mach;
}

/// ============================================================================================
/// RUNNING AND READING
/// ============================================================================================

function hrl_machine_step(_mach, _dt) {
    // The per-FRAME call: an owner mid-teardown or a caller-supplied dt can both be undefined.
    if (!hrl_is_mach(_mach) || !hrl_is_num(_dt)) return _mach;
    hrl_train_step(_mach.train, _dt); return _mach;
}
function hrl_machine_set(_mach, _seconds) {
    if (!hrl_is_mach(_mach) || !hrl_is_num(_seconds)) return _mach;
    hrl_train_set(_mach.train, _seconds); return _mach;
}
function hrl_machine_read(_mach) {
    if (!hrl_is_mach(_mach)) return { hours: 0, minutes: 0, seconds: 0 };
    return hrl_train_read_all(_mach.train);
}

/// Set a clock to a wall time. Only meaningful on the machines that keep time.
///
/// ⛔ IT SETS THE WHOLE TRAIN FROM THE CENTRE ARBOR RATHER THAN MOVING THE HANDS. Moving a hand
/// without moving the wheel behind it is what an animation does; here the hour, the minute and the
/// seconds hands all come off arbors, so setting the time means putting the TRAIN at a moment, and
/// everything else follows - including the escape wheel and the pendulum. That is why a clock set
/// to 3:47:12 in this package has its wheels where a real clock's would be at 3:47:12.
function hrl_machine_set_time(_mach, _h, _m, _s) {
    if (!hrl_is_mach(_mach)) return _mach;
    if (!hrl_is_num(_h)) { _h = 0; }
    if (!hrl_is_num(_m)) { _m = 0; }
    if (!hrl_is_num(_s)) { _s = 0; }
    var _secs = (_h mod 12) * 3600 + _m * 60 + _s;
    return hrl_machine_set(_mach, _secs);
}

/// The oscillator's swing, -1 to 1, from the CONTINUOUS time.
///
/// See hrl_escapement's header: this reads `t` and the train reads `tick_t`, so the pendulum
/// sweeps while the wheels step, and the two cannot drift because both come from one number.
function hrl_machine_swing(_mach) {
    if (!hrl_is_mach(_mach)) return 0;
    var _tr = _mach.train;
    if (_tr.beat <= 0) return sin(_tr.t * 1.7);   // a fly, freewheeling
    return sin(pi * _tr.t / _tr.beat);
}

/// ============================================================================================
/// DRAWING ONE
/// ============================================================================================

/// Every part of a machine's MOVEMENT - frame, wheels, escapement - in machine units.
///
/// PAINTER'S ORDER, and it is assembly order: frame, then the train from the back forward, then
/// the escapement, then the front bridges.
function hrl_machine_movement_parts(_mach) {
    if (!hrl_is_mach(_mach)) return [];
    var _tr = _mach.train;
    var _m = _tr.module;
    var _out = [];

    // ⛔ THE FRAME IS MAPPED TO THE SHADED RAMP, NOT THE MACHINE'S. See hrl_mat_shaded: the plate
    // is behind everything and drawing it from the same five stops as the wheels flattens the
    // movement into one shape. Mapping HERE rather than inside hrl_frame keeps the frame builders
    // material-agnostic - they emit m0..m4 like every other builder and the composer decides what
    // those mean, which is the same split that lets one wheel be drawn in fourteen metals.
    hrl_append(_out, hrl_map_roles(hrl_frame_parts(_mach.frame, _tr, undefined),
                                   hrl_mat_map("p")));

    // ⛔ THE DRIVE GOES ON BEFORE THE WHEELS, NOT AFTER. It was drawn last, so a going barrel sat
    // ON TOP of the whole train and the regulator's weight drum read as a target painted over the
    // movement. A barrel is BEHIND its great wheel on the same arbor, and it is the frame's
    // neighbour rather than the train's. Painter's order is assembly order: plate, drive, wheels.
    //
    // ⚠️ And it is sized against the root wheel's HUB rather than its pitch radius. At pitch radius
    // a drum on a 96-tooth great wheel is as big as the wheel and swallows it; a real barrel is
    // about half the wheel it drives.
    var _root0 = _tr.arbors[0];
    var _rr0 = is_undefined(_root0.wheel) ? _m * 3 : hrl_wheel_pitch_r(_root0.wheel) * 0.46;
    hrl_append(_out, hrl_drive_parts(_mach.drive, _root0.x, _root0.y, _rr0, _m,
                                     _mach.wind, hrl_arbor_angle(_tr, 0), undefined));

    var _n = array_length(_tr.arbors);
    for (var _i = 0; _i < _n; _i++) {
        var _a = _tr.arbors[_i];
        var _ang = hrl_arbor_angle(_tr, _i);
        // The pinion is UNDER the wheel on the same arbor, so it is drawn first.
        if (!is_undefined(_a.pinion)) {
            hrl_append(_out, hrl_place(hrl_wheel_parts(_a.pinion, undefined),
                                       _a.x, _a.y, 1, _ang, 1, undefined));
        }
        if (!is_undefined(_a.extra)) {
            hrl_append(_out, hrl_place(hrl_wheel_parts(_a.extra, undefined),
                                       _a.x, _a.y, 1, _ang, 1, undefined));
        }
        if (!is_undefined(_a.wheel)) {
            hrl_append(_out, hrl_place(hrl_wheel_parts(_a.wheel, undefined),
                                       _a.x, _a.y, 1, _ang, 1, undefined));
        }
    }

    // The escapement sits on the escape wheel's arbor.
    if (_mach.escapement >= 0) {
        var _ea = _tr.arbors[_mach.escape];
        var _ew = _ea.wheel;
        if (!is_undefined(_ew)) {
            var _esc = hrl_esc_parts(_mach.escapement, _ew, hrl_machine_swing(_mach), undefined);
            hrl_append(_out, hrl_offset_parts(_esc, _ea.x, _ea.y));
        }
    }

    hrl_append(_out, hrl_map_roles(hrl_frame_front_parts(_mach.frame, _tr, undefined),
                                   hrl_mat_map("p")));

    // The oscillator hangs below the escapement.
    //
    // ⚠️ THE PENDULUM IS DRAWN FORESHORTENED AND THE PACKAGE SAYS SO. A seconds pendulum is very
    // nearly a metre long against a movement about fifteen centimetres across, so a true-to-scale
    // one is six times the height of everything else and shrinks the machine to a speck. It is
    // scaled to the movement instead - about two thirds of its height - which is the convention
    // every clockmaker's drawing uses. The RATIO BETWEEN oscillators is still honest, because
    // hrl_osc_length carries the square law, so a half-seconds pendulum is still a quarter of a
    // seconds pendulum here. The first version used a flat multiple of the module and produced a
    // three-centimetre pendulum on a metre-wide turret clock.
    if (_mach.osc >= 0 && _mach.escapement >= 0) {
        var _ea2 = _tr.arbors[_mach.escape];
        var _bnd = hrl_train_bounds(_tr);
        var _span = max(_bnd.x1 - _bnd.x0, _bnd.y1 - _bnd.y0);
        // ⚠️ 0.34, NOT 0.62. Hung clear of the plate at two thirds of the movement's height the
        // pendulum became the subject: a long bare rod took half the frame and the wheel-work it
        // is attached to shrank to fit around it. A pendulum in a drawing of a MOVEMENT is there
        // to say what kind of clock this is, not to be measured. The square law between
        // oscillators is untouched, so a half-seconds pendulum is still a quarter of this one.
        var _len = hrl_osc_length(_mach.osc, _tr.beat) * _span * 0.34;
        if (_len <= 0) _len = _span * 0.22;
        // ⛔ IT HANGS FROM THE BOTTOM OF THE PLATE, NOT FROM THE ESCAPE ARBOR'S OWN y. The escape
        // arbor is at the TOP of a clock train, so a pendulum hung from there and drawn two thirds
        // of the movement's height long finished in the MIDDLE of the wheels - invisible behind
        // them, which is exactly what the hero sheet showed. A pendulum's suspension is at the top
        // and its bob swings clear BELOW the movement; keeping its x on the escape arbor is the
        // part that matters, because that is what it is connected to.
        // The oscillator's own scale is the MOVEMENT's, not the tooth's - a bob and a rod are
        // proportioned against the clock, and at module scale the rod came out thinner than a
        // tooth root and the bob smaller than a collet.
        hrl_append(_out, hrl_osc_parts(_mach.osc, _ea2.x, _bnd.y1 + _span * 0.04, _len,
                                       _span * 0.030, hrl_machine_swing(_mach), undefined));
        // The suspension: the cock the pendulum actually hangs from, at the top where it belongs.
        hrl_append(_out, hrl_boss(_ea2.x, _ea2.y - _span * 0.02, _span * 0.020, 12));
    } else if (_mach.osc >= 0) {
        var _last = _tr.arbors[array_length(_tr.arbors) - 1];
        var _bnd2 = hrl_train_bounds(_tr);
        var _span2 = max(_bnd2.x1 - _bnd2.x0, _bnd2.y1 - _bnd2.y0);
        hrl_append(_out, hrl_osc_parts(_mach.osc, _last.x, _last.y, 0, _span2 * 0.030,
                                       hrl_machine_swing(_mach), undefined));
    }

    return hrl_map_roles(_out, _mach.map);
}

/// The DIAL side: the plate, its figures, and the hands on their arbors.
///
/// ⚠️ THE DIAL IS THE SAME SIZE AS THE MOVEMENT, CENTRED ON THE CENTRE ARBOR, because that is
/// where the hands come out. A dial sized independently would leave the hands pointing at nothing
/// on some machines and off the edge on others - and the layout that decides where the centre
/// arbor is has already run by the time this is called.
function hrl_machine_dial_parts(_mach) {
    if (!hrl_is_mach(_mach)) return [];
    var _tr = _mach.train;
    var _m = _tr.module;
    var _b = hrl_train_bounds(_tr);
    var _cx = _tr.arbors[_mach.centre].x;
    var _cy = _tr.arbors[_mach.centre].y;
    var _r = max(_b.x1 - _b.x0, _b.y1 - _b.y0) * 0.50;
    var _out = [];

    hrl_append(_out, hrl_map_roles(
        hrl_offset_parts(hrl_dial_parts(_mach.dial, _r, _m, undefined), _cx, _cy),
        hrl_mat_map("d")));

    var _sp = _mach.spec;

    // ⭐ A REGULATOR PUTS ITS HOUR AND SECONDS HANDS ON SUBSIDIARY DIALS, AND THE FIRST VERSION
    // STACKED ALL THREE ON THE CENTRE. That is not a detail - it is the entire point of the
    // layout. An observatory clock separates the hands so that NO TWO EVER OVERLAP and the minute
    // hand can be read against a full-width track to the second. Drawing three hands on one arbor
    // over a dial that already has two empty subdials on it was a picture of a regulator that was
    // not one, and it looked exactly as confused as that sounds.
    if (_mach.dial == 2) {
        hrl_append(_out, _hrl_hand_at(_mach, _sp.hand_m, _mach.centre, _cx, _cy, _r * 0.84, _m));
        if (_mach.hour >= 0) {
            hrl_append(_out, _hrl_hand_at(_mach, _sp.hand_h, _mach.hour,
                                          _cx, _cy - _r * 0.42, _r * 0.19, _m));
        }
        if (_sp.hand_s >= 0 && _mach.escape != _mach.centre) {
            hrl_append(_out, _hrl_hand_at(_mach, _sp.hand_s, _mach.escape,
                                          _cx, _cy + _r * 0.44, _r * 0.18, _m));
        }
        return hrl_map_roles(_out, _mach.map);
    }

    if (_mach.hour >= 0) {
        hrl_append(_out, _hrl_hand_at(_mach, _sp.hand_h, _mach.hour, _cx, _cy, _r * 0.52, _m));
    }
    hrl_append(_out, _hrl_hand_at(_mach, _sp.hand_m, _mach.centre, _cx, _cy, _r * 0.84, _m));
    if (_sp.hand_s >= 0 && _mach.escape != _mach.centre) {
        hrl_append(_out, _hrl_hand_at(_mach, _sp.hand_s, _mach.escape, _cx, _cy, _r * 0.88, _m));
    }
    return hrl_map_roles(_out, _mach.map);
}

function _hrl_hand_at(_mach, _hand, _arbor, _cx, _cy, _len, _m) {
    var _ang = hrl_arbor_angle(_mach.train, _arbor);
    // Mapped to the BLUED STEEL ramp here rather than in hrl_hand_parts, for the same reason the
    // frame is mapped in the composer: the builders stay material-agnostic and the composer says
    // what a part is made of.
    return hrl_map_roles(
        hrl_place(hrl_hand_parts(_hand, _len, _m, undefined), _cx, _cy, 1, _ang, 1, undefined),
        hrl_mat_map("h"));
}

/// Everything, movement behind and dial in front.
function hrl_machine_parts(_mach, _show_dial) {
    if (!hrl_is_mach(_mach)) return [];   // draw nothing rather than throw mid-frame
    var _out = [];
    hrl_append(_out, hrl_machine_movement_parts(_mach));
    if (_show_dial) hrl_append(_out, hrl_machine_dial_parts(_mach));
    return _out;
}
