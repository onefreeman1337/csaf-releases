{
  "$GMScript": "v1",
  "%Name": "hrl_wheel",
  "name": "hrl_wheel",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}