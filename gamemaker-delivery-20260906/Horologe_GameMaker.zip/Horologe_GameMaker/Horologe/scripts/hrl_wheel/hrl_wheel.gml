/// HOROLOGE - hrl_wheel. A wheel is DRAWN FROM ITS TOOTH COUNT. That sentence is the product.
///
/// ============================================================================================
/// THE ONE IDEA
///
/// A picture of a gear has no tooth count. It has a number of teeth that somebody drew, and if the
/// game wants a different ratio the picture is simply wrong and nobody can tell.
///
/// Here a wheel is a NUMBER, and everything follows from it:
///
///     pitch radius     r = module * N / 2
///     circular pitch   p = pi * module          <- equal on both wheels of a mesh, or they cannot
///                                                  mesh, and this is what the suite asserts
///     angular pitch    a = TAU / N
///     tooth k sits at  a * k                    <- in the wheel's own frame, always, every profile
///     ratio to a mate  -N_this / N_that
///
/// Change N from 96 to 60 and the teeth get coarser AND the hand that wheel drives runs faster,
/// because the drawing and the ratio come out of the same number. That is the whole claim, and
/// hrl_selftest proves the picture keeps it by COUNTING THE TEETH IT ACTUALLY DREW rather than by
/// trusting the loop that drew them.
///
/// ============================================================================================
/// COORDINATE SPACE - MACHINE UNITS, NOT THE UNIT BOX
///
/// ⚠️ EVERY OTHER PRODUCT IN THIS CATALOGUE AUTHORS ITS FORMS IN THE UNIT BOX. THIS ONE CANNOT, AND
/// THE REASON IS WORTH STATING BECAUSE IT LOOKS LIKE A DEVIATION FOR ITS OWN SAKE.
///
/// A specimen is one object and the unit box is the right frame for it. A MOVEMENT is a dozen
/// objects whose sizes are RELATED - a 96-tooth wheel is exactly eight times the pitch radius of a
/// 12-leaf pinion of the same module, and if that relation is lost the wheels no longer touch. So
/// wheels are authored in MACHINE UNITS with the arbor at (0,0) and the module as the unit of
/// length, hrl_train lays them out in that same space, and hrl_machine maps the finished layout
/// into the unit box ONCE, at the end, through hrl_render_in_rect_tight.
///
/// ⛔ THE ARBOR IS THE ORIGIN, ALWAYS, AND THAT IS NOT A CONVENTION - IT IS WHY THE CACHE IS
/// HONEST. hrl_render's caching header explains: a wheel is baked once and drawn rotated, which is
/// only truthful if the thing rotates about the point it actually turns about. A wheel authored
/// off-centre would orbit instead of spin, and it would do it silently.
/// ============================================================================================

#macro HRL_PROFILE_N  8
#macro HRL_CROSSING_N 10

/// ============================================================================================
/// THE WHEEL SPEC
/// ============================================================================================

/// A wheel or pinion.
///
///   _N        tooth count (or leaf count on a pinion, or pin count on a lantern)
///   _module   length per tooth. TWO WHEELS MESH IF AND ONLY IF THIS MATCHES.
///   _profile  0..HRL_PROFILE_N-1, see hrl_tooth_pts
///   _crossing 0..HRL_CROSSING_N-1, see hrl_crossing_parts
///
/// ⚠️ `hub` AND `rimw` ARE FRACTIONS OF THE PITCH RADIUS, NOT ABSOLUTE. A 96-tooth wheel and a
/// 12-leaf pinion are the same drawing at different scales, and a hub bounded in machine units
/// would swallow the pinion whole - a pinion's pitch radius at module 1 is SIX UNITS and a hub of
/// "0.5 units" is 8% of the wheel and 25% of the pinion. This is the proportional half of the law
/// in hrl_geom's header; the physical half (a pivot is a pivot at any wheel size) is handled by
/// hrl_wheel_arbor_r, which is bounded in machine units on purpose.
function hrl_wheel_new(_N, _module, _profile, _crossing) {
    // A wheel needs at least three teeth and a positive module to be a wheel at all.
    if (!hrl_is_num(_N))        { _N = 12; }
    if (!hrl_is_num(_module))   { _module = 1; }
    if (!hrl_is_num(_profile))  { _profile = 0; }
    if (!hrl_is_num(_crossing)) { _crossing = 0; }
    _N = max(3, floor(abs(_N)));
    _module = max(0.0001, abs(_module));
    return {
        N: max(4, floor(_N)),
        module: max(0.02, _module),
        profile: clamp(floor(_profile), 0, HRL_PROFILE_N - 1),
        crossing: clamp(floor(_crossing), 0, HRL_CROSSING_N - 1),
        crossN: 5,
        hub: 0.20,
        rimw: 0.13,
        seed: 1,
    };
}

/// Pitch radius - the circle that actually rolls on its mate's.
function hrl_wheel_pitch_r(_w) { if (!hrl_is_wheel(_w)) return 0; return _w.module * _w.N * 0.5; }

/// Circular pitch - the arc between two tooth centres AT the pitch circle.
///
/// ⛔ THIS IS THE MESH CONDITION AND IT IS THE PRODUCT'S CENTRAL ASSERTION. Two wheels mesh only
/// if this number is equal on both. It is pi * module and does NOT depend on N, which is exactly
/// why a 96 and a 12 can run together: they share the tooth SIZE and differ only in how many they
/// carry. hrl_selftest asserts equality across every mesh of every machine.
function hrl_wheel_pitch(_w) { return pi * _w.module; }

/// Angular pitch - the angle between two tooth centres.
function hrl_wheel_ang_pitch(_w) { return HRL_TAU / _w.N; }

/// How far a tooth stands ABOVE the pitch circle, in machine units.
///
/// ⚠️ PROFILE-DEPENDENT, AND ON PURPOSE. Clock wheel-work uses a tall cycloidal addendum because
/// the drive happens entirely after the line of centres; an escape wheel's club tooth is long and
/// thin; a ratchet's is short and stiff. Making them all one number would draw four different
/// mechanisms as the same mechanism.
function hrl_wheel_addendum(_w) {
    switch (_w.profile) {
        case 0: return _w.module * 0.95;  // cycloidal, tall head
        case 1: return _w.module * 0.80;  // involute
        case 2: return _w.module * 0.72;  // ratchet
        case 3: return _w.module * 0.50;  // lantern pin, half a pin proud
        case 4: return _w.module * 0.62;  // crown
        case 5: return _w.module * 1.15;  // club tooth, long and slim
        case 6: return _w.module * 0.86;  // triangular count tooth
        default: return _w.module * 0.78; // sprocket
    }
}

/// How far the root falls BELOW the pitch circle.
function hrl_wheel_dedendum(_w) {
    switch (_w.profile) {
        case 3: return _w.module * 0.50;
        case 5: return _w.module * 0.55;
        default: return _w.module * 0.72;
    }
}

function hrl_wheel_root_r(_w) { return max(_w.module * 0.6, hrl_wheel_pitch_r(_w) - hrl_wheel_dedendum(_w)); }
function hrl_wheel_tip_r(_w)  { return hrl_wheel_pitch_r(_w) + hrl_wheel_addendum(_w); }

/// The arbor (the shaft the wheel is fixed to), in MACHINE UNITS and deliberately not proportional.
///
/// ⭐ THIS IS THE PHYSICAL HALF OF hrl_geom's BOTH-ENDS LAW, and a mechanism is the clearest case
/// of it in the catalogue: a movement's arbors are all roughly the same diameter whatever their
/// wheels do, because they all carry roughly the same torque and run in the same size of pivot
/// hole. An arbor sized as a fraction of its wheel would draw the great wheel with a fence post
/// through it and the escape wheel with a hair.
function hrl_wheel_arbor_r(_w) { return _w.module * 0.42; }

/// The fraction of one angular pitch that the TOOTH occupies at the pitch circle. The rest is gap.
///
/// ⛔ A PINION'S LEAVES ARE THINNER THAN A WHEEL'S TEETH AND THAT IS NOT DECORATION. In real
/// wheel-work a wheel tooth takes rather less than half the pitch and the pinion leaf rather more,
/// so the pair has running clearance. Drawing both at exactly half the pitch makes them collide on
/// screen at every mesh - visible as teeth passing THROUGH each other, which is the single most
/// obvious way a drawn gear train can be wrong.
function hrl_wheel_tooth_frac(_w) {
    switch (_w.profile) {
        case 0: return (_w.N <= 20) ? 0.54 : 0.42;   // pinion leaves fuller than wheel teeth
        case 1: return (_w.N <= 20) ? 0.52 : 0.44;
        case 2: return 0.60;
        case 3: return 0.50;
        case 4: return 0.38;
        case 5: return 0.30;                          // club tooth: slim
        case 6: return 0.50;
        default: return 0.46;
    }
}

/// ============================================================================================
/// ONE TOOTH
///
/// Every profile returns points for ONE tooth, in LOCAL POLAR terms, walking from the root at
/// -pitch/2 round to the root at +pitch/2, and every one of them is CENTRED ON LOCAL ANGLE ZERO.
///
/// ⛔ THAT CENTRING IS LOAD-BEARING AND IT IS NOT A STYLE RULE. hrl_train's phase solver puts a
/// tooth of the driver on the line of centres and a GAP of the driven wheel opposite it, and it
/// does that arithmetically from the tooth index. If one profile quietly centred its tooth on the
/// leading flank instead, that profile's wheels would mesh half a tooth out - a defect that looks
/// like a rendering artefact, is invisible on a still frame at small size, and would be blamed on
/// the layout for a long time. hrl_selftest asserts, for every profile, that the outline's radial
/// maximum falls within a fifth of a pitch of local zero.
/// ============================================================================================

/// Returns an array of [angle, radius] pairs for one tooth.
function hrl_tooth_pts(_w) {
    var _pa = hrl_wheel_ang_pitch(_w);
    var _rp = hrl_wheel_pitch_r(_w);
    var _rr = hrl_wheel_root_r(_w);
    var _rt = hrl_wheel_tip_r(_w);
    var _hw = _pa * 0.5 * hrl_wheel_tooth_frac(_w);   // half tooth width, in angle, at the pitch circle
    var _out = [];

    switch (_w.profile) {

        // -- 0. CYCLOIDAL. The clockmaker's tooth: radial flanks below the pitch circle, a full
        // rounded head above it. All the driving happens after the line of centres, which is why
        // the head is so tall and why a clock train runs quietly with wide tolerances.
        case 0: {
            array_push(_out, [-_pa * 0.5, _rr]);
            array_push(_out, [-_hw * 1.06, _rr]);
            array_push(_out, [-_hw, _rp - _w.module * 0.02]);
            var _seg = 9;
            for (var _i = 0; _i <= _seg; _i++) {
                var _u = -1 + 2 * (_i / _seg);
                var _a = _hw * _u;
                var _r = _rp + (_rt - _rp) * power(max(0, 1 - _u * _u), 0.62);
                array_push(_out, [_a, _r]);
            }
            array_push(_out, [_hw, _rp - _w.module * 0.02]);
            array_push(_out, [_hw * 1.06, _rr]);
            array_push(_out, [_pa * 0.5, _rr]);
        } break;

        // -- 1. INVOLUTE. The machine-gear tooth: near-straight flanks leaning in at a pressure
        // angle, and a FLAT top where the tip circle truncates it. The flat top is the tell that
        // separates it from cycloidal at a glance, so it is drawn rather than rounded away.
        case 1: {
            var _wt = _hw * 0.56;
            array_push(_out, [-_pa * 0.5, _rr]);
            array_push(_out, [-_hw * 1.18, _rr]);
            var _sg = 5;
            for (var _i = 0; _i <= _sg; _i++) {
                var _t = _i / _sg;
                array_push(_out, [lerp(-_hw * 1.18, -_wt, power(_t, 0.86)), lerp(_rr, _rt, _t)]);
            }
            array_push(_out, [_wt, _rt]);
            for (var _i = _sg; _i >= 0; _i--) {
                var _t = _i / _sg;
                array_push(_out, [lerp(_hw * 1.18, _wt, power(_t, 0.86)), lerp(_rr, _rt, _t)]);
            }
            array_push(_out, [_pa * 0.5, _rr]);
        } break;

        // -- 2. RATCHET. Asymmetric by definition: a long climbing back and a near-radial locking
        // face. The click drops behind the face, so the face must be the STEEP one or the drawing
        // says the ratchet turns the wrong way.
        case 2: {
            array_push(_out, [-_pa * 0.5, _rr]);
            var _sg2 = 6;
            for (var _i = 1; _i <= _sg2; _i++) {
                var _t = _i / _sg2;
                array_push(_out, [lerp(-_pa * 0.5, -_pa * 0.03, _t), lerp(_rr, _rt, power(_t, 1.25))]);
            }
            array_push(_out, [_pa * 0.045, _rt * 0.997]);
            array_push(_out, [_pa * 0.055, _rr]);
            array_push(_out, [_pa * 0.5, _rr]);
        } break;

        // -- 3. LANTERN. There is no tooth. A lantern pinion is two discs with round steel PINS
        // between them, and the pin is what the wheel drives against. The outline here is the
        // shroud disc; hrl_wheel_parts adds the pins, and the tooth count IS the pin count.
        case 3: {
            array_push(_out, [-_pa * 0.5, _rp * 0.86]);
            array_push(_out, [_pa * 0.5, _rp * 0.86]);
        } break;

        // -- 4. CROWN. Teeth stand along the rim as square blocks rather than pointing outward -
        // a contrate wheel seen face on. Narrow and flat-topped so it cannot be mistaken for an
        // involute at thumbnail size.
        case 4: {
            array_push(_out, [-_pa * 0.5, _rr]);
            array_push(_out, [-_hw, _rr]);
            array_push(_out, [-_hw, _rt]);
            array_push(_out, [_hw, _rt]);
            array_push(_out, [_hw, _rr]);
            array_push(_out, [_pa * 0.5, _rr]);
        } break;

        // -- 5. CLUB TOOTH. The escape wheel of a lever watch: a long slim neck leaning forward
        // into the direction of travel, a club-shaped impulse face on its front, and an undercut
        // back so the pallet can drop clear. Nothing else in the corpus looks like it, which is
        // the point: an escape wheel should be recognisable as one.
        // ⛔⛔ EVERY RADIUS HERE IS AN ABSOLUTE OFFSET IN MODULE UNITS, AND THE FIRST VERSION USED
        // FRACTIONS OF THE PITCH RADIUS. That version drew correctly on a 15-tooth escape wheel
        // and was broken on a 90-tooth one, because a "0.94 of the pitch radius" neck is 0.9
        // modules below the pitch circle at N=30 and SIX modules below it at N=96 - so the tooth's
        // neck dived under its own root circle and the wheel's lowest point stopped being the
        // root. MEASURED by the suite: 180 tips counted on a 90-tooth wheel and 192 on a 96, both
        // exactly double, because the root circle then rose above the counter's threshold and each
        // root read as a second tooth.
        //
        // ⭐ This is hrl_geom's BOTH-ENDS law arriving from the other direction: a tooth's shape is
        // PHYSICAL, so its features are the same size in millimetres on a turret wheel and on a
        // watch wheel. Anything expressed as a fraction of the pitch radius grows with the tooth
        // count, which is precisely the thing that must not happen.
        case 5: {
            var _m5 = _w.module;
            array_push(_out, [-_pa * 0.5, _rr]);
            array_push(_out, [-_hw * 1.9, _rr]);
            array_push(_out, [-_hw * 1.15, _rp - _m5 * 0.32]);
            array_push(_out, [-_hw * 0.75, _rt - _m5 * 0.10]);   // heel of the club
            array_push(_out, [_hw * 0.30, _rt]);                 // tip, forward-leaning
            array_push(_out, [_hw * 0.55, _rt - _m5 * 0.28]);
            array_push(_out, [_hw * 0.20, _rp - _m5 * 0.08]);    // the undercut
            array_push(_out, [_hw * 0.95, _rr]);
            array_push(_out, [_pa * 0.5, _rr]);
        } break;

        // -- 6. TRIANGULAR. A count wheel, a star wheel, a snail's index: no rolling contact at
        // all, just a tooth that something drops into once a revolution.
        case 6: {
            array_push(_out, [-_pa * 0.5, _rr]);
            array_push(_out, [-_hw, _rr]);
            array_push(_out, [0, _rt]);
            array_push(_out, [_hw, _rr]);
            array_push(_out, [_pa * 0.5, _rr]);
        } break;

        // -- 7. SPROCKET. Chain work - a fusee chain, a weight line, a going barrel's click ring.
        // Pointed teeth with a ROUNDED POCKET between them, because the pocket is where a link
        // seats and a pointed root would sit a round link on a corner.
        // ⚠️ THE POCKET FLOOR IS AN ABSOLUTE OFFSET FOR THE SAME REASON AS THE CLUB TOOTH ABOVE.
        // It read `_rr * 0.97` and passed the tooth counter only by luck - at N=96 that is 1.4
        // modules below the root circle, and it was within a whisker of the same doubling.
        default: {
            var _m7 = _w.module;
            var _pk = _rr - _m7 * 0.10;
            array_push(_out, [-_pa * 0.5, _pk]);
            var _sg3 = 4;
            for (var _i = 0; _i <= _sg3; _i++) {
                var _t = _i / _sg3;
                array_push(_out, [lerp(-_pa * 0.5, -_hw, _t), lerp(_pk, _rp, power(_t, 0.7))]);
            }
            array_push(_out, [-_hw * 0.34, _rt]);
            array_push(_out, [_hw * 0.34, _rt]);
            for (var _i = 0; _i <= _sg3; _i++) {
                var _t = _i / _sg3;
                array_push(_out, [lerp(_hw, _pa * 0.5, _t), lerp(_rp, _pk, power(_t, 1.4))]);
            }
        } break;
    }
    return _out;
}

/// ============================================================================================
/// THE WHOLE OUTLINE
/// ============================================================================================

/// The closed toothed outline of a wheel, in machine units, arbor at the origin.
///
/// ⛔ ONE CLOSED RING, NOT N SEPARATE TEETH. hrl_relief bevels a CLOSED OUTLINE, and a rim built
/// as N little polygons has N times as many outer edges as it should, so each tooth would get its
/// own lit side and the wheel would read as a flower of separate petals rather than as one piece
/// of metal with teeth cut in it. Concatenating the teeth into a single ring is what makes a
/// wheel look turned from a blank.
function hrl_wheel_outline(_w) {
    if (!hrl_is_wheel(_w)) return [];
    var _pa = hrl_wheel_ang_pitch(_w);
    var _tooth = hrl_tooth_pts(_w);
    var _tn = array_length(_tooth);
    var _pts = [];
    for (var _k = 0; _k < _w.N; _k++) {
        var _base = _pa * _k;
        for (var _i = 0; _i < _tn; _i++) {
            // ⚠️ The last point of one tooth and the first of the next are the SAME point in
            // polar terms (root at +pitch/2 == root at -pitch/2 of the next). Emitting both puts
            // a duplicate vertex in a closed ring, and hrl_shape's header records what a
            // duplicate vertex does to the turning assertion: it discards the real turn there.
            if (_i == _tn - 1 && _k < _w.N - 1) continue;
            var _a = _base + _tooth[_i][0];
            var _r = _tooth[_i][1];
            array_push(_pts, [cos(_a) * _r, sin(_a) * _r]);
        }
    }
    return _pts;
}

/// ============================================================================================
/// READING BACK WHAT WAS DRAWN
///
/// ⭐ THIS IS THE FUNCTION THAT MAKES THE PRODUCT'S CLAIM CHECKABLE, AND IT DELIBERATELY DOES NOT
/// LOOK AT `N`. It walks the OUTLINE - the actual points that will be drawn - and counts radial
/// maxima. If the loop that emits teeth is wrong, if a profile drops one, if a duplicate vertex
/// merges two, this reads a different number from the spec and the suite fires.
///
/// ⛔ VERIFYING AGAINST THE FIELD YOU WROTE PROVES ONLY THAT ASSIGNMENT WORKS (CLAUDE.md §2b, six
/// recorded instances). A tooth counter that returns `_w.N` would pass forever over any defect.
/// ============================================================================================

/// Count the tooth tips actually present in an outline.
///
/// ⛔ THE FIRST VERSION OF THIS COUNTED STRICT LOCAL MAXIMA AND IT WAS WRONG TWICE OVER, WHICH IS
/// worth keeping because both errors are the kind that pass their own review.
///
///  1. A FLAT-TOPPED TOOTH HAS NO STRICT MAXIMUM. The involute profile deliberately truncates its
///     tip, so two adjacent points sit at exactly the same radius and neither is greater than its
///     neighbour. The counter needed a plateau walk, and the plateau walk needed a circular index
///     - which is where the second error was.
///  2. GML's `mod` RETURNS A NEGATIVE FOR A NEGATIVE LEFT OPERAND. `(_i - _b) mod _n` is not the
///     circular index it reads as; it is a negative array subscript for every point in the first
///     tooth. That is an out-of-range read, and CLAUDE.md §2b records this wing shipping exactly
///     that class of defect into four sold cartridges as a silent wrong value rather than a crash.
///
/// ⇒ REPLACED WITH SOMETHING THAT HAS NO INDEX ARITHMETIC AT ALL. Take the radius range of the
/// whole outline, threshold across the middle of it, and count contiguous RUNS above the
/// threshold, wrapping once. A tooth is a run; a root is a gap. It does not care about plateaux,
/// it does not care about sampling density, and it reads the drawing rather than the loop that
/// made it.
function hrl_wheel_count_tips(_pts) {
    var _n = array_length(_pts);
    if (_n < 6) return 0;

    var _r = array_create(_n);
    var _lo = 999999, _hi = -999999;
    for (var _i = 0; _i < _n; _i++) {
        _r[_i] = point_distance(0, 0, _pts[_i][0], _pts[_i][1]);
        if (_r[_i] < _lo) _lo = _r[_i];
        if (_r[_i] > _hi) _hi = _r[_i];
    }
    // ⚠️ A RING WITH NO TEETH MUST READ ZERO, NOT ONE. Without this the threshold sits inside
    // floating-point noise on a plain circle and the whole outline reads as a single enormous
    // tooth - a vacuous pass on exactly the case (a lantern shroud, a plain barrel) where the
    // answer matters.
    if (_hi - _lo < _hi * 0.02) return 0;

    var _cut = _lo + (_hi - _lo) * 0.55;
    var _runs = 0;
    var _prev_above = (_r[_n - 1] >= _cut);
    for (var _i = 0; _i < _n; _i++) {
        var _above = (_r[_i] >= _cut);
        if (_above && !_prev_above) _runs++;
        _prev_above = _above;
    }
    return _runs;
}

/// Count the PINS actually present in a built lantern pinion.
///
/// ⛔ THIS EXISTS BECAUSE A STORE SHEET PRINTED A HARD-CODED NUMBER AND IT WAS WRONG. The tooth
/// sheet captions each cell "N declared, M drawn", and M comes from hrl_wheel_count_tips - which
/// correctly returns nothing for a lantern, because a lantern has no toothed outline to scan. The
/// bake special-cased it with the literal 8 while building a 24-pin wheel, so the one cell on the
/// sheet whose caption nobody could check said "24 declared, 8 drawn" over a picture of 24 pins.
///
/// ⭐ A CAPTION THAT ASSERTS A COUNT MUST COUNT SOMETHING. That is the same rule as the tooth
/// counter itself and it is easy to keep everywhere except the one place the general instrument
/// does not reach - which is exactly where it gets broken. This reads the built part list: it
/// finds every part whose centroid sits near the pitch circle and groups them by angle, so a
/// pin's several bevel quads count once.
///
/// ⚠️ WHAT IT COUNTS IS RADIAL FEATURES AT A RADIUS, NOT "PINS" IN ANY DEEPER SENSE - point it at
/// a toothed wheel and it will happily count the teeth, because a toothed rim's bevel quads are
/// also N radial features at the pitch circle. That is fine for its one caller and it is stated
/// here rather than implied by the name, because a vacuity guard written on the assumption that
/// it could tell a pin from a tooth went red on perfectly correct code.
function hrl_wheel_count_pins(_parts, _rp, _n_hint) {
    var _n = array_length(_parts);
    if (_n == 0 || _rp <= 0) return 0;
    var _pa = HRL_TAU / max(3, _n_hint);
    var _seen = [];
    for (var _i = 0; _i < _n; _i++) {
        var _c = _hrl_part_centroid(_parts[_i]);
        var _r = point_distance(0, 0, _c[0], _c[1]);
        if (abs(_r - _rp) > _rp * 0.16) continue;
        var _a = arctan2(_c[1], _c[0]);
        var _hit = false;
        for (var _j = 0; _j < array_length(_seen); _j++) {
            var _d = _a - _seen[_j];
            while (_d > pi) _d -= HRL_TAU;
            while (_d < -pi) _d += HRL_TAU;
            if (abs(_d) < _pa * 0.45) { _hit = true; break; }
        }
        if (!_hit) array_push(_seen, _a);
    }
    return array_length(_seen);
}

/// The average position of a part's points. Shared by the pin counter and by hrl_selftest's
/// symmetry check, so there is one definition of what a part's position means.
function _hrl_part_centroid(_p) {
    switch (_p.kind) {
        case HRL_DOT: return [_p.cx, _p.cy];
        case HRL_ARC: return [_p.cx, _p.cy];
        case HRL_STRIP: {
            var _x = 0, _y = 0, _k = 0;
            for (var _i = 0; _i < array_length(_p.a); _i++) { _x += _p.a[_i][0]; _y += _p.a[_i][1]; _k++; }
            for (var _i = 0; _i < array_length(_p.b); _i++) { _x += _p.b[_i][0]; _y += _p.b[_i][1]; _k++; }
            return [_x / max(1, _k), _y / max(1, _k)];
        }
        default: {
            var _x = 0, _y = 0;
            var _k = array_length(_p.pts);
            for (var _i = 0; _i < _k; _i++) { _x += _p.pts[_i][0]; _y += _p.pts[_i][1]; }
            return [_x / max(1, _k), _y / max(1, _k)];
        }
    }
}

/// The angle of the tooth nearest a given direction, measured from the wheel's own zero.
function hrl_wheel_tip_angles(_w) {
    var _pa = hrl_wheel_ang_pitch(_w);
    var _out = array_create(_w.N);
    for (var _k = 0; _k < _w.N; _k++) _out[_k] = _pa * _k;
    return _out;
}

/// ============================================================================================
/// CROSSINGS - the openwork between hub and rim
///
/// ⛔ THE CROSSINGS ARE THE HALF OF A WHEEL A BUYER ACTUALLY LOOKS AT. Every wheel in a movement
/// has the same rim and the same hub; what tells a French carriage clock from an English turret
/// clock at a glance is the shape of the openings. Ten forms here, and a machine chooses one for
/// its whole train so the movement agrees with itself.
///
/// ⚠️ EVERY FORM IS BUILT WITH N-FOLD SYMMETRY ABOUT THE ARBOR, and hrl_render's caching header
/// says why that is not optional: a wheel is baked once and drawn rotated, which is only honest if
/// rotating it by one crossing reproduces it exactly.
/// ============================================================================================

function hrl_crossing_parts(_w, _role_face, _role_edge) {
    // The FIRST argument is a WHEEL, not a kind index. Passing a number made GML read it as an
    // OBJECT INDEX ("Unable to find instance for object index 999") - a message that names
    // neither this function nor the wheel it wanted.
    if (!hrl_is_wheel(_w)) return [];
    var _rp = hrl_wheel_pitch_r(_w);
    var _ri = hrl_wheel_root_r(_w) * (1 - _w.rimw);     // inner edge of the rim
    var _rh = max(hrl_wheel_arbor_r(_w) * 1.9, _rp * _w.hub);
    var _c  = max(3, _w.crossN);
    var _out = [];
    if (_ri <= _rh * 1.12) return _out;                  // no room: a pinion is solid, correctly

    var _span = _ri - _rh;

    switch (_w.crossing) {

        // 0. SOLID WEB. No openings at all - a pinion, a cast iron wheel, a stamped blank.
        case 0: break;

        // 1. STRAIGHT ARMS.
        case 1: {
            for (var _k = 0; _k < _c; _k++) {
                var _a = HRL_TAU * _k / _c;
                var _hw2 = _rp * 0.055;
                var _q = _hrl_arm_rect(_a, _rh * 0.92, _ri * 1.02, _hw2, _hw2);
                hrl_append(_out, hrl_raise(_q, _rp * 0.030, 2, _role_face));
            }
        } break;

        // 2. TAPERED ARMS - wider where they meet the hub, which is where the torque is.
        case 2: {
            for (var _k = 0; _k < _c; _k++) {
                var _a = HRL_TAU * _k / _c;
                var _q = _hrl_arm_rect(_a, _rh * 0.92, _ri * 1.02, _rp * 0.082, _rp * 0.040);
                hrl_append(_out, hrl_raise(_q, _rp * 0.030, 2, _role_face));
            }
        } break;

        // 3. CURVED ARMS - one S-curve each, the English turret-clock look.
        case 3: {
            for (var _k = 0; _k < _c; _k++) {
                var _a = HRL_TAU * _k / _c;
                var _q = _hrl_arm_curve(_a, _rh * 0.92, _ri * 1.02, _rp * 0.060, 0.32);
                hrl_append(_out, hrl_raise(_q, _rp * 0.026, 2, _role_face));
            }
        } break;

        // 4. DOUBLE-CURVE ARMS - a gothic ogee, curving one way then the other.
        case 4: {
            for (var _k = 0; _k < _c; _k++) {
                var _a = HRL_TAU * _k / _c;
                var _q = _hrl_arm_curve(_a, _rh * 0.92, _ri * 1.02, _rp * 0.056, -0.40);
                hrl_append(_out, hrl_raise(_q, _rp * 0.026, 2, _role_face));
            }
        } break;

        // 5. PIERCED CIRCLES - a solid web with round holes drilled through it. Cheap to make and
        // it looks it, which is why it belongs to the industrial machines in the corpus.
        case 5: {
            var _hr = min(_span * 0.34, _rp * 0.11);
            var _rr2 = _rh + _span * 0.52;
            hrl_append(_out, hrl_ring_fill(hrl_ellipse_pts(0, 0, _ri, _ri, 40), _role_face, 0, 0));
            for (var _k = 0; _k < _c; _k++) {
                var _a = HRL_TAU * _k / _c;
                hrl_append(_out, hrl_pit(cos(_a) * _rr2, sin(_a) * _rr2, _hr, 14));
            }
        } break;

        // 6. FOLIATE PIERCING - a solid web with shaped openings, the expensive version of 5.
        case 6: {
            hrl_append(_out, hrl_ring_fill(hrl_ellipse_pts(0, 0, _ri, _ri, 40), _role_face, 0, 0));
            for (var _k = 0; _k < _c; _k++) {
                var _a = HRL_TAU * (_k + 0.5) / _c;
                var _q = _hrl_arm_rect(_a, _rh * 1.10, _ri * 0.92, _rp * 0.052, _rp * 0.090);
                hrl_append(_out, hrl_sink(_q, _rp * 0.024, 2, _role_edge));
            }
        } break;

        // 7. CROSS-HALVED - four arms only, whatever the crossing count says, because a halved
        // cross is a joint and not a spoke pattern.
        case 7: {
            for (var _k = 0; _k < 4; _k++) {
                var _a = HRL_TAU * _k / 4;
                var _q = _hrl_arm_rect(_a, 0, _ri * 1.02, _rp * 0.070, _rp * 0.070);
                hrl_append(_out, hrl_raise(_q, _rp * 0.032, 2, _role_face));
            }
        } break;

        // 8. SKELETON LATTICE - arms plus an intermediate ring, the skeleton-clock look.
        case 8: {
            var _rm = _rh + _span * 0.55;
            for (var _k = 0; _k < _c; _k++) {
                var _a = HRL_TAU * _k / _c;
                var _q = _hrl_arm_rect(_a, _rh * 0.92, _ri * 1.02, _rp * 0.042, _rp * 0.042);
                hrl_append(_out, hrl_raise(_q, _rp * 0.022, 2, _role_face));
            }
            hrl_append(_out, hrl_ring(0, 0, _rm, _rp * 0.030, _role_edge));
        } break;

        // 9. BARRED - parallel bars rather than radial spokes. A barrel, a fly, a plate wheel.
        //
        // ⚠️ THE ONE FORM THAT IS NOT N-FOLD SYMMETRIC, AND IT IS DECLARED RATHER THAN DISCOVERED.
        // Parallel bars have TWO-fold symmetry however many of them there are, so a wheel using
        // this crossing cannot be baked-and-rotated in the general case. hrl_wheel_rot_sym returns
        // 2 for it and hrl_selftest checks the declaration against the geometry instead of
        // assuming every form obeys the rule.
        default: {
            var _bars = 3;
            for (var _k = 0; _k < _bars; _k++) {
                var _off = (_k - (_bars - 1) * 0.5) * (_ri * 2 * 0.42);
                var _bw = _rp * 0.055;
                var _hy = sqrt(max(0, _ri * _ri - _off * _off)) * 0.98;
                var _q = [[_off - _bw, -_hy], [_off + _bw, -_hy], [_off + _bw, _hy], [_off - _bw, _hy]];
                hrl_append(_out, hrl_raise(_q, _rp * 0.024, 2, _role_face));
            }
        } break;
    }
    return _out;
}

/// How many times a wheel's crossing pattern maps onto itself in one turn.
///
/// ⭐ DECLARED, NOT DERIVED, AND THE SUITE PROVES THE DECLARATION (the same shape as the donor's
/// habit-openness table: make the fast path a declaration and make the test verify it, rather than
/// shipping a cheap proxy that is wrong invisibly). The renderer needs this number to decide
/// whether a wheel may be baked once and drawn rotated.
function hrl_wheel_rot_sym(_w) {
    switch (_w.crossing) {
        case 0: return _w.N;          // a solid web is symmetric with the teeth
        case 7: return 4;
        case 9: return 2;             // parallel bars
        default: return max(3, _w.crossN);
    }
}

/// ============================================================================================
/// SHARED MACHINE GEOMETRY
///
/// ⚠️ THESE TWO LIVE HERE RATHER THAN IN THE FILE THAT FIRST NEEDED THEM, and the move was worth
/// making. `hrl_bar_pts` was written inside hrl_escapement as a private `_hrl_esc_bar`, and by the
/// time the dial builder wanted a baton marker it was being called across files by its underscore
/// name. A private helper used from another file is a lie in the naming, and this package ships as
/// readable source - a buyer opening hrl_dial should not find it reaching into an escapement's
/// internals. Public name, base file, one definition.
/// ============================================================================================

/// A closed bar from (x0,y0) to (x1,y1) of half-width _hw, rotated by _rot about (_ox,_oy).
/// Pass _rot = 0 for no rotation, in which case _ox and _oy are ignored.
function hrl_bar_pts(_x0, _y0, _x1, _y1, _hw, _rot, _ox, _oy) {
    var _dx = _x1 - _x0, _dy = _y1 - _y0;
    var _l = max(0.000001, sqrt(_dx * _dx + _dy * _dy));
    var _nx = -_dy / _l * _hw, _ny = _dx / _l * _hw;
    var _q = [
        [_x0 + _nx, _y0 + _ny], [_x1 + _nx, _y1 + _ny],
        [_x1 - _nx, _y1 - _ny], [_x0 - _nx, _y0 - _ny],
    ];
    if (_rot == 0) return _q;
    var _out = array_create(4);
    for (var _i = 0; _i < 4; _i++) _out[_i] = hrl_rot_pt(_q[_i][0], _q[_i][1], _ox, _oy, _rot);
    return _out;
}

/// Rotate one point about another.
function hrl_rot_pt(_x, _y, _ox, _oy, _rot) {
    var _dx = _x - _ox, _dy = _y - _oy;
    var _c = cos(_rot), _s = sin(_rot);
    return [_ox + _dx * _c - _dy * _s, _oy + _dx * _s + _dy * _c];
}

/// An arm as a closed quad, from radius _r0 to _r1 along angle _a, half-width _w0 at the inner
/// end and _w1 at the outer.
function _hrl_arm_rect(_a, _r0, _r1, _w0, _w1) {
    var _cx = cos(_a), _sy = sin(_a);
    var _nx = -_sy, _ny = _cx;
    return [
        [_cx * _r0 + _nx * _w0, _sy * _r0 + _ny * _w0],
        [_cx * _r1 + _nx * _w1, _sy * _r1 + _ny * _w1],
        [_cx * _r1 - _nx * _w1, _sy * _r1 - _ny * _w1],
        [_cx * _r0 - _nx * _w0, _sy * _r0 - _ny * _w0],
    ];
}

/// A curved arm: the centreline is a quadratic bezier bowed sideways by _bow, and the outline is
/// that centreline offset both ways.
///
/// ⚠️ BOWED IN THE WHEEL'S OWN FRAME, so the curve turns with the wheel and the pattern stays
/// N-fold symmetric. Bowing it in world space would look right on one frame and unwind as the
/// wheel turned.
function _hrl_arm_curve(_a, _r0, _r1, _hw, _bow) {
    var _cx = cos(_a), _sy = sin(_a);
    var _nx = -_sy, _ny = _cx;
    var _p0 = [_cx * _r0, _sy * _r0];
    var _p2 = [_cx * _r1, _sy * _r1];
    var _rm = (_r0 + _r1) * 0.5;
    var _p1 = [_cx * _rm + _nx * (_r1 - _r0) * _bow, _sy * _rm + _ny * (_r1 - _r0) * _bow];
    var _mid = hrl_qbez(_p0, _p1, _p2, 9);
    var _n = array_length(_mid);
    var _left = array_create(_n), _right = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        // Normal from the local tangent, so the width is honest around the bend.
        var _ia = max(0, _i - 1), _ib = min(_n - 1, _i + 1);
        var _tx = _mid[_ib][0] - _mid[_ia][0], _ty = _mid[_ib][1] - _mid[_ia][1];
        var _tl = max(0.000001, sqrt(_tx * _tx + _ty * _ty));
        var _ux = -_ty / _tl, _uy = _tx / _tl;
        _left[_i]  = [_mid[_i][0] + _ux * _hw, _mid[_i][1] + _uy * _hw];
        _right[_i] = [_mid[_i][0] - _ux * _hw, _mid[_i][1] - _uy * _hw];
    }
    var _out = [];
    for (var _i = 0; _i < _n; _i++) array_push(_out, _left[_i]);
    for (var _i = _n - 1; _i >= 0; _i--) array_push(_out, _right[_i]);
    return _out;
}

/// ============================================================================================
/// THE FINISHED WHEEL
/// ============================================================================================

/// Every part of one wheel, in machine units, arbor at the origin.
///
/// PAINTER'S ORDER, and it is the order a wheel is actually made in: blank, then rim relief, then
/// crossings cut out of it, then the hub and collet, then the arbor.
function hrl_wheel_parts(_w, _map) {
    if (!hrl_is_wheel(_w)) return [];
    var _out = [];
    var _rp = hrl_wheel_pitch_r(_w);
    var _rr = hrl_wheel_root_r(_w);
    var _outline = hrl_wheel_outline(_w);

    if (_w.profile == 3) {
        // A lantern pinion: two shroud discs and the pins between them. There is no toothed
        // outline to bevel, so this path is separate rather than a special case inside the other.
        var _shroud = hrl_ellipse_pts(0, 0, _rp * 0.86, _rp * 0.86, 32);
        hrl_append(_out, hrl_ring_fill(_shroud, "m2", 0, 0));
        hrl_append(_out, hrl_bevel(_shroud, _rp * 0.10, 2, false));
        var _pa = hrl_wheel_ang_pitch(_w);
        for (var _k = 0; _k < _w.N; _k++) {
            var _a = _pa * _k;
            hrl_append(_out, hrl_boss(cos(_a) * _rp, sin(_a) * _rp, _w.module * 0.30, 10));
        }
    } else {
        // ⛔⛔ A CROSSED WHEEL IS AN ANNULUS, NOT A DISC WITH SPOKES PAINTED ON IT, AND THE FIRST
        // VERSION GOT THAT WRONG IN A WAY THAT ONLY OPENING THE PICTURE COULD SHOW.
        //
        // It filled the whole toothed outline as one solid blank and then drew the crossings on
        // top. Every assertion passed - the teeth were counted, the mesh was measured, the
        // symmetry was proved - and the hero sheet came back with a stack of dark discs. The
        // reason is physical: CROSSING OUT A WHEEL MEANS CUTTING THE METAL AWAY. The openings are
        // holes, so what shows through them is the plate behind, and a wheel drawn as a solid disc
        // has no depth, hides everything it overlaps, and turns a movement into a pile of coins.
        //
        // ⭐ It also costs nothing and gains the whole picture: with the web open, five wheels
        // overlapping read as five wheels, the frame is visible through them, and the crossings
        // stop being decoration and become the thing they are.
        var _ri = _rr * (1 - _w.rimw);
        var _open = (_w.crossing != 0) && (_ri > hrl_wheel_arbor_r(_w) * 2.6);

        if (_open) {
            // The rim as a band between the toothed outline and a matching inner circle. The
            // inner ring is generated with EXACTLY the outline's point count so the strip pairs
            // up - a strip whose two sides differ in length draws nothing at all, silently.
            var _no = array_length(_outline);
            var _inner_r = array_create(_no);
            for (var _i = 0; _i < _no; _i++) {
                var _a = HRL_TAU * _i / _no;
                _inner_r[_i] = [cos(_a) * _ri, sin(_a) * _ri];
            }
            hrl_append(_out, hrl_strip(_outline, _inner_r, "m2"));
            hrl_append(_out, hrl_bevel(_outline, _w.module * 0.34, 2, false));
            hrl_append(_out, hrl_bevel(_inner_r, _w.module * 0.26, 2, true));
        } else {
            // A solid web: a pinion, a stamped blank, a cast wheel. Filled from its own centre.
            hrl_append(_out, hrl_ring_fill(_outline, "m2", 0, 0));
            hrl_append(_out, hrl_bevel(_outline, _w.module * 0.34, 2, false));
            if (_ri > hrl_wheel_arbor_r(_w) * 2.2) {
                var _inner = hrl_ellipse_pts(0, 0, _ri, _ri, 44);
                hrl_append(_out, hrl_sink(_inner, _w.module * 0.22, 2, "m1"));
            }
        }
    }

    hrl_append(_out, hrl_crossing_parts(_w, "m3", "m1"));

    // The collet - the brass hub the wheel is driven onto - and then the steel arbor through it.
    var _rh = max(hrl_wheel_arbor_r(_w) * 1.9, _rp * _w.hub);
    hrl_append(_out, hrl_boss(0, 0, _rh, 18));
    hrl_append(_out, hrl_dot(0, 0, hrl_wheel_arbor_r(_w), "m0"));

    if (is_undefined(_map)) return _out;
    return hrl_map_roles(_out, _map);
}

/// The radius that bounds every part of a wheel, for layout and for fitting.
function hrl_wheel_extent(_w) {
    if (_w.profile == 3) return hrl_wheel_pitch_r(_w) + _w.module * 0.30;
    return hrl_wheel_tip_r(_w);
}
