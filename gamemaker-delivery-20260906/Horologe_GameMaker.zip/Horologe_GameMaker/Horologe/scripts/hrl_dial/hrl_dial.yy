{
  "$GMScript": "v1",
  "%Name": "hrl_dial",
  "name": "hrl_dial",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}