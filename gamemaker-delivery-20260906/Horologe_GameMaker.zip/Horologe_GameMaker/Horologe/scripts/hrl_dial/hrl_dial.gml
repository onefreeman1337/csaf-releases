/// HOROLOGE - hrl_dial. The face, the figures on it, and the hands that point at them.
///
/// ============================================================================================
/// THE NUMERALS ARE DRAWN, NOT TYPESET, AND THAT IS A PRODUCT DECISION WITH A REASON
///
/// GameMaker can draw text, and the package ships two fonts for its captions. It would have been
/// three lines to put draw_text round a dial. It is not done, and here is why:
///
///   1. A TYPESET NUMERAL CANNOT ROTATE WITH ITS CHAPTER. On a real dial every figure stands
///      upright to the CENTRE, so the VI is upside down relative to the XII. draw_text can be
///      rotated, but then it is a glyph from a font sitting on a metal plate, at whatever
///      hinting and antialiasing the runtime felt like, and it reads as a caption laid over a
///      picture rather than as something engraved into it.
///   2. A DIAL IS ENGRAVED OR PAINTED, SO ITS FIGURES HAVE THE SAME RELIEF AS EVERYTHING ELSE.
///      These go through hrl_incise and hrl_raise like every other mark in the package, so a
///      numeral on a silvered dial is cut into the silvering and one on enamel stands on it.
///   3. THE PACKAGE'S HEADLINE CLAIM IS THAT NOTHING IS AN IMAGE. A font is a texture page.
///
/// ⚠️ THE STROKE FIGURES ARE A DELIBERATELY SMALL ALPHABET: ten digits, three Roman letters, and
/// nothing else. They exist to put numbers on dials and counters. They are not a text system and
/// the Readme says so - a buyer wanting a typeface should use a typeface.
/// ============================================================================================

#macro HRL_DIAL_N 10
#macro HRL_HAND_N 10

/// ============================================================================================
/// THE STROKE ALPHABET
///
/// Every glyph is a list of polylines in a unit cell: x and y both in [-0.5, 0.5], y DOWN, and
/// the glyph's optical centre at the origin so it can be placed by its centre and rotated about
/// it. Widths are handed in by the caller because a numeral on a turret dial and one on a watch
/// dial are the same shape at different weights.
/// ============================================================================================

/// Digits 0-9 as stroked polylines.
///
/// ⚠️ DRAWN AS A CLOCKMAKER'S DIAL WOULD, NOT AS A TYPEFACE. The 1 has a flag and a foot, the 4 is
/// closed, the 7 is unbarred, and the 9 has a straight tail - which is what the figures on English
/// dials actually look like. A geometric sans would be legible and would say "modern interface"
/// on an object whose whole job is to say "made".
function hrl_glyph_digit(_d) {
    var _n = clamp(floor(_d), 0, 9);
    switch (_n) {
        case 0: return [ _hrl_g_oval(0.30, 0.46) ];
        case 1: return [
            [[-0.16, -0.28], [0.02, -0.44], [0.02, 0.44]],
            [[-0.20, 0.44], [0.24, 0.44]],
        ];
        case 2: return [
            [[-0.26, -0.28], [-0.06, -0.45], [0.16, -0.38], [0.20, -0.16],
             [-0.26, 0.44], [0.26, 0.44]],
        ];
        case 3: return [
            [[-0.24, -0.34], [0.04, -0.45], [0.22, -0.28], [0.04, -0.04], [-0.06, -0.04]],
            [[0.04, -0.04], [0.24, 0.12], [0.08, 0.44], [-0.24, 0.36]],
        ];
        case 4: return [
            [[0.10, 0.44], [0.10, -0.45], [-0.26, 0.18], [0.28, 0.18]],
        ];
        case 5: return [
            [[0.22, -0.44], [-0.18, -0.44], [-0.22, -0.06], [0.02, -0.12],
             [0.24, 0.10], [0.06, 0.44], [-0.22, 0.36]],
        ];
        case 6: return [
            [[0.18, -0.42], [-0.10, -0.34], [-0.22, 0.04], [-0.20, 0.32],
             [0.04, 0.45], [0.22, 0.26], [0.10, 0.02], [-0.20, 0.06]],
        ];
        case 7: return [
            [[-0.26, -0.44], [0.26, -0.44], [-0.06, 0.44]],
        ];
        case 8: return [ _hrl_g_oval(0.22, 0.22), _hrl_g_oval_at(0.26, 0.22, 0.22) ];
        default: return [
            [[-0.18, 0.42], [0.10, 0.34], [0.22, -0.04], [0.20, -0.32],
             [-0.04, -0.45], [-0.22, -0.26], [-0.10, -0.02], [0.20, -0.06]],
        ];
    }
}

/// Roman numerals I to XII, built from three letters. Returns polylines in the same unit cell.
///
/// ⛔ IIII, NOT IV, AND IT IS NOT A MISTAKE - IT IS THE CONVENTION. Almost every Roman-figured
/// clock dial ever made uses IIII for four, for balance against the VIII opposite it. A dial with
/// IV on it looks wrong to anyone who has looked at clocks, in a way they usually cannot name.
/// This is the sort of detail a generator gets to be right about for free and a hand-drawn asset
/// pack gets wrong once and ships forever.
function hrl_glyph_roman(_hour) {
    var _h = clamp(floor(_hour), 1, 12);
    var _s = "";
    switch (_h) {
        case 1:  _s = "I";    break;
        case 2:  _s = "II";   break;
        case 3:  _s = "III";  break;
        case 4:  _s = "IIII"; break;
        case 5:  _s = "V";    break;
        case 6:  _s = "VI";   break;
        case 7:  _s = "VII";  break;
        case 8:  _s = "VIII"; break;
        case 9:  _s = "IX";   break;
        case 10: _s = "X";    break;
        case 11: _s = "XI";   break;
        default: _s = "XII";  break;
    }
    var _len = string_length(_s);
    var _adv = 0.30;
    var _w = (_len - 1) * _adv;
    var _out = [];
    for (var _i = 0; _i < _len; _i++) {
        var _c = string_char_at(_s, _i + 1);
        var _ox = -_w * 0.5 + _i * _adv;
        var _g = _hrl_g_letter(_c);
        for (var _j = 0; _j < array_length(_g); _j++) {
            var _p = _g[_j];
            var _q = array_create(array_length(_p));
            for (var _k = 0; _k < array_length(_p); _k++) _q[_k] = [_p[_k][0] + _ox, _p[_k][1]];
            array_push(_out, _q);
        }
    }
    return _out;
}

/// One Roman letter, seriffed. The serifs matter: a bare vertical bar reads as a baton marker and
/// not as the figure one, and on a dial with both the difference is the whole point.
function _hrl_g_letter(_c) {
    switch (_c) {
        case "V": return [
            [[-0.15, -0.42], [0.00, 0.42], [0.15, -0.42]],
            [[-0.24, -0.42], [-0.06, -0.42]],
            [[0.06, -0.42], [0.24, -0.42]],
        ];
        case "X": return [
            [[-0.15, -0.42], [0.15, 0.42]],
            [[0.15, -0.42], [-0.15, 0.42]],
            [[-0.24, -0.42], [-0.06, -0.42]], [[0.06, -0.42], [0.24, -0.42]],
            [[-0.24, 0.42], [-0.06, 0.42]], [[0.06, 0.42], [0.24, 0.42]],
        ];
        default: return [
            [[0.00, -0.42], [0.00, 0.42]],
            [[-0.09, -0.42], [0.09, -0.42]],
            [[-0.09, 0.42], [0.09, 0.42]],
        ];
    }
}

function _hrl_g_oval(_rx, _ry) { return _hrl_g_oval_at(0, _rx, _ry); }

function _hrl_g_oval_at(_cy, _rx, _ry) {
    var _pts = hrl_ellipse_pts(0, _cy - 0.11, _rx, _ry, 16);
    array_push(_pts, _pts[0]);
    return _pts;
}

/// Place a glyph's polylines into machine-unit parts, centred at (_cx,_cy), of height _h, turned
/// by _rot, at stroke half-width _w.
function hrl_glyph_parts(_glyph, _cx, _cy, _h, _rot, _w, _role) {
    var _out = [];
    var _c = cos(_rot), _s = sin(_rot);
    for (var _i = 0; _i < array_length(_glyph); _i++) {
        var _p = _glyph[_i];
        var _q = array_create(array_length(_p));
        for (var _j = 0; _j < array_length(_p); _j++) {
            var _x = _p[_j][0] * _h, _y = _p[_j][1] * _h;
            _q[_j] = [_cx + _x * _c - _y * _s, _cy + _x * _s + _y * _c];
        }
        hrl_append(_out, hrl_poly(_q, false, _w, _role));
    }
    return _out;
}

/// ============================================================================================
/// THE TEN DIALS
/// ============================================================================================

/// A dial plate, in machine units, centred on the origin, of radius _r.
///
/// ⚠️ THE FIGURES STAND UP TO THE CENTRE, WHICH MEANS THE VI IS UPSIDE DOWN. That is what a real
/// dial does and it is the fastest way to tell a drawn dial from a photographed one: an artist
/// keeps the numbers upright because it looks tidier, and it is wrong. The rotation here is the
/// chapter's own angle plus a quarter turn, which puts every figure's foot toward the centre.
function hrl_dial_parts(_kind, _r, _m, _map) {
    var _k = clamp(_kind, 0, HRL_DIAL_N - 1);
    var _out = [];
    var _plate = hrl_ellipse_pts(0, 0, _r, _r, 64);

    // -- the ground -----------------------------------------------------------------------
    // 9 is a SKELETON chapter ring: no plate at all, so the movement shows through it. That is
    // one of the two reasons a buyer would want this product rather than a picture of a clock.
    if (_k != 9) {
        hrl_append(_out, hrl_ring_fill(_plate, "m3", 0, 0));
        hrl_append(_out, hrl_bevel(_plate, _r * 0.055, 2, false));
    }

    var _rc = _r * 0.84;                  // chapter ring radius
    // ⚠️ 0.105, NOT 0.15. The first version made every figure fifteen percent of the dial radius,
    // which is what a diagram does; a real chapter ring gives its figures about a tenth, and the
    // difference between the two is the difference between a dial and a clip-art clock. Measured
    // by opening the sheet: at 0.15 the Roman XII touched its neighbours and the calendar ring's
    // thirty-one figures ran into each other.
    var _fh = _r * 0.105;                 // figure height
    var _lw = max(_m * 0.06, _r * 0.013); // stroke half-width for figures

    switch (_k) {

        // -- 0. ROMAN CHAPTER RING. The English longcase dial.
        case 0: {
            hrl_append(_out, _hrl_chapter_rings(_r, _m, true));
            for (var _h = 1; _h <= 12; _h++) {
                var _a = HRL_TAU * (_h / 12) - pi * 0.5;
                hrl_append(_out, hrl_glyph_parts(hrl_glyph_roman(_h),
                    cos(_a) * _rc, sin(_a) * _rc, _fh, _a + pi * 0.5, _lw, "m0"));
            }
            hrl_append(_out, _hrl_minute_track(_r, _m, 60, 5));
        } break;

        // -- 1. ARABIC CHAPTER RING.
        case 1: {
            hrl_append(_out, _hrl_chapter_rings(_r, _m, true));
            for (var _h = 1; _h <= 12; _h++) {
                var _a = HRL_TAU * (_h / 12) - pi * 0.5;
                hrl_append(_out, _hrl_number(_h, cos(_a) * _rc, sin(_a) * _rc,
                                             _fh, _a + pi * 0.5, _lw, "m0"));
            }
            hrl_append(_out, _hrl_minute_track(_r, _m, 60, 5));
        } break;

        // -- 2. REGULATOR. Hours, minutes and seconds on three SEPARATE dials, so no two hands
        // ever overlap and the minute hand can be read to the second. It is what an observatory
        // clock looks like, and it is the layout that most obviously needs a generator: three
        // chapter rings at three sizes with three sets of figures.
        case 2: {
            hrl_append(_out, _hrl_minute_track(_r, _m, 60, 5));
            hrl_append(_out, _hrl_chapter_rings(_r, _m, false));
            for (var _mi = 0; _mi < 12; _mi++) {
                var _a = HRL_TAU * (_mi / 12) - pi * 0.5;
                hrl_append(_out, _hrl_number(_mi * 5, cos(_a) * _rc, sin(_a) * _rc,
                                             _fh * 0.9, _a + pi * 0.5, _lw, "m0"));
            }
            // ⚠️ FOUR FIGURES PER SUBDIAL, NOT TWELVE. The first version marked every hour on a
            // subdial a quarter the size of the main one, so twelve numerals at a quarter scale
            // overlapped into an unreadable smear - and the same for sixty seconds in steps of
            // five. A real regulator's subsidiary dials carry the quarters and nothing else, for
            // exactly this reason: there is no room, and the hand tells you the rest.
            hrl_append(_out, _hrl_subdial(0, -_r * 0.42, _r * 0.26, _m, 12, 3, _lw));
            hrl_append(_out, _hrl_subdial(0,  _r * 0.44, _r * 0.24, _m, 60, 15, _lw));
        } break;

        // -- 3. TWENTY-FOUR HOUR. One turn a day, so noon is at the top and midnight at the
        // bottom - the dial a game with a day/night cycle actually wants, because the hand's
        // position IS the time of day rather than a thing you have to disambiguate.
        case 3: {
            hrl_append(_out, _hrl_chapter_rings(_r, _m, true));
            for (var _h = 0; _h < 24; _h++) {
                var _a = HRL_TAU * (_h / 24) + pi * 0.5;
                var _big = (_h mod 6 == 0);
                hrl_append(_out, _hrl_number(_h, cos(_a) * _rc, sin(_a) * _rc,
                                             _fh * (_big ? 0.92 : 0.66), _a + pi * 0.5,
                                             _lw * (_big ? 1 : 0.8), "m0"));
            }
            hrl_append(_out, _hrl_minute_track(_r, _m, 24 * 4, 4));
        } break;

        // -- 4. MOONPHASE. A shaped aperture through the dial with the moon disc behind it. The
        // aperture is the classic double-humped one, cut so the moon appears to wax and wane
        // rather than to slide past a hole.
        case 4: {
            hrl_append(_out, _hrl_chapter_rings(_r, _m, true));
            for (var _h = 1; _h <= 12; _h++) {
                var _a = HRL_TAU * (_h / 12) - pi * 0.5;
                hrl_append(_out, hrl_glyph_parts(hrl_glyph_roman(_h),
                    cos(_a) * _rc, sin(_a) * _rc, _fh * 0.86, _a + pi * 0.5, _lw, "m0"));
            }
            // ⭐ THE MOON GOES IN BEFORE THE APERTURE, WHICH IS WHY THIS READS AS A WINDOW RATHER
            // THAN AS A LEAF. The first version cut the shaped opening and put nothing behind it,
            // so the "aperture" was a grey lens sitting on the dial with no reason to exist. A
            // moonphase is a hole with a painted disc turning behind it, and the disc is the point.
            var _aw = _r * 0.46, _ah = _r * 0.30, _ay = -_r * 0.30;
            var _ap = [];
            for (var _i = 0; _i <= 26; _i++) {
                var _u = -1 + 2 * (_i / 26);
                array_push(_ap, [_u * _aw, _ay - _ah * (0.30 + 0.70 * cos(_u * pi * 0.5))]);
            }
            for (var _i = 26; _i >= 0; _i--) {
                var _u = -1 + 2 * (_i / 26);
                array_push(_ap, [_u * _aw, _ay + _ah * 0.66 * cos(_u * pi * 0.5)]);
            }
            // The opening: a dark pocket cut through the dial.
            hrl_append(_out, hrl_ring_fill(_ap, "m0", 0, _ay));
            hrl_append(_out, hrl_bevel(_ap, _r * 0.024, 2, true));

            // ⭐ AND THE MOON INSIDE IT, WHICH THE FIRST VERSION LEFT OUT ENTIRELY. Without a disc
            // behind it the aperture is a grey lens sitting on a dial for no reason - which is
            // what the sheet showed. A moonphase is a HOLE WITH A PAINTED DISC TURNING BEHIND IT,
            // and the disc is the whole point of the complication.
            //
            // ⚠️ The moon is sized to fit the aperture AT ITS OWN x, not at the aperture's widest.
            // A shape is only as tall as its bounding box at one height (the wing's own law), and
            // a moon sized against the centre height pokes out through the narrowing ends.
            var _mx = _aw * 0.30;
            var _u2 = _mx / _aw;
            var _half_up = _ah * (0.30 + 0.70 * cos(_u2 * pi * 0.5));
            var _half_dn = _ah * 0.66 * cos(_u2 * pi * 0.5);
            // ⚠️ THE MOON IS BOUNDED BY THE SHALLOWER HALF OF THE APERTURE, and with the lower
            // half at a third of the upper it came out a third of the size it should be - a small
            // disc in a slot rather than a moon in a window. The aperture's two humps are now
            // nearer equal, which is also what the ones on real dials look like.
            var _mr = min(_half_up, _half_dn) * 0.92;
            var _mcy = _ay + (_half_dn - _half_up) * 0.10;
            var _moon = hrl_ellipse_pts(_mx, _mcy, _mr, _mr, 24);
            hrl_append(_out, hrl_raise(_moon, _mr * 0.40, 3, "m4"));
            hrl_append(_out, hrl_pit(_mx - _mr * 0.30, _mcy - _mr * 0.24, _mr * 0.26, 10));
            hrl_append(_out, hrl_pit(_mx + _mr * 0.32, _mcy + _mr * 0.12, _mr * 0.18, 10));
            hrl_append(_out, hrl_pit(_mx - _mr * 0.06, _mcy + _mr * 0.42, _mr * 0.14, 8));
            hrl_append(_out, hrl_incise(_ap, true, max(HRL_MIN_STROKE, _r * 0.012)));
        } break;

        // -- 5. CALENDAR RING. The days of the month round the outside, read against a pointer.
        case 5: {
            hrl_append(_out, _hrl_chapter_rings(_r, _m, true));
            for (var _d = 1; _d <= 31; _d++) {
                var _a = HRL_TAU * ((_d - 1) / 31) - pi * 0.5;
                hrl_append(_out, _hrl_number(_d, cos(_a) * _r * 0.92, sin(_a) * _r * 0.92,
                                             _fh * 0.52, _a + pi * 0.5, _lw * 0.8, "m0"));
            }
            for (var _h = 1; _h <= 12; _h++) {
                var _a2 = HRL_TAU * (_h / 12) - pi * 0.5;
                hrl_append(_out, hrl_glyph_parts(hrl_glyph_roman(_h),
                    cos(_a2) * _r * 0.68, sin(_a2) * _r * 0.68, _fh * 0.80,
                    _a2 + pi * 0.5, _lw, "m0"));
            }
        } break;

        // -- 6. TIDE DIAL. High water at the top, low at the bottom, and the lunar day of 24 h 50
        // min round the edge - a real thing on real coastal clocks, and free content for any game
        // with a harbour in it.
        case 6: {
            hrl_append(_out, _hrl_chapter_rings(_r, _m, true));
            hrl_append(_out, _hrl_minute_track(_r, _m, 48, 4));
            for (var _i = 0; _i < 4; _i++) {
                var _a = HRL_TAU * (_i / 4) - pi * 0.5;
                var _wedge = [
                    [0, 0],
                    [cos(_a - 0.22) * _r * 0.70, sin(_a - 0.22) * _r * 0.70],
                    [cos(_a) * _r * 0.80, sin(_a) * _r * 0.80],
                    [cos(_a + 0.22) * _r * 0.70, sin(_a + 0.22) * _r * 0.70],
                ];
                hrl_append(_out, hrl_raise(_wedge, _r * 0.020, 2, (_i mod 2 == 0) ? "m4" : "m1"));
            }
            for (var _i = 0; _i < 12; _i++) {
                var _a3 = HRL_TAU * (_i / 12) - pi * 0.5;
                hrl_append(_out, _hrl_number(_i * 2, cos(_a3) * _rc, sin(_a3) * _rc,
                                             _fh * 0.62, _a3 + pi * 0.5, _lw * 0.8, "m0"));
            }
        } break;

        // -- 7. ZODIAC PLATE. The astrolabe's rete: an eccentric ecliptic circle carrying the
        // twelve signs, over a stereographic grid. It is the most complicated thing on this dial
        // list and the one that most obviously could not be an icon.
        case 7: {
            hrl_append(_out, hrl_ring(0, 0, _r * 0.94, _m * 0.10, "m1"));
            for (var _i = 1; _i <= 3; _i++) {
                hrl_append(_out, hrl_ring(0, 0, _r * 0.94 * (_i / 3.4), _m * 0.06, "m1"));
            }
            for (var _i = 0; _i < 24; _i++) {
                var _a = HRL_TAU * _i / 24;
                hrl_append(_out, hrl_poly([[cos(_a) * _r * 0.12, sin(_a) * _r * 0.12],
                                           [cos(_a) * _r * 0.94, sin(_a) * _r * 0.94]],
                                          false, _m * 0.05, "m1"));
            }
            // The ecliptic: a circle offset from the centre, which is what makes a rete a rete.
            var _ex = 0, _ey = -_r * 0.22, _er = _r * 0.64;
            hrl_append(_out, hrl_ring(_ex, _ey, _er, _m * 0.14, "m4"));
            for (var _i = 0; _i < 12; _i++) {
                var _a4 = HRL_TAU * _i / 12 - pi * 0.5;
                hrl_append(_out, _hrl_number(_i + 1, _ex + cos(_a4) * _er,
                                             _ey + sin(_a4) * _er, _fh * 0.48,
                                             _a4 + pi * 0.5, _lw * 0.7, "m0"));
            }
        } break;

        // -- 8. ENGINE-TURNED BLANK. No figures at all: applied batons on a barleycorn ground.
        // The engine-turning is a real guilloche - a rose engine cuts a hypotrochoid, so that is
        // what is drawn, rather than concentric rings pretending.
        case 8: {
            var _petals = 24;
            var _gp = [];
            var _steps = 360;
            for (var _i = 0; _i <= _steps; _i++) {
                var _th = HRL_TAU * (_i / _steps) * 5;
                var _rr = _r * (0.55 + 0.28 * cos(_th * _petals / 5));
                array_push(_gp, [cos(_th) * _rr, sin(_th) * _rr]);
            }
            hrl_append(_out, hrl_poly(_gp, false, max(HRL_MIN_STROKE * 0.5, _m * 0.035), "m1"));
            hrl_append(_out, _hrl_chapter_rings(_r, _m, true));
            for (var _h = 0; _h < 12; _h++) {
                var _a5 = HRL_TAU * (_h / 12) - pi * 0.5;
                var _b0 = [cos(_a5) * _r * 0.74, sin(_a5) * _r * 0.74];
                var _b1 = [cos(_a5) * _r * 0.88, sin(_a5) * _r * 0.88];
                var _bar = hrl_bar_pts(_b0[0], _b0[1], _b1[0], _b1[1], _r * 0.020, 0, 0, 0);
                hrl_append(_out, hrl_raise(_bar, _r * 0.012, 2, "m4"));
            }
        } break;

        // -- 9. SKELETON CHAPTER RING. A ring of figures and nothing behind them, so the movement
        // is the dial. There is no plate, on purpose - see the top of this function.
        default: {
            hrl_append(_out, hrl_ring(0, 0, _r * 0.96, _m * 0.16, "m4"));
            hrl_append(_out, hrl_ring(0, 0, _r * 0.70, _m * 0.10, "m4"));
            for (var _h = 1; _h <= 12; _h++) {
                var _a6 = HRL_TAU * (_h / 12) - pi * 0.5;
                hrl_append(_out, hrl_glyph_parts(hrl_glyph_roman(_h),
                    cos(_a6) * _r * 0.83, sin(_a6) * _r * 0.83, _fh, _a6 + pi * 0.5,
                    _lw * 1.15, "m4"));
            }
        } break;
    }

    if (is_undefined(_map)) return _out;
    return hrl_map_roles(_out, _map);
}

/// The two rings that bound a chapter ring. `_inner` adds the inner one.
function _hrl_chapter_rings(_r, _m, _inner) {
    var _out = [];
    // Proportional for the same reason as the minute track below it - a chapter ring is laid out
    // against the dial, not against the tooth size of the movement behind it.
    hrl_append(_out, hrl_ring(0, 0, _r * 0.955, max(HRL_MIN_STROKE * 0.5, _r * 0.008), "m1"));
    if (_inner) hrl_append(_out, hrl_ring(0, 0, _r * 0.72, max(HRL_MIN_STROKE * 0.5, _r * 0.007), "m1"));
    return _out;
}

/// The minute track: _n divisions with every _major-th one longer.
///
/// ⛔ THE TICK LENGTH IS PROPORTIONAL, AND CAPPING IT IN MACHINE UNITS WAS WRONG. The first version
/// bounded it at `_m * 1.5` - one and a half tooth widths - on a dial eighty modules across, so
/// every division was under two percent of the radius and the whole track read as a scatter of
/// dots round the bezel. The physical-detail law from hrl_geom does NOT apply here: a chapter
/// ring's divisions are laid out as a proportion of the dial by every clockmaker who has ever cut
/// one, because they exist to be read from a distance that scales with the clock. Engine-turning
/// is physical; a minute track is not, and knowing which is which is the whole of that law.
function _hrl_minute_track(_r, _m, _n, _major) {
    var _out = [];
    var _w = max(HRL_MIN_STROKE * 0.5, _r * 0.006);
    for (var _i = 0; _i < _n; _i++) {
        var _a = HRL_TAU * _i / _n - pi * 0.5;
        var _long = (_i mod _major == 0);
        var _l = _r * (_long ? 0.075 : 0.042);
        var _r0 = _r * 0.955;
        hrl_append(_out, hrl_poly([[cos(_a) * (_r0 - _l), sin(_a) * (_r0 - _l)],
                                   [cos(_a) * _r0, sin(_a) * _r0]],
                                  false, _w * (_long ? 1.6 : 1), "m0"));
    }
    return _out;
}

/// A subsidiary dial - its own ring, figures and track, sunk into the main plate.
/// A subsidiary dial - its own ring, figures and track, recessed into the main plate.
///
/// ⚠️ THE RECESS FACE IS `m3`, NOT `m1`, AND THE DARK VERSION READ AS A HOLE. A sunken panel on a
/// silvered dial is still silvered - it is a step down, not an opening - so its face belongs near
/// the plate's own value with the WALL carrying the depth. Set to the darkest stop it looked like
/// two holes punched in the dial, which is exactly what the hero sheet showed.
function _hrl_subdial(_cx, _cy, _r, _m, _count, _step, _lw) {
    var _out = [];
    var _ring = hrl_ellipse_pts(_cx, _cy, _r, _r, 34);
    hrl_append(_out, hrl_sink(_ring, _r * 0.09, 2, "m3"));
    hrl_append(_out, hrl_ring(_cx, _cy, _r * 0.92, max(HRL_MIN_STROKE * 0.5, _r * 0.030), "m1"));
    var _marks = floor(_count / _step);
    // Its own minute track, so a subdial reads as a dial rather than as a disc with numbers on it.
    for (var _i = 0; _i < _count; _i += max(1, floor(_step / 3))) {
        var _at = HRL_TAU * _i / _count - pi * 0.5;
        hrl_append(_out, hrl_poly([[_cx + cos(_at) * _r * 0.80, _cy + sin(_at) * _r * 0.80],
                                   [_cx + cos(_at) * _r * 0.91, _cy + sin(_at) * _r * 0.91]],
                                  false, max(HRL_MIN_STROKE * 0.5, _r * 0.022), "m0"));
    }
    for (var _i = 0; _i < _marks; _i++) {
        var _a = HRL_TAU * _i / _marks - pi * 0.5;
        hrl_append(_out, _hrl_number(_i * _step, _cx + cos(_a) * _r * 0.60,
                                     _cy + sin(_a) * _r * 0.60, _r * 0.30,
                                     _a + pi * 0.5, _lw * 0.85, "m0"));
    }
    return _out;
}

/// A whole number, laid out as digits.
function _hrl_number(_v, _cx, _cy, _h, _rot, _w, _role) {
    var _s = string(floor(_v));
    var _len = string_length(_s);
    var _adv = _h * 0.62;
    var _total = (_len - 1) * _adv;
    var _out = [];
    var _c = cos(_rot), _sn = sin(_rot);
    for (var _i = 0; _i < _len; _i++) {
        var _d = real(string_char_at(_s, _i + 1));
        var _ox = -_total * 0.5 + _i * _adv;
        hrl_append(_out, hrl_glyph_parts(hrl_glyph_digit(_d),
            _cx + _ox * _c, _cy + _ox * _sn, _h, _rot, _w, _role));
    }
    return _out;
}

/// ============================================================================================
/// THE TEN HANDS
///
/// ⭐ A HAND IS THE ONE PART OF A CLOCK EVERY PLAYER LOOKS DIRECTLY AT, and the ten forms here are
/// the ten a clockmaker would name. They are drawn pointing UP the negative y axis at zero
/// rotation, because that is twelve o'clock, and hrl_machine turns them by the arbor's own angle.
///
/// ⚠️ THE COUNTERPOISE IS NOT DECORATION. Every hand here extends a short way BEHIND its centre,
/// because a real hand is balanced about its pivot or it would stop the clock. It also reads
/// correctly: a hand with nothing behind the boss looks stuck on.
/// ============================================================================================

function hrl_hand_parts(_kind, _len, _m, _map) {
    var _k = clamp(_kind, 0, HRL_HAND_N - 1);
    var _out = [];
    // ⛔⛔ THE WIDTH COMES FROM THE HAND'S OWN LENGTH, NOT FROM THE MODULE, AND THE FIRST VERSION
    // GOT THAT EXACTLY BACKWARDS. It used `_w * 0.51` - three tenths of one tooth - on a hand
    // reaching most of the way across a dial eighty modules wide, so every hand in the package was
    // drawn about half a percent of the dial's width. On the hero sheet they were a faint blue
    // scratch and could not be found at all until somebody went looking for them.
    //
    // ⭐ A hand is one of the few things in this package that is NOT a physical detail: it is sized
    // to the dial it has to be read against, which is why a turret clock's minute hand is a metre
    // long and a watch's is a centimetre. So it scales with its length, and the module floor is
    // only there to stop a very short hand becoming a hairline.
    //
    // ⚠️ 0.075, NOT 0.045, AND THE THIN VERSION MADE ALL TEN HANDS THE SAME HAND. At a twenty-two
    // to one aspect a spade's shield, a cathedral's lobes and a fleur-de-lys's three leaves are all
    // a couple of pixels wide, so the sheet showed ten vertical slivers with captions under them.
    // A real minute hand is nearer ten to one at the base, and the FORM is the whole reason there
    // are ten of them.
    var _w = max(_m * 0.22, _len * 0.075);
    // The counterpoise. Short, because a hand is balanced by a small weight close in rather than
    // by a long tail - and a long one reads as a second, shorter hand pointing the other way.
    var _tail = _len * 0.13;

    switch (_k) {

        // -- 0. SPADE. A taper that swells into a shield near the tip. The English standard.
        case 0: {
            var _p = [
                [-_w * 0.6, _tail], [_w * 0.6, _tail],
                [_w * 0.45, -_len * 0.52],
                [_w * 1.5, -_len * 0.62], [_w * 1.2, -_len * 0.82],
                [0, -_len], [-_w * 1.2, -_len * 0.82], [-_w * 1.5, -_len * 0.62],
                [-_w * 0.45, -_len * 0.52],
            ];
            hrl_append(_out, hrl_raise(_p, _w * 0.24, 2, "m4"));
        } break;

        // -- 1. BREGUET. A plain taper with a pierced circle - a "moon" - near the tip. The most
        // copied hand ever made, and the piercing is a real hole, not a dark dot.
        case 1: {
            var _p = [[-_w * 0.5, _tail], [_w * 0.5, _tail], [_w * 0.22, -_len], [-_w * 0.22, -_len]];
            hrl_append(_out, hrl_raise(_p, _w * 0.20, 2, "m4"));
            var _mr = _w * 1.44;
            hrl_append(_out, hrl_ring(0, -_len * 0.80, _mr, _w * 0.27, "m4"));
        } break;

        // -- 2. POKER. A plain straight taper, and nothing else. It belongs on a regulator, where
        // anything ornamental would get in the way of reading the dial.
        case 2: {
            var _p = [[-_w * 0.55, _tail], [_w * 0.55, _tail], [_w * 0.16, -_len], [-_w * 0.16, -_len]];
            hrl_append(_out, hrl_raise(_p, _w * 0.20, 2, "m4"));
        } break;

        // -- 3. CATHEDRAL. A long pierced body with two lobes, the church-clock hand.
        case 3: {
            var _p = [
                [-_w * 0.7, _tail], [_w * 0.7, _tail],
                [_w * 0.5, -_len * 0.34],
                [_w * 1.35, -_len * 0.48], [_w * 0.4, -_len * 0.62],
                [_w * 1.05, -_len * 0.76], [_w * 0.28, -_len * 0.88],
                [0, -_len],
                [-_w * 0.28, -_len * 0.88], [-_w * 1.05, -_len * 0.76],
                [-_w * 0.4, -_len * 0.62], [-_w * 1.35, -_len * 0.48],
                [-_w * 0.5, -_len * 0.34],
            ];
            hrl_append(_out, hrl_raise(_p, _w * 0.22, 2, "m4"));
        } break;

        // -- 4. FLEUR-DE-LYS. Three lobes at the tip. French, and unmistakable at any size.
        // The three leaves are drawn as one outline plus two side lobes, and they are placed at
        // 0.66 of the length rather than at the tip - a fleur-de-lys hand carries its ornament
        // where the eye lands, not on the point it has to read a division with.
        case 4: {
            var _p = [[-_w * 0.50, _tail], [_w * 0.50, _tail],
                      [_w * 0.26, -_len * 0.55], [-_w * 0.26, -_len * 0.55]];
            hrl_append(_out, hrl_raise(_p, _w * 0.20, 2, "m4"));
            hrl_append(_out, hrl_raise([[0, -_len], [_w * 0.62, -_len * 0.66],
                                        [0, -_len * 0.55], [-_w * 0.62, -_len * 0.66]],
                                       _w * 0.20, 2, "m4"));
            hrl_append(_out, hrl_raise([[_w * 0.40, -_len * 0.55], [_w * 1.65, -_len * 0.72],
                                        [_w * 1.30, -_len * 0.52], [_w * 0.40, -_len * 0.46]],
                                       _w * 0.18, 2, "m4"));
            hrl_append(_out, hrl_raise([[-_w * 0.40, -_len * 0.55], [-_w * 1.65, -_len * 0.72],
                                        [-_w * 1.30, -_len * 0.52], [-_w * 0.40, -_len * 0.46]],
                                       _w * 0.18, 2, "m4"));
        } break;

        // -- 5. SYRINGE. A hollow rectangle running most of the length, then a point.
        case 5: {
            var _p = [
                [-_w * 0.75, _tail], [_w * 0.75, _tail],
                [_w * 0.75, -_len * 0.80], [0, -_len], [-_w * 0.75, -_len * 0.80],
            ];
            hrl_append(_out, hrl_raise(_p, _w * 0.24, 2, "m4"));
            hrl_append(_out, hrl_sink([[-_w * 0.34, -_len * 0.18], [_w * 0.34, -_len * 0.18],
                                       [_w * 0.34, -_len * 0.72], [-_w * 0.34, -_len * 0.72]],
                                      _w * 0.14, 1, "m1"));
        } break;

        // -- 6. BATON. A flat bar of even width. Modern, and the right hand for an instrument.
        case 6: {
            var _p = [[-_w * 0.5, _tail], [_w * 0.5, _tail], [_w * 0.5, -_len], [-_w * 0.5, -_len]];
            hrl_append(_out, hrl_raise(_p, _w * 0.20, 2, "m4"));
        } break;

        // -- 7. SERPENTINE. An S-curved body. The hardest of the ten to draw and the one that
        // most obviously repays being generated: it is a real bezier, offset both ways.
        case 7: {
            var _mid = hrl_qbez([0, _tail], [_w * 3.4, -_len * 0.45], [0, -_len], 14);
            var _n = array_length(_mid);
            var _p = [];
            for (var _i = 0; _i < _n; _i++) {
                var _t = _i / (_n - 1);
                array_push(_p, [_mid[_i][0] + _w * 0.5 * (1 - _t * 0.7), _mid[_i][1]]);
            }
            for (var _i = _n - 1; _i >= 0; _i--) {
                var _t = _i / (_n - 1);
                array_push(_p, [_mid[_i][0] - _w * 0.5 * (1 - _t * 0.7), _mid[_i][1]]);
            }
            hrl_append(_out, hrl_raise(_p, _w * 0.19, 2, "m4"));
        } break;

        // -- 8. ALPHA. A leaf: widest a third of the way along, tapering to a point.
        case 8: {
            var _p = [];
            var _seg = 12;
            for (var _i = 0; _i <= _seg; _i++) {
                var _t = _i / _seg;
                var _y = lerp(_tail, -_len, _t);
                var _hw = _w * 1.3 * sin(pi * power(_t, 0.75));
                array_push(_p, [max(_w * 0.12, _hw), _y]);
            }
            for (var _i = _seg; _i >= 0; _i--) {
                var _t = _i / _seg;
                var _y = lerp(_tail, -_len, _t);
                var _hw = _w * 1.3 * sin(pi * power(_t, 0.75));
                array_push(_p, [-max(_w * 0.12, _hw), _y]);
            }
            hrl_append(_out, hrl_raise(_p, _w * 0.20, 2, "m4"));
        } break;

        // -- 9. SKELETON WITH COUNTERPOISE. Almost nothing at the pointing end and a heavy tail,
        // which is what a long seconds hand needs so it does not load the escapement.
        default: {
            var _p = [[-_w * 0.28, _tail * 2.4], [_w * 0.28, _tail * 2.4],
                      [_w * 0.16, -_len], [-_w * 0.16, -_len]];
            hrl_append(_out, hrl_raise(_p, _w * 0.17, 2, "m4"));
            hrl_append(_out, hrl_boss(0, _tail * 2.4, _w * 1.05, 12));
        } break;
    }

    // The boss the hand is fitted onto. Every hand has one and it is what hides the joint. Sized
    // against the hand for the same reason as the width above.
    hrl_append(_out, hrl_boss(0, 0, max(_w * 0.78, _len * 0.055), 14));

    if (is_undefined(_map)) return _out;
    return hrl_map_roles(_out, _map);
}
