{
  "$GMScript": "v1",
  "%Name": "hrl_train",
  "name": "hrl_train",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}