{
  "$GMScript": "v1",
  "%Name": "hrl_drive",
  "name": "hrl_drive",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}