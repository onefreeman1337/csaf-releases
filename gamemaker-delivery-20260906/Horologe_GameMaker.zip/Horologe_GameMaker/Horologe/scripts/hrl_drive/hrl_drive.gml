/// HOROLOGE - hrl_drive. Where the power comes from, and how it is kept even.
///
/// ============================================================================================
/// SIX DRIVES, AND EACH ONE IS A DIFFERENT ANSWER TO ONE PROBLEM
///
/// A weight pulls with exactly the same force from top to bottom, and it needs headroom. A spring
/// pulls hard when wound and weakly when nearly run down, and it fits in a pocket. Everything in
/// this file is an answer to that trade, and a game that shows the answer is telling the player
/// something about the object: a fusee says "expensive and accurate", a going barrel says
/// "ordinary", a weight on a line says "this clock has been here a long time".
///
/// ⚠️ THE DRIVE IS DRAWN, NOT SIMULATED. hrl_train's rates come from tooth counts and the
/// escapement, and none of these change them - a mainspring running down does not slow a real
/// clock much either, which is the whole reason the fusee exists. Saying so here is more honest
/// than implying a torque model that is not there. What IS live is the WIND: hrl_drive_parts takes
/// a 0..1 wind level and the barrel's click, the fusee's chain and the weight's height all move
/// with it, so a buyer can drive it from their own "the player wound the clock" state.
/// ============================================================================================

#macro HRL_DRIVE_N 6

/// The drive's parts, in machine units, centred on the driving arbor at (_x,_y).
///
///   _wind   0 = fully run down, 1 = fully wound
///   _angle  the driving arbor's own angle, so anything fixed to it turns with it
function hrl_drive_parts(_kind, _x, _y, _r, _m, _wind, _angle, _map) {
    var _k = clamp(_kind, 0, HRL_DRIVE_N - 1);
    var _w = clamp(_wind, 0, 1);
    var _out = [];

    switch (_k) {

        // -- 0. WEIGHT AND LINE. A grooved barrel, a gut line, and a weight that hangs lower as
        // the clock runs. The oldest and the most accurate source of power there is.
        case 0: {
            var _br = _r * 0.62;
            var _drum = hrl_ellipse_pts(_x, _y, _br, _br, 34);
            hrl_append(_out, hrl_raise(_drum, _m * 0.55, 3, "m2"));
            // The grooves, cut as a spiral so the line lies in one layer - which is what stops a
            // weight-driven clock changing rate as it runs.
            for (var _i = 1; _i <= 5; _i++) {
                hrl_append(_out, hrl_ring(_x, _y, _br * (_i / 6),
                                          max(HRL_MIN_STROKE * 0.5, _m * 0.06), "m1"));
            }
            // ⚠️ SHORTENED. The drop was up to 4.8 times the drum radius, which on a movement
            // whose great wheel is a third of the plate ran the line and its weight far outside
            // the frame - visible on the first hero sheet as a stray hairline crossing the plate
            // and ending in a dot. A weight-driven clock's fall IS enormous in life; what belongs
            // in a picture of the MOVEMENT is the first part of it.
            var _drop = _r * (1.1 + (1 - _w) * 1.5);
            hrl_append(_out, hrl_poly([[_x + _br, _y], [_x + _br, _y + _drop]], false,
                                      max(HRL_MIN_STROKE, _m * 0.10), "m0"));
            // The weight: a plain turned cylinder with a cap, hanging from the line.
            var _wy = _y + _drop;
            var _wt = hrl_pts_round(_x + _br - _m * 1.1, _wy, _x + _br + _m * 1.1,
                                    _wy + _m * 4.2, _m * 0.5, 5);
            hrl_append(_out, hrl_raise(_wt, _m * 0.42, 3, "m3"));
            hrl_append(_out, hrl_ring(_x + _br, _wy + _m * 0.6, _m * 0.9,
                                      max(HRL_MIN_STROKE * 0.5, _m * 0.10), "m1"));
        } break;

        // -- 1. GOING BARREL. A drum with the mainspring coiled inside it, driving directly. The
        // spring is visible through the barrel's openings and it COILS TIGHTER as the wind rises,
        // which is drawn as a real spiral whose turns close up rather than as more lines.
        case 1: {
            var _br1 = _r * 0.86;
            var _bar = hrl_ellipse_pts(_x, _y, _br1, _br1, 40);
            hrl_append(_out, hrl_raise(_bar, _m * 0.50, 3, "m2"));
            hrl_append(_out, _hrl_mainspring(_x, _y, _br1 * 0.84, _m, _w, _angle));
            hrl_append(_out, hrl_ring(_x, _y, _br1 * 0.94,
                                      max(HRL_MIN_STROKE * 0.5, _m * 0.12), "m1"));
            hrl_append(_out, hrl_boss(_x, _y, _m * 0.9, 14));
        } break;

        // -- 2. FUSEE AND CHAIN. A cone, wound with a chain from the barrel. As the spring
        // weakens the chain works on a wider part of the cone, so the torque delivered stays
        // constant. It is the most elegant mechanical solution in this whole product, and you can
        // see it working: the chain moves along the cone as the wind falls.
        case 2: {
            var _fh = _r * 1.9;
            var _steps = 9;
            for (var _i = 0; _i < _steps; _i++) {
                var _t = _i / (_steps - 1);
                var _rr = _r * lerp(0.86, 0.30, _t);
                var _yy = _y - _fh * 0.5 + _fh * _t;
                var _grv = hrl_ellipse_pts(_x, _yy, _rr, _rr * 0.30, 22);
                hrl_append(_out, hrl_raise(_grv, _m * 0.18, 2, "m2"));
            }
            // The chain sits at the wind's own height on the cone.
            var _ct = 1 - _w;
            var _cr = _r * lerp(0.86, 0.30, _ct);
            var _cy = _y - _fh * 0.5 + _fh * _ct;
            var _chain = [];
            for (var _i = 0; _i <= 10; _i++) {
                array_push(_chain, [_x + _cr + (_i / 10) * _r * 2.2, _cy + (_i / 10) * _r * 0.30]);
            }
            hrl_append(_out, hrl_poly(_chain, false, max(HRL_MIN_STROKE, _m * 0.14), "m0"));
            for (var _i = 0; _i <= 10; _i += 2) {
                hrl_append(_out, hrl_boss(_chain[_i][0], _chain[_i][1], _m * 0.16, 6));
            }
        } break;

        // -- 3. SPRING BARREL WITH CLICK AND RATCHET. The winding side: a ratchet wheel and a
        // sprung click that lets it wind one way and holds it the other. The click is the part
        // that makes the noise everyone recognises.
        case 3: {
            var _rw = hrl_wheel_new(14, _m * 0.9, 2, 0);
            var _ro = hrl_wheel_outline(_rw);
            var _rot = array_create(array_length(_ro));
            for (var _i = 0; _i < array_length(_ro); _i++) {
                _rot[_i] = hrl_rot_pt(_ro[_i][0] + _x, _ro[_i][1] + _y, _x, _y, _angle);
            }
            hrl_append(_out, hrl_ring_fill(_rot, "m3", _x, _y));
            hrl_append(_out, hrl_bevel(_rot, _m * 0.24, 2, false));
            // The click, pivoted outside the ratchet and pressed into it by its spring.
            var _px = _x + _r * 1.05, _py = _y - _r * 0.55;
            var _cl = hrl_bar_pts(_px, _py, _x + _r * 0.30, _y - _r * 0.10, _m * 0.34,
                                  -0.10 + _w * 0.06, _px, _py);
            hrl_append(_out, hrl_raise(_cl, _m * 0.16, 2, "m4"));
            hrl_append(_out, hrl_dot(_px, _py, _m * 0.34, "m0"));
            // The click spring: a real leaf, curved.
            var _sp = hrl_qbez([_px + _m * 1.4, _py], [_px + _m * 0.4, _py + _m * 2.2],
                               [_px - _m * 0.9, _py + _m * 1.9], 10);
            hrl_append(_out, hrl_poly(_sp, false, max(HRL_MIN_STROKE, _m * 0.13), "m0"));
        } break;

        // -- 4. REMONTOIRE. A small secondary spring rewound at intervals by the main drive, so
        // the escapement is fed by something that is always freshly wound. Drawn as the little
        // spring and the arm that rewinds it.
        case 4: {
            var _rr2 = _r * 0.52;
            hrl_append(_out, hrl_ring(_x, _y, _rr2, max(HRL_MIN_STROKE * 0.5, _m * 0.14), "m2"));
            hrl_append(_out, _hrl_mainspring(_x, _y, _rr2 * 0.86, _m, 0.5 + _w * 0.4, _angle));
            var _arm = hrl_bar_pts(_x, _y, _x + cos(_angle) * _r * 1.35,
                                   _y + sin(_angle) * _r * 1.35, _m * 0.28, 0, 0, 0);
            hrl_append(_out, hrl_raise(_arm, _m * 0.14, 2, "m4"));
            hrl_append(_out, hrl_boss(_x + cos(_angle) * _r * 1.35,
                                      _y + sin(_angle) * _r * 1.35, _m * 0.40, 10));
            hrl_append(_out, hrl_dot(_x, _y, _m * 0.34, "m0"));
        } break;

        // -- 5. HAND CRANK. No stored power at all: something turns it. A mill wheel, a music box
        // being played, an orrery being demonstrated. Included because a machine that is DRIVEN by
        // the player is a different kind of object from one that runs.
        default: {
            var _hx = _x + cos(_angle) * _r * 1.15;
            var _hy = _y + sin(_angle) * _r * 1.15;
            var _cr2 = hrl_bar_pts(_x, _y, _hx, _hy, _m * 0.40, 0, 0, 0);
            hrl_append(_out, hrl_raise(_cr2, _m * 0.20, 2, "m2"));
            // The handle, turned wood, which stays upright on its own pivot.
            var _hd = hrl_pts_pill(_hx - _m * 0.55, _hy - _m * 1.6,
                                   _hx + _m * 0.55, _hy + _m * 1.6, 6);
            hrl_append(_out, hrl_raise(_hd, _m * 0.34, 3, "m3"));
            hrl_append(_out, hrl_boss(_x, _y, _m * 0.85, 14));
        } break;
    }

    if (is_undefined(_map)) return _out;
    return hrl_map_roles(_out, _map);
}

/// A mainspring as a real spiral whose turns TIGHTEN with the wind.
///
/// ⛔ THE SPACING CHANGES, NOT THE COUNT, AND THAT IS THE WHOLE POINT. The obvious way to animate
/// winding is to draw more turns as the wind rises, and it is wrong twice over: a spring has a
/// fixed length so it cannot grow turns, and the drawing would pop as each new turn appeared. A
/// wound spring is the SAME steel packed against the arbor, so the inner turns close up and the
/// outer ones pull away from the barrel wall. Modelled as an Archimedean spiral whose radial pitch
/// falls with the wind, over a fixed number of turns.
function _hrl_mainspring(_x, _y, _r, _m, _wind, _phase) {
    var _turns = 6.5;
    var _steps = 150;
    var _pts = array_create(_steps + 1);
    var _r0 = _m * 0.95;
    // Fully wound: the spiral is packed into the inner third. Run down: it fills the barrel.
    var _r1 = _r * lerp(1.00, 0.44, clamp(_wind, 0, 1));
    for (var _i = 0; _i <= _steps; _i++) {
        var _u = _i / _steps;
        var _th = _u * HRL_TAU * _turns + _phase;
        var _rr = lerp(_r0, _r1, _u);
        _pts[_i] = [_x + cos(_th) * _rr, _y + sin(_th) * _rr];
    }
    return hrl_poly(_pts, false, max(HRL_MIN_STROKE, _m * 0.11), "m0");
}
