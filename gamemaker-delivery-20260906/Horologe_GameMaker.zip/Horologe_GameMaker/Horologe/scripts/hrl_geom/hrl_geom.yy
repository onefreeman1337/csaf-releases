{
  "$GMScript": "v1",
  "%Name": "hrl_geom",
  "name": "hrl_geom",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}