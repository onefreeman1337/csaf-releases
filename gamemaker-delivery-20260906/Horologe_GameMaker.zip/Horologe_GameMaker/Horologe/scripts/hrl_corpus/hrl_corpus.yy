{
  "$GMScript": "v1",
  "%Name": "hrl_corpus",
  "name": "hrl_corpus",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}