/// HOROLOGE - hrl_corpus. Every name in the package, in one place.
///
/// ============================================================================================
/// WHY THE NAMES LIVE HERE AND NOT BESIDE THE THING THEY NAME
///
/// Each builder in this package switches on an integer, and integers are what a buyer's save file
/// and their item definitions will hold. The NAMES are a presentation layer over those integers,
/// and keeping them together does two things:
///
///   1. It makes the corpus countable. hrl_corpus_total() below adds up what is actually in the
///      package, from the same arrays the labels come from, so the number on the store page cannot
///      drift from the number in the code. CLAUDE.md §2b records a live listing that sold a pack
///      at HALF its real size because a figure was TYPED into a checker instead of derived.
///   2. It makes translation one file. A buyer shipping in French replaces this file and nothing
///      else; every builder keeps working because none of them contains a word.
///
/// ⛔ THE ARRAYS ARE INDEX-PARALLEL WITH THE SWITCHES THEY NAME, and that is a shared fact with
/// two declarations - exactly the shape CLAUDE.md §2b warns about. It is checked rather than
/// trusted: hrl_selftest asserts array_length against every HRL_*_N macro, so adding a profile
/// and forgetting its name fires by name instead of drawing an unlabelled tooth.
/// ============================================================================================

function hrl_finish_names() {
    return ["mirror polish", "grained", "frosted", "as cast", "lacquered",
            "blued", "fire gilt", "jewelled"];
}

function hrl_material_names() {
    return ["polished brass", "fire gilt", "cast bronze", "copper", "verdigris",
            "patinated brass", "polished steel", "blued steel", "grey cast iron",
            "silvered", "white enamel", "black polish", "ruby", "figured rosewood"];
}

function hrl_profile_names() {
    return ["cycloidal", "involute", "ratchet", "lantern pin", "crown",
            "club tooth", "triangular", "sprocket"];
}

function hrl_crossing_names() {
    return ["solid web", "straight arms", "tapered arms", "curved arms", "double curve",
            "pierced circles", "foliate piercing", "cross halved", "skeleton lattice",
            "parallel bars"];
}

function hrl_escapement_names() {
    return ["verge and foliot", "anchor recoil", "deadbeat", "grasshopper",
            "cylinder", "duplex", "chronometer detent", "pin pallet"];
}

function hrl_osc_names() {
    return ["seconds pendulum", "half seconds pendulum", "gridiron pendulum",
            "balance and hairspring", "foliot", "fly"];
}

function hrl_dial_names() {
    return ["Roman chapter", "Arabic chapter", "regulator", "twenty four hour",
            "moonphase", "calendar ring", "tide dial", "zodiac plate",
            "engine turned", "skeleton chapter"];
}

function hrl_hand_names() {
    return ["spade", "breguet", "poker", "cathedral", "fleur de lys",
            "syringe", "baton", "serpentine", "alpha", "skeleton"];
}

function hrl_frame_names() {
    return ["full plate", "three quarter plate", "pillar frame", "skeleton frame",
            "bar movement", "birdcage", "lantern frame", "engraved backplate"];
}

function hrl_drive_names() {
    return ["weight and line", "going barrel", "fusee and chain", "spring and click",
            "remontoire", "hand crank"];
}

function hrl_machine_names() {
    return ["longcase regulator", "lantern clock", "carriage clock", "pocket watch",
            "marine chronometer", "turret clock", "orrery", "tellurion",
            "music box", "counting machine", "combination lock", "automaton drive"];
}

/// ============================================================================================
/// THE COUNT
/// ============================================================================================

/// How many distinct authored COMPONENT FORMS the package contains.
///
/// ⛔ DERIVED FROM THE NAME ARRAYS, NEVER TYPED. This is the number the store listing quotes, and
/// a listing that quotes a figure a tool did not produce is the defect CLAUDE.md §2b records
/// costing a live product page its credibility - a checker held the same stale literal the page
/// held, and certified the staleness it existed to catch. Print this, do not remember it.
///
/// ⚠️ IT DOES NOT COUNT MATERIALS OR MACHINES, and the omission is deliberate: those multiply the
/// forms rather than adding to them, and a count that multiplies everything by everything is the
/// kind of number that is technically true and reads as a lie. Materials and machines are quoted
/// separately.
function hrl_corpus_forms() {
    return array_length(hrl_profile_names())
         + array_length(hrl_crossing_names())
         + array_length(hrl_escapement_names())
         + array_length(hrl_osc_names())
         + array_length(hrl_dial_names())
         + array_length(hrl_hand_names())
         + array_length(hrl_frame_names())
         + array_length(hrl_drive_names());
}

/// A one-line summary of what is in the package, built from the arrays above.
function hrl_corpus_line() {
    return string(hrl_corpus_forms()) + " component forms, "
         + string(array_length(hrl_material_names())) + " materials, "
         + string(array_length(hrl_machine_names())) + " machines";
}

/// ============================================================================================
/// LOOKUP HELPERS
/// ============================================================================================

/// Safe indexed lookup: a name array and an index that might be out of range.
///
/// ⚠️ RETURNS A VISIBLE MARKER RATHER THAN AN EMPTY STRING. An out-of-range name that reads ""
/// draws as a blank label, which looks like a layout problem and gets chased in the wrong file for
/// half an hour. "?12" says immediately what happened and where.
function hrl_name_of(_arr, _i) {
    if (_i < 0 || _i >= array_length(_arr)) return "?" + string(_i);
    return _arr[_i];
}

/// The full description of one machine, as a buyer would read it off a label.
function hrl_machine_label(_mach) {
    if (is_undefined(_mach) || !is_struct(_mach) || !variable_struct_exists(_mach, "kind")) return "";
    return hrl_name_of(hrl_machine_names(), _mach.kind)
         + ", " + hrl_name_of(hrl_material_names(), _mach.material)
         + ", " + hrl_name_of(hrl_escapement_names(), _mach.escapement);
}

/// The technical line: what the train actually is.
function hrl_machine_train_line(_mach) {
    var _tr = _mach.train;
    var _s = "";
    var _n = array_length(_tr.meshes);
    for (var _i = 0; _i < _n; _i++) {
        var _m = _tr.meshes[_i];
        var _A = _tr.arbors[_m.a];
        var _B = _tr.arbors[_m.b];
        var _wa = (_m.a_part == "pinion") ? _A.pinion : _A.wheel;
        var _wb = (_m.b_part == "pinion") ? _B.pinion : _B.wheel;
        if (_i > 0) _s += " - ";
        _s += string(_wa.N) + "/" + string(_wb.N);
    }
    return _s;
}
