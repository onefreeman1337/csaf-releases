# HOROLOGE — Mechanisms That Draw Themselves

**Clockwork for GameMaker, computed from tooth counts and drawn in pure GML.**
12 machines · 8 tooth profiles · 10 crossing patterns · 8 escapements · 6 oscillators ·
10 dials · 10 hands · 8 frames · 6 drives · 14 materials ·
no sprites, no atlas, no texture page.

Version 1.0.0 · GameMaker Studio 2.3+ / GameMaker 2024.x · runtime `2024.14.4.268`

---

## What this is, and what it is not

**This is not a gear sprite pack. It is the thing that makes them turn.**

The clockwork shelf for GameMaker is static art. The two highest-priced steampunk icon sets on it
are 100 hand-pixelled pictures each — beautiful, fixed, and with no tooth count in them. A picture of a
gear cannot mesh with another picture of a gear, so if your game needs a different ratio the art is
simply wrong and nobody can tell.

Horologe ships the mechanism. A wheel is **a number**, and everything follows from it:

```
pitch radius     r = module * N / 2
circular pitch   p = pi * module        <- equal on both wheels of a mesh, or they cannot mesh
angular pitch    a = TAU / N
ratio to a mate  -N_this / N_that
```

Change a wheel from 96 teeth to 60 and the teeth get coarser **and** the hand it drives runs
faster, because the drawing and the ratio come out of the same number. That is the whole product.

### The example worth looking at first

The longcase regulator's train is **96/12, 96/12, 90/12 with a 30-tooth escape wheel** — real
English counts. Nobody typed a speed anywhere. Those numbers alone produce:

| | |
| --- | --- |
| centre arbor | exactly **one turn per hour** — the minute hand |
| escape arbor | exactly **one turn per minute** — the seconds hand |
| beat | exactly **1.000 seconds** — a seconds pendulum |

The beat is four lines of arithmetic: an escapement passes half a tooth per beat, so
`beat = 1 / (2 * N_escape * revolutions_per_second)`. Change the 90 to an 80 and you get a
shorter pendulum, a faster seconds hand, and a clock that still works. It is just a different clock.

---

## Quickstart

1. Import `Horologe.yymps` (**Tools → Import Local Package**, select all).
2. Open `rm_hrl_demo` and press Play. That room is the whole API in one screen.
3. `LEFT`/`RIGHT` machine · `UP`/`DOWN` material · `S` new example · `D` dial on/off ·
   `1` `2` `3` real time / ×60 / ×600 · `L` hide the controls.

Then, in your own code:

```gml
// Create: build a machine and set it to a wall time.
mach = hrl_machine_new(0, 0, 12345);        // kind, material, seed
hrl_machine_set_time(mach, 10, 9, 36);

// Step: seconds of GAME time, not frames.
hrl_machine_step(mach, delta_time / 1000000);

// Draw: fitted to any rectangle, at any size.
hrl_render_in_rect_tight(hrl_machine_parts(mach, true), mach.pal, x, y, 256, 256, undefined);

// Read: the numbers come off the arbors, not out of a variable you kept in parallel.
var _t = hrl_machine_read(mach);            // { hours, minutes, seconds }
```

⚠️ **`hrl_machine_step` takes SECONDS, not steps.** A machine advanced by a constant per step keeps
a different time at 30 fps and at 144 fps, and drops frames as a clock running slow. Pass
`delta_time / 1000000` and it keeps real time on any machine.

---

## The three things this does that a picture cannot

### 1. The teeth actually interleave

Centre distance, ratio and phase are all computed from the two tooth counts. The driven wheel's
phase is solved so that a tooth of the driver lands in a **gap** of the driven wheel at the line of
centres — at every moment, not just when it starts.

```gml
var _tr = hrl_train_new(1.0);
var _a = hrl_train_add(_tr, hrl_wheel_new(96, 1.0, 0, 3), undefined, "great");
var _b = hrl_train_add(_tr, undefined, hrl_wheel_new(12, 1.0, 0, 0), "centre");
hrl_train_root(_tr, _a, 0, 0, 1 / 28800, 0);
hrl_train_mesh(_tr, _a, "wheel", _b, "pinion", -2.35, HRL_MESH_EXTERNAL);
// _b is now PLACED at the correct centre distance, TURNING at -96/12, and IN PHASE.
```

`hrl_mesh_error(_tr, 0, t)` measures it at any time you like: it returns how far the driver's
nearest tooth is from the line of centres and how far the driven wheel's nearest gap is from it, in
**arc length at the pitch circle**, and those two must cancel. The bundled suite checks every mesh
of every machine at twelve different moments.

### 2. It steps, because a real train does

A weight or a spring pulls all the time; the escapement lets the train forward one half tooth per
beat and holds it the rest of the time. So there is exactly one quantised quantity — the time the
train has been allowed to advance to — and every wheel is a pure function of it. The seconds hand
**jumps**. The pendulum, which reads the continuous time, **sweeps**. Both come from the same
number, so they cannot drift apart.

That difference is most of what makes a mechanism read as a machine rather than as two animations
playing near each other.

### 3. It drives your game, not just your screen

A machine declares OUTPUTS: an arbor, and what one revolution of it means.

```gml
var _r = hrl_machine_read(mach);
if (_r.hours >= 6 && _r.hours < 18) world_is_daytime = true;
```

A clock's centre arbor means sixty minutes. An orrery's earth arbor means one year. A counting
machine's last arbor means a thousand of the first. Your game reads `hrl_machine_read` and never
has to know what a pinion is.

---

## What is in the package

| file | what it is |
| --- | --- |
| `hrl_wheel` | tooth profiles, crossings, and the counter that reads a tooth count back out of a drawing |
| `hrl_train` | the solver: placement, ratios, phase, quantised time, outputs |
| `hrl_escapement` | eight escapements and six oscillators |
| `hrl_dial` | ten dials, a stroke alphabet for their figures, ten hands |
| `hrl_frame` | eight frames, derived from where the arbors actually are |
| `hrl_drive` | six drives, with a live wind level |
| `hrl_material` | fourteen materials as five-stop perceptual ramps, plus ageing |
| `hrl_machine` | the twelve machines, and the composition of everything above |
| `hrl_corpus` | every name in the package, in one file — replace it to translate |
| `hrl_geom` `hrl_palette` `hrl_relief` `hrl_render` `hrl_shape` | the studio's shared drawing layer |
| `hrl_selftest` | the in-engine suite, 1,226 assertions |
| `hrl_bake` | the code that rendered every image on the store page |

Every global and every macro is prefixed `hrl_` / `HRL_`. GML's global namespace is flat and a
collision in your project is a support ticket nobody can debug remotely.

---

## Performance, and the honest version of it

**A wheel's shape is constant. Only its angle moves.** So bake each component once with
`hrl_render_to_sprite` and draw it with `draw_sprite_ext` at the angle the train solved: a
twelve-wheel movement becomes twelve sprite draws per frame instead of thousands of primitives.

That is only honest because of a rule in `hrl_wheel`: every wheel is built with **n-fold symmetry
about its arbor**, and real wheel-work is radially grained, so its shading is a function of radius
rather than of world direction. A radially shaded, rotationally symmetric thing is genuinely the
same picture after turning. The suite asserts the symmetry per crossing pattern.

⚠️ The parts that are **not** rotationally symmetric — a pallet fork, a hand, a click, a pendulum —
are not baked. There are a handful of them and their shading has to stay put.

⚠️ **`hrl_render_to_sprite` hands you a sprite you own and must `sprite_delete`.** The demo object's
Clean Up event is empty because the demo draws from geometry on purpose; if you copy it as a
starting point and add caching, that is where the delete goes.

---

## Things worth knowing before you change something

- **The seed does not touch the tooth counts.** It varies the finish, the wear and the layout. A
  clock whose wheel counts were randomised would keep random time, and "this clock runs at 1.03
  seconds per beat" is a bug with a story, not a feature.
- **Layout angles are the only free parameter.** `beta` on each stage decides where on the plate
  the next arbor goes and nothing else. The counts fix the sizes; the maker fixes the shape.
- **A machine with `beat = 0` is not a broken clock.** An orrery, a music box and a counting
  machine have no escapement and genuinely run smoothly.
- **Four is IIII, not IV.** Almost every Roman-figured clock dial ever made uses IIII, for balance
  against the VIII opposite it. `hrl_glyph_roman` does the same.
- **Setting and stepping agree.** `hrl_machine_set` puts the train at a moment; stepping to that
  moment gives the same angles to within floating-point. The suite asserts it, because a
  set/step disagreement only shows up after a save and load.

---

## Verification, stated honestly

GML cannot be unit-tested outside the engine — there is no headless runner and no mock. So this
package builds through Igor, runs itself with `-selftest`, and writes a result file:

```
HOROLOGE SELFTEST  pass 1226  fail 0  stage 99
```

What that covers: the tooth count in every drawing against its declaration, across every profile
and fourteen tooth counts; every mesh of every machine at twelve arbitrary times; the regulator's
three derived numbers; set/step equivalence; the material ramps' separation floors; the ageing
model; the rotational symmetry the cache depends on; and that every dial, hand, escapement and
oscillator draws something and moves.

**What it cannot cover:** it computes points and numbers. It cannot see a fill rule, a draw order,
or whether a picture is any good. Every image on the store page was rendered by `hrl_bake` inside
this package and then opened and looked at, which is the only instrument for that.

---

## Licence

See `LICENSE.txt`. In short: build whatever you want with it, in unlimited commercial games; do not
resell the package itself. One licence per developer who touches the source.

The two fonts are Open Sans under Apache-2.0 and are used **only** by the demo room's readout —
every figure on a dial is drawn as strokes by `hrl_dial`, not typeset. Full notices in
`Horologe/fonts/THIRD-PARTY-NOTICES.txt`.

AI disclosure: this package was written with AI assistance, disclosed on every listing that
carries it.

© 2026 Core Systems Asset Factory
