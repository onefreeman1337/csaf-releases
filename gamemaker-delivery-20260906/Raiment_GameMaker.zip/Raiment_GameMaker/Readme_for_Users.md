# RAIMENT — Characters That Draw Their Own Bodies And Everything They Wear

**A GameMaker character appearance system, written in pure GML. No sprites, no atlas, no PNG.**

A figure is a body plan, a build, a pose, a skin, a head of hair and a list of worn items. Hand
Raiment those and it returns the geometry for a whole dressed person — a torso with a waist and a
pelvis, arms that follow the pose, garments whose folds are computed from the drape over that
particular body, armour built as the construction it actually is, and a material treatment on every
surface. Equip something and the figure is **re-drawn**, not re-layered: a coat over a broad build
is a different set of points from the same coat over a slight one.

- **GameMaker 2024.14+.** Built and gated against runtime `2024.14.4.268`.
- **18 resources**, 14 of them script assets. Two fonts, one demo object, one demo room.
- **Everything is `rai_`-prefixed** and there are no global variables at all.

---

## What this is, and what it is not

**It is** a runtime generator. Nothing is baked. Every figure on the store page was drawn by the
same code you are importing, in engine, by `rai_bake` — which ships with the package, so you can
re-render those sheets yourself.

**It is not** a sprite pack, and it will not give you a pixel-art character in someone else's style.
The look is the product's: flat masses with a drawn relief pass, lit from one fixed lamp.

**It is not** a skeletal animation system. Poses are named sets of joint angles, hand-authored;
there is no interpolation between them and no timeline. What it gives you is that the *garments*
re-solve on each pose, which is the part that is expensive to do by hand.

---

## Quickstart

1. In GameMaker: **Tools → Import Local Package**, pick `Raiment.yymps`, **Add All**, import.
2. Open **`rm_rai_demo`** and press Play. That room is the whole product driven by one object.
3. In your own code, the front door is one function:

```gml
var _worn = [
    rai_item("cloth",  "trousers", "charcoal"),
    rai_item("cloth",  "tunic",    "madder"),
    rai_item("armour", "brigandine", "oxhide")
];

var _fig = rai_figure("broad", "guard", _worn, "buckskin", { style: "braid", material: "charcoal" });

// then, in a Draw event:
rai_render_in_rect(_fig.parts, _fig.palette, x, y, 96, 192, 0, undefined);
```

`rai_figure` returns `{ parts, palette, arm, worn, count }`. `parts` is a plain array of drawing
records and `palette` is a struct of colours; `arm` is the armature it solved, if you want to hang
something of your own off a joint.

### The demo room's controls

| key | does |
| --- | --- |
| `Tab` | switch between the single figure and the 24-person crowd |
| `Left` / `Right` | previous / next cloth family |
| `Up` / `Down` | previous / next material |
| `A` | cycle armour family, **including off** |
| `B` | next build |
| `P` | next pose |
| `N` | show / hide the bare body under the clothes |
| `Space` | page through the built-in reference sheets |
| `R` | re-seed the crowd — a new village |

---

## The three things this does that a sprite sheet cannot

### 1. The garment is computed from the body, not scaled to it

`rai_body_halfwidth(arm, y)` answers "how wide is this person here", and every garment panel is
sampled through it. Change the build and the hem, the fullness and every fold move with it — a robe
on `slight` and the same robe on `broad` differ by 37.9% at the chest and the cloth follows.

### 2. Equipping is a model, not a draw order

`rai_outfit_resolve` takes a worn list and resolves it once: one item per slot, each family
declaring the layer band it occupies, and anything mostly hidden stops drawing its detail. Putting a
coat on takes the old coat off, because that is what equipping means.

### 3. A whole crowd from one string

```gml
var _crowd = rai_cast("thornbury", 24, undefined);   // 24 people
var _fig   = rai_cast_figure(_crowd[0]);
```

Each member gets their own build, pose, wardrobe, materials and hair, derived from the seed. The
same string always gives the same village; a different string gives a different one. Adding a person
does not change anybody already there.

---

## What is in the box

Call `rai_corpus_count()` at runtime and it returns the real figures, counted from the declarations
rather than from this file:

| | |
| --- | --- |
| cloth families | 9 — tunic, robe, coat, trousers, skirt, cloak, hood, apron, sash |
| armour families | 6 — plate, mail, scale, brigandine, lamellar, leather |
| armour piece constructions | 23 (gorget, cuirass, pauldron, tasset, bracer, cuisse, greave, coif, bands …) |
| materials | 30, each a five-stop ramp at absolute lightness plus a surface character |
| surface characters | 10 — weave, twill, nap, sheen, quilt, ring, scale, rivet, tooling, wear |
| builds | 5 — slight, average, broad, tall, short |
| poses | 5 — stand, walk, reach, guard, sit |
| hair styles | 8 — crop, bob, long, bound, braid, tonsure, wild, bald |
| archetypes for the crowd | 8 |

**450 distinct outfits** (15 families × 30 materials) and **2,250 figures** across the five builds,
before pose, hair, skin or layering.

### The scripts

| script | what it owns |
| --- | --- |
| `rai_armature` | the skeleton: landmarks, builds, poses, the body outline, `rai_body_halfwidth` |
| `rai_wardrobe` | `rai_figure`, slots, layer bands, occlusion, `rai_corpus_count` |
| `rai_garment` | the nine cloth families and their cuts |
| `rai_armour` | the six armour families, their pieces and their hems |
| `rai_drape` | how cloth hangs: fullness, flare, cling, and the fold pass |
| `rai_material` | the 30 materials and their surface characters |
| `rai_palette` | Oklch colour and the ramp construction |
| `rai_relief` | the lighting pass that makes a mass read as a surface |
| `rai_shape` · `rai_geom` | outlines, bevels, and the geometry predicates |
| `rai_render` | drawing part lists, fitting them to rects, baking to a sprite, text |
| `rai_cast` | archetypes and the seeded crowd |
| `rai_bake` | the store sheets, rendered in engine |
| `rai_selftest` | the 1,660-assertion suite (see below) |

---

## Performance

Building a figure is geometry, not drawing, so build it **once** and keep the result. If you need
many figures on screen at once, `rai_render_to_sprite(parts, palette, w, h, pad)` bakes a part list
to a real sprite you can draw with `draw_sprite_ext` at no per-frame cost.

⚠️ The baked sprite is lit from the product's own fixed lamp, so rotating it rotates the lighting
with it. For a figure that turns, re-render rather than rotate the bake.

---

## Namespacing

Every function, macro and asset in this package begins with `rai_`, `RAI_`, `obj_rai_`, `rm_rai_` or
`fnt_raiment`. GML's global namespace is flat and a collision in your project is a support ticket
nobody can debug remotely, so nothing here is spelled in a way that could collide with yours.

It declares exactly **five globals**, all `rai_`-prefixed, and three of them are knobs meant for you:

| global | what it is |
| --- | --- |
| `global.rai_lx`, `global.rai_ly` | the lamp direction. Set with `rai_lamp_set(lx, ly)`, put back with `rai_lamp_reset()` |
| `global.rai_detail` | the level-of-detail floor. Set with `rai_detail_set(n)` |
| `global.rai_bk_drawn` | a draw counter the sheet renderer keeps |
| `global.rai_stage` | the self-test's progress marker |

⚠️ `rai_lamp_set` changes the lighting for **everything** drawn afterwards. Call `rai_lamp_reset()`
before drawing anything you did not mean to relight, or one figure in a screenful is lit from below
and reads as a hole.

---

## Verification, stated honestly

GML cannot be unit-tested outside the engine, so this package tests itself **inside** it.
`rai_selftest` runs **1,660 assertions** on a real Igor-built executable and writes the result to a
file. The engine gate is a real Igor package build: exit 0, 0 errors, 379 resources compiled.

What that does and does not prove:

- ✅ It proves the geometry is well-formed — outlines simple and wound one way, every part inside
  the unit box, no two families collapsing onto each other, the drape actually gathering, the body
  solid across its own centre line, and every hem fillable by the renderer that fills it.
- ⛔ **It does not prove the picture is good.** Several defects in this package's history passed
  every assertion and were found only by rendering a sheet and looking at it — a head that was not
  attached to its body, feet that did not exist, and a hip the background showed through. The
  assertions that would have caught each of those were written afterwards and are in the suite now.

---

## Translating it

Everything a player would read is in the demo and in `rai_bake`, not in the drawing code. Family
names, material names, pose names and archetype names are **ids**, not display strings — map them to
your own language at your UI layer and nothing in the package needs editing.

⚠️ The two shipped fonts carry ASCII 32–126 only. A character outside that range draws **nothing**,
silently. If you need accented or non-Latin text, replace the font resources.

---

## Licence

See `LICENSE.txt`. Third-party font licences are in `fonts/THIRD-PARTY-NOTICES.txt` inside the
package — Open Sans, Apache-2.0.

**AI disclosure:** this product's code and graphics were produced with AI assistance. It is
disclosed on the store listing and stated here.

© Core Systems Asset Factory
