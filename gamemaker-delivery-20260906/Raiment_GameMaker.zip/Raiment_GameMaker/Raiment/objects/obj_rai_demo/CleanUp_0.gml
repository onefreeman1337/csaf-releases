/// @description PLACEHOLDER — this event has not been authored yet.
// make_project.js writes this once and never overwrites it. If you are reading this in a
// built product, the demo was shipped unfinished.
show_debug_message("RAIMENT: unauthored event CleanUp_0.gml");
