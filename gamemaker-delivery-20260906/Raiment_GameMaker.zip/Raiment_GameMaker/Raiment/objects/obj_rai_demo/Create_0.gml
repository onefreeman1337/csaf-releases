/// @description Raiment demo — state.
///
/// THE DEMO ROOM IS MANDATORY IN THIS WING and it is three things at once: the buyer's quickstart,
/// the source of the store GIF, and the only real smoke test available, because GML cannot be
/// unit-tested outside the engine.
///
/// It is deliberately a WARDROBE, not a game. Every control changes ONE variable that the drawing
/// reads, so a buyer can see which number does what and copy the four lines that matter.

// ⛔ THE FIRST LINE OF ANY HEADLESS ENTRY POINT, AND IT IS NOT OPTIONAL.
// A GML runtime error opens a MODAL DIALOG. Headless, nothing dismisses it and the process never
// exits, so a build robot reports a TIMEOUT instead of a defect and the next session re-runs a
// ten-minute bake to learn nothing. Recording the stage number and ending the game turns an opaque
// hang into a named line in a result file. This wing measured that exact conversion on a previous
// product: an opaque 180 s hang became "CRASH at stage 5: Variable Index [25] out of range [25]".
//
// ⛔ THIS IS THE ONLY exception_unhandled_handler IN THE PACKAGE. Whichever is installed last
// silently wins, so two handlers is a coin toss over how much a crash tells you.
global.rai_stage = -1;
global.rai_bk_drawn = 0;
exception_unhandled_handler(function(_ex) {
    var _st = "";
    try {
        var _tr = _ex.stacktrace;
        for (var _i = 0; _i < array_length(_tr); _i++) {
            if (_i > 0) _st += " <- ";
            _st += string(_tr[_i]);
        }
    } catch (_e) { _st = "(no stacktrace)"; }
    var _f = file_text_open_write("rai_crash.json");
    file_text_write_string(_f, "{\"stage\":" + string(global.rai_stage)
        + ",\"message\":\"" + string_replace_all(string(_ex.message), "\"", "'") + "\""
        + ",\"where\":\"" + string_replace_all(_st, "\"", "'") + "\"}");
    file_text_close(_f);
    game_end(1);
});

// ⛔ EVERY VARIABLE A LATER EVENT READS IS DECLARED ABOVE THE EARLY EXITS, AND CLEAN UP ALWAYS
// RUNS. The headless branches below leave Create part way down, and GameMaker still fires Clean Up
// on the way out - a sibling product in this wing threw "variable not set before reading it" AFTER
// a fully green self-test, reported against the last stage the suite had reached, i.e. a crash
// blamed on code that had already finished and passed.

// The figure being shown.
build_i    = 1;   // index into rai_builds_all()
pose_i     = 0;   // index into rai_poses_all()
garment_i  = 0;   // index into rai_garment_families()
material_i = 0;   // index into rai_materials_all()
armour_i   = 0;   // index into rai_armour_families(), -1 for none

builds    = rai_builds_all();
poses     = rai_poses_all();
garments  = rai_garment_families();
materials = rai_materials_all();
armours   = rai_armour_families();

// The contact sheet on the right cycles materials so the eye can compare them directly. This is
// the single most useful view in the product and it is what the store sheet is cut from.
sheet_page = 0;

show_body = true;

// ⛔ THE DEMO SHOWS THE SYSTEM, NOT ONLY THE CORPUS, AND THAT IS THE WHOLE POINT OF THE PRODUCT.
// A demo that cycles beautiful garments is a demo of an ART PACK, and wing CLAUDE.md §2 has
// measured twice - over 646 assets and again over 2,131 - that an art pack in a code territory
// prices at the bottom of the shelf. The CROWD is what makes this the spine of a game, so a buyer
// must be able to reach it with one key.
//
// ⚠️ THE CROWD IS BUILT ONCE, IN CREATE. Rebuilding twenty-four figures every frame allocates
// thousands of arrays a frame for a picture that does not change; rai_render_to_sprite's header
// says the same thing about caching and this is the same argument one level up.
view = 0;                       // 0 wardrobe, 1 crowd
crowd_seed = "greenhollow";
crowd = rai_cast(crowd_seed, 24, undefined);
crowd_figs = [];
var _ci;
for (_ci = 0; _ci < array_length(crowd); _ci++) {
    array_push(crowd_figs, rai_cast_figure(crowd[_ci]));
}

/// ⛔ THE CORPUS COUNT IS DERIVED, NEVER TYPED. Wing doctrine and master §2b: a measurement copied
/// into a listing is the same defect as one copied into a checker. The demo prints this, the
/// self-test asserts it, and the listing quotes whatever they print.
corpus = rai_corpus_count();
corpus_total = corpus.outfits;

// -- headless modes: run, write the result file, exit -------------------------------------------
//
// ⛔ THE STAGE NUMBER IS SET INSIDE THE SUITE AND READ BY THE WRITER, so a crash mid-suite still
// names where it died. The runner treats stage 99 as the suite's own "reached the end" marker:
// anything less means it stopped partway and the pass count is a count of what it got through, not
// a verdict on the product.
var _args = "";
var _ai;
for (_ai = 0; _ai < parameter_count(); _ai++) _args += parameter_string(_ai + 1) + " ";

if (string_pos("-selftest", _args) > 0) {
    var _res = rai_selftest_run();
    rai_selftest_write(_res);
    game_end(_res.fail > 0 ? 1 : 0);
    exit;
}

if (string_pos("-bake", _args) > 0) {
    global.rai_stage = 200;
    rai_bake_store();
    game_end(0);
    exit;
}

// ⚠️ `-gif` MUST BE TESTED BEFORE `-bake` WOULD BE IF THE STRINGS OVERLAPPED, AND THEY DO NOT -
// but the order is still deliberate: string_pos matching is substring matching, so a mode whose
// name contains another mode's name would silently take the wrong branch.
if (string_pos("-gif", _args) > 0) {
    global.rai_stage = 300;
    rai_bake_gif();
    game_end(0);
    exit;
}

show_debug_message("RAIMENT demo: " + string(corpus.cloth_families) + " cloth + "
    + string(corpus.armour_families) + " armour families x "
    + string(corpus.materials) + " materials = " + string(corpus.outfits)
    + " outfits, on " + string(corpus.builds) + " builds x "
    + string(corpus.poses) + " poses.");
