/// @description Raiment demo — input.
///
/// One key per variable, so the mapping between a control and a number in the API is obvious.

if (keyboard_check_pressed(vk_tab))   view = (view + 1) % 2;

if (keyboard_check_pressed(vk_right)) garment_i  = (garment_i  + 1) % array_length(garments);
if (keyboard_check_pressed(vk_left))  garment_i  = (garment_i  - 1 + array_length(garments)) % array_length(garments);
if (keyboard_check_pressed(vk_up))    material_i = (material_i + 1) % array_length(materials);
if (keyboard_check_pressed(vk_down))  material_i = (material_i - 1 + array_length(materials)) % array_length(materials);
if (keyboard_check_pressed(ord("B"))) build_i    = (build_i    + 1) % array_length(builds);
if (keyboard_check_pressed(ord("P"))) pose_i     = (pose_i     + 1) % array_length(poses);
if (keyboard_check_pressed(ord("N"))) show_body  = !show_body;
if (keyboard_check_pressed(vk_space)) sheet_page = (sheet_page + 1) % 3;

// ⚠️ -1 IS "NO ARMOUR" AND IT IS PART OF THE CYCLE, not a sentinel bolted on. A wardrobe demo that
// cannot take the armour OFF cannot show the cloth, and the cloth is two thirds of the corpus.
if (keyboard_check_pressed(ord("A"))) {
    armour_i += 1;
    if (armour_i >= array_length(armours)) armour_i = -1;
}

// ⛔ THE CROWD IS RE-SEEDED, NEVER RE-ROLLED. A new seed string is a new village; pressing this
// twice with the same string must give the same village back, which is the claim rai_cast's header
// makes and the one a buyer will test first.
if (keyboard_check_pressed(ord("R"))) {
    crowd_seed = "village_" + string(irandom(99999));
    crowd = rai_cast(crowd_seed, 24, undefined);
    crowd_figs = [];
    var _ri;
    for (_ri = 0; _ri < array_length(crowd); _ri++) {
        array_push(crowd_figs, rai_cast_figure(crowd[_ri]));
    }
}
