/// @description Draw GUI
///
/// TWO VIEWS, because the product makes two claims and each needs its own picture.
///
///   WARDROBE - one figure large, plus the same garment across materials. The claim: this is drawn,
///              not blitted. Change the build and the garment changes shape with it, because
///              rai_drape asks the body how wide it is.
///   CROWD    - twenty-four seeded people. The claim: a SYSTEM, not a corpus of pictures. Nobody
///              drew these and nobody could ship them as sprites.
///
/// ⛔ A DEMO THAT ONLY CYCLES A CHARACTER SELLS AN ART PACK. Wing CLAUDE.md §2 measures the whole
/// GameMaker shelf twice and reaches the same law both times: a complete SYSTEM clears the band and
/// a corpus of pictures does not. The crowd is the system claim and it is one key away.
///
/// ⚠️ DRAWN AT THE GUI LAYER ON PURPOSE, so a buyer who drops this object into their own project
/// gets a figure that does not move with their camera. The in-world route is rai_render_parts.

var _w = display_get_gui_width();
var _h = display_get_gui_height();

var _page  = rai_oklch(0.205, 0.012, 262);
var _panel = rai_oklch(0.265, 0.014, 262);
var _ink   = rai_oklch(0.900, 0.010, 262);
var _dim   = rai_oklch(0.620, 0.012, 262);

draw_clear(_page);
draw_set_font(fnt_raiment);

var _pad = 28;
var _lh = _h - 150;

if (view == 1) {
    // -----------------------------------------------------------------------------------------
    // THE CROWD
    // -----------------------------------------------------------------------------------------
    var _cols = 8;
    var _rows = 3;
    var _cw = (_w - _pad * 2) / _cols;
    var _ch = _lh / _rows;
    var _ci;
    for (_ci = 0; _ci < array_length(crowd_figs); _ci++) {
        var _cx = _pad + (_ci % _cols) * _cw;
        var _cy = 84 + floor(_ci / _cols) * _ch;
        draw_set_colour(_panel);
        draw_rectangle(_cx + 3, _cy + 3, _cx + _cw - 3, _cy + _ch - 24, false);
        rai_render_in_rect_tight(crowd_figs[_ci].parts, crowd_figs[_ci].palette,
                                 _cx + 10, _cy + 8, _cw - 20, _ch - 40, undefined);
        draw_set_colour(_dim);
        draw_set_halign(fa_center);
        draw_text(_cx + _cw * 0.5, _cy + _ch - 20, crowd[_ci].archetype);
        draw_set_halign(fa_left);
    }

    draw_set_font(fnt_raiment_title);
    draw_set_colour(_ink);
    draw_text(_pad, 26, "RAIMENT");
    draw_set_font(fnt_raiment);
    draw_set_colour(_dim);
    draw_text(_pad + 170, 34, "crowd  /  seed \"" + crowd_seed + "\"");
    draw_text(_pad, _h - 52, "TAB wardrobe    R re-seed the village");
    draw_text(_pad, _h - 30,
        string(array_length(crowd_figs)) + " people from one string, each with their own build, "
        + "pose, wardrobe and materials - none of them a sprite");
    exit;
}

// ---------------------------------------------------------------------------------------------
// THE WARDROBE
// ---------------------------------------------------------------------------------------------
var _mat   = materials[material_i];
var _fam   = garments[garment_i];
var _build = builds[build_i];
var _pose  = poses[pose_i];
var _arm_name = (armour_i >= 0) ? armours[armour_i] : "none";

var _lw = floor(_w * 0.40);

draw_set_colour(_panel);
draw_rectangle(_pad, 84, _pad + _lw, 84 + _lh, false);

// ⭐ THE DEMO USES THE SAME FRONT DOOR A BUYER WOULD. rai_figure resolves the worn set, layers it,
// namespaces every material's ramp into one palette and hands back a part list - so what is on
// screen is what four lines of a buyer's own code produce, not a private path the demo can reach
// and they cannot.
var _worn = [rai_item("cloth", _fam, _mat)];
if (armour_i >= 0) {
    var _amat = rai_material_def(_mat).metal ? _mat : "steel";
    array_push(_worn, rai_item("armour", armours[armour_i], _amat));
}
var _fig = rai_figure(_build, _pose, _worn, show_body ? "buckskin" : "charcoal");

rai_render_in_rect_tight(_fig.parts, _fig.palette, _pad + 24, 108, _lw - 48, _lh - 48, undefined);

// ---------------------------------------------------------------------------------------------
// RIGHT — the same garment across materials. This is the volume claim.
// ---------------------------------------------------------------------------------------------
var _rx = _pad * 2 + _lw;
var _rw = _w - _rx - _pad;

draw_set_colour(_panel);
draw_rectangle(_rx, 84, _rx + _rw, 84 + _lh, false);

var _gcols = 6;
var _grows = 3;
var _per = _gcols * _grows;
var _gcw = _rw / _gcols;
var _gch = _lh / _grows;

var _k;
for (_k = 0; _k < _per; _k++) {
    var _mi = (sheet_page * _per + _k) % array_length(materials);
    var _m = materials[_mi];

    var _cellx = _rx + (_k % _gcols) * _gcw;
    var _celly = 84 + floor(_k / _gcols) * _gch;

    var _cf = rai_figure("average", "stand", [rai_item("cloth", _fam, _m)], "buckskin");
    rai_render_in_rect_tight(_cf.parts, _cf.palette,
                             _cellx + 6, _celly + 6, _gcw - 12, _gch - 26, undefined);

    draw_set_colour(_dim);
    draw_set_halign(fa_center);
    draw_text(_cellx + _gcw * 0.5, _celly + _gch - 20, _m);
    draw_set_halign(fa_left);
}

// ---------------------------------------------------------------------------------------------
// Chrome
// ---------------------------------------------------------------------------------------------
draw_set_font(fnt_raiment_title);
draw_set_colour(_ink);
draw_text(_pad, 26, "RAIMENT");

draw_set_font(fnt_raiment);
draw_set_colour(_dim);
draw_text(_pad + 170, 34,
    _fam + "  /  " + _mat + "  /  " + _build + "  /  " + _pose + "  /  armour: " + _arm_name);

draw_text(_pad, _h - 52,
    "LEFT/RIGHT garment   UP/DOWN material   B build   P pose   A armour   N skin   SPACE page   TAB crowd");
draw_text(_pad, _h - 30,
    string(corpus.cloth_families + corpus.armour_families) + " families x "
    + string(corpus.materials) + " materials = " + string(corpus.outfits)
    + " outfits, on " + string(corpus.builds) + " builds - none of them a sprite");
