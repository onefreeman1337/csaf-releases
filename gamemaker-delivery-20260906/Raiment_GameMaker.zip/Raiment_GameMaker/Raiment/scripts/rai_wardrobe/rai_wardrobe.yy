{
  "$GMScript": "v1",
  "%Name": "rai_wardrobe",
  "name": "rai_wardrobe",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}