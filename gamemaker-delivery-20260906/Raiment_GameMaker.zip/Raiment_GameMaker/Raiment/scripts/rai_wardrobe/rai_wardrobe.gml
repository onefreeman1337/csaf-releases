/// RAIMENT - rai_wardrobe. The corpus, the equip model, and the one place draw order is decided.
///
/// This is the module a buyer actually calls. Everything else builds one thing; this assembles a
/// DRESSED FIGURE out of a body, a worn set and thirty materials, and hands back a part list plus
/// the palette that goes with it.
///
/// ============================================================================================
/// ⭐ THE PALETTE PROBLEM, AND WHY THIS FILE RETURNS TWO THINGS
/// ============================================================================================
///
/// rai_render draws a part list against ONE palette struct, looked up by role name ("m2", "ink").
/// A dressed figure is not one material - it is a wool coat over a linen tunic with a steel gorget
/// and a leather belt, four ramps at once - so a single palette cannot express it and drawing each
/// item in its own pass would mean four render calls, four fits, and no way to guarantee they line
/// up.
///
/// ⇒ THE FIX IS TO NAMESPACE THE ROLES, NOT TO SPLIT THE DRAW. Item 0's roles become `i0_m0`..
/// `i0_m4`, item 1's become `i1_*`, and this file returns a COMBINED palette carrying all of them.
/// rai_render_colour is already a struct lookup by name, so it needs no change at all, and the
/// whole figure is still one part list drawn in one pass at one scale.
///
/// ⛔ THE FALLBACK IS THE THING TO WATCH. rai_render_colour returns `line` for a role the palette
/// does not carry - deliberately loud rather than invisible - so a namespacing mistake shows up as
/// a figure drawn entirely in outline colour rather than as a crash. rai_selftest asserts that
/// every role in the assembled part list exists in the assembled palette, which is the mechanical
/// version of that check and the only one that runs unattended.
///
/// ============================================================================================
/// ⛔ DRAW ORDER IS DECIDED HERE AND NOWHERE ELSE
/// ============================================================================================
///
/// ARCHITECTURE.md §6.2: a garment module that picks its own z is how two products get a z-fight
/// nobody can debug remotely. Every family declares a LAYER BAND (rai_garment_cut, rai_armour_spec)
/// and this file sorts the worn set by it once. A band, not a final z, because two items can share
/// one - a sash and an apron both sit at the waist - and the tiebreak is the order the buyer
/// equipped them, which is the only answer that is not arbitrary.
///
/// ⚠️ PURE except for building part lists. No draw calls, no engine state, no globals.

/// The equip slots, in a stable order. A slot holds at most one item.
///
/// ⚠️ `back` IS BEHIND THE BODY AND IS THE REASON THE LAYER BANDS START AT 5 RATHER THAN 0. The
/// figure is drawn front-on (rai_armature's COORDINATES header), so a cloak cannot be shown falling
/// behind the shoulders by view angle - it has to be an explicit band UNDER the body.
function rai_slots_all() {
    return ["back", "legs", "body", "armour", "outer", "front", "waist", "head"];
}

/// One worn item.
///
/// @param {String} _kind "cloth" or "armour"
/// @param {String} _family a rai_garment_families() or rai_armour_families() id
/// @param {String} _material a rai_materials_all() id
/// @returns {Struct} the item
function rai_item(_kind, _family, _material) {
    return { kind: _kind, family: _family, material: _material };
}

/// What slot and layer band an item occupies, whichever kind it is.
///
/// Kept as one function so nothing downstream has to branch on `kind` - the two builders declare
/// their cuts in different files and this is where the two vocabularies meet.
///
/// @param {Struct} _it from rai_item
/// @returns {Struct} {slot, layer}
function rai_item_place(_it) {
    if (_it.kind == "armour") {
        var _sp = rai_armour_spec(_it.family);
        return { slot: _sp.slot, layer: _sp.layer };
    }
    var _cut = rai_garment_cut(_it.family);
    return { slot: _cut.slot, layer: _cut.layer };
}

/// ============================================================================================
/// THE OUTFIT
/// ============================================================================================

/// Resolve a worn list into a legal, ordered set.
///
/// TWO THINGS HAPPEN HERE AND BOTH ARE THE EQUIP MODEL:
///   1. SLOT CONFLICT. Two items in one slot cannot both be worn. The LATER one wins, because that
///      is what equipping means in every game that has ever had an inventory - putting a coat on
///      takes the old coat off, it does not fail.
///   2. ORDERING. Sorted by layer band, ties broken by equip order, so the result is deterministic
///      and a buyer who equips the same things in the same order always gets the same figure.
///
/// ⚠️ RETURNS A NEW ARRAY AND DOES NOT TOUCH THE INPUT. A resolver that sorted the caller's own
/// array in place would silently reorder their inventory as a side effect of drawing it.
///
/// @param {Array} _worn array of rai_item
/// @returns {Array} resolved items, in draw order, each with `slot` and `layer` filled in
function rai_outfit_resolve(_worn) {
    var _n = array_length(_worn);
    var _kept = [];
    var _i, _j;

    for (_i = 0; _i < _n; _i++) {
        var _it = _worn[_i];
        var _pl = rai_item_place(_it);
        var _rec = { kind: _it.kind, family: _it.family, material: _it.material,
                     slot: _pl.slot, layer: _pl.layer, order: _i };
        // Later wins: drop anything already held in this slot.
        var _out = [];
        for (_j = 0; _j < array_length(_kept); _j++) {
            if (_kept[_j].slot != _rec.slot) array_push(_out, _kept[_j]);
        }
        array_push(_out, _rec);
        _kept = _out;
    }

    // Insertion sort by (layer, order). The set is a handful of items, so this is cheaper than
    // array_sort with a comparator struct and it is stable by construction.
    var _sorted = [];
    for (_i = 0; _i < array_length(_kept); _i++) {
        var _k = _kept[_i];
        var _at = array_length(_sorted);
        for (_j = 0; _j < array_length(_sorted); _j++) {
            var _s = _sorted[_j];
            if (_k.layer < _s.layer || (_k.layer == _s.layer && _k.order < _s.order)) { _at = _j; break; }
        }
        array_insert(_sorted, _at, _k);
    }
    return _sorted;
}

/// ============================================================================================
/// OCCLUSION
/// ============================================================================================

/// The vertical band an item covers, in unit space.
///
/// ⚠️ THIS IS AN HONEST APPROXIMATION AND IT IS LABELLED AS ONE. True occlusion would mean clipping
/// each garment against the silhouette of everything above it, which is a polygon boolean this
/// package does not have and does not need. What it DOES need is to stop drawing the fold lines and
/// the surface texture of a tunic that is entirely under a coat, because those marks show through
/// the coat's own outline at small sizes and read as dirt.
///
/// ⇒ So: a band, a coverage test, and the marks suppressed - never the garment itself. An item is
/// always drawn; only its DETAIL is dropped where something opaque is over it.
///
/// @param {Struct} _arm from rai_armature
/// @param {Struct} _rec a resolved item
/// @returns {Array} [y0, y1]
function rai_item_band(_arm, _rec) {
    if (_rec.kind == "armour") {
        var _sp = rai_armour_spec(_rec.family);
        return [rai_garment_y(_arm, _sp.top), rai_garment_y(_arm, _sp.bottom)];
    }
    var _cut = rai_garment_cut(_rec.family);
    return [rai_garment_y(_arm, _cut.top), rai_garment_y(_arm, _cut.bottom)];
}

/// How much of an item's band is covered by the items drawn after it.
///
/// @param {Struct} _arm from rai_armature
/// @param {Array} _sorted from rai_outfit_resolve
/// @param {Real} _idx index of the item to test
/// @returns {Real} 0 = fully visible, 1 = entirely inside a later item's band
function rai_item_covered(_arm, _sorted, _idx) {
    var _b = rai_item_band(_arm, _sorted[_idx]);
    var _h = _b[1] - _b[0];
    if (_h <= 0) return 0;
    var _worst = 0;
    var _i;
    for (_i = _idx + 1; _i < array_length(_sorted); _i++) {
        // Only an OPAQUE item occludes. A sash is a band across a tunic and hides nothing; a hood
        // is on the head and is not over the torso at all. Coverage is judged on the band, and the
        // band already encodes both of those correctly.
        var _o = rai_item_band(_arm, _sorted[_i]);
        var _lo = max(_b[0], _o[0]);
        var _hi = min(_b[1], _o[1]);
        if (_hi > _lo) _worst = max(_worst, (_hi - _lo) / _h);
    }
    return _worst;
}

/// ============================================================================================
/// THE ASSEMBLY
/// ============================================================================================

/// Build a whole dressed figure.
///
/// ⭐ THIS IS THE PRODUCT'S FRONT DOOR. Everything a buyer needs is here: a build, a pose, a worn
/// list, and back comes a part list and the palette to draw it with.
///
/// @param {String} _build_id one of rai_builds_all()
/// @param {String} _pose_id one of rai_poses_all()
/// @param {Array} _worn array of rai_item
/// @param {String} _skin material id used for the body, or undefined for the default
/// @param {Struct} _hair {style, material}, or undefined for a bare head
/// @returns {Struct} {parts, palette, arm, worn, count}
function rai_figure(_build_id, _pose_id, _worn, _skin, _hair) {
    var _arm = rai_armature(_build_id, _pose_id);
    var _sorted = rai_outfit_resolve(_worn);
    var _parts = [];
    var _pal = {};
    var _i, _j;

    // -- THE BODY, in its own namespace like everything else -----------------------------------
    var _skin_id = is_undefined(_skin) ? "buckskin" : _skin;
    var _sp = rai_material_palette(_skin_id);
    rai_pal_merge(_pal, _sp, "sk");
    var _body = rai_map_roles(rai_body_parts(_arm, "m2"), rai_ns_map("sk"));

    // ⛔ THE EYES GET THEIR OWN STOP AND IT IS NOT IN THE RAMP. rai_material's `ink` INVERTS on a
    // dark material, and two of the four hide materials the skin is drawn from sit below its 0.55
    // threshold - so eyes in `ink` are white on suede and oxhide. `m0` is one spread-step below
    // the face and gives a smear. This is a stop mixed for the job: the skin's own hue, almost no
    // chroma, and a lightness far enough below the face to read at four pixels.
    var _sd = rai_material_def(_skin_id);
    variable_struct_set(_pal, "sk_dark",
                        rai_oklch(clamp(_sd.L - 0.36, 0.08, 0.46), min(_sd.C, 0.028), _sd.h));
    rai_append(_body, rai_face_parts(_arm, "sk_dark"));

    // -- HAIR ----------------------------------------------------------------------------------
    // Its own namespace, because hair is a material like everything else worn (and 8 styles x 30
    // materials is 240 heads, which is what makes a crowd read as a crowd).
    var _hair_front = [];
    var _hair_back = [];
    if (!is_undefined(_hair)) {
        rai_pal_merge(_pal, rai_material_palette(_hair.material), "hr");
        var _hr = rai_material_roles(_hair.material);
        var _hmap = rai_ns_map("hr");
        _hair_front = rai_map_roles(rai_hair_parts(_arm, _hair.style, _hr), _hmap);
        _hair_back  = rai_map_roles(rai_hair_back_parts(_arm, _hair.style, _hr), _hmap);
    }

    // Anything in the BACK band is drawn before the body. That is what the band is for.
    var _behind = [];
    var _front = [];
    for (_i = 0; _i < array_length(_sorted); _i++) {
        if (_sorted[_i].layer < 10) array_push(_behind, _sorted[_i]);
        else array_push(_front, _sorted[_i]);
    }

    // ⚠️ THE FALL OF LONG HAIR GOES BEHIND THE BODY AND *IN FRONT OF* A CLOAK, which is the one
    // ordering a single band cannot express. Hair lies on the back of a cloak in life; drawn under
    // it, a hooded traveller's hair vanishes and the cloak grows a brown stripe nobody can place.
    for (_i = 0; _i < array_length(_behind); _i++) {
        rai_append(_parts, rai_wardrobe_item_parts(_arm, _behind[_i], "b" + string(_i), _pal,
                                                   rai_item_covered(_arm, _sorted, _i)));
    }
    rai_append(_parts, _hair_back);
    rai_append(_parts, _body);
    rai_append(_parts, _hair_front);
    for (_i = 0; _i < array_length(_front); _i++) {
        var _at = array_length(_behind) + _i;
        rai_append(_parts, rai_wardrobe_item_parts(_arm, _front[_i], "f" + string(_i), _pal,
                                                   rai_item_covered(_arm, _sorted, _at)));
    }
    // Hands last. Nothing in this wardrobe is a glove, and both the robe and the coat reach the
    // wrist - see rai_hand_parts' header for why this is an ordering fix and not a preference.
    rai_append(_parts, rai_map_roles(rai_hand_parts(_arm, "m2"), rai_ns_map("sk")));

    return { parts: _parts, palette: _pal, arm: _arm, worn: _sorted,
             count: array_length(_parts) };
}

/// Build one resolved item's parts, in its own role namespace, and merge its ramp into the palette.
///
/// @param {Struct} _arm from rai_armature
/// @param {Struct} _rec a resolved item
/// @param {String} _ns the namespace prefix for this item's roles
/// @param {Struct} _pal the palette being assembled, mutated in place
/// @param {Real} _covered from rai_item_covered
/// @returns {Array} part list
function rai_wardrobe_item_parts(_arm, _rec, _ns, _pal, _covered) {
    var _mp = rai_material_palette(_rec.material);
    rai_pal_merge(_pal, _mp, _ns);

    var _roles = rai_material_roles(_rec.material);
    var _raw;
    if (_rec.kind == "armour") {
        _raw = rai_armour_parts(_arm, _rec.family, _roles, _rec.material);
    } else {
        // ⛔ THE MATERIAL ID GOES THROUGH, NOT JUST ITS THREE ROLES. rai_garment_parts' header
        // records what its absence cost: every cloth garment in the product was drawing flat while
        // every armour piece carried its construction, because rai_surface_parts had exactly one
        // caller. A material is a weave and a sheen, not a hue.
        _raw = rai_garment_parts(_arm, _rec.family, _roles, _rec.material);
    }

    // The occlusion rule of rai_item_band: drop the DETAIL of a mostly-covered item, never the item.
    // 0.75 rather than 1.0 because a garment three quarters hidden contributes nothing but noise,
    // and requiring total coverage would keep the marks in every real layered outfit.
    if (_covered >= 0.75) {
        var _keep = [];
        var _i;
        for (_i = 0; _i < array_length(_raw); _i++) {
            // Fills and outlines carry the silhouette; strokes narrower than an outline are detail.
            var _p = _raw[_i];
            if (_p.kind == RAI_FILL || _p.kind == RAI_STRIP) { array_push(_keep, _p); continue; }
            if (_p.kind == RAI_POLY && _p.closed) { array_push(_keep, _p); continue; }
        }
        _raw = _keep;
    }

    return rai_map_roles(_raw, rai_ns_map(_ns));
}

/// The role map that rewrites a builder's roles into one item's namespace.
///
/// @param {String} _ns namespace prefix
/// @returns {Struct} role map for rai_map_roles
function rai_ns_map(_ns) {
    return {
        m0: _ns + "_m0", m1: _ns + "_m1", m2: _ns + "_m2", m3: _ns + "_m3", m4: _ns + "_m4",
        ink: _ns + "_ink", accent: _ns + "_accent"
    };
}

/// Merge one material palette into the combined palette under a namespace.
///
/// ⚠️ MUTATES `_dst` IN PLACE, which is stated because it is the one impure-looking thing in this
/// file. It is a local struct owned by rai_figure and never escapes to the caller un-returned.
///
/// @param {Struct} _dst the combined palette
/// @param {Struct} _src from rai_material_palette
/// @param {String} _ns namespace prefix
function rai_pal_merge(_dst, _src, _ns) {
    var _keys = ["m0", "m1", "m2", "m3", "m4", "ink", "accent"];
    var _i;
    for (_i = 0; _i < array_length(_keys); _i++) {
        variable_struct_set(_dst, _ns + "_" + _keys[_i], variable_struct_get(_src, _keys[_i]));
    }
    // The renderer falls back to `line` on an unknown role, so the combined palette must carry one
    // or a namespacing mistake becomes an undefined colour rather than a visibly wrong figure.
    if (!variable_struct_exists(_dst, "line")) variable_struct_set(_dst, "line", _src.m0);
}

/// ============================================================================================
/// THE CORPUS - counted, never asserted
/// ============================================================================================

/// Count what this product actually contains.
///
/// ⛔ THE LISTING QUOTES THIS FUNCTION'S OUTPUT AND NOTHING ELSE. ARCHITECTURE.md §7 and master
/// §2b rule 2: never write a count into the copy that a tool did not just print. The specific
/// failure this guards against is measured elsewhere in the factory - a pack sold for months with a
/// figure describing HALF its real contents, because the number was typed once and the pack grew.
///
/// `outfits` is the honest headline: every legal (family, material) pairing across both kinds,
/// which is the number of distinct single-garment figures this product can draw before any layering
/// or any build is chosen. It is deliberately NOT multiplied by builds and poses - that would be
/// true and it would be the kind of true number nobody believes.
///
/// @returns {Struct} the counts
function rai_corpus_count() {
    var _cloth = array_length(rai_garment_families());
    var _armour = array_length(rai_armour_families());
    var _mats = array_length(rai_materials_all());
    var _builds = array_length(rai_builds_all());
    var _poses = array_length(rai_poses_all());
    var _surfaces = array_length(rai_surfaces_all());
    // `bald` is a real style a buyer selects, so it is counted; the HEADS figure below is what it
    // multiplies into, and a bald head still takes its skin from the material corpus.
    var _hair = array_length(rai_hair_styles_all());

    // Armour piece constructions, counted from the declarations rather than from this comment.
    var _pieces = 0;
    var _fams = rai_armour_families();
    var _i;
    for (_i = 0; _i < array_length(_fams); _i++) {
        _pieces += array_length(rai_armour_pieces(_fams[_i]));
    }

    return {
        cloth_families: _cloth,
        armour_families: _armour,
        armour_pieces: _pieces,
        materials: _mats,
        surfaces: _surfaces,
        builds: _builds,
        poses: _poses,
        hair_styles: _hair,
        heads: _hair * _mats,
        outfits: (_cloth + _armour) * _mats,
        figures: (_cloth + _armour) * _mats * _builds
    };
}
