/// RAIMENT - rai_armour. The rigid families.
///
/// Six families - plate, mail, scale, brigandine, lamellar, leather - and they are NOT six recolours
/// of one shell. Each is built from a different construction, because that is what the eye actually
/// reads on armour: a cuirass is a few big surfaces with lit edges, a hauberk is thousands of small
/// rings, a brigandine is cloth with a rivet grid, lamellar is laced rows of little plates. Give all
/// six the same outline and change only the texture and you have shipped one product six times.
///
/// ⛔ THE DIVISION OF LABOUR WITH rai_garment, STATED ONCE SO NEITHER FILE DRIFTS.
///
///   rai_garment  cloth. Its shape is a DRAPE - it gathers, it carries material, it sags at the hem.
///   rai_armour   rigid. Its shape is a SHELL - it stands off the body by a roughly constant
///                distance and it does NOT gather. A plate that flares like a robe is not armour.
///
/// The exception is deliberate and physical: MAIL AND SCALE ARE FLEXIBLE. A hauberk hangs like a
/// heavy cloth because it is one, so those two families go through rai_drape exactly like a coat
/// does, and only their surface and hem are theirs. Forcing them into the rigid path is the single
/// commonest way generated mail ends up looking like a tin barrel.
///
/// ⛔ RELIEF IS WHAT MAKES METAL, NOT COLOUR. rai_material already gives metals a wider ramp spread
/// (0.190 against cloth's 0.115); this file spends that range by walling every rigid piece with
/// rai_bevel so the lit edge and the shadowed edge are on opposite sides of one plate. A metal
/// palette on a flat fill is a grey garment.
///
/// ⚠️ PURE except for building part lists. No draw calls, no engine state, no globals.

/// The rigid family ids, in a stable order.
///
/// ⛔ THE ORDER IS PART OF THE PRODUCT. rai_selftest counts the corpus from this list and the listing
/// quotes THAT number, so adding a family here changes a published figure.
function rai_armour_families() {
    return ["plate", "mail", "scale", "brigandine", "lamellar", "leather"];
}

/// The pieces a family is made of, in draw order within the family.
///
/// ⭐ THIS IS WHERE THE VOLUME ACTUALLY LIVES, and it is why a family is not one outline. Six
/// families declaring different piece sets is 29 distinct constructions before a single material is
/// chosen; rai_selftest counts this list rather than trusting the number in this comment.
///
/// @param {String} _id one of rai_armour_families()
/// @returns {Array} piece ids
function rai_armour_pieces(_id) {
    switch (_id) {
        // ⚠️ `cuisse` BEFORE `greave` - the list order is the draw order, and the greave's poleyn has
        // to land on top of the cuisse's lower edge to close the knee. See the cuisse block below
        // for why a harness without one showed bare thighs on the cover for weeks.
        case "plate":      return ["gorget", "cuirass", "pauldron", "tasset", "bracer",
                                   "cuisse", "greave"];
        case "mail":       return ["coif", "hauberk", "sleeve"];
        // ⛔ `tasset` REMOVED 2026-09-02, AND IT IS A DRAWING DECISION WITH A RECEIPT. A tasset is a
        // rigid plate hung from a rigid waist; on a FLEXIBLE corselet there is nothing to hang it
        // from, and drawn in the corselet's own material over the corselet's own scales it has no
        // relief to separate it - so what sheet 4 showed at 3x was two rounded rectangles at hip
        // height on a brown shirt, reading unmistakably as CARGO POCKETS. On plate and lamellar the
        // same piece lands on a rigid shell in a contrasting band and reads correctly, which is why
        // it stays there. A scale shirt already hangs to the thigh; it does not need them.
        case "scale":      return ["corselet", "sleeve"];
        case "brigandine": return ["shell", "pauldron", "bracer"];
        case "lamellar":   return ["bands", "pauldron", "tasset"];
        case "leather":    return ["cuirass", "pauldron", "bracer", "greave", "belt"];
        default:           return ["cuirass"];
    }
}

/// How a family is constructed.
///
/// `rigid` decides which of the two paths above the torso takes, and everything else follows from
/// it. `stand` is how far the shell sits off the body, as a fraction of stature - a PHYSICAL
/// thickness, so it is the same fraction on every build by design and the plate is not thicker on a
/// broad figure (rai_geom's inherited law).
///
/// @param {String} _id one of rai_armour_families()
/// @returns {Struct} the construction
function rai_armour_spec(_id) {
    switch (_id) {
        // ⛔ `bottom: "hip"` PUT A BARE TAN COLUMN BETWEEN THE CUISSES ON THE COVER. A cuirass that
        // stops at the hip line stops exactly where the two thigh plates begin and part, so the groin
        // is armoured by nothing - and because the tassets were (correctly) moved outboard onto the
        // hips in an earlier pass, nothing was left in the middle at all. Measured 2026-09-02 at 6x on
        // sheet 4 and on cover.png: a clean-edged skin-coloured rectangle hanging out of the bottom of
        // a full harness, which is the single most visible thing on the product's most-viewed image.
        //
        // ⭐ THE PIECE THAT CLOSES IT IS THE FAULD, AND IT IS WHY REAL HARNESS HAS ONE. Running the
        // cuirass to the seat (the crotch) puts its flared hem over the groin with the tassets hanging
        // on top at the hips, which is both the historical construction and the one that leaves no
        // hole. Nothing else changes: `flare` already belled the hem, it now bells where a fauld does.
        case "plate":
            return { rigid: true,  slot: "armour", layer: 30, top: "shoulder", bottom: "seat",
                     stand: 0.016, bevel: 0.011, steps: 3, hem: "flare", lace: false };
        case "mail":
            return { rigid: false, slot: "armour", layer: 30, top: "shoulder", bottom: "thigh",
                     stand: 0.010, bevel: 0.004, steps: 1, hem: "scallop", lace: false };
        // ⛔⛔ `bottom: "hip"` MADE THE SCALE SHIRT A BOX. It is `rigid: false`, so its outline came
        // from the CLOTH sampler at `heavy` (⚠️ NO LONGER TRUE IN THE PRESENT TENSE - the flexible
        // path took its own armour drape on 2026-09-02; see rai_armour_parts) - body + 0.0135 +
        // 0.0119 = 0.1294 of stature at the
        // shoulder, against a bare arm whose outer edge is at 0.86*0.104 + 0.026 = 0.1154. So the
        // panel is WIDER than the arms it hangs beside, and over the short shoulder-to-hip run that
        // width has nowhere to go: on sheet 4 it was a wide flat trapezoid cutting across both
        // upper arms, with a straight top edge and two rectangular tabs where the scalloped hem
        // fell. A cardboard box, and the worst cell on the sheet. MEASURED 2026-09-02.
        //
        // ⭐ THE FIX IS LENGTH, NOT WIDTH. Mail is the same construction through the same sampler at
        // the same width and reads correctly, and the only thing it does differently is hang to the
        // THIGH - which is what a scale shirt is. The extra run lets the width read as a garment
        // falling from the shoulders rather than as a slab bolted across them, and it puts the
        // scalloped hem over the thigh where a hem belongs instead of at the waist.
        case "scale":
            return { rigid: false, slot: "armour", layer: 30, top: "shoulder", bottom: "thigh",
                     stand: 0.012, bevel: 0.005, steps: 1, hem: "scallop", lace: false };
        case "brigandine":
            return { rigid: true,  slot: "armour", layer: 30, top: "shoulder", bottom: "hip",
                     stand: 0.013, bevel: 0.006, steps: 2, hem: "straight", lace: false };
        case "lamellar":
            return { rigid: true,  slot: "armour", layer: 30, top: "shoulder", bottom: "hip",
                     stand: 0.014, bevel: 0.007, steps: 2, hem: "straight", lace: true };
        case "leather":
            return { rigid: true,  slot: "armour", layer: 30, top: "shoulder", bottom: "waist",
                     stand: 0.012, bevel: 0.008, steps: 2, hem: "point", lace: false };
        default:
            return { rigid: true,  slot: "armour", layer: 30, top: "shoulder", bottom: "hip",
                     stand: 0.013, bevel: 0.008, steps: 2, hem: "straight", lace: false };
    }
}

/// The drape the FLEXIBLE armour path hangs on - mail and scale.
///
/// ⛔ ONE DRAPE STRUCT FOR THE FLEXIBLE PATH, DECLARED HERE AND READ THREE TIMES. The panel and the
/// yoke over it must be sized from the SAME numbers or the yoke either exposes the chord it exists to
/// cover or overhangs it as a shoulder pad - rai_yoke_parts' own header records measuring that. Two
/// literals is how they drift apart.
///
/// ⭐ AND IT IS A FUNCTION RATHER THAN A LOCAL SO THE SUITE CAN BUILD THE RING THE PRODUCT ACTUALLY
/// SHIPS. STAGE 6 used to exercise rai_hem_shape only on a rai_shell_ring, which is the one ring
/// shape whose hem the old midpoint rule located correctly, while every mail and scale corselet in
/// the package goes through rai_drape_ring - so the self-intersection assertion was green over a
/// shipped self-intersection. A fixture that re-derived these four numbers would drift out of step
/// with the product the first time one of them changed (wing CLAUDE.md, Chitin: a fixture must be
/// the call the product actually makes).
///
/// @param {Struct} _sp from rai_armour_spec
/// @returns {Struct} drape parameters for rai_drape_ring
function rai_armour_drape(_sp) {
    return { thickness: _sp.stand, fullness: 0.014, flare: 0.55, cling: 0.55 };
}

/// The surface character a CONSTRUCTION imposes on whatever it is made of.
///
/// ⛔⛔ WITHOUT THIS A MAIL HAUBERK IN IRON DRAWS RIVETS, AND IT DID, ON EVERY MAIL FIGURE THIS
/// PRODUCT HAS EVER MADE. rai_material_def gives iron the character `rivet`, which is right for a
/// breastplate and is what mail is defined by NOT being: mail is drawn wire, linked. The three
/// characters that describe a construction rather than a metal - `ring`, `scale`, `quilt` - were
/// declared in rai_surfaces_all(), counted into the corpus number the listing quotes, and reachable
/// from no material at all. MEASURED 2026-09-02 by reading the two tables against each other.
///
/// ⭐ AND IT IS WHAT MAKES SHEET 4 HONEST. Its caption says "six constructions, not one shell in
/// six colours" - with the surface taken from the material, three of the six were drawing the same
/// studs at three sizes. Now the family decides the weave and the material decides the colour and
/// the ramp, which is what the two words have always meant here.
///
/// @param {String} _id one of rai_armour_families()
/// @param {String} _mat material id
/// @returns {String} one of rai_surfaces_all()
function rai_armour_surface(_id, _mat) {
    switch (_id) {
        case "mail":       return "ring";
        case "scale":      return "scale";
        case "brigandine": return "quilt";
        // Plate, lamellar and leather take the material's own character: a steel cuirass IS
        // riveted, lamellar carries its lacing as geometry rather than as texture, and worked
        // leather's tooling is a property of the hide.
        default:           return rai_material_def(_mat).surface;
    }
}

/// Is a string present in an array of strings?
///
/// ⚠️ NAMED FOR ITS FIRST CALLER AND USED MORE WIDELY - rai_selftest asks it about slots, surface
/// characters and archetype material pools as well as about armour pieces. Said here rather than
/// left to be discovered, because a helper whose name is narrower than its use is how a later
/// session writes a second copy of it.
///
/// A named function rather than an inline literal on purpose: a function literal assigned to a
/// local inside a script is a struct method in GML, and its behaviour under `self` is a subtlety
/// this package has no reason to spend. Plain functions are what the rest of the file uses.
///
/// @param {Array} _list any array of strings
/// @param {String} _what the string to look for
/// @returns {Bool}
function rai_has_piece(_list, _what) {
    var _j;
    for (_j = 0; _j < array_length(_list); _j++) {
        if (_list[_j] == _what) return true;
    }
    return false;
}

/// ============================================================================================
/// THE RIGID SHELL - the counterpart of rai_drape_ring, and deliberately not it
/// ============================================================================================

/// A shell that follows the body at a near-constant offset and does NOT gather.
///
/// ⛔ THE WHOLE DIFFERENCE FROM rai_drape_ring IS THAT THE OFFSET DOES NOT GROW DOWNWARD. Cloth
/// accumulates material under its own weight, which is what `fullness` and `flare` model. Steel does
/// not. What a breastplate DOES do is bell slightly at the bottom edge to clear the hips, and that
/// is one term, applied over the last fifth of the piece, not a fullness spread over all of it.
///
/// ⚠️ Sampled at the same count as cloth so the two silhouettes agree where they meet. A shell built
/// from four points has visible corners against a fourteen-point garment behind it, and the eye
/// reads that as a z-fight rather than as two different materials.
///
/// @param {Struct} _arm from rai_armature
/// @param {Real} _y0 top of the piece in unit space
/// @param {Real} _y1 bottom of the piece in unit space
/// @param {Real} _stand offset from the body, as a fraction of stature
/// @param {Real} _bell how much the bottom edge flares clear of the body, same units
/// @returns {Array} closed ring of [x,y]
function rai_shell_ring(_arm, _y0, _y1, _stand, _bell) {
    var _right = [];
    var _left = [];
    var _i;
    var _off = _stand * _arm.span;
    var _bl = is_undefined(_bell) ? 0 : _bell * _arm.span;
    // ⛔⛔ THE ARMHOLE, AND WITHOUT IT EVERY RIGID FAMILY IS A BOARD HUNG ON THE CHEST. The ring was
    // sampled from `rai_body_halfwidth + stand` at every station including the top one, and at the
    // top station that function returns the full SHOULDER half-width - so the piece began as a
    // horizontal chord running the entire width of the figure, at the widest point of the figure,
    // with a square corner at each end. MEASURED 2026-09-02 by looking at sheet_4_armour: four of
    // six cells (brigandine, lamellar, leather, and scale through the flexible path) read as a
    // rectangle with a scale pattern on it, and the equip sheet showed the brigandine as a
    // sandwich board.
    //
    // ⚠️ THE PREVIOUS SESSION'S FIX WAS AIMED ONE FILE AWAY. It gave the FLEXIBLE families a cloth
    // yoke to cover their top chord, and wrote at length that a rigid shell keeps a straight upper
    // edge "because that is what a breastplate actually has". Half of that is true - a breastplate
    // has no gathered yoke - and the conclusion does not follow: a cuirass is CUT AWAY under the
    // arm so the joint can move, so its widest point is the CHEST and its top corners are drawn
    // well inboard of the acromion. A straight edge is not the same thing as a full-width one.
    //
    // Spent over the top quarter and gone by 0.25, so the widest station lands on the upper chest
    // where a breastplate's actually is. A fraction of the SHOULDER width rather than of stature,
    // because it is a cut relative to the joint it clears (this wing's standing law about a
    // dimension calibrated on one axis being wrong on another).
    var _hole = _arm.w_shoulder * 0.26;

    for (_i = 0; _i <= RAI_DRAPE_STEPS; _i++) {
        var _t = _i / RAI_DRAPE_STEPS;
        var _y = lerp(_y0, _y1, _t);
        // The bell is spent over the bottom fifth only. Below 0.8 it contributes nothing at all,
        // which is what keeps the chest flat.
        var _b = (_t <= 0.8) ? 0 : _bl * ((_t - 0.8) / 0.2);
        // ⚠️ EASED, NOT LINEAR. A straight ramp from the armhole to the chest gives a visible crease
        // where the cut stops; squaring the remaining fraction lands the piece on its full width
        // tangentially, which is what a rolled edge does.
        var _c = (_t >= 0.25) ? 0 : _hole * sqr(1 - _t / 0.25);
        var _w = rai_body_halfwidth(_arm, _y) + _off + _b - _c;
        array_push(_right, [_w, _y]);
        array_push(_left, [-_w, _y]);
    }

    var _ring = [];
    for (_i = 0; _i < array_length(_right); _i++) array_push(_ring, _right[_i]);
    for (_i = array_length(_left) - 1; _i >= 0; _i--) array_push(_ring, _left[_i]);
    return _ring;
}

/// A domed cap over a shoulder - the pauldron.
///
/// ⭐ THE SINGLE HIGHEST-VALUE PIECE IN THE FILE AT READING SIZE, which is why it gets its own
/// builder rather than being a scaled circle. Shoulders are the widest part of a standing figure
/// and the first thing the eye resolves in a silhouette, so a lit dome there says "armoured" at
/// sizes where the cuirass is four pixels of flat colour.
///
/// Elliptical, not circular: a pauldron is much wider than it is deep (rai_geom's arc header states
/// the general form of this trap). A circular cap on a shoulder reads as a ball joint.
///
/// @param {Struct} _arm from rai_armature
/// @param {Real} _side 0 or 1
/// @param {Real} _scale size multiplier, 1.0 is the plate default
/// @returns {Array} closed ring of [x,y]
/// ⚠️ FLATTER THAN IT WAS, AND LOWER. At 2.35 x 1.70 limb-widths the cap was nearly circular and
/// sat above the shoulder line, so three of them stacked read as a pile of bread rolls on each
/// shoulder - visible only at 3x, which is where it was found on 2026-09-02. A real pauldron is a
/// SHALLOW dome over the joint: much wider than it is deep, and its top is at the shoulder rather
/// than above it, because there is nothing up there for it to be strapped to.
function rai_pauldron_pts(_arm, _side, _scale) {
    var _k = is_undefined(_scale) ? 1 : _scale;
    var _sh = _arm.shoulder[_side];
    // ⚠️ 2.20 x 1.20 IS A DISC, NOT A DOME. Cropped to 3x on 2026-09-02 the flattened cap read as a
    // lily pad stuck out sideways from each shoulder: at nearly twice as wide as it is deep it has
    // no visible curvature left, so the relief has nothing to shade and the lames stack into one
    // flat plate. A pauldron is wider than it is deep and not by that much.
    var _rx = _arm.w_limb * 1.95 * _k;
    var _ry = _arm.w_limb * 1.52 * _k;
    // Sits slightly outboard of the joint, the way a real pauldron is strapped, and its crown is
    // tangent to the shoulder line rather than standing over it.
    var _cx = _sh[0] + (_side == 0 ? -1 : 1) * _arm.w_limb * 0.34;
    var _cy = _sh[1] + _ry * 0.62;
    return rai_ellipse_pts(_cx, _cy, _rx, _ry, 18);
}

/// A hip plate - the tasset. Two of them, hanging from the waist and clear of the thigh.
///
/// @param {Struct} _arm from rai_armature
/// @param {Real} _side 0 or 1
/// @param {Real} _drop how far down it hangs, as a fraction of stature
/// @returns {Array} closed ring of [x,y]
function rai_tasset_pts(_arm, _side, _drop) {
    var _dir = (_side == 0) ? -1 : 1;
    var _y0 = _arm.y_hip - _arm.span * 0.020;
    var _y1 = _y0 + _drop * _arm.span;
    // ⚠️ WIDER THAN THE HIP, BECAUSE THE FOREARM HANGS OVER IT. On the plate figure the bracers run
    // straight down past the hips, so a tasset that stops at the hip line is entirely behind one -
    // measured at 3x on 2026-09-02, where only ONE of the two was visible at all. It has to reach
    // past the arm to be a piece of armour rather than a rumour of one.
    var _w0 = _arm.w_hip * 1.18;
    var _w1 = _arm.w_hip * 1.34;
    // ⛔ THE INNER EDGE WAS AT ONE TENTH OF A HIP AND THAT IS THE CENTRE LINE. Both tassets ran
    // almost to x = 0, so the pair met in the middle and rendered as ONE small plate over the
    // crotch with the hips left bare - the opposite of what a tasset is, and unmistakable at 3x on
    // the plate figure. MEASURED 2026-09-02. They hang over the HIPS, from the outer half of the
    // waist, with a real gap between them: that gap is what lets the wearer walk and it is what
    // makes the piece read as two plates rather than as a skirt.
    return [
        [_dir * _arm.w_hip * 0.34, _y0],
        [_dir * _w0, _y0],
        [_dir * _w1, _y1 - _arm.span * 0.012],
        [_dir * _w1 * 0.82, _y1],
        [_dir * _arm.w_hip * 0.46, _y1]
    ];
}

/// ============================================================================================
/// HEMS - three, because the bottom edge is most of what tells two families apart
/// ============================================================================================

/// Replace the straight bottom run of a ring with a shaped hem.
///
/// ⭐ WHY THIS IS WORTH A FUNCTION. At figure size the torso of every armour family is roughly the
/// same rounded rectangle. The BOTTOM EDGE is not: mail scallops, plate bells and comes to a slight
/// point, a lamellar band cuts square. That edge is at the widest part of the piece and is rarely
/// occluded, so it does a disproportionate amount of the identifying.
///
/// @param {Array} _ring from rai_shell_ring or rai_drape_ring
/// @param {String} _kind "straight", "scallop", "point" or "flare"
/// @param {Real} _amt scale of the shaping, in unit space
/// @returns {Array} closed ring of [x,y]
/// The [first, last] index of a ring's BOTTOM RUN - the two points where the descending side meets
/// the ascending one, with any hem samples between them.
///
/// ⛔⛔ THIS EXISTS BECAUSE rai_hem_shape USED TO GUESS IT AS `_n div 2`, AND THAT GUESS WAS TRUE FOR
/// EXACTLY ONE OF THE TWO RING SHAPES THE PRODUCT SHIPS. rai_shell_ring emits 2*(STEPS+1) points and
/// nothing between the runs, so the midpoint IS the crossing. rai_drape_ring emits the same two runs
/// plus FIVE hem-sag samples between them, so with 35 points the midpoint lands on sag sample 2 and
/// sag sample 3 - two adjacent points near the CENTRE of the hem, 0.33 half-widths apart. Every
/// scallop lobe was then stepped across that sliver and pushed down by five times the sag, and the
/// outline folded back through itself.
///
/// MEASURED 2026-09-02 at 8x on sheet_4_armour: mail and scale - the only two flexible families, and
/// the only two that ask for a shaped hem - both showed a straight-cut hem with a small ragged,
/// self-intersecting tangle in the middle of it, enclosing a hole of background. The sheet's own
/// caption said "mail ... scallops at the hem" over a hem that did not scallop.
///
/// ⭐ AND THE SUITE HELD AN ASSERTION FOR EXACTLY THIS, WHICH PASSED: STAGE 6 called
/// `rai_is_simple(rai_hem_shape(shell_ring, "scallop"))` and went green, because its fixture built a
/// SHELL ring - the one shape where the midpoint guess is correct - while the product ships the hem
/// shaper a DRAPE ring. A harness that only ever constructs one input shape has an opinion about one
/// input shape (master CLAUDE.md 2b, the godot_verify row). The fixture is now both shapes.
///
/// @param {Array} _ring closed ring of [x,y], sampled top-down then bottom-up
/// @returns {Array} [first, last] index of the bottom run, or [-1,-1] if there is no clean one
function rai_hem_span(_ring) {
    var _n = array_length(_ring);
    if (_n < 4) return [-1, -1];
    var _ymin = _ring[0][1];
    var _ymax = _ring[0][1];
    var _i;
    for (_i = 1; _i < _n; _i++) {
        _ymin = min(_ymin, _ring[_i][1]);
        _ymax = max(_ymax, _ring[_i][1]);
    }
    var _h = _ymax - _ymin;
    if (_h <= 0.0001) return [-1, -1];

    // ⚠️ THE TOLERANCE IS DERIVED, NOT PICKED. Both ring builders sample their sides at
    // RAI_DRAPE_STEPS intervals over the piece's height, so consecutive side points are h/STEPS
    // apart; half of that is comfortably above any hem sag (a few thousandths of stature against a
    // piece a third of stature tall) and comfortably below the next point up either side.
    var _tol = _h / (RAI_DRAPE_STEPS * 2);
    var _a = -1;
    var _b = -1;
    var _count = 0;
    for (_i = 0; _i < _n; _i++) {
        if (_ring[_i][1] >= _ymax - _tol) {
            if (_a < 0) _a = _i;
            _b = _i;
            _count++;
        }
    }
    // The bottom run must be CONTIGUOUS. If it is not, this ring is not the shape this function
    // models and the caller gets an unshaped hem rather than a folded one.
    if (_a < 0 || (_b - _a + 1) != _count) return [-1, -1];
    return [_a, _b];
}

function rai_hem_shape(_ring, _kind, _amt) {
    if (_kind == "straight") return _ring;
    var _n = array_length(_ring);
    if (_n < 4) return _ring;

    var _sp = rai_hem_span(_ring);
    var _a = _sp[0];
    var _b = _sp[1];
    // ⛔ EVERY ONE OF THESE IS A REFUSAL TO SHAPE, NOT AN ATTEMPT TO COPE. A hem that cannot be
    // located is a straight hem; a hem that folds the outline back through itself is a defect that
    // reaches a buyer. Fail toward the boring picture.
    if (_a < 1 || _b <= _a || _b >= _n - 1) return _ring;

    var _r = _ring[_a];
    var _l = _ring[_b];
    // The two ends must straddle the centre line and be a real width apart, or they are not the two
    // sides of a hem.
    if (_r[0] <= 0 || _l[0] >= 0) return _ring;
    var _span = _r[0] - _l[0];
    if (_span <= 0.0001) return _ring;

    var _out = [];
    var _i;
    for (_i = 0; _i <= _a; _i++) array_push(_out, _ring[_i]);

    // Everything strictly between _a and _b is the old bottom run and is REPLACED. A sag and a shape
    // are two answers to the same question, and keeping both is what tangled it.
    var _y = max(_r[1], _l[1]);
    var _lobes = 7;
    var _per = 3;
    var _k = 0;
    var _j = 0;
    var _u = 0;
    var _d = 0;

    if (_kind == "point") {
        array_push(_out, [(_r[0] + _l[0]) * 0.5, _y + _amt]);
    } else if (_kind == "flare") {
        // A shallow bell: two shoulders rather than a single peak, so it reads as a rim.
        array_push(_out, [_r[0] * 0.55, _y + _amt * 0.75]);
        array_push(_out, [_l[0] * 0.55, _y + _amt * 0.75]);
    } else {
        // Scallop. Seven lobes across the hem, which is enough to read as mail and few enough that
        // each lobe survives at small size.
        //
        // ⚠️ SAMPLED AS ARCS, NOT AS ONE PUSHED-DOWN POINT PER LOBE. A single point per lobe is a
        // SAWTOOTH - straight lines meeting at spikes - and this wing has already paid for the
        // difference between a shape and the points that suggest it. Three interior samples on a
        // half-sine give each lobe a round bottom, and the cusp between two lobes returns to the hem
        // line so the edge reads as scallops rather than as a zigzag.
        for (_k = 0; _k < _lobes; _k++) {
            // Alternate deep and shallow so the edge is not a comb.
            _d = ((_k % 2) == 0) ? _amt : _amt * 0.52;
            for (_j = 1; _j <= _per; _j++) {
                _u = (_k + _j / (_per + 1)) / _lobes;
                array_push(_out, [_r[0] - _span * _u, _y + _d * sin(pi * (_j / (_per + 1)))]);
            }
            if (_k < _lobes - 1) {
                array_push(_out, [_r[0] - _span * ((_k + 1) / _lobes), _y]);
            }
        }
    }

    for (_i = _b; _i < _n; _i++) array_push(_out, _ring[_i]);
    return _out;
}

/// Cut a neck opening into the straight top chord of a rigid shell.
///
/// ⭐ THE OTHER HALF OF THE ARMHOLE. Narrowing the top corners (rai_shell_ring) stops the piece
/// spanning the whole figure; it still leaves a straight bar running across the throat, and a bar
/// with a head coming out of the middle of it is the shape this sheet has been failing on. A real
/// cuirass is cut away at the neck so the wearer can look down, and that scoop is most of what says
/// "breastplate" at reading size.
///
/// ⛔ IT MUST BE APPLIED AFTER rai_hem_shape, NOT INSIDE rai_shell_ring. That function finds the hem
/// by taking the MIDPOINT OF THE ARRAY and relies on both runs being the same length; adding points
/// at the top would move the midpoint and silently scallop a breastplate somewhere up its own side.
/// The wing's yoke header records the identical trap from the other direction. Appending here is
/// safe because the ring closes from its last point back to its first, which is exactly the top
/// chord these points replace.
///
/// ⚠️ THE WALLS LEAN OUTWARD AS THEY RISE, AND THAT IS A CONSTRAINT RATHER THAN A STYLE CHOICE.
/// rai_ring_fill is a triangle fan from a point at the middle of the piece, and this wing's Welkin
/// entry records what a fan does to a concavity it cannot see into. A notch whose sides open upward
/// stays visible from any point below it; one with vertical or inward-leaning sides does not.
///
/// @param {Array} _ring from rai_hem_shape
/// @param {Struct} _arm from rai_armature
/// @param {Real} _y0 the piece's top, in unit space
/// @param {Real} _drop how deep the scoop cuts, in unit space
/// @returns {Array} closed ring of [x,y]
function rai_shell_neck(_ring, _arm, _y0, _drop) {
    var _n = array_length(_ring);
    if (_n < 4) return _ring;
    // The top chord runs from the LAST point (top-left) back to index 0 (top-right), so the inserted
    // run has to go left to right.
    var _xr = _ring[0][0];
    var _out = [];
    var _i;
    for (_i = 0; _i < _n; _i++) array_push(_out, _ring[_i]);

    var _mouth = _arm.w_neck * 1.95;
    var _floor = _arm.w_neck * 1.12;
    // A scoop wider than the chord it is cut into would swallow the corners the armhole just made.
    if (_mouth >= _xr * 0.80) _mouth = _xr * 0.80;
    if (_floor >= _mouth * 0.70) _floor = _mouth * 0.70;

    array_push(_out, [-_mouth, _y0 + _drop * 0.18]);
    array_push(_out, [-_floor, _y0 + _drop]);
    array_push(_out, [ _floor, _y0 + _drop]);
    array_push(_out, [ _mouth, _y0 + _drop * 0.18]);
    return _out;
}

/// ============================================================================================
/// THE FAMILY BUILDER
/// ============================================================================================

/// Build one armour as a part list.
///
/// ⚠️ TAKES THE MATERIAL ID, NOT JUST ITS ROLES, and that is not redundancy. The surface character
/// belongs to the MATERIAL (mail rings, rivets, tooling) and the construction belongs to the
/// FAMILY, so a brigandine in oxhide and a brigandine in steel are two visibly different objects
/// built by the same code path. Passing only the three colour roles would collapse them.
///
/// @param {Struct} _arm from rai_armature
/// @param {String} _id one of rai_armour_families()
/// @param {Struct} _roles {face, shade, line} from rai_material_roles
/// @param {String} _mat material id, for the surface character
/// @returns {Array} part list
function rai_armour_parts(_arm, _id, _roles, _mat) {
    var _sp = rai_armour_spec(_id);
    var _face = _roles.face;
    var _line = _roles.line;
    var _shade = _roles.shade;
    var _out = [];
    var _i, _s;

    var _y0 = rai_garment_y(_arm, _sp.top);
    var _y1 = rai_garment_y(_arm, _sp.bottom);
    var _pieces = rai_armour_pieces(_id);
    var _fd = rai_armour_drape(_sp);

    // -- SLEEVES FIRST, FOR THE REASON rai_garment_parts RECORDS AT LENGTH ---------------------
    //
    // ⛔⛔ THEY USED TO BE LAST AND THEY WERE THE WORST OBJECT ON THE ARMOUR SHEET. A sleeve ring is
    // centred on the shoulder joint, so half its width lies INSIDE the torso - and emitted after
    // the hauberk it painted a rectangle over the chest, hid the arm behind it, and put a hard
    // vertical seam down each side of the body. Cropped at 3x on the mail figure, 2026-09-02: two
    // grey boards bolted to a person. The cloth half of the wardrobe had already been fixed this
    // way and the armour half was missed, which is the copy-per-family trap this wing keeps paying
    // for - the knowledge did not reach the second file.
    //
    // ⚠️ AND ITS OWN DRAPE, NOT THE SHELL'S STAND-OFF. `_sp.stand` is calibrated against a TORSO
    // half-width of about 0.104 of stature; against a limb's 0.026 the same figure is a 46%
    // increase, so a mail sleeve came out nearly twice the diameter of the arm in it. This is the
    // wing's standing law - a dimension calibrated on one axis is wrong on another - and the
    // bracer above already carries a comment about the identical mistake.
    if (rai_has_piece(_pieces, "sleeve")) {
        var _sd = { thickness: _sp.stand * 0.42, fullness: 0.010, flare: 0.40, cling: 0.50 };
        var _shw = rai_sleeve_head_w(_arm, _sd);
        for (_s = 0; _s < 2; _s++) {
            var _sl = rai_sleeve_ring(_arm, _s, 0.58, _sd);
            // The armhole - see rai_sleeve_head_w for why a cap is needed at all.
            //
            // ⛔⛔ THIS COMMENT USED TO READ "Tangent to the shoulder line, never over it" ABOVE A
            // NUMBER THAT IS NEITHER. At centre +0.42 of its own radius the disc's crown stands
            // 0.58 radii ABOVE y_shoulder, and rai_armature's shoulder-cap block states the rule it
            // breaks: rai_body_halfwidth returns 0 above that line, so NO garment can ever reach up
            // there to cover what protrudes into it. An assertion that a comment makes about the
            // code beneath it is worth exactly nothing - this one was wrong for as long as it
            // existed, and it read as confirmation every time somebody checked.
            //
            // ⭐ AND THE FIX WAS ALREADY WRITTEN, IN THE SIBLING FILE, ON THE SAME DAY. rai_garment
            // line 522 carries this identical cap at +0.86 with a measured receipt: at 0.42 "two
            // round lumps rose out of the shoulder slab ... they read as 1980s shoulder pads",
            // cropped at 4x and looked at. That session fixed the cloth half and the armour half was
            // missed - which is the copy-per-family trap the sleeve block 15 lines above THIS one
            // names in its own header. The trap caught the very edit that documented it.
            //
            // Why it was invisible on five families and glaring on the sixth: the lumps only show
            // where nothing is drawn over the shoulder afterwards. plate/brigandine/lamellar/leather
            // all declare a `pauldron` and mail declares a `coif`, and every one of those lands on
            // top. `scale` declares neither (rai_armour_pieces), so on the armour sheet its corselet
            // read as a board hung across the chest with two bare shoulder balls above it - the
            // worst cell on the sheet, and three earlier sessions tuned its WIDTH and its LENGTH
            // trying to fix a defect that was never in the corselet at all.
            //
            // ⭐ THE NUMBER NO LONGER LIVES HERE. Both halves of the wardrobe now call one cap
            // builder (rai_sleeve_cap, beside rai_sleeve_head_w that they already shared), so this
            // cannot drift out of step with the cloth half a third time.
            array_push(_out, rai_sleeve_cap(_arm, _s, _shw, _face));
            array_push(_out, rai_ring_fill(_sl, _face, _arm.shoulder[_s][0], _arm.shoulder[_s][1]));
            var _sbb = rai_pts_bounds(_sl);
            var _stx = rai_surface_marks(rai_armour_surface(_id, _mat), _mat,
                                         _sbb[0], _sbb[1], _sbb[2], _sbb[3], _arm.span, _shade,
                                         undefined, undefined);
            for (_i = 0; _i < array_length(_stx); _i++) {
                var _sclip = rai_clip_part_to_ring(_stx[_i], _sl);
                if (!is_undefined(_sclip)) array_push(_out, _sclip);
            }
            rai_append(_out, rai_sleeve_form(_arm, _sl, _shade));
            array_push(_out, rai_poly(_sl, true, _arm.span * 0.004, _line));
        }
    }

    // -- THE TORSO PIECE ---------------------------------------------------------------------
    var _body;
    if (_sp.rigid) {
        _body = rai_shell_ring(_arm, _y0, _y1, _sp.stand, (_sp.hem == "flare") ? 0.018 : 0.004);
    } else {
        // Flexible: mail and scale hang. Deliberately routed through the cloth sampler - see the
        // header - so they carry weight without billowing.
        //
        // ⚠️ AND NOT ON A CLOTH PRESET, WHICH IS WHAT `heavy` IS. `heavy` is a WINTER COAT: cling
        // 0.20, i.e. it stands almost all of its thickness off the body, plus 0.030 of fullness it
        // spends widening downward. Armour that hangs still hangs ON the wearer - a hauberk lies on
        // the shoulders and follows the ribs - so at 0.1232 half-width against a 0.0978 chest the
        // corselet came out a quarter wider than the body it was on, and the panel, the two sleeves
        // and the yoke merged into one slab. MEASURED 2026-09-02 by cropping the scale cell to 3x.
        //
        // The thickness now comes from the family's OWN declared stand-off rather than from a cloth
        // table, cling is high because mail drapes tightly, and fullness is halved: it is still
        // flexible - the vacuity guard in STAGE 5 proves cloth behaviour is what this path produces
        // - but it is armour-flexible rather than coat-flexible.
        _body = rai_drape_ring(_arm, _y0, _y1, _fd, 0.004);
    }
    _body = rai_hem_shape(_body, _sp.hem, _arm.span * 0.022);
    // ⚠️ RIGID ONLY, AND FOR THE SAME REASON THE YOKE IS FLEXIBLE ONLY. mail and scale come out of
    // rai_drape_ring and get a cloth yoke over their top edge a few lines below, which already
    // covers the chord; cutting a scoop into it as well would open a hole between the two.
    if (_sp.rigid) _body = rai_shell_neck(_body, _arm, _y0, _arm.span * 0.030);

    array_push(_out, rai_ring_fill(_body, _face, 0, (_y0 + _y1) * 0.5));

    // The surface character, clipped to the piece it is on. rai_material returns marks across a
    // BAND; rai_geom's clipping header states why the clip has to happen against the outline's own
    // width at each height rather than against its bounding box.
    var _bb = rai_pts_bounds(_body);
    var _tex = rai_surface_marks(rai_armour_surface(_id, _mat), _mat,
                                 _bb[0], _bb[1], _bb[2], _bb[3], _arm.span, _shade,
                                 undefined, undefined);
    for (_i = 0; _i < array_length(_tex); _i++) {
        var _clipped = rai_clip_part_to_ring(_tex[_i], _body);
        if (!is_undefined(_clipped)) array_push(_out, _clipped);
    }

    // Relief. This is what makes it metal rather than a coloured panel.
    var _bev = rai_bevel(_body, _sp.bevel * _arm.span, _sp.steps, false);
    for (_i = 0; _i < array_length(_bev); _i++) array_push(_out, _bev[_i]);

    // -- LACING, ON THE ONE FAMILY DEFINED BY IT ----------------------------------------------
    if (_sp.lace) {
        // Lamellar is rows of small plates LACED together, and the lacing is the family. Drawn as
        // horizontal courses with the plate divisions marked, rather than as a texture, because the
        // courses have to follow the shell's changing width.
        var _rows = 6;
        var _r;
        for (_r = 1; _r < _rows; _r++) {
            var _ry = lerp(_y0, _y1, _r / _rows);
            var _rw = rai_body_halfwidth(_arm, _ry) + _sp.stand * _arm.span;
            array_push(_out, rai_poly([[-_rw, _ry], [_rw, _ry]], false, _arm.span * 0.005, _line));
            // The vertical divisions between plates in this course.
            var _cols = 7;
            var _c;
            for (_c = 1; _c < _cols; _c++) {
                var _cx = lerp(-_rw, _rw, _c / _cols);
                var _ny = lerp(_y0, _y1, (_r + 1) / _rows);
                array_push(_out, rai_poly([[_cx, _ry], [_cx, min(_ny, _y1)]], false,
                                          _arm.span * 0.003, _shade));
            }
        }
    }

    // Outline last so nothing crosses it.
    array_push(_out, rai_poly(_body, true, _arm.span * 0.006, _line));

    // -- THE SHOULDER, ON THE FAMILIES THAT HANG RATHER THAN STAND ----------------------------
    //
    // ⛔⛔ THE THIRD THING rai_garment FIXED AND rai_armour NEVER HEARD ABOUT. rai_drape_ring builds
    // its top as a straight chord at _y0, so a hanging shell terminates in a horizontal bar across
    // the chest; rai_yoke_parts exists precisely to cover that bar and both sleeve heads, and its
    // own header records being measured and reshaped on 2026-09-02 "by looking at sheet 7" - the
    // CLOTH sheet. The armour half was not looked at in the same pass, so mail and scale kept the
    // bar. On `scale`, which has no coif over it, that bar IS the "board hung across the chest" this
    // sheet has been failing on. Same file, same day, same trap, third time: the sleeve cap above is
    // the second and its own header names the first.
    //
    // ⚠️ FLEXIBLE FAMILIES ONLY, AND THAT IS A DESIGN STATEMENT RATHER THAN A SHORTCUT. A yoke is
    // cloth gathered over the shoulder; plate, brigandine, lamellar and leather are `rigid: true`
    // and their tops come from rai_shell_ring - they carry a gorget or pauldrons over it instead.
    // Giving a rigid shell a cloth yoke would be a new defect traded for an old one.
    //
    // ⛔ THIS BLOCK USED TO ARGUE THAT "a straight upper edge is what a breastplate actually has",
    // AND THAT SENTENCE WAS DOING REAL DAMAGE: it read as a settled reason not to look at the rigid
    // families' top edge, and they were the four cells still failing sheet 4. Half of it was true
    // (a breastplate has no gathered yoke) and the conclusion did not follow - a cuirass is cut away
    // under the arm and scooped at the throat, and neither of those is a yoke. Both now happen in
    // rai_shell_ring and rai_shell_neck, where the receipts are. Corrected 2026-09-02.
    //
    // It also keeps the widths exact: the
    // flexible path is the one whose panel is a rai_drape_ring, so rai_yoke_parts' own
    // rai_drape_halfwidth call returns the SAME width the panel was built from, by construction
    // rather than by a number that has to be kept in step.
    if (!_sp.rigid) {
        var _yd = { thickness: _sp.stand * 0.42, fullness: 0.010, flare: 0.40, cling: 0.50 };
        var _yk = rai_yoke_parts(_arm, _y0, _fd,
                                 rai_has_piece(_pieces, "sleeve") ? 0.58 : 0,
                                 _roles, _yd);
        for (_i = 0; _i < array_length(_yk); _i++) array_push(_out, _yk[_i]);
    }

    // -- THE PIECES THAT ARE NOT THE TORSO ----------------------------------------------------

    // ⛔ THE GORGET GOES DOWN BEFORE THE PAULDRONS, AND IT USED TO GO AFTER THEM. It is a collar
    // at the base of the neck, so anything strapped over the shoulder laps ON TOP of it; drawn
    // last it sat over both pauldrons as a pale lozenge across the collarbones and read as a bib.
    // Seen at 3x on the plate figure, 2026-09-02.
    if (rai_has_piece(_pieces, "gorget")) {
        var _gy = _arm.y_shoulder - _arm.span * 0.010;
        var _gwd = _arm.w_neck * 3.10;
        var _gp = rai_ellipse_pts(_arm.neck[0], _gy, _gwd, _arm.span * 0.017, 16);
        var _gr2 = rai_raise(_gp, _arm.span * 0.005, 2, _face);
        for (_i = 0; _i < array_length(_gr2); _i++) array_push(_out, _gr2[_i]);
        array_push(_out, rai_poly(_gp, true, _arm.span * 0.0035, _line));
    }

    if (rai_has_piece(_pieces, "pauldron")) {
        // ⛔ ONE ELLIPSE IS A BALL JOINT, NOT A PAULDRON, AND THE SHEET SAID SO. The old version
        // raised a single elliptical cap over each shoulder; on the armour sheet that read as two
        // pebbles stuck on the figure, identical across all four families that carry the piece and
        // carrying no information about any of them.
        //
        // ⭐ A PAULDRON IS LAMES - overlapping plates, each with its own lit top edge, growing as
        // they run outward and down over the arm. Three of them is enough to read at any size this
        // ships at, and the STEP between them is what makes the shoulder look articulated instead
        // of moulded. Cheap: the same cap builder at three scales and three offsets.
        var _pscale = (_id == "plate") ? 1.0 : 0.82;
        for (_s = 0; _s < 2; _s++) {
            var _dir2 = (_s == 0) ? -1 : 1;
            // ⚠️ DRAWN BOTTOM-UP, SMALLEST LAST. Plate laps DOWNWARD - each lame overlaps the one
            // below it so rain and a blade both run off - so the lowest and largest goes down
            // first and the smallest, nearest the neck, is painted last on top of it. The first
            // version drew them the other way and the stack read as three separate pads.
            // ⛔⛔ THE LAMES WERE THERE AND INVISIBLE, SO THE PIECE WAS STILL A BALL JOINT - THE
            // COMMENT ABOVE DESCRIBED A SHAPE THE NUMBERS DID NOT PRODUCE. MEASURED 2026-09-02 by
            // cropping the brigandine shoulder out of sheet 4 at 4x and looking at it: three
            // ellipses at a 0.130 scale step, offset by 0.66 of a limb-width, land inside each
            // other's outlines and composite into ONE flat disc with a sliver of the plate below
            // showing at the bottom corner. It read as a chocolate button stuck on the shoulder.
            //
            // ⭐ AND THE RATIO WAS NOT THE PROBLEM, WHICH MATTERS BECAUSE IT HAD ALREADY BEEN TUNED
            // THREE TIMES IN OPPOSITE DIRECTIONS - 2.35x1.70 "bread rolls", then 2.20x1.20 "lily
            // pad", then 1.95x1.52 - each time by eye and each time moving. The crop says the disc
            // reads as a ball because it carries NO ARTICULATION AND NO SHADING, not because it is
            // round: a flat fill of one colour has no shape at any aspect. So the two things the
            // evidence actually names are changed here and the ellipse is deliberately left alone.
            //
            // Separation: a 0.17 step with the offset at 1.05 limb-widths puts each lame's edge
            // OUTSIDE the one above it, which is what makes three plates instead of one mass.
            // Relief: 0.011 is the depth the plate cuirass uses, and the pauldron is the piece that
            // most needs a lit crown because it is the highest point of the silhouette.
            var _lame;
            for (_lame = 2; _lame >= 0; _lame--) {
                var _lk = _pscale * (1.00 - _lame * 0.170);
                var _pp = rai_pauldron_pts(_arm, _s, _lk);
                var _off = _arm.w_limb * _lame * 1.05;
                var _pm = rai_move_pts(_pp, _dir2 * _off * 0.62, _off * 0.86);
                var _pr = rai_raise(_pm, _arm.span * 0.011, 2, _face);
                for (_i = 0; _i < array_length(_pr); _i++) array_push(_out, _pr[_i]);
                array_push(_out, rai_poly(_pm, true, _arm.span * 0.0045, _line));
            }
        }
    }

    if (rai_has_piece(_pieces, "tasset")) {
        for (_s = 0; _s < 2; _s++) {
            var _tp = rai_tasset_pts(_arm, _s, 0.108);
            var _tr = rai_raise(_tp, _arm.span * 0.007, 2, _face);
            for (_i = 0; _i < array_length(_tr); _i++) array_push(_out, _tr[_i]);
            array_push(_out, rai_poly(_tp, true, _arm.span * 0.004, _line));
        }
    }

    if (rai_has_piece(_pieces, "bracer")) {
        for (_s = 0; _s < 2; _s++) {
            // ⛔ THE STAND-OFF IS CALIBRATED ON THE TORSO AND A LIMB IS NOT A TORSO. `stand` runs
            // 0.010-0.016 of STATURE, which against a torso half-width of ~0.104 is a believable
            // 10-15% of plate proud of the body - and against a limb half-width of 0.026 it is 62%,
            // so the bracer came out 0.048 span wide on a 0.152 span forearm. Nearly square, drawn
            // over a thin arm, tilted with the elbow: on the armour sheet it read as a rectangle
            // floating beside the figure rather than as a piece of harness on it. MEASURED
            // 2026-09-02 by looking at the sheet.
            // ⚠️ This is the wing's own recorded failure shape - a dimension derived from the wrong
            // axis, worst exactly where the product could least afford it - and rai_shape's corner
            // header states the general rule: a physical detail is bounded, not proportional.
            // ⛔ NARROWER STILL, AND WITH A COUTER, BECAUSE A RECTANGLE ON A FOREARM IS A PLANK.
            // At 1.18 limb-widths plus a stand-off the bracer was 36% wider than the arm inside
            // it, with two square ends and no join to anything - so on the armour sheet it read as
            // a grey board hung beside the figure rather than as harness strapped to it. Cropping
            // the plate figure to 3x on 2026-09-02 is what showed it; at sheet size it just looked
            // untidy. A vambrace CLOSES on the arm, so it is barely wider than the limb, and the
            // piece that makes it read as articulated is the COUTER - the cop over the elbow that
            // the pauldron above and the bracer below both run into.
            var _w = _arm.w_limb * 1.06 + _sp.stand * _arm.span * 0.22;
            var _br = rai_limb_ring(_arm.elbow[_s], _arm.wrist[_s], _w, _w * 0.88);
            // The couter goes down FIRST so the bracer's own square top edge is covered by it.
            var _cp = rai_raise(rai_ellipse_pts(_arm.elbow[_s][0], _arm.elbow[_s][1],
                                                _w * 1.28, _w * 1.10, 14),
                                _arm.span * 0.006, 2, _face);
            for (_i = 0; _i < array_length(_cp); _i++) array_push(_out, _cp[_i]);
            array_push(_out, rai_ring_fill(_br, _face, _arm.elbow[_s][0], _arm.elbow[_s][1]));
            var _bb2 = rai_bevel(_br, _arm.span * 0.004, 2, false);
            for (_i = 0; _i < array_length(_bb2); _i++) array_push(_out, _bb2[_i]);
            array_push(_out, rai_poly(_br, true, _arm.span * 0.0035, _line));
            array_push(_out, rai_poly(rai_ellipse_pts(_arm.elbow[_s][0], _arm.elbow[_s][1],
                                                      _w * 1.28, _w * 1.10, 14),
                                      true, _arm.span * 0.0035, _line));
        }
    }

    // ⛔⛔ THE THIGH WAS BARE ON EVERY PLATE HARNESS THIS PRODUCT HAS EVER DRAWN, AND IT IS ON THE
    // COVER. A plate figure carried a tasset at the hip and a greave from the KNEE down, with
    // nothing at all between them - so under the tunic hem there was a band of bare skin on each
    // leg, and the most-looked-at image in the listing showed a knight in a short skirt with bare
    // thighs. MEASURED 2026-09-02 by cropping the cover at 4x and looking at it. Nothing mechanical
    // could see it: every piece was correctly built, correctly placed and correctly shaded, and the
    // defect is the SET, not any member of it.
    //
    // ⭐ THE PIECE IS CALLED A CUISSE AND A HARNESS IS NOT A HARNESS WITHOUT ONE. Drawn before the
    // greave so the poleyn - the knee cop that already exists on the greave - covers the joint where
    // the two meet, which is exactly what a poleyn is for. It starts below the hip rather than at
    // it, so the tasset hangs over its top edge instead of butting against it.
    if (rai_has_piece(_pieces, "cuisse")) {
        for (_s = 0; _s < 2; _s++) {
            var _cw0 = _arm.w_limb * 1.34 + _sp.stand * _arm.span * 0.22;
            var _cw1 = _arm.w_limb * 1.12 + _sp.stand * _arm.span * 0.22;
            var _ctop = [lerp(_arm.hip[_s][0], _arm.knee[_s][0], 0.14),
                         lerp(_arm.hip[_s][1], _arm.knee[_s][1], 0.14)];
            var _cr2 = rai_limb_ring(_ctop, _arm.knee[_s], _cw0, _cw1);
            array_push(_out, rai_ring_fill(_cr2, _face, undefined, undefined));
            var _cb = rai_bevel(_cr2, _arm.span * 0.004, 2, false);
            for (_i = 0; _i < array_length(_cb); _i++) array_push(_out, _cb[_i]);
            array_push(_out, rai_poly(_cr2, true, _arm.span * 0.0035, _line));
        }
    }

    if (rai_has_piece(_pieces, "greave")) {
        for (_s = 0; _s < 2; _s++) {
            // Same torso-calibrated stand-off problem as the bracer above; the greave was the pair
            // of oversized slabs on the plate figure's shins.
            // Same narrowing and the same joint cop as the bracer above - a poleyn over the knee.
            var _gw = _arm.w_limb * 1.10 + _sp.stand * _arm.span * 0.22;
            var _gr = rai_limb_ring(_arm.knee[_s], _arm.ankle[_s], _gw, _gw * 0.86);
            var _pl = rai_ellipse_pts(_arm.knee[_s][0], _arm.knee[_s][1], _gw * 1.30, _gw * 1.12, 14);
            var _pr2 = rai_raise(_pl, _arm.span * 0.006, 2, _face);
            for (_i = 0; _i < array_length(_pr2); _i++) array_push(_out, _pr2[_i]);
            array_push(_out, rai_ring_fill(_gr, _face, _arm.knee[_s][0], _arm.knee[_s][1]));
            var _gb = rai_bevel(_gr, _arm.span * 0.004, 2, false);
            for (_i = 0; _i < array_length(_gb); _i++) array_push(_out, _gb[_i]);
            array_push(_out, rai_poly(_gr, true, _arm.span * 0.0035, _line));
            array_push(_out, rai_poly(_pl, true, _arm.span * 0.0035, _line));
        }
    }

    if (rai_has_piece(_pieces, "belt")) {
        var _by = _arm.y_waist;
        var _bw = rai_body_halfwidth(_arm, _by) + _sp.stand * _arm.span * 1.2;
        var _bh = _arm.span * 0.026;
        array_push(_out, rai_fill([[-_bw, _by - _bh * 0.5], [_bw, _by - _bh * 0.5],
                                   [_bw, _by + _bh * 0.5], [-_bw, _by + _bh * 0.5]], _shade));
        // The buckle: a rect treatment, which is what rai_shape's six corner forms are here for.
        var _kw = _arm.span * 0.024;
        var _bk = rai_shape_pts("chamfer", -_kw * 0.5, _by - _kw * 0.45,
                                _kw * 0.5, _by + _kw * 0.45, 1.0, 1.0, 4);
        var _bkr = rai_raise(_bk, _arm.span * 0.004, 2, "m4");
        for (_i = 0; _i < array_length(_bkr); _i++) array_push(_out, _bkr[_i]);
    }

    if (rai_has_piece(_pieces, "coif")) {
        // -- MAIL HOOD ------------------------------------------------------------------------
        //
        // ⛔⛔ THE FIRST VERSION WAS A GREY FRYING PAN AND IT WAS ON THE ARMOUR SHEET. It drew one
        // circular ellipse of radius 1.22 head-radii and then a second FILLED ellipse on top of
        // it, so the head vanished and what remained was a large flat disc with a darker disc in
        // the middle of it - a pan seen face-on, or a sombrero, hovering over a pair of shoulders.
        // MEASURED 2026-09-02 by looking at sheet 4: `mail / iron`, the second cell.
        //
        // Three things were wrong and all three are fixed here. The opening was a DISC rather than
        // an ANNULUS, so the face could not show through it (the same defect rai_garment's hood
        // carried, and its header has the general form). The shell was near-CIRCULAR, so it did
        // not fall onto the shoulders the way an aventail does and had no reason to be that size.
        // And it had no scalloped edge, which is the one thing that says mail rather than cloth -
        // rai_hem_shape existed for exactly that and the coif was not calling it.
        var _hx2 = _arm.head[0];
        var _hy2 = _arm.head[1] - _arm.head_r * 0.06;
        var _hr2 = _arm.head_r;
        var _st  = _sp.stand * _arm.span;
        // _cn + 1 samples, last repeating the first - rai_strip does not close a ring for you.
        var _cn  = 24;
        var _shell2 = array_create(_cn + 1);
        var _open2  = array_create(_cn + 1);
        for (_i = 0; _i <= _cn; _i++) {
            var _ca = (_i / _cn) * RAI_TAU;
            var _cc = cos(_ca);
            var _cs = sin(_ca);
            var _cl = power(max(0, _cs), 1.45);
            // The aventail: mail hangs, so the lower half runs well past the jaw and spreads onto
            // the shoulders. A ring that stops at the chin is a helmet liner, not a coif.
            _shell2[_i] = [_hx2 + _cc * (_hr2 * (1.18 + 0.78 * _cl) + _st),
                           _hy2 + _cs * (_hr2 * (1.16 + 1.30 * _cl) + _st)];
            _open2[_i]  = [_hx2 + _cc * _hr2 * 0.80, _hy2 + _cs * _hr2 * 0.94 + _hr2 * 0.10];
        }
        // The scalloped bottom edge. rai_hem_shape works on a ring built as a descending run, a
        // bottom run and an ascending run; a coif is a closed loop about a centre with no bottom run
        // to find, so rai_hem_span would correctly refuse it and return the ring unshaped. The hem is
        // therefore shaped here, on the lower arc only, by pushing alternate points out along their
        // own radius. Same reading, and it cannot disturb the face opening.
        for (_i = 0; _i <= _cn; _i++) {
            var _sa = (_i / _cn) * RAI_TAU;
            if (sin(_sa) < 0.55) continue;
            var _lobe = ((_i % 2) == 0) ? 1.055 : 0.985;
            _shell2[_i] = [_hx2 + (_shell2[_i][0] - _hx2) * _lobe,
                           _hy2 + (_shell2[_i][1] - _hy2) * _lobe];
        }
        // ⛔⛔ AN ANNULUS, AND THE FIRST FIX STILL FILLED THE MIDDLE. Building the two rings is not
        // the fix; what hides the face is the FILL. `rai_ring_fill(_shell2, ...)` puts a complete
        // disc of iron over the head and the shadow band then only recolours its rim, which is why
        // the coif was still a grey egg on the second bake of the armour sheet. Two strips, no fill.
        var _mid2 = array_create(_cn + 1);
        for (_i = 0; _i <= _cn; _i++) {
            _mid2[_i] = [lerp(_shell2[_i][0], _open2[_i][0], 0.58),
                         lerp(_shell2[_i][1], _open2[_i][1], 0.58)];
        }
        array_push(_out, rai_strip(_shell2, _mid2, _face));
        array_push(_out, rai_strip(_mid2, _open2, _shade));
        // ⛔ NO RING TEXTURE HERE, DELIBERATELY, AND THE REASON IS THE CLIP. rai_clip_part_to_ring
        // clips to a ring's horizontal SPAN at each height - it has no notion of a hole - so mail
        // rings clipped to the coif would be drawn straight across the face opening, which is the
        // frying-pan defect arriving a second time by a different route. The scalloped edge and
        // the annulus are what identify this piece; the hauberk below it carries the rings.
        array_push(_out, rai_poly(_shell2, true, _arm.span * 0.004, _line));
        array_push(_out, rai_poly(_open2, true, _arm.span * 0.004, _line));
    }

    return _out;
}

/// ============================================================================================
/// CLIPPING A SURFACE MARK TO THE PIECE IT IS ON
/// ============================================================================================

/// Clip one texture part to a closed ring, at the ring's own width at that height.
///
/// ⛔ THIS IS THE FUNCTION rai_geom's CLIPPING HEADER IS ABOUT, and the bounding-box version of it
/// is the defect that header names: a shell is at its narrowest at the shoulder and its widest at
/// the hem, so a weave line clipped to the bounding box hangs into open air on both sides of the
/// chest.
///
/// Returns undefined when the mark falls entirely outside the ring, which the caller must handle -
/// pushing an undefined into a part list is a type error two steps downstream (rai_relief's
/// rai_map_roles header records the same shape of silent failure).
///
/// ⚠️ HONEST LIMIT: this clips STROKES and DOTS, which is what rai_surface_parts produces, and it
/// clips them against the ring's HORIZONTAL span at their own y. It is not a general polygon clip
/// and must not be sold as one. A mark spanning a large vertical range on a strongly curved ring is
/// clipped to the span at its endpoints, which is right for a weave line and wrong for a diagonal
/// across a whole piece - so nothing in this package draws one.
///
/// @param {Struct} _part a part from rai_surface_parts
/// @param {Array} _ring the closed outline to clip to
/// @returns {Struct} the clipped part, or undefined
function rai_clip_part_to_ring(_part, _ring) {
    var _bb = rai_pts_bounds(_ring);

    // ⛔ RAI_ARC IS HANDLED HERE WITH RAI_DOT AND MISSING IT WOULD HAVE BEEN THE WHOLE DEFECT.
    // rai_surface_parts builds MAIL out of rai_ring, and rai_ring returns an ARC, not a dot - so a
    // clip that only knew about dots and polylines would have passed every mail ring through
    // untouched, and mail is exactly the family whose texture covers the largest area.
    if (_part.kind == RAI_DOT || _part.kind == RAI_ARC) {
        // Tested at the mark's CENTRE, and the radius is deliberately not subtracted: these marks
        // are one or two pixels across at shipped sizes, so a mark whose centre is inside the piece
        // is inside the piece. Insetting by the radius instead leaves a visible bare margin all
        // round every textured plate.
        if (_part.cy < _bb[1] || _part.cy > _bb[3]) return undefined;
        var _hw = rai_ring_halfwidth_at(_ring, _part.cy);
        if (_hw <= 0) return undefined;
        if (abs(_part.cx) > _hw) return undefined;
        return _part;
    }

    if (_part.kind == RAI_POLY) {
        var _pts = _part.pts;
        var _n = array_length(_pts);
        var _kept = [];
        var _i;
        for (_i = 0; _i < _n; _i++) {
            var _p = _pts[_i];
            if (_p[1] < _bb[1] || _p[1] > _bb[3]) continue;
            var _w = rai_ring_halfwidth_at(_ring, _p[1]);
            if (_w <= 0) continue;
            array_push(_kept, [clamp(_p[0], -_w, _w), _p[1]]);
        }
        if (array_length(_kept) < 2) return undefined;
        return rai_poly(_kept, _part.closed, _part.w, _part.role);
    }

    // Fills (the `sheen` band) are left alone: they are authored to the band the caller gave and
    // clipping their corners would turn a specular streak into a wedge.
    return _part;
}

/// The half-width of a closed ring at a given height.
///
/// Walks the edges and takes the widest crossing, which is correct for the convex-ish rings this
/// product builds and is honest about what it does not do: on a ring with a genuine horizontal
/// concavity it returns the outer span, not the two separate runs. Nothing here builds one.
///
/// @param {Array} _ring closed outline
/// @param {Real} _y height
/// @returns {Real} half-width, or 0 if the ring does not reach that height
function rai_ring_halfwidth_at(_ring, _y) {
    var _n = array_length(_ring);
    var _lo = 0;
    var _hi = 0;
    var _found = false;
    var _i;
    for (_i = 0; _i < _n; _i++) {
        var _a = _ring[_i];
        var _b = _ring[(_i + 1) % _n];
        var _dy = _b[1] - _a[1];
        // A horizontal edge cannot cross a horizontal line at a point, so it is skipped rather
        // than divided by zero. GML's default epsilon on comparisons makes an explicit magnitude
        // test the honest way to ask this (wing CLAUDE.md).
        if (abs(_dy) < 0.0000001) continue;
        var _t = (_y - _a[1]) / _dy;
        if (_t < 0 || _t > 1) continue;
        var _x = _a[0] + (_b[0] - _a[0]) * _t;
        if (!_found) { _lo = _x; _hi = _x; _found = true; }
        else { _lo = min(_lo, _x); _hi = max(_hi, _x); }
    }
    if (!_found) return 0;
    return max(abs(_lo), abs(_hi));
}
