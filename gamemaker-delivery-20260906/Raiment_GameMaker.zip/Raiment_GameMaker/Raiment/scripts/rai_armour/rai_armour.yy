{
  "$GMScript": "v1",
  "%Name": "rai_armour",
  "name": "rai_armour",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}