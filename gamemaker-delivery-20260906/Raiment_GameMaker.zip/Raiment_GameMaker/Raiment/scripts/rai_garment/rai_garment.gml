/// RAIMENT - rai_garment. The cloth families.
///
/// Nine families, each a CUT plus a DRAPE BEHAVIOUR, drawn by rai_drape against whatever body it
/// is put on. A family is not a picture; it is a pattern in the tailoring sense - the same tunic
/// on a broad build and a slight build is the same numbers producing two different outlines.
///
/// ⛔ NOTHING HERE DECIDES ITS OWN DRAW ORDER. rai_wardrobe resolves the worn set into a single
/// ordered list. ARCHITECTURE.md SS6.2: a garment module that picks its own z is how two products
/// get a z-fight nobody can debug remotely.
///
/// ⚠️ PURE except for building part lists. No draw calls.

/// The cloth family ids, in a stable order.
///
/// ⛔ THE ORDER IS PART OF THE PRODUCT. rai_selftest counts the corpus from these lists and the
/// listing quotes THAT number, so adding a family here changes a published figure. Never reorder to
/// make a sheet look better - the sheet is generated from this.
function rai_garment_families() {
    return ["tunic", "robe", "coat", "trousers", "skirt", "cloak", "hood", "apron", "sash"];
}

/// Map a named body anchor to a height in unit space.
///
/// Garments are authored against ANATOMY, not against numbers, so a cut stays correct when the
/// build changes the proportions underneath it.
///
/// @param {Struct} _arm from rai_armature
/// @param {String} _a anchor name
/// @returns {Real} height in unit space
function rai_garment_y(_arm, _a) {
    var _sh = _arm.y_shoulder;
    var _wa = _arm.y_waist;
    var _hp = _arm.y_hip;
    var _so = _arm.y_sole;
    switch (_a) {
        case "neck":     return _arm.neck[1];
        case "shoulder": return _sh;
        case "chest":    return lerp(_sh, _wa, 0.42);
        case "waist":    return _wa;
        case "hip":      return _hp;
        // The crotch. Between `hip` and `thigh`, and the shortest hem a piece can have while still
        // closing the groin - which is what a fauld is for. See rai_armour_spec's plate entry.
        case "seat":     return _arm.y_seat;
        case "thigh":    return lerp(_hp, _so, 0.26);
        case "knee":     return lerp(_hp, _so, 0.50);
        case "calf":     return lerp(_hp, _so, 0.72);
        case "ankle":    return lerp(_hp, _so, 0.94);
        case "sole":     return _so;
        default:         return _wa;
    }
}

/// The cut for a family: where it sits, how it hangs, how far the sleeve runs.
///
/// `slot` is what the garment occupies, and rai_wardrobe uses it to decide what may be worn at the
/// same time. `layer` is the band it draws in, NOT a final z - see the header.
///
/// @param {String} _id one of rai_garment_families()
/// @returns {Struct} the cut
function rai_garment_cut(_id) {
    switch (_id) {
        case "tunic":
            return { slot: "body", layer: 20, top: "shoulder", bottom: "thigh",
                     drape: "soft", sleeve: 0.55, sag: 0.004, collar: "round", folds: true };
        case "robe":
            return { slot: "body", layer: 20, top: "shoulder", bottom: "ankle",
                     drape: "full", sleeve: 1.0, sag: 0.010, collar: "vee", folds: true };
        case "coat":
            return { slot: "outer", layer: 40, top: "shoulder", bottom: "knee",
                     drape: "heavy", sleeve: 1.0, sag: 0.006, collar: "lapel", folds: true };
        case "trousers":
            return { slot: "legs", layer: 10, top: "hip", bottom: "ankle",
                     drape: "fitted", sleeve: 0, sag: 0, collar: "none", folds: false };
        case "skirt":
            return { slot: "legs", layer: 15, top: "waist", bottom: "calf",
                     drape: "full", sleeve: 0, sag: 0.012, collar: "none", folds: true };
        case "cloak":
            // `drape: "cloak"` and not `"full"` - see rai_drape_of, where the measurement is. A
            // back-slot garment is only visible where it is wider than what is in front of it.
            return { slot: "back", layer: 5, top: "shoulder", bottom: "calf",
                     drape: "cloak", sleeve: 0, sag: 0.016, collar: "none", folds: true };
        case "hood":
            return { slot: "head", layer: 60, top: "neck", bottom: "chest",
                     drape: "soft", sleeve: 0, sag: 0, collar: "none", folds: false };
        case "apron":
            return { slot: "front", layer: 45, top: "chest", bottom: "knee",
                     drape: "soft", sleeve: 0, sag: 0.004, collar: "none", folds: true };
        case "sash":
            return { slot: "waist", layer: 50, top: "waist", bottom: "waist",
                     drape: "soft", sleeve: 0, sag: 0, collar: "none", folds: false };
        default:
            return { slot: "body", layer: 20, top: "shoulder", bottom: "waist",
                     drape: "soft", sleeve: 0.5, sag: 0, collar: "round", folds: true };
    }
}

/// ============================================================================================
/// THE YOKE - the shoulder, which is the one part of a garment nothing else was drawing
///
/// ⛔⛔ WITHOUT IT EVERY GARMENT IN THIS PACKAGE HAD A FLAT TOP EDGE AT SHOULDER HEIGHT, AND SO
/// DID EVERY SLEEVE, AND THE TWO TOGETHER READ AS A SANDWICH BOARD WITH A NECK COMING OUT OF IT.
/// rai_drape_ring samples from y0 downward and closes across the top with a straight line, because
/// rai_body_halfwidth returns 0 above the shoulder - so the widest, highest, most-looked-at edge
/// of every figure was a horizontal rule. MEASURED 2026-09-02 on the drape and pose sheets, after
/// a first round of fixes that improved everything else and left this untouched.
///
/// ⭐ CLOTH ON A SHOULDER IS A ROOF. It is highest beside the neck, where the trapezius rises, and
/// it falls away over the deltoid on both sides - and it covers the top of the sleeve, which is
/// what turns two separate boards into one garment with an armhole. Drawn as its own part rather
/// than folded into the panel ring on purpose: rai_hem_shape finds a ring's hem by taking the
/// MIDPOINT OF THE ARRAY, so adding points to the panel would silently scallop a mail hauberk
/// somewhere up its own side.
/// ============================================================================================

/// The shoulder yoke of a garment, covering the panel's top edge and both sleeve heads.
///
/// @param {Struct} _arm from rai_armature
/// @param {Real} _y0 the garment's top, in unit space
/// @param {Struct} _d drape parameters
/// @param {Real} _sleeve the family's sleeve reach; 0 means the yoke stops at the body
/// @param {Struct} _roles {face, shade, line}
/// @param {Struct} _sleeve_d OPTIONAL drape the SLEEVE was built with, when it differs from the
///        panel's. Defaults to `_d`, which is the cloth case.
/// @returns {Array} part list
function rai_yoke_parts(_arm, _y0, _d, _sleeve, _roles, _sleeve_d) {
    // ⚠️ TWO DRAPES, BECAUSE A YOKE SPANS TWO GARMENT PARTS THAT NEED NOT SHARE ONE. It is sized off
    // the PANEL's width at the shoulder and off the SLEEVE's head, and in rai_garment those come
    // from the same struct so one parameter was enough. rai_armour builds its sleeve from a thinner
    // drape than its panel (see its sleeve block), so a single `_d` there would size the yoke's
    // outer reach off cloth the sleeve is not made of - too wide and it is a shoulder pad, too
    // narrow and it exposes the square sleeve head it exists to cover. Defaulted, so every existing
    // caller is unchanged.
    var _sd = is_undefined(_sleeve_d) ? _d : _sleeve_d;
    var _body_w = rai_drape_halfwidth(_arm, _y0, _y0, _y0 + _arm.span * 0.20, _d);
    var _w = _body_w;
    if (_sleeve > 0) {
        // Reach out far enough to cap the sleeve head, which sits at the arm's own origin.
        _w = max(_w, abs(_arm.shoulder[1][0]) + rai_sleeve_head_w(_arm, _sd) * 0.94);
    }
    var _rise = _arm.span * 0.028;
    var _drop = _arm.span * 0.050;
    var _nw = _arm.w_neck * 1.55;

    // ⚠️ THE OUTER END IS A CURVE, NOT A CORNER, AND THE FIRST VERSION HAD A CORNER. Three points
    // straight from the shoulder tip to the top edge gave a sharp angle at the widest, highest
    // part of the figure, which is the shape of a coat hanger - and on the pose sheet the yoke
    // read as a plank laid across the shoulders. A shoulder is round; the four points below are
    // one quarter-turn.
    // ⛔⛔ ROUNDING THE OUTER TIP DID NOT STOP IT READING AS A PLANK, BECAUSE THE PLANK WAS THE TOP
    // EDGE, NOT THE CORNER. The previous ring put the neck at -_rise and the point at 0.44 of the
    // width at -_rise*0.94, so the whole span from the throat out to three quarters of the shoulder
    // sat inside 0.06 of _rise - 0.0017 of stature, which at figure size is FLAT. A corner was
    // removed and a horizontal bar was left, and on the pose sheet that is exactly what it looked
    // like: a coat hanger with a head on top. MEASURED 2026-09-02 by looking at sheet 7.
    //
    // ⭐ THE SHAPE OF A SHOULDER IS A SLOPE, NOT A PLATFORM. The trapezius leaves the neck HIGH and
    // falls continuously to the acromion, which is the lowest point of the top edge before the arm
    // begins - so the tip now lands just under _y0 instead of _rise*0.46 above it, and every point
    // between descends monotonically. The outer quarter-turn is kept; it is now the end of a slope
    // rather than the end of a bar.
    var _ring = [
        [ _w,        _y0 + _drop],
        [ _w,        _y0 + _drop * 0.50],
        [ _w * 0.985, _y0 + _drop * 0.17],
        [ _w * 0.935, _y0 - _rise * 0.08],
        [ _w * 0.83, _y0 - _rise * 0.32],
        [ _w * 0.66, _y0 - _rise * 0.56],
        [ _w * 0.45, _y0 - _rise * 0.78],
        [ _nw * 1.30, _y0 - _rise * 0.98],
        [ 0,          _y0 - _rise * 1.06],
        [-_nw * 1.30, _y0 - _rise * 0.98],
        [-_w * 0.45, _y0 - _rise * 0.78],
        [-_w * 0.66, _y0 - _rise * 0.56],
        [-_w * 0.83, _y0 - _rise * 0.32],
        [-_w * 0.935, _y0 - _rise * 0.08],
        [-_w * 0.985, _y0 + _drop * 0.17],
        [-_w,        _y0 + _drop * 0.50],
        [-_w,        _y0 + _drop]
    ];
    var _out = [rai_ring_fill(_ring, _roles.face, 0, _y0 + _drop * 0.35)];

    // The lamp is up and to the left, so the roof catches along its whole top edge and the
    // right-hand slope falls away. Two strips off the same rail, which is why they cannot drift.
    // ⚠️ THE TWO BANDS SPLIT AT THE NECK, INDEX 7, WHICH IS THE RING'S HIGHEST POINT. Written as a
    // fixed pair of index ranges this breaks silently the moment the ring gains a point, so the
    // split is derived from the array's own length rather than typed.
    var _n = array_length(_ring);
    var _mid = _n div 2;
    var _lit0 = [];
    var _lit1 = [];
    var _dk0 = [];
    var _dk1 = [];
    var _i;
    for (_i = 1; _i <= _mid; _i++) {
        array_push(_lit0, _ring[_i]);
        array_push(_lit1, [_ring[_i][0], _ring[_i][1] + _arm.span * 0.012]);
    }
    for (_i = _mid; _i <= _n - 2; _i++) {
        array_push(_dk0, _ring[_i]);
        array_push(_dk1, [_ring[_i][0], _ring[_i][1] + _arm.span * 0.019]);
    }
    array_push(_out, rai_strip(_dk0, _dk1, _roles.shade));
    array_push(_out, rai_strip(_lit0, _lit1, "m3"));
    // Only the TOP edge is outlined. The bottom is where the yoke meets the panel it is part of,
    // and a line there would draw a seam across the chest that no garment has.
    var _top = [];
    for (_i = 1; _i <= _n - 2; _i++) array_push(_top, _ring[_i]);
    array_push(_out, rai_poly(_top, false, _arm.span * 0.005, _roles.line));
    return _out;
}

/// ============================================================================================
/// COLLARS - a small amount of geometry that does a disproportionate amount of the reading
/// ============================================================================================

/// The neckline, cut out of the top of a body garment.
///
/// ⭐ WORTH THE CODE. At figure size the collar is one of the few places the eye can tell a robe
/// from a coat, because the hem is often occluded and the sleeves are behind the arms. A garment
/// corpus with one neckline looks like one garment recoloured, which is precisely the "generated"
/// tell SS1.1 warns about.
///
/// @param {Struct} _arm from rai_armature
/// @param {String} _kind collar kind
/// @param {String} _role colour role
/// @returns {Array} part list
/// ⛔⛔ A NECKLINE IS A HOLE, NOT A LINE, AND DRAWING IT AS A LINE IS WHY EVERY ROBE IN THIS
/// PRODUCT WORE A CHEVRON. The vee was one three-point polyline in the outline colour, laid over
/// an unbroken field of cloth with nothing behind it - so what a buyer saw was a dark arrowhead
/// painted on a chest, and on the drape sheet five of them in a row read as a logo. MEASURED
/// 2026-09-02 by looking at it.
///
/// ⭐ The fix is that the opening is FILLED, in the garment's own shade stop, so the cloth reads as
/// cut away and the line becomes the EDGE of a shape rather than a mark on a surface. That also
/// gives the lapel something to be a lapel ON.
///
/// @param {Struct} _arm from rai_armature
/// @param {String} _kind collar kind
/// @param {String} _role colour role for the edge
/// @param {String} _shade colour role for the opening
/// @returns {Array} part list
function rai_collar_parts(_arm, _kind, _role, _shade) {
    if (_kind == "none") return [];
    var _y = _arm.y_shoulder;
    var _w = _arm.w_shoulder;
    var _nw = _arm.w_neck * 1.5;
    var _lw = _arm.span * 0.007;
    // The yoke rises above the shoulder line, so an opening that starts AT it would leave a band of
    // cloth across the throat. rai_yoke_parts' `_rise` is the number this has to clear.
    var _top = _y - _arm.span * 0.026;
    var _sh = is_undefined(_shade) ? _role : _shade;

    switch (_kind) {
        case "vee": {
            var _v = [[-_nw, _top], [_nw, _top], [0, _y + _arm.span * 0.085]];
            return [rai_ring_fill(_v, _sh, 0, _y + _arm.span * 0.010),
                    rai_poly(_v, true, _lw, _role)];
        }
        case "lapel": {
            var _d = _arm.span * 0.070;
            // A notched revers each side of a filled opening, which is what a coat has and a robe
            // does not - the whole reason this family reads differently at figure size.
            var _o = [[-_nw * 0.92, _top], [_nw * 0.92, _top],
                      [_nw * 0.55, _y + _d * 1.15], [-_nw * 0.55, _y + _d * 1.15]];
            var _lp = [[-_nw, _top], [-_nw * 0.38, _y + _d], [-_w * 0.46, _y + _d * 0.52]];
            var _rp = [[ _nw, _top], [ _nw * 0.38, _y + _d], [ _w * 0.46, _y + _d * 0.52]];
            return [
                rai_ring_fill(_o, _sh, 0, _y + _d * 0.4),
                rai_poly(_o, true, _lw, _role),
                rai_ring_fill(_lp, _sh, undefined, undefined),
                rai_poly(_lp, true, _lw, _role),
                rai_ring_fill(_rp, _sh, undefined, undefined),
                rai_poly(_rp, true, _lw, _role),
                rai_poly([[0, _y + _d * 1.15], [0, _y + _d * 2.4]], false, _lw * 0.8, _role)
            ];
        }
        default: {
            // Round. A shallow scoop, filled the same way; the arc is the elliptical one because a
            // circular neckline is as deep as it is wide and cuts to the sternum (rai_geom).
            // ⚠️ The half-ellipse closes on its own CHORD. Appending the two end points again to
            // "close it" puts a duplicate vertex at each end, which rai_shape's dedupe header
            // records as capping every bevel and losing a turning measurement.
            var _pts = rai_ellipse_arc_pts(0, _top + _arm.span * 0.004, _nw * 1.10,
                                           _arm.span * 0.034, 0, pi, 10);
            return [rai_ring_fill(_pts, _sh, 0, _top + _arm.span * 0.012),
                    rai_poly(_pts, true, _lw, _role)];
        }
    }
}

/// ============================================================================================
/// THE FAMILY BUILDER
/// ============================================================================================

/// Build one garment as a part list.
///
/// ⛔ `_mat` IS OPTIONAL AND ITS ABSENCE COSTS THE SURFACE CHARACTER. rai_surface_parts has existed
/// in this package since the first build and was called from rai_armour and NOWHERE ELSE, so every
/// cloth garment shipped as one flat fill while every steel one carried rivets. That is the exact
/// asymmetry the store sheets showed: an armour sheet with visible construction beside a drape
/// sheet of plain red shapes. Linen and silk are eleven degrees apart in hue and nothing alike, and
/// what separates them is the weave - rai_material's own header says so and nothing was drawing it.
///
/// @param {Struct} _arm from rai_armature
/// @param {String} _id one of rai_garment_families()
/// @param {Struct} _roles {face, shade, line} colour roles for this garment's material
/// @param {String} _mat material id for the surface character, or undefined for no texture
/// @returns {Array} part list
function rai_garment_parts(_arm, _id, _roles, _mat) {
    var _cut = rai_garment_cut(_id);
    var _d = rai_drape_of(_cut.drape);
    var _face = _roles.face;
    var _line = _roles.line;
    var _shade = _roles.shade;
    var _out = [];

    // The sash is a band, not a panel, so it is its own small case rather than a panel of zero
    // height pretending to be one.
    // ⛔⛔ THE SASH WAS A FLAT RECTANGLE WITH A STUB ON IT AND IT READ AS A BANDAGE. On the
    // 2026-09-02 crowd bake, four of the twenty-four villagers appeared to have a dressing strapped
    // across the chest: a hard-ended horizontal bar of one flat tone, at full body width, with a
    // short blunt tab hanging off it. Every part of that is correct as geometry and wrong as cloth.
    //
    // ⭐ THREE THINGS MAKE A BAND OF CLOTH READ AS A SASH. It WRAPS, so it is shaded across its
    // height like every other tube in this package rather than being one flat tone. It has a KNOT,
    // which is the only thing that says the band is tied rather than painted on. And its tail
    // TAPERS and hangs long enough to fall, because a short blunt tab is a strap.
    if (_id == "sash") {
        var _sy = rai_garment_y(_arm, "waist");
        var _h = _arm.span * 0.036;
        var _sw = rai_drape_halfwidth(_arm, _sy, _sy, _sy + _h, _d);
        var _band = rai_limb_ring([-_sw, _sy], [_sw, _sy], _h * 0.5, _h * 0.5);
        array_push(_out, rai_ring_fill(_band, _face, 0, _sy));
        // Shaded across its height, not along its length: a sash is a small tube lying on a big one.
        rai_append(_out, rai_sleeve_form(_arm, _band, _shade));
        array_push(_out, rai_poly(_band, true, _arm.span * 0.0035, _line));
        // The knot, off centre where a person ties one, and the tail falling from it.
        var _kx = _sw * 0.45;
        rai_append(_out, rai_mass(rai_ellipse_pts(_kx, _sy, _h * 0.62, _h * 0.54, 10),
                                  0.55, 2, _face));
        array_push(_out, rai_poly(rai_ellipse_pts(_kx, _sy, _h * 0.62, _h * 0.54, 10), true,
                                  _arm.span * 0.0035, _line));
        // ⚠️ THE TAIL KEEPS ITS WIDTH AND IS CUT AT AN ANGLE. Tapered to a point it read as a red
        // spike hanging off the belt - a dagger, not cloth - on the 2026-09-02 equip bake. A length
        // of cloth hanging from a knot stays about as wide as it started and ends in a cut edge.
        var _tail = [[_kx - _h * 0.30, _sy + _h * 0.22],
                     [_kx + _h * 0.34, _sy + _h * 0.26],
                     [_kx + _h * 0.40, _sy + _h * 2.90],
                     [_kx + _h * 0.12, _sy + _h * 3.20],
                     [_kx - _h * 0.24, _sy + _h * 2.70]];
        array_push(_out, rai_ring_fill(_tail, _face, _kx, _sy + _h * 1.4));
        rai_append(_out, rai_form_dome(_tail, 0.50, 2));
        array_push(_out, rai_poly(_tail, true, _arm.span * 0.0035, _line));
        return _out;
    }

    // The hood is a shell over the head, sampled off the skull rather than off the torso.
    //
    // ⛔⛔ THE FIRST VERSION FILLED THE OPENING SOLID AND THAT IS WHY EVERY PRIEST ON THE CROWD
    // SHEET WAS A COIN. It drew an outer ellipse in the face colour and then a second, smaller
    // FILLED ellipse in the shade colour on top - so the head underneath was covered completely
    // and what a buyer saw was two concentric discs. On saffron it read as a halo; on charcoal as
    // a hole in the figure. MEASURED 2026-09-02 by looking at the crowd sheet: three of twenty-four.
    //
    // ⭐ A HOOD IS AN ANNULUS, NOT A DISC. What is dark inside a cowl is the RIM - the shadowed
    // inside of the cloth between the hood's edge and the face - and the face itself is lit. Two
    // rings sampled at the same angles and joined by a strip give exactly that, and the face,
    // brows, eyes and any hair below the hairline stay visible through it.
    if (_id == "hood") {
        var _hx = _arm.head[0];
        var _hy = _arm.head[1] - _arm.head_r * 0.06;
        var _hr = _arm.head_r;
        // ⚠️ _n + 1 SAMPLES, NOT _n, AND THE LAST ONE REPEATS THE FIRST. rai_strip walks two rails
        // pairwise and never closes back from the last pair to the first, so a strip built from a
        // ring's _n distinct points leaves a wedge of the annulus missing - one triangle of bare
        // head showing through the side of the hood. It is the same closure rule rai_ring_fill's
        // header states for fans, arriving on the other primitive.
        var _n = 24;
        var _shell = array_create(_n + 1);
        var _open  = array_create(_n + 1);
        var _i2;
        for (_i2 = 0; _i2 <= _n; _i2++) {
            var _a = (_i2 / _n) * RAI_TAU;
            var _c = cos(_a);
            var _s2 = sin(_a);
            // The cowl falls onto the shoulders, so it grows in the lower half rather than being
            // a circle sitting on the head like a bowl.
            var _low = power(max(0, _s2), 1.60);
            _shell[_i2] = [_hx + _c * _hr * (1.26 + 0.62 * _low + _d.thickness),
                           _hy + _s2 * _hr * (1.22 + 0.86 * _low + _d.thickness)];
            _open[_i2]  = [_hx + _c * _hr * 0.80, _hy + _s2 * _hr * 0.94 + _hr * 0.10];
        }
        // ⛔⛔ THE HOOD IS FILLED AS AN ANNULUS AND NOT AS A DISC, AND GETTING THAT WRONG COST A
        // WHOLE BAKE. The first fix built the two rings correctly and then still filled the outer
        // one solid before laying the shadow band over its rim - so the head was underneath a
        // complete disc of cloth and the face was exactly as hidden as before. On the crowd sheet
        // both priests were still gold eggs. A fan fill covers everything inside its outline; the
        // only way to leave a hole is to never fill the middle. Two strips, no fill.
        var _mid = array_create(_n + 1);
        for (_i2 = 0; _i2 <= _n; _i2++) {
            _mid[_i2] = [lerp(_shell[_i2][0], _open[_i2][0], 0.56),
                         lerp(_shell[_i2][1], _open[_i2][1], 0.56)];
        }
        array_push(_out, rai_strip(_shell, _mid, _face));
        // The shadowed inside of the cloth, as the inner half of the same band.
        array_push(_out, rai_strip(_mid, _open, _shade));
        // A lit crown: the lamp is up and to the left (rai_relief), so the cowl catches there.
        var _lit0 = [];
        var _lit1 = [];
        for (_i2 = 0; _i2 <= _n; _i2++) {
            var _a2 = (_i2 / _n) * RAI_TAU;
            if (_a2 < RAI_TAU * 0.52 || _a2 > RAI_TAU * 0.80) continue;
            array_push(_lit0, _shell[_i2]);
            array_push(_lit1, [lerp(_shell[_i2][0], _mid[_i2][0], 0.42),
                               lerp(_shell[_i2][1], _mid[_i2][1], 0.42)]);
        }
        if (array_length(_lit0) >= 2) array_push(_out, rai_strip(_lit0, _lit1, "m3"));
        array_push(_out, rai_poly(_shell, true, _arm.span * 0.005, _line));
        array_push(_out, rai_poly(_open, true, _arm.span * 0.004, _line));
        return _out;
    }

    var _y0 = rai_garment_y(_arm, _cut.top);
    var _y1 = rai_garment_y(_arm, _cut.bottom);

    // Trousers are two tubes, not a panel - a skirt is a panel. This is the one structural fork in
    // the cloth families and it is why `legs` carries two very different garments.
    if (_id == "trousers") {
        var _s;
        for (_s = 0; _s < 2; _s++) {
            var _w0 = _arm.w_limb * 1.30 + _d.thickness;
            var _w1 = _arm.w_limb * 1.05 + _d.thickness;
            var _thigh = rai_limb_ring(_arm.hip[_s], _arm.knee[_s], _w0, _w1);
            var _shin = rai_limb_ring(_arm.knee[_s], _arm.ankle[_s], _w1, _w1 * 0.94);
            array_push(_out, rai_fill(_thigh, _face));
            array_push(_out, rai_fill(_shin, _face));
            // A leg is a tube and takes the same lamp-aware shadow a sleeve does - the helper is
            // written against a limb ring, not against a sleeve, which is why it can serve both.
            rai_append(_out, rai_sleeve_form(_arm, _thigh, _shade));
            rai_append(_out, rai_sleeve_form(_arm, _shin, _shade));
            array_push(_out, rai_poly(_shin, true, _arm.span * 0.004, _line));
        }
        // The seat, joining the two legs so the figure is not wearing two separate tubes.
        var _hw = _arm.w_hip + _d.thickness;
        array_push(_out, rai_fill([[-_hw, _arm.y_hip - _arm.span * 0.030], [_hw, _arm.y_hip - _arm.span * 0.030],
                                   [_hw, _arm.y_hip + _arm.span * 0.045], [-_hw, _arm.y_hip + _arm.span * 0.045]], _face));
        return _out;
    }

    // Everything else is a draped panel.
    var _panel = rai_drape_ring(_arm, _y0, _y1, _d, _cut.sag);
    var _i;

    // ⛔⛔ A `front` SLOT GARMENT IS A PANEL ACROSS THE FRONT, AND DRAPING IT AT FULL BODY WIDTH MADE
    // THE APRON A STRAPLESS DRESS. rai_drape_ring wraps the WHOLE body - which is right for a tunic,
    // a robe, a coat and a skirt, and wrong for the one family in the wardrobe that only ever
    // covers the front. Drawn full width at layer 45 it read on the cloth sheet as a tube of cloth
    // from the armpits to the knee with two bare arms beside it: not an apron, a dress, and a buyer
    // reading the label under it would be looking at the wrong garment. Found 2026-09-02 by looking
    // at sheet 3.
    //
    // ⭐ AN APRON IS NARROWER THAN THE BODY AND THAT IS THE WHOLE OF WHAT MAKES IT ONE. Pulling the
    // panel in to 0.66 of its drape leaves the torso and the hips showing on both sides, so the
    // piece reads as something tied ON over clothes rather than as the clothes - and the waist tie
    // below has somewhere to cross. The narrowing is applied to the sampled ring rather than to the
    // drape parameters so the hem sag, the fold rails and the outline all continue to come off one
    // shape.
    if (_cut.slot == "front") {
        var _narrow = [];
        for (_i = 0; _i < array_length(_panel); _i++) {
            array_push(_narrow, [_panel[_i][0] * 0.66, _panel[_i][1]]);
        }
        _panel = _narrow;
        // The tie. An apron that is not tied on is a bib, and the string is what says which it is.
        // ⚠️ PUSHED BEFORE THE PANEL ON PURPOSE, SO IT ENDS UP UNDERNEATH IT. The tie goes round the
        // BACK, so the only part of it that can be seen from the front is the two ends emerging
        // from behind the apron at the waist - which is what drawing it first produces. A tie laid
        // ON TOP would be a belt worn over the apron, which is a different garment.
        // ⛔ AT 0.34 OF THE PANEL THE TIE LANDED ON THE CHEST, AND AT 0.011 OF STATURE IT WAS A BAR.
        // An apron's top is up near the armpits, so a third of the way down its own panel is the
        // sternum - and a pale horizontal stroke that wide across a figure's chest reads as a
        // bandage or a bandolier, not as a string. On the 2026-09-02 crowd bake four of the
        // twenty-four villagers were wearing one. MEASURED by looking at the sheet.
        //
        // ⭐ A TIE GOES ROUND THE WAIST, so it is anchored to the ANATOMY rather than to a fraction
        // of whatever panel happens to be in front of it - the same rule the sash already follows.
        // Clamped inside the panel so a short apron cannot put its string outside its own cloth.
        var _ty = clamp(rai_garment_y(_arm, "waist"),
                        _y0 + _arm.span * 0.03, _y1 - _arm.span * 0.03);
        var _tw = rai_body_halfwidth(_arm, _ty) + _d.thickness * 1.4;
        array_push(_out, rai_poly([[-_tw, _ty], [_tw, _ty - _arm.span * 0.004]],
                                  false, _arm.span * 0.0075, _shade));
    }

    // -- SLEEVES GO DOWN FIRST, AND THAT ONE LINE IS THE BIGGEST VISUAL FIX IN THIS FILE ---------
    //
    // ⛔⛔ THEY USED TO BE APPENDED LAST, WITH THEIR WHOLE OUTLINE STROKED, SO EVERY SLEEVE DREW A
    // CLOSED RECTANGLE ON TOP OF THE CHEST. A sleeve ring is centred on the shoulder JOINT, and
    // the joint sits exactly on the torso's own edge (rai_armature: shoulder x IS w_shoulder), so
    // half of every sleeve lies inside the body - and outlining it put a hard vertical line down
    // the front of the garment from the collarbone to the hem. On the pose sheet that read as two
    // cardboard slabs strapped to a robe, and on the drape sheet it was the first thing the eye
    // went to on all five figures. MEASURED 2026-09-02 by looking at both.
    //
    // ⭐ THE FIX IS DRAW ORDER, NOT GEOMETRY. Emitted BEFORE the panel, the sleeve's inner half is
    // painted over by the body panel and the only seam left is the panel's own edge - which is
    // where an armhole actually is. Nothing about the sleeve's shape changed.
    //
    // ⚠️ AND IT IS CORRECT ON ALL FIVE POSES, WHICH IS NOT OBVIOUS AND WAS CHECKED. The one case
    // that would break it is a forearm crossing IN FRONT of the chest; `guard` bends the elbow to
    // 1.05 rad but its shoulder is already out at 0.52, so the forearm runs outward from a point
    // beyond the torso edge and never crosses it. `reach` is further out still.
    if (_cut.sleeve > 0) {
        var _k;
        var _hw = rai_sleeve_head_w(_arm, _d);
        for (_k = 0; _k < 2; _k++) {
            var _sl = rai_sleeve_ring(_arm, _k, _cut.sleeve, _d);
            // The armhole. A limb ring has SQUARE ends, so without this the sleeve stops in a
            // horizontal cut at shoulder height - see rai_sleeve_head_w. Tangent to the shoulder
            // line rather than centred on it, for the same reason rai_armature offsets the bare
            // figure's own shoulder cap: nothing may protrude into the band above y_shoulder,
            // because no garment can reach up there to cover it.
            // ⛔⛔ THE CAP USED TO STAND PROUD OF THE YOKE AND IT READ AS AN EPAULETTE. At centre
            // +0.42 of its own radius, the cap's crown sits 0.58 radii ABOVE the shoulder line while
            // the yoke's top edge out at that x has already fallen to about a third of its rise - so
            // on every robed and coated figure two round lumps rose out of the shoulder slab, and on
            // the 2026-09-02 drape bake they read as 1980s shoulder pads. MEASURED by cropping the
            // sheet at 4x and looking at it.
            //
            // ⭐ A DELTOID IS THE END OF THE SHOULDER SLOPE, NOT A BALL ON TOP OF IT. Dropped to
            // +0.86 of its radius the cap's crown lands just BELOW the shoulder line, so the yoke
            // covers it and what is left is the rounding where the shoulder turns into the arm. The
            // armhole is still filled - that is what the cap is for - because it is the BOTTOM of
            // this circle that does that work, and the bottom moved down, not up.
            // ⭐ HOISTED 2026-09-02. This call site is where the 0.42 -> 0.86 fix was measured, and
            // it stayed a LOCAL fix: rai_armour kept its own copy at 0.42 and shipped the same bug
            // on the armour sheet. The number now lives once, in rai_sleeve_cap.
            array_push(_out, rai_sleeve_cap(_arm, _k, _hw, _face));
            array_push(_out, rai_ring_fill(_sl, _face, _arm.shoulder[_k][0], _arm.shoulder[_k][1]));
            rai_append(_out, rai_sleeve_form(_arm, _sl, _shade));
            array_push(_out, rai_poly(_sl, true, _arm.span * 0.004, _line));
            // A cuff, on a sleeve that reaches the wrist. It is the only thing that stops a long
            // sleeve reading as a tube that has been cut off, and it is where the hand comes out.
            if (_cut.sleeve > 0.85) {
                var _cw = _arm.w_limb * 0.90 + _d.thickness * (1 - _d.cling * 0.75)
                        + _d.fullness * _arm.span * 0.22;
                var _wr = _arm.wrist[_k];
                var _el = _arm.elbow[_k];
                var _dx = _wr[0] - _el[0];
                var _dy = _wr[1] - _el[1];
                var _dl = max(0.0001, point_distance(0, 0, _dx, _dy));
                var _bk = [_wr[0] - (_dx / _dl) * _arm.span * 0.026,
                           _wr[1] - (_dy / _dl) * _arm.span * 0.026];
                var _cr = rai_limb_ring(_bk, _wr, _cw * 1.06, _cw * 1.14);
                array_push(_out, rai_ring_fill(_cr, _shade, undefined, undefined));
                array_push(_out, rai_poly(_cr, true, _arm.span * 0.004, _line));
            }
        }
    }

    array_push(_out, rai_ring_fill(_panel, _face, 0, (_y0 + _y1) * 0.5));

    // The volume. Bands at fixed fractions of the panel's OWN half-width, so they follow the
    // silhouette on every build without a second outline to keep in step. See rai_drape_shading.
    var _sd = rai_drape_shading(_arm, _y0, _y1, _d, _roles);
    for (_i = 0; _i < array_length(_sd); _i++) array_push(_out, _sd[_i]);

    // The surface character of the material, clipped to the panel's own width at each height.
    // rai_clip_part_to_ring's header states why a bounding-box clip is wrong here.
    if (!is_undefined(_mat)) {
        var _bb = rai_pts_bounds(_panel);
        // Thinner and further apart than the armour default - see rai_surface_parts' header for
        // what happened when a robe was given a breastplate's texture weight.
        // ⚠️ 0.90 RATHER THAN 1.55 ON THE SPACING, AND IT IS ONLY SAFE BECAUSE THE MARKS ARE BROKEN
        // NOW. The 1.55 was chosen to stop a robe reading as corduroy by pushing the rows further
        // apart, and it did not work - see rai_surface_marks, where the cause turned out to be that
        // every row was one unbroken rule. With dashes, a FINER pitch is what reads as cloth, and a
        // coarse one just makes the dashes look like stitching.
        var _tex = rai_surface_parts(_mat, _bb[0], _bb[1], _bb[2], _bb[3], _arm.span, _shade,
                                     0.58, 0.90);
        for (_i = 0; _i < array_length(_tex); _i++) {
            var _cl = rai_clip_part_to_ring(_tex[_i], _panel);
            if (!is_undefined(_cl)) array_push(_out, _cl);
        }
    }

    if (_cut.folds) {
        var _f = rai_drape_folds(_arm, _y0, _y1, _d, _shade);
        for (_i = 0; _i < array_length(_f); _i++) array_push(_out, _f[_i]);
    }

    // Outline last so folds cannot cross it.
    array_push(_out, rai_poly(_panel, true, _arm.span * 0.005, _line));

    // The shoulder. Goes on AFTER the panel and its outline because it covers both the panel's
    // straight top edge and the two sleeve heads - which is the join it exists to hide. Only a
    // garment that actually sits on the shoulders gets one: a skirt, an apron or a sash starting
    // at the waist would grow a collar out of the middle of the figure.
    if (_cut.top == "shoulder") {
        var _yk = rai_yoke_parts(_arm, _y0, _d, _cut.sleeve, _roles);
        for (_i = 0; _i < array_length(_yk); _i++) array_push(_out, _yk[_i]);
    }

    // -- A CLOAK NEEDS TO SAY IT IS A CLOAK, FROM THE FRONT ---------------------------------------
    //
    // ⛔ WITHOUT THIS IT READS AS AN ARMCHAIR, AND THAT IS NOT A FIGURE OF SPEECH. A cloak sits in
    // the BACK band (rai_wardrobe), so from the front the only thing visible is a wide flared panel
    // sticking out on both sides of the body with the legs standing in front of it - which is the
    // silhouette of somebody sitting in a wing chair. Three of the twenty-four figures on the crowd
    // sheet read that way on 2026-09-02.
    //
    // ⭐ Two pieces fix it and both are things a real cloak has: a standing COLLAR rising behind the
    // neck, which is above the shoulder line where nothing else in the package draws, and a FIBULA
    // pinned at the shoulder rather than at the throat - which is where they were actually worn and
    // is also the only place on this figure where a clasp is not hidden behind the neck column.
    if (_id == "cloak") {
        var _cy = _arm.y_shoulder;
        var _cw = _arm.w_shoulder * 1.06;
        // ⚠️ FLAT AND WIDE, NOT TALL AND DOMED. The first version rose 0.052 of stature on a
        // half-width of one shoulder, which is a semicircle - and a purple semicircle standing
        // behind somebody's head is a cushion. It made the armchair reading WORSE rather than
        // better. A cloak collar is a band: it turns over, it is about half as tall as it is wide
        // at each end, and it is what the fibula pins to.
        var _col2 = rai_ellipse_arc_pts(0, _cy + _arm.span * 0.012, _cw, _arm.span * 0.030,
                                        RAI_TAU * 0.5, RAI_TAU, 14);
        array_push(_col2, [_cw, _cy + _arm.span * 0.020]);
        array_push(_col2, [-_cw, _cy + _arm.span * 0.020]);
        array_push(_out, rai_ring_fill(_col2, _shade, 0, _cy + _arm.span * 0.008));
        // Two turn-over creases, which is what makes a band read as folded cloth rather than as a
        // shape behind the figure.
        var _cq;
        for (_cq = -1; _cq <= 1; _cq += 2) {
            array_push(_out, rai_poly([[_cq * _cw * 0.46, _cy - _arm.span * 0.012],
                                       [_cq * _cw * 0.52, _cy + _arm.span * 0.019]],
                                      false, _arm.span * 0.004, _line));
        }
        array_push(_out, rai_poly(_col2, true, _arm.span * 0.005, _line));
        var _fx = -_arm.w_shoulder * 0.72;
        array_push(_out, rai_dot(_fx, _cy + _arm.span * 0.002, _arm.span * 0.017, "accent"));
        array_push(_out, rai_dot(_fx, _cy + _arm.span * 0.002, _arm.span * 0.008, _line));
    }

    var _col = rai_collar_parts(_arm, _cut.collar, _line, _shade);
    var _j;
    for (_j = 0; _j < array_length(_col); _j++) array_push(_out, _col[_j]);

    return _out;
}
