{
  "$GMScript": "v1",
  "%Name": "rai_garment",
  "name": "rai_garment",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}