/// RAIMENT - rai_material. What a garment is MADE of.
///
/// ⭐ THIS IS THE VOLUME, AND THE VOLUME IS THE MOAT (CLAUDE.md §1.1). Nine cloth families and six
/// armour families is not a corpus. Nine families x thirty materials IS, and it is a corpus no
/// sprite sheet can ship, because a sprite sheet would need every combination drawn.
///
/// ⛔ AND IT MUST NOT BE A PALETTE SWAP. gm-livery shipped exactly this machinery and recorded the
/// expensive half in its own summary: a material is NOT a hue. It is a five-stop Oklch ramp, a
/// ground, an ink asserted readable against it, an accent derived from the ground, AND a SURFACE
/// CHARACTER - the thing that makes brass and bronze different when they are eleven degrees apart
/// in hue. Linen and silk are close in colour and nothing alike; what separates them is weave,
/// sheen and how they fold.
///
/// ⚠️ PURE. Colour maths only, no draw calls. rai_palette does the Oklab -> sRGB work.

/// The surface characters. A material picks one, and it is what the eye actually reads.
///
/// ⚠️ These are CLOTH and METAL behaviours, not decorations: `weave` is a fabric's grain, `ring` is
/// mail, `rivet` is plate fastening, `tooling` is worked leather. A character that does not describe
/// how the material is MADE does not belong here.
function rai_surfaces_all() {
    return ["weave", "twill", "nap", "sheen", "quilt", "ring", "scale", "rivet", "tooling", "worn"];
}

/// The material ids, in a stable order.
///
/// ⛔ THE ORDER IS PART OF THE PRODUCT — rai_selftest counts the corpus from this list and the
/// listing quotes that number. Never reorder to make a sheet look better.
function rai_materials_all() {
    return [
        // cloth
        "linen", "wool", "homespun", "silk", "velvet", "canvas", "felt", "damask", "sackcloth", "cotton",
        // leather and hide
        "buckskin", "oxhide", "suede", "boiled_leather", "fur", "shearling",
        // metal
        "iron", "steel", "blued_steel", "bronze", "brass", "silver", "gold", "blackened_iron",
        // dyed and rich
        "madder", "woad", "saffron", "tyrian", "verdigris", "charcoal"
    ];
}

/// The definition of one material.
///
/// `L` is base lightness, `C` chroma, `h` hue in degrees; `surface` is one of rai_surfaces_all();
/// `drape` names the cloth behaviour rai_drape should use when this material makes a garment - a
/// velvet robe hangs differently from a canvas one, and that is a property of the MATERIAL, not of
/// the family.
///
/// @param {String} _id one of rai_materials_all()
/// @returns {Struct} the material definition
function rai_material_def(_id) {
    switch (_id) {
        // ---- cloth -------------------------------------------------------------------------
        case "linen":          return { L: 0.780, C: 0.036, h:  78, surface: "weave",   drape: "soft",   metal: false };
        case "wool":           return { L: 0.560, C: 0.048, h:  46, surface: "nap",     drape: "heavy",  metal: false };
        case "homespun":       return { L: 0.620, C: 0.040, h:  62, surface: "weave",   drape: "soft",   metal: false };
        case "silk":           return { L: 0.720, C: 0.090, h: 320, surface: "sheen",   drape: "full",   metal: false };
        case "velvet":         return { L: 0.330, C: 0.086, h: 350, surface: "nap",     drape: "heavy",  metal: false };
        case "canvas":         return { L: 0.660, C: 0.044, h:  84, surface: "twill",   drape: "fitted", metal: false };
        case "felt":           return { L: 0.480, C: 0.030, h:  30, surface: "nap",     drape: "heavy",  metal: false };
        case "damask":         return { L: 0.640, C: 0.078, h: 268, surface: "sheen",   drape: "full",   metal: false };
        case "sackcloth":      return { L: 0.580, C: 0.052, h:  68, surface: "weave",   drape: "soft",   metal: false };
        case "cotton":         return { L: 0.820, C: 0.024, h:  92, surface: "weave",   drape: "soft",   metal: false };
        // ---- leather and hide --------------------------------------------------------------
        case "buckskin":       return { L: 0.600, C: 0.070, h:  64, surface: "nap",     drape: "fitted", metal: false };
        case "oxhide":         return { L: 0.400, C: 0.068, h:  46, surface: "tooling", drape: "rigid",  metal: false };
        case "suede":          return { L: 0.520, C: 0.058, h:  52, surface: "nap",     drape: "soft",   metal: false };
        case "boiled_leather": return { L: 0.300, C: 0.060, h:  40, surface: "tooling", drape: "rigid",  metal: false };
        case "fur":            return { L: 0.420, C: 0.052, h:  44, surface: "nap",     drape: "heavy",  metal: false };
        case "shearling":      return { L: 0.760, C: 0.032, h:  74, surface: "nap",     drape: "heavy",  metal: false };
        // ---- metal ---------------------------------------------------------------------------
        case "iron":           return { L: 0.520, C: 0.010, h: 250, surface: "rivet",   drape: "rigid",  metal: true };
        case "steel":          return { L: 0.680, C: 0.012, h: 240, surface: "rivet",   drape: "rigid",  metal: true };
        case "blued_steel":    return { L: 0.400, C: 0.040, h: 258, surface: "sheen",   drape: "rigid",  metal: true };
        case "bronze":         return { L: 0.560, C: 0.088, h:  66, surface: "rivet",   drape: "rigid",  metal: true };
        case "brass":          return { L: 0.700, C: 0.104, h:  84, surface: "sheen",   drape: "rigid",  metal: true };
        case "silver":         return { L: 0.800, C: 0.014, h: 250, surface: "sheen",   drape: "rigid",  metal: true };
        case "gold":           return { L: 0.780, C: 0.130, h:  92, surface: "sheen",   drape: "rigid",  metal: true };
        case "blackened_iron": return { L: 0.280, C: 0.012, h: 250, surface: "rivet",   drape: "rigid",  metal: true };
        // ---- dyed ----------------------------------------------------------------------------
        case "madder":         return { L: 0.480, C: 0.140, h:  28, surface: "weave",   drape: "soft",   metal: false };
        case "woad":           return { L: 0.420, C: 0.110, h: 264, surface: "weave",   drape: "soft",   metal: false };
        case "saffron":        return { L: 0.760, C: 0.150, h:  86, surface: "weave",   drape: "soft",   metal: false };
        case "tyrian":         return { L: 0.400, C: 0.130, h: 330, surface: "sheen",   drape: "full",   metal: false };
        case "verdigris":      return { L: 0.600, C: 0.090, h: 168, surface: "worn",    drape: "rigid",  metal: true };
        // ⛔ `charcoal` WAS DECLARED IN rai_materials_all() WITH NO CASE HERE, and Internal_Ops/
        // corpus_count.js caught it on its first run. It fell through to `default`, so the corpus
        // silently contained two identical materials while the count still said 30 - a corpus
        // shrinking without the number moving, which is invisible to any counter that only counts
        // the list. That is why that tool checks both directions.
        case "charcoal":       return { L: 0.240, C: 0.016, h:  44, surface: "weave",   drape: "soft",   metal: false };
        default:               return { L: 0.600, C: 0.050, h:  60, surface: "weave",   drape: "soft",   metal: false };
    }
}

/// ============================================================================================
/// THE RAMP
/// ============================================================================================

/// Build the five-stop ramp plus ink and accent for a material.
///
/// ⛔ SEPARATION IS ABSOLUTE, NEVER A MULTIPLIER. Wing CLAUDE.md, measured first on gm-lode and
/// again on the product this drawing layer was ported from: a highlight defined as
/// `shade(base, 1.22)` moves 27 luminance levels on a bright material and 11 on a dark one, so the
/// materials that most need the separation get least of it. Here the stops are placed at ABSOLUTE
/// lightness offsets and then clamped.
///
/// ⚠️ AND THIS CORPUS IS THE WORST CASE FOR IT, WHICH IS WHY THE RULE IS RESTATED HERE RATHER THAN
/// INHERITED SILENTLY. The materials run from charcoal at L 0.240 to cotton at L 0.820 - a range of
/// nearly six tenths within one product, worn by the same figure in the same panel. A proportional
/// separation would give the charcoal robe about a third of the relief the cotton one gets, and a
/// dark garment with no relief is a silhouette rather than cloth.
///
/// ⛔ AND `m0` IS NOT A TEXT COLOUR — `ink` IS (wing CLAUDE.md). On a light material every ramp stop
/// is light, so anything that has to READ against the material uses `ink`, which is computed
/// against the ground rather than taken from the ramp.
///
/// @param {String} _id one of rai_materials_all()
/// @returns {Struct} palette with m0..m4, ink, accent
function rai_material_palette(_id) {
    var _d = rai_material_def(_id);

    // Metal has a wider specular range than cloth: that difference IS the metal, and flattening it
    // is why a lot of generated armour reads as grey cloth.
    var _spread = _d.metal ? 0.190 : 0.115;

    var _l0 = clamp(_d.L - _spread,       0.06, 0.97);
    var _l1 = clamp(_d.L - _spread * 0.5, 0.06, 0.97);
    var _l2 = clamp(_d.L,                 0.06, 0.97);
    var _l3 = clamp(_d.L + _spread * 0.5, 0.06, 0.97);
    var _l4 = clamp(_d.L + _spread,       0.06, 0.97);

    // Chroma falls off at the extremes of lightness or the ramp goes neon in the highlights.
    var _c = _d.C;

    // Ink: chosen for CONTRAST against the material's own mid, not from the ramp.
    var _ink = (_d.L > 0.55) ? rai_oklch(0.16, min(_c, 0.03), _d.h)
                             : rai_oklch(0.94, min(_c, 0.02), _d.h);

    // Accent: derived from the ground by rotating hue, so it always belongs to the material.
    var _accent = rai_oklch(clamp(_d.L + 0.10, 0.10, 0.95), min(_c * 1.35, 0.16), _d.h + 32);

    return {
        m0: rai_oklch(_l0, _c * 0.80, _d.h),
        m1: rai_oklch(_l1, _c * 0.92, _d.h),
        m2: rai_oklch(_l2, _c,        _d.h),
        m3: rai_oklch(_l3, _c * 0.88, _d.h),
        m4: rai_oklch(_l4, _c * 0.70, _d.h),
        ink: _ink,
        accent: _accent
    };
}

/// The three roles a garment draws with, picked out of a material palette.
///
/// Kept as its own function so no garment module ever hard-codes "m2" and quietly disagrees with
/// another one about which stop is the face.
///
/// @param {String} _id material id
/// @returns {Struct} {face, shade, line}
function rai_material_roles(_id) {
    return { face: "m2", shade: "m1", line: "m0" };
}

/// ============================================================================================
/// SURFACE TEXTURE
/// ============================================================================================

/// Draw the surface character of a material across a panel.
///
/// ⚠️ CLIPPED BY THE CALLER, NOT HERE. This returns marks across the panel's bounding band; the
/// caller draws them inside the garment's own outline. Keeping the clip out of this file is what
/// lets the same texture serve a sleeve, a hem and a shoulder plate.
///
/// ⛔ DETAIL SIZE IS PHYSICAL AND IS BOUNDED AT BOTH ENDS (rai_geom's header). A weave does not get
/// coarser because the figure is taller: `_span` sets an absolute scale, and the mark spacing is
/// derived from it rather than from the panel size.
///
/// @param {String} _id material id
/// @param {Real} _x0 left of the band
/// @param {Real} _y0 top of the band
/// @param {Real} _x1 right of the band
/// @param {Real} _y1 bottom of the band
/// @param {Real} _span the figure's stature in unit space, for absolute detail scaling
/// ⛔ `_wk` AND `_sk` EXIST BECAUSE ONE TEXTURE SCALE CANNOT SERVE BOTH KINDS OF SURFACE, AND THE
/// FIRST VERSION THAT SERVED BOTH TURNED A ROBE INTO A KNITTED BLANKET. These marks were tuned on
/// ARMOUR - rivets, mail rings, tooling on a breastplate, all of which are coarse, high-contrast
/// and cover a small piece. Applied unchanged to a full-length robe at the same weight they became
/// horizontal stripes about twenty pixels apart running the whole height of the figure, and read
/// as corduroy. MEASURED 2026-09-02 on the drape sheet, in the same pass that added them.
/// Cloth passes a thinner stroke and a wider step; armour keeps the defaults it was tuned at.
///
/// @param {String} _role colour role for the marks
/// @param {Real} _wk stroke-width multiplier, or undefined for 1
/// @param {Real} _sk spacing multiplier, or undefined for 1
/// @returns {Array} part list
function rai_surface_parts(_id, _x0, _y0, _x1, _y1, _span, _role, _wk, _sk) {
    return rai_surface_marks(rai_material_def(_id).surface, _id,
                             _x0, _y0, _x1, _y1, _span, _role, _wk, _sk);
}

/// The marks for a NAMED surface character, whatever material asked for them.
///
/// ⛔⛔ THIS SPLIT EXISTS BECAUSE THREE OF THE TEN SURFACES WERE UNREACHABLE AND THE MAIL WAS
/// DRAWING RIVETS. A surface belongs to the MATERIAL in rai_material_def, and mail, scale and
/// brigandine are FAMILIES - so a mail hauberk in iron asked for iron's character, which is
/// `rivet`, and got a grid of studs. Meanwhile `ring`, `scale` and `quilt` were declared in
/// rai_surfaces_all(), counted into the corpus figure the listing quotes, and used by nothing at
/// all: no material in the table names any of them. That is the phantom-form defect this wing has
/// paid for before - an array summed into a market claim that names things the package does not
/// have. MEASURED 2026-09-02 by reading rai_material_def against rai_surfaces_all.
///
/// ⇒ A CONSTRUCTION CAN OVERRIDE ITS MATERIAL'S CHARACTER, and rai_armour_surface is what decides.
/// Iron is still iron; it is riveted on a cuirass and drawn into rings on a hauberk, which is what
/// the two words mean.
///
/// @param {String} _surface one of rai_surfaces_all()
/// @param {String} _id material id, for anything that hashes off the material
/// @returns {Array} part list
function rai_surface_marks(_surface, _id, _x0, _y0, _x1, _y1, _span, _role, _wk, _sk) {
    var _d = { surface: _surface };
    var _out = [];
    var _w = _span * 0.0035 * (is_undefined(_wk) ? 1.0 : _wk);
    var _step = _span * 0.030 * (is_undefined(_sk) ? 1.0 : _sk);
    var _x, _y, _i;

    switch (_d.surface) {
        case "weave":
        case "twill": {
            // A grain, not a grid: one direction only, or it reads as graph paper.
            //
            // ⛔⛔ AND A GRAIN IS NOT A SET OF RULES. Every row used to run the FULL width of the
            // panel as one unbroken line, so a robe carried about twenty-five continuous horizontal
            // stripes from shoulder to hem. The file's own header already records that this read as
            // CORDUROY and that the answer was a wider step - it was not: at 1.55x the step the
            // 2026-09-02 drape bake still showed a ladder of hard rules down all five figures, and
            // the reason is the CONTINUITY rather than the spacing. A rule that crosses a whole
            // garment is a rib; the same ink broken into short marks is a weave.
            //
            // ⭐ DASHES, PHASED PER ROW. Each row lays a few short segments with gaps between them
            // and a per-row offset, so no two rows line up and nothing reads as a stripe. It also
            // degrades correctly at figure size: RAI_MIN_STROKE holds each mark at a pixel and the
            // GAPS stop the rows merging into a flat dark tone, which is what a finer continuous
            // rule would have done.
            var _skew = (_d.surface == "twill") ? _step * 0.55 : 0;
            // ⚠️ SPARSE. The first dashed version kept the row PITCH and only broke the lines, and
            // at 4x on the drape sheet the marks still lined up into a horizontal ladder across the
            // chest - because a dash on every row at every third position is a ladder with gaps in
            // it. The mark is at the stroke floor already (1px at hero scale), so the only levers
            // left are how MANY and how FAR APART, and a weave that a viewer can count the rows of
            // is not a weave.
            var _seg = _step * 1.25;
            var _stride = _seg * 3.30;
            var _row3 = 0;
            var _xa, _xb, _dy;
            for (_y = _y0; _y <= _y1; _y += _step) {
                // Two frequencies, so the phase pattern does not repeat every other row and turn
                // into a brick bond - which is a different texture and an obvious one.
                var _ph = (((_row3 mod 3) * 0.41) + ((_row3 mod 5) * 0.17)) * _stride;
                for (_x = _x0 - _stride + _ph; _x <= _x1; _x += _stride) {
                    _xa = max(_x0, _x);
                    _xb = min(_x1, _x + _seg);
                    if (_xb > _xa) {
                        // The twill slant is a SLOPE, so a short mark carries its share of it and
                        // the marks stay parallel to what the full-width line used to be.
                        _dy = _skew * (_xb - _xa) / max(0.0001, _x1 - _x0);
                        array_push(_out, rai_poly([[_xa, _y], [_xb, _y + _dy]], false, _w, _role));
                    }
                }
                _row3 += 1;
            }
            break;
        }
        case "quilt": {
            // ⚠️ 0.032 OF STATURE, NOT 0.055. A brigandine's plates are about 4cm across on a 175cm
            // person, which is 2.3% of stature; at 0.055 the grid was more than twice life size and
            // read as QUILTING - big soft squares - on every brigandine and lamellar piece in the
            // catalogue. Gate 1's holdsUpBeside answer on 2026-09-02 named "a quilt grid standing in
            // for cloth texture" by name.
            var _q = _span * 0.032;
            for (_y = _y0; _y <= _y1; _y += _q) {
                array_push(_out, rai_poly([[_x0, _y], [_x1, _y]], false, _w, _role));
            }
            for (_x = _x0; _x <= _x1; _x += _q) {
                array_push(_out, rai_poly([[_x, _y0], [_x, _y1]], false, _w, _role));
            }
            break;
        }
        case "ring": {
            // Mail. Rows of small rings, offset every other row.
            var _r = _span * 0.011;
            var _row = 0;
            for (_y = _y0; _y <= _y1; _y += _r * 1.7) {
                var _off = (_row % 2 == 0) ? 0 : _r;
                for (_x = _x0 + _off; _x <= _x1; _x += _r * 2.0) {
                    array_push(_out, rai_ring(_x, _y, _r * 0.78, _w, _role));
                }
                _row += 1;
            }
            break;
        }
        case "scale": {
            var _s = _span * 0.028;
            var _row2 = 0;
            for (_y = _y0; _y <= _y1; _y += _s * 0.62) {
                var _off2 = (_row2 % 2 == 0) ? 0 : _s * 0.5;
                for (_x = _x0 + _off2; _x <= _x1; _x += _s) {
                    array_push(_out, rai_poly(rai_arc_pts(_x, _y, _s * 0.5, 0, pi, 6), false, _w, _role));
                }
                _row2 += 1;
            }
            break;
        }
        case "rivet": {
            var _rv = _span * 0.060;
            for (_y = _y0 + _rv * 0.5; _y <= _y1; _y += _rv) {
                for (_x = _x0 + _rv * 0.5; _x <= _x1; _x += _rv) {
                    array_push(_out, rai_dot(_x, _y, _span * 0.006, _role));
                }
            }
            break;
        }
        case "tooling": {
            // Worked leather: a border line inside the edge, not an all-over texture.
            var _in = _span * 0.014;
            array_push(_out, rai_rect_poly(_x0 + _in, _y0 + _in, _x1 - _in, _y1 - _in, _w, _role));
            break;
        }
        case "sheen": {
            // A specular band. One, narrow, and NOT a repaint of the panel - the lesson gm-lode
            // paid for on iridescence: a highlight that drifts over the whole surface reads as a
            // decal rather than as light.
            var _bx = lerp(_x0, _x1, 0.34);
            var _bw = (_x1 - _x0) * 0.10;
            array_push(_out, rai_fill([[_bx, _y0], [_bx + _bw, _y0], [_bx + _bw * 0.6, _y1], [_bx - _bw * 0.4, _y1]], _role));
            break;
        }
        case "worn": {
            // Age. Irregular, so it is driven off the hash rather than a loop counter.
            var _st = rai_rng(rai_hash32(_id));
            for (_i = 0; _i < 18; _i++) {
                var _px = lerp(_x0, _x1, rai_rng_next(_st));
                var _py = lerp(_y0, _y1, rai_rng_next(_st));
                array_push(_out, rai_dot(_px, _py, _span * 0.004 * (0.6 + rai_rng_next(_st)), _role));
            }
            break;
        }
        default: {
            // "nap" - a soft material with no hard structure. Deliberately nothing: a nap reads
            // through the RAMP, and drawing marks on it would make felt look like tweed.
            break;
        }
    }
    return _out;
}
