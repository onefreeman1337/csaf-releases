{
  "$GMScript": "v1",
  "%Name": "rai_shape",
  "name": "rai_shape",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}