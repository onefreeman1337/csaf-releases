/// RAIMENT - rai_shape. The six corner treatments, the outline builders, and the geometry
/// assertions every other file in this package is checked against.
///
/// ⛔ EVERY OUTLINE IN THIS FILE IS BUILT TO A GIVEN RECTANGLE, IN THE CALLER'S OWN UNITS. In this
/// package that rectangle is in UNIT-BOX space (see rai_geom's COORDINATES header), because a
/// figure is authored once and drawn at every size from a 32px inventory portrait upward. An earlier
/// product in this wing built the same outlines in screen pixels, for the opposite and equally
/// correct reason - an interface widget is handed its rectangle and a figure is not - so read the
/// numbers below as unit-box fractions, never as pixels.
///
/// ⚠️ THE ABSOLUTE CAPS ARE THE ONE PLACE THAT DISTINCTION BITES. A cap written in pixels is a
/// cap on a PHYSICAL detail, and the law behind it (a moulding is the same moulding on a door and
/// on a jewellery box) is exactly as true here - see rai_geom. Expressed against the unit box and
/// converted at draw time, a slight figure and a broad one get the same buckle fillet and the same
/// rivet bevel in millimetres rather than the same fraction of themselves.
///
/// -- WHAT THIS FILE IS FOR ON A CLOTHED FIGURE ------------------------------------------------
/// ⚠️ NEITHER THE BODY NOR THE CLOTH IS BUILT HERE. A body outline comes from rai_armature
/// (rai_torso_ring, rai_limb_ring) and a garment from rai_drape's sampler, precisely because
/// neither is a rectangle with treated corners - a draped panel is a curve that changes width at
/// every height, which is the whole argument of the product.
///
/// What this file provides to those files is the MEASUREMENT half - the turning test, the
/// simplicity test, the shortest-edge and inset-limit arithmetic every outline in the package is
/// checked against - plus the six rect treatments used by the RIGID fittings, which genuinely are
/// rectangles with treated corners: belt plates, buckles, pauldron and cuirass panels, greave and
/// bracer plates, clasps, and the frames the store sheets present a figure in.
///
/// The corner readings still survive greyscale, which is the test that matters: a buyer scrolling a
/// store page at thumbnail size sees SHAPE before hue.
///
/// -- THE WINDING LAW, INHERITED AND NOT NEGOTIABLE -------------------------------------------
/// ⛔ CORNERS ARE WALKED TOP-RIGHT, BOTTOM-RIGHT, BOTTOM-LEFT, TOP-LEFT. Every builder below obeys
/// it. rai_relief's own header records what happens otherwise: each corner arc ENDS pointing where
/// the next must BEGIN, so any other order self-intersects into a bowtie, the fan fills the wrong
/// region, and rai_inset throws points a long way outside the shape. It shipped once in this
/// catalogue and was found by opening a PNG.
///
/// rai_selftest STAGE 13 asserts TOTAL TURNING on every outline this file can produce - one
/// revolution for a simple polygon, zero for a figure-of-eight - across all six treatments and six
/// aspect ratios, plus simplicity and containment, and it carries a bowtie vacuity guard so the
/// instrument has to prove it can still say no. That assertion is cheap and it is the only
/// mechanical thing that can see this defect.
///
/// ⛔ THIS PARAGRAPH WAS A LIE UNTIL 2026-09-02: it described stage 13 in the present tense while
/// rai_selftest contained not one reference to a corner treatment. Cite a check by the stage that
/// runs it, and go and read that stage before believing a sentence like this one.
/// ============================================================================================

/// ============================================================================================
/// THE SIX CORNER TREATMENT NAMES
///
/// ⛔⛔ THESE SIX WERE USED IN THIS FILE AND DEFINED NOWHERE IN THE PACKAGE, AND THE COMPILER HAD
/// NOTHING TO SAY ABOUT IT. GML resolves an unknown bare identifier as an instance variable read,
/// so `case RAI_CN_SQUARE:` compiled clean into a lookup of a variable that is never assigned, and
/// the gate passed twice - exit 0, 0 errors, 204 scripts, "sawRealWork": true - on a package whose
/// first call into rai_corner_radius dies with
///     "Variable obj_rai_demo.RAI_CN_SQUARE(100714, -2147483648) not set before reading it."
/// It was found by RUNNING the thing, not by building it (master CLAUDE.md 2b, the row that reads
/// "Gate clean -> plugin couldn't load -> run the thing, not just the build"). Nothing static could
/// have caught it: to a compiler an undefined macro and a legitimate instance variable are the
/// same text.
///
/// ⭐ THEY ARE STRINGS, DELIBERATELY, AND THAT IS WHAT MAKES THE ONE REAL CALLER CORRECT. Before
/// this block existed rai_armour's buckle already called rai_shape_pts("chamfer", ...) - a string -
/// while this file switched on constants, so the two halves of the interface disagreed about what a
/// corner treatment even IS. Strings are also the house style everywhere else in the package
/// (rai_has_piece(_pieces, "belt"), rai_raise(..., "m4"), rai_material_def("velvet")), they survive
/// a save/load round trip in a buyer's own data files without a lookup table, and a wrong one is
/// legible in a debugger instead of being an integer nobody can place.
///
/// ⚠️ Namespaced RAI_ per the wing constitution: GML's macro namespace is flat and global, and a
/// collision inside a buyer's project is a support ticket that cannot be debugged remotely.
#macro RAI_CN_SQUARE  "square"
#macro RAI_CN_ROUND   "round"
#macro RAI_CN_CHAMFER "chamfer"
#macro RAI_CN_COVE    "cove"
#macro RAI_CN_STEP    "step"
#macro RAI_CN_PILL    "pill"

/// Points per corner arc. Six is enough at every size a component ships at; at hero scale on a
/// store sheet a pill's end is drawn at twice this by rai_bake.
#macro RAI_CORNER_SEG 6

/// The largest a corner treatment may ever be, in pixels, before the weight multiplier.
///
/// ⛔⛔ THE ABSOLUTE CAP WAS NOT IN THE FIRST VERSION AND THE HERO SHEET SHOWED WHY IN ONE LOOK.
/// A proportional-only radius gave the 840x560 gilt frame a COVE of 112 pixels: four enormous
/// concave bites out of the corners, which read as damage rather than as a moulding. On the corpus
/// sheet the same rule turned every PILL material - enamel, smoked glass, amber resin, plasma -
/// into a featureless blob, because half the short side of a 170x115 panel is 57 pixels.
///
/// ⭐ A CORNER TREATMENT IS A PHYSICAL DETAIL, NOT A PROPORTION. A moulding run on a door and on a
/// jewellery box is the same moulding; the door does not get a bigger ogee. Every treatment in this
/// file is therefore bounded ABOVE in pixels as well as below by the short side, and the two bounds
/// do different jobs: the proportional one stops a small fitting having a corner bigger than
/// itself, and the absolute one stops a turret-clock plate having a fillet you could put a thumb in.
///
/// ⚠️ NOTHING MECHANICAL COULD HAVE CAUGHT IT. The turning assertion passed - a shape with enormous
/// coves is still a simple polygon. Containment passed - the scoops are inside the rect. The ink
/// floors passed. It was found by opening the PNG, which is the instrument this wing keeps
/// rediscovering.
#macro RAI_CORNER_MAX_PX 30

/// The corner radius for a rect under a given treatment.
///
/// ⛔ DERIVED FROM THE SHORT SIDE, ALWAYS, AND CAPPED AT HALF OF IT. The wing constitution records a
/// product where a vertical dimension was derived from a horizontal one and the error was largest
/// exactly where the product could least afford it. Here the failure is a 400x24 progress bar whose
/// corner radius came off its width: 40 pixels of radius on a 24-pixel-tall bar is not a rounded
/// rectangle, it is two circles with a mistake between them.
function rai_corner_radius(_w, _h, _corner, _weight) {
    var _short = min(abs(_w), abs(_h));
    var _k = 0.18;
    switch (_corner) {
        case RAI_CN_SQUARE:  _k = 0.00; break;
        case RAI_CN_ROUND:   _k = 0.20; break;
        case RAI_CN_CHAMFER: _k = 0.22; break;
        case RAI_CN_COVE:    _k = 0.20; break;
        case RAI_CN_STEP:    _k = 0.24; break;
        case RAI_CN_PILL:    _k = 0.50; break;
    }
    var _wt = clamp(is_undefined(_weight) ? 1.0 : _weight, 0.6, 1.4);
    // Three bounds, and each one catches a different failure: half the short side keeps the
    // treatment inside the shape, the proportional term keeps a small control's corner in scale
    // with it, and the absolute cap keeps a large frame's corner a DETAIL. See RAI_CORNER_MAX_PX.
    return min(_short * 0.5, min(_short * _k * _wt, RAI_CORNER_MAX_PX * _wt));
}

/// ============================================================================================
/// THE CORNER WALK TABLE
///
/// ⛔ ONE TABLE, SIX READERS, AND THE FIRST DRAFT OF IT WAS WRONG. Written from memory the
/// direction pairs came out as the axis the corner sits ON rather than the direction the outline
/// TRAVELS, which put the top-right corner's start point at y0 - r: above the rectangle. Nothing
/// downstream would have said so - the outline would still have closed, still had four corners, and
/// still passed a turning test - it would simply have been the wrong shape, on every component, in
/// every theme.
///
/// So the table is derived here once, in words, and every builder indexes it:
///
///   corner 0  TOP-RIGHT     arrive along the top edge going +x   leave down the right edge  +y
///   corner 1  BOTTOM-RIGHT  arrive down the right edge     +y    leave along the bottom     -x
///   corner 2  BOTTOM-LEFT   arrive along the bottom        -x    leave up the left edge     -y
///   corner 3  TOP-LEFT      arrive up the left edge        -y    leave along the top        +x
///
/// `in` is the direction from the corner point BACK along the edge we arrived on (so K + in*r is
/// the point where the treatment starts). `out` is the direction from the corner point along the
/// edge we leave on (so K + out*r is where it ends).
/// ============================================================================================
function rai_corner_frame(_x0, _y0, _x1, _y1, _r) {
    return {
        // The four corner points themselves, in walk order.
        kx: [_x1, _x1, _x0, _x0],
        ky: [_y0, _y1, _y1, _y0],
        // Back along the incoming edge.
        ix: [-1,  0,  1,  0],
        iy: [ 0, -1,  0,  1],
        // Forward along the outgoing edge.
        ox: [ 0, -1,  0,  1],
        oy: [ 1,  0, -1,  0],
        // Arc start angles for a convex fillet, y-down.
        a0: [-RAI_TAU * 0.25, 0, RAI_TAU * 0.25, RAI_TAU * 0.5],
        // Fillet centres.
        cx: [_x1 - _r, _x1 - _r, _x0 + _r, _x0 + _r],
        cy: [_y0 + _r, _y1 - _r, _y1 - _r, _y0 + _r]
    };
}

/// ============================================================================================
/// THE SIX TREATMENTS
///
/// Each returns a CLOSED outline as an array of [x,y] in pixel space, first point NOT repeated,
/// walked TR -> BR -> BL -> TL.
/// ============================================================================================

/// SQUARE. Four points. Machines, printed matter, brutalist stone.
function rai_pts_square(_x0, _y0, _x1, _y1) {
    return [[_x1, _y0], [_x1, _y1], [_x0, _y1], [_x0, _y0]];
}

/// ROUND. Convex quarter circles. The default of everything soft.
function rai_pts_round(_x0, _y0, _x1, _y1, _r, _seg) {
    var _s = max(1, is_undefined(_seg) ? RAI_CORNER_SEG : _seg);
    var _rr = min(_r, min(abs(_x1 - _x0), abs(_y1 - _y0)) * 0.5);
    if (_rr <= 0) return rai_pts_square(_x0, _y0, _x1, _y1);
    var _f = rai_corner_frame(_x0, _y0, _x1, _y1, _rr);
    var _out = [];
    for (var _c = 0; _c < 4; _c++) {
        for (var _i = 0; _i <= _s; _i++) {
            var _a = _f.a0[_c] + (_i / _s) * (RAI_TAU * 0.25);
            array_push(_out, [_f.cx[_c] + cos(_a) * _rr, _f.cy[_c] + sin(_a) * _rr]);
        }
    }
    return _out;
}

/// CHAMFER. A straight 45-degree cut. Cut stone, cast metal.
///
/// Two points per corner, which is the whole difference from ROUND and is instantly legible even at
/// 16 pixels - a chamfer has a visible flat and a fillet does not.
function rai_pts_chamfer(_x0, _y0, _x1, _y1, _r) {
    var _rr = min(_r, min(abs(_x1 - _x0), abs(_y1 - _y0)) * 0.5);
    if (_rr <= 0) return rai_pts_square(_x0, _y0, _x1, _y1);
    var _f = rai_corner_frame(_x0, _y0, _x1, _y1, _rr);
    var _out = [];
    for (var _c = 0; _c < 4; _c++) {
        array_push(_out, [_f.kx[_c] + _f.ix[_c] * _rr, _f.ky[_c] + _f.iy[_c] * _rr]);
        array_push(_out, [_f.kx[_c] + _f.ox[_c] * _rr, _f.ky[_c] + _f.oy[_c] * _rr]);
    }
    return _out;
}

/// COVE. A CONCAVE quarter-round scooped out of the corner. Porcelain, bone, gilt, jade, marble.
///
/// ⛔ THIS FIELD WAS CALLED "ogee" IN THE FIRST DRAFT OF THE MATERIAL TABLE AND THE NAME WAS A
/// GEOMETRIC IMPOSSIBILITY, WHICH IS WORTH RECORDING BECAUSE IT ALMOST GOT BUILT. An ogee (cyma)
/// reverses curvature, and a corner has to turn through exactly 90 degrees. Two equal arcs turning
/// +a then -a net to zero, so no two-piece S-curve can turn a corner at all - it needs three pieces
/// with unequal sweeps, and the tangency conditions at both ends then have no closed-form solution
/// in the space available here. Two drafts were spent trying before the arithmetic was done.
///
/// A COVE is the honest member of that family and is a real moulding in its own right: a concave
/// quarter-round, the profile on an Art Deco frame, a certificate border, a porcelain plate. It
/// reverses the corner's convexity relative to every other treatment in this file, which makes it
/// the single most distinguishable of the six - and it costs one arc.
///
/// The arc is centred ON the corner point, so it scoops toward the interior. Note it produces two
/// sharp convex kinks (at the start and end of the scoop) with a concave arc between: turning is
/// +90 at the kink, -90 across the arc, +90 at the second kink, netting the +90 a corner owes. The
/// self-test's turning assertion is what proves that, on all four corners at once.
/// ⛔⛔ THE SHOULDERS ARE FILLETED AND THE FIRST VERSION LEFT THEM SHARP. That version joined the
/// concave scoop straight onto the straight edge, which is a 90-DEGREE KINK: the outline's tangent
/// turns instantly from along-the-edge to across-it. Cropping one frame corner to 4x showed what
/// that does to a bevel - a bright wedge and a dark spike jutting into the frame, on every coved
/// component on the sheet, reading as torn paper.
///
/// ⭐ AND THE FIX IS THE NAME OF THE MOULDING. A real cove is a COVE AND FILLET: the hollow is
/// blended into the flat by a small convex arc at each shoulder, and that is not decoration, it is
/// what makes the profile manufacturable and what makes it read as turned rather than cut. Three
/// arcs per corner - fillet, cove, fillet - with curvature reversing smoothly at each join.
///
/// The geometry is exact rather than eyeballed. With cove radius r and fillet radius f, the two
/// arcs are tangent when their centres are (r + f) apart, so the fillet's centre sits one fillet
/// radius in from the edge at a distance e = sqrt(r^2 + 2rf) along it, and the join point lies on
/// the line between the two centres. Every angle below falls out of those two facts.
function rai_pts_cove(_x0, _y0, _x1, _y1, _r, _seg) {
    var _s = max(2, is_undefined(_seg) ? RAI_CORNER_SEG : _seg);
    var _req = min(_r, min(abs(_x1 - _x0), abs(_y1 - _y0)) * 0.5);
    if (_req <= 0) return rai_pts_square(_x0, _y0, _x1, _y1);

    // ⚠️ THE FOOTPRINT IS THE REQUESTED RADIUS, NOT THE COVE'S. Filleting extends the treatment
    // along each edge to e = 1.304 r, so the cove itself is scaled down to keep the corner the size
    // the caller asked for - otherwise adding fillets would silently grow every coved component's
    // corner by thirty per cent and re-open the oversize defect RAI_CORNER_MAX_PX exists to close.
    var _rr = _req / 1.3038;
    var _fr = _rr * 0.35;
    var _e  = sqrt(_rr * _rr + 2 * _rr * _fr);

    var _f = rai_corner_frame(_x0, _y0, _x1, _y1, _rr);
    var _out = [];
    var _fs = max(2, _s div 2);

    for (var _c = 0; _c < 4; _c++) {
        var _kx = _f.kx[_c], _ky = _f.ky[_c];
        var _ix = _f.ix[_c], _iy = _f.iy[_c];
        var _ox = _f.ox[_c], _oy = _f.oy[_c];

        // The two fillet centres: one fillet-radius in from each edge, e along it from the corner.
        var _fax = _kx + _ix * _e + _ox * _fr,  _fay = _ky + _iy * _e + _oy * _fr;
        var _fbx = _kx + _ix * _fr + _ox * _e,  _fby = _ky + _iy * _fr + _oy * _e;

        // Angles of the centre-to-centre lines, which are where the arcs join.
        var _pa = arctan2(_fay - _ky, _fax - _kx);
        var _pb = arctan2(_fby - _ky, _fbx - _kx);

        // 1. SHOULDER FILLET, convex, leaving the incoming edge tangentially.
        var _s0 = arctan2(-_oy, -_ox);
        var _s1 = _pa + pi;
        var _sw = _s1 - _s0;
        while (_sw < 0) _sw += RAI_TAU;
        while (_sw > pi) _sw -= RAI_TAU;
        for (var _i = 0; _i <= _fs; _i++) {
            var _t1 = _s0 + _sw * (_i / _fs);
            array_push(_out, [_fax + cos(_t1) * _fr, _fay + sin(_t1) * _fr]);
        }

        // 2. THE COVE, concave, centred on the corner point itself.
        var _cw = _pb - _pa;
        while (_cw > 0) _cw -= RAI_TAU;
        while (_cw < -pi) _cw += RAI_TAU;
        for (var _i = 1; _i <= _s; _i++) {
            var _t2 = _pa + _cw * (_i / _s);
            array_push(_out, [_kx + cos(_t2) * _rr, _ky + sin(_t2) * _rr]);
        }

        // 3. SHOULDER FILLET, convex, meeting the outgoing edge tangentially.
        var _e0 = _pb + pi;
        var _e1 = arctan2(-_iy, -_ix);
        var _ew = _e1 - _e0;
        while (_ew < 0) _ew += RAI_TAU;
        while (_ew > pi) _ew -= RAI_TAU;
        for (var _i = 1; _i <= _fs; _i++) {
            var _t3 = _e0 + _ew * (_i / _fs);
            array_push(_out, [_fbx + cos(_t3) * _fr, _fby + sin(_t3) * _fr]);
        }
    }
    return _out;
}

/// STEP. An orthogonal two-tread staircase cut off the corner. Circuit boards, cathode housings.
///
/// The inner tread is 40% of the outer, which is what makes it read as a deliberate machined
/// clearance rather than as a stair. Equal treads look like a staircase, and a staircase reads as an
/// error at small sizes. Every segment is axis-aligned - a diagonal anywhere in this shape would
/// undo the entire reading.
function rai_pts_step(_x0, _y0, _x1, _y1, _r) {
    var _rr = min(_r, min(abs(_x1 - _x0), abs(_y1 - _y0)) * 0.5);
    if (_rr <= 0) return rai_pts_square(_x0, _y0, _x1, _y1);
    var _a = _rr, _b = _rr * 0.40;
    var _f = rai_corner_frame(_x0, _y0, _x1, _y1, _rr);
    var _out = [];
    for (var _c = 0; _c < 4; _c++) {
        var _sx = _f.kx[_c] + _f.ix[_c] * _a, _sy = _f.ky[_c] + _f.iy[_c] * _a;
        var _ex = _f.kx[_c] + _f.ox[_c] * _a, _ey = _f.ky[_c] + _f.oy[_c] * _a;
        array_push(_out, [_sx, _sy]);
        array_push(_out, [_sx + _f.ox[_c] * _b, _sy + _f.oy[_c] * _b]);
        array_push(_out, [_sx - _f.ix[_c] * (_a - _b) + _f.ox[_c] * _b,
                          _sy - _f.iy[_c] * (_a - _b) + _f.oy[_c] * _b]);
        array_push(_out, [_ex + _f.ix[_c] * _b, _ey + _f.iy[_c] * _b]);
        array_push(_out, [_ex, _ey]);
    }
    return _out;
}

/// PILL. Fully rounded on the short axis. A water-worn pebble, a rolled nodule, a polished bar.
function rai_pts_pill(_x0, _y0, _x1, _y1, _seg) {
    var _r = min(abs(_x1 - _x0), abs(_y1 - _y0)) * 0.5;
    return rai_pts_round(_x0, _y0, _x1, _y1, _r, is_undefined(_seg) ? RAI_CORNER_SEG + 2 : _seg);
}

/// ============================================================================================
/// CLIPPING AN OUTLINE TO A HALF-PLANE
///
/// ⛔⛔ THIS EXISTS BECAUSE THE HEADER BUILDER WAS FILTERING POINTS BY HEIGHT AND THAT IS NOT A
/// CLIP - IT IS HOW YOU MAKE A BOWTIE. Found by looking at the four-themes sheet: a dark theme's title
/// bar had a dark wedge slashed across it.
///
/// The first version kept every point with y <= cut and then pushed one cut-line point onto each
/// END of the array. But the surviving points are the TOP-RIGHT corner's run followed by the
/// TOP-LEFT corner's run, and the outline travels rightward along the top and DOWN the right side -
/// so the right-hand cut point belongs immediately AFTER the top-right run, not at index 0. Put at
/// the ends, the walk ran right-edge, up to the top-left, back down to the right, across, and out:
/// a self-intersecting polygon, which fills the wrong region and throws rai_inset's points about.
///
/// ⚠️ AND THE SUITE COULD NOT SEE IT. The donor's turning stage asserted everything rai_shape_pts
/// can produce, and the broken outline was assembled from those points AFTERWARDS by a caller - so
/// the assertion covered the ingredients and not the result. The gap is the finding, not the one
/// wedge: rai_selftest must assert turning on every outline that is HANDED TO rai_render, not only
/// on the ones this file returns. That includes rai_drape_ring and rai_limb_ring, which are
/// likewise assembled from parts by their callers.
///
/// Sutherland-Hodgman against a single half-plane: walk each edge, keep points inside, and emit the
/// CROSSING POINT wherever an edge changes side. That is the whole difference between a clip and a
/// filter, and it puts the cut points exactly where the walk needs them.
function rai_clip_below(_pts, _cut) {
    var _n = array_length(_pts);
    if (_n < 3) return _pts;
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i];
        var _b = _pts[(_i + 1) % _n];
        var _ain = (_a[1] <= _cut);
        var _bin = (_b[1] <= _cut);
        if (_ain) array_push(_out, [_a[0], _a[1]]);
        if (_ain != _bin) {
            var _dy = _b[1] - _a[1];
            // A horizontal edge cannot change side, so _dy is non-zero whenever this branch runs.
            var _t = (_cut - _a[1]) / _dy;
            array_push(_out, [_a[0] + (_b[0] - _a[0]) * _t, _cut]);
        }
    }
    return (array_length(_out) >= 3) ? rai_dedupe_pts(_out) : _pts;
}

/// ============================================================================================
/// THE DISPATCH
/// ============================================================================================

/// A closed outline for a rect under a given corner treatment.
///
/// _scale shrinks the radius for small parts - a belt buckle wants a proportionally smaller cove
/// than a cuirass plate does, or the treatment eats the fitting it is supposed to be a detail on.
/// ⛔ EVERY TREATMENT GOES OUT THROUGH rai_dedupe_pts. A corner radius that reaches half the short
/// side makes two adjacent corner constructions land on the same point, and a duplicated vertex
/// caps every bevel in the shape to nothing, breaks rai_inset's direction, and loses a turning
/// measurement. Removing them in ONE place is the whole reason four separate consumers do not have
/// to know about them.
function rai_shape_pts(_corner, _x0, _y0, _x1, _y1, _weight, _scale, _seg) {
    var _sc = is_undefined(_scale) ? 1.0 : _scale;
    var _r = rai_corner_radius(_x1 - _x0, _y1 - _y0, _corner, _weight) * _sc;
    switch (_corner) {
        case RAI_CN_SQUARE:  return rai_pts_square(_x0, _y0, _x1, _y1);
        case RAI_CN_CHAMFER: return rai_dedupe_pts(rai_pts_chamfer(_x0, _y0, _x1, _y1, _r));
        case RAI_CN_COVE:    return rai_dedupe_pts(rai_pts_cove(_x0, _y0, _x1, _y1, _r, _seg));
        case RAI_CN_STEP:    return rai_dedupe_pts(rai_pts_step(_x0, _y0, _x1, _y1, _r));
        // ⚠️ PILL AS A MATERIAL'S CORNER TREATMENT GOES THROUGH THE CAPPED RADIUS, NOT THROUGH
        // rai_pts_pill. The two are different things and conflating them is what turned every
        // moulded material's PANEL into a blob on the donor's first bake: `rai_pts_pill` is a true
        // stadium and is correct where a stadium is the object - a rolled pebble, a fibrous sheaf,
        // a bar of satin spar, all of which are thin and small - while a squat block with a
        // half-width radius is just an oval.
        // rai_corner_radius gives PILL the largest _k in the table, so it is still visibly the
        // roundest treatment wherever the cap does not bite.
        case RAI_CN_PILL:    return rai_dedupe_pts(rai_pts_round(_x0, _y0, _x1, _y1, _r,
                                                                 is_undefined(_seg) ? RAI_CORNER_SEG + 2 : _seg));
        default:             return rai_dedupe_pts(rai_pts_round(_x0, _y0, _x1, _y1, _r, _seg));
    }
}

/// The material's own outline for a rect - the fitting treatment a material implies.
///
/// ⛔⛔ THIS FUNCTION READ `_mat.corner` AND `_mat.weight`, AND NO MATERIAL IN THIS PACKAGE HAS
/// EITHER FIELD. rai_material_def returns { L, C, h, surface, drape, metal } for all 30 materials,
/// so every call to this function on this product's OWN corpus would have thrown on the struct read
/// - a second crash of exactly the same family as the RAI_CN_* one above, sitting three lines away
/// from it. It survived because nothing in the package calls it, which is also why its old comment
/// ("the call every component builder actually makes") was false: it is donor code, ported from a
/// product whose materials really did carry a corner and a weight.
///
/// ⚠️ SO THE MAPPING BELOW IS A DOCUMENTED DESIGN DEFAULT, NOT A MEASUREMENT. It is derived from
/// the two fields materials genuinely declare - `drape` and `metal` - on one stated principle: a
/// fitting's corner reads as its stiffness. Rigid metal is cut and filed, so it chamfers; rigid
/// non-metal is moulded leather, so it steps; cloth is soft and rounds. A caller who disagrees can
/// override per material by adding a `corner` (and optional `weight`) field to the struct, which is
/// why both are read through struct_exists rather than assumed.
function rai_shape_of(_mat, _x0, _y0, _x1, _y1, _scale) {
    var _corner = rai_corner_for_material(_mat);
    var _weight = (is_struct(_mat) && variable_struct_exists(_mat, "weight")) ? _mat.weight : 1.0;
    return rai_shape_pts(_corner, _x0, _y0, _x1, _y1, _weight, _scale, undefined);
}

/// The corner treatment a material implies. Always returns one of rai_corners_all().
///
/// An explicit `corner` on the struct always wins; the drape/metal mapping is the fallback.
function rai_corner_for_material(_mat) {
    if (!is_struct(_mat)) return RAI_CN_ROUND;
    if (variable_struct_exists(_mat, "corner")) return _mat.corner;
    var _rigid = variable_struct_exists(_mat, "drape") && _mat.drape == "rigid";
    var _metal = variable_struct_exists(_mat, "metal") && _mat.metal;
    if (_rigid) return _metal ? RAI_CN_CHAMFER : RAI_CN_STEP;
    return RAI_CN_ROUND;
}

/// Every corner treatment, for the self-test's turning sweep.
function rai_corners_all() {
    return [RAI_CN_SQUARE, RAI_CN_ROUND, RAI_CN_CHAMFER, RAI_CN_COVE, RAI_CN_STEP, RAI_CN_PILL];
}

/// ============================================================================================
/// MEASUREMENT - what the self-test asserts against
/// ============================================================================================

/// Remove consecutive coincident points from a closed outline.
///
/// ⛔ THEY ARISE NATURALLY AND THEY ARE NOT HARMLESS. When a corner radius reaches half the short
/// side - which is what PILL means, every time, and what CHAMFER and ROUND do on a square component
/// - two adjacent corner constructions land on the same point and the outline carries a duplicate.
///
/// A duplicated vertex has three downstream consequences and the wing constitution names one of
/// them directly: "skip zero-length edges when measuring or a duplicated point caps every bevel in
/// the package to nothing". The other two are that rai_inset cannot compute a direction there, and
/// that any turning measurement loses the vertex.
///
/// Removing them once, at the end of the shape dispatch, is cheaper and safer than teaching four
/// separate consumers to tolerate them.
function rai_dedupe_pts(_pts) {
    var _n = array_length(_pts);
    if (_n < 2) return _pts;
    var _out = [];
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[_i];
        var _q = _pts[(_i + _n - 1) % _n];
        // ⚠️ 0.001, not a smaller number. GML applies a default epsilon of 0.00001 to numeric
        // comparisons, so a tolerance at or below it cannot fire in either direction.
        if (abs(_p[0] - _q[0]) < 0.001 && abs(_p[1] - _q[1]) < 0.001) continue;
        array_push(_out, _p);
    }
    return (array_length(_out) >= 3) ? _out : _pts;
}

/// Total signed turning of a closed polygon, in revolutions.
///
/// ⭐ THE CHEAPEST TEST FOR THE ONE DEFECT THIS FILE CAN HAVE. A simple closed polygon turns through
/// exactly one revolution; a figure-of-eight turns through zero. It cannot see every wrong shape,
/// but it sees the bowtie, and the bowtie is the one that has actually shipped in this catalogue.
///
/// ⛔ IT DEDUPES FIRST, AND THE FIRST VERSION DID NOT - IT SKIPPED ZERO-LENGTH EDGES INSTEAD, WHICH
/// IS A DIFFERENT THING AND IS WRONG. MEASURED on this product's first headless run: all five PILL
/// cases failed, reading 0.875 and 0.938 revolutions on shapes that are simple circles and stadia.
///
/// A duplicated point P appears as `... A, P, P, B ...`. Skipping every vertex whose adjacent edge
/// has zero length discards TWO vertices per duplicate and therefore discards the real turn at one
/// of them - a quarter to an eighth of a revolution across four corner joins. The shape was correct
/// the whole time and the measurement was not.
///
/// ⚠️ A FALSE RED COSTS EXACTLY WHAT A FALSE GREEN DOES. Acting on this one would have meant
/// "fixing" a correct pill outline until a broken instrument agreed with it.
function rai_turning(_pts) {
    var _p = rai_dedupe_pts(_pts);
    var _n = array_length(_p);
    if (_n < 3) return 0;
    var _sum = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _p[_i];
        var _b = _p[(_i + 1) % _n];
        var _c = _p[(_i + 2) % _n];
        var _ux = _b[0] - _a[0], _uy = _b[1] - _a[1];
        var _vx = _c[0] - _b[0], _vy = _c[1] - _b[1];
        var _lu = point_distance(0, 0, _ux, _uy);
        var _lv = point_distance(0, 0, _vx, _vy);
        if (_lu == 0 || _lv == 0) continue;
        _sum += arctan2(_ux * _vy - _uy * _vx, _ux * _vx + _uy * _vy);
    }
    return _sum / RAI_TAU;
}

/// ============================================================================================
/// IS THIS OUTLINE ACTUALLY SIMPLE?
///
/// ⛔⛔ TOTAL TURNING IS THE CHEAP TEST AND IT IS NOT A COMPLETE ONE. The wing constitution says
/// "total turning is the cheap test: one revolution for a simple polygon, zero for a
/// figure-of-eight, assert it on every authored outline" - and that is true and worth keeping. What
/// it does not say, and what is MEASURED here, is that the converse fails: a turning of exactly one
/// revolution does NOT prove a polygon is simple.
///
/// THE RECEIPT. The header builder's original filter-and-push produced a self-intersecting outline
/// on every corner treatment. Re-instating that defect deliberately and running the suite, the
/// turning assertion fired on STEP - reading -2.000 - and PASSED ON THE OTHER FIVE, including the
/// CHAMFER that produced the visible dark wedge across a dark theme's title bar in the first place. A
/// polygon with a single crossed-over flap can still accumulate exactly one revolution; only a
/// figure-of-eight is forced to zero.
///
/// ⭐ So the sabotage did two jobs: it proved the new assertion fires, and it proved the assertion
/// I had just written would not have caught the bug it was written for. An assertion that goes red
/// on your sabotage is not the same as an assertion that would have caught your defect - check
/// WHICH cases fired, not just that some did.
///
/// This is the definitive test: no two non-adjacent edges may intersect. It is O(n^2) on ~30 points,
/// which is nothing in a suite and is never called at draw time.
/// ============================================================================================

/// Do segments p1->p2 and p3->p4 properly intersect?
///
/// ⚠️ PROPER intersection only - shared endpoints do not count, because adjacent edges of any
/// polygon share one by construction and counting those would fail every shape ever made.
function rai_seg_hit(_p1, _p2, _p3, _p4) {
    var _d1 = (_p4[0] - _p3[0]) * (_p1[1] - _p3[1]) - (_p4[1] - _p3[1]) * (_p1[0] - _p3[0]);
    var _d2 = (_p4[0] - _p3[0]) * (_p2[1] - _p3[1]) - (_p4[1] - _p3[1]) * (_p2[0] - _p3[0]);
    var _d3 = (_p2[0] - _p1[0]) * (_p3[1] - _p1[1]) - (_p2[1] - _p1[1]) * (_p3[0] - _p1[0]);
    var _d4 = (_p2[0] - _p1[0]) * (_p4[1] - _p1[1]) - (_p2[1] - _p1[1]) * (_p4[0] - _p1[0]);
    // Strictly opposite sides on both tests. Touching (a zero) is deliberately NOT a hit: sampled
    // curves routinely graze, and a test that fires on a graze is a test nobody can keep green.
    return ((_d1 > 0) != (_d2 > 0)) && ((_d3 > 0) != (_d4 > 0))
        && abs(_d1) > 0.0001 && abs(_d2) > 0.0001
        && abs(_d3) > 0.0001 && abs(_d4) > 0.0001;
}

/// True if no two non-adjacent edges of this closed outline cross.
function rai_is_simple(_pts) {
    var _p = rai_dedupe_pts(_pts);
    var _n = array_length(_p);
    if (_n < 4) return true;
    for (var _i = 0; _i < _n; _i++) {
        for (var _j = _i + 2; _j < _n; _j++) {
            // The first and last edges are adjacent through the closing point.
            if (_i == 0 && _j == _n - 1) continue;
            if (rai_seg_hit(_p[_i], _p[(_i + 1) % _n], _p[_j], _p[(_j + 1) % _n])) return false;
        }
    }
    return true;
}

/// True if the closed outline's INTERIOR contains the point (0, _y) - i.e. the shape spans its own
/// centre line at that height.
///
/// ⛔⛔ THIS IS THE ONE QUESTION NONE OF THE OTHER INSTRUMENTS IN THIS PACKAGE COULD ASK, AND IT IS
/// THE QUESTION A FIGURE WITH A HOLE IN IT FAILS. Turning, simplicity, containment, distinctness and
/// the ink floors are ALL satisfied by a body whose torso stops at the hip line and whose two legs
/// hang below it with daylight between - which is what this product drew on every figure it ever
/// made, until 2026-09-02. Half-widths cannot see it either: rai_ring_halfwidth_at returns the
/// OUTERMOST crossing, so a ring that is open at the centre and a ring that is solid there give the
/// same answer.
///
/// Even-odd crossings to the right of the centre line, with a half-open test on y so a vertex that
/// lands exactly on the sample height is counted once rather than twice or not at all.
///
/// @param {Array} _pts closed outline of [x,y]
/// @param {Real} _y the height to test, in the outline's own space
/// @returns {Bool} true if (0, _y) is inside
function rai_ring_covers_centre(_pts, _y) {
    var _n = array_length(_pts);
    if (_n < 3) return false;
    var _in = false;
    var _i;
    for (_i = 0; _i < _n; _i++) {
        var _p = _pts[_i];
        var _q = _pts[(_i + 1) % _n];
        if ((_p[1] > _y) == (_q[1] > _y)) continue;
        var _t = (_y - _p[1]) / (_q[1] - _p[1]);
        if ((_p[0] + (_q[0] - _p[0]) * _t) > 0) _in = !_in;
    }
    return _in;
}

/// True if rai_ring_fill can fill this outline correctly from the apex (_cx, _cy).
///
/// ⛔⛔ SIMPLICITY IS THE WRONG QUESTION FOR A FAN, AND BELIEVING OTHERWISE COST A WHOLE BUILD CYCLE
/// HERE. rai_ring_fill walks apex -> p0 -> p1 -> ... and emits one triangle per edge, so what it
/// needs is not that the outline avoids crossing ITSELF but that the vertices wind MONOTONICALLY IN
/// ANGLE about the apex. A perfectly simple outline whose vertices double back in angle makes two
/// triangles overlap, and the region between them is filled twice while the region beside it is not
/// filled at all - which renders as a ragged tangle with a hole in it and no crossing edge anywhere.
///
/// MEASURED 2026-09-02: reinstating the shipped hem defect and running rai_is_simple over the
/// resulting mail corselet returned TRUE, on a ring photographed at 8x with a visible enclosed hole
/// in it. The outline was never the problem. This wing's Welkin entry states the general law - "a
/// correct outline handed to a triangle fan is not a correct picture", and "a suite that computes
/// POINTS can never see a FILL RULE" - and this is the instrument that closes it: it models what the
/// renderer does instead of what the geometry is.
///
/// @param {Array} _pts closed outline of [x,y]
/// @param {Real} _cx fan apex x, as passed to rai_ring_fill
/// @param {Real} _cy fan apex y
/// @returns {Bool} true if every consecutive edge turns the same way about the apex
function rai_ring_fan_safe(_pts, _cx, _cy) {
    var _p = rai_dedupe_pts(_pts);
    var _n = array_length(_p);
    if (_n < 3) return false;
    var _steps = array_create(_n);
    var _sum = 0;
    var _i;
    for (_i = 0; _i < _n; _i++) {
        var _ax = _p[_i][0] - _cx;
        var _ay = _p[_i][1] - _cy;
        var _bx = _p[(_i + 1) % _n][0] - _cx;
        var _by = _p[(_i + 1) % _n][1] - _cy;
        // The apex must be distinct from every vertex, or the angle to it is undefined.
        if (abs(_ax) + abs(_ay) < 0.0001) return false;
        if (abs(_bx) + abs(_by) < 0.0001) return false;
        // The signed turn from this vertex to the next, seen from the apex.
        _steps[_i] = arctan2(_ax * _by - _ay * _bx, _ax * _bx + _ay * _by);
        _sum += _steps[_i];
    }
    // ⚠️ BOTH CONDITIONS, AND THE SUM ALONE IS NOT ONE OF THEM. A total of one revolution only says
    // the apex is inside the outline - an excursion forward and back cancels and still totals a turn.
    // What a fan needs is that no wedge is ever walked BACKWARDS over one already drawn, which is
    // monotonicity of the individual steps. Winding-agnostic: the direction is taken from the ring
    // itself, because the builders in this package are not guaranteed to agree on it and a test that
    // accepts only one direction is a false red waiting to happen.
    if (abs(abs(_sum) - RAI_TAU) >= 0.001) return false;
    var _dir = (_sum > 0) ? 1 : -1;
    for (_i = 0; _i < _n; _i++) {
        if (_steps[_i] * _dir <= 0) return false;
    }
    return true;
}

/// The axis-aligned bounds of a point list, as [x0, y0, x1, y1].
function rai_pts_bounds(_pts) {
    var _n = array_length(_pts);
    if (_n == 0) return [0, 0, 0, 0];
    var _x0 = _pts[0][0], _y0 = _pts[0][1], _x1 = _x0, _y1 = _y0;
    for (var _i = 1; _i < _n; _i++) {
        _x0 = min(_x0, _pts[_i][0]); _x1 = max(_x1, _pts[_i][0]);
        _y0 = min(_y0, _pts[_i][1]); _y1 = max(_y1, _pts[_i][1]);
    }
    return [_x0, _y0, _x1, _y1];
}

/// The shortest edge in a closed outline, ignoring zero-length ones.
function rai_shortest_edge(_pts) {
    var _n = array_length(_pts);
    if (_n < 2) return 0;
    var _m = 999999;
    var _found = false;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[_i], _b = _pts[(_i + 1) % _n];
        var _d = point_distance(_a[0], _a[1], _b[0], _b[1]);
        if (_d <= 0.0001) continue;
        _found = true;
        if (_d < _m) _m = _d;
    }
    return _found ? _m : 0;
}

/// ============================================================================================
/// HOW DEEP A BEVEL MAY BE
///
/// ⛔⛔ THE INHERITED RULE IS "CAP AT 0.45 OF THE SHORTEST EDGE" AND IT IS THE WRONG MEASURE. It is
/// in Wings/GameMaker/CLAUDE.md, it was paid for on a real product, and the DEFECT it describes is
/// completely real - insetting a sampled curve too far swaps consecutive inset points and the bevel
/// quad becomes a bowtie, silently, with the outline, the winding and the ink all still correct.
/// What is wrong is the PROXY, in the direction that costs image quality rather than correctness.
///
/// MEASURED, in rai_selftest, on a circle of radius 60 sampled at 24 points:
///   shortest edge          15.6 px   ->   old rule allows a bevel of  7.0 px
///   true safe inset                  ->   60 px, the radius itself
/// Insetting a convex sampled curve moves every point inward along its own radius; the result is a
/// smaller circle and NOTHING crosses until the inset reaches the centre. The old rule refuses 88%
/// of the legal range, so every rounded, coved and pill component in this product would have got a
/// 7-pixel bevel on a 120-pixel panel - a hairline where the design calls for a moulding.
///
/// ⭐ THE REAL CONSTRAINT IS AT REFLEX VERTICES, NOT SHORT ONES. Inset points converge and swap only
/// where the outline turns the OPPOSITE way to its own winding: the notch in a STEP corner, the
/// kink either side of a COVE scoop. At such a vertex the two adjacent inset edges meet after
///     (half the shorter adjacent edge) / tan(half the turn)
/// so that is what is measured. At a convex vertex the inset edges diverge and the limit is
/// infinite, which is why a smooth curve is unconstrained.
///
/// A false RED costs exactly what a false green does, and this one would have cost it on 40 themes
/// at once. Reported back to the wing constitution with this receipt.
/// ============================================================================================

/// How much of a concave ARC's radius a bevel may use.
///
/// ⛔⛔ THE VERTEX BOUND ALONE IS NOT ENOUGH, AND THE DIFFERENCE COST TWO BAKES AND A RED SUITE.
///
/// The vertex bound asks where ONE notch's two inset edges meet. That is the whole story for a
/// single reflex corner - a STEP corner's notch - and it is badly wrong for a COVE, because a cove
/// is a RUN of reflex vertices making a concave CURVE, and a concave curve of radius R collapses to
/// a point when inset by R no matter how short its individual segments are. The cove's vertices turn
/// only 5 degrees each, so the vertex bound let the hero frame's bevel go to 29.7px on a 23px arc:
/// arithmetically inside every per-vertex limit, and visually a bright wedge and a dark spike
/// jutting out of every coved component on the sheet. It read as torn paper.
///
/// ⚠️ THE FIRST FIX WAS ONE SAFETY FACTOR OVER THE WHOLE VERTEX BOUND, AND IT WAS THE WRONG SHAPE.
/// It worked on the cove and then starved the STEP corner - `STAGE 7 [step] allows no usable bevel`
/// - because a 90-degree notch and a 5-degree arc segment are different objects and one multiplier
/// cannot serve both. The suite caught that in one run, which is what it is for.
///
/// ⭐ SO THERE ARE TWO BOUNDS, MEASURING TWO DIFFERENT THINGS, and only the ARC one carries a safety
/// factor - because only it is approximating a continuous curve by its samples. The general law:
/// A SAFETY BOUND EVALUATED EXACTLY IS NOT A SAFETY BOUND, and a bound that averages two different
/// failure modes protects against neither.
#macro RAI_REFLEX_SAFETY 0.45

/// The largest inset a bevel may use without turning this outline inside out.
///
/// Also capped at 35% of the smaller bounding dimension - beyond that a bevel has eaten the face it
/// is supposed to be a border on, which is a design failure rather than a geometric one.
function rai_inset_limit(_pts) {
    var _n = array_length(_pts);
    if (_n < 3) return 0;
    var _bb = rai_pts_bounds(_pts);
    var _limit = min(_bb[2] - _bb[0], _bb[3] - _bb[1]) * 0.35;
    // Which way this outline winds; a reflex vertex is one turning the other way.
    var _wind = (rai_area2(_pts) >= 0) ? 1 : -1;

    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[(_i + _n - 1) % _n];
        var _b = _pts[_i];
        var _c = _pts[(_i + 1) % _n];
        var _ux = _b[0] - _a[0], _uy = _b[1] - _a[1];
        var _vx = _c[0] - _b[0], _vy = _c[1] - _b[1];
        var _lu = point_distance(0, 0, _ux, _uy);
        var _lv = point_distance(0, 0, _vx, _vy);
        if (_lu <= 0.0001 || _lv <= 0.0001) continue;
        var _turn = arctan2(_ux * _vy - _uy * _vx, _ux * _vx + _uy * _vy);

        // A SHARP CONVEX VERTEX IS NOT UNCONSTRAINED, because rai_inset's normal is only as good as
        // the two edges it is averaged from. It takes the direction from the PREVIOUS vertex to the
        // NEXT one - a fine normal when the adjacent edges are similar, and a badly skewed one when
        // a 250px straight run meets a 53px chamfer flat at 45 degrees. Read off rai_inset directly:
        // at that vertex `q - p` is dominated by the long edge, so the computed normal points almost
        // straight down where the true inward bisector is down-and-left at 22.5 degrees, and the
        // bevel's inner ring is displaced along the wrong axis. Bounding the inset by the SHORT
        // adjacent edge bounds how far that error can travel.
        //
        // ⚠️ THIS BOUND WAS ADDED ON A MISDIAGNOSIS AND IS KEPT ON A DIFFERENT ARGUMENT, WHICH IS
        // WORTH RECORDING BECAUSE THE FIRST COMMENT HERE CITED A MEASUREMENT THAT NEVER HAPPENED.
        // A chamfered panel on an ancestor's corners sheet was read as having a triangular flap of
        // bevel hanging outside itself, the corner was cropped to 7x to "confirm" it, and the crop
        // was misread: the dark triangle IS the chamfer face, correctly shaded, with the page
        // beyond it. There
        // was no escape. The reasoning above is checkable against rai_inset's source and stands on
        // its own; the flap does not exist and no longer appears in this file.
        //
        // ⛔ A FALSE RECEIPT IN A COMMENT IS WORSE THAN NO COMMENT. It is exactly the stale-doctrine
        // generator this factory keeps paying for: the next session would have trusted it, and it
        // would have re-injected a defect that was never there. Looking at a crop is the right
        // instrument; believing what you expected to see in it is not using the instrument.
        //
        // Scoped to SHARP convex vertices only, above 30 degrees. A sampled curve turns 5 to 15
        // degrees per vertex and is untouched, which is the whole point of the correction above; a
        // chamfer, a step and a square corner turn 45 to 90 and are bounded.
        var _sharp = 0.5236;
        if (_turn * _wind > 0 && abs(_turn) > _sharp) {
            _limit = min(_limit, min(_lu, _lv) * 0.45);
        }
        // Same sign as the winding is a CONVEX vertex: the inset edges diverge, no reflex limit.
        if (_turn * _wind >= 0) continue;
        var _half = abs(_turn) * 0.5;
        // A full reversal (a spike) has tan -> infinity and the limit correctly goes to zero.
        var _t = tan(min(_half, RAI_TAU * 0.25 - 0.0001));
        if (_t <= 0.0001) continue;
        // (a) The VERTEX bound: where this one notch's two inset edges meet.
        _limit = min(_limit, (min(_lu, _lv) * 0.5) / _t);
        // (b) The ARC bound: a run of consecutive reflex vertices is a concave CURVE, and a concave
        //     curve of radius R collapses to a point when inset by R however short its segments are.
        //     The local radius falls out of the same two numbers.
        var _sinHalf = sin(_half);
        if (_sinHalf > 0.0001) {
            _limit = min(_limit, (min(_lu, _lv) / (2 * _sinHalf)) * RAI_REFLEX_SAFETY);
        }
    }
    return max(0, _limit);
}

/// A bevel depth that cannot turn its own outline inside out.
///
/// Every component builder in this package passes its requested depth through here. Applied in ONE
/// place rather than at the call sites that happen to fail, because tuning constants at call sites
/// makes a suite green and leaves the next shape to rediscover the defect.
function rai_bevel_cap(_pts, _want) {
    return min(_want, rai_inset_limit(_pts));
}
