{
  "$GMScript": "v1",
  "%Name": "rai_cast",
  "name": "rai_cast",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}