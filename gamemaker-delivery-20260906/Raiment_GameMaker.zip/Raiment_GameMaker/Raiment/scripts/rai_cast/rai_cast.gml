/// RAIMENT - rai_cast. A seeded crowd, where everyone looks like themselves.
///
/// ⭐ THIS IS THE DEMO THAT SELLS THE PRODUCT, and it is also the honest test of whether the corpus
/// is real. One beautifully dressed figure proves an artist drew something. Forty figures from one
/// seed, all distinct, all coherent, proves a SYSTEM - and a system is the thing a sprite sheet
/// cannot be.
///
/// ============================================================================================
/// ⛔ RANDOM IS NOT VARIETY, AND THIS IS THE FILE WHERE THAT GOES WRONG
/// ============================================================================================
///
/// The naive crowd picks a family and a material uniformly at random for every figure. It produces
/// a gold sackcloth robe next to a silk brigandine, and the eye reads the result as NOISE - which
/// is worse than a repeated sprite, because a repeated sprite at least looks deliberate.
///
/// ⇒ EVERY FIGURE IS DRAWN FROM AN ARCHETYPE, and an archetype is a restricted palette AND a
/// restricted wardrobe: a villager wears homespun and wool, a noble wears silk and damask, a
/// guard wears iron over leather. The variety inside an archetype is what makes forty villagers
/// distinguishable; the difference BETWEEN archetypes is what makes the crowd read as a place with
/// classes in it rather than as a colour test.
///
/// ⚠️ AND THE SEED HAS TO BE PER FIGURE, NOT PER CROWD. One stream advanced across forty figures
/// means inserting a figure at the front changes every figure after it - so a buyer who adds an NPC
/// to a village finds the whole village has changed clothes. Each member is seeded from
/// (crowd seed, index), which is what makes a village stable under edits.
///
/// ⚠️ PURE. Returns descriptions, not parts. rai_wardrobe turns one into a figure.

/// The archetype ids, in a stable order.
///
/// ⛔ THE ORDER IS PART OF THE PRODUCT - rai_selftest counts from this list.
function rai_archetypes_all() {
    return ["villager", "labourer", "merchant", "priest", "hunter", "guard", "soldier", "noble"];
}

/// What an archetype is allowed to wear and be made of.
///
/// `body`, `legs`, `outer`, `head`, `waist` are the candidate families for those slots; an empty
/// array means the archetype does not wear that slot at all. `cloth` and `metal` are the material
/// pools, kept separate so a wool cloak over a steel cuirass picks sensibly from each.
///
/// ⚠️ A POOL IS NOT A COSTUME. Two villagers built from this same declaration differ in family,
/// material, build, pose and whether they carry an apron or a cloak - six independent choices - so
/// the archetype narrows the range without collapsing it.
///
/// @param {String} _id one of rai_archetypes_all()
/// @returns {Struct} the pools
function rai_archetype(_id) {
    switch (_id) {
        case "labourer":
            return { body: ["tunic"], legs: ["trousers"], outer: [], head: [],
                     front: ["apron"], waist: ["sash"], armour: [],
                     cloth: ["sackcloth", "homespun", "canvas", "felt", "charcoal"],
                     metal: ["iron"], armour_chance: 0.00, outer_chance: 0.10 };
        case "merchant":
            return { body: ["tunic", "coat"], legs: ["trousers"], outer: ["coat"], head: [],
                     front: [], waist: ["sash"], armour: [],
                     cloth: ["wool", "linen", "damask", "madder", "woad", "buckskin"],
                     metal: ["brass"], armour_chance: 0.00, outer_chance: 0.55 };
        case "priest":
            return { body: ["robe"], legs: [], outer: ["cloak"], head: ["hood"],
                     front: [], waist: ["sash"], armour: [],
                     cloth: ["linen", "cotton", "saffron", "tyrian", "silk", "charcoal"],
                     metal: ["silver", "gold"], armour_chance: 0.00, outer_chance: 0.40 };
        case "hunter":
            return { body: ["tunic"], legs: ["trousers"], outer: ["cloak"], head: ["hood"],
                     front: [], waist: ["sash"], armour: ["leather"],
                     cloth: ["buckskin", "suede", "wool", "fur", "woad", "shearling"],
                     metal: ["blackened_iron"], armour_chance: 0.35, outer_chance: 0.60 };
        case "guard":
            return { body: ["tunic"], legs: ["trousers"], outer: [], head: [],
                     front: [], waist: ["sash"], armour: ["mail", "brigandine", "leather"],
                     cloth: ["wool", "homespun", "madder", "woad", "oxhide"],
                     metal: ["iron", "steel", "bronze", "blackened_iron"],
                     armour_chance: 0.90, outer_chance: 0.15 };
        case "soldier":
            return { body: ["tunic"], legs: ["trousers"], outer: ["cloak"], head: [],
                     front: [], waist: ["sash"], armour: ["plate", "mail", "scale", "lamellar"],
                     cloth: ["wool", "madder", "woad", "boiled_leather", "canvas"],
                     metal: ["steel", "blued_steel", "iron", "bronze", "blackened_iron"],
                     armour_chance: 1.00, outer_chance: 0.45 };
        case "noble":
            return { body: ["robe", "coat"], legs: ["trousers"], outer: ["cloak"], head: [],
                     front: [], waist: ["sash"], armour: [],
                     cloth: ["silk", "damask", "velvet", "tyrian", "saffron", "madder"],
                     metal: ["gold", "silver", "brass"], armour_chance: 0.00, outer_chance: 0.70 };
        default: // villager
            return { body: ["tunic", "robe"], legs: ["trousers", "skirt"], outer: ["cloak"], head: [],
                     front: ["apron"], waist: ["sash"], armour: [],
                     cloth: ["homespun", "wool", "linen", "cotton", "sackcloth", "felt", "madder"],
                     metal: ["iron"], armour_chance: 0.00, outer_chance: 0.30 };
    }
}

/// ============================================================================================
/// THE SEEDED PICK
/// ============================================================================================

/// One item out of an array, from a stream.
///
/// Returns undefined for an empty array rather than throwing, because "this archetype does not wear
/// legs" is a legitimate declaration and every caller here has to handle it anyway.
///
/// @param {Struct} _st from rai_rng
/// @param {Array} _arr candidates
/// @returns the chosen element, or undefined
function rai_pick(_st, _arr) {
    var _n = array_length(_arr);
    if (_n <= 0) return undefined;
    var _i = floor(rai_rng_next(_st) * _n);
    if (_i >= _n) _i = _n - 1;
    return _arr[_i];
}

/// Build one member of the cast.
///
/// ⛔ THE STREAM IS SEEDED FROM (crowd, index) AND NOT ADVANCED ACROSS MEMBERS - see the header.
/// This is what makes a village stable when a buyer inserts an NPC into the middle of it.
///
/// ⚠️ THE DRAW ORDER OF THE PICKS IS PART OF THE OUTPUT. Changing which choice is made first
/// re-rolls every figure in every crowd anyone has already seeded, so treat this sequence as
/// published: build, pose, body, legs, outer, head, waist, front, armour, then materials.
///
/// @param {String} _crowd a name or seed string for the whole crowd
/// @param {Real} _index which member
/// @param {String} _arch one of rai_archetypes_all()
/// @returns {Struct} {build, pose, worn, skin, archetype}
function rai_cast_member(_crowd, _index, _arch) {
    var _a = rai_archetype(_arch);
    var _st = rai_rng(rai_hash32(_crowd + "#" + string(_index)));

    var _build = rai_pick(_st, rai_builds_all());
    // ⛔ WEIGHTED, NOT UNIFORM, AND UNIFORM WAS WRONG FOR A CROWD. rai_poses_all() is five poses,
    // so a flat pick put `reach` on a fifth of any village - and `reach` is a straight horizontal
    // arm, which on a grid of twenty-four standing people reads as a salute rather than as
    // variety. Five of twenty-four were doing it on the crowd sheet of 2026-09-02.
    //
    // ⚠️ THE POOL IS A LIST HERE AND NOT THE CORPUS FUNCTION, DELIBERATELY. rai_pick consumes
    // exactly ONE draw whatever the array length, so re-weighting changes which pose a member
    // gets and NOTHING downstream of it - every later pick reads the same stream value it always
    // did. The corpus still ships all five and the pose sheet still shows all five.
    //
    // ⛔ RE-WEIGHTED AGAIN 2026-09-02, BECAUSE 1-IN-8 WAS STILL TOO MANY AND THE FIRST FIX HAD
    // MEASURED THE WRONG THING. The note above counted `reach` and stopped there, but `guard` ALSO
    // put an arm out at 76 degrees, so the pool was really 2-in-8 arms-out, not 1-in-8 - and a
    // deterministic seed is free to clump them. It did: on the 2026-09-02 crowd sheet SIX of the
    // eight figures in the top row had a horizontal arm while rows two and three, which drew mostly
    // stand and walk, read as an actual village. The tell was that one row looked like people and
    // the other two rows of the same sheet looked like scarecrows.
    //
    // ⭐ A CROWD IS MOSTLY AT REST. 2 of 14 rather than 2 of 8, which puts the expected count of
    // arms-out figures on a 24-person village at about three rather than six, and leaves both poses
    // in the pool so the sheet still shows the corpus is not two poses wide.
    var _pose = rai_pick(_st, ["stand", "stand", "stand", "stand", "stand",
                               "walk", "walk", "walk", "walk",
                               "sit", "sit",
                               "guard", "reach", "reach"]);

    var _body = rai_pick(_st, _a.body);
    var _legs = rai_pick(_st, _a.legs);
    var _outer = (rai_rng_next(_st) < _a.outer_chance) ? rai_pick(_st, _a.outer) : undefined;
    var _head = rai_pick(_st, _a.head);
    var _waist = (rai_rng_next(_st) < 0.45) ? rai_pick(_st, _a.waist) : undefined;
    var _front = (rai_rng_next(_st) < 0.40) ? rai_pick(_st, _a.front) : undefined;
    var _arm = (rai_rng_next(_st) < _a.armour_chance) ? rai_pick(_st, _a.armour) : undefined;

    var _worn = [];
    // ⚠️ LEGS FIRST, and it is not cosmetic: rai_outfit_resolve sorts by layer band anyway, but the
    // equip ORDER is the tiebreak within a band, so a stable order here is what makes a seed
    // reproduce exactly.
    if (!is_undefined(_legs))  array_push(_worn, rai_item("cloth", _legs,  rai_pick(_st, _a.cloth)));
    if (!is_undefined(_body))  array_push(_worn, rai_item("cloth", _body,  rai_pick(_st, _a.cloth)));
    if (!is_undefined(_arm))   array_push(_worn, rai_item("armour", _arm,
                                   (_arm == "leather") ? rai_pick(_st, ["oxhide", "boiled_leather", "buckskin"])
                                                       : rai_pick(_st, _a.metal)));
    if (!is_undefined(_outer)) array_push(_worn, rai_item("cloth", _outer, rai_pick(_st, _a.cloth)));
    if (!is_undefined(_front)) array_push(_worn, rai_item("cloth", _front, rai_pick(_st, _a.cloth)));
    if (!is_undefined(_waist)) array_push(_worn, rai_item("cloth", _waist, rai_pick(_st, _a.cloth)));
    if (!is_undefined(_head))  array_push(_worn, rai_item("cloth", _head,  rai_pick(_st, _a.cloth)));

    // Skin is drawn from a narrow band of the hide materials. Deliberately narrow: this product
    // does not sell faces or identity (rai_armature's header - the body is a mannequin), and a wide
    // skin range on a mannequin reads as a bug rather than as diversity.
    var _skin = rai_pick(_st, ["buckskin", "suede", "oxhide", "shearling"]);

    // ⛔ HAIR IS PICKED LAST, AND THE POSITION IS THE POINT. The pick sequence above is published:
    // inserting a draw anywhere inside it re-rolls every figure in every crowd anyone has already
    // seeded. Appending at the END leaves all nine earlier picks reading exactly the same stream
    // values they always did, so an existing seed keeps its clothes and gains a head.
    //
    // ⚠️ `bald` is weighted by appearing once in eight; the pool is a LIST rather than a call to
    // rai_hair_styles_all() so the crowd's mix can be tuned without changing the corpus count, and
    // so that a style added to the product does not silently reweight every village in a buyer's
    // save file.
    var _hair_style = rai_pick(_st, ["crop", "crop", "bob", "long", "bound", "braid", "wild",
                                     "tonsure", "bald"]);
    // ⛔ NO NEAR-WHITE IN THE HAIR POOL. `shearling` sits at L 0.760 and the skin pool draws from
    // the same four hides, so a shearling head of hair on a shearling or buckskin face is two pale
    // shapes with a hairline between them - which reads as BALD, not as grey. Three of the
    // twenty-four on the crowd sheet looked shaved when they were not. `felt` and `fur` carry the
    // grey and mousy end without colliding with any skin the cast can pick.
    // ⛔ AND NO DYE COLOURS EITHER. `madder` is a strong red and `saffron` a strong yellow - they are
    // what a cloak is dyed, not what hair grows. Laid over a smooth skull at crowd scale they read as
    // a knitted cap and a gold bowl helmet rather than as a head of hair, and on the 2026-09-02 crowd
    // bake four of the twenty-four villagers looked like they were wearing hats. MEASURED by looking
    // at the sheet. `suede` and `sackcloth` carry the mousy and ashen ends the pool was short of.
    //
    // ⚠️ SWAPPING ENTRIES IS SAFE FOR EXISTING SEEDS AND ADDING ONE WOULD NOT BE. rai_pick consumes
    // exactly one draw whatever the array length, so every earlier pick reads the same stream value
    // it always did and a buyer's saved village keeps its clothes; only the hair colour moves.
    var _hair_mat = rai_pick(_st, ["charcoal", "boiled_leather", "oxhide", "wool", "buckskin",
                                   "suede", "sackcloth", "felt", "fur"]);

    return { build: _build, pose: _pose, worn: _worn, skin: _skin, archetype: _arch,
             hair: { style: _hair_style, material: _hair_mat } };
}

/// A whole crowd.
///
/// The archetype mix is itself seeded, so "a village" and "a garrison" differ in their PROPORTIONS
/// as well as in their members - which is most of what makes two crowds read as two places.
///
/// @param {String} _crowd seed string
/// @param {Real} _n how many members
/// @param {Array} _mix archetype ids to draw from, or undefined for a village mix
/// @returns {Array} members
function rai_cast(_crowd, _n, _mix) {
    var _pool = is_undefined(_mix)
        ? ["villager", "villager", "villager", "labourer", "labourer", "merchant", "priest", "guard"]
        : _mix;
    var _out = [];
    var _i;
    for (_i = 0; _i < _n; _i++) {
        // A SECOND, INDEPENDENT stream for the archetype choice. Sharing the member stream would
        // mean changing the mix re-rolls every member's clothes as well as their class.
        var _st = rai_rng(rai_hash32(_crowd + "@" + string(_i)));
        array_push(_out, rai_cast_member(_crowd, _i, rai_pick(_st, _pool)));
    }
    return _out;
}

/// Turn a member into a drawable figure.
///
/// A one-line wrapper, and it exists so the demo and the store bake call the same path a buyer
/// would rather than assembling the arguments themselves - which is how a demo ends up proving
/// something the shipped API cannot do.
///
/// @param {Struct} _m from rai_cast_member
/// @returns {Struct} from rai_figure
function rai_cast_figure(_m) {
    // ⚠️ `hair` is read through struct_exists rather than assumed, because a buyer's own saved
    // member structs predate it and a hard read would throw on load rather than degrade to a bare
    // head. This is the same reason rai_shape_of reads `corner` that way.
    var _h = variable_struct_exists(_m, "hair") ? _m.hair : undefined;
    return rai_figure(_m.build, _m.pose, _m.worn, _m.skin, _h);
}
