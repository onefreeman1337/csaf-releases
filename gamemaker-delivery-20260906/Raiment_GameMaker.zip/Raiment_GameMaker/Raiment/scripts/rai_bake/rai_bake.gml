/// RAIMENT - rai_bake. The store sheets, rendered BY THE PRODUCT.
///
/// ⭐ EVERY IMAGE ON THE LISTING IS DRAWN BY THE CODE BEING SOLD. Not a screenshot of a previewer,
/// not a mock-up in another tool: the executable Igor builds renders these onto surfaces and saves
/// them. A gallery rendered by a side previewer is a picture of a RE-IMPLEMENTATION - this wing
/// measured that on a previous product, where the previewer had a defect that was invisible in the
/// previewer and plainly visible in engine.
///
/// ============================================================================================
/// ⛔ A RETURNED `y` IS ONE NUMBER AND IT IS BLIND IN TWO DIRECTIONS. MEASURE THE INK.
/// ============================================================================================
///
/// Each sheet returns the y it finished at, and that only answers "did the LAST thing drawn fall
/// off the BOTTOM". It cannot see horizontal overflow and it cannot see emptiness. On a sibling
/// product both blind spots shipped while the sheet reported ok: body copy ran off the RIGHT EDGE
/// cut mid-word, and about 35% of a surface was bare.
///
/// So rai_bk_one reads the RENDERED PIXELS back out of the surface and takes an ink bounding box.
/// TWO boxes, not one: `full` for the clip test, and `content` measured below the title rule for
/// the coverage floors - otherwise a full-width rule under the title satisfies the width floor on
/// the picture's behalf and the check quietly stops working.
///
/// ⚠️ THE SCAN STEPS y BY 1 AND x BY 2. A 1px feature on an odd row - a hairline rule under a title
/// is exactly that shape - is walked past by an even-only y scan, and a clipped hairline is
/// precisely the kind of thing that lands on one row. Nothing in this package draws a 1px-wide
/// VERTICAL feature, so the x stride is safe.
///
/// ⚠️ AND A FLAT FILL CLOSE TO THE PAGE COLOUR IS NOT COUNTED AS INK AT ANY STRIDE. A panel running
/// off the bottom in a colour within tolerance of the page reports ok. The answer is not a tighter
/// tolerance: it is to SOLVE such panels' dimensions from the space available so they cannot clip
/// by construction, which is what the sheets below do.
///
/// ⚠️ WHEN THE RETURNED y AND THE INK BOX DISAGREE, THE INK BOX IS RIGHT. Arithmetic is a claim;
/// pixels are evidence.

#macro RAI_SHEET_W 1600
#macro RAI_SHEET_H 1000

/// ⛔ THE POSE SHEET IS SHORTER THAN THE REST, AND THAT IS ARITHMETIC RATHER THAN TASTE.
///
/// Five figures side by side, two of them with a horizontal arm, do not fit 1600px wide at the
/// height the other sheets use: rai_bk_lineup correctly shrinks the whole row to fit the WIDTH, and
/// the leftover height then has nothing in it. On the 2026-09-02 bake that was 250px of black page
/// under the captions - contentH 0.652 against the sheet floor of 0.80, flagged by the bake's own
/// report. Padding it with something would be filler; the honest answer is a page as tall as its
/// content needs, and a gallery is perfectly happy with one image of a different height.
///
/// ⚠️ IT IS NOT A FREE KNOB. Making it shorter still shrinks the figures, because the scale comes
/// from the height budget; making it taller brings the dead band back. 780 is where the width-driven
/// shrink is about 1.0, measured off the previous bake's own numbers.
#macro RAI_POSE_H 780
#macro RAI_COVER_W  630
#macro RAI_COVER_H  500

/// The pair the materials sheet cites as "close in colour, nothing alike". Named here, ONCE, so the
/// caption reads their real numbers out of rai_material_def and rai_selftest can assert the claim
/// against the same two names. MEASURED 2026-09-02: wool is L 0.560 / C 0.048 / h 46, nap, heavy;
/// sackcloth is L 0.580 / C 0.052 / h 68, weave, soft - 0.02 apart in lightness with a different
/// surface character and a different drape, which is exactly the point the sheet is making.
#macro RAI_BK_PAIR_A "wool"
#macro RAI_BK_PAIR_B "sackcloth"

function rai_bk_page() { return rai_oklch(0.155, 0.010, 268); }
function rai_bk_ink()  { return rai_oklch(0.905, 0.010, 268); }
function rai_bk_dim()  { return rai_oklch(0.575, 0.012, 268); }
function rai_bk_rule() { return rai_oklch(0.310, 0.014, 268); }
function rai_bk_well_col() { return rai_oklch(0.198, 0.010, 268); }

/// A sheet heading. Returns the y the content may start at.
///
/// ⛔ rai_text_label DRAWS AT THE x IT IS GIVEN - it does not centre on it. Pass a LEFT edge; a
/// sibling product shipped titles running off the right margin because the page midpoint was
/// passed here and the short titles happened to look deliberately centred.
function rai_bk_head(_title, _sub, _y, _w) {
    rai_text_label(_title, 60, _y, _w - 120, 46, rai_bk_page(), rai_bk_ink());
    var _yy = _y + 58;
    if (_sub != "") {
        rai_text_body(_sub, 60, _yy, _w - 420, 19, rai_bk_dim());
        _yy += 30;
    }
    draw_set_colour(rai_bk_rule());
    draw_rectangle(60, _yy + 14, _w - 60, _yy + 15, false);
    return _yy + 40;
}

/// A recessed cell for a figure.
///
/// ⭐ GRADED, NOT FLAT, AND THAT IS THE CHEAPEST DEPTH IN THE WHOLE GALLERY. A flat rectangle behind
/// a figure is a CARD, and a figure on a card is a sticker however well the figure itself is lit -
/// which is most of the distance between these sheets and the two the operator set as the bar. What
/// Meridian does with a glow behind every node, this does with a floor: the cell is brightest at the
/// top where the lamp is (rai_relief points it up and to the left, and the figures in the cell are
/// lit by that same lamp) and falls away to a deep floor the contact shadow can sit on.
///
/// ⛔ THE TOP TONE DOES NOT MOVE, AND THAT IS DELIBERATE RATHER THAN TIMID. Internal_Ops/_dead_space.js
/// separates figure ink from well fill with a threshold measured BETWEEN the two (well 22, ink 26 in
/// 8-bit grey), so brightening the well past that threshold would make the instrument read the cell's
/// own top as figure ink and report every sheet as perfectly filled - a measuring tool silently
/// returning the answer you want. The gradient therefore runs DOWNWARD from the tone the well always
/// had, which changes nothing any instrument is calibrated against.
function rai_bk_well(_x, _y, _w, _h) {
    var _n = 26;
    for (var _i = 0; _i < _n; _i++) {
        var _t = _i / (_n - 1);
        var _L = lerp(0.198, 0.148, power(_t, 0.80));
        draw_set_colour(rai_oklch(_L, 0.012, 268));
        // +1 on the bottom edge so rounding cannot leave a page-coloured hairline between bands.
        draw_rectangle(_x, _y + _h * (_i / _n), _x + _w, _y + _h * ((_i + 1) / _n) + 1, false);
    }
    draw_set_colour(rai_bk_rule());
    draw_rectangle(_x, _y, _x + _w, _y + _h, true);
}

/// ⭐ A CONTACT SHADOW, WHICH IS WHAT PUTS A FIGURE ON THE FLOOR INSTEAD OF IN FRONT OF A WALL.
///
/// ⛔ EVERY FIGURE ON EVERY SHEET WAS FLOATING UNTIL 2026-09-02. A well is a flat rectangle and a
/// figure drawn inside it touches nothing: the eye reads the pair as a sticker on a card, and no
/// amount of shading ON the figure fixes that, because the missing information is about the space
/// AROUND it. Gate 1's holdsUpBeside answer compared these sheets to Meridian, where the depth cue
/// is a glow behind every node - the same trick, from the other direction.
///
/// Three nested ellipses rather than one: a single hard oval is a puddle, and GML's draw_ellipse
/// takes no falloff. The darkest is smallest and sits right under the soles; each ring out steps
/// back toward the well tone, which is a two-stop gradient and enough at this size.
///
/// ⚠️ IT IS DRAWN BEFORE THE FIGURE AND AFTER THE WELL. Between those two and nowhere else - over
/// the figure it is a stain, under the well it does not exist.
///
/// @param {Real} _cx centre of the figure, in page pixels
/// @param {Real} _y the floor line the figure stands on
/// @param {Real} _w how wide the shadow spreads
function rai_bk_shadow(_cx, _y, _w) {
    // ⚠️ WIDEST AND LIGHTEST FIRST. Drawn the other way round the small dark core is painted over
    // by the broad pale ring and the whole thing reads as one flat oval - which is the puddle this
    // is written to avoid.
    // ⚠️ DARKER THAN THE WELL'S FLOOR, WHICH IS NOW 0.148 RATHER THAN A FLAT 0.198. Written against
    // the old flat well these tones sat at and just under it, so on a graded well the widest ring
    // would have been LIGHTER than the floor it was cast on - a shadow that glows.
    var _t = [0.138, 0.126, 0.112];
    var _k = [1.00, 0.70, 0.42];
    for (var _i = 0; _i < 3; _i++) {
        draw_set_colour(rai_oklch(_t[_i], 0.010, 268));
        draw_ellipse(_cx - _w * _k[_i], _y - _w * _k[_i] * 0.19,
                     _cx + _w * _k[_i], _y + _w * _k[_i] * 0.19, false);
    }
}

/// The ink bounding box over the current render target.
function rai_bk_ink_bounds(_w, _h, _contentY, _reuse) {
    // ⛔ THE BUFFER IS PASSED IN NOW. See rai_bk_one's header: creating a 6.4 MB buffer and a 6.4 MB
    // surface per sheet and freeing both is 12.8 MB of churn nine times over, and it ran the runtime
    // out of memory mid-gallery. Falls back to allocating its own if the caller hands in nothing, so
    // the function is still usable on its own.
    var _own = is_undefined(_reuse) || !buffer_exists(_reuse);
    var _buf = _own ? buffer_create(_w * _h * 4, buffer_fixed, 1) : _reuse;
    buffer_get_surface(_buf, surface_get_target(), 0);
    var _pg = rai_bk_page();
    var _pr = colour_get_red(_pg), _pgn = colour_get_green(_pg), _pb = colour_get_blue(_pg);

    var _fx0 = _w, _fy0 = _h, _fx1 = -1, _fy1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;
    var _ink = 0;

    for (var _y = 0; _y < _h; _y++) {
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = (_y * _w + _x) * 4;
            var _r = buffer_peek(_buf, _o, buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b = buffer_peek(_buf, _o + 2, buffer_u8);
            if (abs(_r - _pr) <= 10 && abs(_g - _pgn) <= 10 && abs(_b - _pb) <= 10) continue;
            _ink += 1;
            if (_x < _fx0) _fx0 = _x;
            if (_x > _fx1) _fx1 = _x;
            if (_y < _fy0) _fy0 = _y;
            if (_y > _fy1) _fy1 = _y;
            if (_y >= _contentY) {
                if (_x < _cx0) _cx0 = _x;
                if (_x > _cx1) _cx1 = _x;
                if (_y < _cy0) _cy0 = _y;
                if (_y > _cy1) _cy1 = _y;
            }
        }
    }
    if (_own) buffer_delete(_buf);
    return { full: [_fx0, _fy0, _fx1, _fy1], content: [_cx0, _cy0, _cx1, _cy1], ink: _ink };
}

/// ============================================================================================
/// ONE FIGURE INTO A CELL
/// ============================================================================================

/// Draw a dressed figure into a rect, and return the part count so the caller can see that work
/// actually happened.
///
/// ⛔ RETURNS A COUNT, NOT A VERDICT (master §2b rule 2). A sheet that reports "drew 12 cells" while
/// every cell drew zero parts is the exact shape this wing keeps recording, and a count is the only
/// thing that distinguishes the two.
///
/// @returns {Real} parts drawn
function rai_bk_figure(_fig, _x, _y, _w, _h) {
    rai_render_in_rect_tight(_fig.parts, _fig.palette, _x, _y, _w, _h, undefined);
    return array_length(_fig.parts);
}

/// ⭐⭐ A ROW OF FIGURES AT ONE SCALE, ON ONE FLOOR. Returns the y below the captions.
///
/// ⛔⛔ rai_bk_figure ABOVE FITS EACH FIGURE TO ITS OWN CELL, AND ON A COMPARISON SHEET THAT IS A
/// LIE THE PICTURE TELLS ABOUT THE PRODUCT. rai_render_in_rect_tight preserves aspect and fits the
/// figure's own bounding box, so a WIDER figure is scaled DOWN to fit the column - and on sheet 1,
/// whose entire claim is "one robe, five builds", `broad` was drawn about two thirds the size of
/// the others. The caption under it read "chest half-width, slight 0.0706 broad 0.0974, a
/// difference of 37.9%" while the image showed the broad figure as the SMALLEST person on the page.
/// MEASURED 2026-09-02 by looking at the baked sheet; the ink floors passed it, because a bounding
/// box has no opinion about what it is being compared to.
///
/// ⭐ ONE SCALE, ONE FLOOR, CELLS CUT TO THE SPECIMEN. Take the scale from the tallest box, give
/// each figure a column as wide as it actually needs, share the leftover width out as air, and
/// stand every figure's box bottom on the same line. Builds then differ in height because their
/// STATURE differs, which is the true thing the sheet is claiming, and a pose with a horizontal arm
/// gets a wider column instead of a smaller body.
///
/// ⚠️ THE WELL IS THE SCALED FIGURE HEIGHT PLUS PADDING, NOT THE HEIGHT BUDGET. When the row is too
/// wide for the page every figure shrinks; if the wells stay at full height the difference becomes
/// dead air above every head, which is the defect this used to have on sheet 7 (34-40% of every
/// cell, measured).
///
/// @param {Array} _figs figures from rai_figure
/// @param {Array} _caps one caption per figure
/// @param {Real} _x left edge of the row
/// @param {Real} _y top of the wells
/// @param {Real} _w width available
/// @param {Real} _h height budget for the wells
/// @returns {Real} the y below the captions
function rai_bk_lineup(_figs, _caps, _x, _y, _w, _h) {
    var _cols = array_length(_figs);
    var _i;
    var _mh = 0.0001;
    var _bb;
    for (_i = 0; _i < _cols; _i++) {
        _bb = rai_render_bounds(_figs[_i].parts);
        _mh = max(_mh, _bb[3] - _bb[1]);
    }
    var _ih = _h - 24;
    var _s = _ih / _mh;
    var _gap = 26;
    var _wid = array_create(_cols);
    var _needed = 0;
    for (_i = 0; _i < _cols; _i++) {
        _bb = rai_render_bounds(_figs[_i].parts);
        _wid[_i] = (_bb[2] - _bb[0]) * _s;
        _needed += _wid[_i];
    }
    var _avail = _w - _gap * (_cols + 1);
    if (_needed > _avail) {
        var _k = _avail / _needed;
        _s *= _k;
        _ih *= _k;
        for (_i = 0; _i < _cols; _i++) _wid[_i] *= _k;
        _needed = _avail;
    }
    var _slack = (_avail - _needed) / _cols;
    var _wellh = _ih + 24;

    var _at = _x + _gap;
    for (_i = 0; _i < _cols; _i++) {
        var _cellw = _wid[_i] + _slack;
        rai_bk_well(_at - _gap * 0.4, _y, _cellw + _gap * 0.8, _wellh);
        // The floor is shared, so the shadow goes on the floor line rather than under each figure's
        // own box - a seated pose whose box bottom rises would otherwise take its shadow up with it.
        rai_bk_shadow(_at + _cellw * 0.5, _y + _wellh - 16,
                      _figs[_i].arm.w_shoulder * _s * 1.35);
        _bb = rai_render_bounds(_figs[_i].parts);
        var _px = _at + _cellw * 0.5 - ((_bb[0] + _bb[2]) * 0.5) * _s;
        var _py = _y + _wellh - 14 - _bb[3] * _s;
        rai_render_parts(_figs[_i].parts, _figs[_i].palette, _px, _py, _s, 0, _s, undefined);
        rai_bk_caption(_caps[_i], _at, _y + _wellh + 10, _cellw);
        _at += _cellw + _gap;
    }
    return _y + _wellh + 40;
}

/// A caption under a cell.
function rai_bk_caption(_text, _x, _y, _w) {
    draw_set_font(fnt_raiment);
    draw_set_colour(rai_bk_dim());
    draw_set_halign(fa_center);
    draw_text(_x + _w * 0.5, _y, _text);
    draw_set_halign(fa_left);
}

/// ============================================================================================
/// SHEET 1 - THE DRAPE PROOF. This is the product's argument, and it goes first.
/// ============================================================================================

/// ⭐ THE ONE SHEET THAT CANNOT BE FAKED WITH AN ATLAS. The SAME garment, in the SAME material, on
/// five different builds - so the silhouette changes and the cloth changes with it. A layered PNG
/// has one shape; this is five, computed. A buyer who understands this image does not need the
/// rest of the page.
function rai_bk_drape(_w, _h) {
    var _y = rai_bk_head("THE GARMENT IS COMPUTED FROM THE BODY",
        "One robe. One material. Five builds. The cloth is not scaled to fit the figure - it is "
        + "sampled off it, so the hem, the fullness and every fold move with the body underneath.",
        44, _w);

    var _builds = rai_builds_all();
    var _n = array_length(_builds);
    var _ch = _h - _y - 110;
    var _i;
    // ⚠️ ONE SCALE ACROSS ALL FIVE - see rai_bk_lineup. Fitted per cell, `broad` came out the
    // SMALLEST figure on a sheet whose caption says broad is 37.9% wider than slight.
    var _figs = array_create(_n);
    for (_i = 0; _i < _n; _i++) {
        _figs[_i] = rai_figure(_builds[_i], "stand",
                               [rai_item("cloth", "robe", "madder")], "buckskin",
                               { style: "crop", material: "boiled_leather" });
    }
    rai_bk_lineup(_figs, _builds, 60, _y, _w - 120, _ch);

    // The measured line. Derived from the suite's own figure so the sheet cannot claim a number the
    // code does not produce.
    draw_set_font(fnt_raiment);
    draw_set_colour(rai_bk_ink());
    var _s = rai_armature("slight", "stand");
    var _b = rai_armature("broad", "stand");
    var _yc = lerp(_s.y_shoulder, _s.y_waist, 0.4);
    var _ws = rai_body_halfwidth(_s, _yc);
    var _wb = rai_body_halfwidth(_b, _yc);
    draw_text(60, _y + _ch + 44,
        "Chest half-width, slight " + string_format(_ws, 1, 4)
        + "  broad " + string_format(_wb, 1, 4)
        + "  -  a difference of " + string_format((_wb / max(0.0001, _ws) - 1) * 100, 1, 1)
        + "%, and every garment on this page follows it.");
    return _y + _ch + 70;
}

/// ============================================================================================
/// SHEET 2 - THE CROWD
/// ============================================================================================

/// ⭐ THE VOLUME CLAIM, SHOWN RATHER THAN STATED. Twenty-four figures from one seed. Nobody drew
/// them; nobody could ship them as sprites. rai_cast's header states why they are drawn from
/// ARCHETYPES rather than uniformly at random: random is not variety, it is noise.
function rai_bk_crowd(_w, _h) {
    var _y = rai_bk_head("A VILLAGE, FROM ONE SEED",
        "Twenty-four people, each with their own build, pose, wardrobe and materials, drawn from "
        + "one string. Change the string and it is a different village. Add a person and nobody "
        + "already there changes clothes.",
        44, _w);

    var _cols = 8;
    var _rows = 3;
    var _cw = (_w - 120) / _cols;
    var _ch = (_h - _y - 60) / _rows;
    var _cast = rai_cast("greenhollow", _cols * _rows, undefined);
    var _drawn = 0;
    var _i;
    for (_i = 0; _i < array_length(_cast); _i++) {
        var _cx = 60 + (_i % _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        rai_bk_well(_cx + 4, _cy + 4, _cw - 8, _ch - 26);
        _drawn += rai_bk_figure(rai_cast_figure(_cast[_i]), _cx + 12, _cy + 10, _cw - 24, _ch - 44);
        rai_bk_caption(_cast[_i].archetype, _cx + 4, _cy + _ch - 22, _cw - 8);
    }
    global.rai_bk_drawn = _drawn;
    return _y + _rows * _ch + 10;
}

/// ============================================================================================
/// SHEET 3 - THE CLOTH FAMILIES
/// ============================================================================================
function rai_bk_cloth(_w, _h) {
    var _fams = rai_garment_families();
    var _y = rai_bk_head("NINE CLOTH FAMILIES",
        "Each one is a CUT and a drape behaviour, not a picture: a neckline, a hem height, a sleeve "
        + "length and how much material it carries. The folds are computed from the drape, which is "
        + "why they move when the body does instead of sitting on it like a decal.",
        44, _w);

    var _cols = 5;
    var _rows = 2;
    var _cw = (_w - 120) / _cols;
    var _ch = (_h - _y - 60) / _rows;
    var _arm = rai_armature("average", "stand");
    var _i;
    for (_i = 0; _i < array_length(_fams); _i++) {
        var _cx = 60 + (_i % _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        rai_bk_well(_cx + 6, _cy + 4, _cw - 12, _ch - 30);
        var _fig = rai_figure("average", "stand",
                              [rai_item("cloth", _fams[_i], "woad")], "buckskin",
                              { style: "crop", material: "boiled_leather" });
        rai_bk_figure(_fig, _cx + 16, _cy + 12, _cw - 32, _ch - 50);
        rai_bk_caption(_fams[_i], _cx + 6, _cy + _ch - 26, _cw - 12);
    }
    return _y + _rows * _ch + 10;
}

/// ============================================================================================
/// SHEET 4 - THE ARMOUR FAMILIES
/// ============================================================================================
function rai_bk_armour(_w, _h) {
    var _fams = rai_armour_families();
    var _y = rai_bk_head("SIX ARMOUR FAMILIES, SIX CONSTRUCTIONS",
        "Not one shell in six colours. Plate is a few big surfaces with lit edges; mail hangs like "
        + "the heavy cloth it is and scallops at the hem; lamellar is laced courses of small "
        + "plates; brigandine is cloth over a rivet grid. The relief is drawn, not a texture.",
        44, _w);

    var _cols = 6;
    var _cw = (_w - 120) / _cols;
    var _ch = _h - _y - 80;
    var _mats = ["steel", "iron", "bronze", "oxhide", "blued_steel", "boiled_leather"];
    var _i;
    for (_i = 0; _i < array_length(_fams); _i++) {
        var _cx = 60 + _i * _cw;
        rai_bk_well(_cx + 6, _y, _cw - 12, _ch);
        // ⛔ STAND, NOT GUARD, AND THE REASON IS THE LAYOUT RATHER THAN THE POSE'S OWN MERIT.
        // `guard` puts the elbow at sh+el = 1.57 rad, i.e. the forearm dead horizontal, so the
        // figure's bounding box goes WIDE - and rai_render_in_rect_tight preserves aspect, so a wide
        // box dropped into a tall narrow column scales the whole figure DOWN to fit the width. That
        // cost twice: six identical arms sticking out as planks, and a quarter of every panel left
        // empty underneath them. MEASURED off this sheet 2026-09-02, by looking at it.
        // A standing figure's box is tall and narrow, which is the shape of the column, so the
        // armour is drawn LARGER and the construction - the thing this sheet exists to show - is
        // actually legible. Pose variety is sheet 7's job and it still shows all five.
        var _fig = rai_figure("broad", "stand",
                              // ⚠️ CHARCOAL TROUSERS, NOT WOOL. Wool sits at L 0.560 / hue 46 and
                              // buckskin skin at L 0.600 / hue 64 - four hundredths apart in
                              // lightness and eighteen degrees in hue - so on the first bakes of
                              // this sheet every figure appeared to be wearing no trousers at all.
                              // The material corpus is the sheet's subject elsewhere; here the job
                              // is to make the ARMOUR legible, and that needs the leg to read as
                              // clothed.
                              [rai_item("cloth", "trousers", "charcoal"),
                               rai_item("cloth", "tunic", "homespun"),
                               rai_item("armour", _fams[_i], _mats[_i])], "buckskin",
                              { style: "crop", material: "charcoal" });
        rai_bk_figure(_fig, _cx + 16, _y + 12, _cw - 32, _ch - 24);
        rai_bk_caption(_fams[_i] + " / " + _mats[_i], _cx + 6, _y + _ch + 10, _cw - 12);
    }
    return _y + _ch + 40;
}

/// ============================================================================================
/// SHEET 5 - THE MATERIALS
/// ============================================================================================
function rai_bk_materials(_w, _h) {
    var _mats = rai_materials_all();
    // ⛔ THE CAPTION USED TO NAME LINEN AND SILK AS THE CLOSE-IN-COLOUR PAIR, AND THE SHEET DIRECTLY
    // BELOW IT SHOWED A CREAM ROBE AND A PINK ONE. MEASURED off rai_material_def: linen is
    // L 0.780 / C 0.036 / h 78 and silk is L 0.720 / C 0.090 / h 320 - 242 degrees apart in hue with
    // two and a half times the chroma. It is a market claim the image refutes (master 2), and it was
    // a TYPED pair rather than a derived one, which is the wing's standing caption law.
    //
    // ⭐ THE PAIR AND ITS NUMBERS ARE BOTH READ OUT OF THE MATERIAL TABLE NOW, so the sentence cannot
    // survive a change to either material, and rai_selftest asserts that this pair really is close in
    // colour and different in character - the claim is under test rather than under review.
    var _pa = rai_material_def(RAI_BK_PAIR_A);
    var _pb = rai_material_def(RAI_BK_PAIR_B);
    var _y = rai_bk_head("THIRTY MATERIALS, AND NOT ONE OF THEM IS A HUE",
        "Every material is a five-stop ramp placed at ABSOLUTE lightness offsets, an ink chosen for "
        + "contrast against its own ground, and a SURFACE CHARACTER - weave, twill, nap, sheen, "
        + "quilt, ring, scale, rivet, tooling, wear. " + RAI_BK_PAIR_A + " and " + RAI_BK_PAIR_B
        + " sit " + string_format(abs(_pa.L - _pb.L), 1, 2) + " apart in lightness and are "
        + _pa.surface + " against " + _pb.surface + ", " + _pa.drape + " against " + _pb.drape + ".",
        44, _w);

    var _cols = 10;
    var _rows = 3;
    var _cw = (_w - 120) / _cols;
    var _ch = (_h - _y - 40) / _rows;
    var _i;
    for (_i = 0; _i < array_length(_mats); _i++) {
        var _cx = 60 + (_i % _cols) * _cw;
        var _cy = _y + floor(_i / _cols) * _ch;
        rai_bk_well(_cx + 4, _cy + 2, _cw - 8, _ch - 24);
        var _fig = rai_figure("average", "stand",
                              [rai_item("cloth", "coat", _mats[_i])], "buckskin",
                              { style: "crop", material: "oxhide" });
        rai_bk_figure(_fig, _cx + 10, _cy + 8, _cw - 20, _ch - 40);
        rai_bk_caption(_mats[_i], _cx + 4, _cy + _ch - 22, _cw - 8);
    }
    return _y + _rows * _ch + 10;
}

/// ============================================================================================
/// SHEET 6 - THE EQUIP MODEL
/// ============================================================================================

/// ⭐ THE SHEET THAT SAYS "SYSTEM" RATHER THAN "ART PACK", and wing CLAUDE.md §2 measures twice over
/// 646 and then 2,131 listings that the difference is the whole price band. Built up one slot at a
/// time: the same figure, with one more thing on it in each cell.
function rai_bk_equip(_w, _h) {
    var _y = rai_bk_head("EQUIPPING IS A MODEL, NOT A DRAW ORDER",
        "Each slot holds one item; each family declares a layer band; the worn set resolves to a "
        + "single ordered list once, and what is mostly hidden stops drawing its detail. Putting a "
        + "coat on takes the old coat off, because that is what equipping means.",
        44, _w);

    var _steps = [
        [],
        [rai_item("cloth", "trousers", "canvas")],
        [rai_item("cloth", "trousers", "canvas"), rai_item("cloth", "tunic", "linen")],
        [rai_item("cloth", "trousers", "canvas"), rai_item("cloth", "tunic", "linen"),
         rai_item("armour", "brigandine", "oxhide")],
        [rai_item("cloth", "trousers", "canvas"), rai_item("cloth", "tunic", "linen"),
         rai_item("armour", "brigandine", "oxhide"), rai_item("cloth", "sash", "madder")],
        [rai_item("cloth", "trousers", "canvas"), rai_item("cloth", "tunic", "linen"),
         rai_item("armour", "brigandine", "oxhide"), rai_item("cloth", "sash", "madder"),
         rai_item("cloth", "cloak", "wool")]
    ];
    var _caps = ["the mannequin", "+ trousers", "+ tunic", "+ brigandine", "+ sash", "+ cloak"];

    var _cols = 6;
    var _ch = _h - _y - 80;
    var _i;
    // ⛔ THE HAIR WAS `bound` IN `madder` AND IT WAS THE LOUDEST THING ON A SHEET ABOUT CLOTHES.
    // `bound` is a tight cap with its knot BEHIND the crown, so from the front it is a smooth dome
    // with no silhouette at all; in madder that is a bright red dome on top of a head, and all six
    // figures on the 2026-09-02 bake read as wearing a knitted beanie. Nothing was wrong with the
    // hair system - this sheet had picked the one combination that looks like a hat.
    var _figs = array_create(_cols);
    for (_i = 0; _i < _cols; _i++) {
        _figs[_i] = rai_figure("average", "stand", _steps[_i], "buckskin",
                               { style: "crop", material: "boiled_leather" });
    }
    return rai_bk_lineup(_figs, _caps, 60, _y, _w - 120, _ch);
}

/// ============================================================================================
/// SHEET 7 - THE POSES
/// ============================================================================================
function rai_bk_poses(_w, _h) {
    var _poses = rai_poses_all();
    var _y = rai_bk_head("FIVE AUTHORED POSES, AND THE CLOTH RE-SOLVES ON EACH",
        "A pose is a named set of joint angles, hand-authored. The garments are not re-drawn for "
        + "it - they are re-computed from the armature it produces, which is why a sleeve follows "
        + "a bent elbow instead of crossing it.",
        44, _w);

    // ⛔ THE COAT WAS HIDING THE THING THE SHEET IS ABOUT. `coat` hangs to the KNEE station, which is
    // a fixed landmark and does not move with the pose, so all five cells showed the same purple
    // column from the shoulder to mid-shin and the only visible difference between `stand`, `walk`
    // and `sit` was how tall the figure was. A seated figure under it is indistinguishable from a
    // short standing one, which is exactly how sheet 7 read on 2026-09-02.
    //
    // ⭐ A TUNIC ANSWERS BOTH HALVES OF THE CAPTION AND THE COAT ANSWERED NEITHER. Its hem is at the
    // thigh, so the raised knee and the separated shins of `sit` and the swinging leg of `walk` are
    // all visible; its sleeve reaches 0.55 of the arm, i.e. just PAST the elbow, which is where the
    // claim "a sleeve follows a bent elbow instead of crossing it" can actually be seen. The cloak
    // stays - it is the back slot, and it is what shows the drape re-solving behind the figure.
    var _worn = [rai_item("cloth", "trousers", "charcoal"),
                 rai_item("cloth", "tunic", "velvet"),
                 rai_item("cloth", "cloak", "tyrian")];
    var _cols = array_length(_poses);
    var _ch = _h - _y - 80;
    var _i;

    // ⛔ THE LAYOUT USED TO LIVE HERE IN FULL, AND SHEET 1 HAD A DIFFERENT ONE. Everything this
    // function had learned - one shared scale so a pose cannot change the figure's size, cells cut
    // to each specimen so a horizontal arm does not shrink everybody, a well sized to the SCALED
    // figure rather than to the height budget - was written against sheet 7 only. Sheet 1, whose
    // whole claim is "one robe, five builds", was still fitting each figure to its own cell and
    // therefore drawing the BROADEST build as the smallest person on the page.
    //
    // ⭐ TWO COPIES OF A LAYOUT IS HOW ONE OF THEM STAYS WRONG. It is rai_bk_lineup now, and the
    // receipts for every rule in it are in that function's header.
    var _figs = array_create(_cols);
    for (_i = 0; _i < _cols; _i++) {
        _figs[_i] = rai_figure("tall", _poses[_i], _worn, "suede",
                               { style: "long", material: "charcoal" });
    }
    return rai_bk_lineup(_figs, _poses, 60, _y, _w - 120, _ch);
}

/// ============================================================================================
/// THE COVER
/// ============================================================================================

/// ⚠️ A COVER IS NOT A SHEET AT A SMALLER SIZE. It is seen at thumbnail width in a browse grid, so
/// it carries THREE figures rather than twenty-four, and the type is set against a well rather than
/// over the picture.
function rai_bk_cover() {
    var _w = RAI_COVER_W;
    var _h = RAI_COVER_H;

    draw_set_font(fnt_raiment_title);
    rai_text_label("RAIMENT", 34, 26, _w - 68, 52, rai_bk_page(), rai_bk_ink());
    draw_set_font(fnt_raiment);
    draw_set_colour(rai_bk_dim());
    draw_text(36, 86, "characters that draw their own bodies and everything they wear");

    draw_set_colour(rai_bk_rule());
    draw_rectangle(34, 112, _w - 34, 113, false);

    var _y = 126;
    var _ch = 300;
    var _cw = (_w - 68) / 3;
    var _sets = [
        [rai_item("cloth", "robe", "tyrian"), rai_item("cloth", "hood", "velvet")],
        [rai_item("cloth", "trousers", "wool"), rai_item("cloth", "tunic", "homespun"),
         rai_item("armour", "plate", "steel")],
        [rai_item("cloth", "skirt", "saffron"), rai_item("cloth", "tunic", "linen"),
         rai_item("cloth", "apron", "canvas")]
    ];
    var _bl = ["tall", "broad", "slight"];
    // ⚠️ The armour figure stands. It carried `guard` and the horizontal forearm turned the plate
    // harness into a grey slab jutting out of the cell - on the ONE image most buyers ever see. Same
    // aspect-fit reason as the armour sheet. `walk` on the third keeps the row from going static.
    // ⚠️ ALL THREE STAND, AND THE VARIETY IS CARRIED BY BUILD AND WARDROBE INSTEAD. `walk` swings
    // the arm out, and on the third figure the half-sleeve ends mid-arm so the cell showed a pale
    // slab of linen with a bare forearm continuing from it at an angle - disjointed at cover size.
    // Pose variety is sheet 7's whole subject; the cover's job is to be legible in a browse grid at
    // thumbnail size, where three clean silhouettes in three different builds read better than one
    // clever pose. tall/broad/slight plus robe, plate harness and apron still make three
    // unmistakably different figures.
    var _ps = ["stand", "stand", "stand"];
    // Three different heads, because the cover is where a buyer decides whether this draws PEOPLE.
    // The hooded figure still gets hair: the cowl is an annulus now, so what shows through it is a
    // face with a hairline, which is exactly what the old filled-disc version could not do.
    //
    // ⛔ AND THE MATERIALS ARE NOT DECORATIVE. `madder` and `saffron` are a strong red and a strong
    // yellow, and a saturated primary laid over a smooth skull reads as a HAT at cover scale - on
    // the 2026-09-02 bake the armoured figure appeared to be wearing a red woollen cap and the
    // gowned one a gold bowl helmet, which on the one image most buyers ever see is the whole first
    // impression. Hair colours belong in the range hair actually comes in; the wardrobe is where the
    // saturated colour goes, and both of those garments already carry it.
    var _hairs = [
        { style: "long",  material: "charcoal" },
        { style: "wild",  material: "boiled_leather" },
        { style: "braid", material: "oxhide" }
    ];
    var _i;
    for (_i = 0; _i < 3; _i++) {
        var _cx = 34 + _i * _cw;
        rai_bk_well(_cx + 4, _y, _cw - 8, _ch);
        rai_bk_figure(rai_figure(_bl[_i], _ps[_i], _sets[_i], "buckskin", _hairs[_i]),
                      _cx + 12, _y + 10, _cw - 24, _ch - 20);
    }

    var _c = rai_corpus_count();
    draw_set_colour(rai_bk_ink());
    draw_text(36, _y + _ch + 18,
        string(_c.cloth_families + _c.armour_families) + " families  x  "
        + string(_c.materials) + " materials  x  " + string(_c.builds) + " builds");
    draw_set_colour(rai_bk_dim());
    draw_text(36, _y + _ch + 40, "pure GML, no sprites, no atlas");
    return _y + _ch + 62;
}

/// ============================================================================================
/// SHEET 0 - THE HERO
///
/// ⛔ EVERY OTHER SHEET IN THIS GALLERY IS A GRID OF EQUAL-WEIGHT CELLS, AND THAT WAS THE HONEST
/// ANSWER TO GATE 1's "does it hold up beside Sigil Core and Meridian". Opened side by side
/// 2026-09-02: both references have a FOCAL POINT - Sigil Core puts one glowing seal at the size of
/// a fist beside its list, Meridian lights one node and pins a detail panel to it - and Raiment had
/// no image in which anything was more important than anything else. The generation claim and the
/// volume claim were both stronger here; the picture craft was weaker, and it was weaker for one
/// structural reason rather than for taste.
///
/// ⭐ SO THIS SHEET IS A HIERARCHY, NOT ANOTHER CATALOGUE. One figure at nearly the full height of
/// the page - big enough that the fauld, the pauldron lames, the mail scallop and the weave of the
/// cloak are all legible - and beside it three quarter-height cells that each change EXACTLY ONE
/// ARGUMENT of the same rai_figure call. That is the product's actual sentence: the same line of
/// code, four times, with one word different.
///
/// ⚠️ THE HERO STANDS. `guard` and `reach` both throw a forearm horizontally, which at hero scale
/// puts a limb across the cell's own width and forces the whole figure smaller to fit it - the
/// aspect-fit reason the cover records for the same choice. A hero image is the one place where the
/// figure's SIZE is the point.
function rai_bk_hero(_w, _h) {
    var _y = rai_bk_head("ONE CALL, ONE FIGURE, AND EVERY THREAD OF IT COMPUTED",
        "The same rai_figure() call four times over, with one argument changed each time. Nothing "
        + "here is a sprite: the body is solved from the build, the garments are sampled off that "
        + "body, and the armour is built as the construction it actually is.",
        44, _w);

    var _hair = { style: "braid", material: "charcoal" };
    var _worn = [rai_item("cloth", "trousers", "charcoal"),
                 rai_item("cloth", "tunic", "madder"),
                 rai_item("armour", "plate", "steel"),
                 rai_item("cloth", "cloak", "tyrian")];

    // ⛔ THE COMPARISON CELLS ARE COLUMNS, NOT ROWS, AND THAT IS THE DIFFERENCE BETWEEN THIS SHEET
    // WORKING AND NOT. The first version stacked them as three wide, short cells down the right-hand
    // side. rai_bk_figure fits a figure by HEIGHT, and a standing person is about 0.30 as wide as
    // they are tall - so in a 740x250 cell each figure came out about 110px wide with 300px of black
    // page either side of it, three times over. The ink box passed at contentH 0.936 because it
    // spans the whole LAYOUT; roughly three quarters of the right-hand half of the page was empty.
    // This wing's standing law: a specimen's aspect must match its cell, or a tight fit manufactures
    // dead space - and the fix is the CELL, never the zoom.
    var _hx = 60;
    var _hw = 620;
    var _hh = _h - _y - 70;
    rai_bk_well(_hx, _y, _hw, _hh);
    rai_bk_figure(rai_figure("broad", "stand", _worn, "buckskin", _hair),
                  _hx + 18, _y + 16, _hw - 36, _hh - 32);
    draw_set_font(fnt_raiment);
    draw_set_colour(rai_bk_dim());
    draw_text(_hx + 4, _y + _hh + 16,
              "broad build  -  plate over a madder tunic  -  tyrian cloak");

    // -- THE THREE ONE-WORD CHANGES --------------------------------------------------------------
    //
    // ⚠️ EACH CELL CHANGES ONE ARGUMENT AND NOTHING ELSE, AND THE CAPTIONS SAY WHICH. A cell that
    // varied two things at once would be a prettier picture and a weaker argument - a buyer cannot
    // attribute a difference to a cause if two causes moved.
    var _cx = _hx + _hw + 32;
    var _gap = 28;
    var _cols = 3;
    var _cw = (_w - 60 - _cx - _gap * (_cols - 1)) / _cols;
    // The caption band is measured from the type size it is set in, not guessed: two wrapped lines
    // at 17px plus the leading under the cell.
    var _capH = 56;
    var _ch = _hh - _capH;

    var _bare = [];
    var _mailed = [rai_item("cloth", "trousers", "charcoal"),
                   rai_item("cloth", "tunic", "madder"),
                   rai_item("armour", "mail", "iron"),
                   rai_item("cloth", "cloak", "tyrian")];

    var _figs = [rai_figure("broad", "stand", _bare, "buckskin", _hair),
                 rai_figure("broad", "stand", _mailed, "buckskin", _hair),
                 rai_figure("slight", "stand", _worn, "buckskin", _hair)];
    var _caps = ["worn: []  -  the body the cloth is sampled off",
                 "plate -> mail  -  a construction, not a recolour",
                 "broad -> slight  -  every garment re-solves"];

    var _i;
    for (_i = 0; _i < _cols; _i++) {
        var _px = _cx + _i * (_cw + _gap);
        rai_bk_well(_px, _y, _cw, _ch);
        rai_bk_figure(_figs[_i], _px + 14, _y + 12, _cw - 28, _ch - 24);
        rai_text_body(_caps[_i], _px + 4, _y + _ch + 14, _cw - 8, 17, rai_bk_dim());
    }

    return _y + _hh + 40;
}

/// ============================================================================================
/// THE DEMO GIF
///
/// ⭐ WHAT IT SHOWS AND WHY. The strongest three seconds this product has is not motion - the poses
/// are authored, not animated - it is the same figure RE-DRAWN as the wardrobe changes underneath
/// it. So the loop equips one item at a time up to a full harness, then runs the whole armour
/// corpus through the same body, then strips back to the mannequin it started from. A viewer sees
/// one person being dressed, which is the product's actual sentence.
///
/// ⛔ FRAME NUMBERS ARE PADDED BY ARITHMETIC, NEVER BY REPLACING SPACES IN A FORMATTED STRING.
/// A sibling in this wing shipped `string_replace(string_format(_f, 3, 0), " ", "0")`, which turns
/// "  0" into "0 0" - one space replaced, not all - so every frame saved as `frame_0 0.png` and
/// ffmpeg found no sequence at all. The frame COUNT check upstream still read 44 of 44, because it
/// globbed and counted and every name was wrong.
///
/// ⚠️ THE SURFACE IS THE FIGURE'S OWN ASPECT, NOT A SQUARE. make_gif.ps1 must never upscale - this
/// wing measured the same 72 frames at 0.15 MB native and 0.84 MB at a 1.15x upscale, five and a
/// half times the bytes for a smaller picture - so the frames are rendered at the size they will be
/// shown and nothing resamples them.
function rai_bake_gif() {
    var _W = 460;
    var _H = 660;
    var _surf = surface_create(_W, _H);
    var _hair = { style: "braid", material: "charcoal" };
    var _skin = "buckskin";

    // The dressing sequence: each step is the FULL worn list at that moment, because rai_figure
    // takes a set rather than a diff.
    var _tr = rai_item("cloth", "trousers", "charcoal");
    var _tu = rai_item("cloth", "tunic", "madder");
    var _ck = rai_item("cloth", "cloak", "tyrian");

    var _sets = [];
    var _caps = [];
    array_push(_sets, []);                       array_push(_caps, "the body");
    array_push(_sets, [_tr]);                    array_push(_caps, "+ trousers");
    array_push(_sets, [_tr, _tu]);               array_push(_caps, "+ tunic");
    array_push(_sets, [_tr, _tu, _ck]);          array_push(_caps, "+ cloak");

    // ...then every armour family in turn, over the same clothes.
    var _fams = rai_armour_families();
    var _mats = ["steel", "iron", "bronze", "oxhide", "blued_steel", "boiled_leather"];
    var _i;
    for (_i = 0; _i < array_length(_fams); _i++) {
        array_push(_sets, [_tr, _tu, rai_item("armour", _fams[_i],
                                              _mats[_i mod array_length(_mats)]), _ck]);
        array_push(_caps, "+ " + _fams[_i]);
    }
    // ...and back to where it began, so the loop closes without a jump cut.
    array_push(_sets, [_tr, _tu, _ck]);          array_push(_caps, "+ cloak");
    array_push(_sets, [_tr, _tu]);               array_push(_caps, "+ tunic");
    array_push(_sets, [_tr]);                    array_push(_caps, "+ trousers");

    // ⚠️ EACH STEP IS HELD FOR SEVERAL FRAMES. At one frame per step the loop is a flicker; the eye
    // needs time to read what changed, and a GIF is judged on its SHAPE rather than its length.
    var _hold = 5;
    var _n = 0;
    var _s;
    for (_s = 0; _s < array_length(_sets); _s++) {
        var _fig = rai_figure("broad", "stand", _sets[_s], _skin, _hair);
        var _k;
        for (_k = 0; _k < _hold; _k++) {
            surface_set_target(_surf);
            draw_clear(rai_bk_page());
            rai_lamp_reset();
            rai_bk_well(10, 10, _W - 20, _H - 58);
            // ⛔ NOT rai_bk_figure. That calls rai_render_in_rect_TIGHT, which fits each figure to
            // its OWN bounding box - correct for a catalogue cell and catastrophic for an animation,
            // because the figure would grow and shrink between frames as the silhouette changes and
            // the loop would breathe instead of dressing. rai_render_in_rect takes its scale from
            // the RECT (rai_render_fit: s = min(w,h)), so every frame is drawn at the same size
            // about the same centre and the only thing that moves is the wardrobe.
            //
            // The rect is deliberately wider than the surface and centred on it: only cx, cy and
            // min(w,h) are read, so this asks for a 570px figure on a 460px page without the width
            // becoming the binding dimension.
            rai_render_in_rect(_fig.parts, _fig.palette,
                               (_W - 600) * 0.5, 30, 600, 570, 0, undefined);
            draw_set_font(fnt_raiment);
            draw_set_colour(rai_bk_dim());
            draw_set_halign(fa_center);
            draw_text(_W * 0.5, _H - 40, _caps[_s]);
            draw_set_halign(fa_left);
            surface_reset_target();

            // Zero-padded to three digits by ARITHMETIC. See the header.
            var _num = string(_n);
            while (string_length(_num) < 3) _num = "0" + _num;
            surface_save(_surf, "gif_" + _num + ".png");
            _n += 1;
        }
    }
    surface_free(_surf);

    var _f = file_text_open_write("rai_gif.json");
    file_text_write_string(_f, "{\"ran\":true,\"frames\":" + string(_n)
        + ",\"steps\":" + string(array_length(_sets))
        + ",\"hold\":" + string(_hold)
        + ",\"w\":" + string(_W) + ",\"h\":" + string(_H) + "}");
    file_text_close(_f);
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

/// Render one sheet, measure it, save it, and report what it actually contains.
/// ⛔⛔ THE SURFACE AND THE BUFFER ARE OWNED BY THE CALLER, AND THAT IS NOT A TIDINESS CHANGE - IT IS
/// WHY THE GALLERY FINISHES. This function used to `surface_create(1600,1000)` and
/// `buffer_create(6,400,000)` per sheet and free both at the end: 12.8 MB allocated and released
/// nine times in a few seconds. GameMaker does not release a surface's texture synchronously, so the
/// pool never caught up and the run died on the FIFTH sheet with
///     Memory allocation failed: Attempting to allocate 6400000 bytes
///     gml_Script_rai_bk_one <- gml_Script_rai_bake_store
/// MEASURED 2026-09-02, the first bake after a ninth sheet was added.
///
/// ⚠️ AND IT FAILED ALMOST SILENTLY, WHICH IS THE WORSE HALF. bake_store.ps1 printed `EXIT 0` and
/// `COLLECTED 4 sheet(s)`, because the crash handler ends the game cleanly and the collector copies
/// whatever is newer than the run - so `store_assets` was left holding FOUR fresh sheets and FIVE
/// stale ones, with nothing red anywhere. A partial gallery is exactly the shape a session ships
/// without noticing. The runner now asserts the sheet COUNT before collecting.
function rai_bk_one(_name, _w, _h, _fn, _contentY, _pool) {
    // Re-make the shared surface and buffer only when the sheet SIZE changes. A surface can also be
    // lost outside our control on a device reset, so its existence is re-checked every time rather
    // than assumed from the recorded size.
    if (_pool.w != _w || _pool.h != _h || !surface_exists(_pool.surf)) {
        if (surface_exists(_pool.surf)) surface_free(_pool.surf);
        if (buffer_exists(_pool.buf)) buffer_delete(_pool.buf);
        _pool.surf = surface_create(_w, _h);
        _pool.buf  = buffer_create(_w * _h * 4, buffer_fixed, 1);
        _pool.w = _w;
        _pool.h = _h;
    }
    var _surf = _pool.surf;
    var _buf = _pool.buf;

    surface_set_target(_surf);
    draw_clear(rai_bk_page());
    rai_lamp_reset();
    global.rai_bk_drawn = 0;

    var _endY = _fn();
    var _ib = rai_bk_ink_bounds(_w, _h, _contentY, _buf);
    rai_render_opaque(_w, _h);

    surface_reset_target();
    surface_save(_surf, _name + ".png");

    var _clipped = (_endY > _h) || (_ib.full[3] >= _h - 6) || (_ib.full[2] >= _w - 6)
                || (_ib.full[0] <= 5) || (_ib.full[1] <= 5);
    var _cw = (_ib.content[2] - _ib.content[0]) / _w;
    var _chh = (_ib.content[3] - _ib.content[1]) / max(1, _h - _contentY);

    // ⛔ THE INK FLOOR IS A FRACTION OF THE SHEET, NOT A COUNT. A literal count calibrated for a
    // 1600x1000 plate is the wrong question for a 630x500 cover: the same DENSITY of ink on a sheet
    // with a fifth of the pixels scores a fifth of the count and fails. 0.0075 reproduces the
    // wing's old threshold exactly at 1600x1000 and means the same thing at every size.
    return "{\"name\":\"" + _name + "\""
         + ",\"endY\":" + string(round(_endY))
         + ",\"ink\":" + string(_ib.ink)
         + ",\"fullBox\":[" + string(_ib.full[0]) + "," + string(_ib.full[1]) + ","
                            + string(_ib.full[2]) + "," + string(_ib.full[3]) + "]"
         + ",\"contentW\":" + string_format(_cw, 1, 3)
         + ",\"contentH\":" + string_format(_chh, 1, 3)
         + ",\"clipped\":" + (_clipped ? "true" : "false")
         + ",\"ok\":" + ((!_clipped && _cw >= 0.86 && _chh >= 0.80 && _ib.ink > 0.0075 * _w * _h)
                         ? "true" : "false")
         + "}";
}

/// Render the whole store gallery and write the report.
function rai_bake_store() {
    var _res = [];

    // ⛔ ONE SURFACE AND ONE BUFFER FOR THE WHOLE GALLERY, RE-MADE ONLY WHEN THE SHEET SIZE CHANGES.
    // See rai_bk_one's header for the crash this replaces. Three sizes are used - the cover, the
    // 1600x1000 sheets and the shorter pose sheet - so this allocates three times instead of nine.
    var _pool = { w: -1, h: -1, surf: -1, buf: -1 };

    // ⚠️ THE COVER'S contentY IS 120, matching its own title block. Measuring "content" below 150
    // on a 500px sheet would put the first row of figures partly into the header region and
    // understate the coverage the check is supposed to be reading.
    array_push(_res, rai_bk_one("cover", RAI_COVER_W, RAI_COVER_H,
        function() { return rai_bk_cover(); }, 120, _pool));

    array_push(_res, rai_bk_one("sheet_0_hero", RAI_SHEET_W, RAI_SHEET_H,
        function() { return rai_bk_hero(RAI_SHEET_W, RAI_SHEET_H); }, 150, _pool));
    array_push(_res, rai_bk_one("sheet_1_drape", RAI_SHEET_W, RAI_SHEET_H,
        function() { return rai_bk_drape(RAI_SHEET_W, RAI_SHEET_H); }, 150, _pool));
    array_push(_res, rai_bk_one("sheet_2_crowd", RAI_SHEET_W, RAI_SHEET_H,
        function() { return rai_bk_crowd(RAI_SHEET_W, RAI_SHEET_H); }, 150, _pool));
    // ⛔ READ IMMEDIATELY. rai_bk_one ZEROES this counter before every sheet, so reading it at the
    // end of the run reports the LAST sheet's value - which is zero, because only the crowd sheet
    // sets it. A count that is always zero is exactly the "green result, no work" shape §2b is
    // about, and it would have shipped a report claiming the crowd drew nothing.
    var _crowdParts = global.rai_bk_drawn;
    array_push(_res, rai_bk_one("sheet_3_cloth", RAI_SHEET_W, RAI_SHEET_H,
        function() { return rai_bk_cloth(RAI_SHEET_W, RAI_SHEET_H); }, 150, _pool));
    array_push(_res, rai_bk_one("sheet_4_armour", RAI_SHEET_W, RAI_SHEET_H,
        function() { return rai_bk_armour(RAI_SHEET_W, RAI_SHEET_H); }, 150, _pool));
    array_push(_res, rai_bk_one("sheet_5_materials", RAI_SHEET_W, RAI_SHEET_H,
        function() { return rai_bk_materials(RAI_SHEET_W, RAI_SHEET_H); }, 150, _pool));
    array_push(_res, rai_bk_one("sheet_6_equip", RAI_SHEET_W, RAI_SHEET_H,
        function() { return rai_bk_equip(RAI_SHEET_W, RAI_SHEET_H); }, 150, _pool));
    array_push(_res, rai_bk_one("sheet_7_poses", RAI_SHEET_W, RAI_POSE_H,
        function() { return rai_bk_poses(RAI_SHEET_W, RAI_POSE_H); }, 150, _pool));

    if (surface_exists(_pool.surf)) surface_free(_pool.surf);
    if (buffer_exists(_pool.buf)) buffer_delete(_pool.buf);

    var _c = rai_corpus_count();
    var _s = "{\"mode\":\"store\",\"sheetsExpected\":9"
           + ",\"clothFamilies\":" + string(_c.cloth_families)
           + ",\"armourFamilies\":" + string(_c.armour_families)
           + ",\"armourPieces\":" + string(_c.armour_pieces)
           + ",\"materials\":" + string(_c.materials)
           + ",\"outfits\":" + string(_c.outfits)
           + ",\"figures\":" + string(_c.figures)
           + ",\"crowdParts\":" + string(_crowdParts)
           + ",\"sheets\":[";
    var _k;
    for (_k = 0; _k < array_length(_res); _k++) {
        if (_k > 0) _s += ",";
        _s += _res[_k];
    }
    _s += "]}";
    var _f = file_text_open_write("rai_bake.json");
    file_text_write_string(_f, _s);
    file_text_close(_f);
}
