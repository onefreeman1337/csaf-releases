/// RAIMENT - rai_drape. Cloth that follows the body it is on.
///
/// ⭐ THIS IS THE PRODUCT. Everything else in the wardrobe is a client of this file.
///
/// WHY IT IS THE WHOLE ARGUMENT FOR BUYING THIS. Both GameMaker character-customisation incumbents
/// layer PRE-DRAWN sprites that the developer has to supply (measured live 2026-09-01: 2toes at
/// $5, "layering pre-drawn sprite assets"; ghostwolf-games at $9.99, "developers supply their own
/// character parts as sprites", last updated 31 October 2022). A layered PNG has ONE shape. It
/// cannot know how wide the body under it is, so every body it goes on has to be the same body.
///
///     A garment here is not a picture placed on a figure. It is a SURFACE COMPUTED FROM the
///     figure, so changing the build changes every garment on it, at runtime, at any size.
///
/// That is why this product replaces the atlas and not just the script.
///
/// ============================================================================================
/// THE MODEL
/// ============================================================================================
///
/// A garment is a CUT plus a DRAPE PROGRAM.
///
///   CUT     - where it starts and stops on the body (y0..y1), how open the neck is, how long the
///             sleeve runs. Authored per family in rai_garment / rai_armour.
///   DRAPE   - how far the cloth stands off the body, how much extra material it carries, and how
///             that material falls. Computed here, from rai_body_halfwidth.
///
/// ⛔ THICKNESS IS ABSOLUTE, FULLNESS IS PROPORTIONAL, AND CONFLATING THEM IS A BUG THIS FILE
/// EXISTS TO PREVENT. Cloth thickness is a PHYSICAL quantity - a wool coat stands about the same
/// distance off a broad chest as off a slight one. Fullness is a TAILORING quantity - a full robe
/// carries more material in proportion to the body. rai_geom's header states the inherited law: a
/// physical detail bounded only as a proportion is wrong on the largest thing you draw.
///
/// ⛔ AND THE OUTLINE IS SYSTEMATICALLY LARGER THAN THE BODY THAT MADE IT. Wing CLAUDE.md, measured
/// on Vestige: "ANCHORS INSIDE THE BOX DOES NOT MEAN STROKES INSIDE THE BOX - and the fix is not to
/// move the anchors." Drape offsets OUTWARD by construction, so anything asserting bounds here must
/// assert the STROKED bounds. rai_selftest does.
///
/// ⚠️ PURE. No draw calls, no engine state. This is the half of the product that can actually be
/// reasoned about, which matters because GML cannot be unit-tested outside the engine (wing SS3).

/// How many heights a garment panel is sampled at. Cloth is a curve, and a hem built from four
/// points has corners in it that read as a paper bag.
#macro RAI_DRAPE_STEPS 14

/// ============================================================================================
/// THE CORE SAMPLER
/// ============================================================================================

/// Half-width of the CLOTH at a height, given the body under it.
///
/// @param {Struct} _arm from rai_armature
/// @param {Real} _y height in unit space
/// @param {Real} _y0 top of the garment
/// @param {Real} _y1 bottom of the garment
/// @param {Struct} _d drape parameters {thickness, fullness, flare, cling}
/// @returns {Real} half-width of the cloth at that height
function rai_drape_halfwidth(_arm, _y, _y0, _y1, _d) {
    var _body = rai_body_halfwidth(_arm, _y);

    // How far down this garment we are, 0 at the top and 1 at the hem.
    var _t = clamp((_y - _y0) / max(0.00001, _y1 - _y0), 0, 1);

    // Material accumulates downward under its own weight: a robe is not equally full at the
    // shoulder and at the ankle. `flare` is how much of the fullness is spent at the hem.
    var _carried = _d.fullness * _arm.span * lerp(1 - _d.flare, 1, _t);

    // `cling` pulls the cloth back toward the body - a fitted jerkin clings, a cloak does not.
    var _stand = _d.thickness * (1 - _d.cling * 0.75);

    return _body + _stand + _carried;
}

/// Sample a garment panel into a closed ring that follows the body.
///
/// Walks the RIGHT side from the top down to the hem, crosses the hem, and walks the LEFT side back
/// up - so the ring is closed and wound consistently, which rai_relief needs in order to know which
/// way is out.
///
/// @param {Struct} _arm from rai_armature
/// @param {Real} _y0 top of the garment in unit space
/// @param {Real} _y1 bottom of the garment in unit space
/// @param {Struct} _d drape parameters {thickness, fullness, flare, cling}
/// @param {Real} _hem_sag how much the hem dips at the centre, in unit space; 0 is a straight hem
/// @returns {Array} closed ring of [x,y]
function rai_drape_ring(_arm, _y0, _y1, _d, _hem_sag) {
    var _sag = is_undefined(_hem_sag) ? 0 : _hem_sag;
    var _right = [];
    var _left = [];
    var _i;

    for (_i = 0; _i <= RAI_DRAPE_STEPS; _i++) {
        var _t = _i / RAI_DRAPE_STEPS;
        var _y = lerp(_y0, _y1, _t);
        var _w = rai_drape_halfwidth(_arm, _y, _y0, _y1, _d);
        array_push(_right, [_w, _y]);
        array_push(_left, [-_w, _y]);
    }

    // The hem. A garment hem is not a straight line across - it hangs lower where there is no leg
    // under it. Sampled as its own arc so it meets both sides exactly.
    var _hem = [];
    if (_sag != 0) {
        var _hw = rai_drape_halfwidth(_arm, _y1, _y0, _y1, _d);
        var _k;
        for (_k = 1; _k < 6; _k++) {
            var _u = _k / 6;
            var _x = lerp(_hw, -_hw, _u);
            // A cosine bulge: zero at both edges, maximum in the middle.
            array_push(_hem, [_x, _y1 + _sag * sin(_u * pi)]);
        }
    }

    var _ring = [];
    for (_i = 0; _i < array_length(_right); _i++) array_push(_ring, _right[_i]);
    for (_i = 0; _i < array_length(_hem); _i++) array_push(_ring, _hem[_i]);
    for (_i = array_length(_left) - 1; _i >= 0; _i--) array_push(_ring, _left[_i]);
    return _ring;
}

/// ============================================================================================
/// VOLUME - the shading that makes a panel cloth rather than a coloured shape
///
/// ⛔⛔ THE FIRST SIX STORE SHEETS SHIPPED WITH NONE OF THIS AND EVERY GARMENT WAS ONE FLAT COLOUR
/// WITH HAIRLINES ON IT. Read the drape sheet from 2026-09-02: five red robes, each a single
/// vermilion silhouette carrying six thin darker strokes. Nothing mechanical could see it - the
/// ink floors count a flat fill as ink, the turning and containment assertions are about the
/// outline, and the fold lines are genuinely there. It is a picture problem and the instrument is
/// the picture.
///
/// ⭐ CLOTH ON A BODY IS A TUBE, AND A TUBE HAS THREE ZONES. Wing CLAUDE.md, measured on Chitin:
/// a long form is "curved ACROSS its width, very nearly flat ALONG its length - which is why a
/// photograph of one has a bright side, a dark side and no highlight at either end." So the
/// shading is LATERAL: bands running the full height of the panel at fixed fractions of its own
/// half-width, which means they follow the silhouette exactly on every build, at every height,
/// with no second outline to keep in sync.
///
/// ⚠️ THE BANDS ARE STRIPS, NOT FANS. A band is a long thin quad following a curve; handed to
/// rai_render_fill it would be filled from its first point and span the curve.
/// ============================================================================================

/// One lateral shading band across a draped panel, as a triangle strip.
///
/// `_u0` and `_u1` are fractions of the panel's own half-width at each height: -1 is the left
/// edge, 0 the centre line, +1 the right edge.
///
/// @param {Struct} _arm from rai_armature
/// @param {Real} _y0 top of the garment
/// @param {Real} _y1 bottom of the garment
/// @param {Struct} _d drape parameters
/// @param {Real} _u0 inner edge of the band
/// @param {Real} _u1 outer edge of the band
/// @param {String} _role colour role
/// @returns {Struct} one part
function rai_drape_band(_arm, _y0, _y1, _d, _u0, _u1, _role) {
    var _a = array_create(RAI_DRAPE_STEPS + 1);
    var _b = array_create(RAI_DRAPE_STEPS + 1);
    var _i;
    for (_i = 0; _i <= RAI_DRAPE_STEPS; _i++) {
        var _t = _i / RAI_DRAPE_STEPS;
        var _y = lerp(_y0, _y1, _t);
        var _w = rai_drape_halfwidth(_arm, _y, _y0, _y1, _d);
        _a[_i] = [_w * _u0, _y];
        _b[_i] = [_w * _u1, _y];
    }
    return rai_strip(_a, _b, _role);
}

/// The three tones a draped panel carries.
///
/// ⛔ THE LAMP SITS UP AND TO THE LEFT (rai_relief), SO THE TWO SIDES ARE NOT SYMMETRIC. A shadow
/// on both edges is a vignette, not a light: it says "round" and refuses to say which way. The
/// left edge takes a narrow sheen, the right takes a broad shadow with a deeper core against the
/// outline, and the middle is left as the face colour - which is what makes the face colour read
/// as the material rather than as the whole garment.
///
/// @param {Struct} _arm from rai_armature
/// @param {Real} _y0 top of the garment
/// @param {Real} _y1 bottom of the garment
/// @param {Struct} _d drape parameters
/// @param {Struct} _roles {face, shade, line}
/// @returns {Array} part list
///
/// ⛔⛔ THREE BANDS WERE NOT A TONE, THEY WERE THREE STRIPES, AND GATE 1 CALLED IT: "flat colour
/// panels with a single shade band". The old version painted `shade` from u 0.34 to the right edge,
/// `line` over the last fifth of that, and one m3 sheen down the left - three hard vertical borders
/// on a garment, which at hero size reads as a flag rather than as cloth. The five-stop ramp the
/// material layer builds was rendering as three stops, and the two rim stops were never reached at
/// all.
///
/// ⭐ CLOTH ON A BODY IS A TUBE WITH FOLDS IN IT, SO THE TONE IS A LAMP GRADIENT PLUS A RIPPLE.
/// Eighteen bands across the panel, each taking its ramp stop from the lamp against the panel's own
/// lateral normal, modulated by a cosine whose period is the fold count. That is one field rather
/// than a gradient with lines drawn on top of it, so the light side of every fold is REAL shading
/// and not a companion stroke - and a fuller garment gets both more folds and deeper ones, which is
/// a fact about how much cloth is being carried rather than a style setting.
///
/// ⚠️ THE RIPPLE IS PHASED SO ITS TROUGHS LAND ON rai_drape_folds' CREASES, through the shared
/// rai_fold_count. Drawn out of phase, the crease line sits on the lit side of its own fold and the
/// garment reads as if it were lit from two directions.
function rai_drape_shading(_arm, _y0, _y1, _d, _roles) {
    var _out = [];
    var _bands = 22;
    var _n = rai_fold_count(_d);
    // How deep the folds cut. A rigid, clinging material barely ripples; a full robe carries a lot
    // of cloth and the tone has to travel most of the ramp inside one fold.
    //
    // ⚠️ THE FOLDS HAVE TO BEAT THE LATERAL TERM OR THE GARMENT IS JUST A LIGHT HALF AND A DARK
    // HALF. At 0.70 lateral against 0.16 base amplitude, the 2026-09-02 bake read as one hard
    // vertical split down the middle of every robe with the ripple barely visible on top of it -
    // which is the three-stripe look this function was rewritten to remove, in a smoother disguise.
    var _amp = 0.22 + _d.fullness * 0.55;
    var _k;
    for (_k = 0; _k < _bands; _k++) {
        var _u0 = -1 + 2 * (_k / _bands);
        var _u1 = -1 + 2 * ((_k + 1) / _bands);
        var _uc = (_u0 + _u1) * 0.5;
        var _v  = (_uc + 1) * 0.5;
        var _g  = clamp(_uc * 0.55 + _amp * cos(RAI_TAU * _n * _v - pi), -1, 1);
        // The panel faces the viewer, so its lateral normal runs along +x and the lamp decides
        // which side is lit. Passing the normal rather than a hard-coded role is what keeps a
        // garment consistent with the armour beside it when a buyer moves the lamp.
        array_push(_out, rai_drape_band(_arm, _y0, _y1, _d, _u0, _u1,
                                        rai_relief_role(1, 0, _g)));
    }
    return _out;
}

/// The two rails of a sleeve ring, in the order rai_sleeve_ring assembles them.
///
/// ⚠️ THIS DEPENDS ON THAT FUNCTION'S ARRAY LAYOUT AND SAYS SO. rai_sleeve_ring returns one rail
/// walked proximal-to-distal followed by the other walked distal-to-proximal, for both the 4-point
/// and the 8-point case, so the mirror index n-1-i is the matching station. If that assembly ever
/// changes, this breaks silently into a bowtie and the sleeve shading crosses the sleeve.
///
/// @param {Array} _ring from rai_sleeve_ring
/// @returns {Struct} {a, b} rails of equal length
function rai_sleeve_rails(_ring) {
    var _n = array_length(_ring);
    var _h = _n div 2;
    var _a = array_create(_h);
    var _b = array_create(_h);
    var _i;
    for (_i = 0; _i < _h; _i++) {
        _a[_i] = _ring[_i];
        _b[_i] = _ring[_n - 1 - _i];
    }
    return { a: _a, b: _b };
}

/// The shadow down a sleeve's away-from-the-lamp side.
///
/// ⛔ WHICH SIDE THAT IS DEPENDS ON THE POSE AND CANNOT BE HARD-CODED. A hanging arm turns its
/// rails to -x and +x, so the shadow is on +x; a reaching arm turns them UP and DOWN, so the
/// shadow is underneath. Writing "the inner rail" would be right on `stand` and lit the wrong way
/// on `reach` and `guard` - three of the five poses this product ships.
///
/// @param {Struct} _arm from rai_armature
/// @param {Array} _ring from rai_sleeve_ring
/// @param {String} _role colour role
/// @returns {Struct} one part
function rai_sleeve_shade(_arm, _ring, _role) {
    var _r = rai_sleeve_rails(_ring);
    var _n = array_length(_r.a);
    var _mx = 0;
    var _my = 0;
    var _i;
    for (_i = 0; _i < _n; _i++) {
        _mx += _r.a[_i][0] - _r.b[_i][0];
        _my += _r.a[_i][1] - _r.b[_i][1];
    }
    // Up and to the left, as a unit vector pointing TOWARD the lamp; y grows downward.
    var _dark_a = ((_mx * -0.55 + _my * -0.83) < 0);
    var _o = array_create(_n);
    var _q = array_create(_n);
    for (_i = 0; _i < _n; _i++) {
        var _p1 = _dark_a ? _r.a[_i] : _r.b[_i];
        var _p2 = _dark_a ? _r.b[_i] : _r.a[_i];
        _o[_i] = _p1;
        _q[_i] = [lerp(_p1[0], _p2[0], 0.44), lerp(_p1[1], _p2[1], 0.44)];
    }
    return rai_strip(_o, _q, _role);
}

/// ⭐ A SLEEVE OR A TROUSER LEG AS A LIT TUBE, WHICH IS WHAT IT IS.
///
/// rai_sleeve_shade above puts ONE shadow on the away-from-the-lamp half. That is a great deal
/// better than nothing and it is still two tones: a light half and a dark half with a hard border
/// down the middle of the arm. Seven bands across the same two rails is the same physics with the
/// step size the ramp was built for, and rai_tube_bands takes its direction from the rails
/// themselves, so it is correct on a hanging arm, a raised arm and a bent knee without a special
/// case - the same argument rai_sleeve_shade's own header makes.
///
/// ⚠️ FALLS BACK TO THE SINGLE SHADOW when detail is RAI_DETAIL_FLAT, so a crowd drawn at map size
/// still has a lit side and a dark side for one part instead of seven.
///
/// @param {Struct} _arm from rai_armature
/// @param {Array} _ring from rai_sleeve_ring or rai_limb_ring
/// @param {String} _role colour role for the flat fallback
/// @returns {Array} part list
function rai_sleeve_form(_arm, _ring, _role) {
    if (!rai_form_on()) return [rai_sleeve_shade(_arm, _ring, _role)];
    var _r = rai_sleeve_rails(_ring);
    return rai_tube_bands(_r.a, _r.b, 7);
}

/// ============================================================================================
/// FOLDS - derived from the same samples, never drawn on top
/// ============================================================================================

/// Fold lines for a panel.
///
/// ⛔ THE FOLDS ARE COMPUTED FROM THE DRAPE, NOT DECORATED ONTO IT. A fold drawn as an independent
/// stripe is the tell that gives away every hand-drawn "procedural" garment: it does not move when
/// the body does. These start where the cloth actually is, so a broader figure spreads its own
/// folds apart.
///
/// The count scales with how much material is carried - a full robe has more folds than a fitted
/// tunic, which is a fact about cloth and not a style choice.
///
/// @param {Struct} _arm from rai_armature
/// @param {Real} _y0 top of the garment
/// @param {Real} _y1 bottom of the garment
/// @param {Struct} _d drape parameters
/// @param {String} _role colour role for the fold line
/// @returns {Array} part list of fold polylines
/// ⭐ HOW MANY FOLDS A PANEL CARRIES. Shared by the tone field and the crease lines, because the
/// crease of a fold has to sit in the trough of its own shading - two independent counts is how a
/// garment ends up lit from two directions at once.
///
/// ⚠️ IT USED TO BE `2 + fullness * 26`, which on a full robe is TWENTY-EIGHT creases across one
/// panel: at hero size that is hatching, and at figure size it is a solid tone. A fold is a
/// structural thing about how much cloth is gathered, and cloth gathers into a handful of large
/// folds and a few small ones, not into thirty parallel scratches.
///
/// @param {Struct} _d drape parameters
/// @returns {Real} fold count
function rai_fold_count(_d) {
    return max(2, floor(2 + _d.fullness * 6));
}

function rai_drape_folds(_arm, _y0, _y1, _d, _role) {
    var _out = [];
    var _n = rai_fold_count(_d);
    var _i, _k;

    for (_k = 0; _k < _n; _k++) {
        // ⚠️ (_k + 0.5) / _n, NOT (_k + 1) / (_n + 1) - the crease must land on the trough of the
        // cosine in rai_drape_shading, and that is where the trough is. The old spacing was chosen
        // when the folds were the only fold information on the panel.
        var _u = (_k + 0.5) / _n;
        var _pts = [];
        for (_i = 0; _i <= 6; _i++) {
            var _t = _i / 6;
            var _y = lerp(_y0, _y1, _t);
            var _w = rai_drape_halfwidth(_arm, _y, _y0, _y1, _d);
            // ⚠️ FOLDS CONVERGE TOWARD THE TOP, AND 0.55 CONVERGED THEM INTO A LOGO. At that
            // strength every fold on the panel met near the collar, so a robe carried three or
            // four dark strokes radiating from one point on its chest - which reads as a chevron
            // or a badge, not as gathered cloth, and on a row of five identical figures it read as
            // branding. MEASURED 2026-09-02 on the drape sheet. Cloth does gather at the shoulder,
            // but only a little: the folds stay nearly parallel and separate toward the hem.
            var _spread = lerp(0.86, 1.0, _t);
            array_push(_pts, [lerp(-_w, _w, _u) * _spread, _y]);
        }
        // ⭐ ONE FINE CREASE, NOT A PAIR OF STROKES. The companion highlight that used to sit beside
        // every fold was standing in for shading that did not exist; rai_drape_shading now carries
        // the lit side of each fold as real tone, and drawing a second light stroke on top of it put
        // a hard line down the middle of the very gradient it was imitating. What is left is the one
        // thing tone cannot do at this size: a crisp dark crease at the bottom of the fold.
        //
        // ⚠️ 0.0035 RATHER THAN 0.006. Gate 1's complaint on 2026-09-02 was "no fine linework", and
        // a crease as wide as an outline is not linework, it is a second outline. RAI_MIN_STROKE
        // holds it at a pixel at any size, so this only ever gets FINER on a large render, never
        // broken into dashes on a small one.
        array_push(_out, rai_poly(_pts, false, _arm.span * 0.0035, _role));
    }
    return _out;
}

/// ============================================================================================
/// SLEEVES
/// ============================================================================================

/// A sleeve drawn along an arm, thickened by the same cloth model as the body panel.
///
/// @param {Struct} _arm from rai_armature
/// @param {Real} _side 0 or 1
/// @param {Real} _reach 0 = shoulder only, 0.5 = elbow, 1 = wrist
/// @param {Struct} _d drape parameters
/// @returns {Array} closed ring of [x,y]
function rai_sleeve_ring(_arm, _side, _reach, _d) {
    var _sh = _arm.shoulder[_side];
    var _el = _arm.elbow[_side];
    var _wr = _arm.wrist[_side];

    var _end;
    if (_reach <= 0.5) {
        var _t = _reach / 0.5;
        _end = [lerp(_sh[0], _el[0], _t), lerp(_sh[1], _el[1], _t)];
    } else {
        var _t2 = (_reach - 0.5) / 0.5;
        _end = [lerp(_el[0], _wr[0], _t2), lerp(_el[1], _wr[1], _t2)];
    }

    var _stand = _d.thickness * (1 - _d.cling * 0.75);
    // ⛔ 0.5 PUT MORE CLOTH IN A SLEEVE THAN IN THE WHOLE BODY PANEL, AND THAT IS WHERE THE SLAB
    // CAME FROM. rai_drape_halfwidth spends `fullness * span` over the panel's whole height with a
    // flare weighting, so at the shoulder a `full` robe carries about 0.008 span of extra material.
    // This line was handing the SLEEVE 0.0225 - nearly three times as much, at the one station
    // where the figure can least afford width - so the sleeve came out twice the arm's own
    // diameter and stood 1.6 shoulder half-widths out from the centre line. MEASURED 2026-09-02
    // off the drape sheet, and it survived one round of fixes because the number looked harmless.
    var _extra = _d.fullness * _arm.span * 0.16;
    // ⛔ THE TAPER USED TO RUN THE WRONG WAY AND IT IS WHY EVERY SLEEVE READ AS A PLANK. The
    // fullness term was applied at FULL strength to the cuff and at 0.4 to the armhole, so on the
    // `full` drape the cuff came out WIDER than the shoulder - 0.0539 span against 0.0469 - and the
    // sleeve widened as it went down the arm. At 2.1x the arm's own half-width, with a straight
    // taper and a hard outline, that is not a bell sleeve, it is a slab; on `reach` and `guard` it
    // read as an oven mitt. MEASURED off the pose sheet 2026-09-02, by looking at it.
    //
    // ⭐ A SLEEVE IS WIDEST AT THE ARMHOLE. It has to clear the deltoid and the whole shoulder joint
    // there, and it narrows toward the wrist on every real garment this package names - robe, coat,
    // tunic alike. Fullness is therefore weighted to the SHOULDER now and damped at the cuff, which
    // keeps a full robe generous without inverting the silhouette.
    // ⚠️ THE ARMHOLE WIDTH IS TAKEN FROM rai_sleeve_head_w AND NOT RECOMPUTED HERE. Two copies of
    // one formula is how a shoulder cap ends up a different size from the sleeve it is capping,
    // and nothing would report it - the picture would simply grow a step at every armhole.
    var _w0 = rai_sleeve_head_w(_arm, _d);
    var _w1 = _arm.w_limb * 0.94 + _stand + _extra * 0.42;

    // Elbow is a real bend, so a sleeve that reaches past it needs the joint sampled or it creases
    // through the arm.
    //
    // ⛔ AND THE JOINT HAS TO BE MITRED, NOT BUTTED. The first version spliced two independent limb
    // rings together at the elbow: each one offsets by ITS OWN normal, and on a bent arm those
    // differ by the bend angle, so the sleeve's edge STEPPED sideways at the joint. On `guard`,
    // where the elbow closes to 1.05 rad, that step is a visible notch cut out of the top of the
    // forearm - it looked like a tear in the cloth on the pose sheet. MEASURED 2026-09-02.
    //
    // ⭐ THE CORRECT OFFSET AT A CORNER IS THE BISECTOR, LENGTHENED BY 1/cos(half the turn). That
    // is the standard mitre: the two edges then meet at one point instead of crossing, and the
    // outline stays simple. The clamp is what stops a fully folded arm sending the mitre to
    // infinity; at that point the sleeve is self-intersecting whatever you do and a bevelled join
    // is the honest degradation.
    if (_reach > 0.5) {
        var _d1x = _el[0] - _sh[0], _d1y = _el[1] - _sh[1];
        var _d2x = _end[0] - _el[0], _d2y = _end[1] - _el[1];
        var _l1 = max(0.0001, point_distance(0, 0, _d1x, _d1y));
        var _l2 = max(0.0001, point_distance(0, 0, _d2x, _d2y));
        var _n1x = -_d1y / _l1, _n1y = _d1x / _l1;
        var _n2x = -_d2y / _l2, _n2y = _d2x / _l2;
        var _mx = _n1x + _n2x, _my = _n1y + _n2y;
        var _ml = point_distance(0, 0, _mx, _my);
        if (_ml < 0.0001) { _mx = _n1x; _my = _n1y; _ml = 1; }
        _mx /= _ml; _my /= _ml;
        // cos(half the turn) between the bisector and either edge normal.
        var _cs = max(0.42, _mx * _n1x + _my * _n1y);
        var _wm = (_w0 + _w1) * 0.5 / _cs;
        return [
            [_sh[0]  + _n1x * _w0, _sh[1]  + _n1y * _w0],
            [_el[0]  + _mx  * _wm, _el[1]  + _my  * _wm],
            [_end[0] + _n2x * _w1, _end[1] + _n2y * _w1],
            [_end[0] - _n2x * _w1, _end[1] - _n2y * _w1],
            [_el[0]  - _mx  * _wm, _el[1]  - _my  * _wm],
            [_sh[0]  - _n1x * _w0, _sh[1]  - _n1y * _w0]
        ];
    }
    return rai_limb_ring(_sh, _end, _w0, _w1);
}

/// The half-width a sleeve has at the armhole. Public so a caller can round the shoulder off with
/// a cap of the right size instead of guessing one.
///
/// ⛔ A LIMB RING HAS SQUARE ENDS, AND AT THE SHOULDER THAT IS A SHELF. The proximal end of a
/// sleeve is a straight cut across the top of the arm, so a hanging sleeve terminates in a
/// horizontal edge sitting at exactly shoulder height and running the full width of the sleeve -
/// which is the line that made the first fix's sleeves still read as boards bolted to the figure.
/// A real armhole is a curve over the deltoid. One cap disc, tangent to the shoulder line, is all
/// it takes, and rai_armature's own shoulder-cap comment records the same fix for the bare arm.
///
/// @param {Struct} _arm from rai_armature
/// @param {Struct} _d drape parameters
/// @returns {Real} half-width at the armhole
function rai_sleeve_head_w(_arm, _d) {
    return _arm.w_limb * 1.24 + _d.thickness * (1 - _d.cling * 0.75)
         + _d.fullness * _arm.span * 0.16;
}

/// How far the armhole cap's CENTRE sits below the shoulder line, as a fraction of its own radius.
///
/// ⛔⛔ THIS NUMBER EXISTED TWICE AND THE TWO COPIES DISAGREED FOR A WHOLE STORE BAKE. rai_garment
/// and rai_armour each drew their own armhole cap; on 2026-09-02 the cloth half was measured at 4x,
/// found to be standing 0.58 radii proud of the shoulder ("1980s shoulder pads"), and moved 0.42 ->
/// 0.86 - and the armour half was left at 0.42 with a comment above it claiming tangency. The
/// armour sheet's `scale` cell is what that produced: a corselet reading as a board hung across the
/// chest with two untextured lumps above it, three sessions of tuning its width and its length, and
/// the cause in neither.
///
/// ⭐ IT IS ONE NUMBER BECAUSE IT ANSWERS ONE QUESTION - where a sleeve's armhole meets the shoulder
/// - and master CLAUDE.md §2b states the law this broke: a shared fact that every consumer keeps its
/// own copy of is a place a shipped product moves without anyone editing it. The `scale` family is
/// the one that showed it, and it showed it only because it declares neither a pauldron nor a coif
/// (rai_armour_pieces), so nothing lands on top to hide the lumps. Five families hid the same bug.
///
/// ⚠️ WHY NOT 1.00. Exact tangency is what rai_armature uses for the BARE shoulder joint, where
/// nothing may protrude because no garment can reach above y_shoulder to cover it. A sleeve cap sits
/// outside that joint and under a yoke that rises at the shoulder, so it is allowed the last 0.14 of
/// a radius; taking it to 1.00 opens a notch between the cap and the yoke instead. The value is
/// settled by looking at the bake, which is why rai_selftest asserts a BOUND on it rather than the
/// number itself.
#macro RAI_SLEEVE_CAP_DROP 0.86

/// The armhole cap for a sleeve, as one part.
///
/// A limb ring has square ends, so a sleeve without this terminates in a horizontal cut at shoulder
/// height running its full width - see rai_sleeve_head_w. This is the disc that rounds it off, and
/// it is the BOTTOM of the disc that fills the armhole, which is why the centre drops rather than
/// the radius growing.
///
/// @param {Struct} _arm from rai_armature
/// @param {Real} _side 0 or 1
/// @param {Real} _hw the armhole half-width, from rai_sleeve_head_w
/// @param {String} _role colour role for the cap's fill
/// @returns {Struct} one part
function rai_sleeve_cap(_arm, _side, _hw, _role) {
    return rai_dot(_arm.shoulder[_side][0],
                   _arm.shoulder[_side][1] + _hw * RAI_SLEEVE_CAP_DROP,
                   _hw, _role);
}

/// ============================================================================================
/// DRAPE PRESETS
/// ============================================================================================

/// Named cloth behaviours, so a garment family declares what its material DOES rather than
/// repeating four magic numbers.
///
/// @param {String} _id the behaviour
/// @returns {Struct} drape parameters
function rai_drape_of(_id) {
    switch (_id) {
        //                          thickness  fullness  flare  cling
        case "fitted":  return { thickness: 0.004, fullness: 0.004, flare: 0.30, cling: 0.85 };
        case "soft":    return { thickness: 0.007, fullness: 0.018, flare: 0.62, cling: 0.45 };
        case "full":    return { thickness: 0.009, fullness: 0.045, flare: 0.80, cling: 0.15 };
        case "heavy":   return { thickness: 0.014, fullness: 0.030, flare: 0.55, cling: 0.20 };
        case "rigid":   return { thickness: 0.017, fullness: 0.002, flare: 0.10, cling: 0.70 };
        // ⛔⛔ A CLOAK IS NOT A "full" GARMENT AND SHARING THAT ROW MADE IT INVISIBLE FROM THE FRONT.
        // The cloak is the one family in the wardrobe that hangs BEHIND the figure (layer 5), so it
        // is only ever seen where it is WIDER than everything in front of it. On `full` its
        // halfwidth at the shoulder came to body + 0.0090 + 0.0080 = 0.121 of stature, and the bare
        // arm's outer edge already sits at 0.86*0.104 + 0.026 = 0.115 - a clearance of 0.006, which
        // is under a pixel at figure size and less than nothing once a sleeve is on. The result on
        // the equip and cloth sheets was a cloak that began at the WAIST and read as a curtain
        // hanging behind the legs, with no fastening and no shoulder. MEASURED 2026-09-02.
        //
        // ⭐ THE FIX IS THE ONE PROPERTY THAT MAKES A CLOAK A CLOAK: it goes OVER the shoulders, so
        // it must be the widest thing on the figure at the top, not just at the hem. Lowering the
        // flare spends more of the fullness up high (0.62 rather than 0.80) and the heavier
        // thickness is a real cloak's cloth. At the shoulder that now reads body + 0.0351 = 0.139,
        // clearing the arm by 0.024 of stature, which is a visible band of cloth either side.
        case "cloak":   return { thickness: 0.016, fullness: 0.055, flare: 0.62, cling: 0.08 };
        default:        return { thickness: 0.007, fullness: 0.014, flare: 0.50, cling: 0.50 };
    }
}
