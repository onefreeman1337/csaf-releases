{
  "$GMScript": "v1",
  "%Name": "rai_relief",
  "name": "rai_relief",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}