/// RAIMENT - rai_selftest. The in-engine suite.
///
/// ============================================================================================
/// ⛔ GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE. There is no headless runner, no mock and no
/// assertion library. This wing's answer is to build the product through Igor, run the executable
/// with `-selftest`, and have it write a JSON result file - the only route that survives a release
/// build. `show_debug_message` plus `-debugoutput` writes engine boot lines and nothing else, and
/// `game_end(n)` does not propagate n to the process exit code. Both measured in this wing.
///
/// ⛔ A SUITE FULL OF GREEN ASSERTIONS PROVES NOTHING UNTIL ONE OF THEM HAS BEEN MADE TO FAIL. This
/// wing has shipped two suites that could never have gone red: a duplicate check written with a
/// tolerance below GML's default epsilon passed VACUOUSLY for every input, and a containment
/// assertion passed while its subjects were being silently shrunk. Every assertion here that could
/// be vacuous is PAIRED with one proving its fixture is in the state it needs, and those pairs are
/// marked VACUITY GUARD.
///
/// ⛔ THE DEFAULT EPSILON. math_get_epsilon() returns 0.00001 on this runtime and it PARTICIPATES IN
/// COMPARISONS, so a tolerance at or below about 1e-5 makes a comparison answer the same thing for
/// every input. RAI_ST_EPS is the one this file uses. GML also has no exponent-literal syntax at
/// all: `1e-5` is a lexer error that reads like a bracket bug.
///
/// ============================================================================================
/// WHAT THIS SUITE IS FOR, ON THIS PRODUCT SPECIFICALLY
///
/// Raiment's claim is that a garment is COMPUTED FROM the body rather than pasted onto it, which is
/// the whole reason it replaces an atlas rather than a script. Three stages carry that claim and
/// everything else supports them:
///
///   STAGE 4  THE DRAPE FOLLOWS THE BODY. Cloth is always outside the body it is on, and - the half
///            that actually matters - THE SAME GARMENT ON TWO BUILDS IS A DIFFERENT OUTLINE. A
///            layered PNG cannot do the second one, so if that assertion ever passes vacuously the
///            product has quietly become the $5 incumbent.
///
///   STAGE 5  RIGID IS RIGID. Armour must NOT gather downward the way cloth does. Without this the
///            two builders collapse into one with a different texture, which is the "six recolours
///            of one shell" failure rai_armour's header names.
///
///   STAGE 9  EVERY ROLE RESOLVES. rai_wardrobe namespaces each item's ramp into one palette, and
///            rai_render falls back to `line` on a miss - so a namespacing mistake does not crash,
///            it draws the whole figure in outline colour. This is the only mechanical check for it.
///
/// ⚠️ WHAT THIS SUITE CANNOT SEE, said here rather than left for a buyer to discover: it computes
/// POINTS and NUMBERS. It cannot see a FILL RULE, a DRAW ORDER, a COLOUR ON A PAGE or a PICTURE.
/// This wing has shipped a crescent moon rendered as a quarter, a rainbow that never drew at all,
/// and a corpus collapsed to a vertical line, every one with a fully green geometry story. The
/// instrument for those is opening the baked sheet and LOOKING, and that step is not optional
/// because this file exists.
/// ============================================================================================

/// The one tolerance in this file. Above GML's 0.00001 epsilon by a factor of ten, which is the
/// smallest number that can fire in BOTH directions.
#macro RAI_ST_EPS 0.0001

/// The occupancy grid two families are compared on. 24x24 over the unit box is about 1.7% of the
/// box per cell, which is roughly the scale at which two figures start to look alike in a row of
/// portraits.
#macro RAI_ST_GRID 24

/// How different two families drawn on the SAME body in the SAME material must be.
///
/// ⚠️ SAID PLAINLY: this is a REGRESSION GUARD, not a live finding, and the honest way to read it is
/// off the histogram written into the result file rather than off this number. It is deliberately
/// LOW - a robe and a coat share a great deal of silhouette and should - so it fires only on a pair
/// that has genuinely collapsed into one shape, which is the failure worth catching.
#macro RAI_ST_PAIR_FLOOR 0.030

/// The smallest figure height, in pixels, at which this product claims its materials are still
/// telling themselves apart. STAGE 11 DERIVES the true figure and the Readme quotes THAT.
///
/// ⛔ THIS READ 64 AND THE PRODUCT COULD NOT DO 64. MEASURED 2026-09-02, first run of the suite that
/// got past the RAI_CN_* crash: stage 11 derives 116 px, limited by `scale`, whose courses overlap
/// at 0.028 * 0.62 = 1.74% of stature, so two courses land in the same pixel below ~116 px. 64 was
/// an aspiration nobody had ever been able to run the suite far enough to test.
///
/// ⚠️ THE FIX IS THE CLAIM, NOT THE ART, AND THAT IS A DELIBERATE CHOICE WITH A COST. Reaching 64
/// needs the scale course at >= 2/64 of stature, i.e. scales ~1.8x their current size - chunky,
/// wrong at hero scale, and a real loss on the store sheet, paid to make a round number true. Scale
/// armour IS a fine overlapping texture. So the number moves to the measurement.
///
/// ⚠️ WHAT THE PRODUCT MAY THEREFORE CLAIM: material TEXTURES resolve from ~116 px, and below that
/// materials stay distinguishable by their RAMP, which carries colour and lightness at any size.
/// ⛔ It may NOT claim a textured figure reads at inventory-portrait sizes. Do not write that.
///
/// Set 120 rather than 116: a round documented ceiling with a little headroom, so a future surface
/// finer than `scale` fails here loudly instead of drifting the real floor upward in silence.
///
/// ⚠️ STAGE 11's spacing table is a HAND COPY of the constants in rai_material's surface builders
/// and only its NAMES are guarded, not its NUMBERS. Values re-read against that file 2026-09-02 and
/// they match: scale 0.028*0.62, ring 0.011*1.7, quilt 0.055, rivet 0.060. Re-read them on any
/// change to those builders - a drifted table measures nothing.
#macro RAI_ST_MIN_FIGURE_PX 120

function rai_st_new() {
    return { pass: 0, fail: 0, notes: [] };
}

function rai_st_ok(_r, _cond, _what) {
    if (_cond) { _r.pass += 1; return; }
    _r.fail += 1;
    // Cap the note list. A systemic failure fires hundreds of times and a result file too large to
    // write is a result file nobody reads.
    if (array_length(_r.notes) < 60) array_push(_r.notes, _what);
}

/// ============================================================================================
/// THE SIGNATURE - what "two families look alike" is measured on
/// ============================================================================================

/// The vertical extent of ONE part, as [minY, maxY] in unit space.
///
/// ⛔ THE POINT OF THIS FUNCTION IS THAT IT DOES NOT CLAMP. rai_st_stamp below discards any point
/// outside the unit box, because it is writing into a fixed grid - which is right for an occupancy
/// map and is exactly why nothing in this suite could ever see a part that escapes the figure. This
/// reader is deliberately unbounded so stage 9b can find one.
///
/// ⚠️ Mirrors rai_render_bounds' treatment of each kind, including RAI_ARC being measured as its
/// FULL CIRCLE rather than as the visible sweep. That is the renderer's own behaviour, and the
/// assertion is about the box the renderer computes, so agreeing with it is the point.
///
/// @param {Struct} _p one part
/// @returns {Array} [minY, maxY]
function rai_st_part_y_extent(_p) {
    var _lo = 999, _hi = -999, _k;
    if (_p.kind == RAI_DOT) {
        _lo = _p.cy - _p.r; _hi = _p.cy + _p.r;
    } else if (_p.kind == RAI_ARC) {
        _lo = _p.cy - _p.r - _p.w; _hi = _p.cy + _p.r + _p.w;
    } else if (_p.kind == RAI_STRIP) {
        for (_k = 0; _k < array_length(_p.a); _k++) {
            _lo = min(_lo, _p.a[_k][1]); _hi = max(_hi, _p.a[_k][1]);
        }
        for (_k = 0; _k < array_length(_p.b); _k++) {
            _lo = min(_lo, _p.b[_k][1]); _hi = max(_hi, _p.b[_k][1]);
        }
    } else {
        for (_k = 0; _k < array_length(_p.pts); _k++) {
            _lo = min(_lo, _p.pts[_k][1]); _hi = max(_hi, _p.pts[_k][1]);
        }
    }
    // An empty point list would otherwise report the sentinels as a real extent.
    if (_hi < _lo) { _lo = 0; _hi = 0; }
    return [_lo, _hi];
}

/// Stamp a part list's drawn geometry into an occupancy grid over the unit box.
///
/// ⛔ IT STAMPS THE GEOMETRY, NEVER THE DECLARATION. Comparing the numbers two families were
/// authored with proves only that they were typed differently - a lesson this wing paid for on a
/// corpus whose rows all differed and whose pictures did not.
///
/// @param {Array} _parts a part list in unit space
/// @returns {Array} RAI_ST_GRID * RAI_ST_GRID of 0 or 1
function rai_st_stamp(_parts) {
    var _n = RAI_ST_GRID;
    var _g = array_create(_n * _n, 0);
    var _i, _j, _k, _px, _py, _cx, _cy;

    for (_i = 0; _i < array_length(_parts); _i++) {
        var _p = _parts[_i];
        if (_p.kind == RAI_DOT || _p.kind == RAI_ARC) {
            _cx = floor((_p.cx + 0.5) * _n);
            _cy = floor((_p.cy + 0.5) * _n);
            if (_cx >= 0 && _cx < _n && _cy >= 0 && _cy < _n) _g[_cy * _n + _cx] = 1;
            continue;
        }
        if (_p.kind == RAI_STRIP) {
            for (_k = 0; _k < array_length(_p.a); _k++) {
                _px = floor((_p.a[_k][0] + 0.5) * _n);
                _py = floor((_p.a[_k][1] + 0.5) * _n);
                if (_px >= 0 && _px < _n && _py >= 0 && _py < _n) _g[_py * _n + _px] = 1;
            }
            continue;
        }
        for (_j = 0; _j < array_length(_p.pts); _j++) {
            _px = floor((_p.pts[_j][0] + 0.5) * _n);
            _py = floor((_p.pts[_j][1] + 0.5) * _n);
            if (_px >= 0 && _px < _n && _py >= 0 && _py < _n) _g[_py * _n + _px] = 1;
        }
    }
    return _g;
}

/// Fraction of occupied cells the two grids disagree on.
///
/// Normalised by the UNION rather than by the cell count, so two small figures that differ
/// completely score 1.0 instead of 0.05 - the alternative flatters every comparison on a subject
/// that occupies a fraction of its box, which a standing figure does.
///
/// @returns {Real} 0 = identical, 1 = no overlap at all
function rai_st_dist(_a, _b) {
    var _same = 0;
    var _union = 0;
    var _i;
    for (_i = 0; _i < array_length(_a); _i++) {
        var _x = _a[_i];
        var _y = _b[_i];
        if (_x > 0 || _y > 0) _union += 1;
        if (_x > 0 && _y > 0) _same += 1;
    }
    if (_union <= 0) return 0;
    return 1 - (_same / _union);
}

/// ============================================================================================
/// THE SUITE
/// ============================================================================================

function rai_selftest_run() {
    var _r = rai_st_new();
    var _i, _j, _k, _y, _w;
    var _builds = rai_builds_all();
    var _poses = rai_poses_all();
    var _cloth = rai_garment_families();
    var _armour = rai_armour_families();
    var _mats = rai_materials_all();

    // Numbers carried into the result file so the next session re-derives thresholds from data
    // rather than inheriting them.
    var _drapeSpread = 0;          // biggest build-to-build outline difference on one family
    var _drapeSpreadName = "";
    var _rigidGather = 0;          // worst downward gather measured on a RIGID family
    var _rigidGatherName = "";
    var _pairWorst = 1;
    var _pairWorstName = "";
    var _pairBelow = 0;
    var _hist = array_create(20, 0);
    var _minFigurePx = 0;
    var _minFigureWhat = "";
    var _clipDropped = 0;
    var _clipKept = 0;

    // -- STAGE 0: the runtime still behaves the way this package assumes -----------------------
    global.rai_stage = 0;
    var _e = math_get_epsilon();
    // ⛔ `!(_e > 0)` ON PURPOSE. The natural expression `_e > 0` is FALSE, because the difference
    // between the epsilon and zero IS the epsilon, so GML calls them equal. Written this way it is
    // a POSITIVE test that the runtime still applies an epsilon, and it goes red the day one stops.
    rai_st_ok(_r, !(_e > 0), "epsilon: expected (_e > 0) to be FALSE - the epsilon trap is gone");
    rai_st_ok(_r, _e < 0.001,
              "epsilon: " + string_format(_e, 1, 12) + " is larger than this package assumes");

    // -- STAGE 1: THE CORPUS IS COUNTABLE, AND NO TWO MATERIALS ARE THE SAME MATERIAL -----------
    // ⛔ THE SECOND HALF IS THE ONE WITH A MEASURED DEFECT BEHIND IT. `charcoal` was declared in
    // rai_materials_all() with no case in rai_material_def, so it fell through to the default and
    // the corpus silently contained two identical materials WHILE THE COUNT STILL SAID 30. A
    // counter that only counts the list cannot see that; this compares the definitions.
    global.rai_stage = 1;
    var _c = rai_corpus_count();
    rai_st_ok(_r, _c.cloth_families == array_length(_cloth), "count: cloth families disagree");
    rai_st_ok(_r, _c.armour_families == array_length(_armour), "count: armour families disagree");
    rai_st_ok(_r, _c.materials == array_length(_mats), "count: materials disagree");
    rai_st_ok(_r, _c.outfits >= 40,
              "VOLUME FLOOR: " + string(_c.outfits) + " outfits is below the operator's 40");

    var _dupes = 0;
    for (_i = 0; _i < array_length(_mats); _i++) {
        for (_j = _i + 1; _j < array_length(_mats); _j++) {
            var _da = rai_material_def(_mats[_i]);
            var _db = rai_material_def(_mats[_j]);
            if (abs(_da.L - _db.L) < RAI_ST_EPS && abs(_da.C - _db.C) < RAI_ST_EPS
                && abs(_da.h - _db.h) < RAI_ST_EPS && _da.surface == _db.surface) {
                _dupes += 1;
                rai_st_ok(_r, false, "materials " + _mats[_i] + " and " + _mats[_j]
                          + " are the same material under two names");
            }
        }
    }
    rai_st_ok(_r, _dupes == 0, "materials: " + string(_dupes) + " duplicate definition(s)");
    // VACUITY GUARD. The comparison above must be able to say YES, or it proves nothing.
    var _probe = rai_material_def("linen");
    rai_st_ok(_r, abs(_probe.L - rai_material_def("linen").L) < RAI_ST_EPS,
              "VACUITY: the material comparison cannot recognise a material as equal to itself");

    // Every cloth family has a cut whose slot is a real slot, and every armour family a spec.
    var _slots = rai_slots_all();
    for (_i = 0; _i < array_length(_cloth); _i++) {
        var _cut = rai_garment_cut(_cloth[_i]);
        rai_st_ok(_r, rai_has_piece(_slots, _cut.slot),
                  _cloth[_i] + ": slot '" + string(_cut.slot) + "' is not a declared slot");
    }
    for (_i = 0; _i < array_length(_armour); _i++) {
        var _sp = rai_armour_spec(_armour[_i]);
        rai_st_ok(_r, rai_has_piece(_slots, _sp.slot),
                  _armour[_i] + ": slot '" + string(_sp.slot) + "' is not a declared slot");
        rai_st_ok(_r, array_length(rai_armour_pieces(_armour[_i])) > 0,
                  _armour[_i] + ": declares no pieces");
    }

    // -- STAGE 2: THE ARMATURE IS A PLAUSIBLE FIGURE, ON EVERY BUILD AND POSE --------------------
    global.rai_stage = 2;
    for (_i = 0; _i < array_length(_builds); _i++) {
        for (_j = 0; _j < array_length(_poses); _j++) {
            var _a = rai_armature(_builds[_i], _poses[_j]);
            var _nm = _builds[_i] + "/" + _poses[_j];
            // The landmarks must run down the figure in order. Out of order is not a proportion
            // problem, it is a figure whose hips are above its shoulders.
            rai_st_ok(_r, _a.y_crown < _a.y_shoulder, _nm + ": crown is not above the shoulders");
            rai_st_ok(_r, _a.y_shoulder < _a.y_waist, _nm + ": shoulders are not above the waist");
            rai_st_ok(_r, _a.y_waist < _a.y_hip, _nm + ": waist is not above the hips");
            rai_st_ok(_r, _a.y_hip < _a.y_sole, _nm + ": hips are not above the sole");
            rai_st_ok(_r, _a.w_shoulder > 0 && _a.w_hip > 0 && _a.w_limb > 0,
                      _nm + ": a body width is zero or negative");

            // ⛔⛔ THE BODY MUST NOT HAVE A HOLE IN IT, AND FOR THE WHOLE LIFE OF THIS PRODUCT IT DID.
            // rai_torso_ring ended on a straight line between the two hip joints and both thighs were
            // drawn as separate tubes hanging off its corners, so from the hip line down there was a
            // gap 0.081 of stature wide with nothing in it. On the bare mannequin you could see the
            // CLOAK BEHIND THE FIGURE through its own hip; under plate it ran as a bare tan column
            // between the cuisses, on the armour sheet and on the cover. Found 2026-09-02 by cropping
            // sheet 3 to 3x. See rai_armature's w_pelvis header.
            //
            // ⭐ NOTHING ALREADY IN THIS SUITE COULD HAVE SEEN IT. The ring was simple, wound one way,
            // inside the unit box, and every landmark was in order - a figure with a hole in it
            // satisfies all of those. rai_ring_covers_centre is the instrument that asks the question
            // the picture was answering: is the shape solid across its own centre line here.
            var _pring = rai_torso_ring(_a);
            var _psd = _a.y_seat - _a.y_hip;
            rai_st_ok(_r, rai_is_simple(_pring), _nm + ": the torso ring self-intersects");
            rai_st_ok(_r, _a.y_hip < _a.y_seat && _a.y_seat < _a.y_sole,
                      _nm + ": the seat is not between the hip and the sole");
            for (_k = 1; _k <= 8; _k++) {
                // Down to 0.60 of the seat depth - above the crotch apex, which is at 0.70 and is
                // legitimately open below.
                var _py = lerp(_a.y_shoulder, _a.y_hip + _psd * 0.60, _k / 9);
                rai_st_ok(_r, rai_ring_covers_centre(_pring, _py),
                          _nm + ": the torso does not span its own centre line at "
                          + string_format((_py - _a.y_shoulder) / (_a.y_seat - _a.y_shoulder), 1, 3)
                          + " of the way down - the body has a HOLE in it");
            }
            // ⚠️ AND A SECOND SWEEP AIMED AT THE PELVIS BAND ITSELF. The sweep above runs the whole
            // torso, so only its last station lands below the hip line - one assertion in eight
            // covering the only region that has ever been wrong. Four stations inside the band the
            // defect lived in make the test proportional to the risk rather than to the geometry.
            for (_k = 1; _k <= 4; _k++) {
                var _pz = _a.y_hip + _psd * 0.60 * (_k / 4);
                rai_st_ok(_r, rai_ring_covers_centre(_pring, _pz),
                          _nm + ": the pelvis does not span the centre line at "
                          + string_format(_psd * 0.60 * (_k / 4) / _a.span, 1, 4)
                          + " of stature below the hip - the crotch is open to the waist");
            }
            // ⚠️ AND THE CONTROL, ON THE SAME RING AT A NEARBY HEIGHT. Between the crotch apex and the
            // two inner-thigh roots the centre line is OUTSIDE the torso, because that is what a
            // crotch is. Without this the eight assertions above are satisfied by a shape that simply
            // has no notch at all - a shield point, not a pelvis - and by an instrument that always
            // says yes.
            rai_st_ok(_r, !rai_ring_covers_centre(_pring, _a.y_hip + _psd * 0.90),
                      _nm + ": the crotch is not open - either the pelvis is a solid point or "
                      + "rai_ring_covers_centre cannot say no");
            // ⛔ THE CROTCH IS THE ONLY CONCAVITY IN THIS OUTLINE AND rai_body_parts FILLS IT WITH A
            // FAN FROM THE WAIST. A concavity a fan cannot see into is how this wing shipped a moon
            // crescent as a quarter (Welkin) and a hem with a hole in it (rai_hem_shape, same day),
            // so the pelvis is not allowed to be the third: assert the fill CONTRACT at the exact
            // apex rai_body_parts passes, because the picture is unreachable from a test.
            rai_st_ok(_r, rai_ring_fan_safe(_pring, _a.waist[0], _a.y_waist),
                      _nm + ": rai_ring_fill cannot fill the torso from the waist - the crotch "
                      + "concavity folds the fan back on itself");
            // ⚠️ AND THE CONTROL, ON THE SAME RING. A point inside the crotch NOTCH is outside the
            // torso, so no fan can be run from there. Without this, the assertion above is satisfied
            // by an instrument that always says yes.
            rai_st_ok(_r, !rai_ring_fan_safe(_pring, 0, _a.y_hip + _psd * 0.90),
                      _nm + ": rai_ring_fan_safe accepts an apex sitting in the open crotch - the "
                      + "instrument cannot say no");
            // The thigh leaves the socket at w_hip and is w_limb*1.22 wide there, so a pelvis
            // narrower than that leaves a STEP in the silhouette where the leg juts out past the
            // body. Bounded both ways: wider than the thigh's outer edge would be a saddlebag.
            rai_st_ok(_r, (_a.w_hip + _a.w_limb * 1.22) - _a.w_pelvis <= _a.w_limb * 0.30,
                      _nm + ": the thigh stands "
                      + string_format(((_a.w_hip + _a.w_limb * 1.22) - _a.w_pelvis) / _a.w_limb, 1, 3)
                      + " limb-widths outside the pelvis - the hip has a step in it");
            rai_st_ok(_r, _a.w_pelvis <= _a.w_hip + _a.w_limb * 1.22 + RAI_ST_EPS,
                      _nm + ": the pelvis is wider than the outer edge of the thigh");
            rai_st_ok(_r, _a.w_limb >= RAI_MIN_LIMB_W - RAI_ST_EPS,
                      _nm + ": limb width " + string_format(_a.w_limb, 1, 5) + " is under the floor");
            rai_st_ok(_r, _a.span > 0, _nm + ": stature is not positive");

            // ⛔⛔ LATERALITY. EACH ARM MUST BELONG TO ITS OWN SIDE, AND FOR THE WHOLE LIFE OF THIS
            // PRODUCT NEITHER DID. rai_armature computed `sin(_p.sh * _dir) * _dir` for the arm
            // displacement; sine is odd, so the two `_dir` factors cancelled and BOTH arms swung
            // +x by an identical amount. On 4 of the 5 poses both wrists ended up on the same side
            // of the body. Nothing in stages 0-11 could see it: the landmarks were still in order,
            // the widths were still positive, the drape still followed the body, and 890 assertions
            // passed over a figure whose left hand was sitting on its own chest.
            //
            // ⭐ IT WAS FOUND BY LOOKING, NOT BY TESTING - the tell on every store sheet was a
            // skin-coloured blob at the centreline with no arm reaching it, because the arm limbs
            // draw UNDER the garment and the hands draw ON TOP of it. These four lines are the
            // instrument that would have caught it, and they are cheap: a front-view figure whose
            // arms open outward keeps each hand on its own side of the spine.
            //
            // ⚠️ ASSERTED ON THE UPPER ARM, NOT THE FOREARM. A closed enough elbow legitimately
            // brings a forearm back inboard (a hand on the chest is a pose, not a defect), so the
            // sign rule belongs on the shoulder-to-elbow segment, which always opens outward. The
            // WRIST is asserted against the centreline instead, which is the property a buyer
            // actually sees.
            for (_k = 0; _k < 2; _k++) {
                var _sgn = (_k == 0) ? -1 : 1;
                var _reach = (_a.elbow[_k][0] - _a.shoulder[_k][0]) * _sgn;
                rai_st_ok(_r, _reach >= -RAI_ST_EPS,
                          _nm + ": the " + ((_k == 0) ? "viewer-left" : "viewer-right")
                          + " elbow displaces toward the far side of the body ("
                          + string_format(_reach, 1, 5) + ")");
            }
            var _spine = _a.neck[0];
            rai_st_ok(_r, _a.wrist[0][0] < _spine,
                      _nm + ": the viewer-left wrist is at or past the centreline ("
                      + string_format(_a.wrist[0][0], 1, 5) + " vs spine "
                      + string_format(_spine, 1, 5) + ")");
            rai_st_ok(_r, _a.wrist[1][0] > _spine,
                      _nm + ": the viewer-right wrist is at or past the centreline ("
                      + string_format(_a.wrist[1][0], 1, 5) + " vs spine "
                      + string_format(_spine, 1, 5) + ")");
            // Both hands collapsing onto the spine passes the two tests above by a hair. The hands
            // must also be genuinely APART - at least a shoulder width between them.
            rai_st_ok(_r, (_a.wrist[1][0] - _a.wrist[0][0]) > _a.w_shoulder,
                      _nm + ": the two wrists are "
                      + string_format(_a.wrist[1][0] - _a.wrist[0][0], 1, 5)
                      + " apart, under one shoulder width");

            // ⛔⛔ AND THE LEGS HAD THE SAME DEFECT AND NO ASSERTION AT ALL. The four arm checks
            // above were written on 2026-09-02 for the double-`_dir` bug and stopped at the waist,
            // so the legs kept a MIRRORED picture-plane swing whose lateral arm (sin(hp) * thigh =
            // 0.0601 of stature) is very nearly the whole hip half-width (0.0677). MEASURED by
            // Internal_Ops/_leg_probe.js against the pre-fix table: `sit` put the viewer-left knee
            // at +0.0115 and the viewer-right at -0.0115 on `average` - swapped - on all five
            // builds, and `walk` left them 0.0151 apart against a 0.1354 stance. On sheet 7 that is
            // one dark column with two overlapping feet.
            //
            // ⚠️ AN ASSERTION WRITTEN FOR ONE HALF OF A FIGURE IS SILENT ABOUT THE OTHER HALF. The
            // laterality block above is a good check and its scope was the arms; nothing said so and
            // nothing tested the legs. Same shape as the master catalogue's half-a-field row.
            rai_st_ok(_r, _a.knee[0][0] < _a.neck[0] && _a.knee[1][0] > _a.neck[0],
                      _nm + ": a knee has crossed the centreline (L "
                      + string_format(_a.knee[0][0], 1, 5) + ", R "
                      + string_format(_a.knee[1][0], 1, 5) + ")");
            // Both knees collapsing onto the spine satisfies the sign test by a hair, exactly as it
            // does for the wrists. A stance is a real distance: at least one hip HALF-width between
            // the knees, or the two legs merge into one column whatever the angles claim.
            rai_st_ok(_r, (_a.knee[1][0] - _a.knee[0][0]) > _a.w_hip,
                      _nm + ": the knees are "
                      + string_format(_a.knee[1][0] - _a.knee[0][0], 1, 5)
                      + " apart, under one hip half-width (" + string_format(_a.w_hip, 1, 5) + ")");
            rai_st_ok(_r, (_a.ankle[1][0] - _a.ankle[0][0]) > _a.w_hip * 0.80,
                      _nm + ": the ankles are "
                      + string_format(_a.ankle[1][0] - _a.ankle[0][0], 1, 5) + " apart");

            // ⭐ THE LIFT BAND, AND IT IS TWO-SIDED ON PURPOSE. A standing pose has to put both feet
            // ON the sole - the segment-length budget in rai_armature exists to make that true and a
            // larger swing angle silently re-opens it - and a SEATED pose has to take them OFF it,
            // because the hips do not drop in this model, so a `sit` reading zero means the pose did
            // not happen. A one-sided ceiling with `sit` exempted would be a bar widened to fit
            // today's data (master 2b); a band goes red in both directions.
            //
            // ⛔ THE SEATED HALF OF THE BAND USED TO READ [span*0.050, span*0.140] AND BOTH NUMBERS
            // WERE ABOUT NOTHING. A seated ankle rises by exactly the part of the thigh a front view
            // stops seeing, so the quantity being bounded is a fraction of the THIGH - and stated
            // that way the bar says something anatomical instead of restating whatever the pose
            // happened to solve to. Under 45% of the thigh the figure is a short standing person,
            // which is precisely what the old ceiling permitted and what shipped: the previous
            // `sit` lifted 0.0913 of stature, i.e. 0.397 of its own thigh, and PASSED.
            // Re-derived 2026-09-02; it goes red on the pose it replaced, which is what makes it a
            // test rather than a restatement (master 2b: a bar re-derived from the thing it is about,
            // never widened to fit today's data).
            var _standing = (_a.y_sole - _a.foot_h);
            for (_k = 0; _k < 2; _k++) {
                var _lift = _standing - _a.ankle[_k][1];
                var _seated = (_poses[_j] == "sit");
                var _lo = _seated ? (_a.len_thigh * 0.45) : (-RAI_ST_EPS);
                var _hi = _seated ? (_a.len_thigh * 0.95) : (_a.span * 0.030);
                rai_st_ok(_r, _lift >= _lo && _lift <= _hi,
                          _nm + ": foot " + string(_k) + " sits " + string_format(_lift, 1, 5)
                          + " off the sole, outside the " + (_seated ? "SEATED" : "STANDING")
                          + " band [" + string_format(_lo, 1, 5) + ", "
                          + string_format(_hi, 1, 5) + "]");
            }
        }
    }

    // POSITIVE CONTROL FOR THE LEG RULES, built to the same standard as the arm one below it: the
    // break has to CREATE the defect rather than rename something. This is the shipped-until-now leg
    // arithmetic, verbatim in shape - a mirrored picture-plane swing at `sit`'s own hip angle - and
    // the stance floor above must REJECT it.
    var _lc = rai_armature("average", "sit");
    var _lc_p = rai_pose("sit");
    var _lc_leg = (_lc.y_sole - _lc.y_hip);
    var _lc_thigh = (_lc_leg - _lc_leg * 0.095) * 0.470;
    var _lc_bad_l = -_lc.w_hip + sin(_lc_p.hp *  1) * _lc_thigh * 0.46;
    var _lc_bad_r =  _lc.w_hip + sin(_lc_p.hp * -1) * _lc_thigh * 0.46;
    rai_st_ok(_r, (_lc_bad_r - _lc_bad_l) <= _lc.w_hip,
              "CONTROL: the stance floor cannot see the mirrored-swing defect it was written for");
    // ...and the shipped solve must still clear it, or the rule is simply always red.
    rai_st_ok(_r, (_lc.knee[1][0] - _lc.knee[0][0]) > _lc.w_hip,
              "CONTROL: the stance floor rejects a correctly-solved seated figure (false red)");

    // POSITIVE CONTROL FOR THE LATERALITY RULE, and it is built the way the raiment row of the
    // master green-lie catalogue demands: the break must CREATE THE ASYMMETRY THE CHECK LOOKS FOR,
    // not rename something on both sides of the comparison. This reproduces the defect arithmetic
    // in place - `sin(a * dir) * dir` for one side - and asserts the rule above REJECTS it. Without
    // this the four assertions could be vacuously true and nobody would know.
    var _ctl = rai_armature("average", "stand");
    var _ctl_p = rai_pose("stand");
    var _ctl_arm = rai_pose_arm(_ctl_p, 0);
    var _ctl_dir = -1;
    var _ctl_upper = _ctl.span * 0.166;
    var _ctl_sx = _ctl.shoulder[0][0];
    // The shipped-until-now expression, verbatim in shape: the extra `* _ctl_dir` is the defect.
    var _ctl_bad = _ctl_sx + sin(_ctl_arm[0] * _ctl_dir) * _ctl_upper * _ctl_dir;
    rai_st_ok(_r, (_ctl_bad - _ctl_sx) * _ctl_dir < -RAI_ST_EPS,
              "CONTROL: the laterality rule cannot see the double-_dir defect it was written for");
    // ...and the corrected expression must still PASS it, or the rule is simply always red.
    var _ctl_good = _ctl_sx + sin(_ctl_arm[0] * _ctl_dir) * _ctl_upper;
    rai_st_ok(_r, (_ctl_good - _ctl_sx) * _ctl_dir >= -RAI_ST_EPS,
              "CONTROL: the laterality rule rejects a correctly-solved left arm (false red)");

    // -- STAGE 3: THE FUNCTION THE PRODUCT RESTS ON ---------------------------------------------
    // rai_body_halfwidth is what lets a garment know how wide the body is where it falls. If it is
    // flat across builds, every garment is flat across builds and the product is an atlas.
    global.rai_stage = 3;
    var _slight = rai_armature("slight", "stand");
    var _broad = rai_armature("broad", "stand");
    rai_st_ok(_r, rai_body_halfwidth(_slight, _slight.y_shoulder - 0.05) <= 0,
              "halfwidth: returns a width above the shoulders");
    rai_st_ok(_r, rai_body_halfwidth(_slight, _slight.y_sole + 0.05) <= 0,
              "halfwidth: returns a width below the sole");
    var _chest = lerp(_slight.y_shoulder, _slight.y_waist, 0.4);
    rai_st_ok(_r, rai_body_halfwidth(_slight, _chest) > 0, "halfwidth: zero at the chest");
    // VACUITY GUARD AND THE REAL ASSERTION AT ONCE: a broad figure is wider than a slight one.
    rai_st_ok(_r, rai_body_halfwidth(_broad, _chest) > rai_body_halfwidth(_slight, _chest) + RAI_ST_EPS,
              "halfwidth: broad and slight builds measure the same at the chest");

    // -- STAGE 4: THE DRAPE FOLLOWS THE BODY, AND IT MOVES WHEN THE BODY DOES --------------------
    global.rai_stage = 4;
    for (_i = 0; _i < array_length(_cloth); _i++) {
        var _cf = _cloth[_i];
        var _ccut = rai_garment_cut(_cf);
        var _cd = rai_drape_of(_ccut.drape);

        for (_j = 0; _j < array_length(_builds); _j++) {
            var _ar = rai_armature(_builds[_j], "stand");
            var _y0 = rai_garment_y(_ar, _ccut.top);
            var _y1 = rai_garment_y(_ar, _ccut.bottom);
            if (_y1 <= _y0) continue;                    // the sash is a band, not a panel
            // Cloth is OUTSIDE the body at every sampled height. rai_drape's header states the
            // corollary: anything asserting bounds here must assert the STROKED outline, which is
            // systematically larger than the anchors.
            for (_k = 0; _k <= 6; _k++) {
                _y = lerp(_y0, _y1, _k / 6);
                _w = rai_drape_halfwidth(_ar, _y, _y0, _y1, _cd);
                rai_st_ok(_r, _w >= rai_body_halfwidth(_ar, _y) - RAI_ST_EPS,
                          _cf + "/" + _builds[_j] + ": cloth is inside the body at t="
                          + string(_k) + "/6");
            }
            var _ring = rai_drape_ring(_ar, _y0, _y1, _cd, _ccut.sag);
            rai_st_ok(_r, array_length(_ring) >= 6, _cf + ": drape ring is degenerate");
            rai_st_ok(_r, rai_is_simple(_ring), _cf + "/" + _builds[_j] + ": drape ring self-intersects");
        }

        // ⭐ THE ASSERTION THE PRODUCT IS SOLD ON. The same family on a slight body and a broad body
        // must be a DIFFERENT OUTLINE. A layered sprite cannot do this; if this ever passes
        // vacuously the product has become the incumbent it was built to replace.
        var _as = rai_armature("slight", "stand");
        var _ab = rai_armature("broad", "stand");
        var _ys0 = rai_garment_y(_as, _ccut.top);
        var _ys1 = rai_garment_y(_as, _ccut.bottom);
        var _yb0 = rai_garment_y(_ab, _ccut.top);
        var _yb1 = rai_garment_y(_ab, _ccut.bottom);
        if (_ys1 > _ys0 && _yb1 > _yb0) {
            var _mid_s = rai_drape_halfwidth(_as, lerp(_ys0, _ys1, 0.4), _ys0, _ys1, _cd);
            var _mid_b = rai_drape_halfwidth(_ab, lerp(_yb0, _yb1, 0.4), _yb0, _yb1, _cd);
            var _d = abs(_mid_b - _mid_s);
            if (_d > _drapeSpread) { _drapeSpread = _d; _drapeSpreadName = _cf; }
            rai_st_ok(_r, _d > RAI_ST_EPS * 10,
                      _cf + ": the same garment measures the same on a slight and a broad build "
                      + "- it is not following the body");
        }
    }

    // -- STAGE 5: RIGID IS RIGID ----------------------------------------------------------------
    // ⛔ THE ONE ASSERTION KEEPING THE TWO BUILDERS APART. Cloth accumulates material downward;
    // steel does not. Measured as the STAND-OFF at the hem minus the stand-off at the top, outside
    // the deliberate bell region, so the bell cannot satisfy it by accident.
    global.rai_stage = 5;
    for (_i = 0; _i < array_length(_armour); _i++) {
        var _af = _armour[_i];
        var _asp = rai_armour_spec(_af);
        var _aa = rai_armature("average", "stand");
        var _ay0 = rai_garment_y(_aa, _asp.top);
        var _ay1 = rai_garment_y(_aa, _asp.bottom);
        var _shell = rai_shell_ring(_aa, _ay0, _ay1, _asp.stand, 0.018);
        rai_st_ok(_r, rai_is_simple(_shell), _af + ": shell ring self-intersects");
        rai_st_ok(_r, array_length(_shell) >= 6, _af + ": shell ring is degenerate");

        if (_asp.rigid) {
            // ⛔ THE TOP SAMPLE USED TO SIT AT 0.10 AND THAT IS NOW INSIDE THE ARMHOLE. It was
            // chosen when rai_shell_ring's top was flat by construction; the armhole added
            // 2026-09-02 deliberately draws the first quarter IN, so a sample there measures the
            // SHAPE and reports it as gathering - all four rigid families went red at 188% to 591%
            // on a change that added no material anywhere. Moved to 0.35, which is the first
            // station outside the cut.
            //
            // ⚠️ AND MOVING A SAMPLE OUT OF A REGION REMOVES THAT REGION FROM COVERAGE, WHICH IS
            // HOW A BAR GETS QUIETLY WIDENED TO FIT TODAY'S DATA. The top quarter is not left
            // untested: the armhole gets its own two-sided assertion below, so the shape that
            // displaced this sample now has to prove it is present AND bounded.
            var _yTop = lerp(_ay0, _ay1, 0.35);
            var _yLow = lerp(_ay0, _ay1, 0.70);          // 0.70 is inside the flat region
            var _offTop = rai_ring_halfwidth_at(_shell, _yTop) - rai_body_halfwidth(_aa, _yTop);
            var _offLow = rai_ring_halfwidth_at(_shell, _yLow) - rai_body_halfwidth(_aa, _yLow);
            var _gather = abs(_offLow - _offTop) / max(RAI_ST_EPS, _offTop);
            if (_gather > _rigidGather) { _rigidGather = _gather; _rigidGatherName = _af; }
            rai_st_ok(_r, _gather < 0.20,
                      _af + ": rigid shell gathers " + string_format(_gather * 100, 1, 1)
                      + "% downward - that is cloth behaviour");

            // THE ARMHOLE, ASSERTED FROM BOTH SIDES. Too little and the piece is the full-width bar
            // that made four of six cells on sheet 4 read as a board; too much and the cut eats the
            // chest the armour is there to cover. Measured as how much narrower the shell's lip is
            // than its flat region, in units of the shoulder it is cutting away from.
            var _yLip = lerp(_ay0, _ay1, 0.02);
            var _offLip = rai_ring_halfwidth_at(_shell, _yLip) - rai_body_halfwidth(_aa, _yLip);
            var _cut = (_offTop - _offLip) / max(RAI_ST_EPS, _aa.w_shoulder);
            rai_st_ok(_r, _cut > 0.15,
                      _af + ": the shell has no armhole - its lip is "
                      + string_format(_cut * 100, 1, 1)
                      + "% of a shoulder narrower than its chest, so it is a full-width bar");
            rai_st_ok(_r, _cut < 0.45,
                      _af + ": the armhole cuts " + string_format(_cut * 100, 1, 1)
                      + "% of a shoulder off the lip - that is a bib, not a cuirass");

            // The neck scoop is applied in rai_armour_parts AFTER rai_hem_shape, so it has to be
            // built the same way here or this assertion is about a ring the product never draws.
            var _scoop = rai_shell_neck(rai_hem_shape(_shell, _asp.hem, _aa.span * 0.022),
                                        _aa, _ay0, _aa.span * 0.030);
            rai_st_ok(_r, rai_is_simple(_scoop), _af + ": the neck-scooped shell self-intersects");
            rai_st_ok(_r, array_length(_scoop) == array_length(rai_hem_shape(_shell, _asp.hem, _aa.span * 0.022)) + 4,
                      _af + ": the neck scoop added no points - the top chord is still a bar");
        }
    }
    // VACUITY GUARD, and it is the important half: a CLOTH panel must FAIL that same test, or the
    // rigid assertion is passing because the measurement cannot see gathering at all.
    var _va = rai_armature("average", "stand");
    var _vcut = rai_garment_cut("robe");
    var _vd = rai_drape_of(_vcut.drape);
    var _vy0 = rai_garment_y(_va, _vcut.top);
    var _vy1 = rai_garment_y(_va, _vcut.bottom);
    var _vRing = rai_drape_ring(_va, _vy0, _vy1, _vd, 0);
    var _vTop = lerp(_vy0, _vy1, 0.10);
    var _vLow = lerp(_vy0, _vy1, 0.70);
    var _vOffTop = rai_ring_halfwidth_at(_vRing, _vTop) - rai_body_halfwidth(_va, _vTop);
    var _vOffLow = rai_ring_halfwidth_at(_vRing, _vLow) - rai_body_halfwidth(_va, _vLow);
    var _vGather = abs(_vOffLow - _vOffTop) / max(RAI_ST_EPS, _vOffTop);
    rai_st_ok(_r, _vGather >= 0.20,
              "VACUITY: a full robe gathers only " + string_format(_vGather * 100, 1, 1)
              + "% - the rigidity test cannot detect gathering, so STAGE 5 proves nothing");

    // -- STAGE 6: THE HEMS ----------------------------------------------------------------------
    global.rai_stage = 6;
    var _hbase = rai_shell_ring(_va, _va.y_shoulder, _va.y_hip, 0.014, 0.004);
    var _hn = array_length(_hbase);
    rai_st_ok(_r, array_length(rai_hem_shape(_hbase, "straight", 0.02)) == _hn,
              "hem: 'straight' changed the ring");
    var _scal = rai_hem_shape(_hbase, "scallop", 0.02);
    rai_st_ok(_r, array_length(_scal) > _hn, "hem: 'scallop' added no points");
    rai_st_ok(_r, rai_is_simple(_scal), "hem: scalloped ring self-intersects");
    var _pnt = rai_hem_shape(_hbase, "point", 0.02);
    rai_st_ok(_r, array_length(_pnt) == _hn + 1, "hem: 'point' did not add exactly one point");
    rai_st_ok(_r, rai_is_simple(_pnt), "hem: pointed ring self-intersects");
    var _flr = rai_hem_shape(_hbase, "flare", 0.02);
    rai_st_ok(_r, array_length(_flr) == _hn + 2, "hem: 'flare' did not add exactly two points");
    rai_st_ok(_r, rai_is_simple(_flr), "hem: flared ring self-intersects");

    // ⛔⛔ EVERYTHING ABOVE THIS LINE IS A SHELL RING, AND NO SHIPPED SCALLOP IS ONE. The three
    // assertions on `_scal` were green for weeks over a hem that self-intersected on both flexible
    // families, because a shell ring is the one shape whose bottom run the old midpoint rule located
    // correctly. mail and scale - the ONLY two families that ask for a scallop - go through
    // rai_drape_ring, which puts five hem-sag samples between the two runs and moves the midpoint
    // onto the middle of the hem. MEASURED 2026-09-02 at 8x on sheet_4_armour: a straight-cut hem
    // with a ragged self-intersecting knot in the centre of it, enclosing a hole of background, on a
    // sheet captioned "mail ... scallops at the hem".
    //
    // ⭐ A HARNESS THAT ONLY EVER CONSTRUCTS ONE INPUT SHAPE HAS AN OPINION ABOUT ONE INPUT SHAPE.
    // The fixture below is the call rai_armour_parts actually makes, built from the same spec and the
    // same rai_armour_drape the product uses, so it cannot drift away from it.
    var _hmSp = rai_armour_spec("mail");
    var _hmY0 = rai_garment_y(_va, _hmSp.top);
    var _hmY1 = rai_garment_y(_va, _hmSp.bottom);
    var _hmRing = rai_drape_ring(_va, _hmY0, _hmY1, rai_armour_drape(_hmSp), 0.004);
    var _hmOut = rai_hem_shape(_hmRing, _hmSp.hem, _va.span * 0.022);
    rai_st_ok(_r, _hmSp.hem == "scallop",
              "VACUITY: mail no longer asks for a scallop, so this fixture proves nothing");
    rai_st_ok(_r, rai_is_simple(_hmOut),
              "hem: the SHIPPED mail hem (drape ring with a sag) self-intersects");
    rai_st_ok(_r, array_length(_hmOut) > array_length(_hmRing),
              "hem: the shipped mail hem added no points");
    // ⛔⛔ AND THE ASSERTION ABOVE IS NOT THE ONE THAT CATCHES THIS DEFECT. Reinstating the shipped
    // hem rule and running rai_is_simple over the result returns TRUE - measured 2026-09-02 - on a
    // corselet photographed at 8x with a visible enclosed hole in its hem. The outline never crossed
    // itself; the FAN that fills it walked two of its wedges backwards over each other. Wing
    // CLAUDE.md's Welkin entry is the general law and rai_ring_fan_safe is the instrument for it:
    // it models rai_ring_fill's own apex and walk instead of asking a question about the geometry.
    rai_st_ok(_r, rai_ring_fan_safe(_hmOut, 0, (_hmY0 + _hmY1) * 0.5),
              "hem: rai_ring_fill cannot fill the shipped mail hem from its own apex - the fan "
              + "doubles back and leaves a hole");

    // ⛔⛔ AND NEITHER OF THE TWO ASSERTIONS ABOVE IS THE ONE THAT CATCHES THIS DEFECT EITHER, WHICH
    // IS THE WHOLE LESSON OF THE DAY. The shipped hem was reinstated verbatim - old indices, old
    // guard, old generator - and rai_is_simple returned TRUE and rai_ring_fan_safe returned TRUE.
    // Both were measured, both times, before this block was written. The outline never crossed itself
    // and the fan never folded: the geometry was simply WRONG, and wrong geometry rendered at 8x is
    // what looked like a tangle. Two plausible mechanisms, two build cycles, both falsified by the
    // break test that was supposed to confirm them.
    //
    // ⭐ THE PROPERTY THAT WAS ACTUALLY VIOLATED IS THE OBVIOUS ONE: A SCALLOPED HEM MUST SCALLOP THE
    // WHOLE HEM. Locating the hem at the array midpoint put all seven lobes inside a sliver a third
    // of a half-width wide, entirely on the RIGHT of the centre line, leaving five sixths of the hem
    // a straight cut - so the test is that the lobes reach both sides. Under the shipped rule the
    // left-hand count is ZERO.
    var _hmY = _hmY1;
    var _hmK;
    var _hmL = 0;
    var _hmR = 0;
    for (_hmK = 0; _hmK < array_length(_hmOut); _hmK++) {
        if (_hmOut[_hmK][1] > _hmY + _va.span * 0.022 * 0.50) {
            if (_hmOut[_hmK][0] < 0) _hmL++;
            if (_hmOut[_hmK][0] > 0) _hmR++;
        }
    }
    rai_st_ok(_r, _hmL >= 2 && _hmR >= 2,
              "hem: the shipped mail hem has " + string(_hmL) + " deep lobes left of the centre and "
              + string(_hmR) + " right of it - a scallop that does not reach both sides is a straight "
              + "cut with a knot in the middle of it");

    // The finder must land on the run rai_drape_ring actually built: the last side sample, five sag
    // samples, the first sample of the other side.
    var _hmIdx = rai_hem_span(_hmRing);
    rai_st_ok(_r, _hmIdx[0] == RAI_DRAPE_STEPS && _hmIdx[1] == RAI_DRAPE_STEPS + 6,
              "hem: rai_hem_span put the bottom run at [" + string(_hmIdx[0]) + ","
              + string(_hmIdx[1]) + "] on a drape ring, not ["
              + string(RAI_DRAPE_STEPS) + "," + string(RAI_DRAPE_STEPS + 6) + "]");
    // ⚠️ AND THE VACUITY GUARD THAT MAKES THE THREE ABOVE MEAN ANYTHING. If the old midpoint rule and
    // the structural finder agree on this fixture then the fixture does not exercise the defect, and
    // the whole block is decoration. They must DISAGREE here.
    rai_st_ok(_r, _hmIdx[0] != (array_length(_hmRing) div 2) - 1,
              "VACUITY: the midpoint guess and rai_hem_span agree on the shipped ring, so this "
              + "fixture cannot detect the defect it was written for");

    // ⛔ THE MATERIALS SHEET MAKES A CLAIM ABOUT TWO NAMED MATERIALS, SO THE CLAIM IS ASSERTED HERE.
    // It used to name linen and silk, which are 242 degrees apart in hue - a sentence the picture
    // directly under it refuted, on a live store sheet. A caption that cites data has to be tested
    // like data, or the next edit to the material table makes it false again in silence.
    var _mpA = rai_material_def(RAI_BK_PAIR_A);
    var _mpB = rai_material_def(RAI_BK_PAIR_B);
    rai_st_ok(_r, abs(_mpA.L - _mpB.L) <= 0.05,
              "caption: " + RAI_BK_PAIR_A + " and " + RAI_BK_PAIR_B + " are "
              + string_format(abs(_mpA.L - _mpB.L), 1, 3)
              + " apart in lightness - the sheet says they are close in colour");
    rai_st_ok(_r, abs(_mpA.C - _mpB.C) <= 0.02,
              "caption: " + RAI_BK_PAIR_A + " and " + RAI_BK_PAIR_B + " differ in chroma by "
              + string_format(abs(_mpA.C - _mpB.C), 1, 3) + " - not close in colour");
    rai_st_ok(_r, abs(_mpA.h - _mpB.h) <= 40,
              "caption: " + RAI_BK_PAIR_A + " and " + RAI_BK_PAIR_B + " are "
              + string_format(abs(_mpA.h - _mpB.h), 1, 0) + " degrees apart in hue");
    // ...and the other half of the sentence, without which "close in colour" is satisfied by naming
    // one material twice.
    rai_st_ok(_r, _mpA.surface != _mpB.surface && _mpA.drape != _mpB.drape,
              "caption: " + RAI_BK_PAIR_A + " and " + RAI_BK_PAIR_B + " share a surface character or "
              + "a drape - the sheet says they are nothing alike");

    // A ring whose bottom run does not STRADDLE the centre line is not a hem, and must come back
    // unshaped rather than folded. Offset far enough that both ends are on the same side whichever
    // way the ellipse is wound, so this cannot pass for the wrong reason.
    var _hmOff = rai_ellipse_pts(0.50, 0, 0.10, 0.10, 24);
    rai_st_ok(_r, array_length(rai_hem_shape(_hmOff, "scallop", 0.02)) == array_length(_hmOff),
              "hem: a bottom run entirely on one side of the centre was shaped anyway");
    // ⚠️ AND THE OTHER HALF, OR THE REFUSAL ABOVE IS SATISFIED BY A FUNCTION THAT REFUSES EVERYTHING.
    // The same ellipse on the centre line IS a shapeable ring and must be shaped.
    var _hmCen = rai_ellipse_pts(0, 0, 0.10, 0.10, 24);
    rai_st_ok(_r, array_length(rai_hem_shape(_hmCen, "scallop", 0.02)) > array_length(_hmCen),
              "VACUITY: rai_hem_shape refuses a centred ring too, so the refusal test above proves "
              + "only that it refuses everything");

    // -- STAGE 7: THE TEXTURE CLIP, IN BOTH DIRECTIONS ------------------------------------------
    // ⛔ BOTH DIRECTIONS OR NEITHER. A clip that drops everything passes a "nothing outside" test
    // perfectly, and a clip that keeps everything passes a "the texture is still there" test just
    // as perfectly. Only the pair says anything.
    global.rai_stage = 7;
    var _cring = rai_shell_ring(_va, _va.y_shoulder, _va.y_hip, 0.014, 0.004);
    var _cbb = rai_pts_bounds(_cring);
    var _inX = 0;
    var _inY = lerp(_cbb[1], _cbb[3], 0.5);
    var _far = rai_ring_halfwidth_at(_cring, _inY) * 3 + 0.2;
    // A mark at the centre of the piece must survive; the same mark far outside must not.
    rai_st_ok(_r, !is_undefined(rai_clip_part_to_ring(rai_dot(_inX, _inY, 0.004, "m2"), _cring)),
              "clip: dropped a dot at the centre of the piece");
    rai_st_ok(_r, is_undefined(rai_clip_part_to_ring(rai_dot(_far, _inY, 0.004, "m2"), _cring)),
              "clip: kept a dot well outside the piece");
    rai_st_ok(_r, !is_undefined(rai_clip_part_to_ring(rai_ring(_inX, _inY, 0.006, 0.001, "m2"), _cring)),
              "clip: dropped a mail RING at the centre of the piece");
    rai_st_ok(_r, is_undefined(rai_clip_part_to_ring(rai_ring(_far, _inY, 0.006, 0.001, "m2"), _cring)),
              "clip: kept a mail RING well outside the piece - ARCs are not being clipped");
    rai_st_ok(_r, is_undefined(rai_clip_part_to_ring(rai_dot(_inX, _cbb[3] + 0.2, 0.004, "m2"), _cring)),
              "clip: kept a dot below the piece");
    // And it must actually narrow a line rather than pass it through.
    var _line = rai_poly([[-_far, _inY], [_far, _inY]], false, 0.002, "m1");
    var _clipped = rai_clip_part_to_ring(_line, _cring);
    rai_st_ok(_r, !is_undefined(_clipped), "clip: dropped a line crossing the piece entirely");
    if (!is_undefined(_clipped)) {
        var _cw = abs(_clipped.pts[0][0]) + abs(_clipped.pts[array_length(_clipped.pts) - 1][0]);
        rai_st_ok(_r, _cw < _far * 2 - RAI_ST_EPS, "clip: a crossing line was not narrowed at all");
        _clipKept += 1;
    }
    _clipDropped += 1;

    // -- STAGE 8: THE EQUIP MODEL ---------------------------------------------------------------
    global.rai_stage = 8;
    var _two = rai_outfit_resolve([rai_item("cloth", "tunic", "linen"),
                                   rai_item("cloth", "robe", "wool")]);
    rai_st_ok(_r, array_length(_two) == 1,
              "equip: two body garments both survived - the slot rule is not firing");
    if (array_length(_two) > 0) {
        rai_st_ok(_r, _two[0].family == "robe", "equip: the LATER item did not win its slot");
    }
    // Layer order, and the back band before everything.
    var _set = rai_outfit_resolve([rai_item("cloth", "coat", "wool"),
                                   rai_item("cloth", "cloak", "felt"),
                                   rai_item("cloth", "trousers", "canvas"),
                                   rai_item("cloth", "tunic", "linen")]);
    rai_st_ok(_r, array_length(_set) == 4, "equip: four different slots did not all survive");
    var _ordered = true;
    for (_i = 1; _i < array_length(_set); _i++) {
        if (_set[_i].layer < _set[_i - 1].layer) _ordered = false;
    }
    rai_st_ok(_r, _ordered, "equip: the resolved set is not in layer order");
    if (array_length(_set) > 0) {
        rai_st_ok(_r, _set[0].family == "cloak", "equip: the cloak is not drawn first (behind)");
    }
    // Occlusion, both directions. A tunic under a coat is mostly covered; a sash covers nothing.
    var _occ = rai_outfit_resolve([rai_item("cloth", "tunic", "linen"),
                                   rai_item("cloth", "coat", "wool")]);
    rai_st_ok(_r, rai_item_covered(_va, _occ, 0) >= 0.75,
              "occlusion: a tunic under a coat reads as uncovered");
    var _occ2 = rai_outfit_resolve([rai_item("cloth", "tunic", "linen"),
                                    rai_item("cloth", "sash", "madder")]);
    rai_st_ok(_r, rai_item_covered(_va, _occ2, 0) < 0.75,
              "VACUITY: a sash counts as covering a tunic, so the occlusion test is measuring "
              + "layer count rather than coverage");

    // -- STAGE 9: EVERY ROLE THE FIGURE ASKS FOR EXISTS IN THE PALETTE IT IS DRAWN WITH ----------
    // ⛔ THE ONLY MECHANICAL CHECK ON THE NAMESPACING. rai_render_colour falls back to `line` on a
    // miss, so the failure mode is a figure drawn entirely in outline colour - visible to an eye
    // and invisible to everything else.
    global.rai_stage = 9;
    var _fig = rai_figure("average", "stand",
                          [rai_item("cloth", "trousers", "canvas"),
                           rai_item("cloth", "tunic", "linen"),
                           rai_item("armour", "plate", "steel"),
                           rai_item("cloth", "cloak", "wool")], "buckskin");
    var _used = rai_roles_used(_fig.parts);
    var _missing = 0;
    for (_i = 0; _i < array_length(_used); _i++) {
        if (!variable_struct_exists(_fig.palette, _used[_i])) {
            _missing += 1;
            rai_st_ok(_r, false, "palette: no colour for role '" + string(_used[_i]) + "'");
        }
    }
    rai_st_ok(_r, _missing == 0, "palette: " + string(_missing) + " role(s) unresolved");
    rai_st_ok(_r, array_length(_fig.parts) > 40,
              "figure: only " + string(array_length(_fig.parts)) + " parts - the assembly is thin");
    // VACUITY GUARD: the lookup must be able to say NO.
    rai_st_ok(_r, !variable_struct_exists(_fig.palette, "zz_not_a_role"),
              "VACUITY: the palette claims to carry a role that does not exist");
    // Four items and a body means five namespaces, so more than one ramp is genuinely present.
    var _distinctRamps = 0;
    var _pkeys = variable_struct_get_names(_fig.palette);
    for (_i = 0; _i < array_length(_pkeys); _i++) {
        if (string_pos("_m2", _pkeys[_i]) > 0) _distinctRamps += 1;
    }
    rai_st_ok(_r, _distinctRamps >= 5,
              "palette: " + string(_distinctRamps) + " ramps for a five-material figure - the "
              + "namespacing has collapsed them");

    // -- STAGE 9b: NO PART ESCAPES THE UNIT BOX --------------------------------------------------
    //
    // ⛔⛔ NOTHING IN THIS SUITE COULD SEE A PART OUTSIDE THE FIGURE, AND rai_st_stamp IS THE REASON.
    // The occupancy stamper - the instrument every distinctness and coverage assertion is built on -
    // guards each write with `if (_px >= 0 && _px < _n)`, so a point outside the unit box is
    // SILENTLY DROPPED. That guard is correct for an array write and it makes the grid structurally
    // incapable of reporting the one thing being checked here.
    //
    // ⭐ WHY IT MATTERS, MEASURED 2026-09-02 off the baked sheet: `rai_render_bounds` is honest and
    // includes every part, so one escaping part inflates the figure's BOX without adding any ink -
    // and rai_bake scales a figure to its box. On sheet 7 each figure rendered ~494px inside a 749px
    // well, a box about 1.47x its own drawing, leaving 34%-40% of every cell as dead air and failing
    // gate1_review question 3 on a sheet where the figures themselves were fine. Two plausible
    // layout explanations were written and both were falsified by re-baking before the cause was
    // understood to be the box rather than the layout.
    //
    // The vertical extent of a figure is anatomically bounded - RAI_CROWN -0.470 to RAI_SOLE 0.470 -
    // so 0.55 is a generous margin that still catches anything meaningfully outside. X is NOT
    // asserted: an outstretched arm legitimately reaches past 0.5 and that is the pose working.
    global.rai_stage = 9;
    var _escaped = 0;
    var _worstY = 0;
    var _worstWhat = "";
    for (_j = 0; _j < array_length(_poses); _j++) {
        var _pf = rai_figure("tall", _poses[_j],
                             [rai_item("cloth", "trousers", "charcoal"),
                              rai_item("cloth", "coat", "velvet"),
                              rai_item("cloth", "cloak", "tyrian")], "suede",
                             { style: "long", material: "charcoal" });
        for (_i = 0; _i < array_length(_pf.parts); _i++) {
            var _ext = rai_st_part_y_extent(_pf.parts[_i]);
            var _off = max(abs(_ext[0]), abs(_ext[1]));
            if (_off > 0.55) {
                _escaped += 1;
                if (_off > _worstY) {
                    _worstY = _off;
                    _worstWhat = _poses[_j] + " part " + string(_i)
                                 + " kind " + string(_pf.parts[_i].kind)
                                 + " role " + string(_pf.parts[_i].role);
                }
            }
        }
    }
    rai_st_ok(_r, _escaped == 0,
              "UNIT BOX: " + string(_escaped) + " part(s) reach past y +-0.55 - worst "
              + string_format(_worstY, 1, 4) + " at " + _worstWhat
              + ". An escaping part adds no ink and inflates the figure's bounding box, which is "
              + "what rai_bake scales to.");
    // VACUITY GUARD: the extent reader must be able to report a real number, or the sweep above
    // passes over nothing. A head dot always exists and always sits well inside the box.
    var _probeFig = rai_figure("tall", "stand", [], "suede", { style: "long", material: "charcoal" });
    rai_st_ok(_r, array_length(_probeFig.parts) > 0
              && abs(rai_st_part_y_extent(_probeFig.parts[0])[1]) > 0.0001,
              "VACUITY: the unit-box sweep read a zero extent for a real part");

    // -- STAGE 9c: THE BOUNDING BOX IS THE FIGURE ------------------------------------------------
    //
    // ⛔⛔ STAGE 9b ABOVE IS TRUE AND NOT SUFFICIENT, AND THE GAP BETWEEN THEM IS A WHOLE STORE SHEET.
    // 9b asks whether any part ESCAPES the unit box; this asks whether the box rai_bake scales to is
    // the FIGURE. Both can hold at once - every part inside +-0.55 and the box still half again as
    // tall as the drawing - and when they do, a sheet lays the figure out against a box bigger than
    // the picture and the difference becomes dead page. MEASURED on the 2026-09-02 bake of sheet 7:
    // 34%-40% of every cell was empty, all of it above the heads, while 9b passed.
    //
    // ⭐ THE FIGURE'S REAL VERTICAL EXTENT IS KNOWN EXACTLY - y_crown to y_sole - so this needs no
    // rendering and no threshold-guessing off a PNG. Hair rises about 1.5% of stature past the crown
    // and a knot on `bound` about 2.3%, so 12% is generous and still catches anything that inflates
    // the box by the ~47% the sheet showed.
    //
    // ⚠️ AND IT NAMES THE OFFENDER. The role strings in a figure are namespaced by item ("sk_" body,
    // "hr_" hair, "b0_"/"f1_" the worn items in draw order), so the failure message says which
    // garment or which body part is responsible - which is the thing four sessions of guessing at
    // this could not produce.
    global.rai_stage = 9;
    var _boxWorst = 0;
    var _boxWhat = "";
    var _boxSwept = 0;
    var _noDraw = 0;
    var _noDrawWhat = "";
    var _boxSets = [[rai_item("cloth", "trousers", "charcoal"),
                     rai_item("cloth", "coat", "velvet"),
                     rai_item("cloth", "cloak", "tyrian")],
                    [rai_item("cloth", "robe", "linen")],
                    [rai_item("cloth", "trousers", "canvas"),
                     rai_item("cloth", "tunic", "linen"),
                     rai_item("armour", "plate", "steel")],
                    []];
    for (_j = 0; _j < array_length(_poses); _j++) {
        for (_i = 0; _i < array_length(_boxSets); _i++) {
            var _bf = rai_figure("tall", _poses[_j], _boxSets[_i], "suede",
                                 { style: "long", material: "charcoal" });
            var _bbx = rai_render_bounds(_bf.parts);
            var _anat = _bf.arm.y_sole - _bf.arm.y_crown;
            var _ratio = (_bbx[3] - _bbx[1]) / max(0.0001, _anat);
            _boxSwept += 1;
            var _nd = rai_render_nodraw_count(_bf.parts);
            if (_nd > 0 && _noDraw == 0) {
                _noDrawWhat = _poses[_j] + " outfit " + string(_i) + ": " + string(_nd)
                              + " part(s) measured but never drawn";
            }
            _noDraw += _nd;
            if (_ratio > _boxWorst) {
                _boxWorst = _ratio;
                var _tp = rai_render_top_part(_bf.parts);
                _boxWhat = _poses[_j] + " outfit " + string(_i)
                           + ": box " + string_format(_bbx[3] - _bbx[1], 1, 4)
                           + " vs crown-to-sole " + string_format(_anat, 1, 4)
                           + ", box top " + string_format(_bbx[1], 1, 4)
                           + " crown " + string_format(_bf.arm.y_crown, 1, 4)
                           + ", topmost drawn part #" + string(_tp.index)
                           + " kind " + string(_tp.kind) + " role '" + string(_tp.role)
                           + "' at y " + string_format(_tp.y, 1, 4);
            }
        }
    }
    rai_st_ok(_r, _boxWorst <= 1.12,
              "BOX vs FIGURE: the bounding box is " + string_format(_boxWorst, 1, 3)
              + "x the anatomical crown-to-sole extent - " + _boxWhat
              + ". rai_bake scales a figure to this box, so every percent above 1.0 is dead page.");
    // ⛔ A PART MEASURED BY THE BOX AND REFUSED BY THE RENDERER. rai_render's three primitives each
    // return early on a degenerate input - a fill under three points, a strip whose rails disagree,
    // a polyline under two - and rai_render_bounds used to measure all of them anyway. That is the
    // exact shape that inflates a box without adding ink, and zero is the only correct answer.
    rai_st_ok(_r, _noDraw == 0,
              "NO-DRAW: " + string(_noDraw) + " part(s) exist that nothing draws - " + _noDrawWhat);
    // VACUITY GUARDS. The sweep must have covered every pose and outfit, and the no-draw counter
    // must be able to say YES - a counter that can only return zero is not a check.
    rai_st_ok(_r, _boxSwept == array_length(_poses) * array_length(_boxSets),
              "VACUITY: the box sweep covered " + string(_boxSwept) + " figures, not "
              + string(array_length(_poses) * array_length(_boxSets)));
    rai_st_ok(_r, rai_render_nodraw_count([rai_fill([[0, 0], [1, 1]], "m2")]) == 1,
              "VACUITY: rai_render_nodraw_count cannot see a two-point fill, so its zero means nothing");
    rai_st_ok(_r, rai_render_nodraw_count([rai_fill([[0, 0], [1, 0], [1, 1]], "m2")]) == 0,
              "VACUITY: rai_render_nodraw_count reports a valid three-point fill as no-draw");

    // -- STAGE 10: THE CAST IS DETERMINISTIC AND STABLE UNDER EDITS -----------------------------
    global.rai_stage = 10;
    var _m1 = rai_cast_member("village", 5, "villager");
    var _m2 = rai_cast_member("village", 5, "villager");
    rai_st_ok(_r, _m1.build == _m2.build && _m1.pose == _m2.pose
              && array_length(_m1.worn) == array_length(_m2.worn),
              "cast: the same seed and index produced two different figures");
    var _m3 = rai_cast_member("village", 6, "villager");
    rai_st_ok(_r, _m1.build != _m3.build || _m1.pose != _m3.pose
              || array_length(_m1.worn) != array_length(_m3.worn)
              || (array_length(_m1.worn) > 0 && array_length(_m3.worn) > 0
                  && _m1.worn[0].material != _m3.worn[0].material),
              "cast: two different indices produced the same figure");
    // ⭐ THE STABILITY CLAIM: growing the crowd must not re-roll the members already in it.
    var _small = rai_cast("village", 4, undefined);
    var _big = rai_cast("village", 12, undefined);
    var _stable = true;
    for (_i = 0; _i < 4; _i++) {
        if (_small[_i].archetype != _big[_i].archetype) _stable = false;
        if (_small[_i].build != _big[_i].build) _stable = false;
    }
    rai_st_ok(_r, _stable, "cast: growing the crowd changed the members already in it");
    // Every material a member wears comes from its own archetype's pool.
    var _arches = rai_archetypes_all();
    for (_i = 0; _i < array_length(_arches); _i++) {
        var _mem = rai_cast_member("probe", 3, _arches[_i]);
        var _pool = rai_archetype(_arches[_i]);
        for (_j = 0; _j < array_length(_mem.worn); _j++) {
            var _it = _mem.worn[_j];
            if (_it.kind != "cloth") continue;
            rai_st_ok(_r, rai_has_piece(_pool.cloth, _it.material),
                      _arches[_i] + " is wearing " + _it.material + ", which is not in its pool");
        }
    }

    // -- STAGE 11: THE MATERIALS STILL EXIST AT THE SIZE THEY SHIP AT ---------------------------
    // ⭐ DERIVES THE NUMBER THE README QUOTES. rai_render floors every stroke at RAI_MIN_STROKE
    // pixels, so a surface character whose marks are spaced at a small fraction of the figure has a
    // minimum figure height below which it is not a texture, it is a fill.
    global.rai_stage = 11;
    var _finest = 1;                                   // finest spacing, as a fraction of stature
    var _finestWhat = "";
    var _feat = [["ring", 0.011 * 1.7], ["scale", 0.028 * 0.62], ["weave", 0.030],
                 ["twill", 0.030], ["quilt", 0.055], ["rivet", 0.060]];
    for (_i = 0; _i < array_length(_feat); _i++) {
        if (_feat[_i][1] < _finest) { _finest = _feat[_i][1]; _finestWhat = _feat[_i][0]; }
    }
    // Two marks have to land in different pixels for a texture to read at all, so the spacing must
    // be at least 2 px: figure height >= 2 / spacing_fraction.
    _minFigurePx = ceil(2 / _finest);
    _minFigureWhat = _finestWhat;
    rai_st_ok(_r, _minFigurePx <= RAI_ST_MIN_FIGURE_PX,
              "materials: the finest character (" + _finestWhat + ") needs a "
              + string(_minFigurePx) + "px figure, above the claimed floor of "
              + string(RAI_ST_MIN_FIGURE_PX));
    // VACUITY GUARD: the table above must match what rai_material actually declares. A table that
    // has drifted from the code it describes measures nothing - this asserts the surfaces named
    // here are the surfaces that exist.
    var _surf = rai_surfaces_all();
    for (_i = 0; _i < array_length(_feat); _i++) {
        rai_st_ok(_r, rai_has_piece(_surf, _feat[_i][0]),
                  "STAGE 11 names surface '" + _feat[_i][0] + "', which rai_material does not have");
    }

    // -- STAGE 11b: THE ARMHOLE CAP DOES NOT STAND PROUD OF THE SHOULDER -------------------------
    //
    // ⛔⛔ THIS DEFECT SHIPPED TWICE, IN TWO FILES, FROM ONE COPY-PASTE. rai_garment and rai_armour
    // each drew their own armhole cap. On 2026-09-02 the cloth one was measured at 4x standing 0.58
    // radii above the shoulder line, called "1980s shoulder pads", and moved 0.42 -> 0.86; the
    // armour one was left at 0.42 under a comment claiming it was "tangent to the shoulder line,
    // never over it". The `scale` cell of the armour sheet is what that shipped as, and three
    // sessions tuned the corselet's width and length looking for a cause that was in neither.
    //
    // ⭐ IT IS ASSERTED ON rai_sleeve_cap RATHER THAN ON A FIGURE, AND THE REASON IS FALSE REDS.
    // `coif`, `hood` and `gorget` are all SUPPOSED to sit above y_shoulder - a head covering that
    // stopped at the shoulder would be the bug - so "no worn part rises above the shoulder line" is
    // a rule this product genuinely breaks on purpose, three times, and asserting it would go red on
    // correct art. What is actually invariant is narrower and is about this ONE disc: it exists to
    // round off a square sleeve end, so its job is entirely below the line and anything it puts
    // above the line is spill.
    //
    // ⚠️ THE BOUND IS A REGRESSION GUARD, NOT A CLAIM THAT 0.86 IS OPTIMAL. 0.86 leaves the crown
    // 0.14 radii proud and looks right in the bake; 0.42 leaves it 0.58 proud and does not. 0.25
    // sits between them with room for the value to be re-tuned by eye without this going red, and
    // catches the whole 0.42 class. The picture settles where in that range it lands; this only
    // refuses the regression. Master CLAUDE.md §2b: a bar chosen to fit today's data is worth
    // saying out loud, so it is said here.
    global.rai_stage = 11;
    var _capArm = rai_armature("average", "stand");
    var _capD = rai_drape_of("heavy");
    var _capHw = rai_sleeve_head_w(_capArm, _capD);
    var _capProud = 0;
    var _capSwept = 0;
    for (_i = 0; _i < 2; _i++) {
        var _cap = rai_sleeve_cap(_capArm, _i, _capHw, "m2");
        var _capExt = rai_st_part_y_extent(_cap);
        // Smaller y is UP - RAI_CROWN is negative and RAI_SOLE positive.
        var _proud = (_capArm.shoulder[_i][1] - _capExt[0]) / max(0.0001, _capHw);
        _capSwept += 1;
        if (_proud > _capProud) _capProud = _proud;
    }
    rai_st_ok(_r, _capSwept == 2, "VACUITY: the armhole-cap sweep measured no caps");
    // VACUITY GUARD: a cap of zero radius would satisfy the bound while drawing nothing, so the
    // thing under test must be shown to have real size before its position means anything.
    rai_st_ok(_r, _capHw > _capArm.w_limb,
              "VACUITY: the armhole half-width (" + string_format(_capHw, 1, 4)
              + ") is not larger than the limb it caps");
    rai_st_ok(_r, _capProud <= 0.25,
              "ARMHOLE CAP: the sleeve cap's crown stands " + string_format(_capProud, 1, 3)
              + " of its own radius above y_shoulder, over the 0.25 bound. Nothing can cover that "
              + "band - rai_body_halfwidth returns 0 above the shoulder line - so a proud cap draws "
              + "bare lumps on every family without a pauldron or a coif over it.");

    // -- STAGE 12: NO TWO FAMILIES DRAW THE SAME FIGURE -----------------------------------------
    global.rai_stage = 12;
    var _all = [];
    var _names = [];
    for (_i = 0; _i < array_length(_cloth); _i++) {
        array_push(_all, rai_st_stamp(rai_garment_parts(_va, _cloth[_i],
                                                        rai_material_roles("wool"))));
        array_push(_names, _cloth[_i]);
    }
    for (_i = 0; _i < array_length(_armour); _i++) {
        array_push(_all, rai_st_stamp(rai_armour_parts(_va, _armour[_i],
                                                       rai_material_roles("steel"), "steel")));
        array_push(_names, _armour[_i]);
    }
    var _pairs = 0;
    for (_i = 0; _i < array_length(_all); _i++) {
        for (_j = _i + 1; _j < array_length(_all); _j++) {
            var _dd = rai_st_dist(_all[_i], _all[_j]);
            _pairs += 1;
            var _bucket = min(19, floor(_dd / 0.05));
            _hist[_bucket] += 1;
            if (_dd < _pairWorst) { _pairWorst = _dd; _pairWorstName = _names[_i] + "/" + _names[_j]; }
            if (_dd < RAI_ST_PAIR_FLOOR) {
                _pairBelow += 1;
                rai_st_ok(_r, false, "families " + _names[_i] + " and " + _names[_j]
                          + " draw the same figure (" + string_format(_dd, 1, 3) + ")");
            }
        }
    }
    rai_st_ok(_r, _pairs > 0, "VACUITY: the pairwise sweep compared nothing");
    rai_st_ok(_r, _pairBelow == 0,
              "corpus: " + string(_pairBelow) + " family pair(s) below the distinctness floor");
    // VACUITY GUARD: the distance must be able to return 0 for a shape against itself, or the
    // sweep above is passing because it cannot recognise sameness.
    rai_st_ok(_r, rai_st_dist(_all[0], _all[0]) < RAI_ST_EPS,
              "VACUITY: the signature distance does not return 0 for a shape against itself");

    // -- STAGE 13: THE SIX CORNER TREATMENTS ARE REAL, SIMPLE, CLOSED OUTLINES -------------------
    // ⛔⛔ THIS STAGE DID NOT EXIST AND rai_shape's OWN HEADER SAID IT DID, VERBATIM: "rai_selftest
    // asserts TOTAL TURNING on every outline this file can produce ... across all six treatments and
    // a range of aspect ratios. That assertion is cheap and it is the only mechanical thing that can
    // see this defect." Nothing in this file referenced a corner treatment at all. That is the
    // master catalogue's "a check that only runs on the failing side of another check" one step
    // worse - a check CITED as validation that had never been written - and it is exactly how the
    // six RAI_CN_* constants reached a passing gate while being defined nowhere in the package.
    //
    // So the claim is now true. Turning, simplicity, containment and closure, on every treatment,
    // across aspect ratios chosen to bracket the two shapes that have actually broken here: the
    // 400x24 progress bar (radius off the SHORT side) and the squat panel whose half-width radius
    // turns a PILL into an oval.
    global.rai_stage = 13;
    var _corners = rai_corners_all();
    var _aspects = [[0, 0, 120, 120],      // square
                    [0, 0, 400,  24],      // the progress bar - extreme wide
                    [0, 0,  24, 400],      // extreme tall, the transpose
                    [0, 0, 170, 115],      // the corpus-sheet panel
                    [0, 0,  32,  32],      // inventory-portrait scale
                    [0, 0, 840, 560]];     // hero frame
    var _cornerCases = 0;
    rai_st_ok(_r, array_length(_corners) == 6,
              "corners: rai_corners_all() returned " + string(array_length(_corners)) + ", not 6");
    for (_i = 0; _i < array_length(_corners); _i++) {
        rai_st_ok(_r, is_string(_corners[_i]),
                  "corners: treatment " + string(_i) + " is not a string");
        for (_j = 0; _j < array_length(_aspects); _j++) {
            var _a4 = _aspects[_j];
            var _cp = rai_shape_pts(_corners[_i], _a4[0], _a4[1], _a4[2], _a4[3], 1.0, 1.0, undefined);
            var _label = string(_corners[_i]) + " at "
                       + string(_a4[2] - _a4[0]) + "x" + string(_a4[3] - _a4[1]);
            _cornerCases += 1;
            rai_st_ok(_r, array_length(_cp) >= 3, "corners: " + _label + " produced fewer than 3 points");
            // ONE REVOLUTION. Sign is free - the walk order is asserted by the bounds test below,
            // and a mirrored-but-simple outline is not the defect this is looking for.
            var _t = abs(rai_turning(_cp));
            rai_st_ok(_r, abs(_t - 1) < 0.02,
                      "corners: " + _label + " turns " + string_format(_t, 1, 3)
                      + " revolutions, not 1 - the bowtie this file's winding law exists to stop");
            rai_st_ok(_r, rai_is_simple(_cp), "corners: " + _label + " self-intersects");
            // CONTAINMENT: a treatment is a corner detail, so it may never leave its own rectangle.
            var _bb = rai_pts_bounds(_cp);
            rai_st_ok(_r, _bb[0] >= _a4[0] - RAI_ST_EPS && _bb[1] >= _a4[1] - RAI_ST_EPS
                       && _bb[2] <= _a4[2] + RAI_ST_EPS && _bb[3] <= _a4[3] + RAI_ST_EPS,
                      "corners: " + _label + " leaves its own rectangle");
        }
    }
    rai_st_ok(_r, _cornerCases == 36,
              "VACUITY: the corner sweep ran " + string(_cornerCases) + " cases, expected 36");
    // VACUITY GUARD, AND IT IS THE HALF THAT MATTERS. Every assertion above passes on a shape that
    // is merely a rectangle, so prove the instrument can still say NO: a known bowtie must fail both
    // the turning test and the simplicity test. Without this the whole stage could be green because
    // rai_turning had been broken into always returning 1.
    var _bowtie = [[0, 0], [100, 100], [100, 0], [0, 100]];
    rai_st_ok(_r, abs(abs(rai_turning(_bowtie)) - 1) >= 0.02,
              "VACUITY: rai_turning reads a bowtie as one revolution - the instrument is blind");
    rai_st_ok(_r, !rai_is_simple(_bowtie),
              "VACUITY: rai_is_simple calls a bowtie simple - the instrument is blind");
    // ...and the third instrument, on the same fixture and on a control that must PASS. A bowtie's
    // wedges cancel about any apex, so no fan can draw it; a plain rectangle is fillable from its own
    // centre. Both directions, or "fan safe" is satisfied by a function that always agrees.
    rai_st_ok(_r, !rai_ring_fan_safe(_bowtie, 50, 50),
              "VACUITY: rai_ring_fan_safe calls a bowtie fillable - the instrument is blind");
    rai_st_ok(_r, rai_ring_fan_safe([[0, 0], [100, 0], [100, 100], [0, 100]], 50, 50),
              "VACUITY: rai_ring_fan_safe refuses a plain rectangle from its own centre - the "
              + "instrument says no to everything");

    // ⛔ AND THE SIX MUST ACTUALLY BE SIX. Everything above passes on a shape that is merely a valid
    // rectangle, so a MISSPELLED treatment name would fall through rai_shape_pts's `default` arm,
    // come back as a perfectly good ROUND, and be measured as correct - which is the same silent
    // fall-through that let `charcoal` sit in the corpus twice (STAGE 1). An earlier draft of this
    // stage asserted is_string() and claimed in a comment that this covered it. It does not: a typo
    // is a string. Distinctness is the assertion that actually closes it, and it is also the
    // mechanical form of the store page's "six corner treatments" claim.
    //
    // Measured at ONE deliberate size. At 32x32 the absolute cap collapses several treatments toward
    // each other legitimately, so sweeping distinctness across every aspect ratio would produce false
    // reds on correct art - and a false red costs exactly what a false green does (rai_shape's own
    // turning header records that lesson).
    //
    // ⛔⛔ PROVEN TO FIRE, AND THE FIRST ATTEMPT TO PROVE IT WAS ITSELF A NO-OP WORTH RECORDING.
    // Break test 1 renamed the macro to RAI_CN_COVE "cove_DELIBERATE_TYPO" and the suite stayed
    // GREEN at 890/890 - correctly, because a macro is substituted at BOTH the definition and every
    // use, so rai_corners_all(), rai_corner_radius's switch and rai_shape_pts's dispatch all moved
    // together and nothing could diverge. RENAMING A CONSTANT IS NOT A DEFECT, IT IS A RENAME; a
    // break test that changes both sides of a comparison at once tests nothing and its green is
    // meaningless. Break test 2 removed the `case RAI_CN_COVE:` arm from rai_shape_pts while leaving
    // the name in rai_corners_all(), which is the real asymmetry this stage exists to catch, and it
    // went red immediately with "corners: 'round' and 'cove' draw the SAME outline". 889/890.
    // ⇒ To prove a check fires, break ONE SIDE of what it compares.
    var _sig = [];
    for (_i = 0; _i < array_length(_corners); _i++) {
        var _sp = rai_shape_pts(_corners[_i], 0, 0, 170, 115, 1.0, 1.0, undefined);
        var _acc = array_length(_sp) * 1000;
        for (_j = 0; _j < array_length(_sp); _j++) {
            _acc += _sp[_j][0] * 0.7 + _sp[_j][1] * 1.3;
        }
        array_push(_sig, _acc);
    }
    for (_i = 0; _i < array_length(_sig); _i++) {
        for (_j = _i + 1; _j < array_length(_sig); _j++) {
            rai_st_ok(_r, abs(_sig[_i] - _sig[_j]) > RAI_ST_EPS,
                      "corners: '" + string(_corners[_i]) + "' and '" + string(_corners[_j])
                      + "' draw the SAME outline - one of them is not being dispatched");
        }
    }

    // -- STAGE 14: EVERY MATERIAL IMPLIES A CORNER THAT EXISTS -----------------------------------
    // rai_shape_of read _mat.corner and _mat.weight, and no material in this package has either
    // field, so it threw on the product's own corpus. This asserts the replacement mapping is total
    // over the real corpus and never returns a treatment the dispatch cannot draw.
    global.rai_stage = 14;
    var _mapped = 0;
    for (_i = 0; _i < array_length(_mats); _i++) {
        var _md = rai_material_def(_mats[_i]);
        var _mc = rai_corner_for_material(_md);
        rai_st_ok(_r, rai_has_piece(_corners, _mc),
                  "materials: " + _mats[_i] + " implies corner '" + string(_mc)
                  + "', which is not one of rai_corners_all()");
        // And it must actually DRAW - the crash this stage exists because of was in the draw path,
        // not in the lookup.
        var _mp = rai_shape_of(_md, 0, 0, 120, 80, 1.0);
        rai_st_ok(_r, array_length(_mp) >= 3,
                  "materials: " + _mats[_i] + " produced no outline through rai_shape_of");
        _mapped += 1;
    }
    rai_st_ok(_r, _mapped == array_length(_mats),
              "VACUITY: the material-corner sweep covered " + string(_mapped) + " of "
              + string(array_length(_mats)) + " materials");
    // An explicit corner on the struct must still win over the drape/metal fallback, or the
    // documented override is a comment rather than a behaviour.
    rai_st_ok(_r, rai_corner_for_material({ corner: RAI_CN_PILL, drape: "rigid", metal: true })
                  == RAI_CN_PILL,
              "materials: an explicit corner does not override the drape/metal default");

    // -- STAGE 15: EVERY PUBLIC ENTRY POINT IS ACTUALLY CALLED, WITH WHAT rai_figure RETURNS ------
    //
    // ⛔⛔ THIS STAGE EXISTS BECAUSE `rai_render_to_sprite` HAD NEVER BEEN CALLED ONCE IN THE
    // PRODUCT'S LIFE AND CRASHED ON ITS FIRST CALL. It cleared its surface with `_pal.ground`, and a
    // palette from rai_figure is NAMESPACED, so it has no bare `ground` key:
    //     Variable <unknown_object>.ground(100817, -2147483648) not set before reading it
    // Nothing in the package called it, so 1,660 assertions, a clean Igor gate and the demo room all
    // passed over a documented API that could not run. MEASURED 2026-09-02 by a fresh-install
    // harness that imports the shipped .yymps into a blank project and does what the Readme says.
    //
    // ⭐ A DEAD READER IS NOT A MISSING FEATURE, IT IS AN UNTESTED CODE PATH - and the test for that
    // class is not clever, it is CALLING THE FUNCTION. Each public entry point below is exercised
    // with exactly what rai_figure hands a buyer, because the defect was in the seam between the two
    // and not inside either one.
    global.rai_stage = 15;
    var _apiFig = rai_figure("broad", "guard",
                             [rai_item("cloth", "trousers", "charcoal"),
                              rai_item("cloth", "tunic", "madder"),
                              rai_item("armour", "brigandine", "oxhide")],
                             "buckskin", { style: "braid", material: "charcoal" });
    rai_st_ok(_r, array_length(_apiFig.parts) > 200,
              "api: a fully dressed figure emitted only " + string(array_length(_apiFig.parts))
              + " parts");

    var _apiSurf = surface_create(128, 192);
    surface_set_target(_apiSurf);
    draw_clear_alpha(c_black, 0);
    rai_render_in_rect(_apiFig.parts, _apiFig.palette, 0, 0, 128, 192, 0, undefined);
    rai_render_in_rect_tight(_apiFig.parts, _apiFig.palette, 0, 0, 128, 192, undefined);
    surface_reset_target();
    surface_free(_apiSurf);
    rai_st_ok(_r, true, "api: rai_render_in_rect / _tight ran on a figure palette");

    var _apiSpr = rai_render_to_sprite(_apiFig.parts, _apiFig.palette, 96, 144, 4);
    rai_st_ok(_r, sprite_exists(_apiSpr),
              "api: rai_render_to_sprite returned no sprite for a figure built by rai_figure");
    if (sprite_exists(_apiSpr)) {
        rai_st_ok(_r, sprite_get_width(_apiSpr) == 96,
                  "api: the baked sprite is " + string(sprite_get_width(_apiSpr)) + " wide, not 96");
        sprite_delete(_apiSpr);
    }
    // ⚠️ AND THE SEAM ITSELF, STATED AS A PROPERTY RATHER THAN AS A CRASH. A figure's palette is
    // namespaced by construction; anything that reads an UNPREFIXED role off it is reading a key
    // that is not part of the contract, which is exactly what went wrong. Asserting the absence
    // keeps the next such read honest instead of waiting for it to throw.
    rai_st_ok(_r, !variable_struct_exists(_apiFig.palette, "ground"),
              "api: a figure palette carries a bare 'ground' - the namespacing contract has changed "
              + "and rai_render_to_sprite's fix was aimed at the wrong thing");
    rai_st_ok(_r, array_length(variable_struct_get_names(_apiFig.palette)) > 8,
              "VACUITY: the figure palette has almost no keys, so the check above passes trivially");

    global.rai_stage = 99;
    return { pass: _r.pass, fail: _r.fail, notes: _r.notes,
             drapeSpread: _drapeSpread, drapeSpreadName: _drapeSpreadName,
             rigidGather: _rigidGather, rigidGatherName: _rigidGatherName,
             clothGather: _vGather,
             pairs: _pairs, pairWorst: _pairWorst, pairWorstName: _pairWorstName,
             pairBelow: _pairBelow, hist: _hist,
             minFigurePx: _minFigurePx, minFigureWhat: _minFigureWhat,
             figureParts: array_length(_fig.parts), ramps: _distinctRamps,
             clipKept: _clipKept, clipDropped: _clipDropped,
             cornerCases: _cornerCases, materialsMapped: _mapped };
}

/// ============================================================================================
/// THE RESULT FILE
///
/// ⛔ A SANDBOXED FILE WRITE IS THE ONLY ROUTE THAT SURVIVES A RELEASE BUILD. Measured in this
/// wing: show_debug_message plus -debugoutput writes only engine boot lines, and game_end(n) does
/// not propagate n to the process exit code.
/// ============================================================================================
function rai_selftest_write(_res) {
    var _f = file_text_open_write("rai_selftest.json");
    var _notes = "";
    var _i;
    for (_i = 0; _i < array_length(_res.notes); _i++) {
        if (_i > 0) _notes += " | ";
        _notes += string_replace_all(string(_res.notes[_i]), "\"", "'");
    }
    var _hs = "";
    for (_i = 0; _i < 20; _i++) {
        if (_i > 0) _hs += ",";
        _hs += string(_res.hist[_i]);
    }
    var _c = rai_corpus_count();
    file_text_write_string(_f,
        "{\"pass\":" + string(_res.pass)
        + ",\"fail\":" + string(_res.fail)
        + ",\"stage\":" + string(global.rai_stage)
        + ",\"epsilon\":" + string_format(math_get_epsilon(), 1, 12)
        + ",\"clothFamilies\":" + string(_c.cloth_families)
        + ",\"armourFamilies\":" + string(_c.armour_families)
        + ",\"armourPieces\":" + string(_c.armour_pieces)
        + ",\"materials\":" + string(_c.materials)
        + ",\"surfaces\":" + string(_c.surfaces)
        + ",\"builds\":" + string(_c.builds)
        + ",\"poses\":" + string(_c.poses)
        + ",\"outfits\":" + string(_c.outfits)
        + ",\"figures\":" + string(_c.figures)
        + ",\"archetypes\":" + string(array_length(rai_archetypes_all()))
        // The drape claim, as a number rather than only as a verdict.
        + ",\"drapeSpread\":" + string_format(_res.drapeSpread, 1, 5)
        + ",\"drapeSpreadName\":\"" + _res.drapeSpreadName + "\""
        + ",\"rigidGatherWorst\":" + string_format(_res.rigidGather, 1, 4)
        + ",\"rigidGatherName\":\"" + _res.rigidGatherName + "\""
        + ",\"clothGather\":" + string_format(_res.clothGather, 1, 4)
        + ",\"familyPairs\":" + string(_res.pairs)
        + ",\"pairWorst\":" + string_format(_res.pairWorst, 1, 3)
        + ",\"pairWorstName\":\"" + _res.pairWorstName + "\""
        + ",\"pairsBelowFloor\":" + string(_res.pairBelow)
        + ",\"pairFloor\":" + string_format(RAI_ST_PAIR_FLOOR, 1, 3)
        + ",\"histBucket\":0.05"
        + ",\"hist\":[" + _hs + "]"
        + ",\"minFigurePx\":" + string(_res.minFigurePx)
        + ",\"minFigureLimitedBy\":\"" + _res.minFigureWhat + "\""
        + ",\"figureParts\":" + string(_res.figureParts)
        + ",\"ramps\":" + string(_res.ramps)
        + ",\"version\":\"" + RAI_VERSION + "\""
        + ",\"notes\":\"" + _notes + "\"}");
    file_text_close(_f);
}
