/// PASTIME - pas_darts. Room 2 of the cabinet.
///
/// Visual language: radial metal and sisal. Alternating wedges, a brass spider, two scoring bands
/// and an upright number ring on a turned surround.
///
/// ⭐ WHAT IS GENERATED, AND WHY IT IS NOT DECORATION. A dartboard's NUMBER RING is the whole game:
/// the numbers are arranged so that missing a big number lands you on a small one, and a board with
/// the numbers in order would make the game trivially safe. This room GENERATES that arrangement by
/// searching for the ring that maximises the total penalty for missing - so every board is a
/// different, genuinely playable arrangement rather than the same twenty numbers rotated.
///
/// pas_selftest asserts that a generated ring beats a RANDOM ring on the property it was searched
/// for, over hundreds of seeds. That assertion is what makes "generated" a claim rather than a word:
/// a search that failed to beat chance would be a shuffle with extra steps.
///
/// ⚠️ AND THE ASSERTION HAS TO BE WRITTEN AGAINST THE RANDOM BASELINE, NOT AGAINST A FIXED NUMBER.
/// A threshold like "adjacency > 140" is a number somebody liked, and it goes red the day the
/// sector count changes. The baseline moves with the corpus; the claim does not.
///
/// Radii are normalised to the board's own half-width, so 0.5 is the outer edge of the surround.
/// ================================================================================================

#macro PAS_DT_MISS   0
#macro PAS_DT_SINGLE 1
#macro PAS_DT_DOUBLE 2
#macro PAS_DT_TREBLE 3
#macro PAS_DT_OUTER  4
#macro PAS_DT_BULL   5

/// @desc Build a darts board.
/// @param {real} seed
/// @param {struct} opts  optional: {sectors, start}  start = the countdown target
function pas_darts_board(seed, opts = {}) {
    var _r = pas_rng(seed);

    var _sectors = (is_struct(opts) && variable_struct_exists(opts, "sectors"))
        ? opts.sectors : pas_rng_pick(_r, [ 16, 18, 20, 20, 24 ]);
    if (_sectors < 6) _sectors = 6;
    if (_sectors & 1) _sectors += 1;          // an odd count cannot alternate; the wedges would
                                              // meet themselves at the seam and read as a mistake.
    var _start = (is_struct(opts) && variable_struct_exists(opts, "start")) ? opts.start : 301;

    // ---- ring radii, jittered inside real tolerances ---------------------
    // A real board's geometry is fixed by the rules; this varies it the amount a maker's board
    // varies, so twelve boards read as twelve boards and not as twelve renders of one file.
    var _j = 0.90 + pas_rng_float(_r) * 0.20;
    var _board = {
        room     : "darts",
        seed     : seed,
        sectors  : _sectors,
        r_bull   : 0.0195 * _j,
        r_outer  : 0.0480 * _j,
        r_tre_in : 0.2400 * _j,
        r_tre_ot : 0.2720 * _j,
        r_dbl_in : 0.4020 * _j,
        r_dbl_ot : 0.4340 * _j,
        r_rim    : 0.4980,
        wire     : pas_rng_int(_r, 0, 2),      // 0 round wire, 1 blade, 2 heavy
        rot      : pas_rng_float(_r) * 360,    // where sector 0 starts
        order    : [],
        adjacency: 0,
        // play
        start    : _start,
        left     : _start,
        throws   : [],
        darts    : [],
        turn     : 0,
        over     : false,
        rng      : _r,
    };

    // ---- the number ring, SEARCHED -----------------------------------------
    var _seq = array_create(_sectors);
    for (var i = 0; i < _sectors; i++) _seq[i] = i + 1;
    _seq = pas_rng_shuffle(_r, _seq);
    _board.order = pas_darts_improve(_seq, _r);
    _board.adjacency = pas_darts_adjacency(_board.order);
    return _board;
}

/// @desc Total penalty for missing: the sum of |difference| between every pair of neighbours.
///
/// The higher this is, the more a miss costs, and that is what makes a dartboard a game of nerve
/// rather than of aim alone. It is the objective the search below maximises and the property the
/// suite asserts against a random baseline.
function pas_darts_adjacency(_seq) {
    var _n = array_length(_seq);
    if (_n < 2) return 0;
    var _t = 0;
    for (var i = 0; i < _n; i++) _t += abs(_seq[i] - _seq[(i + 1) % _n]);
    return _t;
}

/// @desc Hill-climb a ring toward higher adjacency by swapping pairs.
///
/// Steepest-ascent over pair swaps, from a shuffled start, with a fixed budget. It is not optimal
/// and does not need to be: what it must do is reliably beat chance, which is the only claim made
/// for it anywhere in the product.
///
/// ⚠️ It takes the generator so the SEARCH is part of the seeded stream. A search seeded from
/// anywhere else would make the same board come out differently on a rerun, which is exactly the
/// determinism pas_rng exists to guarantee.
function pas_darts_improve(_seq, _r) {
    var _n = array_length(_seq);
    var _cur = array_create(_n);
    for (var i = 0; i < _n; i++) _cur[i] = _seq[i];
    var _best = pas_darts_adjacency(_cur);

    for (var _pass = 0; _pass < 8; _pass++) {
        var _moved = false;
        for (var a = 0; a < _n; a++) {
            for (var b = a + 1; b < _n; b++) {
                var _t = _cur[a]; _cur[a] = _cur[b]; _cur[b] = _t;
                var _v = pas_darts_adjacency(_cur);
                if (_v > _best) { _best = _v; _moved = true; }
                else { _t = _cur[a]; _cur[a] = _cur[b]; _cur[b] = _t; }   // put it back
            }
        }
        if (!_moved) break;
    }
    // One seeded rotation so two boards with the same optimal ring do not look identical.
    var _k = pas_rng_int(_r, 0, _n - 1);
    var _out = array_create(_n);
    for (var i = 0; i < _n; i++) _out[i] = _cur[(i + _k) % _n];
    return _out;
}

/// @desc Which sector and ring a point lands in. PURE: no engine calls, no drawing.
/// @param {real} _u,_v  board-space coordinates, 0..1, centre at 0.5,0.5
/// @return {struct} {sector, number, ring, score}
function pas_darts_hit(_board, _u, _v) {
    var _dx = _u - 0.5, _dy = _v - 0.5;
    var _d = sqrt(_dx * _dx + _dy * _dy);

    if (_d <= _board.r_bull)  return { sector : -1, number : 25, ring : PAS_DT_BULL,  score : 50 };
    if (_d <= _board.r_outer) return { sector : -1, number : 25, ring : PAS_DT_OUTER, score : 25 };
    if (_d >  _board.r_dbl_ot) return { sector : -1, number : 0, ring : PAS_DT_MISS,  score : 0 };

    var _n = _board.sectors;
    var _ang = point_direction(0, 0, _dx, -_dy);              // 0 = east, counter-clockwise
    var _rel = ((_ang - _board.rot) mod 360 + 360) mod 360;
    var _sec = floor(_rel / (360 / _n)) mod _n;
    var _num = _board.order[_sec];

    var _ring = PAS_DT_SINGLE;
    var _mult = 1;
    if (_d >= _board.r_tre_in && _d <= _board.r_tre_ot) { _ring = PAS_DT_TREBLE; _mult = 3; }
    if (_d >= _board.r_dbl_in && _d <= _board.r_dbl_ot) { _ring = PAS_DT_DOUBLE; _mult = 2; }
    return { sector : _sec, number : _num, ring : _ring, score : _num * _mult };
}

/// @desc Throw a dart. input is {act:"press", u, v} in board space, or a string "auto".
///
/// A thrown dart SCATTERS: the aim is where you meant it, the landing is where it went, and the
/// scatter is drawn from the board's own generator so a replayed seed lands every dart in the same
/// place. That is what lets the suite report a failing seed a human can reproduce.
/// @return {string} "score" | "bust" | "won" | "miss" | "over"
function pas_darts_step(_board, _input) {
    if (_board.over) return "over";

    var _u = pas_input_u(_input), _v = pas_input_v(_input);
    if (_u < 0 || _v < 0) {
        // "auto": aim at the best treble on the board, the way a player actually would.
        var _best = 0, _bi = 0;
        for (var i = 0; i < _board.sectors; i++) {
            if (_board.order[i] > _best) { _best = _board.order[i]; _bi = i; }
        }
        var _a = degtorad(_board.rot + (_bi + 0.5) * (360 / _board.sectors));
        var _rr = (_board.r_tre_in + _board.r_tre_ot) * 0.5;
        _u = 0.5 + cos(_a) * _rr;
        _v = 0.5 - sin(_a) * _rr;
    }

    var _sc = 0.016 + pas_rng_float(_board.rng) * 0.030;
    var _sa = pas_rng_float(_board.rng) * 360;
    _u += cos(degtorad(_sa)) * _sc;
    _v += sin(degtorad(_sa)) * _sc;

    var _h = pas_darts_hit(_board, _u, _v);
    array_push(_board.darts, { u : _u, v : _v, ring : _h.ring });
    array_push(_board.throws, _h.score);
    _board.turn += 1;

    // Countdown rules, including the bust: a throw that takes you past zero, or to exactly one,
    // does not count. Without it the game has no tension in its last three darts, which is the
    // only part of a darts game anybody remembers.
    var _after = _board.left - _h.score;
    if (_after == 0 && _h.ring == PAS_DT_DOUBLE) {
        _board.left = 0; _board.over = true; return "won";
    }
    if (_after <= 1) return "bust";
    _board.left = _after;
    if (_h.score == 0) return "miss";
    return "score";
}

function pas_darts_label(_board) {
    return "DARTS  " + string(_board.sectors) + " beds"
         + "   ring penalty " + string(_board.adjacency)
         + "   " + string(_board.left) + " to go";
}

/// A dartboard is round, so its cell is square.
function pas_darts_aspect(_board) { return 1.0; }

/// @desc Draw the board. Reads the struct and NOTHING else.
function pas_darts_draw(_board, _x, _y, _w, _h, _pal) {
    var _f = pas_map(_x, _y, _w, _h);
    var _n = _board.sectors;
    var _step = 360 / _n;
    var _seg = max(4, round(64 / _n));

    // -- the surround: a turned ring the numbers sit on --------------------
    pas_annulus(_f, 0.5, 0.5, _board.r_dbl_ot, _board.r_rim, 0, 360, _pal.w2, 96);
    pas_annulus(_f, 0.5, 0.5, _board.r_rim * 0.985, _board.r_rim, 0, 360, _pal.w4, 96);
    pas_annulus(_f, 0.5, 0.5, _board.r_dbl_ot, _board.r_dbl_ot * 1.02, 0, 360, _pal.w0, 96);

    // -- sisal: alternating wedges ----------------------------------------
    // Drawn as annular sectors between the bull ring and the outer double, so the two scoring
    // bands can be laid over them in one pass each rather than as 3n separate pieces.
    for (var i = 0; i < _n; i++) {
        var _a0 = _board.rot + i * _step;
        var _c = (i & 1) ? _pal.m4 : _pal.m0;
        pas_annulus(_f, 0.5, 0.5, _board.r_outer, _board.r_dbl_ot, -_a0 - _step, -_a0, _c, _seg);
    }

    // -- the two scoring bands --------------------------------------------
    // Colour is the OPPOSITE accent from the sisal underneath, so a treble on a dark bed and a
    // treble on a light bed are equally readable. A single accent would vanish on one of them,
    // which is the failure this cabinet's palette exists to prevent.
    for (var i = 0; i < _n; i++) {
        var _a0 = _board.rot + i * _step;
        var _hot = (i & 1) ? _pal.p3 : _pal.q3;
        pas_annulus(_f, 0.5, 0.5, _board.r_tre_in, _board.r_tre_ot, -_a0 - _step, -_a0, _hot, _seg);
        pas_annulus(_f, 0.5, 0.5, _board.r_dbl_in, _board.r_dbl_ot, -_a0 - _step, -_a0, _hot, _seg);
    }

    // -- the spider -------------------------------------------------------
    // ⚠️ TONE IS SPACING, NOT WIDTH (pas_geom law 4). The three wire gauges differ by a real
    // pixel amount bounded at both ends, not by a fraction that quantises to 1 px at cabinet size.
    var _gauge = [ 0.0035, 0.0055, 0.0080 ];
    var _wire = pas_detail(_f, _gauge[_board.wire], 1, 9);
    for (var i = 0; i < _n; i++) {
        var _a = degtorad(-(_board.rot + i * _step));
        var _c = cos(_a), _s = sin(_a);
        var _ru = _f.s / max(1, _f.w), _rv = _f.s / max(1, _f.h);
        pas_line(_f,
            0.5 + _c * _board.r_outer * _ru, 0.5 + _s * _board.r_outer * _rv,
            0.5 + _c * _board.r_dbl_ot * _ru, 0.5 + _s * _board.r_dbl_ot * _rv,
            _wire, _pal.b3);
    }
    var _rings = [ _board.r_outer, _board.r_tre_in, _board.r_tre_ot,
                   _board.r_dbl_in, _board.r_dbl_ot ];
    for (var i = 0; i < array_length(_rings); i++) {
        pas_ring(_f, 0.5, 0.5, _rings[i], _wire, _pal.b3);
    }

    // -- the bull ---------------------------------------------------------
    pas_disc(_f, 0.5, 0.5, _board.r_outer, _pal.q3);
    pas_ring(_f, 0.5, 0.5, _board.r_outer, _wire, _pal.b3);
    pas_disc(_f, 0.5, 0.5, _board.r_bull, _pal.p3);
    pas_ring(_f, 0.5, 0.5, _board.r_bull, _wire, _pal.b4);

    // -- the numbers ------------------------------------------------------
    // Upright, on the surround, like a real board. Rotated numerals are legible on exactly one
    // side of a wheel and this is not a wheel.
    var _rn = (_board.r_dbl_ot + _board.r_rim) * 0.5;
    var _ru2 = _f.s / max(1, _f.w), _rv2 = _f.s / max(1, _f.h);
    var _cell = (_f.s * 0.16) / max(1, _f.w);
    for (var i = 0; i < _n; i++) {
        var _a = degtorad(-(_board.rot + (i + 0.5) * _step));
        pas_text_fit(_f, string(_board.order[i]),
            0.5 + cos(_a) * _rn * _ru2, 0.5 + sin(_a) * _rn * _rv2,
            _cell, _pal.type, fa_center, fa_middle);   // PAS_HOUSE_OK: the numbers sit on the
            // SURROUND, which is cabinet walnut (w2) and identical on every theme - so the
            // cabinet lettering colour is the correct one here, not the bed-derived ink.
    }

    // -- darts in the board -----------------------------------------------
    // A dart is a shaft and a flight: two marks, not one, because a single dot on a board reads as
    // a printing fault rather than as something that arrived.
    for (var i = 0; i < array_length(_board.darts); i++) {
        var _d = _board.darts[i];
        var _fl = 0.052, _dir = degtorad(-38);
        var _tu = _d.u + cos(_dir) * _fl * _ru2;
        var _tv = _d.v + sin(_dir) * _fl * _rv2;
        pas_line(_f, _d.u, _d.v, _tu, _tv, pas_detail(_f, 0.007, 1, 6), _pal.b1);
        var _fu = _fl * 0.42;
        pas_poly(_f, [
            _tu, _tv,
            _tu + cos(_dir + 2.5) * _fu * _ru2, _tv + sin(_dir + 2.5) * _fu * _rv2,
            _tu + cos(_dir - 2.5) * _fu * _ru2, _tv + sin(_dir - 2.5) * _fu * _rv2
        ], _pal.p4);
        pas_disc(_f, _d.u, _d.v, 0.008, _pal.b4);
    }
}
