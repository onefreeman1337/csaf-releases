/// PASTIME - pas_bake. The store sheets, rendered BY THE PRODUCT.
///
/// ⛔ A GALLERY RENDERED BY A SIDE PREVIEWER IS A PICTURE OF A RE-IMPLEMENTATION. This wing built
/// one once (Facet's JS previewer) and it carried a defect invisible in the previewer and plainly
/// visible in engine. Every image on Pastime's listing comes out of Pastime.exe calling the same
/// public draw functions a buyer's game calls, which is what lets the listing say so truthfully.
///
/// -- THE TWO MEASUREMENTS, AND WHY THERE ARE TWO -------------------------------------------------
/// A sheet function returns the y it finished at, and that ONE number answers only "did the LAST
/// thing drawn fall off the BOTTOM". It is blind to horizontal overflow and blind to emptiness -
/// both of those shipped on Affliction while the extent check reported ok. So the runner also reads
/// the surface back and measures the INK.
///
/// ⛔ AND THE INK BOX HAS TWO BLIND SPOTS OF ITS OWN, both measured on Crest and both handled here:
///   1. A STRIDE OF 2 MISSES A 1px FEATURE ON AN ODD ROW, including a hairline rule. y steps by 1.
///      x may step by 2 - nothing in this package draws a 1px-wide vertical feature.
///   2. A FLAT FILL CLOSE TO THE PAGE COLOUR IS NOT COUNTED AS INK. Everything that must not clip
///      here is sized by SOLVING for the space available rather than by a constant, so it cannot
///      clip by construction.
///
/// ⚠️ AND THE HONEST LIMIT, stated rather than left for a buyer to find: A BOUNDING BOX CANNOT SEE
/// THE SPACE INSIDE ITSELF. A sheet of three small things adrift on a big page scores 77% x 92% and
/// passes. The floors catch an EMPTY sheet and a CLIPPED one; they do not judge a sparse one and no
/// threshold ever will. The instrument for that is opening the PNG and looking, and pas_bake exists
/// to make that step cheap, not to replace it.
/// ================================================================================================

#macro PAS_BK_W 1600
#macro PAS_BK_H 1000

/// Coverage floors. Content, not full: a full-width rule under a title would satisfy an x floor on
/// its own and turn the check into decoration.
#macro PAS_BK_FILL_W 0.86
#macro PAS_BK_FILL_H 0.78
#macro PAS_BK_EDGE   6

/// The title band, IN PIXELS.
///
/// ⛔ IT WAS A FRACTION OF THE PAGE HEIGHT AND IT COLLAPSED ON A SHORT SHEET. MEASURED 2026-09-03:
/// after the darts page was solved down to 540 px to fix its fill floor, 0.088 of the height put
/// the band's hairline at y=45 and the subtitle's baseline at y=36 - so the rule was struck through
/// the subtitle, on the sheet whose whole job is to be read. A type size and a band depth are
/// PHYSICAL measurements; they do not get smaller because the page below them got shorter. Same law
/// as Borough's eaves and Livery's mouldings, arriving in typography.
#macro PAS_BK_TITLE_PX 86

/// @desc The ink bounding box of a surface, as two boxes.
///
/// `full` is every non-ground pixel and is what the CLIP test reads - a clipped hairline is ink and
/// must be caught. `content` skips the title band and is what the COVERAGE floors read, so the
/// title cannot satisfy them on the sheet's behalf.
/// @return {struct} {x0,y0,x1,y1, cx0,cy0,cx1,cy1, ink}
function pas_bk_ink_bounds(_surf, _ground, _titleH) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf);
    var _b = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_b, _surf, 0);

    var _gr = colour_get_red(_ground), _gg = colour_get_green(_ground), _gb = colour_get_blue(_ground);
    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;
    var _ink = 0;

    // y by 1 - a clipped hairline lands on ONE row and an even-only scan walks past it.
    for (var _y = 0; _y < _h; _y++) {
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = (_y * _w + _x) * 4;
            var _p = buffer_peek(_b, _o, buffer_u32);
            var _r = _p & 255, _g = (_p >> 8) & 255, _bl = (_p >> 16) & 255;
            if (abs(_r - _gr) <= 10 && abs(_g - _gg) <= 10 && abs(_bl - _gb) <= 10) continue;
            _ink += 1;
            if (_x < _x0) _x0 = _x;
            if (_x > _x1) _x1 = _x;
            if (_y < _y0) _y0 = _y;
            if (_y > _y1) _y1 = _y;
            if (_y >= _titleH) {
                if (_x < _cx0) _cx0 = _x;
                if (_x > _cx1) _cx1 = _x;
                if (_y < _cy0) _cy0 = _y;
                if (_y > _cy1) _cy1 = _y;
            }
        }
    }
    buffer_delete(_b);
    return { x0 : _x0, y0 : _y0, x1 : _x1, y1 : _y1,
             cx0 : _cx0, cy0 : _cy0, cx1 : _cx1, cy1 : _cy1, ink : _ink };
}

/// @desc Draw a sheet's title band. Every sheet gets the same one, for the same reason the cabinet
///       is the same on every theme: a gallery of nine differently-titled sheets is nine products.
/// @return {real} the y the band ends at
function pas_bk_title(_w, _h, _pal, _title, _sub) {
    var _f = pas_map(0, 0, _w, _h);
    var _bh = PAS_BK_TITLE_PX / max(1, _h);
    draw_set_font(fnt_pastime_title);
    pas_text_fit(_f, _title, 0.030, _bh * 0.40, 0.62, _pal.type, fa_left, fa_middle);
    draw_set_font(fnt_pastime);
    pas_text_fit(_f, _sub, 0.030, _bh * 0.76, 0.94, _pal.dim, fa_left, fa_middle);
    pas_text_fit(_f, "PASTIME", 0.970, _bh * 0.40, 0.22, _pal.b3, fa_right, fa_middle);
    // one hairline, at a real pixel width, under the band
    pas_line(_f, 0.030, _bh * 0.96, 0.970, _bh * 0.96, pas_detail(_f, 0.002, 1, 3), _pal.b1);
    return PAS_BK_TITLE_PX * 0.96;
}

/// @desc Render one sheet to a surface, measure it, save it, and return the row for the report.
function pas_bk_sheet(_name, _w, _h, _fn) {
    var _pal = pas_pal(2);
    var _surf = surface_create(_w, _h);
    surface_set_target(_surf);
    draw_clear(_pal.back);
    draw_set_font(fnt_pastime);
    var _end = _fn(_w, _h);
    surface_reset_target();

    var _bb = pas_bk_ink_bounds(_surf, _pal.back, PAS_BK_TITLE_PX);
    surface_save(_surf, _name + ".png");
    surface_free(_surf);

    var _fw = (_bb.x1 >= 0) ? (_bb.x1 - _bb.x0 + 1) / _w : 0;
    var _fh = (_bb.y1 >= 0) ? (_bb.y1 - _bb.y0 + 1) / _h : 0;
    var _cw = (_bb.cx1 >= 0) ? (_bb.cx1 - _bb.cx0 + 1) / _w : 0;
    var _ch = (_bb.cy1 >= 0) ? (_bb.cy1 - _bb.cy0 + 1) / max(1, _h - PAS_BK_TITLE_PX) : 0;
    var _clip = (_bb.x0 < PAS_BK_EDGE) || (_bb.y0 < PAS_BK_EDGE)
             || (_bb.x1 > _w - 1 - PAS_BK_EDGE) || (_bb.y1 > _h - 1 - PAS_BK_EDGE);

    return {
        name : _name, w : _w, h : _h,
        endY : _end,
        ink : _bb.ink,
        fullW : _fw, fullH : _fh,
        contentW : _cw, contentH : _ch,
        clipped : _clip,
        okFill : (_cw >= PAS_BK_FILL_W) && (_ch >= PAS_BK_FILL_H),
        x0 : _bb.x0, y0 : _bb.y0, x1 : _bb.x1, y1 : _bb.y1,
    };
}

/// ================================================================================================
/// THE SHEETS
/// ================================================================================================

/// 1. THE HERO. One cabinet, one board, at the size a buyer first sees it.
///
/// ⛔ THE HERO IS CHOSEN BY LOOKING AT CANDIDATES AT HERO SIZE, not by picking the most famous
/// subject. This wing put a geode on a hero sheet because a geode is the iconic mineral photograph,
/// and at 728 px it read as a cog. The circuit board is Pastime's hero because it is the room whose
/// generated structure is legible from across a room: traces, pads, chips and a live signal.
function pas_bk_hero(_w, _h) {
    var _pal = pas_pal(1);
    var _ty = pas_bk_title(_w, _h, _pal,
        "EIGHT GAMES. EVERY BOARD DRAWN FROM NUMBERS.",
        "No sprite sheet, no atlas, no PNG. Every trace, pad, pip, wedge and pin below is GML.");
    var _cab = pas_cabinet_new(88041, 1);
    // ⛔ The hero board is asked for a WIDE grid on purpose. contentW read 0.602 with the
    // default 9x7 because a near-square cabinet cannot fill a 1600-wide page, and the answer to
    // that is not a smaller page or a letterbox - it is to bake the candidate at the size it will
    // actually be shown and choose one that works there (this wing's Lode law).
    _cab.boards[0] = pas_circuit_board(88041, { gw : 13, gh : 7, nodes : 15 });
    pas_cabinet_select(_cab, 0);
    // ⛔ Drive it to SOLVED, not part way. The first hero opened six of nine gates, so the label
    // read OPENED and not one trace glowed - a picture of a puzzle nobody had finished, which
    // shows the drawing and hides the SYSTEM. `auto` returns "nothing" once every gate is open,
    // so the loop is bounded by the room rather than by a number that has to be kept in step.
    for (var i = 0; i < 40; i++) {
        if (pas_cabinet_step(_cab, pas_input("key", -1, -1, "auto")) == "nothing") break;
    }
    var _pad = 26;
    var _asp = pas_cabinet_aspect(_cab);
    var _ch = _h - _ty - _pad * 2;
    var _cw = _ch * _asp;
    if (_cw > _w - _pad * 2) { _cw = _w - _pad * 2; _ch = _cw / _asp; }
    pas_cabinet_draw(_cab, (_w - _cw) * 0.5, _ty + _pad + (_h - _ty - _pad * 2 - _ch) * 0.5,
                     _cw, _ch);
    return _ty + _pad + _ch;
}

/// 2. ALL EIGHT ROOMS, in their cabinets. The breadth claim, in one picture.
function pas_bk_eight(_w, _h) {
    var _pal = pas_pal(2);
    var _ty = pas_bk_title(_w, _h, _pal,
        "EIGHT ROOMS, ONE CABINET",
        "Circuit. Darts. Dice. Maze. Range. Wheel. Bagatelle. Tangram. One frame, one palette layer, one geometry vocabulary.");
    // ⛔ SOLVE THE LAYOUT, DO NOT DIVIDE THE PAGE AND HOPE. The first version split the page into
    // two equal rows and drew a 1.30-aspect cabinet inside each, leaving a 200 px dead band across
    // the middle of the sheet - and contentW/contentH both read 1.000 over it, because a BOUNDING
    // BOX CANNOT SEE THE SPACE INSIDE ITSELF. The cabinet height is computed from the column width
    // FIRST, and whatever is left over is shared out as air between the rows rather than left in
    // one lump.
    //
    // ⚠️ A FIXED ASPECT HERE IS DELIBERATE, and it is the opposite choice from the hero sheet. A
    // lineup is a comparison, and eight cabinets of eight different proportions is a ragged shelf
    // rather than a cabinet room. Each board keeps its own margins inside its opening; the sheet's
    // job is to show that the HOUSING is the same eight times.
    var _cols = 4, _rows = 2, _asp = 1.30;
    var _gapX = 16;
    var _cw = (_w - _gapX * (_cols + 1)) / _cols;
    var _bh = _cw / _asp;
    var _gapY = max(10, (_h - _ty - _bh * _rows) / (_rows + 1));
    for (var i = 0; i < pas_room_count(); i++) {
        var _cx = _gapX + (i mod _cols) * (_cw + _gapX);
        var _cy = _ty + _gapY + (i div _cols) * (_bh + _gapY);
        var _cab = pas_cabinet_new(31000 + i * 4441, i * 3);
        pas_cabinet_select(_cab, i);
        for (var k = 0; k < 5; k++) pas_cabinet_step(_cab, pas_input("key", -1, -1, "auto"));
        pas_cabinet_draw(_cab, _cx, _cy, _cw, _bh);
    }
    return _ty + _gapY + _bh * _rows + _gapY;
}

/// 3. FORTY BOARDS. The volume claim, as a picture, with the number derived rather than typed.
///
/// ⛔ THE CAPTION IS DERIVED FROM WHAT IS DRAWN. A hero caption on Lode read "polished, oval cut"
/// from a hard-coded string after the species had changed to a step cut. Here the count comes out
/// of the same loop that draws the cells, so the sheet cannot claim a number it did not render.
function pas_bk_volume(_w, _h) {
    var _pal = pas_pal(5);
    var _cols = 8, _rows = 5;
    var _drawn = 0;
    var _gap = 10;
    var _ty = pas_bk_title(_w, _h, _pal, "FORTY BOARDS, FORTY SEEDS", "");
    var _cw = (_w - _gap * (_cols + 1)) / _cols;
    var _ch = (_h - _ty - _gap * (_rows + 1)) / _rows;
    for (var c = 0; c < _cols; c++) {
        for (var rr = 0; rr < _rows; rr++) {
            var _room = pas_room_name(c);
            var _bd = pas_room_board(_room, 500000 + c * 7919 + rr * 104729, {});
            if (!is_struct(_bd)) continue;
            var _px = _gap + c * (_cw + _gap);
            var _py = _ty + _gap + rr * (_ch + _gap);
            var _asp = pas_room_aspect(_room, _bd);
            var _bw = _cw, _bh = _cw / _asp;
            if (_bh > _ch) { _bh = _ch; _bw = _bh * _asp; }
            var _p2 = pas_pal(c * 5 + rr);
            pas_room_draw(_room, _bd, _px + (_cw - _bw) * 0.5, _py + (_ch - _bh) * 0.5,
                          _bw, _bh, _p2);
            _drawn += 1;
        }
    }
    // now the caption, over the band, with the REAL count
    var _f = pas_map(0, 0, _w, _h);
    draw_set_font(fnt_pastime);
    pas_text_fit(_f, string(_drawn) + " boards on this sheet - eight rooms, five seeds each, every one generated at run time",
                 0.030, (PAS_BK_TITLE_PX / max(1, _h)) * 0.76, 0.94, _pal.dim, fa_left, fa_middle);
    return _h - _gap;
}

/// 4. THE CIRCUIT, close. Traces, pads, DIP bodies, ICE, a live signal.
function pas_bk_circuit(_w, _h) {
    var _pal = pas_pal(1);
    var _ty = pas_bk_title(_w, _h, _pal,
        "CIRCUIT - A ROUTED NETWORK, NOT A PICTURE OF ONE",
        "Manhattan traces on two layers, vias at every corner, annular pads with a real drill hole, DIP bodies with a notch. Open the gates, avoid the ICE, reach the sink.");
    var _gap = 11;
    var _cols = 2;
    var _cw = (_w - _gap * (_cols + 1)) / _cols;
    var _ch = (_h - _ty - _gap * 3) / 2;
    for (var i = 0; i < 4; i++) {
        // ⛔ The GRID is chosen to suit the CELL, not the cell padded around whatever grid came
        // out. contentW read 0.859 against a 0.86 floor with free grids - a real miss by one
        // thousandth, and the wing law is to fix the layout and NEVER to move the threshold.
        // Variety comes from the node count and the routing, which is what a buyer looks at.
        var _bd = pas_circuit_board(770000 + i * 3313,
                                    { gw : 12 + (i mod 2), gh : 7, nodes : 9 + i * 2 });
        for (var k = 0; k < i * 3; k++) pas_circuit_step(_bd, pas_input("key", -1, -1, "auto"));
        var _px = _gap + (i mod _cols) * (_cw + _gap);
        var _py = _ty + _gap + (i div _cols) * (_ch + _gap);
        var _asp = pas_circuit_aspect(_bd);
        var _bw = _cw, _bh = _cw / _asp;
        if (_bh > _ch) { _bh = _ch; _bw = _bh * _asp; }
        pas_circuit_draw(_bd, _px + (_cw - _bw) * 0.5, _py + (_ch - _bh) * 0.5, _bw, _bh,
                         pas_pal(1 + i * 3));
    }
    return _h - _gap;
}

/// 5. FOUR DARTBOARDS, four SEARCHED number rings. The one sheet that proves a search happened.
function pas_bk_darts(_w, _h) {
    var _pal = pas_pal(3);
    var _ty = pas_bk_title(_w, _h, _pal,
        "DARTS - THE NUMBER RING IS SEARCHED, NOT SHUFFLED",
        "Each board arranges its own numbers to maximise the penalty for missing. The figure under each is that penalty, measured on the board above it.");
    var _gap = 20;
    var _cw = (_w - _gap * 5) / 4;
    var _ch = _h - _ty - _gap * 2 - 46;
    var _s = min(_cw, _ch);
    for (var i = 0; i < 4; i++) {
        var _bd = pas_darts_board(910000 + i * 5171, { sectors : 16 + i * 2 });
        for (var k = 0; k < 3 + i; k++) pas_darts_step(_bd, pas_input("key", -1, -1, "auto"));
        var _px = _gap + i * (_cw + _gap) + (_cw - _s) * 0.5;
        var _py = _ty + _gap;
        pas_darts_draw(_bd, _px, _py, _s, _s, pas_pal(3 + i * 2));
        var _f = pas_map(_px, _py + _s + 8, _s, 38);
        pas_text_fit(_f, string(_bd.sectors) + " BEDS", 0.5, 0.30, 0.96, _pal.type,
                     fa_center, fa_middle);
        pas_text_fit(_f, "ring penalty " + string(_bd.adjacency), 0.5, 0.76, 0.96, _pal.dim,
                     fa_center, fa_middle);
    }
    return _ty + _gap + _s + 46;
}

/// 6. THE PIP LATTICES. Six generated face designs, side by side.
function pas_bk_dice(_w, _h) {
    var _pal = pas_pal(0);
    var _ty = pas_bk_title(_w, _h, _pal,
        "DICE - EVERY BOARD CARVES ITS OWN FACE DESIGN",
        "Pips are placed on a generated lattice in mirror pairs, so a face is point-symmetric by construction and no two boards carve the same set.");
    var _gap = 18;
    var _rows = 2;
    var _ch = (_h - _ty - _gap * (_rows + 1)) / _rows;
    for (var i = 0; i < _rows; i++) {
        var _bd = pas_dice_board(330000 + i * 7717, { n : 6, faces : 6 });
        for (var v = 0; v < 6; v++) _bd.values[v] = v + 1;      // show all six faces, in order
        _bd.held[1] = true;
        var _asp = pas_dice_aspect(_bd);
        var _bw = _w - _gap * 2, _bh = _bw / _asp;
        if (_bh > _ch) { _bh = _ch; _bw = _bh * _asp; }
        pas_dice_draw(_bd, (_w - _bw) * 0.5, _ty + _gap + i * (_ch + _gap) + (_ch - _bh) * 0.5,
                      _bw, _bh, pas_pal(i * 4));
    }
    return _h - _gap;
}

/// 7. TWELVE THEMES, one room. The palette layer, shown rather than described.
function pas_bk_themes(_w, _h) {
    var _pal = pas_pal(11);

    // ⛔ THE CAPTION IS DERIVED FROM THE PALETTE, NEVER TYPED. Two things were wrong with the typed
    // one and both are §2 problems rather than layout problems: it said "the same generated WHEEL"
    // after this sheet had been rewritten to show MAZES, and it quoted a bed-lightness range of
    // "0.19 to 0.91" when the darkest theme in the table is 0.23. A caption that does not match its
    // own picture is a market claim the image does not support. This wing shipped the same shape on
    // Lode - a hero captioned "polished, oval cut" after the species had changed to a step cut.
    var _loL = 1, _hiL = 0;
    for (var t = 0; t < pas_theme_count(); t++) {
        var _tp = pas_pal(t);
        if (_tp.bedL < _loL) _loL = _tp.bedL;
        if (_tp.bedL > _hiL) _hiL = _tp.bedL;
    }
    var _ty = pas_bk_title(_w, _h, _pal,
        string(pas_theme_count()) + " THEMES - ONE PALETTE LAYER, NO HARD-CODED COLOUR",
        "The same generated maze through every theme, with each theme's ramp beside it. Bed lightness runs "
        + string_format(_loL, 1, 2) + " to " + string_format(_hiL, 1, 2)
        + "; the mark colour is DERIVED from the bed and is never one of the stops beside it.");
    // ⛔ THIS SHEET WAS A 4x3 GRID OF WHEELS AND dedupe.js MATCHED IT TO THE EIGHT-ROOM SHEET AT
    // HAMMING 5. Both were regular grids of roundish objects on a dark ground, which is what a
    // buyer sees in a thumbnail strip whatever the two sheets are actually about - this wing's
    // Horologe finding, "three grids of round brass things", arriving again.
    //
    // ⛔ THE THRESHOLD IS NEVER MOVED. The sheet changes: twelve TALL cards, one per theme, each
    // carrying the theme's RAMP as a stack of chips beside a rectangular maze plan drawn in it.
    // Different composition, different aspect, different silhouette - and it shows the palette
    // layer more directly than a wheel did, because the ramp itself is on the page.
    // The CARD is solved to its content and the page is solved to the cards - the maze fills the
    // card's width, and the card is exactly as tall as the maze plus the chip bar plus two lines of
    // caption. The first version divided the page into two equal rows and left a third of every
    // card as bare wood, which contentH could not see.
    var _cols = 6, _rows = 2, _gap = 14;
    var _cw = (_w - _gap * (_cols + 1)) / _cols;
    var _ms = _cw - 16;
    var _ch = _ms + 110;
    var _bd = pas_maze_board(606060, { w : 9, h : 9, braid : 0.14 });
    for (var i = 0; i < 22; i++) pas_maze_step(_bd, pas_input("key", -1, -1, "auto"));
    for (var i = 0; i < pas_theme_count(); i++) {
        var _p2 = pas_pal(i);
        var _px = _gap + (i mod _cols) * (_cw + _gap);
        var _py = _ty + _gap + (i div _cols) * (_ch + _gap);
        var _cf = pas_map(_px, _py, _cw, _ch);

        // the card the theme sits on, in the CABINET's wood so the twelve read as one set
        pas_plate(_cf, 0, 0, 1, 1, pas_detail(_cf, 0.03, 3, 14), _p2.w2, _p2.w4, _p2.w0);

        // the maze, square, at the top of the card
        pas_maze_draw(_bd, _px + (_cw - _ms) * 0.5, _py + 10, _ms, _ms, _p2);

        // the ramp, as chips: five bed stops, then both accents, then the derived ink. This is the
        // palette layer ITSELF on the page rather than a description of it, and the ink chip is
        // what makes the separation law visible - it is never one of the five stops beside it.
        var _chips = [ _p2.m0, _p2.m1, _p2.m2, _p2.m3, _p2.m4, _p2.p3, _p2.q3, _p2.ink ];
        var _cy = 10 + _ms + 12;
        var _bw2 = (_cw - 24) / array_length(_chips);
        for (var k = 0; k < array_length(_chips); k++) {
            pas_rrect(_cf, (12 + k * _bw2) / _cw, _cy / _ch,
                      (_bw2 - 2) / _cw, 26 / _ch,
                      pas_detail(_cf, 0.006, 1, 4), _chips[k]);
        }
        pas_text_fit(_cf, string_upper(_p2.name), 0.5, (_cy + 46) / _ch, 0.88,
                     _p2.type, fa_center, fa_middle);
        pas_text_fit(_cf, "bed L " + string_format(_p2.bedL, 1, 2)
                        + "   ink L " + string_format(_p2.inkL, 1, 2),
                     0.5, (_cy + 68) / _ch, 0.92, _p2.dim, fa_center, fa_middle);
    }
    return _h - _gap;
}

/// 8. THE PIN TABLE AND THE RANGE. Two rooms whose subject is a whole SCENE.
function pas_bk_table(_w, _h) {
    var _pal = pas_pal(9);
    var _ty = pas_bk_title(_w, _h, _pal,
        "BAGATELLE - THE CUPS ARE PRICED BY MEASURING THE BOARD",
        "Two hundred and forty sample balls are dropped through the finished pin field and each cup is valued by how rarely it is reached. Beside it, a range in perspective.");
    var _gap = 22;
    var _ch = _h - _ty - _gap * 2;

    var _bg = pas_bagatelle_board(414141, {});
    for (var i = 0; i < 4; i++) pas_bagatelle_step(_bg, pas_input("key", -1, -1, "launch"));
    var _bw = _ch * pas_bagatelle_aspect(_bg);
    pas_bagatelle_draw(_bg, _gap, _ty + _gap, _bw, _ch, pas_pal(9));

    var _rx = _gap * 2 + _bw;
    var _rw = _w - _rx - _gap;
    var _rg = pas_range_board(515151, { lanes : 5 });
    for (var i = 0; i < 3; i++) pas_range_step(_rg, pas_input("key", -1, -1, "auto"));
    var _rh = _rw / pas_range_aspect(_rg);
    if (_rh > _ch) { _rh = _ch; _rw = _rh * pas_range_aspect(_rg); }
    pas_range_draw(_rg, _rx, _ty + _gap + (_ch - _rh) * 0.5, _rw, _rh, pas_pal(4));
    return _ty + _gap + _ch;
}

/// 9. THE DISSECTION AND THE PLAN. Two rooms whose subject is a SHAPE.
function pas_bk_paper(_w, _h) {
    var _pal = pas_pal(7);
    var _ty = pas_bk_title(_w, _h, _pal,
        "TANGRAM - THE SILHOUETTE IS GENERATED, THEN CUT UP",
        "Every figure is dissected into its own piece set, so a board is solvable by construction. Beside it, a maze whose route is found by a search independent of the carver.");
    var _gap = 22;
    var _ch = _h - _ty - _gap * 2;
    var _half = (_w - _gap * 3) / 2;

    var _tg = pas_tangram_board(626262, { pieces : 8 });
    for (var i = 0; i < 5; i++) pas_tangram_step(_tg, pas_input("key", -1, -1, "auto"));
    var _tw = _half, _th = _tw / pas_tangram_aspect(_tg);
    if (_th > _ch) { _th = _ch; _tw = _th * pas_tangram_aspect(_tg); }
    pas_tangram_draw(_tg, _gap + (_half - _tw) * 0.5, _ty + _gap + (_ch - _th) * 0.5,
                     _tw, _th, pas_pal(7));

    var _mz = pas_maze_board(737373, { w : 15, h : 13, braid : 0.22 });
    for (var i = 0; i < 24; i++) pas_maze_step(_mz, pas_input("key", -1, -1, "auto"));
    var _mw = _half, _mh = _mw / pas_maze_aspect(_mz);
    if (_mh > _ch) { _mh = _ch; _mw = _mh * pas_maze_aspect(_mz); }
    pas_maze_draw(_mz, _gap * 2 + _half + (_half - _mw) * 0.5,
                  _ty + _gap + (_ch - _mh) * 0.5, _mw, _mh, pas_pal(10));
    return _ty + _gap + _ch;
}

/// ================================================================================================
/// THE RUNNER
/// ================================================================================================

/// @desc Bake the demo GIF: the cabinet walking its own eight rooms, each one playing itself.
///
/// ⛔ ONE FIXED FRAME SIZE FOR EVERY FRAME. The cabinet takes its proportion from the room it is
/// showing (pas_cabinet_aspect), which is right on a still and wrong in a GIF - the housing would
/// jump shape at every room change and the whole thing would read as eight images rather than one
/// machine. The GIF pins 1.30 and lets each board keep its own margins inside the opening.
///
/// ⚠️ AND IT DRAWS EVERY FRAME EXPLICITLY RATHER THAN PHOTOGRAPHING AN ANIMATION IN PROGRESS. The
/// RPG Maker wing measured the alternative: a GIF paced by screenshot latency instead of by its own
/// stride, with a frozen tail no frame-delta check can see. Here each frame is a deliberate state -
/// step the room, draw, save - so the pacing is arithmetic.
///
/// Native size, and NEVER upscaled: make_gif.ps1 was measured re-encoding a 520px source at 600px
/// for 5.6x the bytes and a worse picture, because a resample invents intermediate colours and GIF
/// pays for each one twice.
function pas_bake_gif() {
    global.pas_stage = 200;
    var _w = 624, _h = 480;
    var _cab = pas_cabinet_new(20260903);
    var _surf = surface_create(_w, _h);
    var _n = 0;

    for (var _room = 0; _room < pas_room_count(); _room++) {
        pas_cabinet_select(_cab, _room);
        for (var _f = 0; _f < 11; _f++) {
            // Hold the first frame of each room still so a viewer can see WHICH room it is before
            // it starts moving. A lead-in is deliberate; what is forbidden is a GIF with no
            // graduating run at all.
            if (_f > 1) pas_cabinet_step(_cab, pas_input("key", -1, -1, "auto"));
            surface_set_target(_surf);
            draw_clear(_cab.pal.back);
            draw_set_font(fnt_pastime);
            pas_cabinet_draw(_cab, 8, 8, _w - 16, _h - 16);
            surface_reset_target();
            // ⛔ PAD BY ARITHMETIC, NEVER BY REPLACING WHITESPACE IN A FORMATTED STRING. This wing
            // measured string_replace(string_format(...), " ", "0") producing "frame_0 0.png" -
            // string_replace changes ONE occurrence - and the frame COUNT check upstream still read
            // 44 of 44, because it globbed and counted while every name was wrong.
            var _pad = (_n < 10) ? "00" : ((_n < 100) ? "0" : "");
            surface_save(_surf, "gif_" + _pad + string(_n) + ".png");
            _n += 1;
        }
    }
    surface_free(_surf);

    var _fh = file_text_open_write("pas_gif.json");
    file_text_write_string(_fh, "{\"frames\":" + string(_n)
        + ",\"steps\":11,\"hold\":2"
        + ",\"w\":" + string(_w) + ",\"h\":" + string(_h)
        + ",\"rooms\":" + string(pas_room_count())
        + ",\"version\":\"" + PAS_VERSION + "\"}");
    file_text_close(_fh);
}

/// @desc Bake every sheet and write the report.
///
/// ⛔ IT WRITES THE MEASUREMENTS, NOT A VERDICT. A runner that printed "ok" would be exactly the
/// shape §2b's second rule warns about; the numbers go into the file so the next session compares
/// them rather than inheriting a sentence.
function pas_bake_all() {
    global.pas_stage = 100;

    // ⛔ ONE LIST, AND THE REPORT DECLARES ITS OWN LENGTH FROM IT. bake_store.ps1 refuses to copy a
    // PARTIAL gallery, and it can only do that if the bake names how many sheets it set out to
    // draw. MEASURED in this wing on Raiment: a bake ran out of memory on the fifth of nine sheets,
    // the exception handler ended it cleanly, the script printed EXIT 0 and COLLECTED 4, and
    // store_assets was left holding four fresh sheets and five stale ones with nothing red
    // anywhere. Taking the count from the list makes the two impossible to drift apart.
    var _list = [
        [ "sheet_1_hero",    PAS_BK_W, 1230,     pas_bk_hero    ],
        [ "sheet_2_eight",   PAS_BK_W, 800,      pas_bk_eight   ],
        [ "sheet_3_volume",  PAS_BK_W, PAS_BK_H, pas_bk_volume  ],
        [ "sheet_4_circuit", PAS_BK_W, PAS_BK_H, pas_bk_circuit ],
        [ "sheet_5_darts",   PAS_BK_W, 540,      pas_bk_darts   ],
        [ "sheet_6_dice",    PAS_BK_W, 1240,     pas_bk_dice    ],
        [ "sheet_7_themes",  PAS_BK_W, 810,      pas_bk_themes  ],
        [ "sheet_8_table",   PAS_BK_W, 940,      pas_bk_table   ],
        [ "sheet_9_paper",   PAS_BK_W, 860,      pas_bk_paper   ],
    ];

    var _rows = [];
    for (var i = 0; i < array_length(_list); i++) {
        var _row = _list[i];
        array_push(_rows, pas_bk_sheet(_row[0], _row[1], _row[2], _row[3]));
    }

    var _f = file_text_open_write("pas_bake.json");
    var _s = "{\"sheetsExpected\":" + string(array_length(_list)) + ",\"sheets\":[";
    for (var i = 0; i < array_length(_rows); i++) {
        var _r = _rows[i];
        if (i > 0) _s += ",";
        _s += "{\"name\":\"" + _r.name + "\""
            + ",\"w\":" + string(_r.w) + ",\"h\":" + string(_r.h)
            + ",\"endY\":" + string(round(_r.endY))
            + ",\"ink\":" + string(_r.ink)
            + ",\"fullW\":" + string_format(_r.fullW, 1, 3)
            + ",\"fullH\":" + string_format(_r.fullH, 1, 3)
            + ",\"contentW\":" + string_format(_r.contentW, 1, 3)
            + ",\"contentH\":" + string_format(_r.contentH, 1, 3)
            + ",\"clipped\":" + (_r.clipped ? "true" : "false")
            + ",\"okFill\":" + (_r.okFill ? "true" : "false")
            + ",\"box\":[" + string(_r.x0) + "," + string(_r.y0) + ","
                           + string(_r.x1) + "," + string(_r.y1) + "]}";
    }
    _s += "],\"fillFloorW\":" + string_format(PAS_BK_FILL_W, 1, 2)
        + ",\"fillFloorH\":" + string_format(PAS_BK_FILL_H, 1, 2)
        + ",\"edgeMargin\":" + string(PAS_BK_EDGE)
        + ",\"version\":\"" + PAS_VERSION + "\"}";
    file_text_write_string(_f, _s);
    file_text_close(_f);
}
