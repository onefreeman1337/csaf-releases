{
  "$GMScript": "v1",
  "%Name": "pas_wheel",
  "name": "pas_wheel",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}