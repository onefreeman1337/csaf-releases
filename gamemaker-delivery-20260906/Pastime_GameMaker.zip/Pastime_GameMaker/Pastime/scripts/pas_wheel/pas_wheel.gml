/// PASTIME - pas_wheel. Room 6 of the cabinet.
///
/// Visual language: fairground. Gilt, lacquer and bulbs. A segmented rim with a peg at every
/// division, a lamp ring, a turned hub with spokes, and a leather flapper that ticks over the pegs.
///
/// ⭐ WHAT IS GENERATED: the PRIZE RING, under the rules a real wheel maker works to. Values are
/// drawn from a generated denomination set, then ARRANGED so that no two equal values are adjacent
/// and the jackpot is flanked by the two smallest segments on the wheel. That second rule is the
/// whole psychology of a prize wheel - the near miss is the product - and it is the sort of thing a
/// static art pack cannot give a buyer because it depends on the numbers.
///
/// ⛔ THE ARRANGEMENT IS A SEARCH AND ITS RESULT IS VERIFIED, NOT ASSUMED. pas_wheel_rules_ok reads
/// the finished ring and reports which rule it breaks; the suite runs it on every seed. A generator
/// that quietly failed its own constraint on one seed in a thousand would otherwise ship, and this
/// wing has measured exactly that shape twice (Muster's two uncrossable fields, Lode's 440 pans that
/// could never come up empty).
///
/// ⚠️ THIS IS THE ONE ROOM WHERE ROTATED NUMERALS ARE CORRECT. Darts draws its numbers upright
/// because a dartboard hangs still; a wheel turns, so its type is radial and every segment reads at
/// the top. Copying one convention to the other would be wrong in both directions.
/// ================================================================================================

#macro PAS_WH_BANKRUPT -1

/// @desc Build a wheel.
/// @param {real} seed
/// @param {struct} opts  optional: {segs}
function pas_wheel_board(seed, opts = {}) {
    var _r = pas_rng(seed);

    var _n = (is_struct(opts) && variable_struct_exists(opts, "segs"))
        ? opts.segs : pas_rng_pick(_r, [ 12, 14, 16, 18, 20, 24 ]);
    if (_n < 6) _n = 6;
    if (_n & 1) _n += 1;                   // odd counts cannot alternate; the seam would show

    // The denomination set. A wheel with evenly spaced prizes is a raffle; a wheel whose steps grow
    // is a game, because the top of it is worth reaching for.
    var _base = pas_rng_pick(_r, [ 5, 10, 20, 25 ]);
    var _steps = [ 1, 1, 2, 2, 3, 4, 5, 8 ];

    var board = {
        room     : "wheel",
        seed     : seed,
        segs     : _n,
        base     : _base,
        values   : array_create(_n, 0),
        lamps    : pas_rng_pick(_r, [ 0, 1, 1, 2 ]) ,   // 0 none, 1 one per segment, 2 two
        spokes   : pas_rng_pick(_r, [ 4, 5, 6, 8 ]),
        pegs     : true,
        rimw     : 0.055 + pas_rng_float(_r) * 0.030,
        angle    : pas_rng_float(_r) * 360,
        vel      : 0,
        spinning : false,
        ticks    : 0,
        result   : -999,
        won      : 0,
        rules    : "",
        rng      : _r,
    };

    // ---- fill the ring ---------------------------------------------------
    var _vals = array_create(_n);
    for (var i = 0; i < _n; i++) {
        _vals[i] = _base * _steps[i mod array_length(_steps)];
    }
    // one jackpot and one bankrupt: the two segments that make the rest of the wheel matter
    _vals[0] = _base * 20;
    _vals[1] = PAS_WH_BANKRUPT;
    board.values = pas_wheel_arrange(_vals, _r);
    board.rules = pas_wheel_rules_ok(board);
    return board;
}

/// @desc Arrange the values under the wheel-maker's two rules.
///
/// ⛔ THE FIRST VERSION OF THIS FUNCTION BROKE ITS OWN FIRST RULE WITH ITS SECOND REPAIR, AND THE
/// SUITE CAUGHT IT ON 140 RINGS OF 220. MEASURED 2026-09-03, pas_selftest STAGE 9, first run:
/// `wheel: 140 rings break a maker rule. seed 61000: adjacent equal at 2`. It shuffled, then
/// repaired adjacent-equal pairs by random swaps, then went back and swapped the two smallest
/// values next to the jackpot - and that second pass moved values without re-checking the first
/// rule, so more than half of every wheel the product could build was wrong.
///
/// ⭐ THE LESSON IS ABOUT THE SHAPE, NOT THE BUG: TWO SEQUENTIAL REPAIRS THAT DO NOT KNOW ABOUT
/// EACH OTHER ARE NOT A REPAIR, THEY ARE A RACE. The rewrite below CONSTRUCTS an arrangement that
/// satisfies both rules instead of patching one that does not:
///
///   1. Place the jackpot, then the two smallest positive values on either side of it. That is
///      rule 2, satisfied by placement rather than by a later correction.
///   2. Fill the rest by always taking the MOST COMMON remaining value that differs from the one
///      just placed - the standard greedy for "rearrange so no two neighbours are equal", which
///      succeeds whenever no value occupies more than half the ring, and none here does.
///   3. Rotate by a seeded amount. Rotation preserves both rules exactly, because both are
///      statements about NEIGHBOURS, so it buys variety for free.
///
/// pas_wheel_rules_ok still reads the finished ring and the suite still runs it on every seed. A
/// construction that is believed rather than checked is this factory's most expensive habit.
function pas_wheel_arrange(_vals, _r) {
    var _n = array_length(_vals);
    if (_n < 3) return _vals;

    // ---- distinct values and their counts --------------------------------
    var _dv = [], _dc = [];
    for (var i = 0; i < _n; i++) {
        var _f = -1;
        for (var k = 0; k < array_length(_dv); k++) if (_dv[k] == _vals[i]) { _f = k; break; }
        if (_f < 0) { array_push(_dv, _vals[i]); array_push(_dc, 1); }
        else _dc[_f] += 1;
    }

    var _out = array_create(_n, 0);

    // ---- rule 2, by placement --------------------------------------------
    var _ji = 0;
    for (var k = 1; k < array_length(_dv); k++) if (_dv[k] > _dv[_ji]) _ji = k;
    _out[0] = _dv[_ji];
    _dc[_ji] -= 1;
    _out[1]      = pas_wh_take_smallest(_dv, _dc);
    _out[_n - 1] = pas_wh_take_smallest(_dv, _dc);

    // ---- rule 1, by greedy placement -------------------------------------
    for (var p = 2; p <= _n - 2; p++) {
        // The last free slot also has to differ from the fixed value at _n-1, or the circle closes
        // on a collision the linear walk never looks at.
        var _forbid2 = (p == _n - 2) ? _out[_n - 1] : _out[0];
        var _pick = pas_wh_take_common(_dv, _dc, _out[p - 1], _forbid2, _r);
        // Relax in one documented order rather than falling through to whatever is left: first
        // drop the far constraint, then take anything. A silent "whatever is left" would satisfy
        // the loop and quietly break rule 1, which is the defect this rewrite exists to end.
        if (is_undefined(_pick)) _pick = pas_wh_take_common(_dv, _dc, _out[p - 1], _out[p - 1], _r);
        if (is_undefined(_pick)) _pick = pas_wh_take_smallest(_dv, _dc);
        _out[p] = _pick;
    }

    // ---- the verified repair ---------------------------------------------
    // ⛔ THE GREEDY IS NOT SUFFICIENT AND THE FAILURE IS STRUCTURAL, NOT RANDOM. MEASURED
    // 2026-09-03 by Internal_Ops/wheel_arrange_probe.js, which replicates this function exactly
    // over 4,000 seeds: 708 rings (17.7%) break rule 1, and EVERY ONE OF THEM COLLIDES AT THE LAST
    // INTERIOR SLOT, n-2, with the relaxation branch firing there and nowhere else. The cause is
    // exact: both flanks consume the SMALLEST value, the greedy takes the most common value first
    // so the smallest value's remaining copies are placed last, and the last slot is adjacent to a
    // flank holding that value. It fails on 18, 20 and 24 segments (34-37% each) and NEVER on 12,
    // 14 or 16 - a size-dependent bug that a 220-seed suite could easily have shown as "a few".
    //
    // ⭐ The probe is why the fix is a repair rather than another guess at the greedy: it named the
    // mechanism instead of my naming it. This wing has spent two build cycles writing instruments
    // for theories that were green over the very defect they were built for.
    //
    // ⛔ AND THIS REPAIR IS VERIFIED, WHICH THE FIRST VERSION OF THIS FILE'S REPAIR WAS NOT. Every
    // candidate swap is checked against all four adjacencies it touches BEFORE it is committed, and
    // the three positions rule 2 pins are never touched at all. MEASURED with the repair: 0 of
    // 4,000 rule-1 violations and 0 of 4,000 rule-2 violations, with the repair firing on exactly
    // the 708 rings that needed it.
    pas_wheel_repair(_out);

    // ---- rotate. Both rules are about neighbours, so rotation preserves them ----
    var _k2 = pas_rng_int(_r, 0, _n - 1);
    var _rot = array_create(_n);
    for (var i = 0; i < _n; i++) _rot[i] = _out[(i + _k2) mod _n];
    return _rot;
}

/// @desc Fix any adjacent-equal pair by a swap that is proven safe first. In place.
///
/// Runs BEFORE the rotation, so the protected positions are known exactly: 0 holds the jackpot and
/// 1 and n-1 hold its flanks, which rule 2 pins. Nothing here may touch those three.
/// @return {bool} true if the ring came out clean
function pas_wheel_repair(_a) {
    var _n = array_length(_a);
    if (_n < 4) return true;

    for (var _pass = 0; _pass < 8; _pass++) {
        var _bad = -1;
        for (var i = 0; i < _n; i++) {
            if (_a[i] == _a[(i + 1) mod _n]) { _bad = i; break; }
        }
        if (_bad < 0) return true;

        // Prefer moving the member rule 2 does not pin. In every measured case that is the LEFT
        // member, because the right one is the flank at n-1.
        var _cands = [ (_bad + 1) mod _n, _bad ];
        var _done = false;
        for (var _ci = 0; _ci < 2 && !_done; _ci++) {
            var _j = _cands[_ci];
            if (_j == 0 || _j == 1 || _j == _n - 1) continue;      // protected by rule 2
            for (var _q = 0; _q < _n && !_done; _q++) {
                if (_q == _j || _q == 0 || _q == 1 || _q == _n - 1) continue;
                // Skip a neighbour of _j: swapping adjacent cells makes the two checks alias and a
                // swap can then be "verified" against itself.
                if (_q == (_j + 1) mod _n || _q == (_j - 1 + _n) mod _n) continue;
                var _vj = _a[_j], _vq = _a[_q];
                if (_vj == _vq) continue;

                // Commit provisionally, test all four adjacencies, roll back on any collision.
                _a[_j] = _vq; _a[_q] = _vj;
                var _ok = (_a[_j] != _a[(_j + 1) mod _n]) && (_a[_j] != _a[(_j - 1 + _n) mod _n])
                       && (_a[_q] != _a[(_q + 1) mod _n]) && (_a[_q] != _a[(_q - 1 + _n) mod _n]);
                if (_ok) _done = true;
                else { _a[_j] = _vj; _a[_q] = _vq; }
            }
        }
        // No safe swap exists. Stop rather than force one: pas_wheel_rules_ok will read the ring
        // and the board will SAY it is wrong, which is the only honest outcome. Measured never to
        // happen over 4,000 seeds, and it is still not assumed.
        if (!_done) return false;
    }
    return false;
}

/// @desc Take one of the smallest remaining POSITIVE values. Consumes it.
///
/// Positive because a bankrupt segment is not a small prize, it is a different kind of thing, and
/// putting it beside the jackpot would make the wheel's best segment its safest one.
function pas_wh_take_smallest(_dv, _dc) {
    var _bi = -1;
    for (var k = 0; k < array_length(_dv); k++) {
        if (_dc[k] <= 0 || _dv[k] <= 0) continue;
        if (_bi < 0 || _dv[k] < _dv[_bi]) _bi = k;
    }
    if (_bi < 0) {
        for (var k = 0; k < array_length(_dv); k++) if (_dc[k] > 0) { _bi = k; break; }
    }
    if (_bi < 0) return 0;
    _dc[_bi] -= 1;
    return _dv[_bi];
}

/// @desc Take the most common remaining value that is neither _no1 nor _no2. Consumes it.
///
/// Most-common-first is what makes the greedy work: the value with the most copies left is the one
/// most likely to be forced next to itself later, so it goes now while there is still a gap for it.
/// @return the value, or undefined when every remaining value is forbidden
function pas_wh_take_common(_dv, _dc, _no1, _no2, _r) {
    var _bi = -1, _bc = -1;
    for (var k = 0; k < array_length(_dv); k++) {
        if (_dc[k] <= 0) continue;
        if (_dv[k] == _no1 || _dv[k] == _no2) continue;
        // A seeded tie-break, so two wheels with the same value multiset are not the same wheel.
        var _score = _dc[k] * 8 + pas_rng_int(_r, 0, 3);
        if (_score > _bc) { _bc = _score; _bi = k; }
    }
    if (_bi < 0) return undefined;
    _dc[_bi] -= 1;
    return _dv[_bi];
}

/// @desc Read the finished ring and report the first rule it breaks, or "" if it keeps both.
///
/// Returns a STRING rather than a bool on purpose: a silent refusal is correct behaviour that
/// cannot be told apart from a failure, and this wing has paid for that distinction (Lanternbound's
/// restore refused every resume and looked exactly like the condition it guarded against).
function pas_wheel_rules_ok(_board) {
    var _n = _board.segs;
    var _a = _board.values;
    for (var i = 0; i < _n; i++) {
        if (_a[i] == _a[(i + 1) mod _n]) return "adjacent equal at " + string(i);
    }
    var _ji = 0, _jv = _a[0];
    for (var i = 1; i < _n; i++) if (_a[i] > _jv) { _jv = _a[i]; _ji = i; }
    var _l = _a[(_ji - 1 + _n) mod _n], _rr = _a[(_ji + 1) mod _n];
    for (var i = 0; i < _n; i++) {
        if (i == _ji) continue;
        if (_a[i] <= 0) continue;
        if (_l > 0 && _a[i] < _l && i != ((_ji - 1 + _n) mod _n) && i != ((_ji + 1) mod _n)) {
            return "jackpot not flanked by the smallest";
        }
        if (_rr > 0 && _a[i] < _rr && i != ((_ji - 1 + _n) mod _n) && i != ((_ji + 1) mod _n)) {
            return "jackpot not flanked by the smallest";
        }
    }
    return "";
}

/// @desc Which segment the flapper is over, for a given wheel angle.
///
/// PURE, and it is the one piece of geometry the renderer, the result and the suite all read. The
/// flapper is at the TOP of the wheel, so segment 0's centre is under it at angle 0.
function pas_wheel_segment_at(_board, _angle) {
    var _n = _board.segs;
    var _step = 360 / _n;
    var _rel = (((90 - _angle) mod 360) + 360) mod 360;
    return floor((_rel + _step * 0.5) / _step) mod _n;
}

/// @desc Advance the spin by one tick. input "spin" starts it; anything else advances.
/// @return {string} "spinning" | "landed" | "idle"
function pas_wheel_step(_board, _input) {
    var _k = pas_input_key(_input);
    if (!_board.spinning && (_k == "spin" || _k == "" || _k == "auto")) {
        _board.vel = 14 + pas_rng_float(_board.rng) * 22;
        _board.spinning = true;
        _board.result = -999;
        _board.ticks = 0;
        return "spinning";
    }
    if (!_board.spinning) return "idle";

    _board.angle = (_board.angle + _board.vel) mod 360;
    _board.ticks += 1;
    // Friction plus a peg drag: the flapper takes a bite out of the wheel every time it clicks
    // past a peg, which is why a real wheel decelerates in steps rather than smoothly.
    _board.vel *= 0.978;
    _board.vel -= 0.012;
    if (_board.vel <= 0.22) {
        _board.vel = 0;
        _board.spinning = false;
        _board.result = pas_wheel_segment_at(_board, _board.angle);
        var _v = _board.values[_board.result];
        _board.won = (_v == PAS_WH_BANKRUPT) ? 0 : (_board.won + _v);
        return "landed";
    }
    return "spinning";
}

function pas_wheel_seg_text(_board, _i) {
    var _v = _board.values[_i];
    return (_v == PAS_WH_BANKRUPT) ? "LOSE" : string(_v);
}

function pas_wheel_label(_board) {
    var _s = "WHEEL  " + string(_board.segs) + " segments"
           + "   top " + string(_board.base * 20)
           + "   bank " + string(_board.won);
    if (_board.rules != "") _s += "   [" + _board.rules + "]";
    return _s;
}

function pas_wheel_aspect(_board) { return 1.0; }

/// @desc Draw the wheel.
function pas_wheel_draw(_board, _x, _y, _w, _h, _pal) {
    var _f = pas_map(_x, _y, _w, _h);
    var _n = _board.segs;
    var _step = 360 / _n;
    var _seg = max(4, round(72 / _n));
    var _ru = _f.s / max(1, _f.w), _rv = _f.s / max(1, _f.h);
    var _rOut = 0.400;
    var _rIn  = 0.075;
    var _rim0 = _rOut;
    var _rim1 = _rOut + _board.rimw;

    // -- back plate the wheel turns against -------------------------------
    pas_disc(_f, 0.5, 0.5, _rim1 + 0.045, _pal.w1);
    pas_ring(_f, 0.5, 0.5, _rim1 + 0.035, pas_detail(_f, 0.010, 2, 10), _pal.w4);

    // -- segments ---------------------------------------------------------
    // Lacquer alternation with a third colour on the jackpot and the bankrupt, so the two segments
    // that decide the game are findable at a glance and at any size.
    for (var i = 0; i < _n; i++) {
        var _a0 = _board.angle + i * _step - _step * 0.5;
        var _v = _board.values[i];
        var _c = (i & 1) ? _pal.m1 : _pal.m3;
        if (_v == PAS_WH_BANKRUPT) _c = _pal.q1;
        else if (_v >= _board.base * 20) _c = _pal.p3;
        pas_annulus(_f, 0.5, 0.5, _rIn, _rOut, -_a0 - _step, -_a0, _c, _seg);
    }

    // -- radial dividers and the gilt rim ---------------------------------
    var _wire = pas_detail(_f, 0.004, 1, 5);
    for (var i = 0; i < _n; i++) {
        var _a = degtorad(-(_board.angle + i * _step - _step * 0.5));
        pas_line(_f,
            0.5 + cos(_a) * _rIn * _ru,  0.5 + sin(_a) * _rIn * _rv,
            0.5 + cos(_a) * _rOut * _ru, 0.5 + sin(_a) * _rOut * _rv, _wire, _pal.b1);
    }
    pas_annulus(_f, 0.5, 0.5, _rim0, _rim1, 0, 360, _pal.b2, 96);
    pas_annulus(_f, 0.5, 0.5, _rim0, _rim0 + (_rim1 - _rim0) * 0.38, 0, 360, _pal.b4, 96);

    // -- pegs: one at every division, standing on the rim -----------------
    // The pegs are what the flapper ticks over. Without them a prize wheel is a pie chart.
    for (var i = 0; i < _n; i++) {
        var _a = degtorad(-(_board.angle + i * _step - _step * 0.5));
        var _pr = (_rim0 + _rim1) * 0.5;
        pas_disc(_f, 0.5 + cos(_a) * _pr * _ru, 0.5 + sin(_a) * _pr * _rv,
                 pas_detail(_f, 0.011, 2, 10) / max(1, _f.s), _pal.b4);
        pas_disc(_f, 0.5 + cos(_a) * _pr * _ru, 0.5 + sin(_a) * _pr * _rv,
                 pas_detail(_f, 0.006, 1, 6) / max(1, _f.s), _pal.w0);
    }

    // -- lamps ------------------------------------------------------------
    if (_board.lamps > 0) {
        var _lc = _n * _board.lamps;
        var _lr = _rim1 + 0.024;
        for (var i = 0; i < _lc; i++) {
            var _a = degtorad(-(i * (360 / _lc)));
            var _lu = 0.5 + cos(_a) * _lr * _ru, _lv = 0.5 + sin(_a) * _lr * _rv;
            // Two discs, not one: a bulb has a bright filament in a warm glass envelope, and one
            // flat disc reads as a rivet.
            pas_disc(_f, _lu, _lv, pas_detail(_f, 0.013, 2, 12) / max(1, _f.s), _pal.b1);
            pas_disc(_f, _lu, _lv, pas_detail(_f, 0.008, 1, 8) / max(1, _f.s),
                     ((i + floor(_board.ticks / 6)) & 1) ? _pal.b4 : _pal.p4);
        }
    }

    // -- segment type, RADIAL ---------------------------------------------
    for (var i = 0; i < _n; i++) {
        var _mid = _board.angle + i * _step;
        var _a = degtorad(-_mid);
        var _tr = (_rIn + _rOut) * 0.62;
        var _tu = 0.5 + cos(_a) * _tr * _ru, _tv = 0.5 + sin(_a) * _tr * _rv;
        var _str = pas_wheel_seg_text(_board, i);
        // The numeral stands ALONG the radius, reading outward, and is flipped on the left half so
        // it is never upside down. That flip is the whole reason radial type is legible.
        var _rot = -_mid;
        var _norm = ((_rot mod 360) + 360) mod 360;
        if (_norm > 90 && _norm < 270) _rot += 180;
        draw_set_halign(fa_center);
        draw_set_valign(fa_middle);
        // ⛔ ink, NOT type. `type` is the CABINET's lettering colour - a pale gold that reads on
        // dark walnut - and these numerals sit on a SEGMENT, which is the BED's ramp. On the pale
        // themes (card 0.86, vellum 0.79, chalk 0.91) that is pale on pale, and the twelve-theme
        // sheet showed three wheels whose numbers could not be read at all.
        //
        // ⭐ pas_palette's own header states this law - "the ramp describes how a SURFACE turns in
        // the light; the thing that CONTRASTS with a surface is what you WRITE on it" - and `ink`
        // is derived from the bed with a separation floor the suite asserts on every theme. The
        // rule was written down, and then the call site did something else. A constraint that lives
        // only in prose is enforced by whoever last read the prose.
        draw_set_colour(_pal.ink);
        var _sc = min(1, (_f.s * 0.085) / max(1, string_width(_str)));
        draw_text_transformed(pas_mx(_f, _tu), pas_my(_f, _tv), _str, _sc, _sc, _rot);
        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
    }

    // -- hub --------------------------------------------------------------
    for (var i = 0; i < _board.spokes; i++) {
        var _a = degtorad(-(_board.angle + i * (360 / _board.spokes)));
        pas_line(_f, 0.5, 0.5,
                 0.5 + cos(_a) * _rIn * 0.92 * _ru, 0.5 + sin(_a) * _rIn * 0.92 * _rv,
                 pas_detail(_f, 0.010, 2, 9), _pal.b1);
    }
    pas_disc(_f, 0.5, 0.5, _rIn * 0.86, _pal.b2);
    pas_disc(_f, 0.5, 0.5, _rIn * 0.58, _pal.b4);
    pas_disc(_f, 0.5, 0.5, _rIn * 0.24, _pal.w0);

    // -- the flapper ------------------------------------------------------
    // Deflected by the peg it is riding, so a still frame of a spinning wheel shows it under load.
    var _tip = _rim0 - 0.010;
    var _defl = _board.spinning ? (sin(degtorad(_board.angle * _n)) * 9) : 0;
    var _fa = degtorad(-90 + _defl);
    var _base = _rim1 + 0.062;
    var _bu = 0.5 + cos(_fa) * _base * _ru, _bv = 0.5 + sin(_fa) * _base * _rv;
    var _tu2 = 0.5 + cos(_fa) * _tip * _ru, _tv2 = 0.5 + sin(_fa) * _tip * _rv;
    var _perp = _fa + pi * 0.5;
    var _bw = 0.026;
    pas_poly(_f, [
        _tu2, _tv2,
        _bu + cos(_perp) * _bw * _ru, _bv + sin(_perp) * _bw * _rv,
        _bu - cos(_perp) * _bw * _ru, _bv - sin(_perp) * _bw * _rv
    ], _pal.p2);
    pas_disc(_f, _bu, _bv, 0.030, _pal.b3);
    pas_disc(_f, _bu, _bv, 0.014, _pal.w0);
}
