/// PASTIME - pas_bagatelle. Room 7 of the cabinet.
///
/// Visual language: pin table. Brass pins standing on a stained, grained board, a sprung plunger, a
/// curved return arch and a row of scoring cups behind turned dividers.
///
/// ⭐ WHAT IS GENERATED: the PIN FIELD and the CUP RANK. Row count, lattice (triangular, square or
/// staggered), a per-pin jitter, and then a cup rank whose values are derived from how HARD each cup
/// actually is to reach - not typed in. That last part is the room: a bagatelle board where the
/// middle cup is worth the most is a board nobody would build, and the only way to know which cup is
/// hard is to run the ball down the field and count.
///
/// ⛔ SO THE VALUES ARE MEASURED FROM THE BOARD, BY THE BOARD. pas_bagatelle_profile drops a
/// hundred sample balls through the finished pin field and returns the landing distribution; the cup
/// values are the inverse of that. It is the same discipline as pas_darts's searched number ring,
/// one level up: the generator does not merely arrange the board, it MEASURES it and prices it.
///
/// ⚠️ AND THE SAMPLING RUNS ON ITS OWN GENERATOR, SEEDED FROM THE BOARD'S SEED, NOT ON THE BOARD'S
/// LIVE ONE. Sampling on the live stream would advance it, so the first ball a player launched would
/// depend on how many samples the profiler happened to take - and changing the sample count would
/// silently change every board in the product.
/// ================================================================================================

/// @desc Build a bagatelle table.
/// @param {real} seed
/// @param {struct} opts  optional: {rows, cups}
function pas_bagatelle_board(seed, opts = {}) {
    var _r = pas_rng(seed);

    var _rows = (is_struct(opts) && variable_struct_exists(opts, "rows"))
        ? opts.rows : pas_rng_int(_r, 7, 11);
    if (_rows < 3) _rows = 3;
    var _cups = (is_struct(opts) && variable_struct_exists(opts, "cups"))
        ? opts.cups : pas_rng_int(_r, 5, 8);
    if (_cups < 3) _cups = 3;

    var board = {
        room     : "bagatelle",
        seed     : seed,
        rows     : _rows,
        cupn     : _cups,
        lattice  : pas_rng_int(_r, 0, 2),
        jitter   : pas_rng_float(_r) * 0.010,
        grain    : pas_rng_int(_r, 0, 3),
        pins     : [],
        cupval   : array_create(_cups, 0),
        cuphits  : array_create(_cups, 0),
        top      : 0.150,          // the top of the pin field, board space
        bot      : 0.780,          // the bottom of it, above the cups
        wall     : 0.075,          // the side rails
        power    : 0.55,
        ball     : -1,             // the launch column of the ball in flight, or -1
        trail    : [],
        left     : 6,
        score    : 0,
        over     : false,
        rng      : _r,
    };

    // ---- the pin field ---------------------------------------------------
    // ⛔ THE FIRST VERSION CHECKED THE BOUNDS AND THEN ADDED THE JITTER. MEASURED 2026-09-03,
    // pas_selftest STAGE 10, first run: 44 assertions of `a pin stands outside the rails`. The
    // check read the LATTICE position, passed it, and the jitter was applied afterwards - so the
    // one thing that could move a pin out of the table was the one thing the guard could not see.
    // ⭐ The general form is worth more than the fix: A GUARD PLACED BEFORE THE LAST MUTATION
    // GUARDS A VALUE NOBODY SHIPS. Every offset row also reached exactly the rail, because
    // (c + 0.5 + 0.5)/per is exactly 1 at the last column, so the guard was sitting on the boundary
    // it was meant to defend even before the jitter touched it.
    //
    // ✅ Fixed by SOLVING the field for the space available rather than by clamping afterwards: the
    // lattice is inset by a margin wider than the largest jitter this generator can produce, and
    // the divisor accounts for the stagger so an offset row cannot reach 1. Containment is then a
    // property of the layout, and the suite's assertion becomes a REGRESSION guard - which is why
    // it is paired with a vacuity guard that feeds it a deliberately escaped pin.
    var _span = 1 - board.wall * 2;
    var _pinMargin = 0.030;                       // > the 0.010 ceiling on `jitter`, with room
    for (var _row = 0; _row < _rows; _row++) {
        var _v = board.top + (board.bot - board.top) * (_row / max(1, _rows - 1));
        var _per = 4 + (_row mod 3);
        if (board.lattice == 1) _per = 6;
        if (board.lattice == 2) _per = 5 + (_row & 1);
        var _off = ((_row & 1) && board.lattice != 1) ? 0.5 : 0;
        var _u0 = board.wall + _pinMargin;
        var _uw = _span - _pinMargin * 2;
        for (var c = 0; c < _per; c++) {
            var _t = (c + 0.5 + _off) / (_per + _off);      // strictly inside 0..1 for any stagger
            array_push(board.pins, {
                u : _u0 + _uw * _t + (pas_rng_float(_r) - 0.5) * board.jitter * 2,
                v : _v + (pas_rng_float(_r) - 0.5) * board.jitter * 2,
                row : _row,
            });
        }
    }

    // ---- price the cups from a measured landing profile -------------------
    var _prof = pas_bagatelle_profile(board, 240);
    var _max = 1;
    for (var i = 0; i < _cups; i++) _max = max(_max, _prof[i]);
    for (var i = 0; i < _cups; i++) {
        // Rarer cup, higher value. Rounded to a five so a rank reads as a rank rather than as a
        // table of arbitrary numbers.
        var _rarity = 1 - (_prof[i] / _max);
        board.cupval[i] = 5 * max(1, round((5 + _rarity * 45) / 5));
    }
    return board;
}

/// @desc Drop `_n` sample balls and count where they land. PURE - no drawing, no engine handles.
/// @return {array} landings per cup
function pas_bagatelle_profile(_board, _n) {
    var _out = array_create(_board.cupn, 0);
    // Own generator, seeded FROM the board's seed but not shared with it. See the header.
    var _r = pas_rng(_board.seed ^ 0x5BD1E995);
    for (var i = 0; i < _n; i++) {
        var _p = pas_bagatelle_drop(_board, pas_rng_float(_r), _r);
        _out[_p.cup] += 1;
    }
    return _out;
}

/// @desc Run one ball down the field. PURE over (board, power, generator).
///
/// The model is a plinko cascade with carried drift: at each row the ball is pushed off whichever
/// pin it is nearest, and it keeps a fraction of that push into the next row. The drift is what
/// makes the launch power matter - without it the field is a Galton board and every launch has the
/// same distribution, which would make the plunger decoration.
/// @return {struct} {cup, path}  path is a flat [u,v,...] in board space
function pas_bagatelle_drop(_board, _power, _r) {
    var _span = 1 - _board.wall * 2;
    var _u = 1 - _board.wall - 0.030;                // enters from the return arch, top right
    var _v = _board.top - 0.045;
    var _drift = -(0.10 + _power * 0.55);            // power throws it further across the table
    var _path = [ _u, _v ];

    for (var _row = 0; _row < _board.rows; _row++) {
        // the nearest pin in this row decides which way the ball goes
        var _bi = -1, _bd = 99, _bv = _v;
        for (var i = 0; i < array_length(_board.pins); i++) {
            var _p = _board.pins[i];
            if (_p.row != _row) continue;
            var _d = abs(_p.u - (_u + _drift * 0.35));
            if (_d < _bd) { _bd = _d; _bi = i; _bv = _p.v; }
        }
        if (_bi < 0) continue;
        var _pin = _board.pins[_bi];
        var _side = ((_u + _drift * 0.35) < _pin.u) ? -1 : 1;
        var _kick = (_span / 12) * (0.55 + pas_rng_float(_r) * 0.75);
        _drift = _drift * 0.62 + _side * _kick;
        // ⛔ THE BALL KEEPS ITS OWN POSITION. The first version wrote `_u = _pin.u + side * kick`,
        // which SNAPS to whichever pin it just struck and throws away where the ball actually was -
        // so the launch power decided the first row and was forgotten by the second, and the
        // plunger became decoration on a Galton board. MEASURED on the store sheet: four of seven
        // cups priced identically at 45, because almost every sample ball landed in the same two.
        //
        // ⭐ This file's own header says the drift is what makes the plunger matter. A constraint
        // that lives only in prose is enforced by whoever last read the prose - the arithmetic has
        // to carry it. The pin deflects the ball; it does not teleport it.
        _u = clamp(_u * 0.45 + _pin.u * 0.55 + _side * _kick + _drift * 0.22,
                   _board.wall + 0.012, 1 - _board.wall - 0.012);
        _v = _bv;
        array_push(_path, _u, _v);
    }

    array_push(_path, _u, _board.bot + 0.060);
    var _cup = clamp(floor(((_u - _board.wall) / _span) * _board.cupn), 0, _board.cupn - 1);
    return { cup : _cup, path : _path };
}

/// @desc Launch a ball, or set the plunger power. input {act:"press",u,v} sets power from v.
/// @return {string} "power" | "landed" | "over"
function pas_bagatelle_step(_board, _input) {
    if (_board.over) return "over";
    var _v = pas_input_v(_input);
    var _k = pas_input_key(_input);
    if (_v >= 0 && _k != "launch") {
        _board.power = clamp(1 - _v, 0.05, 1);
        return "power";
    }

    var _d = pas_bagatelle_drop(_board, _board.power, _board.rng);
    _board.trail = _d.path;
    _board.ball = _d.cup;
    _board.cuphits[_d.cup] += 1;
    _board.score += _board.cupval[_d.cup];
    _board.left -= 1;
    if (_board.left <= 0) _board.over = true;
    return "landed";
}

function pas_bagatelle_label(_board) {
    var _lat = [ "triangular", "square", "staggered" ];
    return "BAGATELLE  " + string(array_length(_board.pins)) + " pins"
         + "   " + _lat[_board.lattice] + " field"
         + "   " + string(_board.cupn) + " cups   score " + string(_board.score);
}

function pas_bagatelle_aspect(_board) { return 0.70; }

/// @desc Draw the table.
function pas_bagatelle_draw(_board, _x, _y, _w, _h, _pal) {
    var _f = pas_map(_x, _y, _w, _h);
    var _span = 1 - _board.wall * 2;

    // -- the board, and its grain -----------------------------------------
    pas_rrect(_f, 0, 0, 1, 1, pas_detail(_f, 0.020, 3, 18), _pal.m2);
    // Grain is TONE: many fine strokes at a real pixel pitch, never one wide line (pas_geom law 4).
    // The waver is what stops it reading as ruled paper.
    var _pitch = pas_detail(_f, 0.014, 5, 13) / max(1, _f.w);
    var _cols = max(2, floor(1 / _pitch));
    for (var i = 0; i < _cols; i++) {
        var _u0 = i * _pitch;
        var _pts = [];
        for (var k = 0; k <= 8; k++) {
            var _t = k / 8;
            array_push(_pts, _u0 + sin(_t * 6.1 + i * 1.7 + _board.grain) * 0.006, _t);
        }
        pas_stroke(_f, _pts, 1, (i & 1) ? merge_colour(_pal.m2, _pal.m1, 0.55)
                                        : merge_colour(_pal.m2, _pal.m3, 0.40));
    }

    // -- side rails and the return arch -----------------------------------
    var _wall = _board.wall;
    pas_rrect(_f, 0, 0, _wall, 1, pas_detail(_f, 0.010, 2, 9), _pal.w2);
    pas_rrect(_f, 1 - _wall, 0, _wall, 1, pas_detail(_f, 0.010, 2, 9), _pal.w1);
    pas_rrect(_f, 0, 0, 1, _wall * 0.55, pas_detail(_f, 0.010, 2, 9), _pal.w4);

    // The arch is the lane the ball is fired up. Drawn as a real curve with a wall on each side,
    // because a single line reads as a scratch on the board.
    var _arc = [];
    for (var k = 0; k <= 26; k++) {
        var _t = k / 26;
        var _a = degtorad(180 * _t);
        _arc[k * 2]     = 1 - _wall - 0.030 - (1 - cos(_a)) * 0.055;
        _arc[k * 2 + 1] = _board.top - 0.045 + (1 - _t) * (0.94 - _board.top);
    }
    pas_stroke(_f, _arc, pas_detail(_f, 0.012, 2, 11), _pal.w4);
    pas_stroke(_f, _arc, pas_detail(_f, 0.006, 1, 6), _pal.m2);

    // -- cups --------------------------------------------------------------
    var _cw = _span / _board.cupn;
    for (var i = 0; i < _board.cupn; i++) {
        var _u0 = _wall + i * _cw;
        var _hot = (_board.ball == i);
        pas_rrect(_f, _u0 + _cw * 0.06, _board.bot + 0.030, _cw * 0.88, 0.150,
                  pas_detail(_f, 0.008, 1, 7), _hot ? _pal.p1 : _pal.m0);
        // a real cup has a lip: the mouth is lighter than the well behind it
        pas_rrect(_f, _u0 + _cw * 0.06, _board.bot + 0.030, _cw * 0.88, 0.024,
                  pas_detail(_f, 0.005, 1, 5), _pal.m3);
        pas_text_fit(_f, string(_board.cupval[i]), _u0 + _cw * 0.5, _board.bot + 0.108,
                     _cw * 0.72, _hot ? _pal.b4 : _pal.ink, fa_center, fa_middle);
        // turned divider posts between the cups
        if (i > 0) {
            pas_line(_f, _u0, _board.bot + 0.020, _u0, _board.bot + 0.185,
                     pas_detail(_f, 0.009, 2, 8), _pal.w4);
            pas_disc(_f, _u0, _board.bot + 0.020, pas_detail(_f, 0.010, 2, 9) / max(1, _f.s),
                     _pal.b3);
        }
    }

    // -- the trail, drawn UNDER the pins ----------------------------------
    // Under, not over: a ball travels between the pins, and a route drawn over them would read as
    // a line ruled across the table.
    if (array_length(_board.trail) >= 4) {
        pas_stroke(_f, _board.trail, pas_detail(_f, 0.006, 1, 6),
                   merge_colour(_pal.m2, _pal.q3, 0.55));
    }

    // -- pins --------------------------------------------------------------
    // Three marks each: a cast shadow on the board, the brass shank, and a lit crown. One flat disc
    // reads as a hole rather than as something standing up out of the wood.
    var _pr = pas_detail(_f, 0.014, 2, 13) / max(1, _f.s);
    for (var i = 0; i < array_length(_board.pins); i++) {
        var _p = _board.pins[i];
        pas_disc(_f, _p.u + _pr * 0.35, _p.v + _pr * 0.45, _pr, _pal.m0);
        pas_disc(_f, _p.u, _p.v, _pr, _pal.b2);
        pas_disc(_f, _p.u - _pr * 0.22, _p.v - _pr * 0.26, _pr * 0.52, _pal.b4);
    }

    // -- the ball, resting in its cup --------------------------------------
    if (_board.ball >= 0) {
        var _bu = _wall + (_board.ball + 0.5) * _cw;
        var _bv = _board.bot + 0.088;
        var _br = _pr * 1.5;
        pas_disc(_f, _bu, _bv + _br * 0.3, _br, _pal.m0);
        pas_disc(_f, _bu, _bv, _br, _pal.b3);
        pas_disc(_f, _bu - _br * 0.3, _bv - _br * 0.32, _br * 0.42, _pal.b4);
    }

    // -- the plunger -------------------------------------------------------
    // A spring is drawn as a COUNT of coils, not as a thick line - and the count moves with the
    // power, so the control reads at a glance without a number beside it.
    var _pu = 1 - _wall * 0.5;
    var _p0 = 0.955, _p1 = 0.955 - 0.16 * _board.power;
    var _coils = 5 + round(_board.power * 5);
    var _spring = [];
    for (var k = 0; k <= _coils * 4; k++) {
        var _t = k / (_coils * 4);
        array_push(_spring, _pu + sin(_t * _coils * 6.283) * _wall * 0.30,
                            _p0 - (_p0 - _p1) * _t);
    }
    pas_stroke(_f, _spring, pas_detail(_f, 0.006, 1, 6), _pal.b2);
    pas_disc(_f, _pu, _p1, _wall * 0.34, _pal.b4);
}
