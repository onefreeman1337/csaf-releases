/// PASTIME - pas_tangram. Room 8 of the cabinet.
///
/// Visual language: paper-cut. Flat shapes, hard edges, a hairline of shadow under each piece and a
/// dark silhouette showing what is still missing.
///
/// ⭐ WHAT IS GENERATED, AND WHY IT IS NOT A TANGRAM SET WITH A NEW PICTURE ON IT. The seven
/// tangram pieces are fixed, so a "generated" tangram can only ever generate FIGURES - and searching
/// for figures a fixed piece set actually tiles is a hard problem whose failure mode is a puzzle with
/// no solution. This room inverts it: it generates a SILHOUETTE and then DISSECTS it. Every board is
/// therefore solvable by construction, because the dissection IS the solution, and every board has
/// its own piece set rather than the same seven shapes rearranged.
///
/// ⛔ CONVEXITY IS DOING REAL WORK HERE AND IS NOT AN AESTHETIC CHOICE. A chord between two points
/// on the boundary of a CONVEX polygon is guaranteed to lie inside it, so every cut is valid and
/// every piece produced is itself convex. That in turn is what makes pas_poly safe on all of them -
/// pr_trianglefan spans a concavity silently, with no error and no failed assertion, and Welkin
/// shipped every moon crescent as a quarter for exactly that reason. Generating a concave outline
/// here would need a clipper AND a fill that is not a fan; this generates the outline by an AFFINE
/// map of a regular polygon, which cannot produce a concave result no matter what the seed is.
///
/// pas_selftest asserts the two properties that carry that argument: every piece is convex, and the
/// piece areas sum to the outline's area. The second is what catches a cut that lost a sliver -
/// convexity alone would be happy with a dissection that dropped one.
/// ================================================================================================

/// @desc Build a dissection puzzle.
/// @param {real} seed
/// @param {struct} opts  optional: {pieces, sides}
function pas_tangram_board(seed, opts = {}) {
    var _r = pas_rng(seed);

    var _np = (is_struct(opts) && variable_struct_exists(opts, "pieces"))
        ? opts.pieces : pas_rng_int(_r, 5, 9);
    if (_np < 2) _np = 2;
    var _sides = (is_struct(opts) && variable_struct_exists(opts, "sides"))
        ? opts.sides : pas_rng_pick(_r, [ 3, 4, 4, 5, 6, 8 ]);
    if (_sides < 3) _sides = 3;

    var board = {
        room    : "tangram",
        seed    : seed,
        sides   : _sides,
        outline : [],
        pieces  : [],
        placed  : 0,
        moves   : 0,
        solved  : false,
        trayw   : 0.235,
        rng     : _r,
    };

    board.outline = pas_tangram_outline(_sides, _r, board.trayw);

    // ---- dissect: always cut the LARGEST remaining piece ------------------
    // Largest-first is what keeps the pieces comparable in size. Cutting a random piece produces
    // one enormous slab and a scatter of slivers, which is a worse puzzle and a worse picture.
    var _polys = [ board.outline ];
    while (array_length(_polys) < _np) {
        var _bi = 0, _ba = -1;
        for (var i = 0; i < array_length(_polys); i++) {
            var _a = pas_tangram_area(_polys[i]);
            if (_a > _ba) { _ba = _a; _bi = i; }
        }
        var _two = pas_tangram_split(_polys[_bi], _r);
        if (array_length(_two) < 2) break;          // could not cut; stop rather than spin
        _polys[_bi] = _two[0];
        array_push(_polys, _two[1]);
    }

    for (var i = 0; i < array_length(_polys); i++) {
        array_push(board.pieces, {
            pts    : _polys[i],
            area   : pas_tangram_area(_polys[i]),
            tint   : i,
            placed : false,
        });
    }
    return board;
}

/// @desc A convex outline: a regular polygon under an affine map.
///
/// Affine maps preserve convexity, so no seed can produce a concave outline - which is the
/// precondition the whole room rests on. A radius-jittered polygon would NOT be safe: sampling
/// radii around a circle can produce a reflex vertex, and it would do so rarely enough to reach a
/// buyer rather than a test.
function pas_tangram_outline(_sides, _r, _trayw) {
    var _rot = pas_rng_float(_r) * 360;
    var _sx = 0.80 + pas_rng_float(_r) * 0.45;
    var _sy = 0.80 + pas_rng_float(_r) * 0.45;
    var _sh = (pas_rng_float(_r) - 0.5) * 0.55;         // shear
    var _raw = array_create(_sides * 2);
    for (var i = 0; i < _sides; i++) {
        var _a = degtorad(_rot + i * (360 / _sides));
        var _x = cos(_a) * _sx;
        var _y = sin(_a) * _sy;
        _raw[i * 2]     = _x + _y * _sh;
        _raw[i * 2 + 1] = _y;
    }
    // Fit into the playing area, left of the tray, with a margin. Uniform scale about the centre
    // of the fitted box, so the shape is never distorted a second time.
    var _minx = 1000000000, _maxx = -1000000000, _miny = 1000000000, _maxy = -1000000000;
    for (var i = 0; i < _sides; i++) {
        _minx = min(_minx, _raw[i * 2]);   _maxx = max(_maxx, _raw[i * 2]);
        _miny = min(_miny, _raw[i * 2 + 1]); _maxy = max(_maxy, _raw[i * 2 + 1]);
    }
    var _availw = 1 - _trayw - 0.16, _availh = 0.78;
    var _k = min(_availw / max(0.0001, _maxx - _minx), _availh / max(0.0001, _maxy - _miny));
    var _cx = (_minx + _maxx) * 0.5, _cy = (_miny + _maxy) * 0.5;
    var _tx = (1 - _trayw) * 0.5, _ty = 0.52;
    var _out = array_create(_sides * 2);
    for (var i = 0; i < _sides; i++) {
        _out[i * 2]     = _tx + (_raw[i * 2] - _cx) * _k;
        _out[i * 2 + 1] = _ty + (_raw[i * 2 + 1] - _cy) * _k;
    }
    return _out;
}

/// @desc Shoelace area, always positive. PURE.
function pas_tangram_area(_p) {
    var _n = array_length(_p) div 2;
    if (_n < 3) return 0;
    var _a = 0;
    for (var i = 0; i < _n; i++) {
        var _j = (i + 1) mod _n;
        _a += _p[i * 2] * _p[_j * 2 + 1] - _p[_j * 2] * _p[i * 2 + 1];
    }
    return abs(_a) * 0.5;
}

/// @desc Is this polygon convex? Every cross product must share a sign.
///
/// The suite runs it on every piece of every board. A dissection that produced a concave piece
/// would draw wrongly through pas_poly and nothing else in the pipeline could see it.
function pas_tangram_convex(_p) {
    var _n = array_length(_p) div 2;
    if (_n < 3) return false;
    var _sign = 0;
    for (var i = 0; i < _n; i++) {
        var _j = (i + 1) mod _n, _k = (i + 2) mod _n;
        var _ax = _p[_j * 2] - _p[i * 2],     _ay = _p[_j * 2 + 1] - _p[i * 2 + 1];
        var _bx = _p[_k * 2] - _p[_j * 2],    _by = _p[_k * 2 + 1] - _p[_j * 2 + 1];
        var _cr = _ax * _by - _ay * _bx;
        // 0.000001 would be UNDER GML's comparison epsilon and could never fire; a near-straight
        // vertex is genuinely fine here, so it is skipped rather than judged.
        if (abs(_cr) < 0.0001) continue;
        var _s = (_cr > 0) ? 1 : -1;
        if (_sign == 0) _sign = _s;
        else if (_s != _sign) return false;
    }
    return true;
}

/// @desc Cut a convex polygon in two with a chord between two non-adjacent edges.
/// @return {array} [polyA, polyB], or [] if no legal cut exists
function pas_tangram_split(_p, _r) {
    var _n = array_length(_p) div 2;
    if (_n < 3) return [];

    // Prefer a cut between the two LONGEST edges: it is the cut that produces two pieces of
    // similar size and neither of them a splinter.
    var _bi = 0, _bj = 1, _bl = -1;
    for (var i = 0; i < _n; i++) {
        for (var j = i + 1; j < _n; j++) {
            if (_n > 3 && (j == i + 1 || (i == 0 && j == _n - 1))) {
                // adjacent edges on a polygon with room to do better: skip, they give a corner chip
                if (_n > 4) continue;
            }
            var _li = pas_tangram_edge_len(_p, i) ;
            var _lj = pas_tangram_edge_len(_p, j);
            var _v = min(_li, _lj) + pas_rng_float(_r) * 0.02;   // seeded tie-break
            if (_v > _bl) { _bl = _v; _bi = i; _bj = j; }
        }
    }

    var _t0 = 0.28 + pas_rng_float(_r) * 0.44;
    var _t1 = 0.28 + pas_rng_float(_r) * 0.44;
    var _A = pas_tangram_on_edge(_p, _bi, _t0);
    var _B = pas_tangram_on_edge(_p, _bj, _t1);

    var _a = [ _A[0], _A[1] ];
    for (var k = _bi + 1; k <= _bj; k++) array_push(_a, _p[k * 2], _p[k * 2 + 1]);
    array_push(_a, _B[0], _B[1]);

    var _b = [ _B[0], _B[1] ];
    for (var k = _bj + 1; k < _n; k++) array_push(_b, _p[k * 2], _p[k * 2 + 1]);
    for (var k = 0; k <= _bi; k++) array_push(_b, _p[k * 2], _p[k * 2 + 1]);
    array_push(_b, _A[0], _A[1]);

    // A cut that produced a degenerate sliver is not a cut. Refusing it keeps the invariant the
    // suite asserts - that the piece areas sum to the whole - instead of silently losing a wedge.
    if (pas_tangram_area(_a) < 0.0002 || pas_tangram_area(_b) < 0.0002) return [];
    return [ _a, _b ];
}

function pas_tangram_edge_len(_p, _i) {
    var _n = array_length(_p) div 2;
    var _j = (_i + 1) mod _n;
    var _dx = _p[_j * 2] - _p[_i * 2], _dy = _p[_j * 2 + 1] - _p[_i * 2 + 1];
    return sqrt(_dx * _dx + _dy * _dy);
}

function pas_tangram_on_edge(_p, _i, _t) {
    var _n = array_length(_p) div 2;
    var _j = (_i + 1) mod _n;
    return [ _p[_i * 2] + (_p[_j * 2] - _p[_i * 2]) * _t,
             _p[_i * 2 + 1] + (_p[_j * 2 + 1] - _p[_i * 2 + 1]) * _t ];
}

/// @desc The centroid of a piece, used for the tray layout and the hit test.
function pas_tangram_centroid(_p) {
    var _n = array_length(_p) div 2;
    var _sx = 0, _sy = 0;
    for (var i = 0; i < _n; i++) { _sx += _p[i * 2]; _sy += _p[i * 2 + 1]; }
    return [ _sx / _n, _sy / _n ];
}

/// @desc Place a piece. input {act:"press",u,v} places the nearest unplaced one; anything else
///       places the first unplaced one, so a headless suite can drive the room to completion.
/// @return {string} "placed" | "solved" | "nothing"
function pas_tangram_step(_board, _input) {
    if (_board.solved) return "solved";
    var _u = pas_input_u(_input), _v = pas_input_v(_input);

    var _bi = -1;
    if (_u >= 0 && _v >= 0) {
        var _bd = 999;
        for (var i = 0; i < array_length(_board.pieces); i++) {
            if (_board.pieces[i].placed) continue;
            var _c = pas_tangram_centroid(_board.pieces[i].pts);
            var _d = (_c[0] - _u) * (_c[0] - _u) + (_c[1] - _v) * (_c[1] - _v);
            if (_d < _bd) { _bd = _d; _bi = i; }
        }
    } else {
        for (var i = 0; i < array_length(_board.pieces); i++) {
            if (!_board.pieces[i].placed) { _bi = i; break; }
        }
    }
    if (_bi < 0) return "nothing";

    _board.pieces[_bi].placed = true;
    _board.placed += 1;
    _board.moves += 1;
    if (_board.placed >= array_length(_board.pieces)) { _board.solved = true; return "solved"; }
    return "placed";
}

function pas_tangram_label(_board) {
    return "TANGRAM  " + string(_board.sides) + "-sided figure"
         + "   " + string(array_length(_board.pieces)) + " pieces"
         + "   " + string(_board.placed) + " placed";
}

function pas_tangram_aspect(_board) { return 1.30; }

/// @desc Draw the puzzle.
function pas_tangram_draw(_board, _x, _y, _w, _h, _pal) {
    var _f = pas_map(_x, _y, _w, _h);
    var _np = array_length(_board.pieces);

    // -- paper ground ------------------------------------------------------
    pas_rrect(_f, 0, 0, 1, 1, pas_detail(_f, 0.014, 2, 14), _pal.m3);

    // -- the silhouette ----------------------------------------------------
    // The WHOLE figure in shadow, with the placed pieces laid over it. That is what makes the
    // remaining gap read as a shape to fill rather than as a set of leftover pieces - and it is
    // exact rather than a union computation, because the pieces tile the outline by construction.
    var _sh = pas_detail(_f, 0.010, 2, 9);
    var _shad = array_create(array_length(_board.outline));
    for (var i = 0; i < array_length(_board.outline); i += 2) {
        _shad[i]     = _board.outline[i] + _sh / max(1, _f.w);
        _shad[i + 1] = _board.outline[i + 1] + _sh / max(1, _f.h);
    }
    // ⛔ m0, NOT m1. The silhouette is the thing the player is trying to fill, so it has to read
    // against the paper at EVERY theme - and m1 is one stop from m3, which on the greener and
    // paler themes made the figure very nearly invisible on the forty-board sheet. The ramp
    // describes how a surface turns in the light; two adjacent stops are the same surface.
    pas_poly(_f, _shad, merge_colour(_pal.m3, _pal.m0, 0.55));
    pas_poly(_f, _board.outline, _pal.m0);

    // -- placed pieces -----------------------------------------------------
    for (var i = 0; i < _np; i++) {
        var _pc = _board.pieces[i];
        if (!_pc.placed) continue;
        var _t = i / max(1, _np - 1);
        // Each piece takes its tint from the two accents, so a set reads as one sheet of cut paper
        // in a range of tones rather than as a bag of colours.
        var _col = merge_colour(_pal.p3, _pal.q3, _t);
        var _lift = pas_detail(_f, 0.005, 1, 5);
        var _drop = array_create(array_length(_pc.pts));
        for (var k = 0; k < array_length(_pc.pts); k += 2) {
            _drop[k]     = _pc.pts[k] + _lift / max(1, _f.w);
            _drop[k + 1] = _pc.pts[k + 1] + _lift / max(1, _f.h);
        }
        pas_poly(_f, _drop, merge_colour(_col, _pal.m0, 0.62));
        pas_poly(_f, _pc.pts, _col);
        // a hard cut edge, which is what makes it read as PAPER rather than as a fill
        var _edge = array_create(array_length(_pc.pts) + 2);
        for (var k = 0; k < array_length(_pc.pts); k++) _edge[k] = _pc.pts[k];
        _edge[array_length(_pc.pts)]     = _pc.pts[0];
        _edge[array_length(_pc.pts) + 1] = _pc.pts[1];
        pas_stroke(_f, _edge, pas_detail(_f, 0.003, 1, 3), merge_colour(_col, _pal.m4, 0.45));
    }

    // -- the tray ----------------------------------------------------------
    // ⛔ THE TRAY IS CUT TO WHAT IS IN IT. A fixed full-height well holding one remaining piece is
    // a large empty panel taking a fifth of the picture, which is what the forty-board sheet showed
    // on three of its five tangrams. The well is sized from the piece count, with a floor so a
    // nearly-finished puzzle still has somewhere to have kept them.
    var _un = 0;
    for (var i = 0; i < _np; i++) if (!_board.pieces[i].placed) _un += 1;
    var _tu = 1 - _board.trayw;
    var _slotH = 0.92 / max(3, _np);
    var _trayH = clamp(_slotH * max(1, _un) + 0.05, 0.16, 0.92);
    var _trayV = 0.5 - _trayH * 0.5;
    pas_well(_f, _tu, _trayV, _board.trayw - 0.035, _trayH,
             pas_detail(_f, 0.012, 2, 11), _pal.m2, _pal.m4, _pal.m0);

    var _slot = 0;
    for (var i = 0; i < _np; i++) {
        var _pc = _board.pieces[i];
        if (_pc.placed) continue;
        var _rows = max(1, _un);
        var _cv = _trayV + _trayH * ((_slot + 0.5) / _rows);
        var _cu = _tu + (_board.trayw - 0.035) * 0.5;
        // Fit the piece into its slot: measure it, then scale. Solving for width AND height would
        // be a non-uniform fit, and a non-uniformly scaled piece is a DIFFERENT piece - which on a
        // dissection puzzle is a lie about what the player has to work with.
        var _minx = 1000000000, _maxx = -1000000000, _miny = 1000000000, _maxy = -1000000000;
        for (var k = 0; k < array_length(_pc.pts); k += 2) {
            _minx = min(_minx, _pc.pts[k]);     _maxx = max(_maxx, _pc.pts[k]);
            _miny = min(_miny, _pc.pts[k + 1]); _maxy = max(_maxy, _pc.pts[k + 1]);
        }
        var _sw = (_board.trayw - 0.10), _shh = (_trayH / _rows) * 0.72;
        var _k2 = min(_sw / max(0.0001, _maxx - _minx), _shh / max(0.0001, _maxy - _miny));
        var _ox = (_minx + _maxx) * 0.5, _oy = (_miny + _maxy) * 0.5;
        var _tp = array_create(array_length(_pc.pts));
        for (var k = 0; k < array_length(_pc.pts); k += 2) {
            _tp[k]     = _cu + (_pc.pts[k] - _ox) * _k2;
            _tp[k + 1] = _cv + (_pc.pts[k + 1] - _oy) * _k2;
        }
        var _t = i / max(1, _np - 1);
        var _col = merge_colour(_pal.p3, _pal.q3, _t);
        pas_poly(_f, _tp, merge_colour(_col, _pal.m2, 0.42));
        _slot += 1;
    }
}
