{
  "$GMScript": "v1",
  "%Name": "pas_tangram",
  "name": "pas_tangram",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}