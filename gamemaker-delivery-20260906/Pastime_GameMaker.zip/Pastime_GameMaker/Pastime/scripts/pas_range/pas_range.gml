/// PASTIME - pas_range. Room 5 of the cabinet.
///
/// Visual language: flat graphic, printed-target palette. A shooting gallery in ELEVATION - lanes
/// receding to a vanishing point, targets standing at their own distances, distance posts down one
/// side and a papered back wall with bunting.
///
/// ⭐ WHAT IS GENERATED: the TARGET FACES and the RANGE ITSELF. A face is a generated ring
/// progression - how many rings, how their radii grow, the scoring values, and whether the face is a
/// plain bull or a lobed silhouette plate. Then the range generates its own lane count and puts each
/// target at its own distance, so a board is a composition rather than a row.
///
/// ⛔ PERSPECTIVE IS WHY THIS ROOM EXISTS AND IT IS ALSO ITS ONE REAL HAZARD. Everything here is
/// sized from ONE function, pas_range_scale, so a target's size, its stand, its shadow and the lane
/// it stands in cannot disagree. This wing's standing law is that a defect living in where one mass
/// sits RELATIVE TO ANOTHER is invisible to every outline test there is - Chitin built every animal
/// upside down under 1,482 green assertions - and a perspective view is nothing but relative
/// placement.
///
/// ⚠️ AND A DISTANT TARGET IS NOT A SMALL TARGET. Its rings compress toward each other as well as
/// getting smaller, so a face that reads at the near lane can be six grey circles at the far one.
/// pas_range_rings drops ring COUNT with distance rather than drawing rings a buyer cannot see -
/// which is the level-of-detail rule this wing wrote after Chitin's vein count was measured never
/// to have changed its answer once in the product's life.
/// ================================================================================================

/// @desc Build a range.
/// @param {real} seed
/// @param {struct} opts  optional: {lanes}
function pas_range_board(seed, opts = {}) {
    var _r = pas_rng(seed);

    var _n = (is_struct(opts) && variable_struct_exists(opts, "lanes"))
        ? opts.lanes : pas_rng_int(_r, 3, 6);
    if (_n < 2) _n = 2;
    if (_n > 8) _n = 8;

    var board = {
        room    : "range",
        seed    : seed,
        lanes   : _n,
        horizon : 0.30 + pas_rng_float(_r) * 0.06,
        bunting : pas_rng_int(_r, 0, 2),
        posts   : pas_rng_pick(_r, [ 3, 4, 5 ]),
        targets : [],
        shots   : [],
        score   : 0,
        left    : 6,
        over    : false,
        rng     : _r,
    };

    for (var i = 0; i < _n; i++) {
        var _rings = pas_rng_int(_r, 3, 6);
        var _vals = array_create(_rings);
        var _radii = array_create(_rings);
        // The ring progression. `grow` above 1 pushes the rings outward so the bull is a small
        // island in a wide field; below 1 packs them, which is a harder, meaner face.
        var _grow = 0.72 + pas_rng_float(_r) * 0.70;
        var _acc = 0;
        for (var k = 0; k < _rings; k++) {
            _acc += power(k + 1, _grow);
            _radii[k] = _acc;
            _vals[k] = (_rings - k) * 10;
        }
        for (var k = 0; k < _rings; k++) _radii[k] = _radii[k] / _acc;   // normalise to 1

        array_push(board.targets, {
            lane  : i,
            dist  : 0.15 + pas_rng_float(_r) * 0.80,
            rings : _rings,
            radii : _radii,
            vals  : _vals,
            lobes : pas_rng_pick(_r, [ 0, 0, 5, 6, 8 ]),   // 0 = a plain round face
            spin  : pas_rng_float(_r) * 360,
            down  : false,
        });
    }
    return board;
}

/// @desc How big something at distance d is on screen. ONE function, every consumer.
///
/// A simple pinhole: apparent size falls as 1/(1 + k*d). Not a linear ramp, because a linear ramp
/// makes the far half of the range look like a flat wall of small objects instead of a receding one.
function pas_range_scale(_d) {
    return 1 / (1 + 2.25 * clamp(_d, 0, 1));
}

/// How far the outermost lane may sit from the centre line at the FRONT of the range.
///
/// ⛔⛔ THIS READ 1.72 AND THE ROOM DREW OUTSIDE ITS OWN RECT. MEASURED 2026-09-03 by baking the
/// eight-room sheet and LOOKING AT IT: the near lane guides ran off the board, out of the cabinet,
/// and across the page - two white diagonals crossing other rooms' cabinets. A lane spread of 1.72
/// puts the outermost guide at u = -0.36, and `pas_line` draws exactly where it is told.
///
/// ⭐ 684 IN-ENGINE ASSERTIONS WERE GREEN OVER IT. Every number the generator produced was correct;
/// what was wrong was WHERE one mass sat relative to another, which no outline test models. This
/// wing's standing law, and the fourth time it has been paid for.
///
/// ⇒ 0.94 keeps the outermost lane inside the board at every distance, because the spread term is
/// bounded by 0.5 and the perspective factor by 1: |u - 0.5| <= 0.47. And the CONTRACT is now
/// asserted - pas_selftest sweeps every target of every generated range and requires its foot
/// inside the unit square, which is a test a picture bug can actually fail.
#macro PAS_RG_SPREAD 0.94

/// @desc THE ONE LATERAL PLACEMENT FUNCTION. Everything this room puts left or right goes through it.
///
/// ⛔⛔ IT IS ONE FUNCTION BECAUSE THE SAME BUG HAPPENED THREE TIMES IN THIS ROOM. First the lane
/// guides at a 1.72 spread ran off the board and across the page. That was fixed. Then the DISTANCE
/// POSTS, which carried their own inline `0.5 + side * 0.86 * k`, were found doing the same thing on
/// the next bake - a caption reading "30yd" cut in half by the right edge - because 0.86 there is a
/// FULL offset while 0.94 in the lane term is multiplied by a spread of at most 0.5.
///
/// ⭐ THE LESSON IS NOT "CHECK THE NUMBER", IT IS THAT TWO CALL SITES COMPUTING THE SAME THING IN
/// DIFFERENT UNITS WILL DISAGREE EVENTUALLY. Fixing the instances leaves the next call site to
/// rediscover it; giving the room a single lateral function means a new feature cannot get it wrong
/// without deleting this line, and the suite asserts THIS rather than each caller.
///
/// @param {real} _t  lateral position, -1 at the left rail to +1 at the right rail
/// @param {real} _k  the perspective factor at this distance, 0..1
function pas_range_lat(_t, _k) {
    return 0.5 + clamp(_t, -1, 1) * 0.47 * clamp(_k, 0, 1);
}

/// @desc Where the FOOT of a target in lane l at distance d stands, in board space.
function pas_range_foot(_board, _lane, _d) {
    var _k = pas_range_scale(_d);
    // The floor runs from the horizon to the bottom of the board, and a foot's height above the
    // bottom is proportional to its apparent size - which is what makes standing objects sit on
    // the same floor plane instead of floating.
    var _v = 1 - (1 - _board.horizon) * (1 - _k) - 0.06;
    // Lanes converge on the vanishing point at the centre of the horizon.
    var _spread = (_board.lanes > 1) ? (((_lane + 0.5) / _board.lanes - 0.5) * 2) : 0;
    return [ pas_range_lat(_spread, _k), _v, _k ];
}

/// @desc Where a lane GUIDE meets the front of the range, in board space.
///
/// A guide is a divider BETWEEN lanes, so there are lanes+1 of them and their lateral term runs the
/// full -1..1 - which is exactly why they escaped first and by the largest margin.
function pas_range_guide_u(_board, _i) {
    return pas_range_lat((_i / max(1, _board.lanes) - 0.5) * 2, 1);
}

/// @desc How many rings of a face are worth drawing at this apparent size.
///
/// LEVEL OF DETAIL, and it is written so that it CAN change its answer - a rule that saturates is
/// silent, and this wing shipped one that had never executed in the product's life.
function pas_range_rings(_target, _px) {
    var _n = _target.rings;
    // A ring needs about 4 px of its own to read. Below that it is grey mush and costs fill rate.
    var _fit = max(1, floor(_px / 8));
    return min(_n, _fit);
}

/// @desc Shoot. input {act:"press",u,v}, or anything else for a seeded shot at the best target.
/// @return {string} "hit" | "miss" | "down" | "over"
function pas_range_step(_board, _input) {
    if (_board.over) return "over";

    var _u = pas_input_u(_input), _v = pas_input_v(_input);
    if (_u < 0 || _v < 0) {
        // "auto": aim at the nearest target still standing - the shot a player would take.
        var _bi = -1, _bd = 99;
        for (var i = 0; i < array_length(_board.targets); i++) {
            if (_board.targets[i].down) continue;
            if (_board.targets[i].dist < _bd) { _bd = _board.targets[i].dist; _bi = i; }
        }
        if (_bi < 0) { _board.over = true; return "over"; }
        var _p = pas_range_foot(_board, _board.targets[_bi].lane, _board.targets[_bi].dist);
        var _fr = 0.185 * _p[2];
        _u = _p[0] + (pas_rng_float(_board.rng) - 0.5) * _fr * 1.6;
        _v = _p[1] - _fr * 1.05 + (pas_rng_float(_board.rng) - 0.5) * _fr * 1.6;
    }

    _board.left -= 1;
    if (_board.left <= 0) _board.over = true;

    var _got = 0, _hit = -1;
    for (var i = 0; i < array_length(_board.targets); i++) {
        var _t = _board.targets[i];
        if (_t.down) continue;
        var _p = pas_range_foot(_board, _t.lane, _t.dist);
        var _fr = 0.185 * _p[2];
        var _cu = _p[0], _cv = _p[1] - _fr * 1.05;
        var _dd = sqrt((_u - _cu) * (_u - _cu) + (_v - _cv) * (_v - _cv)) / max(0.0001, _fr);
        if (_dd > 1) continue;
        for (var k = 0; k < _t.rings; k++) {
            if (_dd <= _t.radii[k]) { _got = _t.vals[k]; _hit = i; break; }
        }
        break;
    }

    array_push(_board.shots, { u : _u, v : _v, score : _got });
    _board.score += _got;
    if (_hit >= 0 && _got >= _board.targets[_hit].vals[0]) {
        _board.targets[_hit].down = true;                 // a bull knocks the plate flat
        return "down";
    }
    return (_got > 0) ? "hit" : "miss";
}

function pas_range_label(_board) {
    return "RANGE  " + string(_board.lanes) + " lanes"
         + "   " + string(array_length(_board.targets)) + " faces"
         + "   score " + string(_board.score) + "   " + string(_board.left) + " shots";
}

function pas_range_aspect(_board) { return 1.55; }

/// @desc Draw the range.
function pas_range_draw(_board, _x, _y, _w, _h, _pal) {
    var _f = pas_map(_x, _y, _w, _h);
    var _hz = _board.horizon;

    // -- back wall and floor ----------------------------------------------
    pas_rrect(_f, 0, 0, 1, 1, pas_detail(_f, 0.012, 2, 12), _pal.m3);
    pas_poly(_f, [ 0, _hz, 1, _hz, 1, 1, 0, 1 ], _pal.m1);
    pas_line(_f, 0, _hz, 1, _hz, pas_detail(_f, 0.005, 1, 5), _pal.m0);

    // -- lane guides, converging on the vanishing point --------------------
    // Drawn as strokes to the vanishing point rather than as trapezoids: a rail is a line on a
    // floor, and filling between the rails would paint over the floor's own tone.
    // ⛔ The end point comes from pas_range_guide_u, which the suite asserts. See its header: the
    // first version inlined a 1.72 spread here and drew two white diagonals out of the cabinet and
    // across the page, under a fully green suite.
    for (var i = 0; i <= _board.lanes; i++) {
        pas_line(_f, pas_range_guide_u(_board, i), 1, 0.5, _hz,
                 pas_detail(_f, 0.004, 1, 4), _pal.guide);
    }

    // -- distance posts, one per marked distance --------------------------
    // 0.86 rather than 0.92 so the post AND its caption stay inside the board at the nearest
    // distance - a caption is drawn from its centre and reaches half its width past the post.
    for (var i = 1; i <= _board.posts; i++) {
        var _d = i / (_board.posts + 1);
        var _k = pas_range_scale(_d);
        var _v = 1 - (1 - _hz) * (1 - _k) - 0.06;
        var _hgt = 0.16 * _k;
        for (var _side = -1; _side <= 1; _side += 2) {
            var _u = pas_range_lat(_side, _k);
            pas_line(_f, _u, _v, _u, _v - _hgt, pas_detail(_f, 0.008, 1, 8) * _k + 1, _pal.w2);
            pas_disc(_f, _u, _v - _hgt, 0.012 * _k + 0.004, _pal.b3);
        }
        // The caption sits INSIDE its post, not on it: a string is drawn from its centre and
        // reaches half its width past whatever it labels, which is how "30yd" came to be cut in
        // half by the board's right edge on the previous bake.
        pas_text_fit(_f, string(round(10 + _d * 60)) + "yd", pas_range_lat(0.80, _k), _v + 0.035,
                     0.09 * _k + 0.03, _pal.guide, fa_center, fa_middle);
    }

    // -- bunting across the back wall -------------------------------------
    if (_board.bunting > 0) {
        var _flags = 9 + _board.bunting * 4;
        var _sag = 0.045;
        for (var i = 0; i < _flags; i++) {
            var _t0 = i / _flags, _t1 = (i + 1) / _flags;
            var _y0 = 0.055 + sin(_t0 * pi) * _sag;
            var _y1 = 0.055 + sin(_t1 * pi) * _sag;
            pas_poly(_f, [ _t0, _y0, _t1, _y1, (_t0 + _t1) * 0.5, (_y0 + _y1) * 0.5 + 0.055 ],
                     (i & 1) ? _pal.p3 : _pal.q3);
        }
        var _rope = [];
        for (var i = 0; i <= 24; i++) {
            var _t = i / 24;
            array_push(_rope, _t, 0.055 + sin(_t * pi) * _sag);
        }
        pas_stroke(_f, _rope, pas_detail(_f, 0.004, 1, 4), _pal.w4);
    }

    // -- targets, FAR TO NEAR ---------------------------------------------
    // ⛔ Painter's order is not a detail in a perspective view: a near target must occlude a far
    // one, and "whichever came first in the array" is not a rule. Sorted by distance, drawn far
    // first, every frame.
    var _order = array_create(array_length(_board.targets));
    for (var i = 0; i < array_length(_board.targets); i++) _order[i] = i;
    for (var i = 1; i < array_length(_order); i++) {
        var _k2 = _order[i]; var _j = i - 1;
        while (_j >= 0 && _board.targets[_order[_j]].dist < _board.targets[_k2].dist) {
            _order[_j + 1] = _order[_j]; _j -= 1;
        }
        _order[_j + 1] = _k2;
    }

    for (var _oi = 0; _oi < array_length(_order); _oi++) {
        var _t = _board.targets[_order[_oi]];
        var _p = pas_range_foot(_board, _t.lane, _t.dist);
        var _u = _p[0], _v = _p[1], _k = _p[2];
        var _fr = 0.185 * _k;
        var _px = _fr * _f.s;

        // ground shadow: an ELLIPSE, because a disc on a floor seen from a standing eye is one.
        // A circular helper here draws a silently wrong curve that agrees only when the two radii
        // match, which they never do on a floor.
        var _sh = pas_ellipse_arc_pts(_u, _v, _fr * 0.9, _fr * 0.26, 0, 360, 28);
        pas_poly(_f, _sh, merge_colour(_pal.m1, _pal.m0, 0.6));

        if (_t.down) {
            // A knocked plate lies flat: the same face, foreshortened, on the floor. Not removed -
            // a target that vanishes when hit reads as a bug.
            var _fl = pas_ellipse_arc_pts(_u, _v, _fr * 0.85, _fr * 0.24, 0, 360, 28);
            pas_poly(_f, _fl, _pal.m4);
            continue;
        }

        // the stand
        pas_line(_f, _u, _v, _u, _v - _fr * 0.55, max(1, pas_detail(_f, 0.010, 1, 9) * _k), _pal.w2);

        var _cu = _u, _cv = _v - _fr * 1.05;
        var _show = pas_range_rings(_t, _px);

        if (_t.lobes > 0) {
            // A lobed plate: the face is not round, so its SILHOUETTE differs from the round faces
            // beside it. A difference drawn INSIDE a shape is not a difference in the shape -
            // this wing measured two species at Jaccard distance exactly zero for want of that.
            var _sil = [];
            for (var s = 0; s <= 56; s++) {
                var _a = degtorad(_t.spin + s * (360 / 56));
                var _rr = _fr * (1 + 0.16 * cos(_a * _t.lobes));
                _sil[s * 2]     = _cu + cos(_a) * _rr * (_f.s / max(1, _f.w));
                _sil[s * 2 + 1] = _cv + sin(_a) * _rr * (_f.s / max(1, _f.h));
            }
            pas_poly(_f, _sil, _pal.m0);
        }

        // Rings, OUTSIDE IN, so each covers the last. When distance forces a reduction the OUTER
        // edge and the BULL are always kept and the drop comes out of the middle - those two are
        // what a shooter aims by, and a level-of-detail rule that dropped either would be trading
        // away the thing the picture is for.
        for (var s = _show - 1; s >= 0; s--) {
            var _idx = (_show <= 1) ? 0 : round(s * (_t.rings - 1) / (_show - 1));
            var _c = (_idx == 0) ? _pal.p3 : ((_idx & 1) ? _pal.m4 : _pal.m0);
            pas_disc(_f, _cu, _cv, _fr * _t.radii[_idx], _c);
        }
        pas_ring(_f, _cu, _cv, _fr, max(1, pas_detail(_f, 0.005, 1, 5) * _k), _pal.b3);
    }

    // -- shot marks -------------------------------------------------------
    for (var i = 0; i < array_length(_board.shots); i++) {
        var _s = _board.shots[i];
        var _c = (_s.score > 0) ? _pal.b4 : _pal.guide;
        pas_disc(_f, _s.u, _s.v, 0.010, _c);
        pas_ring(_f, _s.u, _s.v, 0.019, pas_detail(_f, 0.003, 1, 3), _c);
    }
}
