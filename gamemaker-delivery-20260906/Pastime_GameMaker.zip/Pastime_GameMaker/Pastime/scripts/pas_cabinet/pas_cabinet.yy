{
  "$GMScript": "v1",
  "%Name": "pas_cabinet",
  "name": "pas_cabinet",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}
