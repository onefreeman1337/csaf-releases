/// PASTIME - pas_cabinet. The registry, the housing, and the public API.
///
/// This is the file a buyer reads first, and it is the only one that knows there are eight rooms.
/// Every room is reached through the five dispatchers below and NOTHING else in the package calls a
/// room's functions directly - which is what lets a buyer add a ninth room by writing five functions
/// and adding one name to pas_rooms().
///
/// -- WHY THE ROOM LIST IS ONE ARRAY ------------------------------------------------------------
/// ⛔ THERE IS EXACTLY ONE LIST OF ROOMS IN THIS PACKAGE, and every dispatcher switches on a name
/// taken from it. This factory has paid repeatedly for the alternative: a second runner holding four
/// suite names while the real one held twelve printed "4/4 suites green" over a third of the gates,
/// which is a true statement indistinguishable from a false one. One list, five readers, and
/// pas_selftest walks the list and calls all five for every entry - so a dispatcher missing an arm
/// goes red BY NAME instead of the room silently not existing.
///
/// -- THE HOUSING -------------------------------------------------------------------------------
/// The cabinet is the constant and the board is the variable (see pas_palette). Every room sits in
/// the same carcass, under the same brass-bezelled marquee, over the same label rail, with the same
/// corner treatment - so eight visual languages read as eight games in one piece of furniture rather
/// than as a mixed-quality bundle. That was the candidate's stated risk and this is the answer to it.
///
/// ⛔ THE WELL IS CUT TO THE BOARD, NOT THE BOARD SQUEEZED INTO THE WELL. Each room declares its own
/// aspect and pas_cabinet_well fits the largest rect of that aspect inside the opening. This wing
/// measured the alternative on Horologe: a fixed 4x3 grid over a corpus of differently-shaped
/// specimens left ten of twelve machines filling a third of their cell, with every ink floor green.
/// ================================================================================================

#macro PAS_VERSION "1.0.0"

/// @desc The one list of rooms. Everything else in the package reads it.
function pas_rooms() {
    static _r = [ "circuit", "darts", "dice", "maze", "range", "wheel", "bagatelle", "tangram" ];
    return _r;
}

function pas_room_count() { return array_length(pas_rooms()); }

function pas_room_name(_i) {
    var _r = pas_rooms();
    var _n = array_length(_r);
    return _r[((_i mod _n) + _n) mod _n];
}

/// ================================================================================================
/// INPUT - one shape for every room
/// ================================================================================================
/// A cabinet is played by pointing at it and by pressing keys, so that is the input every room
/// takes: {act, u, v, key}. A bare string is accepted as a key for convenience, because a caller
/// driving the maze from a keyboard should not have to build a struct to say "north".
///
/// ⚠️ u and v are BOARD space, 0..1, NOT pixels and NOT window coordinates. pas_cabinet_to_board
/// converts, and it is the only place that conversion happens - a hit test and a picture that
/// compute the same mapping in two places will disagree eventually.

function pas_input(_act, _u, _v, _key) {
    return { act : _act, u : _u, v : _v, key : _key };
}

function pas_input_key(_in) {
    if (is_string(_in)) return _in;
    if (is_struct(_in) && variable_struct_exists(_in, "key")) return _in.key;
    return "";
}

function pas_input_act(_in) {
    if (is_string(_in)) return "key";
    if (is_struct(_in) && variable_struct_exists(_in, "act")) return _in.act;
    return "";
}

/// Returns -1 when the input carries no pointer, which every room treats as "drive yourself".
/// -1 rather than undefined so a caller can compare without a type check, and so a headless suite
/// can exercise every room's _step without inventing coordinates.
function pas_input_u(_in) {
    if (is_struct(_in) && variable_struct_exists(_in, "u")) return _in.u;
    return -1;
}

function pas_input_v(_in) {
    if (is_struct(_in) && variable_struct_exists(_in, "v")) return _in.v;
    return -1;
}

/// ================================================================================================
/// DISPATCH - five functions, one switch each, all over pas_rooms()
/// ================================================================================================

/// @desc Generate a board for a room.
/// @param {string} _room  a name from pas_rooms()
function pas_room_board(_room, _seed, _opts = {}) {
    switch (_room) {
        case "circuit":   return pas_circuit_board(_seed, _opts);
        case "darts":     return pas_darts_board(_seed, _opts);
        case "dice":      return pas_dice_board(_seed, _opts);
        case "maze":      return pas_maze_board(_seed, _opts);
        case "range":     return pas_range_board(_seed, _opts);
        case "wheel":     return pas_wheel_board(_seed, _opts);
        case "bagatelle": return pas_bagatelle_board(_seed, _opts);
        case "tangram":   return pas_tangram_board(_seed, _opts);
    }
    return undefined;
}

function pas_room_draw(_room, _board, _x, _y, _w, _h, _pal) {
    switch (_room) {
        case "circuit":   pas_circuit_draw(_board, _x, _y, _w, _h, _pal);   break;
        case "darts":     pas_darts_draw(_board, _x, _y, _w, _h, _pal);     break;
        case "dice":      pas_dice_draw(_board, _x, _y, _w, _h, _pal);      break;
        case "maze":      pas_maze_draw(_board, _x, _y, _w, _h, _pal);      break;
        case "range":     pas_range_draw(_board, _x, _y, _w, _h, _pal);     break;
        case "wheel":     pas_wheel_draw(_board, _x, _y, _w, _h, _pal);     break;
        case "bagatelle": pas_bagatelle_draw(_board, _x, _y, _w, _h, _pal); break;
        case "tangram":   pas_tangram_draw(_board, _x, _y, _w, _h, _pal);   break;
    }
}

function pas_room_step(_room, _board, _input) {
    switch (_room) {
        case "circuit":   return pas_circuit_step(_board, _input);
        case "darts":     return pas_darts_step(_board, _input);
        case "dice":      return pas_dice_step(_board, _input);
        case "maze":      return pas_maze_step(_board, _input);
        case "range":     return pas_range_step(_board, _input);
        case "wheel":     return pas_wheel_step(_board, _input);
        case "bagatelle": return pas_bagatelle_step(_board, _input);
        case "tangram":   return pas_tangram_step(_board, _input);
    }
    return "";
}

function pas_room_label(_room, _board) {
    switch (_room) {
        case "circuit":   return pas_circuit_label(_board);
        case "darts":     return pas_darts_label(_board);
        case "dice":      return pas_dice_label(_board);
        case "maze":      return pas_maze_label(_board);
        case "range":     return pas_range_label(_board);
        case "wheel":     return pas_wheel_label(_board);
        case "bagatelle": return pas_bagatelle_label(_board);
        case "tangram":   return pas_tangram_label(_board);
    }
    return "";
}

function pas_room_aspect(_room, _board) {
    switch (_room) {
        case "circuit":   return pas_circuit_aspect(_board);
        case "darts":     return pas_darts_aspect(_board);
        case "dice":      return pas_dice_aspect(_board);
        case "maze":      return pas_maze_aspect(_board);
        case "range":     return pas_range_aspect(_board);
        case "wheel":     return pas_wheel_aspect(_board);
        case "bagatelle": return pas_bagatelle_aspect(_board);
        case "tangram":   return pas_tangram_aspect(_board);
    }
    return 1;
}

/// @desc A structural fingerprint of a generated board.
///
/// ⭐ THIS IS HOW THE VOLUME CLAIM IS PROVEN RATHER THAN ASSERTED. The listing says the cabinet
/// generates 40+ distinct boards; pas_selftest generates five seeds for every one of the eight rooms
/// and requires all forty fingerprints to differ. A count that is merely SUMMED over some arrays is
/// the shape this wing has caught inflating a market claim with forms the package did not have.
///
/// ⚠️ It reads STRUCTURE, never the drawing. Two boards that look different because of a colour are
/// not two boards; two boards with different wall data, different pin fields or different number
/// rings are.
function pas_board_fingerprint(_room, _board) {
    switch (_room) {
        case "circuit":
            var _s = "c" + string(_board.gw) + "," + string(_board.gh) + ",";
            for (var i = 0; i < array_length(_board.nodes); i++) {
                _s += string(_board.nodes[i].gx) + ":" + string(_board.nodes[i].gy)
                    + ":" + string(_board.nodes[i].kind) + ";";
            }
            return _s;
        case "darts":
            var _s2 = "d" + string(_board.sectors) + ",";
            for (var i = 0; i < array_length(_board.order); i++) _s2 += string(_board.order[i]) + ";";
            return _s2;
        case "dice":
            var _s3 = "i" + string(_board.n) + "," + string(_board.faces) + "," + string(_board.lat) + ",";
            for (var v = 1; v <= _board.faces; v++) {
                var _l = _board.layout[v];
                for (var k = 0; k < array_length(_l); k++) _s3 += string(_l[k]) + ",";
                _s3 += ";";
            }
            return _s3;
        case "maze":
            var _s4 = "m" + string(_board.w) + "," + string(_board.h) + ",";
            for (var i = 0; i < array_length(_board.cells); i++) _s4 += string(_board.cells[i]) + ";";
            return _s4;
        case "range":
            var _s5 = "r" + string(_board.lanes) + ",";
            for (var i = 0; i < array_length(_board.targets); i++) {
                var _t = _board.targets[i];
                _s5 += string(_t.rings) + ":" + string(_t.lobes) + ":"
                     + string(round(_t.dist * 1000)) + ";";
            }
            return _s5;
        case "wheel":
            var _s6 = "w" + string(_board.segs) + ",";
            for (var i = 0; i < array_length(_board.values); i++) _s6 += string(_board.values[i]) + ";";
            return _s6;
        case "bagatelle":
            var _s7 = "b" + string(_board.rows) + "," + string(_board.lattice) + ",";
            for (var i = 0; i < array_length(_board.pins); i++) {
                _s7 += string(round(_board.pins[i].u * 1000)) + ":"
                     + string(round(_board.pins[i].v * 1000)) + ";";
            }
            for (var i = 0; i < array_length(_board.cupval); i++) _s7 += string(_board.cupval[i]) + ",";
            return _s7;
        case "tangram":
            var _s8 = "t" + string(_board.sides) + "," + string(array_length(_board.pieces)) + ",";
            for (var i = 0; i < array_length(_board.pieces); i++) {
                _s8 += string(round(_board.pieces[i].area * 100000)) + ";";
            }
            return _s8;
    }
    return "";
}

/// ================================================================================================
/// THE CABINET
/// ================================================================================================

/// @desc Make a cabinet: one board per room, all from one seed.
///
/// Each room is seeded from the cabinet seed by a large odd stride rather than by seed+index.
/// ⛔ A Lehmer or xorshift generator's FIRST draw is very nearly a straight line in the seed for a
/// run of nearby seeds - this wing measured a first draw spanning only 0.5102 to 0.7358 across 440
/// consecutive seeds, which took a 30% rare event to exactly 0% and passed every determinism
/// assertion while doing it. Striding the seeds keeps eight adjacent rooms out of that trap.
function pas_cabinet_new(_seed, _theme = -1) {
    var _rooms = pas_rooms();
    var _cab = {
        seed    : _seed,
        room    : 0,
        theme   : (_theme >= 0) ? _theme : (_seed mod pas_theme_count()),
        boards  : array_create(array_length(_rooms), undefined),
        pal     : undefined,
        message : "",
    };
    for (var i = 0; i < array_length(_rooms); i++) {
        _cab.boards[i] = pas_room_board(_rooms[i], _seed + i * 2654435761, {});
    }
    _cab.pal = pas_pal(_cab.theme);
    return _cab;
}

/// @desc Move to another room. Wraps in both directions.
function pas_cabinet_select(_cab, _i) {
    var _n = pas_room_count();
    _cab.room = ((_i mod _n) + _n) mod _n;
    // Each room gets its own colourway, derived from the cabinet's theme and the room index, so
    // walking the cabinet is a walk through the palette rather than eight boards in one green.
    _cab.pal = pas_pal(_cab.theme + _cab.room * 5);
    return _cab.room;
}

/// @desc Re-roll the current room's board, keeping the cabinet.
function pas_cabinet_reroll(_cab, _seed) {
    _cab.boards[_cab.room] = pas_room_board(pas_room_name(_cab.room), _seed, {});
    return _cab.boards[_cab.room];
}

function pas_cabinet_board(_cab) { return _cab.boards[_cab.room]; }

/// @desc Send an input to the current room.
function pas_cabinet_step(_cab, _input) {
    var _res = pas_room_step(pas_room_name(_cab.room), _cab.boards[_cab.room], _input);
    _cab.message = _res;
    return _res;
}

/// @desc The opening in the carcass, in CABINET space (0..1 of the cabinet rect).
function pas_cabinet_opening() {
    return [ 0.052, 0.176, 0.896, 0.632 ];    // u, v, w, h
}

/// @desc The largest rect of a given aspect that fits the opening, in PIXEL space.
///
/// The Horologe law: measure the specimen, then cut the cell to it. Returns [x, y, w, h].
function pas_cabinet_well(_x, _y, _w, _h, _aspect) {
    var _o = pas_cabinet_opening();
    var _ox = _x + _o[0] * _w, _oy = _y + _o[1] * _h;
    var _ow = _o[2] * _w,      _oh = _o[3] * _h;
    if (_aspect <= 0) _aspect = 1;
    var _bw = _ow, _bh = _ow / _aspect;
    if (_bh > _oh) { _bh = _oh; _bw = _oh * _aspect; }
    return [ _ox + (_ow - _bw) * 0.5, _oy + (_oh - _bh) * 0.5, _bw, _bh ];
}

/// @desc The cabinet's rect inside the current display, letterboxed to a fixed aspect.
///
/// ⛔ ONE FUNCTION, TWO READERS - the draw event and the hit test. A cabinet drawn at one rect and
/// clicked against another is a game that ignores the player, which is undebuggable from a support
/// ticket because it looks like nothing happened. This wing has the same law for pas_circuit's node
/// positions and pas_dice's slots, and for the same reason.
///
/// @param {real} _w,_h  the surface to fit into; pass -1 to read the GUI size
/// @return {array} [x, y, w, h]
function pas_pad_rect(_w = -1, _h = -1, _asp = 1.30) {
    var _sw = (_w > 0) ? _w : display_get_gui_width();
    var _sh = (_h > 0) ? _h : display_get_gui_height();
    var _cw = _sw * 0.96, _ch = _cw / _asp;
    if (_ch > _sh * 0.90) { _ch = _sh * 0.90; _cw = _ch * _asp; }
    return [ (_sw - _cw) * 0.5, (_sh - _ch) * 0.5, _cw, _ch ];
}

/// @desc The cabinet aspect that makes the current board FILL the opening exactly.
///
/// ⛔ THE OPENING IS CUT TO THE BOARD, NOT THE BOARD SQUEEZED INTO THE OPENING - and the first
/// build did the second thing. MEASURED 2026-09-03 by baking the hero sheet and looking at it: a
/// 1.29-aspect circuit board inside a 1.84-aspect opening left a quarter of the cabinet front as
/// bare dark reveal, with contentW and contentH both reporting 0.999 because a BOUNDING BOX CANNOT
/// SEE THE SPACE INSIDE ITSELF. That is this wing's Horologe law - measure the specimen first, then
/// cut the cell to it - and its ink floors are structurally blind to the failure.
///
/// The housing does not change: same carcass, same marquee, same rail, same corner treatment. Only
/// its PROPORTION follows the board, which is what a real cabinet lineup does anyway - a dartboard
/// cabinet is square and a shuffleboard is long.
///
/// ⚠️ CLAMPED, because a room can ask for an aspect no cabinet has. Below 0.80 the marquee's type
/// would be wider than the carcass; above 2.60 the label rail becomes a letterbox. A room outside
/// that range gets a cabinet at the limit and keeps its own margins, which is the honest degrade.
function pas_cabinet_aspect(_cab) {
    var _b = _cab.boards[_cab.room];
    if (is_undefined(_b)) return 1.30;
    var _o = pas_cabinet_opening();
    var _ba = pas_room_aspect(pas_room_name(_cab.room), _b);
    if (_ba <= 0) return 1.30;
    return clamp(_ba * (_o[3] / _o[2]), 0.80, 2.60);
}

/// @desc Convert a PIXEL point to the current board's own 0..1 space, or [-1,-1] if outside.
///
/// The ONE place this conversion happens. Two implementations of a mapping will disagree eventually,
/// and a hit test that disagrees with a picture is a bug a player experiences as the game ignoring
/// them - which is unreportable and undebuggable from a support ticket.
function pas_cabinet_to_board(_cab, _x, _y, _w, _h, _px, _py) {
    var _b = _cab.boards[_cab.room];
    if (is_undefined(_b)) return [ -1, -1 ];
    var _wl = pas_cabinet_well(_x, _y, _w, _h, pas_room_aspect(pas_room_name(_cab.room), _b));
    if (_wl[2] <= 0 || _wl[3] <= 0) return [ -1, -1 ];
    var _u = (_px - _wl[0]) / _wl[2];
    var _v = (_py - _wl[1]) / _wl[3];
    if (_u < 0 || _u > 1 || _v < 0 || _v > 1) return [ -1, -1 ];
    return [ _u, _v ];
}

/// @desc Draw the whole cabinet: housing, board and label.
function pas_cabinet_draw(_cab, _x, _y, _w, _h) {
    var _f = pas_map(_x, _y, _w, _h);
    var _p = _cab.pal;
    var _room = pas_room_name(_cab.room);
    var _b = _cab.boards[_cab.room];

    // -- the wall behind the cabinet --------------------------------------
    draw_set_colour(_p.back);
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);

    // -- the carcass ------------------------------------------------------
    var _rad = pas_detail(_f, 0.022, 3, 26);
    pas_rrect(_f, 0.012, 0.020, 0.976, 0.972, _rad, _p.w0);           // seated shadow
    pas_plate(_f, 0.008, 0.008, 0.976, 0.968, _rad, _p.w2, _p.w4, _p.w0);
    // A scribed line just inside the edge. One line, at a real pixel width, is what makes a slab
    // read as a cabinet front - and it is the only ornament the carcass gets, because a coverage
    // floor satisfied by decoration is a coverage floor that has stopped measuring anything.
    pas_rrect_edge(_f, 0.026, 0.026, 0.940, 0.932, _rad * 0.8,
                   pas_detail(_f, 0.0035, 1, 4), _p.w1);

    // -- the marquee ------------------------------------------------------
    var _mv = 0.040, _mh = 0.108;
    pas_well(_f, 0.052, _mv, 0.896, _mh, _rad * 0.5, _p.plate, _p.w4, _p.w0);
    pas_rrect_edge(_f, 0.052, _mv, 0.896, _mh, _rad * 0.5,
                   pas_detail(_f, 0.004, 1, 4), _p.b2);
    // The product name on the left, the room on the right: the marquee has to say where you are,
    // and a marquee that only says the product name is a logo rather than a fascia.
    draw_set_font(fnt_pastime_title);
    pas_text_fit(_f, "PASTIME", 0.078, _mv + _mh * 0.5, 0.34, _p.type, fa_left, fa_middle);
    pas_text_fit(_f, string_upper(_room), 0.922, _mv + _mh * 0.5, 0.40, _p.b4, fa_right, fa_middle);
    draw_set_font(fnt_pastime);

    // -- brass bolts at the marquee corners --------------------------------
    var _bolt = pas_detail(_f, 0.008, 2, 9) / max(1, _f.s);
    var _bx = [ 0.068, 0.932, 0.068, 0.932 ];
    var _by = [ _mv + 0.018, _mv + 0.018, _mv + _mh - 0.018, _mv + _mh - 0.018 ];
    for (var i = 0; i < 4; i++) {
        pas_disc(_f, _bx[i], _by[i], _bolt, _p.b1);
        pas_disc(_f, _bx[i] - _bolt * 0.25, _by[i] - _bolt * 0.28, _bolt * 0.55, _p.b4);
    }

    // -- the opening the board sits in -------------------------------------
    var _o = pas_cabinet_opening();
    pas_well(_f, _o[0] - 0.012, _o[1] - 0.012, _o[2] + 0.024, _o[3] + 0.024,
             _rad * 0.6, _p.w1, _p.w4, _p.w0);
    // the glass reveal: a dark surround so a board of any aspect sits in something rather than
    // floating on the woodwork
    pas_rrect(_f, _o[0], _o[1], _o[2], _o[3], _rad * 0.45, _p.plate);

    // -- the board ---------------------------------------------------------
    if (!is_undefined(_b)) {
        var _wl = pas_cabinet_well(_x, _y, _w, _h, pas_room_aspect(_room, _b));
        pas_room_draw(_room, _b, _wl[0], _wl[1], _wl[2], _wl[3], _p);
        // a hairline right on the board's own edge, so the board reads as a fitted panel
        var _bf = pas_map(_wl[0], _wl[1], _wl[2], _wl[3]);
        pas_rrect_edge(_bf, 0, 0, 1, 1, pas_detail(_bf, 0.014, 2, 14),
                       pas_detail(_bf, 0.004, 1, 4), _p.w0);
    }

    // -- the label rail ----------------------------------------------------
    var _lv = 0.836, _lh = 0.118;
    pas_well(_f, 0.052, _lv, 0.896, _lh, _rad * 0.5, _p.plate, _p.w4, _p.w0);
    pas_rrect_edge(_f, 0.052, _lv, 0.896, _lh, _rad * 0.5,
                   pas_detail(_f, 0.004, 1, 4), _p.b2);

    var _label = is_undefined(_b) ? "" : pas_room_label(_room, _b);
    pas_text_fit(_f, _label, 0.078, _lv + _lh * 0.34, 0.62, _p.type, fa_left, fa_middle);

    var _sub = "theme " + _p.name + "   room " + string(_cab.room + 1) + " of "
             + string(pas_room_count());
    if (_cab.message != "") _sub += "   " + string_upper(_cab.message);
    pas_text_fit(_f, _sub, 0.078, _lv + _lh * 0.70, 0.62, _p.dim, fa_left, fa_middle);

    // -- the theme swatch: the palette, shown ------------------------------
    // Five stops of the bed and both accents, as a row of chips. It is the cabinet telling the
    // buyer what the palette layer actually does, on every screenshot, without a caption.
    var _cw = 0.020, _cx = 0.922 - _cw * 6;
    var _chips = [ _p.m0, _p.m2, _p.m4, _p.p3, _p.q3, _p.ink ];
    for (var i = 0; i < 6; i++) {
        pas_rrect(_f, _cx + i * _cw, _lv + _lh * 0.30, _cw * 0.80, _lh * 0.40,
                  pas_detail(_f, 0.003, 1, 3), _chips[i]);
    }
}
