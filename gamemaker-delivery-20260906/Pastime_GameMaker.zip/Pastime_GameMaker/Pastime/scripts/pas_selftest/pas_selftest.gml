/// PASTIME - pas_selftest. The in-engine suite.
///
/// ================================================================================================
/// ⛔ GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE. There is no headless runner, no mock and no
/// assertion library. This wing's answer is to build the product through Igor, run the executable
/// with `-selftest`, and have it write a JSON result file - the only route that survives a release
/// build. `show_debug_message` plus `-debugoutput` writes engine boot lines and nothing else, and
/// `game_end(n)` does not propagate n to the process exit code. Both MEASURED in this wing.
///
/// ⛔ A SUITE FULL OF GREEN ASSERTIONS PROVES NOTHING UNTIL ONE OF THEM HAS BEEN MADE TO FAIL, and
/// a suite whose FIXTURE is in the wrong state proves nothing while looking identical. Every
/// assertion here that could pass vacuously is paired with one proving its fixture is in the state
/// it needs, marked VACUITY GUARD.
///
/// ⛔ THE DEFAULT EPSILON. math_get_epsilon() returns 0.00001 on this runtime and it PARTICIPATES IN
/// COMPARISONS, so a tolerance at or below about 0.00001 answers the same thing for every input -
/// in BOTH directions. PAS_ST_EPS is ten times it, the smallest number that can fire either way.
/// GML also has no exponent-literal syntax: `1e-5` is a lexer error that reads like a bracket bug.
///
/// ================================================================================================
/// WHAT THIS SUITE IS FOR, ON THIS PRODUCT SPECIFICALLY
///
/// Pastime's claim is that EACH GAME GENERATES ITS OWN BOARD. Four stages carry that claim and the
/// rest support them:
///
///   STAGE 4  THE MAZE'S WALLS AGREE WITH THEMSELVES. Asserted as its OWN arm, never inferred from
///            solvability - MEASURED before any GML was written (Internal_Ops/maze_design_proof.js,
///            10,000 boards): pas_maze_solve reads only the NEAR cell's wall, so a one-sided carve
///            leaves a route the search walks happily. A solvability assertion is SILENT on that
///            entire class of defect and would have shipped a one-way maze under a green suite.
///
///   STAGE 5  THE DARTS RING BEATS CHANCE. The number ring is searched, and a search that does not
///            beat a random baseline is a shuffle with extra steps. Judged against a RANDOM
///            BASELINE measured in the same run, never against a fixed number somebody liked.
///
///   STAGE 11 THE TANGRAM DISSECTION LOSES NOTHING. Every piece convex AND the piece areas summing
///            to the outline's - convexity alone would be perfectly happy with a dissection that
///            dropped a wedge, which is a puzzle that cannot be completed.
///
///   STAGE 13 THE VOLUME CLAIM, PROVEN. Forty boards, eight rooms, five seeds each, and all forty
///            structural fingerprints distinct. The listing says 40+ generated boards; this is what
///            makes that a measurement instead of a sentence.
///
/// ⚠️ WHAT THIS SUITE CANNOT SEE, said here rather than left for a buyer to discover: it computes
/// POINTS and NUMBERS. It cannot see a FILL RULE, a DRAW ORDER, a COLOUR ON A PAGE or a PICTURE.
/// This wing has shipped a crescent moon rendered as a quarter, a rainbow that never drew once in
/// the product's life, and a corpus collapsed to a vertical line, every one under a fully green
/// geometry story. The instrument for those is baking the sheets and LOOKING, and that step is not
/// optional because this file exists.
/// ================================================================================================

/// The one tolerance in this file. Ten times GML's 0.00001 epsilon, which is the smallest value
/// that can fire in both directions.
#macro PAS_ST_EPS 0.0001

/// How many seeds each corpus-wide arm sweeps. High enough that a one-in-a-hundred generator defect
/// is caught rather than shipped; low enough that the suite runs inside a build step.
#macro PAS_ST_SEEDS 220

/// Seeds per room for the volume claim. 8 rooms x 5 = the 40 the listing quotes.
#macro PAS_ST_VOLUME_SEEDS 5

function pas_st_new() {
    return { pass : 0, fail : 0, notes : [] };
}

function pas_st_ok(_r, _cond, _what) {
    if (_cond) { _r.pass += 1; return; }
    _r.fail += 1;
    // Cap the notes. A systemic failure fires hundreds of times and a result file too large to
    // write is a result file nobody reads.
    if (array_length(_r.notes) < 60) array_push(_r.notes, _what);
}

/// @desc Run the whole suite.
function pas_selftest_run() {
    var _r = pas_st_new();
    var _extra = {
        epsilon      : math_get_epsilon(),
        firstDrawLo  : 1, firstDrawHi : 0,
        ringGen      : 0, ringRand : 0, ringWorst : 0,
        pairMinSep   : 0,
        volumeBoards : 0, volumeDistinct : 0, ciTrivial : 0,
        cupSpread    : 0, cupDistinct : 0,
        lodNear      : 0, lodFar : 0, rangeWorstU : 0.5,
        rooms        : pas_room_count(),
        themes       : pas_theme_count(),
    };

    // ============================================================================================
    // STAGE 0 - the environment. The runtime still applies a comparison epsilon.
    // ============================================================================================
    global.pas_stage = 0;
    var _eps = math_get_epsilon();
    // ⛔ SPLIT IN TWO ON PURPOSE. The natural single clause `_eps > 0 && _eps < TOL` goes RED on a
    // healthy runtime: the difference between the epsilon and zero IS the epsilon, so GML calls
    // them equal, and equal is not greater-than. Written as `!(_eps > 0)` it becomes a POSITIVE
    // test that the epsilon is still applied, and it goes red the day a release stops applying one.
    pas_st_ok(_r, !(_eps > 0), "epsilon no longer participates in comparisons: " + string(_eps));
    pas_st_ok(_r, _eps < 0.001, "epsilon larger than this suite's tolerances: " + string(_eps));

    // ============================================================================================
    // STAGE 1 - pas_rng. Determinism, range, and the FIRST-DRAW trap.
    // ============================================================================================
    global.pas_stage = 1;
    var _a = pas_rng(12345), _b = pas_rng(12345);
    var _same = true;
    for (var i = 0; i < 200; i++) if (pas_rng_next(_a) != pas_rng_next(_b)) { _same = false; break; }
    pas_st_ok(_r, _same, "same seed produced different streams");

    var _c = pas_rng(12345), _d = pas_rng(12346);
    var _diff = false;
    for (var i = 0; i < 20; i++) if (pas_rng_next(_c) != pas_rng_next(_d)) { _diff = true; break; }
    pas_st_ok(_r, _diff, "adjacent seeds produced the same stream");   // VACUITY GUARD for the above

    // pas_rng_int is INCLUSIVE at both ends, and the ends must actually be reachable.
    var _lo = false, _hi = false, _out = false;
    var _e = pas_rng(99);
    for (var i = 0; i < 4000; i++) {
        var _v = pas_rng_int(_e, 3, 7);
        if (_v == 3) _lo = true;
        if (_v == 7) _hi = true;
        if (_v < 3 || _v > 7) _out = true;
    }
    pas_st_ok(_r, _lo, "pas_rng_int never returned its low end");
    pas_st_ok(_r, _hi, "pas_rng_int never returned its high end");
    pas_st_ok(_r, !_out, "pas_rng_int left its range");
    pas_st_ok(_r, pas_rng_int(_e, 5, 5) == 5, "pas_rng_int on an empty range");

    // shuffle must be a PERMUTATION, not a resample
    var _src = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ];
    var _sh = pas_rng_shuffle(_e, _src);
    var _sum = 0, _lenok = (array_length(_sh) == 10);
    for (var i = 0; i < array_length(_sh); i++) _sum += _sh[i];
    pas_st_ok(_r, _lenok && _sum == 55, "shuffle is not a permutation");
    pas_st_ok(_r, _src[0] == 1, "shuffle mutated the caller's array");

    // ⛔ THE FIRST-DRAW TRAP. A generator's first output for a run of NEARBY seeds can be very
    // nearly a straight line - this wing measured a first draw spanning only 0.5102 to 0.7358
    // across 440 consecutive seeds, which took a 30% rare event to exactly 0% while every
    // determinism assertion passed. Every room here is seeded from a cabinet seed, so the property
    // has to be MEASURED rather than assumed to be fine because the generator is a good one.
    for (var i = 0; i < 600; i++) {
        var _f = pas_rng_float(pas_rng(70000 + i));
        if (_f < _extra.firstDrawLo) _extra.firstDrawLo = _f;
        if (_f > _extra.firstDrawHi) _extra.firstDrawHi = _f;
    }
    pas_st_ok(_r, (_extra.firstDrawHi - _extra.firstDrawLo) > 0.80,
        "first draw over 600 consecutive seeds spans only "
        + string_format(_extra.firstDrawHi - _extra.firstDrawLo, 1, 4));

    // ============================================================================================
    // STAGE 2 - pas_palette. The two colour laws, mechanised.
    // ============================================================================================
    global.pas_stage = 2;
    var _cab0 = pas_cabinet_pal();
    for (var t = 0; t < pas_theme_count(); t++) {
        var _p = pas_pal(t);
        var _nm = pas_theme_name(t);

        // LAW 1: the ramp SLIDES, it never clamps and never compresses.
        var _lim = pas_ramp_limits(_p.bedL, 0.30);
        pas_st_ok(_r, !_lim[2], "theme " + _nm + " compressed its ramp instead of sliding");
        pas_st_ok(_r, (_lim[1] - _lim[0]) > 0.20,
            "theme " + _nm + " ramp span collapsed to " + string_format(_lim[1] - _lim[0], 1, 4));
        pas_st_ok(_r, _lim[0] >= PAS_L_FLOOR - PAS_ST_EPS && _lim[1] <= PAS_L_CEIL + PAS_ST_EPS,
            "theme " + _nm + " ramp left the legal lightness range");

        // LAW 2: ink is not a ramp stop - it is separated from the ground.
        pas_st_ok(_r, abs(_p.inkL - _p.bedL) >= PAS_INK_SEP - PAS_ST_EPS,
            "theme " + _nm + " ink separation only "
            + string_format(abs(_p.inkL - _p.bedL), 1, 3));

        // THE HOUSE STYLE, MECHANISED: the cabinet is the SAME on every theme. If this ever goes
        // red the product has stopped being a cabinet and become eight products in a folder, which
        // is the candidate's own stated risk and the thing this assertion exists to hold.
        pas_st_ok(_r, _p.w0 == _cab0.w0 && _p.w4 == _cab0.w4
                   && _p.b0 == _cab0.b0 && _p.b4 == _cab0.b4 && _p.back == _cab0.back,
            "theme " + _nm + " altered the cabinet carcass");
    }
    // VACUITY GUARD: the themes must actually DIFFER, or every assertion above is about one theme
    // written out twelve times.
    var _bedDiff = 0;
    for (var t = 1; t < pas_theme_count(); t++) {
        if (pas_pal(t).bed != pas_pal(0).bed) _bedDiff += 1;
    }
    pas_st_ok(_r, _bedDiff == pas_theme_count() - 1,
        "only " + string(_bedDiff) + " themes differ from theme 0");

    // ============================================================================================
    // STAGE 3 - pas_geom. The limiter binds, and the caption fitter fits.
    // ============================================================================================
    global.pas_stage = 3;
    // A fine sampled curve: 64 points on a small circle, whose edges are far shorter than its span.
    var _fine = pas_ellipse_arc_pts(0.5, 0.5, 0.10, 0.10, 0, 355, 63);
    var _px = array_create(array_length(_fine));
    for (var i = 0; i < array_length(_fine); i++) _px[i] = _fine[i] * 400;
    var _want = 40;
    var _got = pas_inset_limit(_px, _want);
    // VACUITY GUARD: the limiter must actually BIND here, or the assertion below tests nothing.
    // This is the exact shape that caught Lode's openness measure looking at the wrong two things.
    pas_st_ok(_r, _got < _want - PAS_ST_EPS,
        "inset limiter did not bind on a 64-point curve (returned " + string(_got) + ")");
    pas_st_ok(_r, _got > 0, "inset limiter returned nothing on a valid outline");
    // and it must NOT bind on a coarse outline, or it is a limiter that always says no
    var _coarse = [ 0, 0, 400, 0, 400, 400, 0, 400 ];
    pas_st_ok(_r, pas_inset_limit(_coarse, 10) == 10, "inset limiter bound on a coarse rectangle");
    pas_st_ok(_r, pas_inset_limit([ 0, 0, 1, 1 ], 5) == 0, "inset limiter accepted a 2-point outline");

    // ⛔⛔ THE UNITS CONTRACT ON pas_ring, AND IT IS HERE BECAUSE IT ALREADY SHIPPED ONCE.
    // MEASURED 2026-09-03: pas_ring took its band thickness in BOARD units while every one of its
    // seven callers passed PIXELS, so a 12 px trace width arrived as a radius of 12 board units and
    // one ring painted over the entire hero sheet. 681 assertions were green over it, because a
    // ring of the wrong radius is geometrically perfect. The picture was the only witness.
    //
    // ⇒ the CONTRACT is what a test can reach, so the contract is what is asserted: on a 400 px
    // board a 12 px band is 0.03 of the board, and the ring must straddle its radius by half of
    // that on each side. A future edit that reverts the conversion goes red here instead of in a
    // gallery nobody has baked yet.
    var _rf = pas_map(0, 0, 400, 400);
    var _rad = pas_ring_radii(_rf, 0.30, 12);
    pas_st_ok(_r, abs((_rad[1] - _rad[0]) - 0.03) < PAS_ST_EPS,
        "pas_ring band width is " + string_format(_rad[1] - _rad[0], 1, 4)
        + " board units for 12 px on a 400 px board, expected 0.03");
    pas_st_ok(_r, _rad[1] < 0.5 && _rad[0] > 0.25,
        "pas_ring radii left the board: " + string_format(_rad[0], 1, 3)
        + " to " + string_format(_rad[1], 1, 3));
    // VACUITY GUARD: the band must actually SCALE with the board, or the conversion is a constant.
    var _rad2 = pas_ring_radii(pas_map(0, 0, 1600, 1600), 0.30, 12);
    pas_st_ok(_r, (_rad2[1] - _rad2[0]) < (_rad[1] - _rad[0]) - PAS_ST_EPS,
        "pas_ring band width did not shrink in board units on a four-times-larger board");

    // the caption fitter, BOTH directions
    var _tf = pas_map(0, 0, 400, 400);
    draw_set_font(fnt_pastime);
    pas_st_ok(_r, pas_text_scale(_tf, "A", 0.9) == 1, "a short caption was scaled");
    pas_st_ok(_r, pas_text_scale(_tf,
        "A CAPTION LONG ENOUGH THAT IT CANNOT POSSIBLY FIT IN A TENTH OF THE BOARD", 0.10) < 1,
        "a long caption was not scaled down");

    // ============================================================================================
    // STAGE 4 - MAZE. Wall consistency as its OWN arm. See the header.
    // ============================================================================================
    global.pas_stage = 4;
    var _mzSolvable = 0, _mzConsistent = 0, _mzTotal = 0;
    for (var s = 0; s < PAS_ST_SEEDS; s++) {
        var _mb = pas_maze_board(9000 + s * 7, { w : 7 + (s mod 6), h : 6 + (s mod 5),
                                                 braid : (s mod 3) * 0.18 });
        _mzTotal += 1;
        if (array_length(_mb.path) > 0
         && _mb.path[0] == _mb.start
         && _mb.path[array_length(_mb.path) - 1] == _mb.exit) _mzSolvable += 1;
        if (pas_st_walls_agree(_mb)) _mzConsistent += 1;
    }
    pas_st_ok(_r, _mzSolvable == _mzTotal,
        "maze: only " + string(_mzSolvable) + " of " + string(_mzTotal) + " solvable");
    pas_st_ok(_r, _mzConsistent == _mzTotal,
        "maze: only " + string(_mzConsistent) + " of " + string(_mzTotal) + " wall-consistent");
    // VACUITY GUARD on the consistency check itself: it must FIND a defect when one is present, or
    // the arm above is a function that returns true. A one-sided carve is injected by hand here -
    // the exact defect the design proof modelled, and the one solvability cannot see.
    var _bad = pas_maze_board(4242, { w : 6, h : 6 });
    _bad.cells[0] = _bad.cells[0] & ~PAS_MAZE_E;
    _bad.cells[1] = _bad.cells[1] | PAS_MAZE_W;
    pas_st_ok(_r, !pas_st_walls_agree(_bad),
        "the wall-consistency check did not fire on an injected one-sided carve");

    // ============================================================================================
    // STAGE 5 - DARTS. The searched ring beats a MEASURED random baseline.
    // ============================================================================================
    global.pas_stage = 5;
    var _gen = 0, _rand = 0, _n5 = 0, _worst = 999999, _beat = 0;
    var _rr = pas_rng(555);
    for (var s = 0; s < 60; s++) {
        var _db = pas_darts_board(31000 + s * 13, { sectors : 20 });
        var _g = _db.adjacency;
        // the baseline: the SAME numbers, shuffled, measured in this run
        var _base = array_create(20);
        for (var i = 0; i < 20; i++) _base[i] = i + 1;
        var _bsum = 0;
        for (var k = 0; k < 12; k++) {
            _bsum += pas_darts_adjacency(pas_rng_shuffle(_rr, _base));
        }
        var _bavg = _bsum / 12;
        _gen += _g; _rand += _bavg; _n5 += 1;
        if (_g > _bavg) _beat += 1;
        if (_g < _worst) _worst = _g;
    }
    _extra.ringGen = _gen / max(1, _n5);
    _extra.ringRand = _rand / max(1, _n5);
    _extra.ringWorst = _worst;
    pas_st_ok(_r, _beat == _n5,
        "darts: the searched ring beat chance on only " + string(_beat) + " of " + string(_n5));
    pas_st_ok(_r, _extra.ringGen > _extra.ringRand * 1.20,
        "darts: searched ring " + string_format(_extra.ringGen, 1, 1)
        + " is not clearly above the random baseline " + string_format(_extra.ringRand, 1, 1));

    // the hit test, at the three places it must be exactly right
    var _dh = pas_darts_board(777, { sectors : 20 });
    pas_st_ok(_r, pas_darts_hit(_dh, 0.5, 0.5).ring == PAS_DT_BULL, "darts: centre is not the bull");
    pas_st_ok(_r, pas_darts_hit(_dh, 0.02, 0.02).ring == PAS_DT_MISS,
        "darts: a corner of the board scored");
    var _tre = pas_darts_hit(_dh, 0.5 + (_dh.r_tre_in + _dh.r_tre_ot) * 0.5, 0.5);
    pas_st_ok(_r, _tre.ring == PAS_DT_TREBLE && _tre.score == _tre.number * 3,
        "darts: the treble band did not score treble");

    // ============================================================================================
    // STAGE 6 - DICE. Every generated face is symmetric and carries its own value in pips.
    // ============================================================================================
    global.pas_stage = 6;
    var _symOK = 0, _symTotal = 0, _cntOK = 0, _cntTotal = 0, _oddLat = 0;
    for (var s = 0; s < PAS_ST_SEEDS; s++) {
        var _ib = pas_dice_board(21000 + s * 11, {});
        for (var v = 1; v <= _ib.faces; v++) {
            _cntTotal += 1;
            if (pas_dice_pip_count(_ib, v) == v) _cntOK += 1;
            // Symmetry is claimed only on an ODD lattice, where a centre position exists. On an
            // even lattice an odd value has nowhere to put its odd pip, and the generator says so
            // rather than the suite asserting something that cannot be true.
            if ((_ib.lat & 1) == 1) {
                _symTotal += 1;
                if (pas_dice_symmetric(_ib, v)) _symOK += 1;
            }
        }
        if ((_ib.lat & 1) == 1) _oddLat += 1;
    }
    pas_st_ok(_r, _cntOK == _cntTotal,
        "dice: " + string(_cntTotal - _cntOK) + " faces carry the wrong number of pips");
    pas_st_ok(_r, _symOK == _symTotal,
        "dice: " + string(_symTotal - _symOK) + " odd-lattice faces are not point-symmetric");
    // VACUITY GUARD: odd lattices must actually occur, or the symmetry arm ran over nothing.
    pas_st_ok(_r, _oddLat > PAS_ST_SEEDS * 0.3,
        "dice: only " + string(_oddLat) + " boards used an odd lattice, so symmetry was barely tested");

    // ⛔⛔ THE FELT NAP MUST STAY ON THE TABLE. It ran from v = -0.2 to v = 1.4 in the first build,
    // so on the dice store sheet the pile crossed the page and struck through the sheet's own
    // title. A wash emits no geometry, so nothing but this can see it - the rows are computed in
    // pas_dice_nap_v precisely so a test can reach them (Hearth's law).
    //
    // Swept over three very different frame shapes, because the row count is derived from the
    // frame and "it looked fine" only ever tested the one rect that happened to be big.
    var _napShapes = [ pas_map(0, 0, 1600, 520), pas_map(0, 0, 300, 300), pas_map(0, 0, 90, 40) ];
    var _napIn = 0, _napTotal = 0, _napRows = 0;
    for (var s = 0; s < 40; s++) {
        var _nb = pas_dice_board(77000 + s * 41, {});
        for (var _si = 0; _si < array_length(_napShapes); _si++) {
            var _nf = _napShapes[_si];
            var _nr = pas_dice_nap_rows(_nf);
            _napRows += _nr;
            for (var k = 0; k < _nr; k++) {
                var _nv2 = pas_dice_nap_v(_nf, _nb, k);
                _napTotal += 1;
                if (_nv2[0] >= 0 && _nv2[0] <= 1 && _nv2[1] >= 0 && _nv2[1] <= 1) _napIn += 1;
            }
        }
    }
    pas_st_ok(_r, _napIn == _napTotal,
        "dice: " + string(_napTotal - _napIn) + " nap strokes fall outside the table");
    // VACUITY GUARD: there must BE strokes, or "all inside" is a statement about nothing.
    pas_st_ok(_r, _napRows > 200,
        "dice: only " + string(_napRows) + " nap strokes across 120 frames, so the arm tested little");

    // ============================================================================================
    // STAGE 7 - CIRCUIT. Reachable with the gates open, and NOT trivially so.
    // ============================================================================================
    global.pas_stage = 7;
    var _ciOK = 0, _ciTotal = 0, _ciTrivial = 0, _minSep = 999;
    for (var s = 0; s < PAS_ST_SEEDS; s++) {
        var _cb = pas_circuit_board(15000 + s * 17, {});
        _ciTotal += 1;
        if (_cb.solved) _ciTrivial += 1;          // solved BEFORE any gate was opened
        // open every gate and ask the INDEPENDENT search
        for (var i = 0; i < array_length(_cb.nodes); i++) {
            if (_cb.nodes[i].kind == PAS_CI_GATE) _cb.nodes[i].open = true;
        }
        if (pas_circuit_reach(_cb)) _ciOK += 1;
        for (var i = 0; i < array_length(_cb.nodes); i++) {
            for (var j = i + 1; j < array_length(_cb.nodes); j++) {
                var _sep = abs(_cb.nodes[i].gx - _cb.nodes[j].gx)
                         + abs(_cb.nodes[i].gy - _cb.nodes[j].gy);
                if (_sep < _minSep) _minSep = _sep;
            }
        }
    }
    _extra.pairMinSep = _minSep;
    _extra.ciTrivial = _ciTrivial;
    pas_st_ok(_r, _ciOK == _ciTotal,
        "circuit: " + string(_ciTotal - _ciOK) + " boards are unsolvable with every gate open");
    // VACUITY GUARD: if most boards were already solved the arm above proves nothing about gates.
    pas_st_ok(_r, _ciTrivial < _ciTotal * 0.15,
        "circuit: " + string(_ciTrivial) + " of " + string(_ciTotal) + " boards need no gate opened");
    pas_st_ok(_r, _minSep >= 3, "circuit: two nodes only " + string(_minSep) + " cells apart");

    // ============================================================================================
    // STAGE 8 - RANGE. Ring progression, and a level-of-detail rule that CAN change its answer.
    // ============================================================================================
    global.pas_stage = 8;
    var _rgOK = 0, _rgTotal = 0;
    var _lodMoved = 0, _lodTotal = 0;
    for (var s = 0; s < 80; s++) {
        var _gb = pas_range_board(41000 + s * 19, {});
        for (var i = 0; i < array_length(_gb.targets); i++) {
            var _t = _gb.targets[i];
            _rgTotal += 1;
            var _mono = true;
            for (var k = 1; k < _t.rings; k++) if (_t.radii[k] <= _t.radii[k - 1]) _mono = false;
            if (_mono && abs(_t.radii[_t.rings - 1] - 1) < PAS_ST_EPS) _rgOK += 1;
            _lodTotal += 1;
            var _near = pas_range_rings(_t, 400);
            var _far  = pas_range_rings(_t, 12);
            if (_near > _far) _lodMoved += 1;
            _extra.lodNear = _near; _extra.lodFar = _far;
        }
    }
    pas_st_ok(_r, _rgOK == _rgTotal,
        "range: " + string(_rgTotal - _rgOK) + " faces have a bad ring progression");

    // ⛔⛔ CONTAINMENT. THIS ROOM DREW OUTSIDE ITS OWN RECT AND SHIPPED IT TO A STORE SHEET.
    // MEASURED 2026-09-03: a lane spread of 1.72 put the outermost guide at u = -0.36, so two white
    // diagonals ran off the board, out of the cabinet, and across the neighbouring rooms' cabinets
    // on the eight-room sheet - under 684 green assertions, because every number the generator
    // produced was correct and the defect was entirely in WHERE a mass sat.
    //
    // The picture is unreachable from a test, so the CONTRACT is what is tested: every foot and
    // every guide, on every generated board, inside the unit square. This wing has the same law for
    // Hearth's light washes and Welkin's rainbow, both of which drew outside the rect they were
    // handed while every containment assertion beside them passed.
    var _rgIn = 0, _rgInTotal = 0, _worstU = 0.5;
    for (var s = 0; s < PAS_ST_SEEDS; s++) {
        var _gb2 = pas_range_board(43000 + s * 37, {});
        for (var i = 0; i < array_length(_gb2.targets); i++) {
            var _p2 = pas_range_foot(_gb2, _gb2.targets[i].lane, _gb2.targets[i].dist);
            _rgInTotal += 1;
            if (_p2[0] >= 0 && _p2[0] <= 1 && _p2[1] >= 0 && _p2[1] <= 1) _rgIn += 1;
            if (abs(_p2[0] - 0.5) > abs(_worstU - 0.5)) _worstU = _p2[0];
        }
        for (var i = 0; i <= _gb2.lanes; i++) {
            var _gu = pas_range_guide_u(_gb2, i);
            _rgInTotal += 1;
            if (_gu >= 0 && _gu <= 1) _rgIn += 1;
            if (abs(_gu - 0.5) > abs(_worstU - 0.5)) _worstU = _gu;
        }
    }
    _extra.rangeWorstU = _worstU;
    pas_st_ok(_r, _rgIn == _rgInTotal,
        "range: " + string(_rgInTotal - _rgIn) + " feet or guides fall outside the board"
        + " (worst u " + string_format(_worstU, 1, 3) + ")");
    // VACUITY GUARD: the sweep must actually reach the edges, or "inside" is trivially true.
    pas_st_ok(_r, abs(_worstU - 0.5) > 0.30,
        "range: the widest lane only reaches u " + string_format(_worstU, 1, 3)
        + ", so the containment arm is barely testing anything");
    // ⛔ THE CHITIN GUARD. A level-of-detail rule that cannot change its answer is not one - that
    // wing shipped a vein-reduction loop which had never executed once in the product's life, and
    // it was caught by exactly this assertion and by nothing else.
    pas_st_ok(_r, _lodMoved == _lodTotal,
        "range: the ring level-of-detail rule did not respond to size on "
        + string(_lodTotal - _lodMoved) + " faces");

    // ============================================================================================
    // STAGE 9 - WHEEL. The maker's rules hold on the FINISHED ring.
    // ============================================================================================
    global.pas_stage = 9;
    var _whOK = 0, _whTotal = 0;
    var _whFirstBad = "";
    for (var s = 0; s < PAS_ST_SEEDS; s++) {
        var _wb = pas_wheel_board(61000 + s * 23, {});
        _whTotal += 1;
        var _v = pas_wheel_rules_ok(_wb);
        if (_v == "") _whOK += 1;
        else if (_whFirstBad == "") _whFirstBad = "seed " + string(61000 + s * 23) + ": " + _v;
        // the flapper reads the segment whose centre is at the top
        var _seg = pas_wheel_segment_at(_wb, 0);
        pas_st_ok(_r, _seg >= 0 && _seg < _wb.segs, "wheel: segment_at left the ring");
    }
    pas_st_ok(_r, _whOK == _whTotal,
        "wheel: " + string(_whTotal - _whOK) + " rings break a maker rule. " + _whFirstBad);

    // ============================================================================================
    // STAGE 10 - BAGATELLE. The cups are priced from a MEASURED profile, and the field is not flat.
    // ============================================================================================
    global.pas_stage = 10;
    var _bgOK = 0, _bgTotal = 0, _spread = 0, _bgN = 0;
    for (var s = 0; s < 60; s++) {
        var _bb = pas_bagatelle_board(51000 + s * 29, {});
        var _prof = pas_bagatelle_profile(_bb, 120);
        var _reached = 0, _lo2 = 999999, _hi2 = 0;
        for (var i = 0; i < _bb.cupn; i++) {
            if (_prof[i] > 0) _reached += 1;
            if (_bb.cupval[i] < _lo2) _lo2 = _bb.cupval[i];
            if (_bb.cupval[i] > _hi2) _hi2 = _bb.cupval[i];
        }
        _bgTotal += 1;
        // VACUITY GUARD: a field where every ball lands in one cup would make the pricing
        // meaningless AND would make every value identical - both would pass a weaker assertion.
        if (_reached >= 2) _bgOK += 1;
        _spread += (_hi2 - _lo2); _bgN += 1;
        // The whole field must be inside the table.
        //
        // ⚠️ SAID PLAINLY: since the pin layout was fixed to SOLVE for the space available rather
        // than clamp afterwards, this is TRUE BY CONSTRUCTION and is therefore a REGRESSION guard,
        // not a live finding. That is exactly the vacuous-green shape this suite exists to prevent,
        // so it is paired below with a guard proving the check can still say NO.
        pas_st_ok(_r, pas_st_pins_inside(_bb), "bagatelle: a pin stands outside the rails");
    }
    // VACUITY GUARD for the arm above. It found 44 real escapes on this suite's first run and it
    // must still be able to; a check that has only ever passed is not a check.
    var _esc = pas_bagatelle_board(4321, {});
    _esc.pins[0].u = _esc.wall - 0.05;
    pas_st_ok(_r, !pas_st_pins_inside(_esc),
        "the pin-containment check did not fire on a pin moved outside the rail");
    _extra.cupSpread = _spread / max(1, _bgN);
    pas_st_ok(_r, _bgOK == _bgTotal,
        "bagatelle: " + string(_bgTotal - _bgOK) + " fields funnel every ball into one cup");
    pas_st_ok(_r, _extra.cupSpread > 5,
        "bagatelle: mean cup value spread is only " + string_format(_extra.cupSpread, 1, 1)
        + ", so the rank is not pricing anything");

    // ⛔ A SPREAD IS NOT A RANK. MEASURED on the store sheet: a seven-cup board priced 45/45/45/30/
    // 45/35/5 - a spread of 40, comfortably past the arm above, over a rank in which FOUR CUPS TIE.
    // The cause was that the drop snapped to each pin and forgot the ball's own position, so nearly
    // every sample landed in the same two cups and every other cup was equally "rare".
    //
    // ⭐ The arm above measures the RANGE of a distribution and reads as a statement about its
    // SHAPE. Counting distinct values is the property the room actually claims.
    var _distinctSum = 0, _distinctN = 0, _worstDistinct = 99;
    for (var s = 0; s < 60; s++) {
        var _bb2 = pas_bagatelle_board(52000 + s * 43, {});
        var _seen2 = [];
        for (var i = 0; i < _bb2.cupn; i++) {
            var _new = true;
            for (var k = 0; k < array_length(_seen2); k++) {
                if (_seen2[k] == _bb2.cupval[i]) { _new = false; break; }
            }
            if (_new) array_push(_seen2, _bb2.cupval[i]);
        }
        var _dn = array_length(_seen2);
        _distinctSum += _dn; _distinctN += 1;
        if (_dn < _worstDistinct) _worstDistinct = _dn;
    }
    _extra.cupDistinct = _distinctSum / max(1, _distinctN);
    pas_st_ok(_r, _extra.cupDistinct >= 3.5,
        "bagatelle: a board prices its cups at only "
        + string_format(_extra.cupDistinct, 1, 2) + " distinct values on average"
        + " (worst board " + string(_worstDistinct) + ")");

    // ============================================================================================
    // STAGE 11 - TANGRAM. Convex AND complete. See the header for why both.
    // ============================================================================================
    global.pas_stage = 11;
    var _tgConvex = 0, _tgTotal = 0, _tgArea = 0, _tgAreaTotal = 0;
    for (var s = 0; s < PAS_ST_SEEDS; s++) {
        var _tb = pas_tangram_board(71000 + s * 31, {});
        var _whole = pas_tangram_area(_tb.outline);
        var _sumA = 0;
        for (var i = 0; i < array_length(_tb.pieces); i++) {
            _tgTotal += 1;
            if (pas_tangram_convex(_tb.pieces[i].pts)) _tgConvex += 1;
            _sumA += _tb.pieces[i].area;
        }
        _tgAreaTotal += 1;
        // 0.5% of the figure. Well above the epsilon, and tight enough that one lost wedge fires.
        if (abs(_sumA - _whole) < _whole * 0.005) _tgArea += 1;
        pas_st_ok(_r, pas_tangram_convex(_tb.outline), "tangram: the outline itself is concave");
    }
    pas_st_ok(_r, _tgConvex == _tgTotal,
        "tangram: " + string(_tgTotal - _tgConvex) + " pieces are concave, so pas_poly would span them");
    pas_st_ok(_r, _tgArea == _tgAreaTotal,
        "tangram: " + string(_tgAreaTotal - _tgArea) + " dissections lost area");
    // VACUITY GUARD on the convexity check: it must be able to say NO.
    pas_st_ok(_r, !pas_tangram_convex([ 0, 0, 1, 0, 0.5, 0.4, 1, 1, 0, 1 ]),
        "the convexity check passed a deliberately concave polygon");

    // ============================================================================================
    // STAGE 12 - THE CABINET. Every room in the ONE list answers all five dispatchers.
    // ============================================================================================
    global.pas_stage = 12;
    var _rooms = pas_rooms();
    for (var i = 0; i < array_length(_rooms); i++) {
        var _rm = _rooms[i];
        var _bd = pas_room_board(_rm, 1234 + i * 97, {});
        pas_st_ok(_r, is_struct(_bd), "cabinet: no board generator for room " + _rm);
        if (!is_struct(_bd)) continue;
        pas_st_ok(_r, _bd.room == _rm, "cabinet: room " + _rm + " built a board labelled " + string(_bd.room));
        pas_st_ok(_r, string_length(pas_room_label(_rm, _bd)) > 4, "cabinet: no label for room " + _rm);
        pas_st_ok(_r, pas_room_aspect(_rm, _bd) > 0.1, "cabinet: no aspect for room " + _rm);
        pas_st_ok(_r, string_length(pas_board_fingerprint(_rm, _bd)) > 4,
            "cabinet: no fingerprint for room " + _rm);
        // ⛔ THE ARM THAT CATCHES A MISSING DISPATCH. pas_room_step returns "" for a name it does
        // not know, so a room left out of that switch fires HERE, by name, instead of silently
        // doing nothing when a player presses a button.
        pas_st_ok(_r, pas_room_step(_rm, _bd, pas_input("key", -1, -1, "auto")) != "",
            "cabinet: room " + _rm + " has no step dispatch");
    }

    // the well is cut to the board, not the other way round
    var _w1 = pas_cabinet_well(0, 0, 1000, 800, 2.0);
    var _w2 = pas_cabinet_well(0, 0, 1000, 800, 0.5);
    pas_st_ok(_r, abs(_w1[2] / _w1[3] - 2.0) < 0.01, "cabinet: the well did not honour a wide aspect");
    pas_st_ok(_r, abs(_w2[2] / _w2[3] - 0.5) < 0.01, "cabinet: the well did not honour a tall aspect");
    var _op = pas_cabinet_opening();
    pas_st_ok(_r, _w1[2] <= _op[2] * 1000 + 0.5 && _w1[3] <= _op[3] * 800 + 0.5,
        "cabinet: the board escaped the opening");

    // ============================================================================================
    // STAGE 13 - THE VOLUME CLAIM. Forty boards, all structurally distinct.
    // ============================================================================================
    global.pas_stage = 13;
    var _prints = [], _names = [];
    for (var i = 0; i < array_length(_rooms); i++) {
        for (var s = 0; s < PAS_ST_VOLUME_SEEDS; s++) {
            var _sd = 500000 + i * 7919 + s * 104729;
            var _bd2 = pas_room_board(_rooms[i], _sd, {});
            if (!is_struct(_bd2)) continue;
            array_push(_prints, pas_board_fingerprint(_rooms[i], _bd2));
            array_push(_names, _rooms[i] + "@" + string(_sd));
        }
    }
    // ⛔ NAME THE COLLIDING PAIR, DO NOT JUST COUNT. The first run of this suite reported
    // "39 of 40 distinct" and that number is useless on its own - it says a collision exists and
    // nothing about which room or which seeds, so the next step is a hunt. This factory's standing
    // lesson is to print what the check actually RESOLVED TO, never only what it was asked.
    var _dis = 0, _collide = "";
    for (var i = 0; i < array_length(_prints); i++) {
        var _uniq = true;
        for (var j = 0; j < i; j++) {
            if (_prints[j] == _prints[i]) {
                _uniq = false;
                if (_collide == "") {
                    _collide = " first collision: " + _names[j] + " vs " + _names[i];
                }
                break;
            }
        }
        if (_uniq) _dis += 1;
    }
    _extra.volumeBoards = array_length(_prints);
    _extra.volumeDistinct = _dis;
    pas_st_ok(_r, _extra.volumeBoards >= 40,
        "volume: only " + string(_extra.volumeBoards) + " boards were generated");
    pas_st_ok(_r, _dis == _extra.volumeBoards,
        "volume: only " + string(_dis) + " of " + string(_extra.volumeBoards)
        + " boards are distinct." + _collide);

    // ============================================================================================
    // STAGE 14 - PLAYABILITY, and BREAK IT. Every room is driven, then abused.
    // ============================================================================================
    global.pas_stage = 14;
    for (var i = 0; i < array_length(_rooms); i++) {
        var _rm2 = _rooms[i];
        var _bd3 = pas_room_board(_rm2, 8080 + i * 131, {});
        if (!is_struct(_bd3)) continue;
        var _silent = 0;
        for (var k = 0; k < 60; k++) {
            if (pas_room_step(_rm2, _bd3, pas_input("key", -1, -1, "auto")) == "") _silent += 1;
        }
        pas_st_ok(_r, _silent == 0,
            "room " + _rm2 + " returned an empty result " + string(_silent) + " times while being played");

        // BREAK IT. Nonsense that a buyer's game will genuinely send: a bare string nobody
        // implemented, an empty struct, and coordinates far outside the board.
        pas_room_step(_rm2, _bd3, "qwertyuiop");
        pas_room_step(_rm2, _bd3, {});
        pas_room_step(_rm2, _bd3, pas_input("press", -9, -9, ""));
        pas_room_step(_rm2, _bd3, pas_input("press", 99, 99, ""));
        pas_room_step(_rm2, _bd3, pas_input("press", 0.5, 0.5, ""));
        pas_st_ok(_r, is_struct(_bd3), "room " + _rm2 + " lost its board under nonsense input");

        // a degenerate request must produce a board, not a crash and not a plausible-looking lie
        var _tiny = pas_room_board(_rm2, 5, { w : 1, h : 1, n : 0, rows : 0, pieces : 0,
                                              sectors : 1, segs : 1, lanes : 0, gw : 1, gh : 1 });
        pas_st_ok(_r, is_struct(_tiny), "room " + _rm2 + " could not build a degenerate board");
    }

    // a cabinet drives end to end
    var _cab = pas_cabinet_new(31337);
    pas_st_ok(_r, array_length(_cab.boards) == pas_room_count(), "cabinet: wrong board count");
    var _allBoards = true;
    for (var i = 0; i < array_length(_cab.boards); i++) {
        pas_cabinet_select(_cab, i);
        if (!is_struct(pas_cabinet_board(_cab))) _allBoards = false;
        if (pas_cabinet_step(_cab, pas_input("key", -1, -1, "auto")) == "") _allBoards = false;
    }
    pas_st_ok(_r, _allBoards, "cabinet: a room did not build or did not respond");
    // ⛔ AND THE STRIDE: eight rooms seeded from ONE cabinet seed must not collide. This is the
    // first-draw trap from stage 1 arriving where it would actually hurt.
    var _cabPrints = [];
    for (var i = 0; i < pas_room_count(); i++) {
        array_push(_cabPrints, pas_board_fingerprint(pas_room_name(i), _cab.boards[i]));
    }
    var _cabDis = 0;
    for (var i = 0; i < array_length(_cabPrints); i++) {
        var _u2 = true;
        for (var j = 0; j < i; j++) if (_cabPrints[j] == _cabPrints[i]) { _u2 = false; break; }
        if (_u2) _cabDis += 1;
    }
    pas_st_ok(_r, _cabDis == pas_room_count(), "cabinet: two rooms generated the same board");

    // ⛔ THE "I REACHED THE END" MARKER, AND IT IS LOAD-BEARING. A suite that dies partway still
    // writes a pass count, and that count reads exactly like a green run - it is a count of what it
    // got through, not a verdict on the product. run_selftest.ps1 refuses any stage but 99.
    global.pas_stage = 99;
    _r.extra = _extra;
    return _r;
}

/// @desc Is every pin of a bagatelle field inside the rails?
///
/// A named function rather than an inline loop, because the VACUITY GUARD has to call the same code
/// the assertion calls. A guard that re-implements the check tests the guard.
function pas_st_pins_inside(_board) {
    for (var i = 0; i < array_length(_board.pins); i++) {
        if (_board.pins[i].u < _board.wall - PAS_ST_EPS) return false;
        if (_board.pins[i].u > 1 - _board.wall + PAS_ST_EPS) return false;
    }
    return true;
}

/// @desc Do the two halves of every shared wall agree?
///
/// ⛔ THE ARM THE DESIGN PROOF WAS WRITTEN TO JUSTIFY. A wall between two cells is stored TWICE,
/// once in each cell, and pas_maze_solve reads only the NEAR cell's copy. So a carver that removes
/// one side and leaves the other produces a maze that is passable in ONE DIRECTION ONLY - a real,
/// shippable defect that a screenshot cannot show and that a solvability assertion is completely
/// silent about. MEASURED before any GML existed: over 10,000 boards with that defect injected,
/// this property fired on 10,000 and solvability fired on none.
function pas_st_walls_agree(_board) {
    for (var cy = 0; cy < _board.h; cy++) {
        for (var cx = 0; cx < _board.w; cx++) {
            var _c = _board.cells[pas_maze_idx(_board, cx, cy)];
            if (cx + 1 < _board.w) {
                var _e = _board.cells[pas_maze_idx(_board, cx + 1, cy)];
                var _mine = ((_c & PAS_MAZE_E) != 0), _theirs = ((_e & PAS_MAZE_W) != 0);
                if (_mine != _theirs) return false;
            }
            if (cy + 1 < _board.h) {
                var _s = _board.cells[pas_maze_idx(_board, cx, cy + 1)];
                var _m2 = ((_c & PAS_MAZE_S) != 0), _t2 = ((_s & PAS_MAZE_N) != 0);
                if (_m2 != _t2) return false;
            }
        }
    }
    return true;
}

/// ================================================================================================
/// THE RESULT FILE
///
/// ⛔ A SANDBOXED FILE WRITE IS THE ONLY ROUTE THAT SURVIVES A RELEASE BUILD. Measured in this wing:
/// show_debug_message plus -debugoutput writes only engine boot lines, and game_end(n) does not
/// propagate n to the process exit code.
///
/// ⭐ IT WRITES NUMBERS, NOT ONLY VERDICTS. The searched-ring margin, the first-draw spread and the
/// distinct-board count are all printed, so the next session RE-DERIVES them instead of inheriting a
/// threshold somebody liked.
/// ================================================================================================
function pas_selftest_write(_res) {
    var _f = file_text_open_write("pas_selftest.json");
    var _notes = "";
    for (var i = 0; i < array_length(_res.notes); i++) {
        if (i > 0) _notes += " | ";
        _notes += string_replace_all(string(_res.notes[i]), "\"", "'");
    }
    var _x = _res.extra;
    file_text_write_string(_f,
        "{\"pass\":" + string(_res.pass)
        + ",\"fail\":" + string(_res.fail)
        + ",\"stage\":" + string(global.pas_stage)
        + ",\"epsilon\":" + string_format(_x.epsilon, 1, 12)
        + ",\"rooms\":" + string(_x.rooms)
        + ",\"themes\":" + string(_x.themes)
        + ",\"firstDrawSpan\":" + string_format(_x.firstDrawHi - _x.firstDrawLo, 1, 4)
        + ",\"ringSearched\":" + string_format(_x.ringGen, 1, 1)
        + ",\"ringRandom\":" + string_format(_x.ringRand, 1, 1)
        + ",\"ringWorst\":" + string(_x.ringWorst)
        + ",\"circuitMinSep\":" + string(_x.pairMinSep)
        + ",\"circuitTrivial\":" + string(_x.ciTrivial)
        + ",\"cupSpread\":" + string_format(_x.cupSpread, 1, 1)
        + ",\"cupDistinct\":" + string_format(_x.cupDistinct, 1, 2)
        + ",\"lodNear\":" + string(_x.lodNear)
        + ",\"lodFar\":" + string(_x.lodFar)
        + ",\"rangeWorstU\":" + string_format(_x.rangeWorstU, 1, 3)
        + ",\"volumeBoards\":" + string(_x.volumeBoards)
        + ",\"volumeDistinct\":" + string(_x.volumeDistinct)
        + ",\"version\":\"" + PAS_VERSION + "\""
        + ",\"notes\":\"" + _notes + "\"}");
    file_text_close(_f);
}
