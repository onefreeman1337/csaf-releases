{
  "$GMScript": "v1",
  "%Name": "pas_circuit",
  "name": "pas_circuit",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}