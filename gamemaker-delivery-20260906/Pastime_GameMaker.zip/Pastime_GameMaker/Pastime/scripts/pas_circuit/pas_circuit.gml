/// PASTIME - pas_circuit. Room 1 of the cabinet, and the room gm-blackice was folded into.
///
/// Visual language: etched PCB. Right-angle traces on two layers, annular pads with real drill
/// holes, DIP bodies with a pin row and an orientation notch, a hatched ground pour, and silkscreen
/// designators. Nothing here is a rectangle with a label on it.
///
/// ⭐ WHAT IS GENERATED: the NETWORK. Nodes are placed, a spanning tree is grown from the source so
/// the board is connected by construction, extra links are added for loops, and every link is routed
/// as a Manhattan trace with an elbow. The result is a board a player has to READ.
///
/// ⛔ AND SOLVABILITY IS VERIFIED, NEVER ASSUMED - the same discipline as pas_maze and for the same
/// reason. The spanning tree makes a route exist; an assertion that merely restated that would be a
/// check whose only witness is the code it is checking. pas_circuit_reach is an INDEPENDENT
/// breadth-first search over the finished edge list, sharing nothing with the grower, and the suite
/// runs it on every seed with every gate open. If the builder ever strands the sink, it goes red
/// with the seed.
///
/// ⚠️ TWO LAYERS ARE NOT DECORATION, THEY ARE THE FIX FOR A REAL PROBLEM. Manhattan routes cross.
/// On one layer a crossing is a short circuit and reads as a drawing error; on two it is a via and
/// reads as engineering. The layer is assigned at ROUTE time and drawn in two passes, bottom first,
/// so a crossing always resolves the same way rather than depending on iteration order.
/// ================================================================================================

#macro PAS_CI_PAD    0
#macro PAS_CI_GATE   1
#macro PAS_CI_ICE    2
#macro PAS_CI_SOURCE 3
#macro PAS_CI_SINK   4

/// @desc Build a circuit board.
/// @param {real} seed
/// @param {struct} opts  optional: {gw, gh, nodes}
function pas_circuit_board(seed, opts = {}) {
    var _r = pas_rng(seed);

    var _gw = (is_struct(opts) && variable_struct_exists(opts, "gw")) ? opts.gw : pas_rng_int(_r, 8, 11);
    var _gh = (is_struct(opts) && variable_struct_exists(opts, "gh")) ? opts.gh : pas_rng_int(_r, 6, 9);
    if (_gw < 4) _gw = 4;
    if (_gh < 3) _gh = 3;

    var _want = (is_struct(opts) && variable_struct_exists(opts, "nodes"))
        ? opts.nodes : pas_rng_int(_r, 8, 13);

    var board = {
        room   : "circuit",
        seed   : seed,
        gw     : _gw,
        gh     : _gh,
        nodes  : [],
        edges  : [],
        chips  : [],
        pour   : pas_rng_int(_r, 0, 2),      // which corner carries the hatched ground pour
        source : 0,
        sink   : 0,
        moves  : 0,
        solved : false,
        rng    : _r,
    };

    // ---- place nodes on distinct grid cells, never adjacent ---------------
    // Adjacent nodes give a zero-length trace, which draws as a dot and reads as a mistake. The
    // rejection loop is bounded so a dense request degrades to fewer nodes rather than hanging -
    // a generator that can spin is a generator that ships a freeze into a buyer's game.
    var _taken = array_create(_gw * _gh, false);
    var _tries = 0;
    while (array_length(board.nodes) < _want && _tries < _want * 40) {
        _tries += 1;
        var _gx = pas_rng_int(_r, 0, _gw - 1);
        var _gy = pas_rng_int(_r, 0, _gh - 1);
        var _ok = true;
        for (var i = 0; i < array_length(board.nodes); i++) {
            var _o = board.nodes[i];
            if (abs(_o.gx - _gx) + abs(_o.gy - _gy) < 3) { _ok = false; break; }
        }
        if (!_ok) continue;
        _taken[_gy * _gw + _gx] = true;
        array_push(board.nodes, { gx : _gx, gy : _gy, kind : PAS_CI_PAD, open : true, tag : "" });
    }

    var _n = array_length(board.nodes);
    if (_n < 3) {
        // Degenerate. Say so in the struct rather than drawing a plausible-looking empty board.
        board.sink = max(0, _n - 1);
        return board;
    }

    // ---- grow a spanning tree from node 0 ---------------------------------
    var _in = array_create(_n, false);
    _in[0] = true;
    var _tree = [ 0 ];
    var _parent = array_create(_n, -1);
    for (var _k = 1; _k < _n; _k++) {
        // attach the nearest un-attached node to the nearest attached one. Nearest-first keeps
        // traces short and the board legible; a random attachment gives a cat's cradle.
        var _bi = -1, _bj = -1, _bd = 1000000;
        for (var a = 0; a < _n; a++) {
            if (!_in[a]) continue;
            for (var b = 0; b < _n; b++) {
                if (_in[b]) continue;
                var _d = abs(board.nodes[a].gx - board.nodes[b].gx)
                       + abs(board.nodes[a].gy - board.nodes[b].gy);
                if (_d < _bd) { _bd = _d; _bi = a; _bj = b; }
            }
        }
        if (_bj < 0) break;
        _in[_bj] = true;
        _parent[_bj] = _bi;
        array_push(_tree, _bj);
        array_push(board.edges, pas_circuit_route(board, _bi, _bj, _r));
    }

    // ---- source, sink, and the guaranteed route between them --------------
    // The sink is the node FURTHEST from the source through the tree, which is what makes the
    // route long enough to be a puzzle instead of a straight line.
    var _depth = array_create(_n, 0);
    var _far = 0;
    for (var i = 0; i < array_length(_tree); i++) {
        var _v = _tree[i];
        if (_parent[_v] >= 0) _depth[_v] = _depth[_parent[_v]] + 1;
        if (_depth[_v] > _depth[_far]) _far = _v;
    }
    board.source = 0;
    board.sink = _far;
    board.nodes[0].kind = PAS_CI_SOURCE;
    board.nodes[_far].kind = PAS_CI_SINK;

    var _onpath = array_create(_n, false);
    var _at = _far;
    while (_at >= 0) { _onpath[_at] = true; _at = _parent[_at]; }

    // ---- gates on the route, ICE off it -----------------------------------
    // Gates ON the solution path are what the player opens. ICE is placed only OFF it, so a
    // solution always exists - and the suite proves that independently rather than believing it.
    for (var i = 0; i < _n; i++) {
        if (i == board.source || i == board.sink) continue;
        if (_onpath[i]) {
            board.nodes[i].kind = PAS_CI_GATE;
            board.nodes[i].open = false;
        } else if (pas_rng_float(_r) < 0.45) {
            board.nodes[i].kind = PAS_CI_ICE;
        } else if (pas_rng_float(_r) < 0.5) {
            board.nodes[i].kind = PAS_CI_GATE;
            board.nodes[i].open = false;
        }
    }

    // ---- extra links, for loops -------------------------------------------
    var _extra = pas_rng_int(_r, 1, 3);
    for (var e = 0; e < _extra; e++) {
        var _a = pas_rng_int(_r, 0, _n - 1);
        var _b = pas_rng_int(_r, 0, _n - 1);
        if (_a == _b) continue;
        array_push(board.edges, pas_circuit_route(board, _a, _b, _r));
    }

    // ---- silkscreen designators and DIP bodies ----------------------------
    for (var i = 0; i < _n; i++) {
        var _kind = board.nodes[i].kind;
        var _pre = "TP";
        if (_kind == PAS_CI_GATE)   _pre = "Q";
        if (_kind == PAS_CI_ICE)    _pre = "D";
        if (_kind == PAS_CI_SOURCE) _pre = "J";
        if (_kind == PAS_CI_SINK)   _pre = "U";
        board.nodes[i].tag = _pre + string(i + 1);
    }
    var _nchips = pas_rng_int(_r, 1, 3);
    for (var c = 0; c < _nchips; c++) {
        array_push(board.chips, {
            gx  : pas_rng_int(_r, 0, _gw - 3),
            gy  : pas_rng_int(_r, 0, _gh - 2),
            pins: pas_rng_pick(_r, [ 6, 8, 8, 14 ]),
            tag : "U" + string(100 + c),
        });
    }

    board.solved = pas_circuit_reach(board);
    return board;
}

/// @desc Route one Manhattan trace between two nodes and pick its layer.
/// @return {struct} {a, b, layer, pts}  pts is a flat GRID-space path
function pas_circuit_route(_board, _a, _b, _r) {
    var _A = _board.nodes[_a], _B = _board.nodes[_b];
    var _pts;
    var _mode = pas_rng_int(_r, 0, 2);
    if (_mode == 0) {
        _pts = [ _A.gx, _A.gy, _B.gx, _A.gy, _B.gx, _B.gy ];              // horizontal first
    } else if (_mode == 1) {
        _pts = [ _A.gx, _A.gy, _A.gx, _B.gy, _B.gx, _B.gy ];              // vertical first
    } else {
        var _mx = (_A.gx + _B.gx) * 0.5;                                  // a Z, with a mid column
        _pts = [ _A.gx, _A.gy, _mx, _A.gy, _mx, _B.gy, _B.gx, _B.gy ];
    }
    return { a : _a, b : _b, layer : pas_rng_int(_r, 0, 1), pts : _pts };
}

/// @desc Can the signal reach the sink? Breadth-first over the FINISHED edge list.
///
/// Shares nothing with the tree grower above - it does not know a tree was built, and it would find
/// a route through the extra loop links just as happily. That independence is the whole point: two
/// implementations that agree only through the data are evidence, and one implementation asserting
/// its own invariant is not.
function pas_circuit_reach(_board) {
    var _n = array_length(_board.nodes);
    if (_n == 0) return false;
    var _seen = array_create(_n, false);
    var _q = [ _board.source ];
    var _head = 0;
    _seen[_board.source] = true;
    while (_head < array_length(_q)) {
        var _cur = _q[_head];
        _head += 1;
        if (_cur == _board.sink) return true;
        for (var i = 0; i < array_length(_board.edges); i++) {
            var _e = _board.edges[i];
            var _o = -1;
            if (_e.a == _cur) _o = _e.b;
            else if (_e.b == _cur) _o = _e.a;
            if (_o < 0 || _seen[_o]) continue;
            var _k = _board.nodes[_o].kind;
            if (_k == PAS_CI_ICE) continue;                       // ICE never conducts
            if (_k == PAS_CI_GATE && !_board.nodes[_o].open) continue;
            _seen[_o] = true;
            array_push(_q, _o);
        }
    }
    return false;
}

/// @desc Which nodes the signal is currently live at. Used by the renderer, and by the suite.
function pas_circuit_live(_board) {
    var _n = array_length(_board.nodes);
    var _seen = array_create(_n, false);
    if (_n == 0) return _seen;
    var _q = [ _board.source ];
    var _head = 0;
    _seen[_board.source] = true;
    while (_head < array_length(_q)) {
        var _cur = _q[_head];
        _head += 1;
        for (var i = 0; i < array_length(_board.edges); i++) {
            var _e = _board.edges[i];
            var _o = -1;
            if (_e.a == _cur) _o = _e.b;
            else if (_e.b == _cur) _o = _e.a;
            if (_o < 0 || _seen[_o]) continue;
            var _k = _board.nodes[_o].kind;
            if (_k == PAS_CI_ICE) continue;
            if (_k == PAS_CI_GATE && !_board.nodes[_o].open) continue;
            _seen[_o] = true;
            array_push(_q, _o);
        }
    }
    return _seen;
}

/// @desc Toggle the gate nearest the pointer. input is {act:"press", u, v} in board space.
/// @return {string} "opened" | "closed" | "nothing" | "solved"
function pas_circuit_step(_board, _input) {
    if (_board.solved) return "solved";
    var _u = pas_input_u(_input), _v = pas_input_v(_input);
    if (_u < 0 || _v < 0) {
        // "auto": open the first closed gate. A demo that has to be driven by a pointer cannot be
        // exercised by a headless suite, and an unexercised _step is an untested code path.
        for (var i = 0; i < array_length(_board.nodes); i++) {
            if (_board.nodes[i].kind == PAS_CI_GATE && !_board.nodes[i].open) {
                _board.nodes[i].open = true;
                _board.moves += 1;
                _board.solved = pas_circuit_reach(_board);
                return _board.solved ? "solved" : "opened";
            }
        }
        return "nothing";
    }

    var _bi = -1, _bd = 1000000;
    for (var i = 0; i < array_length(_board.nodes); i++) {
        if (_board.nodes[i].kind != PAS_CI_GATE) continue;
        var _p = pas_circuit_node_uv(_board, i);
        var _d = (_p[0] - _u) * (_p[0] - _u) + (_p[1] - _v) * (_p[1] - _v);
        if (_d < _bd) { _bd = _d; _bi = i; }
    }
    if (_bi < 0 || _bd > 0.0064) return "nothing";        // 0.08 board units, squared

    _board.nodes[_bi].open = !_board.nodes[_bi].open;
    _board.moves += 1;
    _board.solved = pas_circuit_reach(_board);
    if (_board.solved) return "solved";
    return _board.nodes[_bi].open ? "opened" : "closed";
}

/// @desc A node's position in BOARD space. One function, so the renderer, the hit test and the
///       suite cannot drift apart - three readers of one convention is exactly where a
///       row/column transposition hides.
function pas_circuit_node_uv(_board, _i) {
    return pas_circuit_grid_uv(_board, _board.nodes[_i].gx, _board.nodes[_i].gy);
}

function pas_circuit_grid_uv(_board, _gx, _gy) {
    var _m = 0.085;
    var _du = (_board.gw > 1) ? (1 - _m * 2) / (_board.gw - 1) : 0;
    var _dv = (_board.gh > 1) ? (1 - _m * 2) / (_board.gh - 1) : 0;
    return [ _m + _gx * _du, _m + _gy * _dv ];
}

function pas_circuit_label(_board) {
    var _gates = 0, _ice = 0;
    for (var i = 0; i < array_length(_board.nodes); i++) {
        if (_board.nodes[i].kind == PAS_CI_GATE) _gates += 1;
        if (_board.nodes[i].kind == PAS_CI_ICE)  _ice += 1;
    }
    return "CIRCUIT  " + string(_board.gw) + "x" + string(_board.gh)
         + "   " + string(array_length(_board.edges)) + " traces"
         + "   " + string(_gates) + " gates  " + string(_ice) + " ICE";
}

function pas_circuit_aspect(_board) {
    return (_board.gh > 0) ? (_board.gw / _board.gh) : 1;
}

/// @desc Draw the board.
function pas_circuit_draw(_board, _x, _y, _w, _h, _pal) {
    var _f = pas_map(_x, _y, _w, _h);
    var _live = pas_circuit_live(_board);
    var _tw = pas_detail(_f, 0.011, 2, 12);      // trace width
    var _pr = 0.026;                              // pad radius, board units

    // -- solder mask ------------------------------------------------------
    pas_rrect(_f, 0, 0, 1, 1, pas_detail(_f, 0.02, 2, 18), _pal.m1);

    // -- ground pour: HATCHED, not solid ----------------------------------
    // ⚠️ TONE IS SPACING (pas_geom law 4). A solid pour is a flat slab across a third of the board;
    // a hatch at a real pixel pitch reads as copper at every size, and the pitch is a PHYSICAL
    // constant with a proportional upper bound, not a fraction - a hatch does not get coarser on a
    // bigger board (Livery's 80 px "fine" engraving).
    var _pitch = pas_detail(_f, 0.020, 5, 16) / max(1, _f.w);
    var _px0 = (_board.pour == 0) ? 0.03 : ((_board.pour == 1) ? 0.55 : 0.03);
    var _py0 = (_board.pour == 2) ? 0.62 : 0.03;
    var _pw = (_board.pour == 0) ? 0.94 : 0.42;
    var _ph = (_board.pour == 0) ? 0.30 : 0.35;
    var _hatch = merge_colour(_pal.m1, _pal.p1, 0.45);
    var _steps = max(2, floor((_pw + _ph) / _pitch));
    for (var i = 0; i < _steps; i++) {
        var _t = i * _pitch;
        var _ax = _px0 + min(_t, _pw), _ay = _py0 + max(0, _t - _pw);
        var _bx = _px0 + max(0, _t - _ph), _by = _py0 + min(_t, _ph);
        pas_line(_f, _ax, _ay, _bx, _by, 1, _hatch);
    }

    // -- DIP bodies -------------------------------------------------------
    for (var c = 0; c < array_length(_board.chips); c++) {
        var _ch = _board.chips[c];
        var _a = pas_circuit_grid_uv(_board, _ch.gx, _ch.gy);
        var _b = pas_circuit_grid_uv(_board, _ch.gx + 2, _ch.gy + 1);
        var _cw = _b[0] - _a[0], _chh = _b[1] - _a[1];
        // pins first, so the body sits ON them
        var _np = _ch.pins div 2;
        for (var p = 0; p < _np; p++) {
            var _pu = _a[0] + _cw * ((p + 0.5) / _np);
            pas_line(_f, _pu, _a[1] - 0.018, _pu, _a[1] + 0.012, _tw * 0.8, _pal.b3);
            pas_line(_f, _pu, _a[1] + _chh - 0.012, _pu, _a[1] + _chh + 0.018, _tw * 0.8, _pal.b3);
        }
        // ⛔ THE BODY IS A FIXED MATERIAL, NOT A BED STOP. A DIP is black epoxy whatever colour
        // the solder mask under it happens to be, and taking it from the bed ramp made it a pale
        // slab with an unreadable part number on the card, vellum and chalk themes. The cabinet's
        // darkest wood is fixed across all twelve, which is the behaviour a physical component
        // wants - the same reason the cabinet itself does not change per theme.
        pas_plate(_f, _a[0], _a[1], _cw, _chh, pas_detail(_f, 0.006, 1, 5),
                  _pal.w0, _pal.w2, _pal.w0);
        // the orientation notch. A DIP without one is a black rectangle; with one it is a chip.
        pas_disc(_f, _a[0] + _cw * 0.12, _a[1] + _chh * 0.5, 0.012, _pal.w3);
        pas_text_fit(_f, _ch.tag, _a[0] + _cw * 0.58, _a[1] + _chh * 0.5,
                     _cw * 0.7, _pal.b3, fa_center, fa_middle);
    }

    // -- traces, BOTTOM layer then TOP ------------------------------------
    // Two passes rather than one loop with a colour lookup: a crossing must always resolve the same
    // way, and "whichever edge happened to come later" is not a rule.
    for (var _layer = 0; _layer <= 1; _layer++) {
        var _col = (_layer == 0) ? merge_colour(_pal.p0, _pal.m0, 0.35) : _pal.p3;
        var _wid = (_layer == 0) ? _tw * 0.8 : _tw;
        for (var i = 0; i < array_length(_board.edges); i++) {
            var _e = _board.edges[i];
            if (_e.layer != _layer) continue;
            var _pts = [];
            for (var k = 0; k < array_length(_e.pts); k += 2) {
                var _uv = pas_circuit_grid_uv(_board, _e.pts[k], _e.pts[k + 1]);
                array_push(_pts, _uv[0], _uv[1]);
            }
            // Live traces glow. The signal is the state of play and it has to be visible without
            // reading the numbers, or the board is a diagram rather than a game.
            var _hot = _live[_e.a] && _live[_e.b];
            pas_stroke(_f, _pts, _wid, _hot ? _pal.p4 : _col);
        }
    }

    // -- vias where traces of different layers cross ----------------------
    // Drawn at every trace CORNER, which is where a real board puts them and where the eye expects
    // the change of layer to happen.
    for (var i = 0; i < array_length(_board.edges); i++) {
        var _e = _board.edges[i];
        for (var k = 2; k < array_length(_e.pts) - 2; k += 2) {
            var _uv = pas_circuit_grid_uv(_board, _e.pts[k], _e.pts[k + 1]);
            pas_disc(_f, _uv[0], _uv[1], _pr * 0.34, _pal.b2);
            pas_disc(_f, _uv[0], _uv[1], _pr * 0.15, _pal.m0);
        }
    }

    // -- nodes ------------------------------------------------------------
    for (var i = 0; i < array_length(_board.nodes); i++) {
        var _nd = _board.nodes[i];
        var _p = pas_circuit_node_uv(_board, i);
        var _u = _p[0], _v = _p[1];
        var _on = _live[i];

        if (_nd.kind == PAS_CI_ICE) {
            // ICE is a hexagon, not a disc: it must be identifiable by SILHOUETTE, because a
            // difference drawn INSIDE a filled shape is not a difference in the shape - this
            // wing measured two species at Jaccard distance exactly zero for want of that.
            var _hex = [];
            for (var k = 0; k < 6; k++) {
                var _a = degtorad(k * 60 + 30);
                array_push(_hex,
                    _u + cos(_a) * _pr * 1.35 * (_f.s / max(1, _f.w)),
                    _v + sin(_a) * _pr * 1.35 * (_f.s / max(1, _f.h)));
            }
            pas_poly(_f, _hex, _pal.q1);
            var _hi = [];
            for (var k = 0; k < 6; k++) {
                var _a2 = degtorad(k * 60 + 30);
                array_push(_hi,
                    _u + cos(_a2) * _pr * 1.05 * (_f.s / max(1, _f.w)),
                    _v + sin(_a2) * _pr * 1.05 * (_f.s / max(1, _f.h)));
            }
            pas_poly(_f, _hi, _pal.q3);
            var _cr = _pr * 0.55;
            pas_line(_f, _u - _cr * (_f.s / max(1, _f.w)), _v - _cr * (_f.s / max(1, _f.h)),
                         _u + _cr * (_f.s / max(1, _f.w)), _v + _cr * (_f.s / max(1, _f.h)),
                         _tw * 0.9, _pal.m0);
            pas_line(_f, _u - _cr * (_f.s / max(1, _f.w)), _v + _cr * (_f.s / max(1, _f.h)),
                         _u + _cr * (_f.s / max(1, _f.w)), _v - _cr * (_f.s / max(1, _f.h)),
                         _tw * 0.9, _pal.m0);
        } else if (_nd.kind == PAS_CI_GATE) {
            // A gate is a SQUARE pad - a second silhouette, distinct from both the round test
            // points and the hexagonal ICE.
            var _sq = _pr * 1.15;
            var _su = _sq * (_f.s / max(1, _f.w)), _sv = _sq * (_f.s / max(1, _f.h));
            pas_rrect(_f, _u - _su, _v - _sv, _su * 2, _sv * 2,
                      pas_detail(_f, 0.004, 1, 4), _pal.b2);
            pas_rrect(_f, _u - _su * 0.62, _v - _sv * 0.62, _su * 1.24, _sv * 1.24,
                      pas_detail(_f, 0.003, 1, 3), _nd.open ? _pal.p4 : _pal.m0);
        } else if (_nd.kind == PAS_CI_SOURCE || _nd.kind == PAS_CI_SINK) {
            // Source and sink are the two ends of the puzzle and get the biggest pads on the board.
            pas_disc(_f, _u, _v, _pr * 1.45, _pal.b3);
            pas_disc(_f, _u, _v, _pr * 1.05, _on ? _pal.p4 : _pal.m0);
            pas_ring(_f, _u, _v, _pr * 1.75, _tw * 0.7,
                     (_nd.kind == PAS_CI_SOURCE) ? _pal.p3 : _pal.q3);
        } else {
            // A test point: an annular pad with a real drill hole through it.
            pas_disc(_f, _u, _v, _pr, _pal.b3);
            pas_disc(_f, _u, _v, _pr * 0.42, _pal.m1);
        }

        pas_text_fit(_f, _nd.tag, _u, _v + _pr * 2.4 * (_f.s / max(1, _f.h)),
                     0.10, _pal.guide, fa_center, fa_middle);
    }
}
