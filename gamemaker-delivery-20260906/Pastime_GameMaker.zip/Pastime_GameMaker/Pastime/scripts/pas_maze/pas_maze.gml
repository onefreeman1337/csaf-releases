/// PASTIME - pas_maze. Room 4 of the cabinet, and the REFERENCE IMPLEMENTATION of the contract.
///
/// Every room in this cabinet implements the same four functions, and this file is the one the
/// other seven are modelled on:
///
///     pas_<room>_board(seed, opts)          -> pure data. NO drawing, NO engine calls.
///     pas_<room>_draw(board, x, y, w, h)    -> draws that struct and ONLY reads it.
///     pas_<room>_step(board, input)         -> advances play; pure over (board, input).
///     pas_<room>_label(board)               -> the cabinet label for this board.
///
/// ⛔ WHY `_board` TAKES NO ENGINE HANDLES AND CREATES NONE. GML cannot be unit-tested outside the
/// engine, so the only defence this wing has is to push logic into functions whose behaviour is
/// decided entirely by their arguments. A `ds_queue` here would be an engine handle: it would leak
/// if an assertion threw mid-generation, and it would make the generator's result depend on state
/// that is not its arguments. The flood fill below uses a plain array as a queue for that reason
/// and for no other.
///
/// ⭐ SOLVABILITY IS VERIFIED, NOT ASSUMED, AND THAT IS A DELIBERATE DESIGN CHOICE.
/// The carver is a randomised depth-first backtracker, which produces a PERFECT maze - every cell
/// reachable, exactly one route between any two cells - so "is it solvable?" is true by
/// construction. An assertion that merely restated the carver's own invariant would be the trap
/// this factory has paid for repeatedly: a check whose only witness is the code it is checking.
/// So the solution path is found by an INDEPENDENT breadth-first search over the finished wall
/// data. Two implementations that share nothing but the wall array. If the carver ever leaves a
/// cell walled off, the BFS returns no path and the suite goes red with the failing seed.

#macro PAS_MAZE_N 1
#macro PAS_MAZE_E 2
#macro PAS_MAZE_S 4
#macro PAS_MAZE_W 8

/// @desc Index of a cell. Kept in one place so the ordering convention cannot drift between the
///       carver, the BFS and the renderer - three readers of the same array is exactly where a
///       row/column transposition hides.
function pas_maze_idx(board, cx, cy) {
    return (cy * board.w) + cx;
}

function pas_maze_in_bounds(board, cx, cy) {
    return (cx >= 0) && (cy >= 0) && (cx < board.w) && (cy < board.h);
}

/// @desc Build a maze board from a seed.
/// @param {real} seed
/// @param {struct} opts  optional: {w, h, braid}  braid 0..1 = fraction of dead ends opened
/// @return {struct} board
function pas_maze_board(seed, opts = {}) {
    var _w     = is_struct(opts) && variable_struct_exists(opts, "w")     ? opts.w     : 11;
    var _h     = is_struct(opts) && variable_struct_exists(opts, "h")     ? opts.h     : 11;
    var _braid = is_struct(opts) && variable_struct_exists(opts, "braid") ? opts.braid : 0;

    // A maze narrower than 2 in either axis has no interior and no meaningful route, and silently
    // "succeeding" on one would hand the renderer a degenerate board. Clamp and record that we did,
    // so the label can say so rather than the board quietly lying about its size.
    if (_w < 2) _w = 2;
    if (_h < 2) _h = 2;

    var _r = pas_rng(seed);
    var _n = _w * _h;

    var board = {
        room    : "maze",
        seed    : seed,
        w       : _w,
        h       : _h,
        braid   : _braid,
        // every cell starts fully walled; the carver removes walls
        cells   : array_create(_n, PAS_MAZE_N | PAS_MAZE_E | PAS_MAZE_S | PAS_MAZE_W),
        start   : 0,
        exit    : _n - 1,
        path    : [],
        cursor  : 0,
        moves   : 0,
        solved  : false,
    };

    // ---- carve: randomised depth-first backtracker -----------------------
    var _visited = array_create(_n, false);
    var _stack   = [ 0 ];
    _visited[0]  = true;
    var _sp = 1;

    while (_sp > 0) {
        var _cur = _stack[_sp - 1];
        var _cx  = _cur % _w;
        var _cy  = _cur div _w;

        // collect unvisited neighbours
        var _cand = [];
        if (pas_maze_in_bounds(board, _cx,     _cy - 1) && !_visited[pas_maze_idx(board, _cx,     _cy - 1)]) array_push(_cand, 0);
        if (pas_maze_in_bounds(board, _cx + 1, _cy)     && !_visited[pas_maze_idx(board, _cx + 1, _cy)])     array_push(_cand, 1);
        if (pas_maze_in_bounds(board, _cx,     _cy + 1) && !_visited[pas_maze_idx(board, _cx,     _cy + 1)]) array_push(_cand, 2);
        if (pas_maze_in_bounds(board, _cx - 1, _cy)     && !_visited[pas_maze_idx(board, _cx - 1, _cy)])     array_push(_cand, 3);

        if (array_length(_cand) == 0) {
            _sp -= 1;
            array_resize(_stack, _sp);
            continue;
        }

        var _dir = pas_rng_pick(_r, _cand);
        var _nx = _cx, _ny = _cy;
        if (_dir == 0) { _ny -= 1; board.cells[_cur] &= ~PAS_MAZE_N; }
        if (_dir == 1) { _nx += 1; board.cells[_cur] &= ~PAS_MAZE_E; }
        if (_dir == 2) { _ny += 1; board.cells[_cur] &= ~PAS_MAZE_S; }
        if (_dir == 3) { _nx -= 1; board.cells[_cur] &= ~PAS_MAZE_W; }

        var _nidx = pas_maze_idx(board, _nx, _ny);
        // remove the matching wall on the far side too. A wall is shared by two cells and stored
        // twice; carving only one side produces a maze that is passable in one direction only,
        // which LOOKS correct in a screenshot and plays wrong.
        if (_dir == 0) board.cells[_nidx] &= ~PAS_MAZE_S;
        if (_dir == 1) board.cells[_nidx] &= ~PAS_MAZE_W;
        if (_dir == 2) board.cells[_nidx] &= ~PAS_MAZE_N;
        if (_dir == 3) board.cells[_nidx] &= ~PAS_MAZE_E;

        _visited[_nidx] = true;
        array_push(_stack, _nidx);
        _sp += 1;
    }

    // ---- braid: open some dead ends so boards differ visually -------------
    // A perfect maze is all dead ends and reads "computer generated". Opening a fraction of them
    // gives loops and a hand-drawn look. It can only REMOVE walls, so it cannot disconnect a maze
    // that was connected - stated here because that is the property the BFS below would catch.
    if (_braid > 0) {
        for (var i = 0; i < _n; i++) {
            var _walls = board.cells[i];
            var _count = ((_walls & PAS_MAZE_N) != 0) + ((_walls & PAS_MAZE_E) != 0)
                       + ((_walls & PAS_MAZE_S) != 0) + ((_walls & PAS_MAZE_W) != 0);
            if (_count < 3) continue;                       // not a dead end
            if (pas_rng_float(_r) >= _braid) continue;

            var _cx = i % _w, _cy = i div _w;
            var _open = [];
            if ((_walls & PAS_MAZE_N) && pas_maze_in_bounds(board, _cx,     _cy - 1)) array_push(_open, 0);
            if ((_walls & PAS_MAZE_E) && pas_maze_in_bounds(board, _cx + 1, _cy))     array_push(_open, 1);
            if ((_walls & PAS_MAZE_S) && pas_maze_in_bounds(board, _cx,     _cy + 1)) array_push(_open, 2);
            if ((_walls & PAS_MAZE_W) && pas_maze_in_bounds(board, _cx - 1, _cy))     array_push(_open, 3);
            if (array_length(_open) == 0) continue;

            var _d = pas_rng_pick(_r, _open);
            var _nx = _cx, _ny = _cy;
            if (_d == 0) { _ny -= 1; board.cells[i] &= ~PAS_MAZE_N; }
            if (_d == 1) { _nx += 1; board.cells[i] &= ~PAS_MAZE_E; }
            if (_d == 2) { _ny += 1; board.cells[i] &= ~PAS_MAZE_S; }
            if (_d == 3) { _nx -= 1; board.cells[i] &= ~PAS_MAZE_W; }
            var _j = pas_maze_idx(board, _nx, _ny);
            if (_d == 0) board.cells[_j] &= ~PAS_MAZE_S;
            if (_d == 1) board.cells[_j] &= ~PAS_MAZE_W;
            if (_d == 2) board.cells[_j] &= ~PAS_MAZE_N;
            if (_d == 3) board.cells[_j] &= ~PAS_MAZE_E;
        }
    }

    board.path   = pas_maze_solve(board);
    board.cursor = board.start;
    return board;
}

/// @desc Shortest route start -> exit, found by breadth-first search over the WALL DATA ALONE.
///
/// Independent of the carver on purpose (see the header). Returns [] when no route exists, and []
/// is a real answer meaning "this board is broken", never "the search did not run" - the suite
/// distinguishes those by also asserting the path's endpoints.
/// @return {array} array of cell indices from start to exit inclusive, or []
function pas_maze_solve(board) {
    var _n    = board.w * board.h;
    var _prev = array_create(_n, -1);
    var _seen = array_create(_n, false);
    var _q    = [ board.start ];
    var _head = 0;
    _seen[board.start] = true;

    while (_head < array_length(_q)) {
        var _cur = _q[_head];
        _head += 1;
        if (_cur == board.exit) break;

        var _cx = _cur % board.w;
        var _cy = _cur div board.w;
        var _walls = board.cells[_cur];

        // A step is legal only where THIS cell has no wall. The far cell's matching wall is not
        // re-checked here: if the two ever disagreed the maze would be one-way, and the carver
        // comment above says why that must not happen. Checking one side keeps this search
        // genuinely independent of the carver's bookkeeping rather than duplicating it.
        if (!(_walls & PAS_MAZE_N) && pas_maze_in_bounds(board, _cx, _cy - 1)) {
            var _j = pas_maze_idx(board, _cx, _cy - 1);
            if (!_seen[_j]) { _seen[_j] = true; _prev[_j] = _cur; array_push(_q, _j); }
        }
        if (!(_walls & PAS_MAZE_E) && pas_maze_in_bounds(board, _cx + 1, _cy)) {
            var _j = pas_maze_idx(board, _cx + 1, _cy);
            if (!_seen[_j]) { _seen[_j] = true; _prev[_j] = _cur; array_push(_q, _j); }
        }
        if (!(_walls & PAS_MAZE_S) && pas_maze_in_bounds(board, _cx, _cy + 1)) {
            var _j = pas_maze_idx(board, _cx, _cy + 1);
            if (!_seen[_j]) { _seen[_j] = true; _prev[_j] = _cur; array_push(_q, _j); }
        }
        if (!(_walls & PAS_MAZE_W) && pas_maze_in_bounds(board, _cx - 1, _cy)) {
            var _j = pas_maze_idx(board, _cx - 1, _cy);
            if (!_seen[_j]) { _seen[_j] = true; _prev[_j] = _cur; array_push(_q, _j); }
        }
    }

    if (!_seen[board.exit]) return [];

    var _rev = [ board.exit ];
    var _at = board.exit;
    while (_at != board.start) {
        _at = _prev[_at];
        if (_at == -1) return [];   // defensive: a broken chain is "no path", not a crash
        array_push(_rev, _at);
    }
    var _out = array_create(array_length(_rev));
    for (var i = 0; i < array_length(_rev); i++) _out[i] = _rev[array_length(_rev) - 1 - i];
    return _out;
}

/// @desc Advance play. input is "n","e","s","w", or the cabinet's {act,u,v,key} struct.
///
/// Both shapes on purpose: pas_cabinet defines one input struct for all eight rooms, and a caller
/// driving this room from a keyboard should not have to build one to say "north". pas_input_key
/// accepts either and is the ONLY place that decision is made.
///
/// ⚠️ An unrecognised key returns "blocked", NOT nothing. A silent refusal is correct behaviour
/// that cannot be told apart from a failure - this factory shipped a resume that rejected every
/// save with a bare null and looked exactly like the hostile input it was guarding against.
/// @return {string} "moved" | "blocked" | "solved"
function pas_maze_step(board, input) {
    if (board.solved) return "solved";

    var _cx = board.cursor % board.w;
    var _cy = board.cursor div board.w;
    var _walls = board.cells[board.cursor];
    var _key = pas_input_key(input);

    // "auto" walks the shortest route one cell at a time, so a headless suite and the demo's
    // attract mode can both exercise the real step function rather than a second code path.
    if (_key == "auto" || _key == "") {
        for (var i = 0; i < array_length(board.path) - 1; i++) {
            if (board.path[i] != board.cursor) continue;
            var _nx = board.path[i + 1];
            var _dcx = (_nx mod board.w) - _cx;
            var _dcy = (_nx div board.w) - _cy;
            if (_dcx ==  1) _key = "e";
            else if (_dcx == -1) _key = "w";
            else if (_dcy ==  1) _key = "s";
            else if (_dcy == -1) _key = "n";
            break;
        }
        if (_key == "auto" || _key == "") return "blocked";
    }

    var _dx = 0, _dy = 0, _wall = 0;
    switch (_key) {
        case "n": _dy = -1; _wall = PAS_MAZE_N; break;
        case "e": _dx =  1; _wall = PAS_MAZE_E; break;
        case "s": _dy =  1; _wall = PAS_MAZE_S; break;
        case "w": _dx = -1; _wall = PAS_MAZE_W; break;
        default: return "blocked";
    }

    if (_walls & _wall) return "blocked";
    if (!pas_maze_in_bounds(board, _cx + _dx, _cy + _dy)) return "blocked";

    board.cursor = pas_maze_idx(board, _cx + _dx, _cy + _dy);
    board.moves += 1;
    if (board.cursor == board.exit) {
        board.solved = true;
        return "solved";
    }
    return "moved";
}

/// @desc The cabinet label for this board.
function pas_maze_label(board) {
    var _len = array_length(board.path);
    return "MAZE  " + string(board.w) + "x" + string(board.h)
         + "   shortest route " + string(_len) + " cells"
         + (board.braid > 0 ? "   braided" : "   perfect");
}

/// @desc The maze's cells are square, so its board is the grid's own aspect.
function pas_maze_aspect(board) {
    return (board.h > 0) ? (board.w / board.h) : 1;
}

/// @desc Draw the maze. Visual language: inked plan view, ONE stroke weight.
///
/// ⛔ ONE WEIGHT IS THE WHOLE LOOK AND IT IS ALSO THE ONLY WEIGHT THAT SURVIVES. draw_line_width
/// floors every stroke at 1.0 px with no antialiasing, so a "heavier outer wall" drawn as a
/// fraction of the cell resolves to exactly the same pixel as the inner walls at cabinet size, and
/// the ramp somebody carefully authored becomes noise. This room draws every wall at one bounded
/// pixel width and gets its hierarchy from what is DRAWN, not from how thickly.
function pas_maze_draw(board, _x, _y, _w, _h, _pal) {
    var _f = pas_map(_x, _y, _w, _h);
    var _m = 0.045;
    var _cw = (1 - _m * 2) / board.w;
    var _ch = (1 - _m * 2) / board.h;
    var _wall = pas_detail(_f, 0.012, 2, 11);

    // -- the sheet the plan is drawn on -----------------------------------
    pas_rrect(_f, 0, 0, 1, 1, pas_detail(_f, 0.014, 2, 14), _pal.m4);
    // a plate mark: the impression an inked plate leaves round a plan. It is the one piece of
    // ornament, and it is what makes the sheet read as printed rather than as a white rectangle.
    pas_rrect_edge(_f, _m * 0.45, _m * 0.45, 1 - _m * 0.9, 1 - _m * 0.9,
                   pas_detail(_f, 0.008, 1, 8), pas_detail(_f, 0.004, 1, 4), _pal.guide);

    // -- the solved route, UNDER the walls --------------------------------
    // Under, because a route is a thing you walk BETWEEN walls. Drawn only as far as the player
    // has actually got, so it is a record of the walk rather than the answer printed on the board.
    if (array_length(board.path) > 1) {
        var _idx = -1;
        for (var i = 0; i < array_length(board.path); i++) {
            if (board.path[i] == board.cursor) { _idx = i; break; }
        }
        if (_idx > 0) {
            var _pts = [];
            for (var i = 0; i <= _idx; i++) {
                var _c = board.path[i];
                array_push(_pts, _m + ((_c mod board.w) + 0.5) * _cw,
                                 _m + ((_c div board.w) + 0.5) * _ch);
            }
            pas_stroke(_f, _pts, _wall * 2.4, merge_colour(_pal.m4, _pal.p3, 0.42));
        }
    }

    // -- start and exit ---------------------------------------------------
    var _su = _m + ((board.start mod board.w) + 0.5) * _cw;
    var _sv = _m + ((board.start div board.w) + 0.5) * _ch;
    var _eu = _m + ((board.exit mod board.w) + 0.5) * _cw;
    var _ev = _m + ((board.exit div board.w) + 0.5) * _ch;
    pas_rrect(_f, _su - _cw * 0.34, _sv - _ch * 0.34, _cw * 0.68, _ch * 0.68,
              pas_detail(_f, 0.004, 1, 4), _pal.q3);
    // The exit is a RING, not a second square: two marks that differ only in colour are one mark
    // to anybody who cannot tell those two colours apart, and this cabinet has twelve themes.
    pas_ring(_f, _eu, _ev, min(_cw, _ch) * 0.34 * (max(1, _f.w) / max(1, _f.s)),
             _wall * 1.6, _pal.p3);

    // -- the walls --------------------------------------------------------
    // Each cell draws only its NORTH and WEST wall, plus the board's own south and east edges.
    // Drawing all four per cell would lay every interior wall down twice, which on a translucent
    // stroke is a visible doubling and on an opaque one is wasted fill.
    for (var cy = 0; cy < board.h; cy++) {
        for (var cx = 0; cx < board.w; cx++) {
            var _c = board.cells[pas_maze_idx(board, cx, cy)];
            var _u0 = _m + cx * _cw, _v0 = _m + cy * _ch;
            if (_c & PAS_MAZE_N) pas_line(_f, _u0, _v0, _u0 + _cw, _v0, _wall, _pal.ink);
            if (_c & PAS_MAZE_W) pas_line(_f, _u0, _v0, _u0, _v0 + _ch, _wall, _pal.ink);
            if (cx == board.w - 1 && (_c & PAS_MAZE_E)) {
                pas_line(_f, _u0 + _cw, _v0, _u0 + _cw, _v0 + _ch, _wall, _pal.ink);
            }
            if (cy == board.h - 1 && (_c & PAS_MAZE_S)) {
                pas_line(_f, _u0, _v0 + _ch, _u0 + _cw, _v0 + _ch, _wall, _pal.ink);
            }
        }
    }

    // -- the walker -------------------------------------------------------
    var _pu = _m + ((board.cursor mod board.w) + 0.5) * _cw;
    var _pv = _m + ((board.cursor div board.w) + 0.5) * _ch;
    var _pr = min(_cw, _ch) * 0.30 * (max(1, _f.w) / max(1, _f.s));
    pas_disc(_f, _pu, _pv + _pr * 0.22, _pr, merge_colour(_pal.m4, _pal.ink, 0.30));
    pas_disc(_f, _pu, _pv, _pr, _pal.b2);
    pas_disc(_f, _pu - _pr * 0.28, _pv - _pr * 0.30, _pr * 0.45, _pal.b4);
}
