{
  "$GMScript": "v1",
  "%Name": "pas_rng",
  "name": "pas_rng",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}
