/// PASTIME - pas_rng. Deterministic seeded randomness.
///
/// Every board in this cabinet is generated from a seed, and the SAME seed must give the SAME
/// board on every machine, every run, forever. That is not a nicety: it is what lets the in-engine
/// suite hammer thousands of boards and report a FAILING SEED that a human can reproduce, and it is
/// what lets a buyer store a board as one integer instead of a blob.
///
/// ⛔ THIS DOES NOT USE GameMaker's `random()`. `random_set_seed` mutates GLOBAL engine state, so a
/// board generated during play would perturb the buyer's own random sequence, and anything else in
/// the buyer's game that reseeds would perturb ours. A generator that can be silently changed by
/// unrelated code somewhere else in the project is not deterministic in any useful sense. This is a
/// self-contained xorshift32 carried in a struct: nothing outside the struct can move it.
///
/// ⛔ GML APPLIES A DEFAULT EPSILON TO NUMERIC COMPARISONS - 0.00001 on this runtime, MEASURED by
/// the Raiment suite, which printed math_get_epsilon() at twelve decimals into its result file.
/// Any tolerance at or below about 0.00001 can NEVER fire in either direction, so a distinctness
/// assertion written that way passes vacuously forever. Never write one against these outputs.
/// GML also has NO exponent-literal syntax: `1e-5` is a lexer error that reads like a bracket bug.
///
/// All state is int64 masked to 32 bits. GML numbers are doubles, so an unmasked shift walks off
/// the top of the mantissa and the stream silently stops being uniform.

#macro PAS_RNG_MASK 0xFFFFFFFF

/// How many outputs are thrown away when a generator is seeded. See pas_rng.
#macro PAS_RNG_WARMUP 2

/// @desc Make a generator. Same seed -> same stream, always.
///
/// ⛔ IT WARMS UP, AND THAT IS NOT A PRECAUTION - IT IS A FIX FOR A MEASURED DEFECT.
/// MEASURED 2026-09-03 by pas_selftest STAGE 1 on an Igor-built Pastime.exe: with no warm-up, the
/// FIRST value of pas_rng_float across 600 CONSECUTIVE seeds spanned only 0.0468 of the unit
/// interval - every board in a `base + index` sweep started from very nearly the same number. This
/// wing has the same law from Lode, where the first draw was spent on a 30% rare event and the
/// event was measured at exactly 0% over 440 runs while every determinism assertion stayed green.
///
/// ⚠️ AND THE SCOPE IS NARROWER THAN IT SOUNDS, which matters because the wide version was about to
/// be written down as fact. Internal_Ops/rng_warmup_probe.js replicates this generator exactly and
/// sweeps the discard count. Its CONTROL measures the reduction a caller actually performs: at ZERO
/// discards, `pick one of five` over 600 consecutive seeds returns 129/124/131/104/112, essentially
/// uniform - because pas_rng_int reduces with `%` and the LOW bits are well mixed even while the
/// magnitude is clustered. ⇒ the defect bites pas_rng_float callers only, and every room's first
/// draw happens to be an int. The live case is pas_bagatelle_profile's own generator, whose first
/// draw is a launch power.
///
/// ⚠️ THE NUMBER IS MEASURED, NOT CHOSEN. The probe's criterion is a span above 0.80 AND all ten
/// tenths of the range occupied, over 600 consecutive seeds from five different bases. ONE discard
/// already passes (0.9864). Two is taken because the criterion only examines the FIRST draw, so a
/// future caller that consumes one float before deciding anything would otherwise be relying on the
/// second - and the cost is two integer operations per board.
///
/// ⛔ WARM UP AT THE SEEDING, NEVER AT THE CALL SITE. A discard at the call site is a discard the
/// next caller has to remember, and the next caller is a buyer.
///
/// @param {real} seed  any integer; 0 is remapped because xorshift is stuck at zero
/// @return {struct}
function pas_rng(seed) {
    var _s = int64(seed) & PAS_RNG_MASK;
    // xorshift32 has exactly one fixed point, 0, where it emits zeros forever. A caller passing
    // seed 0 is not an error and must not silently produce a degenerate board, so remap it to a
    // constant with a well-mixed bit pattern rather than rejecting it.
    if (_s == 0) _s = 0x9E3779B9;
    var _r = { s : _s };
    repeat (PAS_RNG_WARMUP) pas_rng_next(_r);
    return _r;
}

/// @desc Next raw 32-bit value. Advances the generator.
/// @param {struct} r
/// @return {real} 0 .. 4294967295
function pas_rng_next(r) {
    var _x = r.s;
    _x = (_x ^ (_x << 13)) & PAS_RNG_MASK;
    _x = (_x ^ (_x >> 17)) & PAS_RNG_MASK;
    _x = (_x ^ (_x << 5))  & PAS_RNG_MASK;
    r.s = _x;
    return _x;
}

/// @desc Uniform real in [0,1). Never returns 1.
function pas_rng_float(r) {
    return pas_rng_next(r) / 4294967296;
}

/// @desc Uniform integer in [lo,hi] INCLUSIVE of both ends.
///
/// Inclusive on both ends because every caller in this cabinet wants "a cell index" or "a face
/// value", and a half-open range is where off-by-one board bugs come from. If hi < lo the range is
/// empty and there is no correct answer, so it returns lo rather than inventing one - and the
/// self-test asserts that case explicitly instead of leaving it to chance.
function pas_rng_int(r, lo, hi) {
    if (hi <= lo) return lo;
    var _n = (hi - lo) + 1;
    return lo + (pas_rng_next(r) % _n);
}

/// @desc Pick one element of an array. Returns undefined for an empty array.
function pas_rng_pick(r, arr) {
    var _n = array_length(arr);
    if (_n == 0) return undefined;
    return arr[pas_rng_int(r, 0, _n - 1)];
}

/// @desc Fisher-Yates, in place, on a copy. Returns the shuffled copy.
///
/// A copy rather than in-place on the caller's array: a board generator that shuffles its own
/// source corpus would give a different result the second time it ran with the same seed, which is
/// exactly the determinism this file exists to guarantee.
function pas_rng_shuffle(r, arr) {
    var _n = array_length(arr);
    var _out = array_create(_n);
    for (var i = 0; i < _n; i++) _out[i] = arr[i];
    for (var i = _n - 1; i > 0; i--) {
        var _j = pas_rng_int(r, 0, i);
        var _t = _out[i];
        _out[i] = _out[_j];
        _out[_j] = _t;
    }
    return _out;
}
