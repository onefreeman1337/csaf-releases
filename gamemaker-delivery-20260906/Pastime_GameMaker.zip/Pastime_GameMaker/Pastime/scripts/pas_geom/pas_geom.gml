/// PASTIME - pas_geom. The shape vocabulary, and the other half of the house style.
///
/// pas_palette forbids a room from hard-coding a colour. THIS file forbids a room from rolling its
/// own primitive. Between them, eight different visual languages are drawn out of one set of marks
/// and read as one cabinet.
///
/// -- BOARD SPACE -------------------------------------------------------------------------------
/// Every room draws in NORMALISED board space: u and v run 0..1 across the board, and pas_map turns
/// that into pixels. A room therefore contains no pixel numbers at all, which is what lets the same
/// generator draw a 96 px cabinet thumbnail and a 1400 px store sheet without a second code path.
///
/// ⛔ LENGTHS GO THROUGH pas_ms, NOT THROUGH pas_mx. A radius mapped through the u axis is an
/// ELLIPSE on a non-square board, and every disc, pip, pin and lamp in this cabinet would quietly
/// become an egg on any board that is not exactly square. pas_ms uses min(w,h) so a circle is a
/// circle. This wing shipped the same class of error twice before it was written down - Borough's
/// eaves shadow and its catslide roof both took a VERTICAL measurement from a HORIZONTAL one, and
/// were largest exactly on the widest, lowest building the product could draw.
///
/// -- THE FIVE LAWS BAKED INTO THIS FILE --------------------------------------------------------
///
/// 1. ⛔ A PHYSICAL DETAIL NEEDS BOTH BOUNDS. Livery shipped a 112 px cove, an 80 px "fine"
///    engraving and a 187 px margin on one hero image, all from dimensions written only as a
///    fraction of the component. A moulding run on a door and on a jewellery box is the SAME
///    moulding. pas_detail(f, frac, minpx, maxpx) is how every bevel, rail and hairline here is
///    sized: proportional in the middle, bounded at both ends.
///
/// 2. ⛔ A BEVEL IS BOUNDED BY THE OUTLINE'S SHORTEST EDGE, NOT BY THE SHAPE'S SMALLER DIMENSION.
///    Insetting a sampled curve by more than about 0.45 of its shortest edge swaps consecutive
///    inset points and the bevel quad becomes a BOWTIE - silently, with the outline, the winding
///    and the ink all still correct. pas_inset_limit enforces it.
///
/// 3. ⛔ BUTT-ENDED SEGMENT JOINS ARE VISIBLE THE MOMENT A MARK IS DRAWN MORE THAN ONCE.
///    draw_line_width lays down a butt-ended quad, so two segments meeting at an angle leave a
///    wedge of bare bed on the outside of the turn. Lexicon drew every letter three times and every
///    loop on its alphabet plate came out as a DOTTED RING. pas_stroke fills each interior vertex
///    with a disc of the stroke's own radius, skipped below 2 px where the disc IS the segment.
///
/// 4. ⛔ TONE IS SPACING AND LENGTH, NEVER LINE WIDTH. draw_line_width floors every stroke at 1.0 px
///    with no antialiasing, so an authored half-width range resolves to exactly one pixel at
///    cabinet scale and a carefully ramped engraving becomes a barcode. Where this cabinet needs
///    tone it varies how MANY strokes and how FAR each runs.
///
/// 5. ⛔ pr_trianglefan REQUIRES A STAR-SHAPED OUTLINE ABOUT ITS FIRST POINT. Hand it a concave
///    shape and it spans the concavity - silently, with no error and no failed assertion. Welkin
///    shipped every moon crescent as a quarter for exactly this reason. pas_poly says so in its
///    own header and pas_strip is the exact alternative for anything band-shaped, which is what the
///    darts wedges, the wheel segments and the range rings all use.
/// ================================================================================================

/// @desc A drawing frame. Everything else in this file takes one.
/// @param {real} _x,_y,_w,_h  the pixel rect the board occupies
function pas_map(_x, _y, _w, _h) {
    return { x : _x, y : _y, w : _w, h : _h, s : min(_w, _h) };
}

/// u in board space -> pixel x
function pas_mx(_f, _u) { return _f.x + _u * _f.w; }
/// v in board space -> pixel y
function pas_my(_f, _v) { return _f.y + _v * _f.h; }
/// a LENGTH in board space -> pixels. Uses min(w,h) so a circle stays a circle. Law above.
function pas_ms(_f, _k) { return _k * _f.s; }

/// @desc A physical detail's size in pixels: proportional in the middle, bounded at BOTH ends.
///
/// LAW 1. The proportional term keeps a detail from swamping a 40 px thumbnail; the maximum keeps
/// it from becoming a feature in its own right on a 1400 px hero. A moulding is the same moulding
/// on a door and on a jewellery box.
function pas_detail(_f, _frac, _minpx, _maxpx) {
    return clamp(_f.s * _frac, _minpx, _maxpx);
}

/// @desc The largest inset that will not turn a polygon inside out.
///
/// LAW 2. Measured against the SHORTEST EDGE of the outline, not the shape's smaller dimension: a
/// sampled curve reaches its bounding width at one point and its edges are far shorter than its
/// extent. Zero-length edges (a duplicated point) are skipped, or one repeated vertex caps every
/// bevel in the package to nothing.
/// @param {array} _pts flat [x0,y0,x1,y1,...] in PIXELS
/// @param {real} _want the inset you would like
function pas_inset_limit(_pts, _want) {
    var _n = array_length(_pts) div 2;
    if (_n < 3) return 0;
    var _short = 100000;
    for (var i = 0; i < _n; i++) {
        var _j = (i + 1) % _n;
        var _dx = _pts[_j * 2] - _pts[i * 2];
        var _dy = _pts[_j * 2 + 1] - _pts[i * 2 + 1];
        var _d = sqrt(_dx * _dx + _dy * _dy);
        if (_d > 0.0001 && _d < _short) _short = _d;
    }
    if (_short >= 100000) return 0;
    return min(_want, _short * 0.45);
}

/// ================================================================================================
/// MARKS
/// ================================================================================================

/// @desc A filled disc in board space. Radius goes through pas_ms, so it is round on any board.
function pas_disc(_f, _u, _v, _r, _col) {
    draw_set_colour(_col);
    draw_circle(pas_mx(_f, _u), pas_my(_f, _v), pas_ms(_f, _r), false);
}

/// @desc An unfilled ring, drawn as a band rather than as a line.
///
/// Not draw_circle(outline) - that is a 1 px hairline that quantises away at cabinet size (LAW 4).
/// A band has a real width at every scale.
///
/// ⛔⛔ THE RADIUS IS IN BOARD UNITS AND THE THICKNESS IS IN PIXELS. THEY ARE DIFFERENT UNITS AND
/// THE FIRST VERSION OF THIS FUNCTION TOOK BOTH IN BOARD UNITS WHILE EVERY CALLER PASSED PIXELS.
///
/// MEASURED 2026-09-03 by baking the hero sheet and LOOKING AT IT: a 12 px trace width arrived as
/// a radius of 12 BOARD units, so `pas_ring(f, u, v, 0.045, 12, col)` drew a filled annulus six
/// times the size of the whole cabinet. The hero sheet came out as a flat teal rectangle with the
/// label rail and nothing else, because the last such ring painted over everything drawn before it.
///
/// ⭐ AND 681 IN-ENGINE ASSERTIONS WERE GREEN OVER IT, WHICH IS THE POINT. The suite computes
/// POINTS and NUMBERS; a ring of the wrong radius is geometrically perfect and every generator that
/// produced it was correct. Nothing mechanical in this wing can see it. The instrument was opening
/// the PNG.
///
/// ⇒ the two units are deliberate and each is right for what it describes: a RADIUS is a shape
/// dimension and scales with the board, while a STROKE WIDTH is a physical constant bounded at both
/// ends (pas_detail) and must not get coarser on a bigger board. pas_ring_radii splits out the
/// arithmetic so pas_selftest can assert the conversion without needing a surface - a picture is
/// unreachable from a test, so the CONTRACT is what gets tested.
///
/// @param {real} _r    radius, in BOARD units
/// @param {real} _tpx  band thickness, in PIXELS
function pas_ring(_f, _u, _v, _r, _tpx, _col) {
    var _rr = pas_ring_radii(_f, _r, _tpx);
    pas_annulus(_f, _u, _v, _rr[0], _rr[1], 0, 360, _col, 64);
}

/// @desc The inner and outer radii pas_ring will use, in BOARD units. Pure arithmetic.
/// @return {array} [inner, outer]
function pas_ring_radii(_f, _r, _tpx) {
    var _t = _tpx / max(1, _f.s);            // pixels -> board units. The line that was missing.
    return [ max(0, _r - _t * 0.5), _r + _t * 0.5 ];
}

/// @desc A line of real width, with rounded ends.
function pas_line(_f, _u0, _v0, _u1, _v1, _wpx, _col) {
    draw_set_colour(_col);
    var _x0 = pas_mx(_f, _u0), _y0 = pas_my(_f, _v0);
    var _x1 = pas_mx(_f, _u1), _y1 = pas_my(_f, _v1);
    var _w = max(1, _wpx);
    draw_line_width(_x0, _y0, _x1, _y1, _w);
    if (_w >= 2) {
        draw_circle(_x0, _y0, _w * 0.5, false);
        draw_circle(_x1, _y1, _w * 0.5, false);
    }
}

/// @desc A polyline of real width with its JOINS FILLED.
///
/// LAW 3. Two butt-ended quads meeting at an angle leave a wedge of bare bed on the outside of the
/// turn; a disc of the stroke's own radius at every interior vertex fills it exactly. Skipped below
/// 2 px, where the disc IS the segment and drawing it only costs fill rate.
/// @param {array} _pts flat [u0,v0,u1,v1,...] in BOARD space
function pas_stroke(_f, _pts, _wpx, _col) {
    var _n = array_length(_pts) div 2;
    if (_n < 2) return;
    var _w = max(1, _wpx);
    draw_set_colour(_col);
    for (var i = 0; i < _n - 1; i++) {
        draw_line_width(
            pas_mx(_f, _pts[i * 2]),       pas_my(_f, _pts[i * 2 + 1]),
            pas_mx(_f, _pts[(i + 1) * 2]), pas_my(_f, _pts[(i + 1) * 2 + 1]), _w);
    }
    if (_w >= 2) {
        for (var i = 0; i < _n; i++) {
            draw_circle(pas_mx(_f, _pts[i * 2]), pas_my(_f, _pts[i * 2 + 1]), _w * 0.5, false);
        }
    }
}

/// @desc Fill a polygon.
///
/// ⛔ LAW 5: pr_trianglefan spans any concavity relative to _pts[0], SILENTLY. Use this only for
/// convex shapes, or shapes genuinely star-shaped about their first point. Anything crescent-, C-,
/// L- or ring-shaped must use pas_strip or pas_annulus instead.
/// @param {array} _pts flat [u0,v0,...] in BOARD space
function pas_poly(_f, _pts, _col) {
    var _n = array_length(_pts) div 2;
    if (_n < 3) return;
    draw_primitive_begin(pr_trianglefan);
    for (var i = 0; i < _n; i++) {
        draw_vertex_colour(pas_mx(_f, _pts[i * 2]), pas_my(_f, _pts[i * 2 + 1]), _col, 1);
    }
    draw_primitive_end();
}

/// @desc Fill the band between two rails. EXACT where a fan is not.
///
/// The answer to LAW 5. A rail pair models a band directly: every quad is built from one point on
/// each rail, so a band that curves back on itself, or encloses its own centre, is drawn correctly.
/// Both rails must have the same point count and run in the SAME direction.
/// @param {array} _a,_b flat [u,v,...] in BOARD space, equal length
function pas_strip(_f, _a, _b, _col) {
    var _n = min(array_length(_a), array_length(_b)) div 2;
    if (_n < 2) return;
    draw_primitive_begin(pr_trianglestrip);
    for (var i = 0; i < _n; i++) {
        draw_vertex_colour(pas_mx(_f, _a[i * 2]), pas_my(_f, _a[i * 2 + 1]), _col, 1);
        draw_vertex_colour(pas_mx(_f, _b[i * 2]), pas_my(_f, _b[i * 2 + 1]), _col, 1);
    }
    draw_primitive_end();
}

/// @desc Points along a circular arc, in BOARD space, radius corrected so it is a circle.
///
/// Angles in DEGREES, measured clockwise from east, because that is what every wedge, segment and
/// spider wire in this cabinet is authored in and a mixed convention is where sign errors live.
/// @return {array} flat [u,v,...]
function pas_arc_pts(_f, _u, _v, _r, _a0, _a1, _seg) {
    var _out = array_create((_seg + 1) * 2);
    // Board space is anisotropic: a radius that is r in PIXELS is r*s/w in u and r*s/h in v.
    var _ru = (_r * _f.s) / max(1, _f.w);
    var _rv = (_r * _f.s) / max(1, _f.h);
    for (var i = 0; i <= _seg; i++) {
        var _a = degtorad(_a0 + (_a1 - _a0) * (i / _seg));
        _out[i * 2]     = _u + cos(_a) * _ru;
        _out[i * 2 + 1] = _v + sin(_a) * _rv;
    }
    return _out;
}

/// @desc Points along an ELLIPTICAL arc, radii given separately in BOARD space.
///
/// ⚠️ Anything drawn on a table, a bed or a pool is an ellipse in projection, and a circular arc
/// helper draws a silently wrong curve that agrees only when the two radii happen to match. Repast
/// shipped a gilt rim across every plate in the product for want of this function.
function pas_ellipse_arc_pts(_u, _v, _ru, _rv, _a0, _a1, _seg) {
    var _out = array_create((_seg + 1) * 2);
    for (var i = 0; i <= _seg; i++) {
        var _a = degtorad(_a0 + (_a1 - _a0) * (i / _seg));
        _out[i * 2]     = _u + cos(_a) * _ru;
        _out[i * 2 + 1] = _v + sin(_a) * _rv;
    }
    return _out;
}

/// @desc An annular sector - the wedge of a dartboard, the segment of a wheel, the ring of a target.
///
/// Built as a STRIP between an inner rail and an outer rail, which is exact. A fan from the centre
/// would be correct only for a full disc and wrong for every ring, because a ring is not star-shaped
/// about anything.
function pas_annulus(_f, _u, _v, _r0, _r1, _a0, _a1, _col, _seg) {
    var _in  = pas_arc_pts(_f, _u, _v, _r0, _a0, _a1, _seg);
    var _out = pas_arc_pts(_f, _u, _v, _r1, _a0, _a1, _seg);
    pas_strip(_f, _in, _out, _col);
}

/// ================================================================================================
/// PLATES - the cabinet's furniture, and the one shape every room shares
/// ================================================================================================

/// @desc The corner points of a rounded rectangle, in BOARD space.
///
/// ⛔ CORNER ORDER MATTERS AND IS NOT ARBITRARY. Each corner arc ENDS pointing where the next must
/// BEGIN; walk them out of order and the outline is a bowtie whose inset points fly outside the
/// shape. Vestige grew corner hooks on every panel in the product this way and the ink check
/// reported the failure two steps downstream of its cause. TL -> TR -> BR -> BL, clockwise.
function pas_rrect_pts(_f, _u, _v, _uw, _vh, _radpx, _seg) {
    var _ru = _radpx / max(1, _f.w);
    var _rv = _radpx / max(1, _f.h);
    _ru = min(_ru, _uw * 0.5);
    _rv = min(_rv, _vh * 0.5);
    var _x0 = _u, _y0 = _v, _x1 = _u + _uw, _y1 = _v + _vh;
    var _pts = [];
    var _c = [
        [ _x0 + _ru, _y0 + _rv, 180, 270 ],
        [ _x1 - _ru, _y0 + _rv, 270, 360 ],
        [ _x1 - _ru, _y1 - _rv,   0,  90 ],
        [ _x0 + _ru, _y1 - _rv,  90, 180 ]
    ];
    for (var k = 0; k < 4; k++) {
        var _arc = pas_ellipse_arc_pts(_c[k][0], _c[k][1], _ru, _rv, _c[k][2], _c[k][3], _seg);
        for (var i = 0; i < array_length(_arc); i++) array_push(_pts, _arc[i]);
    }
    return _pts;
}

/// @desc A flat rounded plate.
function pas_rrect(_f, _u, _v, _uw, _vh, _radpx, _col) {
    var _pts = pas_rrect_pts(_f, _u, _v, _uw, _vh, _radpx, 5);
    // A rounded rectangle IS star-shaped about its own centre, so a fan from the centre is exact.
    // Prepending the centre is what makes that true - a fan from pts[0], a corner, is not.
    var _fan = [ _u + _uw * 0.5, _v + _vh * 0.5 ];
    for (var i = 0; i < array_length(_pts); i++) array_push(_fan, _pts[i]);
    array_push(_fan, _pts[0], _pts[1]);
    pas_poly(_f, _fan, _col);
}

/// @desc A RAISED plate: face, a lit wall along the top and left, a shadow wall along the bottom
///       and right, and a seated shadow under the whole thing. The cabinet's one piece of joinery.
///
/// The lamp is fixed at the upper left for the entire product. A cabinet lit from two directions is
/// two cabinets, and this wing has shipped an assembly that was correct part by part and wrong as a
/// whole (Chitin's forewings, raked downward by a sign applied twice) more than once.
function pas_plate(_f, _u, _v, _uw, _vh, _radpx, _face, _hi, _lo) {
    var _d = pas_detail(_f, 0.009, 1, 7);
    var _du = _d / max(1, _f.w), _dv = _d / max(1, _f.h);
    // shadow wall first, offset down-right, then the lit wall up-left, then the face over both.
    pas_rrect(_f, _u + _du, _v + _dv, _uw, _vh, _radpx, _lo);
    pas_rrect(_f, _u - _du, _v - _dv, _uw, _vh, _radpx, _hi);
    pas_rrect(_f, _u, _v, _uw, _vh, _radpx, _face);
}

/// @desc A RECESSED well - the bed a board is sunk into. The inverse of pas_plate.
///
/// ⛔ NOT pas_plate WITH _hi AND _lo SWAPPED AND NOTHING ELSE. A recess is lit on its LOWER inner
/// wall and shadowed on its UPPER inner wall, which is the opposite of a raised plate, and the
/// offsets have to move with it or the picture reads as a raised plate with odd colours.
function pas_well(_f, _u, _v, _uw, _vh, _radpx, _face, _hi, _lo) {
    var _d = pas_detail(_f, 0.009, 1, 7);
    var _du = _d / max(1, _f.w), _dv = _d / max(1, _f.h);
    pas_rrect(_f, _u - _du, _v - _dv, _uw, _vh, _radpx, _lo);
    pas_rrect(_f, _u + _du, _v + _dv, _uw, _vh, _radpx, _hi);
    pas_rrect(_f, _u, _v, _uw, _vh, _radpx, _face);
}

/// @desc A hairline outline around a rounded rect, drawn as a stroke so it survives LAW 4.
function pas_rrect_edge(_f, _u, _v, _uw, _vh, _radpx, _wpx, _col) {
    var _pts = pas_rrect_pts(_f, _u, _v, _uw, _vh, _radpx, 5);
    array_push(_pts, _pts[0], _pts[1]);
    pas_stroke(_f, _pts, _wpx, _col);
}

/// ================================================================================================
/// TYPE
/// ================================================================================================

/// @desc Draw a string scaled DOWN to fit a width, never overflowing.
///
/// ⛔ A CAPTION THAT CAN OVERFLOW WILL, AND THIS WING HAS SHIPPED IT TWICE - "WickthorSt Cuthman's"
/// on Charter and "HEDGEHOG FUNGUSCAULIFLOWER FUNGUS" on Forage, the second because the first fix
/// shortened the DATA instead of measuring the string. No ink check can ever catch it: overprinted
/// text is ink exactly where ink belongs. Measure and scale, so renaming can never re-open it.
///
/// ⛔ AND THE SHIPPED FONTS ARE ASCII-ONLY (32..127, read out of fnt_pastime.yy). A missing glyph
/// draws NOTHING AT ALL - no error, no box, just absence that reads as a deliberate space. Livery
/// shipped "40 THEMES  DRAWN IN GML" on its cover for want of one middle dot. Every string in this
/// package is plain ASCII and Internal_Ops/ascii_check.js is the guard.
/// @return {real} the scale actually used
function pas_text_fit(_f, _str, _u, _v, _maxu, _col, _ha, _va) {
    var _maxpx = _maxu * _f.w;
    var _w = string_width(_str);
    var _sc = (_w > 0 && _w > _maxpx) ? (_maxpx / _w) : 1;
    draw_set_halign(_ha);
    draw_set_valign(_va);
    draw_set_colour(_col);
    draw_text_transformed(pas_mx(_f, _u), pas_my(_f, _v), _str, _sc, _sc, 0);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    return _sc;
}

/// @desc The scale pas_text_fit will use. Split out so the suite can assert the law without a
///       surface: a caption is only correct if it was SCALED, and a test that draws proves nothing.
function pas_text_scale(_f, _str, _maxu) {
    var _maxpx = _maxu * _f.w;
    var _w = string_width(_str);
    if (_w <= 0 || _w <= _maxpx) return 1;
    return _maxpx / _w;
}
