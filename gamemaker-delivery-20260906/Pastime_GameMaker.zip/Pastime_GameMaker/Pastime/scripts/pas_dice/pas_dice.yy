{
  "$GMScript": "v1",
  "%Name": "pas_dice",
  "name": "pas_dice",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}