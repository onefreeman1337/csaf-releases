/// PASTIME - pas_dice. Room 3 of the cabinet.
///
/// Visual language: tactile. Turned wood rails with mitred corners, napped felt, and bone dice whose
/// pips are DRILLED - a dark pit with a lit lower rim, not a black dot.
///
/// ⭐ WHAT IS GENERATED: THE FACE DESIGN ITSELF. Almost every dice product in existence ships the
/// six standard pip patterns as art. This room derives them: it picks a lattice, enumerates the
/// point-symmetric position pairs on it, and chooses which pairs each value uses. So the dice on one
/// board share one carved design, and no two boards carve the same one.
///
/// ⛔ POINT SYMMETRY IS THE CONSTRAINT THAT MAKES IT LOOK LIKE A DIE RATHER THAN LIKE NOISE, and it
/// is enforced STRUCTURALLY rather than checked afterwards: pips are only ever added in mirror
/// PAIRS, plus the centre when the value is odd. A constraint that lives only in prose is enforced
/// by whoever last read the prose - this wing shipped four glossy rolled-tube butterfly wings for
/// exactly that reason, with the correct rule written in the header one file away.
///
/// pas_selftest asserts the property anyway, over every value on every seed, because a structural
/// guarantee that nothing tests is a guarantee about the code you think you wrote.
/// ================================================================================================

/// @desc Build a dice board.
/// @param {real} seed
/// @param {struct} opts  optional: {n, faces}
function pas_dice_board(seed, opts = {}) {
    var _r = pas_rng(seed);

    var _n = (is_struct(opts) && variable_struct_exists(opts, "n")) ? opts.n : pas_rng_int(_r, 4, 6);
    if (_n < 1) _n = 1;
    if (_n > 8) _n = 8;
    var _faces = (is_struct(opts) && variable_struct_exists(opts, "faces"))
        ? opts.faces : pas_rng_pick(_r, [ 6, 6, 6, 8 ]);

    // The lattice the pips are drilled on. 3 is the familiar die; 4 and 5 give the wider, sparser
    // faces of a gaming-house set. It is the single decision that changes a board's whole character.
    var _lat = pas_rng_pick(_r, [ 3, 3, 4, 5 ]);

    var board = {
        room    : "dice",
        seed    : seed,
        n       : _n,
        faces   : _faces,
        lat     : _lat,
        corner  : 0.13 + pas_rng_float(_r) * 0.14,   // die corner radius, as a fraction of the die
        pip     : 0.070 + pas_rng_float(_r) * 0.040, // pip radius, same units
        nap     : pas_rng_int(_r, 0, 3),             // felt nap direction
        railw   : 0.052 + pas_rng_float(_r) * 0.030,
        layout  : [],                                 // layout[v] = flat [px,py,...] in -1..1
        values  : array_create(_n, 1),
        held    : array_create(_n, false),
        rolls   : 3,
        score   : 0,
        over    : false,
        rng     : _r,
    };

    board.layout = pas_dice_layout(_lat, _faces, _r);
    for (var i = 0; i < _n; i++) board.values[i] = pas_rng_int(_r, 1, _faces);
    return board;
}

/// @desc Generate the face design: for every value, a point-symmetric set of pip positions.
///
/// PURE. Takes the generator so the design is part of the seeded stream, and returns plain arrays.
///
/// The lattice is L x L over -1..1. Its positions split into MIRROR PAIRS about the centre, plus
/// the centre itself when L is odd. A value of k pips is then k div 2 pairs, plus the centre if k is
/// odd - which is why every generated face is symmetric by construction and why an odd value on an
/// EVEN lattice (no centre position) is impossible and must be handled rather than hoped about.
/// @return {array} index v holds a flat [x,y,...] for value v; index 0 is unused
function pas_dice_layout(_lat, _faces, _r) {
    // ---- enumerate the lattice ------------------------------------------
    var _pos = [];
    for (var gy = 0; gy < _lat; gy++) {
        for (var gx = 0; gx < _lat; gx++) {
            var _x = (_lat == 1) ? 0 : (-1 + 2 * (gx / (_lat - 1)));
            var _y = (_lat == 1) ? 0 : (-1 + 2 * (gy / (_lat - 1)));
            array_push(_pos, { x : _x, y : _y });
        }
    }
    // ---- split into centre and mirror pairs ------------------------------
    var _hasCentre = (_lat & 1) == 1;
    var _pairs = [];
    for (var i = 0; i < array_length(_pos); i++) {
        var _p = _pos[i];
        if (abs(_p.x) < 0.0001 && abs(_p.y) < 0.0001) continue;      // the centre is not a pair
        // Keep each pair once. "First half of the reading order" is the canonical representative:
        // its mirror is always later in the list, so no pair can be counted twice.
        if (_p.y > 0.0001 || (abs(_p.y) < 0.0001 && _p.x > 0.0001)) continue;
        array_push(_pairs, { x : _p.x, y : _p.y,
                             d : sqrt(_p.x * _p.x + _p.y * _p.y) });
    }
    // Spread first: a face wants its pips as far apart as they can be, which is what makes a six
    // readable at a glance. Insertion sort by distance from centre, descending.
    for (var i = 1; i < array_length(_pairs); i++) {
        var _k = _pairs[i];
        var _j = i - 1;
        while (_j >= 0 && _pairs[_j].d < _k.d) { _pairs[_j + 1] = _pairs[_j]; _j -= 1; }
        _pairs[_j + 1] = _k;
    }
    // A seeded rotation of the equally-distant ones is what makes two boards differ: on a 3x3
    // lattice the four corners are all at the same distance, so which diagonal a TWO uses is a
    // genuine design choice and not an accident of sort order.
    var _rot = pas_rng_int(_r, 0, max(0, array_length(_pairs) - 1));
    var _ord = array_create(array_length(_pairs));
    for (var i = 0; i < array_length(_pairs); i++) {
        _ord[i] = _pairs[(i + _rot) mod array_length(_pairs)];
    }

    var _out = array_create(_faces + 1, []);
    for (var v = 1; v <= _faces; v++) {
        var _pips = [];
        var _odd = (v & 1) == 1;
        var _np = v div 2;
        if (_odd && _hasCentre) array_push(_pips, 0, 0);
        // ⛔ An odd value on an EVEN lattice has no centre to put the odd pip on. Rather than
        // silently drawing v-1 pips - a die whose five reads as a four - the extra pip goes on the
        // next pair position, breaking symmetry for that one value ONLY, and pas_dice_symmetric
        // reports it honestly instead of the suite asserting something that cannot be true.
        if (_odd && !_hasCentre) _np += 1;
        for (var k = 0; k < _np && k < array_length(_ord); k++) {
            var _p = _ord[k];
            array_push(_pips, _p.x, _p.y);
            if (!(_odd && !_hasCentre && k == _np - 1)) array_push(_pips, -_p.x, -_p.y);
        }
        _out[v] = _pips;
    }
    return _out;
}

/// @desc Is this generated face point-symmetric? Reported, never assumed.
///
/// The suite asserts this is TRUE for every value on an odd lattice - the case the design intends -
/// and it exists as a function rather than as an assertion so the renderer and the label can be
/// honest about the even-lattice odd-value case instead of the product quietly pretending.
function pas_dice_symmetric(_board, _v) {
    var _p = _board.layout[_v];
    var _n = array_length(_p) div 2;
    for (var i = 0; i < _n; i++) {
        var _x = _p[i * 2], _y = _p[i * 2 + 1];
        var _found = false;
        for (var j = 0; j < _n; j++) {
            // Tolerance 0.0001, never smaller: GML's default comparison epsilon is 0.00001 on this
            // runtime, so a tighter one can never fire and the check would pass vacuously forever.
            if (abs(_p[j * 2] + _x) < 0.0001 && abs(_p[j * 2 + 1] + _y) < 0.0001) {
                _found = true; break;
            }
        }
        if (!_found) return false;
    }
    return true;
}

/// @desc How many pips a generated value actually carries. The suite asserts it equals the value.
function pas_dice_pip_count(_board, _v) {
    return array_length(_board.layout[_v]) div 2;
}

/// @desc Roll the unheld dice, or toggle a hold. input {act:"press",u,v} toggles; anything else rolls.
/// @return {string} "rolled" | "held" | "freed" | "spent" | "over"
function pas_dice_step(_board, _input) {
    if (_board.over) return "over";

    var _u = pas_input_u(_input), _v = pas_input_v(_input);
    if (_u >= 0 && _v >= 0) {
        var _i = pas_dice_at(_board, _u, _v);
        if (_i < 0) return "spent";
        _board.held[_i] = !_board.held[_i];
        return _board.held[_i] ? "held" : "freed";
    }

    if (_board.rolls <= 0) { _board.over = true; return "over"; }
    for (var i = 0; i < _board.n; i++) {
        if (!_board.held[i]) _board.values[i] = pas_rng_int(_board.rng, 1, _board.faces);
    }
    _board.rolls -= 1;
    _board.score = pas_dice_score(_board);
    if (_board.rolls <= 0) _board.over = true;
    return "rolled";
}

/// @desc Score the current hand: the largest set, times its face, plus a straight bonus.
///
/// Deliberately a COMPLETE little game rather than a roller. A die roller is a utility and this
/// wing's price law puts utilities at $1-10 regardless of quality.
function pas_dice_score(_board) {
    var _count = array_create(_board.faces + 1, 0);
    for (var i = 0; i < _board.n; i++) _count[_board.values[i]] += 1;
    var _best = 0;
    for (var v = 1; v <= _board.faces; v++) {
        var _s = _count[v] * v * _count[v];       // a set is worth more the longer it is
        if (_s > _best) _best = _s;
    }
    var _run = 0, _bestrun = 0;
    for (var v = 1; v <= _board.faces; v++) {
        if (_count[v] > 0) { _run += 1; if (_run > _bestrun) _bestrun = _run; } else _run = 0;
    }
    if (_bestrun >= 4) _best += _bestrun * 8;
    return _best;
}

/// @desc Which die is under a point, or -1. Shares its geometry with the renderer through
///       pas_dice_slot, so a hit test and a picture cannot disagree.
function pas_dice_at(_board, _u, _v) {
    for (var i = 0; i < _board.n; i++) {
        var _s = pas_dice_slot(_board, i);
        if (_u >= _s[0] && _u <= _s[0] + _s[2] && _v >= _s[1] && _v <= _s[1] + _s[3]) return i;
    }
    return -1;
}

/// @desc Die i's rect in BOARD space: [u, v, uw, vh].
///
/// ⛔⛔ vh IS uw TIMES THE BOARD'S ASPECT, NOT uw. THIS SHIPPED AS `_dh = _dw * 1.0` AND EVERY DIE
/// IN THE PRODUCT WAS A WIDE LOZENGE. Board space is 0..1 in BOTH axes over a rect that is 2.6
/// times wider than it is tall, so equal fractions of u and v are NOT equal lengths - a "square"
/// written that way comes out 2.6:1. MEASURED 2026-09-03 by baking the eight-room sheet and looking
/// at it: five flat white capsules on a bed of horizontal stripes, with the pips invisible because
/// they were sized off the smaller dimension of a shape that had no smaller dimension worth having.
///
/// ⭐ This is the same family as pas_ring's units mismatch two hours earlier and as Borough's eaves
/// shadow: A DIMENSION IN ONE AXIS DERIVED FROM A DIMENSION IN ANOTHER. pas_geom's pas_ms exists
/// precisely so lengths do not have to be reasoned about per axis; a rect is the one thing that
/// cannot go through it, so a rect has to carry the conversion itself.
///
/// The clamp is real, not defensive: at eight dice the square height would exceed the felt, and a
/// die drawn taller than the table is a worse failure than a slightly smaller one.
function pas_dice_slot(_board, _i) {
    var _m = _board.railw + 0.045;
    var _inner = 1 - _m * 2;
    var _gap = _inner * 0.055;
    var _asp = pas_dice_aspect(_board);
    var _dw = (_inner - _gap * (_board.n - 1)) / _board.n;
    var _dh = _dw * _asp;
    if (_dh > _inner) { _dh = _inner; _dw = _dh / _asp; }
    return [ _m + _i * (_dw + _gap), 0.5 - _dh * 0.5, _dw, _dh ];
}

function pas_dice_label(_board) {
    return "DICE  " + string(_board.n) + "d" + string(_board.faces)
         + "   " + string(_board.lat) + "x" + string(_board.lat) + " pip lattice"
         + "   score " + string(_board.score);
}

function pas_dice_aspect(_board) { return clamp(_board.n * 0.42 + 0.5, 1.2, 3.2); }

/// @desc How many nap strokes the felt gets. A pitch in real pixels, so the pile does not get
///       coarser on a bigger table - a material's grain is a physical constant.
function pas_dice_nap_rows(_f) {
    var _pitch = pas_detail(_f, 0.012, 4, 11) / max(1, _f.h);
    return max(2, floor(1 / _pitch));
}

/// @desc The two v coordinates of nap stroke i: [left end, right end], in BOARD space.
///
/// ⛔ EXISTS SO THE SUITE CAN ASSERT CONTAINMENT. The nap is a direct draw call that emits no
/// geometry, so no downstream check can ever see it - Hearth's firelight wash drew hundreds of
/// pixels outside its rect for exactly that reason, past a containment assertion that walked the
/// part list. The rows are computed here, clamped here, and asserted here.
function pas_dice_nap_v(_f, _board, _i) {
    var _pitch = pas_detail(_f, 0.012, 4, 11) / max(1, _f.h);
    var _lean = sin(degtorad(_board.nap * 22.5)) * 0.06;
    var _v0 = 0.02 + _i * _pitch;
    var _v1 = _v0 + _lean;
    return [ clamp(_v0, 0.02, 0.98), clamp(_v1, 0.02, 0.98) ];
}

/// @desc Draw the board.
function pas_dice_draw(_board, _x, _y, _w, _h, _pal) {
    var _f = pas_map(_x, _y, _w, _h);
    var _rw = _board.railw;

    // -- felt bed, with nap -----------------------------------------------
    pas_rrect(_f, 0, 0, 1, 1, pas_detail(_f, 0.012, 2, 12), _pal.m2);
    // Nap is TONE, so it is spacing and length, never line width (pas_geom law 4).
    //
    // ⛔⛔ AND IT MUST STAY INSIDE THE BOARD. The first version started at v = -0.2 and ran to
    // v = 1.4, so on the dice store sheet the pile ran off the table, across the page and THROUGH
    // THE SHEET'S OWN TITLE - the same defect as pas_range's lane guides, in the same session, in a
    // second room. A public draw call that takes a rect must be asserted to stay inside it, and
    // "it looked fine" only ever tested the one rect that happened to be big enough.
    //
    // ⚠️ A wash is a direct draw call and emits no geometry, so nothing downstream can see it. That
    // is Hearth's law exactly: compute the rows in ONE function and let the suite assert THAT.
    var _nrows = pas_dice_nap_rows(_f);
    for (var i = 0; i < _nrows; i++) {
        var _nv = pas_dice_nap_v(_f, _board, i);
        // Softer than the first build: the nap was a set of hard light-and-dark bands across the
        // whole table and read as corduroy rather than as baize. 0.30 keeps it a texture.
        pas_line(_f, 0.02, _nv[0], 0.98, _nv[1], 1,
                 (i & 1) ? merge_colour(_pal.m2, _pal.m3, 0.30)
                         : merge_colour(_pal.m2, _pal.m1, 0.26));
    }

    // -- rails: four mitred lengths, not one frame ------------------------
    // ⛔ Mitred deliberately. Four butted rectangles read as a picture frame from a shop; four
    // trapezoids meeting on the diagonal read as joinery, and this cabinet is furniture.
    //
    // ⛔ AND THE RAIL WIDTH IS ONE PHYSICAL MEASUREMENT CONVERTED PER AXIS. Written as a single
    // fraction of both, a rail on a 3:1 table is three times wider down the sides than it is deep
    // across the ends - which is not joinery, it is a drawing mistake. This wing has the same law
    // from Borough, where a vertical dimension taken from a horizontal one put a band a fifth of a
    // wall deep under the eaves of every cottage.
    var _railpx = pas_detail(_f, _rw, 4, 34);
    var _ru = _railpx / max(1, _f.w);
    var _rv = _railpx / max(1, _f.h);
    var _rail = [
        [ 0,0,  1,0,  1 - _ru, _rv,  _ru, _rv ],                       // top
        [ 1,0,  1,1,  1 - _ru, 1 - _rv,  1 - _ru, _rv ],               // right
        [ 1,1,  0,1,  _ru, 1 - _rv,  1 - _ru, 1 - _rv ],               // bottom
        [ 0,1,  0,0,  _ru, _rv,  _ru, 1 - _rv ]                        // left
    ];
    var _rcol = [ _pal.w4, _pal.w1, _pal.w0, _pal.w2 ];   // lamp fixed at the upper left
    for (var i = 0; i < 4; i++) pas_poly(_f, _rail[i], _rcol[i]);
    pas_rrect_edge(_f, _ru, _rv, 1 - _ru * 2, 1 - _rv * 2,
                   pas_detail(_f, 0.006, 1, 5), pas_detail(_f, 0.004, 1, 3), _pal.w0);

    // -- the dice ---------------------------------------------------------
    for (var i = 0; i < _board.n; i++) {
        var _s = pas_dice_slot(_board, i);
        var _du = _s[0], _dv = _s[1], _dw = _s[2], _dh = _s[3];
        var _rad = pas_detail(_f, _board.corner * 0.30, 2, 40);

        // a held die sits on a brass plate - state visible without reading a word
        if (_board.held[i]) {
            pas_rrect(_f, _du - _dw * 0.07, _dv - _dh * 0.07,
                      _dw * 1.14, _dh * 1.14, _rad * 1.2, _pal.b2);
        }
        // seated shadow, then the bone body
        pas_rrect(_f, _du + _dw * 0.035, _dv + _dh * 0.045, _dw, _dh, _rad, _pal.w0);
        pas_plate(_f, _du, _dv, _dw, _dh, _rad, _pal.m4, _pal.b4, _pal.m1);

        var _v = _board.values[i];
        if (_v > _board.faces) _v = _board.faces;

        if (_board.faces <= 6) {
            // -- drilled pips ----------------------------------------------
            // A pip is a PIT: a dark disc with a LIT lower rim, because a drilled hollow catches
            // the lamp on the wall furthest from it. A flat black dot is a sticker.
            var _lay = _board.layout[_v];
            var _spread = 0.30;
            for (var k = 0; k < array_length(_lay); k += 2) {
                var _pu = _du + _dw * (0.5 + _lay[k] * _spread);
                var _pv = _dv + _dh * (0.5 + _lay[k + 1] * _spread);
                var _rr = _board.pip * min(_dw * _f.w, _dh * _f.h) / max(1, _f.s);
                pas_disc(_f, _pu, _pv + _rr * 0.16, _rr, _pal.m1);
                pas_disc(_f, _pu, _pv, _rr * 0.92, _pal.w0);
            }
        } else {
            // -- numeral faces ---------------------------------------------
            // Above six, pips stop being countable at a glance and a numeral is what a real
            // polyhedral die carries. The face still gets its generated corner and bevel.
            pas_text_fit(_f, string(_v), _du + _dw * 0.5, _dv + _dh * 0.5,
                         _dw * 0.62, _pal.w0, fa_center, fa_middle);
        }
    }
}
