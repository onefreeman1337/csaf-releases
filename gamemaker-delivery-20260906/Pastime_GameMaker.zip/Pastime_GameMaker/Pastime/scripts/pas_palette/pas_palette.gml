/// PASTIME - pas_palette. The colour layer, and one of the two files that make this a CABINET.
///
/// The candidate's stated risk is BREADTH: eight minigames is eight visual languages, and if the
/// house style does not hold in all eight the product reads as a mixed-quality bundle rather than
/// as one piece of furniture. This file is half of the answer (pas_geom is the other half): NO ROOM
/// HARD-CODES A COLOUR. Every room asks this file for its bed, its ink and its two accents, and the
/// cabinet housing every room sits in is a SINGLE FIXED RAMP shared by all of them.
///
/// ⇒ the constant is the furniture and the variable is the board. That is what makes eight
/// different visual languages read as eight games in one cabinet.
///
/// -- WHY OKLCH AND NOT HSV ---------------------------------------------------------------------
/// A bed is not a colour, it is a RAMP: five stops from the lit lip of a rail down to the shadow
/// under it. What makes green baize read as baize rather than as green is that those stops are
/// evenly spaced in APPARENT lightness, and that the spacing survives being re-hued to walnut, to
/// solder mask, to sisal, to printed card. In HSV "same saturation" means wildly different apparent
/// contrast across the hue circle, so a ramp tuned on warm wood collapses on cold green - and every
/// mark this cabinet draws on a bed would merge into it on half the themes with no change to a line
/// of the buyer's code. Oklab spaces colour by how it LOOKS, for about twenty lines of matrix
/// arithmetic, and that is the only reason pas_selftest can assert a separation floor across every
/// theme and have the assertion mean something.
///
/// ⛔ THE TWO COLOUR LAWS THIS WING HAS PAID MOST FOR, both enforced below:
///   1. A RAMP SLIDES TO FIT AND IS NEVER CLAMPED AT ITS ENDS. Hearth's limewash clamped its top
///      two stops to the same value and drew a dome as a flat fill with a line round it. pas_ramp
///      translates the whole ramp into the legal range and only compresses when the span is wider
///      than the entire lightness axis - and reports that it did.
///   2. `ink` IS NOT A RAMP STOP. On a light material every stop is light: Lexicon set a caption in
///      the material's deepest stop on parchment (ground L 0.80, deepest stop 0.62) and it was
///      invisible. The ramp describes how a SURFACE turns in the light; the thing that CONTRASTS
///      with a surface is what you write on it. pas_pal derives ink from the ground with an
///      asserted separation floor, in the direction that has room.
///
/// ⛔ GML APPLIES A DEFAULT EPSILON TO NUMERIC COMPARISONS - 0.00001 on this runtime, MEASURED by
/// the Raiment suite. Any tolerance at or below about 0.00001 can NEVER fire in either direction.
/// GML also has NO exponent-literal syntax: `1e-5` is a lexer error that reads like a bracket bug.
/// Every tolerance in this package is written out in full and none is below 0.0001.
/// ================================================================================================

/// The legal lightness range. Not 0..1: pure black and pure white are not surfaces, they are the
/// absence of one, and a ramp that reaches either end loses its top or bottom stop to the gamut.
#macro PAS_L_FLOOR 0.070
#macro PAS_L_CEIL  0.965

/// The separation an ink must have from its own ground to be legible. Asserted by the suite over
/// every theme, so it is a property of the corpus rather than a number someone liked.
#macro PAS_INK_SEP 0.34

/// Oklab -> linear sRGB. Bjorn Ottosson's matrices.
function pas_oklab_linear(_L, _a, _b) {
    var _l = _L + 0.3963377774 * _a + 0.2158037573 * _b;
    var _m = _L - 0.1055613458 * _a - 0.0638541728 * _b;
    var _s = _L - 0.0894841775 * _a - 1.2914855480 * _b;
    _l = _l * _l * _l; _m = _m * _m * _m; _s = _s * _s * _s;
    return [
         4.0767416621 * _l - 3.3077115913 * _m + 0.2309699292 * _s,
        -1.2684380046 * _l + 2.6097574011 * _m - 0.3413193965 * _s,
        -0.0041960863 * _l - 0.7034186147 * _m + 1.7076147010 * _s
    ];
}

function pas_gamma(_c) {
    return (_c <= 0.0031308) ? (12.92 * _c) : (1.055 * power(_c, 1 / 2.4) - 0.055);
}

/// Chroma ceiling near white and near black.
///
/// Oklab will happily hand back a fully-saturated colour at L 0.95 and sRGB renders it as neon.
/// Real pigment gets LESS chromatic as it approaches paper-white or lamp-black; this curve puts
/// that back, and it is what keeps a lacquered fairground wheel looking expensive rather than
/// radioactive.
function pas_chroma_ceiling(_L, _C) {
    var _hi = max(0, (_L - 0.68) / 0.32);
    var _lo = max(0, (0.22 - _L) / 0.22);
    return _C * (1 - _hi * 0.62) * (1 - _lo * 0.45);
}

/// Oklch -> a GameMaker colour, with GAMUT REDUCTION rather than clipping.
///
/// Clipping an out-of-gamut colour shifts its HUE - a too-saturated blue clips to purple - which
/// would quietly undo the perceptual spacing this whole file exists to provide. Walking chroma down
/// until the colour fits keeps the hue exactly where it was put.
function pas_oklch(_L, _C, _hdeg) {
    var _h = degtorad(_hdeg);
    var _c = pas_chroma_ceiling(_L, _C);
    var _rgb;
    for (var _i = 0; _i < 24; _i++) {
        _rgb = pas_oklab_linear(_L, cos(_h) * _c, sin(_h) * _c);
        if (_rgb[0] >= -0.0015 && _rgb[1] >= -0.0015 && _rgb[2] >= -0.0015
         && _rgb[0] <=  1.0015 && _rgb[1] <=  1.0015 && _rgb[2] <=  1.0015) break;
        _c *= 0.92;
    }
    _rgb = pas_oklab_linear(_L, cos(_h) * _c, sin(_h) * _c);
    return make_colour_rgb(
        round(clamp(pas_gamma(clamp(_rgb[0], 0, 1)), 0, 1) * 255),
        round(clamp(pas_gamma(clamp(_rgb[1], 0, 1)), 0, 1) * 255),
        round(clamp(pas_gamma(clamp(_rgb[2], 0, 1)), 0, 1) * 255)
    );
}

/// @desc Five stops of one material, evenly spaced in apparent lightness.
///
/// LAW 1 IS IMPLEMENTED HERE. The requested span is centred on `_L`, then TRANSLATED until it fits
/// between the floor and the ceiling. Translation preserves every gap; clamping destroys the gap at
/// whichever end hit the wall, and two identical stops render a bevel as a flat fill with a line
/// round it. Compression happens only when the span is wider than the whole legal axis, which no
/// material in this cabinet asks for - the suite asserts that the compressed branch is never taken.
///
/// @param {real} _L     ground lightness, the ramp's centre
/// @param {real} _C     chroma
/// @param {real} _h     hue in degrees
/// @param {real} _span  total lightness travel from stop 0 to stop 4
/// @return {array} 5 colours, index 0 darkest
function pas_ramp(_L, _C, _h, _span) {
    var _lim = pas_ramp_limits(_L, _span);
    var _out = array_create(5);
    for (var i = 0; i < 5; i++) {
        _out[i] = pas_oklch(_lim[0] + (_lim[1] - _lim[0]) * (i / 4), _C, _h);
    }
    return _out;
}

/// @desc The lightness endpoints pas_ramp will use, as pure arithmetic.
///
/// Split out from pas_ramp on purpose: the suite has to be able to assert the SLIDE (that the gaps
/// survive) without going through make_colour_rgb, which quantises to 8 bits per channel and would
/// let a 0.004 lightness gap read as identical. Testing the colours tests the quantiser; testing
/// this tests the law.
/// @return {array} [lo, hi, compressed]  compressed is true only if the span had to be shortened
function pas_ramp_limits(_L, _span) {
    var _lo = _L - _span * 0.5;
    var _hi = _L + _span * 0.5;
    if (_lo < PAS_L_FLOOR) { var _d = PAS_L_FLOOR - _lo; _lo += _d; _hi += _d; }
    if (_hi > PAS_L_CEIL)  { var _e = _hi - PAS_L_CEIL;  _lo -= _e; _hi -= _e; }
    if (_lo < PAS_L_FLOOR) return [ PAS_L_FLOOR, PAS_L_CEIL, true ];
    return [ _lo, _hi, false ];
}

/// @desc The colour to WRITE on a ground - never a stop of the ground's own ramp.
///
/// LAW 2. Travels away from the ground in whichever direction has room, by at least PAS_INK_SEP,
/// and drops most of the chroma: ink is a mark, not a second material, and a mark that carries the
/// ground's full chroma reads as a colour wash rather than as something written.
function pas_ink_for(_L, _C, _h) {
    var _dir = (_L >= 0.5) ? -1 : 1;
    var _t = _L + _dir * 0.50;
    if (_t < PAS_L_FLOOR) _t = PAS_L_FLOOR;
    if (_t > PAS_L_CEIL)  _t = PAS_L_CEIL;
    // If the clamp above ate the separation, go the other way instead. Only reachable for a ground
    // in the middle of the axis with an extreme floor/ceiling, which no theme here has - but a
    // buyer's own theme can, and silently illegible text is the failure this file exists to stop.
    if (abs(_t - _L) < PAS_INK_SEP) {
        var _o = _L - _dir * 0.50;
        if (_o >= PAS_L_FLOOR && _o <= PAS_L_CEIL) _t = _o;
    }
    return pas_oklch(_t, _C * 0.35, _h);
}

/// @desc The lightness pas_ink_for will land on. Same split as pas_ramp_limits, same reason.
function pas_ink_L(_L) {
    var _dir = (_L >= 0.5) ? -1 : 1;
    var _t = _L + _dir * 0.50;
    if (_t < PAS_L_FLOOR) _t = PAS_L_FLOOR;
    if (_t > PAS_L_CEIL)  _t = PAS_L_CEIL;
    if (abs(_t - _L) < PAS_INK_SEP) {
        var _o = _L - _dir * 0.50;
        if (_o >= PAS_L_FLOOR && _o <= PAS_L_CEIL) _t = _o;
    }
    return _t;
}

/// ================================================================================================
/// THE CABINET. One ramp, every theme, every room - this is the furniture.
/// ================================================================================================
/// Dark stained walnut with brass. It is deliberately NOT a parameter: the moment the housing can
/// change per room, eight rooms become eight products sharing a folder. A buyer who wants a
/// different cabinet edits this one function, and every room follows it.
function pas_cabinet_pal() {
    static _c = undefined;
    if (is_undefined(_c)) {
        var _wood  = pas_ramp(0.255, 0.048, 52,  0.30);   // stained walnut carcass
        var _brass = pas_ramp(0.660, 0.092, 88,  0.42);   // the fittings, the score bezel, the pins
        _c = {
            w0 : _wood[0], w1 : _wood[1], w2 : _wood[2], w3 : _wood[3], w4 : _wood[4],
            b0 : _brass[0], b1 : _brass[1], b2 : _brass[2], b3 : _brass[3], b4 : _brass[4],
            // The room the cabinet stands in. Darker than the carcass so the cabinet reads as an
            // object standing in front of something rather than as a rectangle on a page.
            back  : pas_oklch(0.135, 0.020, 264),
            // The label plate and the type on it. Enamel, not wood: a label is a different material
            // from the thing it is screwed to, which is what makes it read as a label.
            plate : pas_oklch(0.180, 0.014, 258),
            type  : pas_oklch(0.905, 0.020, 88),
            dim   : pas_oklch(0.560, 0.014, 88),
        };
    }
    return _c;
}

/// ================================================================================================
/// THE THEMES. Each one is a BED plus two accents; the cabinet above never changes.
/// ================================================================================================
/// A theme is three numbers for the bed and two hues for the accents, and everything else is
/// derived. Twelve of them, so a cabinet of eight rooms seeded differently does not repeat a
/// colourway - and so that the separation assertions below run over a corpus rather than an example.
///
/// ⚠️ THE BED LIGHTNESSES SPAN THE AXIS ON PURPOSE - 0.19 (etched board) to 0.86 (printed card).
/// A colour transform tuned only on a mid-grey bed is tuned on the one case that needs none of the
/// corrections in this file, which is this wing's standing lesson from Repast: tune on the palest
/// and the most neutral, never on the vivid one.
function pas_theme_count() { return 12; }

function pas_theme_name(_i) {
    static _n = [
        "baize", "solder", "walnut", "sisal", "card", "slate",
        "lacquer", "vellum", "verdigris", "oxblood", "chalk", "gunmetal"
    ];
    return _n[(_i % array_length(_n) + array_length(_n)) % array_length(_n)];
}

/// @desc A full palette for one theme.
/// @param {real} _i  theme index; wraps, so a caller may pass a seed
/// @return {struct}
function pas_pal(_i) {
    //                bedL   bedC   bedH   span   a1 hue  a1 C   a2 hue  a2 C
    static _T = [
        [ 0.360, 0.070, 152,  0.30,  44,    0.115,  16,    0.130 ],  // baize     green cloth, brass, red
        [ 0.235, 0.062, 152,  0.26, 108,    0.105, 196,    0.095 ],  // solder    PCB green, gold, cyan
        [ 0.330, 0.055,  58,  0.32,  86,    0.100,  22,    0.115 ],  // walnut    wood, brass, cherry
        [ 0.560, 0.058,  76,  0.30,  18,    0.135, 232,    0.090 ],  // sisal     dartboard, red, blue
        [ 0.860, 0.018,  92,  0.26,  16,    0.140, 252,    0.110 ],  // card      printed white, red, blue
        [ 0.230, 0.014, 258,  0.28,  76,    0.115, 168,    0.085 ],  // slate     stone, ochre, jade
        [ 0.290, 0.100,  22,  0.34,  92,    0.120, 200,    0.100 ],  // lacquer   fairground red, gilt
        [ 0.790, 0.030,  84,  0.28,  30,    0.120, 168,    0.080 ],  // vellum    parchment, sanguine
        [ 0.480, 0.070, 176,  0.30,  40,    0.110, 340,    0.095 ],  // verdigris aged copper
        [ 0.265, 0.085,  20,  0.30,  84,    0.115, 210,    0.085 ],  // oxblood   deep red leather
        [ 0.905, 0.010, 250,  0.24, 246,    0.115,   8,    0.120 ],  // chalk     near-white, ink blue
        [ 0.315, 0.020, 244,  0.28, 200,    0.105,  46,    0.115 ],  // gunmetal  cold steel, ice, amber
    ];

    var _n = pas_theme_count();
    var _k = ((_i % _n) + _n) % _n;
    var _t  = _T[_k];
    var _bL = _t[0], _bC = _t[1], _bH = _t[2], _sp = _t[3];
    var _bed = pas_ramp(_bL, _bC, _bH, _sp);
    var _a1  = pas_ramp(0.560, _t[5], _t[4], 0.44);
    var _a2  = pas_ramp(0.520, _t[7], _t[6], 0.44);
    var _cab = pas_cabinet_pal();

    return {
        idx  : _k,
        name : pas_theme_name(_k),
        // the bed - the surface a board is drawn ON
        bedL : _bL, bedC : _bC, bedH : _bH,
        m0 : _bed[0], m1 : _bed[1], m2 : _bed[2], m3 : _bed[3], m4 : _bed[4],
        bed : _bed[2],
        // what you WRITE on that bed
        ink   : pas_ink_for(_bL, _bC, _bH),
        inkL  : pas_ink_L(_bL),
        // A second, QUIETER mark for gridlines, guides and silkscreen.
        //
        // ⚠️ 0.62, NOT 0.42. MEASURED 2026-09-03 by opening the circuit sheet: at 0.42 the
        // designators (Q10, D7, TP4) were a pale grey on a pale bed and could not be read at all on
        // card, vellum or chalk - three of twelve themes. "Quieter than ink" has to stay legible or
        // it is not a quieter mark, it is an absent one, and absence in a gap between marks is
        // exactly what a gap between marks looks like.
        guide : merge_colour(_bed[2], pas_ink_for(_bL, _bC, _bH), 0.62),
        // two accents, five stops each
        p0 : _a1[0], p1 : _a1[1], p2 : _a1[2], p3 : _a1[3], p4 : _a1[4],
        q0 : _a2[0], q1 : _a2[1], q2 : _a2[2], q3 : _a2[3], q4 : _a2[4],
        // the cabinet, carried through so a room needs exactly one palette object
        w0 : _cab.w0, w1 : _cab.w1, w2 : _cab.w2, w3 : _cab.w3, w4 : _cab.w4,
        b0 : _cab.b0, b1 : _cab.b1, b2 : _cab.b2, b3 : _cab.b3, b4 : _cab.b4,
        back : _cab.back, plate : _cab.plate, type : _cab.type, dim : _cab.dim,
    };
}
