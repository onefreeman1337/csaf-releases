/// @description PASTIME - the demo. Also the headless entry point.
///
/// A buyer who cannot press Play cannot evaluate the product, so this object is the quickstart, the
/// GIF source and the only real smoke test the wing has. It is also the ONE entry point for the
/// in-engine suite and the store-sheet bake, because a second build configuration is a second thing
/// to keep in step.
///
/// ⛔ EVERY VARIABLE Clean Up READS IS DECLARED ABOVE THE EARLY EXITS. `-selftest` calls game_end
/// partway down this event, and GameMaker fires Clean Up ON THE WAY OUT ANYWAY - so a variable
/// assigned below the exit is read by a teardown that still runs, and the crash is reported against
/// whatever stage the SUITE had reached rather than against the teardown. MEASURED in this wing on
/// Lexicon, where it read as a suite failure in code that had already passed.
///
/// ⛔ AND THE HANDLER IS INSTALLED FIRST. A GML runtime error opens a MODAL DIALOG; headless, the
/// process then never exits and a build step waits forever on something nobody can see. Recording a
/// stage number and ending the game turns an opaque hang into a line naming the stage.

global.pas_stage = -1;

exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("pas_crash.json");
    file_text_write_string(_f, "{\"stage\":" + string(global.pas_stage)
        + ",\"message\":\"" + string_replace_all(string(_ex.message), "\"", "'") + "\""
        + ",\"script\":\"" + string_replace_all(string(_ex.script), "\"", "'") + "\"}");
    file_text_close(_f);
    game_end(1);
});

// ---- everything Clean Up and Draw read, declared BEFORE any exit ---------------------------
cab       = undefined;
mode      = "demo";
attract   = true;
attract_t = 0;
hint      = 0;
seed      = 20260903;

// ---- command line ---------------------------------------------------------------------------
var _args = "";
for (var _ai = 0; _ai < parameter_count(); _ai++) _args += parameter_string(_ai + 1) + " ";

if (string_pos("-selftest", _args) > 0) {
    var _res = pas_selftest_run();
    pas_selftest_write(_res);
    game_end(_res.fail > 0 ? 1 : 0);
    exit;
}

// ⚠️ -gif IS TESTED BEFORE -bake. The two strings do not overlap, so the order is not load-bearing
// today - but the RPG Maker wing lost a session to exactly this shape, and an explicit order costs
// nothing while a shared prefix would be silent.
if (string_pos("-gif", _args) > 0) {
    pas_bake_gif();
    game_end(0);
    exit;
}

if (string_pos("-bake", _args) > 0) {
    pas_bake_all();
    game_end(0);
    exit;
}

// ---- the interactive demo --------------------------------------------------------------------
randomise();
cab = pas_cabinet_new(seed);
pas_cabinet_select(cab, 0);
window_set_caption("Pastime - a cabinet of minigames, each one drawing its own board");
