/// @description Drive the cabinet.
///
/// LEFT/RIGHT walk the rooms, SPACE re-rolls the current board, T cycles the theme, and clicking
/// inside the board sends a pointer input to whichever room is showing. Every one of those goes
/// through the SAME dispatchers a buyer's own game would call - there is no demo-only code path
/// into a room, because a demo-only path is a path the suite never covers and the buyer discovers.

if (is_undefined(cab)) exit;

// ---- attract mode --------------------------------------------------------------------------
// Runs the current room by itself until the first key or click. It is the GIF, and it is also a
// continuous smoke test: anything that would crash under play crashes here, on every run, without
// anyone having to remember to press a button.
if (attract) {
    attract_t += 1;
    if (attract_t mod 14 == 0) pas_cabinet_step(cab, pas_input("key", -1, -1, "auto"));
    if (attract_t mod 300 == 0) {
        pas_cabinet_select(cab, cab.room + 1);
        if (cab.room == 0) {
            seed += 1;
            for (var i = 0; i < pas_room_count(); i++) {
                cab.boards[i] = pas_room_board(pas_room_name(i), seed + i * 2654435761, {});
            }
        }
    }
}

if (keyboard_check_pressed(vk_anykey) || mouse_check_button_pressed(mb_any)) attract = false;

// ---- rooms ----------------------------------------------------------------------------------
if (keyboard_check_pressed(vk_right)) pas_cabinet_select(cab, cab.room + 1);
if (keyboard_check_pressed(vk_left))  pas_cabinet_select(cab, cab.room - 1);
for (var _k = 1; _k <= pas_room_count() && _k <= 9; _k++) {
    if (keyboard_check_pressed(ord(string(_k)))) pas_cabinet_select(cab, _k - 1);
}

// ---- re-roll and theme ------------------------------------------------------------------------
if (keyboard_check_pressed(vk_space)) {
    seed += 7919;
    pas_cabinet_reroll(cab, seed);
    cab.message = "new board";
}
if (keyboard_check_pressed(ord("T"))) {
    cab.theme = (cab.theme + 1) mod pas_theme_count();
    pas_cabinet_select(cab, cab.room);            // re-derives the room's colourway
    cab.message = "theme";
}
if (keyboard_check_pressed(ord("A"))) attract = !attract;
if (keyboard_check_pressed(ord("H"))) hint = 1 - hint;

// ---- the keys the rooms themselves take -------------------------------------------------------
// Passed straight through. The maze wants n/e/s/w; the wheel wants a spin; everything else treats
// an unknown key as "drive yourself", which is what makes ENTER a universal "do something".
if (keyboard_check_pressed(vk_up))    pas_cabinet_step(cab, pas_input("key", -1, -1, "n"));
if (keyboard_check_pressed(vk_down))  pas_cabinet_step(cab, pas_input("key", -1, -1, "s"));
if (keyboard_check_pressed(ord("D"))) pas_cabinet_step(cab, pas_input("key", -1, -1, "e"));
if (keyboard_check_pressed(ord("S"))) pas_cabinet_step(cab, pas_input("key", -1, -1, "w"));
if (keyboard_check_pressed(vk_enter)) pas_cabinet_step(cab, pas_input("key", -1, -1, "auto"));

// The wheel is the one room with a continuous state, so it needs a tick even when nobody presses
// anything. Asking the room rather than testing its name would need a "wants ticks" flag on every
// room; naming it here keeps the room contract at five functions.
if (pas_room_name(cab.room) == "wheel") {
    var _wb = pas_cabinet_board(cab);
    if (is_struct(_wb) && _wb.spinning) pas_cabinet_step(cab, pas_input("key", -1, -1, "tick"));
}

// ---- pointer ---------------------------------------------------------------------------------
if (mouse_check_button_pressed(mb_left)) {
    // Same rect the draw event uses, from the same function with the same aspect - a hit test
    // computed differently from the picture is a game that ignores the player.
    var _r = pas_pad_rect(-1, -1, pas_cabinet_aspect(cab));
    var _uv = pas_cabinet_to_board(cab, _r[0], _r[1], _r[2], _r[3], mouse_x, mouse_y);
    if (_uv[0] >= 0) pas_cabinet_step(cab, pas_input("press", _uv[0], _uv[1], ""));
}
