/// @description Draw the cabinet and the key strip.
///
/// Drawn in the GUI layer so the cabinet is letterboxed to the window rather than to a room, which
/// is what lets the same build be a 520 px GIF source and a 1600 px screenshot with no second path.

if (is_undefined(cab)) exit;

var _p = cab.pal;
draw_set_font(fnt_pastime);
draw_set_colour(_p.back);
draw_rectangle(0, 0, display_get_gui_width(), display_get_gui_height(), false);

// The cabinet takes its PROPORTION from the room showing, so the board fills the opening
// instead of floating in it. See pas_cabinet_aspect - the first build left a quarter of the
// cabinet front as bare reveal and every ink floor read 0.999 over it.
var _r = pas_pad_rect(-1, -1, pas_cabinet_aspect(cab));
pas_cabinet_draw(cab, _r[0], _r[1], _r[2], _r[3]);

// ---- the key strip ---------------------------------------------------------------------------
// Under the cabinet, in the wall colour, so it reads as a card propped against the machine rather
// than as an overlay. It says what the keys do because a demo whose controls are undiscoverable is
// a demo a buyer closes.
if (hint == 0) {
    var _hf = pas_map(_r[0], _r[1] + _r[3], _r[2], max(18, display_get_gui_height() - (_r[1] + _r[3])));
    pas_text_fit(_hf,
        "LEFT / RIGHT or 1-8  room     SPACE  new board     T  theme     CLICK  play     A  attract     H  hide",
        0.5, 0.42, 0.98, _p.dim, fa_center, fa_middle);
}
