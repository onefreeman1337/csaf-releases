/// @description Teardown.
///
/// ⛔ CLEAN UP RUNS EVEN WHEN Create EXITED EARLY. `-selftest` calls game_end partway down Create,
/// and GameMaker still fires this event on the way out - so anything freed here must be GUARDED,
/// not assumed. MEASURED in this wing on Lexicon: an unguarded free of a cache that had never been
/// assigned was reported against the last stage the SUITE had reached, i.e. as a failure in code
/// that had already finished and passed.
///
/// Pastime holds no engine handles at all - no data structures, no surfaces, no buffers - because
/// every board is a plain struct and every generator is pure over its arguments. That is a design
/// property rather than an accident, and it is why there is nothing to free here. The guard stays
/// anyway: the day something IS held, this event will already be shaped correctly.

if (variable_instance_exists(id, "cab")) cab = undefined;
