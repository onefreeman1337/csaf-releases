# PASTIME

**A cabinet of minigames for GameMaker, in which each game generates its own board.**

Version 1.0.0 · GameMaker 2024.14 (LTS runtime) · pure GML, no extensions, no sprites

---

## What this is

Eight complete little games in one cabinet. The point is not that there are eight of them — it is
that **not one of them ships a picture**. Every trace, pad, wedge, pip, pin, cup, segment, wall and
cut piece you will see is computed from a seed at run time. There is no sprite in this package, no
spritesheet, no atlas and no texture page.

| Room | What it generates |
| --- | --- |
| **Circuit** | A routed network: Manhattan traces on two layers, vias at the corners, annular pads with real drill holes, DIP bodies with an orientation notch, a hatched ground pour, silkscreen designators. Open the gates, avoid the ICE, get the signal to the sink. |
| **Darts** | The **number ring itself**, searched — not the standard sequence, and not a shuffle. Alternating sisal beds, a brass spider, doubles and trebles, an upright number ring on a turned surround. 301 down, bust rule, double to finish. |
| **Dice** | **The face design.** Pips are placed on a generated lattice in mirror pairs, so a face is point-symmetric by construction and no two boards carve the same set. Napped felt, mitred rails, drilled pips with a lit rim. Roll, hold, score. |
| **Maze** | Walls, corridors, and a route found by a search that shares nothing with the carver. Perfect or braided, any size. Inked plan view. |
| **Range** | A gallery in perspective: lanes converging to a vanishing point, target faces with generated ring progressions, distance posts, bunting. Targets fall when you hit the bull. |
| **Wheel** | The prize ring, arranged under a wheel-maker's two rules — no two equal values adjacent, and the jackpot flanked by the two meanest segments. Gilt rim, pegs, lamps, a turned hub, a leather flapper that ticks. |
| **Bagatelle** | The pin field, and then **the cup values are measured from it**: 240 sample balls are dropped through the finished field and each cup is priced by how rarely it is reached. Brass pins, a sprung plunger, a return arch. |
| **Tangram** | A silhouette, then its own dissection. Every figure is cut into its own piece set, so every board is solvable by construction and no two share a piece set. Paper-cut flats with hard edges. |

**Twelve themes** re-colour the whole cabinet from one palette layer. No room hard-codes a colour.

---

## Quickstart

1. In GameMaker, **Tools → Import Local Package**, choose `Pastime.yymps`, **Add All**.
2. Open `rm_pas_demo` and press **Play**. The cabinet runs itself in attract mode.
3. `LEFT` / `RIGHT` or `1`–`8` walk the rooms · `SPACE` new board · `T` next theme ·
   `CLICK` play · `A` attract on/off · `H` hide the key strip.

To put a board in your own game, three lines:

```gml
// Create
board = pas_darts_board(irandom(999999), {});
pal   = pas_pal(3);                       // any theme index; it wraps

// Draw
pas_darts_draw(board, 64, 64, 480, 480, pal);

// Step  (u,v are 0..1 across the board; -1 means "drive yourself")
pas_darts_step(board, pas_input("press", _u, _v, ""));
```

Or take the whole cabinet, housing and all:

```gml
cab = pas_cabinet_new(12345);
pas_cabinet_select(cab, 0);
var _r = pas_pad_rect(-1, -1, pas_cabinet_aspect(cab));
pas_cabinet_draw(cab, _r[0], _r[1], _r[2], _r[3]);
```

---

## The contract every room implements

Five functions, the same five for all eight, so a ninth room is five functions and one line in
`pas_rooms()`:

```gml
pas_<room>_board(seed, opts)              // -> a struct. PURE data. No drawing, no engine calls.
pas_<room>_draw(board, x, y, w, h, pal)   // draws that struct and ONLY reads it
pas_<room>_step(board, input)             // advances play; returns a result string
pas_<room>_label(board)                   // the cabinet label for this board
pas_<room>_aspect(board)                  // the shape of cell this board wants
```

`_board` and `_step` are **pure over their arguments**: no engine handles, no data structures, no
globals. That is why the same seed gives the same board on every machine and every run, and why a
board is one integer rather than a blob.

`input` is one struct for all eight rooms: `pas_input(act, u, v, key)`. `u` and `v` are **board
space, 0..1**, not pixels — `pas_cabinet_to_board` converts, and it is the only place that
conversion happens.

---

## Compatibility

- **GameMaker 2024.14 LTS runtime**, built and tested on `runtime-2024.14.4.268`.
- **Pure GML.** No extensions, no DLLs, no shaders, no included files.
- **No sprites, no rooms of ours in your project.** The demo object and demo room are optional —
  delete both and every generator still works.
- **Namespaced to `pas_`.** Scripts `pas_*`, macros `PAS_*`, object `obj_pas_demo`, room
  `rm_pas_demo`, fonts `fnt_pastime*`. GML's global namespace is flat, so nothing here can collide
  with your own code unless you also use the `pas_` prefix.
- **No absolute paths, no hardcoded room or layer indices.** Every board draws into a rect you give
  it, so it works on a surface, in the GUI layer, or straight into a room.
- **GMRT:** this ships against the stable LTS runtime, which GameMaker has stated is supported until
  at least Q1 2028. Nothing here uses a feature GMRT's compatibility layer is documented as
  dropping, but GMRT support is not claimed and is not a dependency.

---

## What has been verified, and what has not

**689 assertions run in-engine**, on an Igor-built `Pastime.exe`, every build. They cover every
room's structural invariants — a maze is solvable AND its walls agree with themselves, a circuit is
reachable with its gates open, every generated die face is point-symmetric and carries its own value
in pips, every tangram piece is convex and the pieces sum to the whole figure, every wheel keeps
both maker rules, no pin stands outside its rails, every range target sits inside its board.

Two of those deserve naming because they are the product's own claims, measured rather than asserted:

- **The dartboard's searched ring beats chance.** Judged against a random baseline measured in the
  same run, over 60 boards: searched 197.4 against random 139.6.
- **Forty boards from forty seeds are all structurally distinct.** Eight rooms, five seeds each, and
  every one of the forty structural fingerprints differs.

**What the suite cannot see, said here rather than left for you to find out:** it computes points
and numbers. It cannot see a fill rule, a draw order, a colour on a page or a picture. Every store
image in this package was rendered by `Pastime.exe` itself and then opened and looked at, because
that is the only instrument for those — and doing it caught six defects the 689 assertions were
completely silent about.

---

## Licence

One developer, unlimited games, commercial or free. Everything the package DRAWS is yours with no
attribution and no revenue share. You may not resell or redistribute the package itself. Full terms
in `LICENSE.txt`; font notices in `Pastime/fonts/THIRD-PARTY-NOTICES.txt`.

**AI disclosure:** this package was written with AI assistance, disclosed truthfully on every
listing that carries it.

---

Core Systems Asset Factory
