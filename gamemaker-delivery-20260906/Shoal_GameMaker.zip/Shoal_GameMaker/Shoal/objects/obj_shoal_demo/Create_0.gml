/// SHOAL - the demo room.
///
/// This object is the buyer's quickstart, the GIF source and the only real smoke test this engine
/// offers, all at once. It is also the FIRST thing a buyer opens, so it is written to be read:
/// everything below is ordinary use of the public API, with no private helpers and no tricks.
///
/// ⛔ IT IS ALSO THE HEADLESS ENTRY POINT. Two command-line flags divert it before any demo state
/// is built:
///     Shoal.exe -selftest   run the in-engine suite, write sho_selftest.json, exit
///     Shoal.exe -bake       render the store sheets, write PNGs, exit
/// Both are driven unattended by Internal_Ops/run_engine.ps1. Neither ships as a feature; they are
/// why this package can be verified at all.

var _mode = "";
for (var _i = 0; _i < parameter_count(); _i++) {
    var _p = string_lower(parameter_string(_i));
    if (_p == "-selftest") _mode = "selftest";
    if (_p == "-bake") _mode = "bake";
}
if (_mode == "selftest") { sho_selftest_main(); exit; }
if (_mode == "bake") { sho_bake_main(); exit; }

/* -- THE WATER ---------------------------------------------------------------------------------
 * Where and when. Everything that can be caught follows from these three, through sho_water's
 * tables - there is no separate list of "fish in this level" anywhere in the package.
 * ------------------------------------------------------------------------------------------- */
biome_i = 3;                                  // reef
season = 0;                                   // spring
hour = 9;
biome = sho_biome_ids()[biome_i];

/* -- THE ROD ----------------------------------------------------------------------------------- */
line_i = 2;                                   // braid
line = sho_line_ids()[line_i];
log = sho_log_new();
fight = undefined;
last_catch = undefined;
card_timer = 0;
message = "Cast a line.";
cast_seed = 20260823;

/* -- THE SHOAL IN THE BACKGROUND ---------------------------------------------------------------
 * Twelve fish rolled from this same water, drifting past. They are not decoration: they are the
 * demonstration. Every one is a different species, drawn from geometry, and none of them is a
 * sprite - which is the product's whole claim, shown rather than stated.
 * ------------------------------------------------------------------------------------------- */
shoal = [];
for (var _i = 0; _i < 12; _i++) {
    var _c = sho_water_roll(biome, season, hour, cast_seed + _i * 977);
    array_push(shoal, {
        sp: _c.sp,
        x: random_range(-200, room_width + 200),
        y: random_range(90, room_height - 90),
        // Bigger fish swim slower, which reads as depth and costs nothing.
        speed: random_range(14, 34) * (1 - clamp(_c.len_cm / 260, 0, 0.55)),
        size: 26 + _c.len_cm * 0.42,
        flip: (irandom(1) == 1),
        bob: random(6.283), bobamp: random_range(3, 9)
    });
}

/// Re-roll the shoal after the water changes, so the screen always shows what is actually here.
restock = function() {
    biome = sho_biome_ids()[biome_i];
    for (var _i = 0; _i < array_length(shoal); _i++) {
        var _c = sho_water_roll(biome, season, hour, cast_seed + _i * 977 + hour * 31 + season * 7);
        shoal[_i].sp = _c.sp;
        shoal[_i].size = 26 + _c.len_cm * 0.42;
    }
};

/// Cast. One call to sho_water_roll decides what is down there; one to sho_fight_begin starts the
/// fight. That is the entire integration a buyer has to write.
cast = function() {
    cast_seed += 7919;
    var _c = sho_water_roll(biome, season, hour, cast_seed);
    if (is_undefined(_c)) { message = "Nothing is feeding here."; return; }
    last_catch = _c;
    fight = sho_fight_begin(_c, line);
    message = "Something takes it.";
};
