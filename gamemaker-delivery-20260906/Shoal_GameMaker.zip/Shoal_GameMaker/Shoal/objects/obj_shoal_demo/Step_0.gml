/// SHOAL demo - Step.
///
/// ⚠️ EVERYTHING TIME-BASED USES delta_time, NOT A FRAME COUNT. sho_tackle's fight is specified in
/// seconds per second, so driving it with a per-frame constant would make the minigame behave
/// differently at 30, 60 and 144 fps - on a machine we do not have.

var _dt = delta_time / 1000000;               // delta_time is MICROseconds
if (_dt <= 0 || _dt > 0.25) _dt = 1 / 60;     // a hitch or a breakpoint must not teleport the fight

/* -- the shoal drifts -------------------------------------------------------------------------- */
for (var _i = 0; _i < array_length(shoal); _i++) {
    var _f = shoal[_i];
    _f.x += (_f.flip ? -_f.speed : _f.speed) * _dt;
    _f.bob += _dt * 1.6;
    if (_f.x < -240) _f.x = room_width + 240;
    if (_f.x > room_width + 240) _f.x = -240;
}

/* -- the fight --------------------------------------------------------------------------------- */
if (!is_undefined(fight) && !sho_fight_over(fight)) {
    // THE ONLY INPUT THE PACKAGE SEES IS A BOOLEAN. sho_tackle takes "is the player reeling" and
    // knows nothing about keyboards - which is why a buyer can drive it from a gamepad, a touch
    // control or an on-screen slider without editing it.
    var _reeling = (keyboard_check(vk_space) || mouse_check_button(mb_left));
    sho_fight_step(fight, _dt, _reeling);

    if (sho_fight_over(fight)) {
        if (fight.state == SHO_FIGHT_LANDED) {
            sho_log_land(log, last_catch);          // sets last_catch.record for the card
            card_timer = 6.5;
            message = last_catch.record ? "A new record." : "Landed.";
        } else {
            sho_log_lost(log);
            message = sho_fight_state_name(fight.state) + ".";
        }
    }
}
if (card_timer > 0) card_timer -= _dt;

/* -- controls ---------------------------------------------------------------------------------- */
if (keyboard_check_pressed(vk_enter) || keyboard_check_pressed(vk_space)) {
    if (is_undefined(fight) || sho_fight_over(fight)) cast();
}
if (keyboard_check_pressed(ord("B"))) {
    biome_i = (biome_i + 1) % array_length(sho_biome_ids());
    restock(); message = sho_biome_name(biome) + ".";
}
if (keyboard_check_pressed(ord("S"))) {
    season = (season + 1) % 4;
    restock(); message = sho_season_name(season) + ".";
}
if (keyboard_check_pressed(ord("T"))) {
    hour = (hour + 3) % 24;
    restock(); message = sho_band_name(sho_hour_band(hour)) + ", " + sho_hour_text(hour) + ".";
}
if (keyboard_check_pressed(ord("L"))) {
    line_i = (line_i + 1) % array_length(sho_line_ids());
    line = sho_line_ids()[line_i];
    message = "Line: " + line + " (" + string(sho_line_rating(line)) + ").";
}
