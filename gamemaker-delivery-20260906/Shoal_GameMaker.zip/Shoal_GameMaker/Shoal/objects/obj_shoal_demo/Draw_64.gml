/// SHOAL demo - Draw GUI.
///
/// Every pixel below comes from the package's own public functions. There is no sprite, no
/// windowskin, no nine-slice and no font beyond the two open-licensed faces sho_render names.

var _w = display_get_gui_width(), _h = display_get_gui_height();

/* -- the water ---------------------------------------------------------------------------------
 * A vertical gradient from the biome's own surface colour to its own deep colour, drawn as bands.
 * sho_water_colour takes a depth, so this is the SAME function the rest of the package uses.
 * ------------------------------------------------------------------------------------------- */
var _bands = 28;
for (var _i = 0; _i < _bands; _i++) {
    draw_set_colour(sho_water_colour(biome, _i / (_bands - 1)));
    draw_rectangle(0, _h * _i / _bands, _w, _h * (_i + 1) / _bands + 1, false);
}

/* -- the shoal ---------------------------------------------------------------------------------
 * Drawn dimmed and slightly small, so the hooked fish reads as the subject. The ink is shaded by
 * depth through sho_livery_ink's own `shade` argument rather than by drawing them translucent -
 * alpha over a gradient makes a fish look like a ghost; a darker ink makes it look further away.
 * ------------------------------------------------------------------------------------------- */
for (var _i = 0; _i < array_length(shoal); _i++) {
    var _f = shoal[_i];
    var _depth = clamp(_f.y / _h, 0, 1);
    var _sp = _f.sp;
    _sp.ink = sho_livery_ink(_sp.livery, -0.06 - _depth * 0.16);
    sho_species_draw_fit(_sp, _f.x, _f.y + sin(_f.bob) * _f.bobamp,
                         _f.size * 1.9, _f.size * 1.2, _f.flip);
}

/* -- the hooked fish ---------------------------------------------------------------------------- */
if (!is_undefined(fight) && !sho_fight_over(fight)) {
    // Distance drives it across the screen: at 1 it is out at the end of the cast, at 0 it is here.
    var _fx = lerp(_w * 0.20, _w * 0.78, clamp(fight.distance, 0, 1));
    var _fy = _h * 0.46 + sin(current_time / 260) * 12;
    var _sp = last_catch.sp;
    _sp.ink = sho_livery_ink(_sp.livery, 0);

    // The line, from the rod tip. It goes TAUT AND STRAIGHT under load and sags when slack, which
    // is the same information the gauge carries, read without looking away from the fish.
    var _strain = sho_fight_strain(fight);
    var _sag = (1 - _strain) * 46;
    draw_set_colour(sho_ui_colour("ink2"));
    var _px = _w * 0.06, _py = _h * 0.14;
    var _pts = sho_qbez([_px, _py], [(_px + _fx) * 0.5, (_py + _fy) * 0.5 + _sag], [_fx, _fy], 16);
    for (var _i = 1; _i < array_length(_pts); _i++) {
        draw_line_width(_pts[_i - 1][0], _pts[_i - 1][1], _pts[_i][0], _pts[_i][1], 1);
    }

    var _size = 60 + last_catch.len_cm * 0.9;
    sho_species_draw_fit(_sp, _fx, _fy, _size * 1.9, _size * 1.15, false);
}

/* -- the gauges --------------------------------------------------------------------------------
 * Drawn from sho_fight_strain and the fight's own fields. The strain gauge changes COLOUR as it
 * approaches the rating - the one number a player must not have to read.
 * ------------------------------------------------------------------------------------------- */
var _gx = 28, _gy = _h - 118, _gw = 300;
sho_ui_plate(_gx - 12, _gy - 16, _gx + _gw + 12, _h - 22,
             sho_ui_colour("plate"), sho_ui_colour("rule"));

if (!is_undefined(fight)) {
    var _strain = sho_fight_strain(fight);
    sho_ui_text(_gx, _gy, "LINE", 1.1, sho_ui_colour("ink2"), fa_left);
    draw_set_colour(sho_ui_colour("well"));
    draw_rectangle(_gx + 62, _gy - 8, _gx + _gw, _gy + 8, false);
    // Cold to hot across the strain range, in Oklch so the steps are perceptually even.
    draw_set_colour(sho_oklch(lerp(0.72, 0.62, _strain), lerp(0.06, 0.20, _strain),
                              lerp(196, 28, _strain)));
    draw_rectangle(_gx + 62, _gy - 8, _gx + 62 + (_gw - 62) * _strain, _gy + 8, false);

    sho_ui_text(_gx, _gy + 26, "FISH", 1.1, sho_ui_colour("ink2"), fa_left);
    draw_set_colour(sho_ui_colour("well"));
    draw_rectangle(_gx + 62, _gy + 18, _gx + _gw, _gy + 34, false);
    draw_set_colour(sho_ui_colour("accent"));
    var _st = clamp(fight.stamina / fight.stamina_max, 0, 1);
    draw_rectangle(_gx + 62, _gy + 18, _gx + 62 + (_gw - 62) * _st, _gy + 34, false);

    sho_ui_text(_gx, _gy + 58, sho_fight_state_name(fight.state), 1.1,
                (fight.state == SHO_FIGHT_RUNNING) ? sho_ui_colour("accent") : sho_ui_colour("ink"),
                fa_left);
    sho_ui_text(_gx + _gw, _gy + 58, line + " / " + string(sho_line_rating(line)), 1.0,
                sho_ui_colour("ink2"), fa_right);
}

/* -- the specimen card, for a few seconds after a catch ----------------------------------------- */
if (card_timer > 0 && !is_undefined(last_catch) && last_catch.record != undefined) {
    var _cw = 320, _ch = 454;
    sho_card_draw(last_catch, _w - _cw - 34, _h * 0.5 - _ch * 0.5, _cw, _ch);
}

/* -- the status line ---------------------------------------------------------------------------- */
sho_ui_plate(0, 0, _w, 54, sho_ui_colour("plate"), undefined);
sho_ui_rule(0, _w, 54, sho_ui_colour("rule"));
sho_ui_text(24, 27, "SHOAL", 1.7, sho_ui_colour("ink"), fa_left, sho_font_title());
sho_ui_text(150, 27,
    sho_biome_name(biome) + "   " + sho_season_name(season) + "   " + sho_hour_text(hour)
    + " (" + sho_band_name(sho_hour_band(hour)) + ")",
    1.15, sho_ui_colour("ink2"), fa_left);
sho_ui_text(_w - 24, 27,
    string(sho_log_species_count(log)) + " species   "
    + string(log.landed) + " landed / " + string(log.caught) + " hooked",
    1.15, sho_ui_colour("ink2"), fa_right);

/* -- the record board --------------------------------------------------------------------------- */
var _board = sho_log_board(log, 5);
if (array_length(_board) > 0 && card_timer <= 0) {
    var _bx = _w - 366, _by = 82;
    sho_ui_plate(_bx, _by, _w - 24, _by + 40 + array_length(_board) * 30,
                 sho_ui_colour("plate"), sho_ui_colour("rule"));
    sho_ui_text(_bx + 16, _by + 22, "RECORDS", 1.1, sho_ui_colour("accent"), fa_left);
    for (var _i = 0; _i < array_length(_board); _i++) {
        var _e = _board[_i];
        var _sp = sho_log_species(_e);
        var _ry = _by + 52 + _i * 30;
        if (!is_undefined(_sp)) {
            _sp.ink = sho_livery_ink(_sp.livery, 0);
            sho_species_draw_fit(_sp, _bx + 40, _ry, 52, 22, false);
        }
        sho_ui_text_fit(_bx + 74, _ry, _sp.name, 0.95, sho_ui_colour("ink"),
                        fa_left, sho_font(), 180);
        sho_ui_text(_w - 40, _ry, string(_e.len_cm) + " cm", 0.95, sho_ui_colour("ink2"), fa_right);
    }
}

/* -- the keys ----------------------------------------------------------------------------------- */
sho_ui_text(_w * 0.5, _h - 22,
    "SPACE hold to reel / cast     B water     S season     T time     L line        " + message,
    1.05, sho_ui_colour("ink2"), fa_center);

draw_set_halign(fa_left);
draw_set_valign(fa_top);
