{
  "$GMScript": "v1",
  "%Name": "sho_fins",
  "isCompatibility": false,
  "isDnD": false,
  "name": "sho_fins",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}