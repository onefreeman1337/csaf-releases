/// ============================================================================================
/// SHOAL - sho_fins: THE CORPUS, half two. 8 fin sets.
///
/// The fin set is the ONLY other thing that changes a fish's outline, so it carries the other half
/// of the identification: 12 forms x 8 sets = 96 silhouettes, and those 96 are what must stay
/// mutually legible at 20px. Patterns and palettes multiply the catalogue and change no outline at
/// all (Motif_Corpus.md §0).
///
/// -- A FIN SET IS A PLACEMENT RULE, NOT A DRAWING ----------------------------------------------
/// Every fin here is sized and positioned from the profile it is attaching to - the body's own edge
/// at that x, its own local depth, its own declared dorsal range. That is what lets `sail` look
/// right on an eel 0.10 deep AND on a disc 0.56 deep from one piece of code. A fin authored at
/// absolute coordinates would be a dorsal on one form and a hat on another.
///
/// ⛔ AND THE BUDGET IS SOLVED, NEVER CHECKED AFTER THE FACT. Each form declares `finbudget` - the
/// furthest |y| any fin on it may reach - and every ridge below is CLAMPED against the body edge it
/// grows from, so a fin physically cannot overflow. The wing's constitution is explicit about why:
/// a panel sized by choosing a number and hoping a checker notices is how a clipped plate shipped
/// invisible to an ink-bounds check. sho_selftest still measures it, but the measurement should
/// never be what saves us.
///
/// COORDINATES. Same unit box, same y-DOWN, same tail-left / head-right as sho_forms.
/// `_side` is -1 for the back and +1 for the belly, everywhere in this file.
/// ============================================================================================

/// The 8 fin set ids, in the order Motif_Corpus.md §3 declares them.
function sho_fin_ids() {
    return ["plain", "sail", "twin", "trail", "fringe", "wing", "spine", "lobe"];
}

function sho_fin_name(_id) {
    switch (_id) {
        case "plain":  return "Plain";
        case "sail":   return "Sail";
        case "twin":   return "Twin";
        case "trail":  return "Trail";
        case "fringe": return "Fringe";
        case "wing":   return "Wing";
        case "spine":  return "Spine";
        case "lobe":   return "Lobe";
    }
    return "?";
}

/// ============================================================================================
/// RIDGE PROFILES
///
/// A ridge is a fin grown off one edge of the body between two axial positions. Its OUTER edge is
/// this shape function times the fin's height; its INNER edge is the body itself.
///
/// ⚠️ `t` RUNS AFT TO FORE, matching u. A shape that peaks at t=0.2 peaks near the TAIL. Getting
/// this backwards moves every dorsal fin onto the head and the mistake is invisible on a
/// symmetrical form, which is half the corpus.
/// ============================================================================================

function sho_fin_shape(_t, _kind) {
    switch (_kind) {
        // A triangle, peaking forward of centre. The null case: small, unmistakably a fin.
        case "tri":    return (_t < 0.42) ? (_t / 0.42) : ((1 - _t) / 0.58);
        // Rises fast, holds high, falls fast: the loudest outline in the corpus.
        case "sail":   return power(sin(_t * pi), 0.30);
        // A rounded paddle - soft everywhere, no straight edge and no corner.
        case "round":  return power(sin(_t * pi), 0.62);
        // Low and continuous, with only the last few percent tapering, so it thickens the outline
        // evenly instead of reading as a lump.
        case "fringe": return clamp(min(_t, 1 - _t) * 8.5, 0, 1);
        // Modest over the body, then a long filament streaming off the AFT end.
        case "trail":  return (_t < 0.30) ? (0.30 + 0.70 * (_t / 0.30))
                                          : (1.00 - 0.62 * ((_t - 0.30) / 0.70));
    }
    return 0;
}

/// One membraned fin along a body edge.
///
/// The inner edge is sampled from the body itself rather than assumed flat, so a fin on `hatchet`'s
/// curved keel follows the keel and leaves no gap. `_h` is the height BEFORE the budget clamp; the
/// clamp is per-sample, so a fin on a deep part of the body is shortened exactly where it needs to
/// be rather than the whole fin being scaled down.
function sho_fin_ridge(_dst, _prof, _u0, _u1, _h, _kind, _side, _role) {
    var _s = _prof.spec;
    var _n = 20;
    var _in = array_create(_n + 1), _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        // The u range is clamped as well as the x: `sail` deliberately asks for dorsal0 - 10% and
        // dorsal1 + 10% so its fin overhangs the declared range, and on a form whose dorsal range
        // already reaches the ends that would run the fin off the snout.
        var _x = clamp(lerp(lerp(_s.x0, _s.x1, clamp(_u0, 0, 1)),
                            lerp(_s.x0, _s.x1, clamp(_u1, 0, 1)), _t),
                       _prof.x[0], _prof.x[_prof.n]);
        var _sp = sho_form_span(_prof, _x);
        var _base = (_side < 0) ? _sp[0] : _sp[1];
        var _want = _h * sho_fin_shape(_t, _kind);
        // THE BUDGET, SOLVED. Room left between this edge and the form's own ceiling.
        var _room = max(0, _s.finbudget - abs(_base));
        var _use = min(_want, _room);
        _in[_i]  = [_x, _base - _side * 0.002];
        _out[_i] = [_x, _base + _side * _use];
    }
    array_push(_dst, sho_strip(_in, _out, _role));
    return _dst;
}

/// A row of bare spines with no membrane between them: the only serrated contour in the corpus.
function sho_fin_spines(_dst, _prof, _u0, _u1, _h, _count, _side, _role) {
    var _s = _prof.spec;
    for (var _i = 0; _i < _count; _i++) {
        var _t = (_count == 1) ? 0.5 : (_i / (_count - 1));
        var _x = clamp(lerp(lerp(_s.x0, _s.x1, clamp(_u0,0,1)), lerp(_s.x0, _s.x1, clamp(_u1,0,1)), _t), _prof.x[0], _prof.x[_prof.n]);
        var _sp = sho_form_span(_prof, _x);
        var _base = (_side < 0) ? _sp[0] : _sp[1];
        var _room = max(0, _s.finbudget - abs(_base));
        // Tallest at the shoulder, shortening aft - a comb of equal teeth reads as machinery.
        var _use = min(_h * (0.46 + 0.54 * power(_t, 0.8)), _room);
        var _half = 0.0135 + 0.006 * (1 - _t);
        array_push(_dst, sho_fill([
            [_x - _half, _base], [_x + _half * 0.55, _base + _side * _use], [_x + _half, _base]
        ], _role));
    }
    return _dst;
}

/// The caudal fin, built as a fan from the peduncle centre.
///
/// ⛔ THE FAN'S ANCHOR IS THE PEDUNCLE CENTRE AND EVERY OTHER POINT MUST BE VISIBLE FROM IT. That
/// is sho_geom's stated rule for a fill, and a fork's inner notch is the point that tests it: put
/// the notch further out than the lobe tips and the fan folds over itself into a bow tie, silently,
/// because it is still a legal triangle list.
function sho_fin_caudal(_dst, _prof, _kind, _role) {
    var _s = _prof.spec;
    if (_s.tail <= 0) return _dst;                 // `ray` carries a whip instead - sho_forms extra

    var _yt = _prof.yt[0], _yb = _prof.yb[0];
    var _cx = _prof.x[0], _cy = (_yt + _yb) * 0.5;
    var _half = max(0.018, (_yb - _yt) * 0.5);

    // ⛔ THE PER-KIND MULTIPLIER IS APPLIED BEFORE THE CLAMP, NOT AFTER. The first version clamped
    // `_len` to the budget and THEN multiplied it by 1.34 for `trail`, which put the clamp on the
    // wrong side of the arithmetic and pushed six pairings past SHO_BODY_BOX. The suite caught it;
    // it is fixed here rather than by widening the budget, because the budget is the product's own
    // promise that a specimen fits its frame.
    var _mul = (_kind == "trail") ? 1.34 : 1.00;
    var _spd = (_kind == "trail") ? 1.30 : 1.00;
    // The room left along x before the tail tip leaves the disc, with a hair of margin.
    var _room = max(0.045, SHO_BODY_BOX - abs(_cx) - 0.014);
    var _len = min(_half * _s.tail * 2.35 * _mul, _room) / _mul;
    var _sprd = min(_half * _s.tail * 1.75 * _spd, _s.finbudget - 0.010) / _spd;
    // ⛔ AND CAPPED AGAINST THE BODY IT IS ATTACHED TO. The spread is derived from the PEDUNCLE's
    // depth times the form's `tail` scale, and on a form with a slim peduncle and a large scale -
    // torpedo, spindle - that product exceeded the depth of the whole fish: measured at 0.306 of
    // spread on a body 0.226 deep, which rendered as a pale parachute wider than the animal. A tail
    // is part of a fish and cannot be larger than one.
    _sprd = min(_sprd, sho_form_halfdepth_at(_prof, 0.5) * 1.55);
    _sprd = max(_sprd, 0.026);

    var _p = [];
    array_push(_p, [_cx, _cy]);
    array_push(_p, [_cx + 0.004, _yt]);

    switch (_kind) {
        case "fork": {
            array_push(_p, [_cx - _len, _cy - _sprd]);
            array_push(_p, [_cx - _len * 0.42, _cy]);      // the notch: nearer the anchor than both
            array_push(_p, [_cx - _len, _cy + _sprd]);
        } break;
        case "trail": {
            // Two long streaming lobes and a deep notch. The mass sits BEHIND the body, which is
            // the stated separator from `sail`, whose mass sits above it.
            array_push(_p, [_cx - _len * 1.34, _cy - _sprd * 1.30]);
            array_push(_p, [_cx - _len * 0.30, _cy]);
            array_push(_p, [_cx - _len * 1.34, _cy + _sprd * 1.30]);
        } break;
        case "round": {
            // ⚠️ 0.62 AND 0.78, NOT 0.92 AND 1.0. A rounded tail swept at the same extents as a fork
            // is not a tail, it is a PARACHUTE - measured on the store sheet as a pale half-disc
            // wider than the body it was attached to, on every form with a long peduncle. A fork's
            // spread is carried by two thin lobes; a solid half-ellipse at the same spread has
            // several times the area and reads completely differently.
            var _n = 9;
            for (var _i = 0; _i <= _n; _i++) {
                var _a = -pi * 0.5 + (_i / _n) * pi;      // sweep from top round to bottom
                array_push(_p, [_cx - cos(_a) * _len * 0.62, _cy + sin(_a) * _sprd * 0.78]);
            }
        } break;
        case "stub": {
            array_push(_p, [_cx - _len * 0.44, _cy - _sprd * 0.80]);
            array_push(_p, [_cx - _len * 0.52, _cy]);
            array_push(_p, [_cx - _len * 0.44, _cy + _sprd * 0.80]);
        } break;
    }

    array_push(_p, [_cx + 0.004, _yb]);

    // ⛔ THE RADIAL FIT, AND IT IS THE SAME LESSON AS THE PECTORAL'S, LEARNED TWICE. Clamping x and
    // y separately does NOT bound a radius: torpedo/trail put its lobe tip at x = -0.486 and
    // y = 0.255, both comfortably inside a 0.5 box, with a hypotenuse of 0.549 - well outside the
    // 0.5 DISC the contract is written against. The suite caught it as a reach failure on six
    // pairings after the per-axis clamps had already been "fixed" once.
    //
    // Pulling each point back ALONG ITS OWN DIRECTION preserves the fin's angle and its notch
    // geometry; scaling toward an axis instead would fold a fork into a paddle on exactly the forms
    // where the fork is the identification.
    array_push(_dst, sho_fill(sho_fin_fit(_p), _role));
    return _dst;
}

/// Pull every point of a part back inside the contract disc, along its own direction.
function sho_fin_fit(_pts) {
    var _lim = SHO_BODY_BOX - 0.010;
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _r = point_distance(0, 0, _pts[_i][0], _pts[_i][1]);
        if (_r <= _lim) { _out[_i] = _pts[_i]; continue; }
        var _k = _lim / _r;
        _out[_i] = [_pts[_i][0] * _k, _pts[_i][1] * _k];
    }
    return _out;
}

/// A pectoral fin, swept back and down from the body's own pectoral anchor.
///
/// ⛔ THE TIP IS CLAMPED TO THE DISC, IN BOTH AXES. The first version clamped only y, and the suite
/// found 32 pairings over budget - `ray/wing` at r = 0.80 against a box of 0.50, i.e. more than half
/// again outside the frame. A per-axis clamp does not bound a RADIUS: 0.42 in x and 0.42 in y are
/// both inside a 0.5 square and their hypotenuse is 0.59. So the tip is pulled back ALONG ITS OWN
/// DIRECTION until it fits, which preserves the fin's angle - the thing that distinguishes `wing`
/// from every other set - instead of squashing it toward an axis.
function sho_fin_pectoral(_dst, _prof, _len, _drop, _kind, _role) {
    var _s = _prof.spec;
    var _x = lerp(_s.x0, _s.x1, _s.pect[0]);
    var _sp = sho_form_span(_prof, _x);
    var _half = (_sp[1] - _sp[0]) * 0.5;
    var _y = _sp[2] + _half * _s.pect[1];

    var _tipx = _x - _len;
    var _tipy = clamp(_y + _drop, -_s.finbudget, _s.finbudget);
    var _r = point_distance(0, 0, _tipx, _tipy);
    var _lim = SHO_BODY_BOX - 0.012;
    if (_r > _lim) {
        var _k = _lim / _r;
        _tipx *= _k; _tipy *= _k;
        _len = _x - _tipx;
        _drop = _tipy - _y;
    }

    if (_kind == "round") {
        var _pts = sho_qbez([_x, _y - _half * 0.16], [_x - _len * 0.55, _tipy - _drop * 0.30],
                            [_tipx, _tipy], 10);
        var _back = sho_qbez([_tipx, _tipy], [_x - _len * 0.30, _y + _half * 0.55],
                             [_x, _y + _half * 0.30], 10);
        array_push(_dst, sho_fill(sho_append([[_x, _y]], sho_append(_pts, _back)), _role));
    } else {
        array_push(_dst, sho_fill([
            [_x, _y - _half * 0.20], [_tipx, _tipy], [_x + _len * 0.10, _y + _half * 0.36]
        ], _role));
    }
    return _dst;
}

/// ============================================================================================
/// THE 8 SETS
///
/// Each reads the form's own dorsal range and local depth. `_unit` is the body's greatest depth,
/// so every fin is proportioned to the fish it is on.
/// ============================================================================================

function sho_fin_parts(_prof, _id, _dst) {
    var _s = _prof.spec;
    // The form's own declared fin unit, falling back to the body's LOCAL half-depth at the middle
    // of its dorsal range.
    //
    // ⛔ LOCAL, NOT MAXIMUM. Sizing every fin by the deepest point of the whole body meant that on
    // `hatchet` - a shallow back over a deep keel - the dorsal fin was scaled by a BELLY
    // measurement and came out taller than the fish, rendering as a mushroom on the store sheet.
    // The suite could not see it: the fin was inside its budget, it emitted solid ops, and it was
    // distinct from the other seven. It took opening the PNG.
    var _unit = (_s.finunit > 0) ? _s.finunit
              : sho_form_halfdepth_at(_prof, (_s.dorsal0 + _s.dorsal1) * 0.5);
    var _d0 = _s.dorsal0, _d1 = _s.dorsal1;
    var _span = _d1 - _d0;

    switch (_id) {

        /// The null case. Small triangular dorsal, matching anal fin, forked tail.
        /// ⚠️ It must NOT vanish at 20px - a fin that disappears makes two base forms collide, and
        /// `plain` is the pairing where a form is most exposed. Hence the 0.052 floor.
        case "plain": {
            var _h = max(0.052, _unit * 0.46);
            sho_fin_ridge(_dst, _prof, _d0 + _span * 0.18, _d0 + _span * 0.74, _h, "tri", -1, SHO_R_FIN);
            sho_fin_ridge(_dst, _prof, _d0 + _span * 0.10, _d0 + _span * 0.52, _h * 0.64, "tri", 1, SHO_R_FIN);
            sho_fin_pectoral(_dst, _prof, _unit * 0.52, _unit * 0.40, "tri", SHO_R_FIN);
            sho_fin_caudal(_dst, _prof, "fork", SHO_R_FIN);
        } break;

        /// One dorsal running most of the back, tall enough to roughly double apparent height.
        case "sail": {
            var _h = max(0.108, _unit * 1.02);
            sho_fin_ridge(_dst, _prof, _d0 - _span * 0.10, _d1 + _span * 0.10, _h, "sail", -1, SHO_R_FIN);
            sho_fin_ridge(_dst, _prof, _d0, _d0 + _span * 0.58, _h * 0.30, "tri", 1, SHO_R_FIN);
            sho_fin_pectoral(_dst, _prof, _unit * 0.48, _unit * 0.44, "tri", SHO_R_FIN);
            sho_fin_caudal(_dst, _prof, "fork", SHO_R_FIN);
        } break;

        /// Two separated dorsals, front tall and rear small.
        /// ⛔ THE NOTCH BETWEEN THEM IS THE IDENTIFICATION, so the gap is 18% of the dorsal range
        /// and never less - closed up, this is just a lumpy `sail`, and at 20px the two are the
        /// same picture.
        case "twin": {
            // ⛔ THE HEIGHT RATIO WIDENED FROM 1:0.52 TO 1:0.38 AFTER MEASUREMENT. On the slim forms
            // - torpedo, pike, sunfish - `twin` was measuring within 0.03 of `plain` and of `spine`,
            // i.e. the notch was not perceptible at all and three of the eight sets were one set on
            // those bodies. Two fins of similar height read as one lumpy fin; a tall one and a
            // small one read as two. The GAP does the same work and is widened with it.
            var _h = max(0.090, _unit * 0.86);
            sho_fin_ridge(_dst, _prof, _d0 + _span * 0.56, _d1, _h, "tri", -1, SHO_R_FIN);
            sho_fin_ridge(_dst, _prof, _d0, _d0 + _span * 0.30, _h * 0.38, "tri", -1, SHO_R_FIN);
            sho_fin_ridge(_dst, _prof, _d0 + _span * 0.06, _d0 + _span * 0.46, _h * 0.44, "tri", 1, SHO_R_FIN);
            sho_fin_pectoral(_dst, _prof, _unit * 0.50, _unit * 0.42, "tri", SHO_R_FIN);
            sho_fin_caudal(_dst, _prof, "fork", SHO_R_FIN);
        } break;

        /// Long trailing filaments off dorsal and anal, and a long streaming tail.
        /// ⚠️ NOT `sail`: the mass is BEHIND the body, not above it. Every element here is biased
        /// aft for that reason, including the tail, which is a third longer than any other set's.
        case "trail": {
            var _h = max(0.070, _unit * 0.66);
            sho_fin_ridge(_dst, _prof, _d0 - _span * 0.26, _d1 - _span * 0.16, _h, "trail", -1, SHO_R_FIN);
            sho_fin_ridge(_dst, _prof, _d0 - _span * 0.30, _d1 - _span * 0.30, _h * 0.86, "trail", 1, SHO_R_FIN);
            sho_fin_pectoral(_dst, _prof, _unit * 0.86, _unit * 0.52, "tri", SHO_R_FIN);
            sho_fin_caudal(_dst, _prof, "trail", SHO_R_FIN);
        } break;

        /// A continuous low fin skirting both back and belly, thickening the outline evenly.
        case "fringe": {
            var _h = max(0.038, _unit * 0.30);
            sho_fin_ridge(_dst, _prof, 0.06, 0.94, _h, "fringe", -1, SHO_R_FIN);
            sho_fin_ridge(_dst, _prof, 0.05, 0.88, _h, "fringe", 1, SHO_R_FIN);
            sho_fin_pectoral(_dst, _prof, _unit * 0.44, _unit * 0.34, "round", SHO_R_FIN);
            sho_fin_caudal(_dst, _prof, "round", SHO_R_FIN);
        } break;

        /// Enormously extended pectorals, held out. THE ONLY SET THAT WIDENS THE SILHOUETTE
        /// HORIZONTALLY, which is its entire job - so the pectoral is 2.4x the body's own depth and
        /// there are two of them, offset, to read as a pair seen from the side.
        case "wing": {
            var _h = max(0.044, _unit * 0.38);
            sho_fin_ridge(_dst, _prof, _d0 + _span * 0.24, _d0 + _span * 0.70, _h, "tri", -1, SHO_R_FIN);
            sho_fin_pectoral(_dst, _prof, _unit * 2.40, _unit * 1.05, "tri", SHO_R_FIN);
            sho_fin_pectoral(_dst, _prof, _unit * 1.85, _unit * 1.55, "tri", SHO_R_FIN);
            sho_fin_caudal(_dst, _prof, "fork", SHO_R_FIN);
        } break;

        /// Bare dorsal spines, no membrane. The only serrated contour in the corpus.
        case "spine": {
            var _h = max(0.070, _unit * 0.70);
            sho_fin_spines(_dst, _prof, _d0, _d1, _h, 9, -1, SHO_R_FIN);
            sho_fin_spines(_dst, _prof, _d0 + _span * 0.10, _d0 + _span * 0.56, _h * 0.46, 4, 1, SHO_R_FIN);
            sho_fin_pectoral(_dst, _prof, _unit * 0.46, _unit * 0.40, "tri", SHO_R_FIN);
            sho_fin_caudal(_dst, _prof, "fork", SHO_R_FIN);
        } break;

        /// Rounded paddle fins, no forks anywhere. THE ONLY SET WITH NO STRAIGHT EDGE, and the
        /// only one whose tail is round rather than notched.
        case "lobe": {
            var _h = max(0.062, _unit * 0.56);
            sho_fin_ridge(_dst, _prof, _d0 + _span * 0.10, _d0 + _span * 0.82, _h, "round", -1, SHO_R_FIN);
            sho_fin_ridge(_dst, _prof, _d0 + _span * 0.04, _d0 + _span * 0.62, _h * 0.72, "round", 1, SHO_R_FIN);
            sho_fin_pectoral(_dst, _prof, _unit * 0.72, _unit * 0.50, "round", SHO_R_FIN);
            sho_fin_caudal(_dst, _prof, "round", SHO_R_FIN);
        } break;
    }
    return _dst;
}
