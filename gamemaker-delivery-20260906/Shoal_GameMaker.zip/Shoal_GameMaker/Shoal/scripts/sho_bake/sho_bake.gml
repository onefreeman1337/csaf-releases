/// ============================================================================================
/// SHOAL - sho_bake: the product renders its own store gallery, headlessly.
///
/// NOT A FEATURE. This is verification machinery that happens to produce the listing images, and
/// the two being the same thing is the point.
///
/// -- WHY THE PRODUCT RENDERS ITS OWN STORE PAGE ------------------------------------------------
/// A gallery rendered by a side previewer is a picture of a RE-IMPLEMENTATION. This wing measured
/// exactly that: a JS previewer carried a defect plainly visible in the engine and invisible in the
/// previewer, and a store page built from it would have been selling pixels the shipped GML does
/// not produce. Every sheet below draws through the same public functions a buyer calls, so the
/// listing can say "every image on this page was rendered by the product itself" and have it be
/// true.
///
/// -- ⛔ THE SHEET THAT IS NOT FOR THE STORE ----------------------------------------------------
/// sheet_1 is the 96-silhouette contact sheet, and it exists because Motif_Corpus.md §0 says so:
/// a fish's identity at 20px is base form x fin set ALONE, and 15 of the previous product's 44
/// motifs read as the wrong animal past a fully green 1,401-assertion suite. The pairwise numbers
/// are sho_selftest's job. THIS sheet is the half no number can do - it is rendered so that a human
/// opens it and looks, and that step cannot be delegated.
///
/// -- MEASUREMENT -------------------------------------------------------------------------------
/// Each sheet is measured for INK BOUNDS rather than for a returned y. See sho_bk_ink_bounds: a
/// returned y is blind to horizontal overflow and to emptiness, and this wing has shipped both.
/// ============================================================================================

/// The floors. Measured against this wing's real defects rather than chosen.
#macro SHO_BK_MIN_W_FRAC 0.86
#macro SHO_BK_MIN_H_FRAC 0.80
#macro SHO_BK_EDGE       6

/// The ink bounds of a surface. Returns TWO boxes, each [x0, y0, x1, y1] or undefined:
///
///   .full     every inked pixel, including the title block.   -> the CLIP test
///   .content  only ink BELOW the title rule.                  -> the COVERAGE tests
///
/// ⛔ STRIDE 1 IN Y, AND THE REASON IS MEASURED. The donor of this function used to step y by 2,
/// with a comment claiming it "cannot miss anything wider than a pixel - and nothing this package
/// draws at sheet scale is one pixel wide". BOTH HALVES WERE FALSE: the hairline rule under every
/// title is drawn with draw_line_width(..., 1) and was measured occupying exactly one ODD row, five
/// times the tolerance away from the page colour, invisible to the even-only scan. The whole point
/// of the edge test is to catch something touching the border, and a clipped hairline is precisely
/// the shape that lands on one row.
///
/// X still steps by 2: nothing here draws a one-pixel-wide VERTICAL feature, and being wrong about
/// that costs an x extent off by one rather than a missed rule.
///
/// ⛔ AND TWO BOXES, BECAUSE ONE NUMBER CANNOT DO BOTH JOBS. Once the scan can see the title rule,
/// that full-width line satisfies the x-coverage floor on every sheet single-handed - the exact
/// neutralisation this wing's constitution warns about, arriving through the door that was just
/// opened. Coverage is therefore measured over the CONTENT box, which starts below the rule.
///
/// ⚠️ AND ITS OWN HONEST LIMIT: a flat fill within tolerance of the page is NOT counted as ink at
/// all. Every plate this package draws is well clear of the page in lightness, which is why the
/// UI palette puts "plate" at L 0.215 against a page at L 0.150 - a decision taken here, for this
/// check, and not a coincidence.
function sho_bk_ink_bounds(_surf, _w, _h) {
    var _ground = sho_ui_colour("page");
    var _gr = colour_get_red(_ground), _gg = colour_get_green(_ground), _gb = colour_get_blue(_ground);
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _surf, 0);

    var _top = variable_global_exists("sho_bk_top") ? global.sho_bk_top : 0;

    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;
    for (var _y = 0; _y < _h; _y += 1) {
        var _isContent = (_y >= _top);
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = (_y * _w + _x) * 4;
            var _r = buffer_peek(_buf, _o, buffer_u8);
            var _g = buffer_peek(_buf, _o + 1, buffer_u8);
            var _b = buffer_peek(_buf, _o + 2, buffer_u8);
            // A tolerance of 10 per channel, not 0: the page is drawn once and everything else is
            // composited over it, and a fill's own edge antialiasing lands a value or two off the
            // ground. Zero tolerance would report the page itself as ink.
            if (abs(_r - _gr) > 10 || abs(_g - _gg) > 10 || abs(_b - _gb) > 10) {
                if (_x < _x0) _x0 = _x;
                if (_x > _x1) _x1 = _x;
                if (_y < _y0) _y0 = _y;
                if (_y > _y1) _y1 = _y;
                if (_isContent) {
                    if (_x < _cx0) _cx0 = _x;
                    if (_x > _cx1) _cx1 = _x;
                    if (_y < _cy0) _cy0 = _y;
                    if (_y > _cy1) _cy1 = _y;
                }
            }
        }
    }
    buffer_delete(_buf);
    return {
        full:    (_x1 < 0)  ? undefined : [_x0, _y0, _x1, _y1],
        content: (_cx1 < 0) ? undefined : [_cx0, _cy0, _cx1, _cy1]
    };
}

/// The largest scale at or below `_want` at which `_t` fits inside `_max` pixels, in the CURRENT
/// font. Measured with string_width rather than estimated.
///
/// ⛔ THIS EXISTS BECAUSE FOUR OF FIVE SHEETS SHIPPED THEIR TITLES OFF THE PAGE. Sheet 1's title is
/// "96 SILHOUETTES" and fit; every longer one ran past both edges at scale 3.0, and the ink-bounds
/// check caught it as "ink at x=0..1598 on a 1600 surface" - correctly, but only AFTER rendering.
/// A headline chosen for the store cannot be constrained by how many characters happen to fit, so
/// the type is fitted to the sheet instead. Solve it, do not check it afterwards.
function sho_bk_fit(_t, _want, _max) {
    var _w = string_width(_t);
    if (_w <= 0) return _want;
    return min(_want, _max / _w);
}

/// A sheet's title block. Returns the y to carry on drawing from, and records where CONTENT starts.
function sho_bk_title(_t, _sub, _y, _w) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_font(sho_font_title());
    draw_set_colour(sho_ui_colour("ink"));
    draw_text_transformed(_w * 0.5, _y, _t, sho_bk_fit(_t, 3.0, _w - 200),
                          sho_bk_fit(_t, 3.0, _w - 200), 0);
    draw_set_font(sho_font());
    draw_set_colour(sho_ui_colour("ink2"));
    draw_text_transformed(_w * 0.5, _y + 46, _sub, sho_bk_fit(_sub, 1.5, _w - 200),
                          sho_bk_fit(_sub, 1.5, _w - 200), 0);
    sho_ui_rule(90, _w - 90, _y + 82, sho_ui_colour("rule"));
    // A few pixels below the rule, so the rule itself is excluded from the coverage figure it would
    // otherwise satisfy single-handed.
    global.sho_bk_top = _y + 90;
    return _y + 118;
}

/// A centred caption, never wider than `_maxw`.
///
/// ⛔ THE WIDTH LIMIT IS NOT OPTIONAL ON THIS PRODUCT. Shoal GENERATES its species names, so a cell
/// caption is anything from "Banded Reef Dace" to "Counter-shaded Snowmelt Keelbelly" - a factor of
/// two - and the sheet showed two adjacent captions running into each other, unreadable, with the
/// ink-bounds check perfectly happy because nothing had left the page.
function sho_bk_caption(_t, _x, _y, _scale, _c, _maxw) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_font(sho_font());
    draw_set_colour(is_undefined(_c) ? sho_ui_colour("ink2") : _c);
    var _s = _scale;
    if (!is_undefined(_maxw)) {
        var _w = string_width(_t);
        if (_w > 0) _s = min(_scale, _maxw / _w);
    }
    draw_text_transformed(_x, _y, _t, _s, _s, 0);
}

/// ============================================================================================
/// THE SHEETS
/// ============================================================================================

/// SHEET 1 - THE 96 SILHOUETTES. 12 forms down, 8 fin sets across.
///
/// Flat ink, no pattern, no palette - because pattern and palette cannot change an outline, so the
/// outline has to be judged with both switched off. This is the corpus's acceptance test made
/// visible: any two cells that read as the same shape are a defect, whatever the numbers say.
function sho_bk_sheet_silhouettes(_w, _h) {
    var _forms = sho_form_ids(), _fins = sho_fin_ids();
    var _nf = array_length(_forms), _nn = array_length(_fins);
    var _y = sho_bk_title("96 SILHOUETTES",
        "12 base forms x 8 fin sets. Pattern and palette change no outline.", 74, _w);

    var _left = 176;
    var _cw = (_w - _left - 60) / _nn;
    var _ch = (_h - _y - 40) / _nf;
    var _ink = sho_ui_colour("ink");

    // Column headings
    for (var _c = 0; _c < _nn; _c++) {
        sho_bk_caption(string_upper(sho_fin_name(_fins[_c])), _left + _cw * (_c + 0.5), _y - 16, 1.4,
                       sho_ui_colour("accent"));
    }
    for (var _r = 0; _r < _nf; _r++) {
        var _cy = _y + _ch * (_r + 0.5);
        draw_set_halign(fa_right); draw_set_valign(fa_middle);
        draw_set_font(sho_font());
        draw_set_colour(sho_ui_colour("accent"));
        draw_text_transformed(_left - 22, _cy, string_upper(sho_form_name(_forms[_r])), 1.5, 1.5, 0);
        for (var _c = 0; _c < _nn; _c++) {
            var _sp = sho_species_make(_forms[_r], "plain", _fins[_c], "riverine", undefined);
            // 0.46 rather than 0.5: a cell drawn at exactly half its own pitch has its neighbours
            // touching, and two silhouettes that touch are one silhouette.
            sho_species_silhouette_fit(_sp, _left + _cw * (_c + 0.5), _cy,
                                       _cw * 0.90, _ch * 0.74, _ink, false);
        }
    }
    return true;
}

/// SHEET 2 - the catalogue: real species, in colour, with names.
function sho_bk_sheet_species(_w, _h) {
    var _y = sho_bk_title("EVERY FISH IS DRAWN, NOT DRAWN FROM",
        "12 forms x 10 patterns x 8 fin sets x 10 palettes. No sprite, no atlas, no texture page.",
        74, _w);
    var _cols = 5, _rows = 4;
    var _cw = (_w - 120) / _cols, _ch = (_h - _y - 46) / _rows;
    for (var _r = 0; _r < _rows; _r++) {
        for (var _c = 0; _c < _cols; _c++) {
            var _i = _r * _cols + _c;
            // Walked with coprime strides so twenty cells sample all four axes rather than
            // marching one of them. 7 and 3 are coprime to 12, 10 and 8.
            var _sp = sho_species_at(_i * 7, _i * 3, _i * 5, _i * 7 + 3);
            var _cx = 60 + _cw * (_c + 0.5), _cy = _y + _ch * (_r + 0.5);
            // ⛔ THE TWO CAPTIONS WERE PRINTED ON TOP OF EACH OTHER. They sat 0.05 of the row pitch
            // apart - about 10px - while the type itself is around 20px tall, so every common name
            // in the gallery was overprinted by its own binomial. The plate is now shallower and
            // the two lines are 0.085 apart, which is measured against the type rather than chosen.
            var _py1 = _cy + _ch * 0.20;
            sho_ui_plate(_cx - _cw * 0.46, _cy - _ch * 0.44, _cx + _cw * 0.46, _py1,
                         sho_ui_colour("well"), sho_ui_colour("rule"));
            sho_species_draw_fit(_sp, _cx, (_cy - _ch * 0.44 + _py1) * 0.5,
                                 _cw * 0.84, _ch * 0.56, false);
            sho_bk_caption(_sp.name, _cx, _cy + _ch * 0.315, 1.25, sho_ui_colour("ink"), _cw * 0.94);
            sho_bk_caption(_sp.latin, _cx, _cy + _ch * 0.400, 1.05, sho_ui_colour("ink2"), _cw * 0.94);
        }
    }
    return true;
}

/// SHEET 3 - specimen cards, one per rarity tier, so the generated ornament is visible as a ladder.
function sho_bk_sheet_cards(_w, _h) {
    var _y = sho_bk_title("EVERY CATCH BECOMES A SPECIMEN CARD",
        "Frame, corner furniture and accent are generated from the catch's own rarity.", 74, _w);
    var _n = 5;
    var _cw = (_w - 130) / _n;
    var _cardw = _cw * 0.88, _cardh = min(_h - _y - 60, _cardw * 1.42);
    for (var _i = 0; _i < _n; _i++) {
        var _sp = sho_species_at(_i * 5 + 1, _i * 3 + 2, _i * 3, _i * 7 + 1);
        var _c = sho_catch_make(_sp, round(_sp.typical * (0.9 + _i * 0.22)),
                                sho_biome_ids()[_i mod 5], _i mod 4, 6 + _i * 4, _i);
        _c.record = (_i == 4);
        sho_card_draw(_c, 65 + _cw * _i + (_cw - _cardw) * 0.5, _y + 22, _cardw, _cardh);
    }
    return true;
}

/// SHEET 4 - the patterns, all ten, on one form, so the axis is legible as an axis.
function sho_bk_sheet_patterns(_w, _h) {
    var _y = sho_bk_title("TEN PATTERNS, CLIPPED IN GEOMETRY",
        "No surface, no blend mode, no mask. Every mark is built to the body's own edges.", 74, _w);
    var _ids = sho_pattern_ids();
    var _cols = 5, _rows = 2;
    var _cw = (_w - 120) / _cols, _ch = (_h - _y - 46) / _rows;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _r = _i div _cols, _c = _i mod _cols;
        var _cx = 60 + _cw * (_c + 0.5), _cy = _y + _ch * (_r + 0.5);
        var _sp = sho_species_make("spindle", _ids[_i], "plain", "reef", undefined);
        sho_ui_plate(_cx - _cw * 0.46, _cy - _ch * 0.40, _cx + _cw * 0.46, _cy + _ch * 0.26,
                     sho_ui_colour("well"), sho_ui_colour("rule"));
        sho_species_draw_fit(_sp, _cx, _cy - _ch * 0.07, _cw * 0.84, _ch * 0.52, false);
        sho_bk_caption(string_upper(sho_pattern_name(_ids[_i])), _cx, _cy + _ch * 0.345, 1.4,
                       sho_ui_colour("accent"), _cw * 0.9);
    }
    return true;
}

/// SHEET 5 - the palettes, all ten, on one species, so the colour system is legible as a system.
function sho_bk_sheet_liveries(_w, _h) {
    var _y = sho_bk_title("TEN PALETTES, COMPUTED IN OKLCH",
        "Body, belly, fin, mark and eye are DERIVED from three numbers - not five picked colours.",
        74, _w);
    var _ids = sho_livery_ids();
    var _cols = 5, _rows = 2;
    var _cw = (_w - 120) / _cols, _ch = (_h - _y - 46) / _rows;
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _r = _i div _cols, _c = _i mod _cols;
        var _cx = 60 + _cw * (_c + 0.5), _cy = _y + _ch * (_r + 0.5);
        var _sp = sho_species_make("disc", "bands", "lobe", _ids[_i], undefined);
        sho_ui_plate(_cx - _cw * 0.46, _cy - _ch * 0.40, _cx + _cw * 0.46, _cy + _ch * 0.26,
                     sho_ui_colour("well"), sho_ui_colour("rule"));
        sho_species_draw_fit(_sp, _cx, _cy - _ch * 0.07, _cw * 0.84, _ch * 0.52, false);
        // The five derived inks as swatches under each fish: the system, shown rather than claimed.
        var _ink = sho_livery_ink(_ids[_i], 0);
        var _cols5 = [_ink.body, _ink.belly, _ink.fin, _ink.mark, _ink.eye];
        var _sw = _cw * 0.115;
        for (var _k = 0; _k < 5; _k++) {
            draw_set_colour(_cols5[_k]);
            var _sx = _cx - _sw * 2.5 + _sw * _k;
            draw_rectangle(_sx, _cy + _ch * 0.30, _sx + _sw - 3, _cy + _ch * 0.30 + _sw * 0.62, false);
        }
        sho_bk_caption(string_upper(sho_livery_name(_ids[_i])), _cx, _cy + _ch * 0.405, 1.4,
                       sho_ui_colour("accent"), _cw * 0.9);
    }
    return true;
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

/// ⛔ AN UNHANDLED GML ERROR OPENS A MODAL DIALOG, and headless there is nobody to dismiss it, so
/// the process never exits and the runner reports a meaningless timeout. This handler turns that
/// into a named stage and a clean exit. It is the single most valuable line in the file.
function sho_bake_main() {
    var _stage = -1;
    exception_unhandled_handler(function(_ex) {
        var _f = file_text_open_write("sho_bake.json");
        file_text_write_string(_f, "{\"crash\":true,\"stage\":" + string(global.sho_bk_stage)
            + ",\"message\":\"" + string_replace_all(string(_ex.message), "\"", "'") + "\"}");
        file_text_close(_f);
        game_end(1);
    });
    global.sho_bk_stage = -1;

    // name, function, width, height. Sheet 1 is taller than the rest: 12 rows of silhouettes on a
    // 1000px page would be 60px a row, which is not a contact sheet, it is a thumbnail strip.
    var _sheets = [
        // ⚠️ 1900 TALL, NOT 1500. Twelve rows on a 1500px page gave each cell 104px of height, and
        // because a specimen is scaled by min(cellW, cellH) that height was the binding constraint
        // on every fish - so the sheet was 40% dead space AND the shapes were too small to judge.
        // The whole point of this sheet is that a human can look at it and tell.
        ["sheet_1_silhouettes", sho_bk_sheet_silhouettes, 1600, 1900],
        ["sheet_2_species",     sho_bk_sheet_species,     1600, 1000],
        // ⚠️ 640 TALL, AND THE SHEET IS SIZED TO THE CARDS RATHER THAN THE CARDS TO THE SHEET.
        // Five cards across a 1600px page are 259px wide, and a specimen card is 1:1.42 portrait,
        // so they CANNOT be taller than ~368px whatever the page height is. On a 1000px page that
        // left 40% of the sheet as bare ground - which the coverage floor correctly reported as
        // SPARSE, and which would have argued to a buyer that there is not much in the product.
        ["sheet_3_cards",       sho_bk_sheet_cards,       1600,  640],
        ["sheet_4_patterns",    sho_bk_sheet_patterns,    1600, 1000],
        ["sheet_5_liveries",    sho_bk_sheet_liveries,    1600, 1000]
    ];

    var _out = "{\"crash\":false,\"sheets\":[";
    for (var _i = 0; _i < array_length(_sheets); _i++) {
        global.sho_bk_stage = _i;
        var _name = _sheets[_i][0], _fn = _sheets[_i][1];
        var _w = _sheets[_i][2], _h = _sheets[_i][3];
        global.sho_bk_top = 0;

        var _surf = surface_create(_w, _h);
        surface_set_target(_surf);
        draw_clear(sho_ui_colour("page"));
        _fn(_w, _h);
        surface_reset_target();

        var _boxes = sho_bk_ink_bounds(_surf, _w, _h);
        surface_save(_surf, _name + ".png");
        surface_free(_surf);

        var _ok = true, _why = "";
        var _f = _boxes.full, _c = _boxes.content;
        if (is_undefined(_f)) { _ok = false; _why = "sheet is EMPTY - no ink at all"; }
        else if (_f[0] < SHO_BK_EDGE || _f[1] < SHO_BK_EDGE
              || _f[2] > _w - 1 - SHO_BK_EDGE || _f[3] > _h - 1 - SHO_BK_EDGE) {
            _ok = false;
            _why = "CLIPPED: ink at x=" + string(_f[0]) + ".." + string(_f[2])
                 + " y=" + string(_f[1]) + ".." + string(_f[3])
                 + " on a " + string(_w) + "x" + string(_h) + " surface";
        } else if (is_undefined(_c)) { _ok = false; _why = "no content below the title rule"; }
        else if ((_c[3] - _c[1]) < (_h - global.sho_bk_top) * SHO_BK_MIN_H_FRAC) {
            _ok = false;
            _why = "SPARSE: content fills only " + string(_c[3] - _c[1]) + "px of "
                 + string(_h - global.sho_bk_top) + " available";
        }

        _out += (_i > 0 ? "," : "") + "{\"sheet\":\"" + _name + "\",\"ok\":" + (_ok ? "true" : "false")
             + ",\"reason\":\"" + _why + "\",\"w\":" + string(_w) + ",\"h\":" + string(_h)
             + ",\"full\":" + sho_bk_box_json(_f) + ",\"content\":" + sho_bk_box_json(_c) + "}";
    }
    _out += "]}";

    var _fh = file_text_open_write("sho_bake.json");
    file_text_write_string(_fh, _out);
    file_text_close(_fh);
    game_end(0);
}

function sho_bk_box_json(_b) {
    if (is_undefined(_b)) return "null";
    return "[" + string(_b[0]) + "," + string(_b[1]) + "," + string(_b[2]) + "," + string(_b[3]) + "]";
}
