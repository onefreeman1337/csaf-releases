{
  "$GMScript": "v1",
  "%Name": "sho_bake",
  "isCompatibility": false,
  "isDnD": false,
  "name": "sho_bake",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}