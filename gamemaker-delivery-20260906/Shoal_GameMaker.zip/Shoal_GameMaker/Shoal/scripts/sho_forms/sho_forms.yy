{
  "$GMScript": "v1",
  "%Name": "sho_forms",
  "isCompatibility": false,
  "isDnD": false,
  "name": "sho_forms",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}