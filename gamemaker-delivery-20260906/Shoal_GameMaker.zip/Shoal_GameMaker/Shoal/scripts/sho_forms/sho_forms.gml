/// ============================================================================================
/// SHOAL - sho_forms: THE CORPUS, half one. 12 base body forms.
///
/// This file and sho_fins are the product. Everything else composes, colours or draws what is
/// authored here. 12 forms x 8 fin sets is 96 SILHOUETTES; patterns and palettes multiply the
/// catalogue on top of that but change no outline at all.
///
/// -- READ Internal_Ops/Motif_Corpus.md FIRST ---------------------------------------------------
/// Every form below has a 20px silhouette note in §2 of that document, and the note is the
/// acceptance criterion, not decoration. The document was written before this file existed. Amend
/// it in the same edit when a form changes.
///
/// -- WHY A FISH IS AN ENVELOPE PAIR AND NOT A PILE OF MASSES -----------------------------------
/// The wing's previous product built each motif from loose filled masses. That is right for a lion
/// and wrong for a fish, for two reasons that both bite later:
///
///   1. A FISH IS ONE CLOSED SILHOUETTE. Loose masses give a lumpy contour with internal seams
///      that show the moment two masses take slightly different colours.
///   2. THE PATTERN HAS TO BE CLIPPED TO THE BODY IN GEOMETRY (Motif_Corpus.md §4), never painted
///      and masked. That needs an exact answer to "where does the body start and stop at this x",
///      for any x, cheaply, every frame. A pile of ellipses cannot answer it.
///
/// So a form is TWO PROFILES over one axial parameter u, tail (u=0) to snout (u=1): a top edge and
/// a bottom edge. The body fills as a triangle STRIP between them, which is exact for any profile
/// and - unlike a triangle fan - carries no star-shaped requirement, so `eel` can wave and `ray`
/// can be a diamond without special-casing the fill.
///
/// sho_form_span() then answers the clipping question in two array lookups and a lerp.
///
/// -- WHY THE TOP AND BOTTOM ENVELOPES ARE INDEPENDENT ------------------------------------------
/// Because half the corpus IS the asymmetry. `hatchet` is a flat back over a deep keeled belly;
/// `flathead` is a flat top with the mass forward; `spindle` has a belly curve that `torpedo`
/// specifically does not. A single half-height with a mirror flag cannot express any of them, and
/// six of the twelve would collapse toward each other - which is the exact collision risk
/// Motif_Corpus.md §2 warns about.
///
/// COORDINATES. Unit box [-0.5, 0.5] on both axes, y DOWN, origin at the fish's optical centre.
/// Every fish is TAIL-LEFT / HEAD-RIGHT. Nothing here flips an axis, so a form reads the same in
/// Motif_Corpus.md and on screen.
/// ============================================================================================

/// -- THE COORDINATE CONTRACT -------------------------------------------------------------------
///
/// SHO_BODY_BOX is a DISC, not a square: the extent test is hypot(x, y) <= BOX. A specimen is drawn
/// into round frames as well as square ones, and a square budget lets a corner escape a round one.
///
/// ⛔ AND THE BUDGET IS SHARED WITH THE FIN SET, WHICH IS THE TERM AN INHERITED CONTRACT WOULD
/// MISS. A body that fits perfectly and a fin set that fits perfectly can overflow together: the
/// fin attaches to the body's own edge, so its reach is body depth PLUS fin extent. The split is
/// declared per form as `finbudget` below, sho_fins is required to respect it, and sho_selftest
/// measures the COMBINED ops of all 96 pairings against SHO_BODY_BOX rather than either alone.
#macro SHO_BODY_BOX   0.50
#macro SHO_FORM_N     56

/// -- ROLES -------------------------------------------------------------------------------------
/// A part carries a role, never a colour. sho_livery resolves a role against the species being
/// drawn, which is what lets one form appear in ten palettes without the geometry knowing about any
/// of them.
#macro SHO_R_BODY     0
#macro SHO_R_BELLY    1
#macro SHO_R_FIN      2
#macro SHO_R_MARK     3
#macro SHO_R_EYE      4
#macro SHO_R_EDGE     5

/// ============================================================================================
/// THE CORPUS TABLE
/// ============================================================================================

/// The 12 base form ids, in the order Motif_Corpus.md §2 declares them.
function sho_form_ids() {
    return [
        "spindle", "torpedo", "disc", "sunfish", "eel", "ribbon",
        "flathead", "hatchet", "angler", "ray", "fan", "pike"
    ];
}

function sho_form_name(_id) {
    switch (_id) {
        case "spindle":  return "Spindle";
        case "torpedo":  return "Torpedo";
        case "disc":     return "Disc";
        case "sunfish":  return "Sunfish";
        case "eel":      return "Eel";
        case "ribbon":   return "Ribbon";
        case "flathead": return "Flathead";
        case "hatchet":  return "Hatchet";
        case "angler":   return "Angler";
        case "ray":      return "Ray";
        case "fan":      return "Fan";
        case "pike":     return "Pike";
    }
    return "?";
}

/// ============================================================================================
/// THE ENVELOPE
///
/// One curve shape, six numbers, used twice per form. Peaking at `p`, falling to `r0` of full
/// depth at the tail and `r1` at the snout, with independent exponents either side.
///
/// ⚠️ THE EXPONENTS ARE THE WHOLE VOCABULARY AND THEY ARE NOT INTERCHANGEABLE WITH THE RATIOS.
/// A high r0 makes the tail end DEEP (a truncated rear, `sunfish`); a high e0 makes the taper
/// toward the tail LATE, so the body stays full and then drops away (a peduncle, `spindle`).
/// Confusing the two is how `torpedo` and `spindle` end up the same bar.
/// ============================================================================================

function sho_env(_u, _e) {
    var _s;
    if (_u <= _e.p) {
        var _t = (_e.p <= 0) ? 1 : (_u / _e.p);
        _s = _e.r0 + (1 - _e.r0) * power(_t, _e.e0);
    } else {
        var _t = (_e.p >= 1) ? 1 : ((1 - _u) / (1 - _e.p));
        _s = _e.r1 + (1 - _e.r1) * power(_t, _e.e1);
    }
    return _e.H * _s;
}

/// A shorthand so a form's declaration reads as a table rather than as six struct literals.
function sho_e(_H, _p, _r0, _r1, _e0, _e1) {
    return { H: _H, p: _p, r0: _r0, r1: _r1, e0: _e0, e1: _e1 };
}

/// ============================================================================================
/// THE 12 SPECS
///
/// Each returns a pure data struct - no engine calls, nothing sampled - so the whole corpus can be
/// read, diffed and checked before any of it is drawn.
///
///   x0, x1      axial extent: peduncle (tail junction) to snout.
///   top, bot    the two envelopes, as HALF-DEPTHS above and below the spine.
///   waveamp     spine displacement amplitude (serpentine forms only).
///   wavecyc     spine displacement cycles across the body.
///   girth       cross-section WIDTH as a fraction of its DEPTH. Not drawn - this is a side view -
///               but it is what makes mass physical, and it is a real property of a body plan.
///               ⛔ IT EXISTS BECAUSE THE SUITE CAUGHT A REAL DEFECT: mass was derived from
///               side-view depth alone, so a hatchetfish came out heavier than a tuna of the same
///               length. A hatchet is deep AND paper-thin; depth in side view says nothing about
///               width. 1.00 is round in cross-section; below that is laterally compressed;
///               ABOVE it is dorsally flattened, which is why `flathead` is 1.40 and `ray` is 2.20.
///   finunit     the depth a FIN SET sizes itself against. 0 means "use the body depth", which is
///               true for eleven of the twelve. ⛔ `fan` overrides it because its body is small BY
///               DESIGN and its identification is its span: sized against the body, its fin sets
///               came out smaller than the span AND were clamped to the same budget, so they could
///               not project past it at any value. That measured as EXACTLY ZERO distance across
///               four pairings and survived two fixes that did not touch the cause.
///   dorsal0/1   the u range along the back where a dorsal fin may sit.
///   pect        [u, side] anchor for a pectoral fin: side is a fraction of local depth.
///   tail        caudal fin scale, as a multiple of the peduncle half-depth.
///   finbudget   THE SHARED-BUDGET TERM. Maximum |y| any fin on this form may reach.
///   eye         [u, side] eye anchor.
///   extra       an id for form-intrinsic geometry drawn by sho_form_extra(). "" for none.
///
/// ⛔ `extra` IS NOT DECORATION AND IS NOT OPTIONAL. Four forms carry part of their identification
/// outside the body envelope - a ray IS its pectoral sweep, a fan IS its fin span, an angler IS its
/// lure, a pike IS its jaw - and those four must read correctly with ALL EIGHT fin sets, including
/// `plain`. Putting that geometry in the fin set instead would make the form legible in one pairing
/// out of eight, which is exactly the failure Motif_Corpus.md §0 describes.
/// ============================================================================================

function sho_form_spec(_id) {
    switch (_id) {

        /// The baseline everything else is judged against: streamlined, deepest at one third from
        /// the snout, with a BELLY. The belly envelope is 30% deeper than the back and peaks
        /// slightly further aft, which is the whole of what separates this from `torpedo`.
        case "spindle": return {
            x0: -0.250, x1: 0.440,
            top: sho_e(0.116, 0.640, 0.255, 0.045, 1.55, 0.78),
            bot: sho_e(0.150, 0.580, 0.265, 0.055, 1.45, 0.72),
            waveamp: 0.000, wavecyc: 0.0, girth: 0.85, finunit: 0.00,
            dorsal0: 0.42, dorsal1: 0.80, pect: [0.66, 0.62], tail: 2.05,
            finbudget: 0.360, eye: [0.855, -0.30], extra: ""
        };

        /// Near-cylindrical: a straight bar with rounded ends and a BLUNT nose. r1 is 0.62 rather
        /// than spindle's 0.045 - the nose does not come to a point - and both exponents are above
        /// 2 so the depth holds flat across the middle instead of curving.
        /// ⚠️ NOT `spindle`: no belly. top and bot are the same numbers on purpose.
        case "torpedo": return {
            x0: -0.265, x1: 0.450,
            top: sho_e(0.113, 0.500, 0.640, 0.620, 2.40, 2.30),
            bot: sho_e(0.113, 0.500, 0.640, 0.620, 2.40, 2.30),
            waveamp: 0.000, wavecyc: 0.0, girth: 1.00, finunit: 0.00,
            dorsal0: 0.40, dorsal1: 0.78, pect: [0.64, 0.66], tail: 1.55,
            finbudget: 0.355, eye: [0.860, -0.30], extra: ""
        };

        /// A coin on edge: laterally compressed, and as close to CIRCULAR as the corpus gets.
        ///
        /// ⛔ REVISED AFTER LOOKING AT THE CONTACT SHEET. The first numbers made this 0.43 long by
        /// 0.54 deep - taller than long - which put it in the same read as `sunfish` and, at 20px,
        /// as `fan`. Three rounded blobs is not a corpus. It is now 0.475 long by 0.49 deep, i.e.
        /// genuinely round, and `sunfish` has been pushed the other way so the two separate by
        /// PROPORTION rather than by a detail neither of them shows at thumbnail size.
        case "disc": return {
            x0: -0.175, x1: 0.300,
            top: sho_e(0.245, 0.470, 0.115, 0.075, 0.46, 0.52),
            bot: sho_e(0.245, 0.500, 0.115, 0.075, 0.46, 0.52),
            waveamp: 0.000, wavecyc: 0.0, girth: 0.30, finunit: 0.00,
            dorsal0: 0.30, dorsal1: 0.74, pect: [0.62, 0.42], tail: 0.85,
            finbudget: 0.430, eye: [0.800, -0.38], extra: ""
        };

        /// A circle with the back sliced off flat, and TALLER THAN IT IS LONG - 0.415 long by 0.60
        /// deep, the most extreme height-to-length ratio in the corpus. r0 = 0.97 on both envelopes
        /// gives a near-vertical rear wall and `tail` is 0.26, so the caudal is a nub rather than a
        /// fin. Proportion first, truncation second: at 20px only the first is visible.
        /// ⚠️ NOT `disc`, which is now round; NOT `fan`, whose mass is FIN rather than body.
        case "sunfish": return {
            x0: -0.095, x1: 0.320,
            top: sho_e(0.300, 0.640, 0.970, 0.070, 1.45, 0.50),
            bot: sho_e(0.300, 0.620, 0.970, 0.075, 1.45, 0.50),
            waveamp: 0.000, wavecyc: 0.0, girth: 0.35, finunit: 0.00,
            dorsal0: 0.22, dorsal1: 0.62, pect: [0.66, 0.40], tail: 0.26,
            finbudget: 0.440, eye: [0.815, -0.40], extra: ""
        };

        /// A wavy line with mass. Length 0.82 against a depth of 0.10 - eight to one - and a spine
        /// wave of 1.35 cycles.
        /// ⛔ MUST NOT CLOSE INTO A LOOP. The wave is 1.35 cycles at amplitude 0.115: enough that
        /// the silhouette reads as serpentine at 20px, not enough that the body crosses itself.
        /// Two full cycles read as a knot and lost the form entirely.
        case "eel": return {
            x0: -0.380, x1: 0.450,
            top: sho_e(0.048, 0.500, 0.720, 0.560, 2.80, 2.60),
            bot: sho_e(0.052, 0.500, 0.720, 0.560, 2.80, 2.60),
            waveamp: 0.115, wavecyc: 1.35, girth: 0.95, finunit: 0.00,
            dorsal0: 0.25, dorsal1: 0.86, pect: [0.80, 0.90], tail: 1.15,
            finbudget: 0.290, eye: [0.905, -0.40], extra: ""
        };

        /// A wide banner: an eel's length carried at a disc's depth, held straight.
        /// ⚠️ NOT `eel` - three times the depth and no spine wave. NOT `disc` - twice the length.
        /// The pairing is deliberate: these three are the corpus's length/depth extremes and stating
        /// them as ratios rather than adjectives is what keeps them apart at 20px.
        case "ribbon": return {
            x0: -0.355, x1: 0.440,
            top: sho_e(0.163, 0.500, 0.560, 0.300, 1.10, 1.30),
            bot: sho_e(0.168, 0.500, 0.560, 0.300, 1.10, 1.30),
            waveamp: 0.020, wavecyc: 0.5, girth: 0.15, finunit: 0.00,
            dorsal0: 0.22, dorsal1: 0.86, pect: [0.78, 0.70], tail: 0.85,
            finbudget: 0.400, eye: [0.885, -0.38], extra: ""
        };

        /// A wedge, widest AT THE HEAD. p = 0.90 on the belly envelope puts the deepest point
        /// forward of the eye, which is the stated separator from a reversed `spindle`. The back is
        /// nearly flat (H 0.062, exponents high) because the form is dorsally flattened.
        case "flathead": return {
            x0: -0.255, x1: 0.445,
            top: sho_e(0.062, 0.780, 0.300, 0.520, 1.80, 1.60),
            bot: sho_e(0.158, 0.900, 0.185, 0.640, 1.35, 1.90),
            waveamp: 0.000, wavecyc: 0.0, girth: 1.40, finunit: 0.00,
            dorsal0: 0.32, dorsal1: 0.70, pect: [0.80, 0.86], tail: 1.70,
            finbudget: 0.350, eye: [0.885, -0.72], extra: ""
        };

        /// A cleaver: the BACK is straight and the belly is a deep curved keel.
        /// ⚠️ NOT `disc`, which curves both ways. The asymmetry here is 4.6:1 - the deepest belly in
        /// the corpus against one of the shallowest backs - and it is the only thing carrying the
        /// distinction, so neither number may be softened toward the other.
        case "hatchet": return {
            x0: -0.180, x1: 0.360,
            top: sho_e(0.058, 0.560, 0.620, 0.420, 2.10, 1.70),
            bot: sho_e(0.268, 0.520, 0.180, 0.140, 1.05, 0.88),
            waveamp: 0.000, wavecyc: 0.0, girth: 0.22, finunit: 0.00,
            dorsal0: 0.30, dorsal1: 0.72, pect: [0.66, 0.50], tail: 0.95,
            finbudget: 0.415, eye: [0.845, -0.55], extra: ""
        };

        /// A head with an afterthought. The mass is FORWARD - p = 0.88 on both envelopes, against
        /// `sunfish`'s central mass - and the rear third is a shrunken stalk (r0 = 0.13).
        /// The illicium is `extra`: an angler without its lure is just a bad sunfish.
        case "angler": return {
            x0: -0.185, x1: 0.395,
            top: sho_e(0.205, 0.860, 0.130, 0.180, 1.90, 1.05),
            bot: sho_e(0.212, 0.880, 0.130, 0.190, 1.90, 1.00),
            waveamp: 0.000, wavecyc: 0.0, girth: 0.90, finunit: 0.00,
            dorsal0: 0.20, dorsal1: 0.52, pect: [0.72, 0.72], tail: 0.95,
            finbudget: 0.385, eye: [0.830, -0.56], extra: "illicium"
        };

        /// A kite with a string.
        ///
        /// ⛔ REVISED AFTER LOOKING. The first numbers were 0.58 long by 0.60 deep with the widest
        /// point at 40% - a SYMMETRICAL RHOMBUS, which read as a four-pointed compass star and was
        /// indistinguishable from `fan` at thumbnail size. A kite is not a rhombus: it is WIDER
        /// THAN TALL, its widest point sits FORWARD of centre, and it has a string. So the span is
        /// now 0.72 long by 0.53 deep, p is 0.62, and the rear comes to an actual point (r0 = 0.012)
        /// where the whip attaches. The whip in `extra` was also doubled in length and weight,
        /// because at the first size it was invisible and the form was a rhombus after all.
        case "ray": return {
            x0: -0.310, x1: 0.410,
            top: sho_e(0.265, 0.620, 0.012, 0.020, 1.00, 1.05),
            bot: sho_e(0.265, 0.620, 0.012, 0.020, 1.00, 1.05),
            waveamp: 0.000, wavecyc: 0.0, girth: 2.20, finunit: 0.00,
            dorsal0: 0.34, dorsal1: 0.58, pect: [0.52, 0.95], tail: 0.00,
            finbudget: 0.420, eye: [0.800, -0.26], extra: "whip"
        };

        /// A square of fin with a body inside it.
        ///
        /// ⛔ REVISED AFTER LOOKING, AND THIS ONE WAS THE WORST DEFECT IN THE CORPUS. The first
        /// version's span was a raised cosine running the WHOLE body, which produced a smooth lens
        /// - a diamond, identical to `ray`'s - and, far worse, it SWALLOWED THE FIN SET ENTIRELY:
        /// the silhouette rasteriser measured fan/plain against fan/sail at distance ZERO. Eight of
        /// the 96 silhouettes were one silhouette, and no amount of pattern or palette would have
        /// hidden it.
        ///
        /// Two changes fix both halves. The span is now FLAT-TOPPED and near-square (a plateau with
        /// short shoulders, `power(_r, 0.30)`), which is what "a square of fin" actually means and
        /// is nothing like a diamond. And it is inset from both ends of the body - it starts aft of
        /// the head and stops short of the peduncle - so the dorsal fin and the caudal fin of every
        /// fin set still project past it and remain legible.
        case "fan": return {
            x0: -0.195, x1: 0.265,
            top: sho_e(0.112, 0.520, 0.320, 0.120, 0.90, 0.80),
            bot: sho_e(0.118, 0.520, 0.320, 0.120, 0.90, 0.80),
            waveamp: 0.000, wavecyc: 0.0, girth: 0.25, finunit: 0.30,
            // ⛔ THE DORSAL RANGE IS THE WHOLE BODY, AND THE BUDGET IS ABOVE THE SPAN'S REACH.
            // Both are consequences of the same defect. The span occupies u 0.30-0.74 and reaches
            // ~0.37; a fin set confined to u 0.30-0.72 and clamped to 0.430 was inside the span in
            // BOTH axes, so all eight sets drew the same silhouette. Widening the range to the full
            // body lets each set project past the span fore and aft, and lifting the budget to
            // 0.470 lets the tall ones project above it.
            dorsal0: 0.10, dorsal1: 0.92, pect: [0.62, 0.55], tail: 0.95,
            finbudget: 0.470, eye: [0.800, -0.42], extra: "fanspan"
        };

        /// An arrow. Long, straight, and the jaw is carried a THIRD of the length forward - p is
        /// 0.38, well aft, so the body is already tapering by mid-length and the head is a long
        /// point rather than a blunt end.
        /// ⚠️ NOT `torpedo`, which is blunt-nosed with its depth held flat to the front.
        case "pike": return {
            x0: -0.255, x1: 0.340,
            top: sho_e(0.094, 0.380, 0.430, 0.660, 1.30, 2.60),
            bot: sho_e(0.100, 0.360, 0.430, 0.680, 1.30, 2.60),
            waveamp: 0.000, wavecyc: 0.0, girth: 0.80, finunit: 0.00,
            dorsal0: 0.30, dorsal1: 0.62, pect: [0.58, 0.70], tail: 1.85,
            finbudget: 0.345, eye: [0.880, -0.44], extra: "jaw"
        };
    }
    return undefined;
}

/// ============================================================================================
/// SAMPLING
/// ============================================================================================

/// Build the sampled profile for a form. This is the struct every other file in the package talks
/// to; nothing downstream ever reads a spec directly.
///
///   n           number of samples
///   x[]         axial positions, STRICTLY ASCENDING (relied on by sho_form_span)
///   yt[], yb[]  top and bottom edge, absolute (spine displacement already applied)
///   sp[]        the spine itself, for pattern centring and the lateral line
function sho_form_profile(_id) {
    var _s = sho_form_spec(_id);
    if (is_undefined(_s)) return undefined;

    var _n = SHO_FORM_N;
    var _x  = array_create(_n + 1);
    var _yt = array_create(_n + 1);
    var _yb = array_create(_n + 1);
    var _sp = array_create(_n + 1);

    for (var _i = 0; _i <= _n; _i++) {
        var _u = _i / _n;
        var _y = (_s.waveamp == 0) ? 0
               : sin((_u * _s.wavecyc + 0.18) * 2 * pi) * _s.waveamp;
        _x[_i]  = lerp(_s.x0, _s.x1, _u);
        _sp[_i] = _y;
        _yt[_i] = _y - sho_env(_u, _s.top);
        _yb[_i] = _y + sho_env(_u, _s.bot);
    }

    return {
        id: _id, spec: _s, n: _n,
        x: _x, yt: _yt, yb: _yb, sp: _sp
    };
}

/// The body's top and bottom edge at an arbitrary x, or `undefined` outside the body.
///
/// ⛔ THIS IS THE FUNCTION THE WHOLE PATTERN SYSTEM STANDS ON. Motif_Corpus.md §4 requires every
/// pattern to be clipped to the body IN GEOMETRY rather than painted and masked, and this is what
/// makes that affordable: two lookups and a lerp, per pattern element, per frame.
///
/// ⚠️ It returns the edges, NOT a half-depth about zero. On `hatchet` those differ by a factor of
/// four and a caller that assumes symmetry puts every horizontal stripe outside the fish.
function sho_form_span(_prof, _x) {
    var _n = _prof.n;
    if (_x <= _prof.x[0]) {
        if (_x < _prof.x[0]) return undefined;
        return [_prof.yt[0], _prof.yb[0], _prof.sp[0]];
    }
    if (_x >= _prof.x[_n]) {
        if (_x > _prof.x[_n]) return undefined;
        return [_prof.yt[_n], _prof.yb[_n], _prof.sp[_n]];
    }
    // x is a linear ramp from x0 to x1, so the index is exact arithmetic rather than a search.
    var _t = (_x - _prof.x[0]) / (_prof.x[_n] - _prof.x[0]) * _n;
    var _i = clamp(floor(_t), 0, _n - 1);
    var _f = _t - _i;
    return [
        lerp(_prof.yt[_i], _prof.yt[_i + 1], _f),
        lerp(_prof.yb[_i], _prof.yb[_i + 1], _f),
        lerp(_prof.sp[_i], _prof.sp[_i + 1], _f)
    ];
}

/// The closed outline ring: along the top from tail to snout, back along the bottom.
/// Used for the contour stroke and by sho_selftest's silhouette rasteriser.
function sho_form_outline(_prof) {
    var _n = _prof.n;
    var _out = array_create((_n + 1) * 2);
    for (var _i = 0; _i <= _n; _i++) _out[_i] = [_prof.x[_i], _prof.yt[_i]];
    for (var _i = 0; _i <= _n; _i++) _out[_n + 1 + _i] = [_prof.x[_n - _i], _prof.yb[_n - _i]];
    return _out;
}

/// The body as a filled triangle strip between the two edges.
///
/// A STRIP, NOT A FAN. A fan from the centroid is wrong for `eel` (serpentine, so the centroid sits
/// outside the body at two points) and for `hatchet` (the centroid sits below the flat back). Both
/// would fill as a bow tie, and both would do it silently - the fill is still a legal triangle list.
function sho_form_body(_prof, _role) {
    var _n = _prof.n;
    var _a = array_create(_n + 1), _b = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        _a[_i] = [_prof.x[_i], _prof.yt[_i]];
        _b[_i] = [_prof.x[_i], _prof.yb[_i]];
    }
    return sho_strip(_a, _b, _role);
}

/// ============================================================================================
/// FORM-INTRINSIC GEOMETRY
///
/// See the note above sho_form_spec: these four are part of the IDENTIFICATION, not decoration,
/// and they are drawn for every fin set.
/// ============================================================================================

function sho_form_extra(_prof, _dst) {
    var _s = _prof.spec;
    switch (_s.extra) {

        /// The angler's lure: a stalk rising from just behind the snout, arching FORWARD over the
        /// mouth, with a bulb on the end. Forward is the whole point - a stalk that leans back
        /// reads as a dorsal spine and the form loses its name.
        case "illicium": {
            var _sp = sho_form_span(_prof, _s.x1 * 0.42);
            var _y0 = _sp[0];
            // ⛔ PULLED IN AFTER THE SUITE MEASURED IT AT r = 0.54 ON ALL EIGHT PAIRINGS. The bulb
            // sat at (0.403, -0.294): inside a 0.5 SQUARE on both axes and outside the 0.5 DISC the
            // contract is written against. This is the third time the same mistake appeared in this
            // package - once on the pectoral, once on the caudal, once here - and every time it
            // came from reasoning about x and y separately about a radial budget.
            var _tipx = _s.x1 * 0.82, _tipy = _y0 - 0.175;
            var _pts = sho_qbez([_s.x1 * 0.42, _y0], [_s.x1 * 0.50, _y0 - 0.225],
                                [_tipx, _tipy], 14);
            array_push(_dst, sho_taper_ribbon(_pts, 0.0165, 0.0095, SHO_R_FIN));
            array_push(_dst, sho_dot(_tipx, _tipy, 0.0375, SHO_R_MARK));
        } break;

        /// The ray's whip: a long tapering tail running left, well past the body's own peduncle.
        /// It is the "string" half of "a kite with a string" and without it the form is a rhombus.
        ///
        /// ⛔ DOUBLED IN LENGTH AND WEIGHT AFTER LOOKING AT THE CONTACT SHEET. At its first size
        /// (reach 0.27, half-width 0.021) it was simply not visible at cell scale, so `ray` read as
        /// a symmetrical four-pointed star and collided with `fan`. A feature that carries half of
        /// a form's identity cannot be a garnish.
        case "whip": {
            var _pts = sho_qbez([_s.x0 + 0.008, 0.0], [_s.x0 - 0.055, 0.030],
                                [_s.x0 - 0.150, 0.012], 16);
            array_push(_dst, sho_taper_ribbon(_pts, 0.0275, 0.0055, SHO_R_FIN));
            // A barb, two thirds along: the one detail that says stingray rather than kite string.
            array_push(_dst, sho_fill([[_s.x0 - 0.060, 0.014], [_s.x0 - 0.104, -0.030],
                                       [_s.x0 - 0.088, 0.026]], SHO_R_FIN));
        } break;

        /// The fan's span: a FLAT-TOPPED fin mass above and below a small body, so the whole thing
        /// reads as a near-square of fin rather than as a lens.
        ///
        /// ⛔ THIS GEOMETRY IS THE FIX FOR THE WORST DEFECT THE CONTACT SHEET FOUND, and both halves
        /// of it are deliberate:
        ///
        ///   1. `power(_r, 0.30)` NOT `power(_r, 0.62)`. A raised cosine to the 0.62 is a smooth
        ///      lens - a diamond - which is exactly what `ray` is, so two of the twelve forms were
        ///      the same picture. At 0.30 the curve leaves the floor almost immediately and holds
        ///      flat across the middle: a plateau with short shoulders, which is a square of fin.
        ///
        ///   2. THE SPAN IS INSET FROM BOTH ENDS OF THE BODY. Before, it ran the whole length and
        ///      past it, and the silhouette rasteriser measured fan/plain against fan/sail at
        ///      distance ZERO - the span drowned every fin set, so eight silhouettes were one. It
        ///      now starts aft of the head and stops short of the peduncle, leaving the dorsal fin
        ///      and the caudal fin of each set projecting past it where they can still be read.
        case "fanspan": {
            var _n = 24;
            var _up = array_create(_n + 1), _dn = array_create(_n + 1);
            var _ub = array_create(_n + 1), _db = array_create(_n + 1);
            var _len = _s.x1 - _s.x0;
            // ⛔ CONCAVITY. FOURTH REVISION, AND THE THIRD ONE WAS THE MOST INSTRUCTIVE FAILURE.
            //
            // Revision 2 was a narrow hard-peaked spike and read as a FOUR-POINTED STAR. Revision 3
            // widened the base to 76% of the body and softened the shoulders (rising exponent 0.55)
            // - and produced a smooth pointed LOZENGE, a rugby ball. Distinct from everything,
            // recognisable as nothing.
            //
            // The diagnosis is structural rather than a matter of numbers, and it generalises: a
            // silhouette MERGES the body and the fin into one mass, so a tall fin sitting flush on
            // a small body is always going to be one convex blob however it is proportioned. What
            // makes a shape read as FINS rather than as a BLOB is CONCAVITY - the scooped sweep
            // between a fin's trailing edge and the tail, which no convex outline can express.
            //
            // So the rising exponent is now 1.55, ABOVE one rather than below it. Height climbs
            // slowly from the peduncle and then steeply, which draws the outline as a long scooped
            // sweep from the tail up to a peak carried forward at 0.72 - a sailfin. It is the only
            // concave outline in the corpus, which is exactly why it is legible.
            var _a = _s.x0 + _len * 0.10;
            var _b = _s.x1 - _len * 0.13;
            for (var _i = 0; _i <= _n; _i++) {
                var _t = _i / _n;
                var _x = lerp(_a, _b, _t);
                var _sp = sho_form_span(_prof, clamp(_x, _prof.x[0], _prof.x[_prof.n]));
                var _k = (_t < 0.72) ? power(_t / 0.72, 1.55) : power((1 - _t) / 0.28, 0.62);
                _ub[_i] = [_x, _sp[0] + 0.002];
                _db[_i] = [_x, _sp[1] - 0.002];
                _up[_i] = [_x, max(-_s.finbudget, _sp[0] - 0.250 * _k)];
                _dn[_i] = [_x, min( _s.finbudget, _sp[1] + 0.236 * _k)];
            }
            array_push(_dst, sho_strip(_up, _ub, SHO_R_FIN));
            array_push(_dst, sho_strip(_db, _dn, SHO_R_FIN));
        } break;

        /// The pike's jaw: a long wedge carried forward of the snout, with the lower jaw slightly
        /// longer than the upper. The overshot lower jaw is the cheapest pike cue there is.
        case "jaw": {
            var _sp = sho_form_span(_prof, _s.x1 - 0.030);
            array_push(_dst, sho_fill([[_s.x1 - 0.030, _sp[0]], [_s.x1 + 0.128, _sp[2] - 0.017],
                                       [_s.x1 - 0.030, _sp[2] - 0.004]], SHO_R_BODY));
            array_push(_dst, sho_fill([[_s.x1 - 0.030, _sp[2] + 0.004], [_s.x1 + 0.150, _sp[2] + 0.011],
                                       [_s.x1 - 0.030, _sp[1]]], SHO_R_BODY));
        } break;
    }
    return _dst;
}

/// The eye, as a solid mark with a highlight. Drawn for every form, positioned from the spec's own
/// `eye` anchor as a fraction of the LOCAL depth, so it sits correctly on a hatchet's flat back and
/// on an angler's bulbous head without either being special-cased.
function sho_form_eye(_prof, _dst) {
    var _s = _prof.spec;
    var _x = lerp(_s.x0, _s.x1, _s.eye[0]);
    var _sp = sho_form_span(_prof, _x);
    var _half = (_sp[1] - _sp[0]) * 0.5;
    var _y = _sp[2] + _half * _s.eye[1];
    var _r = clamp(_half * 0.30, 0.0145, 0.0335);
    array_push(_dst, sho_dot(_x, _y, _r, SHO_R_EYE));
    array_push(_dst, sho_dot(_x - _r * 0.30, _y - _r * 0.30, _r * 0.34, SHO_R_MARK));
    return _dst;
}

/// The body's HALF-DEPTH at one axial position.
///
/// ⛔ THIS IS WHAT A FIN SHOULD BE SIZED AGAINST, AND USING THE WHOLE-BODY MAXIMUM INSTEAD PRODUCED
/// THE UGLIEST FISH ON THE STORE SHEET. `hatchet` is a shallow back over a very deep keel, so its
/// maximum depth is a BELLY measurement - and a dorsal fin scaled by it came out taller than the
/// entire fish, which rendered as a mushroom on a stick. `flathead` had the same defect for the same
/// reason. Local depth is 0.163 against a maximum of 0.268 on hatchet, and the difference is the
/// difference between a sail and a parasol.
///
/// ⚠️ It returns a HALF-depth, matching what sho_form_depth returns, so the two are interchangeable
/// at a call site. Returning the full depth here would silently double every fin in the package.
function sho_form_halfdepth_at(_prof, _u) {
    var _s = _prof.spec;
    var _x = clamp(lerp(_s.x0, _s.x1, clamp(_u, 0, 1)), _prof.x[0], _prof.x[_prof.n]);
    var _sp = sho_form_span(_prof, _x);
    return (_sp[1] - _sp[0]) * 0.5;
}

/// The maximum |y| the body itself reaches. sho_fins reads this so a fin can be sized from the
/// body it is actually attached to rather than from a constant.
function sho_form_depth(_prof) {
    var _m = 0;
    for (var _i = 0; _i <= _prof.n; _i++) {
        _m = max(_m, abs(_prof.yt[_i]), abs(_prof.yb[_i]));
    }
    return _m;
}
