/// ============================================================================================
/// SHOAL - sho_render: the ONLY file in this package that talks to the GPU.
///
/// Everything above this file produces DATA. sho_forms returns sampled profiles, sho_fins returns
/// arrays of structs, sho_species returns a struct describing a fish, sho_tackle runs a whole
/// minigame with no engine call in it. None of them can draw and none knows what a surface is.
/// This file turns all of it into draw calls and knows nothing about what a `spindle`, a `sail` or
/// a spawning run means.
///
/// That split is not tidiness. It is what lets sho_selftest assert the entire corpus, the whole
/// coordinate contract and the whole catch system HEADLESSLY, on a machine with no window - and
/// this wing's constitution is explicit that GML has no other route to an automated test.
///
/// -- STATE IS SAVED AND RESTORED AT EVERY ENTRY POINT ------------------------------------------
/// Colour, alpha, font, halign, valign. A renderer that leaks GPU state into a buyer's Draw event
/// produces a bug three files away from its cause, in their code, which they cannot reproduce and
/// we cannot debug remotely. Every public function here puts back what it found.
/// ============================================================================================

/// The stroke floor. NOT a rounding tweak and NOT tunable per call.
///
/// ⛔ THIS CONSTANT EXISTS BECAUSE OF A MEASURED SHIPPING FAILURE. Stroke widths in this package are
/// a PROPORTION of the fish, so a specimen drawn at 20px has a detail line of 0.014 * 20 = 0.28px,
/// and GameMaker draws that at roughly a quarter coverage - a grey smear rather than a line. A
/// product in this wing shipped a whole corpus that way: 369 in-engine assertions passed, the
/// extent check passed, the ink-bounds check passed, and the marks were grey dust. It took opening
/// the PNG and looking.
///
/// Shoal's bodies, fins and patterns are FILLED MASSES precisely so they do not depend on this, and
/// the floor covers what is left: the lateral line and the specimen frame's edge.
#macro SHO_W_FLOOR 1.00

/// ============================================================================================
/// INK
///
/// An ink is a struct mapping every role to a colour. One function turns a role into a colour, and
/// it is the only place in the package that does - which is what lets 12 forms x 8 fin sets x 10
/// patterns appear in ten palettes without any geometry knowing about colour.
/// ============================================================================================

function sho_role_colour(_role, _ink) {
    switch (_role) {
        case SHO_R_BODY:  return _ink.body;
        case SHO_R_BELLY: return _ink.belly;
        case SHO_R_FIN:   return _ink.fin;
        case SHO_R_MARK:  return _ink.mark;
        case SHO_R_EYE:   return _ink.eye;
        default:          return _ink.edge;
    }
}

/// Every role the same colour.
///
/// This is what makes the silhouette rasteriser possible, and the rasteriser is the check
/// Motif_Corpus.md §0 names as the one that matters - pattern and palette cannot change an outline,
/// so the outline has to be tested with both switched off. It is also genuinely useful to a buyer:
/// a flat ink is a shadow, a reflection, a fish seen against the sun, or a codex silhouette for a
/// species not yet caught.
function sho_ink_flat(_c) {
    return { body: _c, belly: _c, fin: _c, mark: _c, eye: _c, edge: _c };
}

/// ============================================================================================
/// FONTS - the only two places either font resource is named
/// ============================================================================================

/// The body font, used for species names, biome rows, record figures and card text.
///
/// ⛔ SUBSTITUTING A FONT IS A ONE-LINE EDIT, AND THAT IS THE ENTIRE POINT OF THIS FUNCTION.
/// A buyer changing the look of their own UI should not have to find and replace a font resource
/// across somebody else's drawing code. Return any font resource you like from these two. Nothing
/// else in the package names a font.
function sho_font() {
    return fnt_shoal;
}

/// The display font, used for card titles and headings.
function sho_font_title() {
    return fnt_shoal_title;
}

/// ============================================================================================
/// PRIMITIVES
/// ============================================================================================

/// Draw one placed part. Internal - call sho_draw_parts.
function sho_draw_part(_p, _ink) {
    draw_set_colour(sho_role_colour(_p.role, _ink));

    switch (_p.kind) {

        case SHO_DOT:
            draw_circle(_p.cx, _p.cy, max(0.4, _p.r), false);
            return;

        case SHO_ARC: {
            // Sampled, not draw_circle's outline: an arc here may be partial, and GameMaker's
            // circle outline ignores line width entirely.
            var _sweep = abs(_p.a1 - _p.a0);
            var _steps = max(10, ceil(_sweep * 14));
            var _w = max(SHO_W_FLOOR, _p.w);
            var _px = _p.cx + cos(_p.a0) * _p.r;
            var _py = _p.cy + sin(_p.a0) * _p.r;
            for (var _i = 1; _i <= _steps; _i++) {
                var _a = lerp(_p.a0, _p.a1, _i / _steps);
                var _nx = _p.cx + cos(_a) * _p.r;
                var _ny = _p.cy + sin(_a) * _p.r;
                draw_line_width(_px, _py, _nx, _ny, _w);
                _px = _nx; _py = _ny;
            }
            return;
        }

        case SHO_FILL: {
            var _n = array_length(_p.pts);
            if (_n < 3) return;
            draw_primitive_begin(pr_trianglefan);
            for (var _i = 0; _i < _n; _i++) draw_vertex(_p.pts[_i][0], _p.pts[_i][1]);
            draw_primitive_end();
            return;
        }

        case SHO_STRIP: {
            // ONE primitive, not N quads. Adjacent triangles in a strip share their edges; drawing
            // the same band as separate quads leaves a hairline showing through every join, which
            // on a bend reads as a dotted line rather than as a line. Every body in this package is
            // a strip, so this matters on literally every fish.
            var _n = min(array_length(_p.a), array_length(_p.b));
            if (_n < 2) return;
            draw_primitive_begin(pr_trianglestrip);
            for (var _i = 0; _i < _n; _i++) {
                draw_vertex(_p.a[_i][0], _p.a[_i][1]);
                draw_vertex(_p.b[_i][0], _p.b[_i][1]);
            }
            draw_primitive_end();
            return;
        }

        default: {
            var _n = array_length(_p.pts);
            if (_n < 2) return;
            var _w = max(SHO_W_FLOOR, _p.w);
            for (var _i = 1; _i < _n; _i++) {
                draw_line_width(_p.pts[_i - 1][0], _p.pts[_i - 1][1],
                                _p.pts[_i][0], _p.pts[_i][1], _w);
            }
            if (_p.closed) {
                draw_line_width(_p.pts[_n - 1][0], _p.pts[_n - 1][1],
                                _p.pts[0][0], _p.pts[0][1], _w);
            }
            return;
        }
    }
}

/// Draw a placed part list.
function sho_draw_parts(_parts, _ink, _alpha) {
    if (is_undefined(_alpha)) _alpha = 1;
    var _oldC = draw_get_colour(), _oldA = draw_get_alpha();
    if (_alpha != 1) draw_set_alpha(_alpha);
    for (var _i = 0; _i < array_length(_parts); _i++) sho_draw_part(_parts[_i], _ink);
    draw_set_colour(_oldC);
    draw_set_alpha(_oldA);
}

/// ============================================================================================
/// PLACEMENT
/// ============================================================================================

/// Mirror a unit-box part list about x, so a fish can swim the other way.
///
/// ⛔ MIRRORING HAPPENS IN UNIT-BOX SPACE, BEFORE PLACEMENT, AND IT IS THE ONLY PLACE FLIP EXISTS.
/// A buyer's fish turns around; every authored form, fin set and pattern in this package is drawn
/// tail-left / head-right and NONE of them knows that. Pushing the flip up into the authoring layer
/// would mean 12 forms x 8 fins x 10 patterns each having an opinion about facing - which is the
/// wing's measured sprite-facing trap arriving in geometry instead of in art.
///
/// ⚠️ A negative scale through sho_place would NOT do this: that mirrors x and y together, i.e. it
/// turns the fish upside down as well as around, and on a symmetrical form it looks correct.
///
/// Winding reverses, which is harmless: GameMaker does not backface-cull 2D primitives, and both
/// primitive kinds this package emits are unculled triangle lists.
function sho_mirror(_parts) {
    var _n = array_length(_parts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case SHO_DOT: _out[_i] = sho_dot(-_p.cx, _p.cy, _p.r, _p.role); break;
            // An arc's sweep mirrors to [pi - a1, pi - a0]. Negating the angles alone flips it
            // vertically instead, which is silent on a full ring and wrong on every partial one.
            case SHO_ARC: _out[_i] = sho_arc(-_p.cx, _p.cy, _p.r, pi - _p.a1, pi - _p.a0,
                                             _p.w, _p.role); break;
            case SHO_STRIP: {
                var _na = array_length(_p.a), _nb = array_length(_p.b);
                var _a = array_create(_na), _b = array_create(_nb);
                for (var _k = 0; _k < _na; _k++) _a[_k] = [-_p.a[_k][0], _p.a[_k][1]];
                for (var _k = 0; _k < _nb; _k++) _b[_k] = [-_p.b[_k][0], _p.b[_k][1]];
                _out[_i] = sho_strip(_a, _b, _p.role);
            } break;
            case SHO_FILL: {
                var _np = array_length(_p.pts);
                var _pts = array_create(_np);
                for (var _k = 0; _k < _np; _k++) _pts[_k] = [-_p.pts[_k][0], _p.pts[_k][1]];
                _out[_i] = sho_fill(_pts, _p.role);
            } break;
            default: {
                var _np = array_length(_p.pts);
                var _pts = array_create(_np);
                for (var _k = 0; _k < _np; _k++) _pts[_k] = [-_p.pts[_k][0], _p.pts[_k][1]];
                _out[_i] = sho_poly(_pts, _p.closed, _p.w, _p.role);
            } break;
        }
    }
    return _out;
}

/// Map a unit-box part list onto the screen at (_cx, _cy) with half-extent _size, optionally
/// mirrored. Stroke widths scale with the fish, floored in sho_draw_part - see SHO_W_FLOOR.
function sho_place_fish(_parts, _cx, _cy, _size, _flip) {
    var _p = (!is_undefined(_flip) && _flip) ? sho_mirror(_parts) : _parts;
    return sho_place(_p, _cx, _cy, _size, 0, _size, undefined);
}

/// Draw a whole specimen: body, pattern, fins, extras and eye, at (_cx, _cy).
///
/// ⛔ THE DRAW ORDER IS PART OF THE PRODUCT AND IS NOT ARBITRARY.
///   1. fins FIRST, so they sit behind the body and the body's edge stays clean. A fin drawn over
///      the body shows its own root as a seam across the fish, on every one of the 96 pairings.
///   2. the body.
///   3. the pattern, which is already clipped to the body in geometry, so it lands inside the
///      outline exactly and never over a fin.
///   4. form-intrinsic extras - a pike's jaw and an angler's lure read as part of the head and must
///      sit over the body; a ray's whip and a fan's span are behind it and are emitted first by
///      sho_form_extra for that reason.
///   5. the eye, last, because it is the one feature that must never be occluded.
function sho_species_draw(_sp, _cx, _cy, _size, _flip) {
    if (!sho_species_is(_sp)) return;      // draw nothing rather than throw mid-frame
    var _oldC = draw_get_colour(), _oldA = draw_get_alpha();
    var _prof = _sp.prof;

    var _fins = sho_fin_parts(_prof, _sp.fin, []);
    sho_draw_parts(sho_place_fish(_fins, _cx, _cy, _size, _flip), _sp.ink, 1);

    sho_draw_parts(sho_place_fish([sho_form_body(_prof, SHO_R_BODY)], _cx, _cy, _size, _flip), _sp.ink, 1);
    sho_draw_parts(sho_place_fish(sho_pattern_parts(_prof, _sp.pattern, _sp.seed, []),
                             _cx, _cy, _size, _flip), _sp.ink, 1);

    var _extra = sho_form_extra(_prof, []);
    sho_draw_parts(sho_place_fish(_extra, _cx, _cy, _size, _flip), _sp.ink, 1);

    var _eye = sho_form_eye(_prof, []);
    sho_draw_parts(sho_place_fish(_eye, _cx, _cy, _size, _flip), _sp.ink, 1);

    draw_set_colour(_oldC);
    draw_set_alpha(_oldA);
}

/// ============================================================================================
/// FITTING A SPECIMEN TO A FRAME
///
/// ⛔ A UNIT BOX IS NOT A BOUNDING BOX, AND THE DIFFERENCE IS 40% OF EVERY PANEL. Forms are
/// authored in [-0.5, 0.5] so they share one coordinate contract, but no form fills it: `spindle`
/// occupies 0.69 of the width and about 0.30 of the height, and `flathead` far less. Drawing at
/// "half-extent = half the panel" therefore leaves a third to a half of every frame empty, which is
/// exactly what the store sheets showed - and what a buyer's inventory slot would show too.
///
/// So the drawing is measured and fitted. This is a product feature, not a store-sheet fix: a fish
/// dropped into a UI slot should fill the slot.
///
/// THE MEASUREMENT IS CACHED, because it depends only on the form and the fin set - 96 possible
/// values - and never on the pattern, the palette or the individual.
function sho_species_bbox(_sp) {
    // A degenerate box for an unusable species: every _fit caller divides by its width, and they
    // all clamp with max(0.001, ...), so this propagates safely instead of throwing.
    if (!sho_species_is(_sp)) return [0, 0, 0, 0];
    if (!variable_global_exists("sho_bbox_cache")) global.sho_bbox_cache = {};
    var _key = _sp.form + "/" + _sp.fin;
    if (variable_struct_exists(global.sho_bbox_cache, _key)) {
        return variable_struct_get(global.sho_bbox_cache, _key);
    }
    var _prof = _sp.prof;
    var _p = sho_fin_parts(_prof, _sp.fin, []);
    array_push(_p, sho_form_body(_prof, SHO_R_BODY));
    sho_form_extra(_prof, _p);

    var _x0 = 9, _y0 = 9, _x1 = -9, _y1 = -9;
    for (var _i = 0; _i < array_length(_p); _i++) {
        var _q = _p[_i];
        if (_q.kind == SHO_DOT || _q.kind == SHO_ARC) {
            _x0 = min(_x0, _q.cx - _q.r); _x1 = max(_x1, _q.cx + _q.r);
            _y0 = min(_y0, _q.cy - _q.r); _y1 = max(_y1, _q.cy + _q.r);
            continue;
        }
        var _lists = (_q.kind == SHO_STRIP) ? [_q.a, _q.b] : [_q.pts];
        for (var _l = 0; _l < array_length(_lists); _l++) {
            var _pts = _lists[_l];
            for (var _k = 0; _k < array_length(_pts); _k++) {
                _x0 = min(_x0, _pts[_k][0]); _x1 = max(_x1, _pts[_k][0]);
                _y0 = min(_y0, _pts[_k][1]); _y1 = max(_y1, _pts[_k][1]);
            }
        }
    }
    var _box = [_x0, _y0, _x1, _y1];
    variable_struct_set(global.sho_bbox_cache, _key, _box);
    return _box;
}

/// Draw a specimen fitted into a box of _w x _h, centred, at up to `_maxScale` of natural size.
///
/// ⚠️ THE FISH IS RE-CENTRED ON ITS OWN BOUNDING BOX, not on the unit-box origin. Half the corpus is
/// asymmetric about y - `hatchet` is nearly all belly, `flathead` nearly all back - so centring on
/// the origin hangs those forms off the bottom of a tight frame even when they fit it.
function sho_species_draw_fit(_sp, _cx, _cy, _w, _h, _flip) {
    if (!sho_species_is(_sp)) return;
    var _b = sho_species_bbox(_sp);
    var _bw = max(0.001, _b[2] - _b[0]), _bh = max(0.001, _b[3] - _b[1]);
    var _s = min(_w / _bw, _h / _bh);
    // Shift by the bbox centre, in SCREEN units, and mirror that shift when the fish is flipped.
    var _mx = (_b[0] + _b[2]) * 0.5 * _s;
    var _my = (_b[1] + _b[3]) * 0.5 * _s;
    if (!is_undefined(_flip) && _flip) _mx = -_mx;
    sho_species_draw(_sp, _cx - _mx, _cy - _my, _s, _flip);
}

/// The same, in silhouette.
function sho_species_silhouette_fit(_sp, _cx, _cy, _w, _h, _colour, _flip) {
    if (!sho_species_is(_sp)) return;
    var _b = sho_species_bbox(_sp);
    var _bw = max(0.001, _b[2] - _b[0]), _bh = max(0.001, _b[3] - _b[1]);
    var _s = min(_w / _bw, _h / _bh);
    var _mx = (_b[0] + _b[2]) * 0.5 * _s;
    var _my = (_b[1] + _b[3]) * 0.5 * _s;
    if (!is_undefined(_flip) && _flip) _mx = -_mx;
    sho_species_silhouette(_sp, _cx - _mx, _cy - _my, _s, _colour, _flip);
}

/// The silhouette: the same fish, every role one colour, no pattern.
///
/// Used by the codex for an uncaught species, by the demo for a fish seen against bright water, and
/// by sho_selftest's rasteriser - which is the corpus's real acceptance test.
function sho_species_silhouette(_sp, _cx, _cy, _size, _colour, _flip) {
    if (!sho_species_is(_sp)) return;
    var _ink = sho_ink_flat(_colour);
    var _prof = _sp.prof;
    var _p = sho_fin_parts(_prof, _sp.fin, []);
    array_push(_p, sho_form_body(_prof, SHO_R_BODY));
    sho_form_extra(_prof, _p);
    sho_draw_parts(sho_place_fish(_p, _cx, _cy, _size, _flip), _ink, 1);
}
