{
  "$GMScript": "v1",
  "%Name": "sho_render",
  "isCompatibility": false,
  "isDnD": false,
  "name": "sho_render",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}