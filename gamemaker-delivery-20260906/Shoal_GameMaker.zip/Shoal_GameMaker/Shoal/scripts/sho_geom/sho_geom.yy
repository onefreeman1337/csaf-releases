{
  "$GMScript": "v1",
  "%Name": "sho_geom",
  "isCompatibility": false,
  "isDnD": false,
  "name": "sho_geom",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}