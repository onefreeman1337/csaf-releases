{
  "$GMScript": "v1",
  "%Name": "sho_log",
  "isCompatibility": false,
  "isDnD": false,
  "name": "sho_log",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}