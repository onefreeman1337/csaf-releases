/// ============================================================================================
/// SHOAL - sho_log: the collection. Records, the codex, completion, save and load.
///
/// This is the file that turns a fishing minigame into a GAME. A player who lands a fish gets a
/// card; a player who keeps landing them gets a RECORD BOARD, a codex filling in, and a completion
/// figure that means something because the catalogue is finite and knowable.
///
/// -- WHAT IS STORED, AND WHAT IS NOT -----------------------------------------------------------
/// One entry per SPECIES, keyed by its code (`form/pattern/fin/livery`), holding only the best
/// specimen and a count. Not every catch: a player who fishes for twenty hours would otherwise
/// carry an unbounded save file, and nothing in the product ever asks "what was my 400th fish".
///
/// ⛔ AND NOTHING HERE STORES A DRAWING, A COLOUR OR A GEOMETRY. An entry is four component ids and
/// three numbers; the fish is REGENERATED from them by sho_species_make on load. That is what makes
/// a save file 60 bytes an entry instead of a serialised scene, and it is only possible because the
/// corpus is deterministic - the same four components always produce the same fish. If that ever
/// stops being true, every save file in every buyer's game silently shows different fish than the
/// ones the player caught.
///
/// -- THE SAVE FORMAT IS PLAIN TEXT AND VERSIONED -----------------------------------------------
/// One line per entry, `v1|code|len|mass|rarity|count`. A buyer can read it, diff it, hand-edit it
/// for testing, and migrate it. A binary blob is smaller and every one of those becomes impossible.
/// ============================================================================================

#macro SHO_SAVE_VERSION "v1"

/// A fresh, empty log.
function sho_log_new() {
    return { entries: {}, caught: 0, landed: 0, lost: 0 };
}

/// ============================================================================================
/// REFUSE, NEVER THROW — the convention this file already followed in ONE place and nowhere else.
/// ============================================================================================
/// `sho_log_load_string` has always opened with `if (!is_string(_str) ...) return _log;`, which is
/// why an adversarial pass could hand it undefined, "", "garbage", 42, a JSON blob, half a save and
/// a save with trailing junk WITHOUT a single crash. Every other public function in this file
/// dereferenced its argument immediately, so `sho_log_land(log, undefined)` threw.
///
/// ⭐ WHY THAT MATTERS MORE THAN IT LOOKS: this is the SAVE PATH. A buyer ships their game, a
/// player's session produces an undefined catch (a fight that ended in a loss, a slot that was
/// never filled, a migrated save), and the throw happens inside a bought library in the player's
/// game — which this wing's own constitution calls a support ticket the seller cannot debug
/// remotely. MEASURED 2026-09-06: 102 hostile calls, 26 crashes, before these guards.
///
/// The predicate is one function so the idiom cannot drift between call sites.
function sho_log_is(_log) {
    return !is_undefined(_log) && is_struct(_log) && variable_struct_exists(_log, "entries");
}

/// A catch is only usable here if it carries the species struct `sho_log_land` reads through.
function sho_catch_is(_catch) {
    return !is_undefined(_catch) && is_struct(_catch)
        && variable_struct_exists(_catch, "sp") && is_struct(_catch.sp)
        && variable_struct_exists(_catch.sp, "code");
}

/// Record a landed catch. Returns true if it set a new record for its species.
///
/// ⚠️ THE CATCH IS MUTATED: `record` is set on it, because the specimen card reads that field and
/// the card is normally drawn straight after this call. Returning the flag as well is deliberate -
/// a caller that wants to fire a sound or a toast should not have to know that.
function sho_log_land(_log, _catch) {
    // Refuse rather than throw: a malformed catch records nothing and is not a record.
    if (!sho_log_is(_log) || !sho_catch_is(_catch)) return false;
    var _code = _catch.sp.code;
    _log.caught += 1;
    _log.landed += 1;

    if (!variable_struct_exists(_log.entries, _code)) {
        variable_struct_set(_log.entries, _code, {
            code: _code, len_cm: _catch.len_cm, mass_g: _catch.mass_g,
            rarity: _catch.rarity, count: 1
        });
        _catch.record = true;          // the first of a species is always a record
        return true;
    }

    var _e = variable_struct_get(_log.entries, _code);
    _e.count += 1;
    // LENGTH is the record, not mass. They rank identically for one species - mass is a monotonic
    // function of length within a form - so either works, and length is what an angler quotes.
    if (_catch.len_cm > _e.len_cm) {
        _e.len_cm = _catch.len_cm;
        _e.mass_g = _catch.mass_g;
        _e.rarity = max(_e.rarity, _catch.rarity);
        _catch.record = true;
        return true;
    }
    _catch.record = false;
    return false;
}

/// Record a fish that got away. Counted, because "hooked 40, landed 12" is a statistic a player
/// cares about and it costs one integer.
function sho_log_lost(_log) {
    if (!sho_log_is(_log)) return _log;
    _log.caught += 1;
    _log.lost += 1;
    return _log;
}

/// Has this species been caught?
function sho_log_has(_log, _code) {
    if (!sho_log_is(_log) || !is_string(_code)) return false;
    return variable_struct_exists(_log.entries, _code);
}

/// The best specimen of a species, or undefined.
function sho_log_best(_log, _code) {
    if (!sho_log_is(_log) || !is_string(_code)) return undefined;
    if (!variable_struct_exists(_log.entries, _code)) return undefined;
    return variable_struct_get(_log.entries, _code);
}

/// How many distinct species have been caught.
function sho_log_species_count(_log) {
    if (!sho_log_is(_log)) return 0;
    return array_length(variable_struct_get_names(_log.entries));
}

/// Completion, 0..1, against the whole catalogue.
///
/// ⚠️ AGAINST 9,600, AND THAT IS A DELIBERATE CHOICE WITH A CONSEQUENCE. The full catalogue is a
/// combination count, so 100% is not a realistic goal and is not meant to be - this is a number
/// that goes up forever, like a life list, not a progress bar to be filled. A buyer who wants a
/// completable set should call sho_log_completion_of() against a biome, which is a real target.
function sho_log_completion(_log) {
    return sho_log_species_count(_log) / sho_species_count();
}

/// Completion against what one water can actually produce, which IS completable.
///
/// The denominator is computed from the same weight tables the roll uses, so a species that cannot
/// appear in a biome is never counted against a player trying to finish it. Getting this wrong in
/// the obvious direction - counting the whole catalogue per biome - would make every biome show a
/// few percent forever.
function sho_log_completion_of(_log, _biome) {
    var _forms = sho_water_forms_here(_biome);
    // Palettes are season- and hour-dependent, so the honest denominator is the union across the
    // whole year and the whole day: everything the water can EVER produce.
    var _livs = [];
    var _all = sho_livery_ids();
    for (var _i = 0; _i < array_length(_all); _i++) {
        var _ok = false;
        for (var _s = 0; _s < 4 && !_ok; _s++) {
            for (var _h = 0; _h < 24 && !_ok; _h += 6) {
                if (sho_livery_weight(_biome, _s, _h, _i) > 0) _ok = true;
            }
        }
        if (_ok) array_push(_livs, _all[_i]);
    }
    var _total = array_length(_forms) * array_length(_livs)
               * array_length(sho_pattern_ids()) * array_length(sho_fin_ids());
    if (_total <= 0) return 0;

    var _have = 0;
    var _names = variable_struct_get_names(_log.entries);
    for (var _i = 0; _i < array_length(_names); _i++) {
        var _parts = string_split(_names[_i], "/");
        if (array_length(_parts) != 4) continue;
        var _fOK = false, _lOK = false;
        for (var _k = 0; _k < array_length(_forms); _k++) if (_forms[_k] == _parts[0]) _fOK = true;
        for (var _k = 0; _k < array_length(_livs);  _k++) if (_livs[_k]  == _parts[3]) _lOK = true;
        if (_fOK && _lOK) _have += 1;
    }
    return _have / _total;
}

/// The record board: every entry, heaviest first, as an array.
///
/// ⚠️ SORTED BY MASS, NOT BY LENGTH, and the two genuinely disagree ACROSS species - a 120cm ribbon
/// weighs less than a 60cm torpedo, because girth is real (see sho_species). A board sorted by
/// length would put the flimsiest fish in the product at the top, which is why sho_forms carries a
/// girth figure at all.
function sho_log_board(_log, _limit) {
    if (!sho_log_is(_log)) return [];
    var _names = variable_struct_get_names(_log.entries);
    var _out = [];
    for (var _i = 0; _i < array_length(_names); _i++) {
        array_push(_out, variable_struct_get(_log.entries, _names[_i]));
    }
    // Insertion sort: the board is tens of entries, not thousands, and this keeps the file free of
    // a comparator closure whose behaviour differs between GML versions.
    for (var _i = 1; _i < array_length(_out); _i++) {
        var _v = _out[_i];
        var _k = _i - 1;
        while (_k >= 0 && _out[_k].mass_g < _v.mass_g) { _out[_k + 1] = _out[_k]; _k -= 1; }
        _out[_k + 1] = _v;
    }
    if (!is_undefined(_limit) && array_length(_out) > _limit) {
        var _cut = array_create(_limit);
        for (var _i = 0; _i < _limit; _i++) _cut[_i] = _out[_i];
        return _cut;
    }
    return _out;
}

/// Is this code four components that all still EXIST?
///
/// ⛔ IT CHECKS MEMBERSHIP, NOT SHAPE, and the difference is what protects a buyer's save file
/// across a version. `sho_species_make` will happily build a struct from a form id that no longer
/// exists - the profile comes back undefined and the fish blows up at DRAW time, three files and
/// several frames away from the corrupt row that caused it. Validating on the way in means a
/// renamed component costs one skipped entry instead of a crash in someone's game.
function sho_code_valid(_code) {
    if (!is_string(_code)) return false;
    var _p = string_split(_code, "/");
    if (array_length(_p) != 4) return false;
    var _lists = [sho_form_ids(), sho_pattern_ids(), sho_fin_ids(), sho_livery_ids()];
    for (var _i = 0; _i < 4; _i++) {
        var _ok = false;
        for (var _k = 0; _k < array_length(_lists[_i]); _k++) {
            if (_lists[_i][_k] == _p[_i]) { _ok = true; break; }
        }
        if (!_ok) return false;
    }
    return true;
}

/// Rebuild the species struct for a log entry, so a codex can draw it.
function sho_log_species(_entry) {
    if (is_undefined(_entry) || !is_struct(_entry) || !variable_struct_exists(_entry, "code")) return undefined;
    if (!sho_code_valid(_entry.code)) return undefined;
    var _p = string_split(_entry.code, "/");
    return sho_species_make(_p[0], _p[1], _p[2], _p[3], undefined);
}

/// ============================================================================================
/// SAVE AND LOAD
/// ============================================================================================

/// Serialise to a plain-text string. The caller decides where it goes - a file, an ini, a slot in
/// their own save system - because this package has no opinion about a buyer's save architecture.
function sho_log_save_string(_log) {
    // An unusable log saves as an EMPTY log rather than throwing: the caller is mid-save, and
    // a throw there loses the player's whole session instead of one bad record.
    if (!sho_log_is(_log)) { _log = sho_log_new(); }
    var _s = SHO_SAVE_VERSION + "|" + string(_log.caught) + "|" + string(_log.landed)
           + "|" + string(_log.lost) + "\n";
    var _names = variable_struct_get_names(_log.entries);
    for (var _i = 0; _i < array_length(_names); _i++) {
        var _e = variable_struct_get(_log.entries, _names[_i]);
        _s += _e.code + "|" + string(_e.len_cm) + "|" + string(_e.mass_g)
            + "|" + string(_e.rarity) + "|" + string(_e.count) + "\n";
    }
    return _s;
}

/// Parse one back. Returns a fresh log; never throws on malformed input.
///
/// ⛔ A CORRUPT SAVE MUST NOT CRASH A BUYER'S GAME, and "never throws" is a promise this function
/// keeps by checking every field rather than by wrapping the whole thing in a try. A save file is
/// the one input a game takes from outside itself, it is the one users edit, and it is the one that
/// survives a version upgrade. Every line is validated: wrong version, wrong field count, a code
/// with the wrong number of parts, a non-numeric length - each is skipped, and the rest still load.
/// Losing one row beats losing a player's whole collection.
function sho_log_load_string(_str) {
    var _log = sho_log_new();
    if (!is_string(_str) || string_length(_str) == 0) return _log;

    var _lines = string_split(_str, "\n");
    if (array_length(_lines) == 0) return _log;

    var _head = string_split(_lines[0], "|");
    if (array_length(_head) < 4 || _head[0] != SHO_SAVE_VERSION) return _log;
    _log.caught = real(_head[1]);
    _log.landed = real(_head[2]);
    _log.lost   = real(_head[3]);

    for (var _i = 1; _i < array_length(_lines); _i++) {
        var _l = string_trim(_lines[_i]);
        if (string_length(_l) == 0) continue;
        var _p = string_split(_l, "|");
        if (array_length(_p) < 5) continue;
        // The code must name four components that still EXIST. A pattern renamed in a future
        // version would otherwise load as an entry that can never be drawn.
        if (!sho_code_valid(_p[0])) continue;
        variable_struct_set(_log.entries, _p[0], {
            code: _p[0], len_cm: real(_p[1]), mass_g: real(_p[2]),
            rarity: clamp(real(_p[3]), 0, 4), count: max(1, real(_p[4]))
        });
    }
    return _log;
}
