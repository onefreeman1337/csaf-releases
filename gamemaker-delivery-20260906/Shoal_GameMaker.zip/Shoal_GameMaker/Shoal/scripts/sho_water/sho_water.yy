{
  "$GMScript": "v1",
  "%Name": "sho_water",
  "isCompatibility": false,
  "isDnD": false,
  "name": "sho_water",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}