/// ============================================================================================
/// SHOAL - sho_water: WHERE and WHEN. Biomes, seasons, hours, and what is in the water.
///
/// This is the system underneath the drawing. Without it the product is a fish generator; with it,
/// a player learns that the flathead is an estuary fish, that ice liveries only appear in winter,
/// and that whatever is down in the deep at 03:00 is worth staying up for. That learning IS the
/// game loop, and it is made of the tables below.
///
/// -- ⛔ RARITY IS DERIVED, NEVER DECLARED ------------------------------------------------------
/// There is no "rarity: 4" field on any species anywhere in this package. A catch's tier is
/// computed from how unlikely its own combination was in the water it came out of - so a fish that
/// is common in the reef is genuinely scarce in a river, without either fact being written down
/// twice. Declaring rarity separately from the weights that produce it is how the two drift until
/// a "legendary" turns up nine times an hour.
///
/// -- THE WEIGHTS ARE THE CONTENT ---------------------------------------------------------------
/// 5 biomes x 12 forms and 5 biomes x 10 palettes is 110 authored weights, plus 4 seasonal and 4
/// hourly modifiers per palette. They are what makes each stretch of water feel like a place.
/// ============================================================================================

function sho_biome_ids() { return ["river", "lake", "estuary", "reef", "deep"]; }

function sho_biome_name(_id) {
    switch (_id) {
        case "river":   return "River";
        case "lake":    return "Lake";
        case "estuary": return "Estuary";
        case "reef":    return "Reef";
        case "deep":    return "Deep Water";
    }
    return "?";
}

/// Four bands rather than 24 separate cases: a table per hour would be 24x the content for no more
/// information, and a player reasons in dawn / day / dusk / night anyway.
function sho_hour_band(_h) {
    var _hh = _h mod 24;
    if (_hh >= 5 && _hh < 8)   return 0;   // dawn
    if (_hh >= 8 && _hh < 17)  return 1;   // day
    if (_hh >= 17 && _hh < 21) return 2;   // dusk
    return 3;                              // night
}

function sho_band_name(_b) {
    switch (_b) {
        case 0: return "Dawn";
        case 1: return "Day";
        case 2: return "Dusk";
        case 3: return "Night";
    }
    return "?";
}

/// ============================================================================================
/// THE TABLES
///
/// A weight of 0 means "never here". That is a real design tool, not a null: it is what makes an
/// oarfish a deep-water fish and keeps the river feeling like a river.
/// ============================================================================================

/// How common each BODY FORM is in each biome. Index order matches sho_form_ids().
///        spindle torpedo disc sunfish eel ribbon flathead hatchet angler ray fan pike
function sho_biome_form_weights(_biome) {
    switch (_biome) {
        case "river":   return [30, 2, 16,  0, 14,  0, 12,  2,  0,  0,  3, 21];
        case "lake":    return [26, 3, 22,  0,  9,  0,  8,  4,  0,  0,  5, 23];
        case "estuary": return [18, 9, 12,  1, 16,  2, 24,  5,  3,  8,  2, 10];
        case "reef":    return [ 9, 14, 24,  3,  8,  2,  7,  6,  4, 11, 20,  2];
        case "deep":    return [ 4, 12,  5, 14, 11, 16,  3, 15, 18,  9,  2,  1];
    }
    return [10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10];
}

/// How common each PALETTE is in each biome. Index order matches sho_livery_ids().
///        riverine reef abyssal estuary alpine kelp brackish ice volcanic spawning
function sho_biome_livery_weights(_biome) {
    switch (_biome) {
        case "river":   return [40,  0,  0,  6, 14, 18,  8,  4,  0, 10];
        case "lake":    return [26,  0,  0,  4, 32, 20,  4,  8,  0,  6];
        case "estuary": return [16,  2,  0, 38,  2, 14, 24,  1,  0,  3];
        case "reef":    return [ 2, 46,  1,  4,  0, 22, 10,  0,  4, 11];
        case "deep":    return [ 0,  4, 42,  2,  3,  6,  5,  6, 26,  6];
    }
    return [10, 10, 10, 10, 10, 10, 10, 10, 10, 10];
}

/// Seasonal multipliers on the palette weights, in tenths. THIS IS WHERE SPAWNING LIVERY LIVES:
/// it is x30 in spring and x0 for the rest of the year, so the loudest palette in the product is
/// a thing that happens rather than a thing that is available.
///
/// ⚠️ A ZERO HERE IS ABSOLUTE and it is meant to be. `ice` outside winter and `spawning` outside
/// spring are not rare, they are absent - which is what makes the calendar worth watching.
function sho_season_livery_mult(_season, _li) {
    //                riverine reef abyssal estuary alpine kelp brackish ice volcanic spawning
    var _spring = [ 12, 10, 10, 10, 12, 14,  8,  0,  10, 30];
    var _summer = [ 12, 14, 10, 12,  6, 16, 12,  0,  10,  0];
    var _autumn = [ 14,  8, 10, 14,  8, 10, 14,  2,  10,  0];
    var _winter = [  6,  4, 12,  6, 16,  4,  8, 26,  12,  0];
    switch (_season mod 4) {
        case 0: return _spring[_li] / 10;
        case 1: return _summer[_li] / 10;
        case 2: return _autumn[_li] / 10;
        default: return _winter[_li] / 10;
    }
}

/// Hourly multipliers on the palette weights, in tenths. Dark liveries at night, bright ones at
/// midday - which is both true of real fish and the reason a player fishes at a particular hour.
function sho_band_livery_mult(_band, _li) {
    //             riverine reef abyssal estuary alpine kelp brackish ice volcanic spawning
    var _dawn  = [ 12, 10,  8, 12, 12, 12, 12, 10,  8, 16];
    var _day   = [ 12, 16,  4, 10, 12, 12, 10, 12,  6,  8];
    var _dusk  = [ 10,  8, 14, 10,  8, 10, 12,  8, 12, 14];
    var _night = [  6,  4, 22,  8,  6,  6,  8,  6, 20,  6];
    switch (_band) {
        case 0: return _dawn[_li] / 10;
        case 1: return _day[_li] / 10;
        case 2: return _dusk[_li] / 10;
        default: return _night[_li] / 10;
    }
}

/// The effective weight of one palette in one place at one time. One function, so the composition
/// order is stated once and every caller - the roll, the rarity, the codex hint - agrees.
function sho_livery_weight(_biome, _season, _hour, _li) {
    var _base = sho_biome_livery_weights(_biome)[_li];
    if (_base <= 0) return 0;
    return _base * sho_season_livery_mult(_season, _li)
                 * sho_band_livery_mult(sho_hour_band(_hour), _li);
}

/// ============================================================================================
/// THE ROLL
/// ============================================================================================

/// Pick an index from a weight array, by a value in 0..1. Returns -1 if every weight is zero, which
/// a caller must handle rather than clamp - an empty table is a design error, not a fish.
function sho_pick_weighted(_w, _t) {
    var _n = array_length(_w), _sum = 0;
    for (var _i = 0; _i < _n; _i++) _sum += max(0, _w[_i]);
    if (_sum <= 0) return -1;
    var _r = clamp(_t, 0, 0.999999) * _sum, _acc = 0;
    for (var _i = 0; _i < _n; _i++) {
        _acc += max(0, _w[_i]);
        if (_r < _acc) return _i;
    }
    return _n - 1;
}

/// What is on the end of the line.
///
/// Form, pattern, fin and palette are drawn against the water's own tables; LENGTH is drawn against
/// the form's typical size with a long tail, so a genuinely big fish is rare and memorable rather
/// than a slider position. Rarity then falls out of all of it.
function sho_water_roll(_biome, _season, _hour, _seed) {
    /// Refuse, never throw. The Readme's own first line of integration code is
    /// `sho_water_roll("reef", 0, 14, irandom(999999))`, so the SEED comes from the caller and an
    /// uninitialised variable arrives here as `undefined` — which used to die inside the generator
    /// as `DoMod :2: undefined value`, a message that names nothing a buyer can act on.
    /// A missing seed becomes an arbitrary but VALID one; a missing season/hour become 0.
    if (!is_real(_seed))   { _seed = 0; }
    if (!is_real(_season)) { _season = 0; }
    if (!is_real(_hour))   { _hour = 0; }
    var _rng = sho_rng(_seed);
    var _forms = sho_form_ids(), _liveries = sho_livery_ids();
    var _pats = sho_pattern_ids(), _fins = sho_fin_ids();

    var _fw = sho_biome_form_weights(_biome);
    var _fi = sho_pick_weighted(_fw, sho_rng_next(_rng));
    if (_fi < 0) return undefined;

    var _lw = array_create(array_length(_liveries));
    for (var _i = 0; _i < array_length(_liveries); _i++) {
        _lw[_i] = sho_livery_weight(_biome, _season, _hour, _i);
    }
    var _li = sho_pick_weighted(_lw, sho_rng_next(_rng));
    if (_li < 0) return undefined;

    // Pattern and fin set are not biome-locked: they are the axes that vary WITHIN a water, which
    // is what keeps a single fishing spot from producing the same picture all afternoon.
    var _pi = floor(sho_rng_next(_rng) * array_length(_pats)) mod array_length(_pats);
    var _ni = floor(sho_rng_next(_rng) * array_length(_fins)) mod array_length(_fins);

    var _sp = sho_species_make(_forms[_fi], _pats[_pi], _fins[_ni], _liveries[_li], undefined);

    // Length: typical size scaled by a value biased low, with a long upper tail. power(u, 2.4)
    // spends most of its range below the middle, so most fish are unremarkable and the big one is
    // an event.
    var _u = sho_rng_next(_rng);
    var _scale = 0.52 + power(_u, 2.4) * 1.28;
    var _len = max(1, round(_sp.typical * _scale));

    var _r = sho_rarity_of(_biome, _season, _hour, _fi, _li, _scale);
    return sho_catch_make(_sp, _len, _biome, _season, _hour, _r);
}

/// The tier, derived. See the header: nothing declares this.
///
/// Two independent contributions, because they mean different things to a player:
///   * SCARCITY - how unlikely this form and this palette were in this water at this time.
///   * SIZE     - how far past typical this individual is.
/// A common fish of exceptional size deserves a card that says so, and so does an ordinary
/// specimen of something that almost never surfaces here.
function sho_rarity_of(_biome, _season, _hour, _fi, _li, _scale) {
    var _fw = sho_biome_form_weights(_biome);
    var _fsum = 0;
    for (var _i = 0; _i < array_length(_fw); _i++) _fsum += max(0, _fw[_i]);
    var _fp = (_fsum > 0) ? (max(0, _fw[_fi]) / _fsum) : 1;

    var _lsum = 0;
    for (var _i = 0; _i < array_length(sho_livery_ids()); _i++) {
        _lsum += sho_livery_weight(_biome, _season, _hour, _i);
    }
    var _lp = (_lsum > 0) ? (sho_livery_weight(_biome, _season, _hour, _li) / _lsum) : 1;

    // The joint probability of drawing this form AND this palette here. Rarity climbs as it falls.
    var _p = max(0.000001, _fp * _lp);
    var _score = 0;
    if (_p < 0.070) _score += 1;
    if (_p < 0.028) _score += 1;
    if (_p < 0.010) _score += 1;
    if (_scale > 1.42) _score += 1;
    if (_scale > 1.66) _score += 1;
    return clamp(_score, 0, 4);
}

/// Everything a given water can produce, for the codex's "seen here" list and for sho_selftest's
/// reachability assertion.
///
/// ⛔ THAT ASSERTION IS THE ONE THAT MATTERS ABOUT THIS FILE. 110 hand-authored weights can very
/// easily contain a row that makes some form unreachable everywhere, or a season in which a biome
/// produces nothing at all - and neither shows up as an error, only as content a buyer paid for and
/// can never see. The suite walks all 5 biomes x 4 seasons x 4 bands and asserts every form and
/// every palette is reachable somewhere, and that no combination of place and time is empty.
function sho_water_forms_here(_biome) {
    var _w = sho_biome_form_weights(_biome), _ids = sho_form_ids(), _out = [];
    for (var _i = 0; _i < array_length(_w); _i++) if (_w[_i] > 0) array_push(_out, _ids[_i]);
    return _out;
}

function sho_water_liveries_here(_biome, _season, _hour) {
    var _ids = sho_livery_ids(), _out = [];
    for (var _i = 0; _i < array_length(_ids); _i++) {
        if (sho_livery_weight(_biome, _season, _hour, _i) > 0) array_push(_out, _ids[_i]);
    }
    return _out;
}
