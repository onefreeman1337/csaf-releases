/// ============================================================================================
/// SHOAL - sho_pattern: 10 patterns, clipped to the body IN GEOMETRY.
///
/// A pattern changes no outline (Motif_Corpus.md §0) - it is what turns 96 silhouettes into a
/// catalogue, and what a specimen card is actually showing. It is the identity at card size, where
/// the silhouette has already done its work.
///
/// -- ⛔ WHY THIS IS CLIPPED AND NOT MASKED -----------------------------------------------------
/// The obvious implementation is to draw the pattern over the whole rectangle and then mask it back
/// to the body - with a surface, a blend mode, or by painting the outside in the water colour. All
/// three are wrong here, and the third is wrong in the way that only shows up in a real game:
///
///   * A SURFACE per fish is a texture swap and an allocation per specimen, on a screen that may
///     hold a whole shoal. The wing has measured what per-object surfaces cost.
///   * A BLEND MODE leaks into the buyer's own draw event, which is the exact class of bug this
///     package's renderer note forbids - a defect three files from its cause, in their code.
///   * PAINTING THE OUTSIDE only works over a KNOWN, FLAT background. Put the fish over the
///     buyer's water shader, a parallax reef, another fish, or anything with alpha, and the
///     "mask" is a fish-shaped rectangle of the wrong colour. It looks perfect in our demo and
///     breaks the first time somebody drops it into a real scene.
///
/// So every element below is built to the body's own edges, by asking sho_form_span where the fish
/// starts and stops at each x. That is exact, allocation-free, background-agnostic, and it is the
/// whole reason sho_forms is an envelope pair rather than a pile of masses.
///
/// -- DETERMINISM -------------------------------------------------------------------------------
/// Spot placement is seeded from the species, never from random(). A fish whose spots move every
/// frame is the one bug a buyer notices immediately and cannot work around.
/// ============================================================================================

/// The 10 pattern ids, in the order Motif_Corpus.md §4 declares them.
function sho_pattern_ids() {
    return ["plain", "bands", "stripes", "spots", "ocelli",
            "marble", "net", "saddle", "mask", "gradient"];
}

function sho_pattern_name(_id) {
    switch (_id) {
        case "plain":    return "Plain";
        case "bands":    return "Banded";
        case "stripes":  return "Striped";
        case "spots":    return "Spotted";
        case "ocelli":   return "Ocellated";
        case "marble":   return "Marbled";
        case "net":      return "Reticulated";
        case "saddle":   return "Saddled";
        case "mask":     return "Masked";
        case "gradient": return "Counter-shaded";
    }
    return "?";
}

/// ============================================================================================
/// THE CLIPPING PRIMITIVES
///
/// Everything in this file is built from these four. Each is exact against the body's edges.
/// ============================================================================================

/// A VERTICAL band between two axial fractions, filling the body's full depth.
/// `_lean` shears the band, which is what turns `bands` into `marble` without a second primitive.
///
/// ⛔ THE SHEAR IS APPLIED BEFORE THE SPAN IS LOOKED UP, AND THAT ORDER IS THE WHOLE CORRECTNESS
/// ARGUMENT. The first version looked the body up at the UNSHEARED x and then emitted the point at
/// the SHEARED one - so on a tapering form the band's own corners sat outside the outline it was
/// supposed to be clipped to. The suite measured 26 such pairings, worst `ray/net` at 62 points.
/// Every rail here is now built at the x it is actually drawn at, and that x is clamped into the
/// body first, so a point outside the fish is not merely unlikely - it is unconstructable.
function sho_pat_band(_dst, _prof, _u0, _u1, _role, _lean) {
    var _s = _prof.spec;
    var _n = 10;
    var _a = array_create(_n + 1), _b = array_create(_n + 1);
    var _lo = _prof.x[0], _hi = _prof.x[_prof.n];
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        var _u = clamp(lerp(_u0, _u1, _t), 0, 1);
        var _sh = (is_undefined(_lean) ? 0 : _lean) * (_t - 0.5);
        // Top and bottom rails lean in opposite directions, which is what makes it a shear rather
        // than a translation - a translated band is just a band somewhere else.
        var _xa = clamp(lerp(_s.x0, _s.x1, _u) - _sh, _lo, _hi);
        var _xb = clamp(lerp(_s.x0, _s.x1, _u) + _sh, _lo, _hi);
        var _sa = sho_form_span(_prof, _xa);
        var _sb = sho_form_span(_prof, _xb);
        _a[_i] = [_xa, _sa[0]];
        _b[_i] = [_xb, _sb[1]];
    }
    array_push(_dst, sho_strip(_a, _b, _role));
    return _dst;
}

/// A HORIZONTAL stripe between two absolute y values, over the whole body.
///
/// ⛔ THIS IS THE ONE THAT NEEDS RUN-SPLITTING AND IT IS NOT OPTIONAL. A horizontal stripe crosses
/// a fish's outline wherever the body is shallower than the stripe - under a `hatchet`'s flat back,
/// at both ends of anything tapered - and emitting one strip across the whole length would draw
/// those gaps as a solid bar sticking out through the fish, above and below the outline. So the
/// body is walked, contiguous runs where the stripe is genuinely inside are collected, and each run
/// becomes its own strip. `spindle` yields one run; `sunfish` with a high stripe yields none, which
/// is correct and must not be forced to yield something.
function sho_pat_stripe(_dst, _prof, _y0, _y1, _role) {
    var _n = _prof.n;
    var _a = [], _b = [];
    for (var _i = 0; _i <= _n; _i++) {
        var _top = max(_y0, _prof.yt[_i]);
        var _bot = min(_y1, _prof.yb[_i]);
        // A 0.004 floor rather than > 0: a run one thousandth of a unit deep is not a stripe, it is
        // a sliver at the tip of the taper that renders as a stray dot.
        if (_bot - _top > 0.004) {
            array_push(_a, [_prof.x[_i], _top]);
            array_push(_b, [_prof.x[_i], _bot]);
        } else if (array_length(_a) >= 2) {
            array_push(_dst, sho_strip(_a, _b, _role));
            _a = []; _b = [];
        } else { _a = []; _b = []; }
    }
    if (array_length(_a) >= 2) array_push(_dst, sho_strip(_a, _b, _role));
    return _dst;
}

/// A WEDGE hugging one edge: from the body's own top (or bottom) edge, a fraction of the local
/// depth inward, between two axial fractions. This is how a saddle, a counter-shaded belly and a
/// dorsal blotch are all one primitive.
///
/// `_f0` is the fraction of local depth at the ends and `_f1` at the middle, so a saddle can be
/// deepest in its centre instead of being a rectangle with the corners cut off.
function sho_pat_wedge(_dst, _prof, _u0, _u1, _side, _f0, _f1, _role) {
    var _s = _prof.spec;
    var _n = 14;
    var _a = array_create(_n + 1), _bb = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n;
        // Clamped ONCE, and the clamped value is what is emitted - see the note on sho_pat_band.
        // Looking the body up at a clamped x and then drawing at the raw one is the same defect
        // wearing a different variable name, and it is easy to reintroduce here by accident.
        var _x = clamp(lerp(lerp(_s.x0, _s.x1, _u0), lerp(_s.x0, _s.x1, _u1), _t),
                       _prof.x[0], _prof.x[_prof.n]);
        var _sp = sho_form_span(_prof, _x);
        var _depth = _sp[1] - _sp[0];
        var _f = lerp(_f0, _f1, sin(_t * pi));
        if (_side < 0) { _a[_i] = [_x, _sp[0]]; _bb[_i] = [_x, _sp[0] + _depth * _f]; }
        else           { _a[_i] = [_x, _sp[1] - _depth * _f]; _bb[_i] = [_x, _sp[1]]; }
    }
    array_push(_dst, sho_strip(_a, _bb, _role));
    return _dst;
}

/// A spot, placed at an axial fraction and a depth fraction, kept ONLY if the whole circle fits
/// inside the body. Returns true if it was placed.
///
/// ⚠️ CONTAINMENT IS TESTED AT THREE x POSITIONS, not one. Testing only the centre lets a spot near
/// a steep taper hang out over the outline on the side nearest the tail - visible as a bump on the
/// silhouette, which is the one thing a pattern is not allowed to change.
function sho_pat_spot(_dst, _prof, _u, _v, _r, _role) {
    var _s = _prof.spec;
    var _x = lerp(_s.x0, _s.x1, _u);
    var _mid = sho_form_span(_prof, clamp(_x, _prof.x[0], _prof.x[_prof.n]));
    if (is_undefined(_mid)) return false;
    var _y = lerp(_mid[0], _mid[1], _v);
    for (var _k = -1; _k <= 1; _k++) {
        var _xx = _x + _k * _r;
        if (_xx < _prof.x[0] || _xx > _prof.x[_prof.n]) return false;
        var _sp = sho_form_span(_prof, _xx);
        if (is_undefined(_sp)) return false;
        if (_y - _r < _sp[0] || _y + _r > _sp[1]) return false;
    }
    array_push(_dst, sho_dot(_x, _y, _r, _role));
    return true;
}

/// The lateral line: the one feature every real fish has and the reason `plain` is not blank.
/// It follows the spine, which on `eel` is a wave.
function sho_pat_lateral(_dst, _prof, _role) {
    var _n = _prof.n;
    var _pts = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        // Slightly above the spine, as it sits on a real fish, and expressed as a fraction of local
        // depth so it stays in proportion on a hatchet and on an eel alike.
        var _d = _prof.yb[_i] - _prof.yt[_i];
        _pts[_i] = [_prof.x[_i], _prof.sp[_i] - _d * 0.09];
    }
    array_push(_dst, sho_taper_ribbon(_pts, 0.0035, 0.0075, _role));
    return _dst;
}

/// ============================================================================================
/// THE 10 PATTERNS
/// ============================================================================================

function sho_pattern_parts(_prof, _id, _seed, _dst) {
    var _rng = sho_rng(_seed + 7919);

    switch (_id) {

        /// No body pattern - only the lateral line every fish carries.
        case "plain": {
            sho_pat_lateral(_dst, _prof, SHO_R_MARK);
        } break;

        /// Vertical bars. The count varies with the fish's own length so a `disc` gets four and a
        /// `ribbon` gets nine, rather than every form getting the same number squashed or stretched.
        case "bands": {
            var _len = _prof.spec.x1 - _prof.spec.x0;
            var _c = clamp(round(_len * 11), 4, 10);
            for (var _i = 0; _i < _c; _i++) {
                var _u = (_i + 0.62) / (_c + 0.30);
                sho_pat_band(_dst, _prof, _u - 0.030, _u + 0.030, SHO_R_MARK, 0);
            }
        } break;

        /// Horizontal lines along the length, spaced through the deepest part of the body so a
        /// shallow form still shows two or three rather than one down the middle.
        case "stripes": {
            var _d = sho_form_depth(_prof);
            for (var _i = -2; _i <= 2; _i++) {
                if (_i == 0) continue;
                var _y = _i * _d * 0.30;
                sho_pat_stripe(_dst, _prof, _y - _d * 0.075, _y + _d * 0.075, SHO_R_MARK);
            }
            sho_pat_lateral(_dst, _prof, SHO_R_MARK);
        } break;

        /// Scattered round spots on a jittered grid. A pure random scatter clumps and reads as
        /// noise; a strict grid reads as a chequerboard. The jitter is 55% of a cell.
        case "spots": {
            var _d = sho_form_depth(_prof);
            var _r = clamp(_d * 0.115, 0.011, 0.030);
            for (var _i = 0; _i < 8; _i++) {
                for (var _k = 0; _k < 4; _k++) {
                    var _u = (_i + 0.5 + (sho_rng_next(_rng) - 0.5) * 0.55) / 8;
                    var _v = (_k + 0.5 + (sho_rng_next(_rng) - 0.5) * 0.55) / 4;
                    sho_pat_spot(_dst, _prof, _u, _v, _r, SHO_R_MARK);
                }
            }
        } break;

        /// Ringed eyespots: a large mark with a hole. Fewer and bigger than `spots`, or the two
        /// patterns are the same picture at card size.
        case "ocelli": {
            var _d = sho_form_depth(_prof);
            var _r = clamp(_d * 0.235, 0.020, 0.052);
            for (var _i = 0; _i < 4; _i++) {
                for (var _k = 0; _k < 2; _k++) {
                    var _u = (_i + 0.5 + (sho_rng_next(_rng) - 0.5) * 0.42) / 4;
                    var _v = (_k + 0.5 + (sho_rng_next(_rng) - 0.5) * 0.42) / 2;
                    if (sho_pat_spot(_dst, _prof, _u, _v, _r, SHO_R_MARK)) {
                        // The pupil is drawn in the BODY role, not the water colour - see the
                        // header: a hole painted in the background colour is a hole only over that
                        // background, and this one has to work over a reef.
                        sho_pat_spot(_dst, _prof, _u, _v, _r * 0.46, SHO_R_BODY);
                    }
                }
            }
        } break;

        /// Sheared, irregularly spaced bands: the same primitive as `bands` with a lean and a
        /// jittered width, which is what marbling is.
        case "marble": {
            for (var _i = 0; _i < 7; _i++) {
                var _u = (_i + 0.45 + (sho_rng_next(_rng) - 0.5) * 0.55) / 7;
                var _w = 0.026 + sho_rng_next(_rng) * 0.045;
                var _l = (sho_rng_next(_rng) - 0.5) * 0.16;
                sho_pat_band(_dst, _prof, _u - _w, _u + _w, SHO_R_MARK, _l);
            }
        } break;

        /// Reticulated: a lattice of thin bands and thin stripes. Both are clipped, so the mesh
        /// stops at the outline on all four sides rather than being trimmed to a rectangle.
        case "net": {
            var _d = sho_form_depth(_prof);
            for (var _i = 0; _i < 9; _i++) {
                var _u = (_i + 0.55) / 9.3;
                sho_pat_band(_dst, _prof, _u - 0.009, _u + 0.009, SHO_R_MARK, 0.05);
            }
            for (var _i = -2; _i <= 2; _i++) {
                var _y = _i * _d * 0.27;
                sho_pat_stripe(_dst, _prof, _y - _d * 0.022, _y + _d * 0.022, SHO_R_MARK);
            }
        } break;

        /// Blocks sitting on the back: dorsal saddles, deepest in their centres.
        case "saddle": {
            // ⚠️ 0.12/0.32 OF LOCAL DEPTH, NOT 0.16/0.46. A saddle is a BLOCK SITTING ON THE BACK;
            // at 46% of local depth it becomes a bar down the middle of the fish, and on the deep
            // forms - sunfish, disc, hatchet - four of them in a dark mark colour merged into one
            // muddy mass that read as damage rather than as markings. Measured on the store sheet;
            // no assertion could have seen it, because the geometry was inside the body the whole
            // time, which is all the clipping check asks.
            for (var _i = 0; _i < 4; _i++) {
                var _u = (_i + 0.55) / 4.4;
                sho_pat_wedge(_dst, _prof, _u - 0.068, _u + 0.068, -1, 0.12, 0.32, SHO_R_MARK);
            }
            sho_pat_lateral(_dst, _prof, SHO_R_MARK);
        } break;

        /// A band across the head, through the eye - the single most recognisable fish marking
        /// there is. Positioned from the form's OWN eye anchor, so it lands on the eye of an angler
        /// and the eye of an eel without either being special-cased.
        case "mask": {
            var _u = _prof.spec.eye[0];
            sho_pat_band(_dst, _prof, _u - 0.075, _u + 0.075, SHO_R_MARK, -0.05);
            sho_pat_lateral(_dst, _prof, SHO_R_MARK);
        } break;

        /// Counter-shading: dark back, pale belly, the way almost every open-water fish is actually
        /// coloured. Two wedges from opposite edges, meeting near the lateral line.
        case "gradient": {
            sho_pat_wedge(_dst, _prof, 0.02, 0.98, -1, 0.20, 0.38, SHO_R_MARK);
            sho_pat_wedge(_dst, _prof, 0.02, 0.94,  1, 0.26, 0.46, SHO_R_BELLY);
        } break;
    }
    return _dst;
}
