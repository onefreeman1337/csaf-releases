{
  "$GMScript": "v1",
  "%Name": "sho_pattern",
  "isCompatibility": false,
  "isDnD": false,
  "name": "sho_pattern",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}