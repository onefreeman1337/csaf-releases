{
  "$GMScript": "v1",
  "%Name": "sho_tackle",
  "isCompatibility": false,
  "isDnD": false,
  "name": "sho_tackle",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}