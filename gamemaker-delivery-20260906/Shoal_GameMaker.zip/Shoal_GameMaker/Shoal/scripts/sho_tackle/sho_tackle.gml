/// ============================================================================================
/// SHOAL - sho_tackle: the fight. A tension minigame, as PURE LOGIC.
///
/// ⛔ THERE IS NOT ONE ENGINE CALL IN THIS FILE. No draw, no input, no surface, no instance, no
/// room. It is a state machine you step with a delta and a boolean, and that is deliberate for two
/// reasons that both matter to a buyer:
///
///   1. THIS WING'S CONSTITUTION SAYS GML CANNOT BE UNIT-TESTED OUTSIDE THE ENGINE, and the honest
///      response is to make as much of the product as possible testable INSIDE it. Every rule below
///      is asserted by sho_selftest against exact numbers, headlessly, on a real build - which is
///      not true of anything that touches the GPU.
///   2. A BUYER'S INPUT IS NOT OURS TO ASSUME. Keyboard, mouse, gamepad, touch, a rhythm of taps, a
///      held button, an on-screen slider - a fishing minigame welded to keyboard_check() is one a
///      buyer has to unpick before they can use it. `sho_tackle_step` takes a boolean meaning "the
///      player is reeling" and knows nothing about where it came from.
///
/// -- THE FIGHT ---------------------------------------------------------------------------------
/// Reeling pulls the fish toward the boat and RAISES line tension. Not reeling lets tension fall,
/// and lets the fish run. Tension past the line's rating snaps it. The fish tires as it fights, and
/// a tired fish runs less - so the whole thing is a judgement about when to pull and when to wait,
/// which is what fishing actually is.
///
/// Three numbers make every species fight differently, and all three are DERIVED from the specimen
/// rather than declared: a big fish pulls harder, a slim fast form runs more often, a deep-bodied
/// one has more stamina. So a `pike` fights like a pike without anybody writing down that it should.
/// ============================================================================================

#macro SHO_FIGHT_RUNNING 0
#macro SHO_FIGHT_HELD    1
#macro SHO_FIGHT_LANDED  2
#macro SHO_FIGHT_SNAPPED 3
#macro SHO_FIGHT_THROWN  4

/// Line ratings, in the same arbitrary tension units the fight runs in. A buyer swaps these or adds
/// their own; nothing else in the package reads them.
function sho_line_rating(_id) {
    switch (_id) {
        case "hair":   return 0.55;    // cheap, snaps under any real fish
        case "gut":    return 0.80;
        case "braid":  return 1.00;    // the reference
        case "wire":   return 1.30;
        case "silk":   return 1.60;    // the endgame line
    }
    return 1.00;
}

function sho_line_ids() { return ["hair", "gut", "braid", "wire", "silk"]; }

/// Start a fight against a catch.
///
///   distance  1 = at the limit of the cast, 0 = at the boat. Reeling drives this down.
///   tension   0 = slack, 1 = at the line's rating. Past `rating` the line parts.
///   stamina   1 = fresh, 0 = beaten. Falls while the fish fights.
///   slack     how long the line has been slack; a fish throws the hook if this runs on.
function sho_fight_begin(_catch, _line) {
    // Refuse an unusable catch with undefined; sho_fight_over(undefined) then reads true, so a
    // caller's Step-event loop terminates instead of spinning on a fight that never began.
    if (is_undefined(_catch) || !is_struct(_catch) || !variable_struct_exists(_catch, "sp")
        || !sho_species_is(_catch.sp)) return undefined;
    var _sp = _catch.sp;
    var _spec = _sp.prof.spec;

    // POWER: how hard it pulls. Mass is the honest driver - it is already derived from length,
    // fineness and girth - normalised against a 1kg fish so the numbers stay readable.
    var _power = clamp(0.42 + power(_catch.mass_g / 1000, 0.42) * 0.30, 0.42, 1.85);

    // FLIGHTINESS: how often it bolts. A long slim body is built for acceleration; a deep one is
    // not. Fineness is depth over length, so its INVERSE is the right sense.
    var _fine = (sho_form_depth(_sp.prof) * 2) / max(0.001, _spec.x1 - _spec.x0);
    var _flighty = clamp(0.30 + (0.42 / max(0.08, _fine)) * 0.16, 0.30, 0.95);

    // STAMINA: bulk carries it. A deep-bodied fish is a heavier, slower, longer fight.
    var _stam = clamp(0.55 + _fine * 0.75 + power(_catch.mass_g / 1000, 0.30) * 0.12, 0.55, 1.90);

    return {
        catch_: _catch,
        rating: sho_line_rating(_line), line: _line,
        power: _power, flighty: _flighty, stamina_max: _stam,
        distance: 1.0, tension: 0.18, stamina: _stam, slack: 0,
        state: SHO_FIGHT_HELD, running: false, run_left: 0,
        elapsed: 0, peak_tension: 0.18, rng: sho_rng(_catch.sp.seed + 104729)
    };
}

/// Advance the fight by `_dt` seconds. `_reeling` is true while the player is pulling.
///
/// Returns the fight, mutated. Read `.state` for the outcome.
///
/// ⚠️ EVERY RATE BELOW IS PER SECOND AND IS MULTIPLIED BY _dt. A minigame written per-FRAME behaves
/// differently at 30, 60 and 144 fps, which a buyer discovers on a machine we do not have.
function sho_fight_step(_f, _dt, _reeling) {
    if (is_undefined(_f) || !is_struct(_f) || !variable_struct_exists(_f, "state")) return _f;
    if (!is_real(_dt)) return _f;
    if (_f.state != SHO_FIGHT_HELD && _f.state != SHO_FIGHT_RUNNING) return _f;
    _dt = clamp(_dt, 0, 0.25);         // a frame hitch must not teleport the fight
    _f.elapsed += _dt;

    // -- does it bolt? Only while it has something left, and never twice at once.
    if (_f.run_left <= 0) {
        var _chance = _f.flighty * 0.55 * (_f.stamina / _f.stamina_max) * _dt;
        if (sho_rng_next(_f.rng) < _chance) {
            _f.run_left = 0.45 + sho_rng_next(_f.rng) * 0.85;
            _f.state = SHO_FIGHT_RUNNING;
        }
    } else {
        _f.run_left -= _dt;
        if (_f.run_left <= 0) { _f.run_left = 0; _f.state = SHO_FIGHT_HELD; }
    }

    var _running = (_f.run_left > 0);

    // -- tension. Reeling adds; a run adds much more; slack line bleeds it away.
    var _d = 0;
    if (_reeling) _d += 0.62 * _f.power;
    if (_running) _d += 0.95 * _f.power * (0.45 + 0.55 * (_f.stamina / _f.stamina_max));
    if (!_reeling && !_running) _d -= 0.80;
    _f.tension = max(0, _f.tension + _d * _dt);
    _f.peak_tension = max(_f.peak_tension, _f.tension);

    // -- distance. Reeling gains line; a run takes it back. A run against a slack rod takes MORE,
    //    which is what makes "just let it run" a real cost rather than a free option.
    var _move = 0;
    if (_reeling) _move -= 0.30 * (1.25 - 0.45 * (_f.tension / max(0.2, _f.rating)));
    if (_running) _move += 0.34 * _f.power * (_reeling ? 0.55 : 1.0);
    _f.distance = clamp(_f.distance + _move * _dt, 0, 1.35);

    // -- stamina. It tires from its own effort and from being held against.
    var _drain = (_running ? 0.30 : 0.045) + (_reeling ? 0.16 : 0) * (_f.tension / max(0.2, _f.rating));
    _f.stamina = max(0, _f.stamina - _drain * _dt);
    // A beaten fish stops bolting. Without this the endgame never arrives and the fight is a
    // coin-flip against the line rather than a contest the player can win.
    if (_f.stamina <= 0.12) { _f.run_left = 0; _f.state = SHO_FIGHT_HELD; }

    // -- slack. A hook only stays in under load.
    if (_f.tension < 0.08) _f.slack += _dt; else _f.slack = 0;

    // -- outcomes, checked in severity order.
    if (_f.tension > _f.rating) { _f.state = SHO_FIGHT_SNAPPED; return _f; }
    if (_f.slack > 2.4)         { _f.state = SHO_FIGHT_THROWN;  return _f; }
    if (_f.distance <= 0)       { _f.state = SHO_FIGHT_LANDED;  return _f; }
    return _f;
}

/// How close to parting the line is, 0..1. This is the number a gauge should read, and it is
/// exposed rather than left to a caller to compute so every UI in every buyer's game agrees.
function sho_fight_strain(_f) {
    if (is_undefined(_f) || !is_struct(_f) || !variable_struct_exists(_f, "tension")) return 0;
    return clamp(_f.tension / max(0.05, _f.rating), 0, 1);
}

/// Is the fight over?
function sho_fight_over(_f) {
    // ⭐ TRUE for an unusable fight ON PURPOSE. The Readme's own Step-event snippet loops
    // `while (!sho_fight_over(f))`, so returning false here would hang a buyer's game forever on a
    // fight that never began — strictly worse than the throw this replaces.
    if (is_undefined(_f) || !is_struct(_f) || !variable_struct_exists(_f, "state")) return true;
    return (_f.state == SHO_FIGHT_LANDED || _f.state == SHO_FIGHT_SNAPPED
         || _f.state == SHO_FIGHT_THROWN);
}

function sho_fight_state_name(_s) {
    switch (_s) {
        case SHO_FIGHT_RUNNING: return "Running";
        case SHO_FIGHT_HELD:    return "Held";
        case SHO_FIGHT_LANDED:  return "Landed";
        case SHO_FIGHT_SNAPPED: return "Line parted";
        case SHO_FIGHT_THROWN:  return "Threw the hook";
    }
    return "?";
}

/// The line a specimen NEEDS, as advice for a buyer's tackle shop and for the codex.
///
/// Derived by the same arithmetic the fight uses, so it cannot drift from what actually happens -
/// which a hand-written "recommended line" table absolutely would.
function sho_fight_line_needed(_catch) {
    var _f = sho_fight_begin(_catch, "braid");
    if (is_undefined(_f)) return sho_line_ids()[0];   // the lightest line, for an unusable catch
    // A steady reel is the worst case for tension: peak load is reeling plus a run.
    var _peak = 0.62 * _f.power + 0.95 * _f.power;
    var _ids = sho_line_ids();
    for (var _i = 0; _i < array_length(_ids); _i++) {
        if (sho_line_rating(_ids[_i]) >= _peak * 0.60) return _ids[_i];
    }
    return _ids[array_length(_ids) - 1];
}
