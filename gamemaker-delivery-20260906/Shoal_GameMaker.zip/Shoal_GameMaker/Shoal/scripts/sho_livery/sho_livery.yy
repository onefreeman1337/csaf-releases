{
  "$GMScript": "v1",
  "%Name": "sho_livery",
  "isCompatibility": false,
  "isDnD": false,
  "name": "sho_livery",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}