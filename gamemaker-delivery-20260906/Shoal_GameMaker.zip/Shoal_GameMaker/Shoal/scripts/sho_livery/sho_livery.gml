/// ============================================================================================
/// SHOAL - sho_livery: 10 palettes, and the ink every specimen is drawn with.
///
/// A palette is FIVE colours derived from three numbers, not five hand-picked hex values. Every one
/// is computed in Oklch (sho_palette), so "the mark is two steps darker than the body" means the
/// same amount of darker on a volcanic red as on an abyssal blue - which hand-picked hex cannot
/// promise and is the whole reason this package does colour the hard way.
///
/// -- WHY FIVE ROLES AND NOT A TINT -------------------------------------------------------------
/// A fish is not one colour with a filter on it. It has a back, a belly, fins that are usually more
/// translucent and less saturated than the body, a mark colour that has to read against the body at
/// card size, and an eye that has to read against everything. Tinting one base colour gives all
/// five the same chroma and the fish reads as a decal.
///
/// -- ⛔ THE CONTRAST FLOOR IS A GATE, NOT A PREFERENCE ------------------------------------------
/// `mark` against `body` is the pair that carries every pattern in the package. If those two land
/// close in lightness, all ten patterns vanish at once and the catalogue collapses to 96 blank
/// shapes - silently, because every mechanical check still passes and the fish is still drawn.
/// sho_selftest asserts a minimum lightness separation on all ten, and the numbers below were
/// chosen against that assertion rather than by eye.
/// ============================================================================================

/// The 10 palette ids, in the order Motif_Corpus.md §5 declares them.
function sho_livery_ids() {
    return ["riverine", "reef", "abyssal", "estuary", "alpine",
            "kelp", "brackish", "ice", "volcanic", "spawning"];
}

function sho_livery_name(_id) {
    switch (_id) {
        case "riverine": return "Riverine";
        case "reef":     return "Reef";
        case "abyssal":  return "Abyssal";
        case "estuary":  return "Estuary";
        case "alpine":   return "Alpine";
        case "kelp":     return "Kelp";
        case "brackish": return "Brackish";
        case "ice":      return "Ice";
        case "volcanic": return "Volcanic";
        case "spawning": return "Spawning";
    }
    return "?";
}

/// The three numbers a palette is: base hue, base lightness, base chroma. Everything else is
/// derived, so a palette is tuned by moving three sliders rather than by re-picking five colours
/// and hoping they still relate to each other.
///
///   hue   degrees, Oklch
///   L     lightness of the BODY
///   C     chroma of the body
///   dh    how far the MARK hue rotates from the body hue - the second axis of separation, so a
///         pattern is distinguishable by hue as well as by lightness on palettes where the
///         lightness range is narrow.
///   dL    how much darker (negative) or lighter the mark is than the body.
function sho_livery_spec(_id) {
    switch (_id) {
        /// Fresh water over gravel: olive-brown back, cream belly, muted throughout.
        case "riverine": return { hue:  92, L: 0.470, C: 0.070, dh:  -16, dL: -0.230 };
        /// Tropical reef: the loudest palette in the set, and the only one whose mark goes LIGHTER
        /// than the body, because reef fish mark in white and yellow rather than in shadow.
        case "reef":     return { hue:  38, L: 0.605, C: 0.165, dh:   26, dL:  0.185 };
        /// Deep water: near-black body with a cold blue cast, and a mark that can only be lighter -
        /// there is nothing darker available at this lightness.
        case "abyssal":  return { hue: 258, L: 0.285, C: 0.062, dh:   14, dL:  0.230 };
        /// Silt and tidal mud: warm grey-brown, low chroma, a working-fish palette.
        case "estuary":  return { hue:  62, L: 0.505, C: 0.055, dh:  -22, dL: -0.215 };
        /// Cold clear lakes: steel blue with a bright silver flank.
        case "alpine":   return { hue: 232, L: 0.560, C: 0.070, dh:   18, dL: -0.245 };
        /// Weed beds: deep green, dark marks, the best camouflage palette in the set.
        case "kelp":     return { hue: 148, L: 0.410, C: 0.098, dh:  -26, dL: -0.190 };
        /// Where fresh meets salt: a dull bronze-green that belongs to neither.
        case "brackish": return { hue: 108, L: 0.445, C: 0.048, dh:   30, dL: -0.190 };
        /// Ice melt: very pale, very low chroma, marks in cold grey.
        case "ice":      return { hue: 214, L: 0.775, C: 0.038, dh:  -12, dL: -0.290 };
        /// Volcanic vents: near-black with a hot red mark. The widest lightness range in the set.
        case "volcanic": return { hue:  28, L: 0.335, C: 0.115, dh:    8, dL:  0.265 };
        /// Breeding livery: the high-chroma one, worn only in season. sho_water hands it out during
        /// a spawning run and at no other time, which is what makes it feel earned.
        case "spawning": return { hue: 358, L: 0.520, C: 0.190, dh:  -34, dL:  0.215 };
    }
    return undefined;
}

/// Build the five-colour ink for a palette.
///
/// `_shade` lets a caller darken the whole fish coherently - a specimen seen deep, or behind
/// another. It moves lightness only, so hue relationships and the contrast floor survive it.
function sho_livery_ink(_id, _shade) {
    var _s = sho_livery_spec(_id);
    if (is_undefined(_s)) _s = sho_livery_spec("riverine");
    var _k = is_undefined(_shade) ? 0 : clamp(_shade, -0.35, 0.35);

    var _L = clamp(_s.L + _k, 0.06, 0.94);
    // The belly is lighter and markedly less chromatic: counter-shading is a lightness effect in
    // nature, and pushing chroma with it is what makes a tinted fish look like plastic.
    var _bL = clamp(_L + 0.215, 0.10, 0.96);
    // Fins are the body colour pulled toward the belly and desaturated - they are thin tissue.
    var _fL = clamp(_L + 0.085, 0.08, 0.95);
    var _mL = clamp(_L + _s.dL, 0.05, 0.96);

    return {
        body:  sho_oklch(_L,  _s.C,          _s.hue),
        belly: sho_oklch(_bL, _s.C * 0.34,   _s.hue + 6),
        fin:   sho_oklch(_fL, _s.C * 0.58,   _s.hue + _s.dh * 0.35),
        mark:  sho_oklch(_mL, _s.C * 0.88,   _s.hue + _s.dh),
        // The eye is near-black on every palette on purpose. It is the one feature that must read
        // at 20px on all ten, and tying it to the palette hue loses it on `abyssal` and `volcanic`.
        eye:   sho_oklch(0.115, 0.020, _s.hue),
        edge:  sho_oklch(clamp(_L - 0.185, 0.04, 0.9), _s.C * 0.7, _s.hue)
    };
}

/// The lightness a palette assigns to a role, WITHOUT going through a colour.
///
/// sho_selftest's contrast assertion needs the perceptual lightness of body and mark, and reading
/// it back out of a packed GameMaker colour would measure sRGB bytes rather than Oklab lightness -
/// i.e. it would assert something other than what the palette promises. So the numbers are exposed
/// directly, from the same arithmetic sho_livery_ink uses.
///
/// ⚠️ THIS DUPLICATES THREE LINES OF sho_livery_ink AND THAT IS A REAL RISK. If the derivation
/// above changes and this does not, the suite asserts a contrast the product no longer has. The
/// suite therefore ALSO checks the two agree in direction on every palette, which is the cheap half
/// of the guard; the expensive half is remembering, and it is flagged here for that reason.
function sho_livery_role_L(_id, _role, _shade) {
    var _s = sho_livery_spec(_id);
    if (is_undefined(_s)) return 0;
    var _L = clamp(_s.L + (is_undefined(_shade) ? 0 : _shade), 0.06, 0.94);
    switch (_role) {
        case SHO_R_BODY:  return _L;
        case SHO_R_BELLY: return clamp(_L + 0.215, 0.10, 0.96);
        case SHO_R_FIN:   return clamp(_L + 0.085, 0.08, 0.95);
        case SHO_R_MARK:  return clamp(_L + _s.dL, 0.05, 0.96);
        case SHO_R_EYE:   return 0.115;
    }
    return clamp(_L - 0.185, 0.04, 0.9);
}

/// The water colour a biome is drawn over. Not a palette role - it belongs to the SCENE, not to any
/// fish - but it is derived from the same Oklch maths so a specimen and its water are relatable.
function sho_water_colour(_biome, _depth) {
    var _d = clamp(is_undefined(_depth) ? 0.5 : _depth, 0, 1);
    switch (_biome) {
        case "river":   return sho_oklch(lerp(0.400, 0.185, _d), 0.055, 196);
        case "reef":    return sho_oklch(lerp(0.585, 0.255, _d), 0.090, 212);
        case "deep":    return sho_oklch(lerp(0.215, 0.070, _d), 0.048, 262);
        case "estuary": return sho_oklch(lerp(0.370, 0.160, _d), 0.045,  96);
        case "lake":    return sho_oklch(lerp(0.455, 0.190, _d), 0.062, 232);
    }
    return sho_oklch(lerp(0.400, 0.180, _d), 0.050, 214);
}
