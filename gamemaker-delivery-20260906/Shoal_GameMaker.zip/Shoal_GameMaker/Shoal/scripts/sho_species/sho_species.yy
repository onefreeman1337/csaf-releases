{
  "$GMScript": "v1",
  "%Name": "sho_species",
  "isCompatibility": false,
  "isDnD": false,
  "name": "sho_species",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}