/// ============================================================================================
/// SHOAL - sho_species: the composition. A seed becomes a fish.
///
///     species = base form (12) x pattern (10) x fin set (8) x palette (10)
///
/// ⚠️ 12 x 10 x 8 x 10 = 9,600, and that is a COMBINATION COUNT, not 9,600 drawings. It is stated
/// that way here, in the product's own source, so the listing copy has no room to imply otherwise:
/// the moat is the 40 authored components and the 96 silhouettes they make, and a buyer who counts
/// them will find exactly what the arithmetic says.
///
/// -- A SPECIES IS ALSO A NAME ------------------------------------------------------------------
/// A catch that reads "spindle/bands/sail/riverine" is a data structure. A catch that reads
/// "Banded Riverine Dace - Leuciscus fasciatus" is a fish. The word corpus below is authored, not
/// templated from the component ids: 36 common nouns, 30 epithets, 12 genera and 10 specific names,
/// so a name reads like a field guide rather than like string concatenation.
///
/// -- CACHING -----------------------------------------------------------------------------------
/// A profile is 4 arrays of 57 points and it depends ONLY on the form id, so there are exactly 12
/// of them in the whole product. They are built once and shared. Building one per fish per frame
/// would allocate ~2,700 arrays a frame on a screen holding a shoal of twenty.
/// ============================================================================================

/// The shared profile cache. Namespaced to the product, because GML's global namespace is flat and
/// a collision in a buyer's project is a support ticket that cannot be debugged remotely.
function sho_profile(_form) {
    if (!variable_global_exists("sho_profile_cache")) global.sho_profile_cache = {};
    if (!variable_struct_exists(global.sho_profile_cache, _form)) {
        variable_struct_set(global.sho_profile_cache, _form, sho_form_profile(_form));
    }
    return variable_struct_get(global.sho_profile_cache, _form);
}

/// Drop the cache. A buyer who edits sho_forms at run time (or hot-reloads) needs this; nothing in
/// the package calls it.
function sho_profile_flush() {
    global.sho_profile_cache = {};
}

/// ============================================================================================
/// THE NAME CORPUS
/// ============================================================================================

/// Three common nouns per form: the same body plan under three names a player might meet. Picked
/// so that no two forms share a noun and every noun is a plausible fish.
function sho_form_nouns(_id) {
    switch (_id) {
        case "spindle":  return ["Dace", "Roach", "Shiner"];
        case "torpedo":  return ["Runner", "Bonito", "Cobia"];
        case "disc":     return ["Bream", "Rudd", "Pompano"];
        case "sunfish":  return ["Moonfish", "Opah", "Louvar"];
        case "eel":      return ["Eel", "Conger", "Sandsnake"];
        case "ribbon":   return ["Oarfish", "Cutlass", "Bandfish"];
        case "flathead":  return ["Flathead", "Sculpin", "Goby"];
        case "hatchet":  return ["Hatchetfish", "Keelbelly", "Silverside"];
        case "angler":   return ["Angler", "Frogmouth", "Goosefish"];
        case "ray":      return ["Skate", "Stingray", "Mantlet"];
        case "fan":      return ["Sailfin", "Fanfish", "Batfish"];
        case "pike":     return ["Pike", "Gar", "Needlenose"];
    }
    return ["Fish"];
}

/// Three adjectives per palette. These carry the colour into the name, which is how a real field
/// guide works - and it means a player can tell two catches apart by name alone.
function sho_livery_epithets(_id) {
    switch (_id) {
        case "riverine": return ["Olive", "Gravel", "Willow"];
        case "reef":     return ["Coral", "Sunflank", "Marigold"];
        case "abyssal":  return ["Midnight", "Lantern", "Trench"];
        case "estuary":  return ["Silt", "Tidewrack", "Amber"];
        case "alpine":   return ["Snowmelt", "Steel", "Tarn"];
        case "kelp":     return ["Kelp", "Weedy", "Verdant"];
        case "brackish": return ["Bronze", "Saltmarsh", "Dun"];
        case "ice":      return ["Frost", "Pale", "Glacier"];
        case "volcanic": return ["Ember", "Cinder", "Vent"];
        case "spawning": return ["Ruddy", "Nuptial", "Rose"];
    }
    return ["Common"];
}

/// A genus per form and a specific name per pattern, so the binomial says something true about the
/// fish rather than being decoration: two catches sharing a genus really do share a body plan.
function sho_form_genus(_id) {
    switch (_id) {
        case "spindle":  return "Leuciscus";
        case "torpedo":  return "Elagatis";
        case "disc":     return "Abramis";
        case "sunfish":  return "Mola";
        case "eel":      return "Anguilla";
        case "ribbon":   return "Trachipterus";
        case "flathead": return "Platycephalus";
        case "hatchet":  return "Argyropelecus";
        case "angler":   return "Lophius";
        case "ray":      return "Raja";
        case "fan":      return "Pterophyllum";
        case "pike":     return "Esox";
    }
    return "Piscis";
}

function sho_pattern_epithet(_id) {
    switch (_id) {
        case "plain":    return "vulgaris";
        case "bands":    return "fasciatus";
        case "stripes":  return "lineatus";
        case "spots":    return "punctatus";
        case "ocelli":   return "ocellatus";
        case "marble":   return "marmoratus";
        case "net":      return "reticulatus";
        case "saddle":   return "ephippium";
        case "mask":     return "personatus";
        case "gradient": return "argenteus";
    }
    return "incertus";
}

/// ============================================================================================
/// COMPOSITION
/// ============================================================================================

/// Build a species from four explicit components. `_seed` drives only the things that must vary
/// WITHIN a species - spot placement, the choice among the three nouns, the individual's size - and
/// never the components themselves.
///
/// ⛔ THE SEED IS DERIVED FROM THE COMPONENTS WHEN NOT GIVEN, so the same four components always
/// yield the same fish. A codex that showed a different individual every time it opened would make
/// the collection meaningless, and it is the exact determinism failure this package's geometry
/// layer already records at the rng level.
function sho_species_make(_form, _pattern, _fin, _livery, _seed) {
    // Substitute the corpus's first component for anything unusable, so a caller with one bad id
    // gets a real fish rather than a crash. Refusing entirely would give every renderer a null.
    if (!sho_form_is(_form))                     { _form    = sho_form_ids()[0]; }
    if (is_undefined(_pattern) || !is_string(_pattern)) { _pattern = sho_pattern_ids()[0]; }
    if (is_undefined(_fin)     || !is_string(_fin))     { _fin     = sho_fin_ids()[0]; }
    if (is_undefined(_livery)  || !is_string(_livery))  { _livery  = sho_livery_ids()[0]; }
    var _code = _form + "/" + _pattern + "/" + _fin + "/" + _livery;
    var _s = is_undefined(_seed) ? sho_hash32(_code) : _seed;
    var _rng = sho_rng(_s);

    var _nouns = sho_form_nouns(_form);
    var _epis  = sho_livery_epithets(_livery);
    var _noun = _nouns[floor(sho_rng_next(_rng) * array_length(_nouns)) % array_length(_nouns)];
    var _epi  = _epis[floor(sho_rng_next(_rng) * array_length(_epis)) % array_length(_epis)];

    var _prof = sho_profile(_form);

    return {
        form: _form, pattern: _pattern, fin: _fin, livery: _livery,
        seed: _s, code: _code, prof: _prof,
        ink: sho_livery_ink(_livery, 0),
        name: sho_pattern_name(_pattern) + " " + _epi + " " + _noun,
        latin: sho_form_genus(_form) + " " + sho_pattern_epithet(_pattern),
        // Typical length in centimetres for the species, from the form's own proportions: a ribbon
        // is long, a disc is not. The individual's own size is rolled at catch time by sho_water,
        // against this figure.
        typical: sho_form_typical_cm(_form)
    };
}

/// Every species the four component lists can make, chosen by index. Used by the codex, by the
/// store bake and by sho_selftest, all of which need to walk the catalogue rather than sample it.
function sho_species_at(_fi, _pi, _ni, _li) {
    var _f = sho_form_ids(), _p = sho_pattern_ids(), _n = sho_fin_ids(), _l = sho_livery_ids();
    // ⛔ GML's `mod` KEEPS THE SIGN, so a negative index reaches the array as a negative and throws
    // "Variable Index [-1] out of range". A caller deriving an index from a delta produces exactly
    // that. Normalise into range instead: wrapping is what `mod` was already doing for positives.
    _fi = is_real(_fi) ? ((floor(_fi) % array_length(_f)) + array_length(_f)) % array_length(_f) : 0;
    _pi = is_real(_pi) ? ((floor(_pi) % array_length(_p)) + array_length(_p)) % array_length(_p) : 0;
    _ni = is_real(_ni) ? ((floor(_ni) % array_length(_n)) + array_length(_n)) % array_length(_n) : 0;
    _li = is_real(_li) ? ((floor(_li) % array_length(_l)) + array_length(_l)) % array_length(_l) : 0;
    return sho_species_make(
        _f[_fi mod array_length(_f)], _p[_pi mod array_length(_p)],
        _n[_ni mod array_length(_n)], _l[_li mod array_length(_l)], undefined);
}

/// A species from a single seed. The four components are pulled from separate BYTE RANGES of the
/// hash rather than from four successive rng draws, so nearby seeds do not produce nearby fish.
function sho_species_from_seed(_seed) {
    var _h = sho_hash32(string(_seed) + "|shoal");
    var _f = sho_form_ids(), _p = sho_pattern_ids(), _n = sho_fin_ids(), _l = sho_livery_ids();
    return sho_species_make(
        _f[(_h        ) mod array_length(_f)],
        _p[(_h >>  7  ) mod array_length(_p)],
        _n[(_h >> 14  ) mod array_length(_n)],
        _l[(_h >> 21  ) mod array_length(_l)],
        _h);
}


/// ============================================================================================
/// REFUSE, NEVER THROW — the package's own convention, applied at every public entry point.
/// ============================================================================================
/// `sho_form_profile` has always returned `undefined` for an unknown form, so REFUSING is this
/// package's documented idiom. What it did not do was CHECK that refusal before dereferencing it,
/// so an unknown id travelled one function further and threw `<unknown_object>.spec`.
///
/// ⭐ THE LIKELIEST INTEGRATOR MISTAKE IN THIS PACKAGE IS AN INDEX WHERE AN ID BELONGS, and it is
/// the Readme's own fault for putting both conventions two lines apart: `sho_species_at(fi,pi,ni,li)`
/// takes INDICES and looks them up, while `sho_mass_g(form, len)` takes the ID ITSELF. Passing 0
/// to the second used to throw. MEASURED 2026-09-06: this was the first crash an adversarial pass
/// found, and it was also the first mistake the fresh-install harness made unprompted, which is
/// about as direct a piece of evidence as a package gets that a buyer will make it too.
function sho_species_is(_sp) {
    return !is_undefined(_sp) && is_struct(_sp)
        && variable_struct_exists(_sp, "prof") && is_struct(_sp.prof)
        && variable_struct_exists(_sp, "form") && variable_struct_exists(_sp, "fin");
}

/// A form id is usable only if the corpus actually has a spec for it.
function sho_form_is(_id) {
    return is_string(_id) && !is_undefined(sho_form_spec(_id));
}

/// The number of distinct species the corpus can produce. Stated as the multiplication so the
/// figure carries its own arithmetic wherever it is printed.
function sho_species_count() {
    return array_length(sho_form_ids()) * array_length(sho_pattern_ids())
         * array_length(sho_fin_ids())  * array_length(sho_livery_ids());
}

/// The number of distinct SILHOUETTES - the figure that actually bounds legibility, and the one
/// Motif_Corpus.md §0 says the copy must not blur into the count above.
function sho_silhouette_count() {
    return array_length(sho_form_ids()) * array_length(sho_fin_ids());
}

/// Typical adult length, in centimetres, per body form.
function sho_form_typical_cm(_id) {
    switch (_id) {
        case "spindle":  return 26;
        case "torpedo":  return 62;
        case "disc":     return 30;
        case "sunfish":  return 95;
        case "eel":      return 78;
        case "ribbon":   return 120;
        case "flathead": return 38;
        case "hatchet":  return 11;
        case "angler":   return 48;
        case "ray":      return 70;
        case "fan":      return 18;
        case "pike":     return 84;
    }
    return 30;
}

/// Mass from length, by the standard fisheries cube law W = a * L^b with b = 3.
///
/// `a` varies with body shape and that is the point: a hatchet and a tuna of the same length are
/// nowhere near the same weight, and a record board that ranked them together would be nonsense.
///
/// ⛔ THE THIRD TERM IS GIRTH AND IT IS THE ONE AN OBVIOUS IMPLEMENTATION OMITS. The first version
/// derived `a` from the form's side-view DEPTH alone, and the self-test caught it immediately: a
/// 40cm hatchetfish came out heavier than a 40cm tuna. A hatchet is deep AND paper-thin, so depth
/// in a side view says nothing at all about mass - the drawing simply does not contain the missing
/// dimension. `girth` is that dimension, authored per form in sho_forms.
///
/// Volume goes as length x depth x width, so the coefficient scales with fineness AND girth. Both
/// are normalised against `spindle`, the corpus's own reference body.
function sho_mass_g(_form, _len_cm) {
    // Refuse an unknown form and a non-numeric length rather than throwing (see sho_species_is).
    if (!sho_form_is(_form)) return 0;
    if (!is_real(_len_cm)) return 0;
    var _prof = sho_profile(_form);
    var _spec = _prof.spec;
    var _len_u = _spec.x1 - _spec.x0;
    var _depth = sho_form_depth(_prof) * 2;
    // Fineness: depth as a fraction of length. A cube-law coefficient around 0.010 is typical for a
    // fusiform fish; scaling by fineness and girth against spindle's own ratios keeps every form
    // sane without a second table of hand-tuned numbers.
    var _fine = _depth / max(0.001, _len_u);
    return 0.0105 * (_fine / 0.42) * (_spec.girth / 0.85) * power(max(1, _len_cm), 3);
}
