/// ============================================================================================
/// SHOAL - sho_card: the specimen card, and the small UI layer the package draws itself with.
///
/// EVERY CATCH PRODUCES A CARD. That is the product's second promise after the fish themselves: a
/// player who lands something gets an artefact, not a toast that says "+1 Trout". The card carries
/// the specimen drawn at size, its name and binomial, its measurements, where and when it was
/// taken, and a frame whose ornament is generated from the catch's own rarity - so a legendary
/// looks like a legendary before a single word is read.
///
/// -- ⛔ NO STOCK CHROME, ANYWHERE -------------------------------------------------------------
/// Every frame, rule, plate, corner and tick below is drawn from geometry by this file. This
/// package contains no windowskin, no nine-slice, no border sprite and no font resource beyond the
/// two open-licensed faces named in sho_render. The wing's constitution is explicit that a product
/// which looks like the engine it was made in is not finished, and a card is the single most
/// visible surface this product has.
///
/// -- THE CARD IS SIZED FROM ITS BOX, NEVER FROM CONSTANTS --------------------------------------
/// Every measurement below is a fraction of the card's own width or height. The wing has measured
/// what the alternative costs: a panel sized by choosing pixel numbers renders correctly at the one
/// size it was authored at and clips at every other, and the defect is invisible to an extent check
/// because the extent check is looking at the sheet, not at the panel. Draw it at 200px or at 900px
/// and it composes.
/// ============================================================================================

/// ============================================================================================
/// THE UI PALETTE
///
/// Six colours, all Oklch, all derived from one hue so the chrome reads as one object. Deep and
/// cold on purpose: the card is a specimen tray seen under water light, and it has to sit behind
/// ten fish palettes without arguing with any of them.
/// ============================================================================================

function sho_ui_colour(_name) {
    switch (_name) {
        case "page":   return sho_oklch(0.150, 0.016, 236);   // the sheet behind everything
        case "plate":  return sho_oklch(0.215, 0.022, 236);   // a raised panel
        case "well":   return sho_oklch(0.115, 0.018, 240);   // a recess: where a specimen sits
        case "rule":   return sho_oklch(0.360, 0.030, 232);   // hairlines and frames
        case "ink":    return sho_oklch(0.900, 0.014, 226);   // primary text
        case "ink2":   return sho_oklch(0.640, 0.020, 228);   // secondary text
        case "accent": return sho_oklch(0.720, 0.105, 190);   // figures worth reading
    }
    return sho_oklch(0.5, 0, 0);
}

/// A hairline. One place, so its width is one decision.
function sho_ui_rule(_x0, _x1, _y, _c) {
    var _old = draw_get_colour();
    draw_set_colour(_c);
    draw_line_width(_x0, _y, _x1, _y, 1);
    draw_set_colour(_old);
}

/// A filled panel with a drawn edge.
function sho_ui_plate(_x0, _y0, _x1, _y1, _fill, _edge) {
    var _old = draw_get_colour();
    draw_set_colour(_fill);
    draw_rectangle(_x0, _y0, _x1, _y1, false);
    if (!is_undefined(_edge)) {
        draw_set_colour(_edge);
        draw_rectangle(_x0, _y0, _x1, _y1, true);
    }
    draw_set_colour(_old);
}

function sho_ui_text(_x, _y, _t, _scale, _c, _ha, _font) {
    draw_set_halign(is_undefined(_ha) ? fa_left : _ha);
    draw_set_valign(fa_middle);
    draw_set_font(is_undefined(_font) ? sho_font() : _font);
    draw_set_colour(_c);
    draw_text_transformed(_x, _y, _t, _scale, _scale, 0);
}

/// The same, but never wider than `_maxw`.
///
/// ⛔ THIS IS A PRODUCT REQUIREMENT, NOT A STORE-SHEET CONVENIENCE, AND IT SHIPPED BROKEN. The card
/// sheet came back clipped at "ink at x=2 on a 1600 surface" and the cause was not the sheet's
/// layout - it was a SPECIES NAME running off the edge of its own card. Shoal generates its names
/// (pattern + epithet + noun), so "Counter-shaded Nuptial Needlenose" is a perfectly ordinary catch
/// and is more than twice the width of "Banded Reef Dace". A card whose title is sized by a
/// constant works for the short names and overflows for the long ones, in the BUYER's game, where
/// no ink-bounds check will ever run.
///
/// The wing's constitution has this lesson from the other direction: draw the same thing smaller to
/// find the layout bugs. Generated text is the same trap arriving through content instead of scale.
function sho_ui_text_fit(_x, _y, _t, _scale, _c, _ha, _font, _maxw) {
    draw_set_font(is_undefined(_font) ? sho_font() : _font);
    var _w = string_width(_t);
    var _s = (_w > 0) ? min(_scale, _maxw / _w) : _scale;
    sho_ui_text(_x, _y, _t, _s, _c, _ha, _font);
}

/// ============================================================================================
/// RARITY
///
/// Five tiers. They drive the card's ornament, its accent colour and its border weight, so rarity
/// is legible from the shape of the card at a glance rather than from a word.
/// ============================================================================================

function sho_rarity_ids() { return ["common", "frequent", "scarce", "rare", "fabled"]; }

function sho_rarity_name(_r) {
    switch (_r) {
        case 0: return "Common";
        case 1: return "Frequent";
        case 2: return "Scarce";
        case 3: return "Rare";
        case 4: return "Fabled";
    }
    return "?";
}

/// The accent hue climbs from a cold neutral to a warm gold across the five tiers, and chroma
/// climbs with it. A tier told apart only by a label is a tier a player does not feel.
function sho_rarity_colour(_r) {
    var _t = clamp(_r, 0, 4) / 4;
    return sho_oklch(lerp(0.560, 0.800, _t), lerp(0.016, 0.132, _t), lerp(232, 82, _t));
}

/// Corner furniture, generated from the tier: a common card has plain corners, a fabled one has
/// three nested brackets and a rosette. THE ORNAMENT IS DRAWN, not selected from sprites, and its
/// size is a fraction of the card so it survives being rendered at any scale.
function sho_card_corners(_x0, _y0, _x1, _y1, _r, _c) {
    var _n = clamp(_r, 0, 4);
    var _len = (_x1 - _x0) * 0.052;
    var _old = draw_get_colour();
    draw_set_colour(_c);
    for (var _k = 0; _k <= _n; _k++) {
        var _o = _k * (_x1 - _x0) * 0.011;
        var _l = _len * (1 - _k * 0.16);
        // Four corners, each two strokes. Nested by _k, so the tier is the DEPTH of the bracket.
        for (var _i = 0; _i < 4; _i++) {
            var _cx = (_i mod 2 == 0) ? (_x0 - _o) : (_x1 + _o);
            var _cy = (_i < 2) ? (_y0 - _o) : (_y1 + _o);
            var _sx = (_i mod 2 == 0) ? 1 : -1;
            var _sy = (_i < 2) ? 1 : -1;
            draw_line_width(_cx, _cy, _cx + _sx * _l, _cy, 2);
            draw_line_width(_cx, _cy, _cx, _cy + _sy * _l, 2);
        }
    }
    // The rosette: only on the top two tiers, and it is the loudest thing on the card.
    if (_n >= 3) {
        var _mx = (_x0 + _x1) * 0.5, _my = _y0 - (_x1 - _x0) * 0.028;
        var _rr = (_x1 - _x0) * 0.020;
        var _pts = (_n == 4) ? 8 : 6;
        for (var _i = 0; _i < _pts; _i++) {
            var _a = (_i / _pts) * 2 * pi - pi * 0.5;
            draw_line_width(_mx, _my, _mx + cos(_a) * _rr * 1.9, _my + sin(_a) * _rr * 1.9, 2);
        }
        draw_circle(_mx, _my, _rr, false);
    }
    draw_set_colour(_old);
}

/// ============================================================================================
/// THE CARD
/// ============================================================================================

/// A catch, as every part of this package passes one around:
///
///   sp       the species struct from sho_species_make
///   len_cm   this individual's length
///   mass_g   its mass, from sho_mass_g
///   biome    where it was taken
///   season   0..3
///   hour     0..23
///   rarity   0..4
///   record   true if it beat this species' previous best
///
/// sho_water builds them; sho_log stores them; this file draws them. None of the three needs the
/// others to be present, which is what lets a buyer take the card alone if that is all they want.
function sho_catch_make(_sp, _len_cm, _biome, _season, _hour, _rarity) {
    if (!sho_species_is(_sp)) return undefined;
    if (!is_real(_len_cm)) { _len_cm = sho_form_typical_cm(_sp.form); }
    return {
        sp: _sp, len_cm: _len_cm, mass_g: sho_mass_g(_sp.form, _len_cm),
        biome: _biome, season: _season, hour: _hour, rarity: _rarity, record: false
    };
}

function sho_season_name(_s) {
    switch (_s mod 4) {
        case 0: return "Spring";
        case 1: return "Summer";
        case 2: return "Autumn";
        case 3: return "Winter";
    }
    return "?";
}

function sho_hour_text(_h) {
    var _hh = _h mod 24;
    return string(_hh < 10 ? "0" : "") + string(_hh) + ":00";
}

/// Draw a full specimen card in the box (_x, _y, _w, _h).
///
/// Portrait, roughly 5:7, because that is the proportion a specimen with a name under it wants -
/// and because a card the same aspect as the screen reads as a dialog rather than as an object.
function sho_card_draw(_catch, _x, _y, _w, _h) {
    // A card with no catch draws nothing. This is a UI call in a Draw event, so a throw here takes
    // the buyer's whole frame down for a value that is simply not ready yet.
    if (is_undefined(_catch) || !is_struct(_catch) || !variable_struct_exists(_catch, "sp")
        || !sho_species_is(_catch.sp)) return;
    var _oc = draw_get_colour(), _oa = draw_get_alpha();
    var _of = draw_get_font(), _oh = draw_get_halign(), _ov = draw_get_valign();

    var _sp = _catch.sp;
    var _acc = sho_rarity_colour(_catch.rarity);
    var _x1 = _x + _w, _y1 = _y + _h;
    var _pad = _w * 0.062;

    // 1. the card body and its frame
    sho_ui_plate(_x, _y, _x1, _y1, sho_ui_colour("plate"), sho_ui_colour("rule"));
    sho_card_corners(_x, _y, _x1, _y1, _catch.rarity, _acc);

    // 2. the specimen well - a recess, so the fish reads as mounted rather than pasted
    var _wy0 = _y + _pad;
    var _wy1 = _y + _h * 0.470;
    sho_ui_plate(_x + _pad, _wy0, _x1 - _pad, _wy1, sho_ui_colour("well"), sho_ui_colour("rule"));

    // 3. THE SPECIMEN, FITTED to the well rather than scaled by a fraction of it. A unit box is not
    //    a bounding box (see sho_render): scaling by the frame left a third of the well empty on
    //    every card and more than half of it on the slimmer forms.
    sho_species_draw_fit(_sp, (_x + _x1) * 0.5, (_wy0 + _wy1) * 0.5,
                         (_x1 - _x - _pad * 2) * 0.92, (_wy1 - _wy0) * 0.86, false);

    // 4. the name block
    var _ty = _wy1 + _h * 0.062;
    var _inner = _w - _pad * 2;
    // ⚠️ 0.0038 RATHER THAN 0.0044, AND THE REASON IS TYPOGRAPHIC CONSISTENCY ACROSS CARDS. The fit
    // only ever shrinks, so a base scale that suits the shortest name leaves short names at full
    // size while long ones are reduced - and a row of cards then shows three different heading
    // sizes. Setting the base where a TYPICAL generated name already fits means most cards agree
    // and only the extremes are reduced.
    sho_ui_text_fit((_x + _x1) * 0.5, _ty, _sp.name, _w * 0.0038, sho_ui_colour("ink"),
                    fa_center, sho_font_title(), _inner);
    sho_ui_text_fit((_x + _x1) * 0.5, _ty + _h * 0.046, _sp.latin, _w * 0.0028,
                    sho_ui_colour("ink2"), fa_center, sho_font(), _inner);
    sho_ui_rule(_x + _pad, _x1 - _pad, _ty + _h * 0.076, sho_ui_colour("rule"));

    // 5. the measurements, as a two-column reading, right-aligned figures.
    //    ⚠️ The rows are laid out from a PITCH computed off the card height, and the pitch is
    //    multiplied by the row INDEX rather than by the row count. The wing has the opposite
    //    mistake on record: two bake sheets reported a clip that did not exist because a layout
    //    expression multiplied pitch by count instead of count - 1.
    var _rows = [
        ["Length", string(_catch.len_cm) + " cm"],
        ["Mass",   sho_mass_text(_catch.mass_g)],
        ["Water",  sho_biome_name(_catch.biome)],
        ["Taken",  sho_season_name(_catch.season) + ", " + sho_hour_text(_catch.hour)]
    ];
    var _ry = _ty + _h * 0.118;
    var _pitch = _h * 0.058;
    for (var _i = 0; _i < array_length(_rows); _i++) {
        var _yy = _ry + _pitch * _i;
        // The label takes the left 40% and the figure the right 55%, both fitted, so a long biome
        // name and a long mass figure cannot collide with each other in the middle of the row.
        sho_ui_text_fit(_x + _pad, _yy, _rows[_i][0], _w * 0.0030, sho_ui_colour("ink2"),
                        fa_left, sho_font(), _inner * 0.40);
        sho_ui_text_fit(_x1 - _pad, _yy, _rows[_i][1], _w * 0.0032, sho_ui_colour("ink"),
                        fa_right, sho_font(), _inner * 0.55);
    }

    // 6. the rarity strip, in the accent, plus the record mark if this beat the previous best
    var _sy = _y1 - _pad * 0.78;
    sho_ui_rule(_x + _pad, _x1 - _pad, _sy - _h * 0.030, sho_ui_colour("rule"));
    sho_ui_text_fit(_x + _pad, _sy, string_upper(sho_rarity_name(_catch.rarity)), _w * 0.0030,
                    _acc, fa_left, sho_font(), _inner * 0.45);
    if (_catch.record) {
        sho_ui_text_fit(_x1 - _pad, _sy, "NEW RECORD", _w * 0.0030, sho_ui_colour("accent"),
                        fa_right, sho_font(), _inner * 0.50);
    }

    draw_set_colour(_oc); draw_set_alpha(_oa);
    draw_set_font(_of); draw_set_halign(_oh); draw_set_valign(_ov);
}

/// Mass, in the unit a player can read. Grams below a kilo, kilos above.
///
/// ⛔ string_format, NOT string(). GML's string() renders a real with TWO decimal places, so
/// string(2.5) is "2.50" and a card reads "2.50 kg" - which looks like a spreadsheet, not a catch.
/// The self-test asserts both branches against literal expected text for exactly this reason: it is
/// the kind of defect that is invisible until somebody reads a rendered card, and by then it is on
/// the store page.
function sho_mass_text(_g) {
    if (!is_real(_g)) return "-";          // a card with no mass yet prints a dash, not a crash
    if (_g < 1000) return string(round(_g)) + " g";
    return string_format(_g / 1000, 1, 1) + " kg";
}
