{
  "$GMScript": "v1",
  "%Name": "sho_card",
  "isCompatibility": false,
  "isDnD": false,
  "name": "sho_card",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}