# Shoal — a fishing system that draws its own fish

**For GameMaker (GMS2 runtime 2024.14+). Pure GML. No sprites, no atlas, no texture page.**

Shoal is a complete fishing subsystem: what is in the water, how it fights on the line, and what
you get for landing it. Every fish it produces is **drawn from geometry at run time** — there is no
`sprites/` folder in this package, and there is no image file of any kind.

```
species = base form (12) × pattern (10) × fin set (8) × palette (10)
```

That is **9,600 distinct species from 40 authored components**, and the number is a multiplication
rather than a folder of drawings — it says so out loud so you can check it.

⚠️ **The figure that actually bounds legibility is 96.** A fish's identity at small size is carried
by its **body form × fin set alone** — patterns and palettes multiply the catalogue, not the
silhouette. So the honest claim is *96 distinct silhouettes*, each of which was rendered onto a
contact sheet and looked at, and 9,600 catalogue entries built on top of them.

---

## Install

1. In GameMaker: **Tools → Import Local Package**, choose `Shoal.yymps`, **Add All**.
2. Open **`rm_shoal_demo`** and press Play.

That is the whole installation. The demo is one object with three events and it is written to be
read — it is the quickstart, not a black box.

**Demo controls:** `SPACE` cast, then hold to reel · `B` change water · `S` change season ·
`T` change time of day · `L` change line.

---

## The five-minute integration

```gml
// 1. WHAT IS DOWN THERE. Biome, season, hour and a seed.
var _catch = sho_water_roll("reef", 0, 14, irandom(999999));

// 2. THE FIGHT. Pure logic - no engine calls, no input assumptions.
var _fight = sho_fight_begin(_catch, "braid");

// ...in your Step event, with YOUR input:
sho_fight_step(_fight, delta_time / 1000000, my_reel_button_is_held);
if (sho_fight_over(_fight) && _fight.state == SHO_FIGHT_LANDED) {
    sho_log_land(my_log, _catch);       // records it, and flags a personal best
}

// 3. DRAW IT. Anywhere, at any size, facing either way.
sho_species_draw_fit(_catch.sp, x, y, 220, 120, false);

// 4. OR DRAW THE WHOLE CARD.
sho_card_draw(_catch, 40, 40, 320, 454);
```

---

## What is in the box

| Script | What it is |
| --- | --- |
| `sho_forms` | **The corpus, half one.** 12 base body forms, each two independent profile envelopes |
| `sho_fins` | **The corpus, half two.** 8 fin sets, each sized from the body it attaches to |
| `sho_pattern` | 10 patterns, clipped to the body **in geometry** — no surface, no blend mode, no mask |
| `sho_livery` | 10 palettes, five roles each, computed in **Oklch** from three numbers per palette |
| `sho_species` | Composition, naming (36 nouns, 30 epithets, 12 genera), and the cube-law mass model |
| `sho_water` | 5 biomes × 4 seasons × 4 time bands, 110 authored weights, **derived** rarity |
| `sho_tackle` | The tension minigame. **Zero engine calls** — a state machine you step |
| `sho_card` | The specimen card, and the small drawn UI layer |
| `sho_log` | Records, codex, completion, and a plain-text save format |
| `sho_render` | The only file that touches the GPU |
| `sho_geom`, `sho_palette` | The shared primitive and colour layer |
| `sho_selftest`, `sho_bake` | Verification and gallery rendering. Not features — see below |

---

## Things worth knowing before you start

**Every global and macro is namespaced `SHO_` / `sho_`.** GML's global namespace is flat, and a
collision inside your project is a support ticket nobody can debug remotely. The one global this
package creates is `global.sho_profile_cache`.

**Nothing here calls `random()`.** Every seeded thing — spot placement, name selection, the fight —
runs off a seeded generator, so the same species always looks the same and a save file can store
four component ids instead of a serialised fish.

**The fight takes a boolean, not a key.** `sho_fight_step(fight, dt, reeling)`. Keyboard, gamepad,
touch, a held button, a rhythm of taps — none of that is this package's business.

**Rarity is derived, never declared.** No species carries a rarity field. A catch's tier comes from
how unlikely its combination was *in that water at that time*, so the same fish is common in the
reef and scarce in a river without either fact being written down twice.

**Time is in seconds.** Every rate in `sho_tackle` is per second and multiplied by your delta, so
the minigame behaves identically at 30, 60 and 144 fps. Measured, not asserted: the same fight held
on the reel takes 1.00s at 60fps and 0.99s at 144fps.

**The public API refuses, it does not throw.** Hand any public function an `undefined`, a `{}`, an
unknown id, an index where an id belongs, a negative size or a save string from a different game,
and it returns a sane empty value — `false`, `0`, `undefined`, an empty array, or simply draws
nothing. It does not raise. This matters most on the **save path**: when a player's old save file
reaches `sho_log_load_string`, a crash there would happen inside your shipped game, and you would
have no way to debug it. 102 hostile calls, 0 crashes.

⚠️ One consequence worth knowing: `sho_fight_over(undefined)` returns **true**, deliberately. The
Step-event loop above is `while (!sho_fight_over(f))`, so returning false for an unusable fight
would hang your game rather than end it.

**Fonts are optional and swappable.** `sho_font()` in `sho_render` is the single place either font
resource is named. Without `fonts/`, fish still draw; only lettering is lost.

---

## Verifying it yourself

This package ships its own test suite and its own gallery renderer, and both run headlessly:

```
Shoal.exe -selftest    # 1,480 assertions; writes sho_selftest.json
Shoal.exe -bake        # renders the store sheets from the shipped GML
```

They are not features and they cost you nothing at run time — they are why the claims above can be
checked rather than believed. **Every image on the store page was rendered by `-bake`**, through the
same public functions this Readme documents.

---

## Support

Questions, bugs and feature requests: the product's page on itch.io.

Core Systems Asset Factory — Shoal v1.0.0
