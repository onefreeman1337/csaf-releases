# BARRAGE — Bullet Patterns Whose Art Answers To The Pattern

**A GameMaker projectile and pattern system, written in pure GML. No sprites, no spritesheet, no
atlas — `sprites/` does not exist in this package.**

A pattern is a pure function of `(wave, shot, time)`. Ask it for a moment and it hands back every
live shot with a position, a heading and a charge. Every one of those shots then **draws itself**
from the pattern that fired it: raise the arm count and the gap between neighbouring shots narrows,
so Barrage picks a narrower body, and a wall of fire stays readable instead of becoming a smear.

That coupling is the product. The shelf sells the wiring (a framework whose own copy says *all you
need is to draw a sprite*) and the art (fixed spritesheets), and never joins them.

- **GameMaker 2024.14+.** Built and gated against runtime `2024.14.4.268`.
- **16 resources** — 12 script assets, 2 fonts, 1 demo object, 1 demo room. 5,702 lines of GML.
- **162 functions and 63 macros, every one `bar_` / `BAR_` prefixed**, and the only three globals in
  the package are `global.bar_lx`, `global.bar_ly` and `global.bar_stage`. Nothing here can collide
  with a name in your project.

---

## What this is, and what it is not

**It is** a runtime generator. Nothing is baked. Every image on the store page was drawn by the same
code you are importing, in engine, by `bar_bake` — which ships with the package, so you can
re-render those sheets yourself and check.

**It is not** a bullet-hell engine. There is no collision system, no player, no scoring and no
enemy AI. Barrage answers *where is every shot, which way is it pointed, and what does it look
like*; hit detection against your own player is yours, and the shot's kill radius is published
(`BAR_HITBOX_R`) so you can write it in one line.

**It is not** a sprite pack. The look is the product's: flat masses with a drawn relief pass, lit
from one fixed lamp, over a five-stop ramp per element.

---

## Quickstart

1. In GameMaker: **Tools → Import Local Package**, pick `Barrage.yymps`, **Add All**, import.
2. Open **`rm_bar_demo`** and press Play. That room is the whole product driven by one object.
3. In your own code, the front door is three calls:

```gml
// Create
spec  = bar_pattern_spec(BAR_PAT_RING, 24, 5, 11, 360, 0.30, 0, 0.34, 0, 0);
body  = bar_bullet_for(spec.arms, 0.9, "pellet", 0.055);   // asks: what body survives 24 arms?
elem  = bar_element_find("plasma");
t     = 0;

// Step
t += delta_time / 1000000;

// Draw
var _unit = min(room_width, room_height);
var _live = bar_pattern_live(spec, t);
for (var _i = 0; _i < array_length(_live); _i++) {
    var _s = _live[_i];
    bar_render_parts(
        bar_bullet_parts(body, _s.charge),
        bar_element_pal(elem, _s.charge),
        x + _s.x * _unit, y + _s.y * _unit,
        _unit * 0.055, _s.heading, 1, undefined);
}
```

Each entry of `bar_pattern_live` is a plain struct:

| field | is |
| --- | --- |
| `x`, `y` | position, in **field units** — `1.0` is whatever you multiply by. The demo uses the short side of the screen; nothing in Barrage knows about pixels until you choose the unit. |
| `r` | distance from the emitter, in the same units |
| `hx`, `hy` | the heading as a unit vector, if you would rather not convert back from degrees |
| `heading` | the heading in degrees, ready to hand to `bar_render_parts` |
| `born`, `age` | when the shot's wave fired, and how long it has been alive, in seconds |
| `alive` | whether it has been fired yet |
| `charge` | 0..1, how far the shot is through winding up. Slides the element ramp. |

### The demo room's controls

| key | does |
| --- | --- |
| `left` / `right`, or `A` / `D` | previous / next pattern family |
| `up` / `down` | previous / next element |
| `Q` / `E` | scrub the clock backwards / forwards, held |
| `space` | pause |
| `H` | toggle the drawn hitbox and graze band |
| `R` | restart the pattern |

---

## The pattern spec

Everything you tune lives in one struct and nothing else does.

```gml
bar_pattern_spec(fam, arms, waves, spin, spread, speed, accel, gap, aim, jitter)
```

| field | meaning |
| --- | --- |
| `fam` | one of the twelve `BAR_PAT_*` families |
| `arms` | shots per wave. **The headline number** — `bar_bullet_for` reads it to choose a body |
| `waves` | how many waves the pattern fires |
| `spin` | degrees the whole pattern turns between waves (what makes a ring a spiral) |
| `spread` | degrees the arms span. 360 for a full ring, less for a fan |
| `speed` | field units per second at wave start |
| `accel` | field units per second per second |
| `gap` | seconds between waves |
| `aim` | heading in degrees the pattern is pointed at |
| `jitter` | per-shot randomisation. `0` for a clean pattern |

**The twelve families, and the question each one asks the player:** ring (move off the axis) · fan
(read the spread and pick a side) · spiral (keep moving, one direction) · aimed (stop standing
still) · lace (find the moving gap) · wall (find the fixed gap, now) · rain (watch a second axis) ·
bloom (leave before it opens) · converge (do not go to the middle) · whip (the safe side is
changing) · homing (break line of sight) · arc (duck under, or go over).

`bar_pattern_preset(fam)` returns a tuned spec for any of them if you want a starting point.

### Scrubbing is free, and that is not a side effect

Because a pattern is a pure function of time, running it backwards is the same operation as running
it forwards. You can preview a wave, step to the exact frame a shot becomes unreadable, and assert
things about a pattern **without a clock running and without spawning a single instance**:

```gml
var _n = array_length(bar_pattern_live(spec, 1.75));   // how crowded is it at t=1.75?
```

---

## The two corpora

**45 projectile bodies** across 8 silhouette classes — round, lance, facet, star, ring, organic,
arcane, heavy. `bar_bullet_find("crystal")` by name, `bar_bullet_info(ix)` for its record,
`bar_bullet_count()` for all of them.

**12 elements**, each a five-stop ramp rather than a tint: the lit flank, the shadowed flank and the
rim take different stops, which is what gives a body an internal edge and lets it survive being one
of a hundred overlapping shapes. Every adjacent pair is asserted in-engine to differ in apparent
lightness. `bar_element_find("frost")`, `bar_element_pal(ix, charge)`.

**`charge`** slides the ramp as a shot ages, so a shot winding up and a shot at full speed are not
the same picture.

---

## Legibility — the half nothing on the shelf ships

An unreadable bullet is a death the player could not have avoided. Barrage measures three things
and tells you which knob moves each one:

```gml
var _rep = bar_legibility_report(spec, elem, body, 0.055, 0.14, 0.24);
show_debug_message(bar_legibility_line(_rep));
// BARRAGE legibility: 9 checks, no issues (ring / pellet)
```

- **Crowding** — sampled across the radii the pattern actually occupies, because a ring is most
  crowded when it is *young* and checking only the outer edge passes everything.
- **Contrast** — the worst-case separation between the body's ramp and the lightness band of your
  field, at rest **and** fully charged. Worst case, not average: a shot crosses the whole field, so
  the only number that matters is the band where it is hardest to see.
- **Warning time** — how long the player has between a wave appearing and reaching them.

`_rep.issues` is a list of `{ kind, measured, floor, fix }`. The `fix` names the parameter to
change. **It reports rather than clamps** — a pattern too dense to be legible is a design decision
you should be told about, not one silently made for you.

The drawn hitbox and graze band come from `bar_legibility_parts(true)`; the kill radius is
`BAR_HITBOX_R` (0.34 of a body's 0.50 half-width) and the graze band is `BAR_GRAZE_BAND` (+55%).

---

## Compatibility

- **GameMaker 2024.14+**, legacy runtime. Built and gated against `2024.14.4.268`. Nothing here
  uses a GMRT-only feature.
- **No shaders and no extensions anywhere.** The drawing path is `draw_primitive`, `draw_circle`,
  `draw_line_width` and `draw_rectangle` through `bar_render`, so it works anywhere GameMaker
  draws — including onto a surface of your own, or inside a GUI event.
- **The one place a surface is used is opt-in and is not in the default path**: `bar_render_to_sprite`
  bakes a body to a sprite you can blit thousands of times. Three rules, and they are enforced by the
  suite rather than left to you: build it in **Create**, never in a Draw event (nesting render
  targets silently produces an empty sprite on some drivers); **you own the sprite and must
  `sprite_delete` it**; and only ever hand it a body marked `spin_safe` — a pellet, an orb, a bubble.
  A body with a nose is wrong at 359 of 360 headings once baked, which is the whole reason this
  product draws instead. The demo does not use the cache.
- **No collision, no instances, no objects required.** `bar_pattern_live` is a function; you decide
  what holds the result. The demo uses one object because it needs somewhere to keep a clock.
- **No global state** beyond the lamp direction (`bar_lamp_set` / `bar_lamp_reset`) and the crash
  stage marker used by the demo's own error handler.
- **Deterministic.** Jitter is seeded from each shot's own identity, never from `random()`, so two
  calls asking for the same shot return the same shot and scrubbing is stable.

---

## Verifying it yourself

The package ships its own test suite and its own store-sheet renderer, and both are things you can
run:

- `Barrage.exe -selftest` writes `bar_selftest.json` to `%LOCALAPPDATA%\Barrage\` — **2,293
  assertions** over the corpora, the pattern arithmetic, the legibility solver and the demo's own
  input handling.
- `Barrage.exe -bake` re-renders every image on the store page into the same folder.

---

## Licence

One seat per developer; ship the compiled result in as many of your own games as you like. Do not
redistribute the source or resell it as an asset. Full terms in `LICENSE.txt`.

The two fonts are built from **Open Sans**, used under the Apache License 2.0 — see
`Barrage/fonts/THIRD-PARTY-NOTICES.txt` and `Barrage/fonts/Apache-2.0.txt`, both of which ship
inside the package.

---

## Disclosure

Barrage's code and its generated artwork were written with AI assistance. The sound design question
does not arise: this package contains no audio.

*Core Systems Asset Factory*
