/// BARRAGE - bar_bullet. The projectile body corpus.
///
/// EVERY BODY IS A PROFILE, NOT A PICTURE. A body is a half-width function sampled along the
/// travel axis into a closed outline, plus the ornament its family adds. There is no sprite,
/// no spritesheet and no atlas in this package: `sprites/` does not exist.
///
/// -- WHY THAT IS THE PRODUCT AND NOT A TECHNIQUE ---------------------------------------------
/// ⭐ A PATTERN FIRES THE SAME BODY AT EVERY HEADING ON THE CIRCLE AT ONCE. A baked bullet is
/// therefore correct at one heading and wrong at the other 359, and a dense ring shows all of
/// them in the same frame - see bar_render's cache header, which is the one place in this package
/// where that arithmetic is unavoidable. The shelf's answer to this is to sell a $19.99-$98
/// spritesheet and let the buyer rotate it; that works until the shot is lit, and every body here
/// is lit by bar_relief from its own surface normals.
///
/// ⭐ AND THE BODY ANSWERS TO THE PATTERN, which is the coupling nothing on the shelf ships.
/// bar_bullet_for() narrows the body as the arm count rises: a 24-arm ring drawn with 6-arm
/// bodies is a solid wall with no gaps to read, and a 6-arm ring drawn with 24-arm bodies is four
/// threads and no threat. The buyer sets ONE number - how many arms - and the art follows.
///
/// -- THE LAWS THIS FILE OBEYS ------------------------------------------------------------------
/// ⛔ SILHOUETTE FIRST. Every body must be identifiable with the palette removed (bar_shape's
/// greyscale law): about one man in twelve cannot separate the red shot from the green one, and
/// in this genre an unreadable bullet is a death the player could not have avoided. Bodies are
/// therefore separated by SHAPE CLASS first and colour second, and bar_selftest asserts that no
/// two bodies in the same class share an aspect ratio.
///
/// ⛔ SPIN SAFETY. A body is `spin_safe` only if it is radially symmetric, i.e. it has no nose and
/// no lit side to carry round when cached. bar_render_to_sprite must only ever be handed one of
/// those, and bar_selftest asserts it - the comment in bar_render promises this and this is where
/// the promise is kept.
///
/// ⛔ THE PIXEL FLOOR IS A SAFETY RULE HERE (bar_geom's COORDINATES header). A body drawn at 6 px
/// in a wall of fire must still have a closed outline; bar_render's 1.0 px stroke floor does that
/// half, and this file does the other half by never authoring an ornament thinner than the rim it
/// sits on.
/// ============================================================================================

/// How many bodies the corpus ships. ⛔ ASSERTED by bar_selftest against the dispatch, so this
/// number and the listing copy cannot drift apart - this wing has shipped a live page claiming a
/// pack was half its real size, for days, because a checker held the same stale number the page
/// did. bar_bullet_count() COUNTS the dispatch rather than returning this.
///
/// ⭐ AND THE ASSERTION EARNED ITS KEEP ON ITS VERY FIRST RUN. This macro was authored as 44 from
/// the design sketch; the table below actually holds 45, and the suite said so in engine before a
/// single word of listing copy existed. That is the whole point of counting the dispatch instead
/// of trusting the number: the number was wrong, and it was wrong in the direction that
/// undersells the product.
#macro BAR_BODY_COUNT 45

/// Shape classes. The silhouette families a player learns to read.
#macro BAR_CL_ROUND  0
#macro BAR_CL_LANCE  1
#macro BAR_CL_FACET  2
#macro BAR_CL_STAR   3
#macro BAR_CL_RING   4
#macro BAR_CL_ORGAN  5
#macro BAR_CL_ARCANE 6
#macro BAR_CL_HEAVY  7

/// The body table. name, class, spin_safe, aspect (length along travel / width), and the profile
/// parameters the builder reads.
///
/// ⚠️ `spin_safe` IS NOT DERIVED FROM THE CLASS, and it would be wrong if it were: a halo is
/// ROUND-class and spin safe, a caltrop is STAR-class and also spin safe, and a bloom is
/// ORGAN-class and is NOT. It is a property of the geometry, so it is authored per body and
/// asserted per body.
function bar_bullet_table() {
    return [
        // ---- ROUND: radially symmetric, safe to cache, the bulk of any dense wall -------------
        { name: "pellet",   cl: BAR_CL_ROUND,  spin: true,  aspect: 1.00, p: 0.50, orn: 0 },
        { name: "orb",      cl: BAR_CL_ROUND,  spin: true,  aspect: 1.00, p: 0.50, orn: 1 },
        { name: "bubble",   cl: BAR_CL_ROUND,  spin: true,  aspect: 1.00, p: 0.50, orn: 2 },
        { name: "pearl",    cl: BAR_CL_ROUND,  spin: true,  aspect: 1.00, p: 0.50, orn: 3 },
        { name: "mote",     cl: BAR_CL_ROUND,  spin: true,  aspect: 1.00, p: 0.30, orn: 0 },
        { name: "sun",      cl: BAR_CL_ROUND,  spin: true,  aspect: 1.00, p: 0.50, orn: 4 },
        { name: "eye",      cl: BAR_CL_ROUND,  spin: true,  aspect: 1.00, p: 0.50, orn: 5 },
        // ---- LANCE: a nose and a tail. NEVER spin safe -----------------------------------------
        { name: "lance",    cl: BAR_CL_LANCE,  spin: false, aspect: 3.10, p: 0.62, orn: 0 },
        { name: "dart",     cl: BAR_CL_LANCE,  spin: false, aspect: 2.30, p: 0.55, orn: 1 },
        { name: "needle",   cl: BAR_CL_LANCE,  spin: false, aspect: 4.40, p: 0.40, orn: 0 },
        { name: "bolt",     cl: BAR_CL_LANCE,  spin: false, aspect: 2.70, p: 0.70, orn: 2 },
        { name: "quill",    cl: BAR_CL_LANCE,  spin: false, aspect: 3.60, p: 0.48, orn: 3 },
        { name: "spear",    cl: BAR_CL_LANCE,  spin: false, aspect: 3.90, p: 0.58, orn: 4 },
        { name: "spindle",  cl: BAR_CL_LANCE,  spin: false, aspect: 2.05, p: 0.50, orn: 0 },
        { name: "javelin",  cl: BAR_CL_LANCE,  spin: false, aspect: 5.20, p: 0.44, orn: 1 },
        // ---- FACET: cut, flat-sided, catches the lamp in bands ---------------------------------
        { name: "gem",      cl: BAR_CL_FACET,  spin: false, aspect: 1.35, p: 0.55, orn: 0 },
        { name: "crystal",  cl: BAR_CL_FACET,  spin: false, aspect: 1.95, p: 0.50, orn: 1 },
        { name: "prism",    cl: BAR_CL_FACET,  spin: false, aspect: 1.60, p: 0.62, orn: 2 },
        { name: "chip",     cl: BAR_CL_FACET,  spin: false, aspect: 1.15, p: 0.45, orn: 3 },
        { name: "shard",    cl: BAR_CL_FACET,  spin: false, aspect: 2.60, p: 0.38, orn: 0 },
        { name: "wedge",    cl: BAR_CL_FACET,  spin: false, aspect: 1.75, p: 0.68, orn: 4 },
        // ---- STAR: points about a centre. Spin safe when the points are even --------------------
        { name: "star4",    cl: BAR_CL_STAR,   spin: true,  aspect: 1.00, p: 0.44, orn: 4 },
        { name: "star5",    cl: BAR_CL_STAR,   spin: false, aspect: 1.00, p: 0.42, orn: 5 },
        { name: "star6",    cl: BAR_CL_STAR,   spin: true,  aspect: 1.00, p: 0.46, orn: 6 },
        { name: "caltrop",  cl: BAR_CL_STAR,   spin: true,  aspect: 1.00, p: 0.36, orn: 3 },
        { name: "burr",     cl: BAR_CL_STAR,   spin: true,  aspect: 1.00, p: 0.40, orn: 8 },
        { name: "spark",    cl: BAR_CL_STAR,   spin: true,  aspect: 1.00, p: 0.30, orn: 7 },
        // ---- RING: hollow. The class a player reads as "passes through" -------------------------
        { name: "halo",     cl: BAR_CL_RING,   spin: true,  aspect: 1.00, p: 0.50, orn: 0 },
        { name: "hoop",     cl: BAR_CL_RING,   spin: true,  aspect: 1.00, p: 0.50, orn: 1 },
        { name: "annulus",  cl: BAR_CL_RING,   spin: true,  aspect: 1.00, p: 0.50, orn: 2 },
        { name: "coil",     cl: BAR_CL_RING,   spin: true,  aspect: 1.00, p: 0.50, orn: 3 },
        // ---- ORGAN: grown rather than cut ------------------------------------------------------
        { name: "droplet",  cl: BAR_CL_ORGAN,  spin: false, aspect: 1.55, p: 0.52, orn: 0 },
        { name: "tear",     cl: BAR_CL_ORGAN,  spin: false, aspect: 1.85, p: 0.46, orn: 1 },
        { name: "seed",     cl: BAR_CL_ORGAN,  spin: false, aspect: 1.40, p: 0.58, orn: 2 },
        { name: "spore",    cl: BAR_CL_ORGAN,  spin: true,  aspect: 1.00, p: 0.48, orn: 3 },
        { name: "bloom",    cl: BAR_CL_ORGAN,  spin: false, aspect: 1.20, p: 0.50, orn: 4 },
        { name: "fang",     cl: BAR_CL_ORGAN,  spin: false, aspect: 2.40, p: 0.42, orn: 5 },
        // ---- ARCANE: drawn marks, not solids ---------------------------------------------------
        { name: "rune",     cl: BAR_CL_ARCANE, spin: false, aspect: 1.10, p: 0.48, orn: 0 },
        { name: "sigil",    cl: BAR_CL_ARCANE, spin: true,  aspect: 1.00, p: 0.46, orn: 1 },
        { name: "glyph",    cl: BAR_CL_ARCANE, spin: false, aspect: 1.25, p: 0.44, orn: 2 },
        { name: "ward",     cl: BAR_CL_ARCANE, spin: true,  aspect: 1.00, p: 0.50, orn: 3 },
        // ---- HEAVY: slow, large, the thing you must move around --------------------------------
        { name: "shell",    cl: BAR_CL_HEAVY,  spin: false, aspect: 1.45, p: 0.72, orn: 0 },
        { name: "slug",     cl: BAR_CL_HEAVY,  spin: false, aspect: 1.70, p: 0.66, orn: 1 },
        { name: "boulder",  cl: BAR_CL_HEAVY,  spin: true,  aspect: 1.00, p: 0.62, orn: 2 },
        { name: "anvil",    cl: BAR_CL_HEAVY,  spin: false, aspect: 1.30, p: 0.70, orn: 3 },
    ];
}

/// COUNT the dispatch rather than trusting the macro. See BAR_BODY_COUNT's own comment: a checker
/// that holds the same number the copy holds certifies the staleness it exists to catch.
function bar_bullet_count() { return array_length(bar_bullet_table()); }

function bar_bullet_info(_ix) {
    var _t = bar_bullet_table();
    var _n = array_length(_t);
    return _t[((_ix % _n) + _n) % _n];
}

function bar_bullet_find(_name) {
    var _t = bar_bullet_table();
    for (var _i = 0; _i < array_length(_t); _i++) if (_t[_i].name == _name) return _i;
    return -1;
}

/// ============================================================================================
/// THE PROFILE
/// ============================================================================================

/// Half-width of a body at _t along its travel axis, _t in [0,1] from tail to nose.
///
/// _p is the position of the widest point. That single number is what separates a droplet (wide
/// at the tail, drawn to a nose) from a lance (wide near the nose, drawn to a long tail), and it
/// is why these are profiles rather than drawings: the shape is one continuous parameter, so
/// bar_bullet_for can move it as the pattern demands and every derived mark follows.
///
/// ⚠️ THE PROFILE NEVER RETURNS EXACTLY ZERO AT EITHER END. A zero half-width collapses two
/// outline points onto each other, and a duplicated vertex caps every bevel in the shape to
/// nothing and breaks bar_inset's direction - bar_shape's dedupe header records the same defect
/// from the other side. The nose is a small flat, not a point, and at draw size it reads as a
/// point anyway.
function bar_bullet_halfwidth(_t, _p, _cl) {
    var _u = clamp(_t, 0, 1);
    var _pp = clamp(_p, 0.08, 0.92);
    // Two half-cosines meeting at the widest point: continuous, and never negative.
    var _s;
    if (_u <= _pp) _s = 0.5 - 0.5 * cos(pi * (_u / _pp));
    else           _s = 0.5 + 0.5 * cos(pi * ((_u - _pp) / (1 - _pp)));
    // Class shaping. FACET and HEAVY hold their width longer (a cut stone has shoulders);
    // LANCE and ORGAN fall away faster toward the nose.
    var _k = 1.0;
    if (_cl == BAR_CL_FACET || _cl == BAR_CL_HEAVY) _k = 0.72;
    if (_cl == BAR_CL_LANCE || _cl == BAR_CL_ORGAN) _k = 1.45;
    return 0.055 + 0.445 * power(clamp(_s, 0, 1), _k);
}

/// A TRUE star: alternating outer and inner radii, _n points.
///
/// ⛔ NOT bar_star_pts, WHICH IS A REGULAR POLYGON DESPITE ITS NAME. MEASURED 2026-09-05 by baking
/// the corpus sheet and LOOKING at it: star4, star5 and star6 rendered as a square, a pentagon and
/// a hexagon, because the shared helper walks n points around one radius. Nothing mechanical could
/// have caught it - 1,768 assertions passed over those bodies, every one of which is a perfectly
/// valid simple polygon with one revolution of turning. It took opening the PNG.
///
/// ⚠️ The shared helper is NOT renamed or changed: other products in this wing depend on it and a
/// shared generator is a shared fact (master §2b). The right fix is a correct local function.
function bar_bullet_star_pts(_r, _n, _inner, _phase) {
    var _out = [];
    var _k = max(3, _n);
    for (var _i = 0; _i < _k * 2; _i++) {
        var _a = _phase + (_i / (_k * 2)) * BAR_TAU;
        var _rr = ((_i % 2) == 0) ? _r : _r * _inner;
        array_push(_out, [cos(_a) * _rr, sin(_a) * _rr]);
    }
    return _out;
}

/// The closed outline of a body, nose at +x, centred on its travel origin.
///
/// ⛔⛔ THE OUTLINE IS CLASS-AWARE, AND THE FIRST VERSION WAS NOT. It ran EVERY body through the
/// travel-axis profile, which is a lens: wide in the middle, narrow at both ends. That is exactly
/// right for a lance and exactly wrong for a pellet, so the whole ROUND class - the bodies a dense
/// wall is actually made of - baked as DIAMONDS. A pellet that is not round is not a pellet.
///
/// ⭐ AND IT PASSED EVERY ASSERTION. The suite checks that an outline is simple, correctly wound,
/// duplicate-free and non-degenerate, and a diamond is all four. There is no mechanical test for
/// "this is the wrong shape" - that is what Gate 1 and opening the PNG are for, and this defect is
/// the receipt for why this wing makes both mandatory.
function bar_bullet_outline(_ix, _n) {
    var _b = bar_bullet_info(_ix);
    var _steps = max(6, is_undefined(_n) ? 18 : _n);

    // ROUND, RING and ARCANE are radially symmetric by definition - their identity is internal,
    // not in the silhouette - so they get a circle, not a profile.
    //
    // ⚠️ `p` IS THE RADIUS FOR THESE CLASSES, AND GIVING IT A JOB HERE FIXED A REAL DUPLICATE.
    // `p` means "where the widest point sits along the travel axis", which is meaningless for a
    // circle - so it was ignored, and `mote` (p 0.30) drew the identical body to `pellet` (p 0.50)
    // under a different name. The corpus claimed 45 distinct bodies and had 44. A mote is a SPECK,
    // so p now scales the circle and the name is true: it is the smallest thing in the corpus and
    // reads as chaff beside a pellet.
    if (_b.cl == BAR_CL_ROUND || _b.cl == BAR_CL_RING || _b.cl == BAR_CL_ARCANE) {
        var _rad = 0.5 * clamp(_b.p / 0.5, 0.55, 1.0);
        return bar_dedupe_pts(bar_arc_pts(0, 0, _rad, 0, BAR_TAU - (BAR_TAU / (_steps * 2)), _steps * 2));
    }

    // STAR is its own silhouette: the point COUNT and the DEPTH between points are the identity.
    //
    // ⛔⛔ THE FIRST VERSION KEYED ONLY ON THE ORNAMENT INDEX AND SHIPPED TWO IDENTICAL BODIES.
    // `star4` and `spark` both carry orn 4, so both resolved to 4 points at inner 0.46 - the same
    // outline, the same relief, the same everything, under two names. That makes "45 distinct
    // bodies" false, and the volume IS this product's moat (master §1.1), so a duplicate is not a
    // cosmetic problem: it is one count of the headline claim that does not exist.
    //
    // ⚠️ THE SUITE COULD NOT SEE IT. 1,768 assertions, every one of which a duplicate passes
    // perfectly - both shapes are simple, correctly wound, non-degenerate and build real parts.
    // The corpus needed a DISTINCTNESS assertion and did not have one; it does now, and it is the
    // check that defends the number in the listing copy.
    //
    // ⚠️ And `caltrop` was 3-pointed, which is both a 6-vertex outline (below the suite's own
    // minimum) and wrong for the word - a caltrop is a four-spiked jack that always lands point
    // up. Fixed to 4 deep points, which also separates it from star4 by DEPTH rather than count.
    if (_b.cl == BAR_CL_STAR) {
        var _pts = 4;
        var _inner = 0.46;
        switch (_b.orn) {
            case 5: _pts = 5; _inner = 0.44; break;   // star5
            case 6: _pts = 6; _inner = 0.62; break;   // star6 - shallower, or the points merge
            case 3: _pts = 4; _inner = 0.26; break;   // caltrop - deep spikes, a four-armed jack
            case 8: _pts = 8; _inner = 0.68; break;   // burr - many shallow points, a seed head
            case 7: _pts = 6; _inner = 0.20; break;   // spark - the sharpest thing in the corpus
            default: _pts = 4; _inner = 0.46; break;  // star4
        }
        return bar_dedupe_pts(bar_bullet_star_pts(0.5, _pts, _inner, -pi * 0.5));
    }

    // Everything with a NOSE gets the travel-axis profile.
    var _len = 0.5;
    var _wid = _len / max(0.35, _b.aspect);
    var _top = [];
    var _bot = [];
    for (var _i = 0; _i <= _steps; _i++) {
        var _t = _i / _steps;
        var _h = bar_bullet_halfwidth(_t, _b.p, _b.cl) * 2 * _wid;
        var _x = (_t - 0.5) * 2 * _len;
        array_push(_top, [_x, -_h]);
        array_push(_bot, [_x,  _h]);
    }
    // Walk the top forward and the bottom back, so the ring is closed and consistently wound.
    var _out = [];
    for (var _i = 0; _i <= _steps; _i++) array_push(_out, _top[_i]);
    for (var _i = _steps; _i >= 0; _i--) array_push(_out, _bot[_i]);
    return bar_dedupe_pts(_out);
}

/// ============================================================================================
/// THE BODY
/// ============================================================================================

/// Build one projectile body as a part list in unit-box space, nose at +x.
///
/// _charge in [0,1] is the wind-up. It does NOT change the silhouette - a player must be able to
/// learn one shape and have it hold - it only moves the ramp (bar_element_pal) and grows the core.
/// ⭐ That split is the whole tell system: SHAPE says what it is, BRIGHTNESS says how soon.
function bar_bullet_parts(_ix, _charge) {
    var _b = bar_bullet_info(_ix);
    var _c = is_undefined(_charge) ? 0 : clamp(_charge, 0, 1);
    var _parts = [];

    var _ring = bar_bullet_outline(_ix, 20);

    // The aura sits UNDER everything and is the only part allowed outside the outline. It is what
    // separates a shot from the field it crosses, so it is drawn first and never skipped.
    var _aura = bar_scale_pts(_ring, 1.34 + _c * 0.14);
    bar_append(_parts, bar_ring_fill(_aura, "aura", 0, 0));

    // The solid body, then its relief. bar_dome shades from the outline's own normals, so the lit
    // side is a property of the geometry rather than a painted highlight.
    //
    // ⛔⛔ THE DOME DEPTH IS PER CLASS, AND A SINGLE DEPTH OF 0.58 SHIPPED A PINWHEEL. MEASURED
    // 2026-09-05 by cropping one pellet out of the corpus sheet at 4x and looking at it: on a
    // CIRCLE every edge normal points radially outward, so a deep dome bands the WHOLE body into
    // radial wedges and a pellet reads as a swirl rather than as a lit ball. The banding is not a
    // bug - bar_relief's header argues correctly that hard bands are what a made object
    // photographs like - it is a bug about HOW MUCH OF THE BODY the bands are allowed to cover.
    //
    // ⭐ ROUND bodies therefore get a shallow rim (a large flat lit face, shaded only at the edge,
    // which is how a sphere actually reads at 8 px) and bodies with a NOSE keep the deep dome,
    // because on those the normals sweep along the length and the bands describe the form.
    //
    // ⚠️ Found by MAGNIFYING, after the eye reported "cogged" at 1x and the argument said the
    // geometry was a clean 40-point circle. Both were true. Wing CLAUDE.md: when your eye and an
    // argument disagree, magnify the pixels.
    var _domeDepth = 0.58;
    if (_b.cl == BAR_CL_ROUND || _b.cl == BAR_CL_RING) _domeDepth = 0.22;
    if (_b.cl == BAR_CL_STAR || _b.cl == BAR_CL_ARCANE) _domeDepth = 0.34;
    bar_append(_parts, bar_ring_fill(_ring, "m3", 0, 0));
    bar_append(_parts, bar_dome(_ring, _domeDepth, 3));
    bar_append(_parts, bar_poly(_ring, true, 0.020, "line"));

    // The core. Grows with charge; this is the "how soon" channel.
    var _cr = 0.085 + 0.075 * _c;
    if (_b.cl == BAR_CL_RING) {
        // A hollow body has no core - it has a bore, and the bore is the silhouette.
        bar_append(_parts, bar_ring_fill(bar_scale_pts(_ring, 0.52), "aura", 0, 0));
        bar_append(_parts, bar_poly(bar_scale_pts(_ring, 0.52), true, 0.016, "line"));
    } else {
        bar_append(_parts, bar_dot(0, 0, _cr, "core"));
    }

    bar_append(_parts, bar_bullet_ornament(_ix, _c));
    return _parts;
}

/// Family ornament. Nine treatments, indexed by the table's `orn`, each doing a different job to
/// the silhouette so two bodies of the same class are told apart by shape and not by hue.
///
/// ⚠️ EVERY ORNAMENT STAYS INSIDE OR ON THE OUTLINE except the STAR points, which ARE the
/// silhouette for that class. bar_shape's clipping header is the reason: a mark that runs off the
/// edge of the form it decorates is the defect a buyer sees in the first shot they fire.
function bar_bullet_ornament(_ix, _c) {
    var _b = bar_bullet_info(_ix);
    var _o = [];
    var _ring = bar_bullet_outline(_ix, 20);

    switch (_b.cl) {
        case BAR_CL_STAR: {
            // ⚠️ THE POINTS ARE THE OUTLINE NOW, NOT AN ORNAMENT. The first version drew a SECOND
            // star on top of the body, which is why the class baked as a blob with a shape inside
            // it. The ornament's job here is only to give the centre a facet so the points read as
            // radiating from something rather than as a flat cut-out.
            var _hub = bar_bullet_outline(_ix, 6);
            bar_append(_o, bar_incise(bar_scale_pts(_hub, 0.44), true, 0.016));
        } break;

        case BAR_CL_FACET: {
            // Facet lines: straight cuts from the nose, which is what makes a cut stone read as
            // cut rather than as a smooth blob at 8 px.
            var _f = 2 + (_b.orn % 3);
            for (var _i = 0; _i < _f; _i++) {
                var _y = -0.22 + 0.44 * ((_i + 1) / (_f + 1));
                bar_append(_o, bar_poly([[-0.30, _y], [0.34, _y * 0.35]], false, 0.014, "m4"));
            }
        } break;

        case BAR_CL_LANCE: {
            // A collar behind the nose. It gives the eye a length cue, which is what tells a
            // player how far a fast shot has actually travelled between two frames.
            var _cx = 0.10 + 0.04 * _b.orn;
            bar_append(_o, bar_poly([[_cx, -0.16], [_cx, 0.16]], false, 0.030, "m4"));
            if (_b.orn >= 3) bar_append(_o, bar_poly([[_cx - 0.09, -0.11], [_cx - 0.09, 0.11]], false, 0.020, "m1"));
        } break;

        case BAR_CL_RING: {
            var _spokes = _b.orn * 2;
            for (var _i = 0; _i < _spokes; _i++) {
                var _a = (_i / max(1, _spokes)) * BAR_TAU;
                bar_append(_o, bar_poly([
                    [cos(_a) * 0.26, sin(_a) * 0.26],
                    [cos(_a) * 0.48, sin(_a) * 0.48]
                ], false, 0.022, "m3"));
            }
        } break;

        case BAR_CL_ARCANE: {
            // A drawn mark rather than a solid: concentric arcs whose gaps carry the identity.
            var _segs = 2 + _b.orn;
            for (var _i = 0; _i < _segs; _i++) {
                var _a0 = (_i / _segs) * BAR_TAU + 0.22;
                var _a1 = _a0 + (BAR_TAU / _segs) - 0.44;
                bar_append(_o, bar_arc(0, 0, 0.38, _a0, _a1, 0.032, "m4"));
            }
            bar_append(_o, bar_ring(0, 0, 0.18, 0.020, "core"));
        } break;

        case BAR_CL_HEAVY: {
            // Banding. A heavy shot has to read as MASS at a glance, and mass is bands.
            for (var _i = 0; _i < 3; _i++) {
                var _x = -0.22 + _i * 0.20;
                bar_append(_o, bar_poly([[_x, -0.30], [_x, 0.30]], false, 0.026, "m1"));
            }
        } break;

        case BAR_CL_ORGAN: {
            // A seam along the body, offset so it is never symmetric - the tell of something
            // grown rather than machined.
            bar_append(_o, bar_poly([[-0.34, 0.06], [0.10, -0.02], [0.36, 0.03]], false, 0.018, "m4"));
        } break;

        default: {
            // ROUND. The ornament index picks a treatment ON the disc, because a round body has
            // no silhouette variation to spend and all its identity is internal.
            if (_b.orn == 1) bar_append(_o, bar_ring(0, 0, 0.34, 0.026, "m4"));
            if (_b.orn == 2) bar_append(_o, bar_ring(0, 0, 0.40, 0.018, "m0"));
            if (_b.orn == 3) bar_append(_o, bar_dot(-0.13, -0.13, 0.075, "m4"));
            if (_b.orn == 4) {
                for (var _i = 0; _i < 8; _i++) {
                    var _a = (_i / 8) * BAR_TAU;
                    bar_append(_o, bar_poly([
                        [cos(_a) * 0.34, sin(_a) * 0.34],
                        [cos(_a) * 0.50, sin(_a) * 0.50]
                    ], false, 0.020, "m3"));
                }
            }
            if (_b.orn == 5) {
                bar_append(_o, bar_ring(0, 0, 0.30, 0.030, "m0"));
                bar_append(_o, bar_dot(0.06, 0, 0.10, "line"));
            }
        } break;
    }
    return _o;
}

/// ============================================================================================
/// THE COUPLING — the reason this product exists
/// ============================================================================================

/// Which body a pattern should fire, given how crowded it is about to be.
///
/// ⭐ THIS FUNCTION IS THE PRODUCT'S HEADLINE CLAIM IN SEVEN LINES. The shelf sells the WIRING
/// (a danmaku framework whose own copy says "all you need is to draw a sprite") and the ART (VFX
/// spritesheets at $19.99-$98, fixed frames that cannot answer to anything). Neither can do this,
/// because it needs the pattern and the picture to be the same object.
///
/// The rule is a legibility rule, not a taste one: the gap between adjacent shots on a ring of
/// radius r with n arms is about TAU*r/n, and a body wider than that gap makes a solid wall. So
/// as arms rise the body must narrow, and past the point where narrowing stops helping it must
/// change CLASS - to LANCE, which is narrow across the ring and long along it, i.e. it spends its
/// area in the direction that has room.
/// ⛔⛔ `_bodyscale` IS NOT OPTIONAL DECORATION - ITS ABSENCE WAS THIS FILE'S WORST BUG AND THE
/// SUITE CAUGHT IT IN ENGINE ON THE FIRST RUN. The first version compared `1.0 / aspect` - a
/// UNIT-BOX width, always about 1.0 - against a gap measured in FIELD units, which at four arms on
/// a wide ring is about 0.87. So a pellet was "too wide" for an almost empty ring, and the
/// function fell through to a javelin every single time: the note it printed read
/// `coupling: 4 arms -> lance, 48 arms -> javelin`, i.e. the coupling appeared to work because the
/// answers differed, while the sparse case was simply wrong.
///
/// ⭐ THIS IS MASTER §2b's UNIT-MISMATCH SHAPE EXACTLY: a unit mismatch into a bounds check FAILS
/// CLOSED and imitates precisely the condition the guard exists for, which is the most convincing
/// disguise available, because the guard is supposed to reject sometimes. It was visible only
/// because the suite prints WHICH body came back at both ends rather than just asserting that the
/// two differ - an assertion that they differ would have passed on this defect forever.
function bar_bullet_for(_arms, _radius, _prefer, _bodyscale) {
    var _gap = (BAR_TAU * max(0.001, _radius)) / max(1, _arms);
    // The drawn width of a body, in the SAME units as the gap: field units.
    var _bs = is_undefined(_bodyscale) ? 0.055 : max(0.001, _bodyscale);
    // Leave at least half a body of clear channel, which is bar_legibility's own crowding bar.
    var _want = _gap / 1.5;
    var _t = bar_bullet_table();
    var _best = is_undefined(_prefer) ? 0 : bar_bullet_find(_prefer);
    if (_best < 0) _best = 0;

    var _widthOf = function(_row, _scale) { return _scale / max(0.35, _row.aspect); };

    // If the preferred body already fits the gap, keep it: the buyer's choice wins when it works.
    if (_widthOf(_t[_best], _bs) <= _want) return _best;

    // Otherwise the narrowest body in the SAME class - a buyer who chose a class chose a look.
    var _cl = _t[_best].cl;
    var _pick = -1;
    var _narrow = 999;
    for (var _i = 0; _i < array_length(_t); _i++) {
        if (_t[_i].cl != _cl) continue;
        var _w = _widthOf(_t[_i], _bs);
        if (_w < _narrow) { _narrow = _w; _pick = _i; }
    }
    if (_pick >= 0 && _narrow <= _want) return _pick;

    // Then LANCE, which spends its area ALONG the ring rather than across it.
    //
    // ⚠️ THE WIDEST LANCE THAT FITS, NOT THE NARROWEST. Taking the narrowest is "safe" and is
    // wrong: it jumps straight from a pellet to a javelin the moment one extra arm is added, so a
    // buyer nudging a number watches the art leap two classes. Picking the widest body that still
    // clears the gap degrades gracefully - pellet, spindle, dart, lance, quill, needle, javelin -
    // which is what makes this read as a design tool rather than a safety clamp.
    var _lancePick = -1;
    var _lanceWidest = -1;
    for (var _i = 0; _i < array_length(_t); _i++) {
        if (_t[_i].cl != BAR_CL_LANCE) continue;
        var _w2 = _widthOf(_t[_i], _bs);
        if (_w2 <= _want && _w2 > _lanceWidest) { _lanceWidest = _w2; _lancePick = _i; }
    }
    if (_lancePick >= 0) return _lancePick;

    // Nothing fits: hand back the narrowest thing in the corpus.
    // ⛔ IT DOES NOT SILENTLY SUCCEED. A pattern too dense to be legible is a DESIGN error the
    // buyer must be told about, and bar_legibility_report is where they are told - this function
    // returns the best available body and the report says it was not enough. A guard that
    // fabricates a passing answer when its search fails is the branch nobody reviews (master §2b).
    var _n2 = -1; var _nw = 999;
    for (var _i = 0; _i < array_length(_t); _i++) {
        var _w3 = _widthOf(_t[_i], _bs);
        if (_w3 < _nw) { _nw = _w3; _n2 = _i; }
    }
    return max(0, _n2);
}
