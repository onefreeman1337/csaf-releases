{
  "$GMScript": "v1",
  "%Name": "bar_bullet",
  "name": "bar_bullet",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}