/// BARRAGE - bar_geom. Part of the shared drawing foundation.
///
/// This file is the studio's cross-product drawing/colour layer, carried forward with over
/// 2,300 in-engine assertions behind it - including the GML default-epsilon fix described
/// below, which had produced a suite of assertions that could never go red.
///
/// ⛔ GML APPLIES A DEFAULT EPSILON TO NUMERIC COMPARISONS, and it is 0.00001 on this runtime
/// - MEASURED by bar_selftest, which prints math_get_epsilon() into its own result file at
/// twelve decimals. Any tolerance at or below about 0.00001 can NEVER fire, in either
/// direction, so a distinctness assertion written that way passes vacuously forever and an
/// equality assertion written that way goes red on two values that are the same object.
/// Never write one here. And GML has no exponent-literal syntax at all: `1e-5` is a lexer
/// error that reads like a bracket bug.
///
/// The five drawing primitives and the helpers that build them.
///
/// Barrage draws every one of its projectiles from data - the body's silhouette from its lobe
/// list, the core from a radius program, the aura from a falloff curve, the trail from a decay
/// envelope, the facing from the velocity that carries it. There is NO sprite, NO spritesheet, NO
/// atlas and NO texture page in this package: `sprites/` does not exist. That is the product's
/// headline claim, it is literally true, and it is the whole reason a shot fired by a WIDER ring
/// gets a THINNER body, at RUNTIME, at any size, instead of being drawn three times in an art tool
/// and hoped at.
///
/// ⭐ AND IT IS THE ONE CLAIM THIS PRODUCT MAKES THAT A SPRITESHEET CANNOT. Change a pattern's
/// arm count from 6 to 24 and every bullet in it narrows, brightens at the core and shortens its
/// trail - because all three are computed from the same number, and a 24-arm ring drawn with
/// 6-arm bodies is an unreadable wall. A painted bullet has no arm count. This is why the shelf's
/// $19.99-$98 VFX spritesheets cannot answer to a pattern and this product can.
///
/// This file produces GEOMETRY and knows nothing about drawing. bar_render turns geometry
/// into draw calls and knows nothing about what a `lace`, a `bloom` or a `graze band`
/// means. Keeping that split clean is what lets the whole corpus be checked before any of it
/// runs in-engine.
///
/// COORDINATES. Two spaces, and keeping them apart is what makes this product composable.
///
/// 1. UNIT-BOX SPACE, [-0.5, 0.5] on both axes, y DOWN, origin at the centre. EVERY PROJECTILE
///    BODY is authored here - a core, an aura ring, a shard, a petal, a lance head. A body's own
///    centre is its TRAVEL ORIGIN, at (0,0), because a bullet turns about the point it is carried
///    by and nothing else; that is what lets bar_place spin one to the heading the pattern solved
///    without the drawing knowing anything about the pattern.
///
/// 2. CELL SPACE, in PIXELS, which is where a finished projectile is DRAWN - a play field, a
///    pattern preview, a sheet cell. bar_render_in_rect_tight maps the unit box into it.
///
/// ⛔ A PROJECTILE *IS* A PICTURE WITH AN ASPECT RATIO, which is exactly why the unit box is right
/// here and was wrong for an interface component. The same shard at 6 px in a dense ring and at
/// 700 px on a store plate is the same drawing at different scales; a button at 40x18 and at
/// 400x180 is not.
///
/// ⛔⛔ AND THAT MAKES ONE INHERITED LAW MORE IMPORTANT HERE THAN ANYWHERE (wing CLAUDE.md, Livery,
/// four instances on one sheet): A PHYSICAL DETAIL BOUNDED ONLY AS A PROPORTION IS WRONG ON THE
/// LARGEST THING YOU DRAW. A core's bright centre is about the same number of pixels across on a
/// pinprick pellet as on a boss's opening shell, and an outline does not get fatter because the
/// bullet did. This package draws the same body at 6 px in a wall of fire and at 800 px on a store
/// sheet, so every detail whose size is PHYSICAL - core radius, rim width, outline weight, graze
/// band - is bounded at BOTH ends: min(proportional, an absolute cap) going up, and a proportional
/// floor going down.
///
/// ⚠️ AND THE FLOOR IS NOT COSMETIC HERE, IT IS THE PRODUCT'S SAFETY RULE. A bullet whose outline
/// falls below one device pixel stops being separable from the field it crosses, and a bullet the
/// player cannot separate from the background is an unfair death. That is the ONE place where this
/// package refuses to scale a detail down, and bar_legibility is where the refusal lives.
///
/// ⚠️ BODY PROPORTION IS THE ONE THING NOT BOUNDED THAT WAY, and it is the exception that proves
/// the rule: a body's aspect is not a decorative detail, it is WHICH BULLET THIS IS. A lance is a
/// splinter because its length multiplier is 3.1 and a pellet is a disc because its is 1.0, so
/// those numbers scale with the drawing and must. Clamping them would silently erase the one
/// relationship this product exists to show.
/// ============================================================================================
#macro BAR_VERSION "1.0.0"

#macro BAR_DOT   0
#macro BAR_ARC   1
#macro BAR_POLY  2
#macro BAR_FILL  3
#macro BAR_STRIP 4

#macro BAR_TAU    6.283185307179586

/// ⚠️ THE DONOR'S FLOOR LINE, KEPT AND REPURPOSED RATHER THAN DELETED.
/// Several products back this was the geological surface every piece stood on. A projectile does
/// not stand on anything - it is carried by a velocity and touches nothing - so here it is the
/// TAIL LINE: the depth past which a body's trail is drawn rather than its solid form, and the
/// strip from BAR_TAIL to +0.5 is reserved for the decaying tail. Free bodies with no trail ignore
/// it entirely; they are centred on their travel origin, which is (0,0).
#macro BAR_TAIL   0.44

/// Kept as an alias so the ported drawing layer's own internal references still resolve. Nothing
/// authored for this product should use either older name - use BAR_TAIL, which says what it
/// means here.
#macro BAR_SEAT   BAR_TAIL
#macro BAR_GROUND BAR_TAIL

/// ============================================================================================
/// PART CONSTRUCTORS
/// ============================================================================================

/// A filled circle.
function bar_dot(_cx, _cy, _r, _role) {
    return { kind: BAR_DOT, cx: _cx, cy: _cy, r: _r, role: _role };
}

/// A sampled, stroked arc. Angles in radians, y-down (angle 0 = +x, pi/2 = down).
function bar_arc(_cx, _cy, _r, _a0, _a1, _w, _role) {
    return { kind: BAR_ARC, cx: _cx, cy: _cy, r: _r, a0: _a0, a1: _a1, w: _w, role: _role };
}

/// A stroked polyline. _pts is an array of [x,y].
function bar_poly(_pts, _closed, _w, _role) {
    return { kind: BAR_POLY, pts: _pts, closed: _closed, w: _w, role: _role };
}

/// A triangle FAN. See the header: the outline must be star-shaped about pts[0].
function bar_fill(_pts, _role) {
    return { kind: BAR_FILL, pts: _pts, role: _role };
}

/// A triangle STRIP between two polylines of equal length.
function bar_strip(_a, _b, _role) {
    return { kind: BAR_STRIP, a: _a, b: _b, role: _role };
}

/// A full stroked circle. An arc, not a primitive of its own - GML's draw_circle outline ignores
/// line width, and width carries meaning across this whole corpus.
function bar_ring(_cx, _cy, _r, _w, _role) {
    return bar_arc(_cx, _cy, _r, 0, BAR_TAU, _w, _role);
}

/// An axis-aligned rectangle as a fan. Convex, so star-shaped about any corner.
function bar_rect_fill(_x0, _y0, _x1, _y1, _role) {
    return bar_fill([[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]], _role);
}

/// An axis-aligned rectangle as a stroked outline.
function bar_rect_poly(_x0, _y0, _x1, _y1, _w, _role) {
    return bar_poly([[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]], true, _w, _role);
}

/// Fill a CLOSED ring of points as a fan from an interior point.
///
/// USE THIS AND NEVER HAND-ROLL IT. A fan walks centre -> p0 -> p1 -> ... -> pN and closes from
/// pN straight back to the centre, so the edge from pN back to p0 is never walked and a wedge of
/// the shape is silently missing. The ring's first point is repeated at the end here. That is the
/// whole fix, and it is why every closed outline in this product is closed.
function bar_ring_fill(_pts, _role, _cx, _cy) {
    var _n = array_length(_pts);
    var _ax = _cx, _ay = _cy;
    if (is_undefined(_ax)) {
        _ax = 0; _ay = 0;
        for (var _i = 0; _i < _n; _i++) { _ax += _pts[_i][0]; _ay += _pts[_i][1]; }
        _ax /= _n; _ay /= _n;
    }
    var _out = array_create(_n + 2);
    _out[0] = [_ax, _ay];
    for (var _i = 0; _i < _n; _i++) _out[_i + 1] = _pts[_i];
    _out[_n + 1] = _pts[0];
    return bar_fill(_out, _role);
}

/// ============================================================================================
/// ARRAY HELPERS
/// ============================================================================================

/// Append every element of _src onto _dst, in place. Returns _dst.
/// Used everywhere instead of array_concat so the allocation pattern is one array per form
/// rather than one per composition step - a full form rebuilt every frame is real garbage.
/// ⛔ A SINGLE PART IS ACCEPTED, AND IT IS NOT TIDINESS. Four builders in this layer return ONE
/// part rather than a list - bar_fill, bar_poly, bar_dot and bar_taper_ribbon - and handing one of
/// those to the loop below asks array_length() about a struct, which answers 0. The part is then
/// dropped with no error, no warning and a perfectly clean compile. MEASURED in this studio's shared drawing layer, on the product it was written for: six call sites were computing geometry and throwing it away, and the only thing that noticed was a single assertion about where one form met the ground. Accepting a bare part is the difference between a defect that shouts and one that does
/// not exist as far as any tool can tell.
function bar_append(_dst, _src) {
    if (!is_array(_src)) { array_push(_dst, _src); return _dst; }
    var _n = array_length(_src);
    for (var _i = 0; _i < _n; _i++) array_push(_dst, _src[_i]);
    return _dst;
}

/// ============================================================================================
/// CURVE SAMPLING - everything curved in this corpus is a sampled polyline, because that is the
/// only curved thing GML draws with an honoured line width.
/// ============================================================================================

/// Quadratic bezier, _n segments, inclusive of both ends.
function bar_qbez(_p0, _p1, _p2, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _t = _i / _n, _u = 1 - _t;
        _out[_i] = [
            _u * _u * _p0[0] + 2 * _u * _t * _p1[0] + _t * _t * _p2[0],
            _u * _u * _p0[1] + 2 * _u * _t * _p1[1] + _t * _t * _p2[1]
        ];
    }
    return _out;
}

/// Points along a circle, inclusive of both ends.
function bar_arc_pts(_cx, _cy, _r, _a0, _a1, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _a = _a0 + (_a1 - _a0) * (_i / _n);
        _out[_i] = [_cx + cos(_a) * _r, _cy + sin(_a) * _r];
    }
    return _out;
}

/// Points along an ellipse, closed (first point NOT repeated).
function bar_ellipse_pts(_cx, _cy, _rx, _ry, _n) {
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = (_i / _n) * BAR_TAU;
        _out[_i] = [_cx + cos(_a) * _rx, _cy + sin(_a) * _ry];
    }
    return _out;
}

/// Points along an ELLIPTICAL arc from _a0 to _a1, endpoints included.
///
/// ⚠️ bar_arc_pts above takes a single radius and is therefore a CIRCULAR arc, and a bullet
/// pattern is a subject where that is USUALLY right and occasionally very wrong. A pellet seen square
/// on is circular and must be: a core drawn as an ellipse would put its bright centre off the axis
/// it travels along and the shot would look bent. But a ring seen in perspective, the mouth of a
/// cone attack, a lance head foreshortened by its own heading and the aura around a shot moving
/// toward the camera are all ELLIPTICAL, and an arc of any of them needs both radii. Reaching for
/// bar_arc_pts silently draws a circle where the form is an ellipse, and the two agree only when
/// _rx happens to equal _ry. Repast paid for this once, drawing a circular arc where an ellipse
/// was meant, and it is the kind of error that looks like a maths bug and is a call-site choice.
///
/// Angles follow the same convention as bar_ellipse_pts, and y grows DOWNWARD: sin(_a) > 0 is the
/// LOWER half of a shape on screen and sin(_a) < 0 is the upper half. The lamp in bar_relief sits
/// up and to the left, so that sign is what decides which half of a body's rim is lit; do not
/// "tidy" it.
function bar_ellipse_arc_pts(_cx, _cy, _rx, _ry, _a0, _a1, _n) {
    var _out = array_create(_n + 1);
    for (var _i = 0; _i <= _n; _i++) {
        var _a = _a0 + (_a1 - _a0) * (_i / _n);
        _out[_i] = [_cx + cos(_a) * _rx, _cy + sin(_a) * _ry];
    }
    return _out;
}

/// Regular polygon / star point ring.
function bar_star_pts(_cx, _cy, _r, _n, _phase) {
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = _phase + (_i / _n) * BAR_TAU;
        _out[_i] = [_cx + cos(_a) * _r, _cy + sin(_a) * _r];
    }
    return _out;
}

/// Offset a polyline sideways by _d, using per-vertex normals.
function bar_offset_pts(_pts, _d) {
    var _n = array_length(_pts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        _out[_i] = [_pts[_i][0] - _dy * _d, _pts[_i][1] + _dx * _d];
    }
    return _out;
}

/// A polyline given real thickness, as a triangle strip. Correct for shapes a fan cannot do.
function bar_ribbon(_pts, _half, _role) {
    return bar_strip(bar_offset_pts(_pts, _half), bar_offset_pts(_pts, -_half), _role);
}

/// A ribbon whose half-width is given PER POINT rather than interpolated between two ends.
///
/// ⛔ THIS IS THE PRIMITIVE THAT MAKES ENGRAVED TONE POSSIBLE, AND ITS ABSENCE IS WHY FOUR ROUNDS
/// OF PARAMETER TUNING FAILED TO FIX THE SHADING. See bar_relief for the argument in
/// full; the short version is that an engraver ramps tone by SWELLING A LINE, not by filling a
/// region and drawing lines of constant weight on top of it. A constant-width stroke can only ever
/// participate in a pattern; a swelling one participates in a gradient. bar_taper_ribbon below is
/// the two-endpoint special case of this and stays because a ribbon tail genuinely does taper
/// monotonically - but tone does not, so it needs the array.
///
/// _w is a half-width per point and must be the same length as _pts. A shorter array is a DEFECT
/// rather than something to pad: it means the caller's two loops disagree, and silently reusing the
/// last width would draw a plausible wrong picture. Asserted rather than tolerated.
function bar_var_ribbon(_pts, _w, _role) {
    var _n = array_length(_pts);
    if (_n < 2 || array_length(_w) != _n) return bar_strip([], [], _role);
    var _a = array_create(_n), _b = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        var _d = _w[_i];
        _a[_i] = [_pts[_i][0] - _dy * _d, _pts[_i][1] + _dx * _d];
        _b[_i] = [_pts[_i][0] + _dy * _d, _pts[_i][1] - _dx * _d];
    }
    return bar_strip(_a, _b, _role);
}

/// A ribbon whose thickness varies along its length, taper from _w0 at the start to _w1 at the
/// end with an optional exponent. A tapered ribbon tail reads as CUT; one of constant width reads
/// as extruded, which is the loudest tell of programmer art.
function bar_taper_ribbon(_pts, _w0, _w1, _role) {
    var _n = array_length(_pts);
    var _a = array_create(_n), _b = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _pts[max(0, _i - 1)], _q = _pts[min(_n - 1, _i + 1)];
        var _dx = _q[0] - _p[0], _dy = _q[1] - _p[1];
        var _len = point_distance(0, 0, _dx, _dy);
        if (_len == 0) _len = 1;
        _dx /= _len; _dy /= _len;
        var _d = lerp(_w0, _w1, _i / max(1, _n - 1));
        _a[_i] = [_pts[_i][0] - _dy * _d, _pts[_i][1] + _dx * _d];
        _b[_i] = [_pts[_i][0] + _dy * _d, _pts[_i][1] - _dx * _d];
    }
    return bar_strip(_a, _b, _role);
}

/// ============================================================================================
/// CLIPPING
///
/// Liang-Barsky: clip a segment to an axis-aligned rectangle. Returns [[x0,y0],[x1,y1]] or
/// undefined. Analytic rather than a scissor rect, because GML's clipping is a surface/viewport
/// operation that does not survive being called from inside a buyer's own draw event - and
/// every bevel quad, incised stroke, facet line and rim highlight must stop at the outline that
/// owns it. A highlight ray that runs off the edge of the core it sits on, and an aura band that
/// carries on past the body it is blended into, are the two reasons this is here - and both are
/// defects a buyer sees in the very first shot they fire.
///
/// ⛔ AND CLIPPING IS NOT THE SAME QUESTION AS SPAN (wing CLAUDE.md, from the donor's donor): a
/// bounding box is only the shape's true width at ONE height. A line drawn across a tapered lance
/// at any other height overhangs it on both sides. Clip to the outline's span AT ITS
/// OWN y - which on this product's bodies is the difference between a shard with a lit edge and a
/// shard with two whiskers.
/// ============================================================================================

function bar_clip_seg(_x0, _y0, _x1, _y1, _rx0, _ry0, _rx1, _ry1) {
    var _t0 = 0, _t1 = 1;
    var _dx = _x1 - _x0, _dy = _y1 - _y0;
    var _p, _q, _r;
    for (var _e = 0; _e < 4; _e++) {
        switch (_e) {
            case 0: _p = -_dx; _q = _x0 - _rx0; break;
            case 1: _p =  _dx; _q = _rx1 - _x0; break;
            case 2: _p = -_dy; _q = _y0 - _ry0; break;
            default: _p = _dy; _q = _ry1 - _y0; break;
        }
        if (_p == 0) {
            if (_q < 0) return undefined;
        } else {
            _r = _q / _p;
            if (_p < 0) {
                if (_r > _t1) return undefined;
                if (_r > _t0) _t0 = _r;
            } else {
                if (_r < _t0) return undefined;
                if (_r < _t1) _t1 = _r;
            }
        }
    }
    return [[_x0 + _t0 * _dx, _y0 + _t0 * _dy], [_x0 + _t1 * _dx, _y0 + _t1 * _dy]];
}

/// ============================================================================================
/// TRANSFORMS
/// ============================================================================================

/// Map one point from unit-box space to form space.
function bar_map_pt(_p, _cx, _cy, _s, _rot) {
    var _x = _p[0] * _s, _y = _p[1] * _s;
    if (_rot != 0) {
        var _c = cos(_rot), _sn = sin(_rot);
        var _nx = _x * _c - _y * _sn;
        _y = _x * _sn + _y * _c;
        _x = _nx;
    }
    return [_cx + _x, _cy + _y];
}

/// Resolve a role through an optional remap struct.
function bar_role(_role, _map) {
    if (is_undefined(_map)) return _role;
    if (variable_struct_exists(_map, _role)) return variable_struct_get(_map, _role);
    return _role;
}

/// Place a unit-box part list at (_cx,_cy) at scale _s.
///
/// STROKE WIDTHS SCALE, WITH A FLOOR IN THE RENDERER. The design corpus originally said the
/// weight was "held constant in screen space rather than scaled" - implemented literally, that
/// makes a card-scale form's strokes 32% of its own width while a hero-scale one's are 6%, so
/// small forms rendered as solid blobs. Constant PROPORTION plus bar_render's 1.0px floor is
/// what the rule was actually reaching for.
function bar_place(_parts, _cx, _cy, _s, _rot, _wscale, _map) {
    var _n = array_length(_parts);
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        var _r = bar_role(_p.role, _map);
        switch (_p.kind) {
            case BAR_DOT: {
                var _q = bar_map_pt([_p.cx, _p.cy], _cx, _cy, _s, _rot);
                _out[_i] = bar_dot(_q[0], _q[1], _p.r * _s, _r);
            } break;
            case BAR_ARC: {
                var _q = bar_map_pt([_p.cx, _p.cy], _cx, _cy, _s, _rot);
                _out[_i] = bar_arc(_q[0], _q[1], _p.r * _s, _p.a0 + _rot, _p.a1 + _rot,
                                   _p.w * _wscale, _r);
            } break;
            case BAR_STRIP: {
                var _na = array_length(_p.a), _nb = array_length(_p.b);
                var _a = array_create(_na), _b = array_create(_nb);
                for (var _k = 0; _k < _na; _k++) _a[_k] = bar_map_pt(_p.a[_k], _cx, _cy, _s, _rot);
                for (var _k = 0; _k < _nb; _k++) _b[_k] = bar_map_pt(_p.b[_k], _cx, _cy, _s, _rot);
                _out[_i] = bar_strip(_a, _b, _r);
            } break;
            case BAR_FILL: {
                var _np = array_length(_p.pts);
                var _pts = array_create(_np);
                for (var _k = 0; _k < _np; _k++) _pts[_k] = bar_map_pt(_p.pts[_k], _cx, _cy, _s, _rot);
                _out[_i] = bar_fill(_pts, _r);
            } break;
            default: {
                var _np = array_length(_p.pts);
                var _pts = array_create(_np);
                for (var _k = 0; _k < _np; _k++) _pts[_k] = bar_map_pt(_p.pts[_k], _cx, _cy, _s, _rot);
                _out[_i] = bar_poly(_pts, _p.closed, _p.w * _wscale, _r);
            } break;
        }
    }
    return _out;
}

/// ============================================================================================
/// SEEDED HASH
///
/// Nothing in this product is random at draw time. The only randomness is a seeded hash of the
/// form's id, so two forms that differ in any property look different and the SAME form never
/// flickers between looks. Never call random() anywhere in this package - a jittered edge that
/// re-jitters every frame is the one bug a buyer will notice immediately and cannot work around.
/// ============================================================================================

/// Exact 32-bit unsigned multiply, done in 16-bit halves.
///
/// GML numbers are doubles. A direct h * 16777619 with h near 2^32 reaches 7.2e16, past the 2^53
/// point where doubles stop being exact - so the hash would silently lose its low bits and two
/// different form ids could collide. Splitting the multiply keeps every intermediate under 2^33.
function bar_mul32(_a, _b) {
    var _al = _a & 0xFFFF;
    var _ah = (_a >> 16) & 0xFFFF;
    var _bl = _b & 0xFFFF;
    var _bh = (_b >> 16) & 0xFFFF;
    var _lo = _al * _bl;
    var _mid = ((_al * _bh) + (_ah * _bl)) & 0xFFFF;
    return (_lo + (_mid << 16)) & 0xFFFFFFFF;
}

/// FNV-1a, 32-bit. Same construction as the authoring-side previewer, so a form looks the same
/// in the engine as it did on the corpus sheet.
function bar_hash32(_s) {
    var _h = 2166136261;
    var _n = string_length(_s);
    for (var _i = 1; _i <= _n; _i++) {
        _h = _h ^ ord(string_char_at(_s, _i));
        _h = bar_mul32(_h, 16777619);
    }
    return _h;
}

/// A deterministic 0..1 generator (Lehmer / MINSTD). The state is a ONE-ELEMENT ARRAY, and that
/// is the whole design: arrays are references in GML, so `bar_rng_next` mutates the caller's
/// state and nothing else, with no binding rules involved.
///
/// ⛔ IT WAS A STRUCT WITH A next() METHOD FIRST, AND THAT BROKE THE PRODUCT'S CENTRAL PROMISE.
/// The in-engine self-test came back with three failures of the form "geometry differs between
/// identical calls" plus an rng sequence that did not match the reference values computed in the
/// authoring previewer. Writing `s = ...` and then `self.s = ...` inside a struct-literal method
/// BOTH failed the same way: generator state was not staying with the generator, so two freshly
/// seeded rngs did not agree on their first draw. A jittered form would have re-jittered itself
/// differently every time anything else drew - which is exactly the bug this file's determinism
/// rule exists to prevent.
///
/// Nothing in the JavaScript preview could have caught it: JS closures capture correctly and have
/// no `self` to get wrong. This is the class of defect that ONLY an in-engine test finds, and it
/// is the reason this wing ships one.
/// ⛔⛔ THE GENERATOR IS WARMED UP, AND SKIPPING THAT MAKES THE FIRST DRAW A LINEAR FUNCTION OF THE
/// SEED. MEASURED 2026-08-31 on this product, and it had already shipped a broken game mechanic.
///
/// This is a Lehmer generator: the first draw is `(seed * 48271 mod 2^31-1) / 2^31-1`. For any run
/// of nearby seeds - which is what every caller in this package uses, `base + index` - that product
/// does not wrap, so the first draw is very nearly a straight line in the seed. In the donor
/// product, across the 440 nearby seeds its suite used, the FIRST DRAW SPANNED ONLY 0.5102 to
/// 0.7358, and a mechanic with a stated 30% chance measured at EXACTLY 0% over 440 trials. Nothing
/// about the code looked wrong, every determinism assertion passed, and the picture was unaffected.
///
/// ⚠️ IT MATTERS HERE FOR A DIFFERENT AND SHARPER REASON. This product seeds a pattern from its
/// catalogue index, so consecutive patterns get consecutive seeds - exactly the run of nearby seeds
/// that breaks. A first draw used to pick a pattern's arm count, its body form or its
/// palette would then be a near-linear function of the index, and forty patterns would
/// come out sorted rather than varied: an entire store sheet of visibly graded, obviously
/// mechanical variation, which is worse than repetition because it looks deliberate.
///
/// Three discards decorrelate it: measured over the same 440 seeds, the first draw then spans
/// 0.0008 to 0.9992 and the barren rate reads 29.8% against the intended 30%.
///
/// ⭐ THE GENERAL FORM, and it is worth carrying to every product in this wing: A SEEDED GENERATOR'S
/// FIRST DRAW IS NOT UNIFORM ACROSS NEARBY SEEDS, so spending it on a RARE-EVENT DECISION makes
/// that event's probability depend on which seed range the caller happened to use. Warm up at the
/// seeding, not at the call site, or the next caller pays for it again.
function bar_rng(_seed) {
    var _s = _seed % 2147483647;
    if (_s <= 0) _s = 1;
    var _st = [_s];
    bar_rng_next(_st);
    bar_rng_next(_st);
    bar_rng_next(_st);
    return _st;
}

/// The next value in 0..1 from a generator made by bar_rng. Every intermediate stays under 2^47,
/// so no precision guard is needed here.
function bar_rng_next(_st) {
    _st[0] = (_st[0] * 48271) % 2147483647;
    return (_st[0] - 1) / 2147483646;
}
