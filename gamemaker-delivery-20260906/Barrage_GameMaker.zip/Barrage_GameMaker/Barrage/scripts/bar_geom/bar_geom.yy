{
  "$GMScript": "v1",
  "%Name": "bar_geom",
  "name": "bar_geom",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}