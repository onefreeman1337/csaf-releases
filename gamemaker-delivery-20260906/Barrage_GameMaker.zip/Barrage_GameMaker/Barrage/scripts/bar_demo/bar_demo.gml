/// bar_demo.gml — the demo room's state machine, with the engine taken out of it.
///
/// ⛔⛔ THIS FILE EXISTS BECAUSE THE DEMO ROOM'S INPUT HANDLING HAD NEVER EXECUTED, IN ANY RUN, EVER.
/// The suite runs headless through `-selftest`, which exits inside Create before the room starts, and
/// the store sheets bake through `-bake`, which exits in the same place. So the ONLY code path a
/// buyer touches first - press a key, watch the pattern change - was the one path with zero
/// coverage, on a product whose quickstart is "open the demo room and press D".
///
/// ⭐ THE REASON IT COULD NOT BE TESTED IS THE REASON IT WAS WRONG TO WRITE THAT WAY: Step_0 read
/// the keyboard and mutated state in the same expression, so there was no seam to test at. Nothing
/// here calls keyboard_check, nothing here draws, and nothing here reads delta_time - the caller
/// supplies all three as plain values. That makes every transition assertable from the headless
/// suite, and it is the same separation that made the store sheets' text fitting checkable.
///
/// ⚠️ THE POINT IS NOT THAT INPUT IS "HARD TO TEST". It is that an untested path is where defects
/// live, and this wing has a receipt one product over: gm-liege shipped six dead font references
/// through a CLEAN compiler gate and a 164-assertion suite, because not one assertion drew a string.
/// A large pass count over a subsystem with no coverage is not evidence about that subsystem.

/// A blank input frame. Every field defaults to "not pressed", so a caller - or a test - only has
/// to name the keys it means.
///
/// ⚠️ PRESSED vs HELD IS PART OF THE CONTRACT, NOT AN IMPLEMENTATION DETAIL. The scrub keys repeat
/// every frame while held because a buyer tuning a boss wants to crawl frame by frame; the pattern
/// and element keys fire once per press because holding them would flick through twelve families in
/// a fifth of a second. The suite asserts both behaviours, since "it advanced" is equally true of
/// the version that advances twelve times.
function bar_demo_input() {
    return {
        pause: false, hitbox: false,
        next: false, prev: false,
        elemUp: false, elemDown: false,
        reset: false,
        scrubBack: false, scrubFwd: false,      // HELD, not pressed
    };
}

/// The demo's whole state. A struct rather than instance variables, so the suite can make one
/// without a room, an instance or a running game.
function bar_demo_state() {
    return {
        pattern: BAR_PAT_RING,
        element: 0,
        body:    bar_bullet_find("pellet"),
        t:       0,
        paused:  false,
        hitbox:  true,
        report:  "",
    };
}

/// The scrub step, in seconds of pattern time per frame held.
#macro BAR_DEMO_SCRUB 0.01

/// Advance the demo by one frame.
///
/// `_dt` is elapsed seconds. The caller passes `delta_time / 1000000`; the suite passes whatever it
/// wants to assert about, which is the entire benefit.
function bar_demo_step(_st, _in, _dt) {
    if (_in.pause)  _st.paused = !_st.paused;
    if (_in.hitbox) _st.hitbox = !_st.hitbox;

    // ⚠️ WRAPPING ADDS THE COUNT BEFORE THE MODULO. `(_p - 1) % N` is negative in GML for _p = 0,
    // and a negative pattern index reads a table row that does not exist - which is a crash on the
    // very first LEFT press from the default state, i.e. the most likely single keystroke a buyer
    // who opens the demo and pushes the wrong arrow will produce.
    if (_in.next) { _st.pattern = (_st.pattern + 1) % BAR_PATTERN_COUNT; _st.t = 0; }
    if (_in.prev) { _st.pattern = (_st.pattern + BAR_PATTERN_COUNT - 1) % BAR_PATTERN_COUNT; _st.t = 0; }

    if (_in.elemUp)   _st.element = (_st.element + 1) % BAR_ELEMENT_COUNT;
    if (_in.elemDown) _st.element = (_st.element + BAR_ELEMENT_COUNT - 1) % BAR_ELEMENT_COUNT;

    if (_in.reset) _st.t = 0;

    // Scrubbing is deliberately allowed while running, and is clamped at zero rather than wrapping:
    // a buyer crawling backwards past the start wants to stop at the start, not jump to the end.
    if (_in.scrubBack) _st.t = max(0, _st.t - BAR_DEMO_SCRUB);
    if (_in.scrubFwd)  _st.t += BAR_DEMO_SCRUB;

    var _spec = bar_pattern_preset(_st.pattern);
    _st.body = bar_bullet_for(_spec.arms, 0.9, "pellet", 0.055);

    if (!_st.paused) _st.t += _dt;

    // Loop rather than letting the pattern run empty: a demo room that goes blank reads as broken.
    var _span = _spec.gap * _spec.waves + 3.2;
    if (_st.t > _span) _st.t = 0;

    _st.report = bar_legibility_line(
        bar_legibility_report(_spec, _st.element, _st.body, 0.055, 0.12, 0.26));
    return _spec;
}

/// The demo's field, alone.
///
/// ⛔ DELIBERATELY NOT BLACK. bar_legibility measures the shot against this ramp, and the whole
/// reason that check exists is that this wing once spent five bakes tuning a dark mark on an
/// almost-black floor, where it was invisible BY CONSTRUCTION and no amount of changing the mark
/// could ever have shown up. The demo draws a field the bullets can be seen against, and prints the
/// measurement so a buyer can see it too.
///
/// ⚠️ SPLIT OUT SO THE STORE SHEET'S INK CHECK CAN DIFF AGAINST THE RIGHT BACKGROUND. That check
/// compares a rendered sheet to a background-only reference, and it has already been wrong once in
/// exactly this way: when it diffed against a flat colour while a RAMP was painted over the page,
/// every pixel differed and it reported "full page, clipped" on all five sheets - an instrument
/// that could not fail. A sheet painting its own field needs its own reference, from this function,
/// so the two cannot drift apart.
function bar_demo_field(_w, _h) {
    bar_render_ramp(0, 0, _w, _h,
        [bar_oklch(0.12, 0.030, 250), bar_oklch(0.19, 0.035, 246), bar_oklch(0.26, 0.030, 242)],
        [0.55, 0.30, 0.15]);
}

/// Draw the demo, whole, into the current target at the given size.
///
/// ⛔⛔ THE STORE SHEET AND THE DEMO ROOM ARE THIS ONE FUNCTION. They used to be two copies of the
/// same drawing code - the room's Draw event, and nothing at all on the gallery, because the
/// gallery had no picture of the product in use. Adding one as a SECOND implementation is the
/// defect this wing keeps paying for (a second copy of a value does not drift, it wins), and it is
/// worse here than usual: the copy that would go stale is the one a buyer decides from, and a store
/// image that no longer matches the product is a false claim rather than a bug.
///
/// ⭐ SO THE GALLERY SHOT IS A PICTURE OF THE DEMO ROOM BY CONSTRUCTION. Changing the demo changes
/// the sheet, and there is no arrangement of edits that lets them disagree.
///
/// ⚠️ `_w`/`_h` are passed rather than read from the display, because the bake renders at page size
/// and the room renders at GUI size. Reading the display here would silently pin the sheet to
/// whatever the window happened to be.
function bar_demo_draw(_st, _spec, _w, _h) {
    var _pal = bar_element_pal(_st.element, 0);

    bar_demo_field(_w, _h);

    var _cx = _w * 0.5;
    var _cy = _h * 0.52;
    var _unit = min(_w, _h);          // 1.0 field unit = the short side
    var _bs = _unit * 0.055;          // body draw size

    // The emitter, so the pattern has a visible origin.
    bar_render_parts([
        bar_dot(0, 0, 0.42, "m1"),
        bar_ring(0, 0, 0.46, 0.05, "line"),
        bar_dot(0, 0, 0.16, "core"),
    ], _pal, _cx, _cy, _unit * 0.035, 0, 1, undefined);

    // Every live shot, drawn from geometry at its own heading.
    //
    // ⛔ ROTATED BY THE SHOT'S HEADING, NOT DRAWN FLAT. A body has a nose; a pattern fires the same
    // body at every heading on the circle at once. This single line is the thing a spritesheet
    // cannot do without 360 frames per body per palette, and it is why the product draws instead
    // of bakes.
    var _live = bar_pattern_live(_spec, _st.t);
    for (var _i = 0; _i < array_length(_live); _i++) {
        var _s = _live[_i];
        var _sp = bar_element_pal(_st.element, _s.charge);
        bar_render_parts(bar_bullet_parts(_st.body, _s.charge), _sp,
            _cx + _s.x * _unit, _cy + _s.y * _unit,
            _bs, _s.heading, 1, undefined);
        if (_st.hitbox) {
            bar_render_parts(bar_legibility_parts(true), _sp,
                _cx + _s.x * _unit, _cy + _s.y * _unit, _bs, 0, 1, undefined);
        }
    }

    // -- The readout --------------------------------------------------------------------------
    //
    // ⭐ THE READOUT SITS ON ITS OWN GROUND, AND FOR THIS PRODUCT THAT IS NOT A COSMETIC CHOICE.
    // The shots are drawn UNDER it and a dense wave puts a hundred bright bodies straight through
    // the text; measured on the store GIF at 57 arms, the line naming the arm count had a ring
    // crossing it and was genuinely hard to read. A package whose entire argument is that an
    // unreadable mark is a defect cannot ship a readout that its own bullets obscure - it would be
    // the failure this product sells the cure for, committed against its own interface.
    //
    // ⚠️ ALPHA IS SAVED AND RESTORED. bar_render's part path deliberately has no alpha at all, so
    // anything that sets it here must put it back or the next body drawn inherits it.
    // ⚠️ DERIVED FROM THE LAYOUT BELOW, NOT GUESSED. The block runs: title at y=18 (34 tall), the
    // family line at 66, the stats line at 92, then the report from 116 at 20 per line. So the last
    // baseline is 116 + n*20 and the panel needs that plus a little air. The first version used a
    // made-up 96 + n*20 and cut the legibility line exactly in half - which is the one line on this
    // screen that must never be hard to read.
    // ⛔ THE PANEL IS OPAQUE, AND THAT IS A MEASURED DECISION RATHER THAN A STYLE ONE.
    // A semi-transparent fill was tried twice and both times rendered LIGHTER than the field it was
    // drawn over: `bar_oklch(0.09,…)` at 0.72, then `c_black` at 0.62 — and a black fill at any
    // alpha cannot be lighter than its destination under normal blending, so the model was wrong,
    // not the colour.
    //
    // ⭐ THE POSITIVE CONTROL SETTLED IT IN ONE BAKE and is worth recording because it is the move
    // CLAUDE.md §2b prescribes for exactly this shape: the same rectangle drawn OPAQUE LIME came out
    // bright green, at the right place and the right size. So the colour is honoured, the geometry
    // is right, and the anomaly lives specifically in ALPHA BLENDING onto this surface.
    //
    // ⚠️ THE CAUSE IS UNDETERMINED AND IS DELIBERATELY NOT GUESSED AT HERE. Two plausible stories
    // (a blend mode left set upstream; the surface's own alpha channel being composited onto white
    // by surface_save, which is a defect family this factory has recorded elsewhere) both fit and
    // NEITHER WAS TESTED. Writing one of them down as fact is the second-order failure §2b names —
    // a cause promoted to doctrine before the run that would falsify it was looked at. What is
    // MEASURED is: opaque works, alpha does not, and an opaque panel is what a readout wants anyway.
    //
    // ⚠️ AND IT IS ONLY AS WIDE AS THE TEXT. A full-width bar is unremarkable at the demo's 800px
    // and a grey stripe across a 1600px store sheet; the panel belongs to the readout, so it is
    // sized by the readout.
    var _reportLines = array_length(string_split(_st.report, "\n"));
    var _panelH = 124 + _reportLines * 20;
    var _panelW = min(_w - 24, 780);
    var _a0 = draw_get_alpha();
    draw_set_colour(bar_oklch(0.10, 0.022, 250));
    draw_rectangle(0, 0, _panelW, _panelH, false);
    draw_set_colour(bar_oklch(0.34, 0.030, 248));
    draw_rectangle(0, _panelH, _panelW, _panelH + 1, false);
    draw_rectangle(_panelW, 0, _panelW + 1, _panelH, false);
    draw_set_alpha(_a0);
    draw_set_colour(c_white);
    //
    // ⛔⛔ THIS TITLE WAS DRAWN WITH bar_text_fit AND RENDERED AS "AGE 1.0.0" — "BARR" OFF THE LEFT
    // EDGE — IN EVERY BUILD OF THE DEMO ROOM UNTIL 2026-09-05. bar_text_fit sets fa_center, so the
    // `24` is the CENTRE of the string, not its left margin, and more than half the word hung off
    // the page. bar_text_label is the left-anchored twin and exists for exactly this reason; its
    // own header in bar_render.gml records the same defect being paid for on a sibling product,
    // and bar_bake's title helper records it being paid for a second time on the store sheets.
    //
    // ⭐ IT SURVIVED BECAUSE NOTHING EVER PHOTOGRAPHED THE DEMO ROOM. The suite exits in Create,
    // the bake exited in Create, and no gallery image showed the room — so the one defect sitting
    // on the first screen a buyer sees was in the only place nothing looked. It was found within
    // minutes of the in-use sheet existing, by the ink check reporting the content box starting at
    // x=0 and by opening the PNG.
    draw_set_font(fnt_barrage_title);
    bar_text_label("BARRAGE " + BAR_VERSION, 24, 18, _w - 48, 34,
        bar_oklch(0.10, 0.02, 250), bar_oklch(0.94, 0.02, 250));

    draw_set_font(fnt_barrage);
    var _y = 66;
    bar_text_line(string_upper(bar_pattern_name(_spec.fam)) + "  -  "
        + bar_pattern_table()[_spec.fam].asks, 24, _y, _w - 48, 18,
        bar_oklch(0.88, 0.03, 250), true);
    _y += 26;
    bar_text_line("element " + _pal.name + "   body " + bar_bullet_info(_st.body).name
        + "   arms " + string(_spec.arms) + "   live " + string(array_length(_live))
        + "   t " + string_format(_st.t, 1, 2), 24, _y, _w - 48, 16,
        bar_oklch(0.76, 0.02, 250), false);
    _y += 24;

    // The legibility report, on screen, always. A buyer should not have to call an API to find out
    // that their pattern cannot be read.
    var _lines = string_split(_st.report, "\n");
    for (var _i = 0; _i < array_length(_lines); _i++) {
        bar_text_line(_lines[_i], 24, _y, _w - 48, 15, bar_oklch(0.70, 0.04, 250), false);
        _y += 20;
    }

    // ⛔ A/D WERE MISSING FROM THIS LINE UNTIL 2026-09-05, AND THE DEMO HAS ALWAYS ACCEPTED THEM.
    // Found by check_demo_input_map.js on its first run: Step_0 reads ord("A") and ord("D") as
    // alternatives to the arrow keys and the legend named only the arrows, so the WASD half of the
    // controls existed and was undiscoverable. An unadvertised key is a feature nobody finds.
    bar_text_line("left/right or A/D pattern   up/down element   Q/E scrub   space pause   "
        + "H hitbox   R reset",
        24, _h - 30, _w - 48, 14, bar_oklch(0.62, 0.02, 250), false);

    return array_length(_live);
}
