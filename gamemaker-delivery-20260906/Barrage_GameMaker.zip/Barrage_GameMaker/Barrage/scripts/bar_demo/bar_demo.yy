{
  "$GMScript": "v1",
  "%Name": "bar_demo",
  "name": "bar_demo",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}