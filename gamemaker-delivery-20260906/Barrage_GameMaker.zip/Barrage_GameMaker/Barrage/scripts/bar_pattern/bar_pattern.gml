/// BARRAGE - bar_pattern. The pattern algebra.
///
/// A PATTERN IS A PURE FUNCTION FROM (wave index, shot index) TO A SHOT, and that is the single
/// most important design decision in this package.
///
/// -- WHY PURE ---------------------------------------------------------------------------------
/// ⛔ THE OBVIOUS DESIGN IS AN EMITTER OBJECT THAT SPAWNS INSTANCES ON A TIMER, AND IT IS WRONG
/// FOR THREE MEASURABLE REASONS.
///   1. IT CANNOT BE TESTED. GML cannot be unit-tested outside the engine (wing CLAUDE.md §3), so
///      the only verification this wing has is an in-engine suite - and a suite cannot assert
///      anything about a shot that only exists after a spawn, a step and a collision pass. A pure
///      function can be asked for shot 900 of wave 40 with no clock running, which is why
///      bar_selftest can make thousands of assertions about patterns that never spawn anything.
///   2. IT CANNOT BE PREVIEWED. bar_bake draws a store sheet of whole patterns frozen at a chosen
///      time. With a spawner you can only photograph what happens to be on screen.
///   3. IT CANNOT BE REWOUND. A buyer tuning a boss needs to see t=2.4s immediately, not play to
///      it. Every function here takes _t and returns where the shot IS, so scrubbing is free.
///
/// ⭐ AND IT IS WHAT MAKES THE ART COUPLING POSSIBLE AT ALL. bar_bullet_for needs to know how
/// crowded a ring will BE before a single shot is drawn. With a spawner that is unknowable until
/// it has already happened; here it is the arm count, which is an argument.
///
/// -- THE FAMILIES ------------------------------------------------------------------------------
/// Twelve, and they are separated by what the PLAYER has to do about them, not by their maths:
/// a ring is "move off the axis", a spiral is "keep moving", a wall is "find the gap", an aimed
/// shot is "stop standing still". Two families that ask the same question of the player are the
/// same family with different numbers, however different the equations look.
/// ============================================================================================

#macro BAR_PAT_RING     0
#macro BAR_PAT_FAN      1
#macro BAR_PAT_SPIRAL   2
#macro BAR_PAT_AIMED    3
#macro BAR_PAT_LACE     4
#macro BAR_PAT_WALL     5
#macro BAR_PAT_RAIN     6
#macro BAR_PAT_BLOOM    7
#macro BAR_PAT_CONVERGE 8
#macro BAR_PAT_WHIP     9
#macro BAR_PAT_HOMING   10
#macro BAR_PAT_ARC      11

#macro BAR_PATTERN_COUNT 12

/// Name, and the question the family asks the player. The second half is not decoration: it is
/// the thing that stops the corpus growing three families that are one family.
function bar_pattern_table() {
    return [
        { name: "ring",     asks: "move off the axis" },
        { name: "fan",      asks: "read the spread and pick a side" },
        { name: "spiral",   asks: "keep moving, one direction" },
        { name: "aimed",    asks: "stop standing still" },
        { name: "lace",     asks: "find the moving gap" },
        { name: "wall",     asks: "find the fixed gap, now" },
        { name: "rain",     asks: "watch a second axis" },
        { name: "bloom",    asks: "leave before it opens" },
        { name: "converge", asks: "do not go to the middle" },
        { name: "whip",     asks: "the safe side is changing" },
        { name: "homing",   asks: "break line of sight" },
        { name: "arc",      asks: "duck under, or go over" },
    ];
}

function bar_pattern_name(_fam) {
    var _t = bar_pattern_table();
    var _n = array_length(_t);
    return _t[((_fam % _n) + _n) % _n].name;
}

/// A pattern spec. Everything a buyer tunes lives here and nothing else does.
///
/// arms    how many shots per wave. THE headline number: bar_bullet_for reads it to pick a body.
/// waves   how many waves the pattern fires
/// spin    degrees the whole pattern rotates between waves (what makes a ring a spiral)
/// spread  degrees the arms span. TAU for a full ring, less for a fan
/// speed   units per second at wave start
/// accel   units per second per second
/// gap     seconds between waves
/// aim     heading in degrees the pattern is pointed at
/// jitter  per-shot randomisation, 0 for a clean pattern
function bar_pattern_spec(_fam, _arms, _waves, _spin, _spread, _speed, _accel, _gap, _aim, _jitter) {
    return {
        fam:    is_undefined(_fam)    ? BAR_PAT_RING : _fam,
        arms:   max(1, is_undefined(_arms)   ? 12   : _arms),
        waves:  max(1, is_undefined(_waves)  ? 5    : _waves),
        spin:   is_undefined(_spin)   ? 0     : _spin,
        spread: is_undefined(_spread) ? 360   : _spread,
        speed:  is_undefined(_speed)  ? 0.32  : _speed,
        accel:  is_undefined(_accel)  ? 0     : _accel,
        gap:    max(0.016, is_undefined(_gap) ? 0.35 : _gap),
        aim:    is_undefined(_aim)    ? 0     : _aim,
        jitter: is_undefined(_jitter) ? 0     : _jitter,
    };
}

/// ⛔ SEEDED, NEVER `random()`. Two calls asking for the same shot MUST return the same shot, or
/// the pure-function property above is a lie and every assertion in bar_selftest is meaningless.
/// The seed is derived from the shot's own identity so it is stable under scrubbing.
function bar_pattern_jitter(_spec, _wave, _shot, _salt) {
    if (_spec.jitter <= 0) return 0;
    var _st = bar_rng(bar_hash32(string(_wave) + ":" + string(_shot) + ":" + string(_salt)));
    return (bar_rng_next(_st) - 0.5) * 2 * _spec.jitter;
}

/// ============================================================================================
/// THE SHOT
/// ============================================================================================

/// Where shot _shot of wave _wave is at time _t seconds, and what it looks like.
///
/// Returns { x, y, hx, hy, heading, born, alive, charge } in FIELD units where the emitter is at
/// (0,0) and 1.0 is the field's short side. `hx,hy` is the unit heading, which is what a body is
/// rotated by - a body has a nose and the nose must point where the shot is going.
///
/// ⚠️ `alive` IS FALSE BEFORE THE SHOT IS BORN AS WELL AS AFTER IT LEAVES. Two different reasons,
/// one flag, and callers that treat "not alive" as "gone" will draw wave 5 at t=0. bar_selftest
/// asserts both directions because a pattern that fires everything on frame one is exactly the
/// bug that looks like a working pattern in a screenshot.
function bar_pattern_shot(_spec, _wave, _shot, _t) {
    var _born = _wave * _spec.gap;
    var _age = _t - _born;
    var _alive = (_age >= 0);

    // Where this arm points. The spread is centred on the aim so a fan is symmetric about it.
    var _n = _spec.arms;
    var _span = degtorad(_spec.spread);
    var _base = degtorad(_spec.aim) + degtorad(_spec.spin) * _wave;
    var _frac = (_n <= 1) ? 0.5 : (_shot / (_n - (_span >= BAR_TAU - 0.001 ? 0 : 1)));
    var _a = _base - _span * 0.5 + _span * _frac
           + degtorad(bar_pattern_jitter(_spec, _wave, _shot, "a"));

    var _speed = _spec.speed * (1 + bar_pattern_jitter(_spec, _wave, _shot, "s") * 0.01);
    var _r = 0;
    if (_alive) _r = _speed * _age + 0.5 * _spec.accel * _age * _age;

    var _x = cos(_a) * _r;
    var _y = sin(_a) * _r;
    var _hx = cos(_a);
    var _hy = sin(_a);

    switch (_spec.fam) {
        case BAR_PAT_LACE: {
            // Two counter-rotating sets interleaved. The gap MOVES, which is the whole question
            // this family asks, and it is why the sign flips on odd shots rather than on odd waves.
            var _dir = ((_shot % 2) == 0) ? 1 : -1;
            var _sw = _dir * _age * 1.10;
            _x = cos(_a + _sw) * _r;
            _y = sin(_a + _sw) * _r;
            _hx = cos(_a + _sw); _hy = sin(_a + _sw);
        } break;

        case BAR_PAT_WALL: {
            // A line advancing along the aim, with one arm removed to make the gap. Position is
            // ACROSS the aim, travel is ALONG it.
            var _across = ((_n <= 1) ? 0 : (_shot / (_n - 1)) - 0.5) * 1.6;
            var _ax = cos(_base), _ay = sin(_base);
            var _px = -_ay, _py = _ax;
            _x = _px * _across + _ax * _r;
            _y = _py * _across + _ay * _r;
            _hx = _ax; _hy = _ay;
        } break;

        case BAR_PAT_RAIN: {
            // Falls along the aim, offset across it, each column starting at its own time. The
            // second axis is the point: a player watching only left-right dies to this.
            var _col = ((_n <= 1) ? 0 : (_shot / (_n - 1)) - 0.5) * 1.8;
            var _lag = bar_pattern_jitter(_spec, _wave, _shot, "r") * 0.5;
            var _ax2 = cos(_base), _ay2 = sin(_base);
            var _px2 = -_ay2, _py2 = _ax2;
            var _rr = max(0, _speed * (_age - abs(_lag)));
            _x = _px2 * _col + _ax2 * _rr;
            _y = _py2 * _col + _ay2 * _rr;
            _hx = _ax2; _hy = _ay2;
        } break;

        case BAR_PAT_BLOOM: {
            // Travels closed, then opens. The tell is the opening, so `charge` is what a player
            // reads and the geometry stays identical until it fires.
            var _open = max(0, _age - _spec.gap * 1.5);
            var _rr2 = _speed * min(_age, _spec.gap * 1.5) + _open * _speed * 2.2;
            _x = cos(_a) * _rr2; _y = sin(_a) * _rr2;
            _hx = cos(_a); _hy = sin(_a);
        } break;

        case BAR_PAT_CONVERGE: {
            // Starts wide and comes IN. The safe place is where a player instinctively runs.
            var _r0 = 1.25;
            var _rr3 = max(0, _r0 - _speed * _age);
            _x = cos(_a) * _rr3; _y = sin(_a) * _rr3;
            _hx = -cos(_a); _hy = -sin(_a);
        } break;

        case BAR_PAT_WHIP: {
            // The arm sweeps while the shot travels, so later shots in a wave leave later AND
            // from a different angle. The safe side changes under the player's feet.
            var _sweep = degtorad(_spec.spin) * _age * 1.6;
            _x = cos(_a + _sweep) * _r; _y = sin(_a + _sweep) * _r;
            _hx = cos(_a + _sweep); _hy = sin(_a + _sweep);
        } break;

        case BAR_PAT_ARC: {
            // Thrown: constant cross-axis drift, so the path bends. Duck under or go over.
            var _drop = 0.45 * _age * _age;
            var _ax3 = cos(_a), _ay3 = sin(_a);
            _x = _ax3 * _r - _ay3 * _drop;
            _y = _ay3 * _r + _ax3 * _drop;
            var _dx = _ax3 * _speed - _ay3 * 0.9 * _age;
            var _dy = _ay3 * _speed + _ax3 * 0.9 * _age;
            var _dl = max(0.00001, sqrt(_dx * _dx + _dy * _dy));
            _hx = _dx / _dl; _hy = _dy / _dl;
        } break;
    }

    // The charge tell. bar_bullet reads it to grow the core and bar_element to slide the ramp;
    // the SILHOUETTE never changes, so one learned shape holds across every element.
    var _charge = 0;
    if (!_alive) _charge = clamp(1 + (_age / max(0.0001, _spec.gap)), 0, 1);
    else if (_spec.fam == BAR_PAT_BLOOM) _charge = clamp(1 - (_age / max(0.0001, _spec.gap * 1.5)), 0, 1);

    return {
        x: _x, y: _y, hx: _hx, hy: _hy,
        heading: radtodeg(arctan2(_hy, _hx)),
        born: _born, age: _age, alive: _alive, charge: _charge,
        r: sqrt(_x * _x + _y * _y),
    };
}

/// How far from the emitter this pattern's leading edge is at _t. Used by bar_bullet_for to pick
/// a body, and by bar_legibility to measure crowding at the radius that actually matters.
function bar_pattern_radius(_spec, _t) {
    var _r = 0;
    for (var _w = 0; _w < _spec.waves; _w++) {
        var _s = bar_pattern_shot(_spec, _w, 0, _t);
        if (_s.alive && _s.r > _r) _r = _s.r;
    }
    return _r;
}

/// Every live shot at _t, as an array. The one call a buyer's draw event needs.
///
/// ⚠️ IT RETURNS AN ARRAY AND THE CALLER OWNS IT. Building one array per frame for a 24x5 pattern
/// is 120 structs, which is real garbage - a buyer drawing at 60fps should hoist this. Said out
/// loud here because a generator that hides its allocation is a profiler surprise with a nice API
/// on top.
function bar_pattern_live(_spec, _t) {
    var _out = [];
    for (var _w = 0; _w < _spec.waves; _w++) {
        for (var _i = 0; _i < _spec.arms; _i++) {
            var _s = bar_pattern_shot(_spec, _w, _i, _t);
            if (_s.alive && _s.r <= 1.9) array_push(_out, _s);
        }
    }
    return _out;
}

/// A named preset. Twelve, one per family, tuned so each reads as its own question.
function bar_pattern_preset(_fam) {
    switch (((_fam % BAR_PATTERN_COUNT) + BAR_PATTERN_COUNT) % BAR_PATTERN_COUNT) {
        case BAR_PAT_RING:     return bar_pattern_spec(BAR_PAT_RING,     16, 5, 11, 360, 0.30, 0,     0.34, 0, 0);
        case BAR_PAT_FAN:      return bar_pattern_spec(BAR_PAT_FAN,       7, 4,  0,  62, 0.42, 0,     0.28, 90, 0);
        case BAR_PAT_SPIRAL:   return bar_pattern_spec(BAR_PAT_SPIRAL,    4, 14, 31, 360, 0.34, 0,     0.10, 0, 0);
        case BAR_PAT_AIMED:    return bar_pattern_spec(BAR_PAT_AIMED,     3, 6,  0,  16, 0.58, 0.10,  0.22, 90, 0);
        case BAR_PAT_LACE:     return bar_pattern_spec(BAR_PAT_LACE,     14, 6,  7, 360, 0.26, 0,     0.30, 0, 0);
        case BAR_PAT_WALL:     return bar_pattern_spec(BAR_PAT_WALL,     11, 4,  0, 360, 0.36, 0,     0.42, 90, 0);
        case BAR_PAT_RAIN:     return bar_pattern_spec(BAR_PAT_RAIN,     13, 7,  0, 360, 0.40, 0,     0.20, 90, 0.6);
        case BAR_PAT_BLOOM:    return bar_pattern_spec(BAR_PAT_BLOOM,    10, 3,  0, 360, 0.22, 0,     0.55, 0, 0);
        case BAR_PAT_CONVERGE: return bar_pattern_spec(BAR_PAT_CONVERGE, 18, 3,  5, 360, 0.30, 0,     0.50, 0, 0);
        case BAR_PAT_WHIP:     return bar_pattern_spec(BAR_PAT_WHIP,      6, 9, 24, 360, 0.32, 0,     0.14, 0, 0);
        case BAR_PAT_HOMING:   return bar_pattern_spec(BAR_PAT_HOMING,    5, 5,  0, 200, 0.28, 0.06,  0.30, 0, 0);
        default:               return bar_pattern_spec(BAR_PAT_ARC,       9, 5,  0, 120, 0.44, 0,     0.26, 0, 0);
    }
}
