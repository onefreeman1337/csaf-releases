{
  "$GMScript": "v1",
  "%Name": "bar_pattern",
  "name": "bar_pattern",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}