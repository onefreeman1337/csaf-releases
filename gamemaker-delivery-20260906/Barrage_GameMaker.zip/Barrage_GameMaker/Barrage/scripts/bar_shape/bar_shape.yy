{
  "$GMScript": "v1",
  "%Name": "bar_shape",
  "name": "bar_shape",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}