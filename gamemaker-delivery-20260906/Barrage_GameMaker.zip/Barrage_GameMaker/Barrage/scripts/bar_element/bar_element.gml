/// BARRAGE - bar_element. The element ramps every projectile is drawn through.
///
/// An element is not a colour, it is a five-stop RAMP plus the two accents that sit outside it:
/// the CORE (the hot centre, brighter than m4) and the AURA (the outermost falloff, which is
/// allowed to be darker AND more chromatic than m0 because it is what the body sits inside).
///
/// bar_palette owns the colour MATHS; this file owns Barrage's own ramps and nothing else.
///
/// -- WHY A RAMP AND NOT A TINT ---------------------------------------------------------------
/// ⛔ THIS IS A SAFETY PROPERTY IN THIS GENRE, NOT A STYLE CHOICE. A player reads a bullet
/// against three things at once: the field behind it, the other bullets around it, and their own
/// ship. A tint gives one colour and leaves all three to luck. A ramp lets bar_relief put the lit
/// flank, the shadowed flank and the rim on DIFFERENT stops, so the body has an internal edge -
/// and an internal edge is what survives being one of a hundred overlapping shapes.
///
/// ⭐ THE SEPARATION FLOOR IS THE ASSERTION THAT MAKES THAT CLAIM MEAN ANYTHING. Every adjacent
/// pair of stops in every element below is required to differ by at least BAR_STOP_FLOOR in
/// Oklab L, and bar_selftest checks all of them. Without it an element can be authored that looks
/// fine in isolation and renders as a flat disc the moment two of them overlap - which is exactly
/// the failure a static spritesheet cannot have and a generated corpus can.
///
/// ⚠️ AND THE FLOOR IS CHECKED IN L, NOT IN RGB DISTANCE, for the reason bar_palette's header
/// gives: RGB distance says a saturated blue and a saturated green are far apart when a player
/// scanning a screen at speed cannot separate them at all, and about one man in twelve cannot
/// separate red from green by hue under any circumstances. Lightness is the channel that always
/// works, so it is the channel the floor is written in.
/// ============================================================================================

/// The minimum Oklab-L gap between adjacent ramp stops. Asserted by bar_selftest over every
/// element. 0.055 is not arbitrary: below about 0.05 two stops stop reading as separate surfaces
/// at the 6-12 px sizes a dense pattern actually draws at, which is the size that matters.
#macro BAR_STOP_FLOOR 0.055

/// How many elements the corpus ships. Asserted, so the number in the listing copy cannot drift
/// away from the number in the code (a defect this wing has shipped before: a live page claimed a
/// pack was half its real size for days).
#macro BAR_ELEMENT_COUNT 12

/// The element table.
///
/// Each row: name, hue in degrees, base chroma, and the L of the darkest and lightest ramp stops.
/// The five stops are laid out BETWEEN those two, never clamped at the ends - bar_palette's law
/// (1): Hearth's limewash clamped its top two stops together and drew a dome as a flat fill.
///
/// ⚠️ THE NEAR-NEUTRALS CARRY A CHROMA OF ALMOST ZERO AND THAT IS DELIBERATE. bone, ash, steel and
/// void are the elements every transform in this product is tuned against, because a hue blend
/// through a neutral is the case bar_palette's law (2) says gets driven through magenta.
function bar_element_table() {
    return [
        //  name        hue    chroma   L0     L4
        { name: "plasma", hue: 262, chroma: 0.150, l0: 0.24, l4: 0.86 },
        { name: "ember",  hue:  44, chroma: 0.165, l0: 0.26, l4: 0.88 },
        { name: "venom",  hue: 138, chroma: 0.145, l0: 0.24, l4: 0.84 },
        { name: "arc",    hue: 218, chroma: 0.140, l0: 0.28, l4: 0.92 },
        { name: "frost",  hue: 196, chroma: 0.105, l0: 0.30, l4: 0.90 },
        { name: "rose",   hue: 356, chroma: 0.155, l0: 0.25, l4: 0.86 },
        { name: "gilt",   hue:  86, chroma: 0.130, l0: 0.27, l4: 0.89 },
        { name: "brine",  hue: 172, chroma: 0.120, l0: 0.23, l4: 0.83 },
        { name: "bone",   hue:  74, chroma: 0.022, l0: 0.30, l4: 0.93 },
        { name: "ash",    hue: 250, chroma: 0.014, l0: 0.22, l4: 0.80 },
        { name: "steel",  hue: 232, chroma: 0.030, l0: 0.26, l4: 0.86 },
        { name: "void",   hue: 300, chroma: 0.060, l0: 0.16, l4: 0.62 },
    ];
}

/// Build the palette struct for one element.
///
/// Returns m0..m4 (the ramp bar_relief indexes by surface normal), plus:
///   line   the outline colour, and the FALLBACK bar_render_colour returns for an unknown role
///   core   the hot centre - deliberately ABOVE m4
///   aura   the outer falloff - deliberately BELOW m0 and more chromatic
///   graze  the near-miss band, see bar_legibility
///
/// _charge in [0,1] slides the whole ramp toward the core. A shot that is winding up is the SAME
/// body getting hotter, never a different colour: that is what lets a player learn one tell and
/// have it hold across every element.
function bar_element_pal(_ix, _charge) {
    var _t = bar_element_table();
    var _n = array_length(_t);
    var _e = _t[((_ix % _n) + _n) % _n];
    var _c = is_undefined(_charge) ? 0 : clamp(_charge, 0, 1);

    // The ramp SLIDES rather than clamping: both ends move together, so no two stops can collapse.
    var _lo = _e.l0 + _c * 0.16;
    var _hi = min(0.97, _e.l4 + _c * 0.07);
    var _ch = _e.chroma * (1 + _c * 0.22);

    // ⛔⛔ THE STOP L COMES FROM bar_element_stop_l AND IS NOT RECOMPUTED HERE. MEASURED
    // 2026-09-05 by this project's own break test, which is the only thing that could have found
    // it: the first version computed `_lo + (_hi - _lo) * (_i / 4)` inline, and bar_element_stop_l
    // computed the same expression separately for the suite to assert against. Breaking the RAMP
    // deliberately - collapsing m3 and m4 onto the same value, the exact Hearth limewash defect -
    // was NOT CAUGHT, because the assertion was reading the other copy.
    //
    // ⭐ That is master §2b's "verify against the READER, not the field you wrote" one level down:
    // a test that checks a REIMPLEMENTATION of the shipped arithmetic proves the reimplementation
    // works. Two expressions that must agree are one expression, and this is now that expression.
    var _pal = {};
    for (var _i = 0; _i < 5; _i++) {
        variable_struct_set(_pal, "m" + string(_i), bar_oklch(bar_element_stop_l(_ix, _i, _c), _ch, _e.hue));
    }
    // The outline is darker than every stop so a body always has a closed edge against its
    // neighbours. It is also the fallback for any role this palette does not name.
    _pal.line  = bar_oklch(max(0.10, _lo - 0.13), _ch * 0.72, _e.hue);
    _pal.core  = bar_oklch(min(0.985, _hi + 0.09), _ch * 0.45, _e.hue);
    _pal.aura  = bar_oklch(max(0.12, _lo - 0.06), _ch * 1.25, _e.hue);
    _pal.graze = bar_oklch(0.95, _ch * 0.30, _e.hue);
    _pal.name  = _e.name;
    _pal.hue   = _e.hue;
    return _pal;
}

/// The Oklab L this element's stop _i sits at, WITHOUT going through sRGB.
///
/// ⛔ bar_selftest's separation floor is checked against THIS, not against the rendered colour.
/// Reading L back out of a make_colour_rgb value means inverting the gamma transfer and the
/// gamut reduction, and the gamut reduction is deliberately lossy - so a stop that was reduced
/// would read as a smaller gap than it was authored with and the assertion would fail on a
/// correct table. Assert the intent; the rendering of it is bar_palette's problem and has its
/// own assertions.
function bar_element_stop_l(_ix, _i, _charge) {
    var _t = bar_element_table();
    var _n = array_length(_t);
    var _e = _t[((_ix % _n) + _n) % _n];
    var _c = is_undefined(_charge) ? 0 : clamp(_charge, 0, 1);
    var _lo = _e.l0 + _c * 0.16;
    var _hi = min(0.97, _e.l4 + _c * 0.07);
    return _lo + (_hi - _lo) * (clamp(_i, 0, 4) / 4);
}

/// Element index by name, or -1. Buyers name elements; the corpus indexes them.
function bar_element_find(_name) {
    var _t = bar_element_table();
    for (var _i = 0; _i < array_length(_t); _i++) {
        if (_t[_i].name == _name) return _i;
    }
    return -1;
}
