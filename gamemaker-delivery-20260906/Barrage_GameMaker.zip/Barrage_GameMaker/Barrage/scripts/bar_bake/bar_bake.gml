/// bar_bake.gml — render the store sheets FROM THE PRODUCT'S OWN DRAW CODE, and measure the ink.
///
/// ⛔ A GALLERY RENDERED BY A SIDE PREVIEWER IS A PICTURE OF A RE-IMPLEMENTATION. This wing has a
/// receipt: a JS previewer carried a defect invisible in the previewer and plainly visible in
/// engine. Baking through the real executable is what lets the listing truthfully say every image
/// on the page was rendered by the product itself.
///
/// ⛔ AND AN EXTENT CHECK IS ONE NUMBER, BLIND IN TWO DIRECTIONS. A returned `y` only answers "did
/// the LAST thing drawn fall off the BOTTOM" - it cannot see horizontal overflow and cannot see
/// emptiness. On a sibling product both blind spots shipped while it reported ok. So this measures
/// the RENDERED PIXELS and returns an ink bounding box.
///
/// ⚠️ STRIDE Y BY 1. A stride of 2 walks straight past a 1px feature on an odd row - including a
/// title rule, which is exactly the shape that lands on one row.
///
/// ⚠️ AND THE INK BOX HAS A PERMANENT BLIND SPOT: a bounding box cannot see the space INSIDE
/// itself, so a few figures adrift on a large page score well and look empty. It catches an EMPTY
/// sheet and a CLIPPED one. It is not a judge of taste and must never be tuned to make a sheet
/// pass - the only instrument for sparseness is opening the file and looking at it.

#macro BAR_BK_W 1600
#macro BAR_BK_H 1000

/// ⛔⛔ IT DIFFS AGAINST A BACKGROUND-ONLY REFERENCE SURFACE, NOT AGAINST A SINGLE COLOUR.
/// MEASURED 2026-09-05 on the first bake: comparing every pixel to the flat clear colour reported
/// `ink 322971, box 0,32 -> 1598,999, fill 1.00 x 0.97, clipped TRUE` on all five sheets - because
/// a vertical RAMP is painted over the whole page, so every pixel differs from the clear colour
/// and the "ink box" was measuring the BACKGROUND. It was a instrument that could only ever
/// return "the page is full and clipped", i.e. one that cannot fail, which is no instrument at all.
///
/// ⚠️ AND IT WAS RIGHT BY ACCIDENT THAT RUN - the titles genuinely WERE clipped - which is the
/// most dangerous way for a broken check to behave, because it looks like it is working. The
/// titles were found by opening the PNG, not by this.
///
/// The reference is rendered by the SAME code path as the real background, so anything that
/// differs is content by construction.
function bar_bk_ink_bounds(_surf, _ref) {
    var _w = surface_get_width(_surf);
    var _h = surface_get_height(_surf);
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    var _rbuf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _surf, 0);
    buffer_get_surface(_rbuf, _ref, 0);

    var _x0 = _w, _y0 = _h, _x1 = -1, _y1 = -1;
    var _ink = 0;

    for (var _y = 0; _y < _h; _y += 1) {          // stride 1 - see the header
        for (var _x = 0; _x < _w; _x += 2) {
            var _o = ((_y * _w) + _x) * 4;
            var _dr = abs(buffer_peek(_buf, _o,     buffer_u8) - buffer_peek(_rbuf, _o,     buffer_u8));
            var _dg = abs(buffer_peek(_buf, _o + 1, buffer_u8) - buffer_peek(_rbuf, _o + 1, buffer_u8));
            var _db = abs(buffer_peek(_buf, _o + 2, buffer_u8) - buffer_peek(_rbuf, _o + 2, buffer_u8));
            if (_dr > 10 || _dg > 10 || _db > 10) {
                _ink += 1;
                if (_x < _x0) _x0 = _x;
                if (_x > _x1) _x1 = _x;
                if (_y < _y0) _y0 = _y;
                if (_y > _y1) _y1 = _y;
            }
        }
    }
    buffer_delete(_buf);
    buffer_delete(_rbuf);
    return { x0: _x0, y0: _y0, x1: _x1, y1: _y1, ink: _ink, w: _w, h: _h };
}

/// Paint the page background. ONE function, used by the real sheets AND by the reference surface
/// the ink check diffs against, so the two cannot drift apart.
/// ⚠️ TAKES ITS SIZE, so it has the same signature as every other background painter (bar_demo_field)
/// and the runner can select between them by name. A no-argument version worked only because GML
/// ignores extra arguments, which is a silent coincidence rather than a contract.
function bar_bk_paint_ground(_w, _h) {
    var _ground = bar_bk_ground();
    draw_clear(_ground);
    bar_render_ramp(0, 0, _w, _h,
        [_ground, bar_oklch(0.21, 0.022, 246), bar_oklch(0.26, 0.020, 242)],
        [0.60, 0.28, 0.12]);
}

/// The page ground. ⛔ DELIBERATELY NOT NEAR-BLACK. This wing spent five bakes tuning a dark mark
/// on an almost-black floor where it was invisible BY CONSTRUCTION; a bullet sheet has the same
/// risk and the same fix, so the ground is chosen so every element's ramp clears it, and
/// bar_legibility can be pointed at these exact numbers.
function bar_bk_ground() { return bar_oklch(0.17, 0.020, 250); }

/// ⛔ bar_text_fit SETS fa_center, SO `_x` IS THE CENTRE OF THE STRING, NOT ITS LEFT EDGE.
/// MEASURED 2026-09-05 by baking the sheets and LOOKING: every title was passed a left margin of
/// 54 and rendered centred on x=54, so more than half of each one ran off the left edge of the
/// page - "EVERY BODY IS A PROFILE, NOT A PICTURE" baked as "PROFILE, NOT A PICTURE".
///
/// ⭐ AND THE INK CHECK CALLED IT `clipped: True` AND I NEARLY READ THAT AS A FALSE POSITIVE,
/// because the ramp painted over the whole page makes every sheet touch every edge. An instrument
/// that is right for the wrong reason is worth no more than one that is wrong - the title was
/// found by opening the PNG, which is the only thing that could have found it.
function bar_bk_title(_text, _sub) {
    draw_set_font(fnt_barrage_title);
    bar_text_fit(_text, BAR_BK_W * 0.5, 58, BAR_BK_W - 140, 50,
        bar_oklch(0.08, 0.02, 250), bar_oklch(0.95, 0.02, 250));
    // ⚠️ AND bar_text_line FORCES fa_left INTERNALLY, so setting halign around it does nothing.
    // Checked rather than assumed - the title bug above came from believing an alignment I had
    // not read. The subtitle is therefore positioned by its LEFT edge, deliberately.
    draw_set_font(fnt_barrage);
    bar_text_line(_sub, 100, 106, BAR_BK_W - 200, 19, bar_oklch(0.74, 0.03, 250), false);
}

/// A caption centred under a centred specimen.
///
/// ⚠️ THERE IS DELIBERATELY NO LEFT-ANCHORED SIBLING. There was one, every sheet used it under
/// centred art, and the result was the zigzag described below. Keeping both would leave the wrong
/// one one keystroke away, and this package already carries a receipt (bar_text_label's header) for
/// what two anchor conventions in one grid cost.
///
/// ⛔ EVERY CAPTION ON THESE SHEETS WAS LEFT-ALIGNED TO ITS CELL WHILE THE ART IT NAMES WAS CENTRED
/// IN THAT CELL, so a short name under a wide body sat visibly off to one side and the page read as
/// a zigzag. MEASURED 2026-09-05 by opening the PNGs: on sheet 5, `plasma` starts at x=78 under a
/// body centred at x=195. It is not a rendering fault - it is two different anchor conventions used
/// in one grid, which is exactly the trap bar_text_label's header already documents one layer down.
function bar_bk_caption_c(_text, _cx, _y, _w) {
    draw_set_font(fnt_barrage);
    bar_text_line_centred(_text, _cx, _y, _w, 15, bar_oklch(0.68, 0.02, 250), false);
}

/// ============================================================================================
/// FITTING A SPECIMEN TO ITS CELL
/// ============================================================================================
///
/// ⛔⛔ THE PATTERN SHEET DREW EVERY FAMILY AT ONE FIXED WORLD SCALE AND THEN *DELETED* THE SHOTS
/// THAT DID NOT FIT. MEASURED 2026-09-05 by opening the PNG. Two separate defects came out of that
/// single decision and both were visible on the page:
///
///   1. THE SCALE VARIED ~6x ACROSS CELLS, because the families genuinely differ in extent. RING
///      and SPIRAL filled their cells; AIMED occupied about 2% of its own cell and read as a
///      rendering failure rather than as a tight cluster, which is what it is.
///   2. THE CLIP WAS A COMPENSATING CONSTANT. `if (abs(_px) > _halfW) continue;` does not make a
///      pattern fit - it removes evidence that it did not, so RING lost its outer waves on the
///      left and CONVERGE came out as two disconnected islands with a hole where the middle was.
///      This wing's own constitution names the shape: a compensating constant is evidence of an
///      upstream bug, and four of them is a confession.
///
/// ⭐ AND THE CAPTION COLLISIONS WERE ARITHMETIC, NOT BAD LUCK. Art was permitted out to
/// `_ch * 0.40` from the cell centre and the caption was drawn at `_ch * 0.36` - so the two bands
/// OVERLAPPED BY DESIGN and five of twelve captions had bullets sitting on the words. No amount of
/// re-baking would have cleared it; the layout had no gap in it to begin with.
///
/// The fix is to measure what the pattern actually occupies and fit THAT to an art box which stops
/// where the caption band starts. Nothing is dropped, so the sheet can assert a shot count.
///
/// ⚠️ THE SPAN FLOOR IS A GUARD, NOT A FUDGE. A family whose shots coincide has span 0 and would
/// divide the cell by nothing; the floor bounds the zoom of a genuinely degenerate case. It is set
/// well below the smallest real family so it never touches one, and the self-test asserts both
/// halves of that: it fires on a collapsed input and does NOT fire on any of the twelve presets.
#macro BAR_FIT_SPAN_FLOOR 0.30

/// Measure the extent of a live shot list and return the scale and offset that centre it in a box.
///
/// `_pad` is the shot's own drawn half-width in world units - a bounding box of CENTRES is not a
/// bounding box of BODIES, and fitting the centres alone pushes half of each edge shot outside the
/// box. Measured on the first re-bake: without it the outermost ring shots sat half over the cell
/// border.
function bar_fit_shots(_live, _boxW, _boxH, _pad) {
    var _n = array_length(_live);
    if (_n <= 0) return { unit: 1, ox: 0, oy: 0, n: 0, spanX: 0, spanY: 0, floored: false };

    var _mnx = _live[0].x, _mxx = _live[0].x;
    var _mny = _live[0].y, _mxy = _live[0].y;
    for (var _i = 1; _i < _n; _i++) {
        var _s = _live[_i];
        if (_s.x < _mnx) _mnx = _s.x;
        if (_s.x > _mxx) _mxx = _s.x;
        if (_s.y < _mny) _mny = _s.y;
        if (_s.y > _mxy) _mxy = _s.y;
    }

    var _rawX = _mxx - _mnx;
    var _rawY = _mxy - _mny;
    var _spanX = max(_rawX + _pad * 2, BAR_FIT_SPAN_FLOOR);
    var _spanY = max(_rawY + _pad * 2, BAR_FIT_SPAN_FLOOR);

    return {
        unit:  min(_boxW / _spanX, _boxH / _spanY),
        ox:    (_mnx + _mxx) * 0.5,
        oy:    (_mny + _mxy) * 0.5,
        n:     _n,
        spanX: _rawX,
        spanY: _rawY,
        floored: (_rawX + _pad * 2 < BAR_FIT_SPAN_FLOOR) || (_rawY + _pad * 2 < BAR_FIT_SPAN_FLOOR),
    };
}

/// ============================================================================================
/// SHEET 1 — THE CORPUS. The volume claim, made visible.
/// ============================================================================================
///
/// ⭐ THIS IS THE SHEET THE GATE 1 VOLUME CLAIM RESTS ON, so it draws EVERY body rather than a
/// selection: 45 of 45. A sheet showing a chosen dozen is an argument that twelve exist.
function bar_bake_corpus(_surf) {
    var _n = bar_bullet_count();
    var _cols = 9;
    var _rows = ceil(_n / _cols);
    var _x0 = 70, _y0 = 190;
    var _cw = (BAR_BK_W - 140) / _cols;
    var _ch = (BAR_BK_H - _y0 - 90) / _rows;

    bar_bk_title("EVERY BODY IS A PROFILE, NOT A PICTURE",
        string(_n) + " projectile bodies across 8 silhouette classes, drawn in pure GML. "
        + "No sprite, no spritesheet, no atlas - `sprites/` does not exist in this package.");

    for (var _i = 0; _i < _n; _i++) {
        var _cx = _x0 + (_i % _cols) * _cw + _cw * 0.5;
        var _cy = _y0 + floor(_i / _cols) * _ch + _ch * 0.42;
        // Each body in a DIFFERENT element, so the sheet shows both corpora at once.
        var _pal = bar_element_pal(_i % BAR_ELEMENT_COUNT, 0);
        bar_render_parts(bar_bullet_parts(_i, 0), _pal, _cx, _cy, _ch * 0.46, 0, 1, undefined);
        bar_bk_caption_c(bar_bullet_info(_i).name, _cx, _cy + _ch * 0.30, _cw - 12);
    }
    return _y0 + _rows * _ch;
}

/// ============================================================================================
/// SHEET 2 — THE PATTERNS. Twelve families, each frozen where it reads.
/// ============================================================================================
function bar_bake_patterns(_surf) {
    var _cols = 4;
    var _rows = 3;
    var _x0 = 60, _y0 = 190;
    var _cw = (BAR_BK_W - 120) / _cols;
    var _ch = (BAR_BK_H - _y0 - 70) / _rows;

    bar_bk_title("TWELVE PATTERN FAMILIES, SEPARATED BY WHAT THE PLAYER MUST DO",
        "Each is a pure function of (wave, shot, time), so a pattern can be scrubbed, previewed "
        + "and asserted without a clock running - and its shots can be counted before one is drawn.");

    // The caption band. Art is fitted into the space ABOVE it and can therefore never enter it -
    // the previous layout let the two overlap by 0.04 of a cell and five captions had shots on them.
    var _capH = 34;

    for (var _f = 0; _f < BAR_PATTERN_COUNT; _f++) {
        var _cellX = _x0 + (_f % _cols) * _cw;
        var _cellY = _y0 + floor(_f / _cols) * _ch;
        var _cx = _cellX + _cw * 0.5;
        var _spec = bar_pattern_preset(_f);
        var _body = bar_bullet_for(_spec.arms, 0.9, "pellet", 0.055);
        var _t = _spec.gap * _spec.waves * 0.85 + 0.55;

        var _artW = _cw - 30;
        var _artH = _ch - _capH - 16;
        var _acy = _cellY + _artH * 0.5;

        var _live = bar_pattern_live(_spec, _t);
        var _fit = bar_fit_shots(_live, _artW, _artH, 0.055);

        // ⭐ EVERY SHOT IS DRAWN. There is no `continue` here any more, which is the point: the
        // count in the caption is the count on the page, and the two cannot drift.
        for (var _i = 0; _i < array_length(_live); _i++) {
            var _s = _live[_i];
            var _pal = bar_element_pal(_f % BAR_ELEMENT_COUNT, _s.charge);
            bar_render_parts(bar_bullet_parts(_body, _s.charge), _pal,
                _cx  + (_s.x - _fit.ox) * _fit.unit,
                _acy + (_s.y - _fit.oy) * _fit.unit,
                _fit.unit * 0.055, _s.heading, 1, undefined);
        }

        bar_bk_caption_c(string_upper(bar_pattern_name(_f)) + "  -  "
            + bar_pattern_table()[_f].asks, _cx, _cellY + _artH + 12, _cw - 24);
        bar_bk_caption_c(string(array_length(_live)) + " shots live  -  "
            + string(_spec.arms) + " arms x " + string(_spec.waves) + " waves",
            _cx, _cellY + _artH + 30, _cw - 24);
    }
    return _y0 + _rows * _ch;
}

/// ============================================================================================
/// SHEET 3 — THE COUPLING. The one frame a spritesheet cannot produce.
/// ============================================================================================
///
/// ⭐ THIS IS THE PRODUCT'S HEADLINE CLAIM AS A PICTURE. The same ring at four densities: as the
/// arm count rises the body NARROWS and finally changes class, because the gap between adjacent
/// shots is arithmetic and the art answers to it. A fixed spritesheet draws the same bullet in all
/// four panels and the fourth is a solid wall.
/// ⛔⛔ AND FOR ONE BAKE IT MADE THAT CLAIM AT A SIZE NOBODY COULD READ IT AT. MEASURED 2026-09-05
/// by opening the PNG: the four rings were drawn ~296px across on a 1600x1000 page, which puts each
/// body at about EIGHT PIXELS - and at eight pixels a `spindle` and a `dart` are the same grey dot.
/// The sheet asserted "the body changes class" and then showed four pictures in which the change is
/// invisible, while 55% of the page was empty.
///
/// ⭐ THE DEAD SPACE AND THE UNREADABLE CLAIM WERE THE SAME DEFECT AND THEY HAVE THE SAME FIX: the
/// page had room for the evidence all along. The row of rings is the pattern, and a second row
/// shows the body each ring CHOSE, magnified, so the headline is something the eye can check rather
/// than something the caption insists on. A store sheet whose central claim needs a magnifier is
/// not a store sheet.
/// The arm counts at which the chosen body actually CHANGES, found by asking the product.
///
/// ⛔⛔ THE FOUR COUNTS ON THIS SHEET USED TO BE TYPED IN BY HAND - [8, 48, 96, 148] - AND TWO OF
/// THEM PICKED THE SAME BODY. MEASURED 2026-09-05 from the suite's own note: `coupling: 4 ->
/// pellet, 48 -> pellet, 96 -> spindle, 148 -> dart`. So the sheet whose entire claim is "the body
/// answers to the pattern" was about to show that body NOT answering in one of its four panels,
/// directly above a magnified row that would have printed `pellet` twice.
///
/// ⭐ THE HAND-TYPED NUMBERS WERE NEVER WRONG - THEY WERE UNCHECKED, WHICH IS DIFFERENT AND WORSE,
/// because nothing in the package could have told me they had drifted from bar_bullet_for's real
/// thresholds. Scanning for the transitions makes the sheet a measurement of the product rather
/// than an illustration of what the product was assumed to do, and it cannot go stale when the body
/// table changes.
function bar_coupling_steps(_want, _from, _radius, _bodyscale) {
    var _out = [];
    var _seen = [];
    for (var _a = _from; _a <= 400 && array_length(_out) < _want; _a++) {
        var _b = bar_bullet_for(_a, _radius, "pellet", _bodyscale);
        var _known = false;
        for (var _i = 0; _i < array_length(_seen); _i++) if (_seen[_i] == _b) _known = true;
        if (_known) continue;
        array_push(_seen, _b);
        array_push(_out, { arms: _a, body: _b });
    }
    return _out;
}

function bar_bake_coupling(_surf) {
    /// ⛔⛔ ONE RADIUS, USED THREE TIMES. The first version of this sheet CHOSE each body for radius
    /// 0.9, DREW the ring at 0.465 and MEASURED the crowding at 0.465 - three numbers where there
    /// should have been one. It printed `clear channel -0.003` under two of its four panels, and a
    /// negative clear channel is `solid` in bar_legibility's own vocabulary: the sheet was
    /// advertising, on the store page, the exact failure state the product exists to prevent.
    ///
    /// ⭐ AND THE PRODUCT WAS INNOCENT. bar_bullet_for guarantees a clear channel of at least a
    /// third of the gap AT THE RADIUS IT IS ASKED ABOUT, so asking about one radius while rendering
    /// another is the bake misreporting the library. The tell was printing the number at all - the
    /// previous sheet showed a WORD ("clears every check"), and a word cannot come out negative.
    var _R = 0.9;               // chosen for, drawn at, and measured at - one value, three uses
    var _ringSpeed = 0.30;
    var _bodyScale = 0.055;

    // ⚠️ THE SCAN STARTS AT 12 RATHER THAN AT THE LOWEST COUNT THAT EXISTS. Six shots fitted to a
    // cell are six dots, not a ring, and the shape has to read before a change in it can be a point.
    var _steps = bar_coupling_steps(4, 12, _R, _bodyScale);
    var _x0 = 60;
    var _cw = (BAR_BK_W - 120) / 4;

    // Two bands: the pattern, then the body it chose.
    var _ringTop = 160, _ringH = 400;
    var _bodyTop = 618, _bodyH = 272;

    bar_bk_title("THE BODY ANSWERS TO THE PATTERN",
        "One ring, four densities, one number changed. The shelf sells the WIRING (a framework "
        + "whose own copy says: all you need is to draw a sprite) and the ART (fixed spritesheets) "
        + "and never couples them. The coupling is the product.");

    draw_set_font(fnt_barrage);
    bar_text_line_centred("BELOW: THE BODY EACH RING CHOSE, AT THE SAME MAGNIFICATION",
        BAR_BK_W * 0.5, 578, BAR_BK_W - 200, 15, bar_oklch(0.56, 0.02, 250), false);

    for (var _k = 0; _k < array_length(_steps); _k++) {
        var _arms = _steps[_k].arms;
        var _body = _steps[_k].body;
        var _cx = _x0 + _k * _cw + _cw * 0.5;
        var _spec = bar_pattern_spec(BAR_PAT_RING, _arms, 1, 0, 360, _ringSpeed, 0, 0.35, 0, 0);

        // The instant the wave reaches _R, derived rather than typed: r = speed * t.
        var _live = bar_pattern_live(_spec, _R / _ringSpeed);
        var _fit = bar_fit_shots(_live, _cw - 40, _ringH - 34, _bodyScale);
        var _rcy = _ringTop + (_ringH - 34) * 0.5;
        for (var _i = 0; _i < array_length(_live); _i++) {
            var _s = _live[_i];
            bar_render_parts(bar_bullet_parts(_body, 0), bar_element_pal(3, 0),
                _cx  + (_s.x - _fit.ox) * _fit.unit,
                _rcy + (_s.y - _fit.oy) * _fit.unit,
                _fit.unit * 0.055, _s.heading, 1, undefined);
        }
        bar_bk_caption_c("at " + string(_arms) + " arms it becomes  "
            + string_upper(bar_bullet_info(_body).name),
            _cx, _ringTop + _ringH - 26, _cw - 24);

        // ⚠️ ONE MAGNIFICATION FOR ALL FOUR, and the caption says so. Fitting each body to its own
        // cell would make a narrow dart and a fat pellet the same size on the page, which is the
        // precise opposite of the claim this sheet exists to make.
        bar_render_parts(bar_bullet_parts(_body, 0), bar_element_pal(3, 0),
            _cx, _bodyTop + _bodyH * 0.42, _bodyH * 0.34, 0, 1, undefined);
        bar_bk_caption_c(bar_bullet_info(_body).name,
            _cx, _bodyTop + _bodyH * 0.42 + _bodyH * 0.36, _cw - 24);

        // ⭐ THE NUMBER THE CHOICE IS MADE ON, not a sentence about it - and it is the only thing on
        // this row that DIFFERS between the four cells, which is what makes it worth printing. A
        // caption repeated identically under four pictures is decoration; this one is the argument.
        var _cr = bar_legibility_crowding(_spec, _R, _body, _bodyScale);
        bar_bk_caption_c("clear channel " + string_format(_cr.clear, 1, 3)
            + "  /  body " + string_format(_cr.bodyWidth, 1, 3),
            _cx, _bodyTop + _bodyH * 0.42 + _bodyH * 0.36 + 20, _cw - 24);
    }
    return _bodyTop + _bodyH;
}

/// ============================================================================================
/// SHEET 4 — LEGIBILITY. The half nothing on the shelf ships.
/// ============================================================================================
/// The contrast check drawn as a picture of itself: the lightness axis a shot is judged on, the
/// band of field lightness it has to be seen against, and the element's five stops marked on the
/// same axis. The gap between the nearest stop and the band IS the contrast number.
///
/// ⭐ THIS EXISTS BECAUSE A NUMBER ON A STORE SHEET IS AN ASSERTION AND A CHART IS AN ARGUMENT.
/// `contrast: measured 0.007 against floor 0.160` is true, checkable and completely inert to
/// somebody deciding whether to spend $15; the same fact drawn shows a buyer, in one glance, that
/// void's stops sit INSIDE the band the field occupies and bone's stand clear of it. It also
/// happens to fill the 150px of dead page this sheet was carrying between its art and its captions,
/// which is the honest way to fill dead space: put something in it that is worth reading.
/// ⚠️ THE FIELD BAND GETS ITS OWN ROW, NOT A HAIRLINE ON THE AXIS. The first version drew it as two
/// 3px ticks above and below the strip; baked and looked at, they were indistinguishable from the
/// stop marks beside them, so the chart showed the element's stops against nothing and the entire
/// argument - "these stops are INSIDE the band, those are clear of it" - was invisible. Half a
/// comparison drawn well is not a comparison.
function bar_bk_l_strip(_cx, _y, _w, _h, _elem, _f0, _f1) {
    var _x0 = _cx - _w * 0.5;
    var _bandH = 14;
    var _axisY = _y + _bandH + 10;

    draw_set_font(fnt_barrage);

    // ROW A - the field band, on the same x axis as the strip below it.
    draw_set_colour(bar_oklch(0.30, 0.02, 250));
    draw_rectangle(_x0, _y, _x0 + _w, _y + _bandH, false);
    draw_set_colour(bar_oklch(0.72, 0.13, 62));
    draw_rectangle(_x0 + _w * _f0, _y, _x0 + _w * _f1, _y + _bandH, false);
    bar_text_line_centred("FIELD " + string_format(_f0, 1, 2) + " - " + string_format(_f1, 1, 2),
        _x0 + _w * (_f0 + _f1) * 0.5, _y - 17, _w, 12, bar_oklch(0.72, 0.13, 62), false);

    // ROW B - the L axis, 0 to 1, painted as the greyscale it actually represents, so the chart is
    // its own legend and nothing has to be taken on trust from a caption.
    var _n = 72;
    for (var _i = 0; _i < _n; _i++) {
        draw_set_colour(bar_oklch(_i / (_n - 1), 0, 250));
        draw_rectangle(_x0 + _w * (_i / _n), _axisY, _x0 + _w * ((_i + 1) / _n) + 1, _axisY + _h, false);
    }

    // The element's stops, each in its own colour, on a dark keyline so a light stop stays visible
    // against the light end of the axis.
    var _pal = bar_element_pal(_elem, 0);
    for (var _s = 0; _s < BAR_RAMP_N; _s++) {
        var _tx = _x0 + _w * clamp(bar_element_stop_l(_elem, _s, 0), 0, 1);
        draw_set_colour(bar_oklch(0.06, 0.02, 250));
        draw_rectangle(_tx - 5, _axisY - 8, _tx + 5, _axisY + _h + 8, false);
        draw_set_colour(bar_render_colour(_pal, "m" + string(_s)));
        draw_rectangle(_tx - 3, _axisY - 6, _tx + 3, _axisY + _h + 6, false);
    }

    bar_text_line("L 0", _x0, _axisY + _h + 12, 60, 12, bar_oklch(0.52, 0.02, 250), false);
    bar_text_line_centred("L 1", _x0 + _w - 14, _axisY + _h + 12, 60, 12,
        bar_oklch(0.52, 0.02, 250), false);
    draw_set_colour(c_white);
    return _axisY + _h + 28;
}

/// ⛔ THE SUBTITLE PROMISED "REPORTED WITH THE NUMBER" AND THE SHEET CARRIED NOT ONE NUMBER.
/// MEASURED 2026-09-05 by opening the PNG. Three panels each said a word - "clears every check",
/// "FLAGGED" - which is the VERDICT, and master §2b's second rule is count the work, not the
/// verdict. A buyer reading this sheet is being asked to take the measurement on trust from a
/// product whose entire pitch is that it measures. So every panel now prints what was measured, the
/// floor it was measured against, and how many checks ran.
///
/// ⚠️ AND THE FAILING PANEL IS THE ONE THAT MATTERS, so it prints the number that failed. A
/// legibility tool that only ever shows its passes is a decoration.
function bar_bake_legibility(_surf) {
    var _x0 = 70, _y0 = 166;
    var _cw = (BAR_BK_W - 140) / 3;

    // ⚠️ THE ART BAND IS BOUNDED BY THE CELL WIDTH, NOT BY THE PAGE HEIGHT. Three panels across a
    // 1600px page get 487px each, so a panel can never be taller than that without overflowing
    // sideways - which is why growing the art could not close this sheet's dead space and the
    // L strip below had to. Layout arithmetic that ignores the other axis just moves the overflow.
    var _artH = 440;
    var _cy = _y0 + _artH * 0.5;
    var _stripY = _y0 + _artH + 54;
    var _stripH = 46;
    var _capY = _stripY + _stripH + 90;
    var _bIx = bar_bullet_find("orb");
    var _spec = bar_pattern_preset(BAR_PAT_RING);

    bar_bk_title("IT MEASURES WHETHER THE PLAYER CAN SEE IT",
        "Crowding, contrast against the field, and warning time - measured, reported with the "
        + "number and the knob that moves it. An unreadable bullet is a death the player could "
        + "not have avoided.");

    draw_set_font(fnt_barrage);
    bar_text_line_centred("BELOW EACH: THE FIELD BAND THIS SHOT MUST BE SEEN AGAINST, AND THE "
        + "ELEMENT'S FIVE STOPS ON THE SAME LIGHTNESS AXIS",
        BAR_BK_W * 0.5, _stripY - 44, BAR_BK_W - 200, 15, bar_oklch(0.56, 0.02, 250), false);

    // Panel 1: the hitbox and graze band, drawn by default.
    var _plasma = bar_element_find("plasma");
    var _cx = _x0 + _cw * 0.5;
    var _pal = bar_element_pal(_plasma, 0);
    bar_render_parts(bar_bullet_parts(_bIx, 0), _pal, _cx, _cy, _artH * 0.42, 0, 1, undefined);
    bar_render_parts(bar_legibility_parts(true), _pal, _cx, _cy, _artH * 0.42, 0, 1, undefined);
    bar_bk_l_strip(_cx, _stripY, _cw - 90, _stripH, _plasma, 0.14, 0.24);
    bar_bk_caption_c("THE HITBOX IS SMALLER THAN THE BODY, AND IT IS DRAWN", _cx, _capY, _cw - 20);
    bar_bk_caption_c("most games make the player learn it by dying", _cx, _capY + 20, _cw - 20);
    // The element is NAMED here for the same reason panels 2 and 3 name theirs: the strip under
    // this panel is a measurement of a specific element, and an unlabelled chart is a decoration.
    bar_bk_caption_c("plasma  /  kill radius " + string_format(BAR_HITBOX_R, 1, 2)
        + " of a 0.50 half-body  /  graze band +"
        + string(round(BAR_GRAZE_BAND * 100)) + "%",
        _cx, _capY + 44, _cw - 20);

    // Panels 2 and 3: the same element check, one that clears and one that does not.
    var _names = ["bone", "void"];
    for (var _p = 0; _p < 2; _p++) {
        var _pcx = _x0 + _cw * (1.5 + _p);
        var _el  = bar_element_find(_names[_p]);
        var _f0  = (_p == 0) ? 0.14 : 0.16;
        var _f1  = (_p == 0) ? 0.24 : 0.30;
        var _rep = bar_legibility_report(_spec, _el, _bIx, 0.055, _f0, _f1);

        for (var _i = 0; _i < 7; _i++) {
            var _a = (_i / 7) * BAR_TAU;
            bar_render_parts(bar_bullet_parts(_bIx, 0), bar_element_pal(_el, 0),
                _pcx + cos(_a) * _cw * 0.27, _cy + sin(_a) * _cw * 0.27,
                _artH * 0.20, 0, 1, undefined);
        }
        bar_bk_l_strip(_pcx, _stripY, _cw - 90, _stripH, _el, _f0, _f1);

        bar_bk_caption_c(string_upper(_names[_p]) + " ON THIS FIELD: "
            + (_rep.ok ? "CLEARS ALL " + string(_rep.checked) + " CHECKS"
                       : "FLAGGED BY " + string(array_length(_rep.issues)) + " OF "
                         + string(_rep.checked)),
            _pcx, _capY, _cw - 20);

        // The numbers themselves. An empty issue list prints the fact that it is empty rather than
        // printing nothing, because a blank line under a passing panel is indistinguishable from a
        // panel whose readout failed to draw.
        if (array_length(_rep.issues) == 0) {
            bar_bk_caption_c("no issue raised on crowding, contrast or warning time",
                _pcx, _capY + 20, _cw - 20);
            bar_bk_caption_c("field L " + string_format(_f0, 1, 2) + " to "
                + string_format(_f1, 1, 2) + "  /  body " + _rep.body,
                _pcx, _capY + 44, _cw - 20);
        } else {
            var _it = _rep.issues[0];
            bar_bk_caption_c(_it.kind + ": measured " + string_format(_it.measured, 1, 3)
                + " against floor " + string_format(_it.floor, 1, 3),
                _pcx, _capY + 20, _cw - 20);
            bar_bk_caption_c("a dark mark on a dark ground is invisible by construction",
                _pcx, _capY + 44, _cw - 20);
        }
    }
    return _capY + 60;
}

/// ============================================================================================
/// SHEET 5 — THE ELEMENTS.
/// ============================================================================================
function bar_bake_elements(_surf) {
    var _n = BAR_ELEMENT_COUNT;
    var _cols = 6;
    var _rows = ceil(_n / _cols);
    var _x0 = 70, _y0 = 186;
    var _cw = (BAR_BK_W - 140) / _cols;
    var _ch = (BAR_BK_H - _y0 - 52) / _rows;

    bar_bk_title("TWELVE ELEMENTS, EACH A FIVE-STOP RAMP",
        "Not a tint. A ramp lets the lit flank, the shadowed flank and the rim take different "
        + "stops, so a body has an internal edge - which is what survives being one of a hundred "
        + "overlapping shapes. Every adjacent pair is asserted to differ in apparent lightness.");

    var _bIx = bar_bullet_find("crystal");
    for (var _e = 0; _e < _n; _e++) {
        var _cx = _x0 + (_e % _cols) * _cw + _cw * 0.5;
        var _cy = _y0 + floor(_e / _cols) * _ch + _ch * 0.34;
        var _pal = bar_element_pal(_e, 0);
        bar_render_parts(bar_bullet_parts(_bIx, 0), _pal, _cx, _cy, _ch * 0.40, -20, 1, undefined);
        // The ramp itself, as five chips, so the claim above is visible rather than asserted.
        for (var _s = 0; _s < 5; _s++) {
            var _sw = _cw * 0.13;
            draw_set_colour(bar_render_colour(_pal, "m" + string(_s)));
            draw_rectangle(_cx - _sw * 2.5 + _s * _sw, _cy + _ch * 0.24,
                           _cx - _sw * 2.5 + _s * _sw + _sw - 3, _cy + _ch * 0.24 + 20, false);
        }
        draw_set_colour(c_white);
        bar_bk_caption_c(_pal.name, _cx, _cy + _ch * 0.24 + 26, _cw - 16);
    }
    return _y0 + _rows * _ch;
}

/// ============================================================================================
/// SHEET 6 — THE PRODUCT IN USE. The demo room, drawn by the demo room's own code.
/// ============================================================================================
///
/// ⛔⛔ THE GALLERY HAD FIVE SPECIMEN PLATES AND NO PICTURE OF THE PRODUCT RUNNING. Found 2026-09-05
/// by opening the two Gate 1 reference images and comparing honestly: Sigil Core's best sheet is a
/// SPELLBOOK a player uses, Meridian's is a SKILL TREE a player clicks. Both lead with the thing in
/// use. Barrage led with five catalogue plates - every one of them true, generated and well made,
/// and not one of them answering the only question a buyer is actually asking, which is *what will
/// this look like in my game*.
///
/// ⭐ IT IS NOT A SIXTH DRAWING. `bar_demo_draw` is the demo room's Draw event, called here at page
/// size, so this sheet cannot drift from the product the way a hand-built "screenshot-alike" would.
/// ⚠️ AND IT IS DRAWN AT A REAL MOMENT: the state is stepped through bar_demo_step with the same
/// clock a running room uses, rather than posed by setting `t` directly, so the frame on the store
/// page is one the demo genuinely produces.
/// ⚠️ THIS SHEET REPORTS `clipped: true` AND THAT IS CORRECT, WHICH IS WHY THE FLAG IS PRINTED
/// RATHER THAN ENFORCED. `clipped` asks "does content touch the frame edge", which is a DEFECT on a
/// specimen plate with margins and the NORMAL STATE of a game view - shots fly off the bottom of
/// the screen, because that is what shots do. The flag is not noise here: on the first bake of this
/// sheet it read `box 0,10` and the cause was a real product defect (the demo's title was drawn
/// centre-anchored at x=24 and rendered as "AGE 1.0.0"). Fixed, it reads `box 26,24` with the
/// bottom edge still touched. ⛔ So read the BOX, never the boolean - and never "fix" this by
/// shrinking the pattern until the flag clears, which would be tuning the product to please an
/// instrument aimed at a different kind of picture.
function bar_bake_inuse(_surf) {
    var _st = bar_demo_state();
    _st.pattern = BAR_PAT_LACE;      // the family whose whole question is "find the moving gap"
    _st.element = bar_element_find("arc");
    _st.hitbox  = true;

    // Step the real state machine to a real frame. ⚠️ NOT `_st.t = 1.9`: posing the clock skips
    // every transition the room performs on the way there, and the point of this sheet is that it
    // is a frame the product actually reaches.
    var _spec = bar_demo_step(_st, bar_demo_input(), 0);
    var _steps = 114;
    for (var _i = 0; _i < _steps; _i++) _spec = bar_demo_step(_st, bar_demo_input(), 1 / 60);

    bar_demo_draw(_st, _spec, BAR_BK_W, BAR_BK_H);
    return BAR_BK_H;
}

/// ============================================================================================
/// THE GIF — the headline claim, in motion.
/// ============================================================================================
///
/// ⭐ WHAT IT SHOWS AND WHY IT IS THIS AND NOT A PATTERN LOOPING. A pattern going round is pretty
/// and a buyer has seen it; what they have not seen is the ARM COUNT RISING while the bullet
/// NARROWS AND CHANGES CLASS UNDER IT. That is the one thing a fixed spritesheet cannot do at all -
/// it would draw the same bullet in every frame and the last frame would be a solid wall - and it
/// is the product's whole argument, so it belongs in the first two seconds rather than in a caption.
///
/// ⚠️ THE READOUT IS LEFT ON DELIBERATELY. It names the arm count and the body, so the viewer can
/// see WHICH body was chosen as well as that it changed, and the numbers move with the picture
/// rather than being asserted beside it.
///
/// ⚠️ SIZED FOR itch's 3 MB CAP AT THE SOURCE. A 1600x1000 frame downsampled by the encoder is
/// bytes spent on detail the cap then destroys; this renders at the size it will be shown at, so
/// make_gif.ps1 never has to upscale (this wing measured an upscale costing 5.6x the bytes for
/// nothing).
#macro BAR_GIF_W 800
#macro BAR_GIF_H 500
#macro BAR_GIF_FRAMES 44

/// ⛔⛔ THE ARM RAMP STOPS AT A COUNT THAT IS STILL LEGIBLE, AND THE FIRST VERSION DID NOT.
/// MEASURED 2026-09-05 by encoding the GIF and looking at three frames: ramping to 178 arms made
/// the readout print `BARRAGE legibility: 1 of 4 checks flagged (ring / spindle)` and
/// `crowding: measured -0.0N against floor 0.0134`, so the highest-converting asset on the store
/// page was a video of the product REPORTING ITS OWN PATTERN AS UNREADABLE. Sheet 3 had the same
/// shape earlier the same day (`clear channel -0.003`) and it is worth naming the family: an
/// honest instrument wired to a promotional surface will happily advertise the failure it exists
/// to prevent, and only looking at the output catches it.
///
/// ⭐ THE FIX IS NOT TO HIDE THE READOUT. The readout is the product's best feature and the ramp is
/// the product's best claim; what was wrong was the RANGE. 100 arms still crosses three body
/// classes (pellet -> spindle -> dart), which is the whole point, and stays inside what
/// bar_bullet_for can actually keep readable at this radius.
#macro BAR_GIF_MAX_ARMS 100

/// The radius the wave is DRAWN at - chosen so a three-wave ring fits an 800x500 frame without
/// running through the readout.
#macro BAR_GIF_RADIUS 0.48

/// ⛔ THE RADIUS THE BODY IS CHOSEN FOR IS THE TIGHTEST ONE bar_legibility WILL JUDGE IT AT, WHICH
/// IS NOT THE ONE IT IS DRAWN AT — and getting that wrong made 35 of 44 frames flag.
///
/// bar_legibility_report samples crowding across `r = 0.10 + (1.10 - 0.10) * (i / 6)` for i = 1..6,
/// because a ring is most crowded when it is YOUNG and checking only the outer edge passes
/// everything. Its tightest sample is therefore ~0.267. Choosing a body for the radius the GIF
/// happens to freeze at (0.48) picks something that fits THERE and is too wide where the report
/// actually bites, so the readout correctly complained.
///
/// ⚠️ THIS IS NOT THE SHEET-3 ERROR IN DISGUISE. There, a crowding NUMBER was printed for a radius
/// the body had not been chosen for, so the number described a different picture from the one above
/// it. Here the body is chosen for the WHOLE FLIGHT and the report agrees across all six samples;
/// the drawn radius is just which instant we are looking at. The test is whether the readout in the
/// frame is true of the frame, and it is - make_gif.js refuses to encode otherwise.
///
/// ⭐ AND IT MAKES THE GIF ARGUE THE RIGHT THING. What a viewer now watches is the arm count
/// climbing while the body NARROWS TO KEEP THE WAVE READABLE and the readout keeps saying no
/// issues - which is the product working, rather than the product complaining.
// ⛔ DERIVED, NEVER TYPED. See bar_legibility_crowd_r: typing 0.267 here instead of asking for
/// the report's own sample 1 (0.26667) flagged exactly one frame of forty-four and read as a
/// non-monotonic body ladder. The tightest radius the report judges at is the radius a body must
/// be chosen for.
#macro BAR_GIF_FIT_R bar_legibility_crowd_r(1)

/// The arm count at frame `_i`, easing so the interesting middle - where the class changes - gets
/// more frames than the ends.
function bar_gif_arms(_i, _n) {
    var _t = _i / max(1, _n - 1);
    var _e = _t * _t * (3 - 2 * _t);          // smoothstep
    return round(10 + _e * (BAR_GIF_MAX_ARMS - 10));
}

/// Render the frames, and write a per-frame record beside them so the encoder can REFUSE to build
/// a GIF that advertises a flagged pattern. A picture cannot be asserted about; a number can.
function bar_bake_gif() {
    var _st = bar_demo_state();
    _st.element = bar_element_find("arc");
    _st.hitbox  = false;                       // the graze rings read as clutter at 800px
    _st.pattern = BAR_PAT_RING;

    var _speed = 0.30;
    var _f = file_text_open_write("bar_gif.json");
    file_text_write_string(_f, "{\"frames\":[");

    for (var _i = 0; _i < BAR_GIF_FRAMES; _i++) {
        var _arms = bar_gif_arms(_i, BAR_GIF_FRAMES);
        var _spec = bar_pattern_spec(BAR_PAT_RING, _arms, 3, 7, 360, _speed, 0, 0.34, 0, 0);

        // The body is CHOSEN, not scripted - the same call a buyer makes, at the radius the wave is
        // actually drawn at, so the class change on screen is the product's own decision and the
        // number underneath it describes the picture above it.
        _st.body = bar_bullet_for(_arms, BAR_GIF_FIT_R, "pellet", 0.055);

        // ⚠️ t DERIVED FROM THE RADIUS, NOT TYPED. r = speed * t, so the leading wave lands exactly
        // on BAR_GIF_RADIUS and the ring fits the frame instead of running through the readout.
        _st.t = BAR_GIF_RADIUS / _speed;

        var _rep = bar_legibility_report(_spec, _st.element, _st.body, 0.055, 0.12, 0.26);
        _st.report = bar_legibility_line(_rep);

        var _surf = surface_create(BAR_GIF_W, BAR_GIF_H);
        surface_set_target(_surf);
        bar_demo_draw(_st, _spec, BAR_GIF_W, BAR_GIF_H);
        surface_reset_target();
        surface_save(_surf, "gif_" + string_replace(string_format(1000 + _i, 4, 0), " ", "") + ".png");
        surface_free(_surf);

        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "{\"i\":" + string(_i)
            + ",\"arms\":" + string(_arms)
            + ",\"body\":\"" + bar_bullet_info(_st.body).name + "\""
            + ",\"ok\":" + (_rep.ok ? "true" : "false")
            + ",\"issues\":" + string(array_length(_rep.issues)) + "}");
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

/// Render every sheet, measure its ink, and write a report the harness reads.
///
/// ⛔ THE INK REPORT IS WRITTEN EVEN WHEN EVERY SHEET PASSES, and it records the numbers rather
/// than a verdict (master §2b: count the work, not the verdict). A bake that prints "ok" and
/// nothing else is indistinguishable from a bake that drew nothing.
function bar_bake_all() {
    var _sheets = [
        { name: "sheet_1_corpus",      fn: bar_bake_corpus },
        { name: "sheet_2_patterns",    fn: bar_bake_patterns },
        { name: "sheet_3_coupling",    fn: bar_bake_coupling },
        { name: "sheet_4_legibility",  fn: bar_bake_legibility },
        { name: "sheet_5_elements",    fn: bar_bake_elements },
        // ⛔ ITS OWN REFERENCE. This sheet paints the DEMO's field, not the page ground, so diffing
        // it against the page ground would mark every pixel as content and report "full page,
        // clipped" - which is precisely the failure this checker was rebuilt to escape once
        // already (see bar_bk_ink_bounds). A per-sheet background is a per-sheet reference.
        { name: "sheet_6_in_use",      fn: bar_bake_inuse, ref: bar_demo_field },
    ];

    var _f = file_text_open_write("bar_bake.json");
    file_text_write_string(_f, "{\"sheets\":[");

    // The reference: THAT SHEET'S background and NOTHING else, painted by the same function the
    // sheet itself uses, so the ink check measures content rather than the ramp. Per sheet, because
    // a sheet that paints its own field (sheet 6) diffed against the page ground reports every
    // pixel as content - the exact "instrument that cannot fail" this checker was rebuilt to escape.
    var _ref = surface_create(BAR_BK_W, BAR_BK_H);

    for (var _i = 0; _i < array_length(_sheets); _i++) {
        var _s = _sheets[_i];
        var _paintRef = variable_struct_exists(_s, "ref") ? _s.ref : bar_bk_paint_ground;

        surface_set_target(_ref);
        _paintRef(BAR_BK_W, BAR_BK_H);
        surface_reset_target();

        var _surf = surface_create(BAR_BK_W, BAR_BK_H);
        surface_set_target(_surf);
        _paintRef(BAR_BK_W, BAR_BK_H);
        var _reach = _s.fn(_surf);
        surface_reset_target();

        var _ink = bar_bk_ink_bounds(_surf, _ref);
        surface_save(_surf, _s.name + ".png");
        surface_free(_surf);

        // Coverage, measured. Floors are FLOORS AGAINST EMPTY, not a judgement of quality.
        var _fillW = (_ink.x1 - _ink.x0) / BAR_BK_W;
        var _fillH = (_ink.y1 - _ink.y0) / BAR_BK_H;
        var _clipped = (_ink.x0 <= 6) || (_ink.y0 <= 6) || (_ink.x1 >= BAR_BK_W - 8) || (_ink.y1 >= BAR_BK_H - 8);

        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "{\"name\":\"" + _s.name + "\"");
        file_text_write_string(_f, ",\"ink\":" + string(_ink.ink));
        file_text_write_string(_f, ",\"x0\":" + string(_ink.x0) + ",\"y0\":" + string(_ink.y0));
        file_text_write_string(_f, ",\"x1\":" + string(_ink.x1) + ",\"y1\":" + string(_ink.y1));
        file_text_write_string(_f, ",\"fillW\":" + string(_fillW) + ",\"fillH\":" + string(_fillH));
        file_text_write_string(_f, ",\"clipped\":" + (_clipped ? "true" : "false"));
        file_text_write_string(_f, ",\"reach\":" + string(_reach));
        file_text_write_string(_f, "}");
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
    surface_free(_ref);
}
