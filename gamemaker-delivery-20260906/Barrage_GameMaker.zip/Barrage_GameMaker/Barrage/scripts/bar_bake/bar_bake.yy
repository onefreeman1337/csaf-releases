{
  "$GMScript": "v1",
  "%Name": "bar_bake",
  "name": "bar_bake",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}