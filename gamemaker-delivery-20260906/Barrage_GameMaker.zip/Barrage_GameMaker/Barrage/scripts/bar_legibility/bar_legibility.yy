{
  "$GMScript": "v1",
  "%Name": "bar_legibility",
  "name": "bar_legibility",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}