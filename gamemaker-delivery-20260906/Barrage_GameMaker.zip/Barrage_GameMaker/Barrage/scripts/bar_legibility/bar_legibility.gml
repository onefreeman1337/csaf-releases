/// BARRAGE - bar_legibility. Whether the player can actually SEE what is about to kill them.
///
/// -- WHY THIS FILE IS THE PRODUCT AND NOT AN EXTRA ---------------------------------------------
/// ⭐ NOTHING ON THIS SHELF SHIPS THIS. The wiring half (a danmaku framework at $14.99 whose own
/// copy says "all you need is to draw a sprite") has no opinion about whether the sprite is
/// readable, because it never sees it. The art half (VFX spritesheets at $19.99-$98) is fixed
/// frames that cannot know what they will be drawn over. Legibility lives exactly in the join, so
/// only a product that owns BOTH can measure it - which is the coupling this package is for.
///
/// ⛔ AND IN THIS GENRE IT IS NOT AN AESTHETIC. An unreadable bullet is a death the player could
/// not have avoided, and a game full of them is refunded. Every function here answers one
/// question: given what the buyer has configured, is there a shot on screen that a player could
/// not have seen in time?
///
/// -- THE THREE FAILURES IT CATCHES, AND HOW EACH IS MEASURED -----------------------------------
///   CROWDING   two shots so close that the gap between them is smaller than the player's ship.
///              Measured as arc length between adjacent arms against body width. This is the one
///              bar_bullet_for tries to fix automatically; this file reports when it could not.
///   CONTRAST   a shot whose ramp sits on top of the field's ramp in LIGHTNESS. Measured in Oklab
///              L, never in RGB distance, for bar_element's reason: about one man in twelve
///              cannot use hue at all, and lightness is the channel that always works.
///   WARNING    a shot that becomes lethal faster than a human can react. Measured in SECONDS of
///              travel between the shot appearing and the shot arriving.
///
/// ⛔⛔ THE CONTRAST CHECK EXISTS BECAUSE THIS STUDIO SHIPPED THE INVERSE DEFECT AND SPENT FIVE
/// BAKES ON IT. A ground shadow was tuned four different ways, every attempt pixel
/// identical, because the floor it was drawn on was `oklch 0.11 -> 0.07` - almost pure black - so
/// a dark mark on it was invisible BY CONSTRUCTION and no amount of changing the MARK could ever
/// have shown up (wing CLAUDE.md, 2026-09-05). The rule that came out of it is the rule this file
/// mechanises: BEFORE TUNING A MARK, CHECK THAT ITS BACKGROUND CAN SHOW IT. A buyer who picks a
/// dark element over a dark field is one command away from that same afternoon, and this is the
/// command.
///
/// ⚠️ WHAT IT IS NOT. It measures the CONFIGURATION, not the rendered frame. It cannot see a
/// buyer's own background sprite, a shader they added, or their ship. It reports on what this
/// package controls and says so, because a checker that claims more than it measures is worse
/// than none (master §2b).
/// ============================================================================================

/// Human reaction floor, in seconds. Below this a shot is not a challenge, it is a coin flip.
/// 0.25 is the conventional simple-visual-reaction figure and is used as a FLOOR, not a target;
/// the point is to catch 0.05, not to argue about 0.22 against 0.28.
#macro BAR_REACT_FLOOR 0.25

/// The minimum Oklab-L difference between a body and the field behind it.
/// Same units and the same reason as BAR_STOP_FLOOR in bar_element.
#macro BAR_FIELD_FLOOR 0.16

/// The graze band: how far outside the hitbox a near miss still reads, as a fraction of body
/// width. It exists because a hitbox smaller than the drawn body is the genre's core trick, and
/// an undrawn hitbox is the genre's core complaint.
#macro BAR_GRAZE_BAND 0.55

/// The drawn kill radius, in the same unit box every body is authored in (a body spans -0.5..0.5,
/// so this is a radius against a HALF-width of 0.5).
///
/// ⛔ THIS WAS A BARE 0.34 INSIDE bar_legibility_parts UNTIL 2026-09-05, and it was found by trying
/// to print it on a store sheet: the sheet's own subtitle promises "the number and the knob that
/// moves it", and the single most important number in the package - how big the thing that kills
/// you actually is - was a literal a buyer could not find, change, or read off the page. A product
/// that sells measurement cannot keep its headline constant anonymous.
#macro BAR_HITBOX_R 0.34

/// The radii the crowding check samples. A ring is most crowded when it is YOUNG, so the sweep runs
/// from near the emitter outward and the TIGHTEST sample is the one that decides whether a body is
/// narrow enough to survive the whole flight.
///
/// ⛔⛔ THESE EXIST BECAUSE A CALLER TYPED THE TIGHTEST RADIUS AS `0.267` AND IT WAS WRONG IN THE
/// FOURTH DECIMAL. The real value is 0.10 + (1.10 - 0.10) / 6 = 0.26667, and rounding it UP by
/// 0.0003 makes the gap look very slightly wider, which licenses a body one step too wide, which
/// the report then correctly flags. MEASURED 2026-09-05 building the store GIF: exactly ONE frame
/// of forty-four went red — 63 arms choosing `lance` — while 100 arms was fine, which reads as a
/// non-monotonic bug in the body ladder and is nothing of the kind.
///
/// ⭐ A NUMBER COPIED OUT OF ANOTHER FUNCTION IS A SECOND COPY OF A CONSTANT, and this factory's
/// standing law is that a second copy does not drift, it WINS. One declaration, two readers: the
/// report samples it and any caller asking "what body survives this pattern" asks for sample 1.
#macro BAR_CROWD_RMIN 0.10
#macro BAR_CROWD_RMAX 1.10
#macro BAR_CROWD_SAMPLES 6

function bar_legibility_crowd_r(_i) {
    return BAR_CROWD_RMIN + (BAR_CROWD_RMAX - BAR_CROWD_RMIN) * (_i / BAR_CROWD_SAMPLES);
}

/// ============================================================================================
/// CROWDING
/// ============================================================================================

/// The arc gap between adjacent shots of a wave at radius _r, in field units.
///
/// ⚠️ FOR A FULL RING THE ARMS WRAP AND FOR A FAN THEY DO NOT, and using the wrong one is a
/// silent off-by-one that under-reports crowding on exactly the densest patterns. A 360-degree
/// spread has `arms` gaps; anything narrower has `arms - 1`.
function bar_legibility_gap(_spec, _r) {
    var _full = (_spec.spread >= 359.5);
    var _gaps = _full ? _spec.arms : max(1, _spec.arms - 1);
    var _span = degtorad(_spec.spread) * max(0.0001, _r);
    return _span / _gaps;
}

/// Is this pattern legible at radius _r with body _body, drawn at _bodyscale field units?
function bar_legibility_crowding(_spec, _r, _body, _bodyscale) {
    var _info = bar_bullet_info(_body);
    var _w = _bodyscale / max(0.35, _info.aspect);
    var _gap = bar_legibility_gap(_spec, _r);
    // The clear channel between two bodies, edge to edge.
    var _clear = _gap - _w;
    return {
        gap: _gap,
        bodyWidth: _w,
        clear: _clear,
        // A player's ship needs somewhere to be. Half a body width is the tightest that has ever
        // been playable; below zero the wave is a solid wall.
        ok: (_clear >= _w * 0.5),
        solid: (_clear <= 0),
    };
}

/// ============================================================================================
/// CONTRAST
/// ============================================================================================

/// The worst-case L separation between an element's body and a field whose ramp runs _fieldL0 to
/// _fieldL1 in Oklab L.
///
/// ⭐ WORST CASE, NOT AVERAGE, AND THAT IS THE WHOLE POINT. A shot crosses the ENTIRE field, so
/// the only number that matters is the band where it is hardest to see. An average would report a
/// bullet as legible because it is legible somewhere, which is precisely the reasoning that put a
/// black shadow on a black floor.
function bar_legibility_contrast(_elem, _fieldL0, _fieldL1, _charge) {
    var _worst = 999;
    var _atStop = -1;
    var _atField = 0;
    // The stops that carry the body's identity: m1..m4 and the core. m0 is the shadowed flank and
    // is allowed to disappear into a dark field - it is an internal edge, not the silhouette.
    for (var _i = 1; _i <= 4; _i++) {
        var _l = bar_element_stop_l(_elem, _i, _charge);
        // Sample the field ramp; the worst point is wherever it comes closest to this stop.
        for (var _j = 0; _j <= 8; _j++) {
            var _fl = _fieldL0 + (_fieldL1 - _fieldL0) * (_j / 8);
            var _d = abs(_l - _fl);
            if (_d < _worst) { _worst = _d; _atStop = _i; _atField = _fl; }
        }
    }
    return {
        worst: _worst,
        atStop: _atStop,
        atFieldL: _atField,
        ok: (_worst >= BAR_FIELD_FLOOR),
    };
}

/// ============================================================================================
/// WARNING TIME
/// ============================================================================================

/// How long a shot is visible before it reaches distance _r, in seconds.
///
/// ⚠️ SOLVED, NOT SIMULATED. r = v*t + a*t*t/2 inverted, so the answer is exact and instant for
/// any t - which is the pure-function property bar_pattern's header exists to defend. A stepped
/// simulation would give the same answer more slowly and would be wrong by a frame.
function bar_legibility_warning(_spec, _r) {
    var _v = max(0.00001, _spec.speed);
    var _a = _spec.accel;
    if (abs(_a) < 0.0001) return _r / _v;
    var _disc = _v * _v + 2 * _a * _r;
    if (_disc < 0) return 999;                    // never arrives
    return (-_v + sqrt(_disc)) / _a;
}

/// ============================================================================================
/// THE REPORT
/// ============================================================================================

/// Check a whole pattern configuration and hand back every problem found.
///
/// ⛔ IT NAMES THE FAILURE AND THE NUMBER, NEVER JUST A BOOLEAN. A silent refusal is correct
/// behaviour that cannot be told apart from a defect (master §2b), and "your pattern is illegible"
/// with no number is a support ticket rather than a fix. Every issue carries what was measured,
/// what the floor was, and which knob moves it.
///
/// ⚠️ AND IT REPORTS `checked` SO A CLEAN RESULT CANNOT BE CONFUSED WITH AN EMPTY ONE. An empty
/// result is not a finding: a report of zero issues over zero checks is what a broken checker
/// returns, and this wing has shipped that shape before.
function bar_legibility_report(_spec, _elem, _body, _bodyscale, _fieldL0, _fieldL1) {
    var _issues = [];
    var _checked = 0;
    var _bs = is_undefined(_bodyscale) ? 0.06 : _bodyscale;
    var _f0 = is_undefined(_fieldL0) ? 0.14 : _fieldL0;
    var _f1 = is_undefined(_fieldL1) ? 0.30 : _fieldL1;

    // CROWDING, sampled across the radii the pattern actually occupies rather than at one radius.
    // A ring is most crowded when it is YOUNG, so checking only the outer edge passes everything.
    for (var _i = 1; _i <= BAR_CROWD_SAMPLES; _i++) {
        var _r = bar_legibility_crowd_r(_i);
        _checked++;
        var _c = bar_legibility_crowding(_spec, _r, _body, _bs);
        if (!_c.ok) {
            array_push(_issues, {
                kind: "crowding",
                at: _r,
                measured: _c.clear,
                floor: _c.bodyWidth * 0.5,
                solid: _c.solid,
                fix: "lower arms, raise speed so the wave opens sooner, or let bar_bullet_for pick a narrower body",
            });
            break;      // one crowding issue is the finding; six copies of it is noise.
        }
    }

    // CONTRAST, at rest and fully charged: a shot that is legible only while winding up is not
    // legible. Both ends, because the ramp SLIDES with charge.
    _checked += 2;
    var _k0 = bar_legibility_contrast(_elem, _f0, _f1, 0);
    var _k1 = bar_legibility_contrast(_elem, _f0, _f1, 1);
    if (!_k0.ok || !_k1.ok) {
        var _w = min(_k0.worst, _k1.worst);
        array_push(_issues, {
            kind: "contrast",
            measured: _w,
            floor: BAR_FIELD_FLOOR,
            fieldL: (_k0.worst <= _k1.worst) ? _k0.atFieldL : _k1.atFieldL,
            fix: "pick an element whose ramp clears the field, or move the field ramp - a dark shot on a dark field is invisible by construction, not by tuning",
        });
    }

    // WARNING TIME at the near radius, where a player is standing.
    _checked++;
    var _warn = bar_legibility_warning(_spec, 0.35);
    if (_warn < BAR_REACT_FLOOR) {
        array_push(_issues, {
            kind: "warning",
            measured: _warn,
            floor: BAR_REACT_FLOOR,
            fix: "lower speed or accel, or start the wave further out",
        });
    }

    return {
        ok: (array_length(_issues) == 0),
        checked: _checked,
        issues: _issues,
        pattern: bar_pattern_name(_spec.fam),
        body: bar_bullet_info(_body).name,
    };
}

/// One line a buyer can print. The report is the machine-readable form; this is the human one.
function bar_legibility_line(_rep) {
    if (_rep.checked <= 0) return "BARRAGE legibility: NOTHING CHECKED - this is not a pass.";
    if (_rep.ok) return "BARRAGE legibility: " + string(_rep.checked) + " checks, no issues ("
        + _rep.pattern + " / " + _rep.body + ")";
    var _s = "BARRAGE legibility: " + string(array_length(_rep.issues)) + " of "
        + string(_rep.checked) + " checks flagged (" + _rep.pattern + " / " + _rep.body + ")";
    for (var _i = 0; _i < array_length(_rep.issues); _i++) {
        var _it = _rep.issues[_i];
        _s += "\n  " + _it.kind + ": measured " + string_format(_it.measured, 1, 4)
            + " against floor " + string_format(_it.floor, 1, 4) + " -> " + _it.fix;
    }
    return _s;
}

/// ============================================================================================
/// THE GRAZE BAND
/// ============================================================================================

/// The drawn hitbox for a shot: the small circle that actually kills, plus the band that reads as
/// a near miss.
///
/// ⭐ THE HITBOX IS SMALLER THAN THE BODY AND THAT IS THE GENRE'S CORE TRICK - it is what makes a
/// wall of fire survivable and thrilling rather than merely unfair. It is also the genre's core
/// COMPLAINT, because most games never draw it, so the player has to learn it by dying. Drawing
/// it is free and this package does it by default.
function bar_legibility_hitbox(_bodyscale) {
    var _bs = is_undefined(_bodyscale) ? 0.06 : _bodyscale;
    return {
        kill: _bs * 0.34,
        graze: _bs * 0.34 * (1 + BAR_GRAZE_BAND),
    };
}

/// The hitbox and graze band as drawable parts, in unit-box space.
function bar_legibility_parts(_show) {
    var _o = [];
    if (!_show) return _o;
    bar_append(_o, bar_ring(0, 0, BAR_HITBOX_R * (1 + BAR_GRAZE_BAND), 0.014, "graze"));
    bar_append(_o, bar_dot(0, 0, BAR_HITBOX_R, "core"));
    return _o;
}
