{
  "$GMScript": "v1",
  "%Name": "bar_palette",
  "name": "bar_palette",
  "isCompatibility": false,
  "isDnD": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}