/// BARRAGE - bar_palette. Part of the shared drawing foundation.
///
/// This file is the studio's cross-product drawing/colour layer, carried forward with more
/// than 2,300 in-engine assertions behind it - including the GML default-epsilon fix
/// described below, which had produced a suite of assertions that could never go red.
///
/// ⛔ GML APPLIES A DEFAULT EPSILON TO NUMERIC COMPARISONS, and it is 0.00001 on this runtime
/// - MEASURED by bar_selftest, which prints math_get_epsilon() into its own result file at
/// twelve decimals. Any tolerance at or below about 0.00001 can NEVER fire, in either
/// direction, so a distinctness assertion written that way passes vacuously forever and an
/// equality assertion written that way goes red on two values that are the same object.
/// Never write one here. And GML has no exponent-literal syntax at all: `1e-5` is a lexer
/// error that reads like a bracket bug.
///
/// The colour MATHS only. Oklab -> linear sRGB, the gamma transfer, a per-lightness chroma
/// ceiling, and bar_oklch.
///
/// -- WHY OKLCH AND NOT HSV -------------------------------------------------------------
/// A bullet is not a colour, it is a RAMP: five stops from the blown-out core that reads as the
/// hot centre of the shot, down through the body's lit flank, to the outermost aura where it dies
/// into whatever it is crossing. What makes a shot read as PLASMA rather than as blue is that
/// those five stops are evenly spaced in APPARENT lightness, and that the spacing survives being
/// re-hued from plasma to ember to venom to bone.
///
/// ⭐ AND ON THIS PRODUCT THAT IS NOT A NICETY, IT IS A SAFETY PROPERTY. A projectile has no colour
/// of its own; it is one set of outlines drawn through whichever element ramp fired it, and every
/// one of those ramps has to keep a bullet legible against the bullet behind it AND against the
/// field it crosses. In HSV, "same saturation" means wildly different apparent contrast across the
/// hue circle, so a ramp tuned on warm ember collapses on cold plasma - and a buyer whose boss
/// fires a cold pattern would find their bullets had merged into one blue smear, with no change to
/// a single line of their own code. In this genre that is not an aesthetic complaint: an
/// unreadable bullet is a death the player could not have avoided, and a refund. That is the
/// failure mode a static spritesheet cannot have and a generated corpus can, so it is the one this
/// file exists to prevent. Oklab spaces colour by how it LOOKS, for about twenty lines of matrix
/// arithmetic, which is the only reason bar_element can assert a per-stop separation floor across
/// every element and have that assertion mean something.
///
/// ⛔ AND THE TWO LAWS THAT COST THIS WING MOST LIVE HERE. (1) A ramp SLIDES to fit between the
/// floor and the ceiling and is NEVER clamped at its ends - Hearth's limewash clamped its top two
/// stops to the same value and drew a dome as a flat fill with a line round it. (2) Interpolating
/// the HUE of a colour that has no CHROMA is meaningless - a donor several products back drove a
/// near-neutral through magenta, because a neutral's hue is a direction the ramp leans, not a
/// colour anyone can see. Weight a hue blend by CHROMA CONTRIBUTION, never by the transform's own
/// progress.
///
/// ⚠️ AND THE SECOND OF THOSE IS THIS PRODUCT'S CENTRAL COLOUR RISK, not a footnote. Several
/// elements here are near-neutral by nature - bone, ash, steel shot, shadow - and the others are
/// strongly chromatic - plasma, ember, venom, arc. Every transform this product owns (charging,
/// arming, the danger ramp as a shot goes lethal, fading into a trail) blends between exactly such
/// a pair, which is the case the naive version gets wrong. Tune a transform on the PALEST and most
/// NEUTRAL element, never on the plasma.
///
/// ⚠️ THIS PARAGRAPH WAS MISSED BY AN EARLIER PORT'S SURVIVOR SCAN, and the miss is worth keeping
/// because it is structural rather than careless. Internal_Ops/scaffold.js scans for a fixed list
/// of SUBJECT NOUNS from the file this drawing layer was carried forward from; the paragraph that
/// used to sit here was written entirely out of words that were not on that list, and it survived
/// two further hops. A word list can only ever catch the words someone thought of. ⇒ after any
/// future port, READ the ported files as well as running the scan - the scan narrows where to
/// look, it does not certify what it did not check. (This port found it exactly that way: the
/// scan reported ZERO survivors in this file, with a live positive control proving the scan
/// worked, and the whole section above was still the donor's subject.)
///
/// ⛔ Barrage's own element ramps, charge trajectories and accent derivations live in bar_element,
/// built on the four functions below. Nothing product-specific belongs in this file.
/// ============================================================================================
#macro BAR_GOLDEN_ANGLE 137.50776405003785
#macro BAR_SAT_FLOOR 0.045

/// Oklab -> linear sRGB. Bjorn Ottosson's matrices.
function bar_oklab_linear(_L, _a, _b) {
    var _l = _L + 0.3963377774 * _a + 0.2158037573 * _b;
    var _m = _L - 0.1055613458 * _a - 0.0638541728 * _b;
    var _s = _L - 0.0894841775 * _a - 1.2914855480 * _b;
    _l = _l * _l * _l; _m = _m * _m * _m; _s = _s * _s * _s;
    return [
         4.0767416621 * _l - 3.3077115913 * _m + 0.2309699292 * _s,
        -1.2684380046 * _l + 2.6097574011 * _m - 0.3413193965 * _s,
        -0.0041960863 * _l - 0.7034186147 * _m + 1.7076147010 * _s
    ];
}

function bar_gamma(_c) {
    return (_c <= 0.0031308) ? (12.92 * _c) : (1.055 * power(_c, 1 / 2.4) - 0.055);
}

/// Chroma ceiling near white and near black.
///
/// Oklab will happily hand back a fully-saturated colour at L 0.95 and sRGB renders it as neon.
/// Real ink gets LESS chromatic as it approaches paper-white or lamp-black; this curve puts that
/// back, and it is what keeps the top two rarities looking expensive instead of radioactive.
function bar_chroma_ceiling(_L, _C) {
    var _hi = max(0, (_L - 0.68) / 0.32);
    var _lo = max(0, (0.22 - _L) / 0.22);
    return _C * (1 - _hi * 0.62) * (1 - _lo * 0.45);
}

/// Oklch -> a GameMaker colour, with GAMUT REDUCTION rather than clipping.
///
/// Clipping an out-of-gamut colour shifts its HUE - a too-saturated blue clips to purple - which
/// would quietly undo the perceptual spacing this whole file exists to provide. Walking chroma
/// down until the colour fits keeps the hue exactly where it was put.
function bar_oklch(_L, _C, _hdeg) {
    var _h = degtorad(_hdeg);
    var _c = bar_chroma_ceiling(_L, _C);
    var _rgb;
    for (var _i = 0; _i < 24; _i++) {
        _rgb = bar_oklab_linear(_L, cos(_h) * _c, sin(_h) * _c);
        if (_rgb[0] >= -0.0015 && _rgb[1] >= -0.0015 && _rgb[2] >= -0.0015
         && _rgb[0] <=  1.0015 && _rgb[1] <=  1.0015 && _rgb[2] <=  1.0015) break;
        _c *= 0.92;
    }
    _rgb = bar_oklab_linear(_L, cos(_h) * _c, sin(_h) * _c);
    return make_colour_rgb(
        round(clamp(bar_gamma(clamp(_rgb[0], 0, 1)), 0, 1) * 255),
        round(clamp(bar_gamma(clamp(_rgb[1], 0, 1)), 0, 1) * 255),
        round(clamp(bar_gamma(clamp(_rgb[2], 0, 1)), 0, 1) * 255)
    );
}
