/// bar_selftest.gml — the in-engine suite. Runs headless, writes its result to a file.
///
/// ⚠️ THIS IS THE ONLY REAL TEST THIS WING HAS. GML cannot be unit-tested outside the engine: no
/// Node-mockable core, no -batchmode equivalent. Verification risk here is structurally higher
/// than in the other wings and pretending otherwise is the failure master §2 forbids.
///
/// ⛔ THE FOUR ROUTES THAT DO NOT WORK, all measured by this wing before this one:
///   - `show_debug_message` + `-debugoutput <file>` : DEAD in a release build.
///   - `game_end(n)` -> process exit code           : the argument is NOT propagated.
///   - driving Igor directly for the build          : without `--uf=` it reports a Permission
///     Error identical to a lapsed licence, on a healthy machine. Shell out to gm_gate.ps1.
///   - `file_text_open_write` to %LOCALAPPDATA%      : ✅ the one that works.
///
/// ⛔ A GML RUNTIME ERROR OPENS A MODAL DIALOG, so headless the process NEVER EXITS - an opaque
/// hang with no output. `exception_unhandled_handler` is installed first thing, and every stage
/// records a number into a GLOBAL, so a crash reports WHERE.
///
/// ⛔⛔ AND THE STAGE MARKER MUST BE WRITTEN TO THE GLOBAL, NOT ONLY TO THE LOCAL STRUCT. A sibling
/// product's first version set only the local, so the crash handler - which reads the global -
/// reported "stage 1" for a crash anywhere in the suite, turning a located failure back into an
/// opaque one. An instrument that always answers "1" is not reporting, it is agreeing.
///
/// -- WHAT THIS SUITE IS FOR, GIVEN THE LIEGE LESSON --------------------------------------------
/// ⛔ A SIBLING PRODUCT PASSED **164/164** WITH ITS ENTIRE TEXT LAYER DEAD, because not one of its
/// 164 assertions drew a string: a whole subsystem at zero coverage, invisible because the COUNT
/// was large. So this suite is written against the CLAIMS the product makes, not against the code
/// that happens to be easy to reach, and every stage names the claim it is defending.
/// ============================================================================================

/// ⚠️ TOLERANCE FLOOR. GML applies a DEFAULT EPSILON to numeric comparisons, measured by this wing
/// at 0.00001 off a real Igor-built exe. A tolerance AT or BELOW it is unusable in BOTH
/// directions: a smaller one is false for every pair including equal ones, and one AT it goes red
/// on two values that are the same object. Never write a tolerance below ~1e-5, and never AT it.
/// (And GML has no exponent-literal syntax: `1e-5` is a lexer error that reads like a bracket bug.)
#macro BAR_ST_EPS 0.0001

function bar_st_assert(_st, _cond, _msg) {
    _st.total += 1;
    if (_cond) { _st.pass += 1; return true; }
    _st.fail += 1;
    if (array_length(_st.failures) < 40) array_push(_st.failures, _msg);
    return false;
}

function bar_st_stage(_st, _n) {
    _st.stage = _n;
    global.bar_stage = _n;
}

function bar_selftest_run() {
    var _st = { total: 0, pass: 0, fail: 0, failures: [], stage: 0, notes: [] };

    // -- STAGE 1: the runtime still applies an epsilon -----------------------------------------
    // ⛔ A POSITIVE TEST ON PURPOSE. The natural form `_e > 0 && _e < TOL` goes RED on its first
    // clause: the difference between the epsilon and zero IS the epsilon, so GML calls them equal
    // and equal is not greater-than. Do not "repair" this into one clause.
    bar_st_stage(_st, 1);
    var _e = math_get_epsilon();
    bar_st_assert(_st, !(_e > BAR_ST_EPS), "default epsilon larger than this suite's tolerance: " + string(_e));
    bar_st_assert(_st, !(_e < 0), "math_get_epsilon() went negative: " + string(_e));

    // -- STAGE 2: THE COUNT CLAIM ---------------------------------------------------------------
    // CLAIM: "44 bodies, 12 elements, 12 pattern families". These numbers go in the listing copy,
    // and this wing has shipped a live page claiming a pack was HALF its real size for days,
    // because the checker held the same stale number the page did. So the macro is asserted
    // against the DISPATCH, never used in place of it.
    bar_st_stage(_st, 2);
    var _bodies = bar_bullet_table();
    var _elems = bar_element_table();
    var _pats = bar_pattern_table();
    bar_st_assert(_st, array_length(_bodies) == BAR_BODY_COUNT,
        "BAR_BODY_COUNT says " + string(BAR_BODY_COUNT) + " but the table holds " + string(array_length(_bodies)));
    bar_st_assert(_st, bar_bullet_count() == array_length(_bodies),
        "bar_bullet_count() disagrees with its own table");
    bar_st_assert(_st, array_length(_elems) == BAR_ELEMENT_COUNT,
        "BAR_ELEMENT_COUNT says " + string(BAR_ELEMENT_COUNT) + " but the table holds " + string(array_length(_elems)));
    bar_st_assert(_st, array_length(_pats) == BAR_PATTERN_COUNT,
        "BAR_PATTERN_COUNT says " + string(BAR_PATTERN_COUNT) + " but the table holds " + string(array_length(_pats)));
    // VACUITY: the corpus must actually be large, or every sweep below passes over nothing.
    bar_st_assert(_st, array_length(_bodies) >= 40,
        "VACUITY: the corpus is " + string(array_length(_bodies)) + " bodies, below the 40 this product's Gate 1 claim rests on");

    // -- STAGE 3: NAMES ARE UNIQUE --------------------------------------------------------------
    // A duplicate name makes bar_bullet_find return the first of two different bodies, silently.
    bar_st_stage(_st, 3);
    for (var _i = 0; _i < array_length(_bodies); _i++) {
        bar_st_assert(_st, bar_bullet_find(_bodies[_i].name) == _i,
            "body name '" + _bodies[_i].name + "' does not resolve back to its own index");
    }
    for (var _i = 0; _i < array_length(_elems); _i++) {
        bar_st_assert(_st, bar_element_find(_elems[_i].name) == _i,
            "element name '" + _elems[_i].name + "' does not resolve back to its own index");
    }

    // -- STAGE 4: THE ELEMENT SEPARATION FLOOR --------------------------------------------------
    // CLAIM (bar_element): "every adjacent pair of stops differs by at least BAR_STOP_FLOOR in
    // Oklab L". Checked at rest AND fully charged, because the ramp SLIDES with charge and a
    // floor that only holds at rest is a floor that fails exactly when the shot is about to hurt.
    bar_st_stage(_st, 4);
    var _worstStop = 999;
    var _worstStopWhere = "";
    for (var _i = 0; _i < array_length(_elems); _i++) {
        for (var _c = 0; _c <= 1; _c++) {
            for (var _s = 0; _s < 4; _s++) {
                var _a = bar_element_stop_l(_i, _s, _c);
                var _b = bar_element_stop_l(_i, _s + 1, _c);
                var _d = abs(_b - _a);
                if (_d < _worstStop) { _worstStop = _d; _worstStopWhere = _elems[_i].name + " m" + string(_s) + "/m" + string(_s + 1) + " charge " + string(_c); }
                bar_st_assert(_st, _d >= BAR_STOP_FLOOR,
                    _elems[_i].name + ": stops m" + string(_s) + " and m" + string(_s + 1)
                    + " differ by only " + string(_d) + " in L at charge " + string(_c)
                    + " (floor " + string(BAR_STOP_FLOOR) + ") - two surfaces of this body will render as one");
            }
        }
    }
    array_push(_st.notes, "worst element stop gap " + string(_worstStop) + " at " + _worstStopWhere
        + " (floor " + string(BAR_STOP_FLOOR) + ")");

    // -- STAGE 5: THE PROFILE NEVER COLLAPSES ---------------------------------------------------
    // CLAIM (bar_bullet): "the profile never returns exactly zero at either end", because a zero
    // half-width duplicates a vertex, which caps every bevel to nothing and breaks bar_inset's
    // direction. Swept across every body and the whole travel axis.
    bar_st_stage(_st, 5);
    var _minHalf = 999;
    for (var _i = 0; _i < array_length(_bodies); _i++) {
        for (var _k = 0; _k <= 24; _k++) {
            var _h = bar_bullet_halfwidth(_k / 24, _bodies[_i].p, _bodies[_i].cl);
            if (_h < _minHalf) _minHalf = _h;
            bar_st_assert(_st, _h > 0.01,
                _bodies[_i].name + ": half-width collapsed to " + string(_h) + " at t=" + string(_k / 24));
        }
    }
    array_push(_st.notes, "smallest profile half-width " + string(_minHalf));

    // -- STAGE 6: EVERY OUTLINE IS A SIMPLE, CORRECTLY-WOUND POLYGON ----------------------------
    // The geometry assertion bar_shape's header says is "the only mechanical thing that can see"
    // the winding defect. A self-crossing outline fills the wrong region and throws bar_inset's
    // points a long way outside the shape.
    bar_st_stage(_st, 6);
    var _minPts = 99999;
    var _outlines = array_create(array_length(_bodies), []);
    for (var _i = 0; _i < array_length(_bodies); _i++) {
        var _o = bar_bullet_outline(_i, 18);
        var _n = array_length(_o);
        if (_n < _minPts) _minPts = _n;
        bar_st_assert(_st, _n >= 8, _bodies[_i].name + ": outline has only " + string(_n) + " points");
        _outlines[_i] = _o;
        bar_st_assert(_st, bar_is_simple(_o), _bodies[_i].name + ": outline self-intersects");
        // ⚠️ bar_turning RETURNS REVOLUTIONS, NOT RADIANS - it divides by BAR_TAU on its last line.
        // The first version of this assertion compared against BAR_TAU and went red on all 45
        // bodies while the geometry was correct: 45 false reds from one unit mistake in the
        // CHECKER. That is master §2b's rule running in my own favour for once - when an
        // instrument disagrees with something already proven, suspect the instrument - and it is
        // also why the failure message prints the value, because "1.00" against an expectation of
        // 6.28 named the cause on sight.
        var _turn = bar_turning(_o);
        bar_st_assert(_st, abs(abs(_turn) - 1.0) < 0.02,
            _bodies[_i].name + ": total turning is " + string(_turn) + " revolutions, not one");
        var _dd = bar_dedupe_pts(_o);
        bar_st_assert(_st, array_length(_dd) == _n,
            _bodies[_i].name + ": outline carries duplicate vertices (" + string(_n) + " -> " + string(array_length(_dd)) + ")");
    }
    array_push(_st.notes, "smallest outline " + string(_minPts) + " points");

    // -- STAGE 6b: NO TWO BODIES ARE THE SAME SHAPE --------------------------------------------
    // ⛔⛔ THE ASSERTION THE CORPUS CLAIM ACTUALLY RESTS ON, AND IT WAS MISSING UNTIL A DUPLICATE
    // SHIPPED. `star4` and `spark` shared an ornament index and resolved to the identical outline
    // - same points, same relief, same everything, under two names - so "45 distinct bodies" was
    // false by one. Every other assertion in this suite passes a duplicate perfectly, because a
    // duplicate is a perfectly valid shape; the only thing that can see it is a comparison
    // BETWEEN bodies. The volume is this product's moat, so this defends the number in the copy.
    // ⛔ COMPARED ON THE WHOLE DRAWN BODY, NOT ON THE OUTLINE. The first version of this stage
    // compared outlines and went red 106 times - on every ROUND, RING and ARCANE body, because
    // those share a circle BY DESIGN: their identity is internal (the core, the ring, the spokes,
    // the arcs), which is what bar_bullet's own header says. A check that flags 106 correct cases
    // is not a stricter gate, it is a deleted one (master §2b), and weakening it to silence would
    // have been worse. The claim is "45 distinct BODIES", so the comparison is over the body a
    // buyer actually sees: every part, its kind, its role and its geometry.
    var _sigs = array_create(array_length(_bodies), 0);
    for (var _i = 0; _i < array_length(_bodies); _i++) {
        var _ps = bar_bullet_parts(_i, 0);
        var _sig = array_length(_ps) * 1000;
        for (var _k = 0; _k < array_length(_ps); _k++) {
            var _p2 = _ps[_k];
            // ⛔ ABSOLUTE VALUES AND AN INDEX WEIGHT. MEASURED: the first fold summed SIGNED
            // coordinates, and a symmetric shape sums to ~0 no matter how big it is - so star4 and
            // caltrop (inner radius 0.46 against 0.26, plainly different shapes) collided, as did
            // star6 and spark. A signature that cancels on exactly the shapes this corpus is full
            // of reports duplicates that are not there, which would have had me "fixing" two
            // correct bodies. The index weight also makes the fold order-sensitive, so two shapes
            // with the same vertices in a different order are not conflated.
            _sig += _p2.kind * 31 + string_length(_p2.role) * 7;
            if (variable_struct_exists(_p2, "cx")) _sig += abs(_p2.cx) * 977 + abs(_p2.cy) * 613;
            if (variable_struct_exists(_p2, "r"))  _sig += abs(_p2.r) * 1471;
            if (variable_struct_exists(_p2, "pts")) {
                var _pp = _p2.pts;
                for (var _m = 0; _m < array_length(_pp); _m++) {
                    _sig += (abs(_pp[_m][0]) * 13 + abs(_pp[_m][1]) * 29) * (1 + _m * 0.017);
                }
            }
        }
        _sigs[_i] = _sig;
    }
    var _dupes = 0;
    var _worstPair = "";
    var _closest = 999999;
    for (var _i = 0; _i < array_length(_bodies); _i++) {
        for (var _j = _i + 1; _j < array_length(_bodies); _j++) {
            var _d = abs(_sigs[_i] - _sigs[_j]);
            if (_d < _closest) { _closest = _d; _worstPair = _bodies[_i].name + "/" + _bodies[_j].name; }
            if (_d < 0.001) {
                _dupes++;
                bar_st_assert(_st, false, "DUPLICATE BODY: " + _bodies[_i].name + " and "
                    + _bodies[_j].name + " draw the same thing - the corpus count is overstated by one");
            }
        }
    }
    bar_st_assert(_st, _dupes == 0, "the corpus contains " + string(_dupes) + " duplicate body pair(s)");
    // VACUITY: the sweep must have compared something, or a clean result means nothing.
    bar_st_assert(_st, _closest < 999, "VACUITY: no two bodies were ever compared for distinctness");
    array_push(_st.notes, "closest distinct body pair " + _worstPair + " at " + string(_closest));

    // -- STAGE 7: SPIN SAFETY IS REAL, AND THE CHECK IS NOT VACUOUS -----------------------------
    // CLAIM (bar_render's cache header): "bar_render_to_sprite must only ever be handed a
    // spin_safe body, and bar_selftest asserts it". A spin_safe body must be radially symmetric,
    // i.e. aspect 1. ⛔ AND THE CORPUS MUST CONTAIN BOTH KINDS, or this whole stage is a check
    // that cannot fail - the vacuous-control shape master §2b records.
    bar_st_stage(_st, 7);
    var _spin = 0;
    var _nospin = 0;
    for (var _i = 0; _i < array_length(_bodies); _i++) {
        if (_bodies[_i].spin) {
            _spin++;
            bar_st_assert(_st, abs(_bodies[_i].aspect - 1.0) < BAR_ST_EPS,
                _bodies[_i].name + " is marked spin_safe but its aspect is " + string(_bodies[_i].aspect)
                + " - it has a nose, so a cached sprite would carry its lit side round with it");
        } else {
            _nospin++;
        }
    }
    bar_st_assert(_st, _spin > 0, "VACUITY: no body is spin_safe, so stage 7 asserted nothing");
    bar_st_assert(_st, _nospin > 0, "VACUITY: every body is spin_safe, so the distinction is not being made");
    array_push(_st.notes, "spin-safe bodies " + string(_spin) + ", directional " + string(_nospin));

    // -- STAGE 8: A BODY IS ACTUALLY DRAWN, AND IT IS NOT EMPTY ---------------------------------
    // ⛔ THE LIEGE LESSON: a large assertion count over a subsystem with zero coverage. Stages 5-7
    // are all about the OUTLINE; nothing so far has built a real part list. This does.
    bar_st_stage(_st, 8);
    var _minParts = 99999;
    var _pal = bar_element_pal(0, 0);
    for (var _i = 0; _i < array_length(_bodies); _i++) {
        var _parts = bar_bullet_parts(_i, 0);
        var _np = array_length(_parts);
        if (_np < _minParts) _minParts = _np;
        bar_st_assert(_st, _np >= 4,
            _bodies[_i].name + ": builds only " + string(_np) + " parts - a body is an aura, a fill, a relief and an outline at minimum");
        // Every role a part names must resolve to a real colour, or bar_render_colour silently
        // falls back to `line` and the body renders as a flat silhouette.
        var _bad = "";
        for (var _j = 0; _j < _np; _j++) {
            var _role = _parts[_j].role;
            if (!variable_struct_exists(_pal, _role)) _bad = _role;
        }
        bar_st_assert(_st, _bad == "",
            _bodies[_i].name + ": uses role '" + _bad + "' which no element palette defines - it would silently render as the outline colour");
    }
    array_push(_st.notes, "smallest body part-count " + string(_minParts));

    // -- STAGE 9: CHARGE MOVES THE RAMP AND NOT THE SILHOUETTE ----------------------------------
    // CLAIM (bar_bullet): "charge does NOT change the silhouette - SHAPE says what it is,
    // BRIGHTNESS says how soon". Asserted in BOTH directions: the outline must be identical, and
    // the ramp must actually have moved. One without the other is half a claim.
    bar_st_stage(_st, 9);
    var _moved = 0;
    for (var _i = 0; _i < array_length(_bodies); _i++) {
        var _o0 = bar_bullet_outline(_i, 14);
        var _o1 = bar_bullet_outline(_i, 14);
        var _same = (array_length(_o0) == array_length(_o1));
        if (_same) {
            for (var _k = 0; _k < array_length(_o0); _k++) {
                if (abs(_o0[_k][0] - _o1[_k][0]) > BAR_ST_EPS || abs(_o0[_k][1] - _o1[_k][1]) > BAR_ST_EPS) { _same = false; break; }
            }
        }
        bar_st_assert(_st, _same, _bodies[_i].name + ": outline is not deterministic");
    }
    for (var _i = 0; _i < array_length(_elems); _i++) {
        var _l0 = bar_element_stop_l(_i, 4, 0);
        var _l1 = bar_element_stop_l(_i, 4, 1);
        if (abs(_l1 - _l0) > 0.01) _moved++;
    }
    bar_st_assert(_st, _moved == array_length(_elems),
        "only " + string(_moved) + " of " + string(array_length(_elems)) + " elements change lightness under charge - the tell does not reach the ramp");

    // -- STAGE 10: THE PATTERN IS A PURE FUNCTION -----------------------------------------------
    // CLAIM (bar_pattern's header): "two calls asking for the same shot MUST return the same
    // shot". Every assertion about patterns depends on it, so it is asserted rather than assumed -
    // and it is the one property `random()` would silently destroy.
    bar_st_stage(_st, 10);
    for (var _f = 0; _f < BAR_PATTERN_COUNT; _f++) {
        var _spec = bar_pattern_preset(_f);
        for (var _k = 0; _k < 6; _k++) {
            var _t = 0.1 + _k * 0.37;
            var _s1 = bar_pattern_shot(_spec, _k % _spec.waves, _k, _t);
            var _s2 = bar_pattern_shot(_spec, _k % _spec.waves, _k, _t);
            bar_st_assert(_st, abs(_s1.x - _s2.x) < BAR_ST_EPS && abs(_s1.y - _s2.y) < BAR_ST_EPS,
                bar_pattern_name(_f) + ": the same shot returned two different positions - the pattern is not pure");
        }
    }

    // -- STAGE 11: `alive` IS FALSE IN BOTH DIRECTIONS ------------------------------------------
    // CLAIM (bar_pattern): "`alive` is false BEFORE the shot is born as well as after it leaves,
    // and callers that treat 'not alive' as 'gone' will draw wave 5 at t=0". A pattern that fires
    // everything on frame one is the bug that looks like a working pattern in a screenshot, so it
    // is asserted from both ends.
    bar_st_stage(_st, 11);
    for (var _f = 0; _f < BAR_PATTERN_COUNT; _f++) {
        var _spec = bar_pattern_preset(_f);
        var _late = bar_pattern_shot(_spec, _spec.waves - 1, 0, 0.0);
        bar_st_assert(_st, !_late.alive || _spec.waves == 1,
            bar_pattern_name(_f) + ": the LAST wave is already alive at t=0 - every wave fires at once");
        var _first = bar_pattern_shot(_spec, 0, 0, 0.0);
        bar_st_assert(_st, _first.alive,
            bar_pattern_name(_f) + ": the FIRST wave is not alive at t=0 - the pattern never starts");
        // and the radius must grow with time, or the shots do not travel.
        var _r1 = bar_pattern_radius(_spec, 0.30);
        var _r2 = bar_pattern_radius(_spec, 0.90);
        bar_st_assert(_st, _r2 > _r1 || _spec.fam == BAR_PAT_CONVERGE,
            bar_pattern_name(_f) + ": leading edge did not advance between t=0.30 and t=0.90");
    }

    // -- STAGE 12: LIVE SHOTS EXIST, AND ARE NOT ALL OF THEM ------------------------------------
    // A `live` list that returns everything is the same defect as one that returns nothing: both
    // mean the filter is not running. Asserted as a band, not a boolean.
    bar_st_stage(_st, 12);
    for (var _f = 0; _f < BAR_PATTERN_COUNT; _f++) {
        var _spec = bar_pattern_preset(_f);
        var _all = _spec.arms * _spec.waves;
        var _n = array_length(bar_pattern_live(_spec, _spec.gap * 1.5));
        bar_st_assert(_st, _n > 0, bar_pattern_name(_f) + ": no shots are live mid-pattern");
        bar_st_assert(_st, _n <= _all, bar_pattern_name(_f) + ": more shots live than the pattern has");
    }

    // -- STAGE 13: THE COUPLING ACTUALLY COUPLES ------------------------------------------------
    // ⛔ THIS IS THE PRODUCT'S HEADLINE CLAIM AND THEREFORE THE ASSERTION THAT MATTERS MOST:
    // "the body answers to the pattern". A connectivity test at a FLOOR cannot detect connection
    // (master §2b), so it is asked from BOTH ends of the range: a sparse ring must keep a wide
    // body, and a dense one must be narrowed. If both return the same body the coupling is dead
    // and every claim in the listing copy about it is false.
    bar_st_stage(_st, 13);
    var _bs = 0.055;
    // ⛔ THE DENSE END IS 96 ARMS, NOT 48, AND THE REASON IS THE POINT OF THIS COMMENT. At 48 arms
    // on a ring of radius 0.9 the arc gap is 0.118 and a 0.055 pellet leaves 1.1 body widths of
    // clear channel - it genuinely FITS, so the correct behaviour is to change nothing. The first
    // version of this stage asserted that 48 arms must narrow, which asked the question at a value
    // where the effect is not reachable and then read "no change" as a dead coupling: master §2b's
    // "a connectivity test run at a FLOOR cannot detect connection". The engagement point is
    // arithmetic, not taste - the pellet stops fitting past about 68 arms - so the dense end is
    // chosen ABOVE it and the sparse end well below.
    var _sparse = bar_bullet_for(4, 0.9, "pellet", _bs);
    var _dense = bar_bullet_for(96, 0.9, "pellet", _bs);
    var _wSparse = _bs / max(0.35, bar_bullet_info(_sparse).aspect);
    var _wDense = _bs / max(0.35, bar_bullet_info(_dense).aspect);

    // AND THE OTHER DIRECTION, which is the half that keeps this from becoming a clamp: a density
    // that does NOT need narrowing must be left alone. A coupling that always fires is not a
    // coupling, it is a filter.
    bar_st_assert(_st, bar_bullet_info(bar_bullet_for(48, 0.9, "pellet", _bs)).name == "pellet",
        "48 arms fits a pellet with 1.1 body widths of clear channel and bar_bullet_for narrowed it anyway");

    // ⛔⛔ THE ASSERTION THAT USED TO BE HERE ONLY CHECKED THAT THE TWO ENDS DIFFER, AND IT PASSED
    // OVER A REAL DEFECT. bar_bullet_for compared unit-box widths against field-unit gaps, so it
    // rejected the pellet even at FOUR arms and returned a lance; the two answers still differed,
    // so "the coupling is alive" was true and meaningless. The fix is to pin the SPARSE end to a
    // known-correct answer instead of to the other end of the same broken scale.
    bar_st_assert(_st, bar_bullet_info(_sparse).name == "pellet",
        "a 4-arm ring should keep the buyer's chosen pellet, and bar_bullet_for returned "
        + bar_bullet_info(_sparse).name + " - the gap comparison is in the wrong units");
    bar_st_assert(_st, _wDense < _wSparse,
        "bar_bullet_for returned a body no narrower for 48 arms (" + bar_bullet_info(_dense).name
        + ", width " + string(_wDense) + ") than for 4 (" + bar_bullet_info(_sparse).name
        + ", width " + string(_wSparse) + ") - THE COUPLING IS DEAD");
    // and monotone across the range, not just at the ends.
    var _prevW = 999;
    var _monotone = true;
    for (var _a = 4; _a <= 148; _a += 8) {
        var _bIx = bar_bullet_for(_a, 0.9, "pellet", _bs);
        var _w = _bs / max(0.35, bar_bullet_info(_bIx).aspect);
        if (_w > _prevW + BAR_ST_EPS) _monotone = false;
        _prevW = _w;
    }
    bar_st_assert(_st, _monotone, "body width does not fall monotonically as arm count rises");
    // AND the result must actually FIT, which is the thing the buyer cares about and which no
    // amount of comparing two answers to each other can establish.
    var _fitOk = bar_legibility_crowding(bar_pattern_spec(BAR_PAT_RING, 96, 3, 0, 360, 0.3, 0, 0.3, 0, 0),
        0.9, bar_bullet_for(96, 0.9, "pellet", _bs), _bs);
    bar_st_assert(_st, _fitOk.ok,
        "the body bar_bullet_for chose for 96 arms still does not fit: clear channel "
        + string(_fitOk.clear) + " against body width " + string(_fitOk.bodyWidth));
    array_push(_st.notes, "coupling: 4 -> " + bar_bullet_info(_sparse).name
        + ", 48 -> " + bar_bullet_info(bar_bullet_for(48, 0.9, "pellet", _bs)).name
        + ", 96 -> " + bar_bullet_info(_dense).name
        + ", 148 -> " + bar_bullet_info(bar_bullet_for(148, 0.9, "pellet", _bs)).name);

    // -- STAGE 14: LEGIBILITY FIRES, AND DOES NOT FIRE ------------------------------------------
    // ⛔ BOTH DIRECTIONS. A checker that only proves it can fire proves nothing about false reds,
    // and a legibility gate that flags everything is a deleted gate.
    bar_st_stage(_st, 14);
    var _sane = bar_pattern_spec(BAR_PAT_RING, 8, 4, 0, 360, 0.30, 0, 0.35, 0, 0);
    var _repSane = bar_legibility_report(_sane, bar_element_find("bone"), bar_bullet_find("pellet"), 0.05, 0.10, 0.22);
    bar_st_assert(_st, _repSane.checked > 0, "VACUITY: the legibility report checked nothing");
    bar_st_assert(_st, _repSane.ok,
        "FALSE RED: a sane pattern was flagged - " + bar_legibility_line(_repSane));

    // CROWDING must fire on an absurdly dense ring.
    var _crowd = bar_pattern_spec(BAR_PAT_RING, 200, 3, 0, 360, 0.30, 0, 0.35, 0, 0);
    var _repCrowd = bar_legibility_report(_crowd, bar_element_find("bone"), bar_bullet_find("boulder"), 0.09, 0.10, 0.22);
    bar_st_assert(_st, !_repCrowd.ok, "200 arms of a wide body was reported legible");

    // CONTRAST must fire on the hard case: a dark shot on a dark field. This is the assertion
    // that mechanises "a shadow cannot exist on a black floor" - five bakes were spent on it.
    var _repDark = bar_legibility_report(_sane, bar_element_find("void"), bar_bullet_find("pellet"), 0.05, 0.16, 0.30);
    var _sawContrast = false;
    for (var _i = 0; _i < array_length(_repDark.issues); _i++) {
        if (_repDark.issues[_i].kind == "contrast") _sawContrast = true;
    }
    bar_st_assert(_st, _sawContrast,
        "a dark element on a dark field was not flagged - the check that exists because this wing spent five bakes tuning a mark its background could not show");

    // WARNING must fire on a shot that arrives faster than a human reacts.
    var _fast = bar_pattern_spec(BAR_PAT_AIMED, 3, 3, 0, 20, 9.0, 0, 0.30, 0, 0);
    var _repFast = bar_legibility_report(_fast, bar_element_find("bone"), bar_bullet_find("needle"), 0.04, 0.10, 0.22);
    var _sawWarn = false;
    for (var _i = 0; _i < array_length(_repFast.issues); _i++) {
        if (_repFast.issues[_i].kind == "warning") _sawWarn = true;
    }
    bar_st_assert(_st, _sawWarn, "a shot crossing the field in under the reaction floor was not flagged");

    // -- STAGE 15: THE WARNING SOLVE AGREES WITH A SIMULATION -----------------------------------
    // The closed-form inverse of r = vt + at²/2 is the kind of arithmetic that is silently wrong.
    // Checked against a stepped integration, which is slow, obvious and independent.
    bar_st_stage(_st, 15);
    var _spec2 = bar_pattern_spec(BAR_PAT_RING, 8, 3, 0, 360, 0.40, 0.25, 0.35, 0, 0);
    var _solved = bar_legibility_warning(_spec2, 0.60);
    var _simT = 0;
    var _simR = 0;
    var _dt = 0.0005;
    while (_simR < 0.60 && _simT < 20) { _simT += _dt; _simR = _spec2.speed * _simT + 0.5 * _spec2.accel * _simT * _simT; }
    bar_st_assert(_st, abs(_solved - _simT) < 0.01,
        "the closed-form warning time (" + string(_solved) + ") disagrees with a stepped simulation (" + string(_simT) + ")");
    array_push(_st.notes, "warning solve " + string(_solved) + " vs simulation " + string(_simT));

    // -- STAGE 16: THE GAP ARITHMETIC HANDLES WRAP ----------------------------------------------
    // CLAIM (bar_legibility): "a 360-degree spread has `arms` gaps; anything narrower has
    // arms - 1", and using the wrong one under-reports crowding on exactly the densest patterns.
    bar_st_stage(_st, 16);
    var _ring8 = bar_pattern_spec(BAR_PAT_RING, 8, 1, 0, 360, 0.3, 0, 0.3, 0, 0);
    var _fan8 = bar_pattern_spec(BAR_PAT_FAN, 8, 1, 0, 180, 0.3, 0, 0.3, 0, 0);
    var _gRing = bar_legibility_gap(_ring8, 1.0);
    var _gFan = bar_legibility_gap(_fan8, 1.0);
    bar_st_assert(_st, abs(_gRing - (BAR_TAU / 8)) < BAR_ST_EPS,
        "full-ring gap is " + string(_gRing) + ", expected " + string(BAR_TAU / 8));
    bar_st_assert(_st, abs(_gFan - (pi / 7)) < BAR_ST_EPS,
        "half-fan gap is " + string(_gFan) + ", expected " + string(pi / 7) + " (arms-1 gaps, not arms)");

    // -- STAGE 17: THE STORE SHEET FITS ITS SPECIMENS INSTEAD OF CLIPPING THEM -------------------
    // CLAIM (bar_bake): every shot a pattern produces is drawn inside its cell, at a scale derived
    // from what that pattern actually occupies.
    //
    // ⛔ THIS STAGE EXISTS BECAUSE THE SHEET USED TO DROP SHOTS THAT DID NOT FIT and nothing could
    // tell. The old code's `continue` removed the evidence of its own overflow, so the sheet looked
    // plausible while RING was missing its outer waves and CONVERGE had a hole in the middle. The
    // defect was found by opening the PNG; this stage is what stops it coming back silently.
    bar_st_stage(_st, 17);
    var _fitBoxW = 340, _fitBoxH = 250, _fitPad = 0.055;
    for (var _fi = 0; _fi < BAR_PATTERN_COUNT; _fi++) {
        var _fspec = bar_pattern_preset(_fi);
        var _flive = bar_pattern_live(_fspec, _fspec.gap * _fspec.waves * 0.85 + 0.55);
        var _ffit = bar_fit_shots(_flive, _fitBoxW, _fitBoxH, _fitPad);

        bar_st_assert(_st, array_length(_flive) > 0,
            bar_pattern_name(_fi) + " produced no live shots to fit");

        // The span floor is a guard for a degenerate input. If it fires on a REAL family it is
        // silently rescaling that family, so assert it does not - this is the half of the guard
        // that a one-sided test would miss.
        bar_st_assert(_st, !_ffit.floored,
            "the span floor fired on real family " + bar_pattern_name(_fi)
            + " (spans " + string(_ffit.spanX) + "," + string(_ffit.spanY)
            + ") - it is meant to catch only a collapsed pattern");

        // Every shot inside the box, measured against the box rather than against itself.
        var _worst = 0;
        for (var _si = 0; _si < array_length(_flive); _si++) {
            var _sh = _flive[_si];
            var _dx = abs((_sh.x - _ffit.ox) * _ffit.unit) + _fitPad * _ffit.unit;
            var _dy = abs((_sh.y - _ffit.oy) * _ffit.unit) + _fitPad * _ffit.unit;
            _worst = max(_worst, _dx / (_fitBoxW * 0.5), _dy / (_fitBoxH * 0.5));
        }
        bar_st_assert(_st, _worst <= 1.0001,
            bar_pattern_name(_fi) + " overflows its cell by " + string((_worst - 1) * 100)
            + "% - a fitted panel must not need clipping");
    }

    // The guard's positive control: a collapsed pattern MUST trip the floor, or the floor is dead
    // code and the division it protects is unguarded.
    var _collapsed = [{ x: 0.2, y: 0.2 }, { x: 0.2, y: 0.2 }, { x: 0.2, y: 0.2 }];
    var _cfit = bar_fit_shots(_collapsed, _fitBoxW, _fitBoxH, 0);
    bar_st_assert(_st, _cfit.floored,
        "the span floor did NOT fire on a fully collapsed shot list - it cannot protect the divide");
    bar_st_assert(_st, _cfit.unit > 0 && _cfit.unit < 100000,
        "a collapsed shot list produced unit " + string(_cfit.unit) + " - the floor did not bound it");

    // An empty list must not divide either, and must say it fitted nothing.
    var _efit = bar_fit_shots([], _fitBoxW, _fitBoxH, 0);
    bar_st_assert(_st, _efit.n == 0 && _efit.unit > 0,
        "an empty shot list did not degrade safely (n " + string(_efit.n) + ", unit " + string(_efit.unit) + ")");

    // -- STAGE 17b: THE COUPLING SHEET FINDS FOUR GENUINELY DIFFERENT BODIES --------------------
    // CLAIM (bar_bake): the four panels of the coupling sheet show four DISTINCT bodies.
    //
    // ⛔ THE HAND-TYPED COUNTS FAILED THIS. [8, 48, 96, 148] picked pellet twice, so the sheet
    // making the "the body answers to the pattern" argument had a panel in which it demonstrably
    // did not. A sheet is allowed to be an illustration; it is not allowed to be a counterexample.
    var _stepR = 0.9, _stepBs = 0.055;
    var _steps = bar_coupling_steps(4, 12, _stepR, _stepBs);
    bar_st_assert(_st, array_length(_steps) == 4,
        "the coupling scan found " + string(array_length(_steps)) + " transitions, not 4 - the "
        + "sheet would silently render fewer panels than it is laid out for");
    for (var _si2 = 0; _si2 < array_length(_steps); _si2++) {
        for (var _sj = _si2 + 1; _sj < array_length(_steps); _sj++) {
            bar_st_assert(_st, _steps[_si2].body != _steps[_sj].body,
                "coupling panels " + string(_si2) + " and " + string(_sj) + " both show "
                + bar_bullet_info(_steps[_si2].body).name);
        }
        // Rising arm counts, or the sheet reads right to left.
        if (_si2 > 0) bar_st_assert(_st, _steps[_si2].arms > _steps[_si2 - 1].arms,
            "coupling arm counts are not increasing at panel " + string(_si2));

        // ⛔ THE NUMBER THE SHEET PRINTS MUST NOT BE NEGATIVE. A negative clear channel is `solid`
        // in bar_legibility's own vocabulary - the wave is a wall - so a store sheet printing one
        // is advertising the failure the product exists to prevent. It printed -0.003 under two
        // panels on 2026-09-05, because the body was chosen for one radius and measured at another.
        // Measuring at the SAME radius the choice was made for is the whole content of this check.
        var _ccSpec = bar_pattern_spec(BAR_PAT_RING, _steps[_si2].arms, 1, 0, 360, 0.30, 0, 0.35, 0, 0);
        var _cc = bar_legibility_crowding(_ccSpec, _stepR, _steps[_si2].body, _stepBs);
        bar_st_assert(_st, _cc.clear > 0 && !_cc.solid,
            "coupling panel " + string(_si2) + " (" + string(_steps[_si2].arms) + " arms, "
            + bar_bullet_info(_steps[_si2].body).name + ") measures clear channel "
            + string(_cc.clear) + " at r=" + string(_stepR) + " - the sheet would print a solid wall");
    }
    var _stepNote = "coupling transitions:";
    for (var _sk = 0; _sk < array_length(_steps); _sk++) {
        _stepNote += " " + string(_steps[_sk].arms) + "->" + bar_bullet_info(_steps[_sk].body).name;
    }
    array_push(_st.notes, _stepNote);

    // -- STAGE 18: A CENTRED CAPTION IS CENTRED ON THE WIDTH THAT IS ACTUALLY DRAWN --------------
    // CLAIM (bar_render): bar_text_line_centred puts the string's midpoint on _cx.
    //
    // ⚠️ THE FONT IS SET FIRST, DELIBERATELY. string_width reads the CURRENT font, so a test that
    // measures under whatever font the previous stage happened to leave set is measuring something
    // it did not choose.
    bar_st_stage(_st, 18);
    draw_set_font(fnt_barrage);
    var _capW = 300;
    var _samples = ["plasma", "a much longer caption than the cell can possibly hold at full size"];
    for (var _ci = 0; _ci < array_length(_samples); _ci++) {
        var _txt = _samples[_ci];
        var _sc = bar_text_scale(_txt, _capW, 15);
        var _wd = bar_text_width(_txt, _capW, 15);
        bar_st_assert(_st, abs(_wd - string_width(_txt) * _sc) < BAR_ST_EPS,
            "bar_text_width disagrees with bar_text_scale on \"" + _txt + "\"");
        bar_st_assert(_st, _wd <= _capW + 0.001,
            "\"" + _txt + "\" fits to " + string(_wd) + "px against a " + string(_capW) + "px cap");

        // The midpoint of the drawn string lands on the requested centre. Not a tautology: a
        // helper that forgot to displace at all returns _cx, and _cx + _wd/2 != _cx for _wd > 0.
        var _cxWant = 500;
        var _left = bar_text_centre_left(_txt, _cxWant, _capW, 15);
        bar_st_assert(_st, _wd > 0, "\"" + _txt + "\" measured zero wide - the centring check would "
            + "pass vacuously on it");
        bar_st_assert(_st, abs((_left + _wd * 0.5) - _cxWant) < 0.001,
            "a caption centred on " + string(_cxWant) + " has its midpoint at "
            + string(_left + _wd * 0.5) + " - it is not centred, it is anchored");
    }
    // The long sample must genuinely have been shrunk, or the second assertion above passed
    // vacuously and this stage proves nothing about the fitting path.
    bar_st_assert(_st, bar_text_scale(_samples[1], _capW, 15) < bar_text_scale(_samples[0], _capW, 15),
        "the long caption was not shrunk relative to the short one - the fit path never ran");

    // -- STAGE 19: THE DEMO ROOM'S INPUT PATH, WHICH HAD NEVER RUN ------------------------------
    // CLAIM (bar_demo): every key the demo advertises does what the on-screen legend says.
    //
    // ⛔ BEFORE THIS STAGE THE COUNT WAS 1832 ASSERTIONS AND *ZERO* OF THEM TOUCHED THE DEMO'S INPUT
    // HANDLING - the first thing any buyer does with this package. A pass count is a statement about
    // the code it covers and says nothing whatever about the code it does not.
    bar_st_stage(_st, 19);

    // LEFT from the default state. This is the single keystroke most likely to be pressed first by
    // someone who guessed the wrong arrow, and `(0 - 1) % N` is NEGATIVE in GML - a table read off
    // the front of the array, i.e. a crash on the demo's opening frame.
    var _d = bar_demo_state();
    bar_demo_step(_d, (function() { var _i = bar_demo_input(); _i.prev = true; return _i; })(), 0);
    bar_st_assert(_st, _d.pattern >= 0 && _d.pattern < BAR_PATTERN_COUNT,
        "stepping LEFT from the default state produced pattern index " + string(_d.pattern)
        + " - out of range, which is a crash on the demo's first keypress");
    bar_st_assert(_st, _d.pattern == BAR_PATTERN_COUNT - 1,
        "LEFT from pattern 0 landed on " + string(_d.pattern) + ", expected the last family");

    // A full lap in each direction returns to where it started, and every index on the way is legal.
    var _d2 = bar_demo_state();
    var _startPat = _d2.pattern;
    for (var _k = 0; _k < BAR_PATTERN_COUNT; _k++) {
        bar_demo_step(_d2, (function() { var _i = bar_demo_input(); _i.next = true; return _i; })(), 0);
        bar_st_assert(_st, _d2.pattern >= 0 && _d2.pattern < BAR_PATTERN_COUNT,
            "walking RIGHT left the pattern index at " + string(_d2.pattern));
    }
    bar_st_assert(_st, _d2.pattern == _startPat,
        "a full lap of RIGHT ended on " + string(_d2.pattern) + ", not back at " + string(_startPat));

    var _d3 = bar_demo_state();
    for (var _k = 0; _k < BAR_ELEMENT_COUNT; _k++) {
        bar_demo_step(_d3, (function() { var _i = bar_demo_input(); _i.elemDown = true; return _i; })(), 0);
        bar_st_assert(_st, _d3.element >= 0 && _d3.element < BAR_ELEMENT_COUNT,
            "walking element DOWN left the index at " + string(_d3.element));
    }
    bar_st_assert(_st, _d3.element == 0,
        "a full lap of element DOWN ended on " + string(_d3.element) + ", not back at 0");

    // PAUSE actually stops the clock, and unpausing starts it again. Asserted in both directions,
    // because a toggle that is stuck ON passes any test that only checks it stops.
    var _d4 = bar_demo_state();
    bar_demo_step(_d4, (function() { var _i = bar_demo_input(); _i.pause = true; return _i; })(), 0);
    bar_st_assert(_st, _d4.paused, "SPACE did not pause");
    var _tPaused = _d4.t;
    bar_demo_step(_d4, bar_demo_input(), 0.5);
    bar_st_assert(_st, abs(_d4.t - _tPaused) < BAR_ST_EPS,
        "the clock advanced by " + string(_d4.t - _tPaused) + " while paused");
    bar_demo_step(_d4, (function() { var _i = bar_demo_input(); _i.pause = true; return _i; })(), 0);
    bar_demo_step(_d4, bar_demo_input(), 0.25);
    bar_st_assert(_st, _d4.t > _tPaused,
        "the clock did not restart after unpausing - a toggle stuck ON passes every test that only "
        + "checks that it stops");

    // SCRUB is HELD, so it must move on consecutive frames with no fresh press. A "pressed"
    // implementation moves once and then stops, which looks identical on a single-frame test.
    var _d5 = bar_demo_state();
    bar_demo_step(_d5, (function() { var _i = bar_demo_input(); _i.scrubFwd = true; return _i; })(), 0);
    var _after1 = _d5.t;
    bar_demo_step(_d5, (function() { var _i = bar_demo_input(); _i.scrubFwd = true; return _i; })(), 0);
    bar_st_assert(_st, abs((_d5.t - _after1) - BAR_DEMO_SCRUB) < BAR_ST_EPS,
        "scrubbing a second HELD frame moved the clock by " + string(_d5.t - _after1)
        + ", expected " + string(BAR_DEMO_SCRUB) + " - a held key that only fires once is a "
        + "pressed key wearing the wrong name");

    // Scrubbing back from zero clamps rather than going negative. A negative t is a pattern time
    // before the wave was born, which bar_pattern is not defined for.
    var _d6 = bar_demo_state();
    for (var _k = 0; _k < 5; _k++) {
        bar_demo_step(_d6, (function() { var _i = bar_demo_input(); _i.scrubBack = true; return _i; })(), 0);
    }
    bar_st_assert(_st, _d6.t >= 0,
        "scrubbing back past the start left t at " + string(_d6.t));

    // Changing pattern resets the clock, and the loop never leaves t past its own span.
    var _d7 = bar_demo_state();
    bar_demo_step(_d7, bar_demo_input(), 2.0);
    bar_st_assert(_st, _d7.t > 0, "the clock did not advance on an unpaused frame");
    bar_demo_step(_d7, (function() { var _i = bar_demo_input(); _i.next = true; return _i; })(), 0);
    bar_st_assert(_st, _d7.t == 0, "changing pattern left the clock at " + string(_d7.t));

    var _d8 = bar_demo_state();
    for (var _k = 0; _k < 400; _k++) {
        bar_demo_step(_d8, bar_demo_input(), 0.1);
        var _sp8 = bar_pattern_preset(_d8.pattern);
        bar_st_assert(_st, _d8.t <= _sp8.gap * _sp8.waves + 3.2 + BAR_ST_EPS,
            "the demo clock ran past its own loop span to " + string(_d8.t));
    }

    // The hitbox toggle, both ways - it starts ON, so a test that only presses once and checks it
    // changed would pass on a toggle that can never come back.
    var _d9 = bar_demo_state();
    var _h0 = _d9.hitbox;
    bar_demo_step(_d9, (function() { var _i = bar_demo_input(); _i.hitbox = true; return _i; })(), 0);
    bar_st_assert(_st, _d9.hitbox != _h0, "H did not toggle the hitbox overlay");
    bar_demo_step(_d9, (function() { var _i = bar_demo_input(); _i.hitbox = true; return _i; })(), 0);
    bar_st_assert(_st, _d9.hitbox == _h0, "H did not toggle the hitbox overlay back");

    // Every family is reachable by walking, and each one produces a legibility line rather than an
    // empty string - the readout is the demo's whole argument and a blank one reads as broken.
    var _d10 = bar_demo_state();
    for (var _k = 0; _k < BAR_PATTERN_COUNT; _k++) {
        bar_demo_step(_d10, (function() { var _i = bar_demo_input(); _i.next = true; return _i; })(), 0.016);
        bar_st_assert(_st, string_length(_d10.report) > 0,
            "family " + string(_d10.pattern) + " produced an empty legibility readout");
        bar_st_assert(_st, _d10.body >= 0 && _d10.body < bar_bullet_count(),
            "family " + string(_d10.pattern) + " chose body index " + string(_d10.body));
    }
    array_push(_st.notes, "demo input: " + string(BAR_PATTERN_COUNT) + " families and "
        + string(BAR_ELEMENT_COUNT) + " elements walked in both directions");

    bar_st_stage(_st, 99);
    array_push(_st.notes, "corpus " + string(array_length(_bodies)) + " bodies, "
        + string(array_length(_elems)) + " elements, " + string(array_length(_pats)) + " pattern families");
    return _st;
}

/// Write the result where the harness can read it. %LOCALAPPDATA%\<Game>\ — the only route that
/// survives a release build.
function bar_selftest_write(_st) {
    var _f = file_text_open_write("bar_selftest.json");
    file_text_write_string(_f, "{");
    file_text_write_string(_f, "\"total\":" + string(_st.total));
    file_text_write_string(_f, ",\"pass\":" + string(_st.pass));
    file_text_write_string(_f, ",\"fail\":" + string(_st.fail));
    file_text_write_string(_f, ",\"stage\":" + string(_st.stage));
    file_text_write_string(_f, ",\"notes\":[");
    for (var _i = 0; _i < array_length(_st.notes); _i++) {
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "\"" + string_replace_all(_st.notes[_i], "\"", "'") + "\"");
    }
    file_text_write_string(_f, "],\"failures\":[");
    for (var _i = 0; _i < array_length(_st.failures); _i++) {
        if (_i > 0) file_text_write_string(_f, ",");
        file_text_write_string(_f, "\"" + string_replace_all(_st.failures[_i], "\"", "'") + "\"");
    }
    file_text_write_string(_f, "]}");
    file_text_close(_f);
}
