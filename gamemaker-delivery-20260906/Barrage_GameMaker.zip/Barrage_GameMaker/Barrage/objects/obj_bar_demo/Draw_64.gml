/// Barrage demo — the runnable demo room, and the only real smoke test this wing has.
///
/// ⛔ THE DRAWING IS NOT HERE ANY MORE. It lives in bar_demo_draw, which this event and the store
/// sheet BOTH call, so the gallery's "product in use" shot is a picture of this room by
/// construction rather than a second implementation of it that can drift.

bar_demo_draw(demo_state, demo_spec,
    display_get_gui_width(), display_get_gui_height());
