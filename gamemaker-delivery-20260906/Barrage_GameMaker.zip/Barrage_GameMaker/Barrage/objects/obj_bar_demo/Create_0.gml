/// @description Barrage demo — and the headless self-test entry point.
///
/// ⛔ TWO ORDERING TRAPS, BOTH MEASURED BY THIS WING, BOTH FIXED BY THE FIRST TWENTY LINES.
///
/// 1. A GML RUNTIME ERROR OPENS A MODAL DIALOG. Headless, nothing dismisses it, so the process
///    NEVER EXITS - an opaque hang with no output and no clue. The handler below turns that into a
///    recorded stage number and a clean exit, which is the difference between "the build is broken
///    somehow" and "CRASH at stage 13: Variable Index out of range".
///
/// 2. AN EARLY EXIT IN Create SKIPS SETUP THAT Clean Up STILL DEPENDS ON - AND CLEAN UP ALWAYS
///    RUNS. The -selftest path calls game_end() partway down this event and GameMaker fires
///    CleanUp on the way out anyway. A variable declared BELOW the early exit but read in CleanUp
///    reports "not set before reading it" against THE LAST STAGE THE SUITE REACHED, i.e. a crash
///    attributed to code that had already finished and passed. So every variable any later event
///    reads is declared ABOVE the early exit, and CleanUp guards with variable_instance_exists.

exception_unhandled_handler(function(_ex) {
    var _f = file_text_open_write("bar_crash.txt");
    file_text_write_string(_f, "CRASH at stage " + string(global.bar_stage) + ": " + _ex.message);
    file_text_close(_f);
    game_end();
});

global.bar_stage = 0;

// ⛔ DECLARED ABOVE THE EARLY EXIT. See trap 2 in the header.
demo_state   = bar_demo_state();
demo_pattern = demo_state.pattern;
demo_element = demo_state.element;
demo_body    = demo_state.body;
demo_t       = demo_state.t;
demo_paused  = demo_state.paused;
demo_hitbox  = demo_state.hitbox;
demo_report  = demo_state.report;

// ---------------------------------------------------------------------------------------------
// Headless self-test: `Barrage.exe -selftest`
// ---------------------------------------------------------------------------------------------
var _args = "";
for (var _i = 0; _i < parameter_count(); _i++) _args += parameter_string(_i) + " ";

if (string_pos("-bake", _args) > 0) {
    global.bar_stage = 200;
    bar_bake_all();
    game_end();
    exit;
}

// ⚠️ CHECKED BEFORE "-bake" WOULD BE, IF THEY SHARED A PREFIX. They do not - "-gif" and "-bake"
// have no prefix in common - but the order is deliberate anyway: string_pos matching is substring
// matching, and a later mode whose flag CONTAINS an earlier one would be unreachable.
if (string_pos("-gif", _args) > 0) {
    global.bar_stage = 210;
    bar_bake_gif();
    game_end();
    exit;
}

if (string_pos("-selftest", _args) > 0) {
    global.bar_stage = 1;
    var _st = bar_selftest_run();
    global.bar_stage = _st.stage;
    bar_selftest_write(_st);
    game_end();
    exit;
}

// ---------------------------------------------------------------------------------------------
// The interactive demo room.
// ---------------------------------------------------------------------------------------------
demo_spec = bar_pattern_preset(demo_pattern);
demo_body = bar_bullet_for(demo_spec.arms, 0.9, "pellet", 0.055);
demo_report = bar_legibility_line(
    bar_legibility_report(demo_spec, demo_element, demo_body, 0.055, 0.12, 0.26));
