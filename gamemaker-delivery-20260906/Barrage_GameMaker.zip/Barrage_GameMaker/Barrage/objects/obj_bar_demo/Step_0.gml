/// Barrage demo — input, and nothing else.
///
/// ⛔ THE STATE MACHINE IS NOT HERE ANY MORE, AND THAT IS THE POINT. This event used to read the
/// keyboard and mutate state in the same expression, which left no seam to test at - so the one
/// code path a buyer touches first had never executed in any run. It now does exactly one job:
/// turn the keyboard into a plain struct. bar_demo_step does the thinking and the headless suite
/// drives it directly.
///
/// ⚠️ THE CLOCK IS A NUMBER bar_demo_step ADVANCES, NOT A SPAWNER. bar_pattern is a pure function of
/// (wave, shot, t), so scrubbing back is the same operation as playing forward and the demo can
/// offer it for free. That is the property bar_pattern's header defends.

var _in = bar_demo_input();
_in.pause     = keyboard_check_pressed(vk_space);
_in.hitbox    = keyboard_check_pressed(ord("H"));
_in.next      = keyboard_check_pressed(vk_right) || keyboard_check_pressed(ord("D"));
_in.prev      = keyboard_check_pressed(vk_left)  || keyboard_check_pressed(ord("A"));
_in.elemUp    = keyboard_check_pressed(vk_up);
_in.elemDown  = keyboard_check_pressed(vk_down);
_in.reset     = keyboard_check_pressed(ord("R"));
// Held, not pressed: a buyer tuning a boss wants to crawl through the frame the shot becomes
// unreadable on.
_in.scrubBack = keyboard_check(ord("Q"));
_in.scrubFwd  = keyboard_check(ord("E"));

demo_spec = bar_demo_step(demo_state, _in, delta_time / 1000000);

// The draw event reads these; they are kept as instance variables so the object stays readable to
// a buyer opening it in the IDE rather than making them chase a struct.
demo_pattern = demo_state.pattern;
demo_element = demo_state.element;
demo_body    = demo_state.body;
demo_t       = demo_state.t;
demo_paused  = demo_state.paused;
demo_hitbox  = demo_state.hitbox;
demo_report  = demo_state.report;
