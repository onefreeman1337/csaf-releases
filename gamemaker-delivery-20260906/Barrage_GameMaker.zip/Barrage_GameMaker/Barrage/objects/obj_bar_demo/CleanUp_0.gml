/// Nothing to release.
///
/// ⚠️ THIS IS A DELIBERATE EMPTY EVENT, NOT AN UNFINISHED ONE. The demo allocates no surface, no
/// buffer, no data structure and no sprite: `bar_pattern_live` returns a plain array the garbage
/// collector owns, and the demo never calls `bar_render_to_sprite`, which is the only function in
/// the package that creates anything needing manual release.
///
/// ⛔ SAYING SO MATTERS, because bar_render_to_sprite's header used to claim THIS EVENT deleted
/// every sprite the demo made. It never did, and there was never a sprite to delete — an
/// unfalsifiable claim about cleanup, kept alive by the thing it described never happening
/// (corrected 2026-09-05, receipt in that header).
///
/// ⚠️ Create_0's header explains why the event exists at all: `-selftest` and `-bake` call
/// `game_end()` partway down Create, and GameMaker fires Clean Up on the way out anyway. Anything
/// added here must therefore guard with `variable_instance_exists`, because it can run against an
/// instance whose Create never finished.
