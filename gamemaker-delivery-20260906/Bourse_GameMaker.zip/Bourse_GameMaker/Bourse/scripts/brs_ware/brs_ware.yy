{
  "$GMScript": "v1",
  "%Name": "brs_ware",
  "isCompatibility": false,
  "isDnD": false,
  "name": "brs_ware",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}