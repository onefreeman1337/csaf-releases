/// BOURSE - brs_ware. THE CORPUS: forty-eight trade goods, drawn from data.
///
/// This file is the product. Everything else in the package exists to price these, shelve these,
/// or render these. There is no sprite, no atlas and no texture page anywhere in Bourse - a sack
/// of grain is forty-one points and a bevel, and a buyer can read every one of them.
///
/// -- WHAT A WARE IS ----------------------------------------------------------------------------
/// Two things, kept apart on purpose:
///   brs_ware_spec(id)   the ECONOMICS - base value, bulk, spoilage, how sharply demand answers
///                       price - which brs_market simulates and never draws
///   brs_ware_parts(id)  the PICTURE - a part list in the unit box, which brs_render draws and
///                       never reasons about
/// A buyer who wants their own goods writes one entry in each. A buyer who wants OUR goods to look
/// like their game changes the material pair in the spec and touches no geometry at all.
///
/// -- COORDINATES, AND THE ONE LANDMARK ---------------------------------------------------------
/// Unit box [-0.5, 0.5] on both axes, y DOWN. THE COUNTER LINE IS y = BRS_STAND, and every ware in
/// the corpus rests its base on it. That is what lets a cask authored on Tuesday and a bolt of
/// linen authored on Wednesday stand on the same shelf without a per-ware nudge, and it is asserted
/// for all forty-eight in brs_selftest rather than trusted.
///
/// ⛔ THE FITTINGS ARE ROLE-MAPPED, NOT DRAWN IN THE FITTING COLOUR. The relief engine colours
/// every wall it builds from the ramp roles m0..m4 - that is hard-wired, and it has to be, because
/// the whole point is that one lamp lights everything. So an iron hoop is built exactly like an oak
/// stave and then passed through brs_as_fitting(), which rewrites its roles to n0..n4. Draw a hoop
/// without that call and you get an oak hoop on an oak cask: perfectly lit, and invisible.
///
/// ⛔ AND A TELL MUST CHANGE AREA, SPACING OR SILHOUETTE - never fine detail inside a filled mass.
/// This wing has paid for that law three times (Wings/GameMaker/CLAUDE.md): line width is quantised
/// to one pixel by the rasteriser, so two goods distinguished only by the weave drawn on their
/// surface are the same good at shelf size. Every pair in this corpus that could collide - the two
/// ingots, the two barrels, the two sacks - is separated by its OUTLINE first.
/// ============================================================================================

/// The counter line. Every ware stands on it.
#macro BRS_STAND 0.42

/// The top of the unit box a ware may reach. Leaves a hair of margin so a bevel on the topmost
/// point cannot escape the box the renderer fits.
#macro BRS_CEIL -0.46

/// ============================================================================================
/// SHARED FORM BUILDERS
///
/// Nine builders make all forty-eight goods. That is deliberate: a corpus of forty-eight bespoke
/// functions is a corpus where fixing the lighting means forty-eight edits, and this wing has the
/// receipt for what that costs.
/// ============================================================================================

/// Wrap a SINGLE part as a one-element part list.
///
/// ⛔ THE TRAP THIS EXISTS FOR, AND IT SHIPPED SILENTLY UNTIL THE SUITE CAUGHT IT. Most builders in
/// the drawing layer return a part LIST - brs_raise, brs_incise, brs_ridge, brs_boss, brs_bevel -
/// but four return ONE part: brs_fill, brs_poly, brs_dot and brs_taper_ribbon. Handing a single
/// part to brs_append or to a role map asks array_length() about a struct, which answers 0, so the
/// part is dropped WITH NO ERROR AT ALL. Six call sites in this corpus did exactly that: every
/// stalk of the herb bundle, the cradle under the perfume vial, the honey drip, the water skin's
/// strap, the stylus and the indigo runs were all being computed and thrown away. The picture just
/// quietly had less in it, the gate was clean, and nothing but the counter-line assertion noticed.
function brs_one(_p) {
    return is_array(_p) ? _p : [_p];
}

/// Rewrite a part list built by the relief engine into FITTING colours.
///
/// See the header. This is the single most load-bearing four lines in the file - and it TOLERATES
/// a single part rather than silently discarding one, for the reason brs_one records above.
function brs_as_fitting(_parts) {
    return brs_map_roles(brs_one(_parts), { m0: "n0", m1: "n1", m2: "n2", m3: "n3", m4: "n4" });
}

/// A closed outline from a half-width profile, sampled top to bottom.
///
/// _hw is an array of half-widths; the outline runs down the right side and back up the left, so
/// the result is a closed body of revolution seen side-on - which is what a sack, a cask, a jar, a
/// bottle, a jug, a tub and a bucket all are.
///
/// ⚠️ A HALF-WIDTH OF EXACTLY ZERO IS CLAMPED TO A HAIR. Two coincident points give the inset pass
/// a zero-length edge, and a zero-length edge has no normal: the bevel then reads its neighbour's
/// and puts a bright wedge at the top of every pointed form. Clamping costs nothing and the
/// alternative is a defect that only shows on the four pointed goods.
function brs_profile_pts(_cx, _y0, _y1, _hw) {
    var _n = array_length(_hw);
    var _pts = array_create(_n * 2);
    for (var _i = 0; _i < _n; _i++) {
        var _t = _i / (_n - 1);
        var _w = max(0.004, _hw[_i]);
        _pts[_i] = [_cx + _w, lerp(_y0, _y1, _t)];
        _pts[_n * 2 - 1 - _i] = [_cx - _w, lerp(_y0, _y1, _t)];
    }
    return _pts;
}

/// Sample a half-width profile as a smooth barrel/sack curve.
///
/// _waist is how far the ends pull in from the widest point (0 = a cylinder, 0.5 = a lens), and
/// _belly is where the widest point sits from top (0.5 = the middle, 0.7 = a sack that sits down).
function brs_profile_curve(_hw_max, _n, _waist, _belly, _top_cut, _bot_cut) {
    var _out = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _t = _i / (_n - 1);
        // A cosine hump about _belly, raised to a power so the shoulder can be made lazy or abrupt
        // without a second parameter. power() rather than a cutoff: this wing has the receipt for
        // what a hard cutoff does to a distribution (it draws a straight edge across the form).
        var _d = abs(_t - _belly) / max(0.0001, (_t < _belly) ? _belly : (1 - _belly));
        var _k = 1 - _waist * power(clamp(_d, 0, 1), 1.7);
        if (_t < _top_cut) _k *= _t / max(0.0001, _top_cut);
        if (_t > 1 - _bot_cut) _k *= (1 - _t) / max(0.0001, _bot_cut);
        _out[_i] = _hw_max * _k;
    }
    return _out;
}

/// A raised body of revolution, in BODY colours.
function brs_body(_cx, _y0, _y1, _hw, _bev) {
    return brs_raise(brs_profile_pts(_cx, _y0, _y1, _hw), _bev, 3, "m2");
}

/// The lit belly of a round body: a narrower profile pushed toward the lamp and filled bright.
///
/// ⛔ THIS IS WHAT MAKES A CYLINDER READ AS A CYLINDER. The relief bevel lights the OUTLINE, which
/// is correct and is not enough: a barrel bevelled on its silhouette and flat inside reads as a
/// bevelled plank. A body of revolution has its brightest band inside the outline, offset toward
/// the light, and that band is the entire difference. Measured by drawing both and looking.
function brs_sheen(_cx, _y0, _y1, _hw, _k, _shift, _role) {
    var _n = array_length(_hw);
    var _in = array_create(_n);
    for (var _i = 0; _i < _n; _i++) _in[_i] = _hw[_i] * _k;
    var _dy = (_y1 - _y0) * 0.06;
    var _pts = brs_profile_pts(_cx - _shift, _y0 + _dy, _y1 - _dy, _in);
    return [brs_ring_fill(_pts, _role, undefined, undefined)];
}

/// A band running across a round body - a cask hoop, a sack tie, a bale cord. In FITTING colours.
function brs_hoop(_cx, _y, _hw, _t) {
    var _pts = [[_cx - _hw, _y - _t], [_cx + _hw, _y - _t], [_cx + _hw, _y + _t], [_cx - _hw, _y + _t]];
    return brs_as_fitting(brs_raise(_pts, _t * 0.7, 2, "m3"));
}

/// A raised rounded box in BODY colours - a crate, a chest, a block, a bale.
function brs_box(_x0, _y0, _x1, _y1, _r, _bev) {
    return brs_raise(brs_round_rect_pts(_x0, _y0, _x1, _y1, _r, 3), _bev, 3, "m2");
}

/// A batten, strap or corner iron laid over a box. In FITTING colours.
function brs_batten(_x0, _y0, _x1, _y1) {
    var _b = min(abs(_x1 - _x0), abs(_y1 - _y0)) * 0.34;
    return brs_as_fitting(brs_raise([[_x0, _y0], [_x1, _y0], [_x1, _y1], [_x0, _y1]], _b, 2, "m3"));
}

/// Vertical staves incised into a round body - the joints between the boards of a cask.
///
/// ⚠️ SPACING, NOT WIDTH. The renderer floors a stroke at one pixel, so at shelf size every stave
/// line is exactly one pixel whatever it was authored as; what a viewer actually reads is HOW MANY
/// there are and how far apart. Six on a cask and eleven on a vat is a difference you can see at
/// twenty pixels; a stave twice as wide is not.
function brs_staves(_cx, _y0, _y1, _hw, _n) {
    var _out = [];
    for (var _i = 1; _i < _n; _i++) {
        var _f = -1 + 2 * (_i / _n);
        var _x = _cx + _f * _hw * 0.86;
        // Shorten toward the edges: a stave near the silhouette is seen almost edge-on and running
        // it the full height puts a straight line across a curved shoulder.
        var _sh = (1 - abs(_f) * 0.55);
        var _my = (_y0 + _y1) * 0.5, _hh = (_y1 - _y0) * 0.5 * _sh;
        brs_append(_out, brs_incise([[_x, _my - _hh], [_x, _my + _hh]], false, 0.012));
    }
    return _out;
}

/// A stencilled brand on a crate or sack - the trade's mark, in ink rather than in relief.
///
/// ⛔ FLAT, ON PURPOSE, AND IT IS THE ONLY FLAT THING ON A WARE. Stencil ink sits IN the grain; it
/// has no wall and catches no light, and bevelling it turns a brand into an applied badge. The
/// contrast between a lit form and a dead-flat mark on it is a large part of why these read as
/// goods rather than as icons.
function brs_stencil(_cx, _cy, _r, _kind) {
    var _out = [];
    switch (_kind) {
        case 0: { // a barred circle - the guild check
            array_push(_out, brs_ring(_cx, _cy, _r, _r * 0.20, "mark"));
            array_push(_out, brs_poly([[_cx - _r * 0.8, _cy], [_cx + _r * 0.8, _cy]], false, _r * 0.20, "mark"));
        } break;
        case 1: { // a chevron pair - the carrier's mark
            for (var _i = 0; _i < 2; _i++) {
                var _o = _cy - _r * 0.35 + _i * _r * 0.7;
                array_push(_out, brs_poly([[_cx - _r * 0.75, _o + _r * 0.3], [_cx, _o - _r * 0.3],
                                           [_cx + _r * 0.75, _o + _r * 0.3]], false, _r * 0.20, "mark"));
            }
        } break;
        case 2: { // a triangle - the excise stamp
            array_push(_out, brs_poly(brs_star_pts(_cx, _cy, _r * 0.92, 3, -BRS_TAU * 0.25),
                                      true, _r * 0.20, "mark"));
        } break;
        case 3: { // a crossed square - the bonded seal
            array_push(_out, brs_rect_poly(_cx - _r * 0.72, _cy - _r * 0.72, _cx + _r * 0.72,
                                           _cy + _r * 0.72, _r * 0.20, "mark"));
            array_push(_out, brs_poly([[_cx - _r * 0.72, _cy - _r * 0.72],
                                       [_cx + _r * 0.72, _cy + _r * 0.72]], false, _r * 0.18, "mark"));
        } break;
        default: { // three tally bars - the weighed mark
            for (var _i = 0; _i < 3; _i++) {
                var _x = _cx - _r * 0.5 + _i * _r * 0.5;
                array_push(_out, brs_poly([[_x, _cy - _r * 0.7], [_x, _cy + _r * 0.7]],
                                          false, _r * 0.17, "mark"));
            }
        } break;
    }
    return _out;
}

/// A cord tie: two short raised strokes crossing the form, plus the loose ends.
function brs_tie(_cx, _cy, _w, _drop) {
    var _out = brs_as_fitting(brs_ridge([[_cx - _w, _cy], [_cx + _w, _cy]], false, 0.026));
    brs_append(_out, brs_as_fitting(brs_ridge(
        [[_cx - _w * 0.25, _cy], [_cx - _w * 0.5, _cy + _drop]], false, 0.018)));
    brs_append(_out, brs_as_fitting(brs_ridge(
        [[_cx + _w * 0.25, _cy], [_cx + _w * 0.55, _cy + _drop * 0.8]], false, 0.018)));
    return _out;
}

/// The shadow a ware casts onto the counter cloth. Drawn FIRST, always.
function brs_ware_shadow(_cx, _hw) {
    return [brs_ring_fill(brs_ellipse_pts(_cx + 0.035, BRS_STAND + 0.012, _hw * 1.06,
                                          _hw * 0.17, 20), "shadow", undefined, undefined)];
}

/// ============================================================================================
/// THE EIGHT TRADES
/// ============================================================================================

function brs_trade_ids() {
    return ["provision", "cloth", "metal", "drink", "spice", "timber", "hide", "luxury"];
}

function brs_trade_name(_id) {
    switch (_id) {
        case "provision": return "Grain & Provision";
        case "cloth":     return "Cloth & Fibre";
        case "metal":     return "Metal & Ore";
        case "drink":     return "Drink";
        case "spice":     return "Spice & Apothecary";
        case "timber":    return "Timber & Stone";
        case "hide":      return "Hide & Craft";
        default:          return "Luxury";
    }
}

/// Every ware id in the corpus, grouped six per trade in trade order.
function brs_ware_ids() {
    return [
        "grain_sack", "flour_barrel", "bread_batch", "cheese_wheel", "salt_block", "honey_pot",
        "linen_bolt", "wool_bale", "dyed_silk", "hemp_coil", "raw_fleece", "thread_rack",
        "iron_ingot", "copper_stack", "silver_bar", "ore_basket", "nail_keg", "shoe_ring",
        "wine_cask", "ale_barrel", "spirit_bottle", "water_skin", "cider_jug", "mead_amphora",
        "spice_jar", "pepper_sack", "saffron_box", "herb_bundle", "oil_flask", "incense_cakes",
        "plank_stack", "log_bundle", "charcoal_sack", "cut_stone", "slate_tiles", "lime_bucket",
        "hide_roll", "tanned_stack", "candle_box", "tallow_tub", "tool_chest", "wax_tablets",
        "pearl_casket", "glass_beads", "indigo_pot", "lacquer_box", "gilt_icon", "perfume_vial"
    ];
}

/// The ECONOMICS of a ware. Nothing here draws.
///
///   base    the price in a market at rest, in the buyer's own coin units
///   bulk    how much cart space one unit takes - what makes a caravan choose
///   perish  fraction of stock lost per season; 0 for metal and stone
///   elast   how sharply demand answers price. 1.0 is ordinary; bread is 0.35 (people eat it at
///           any price) and pearls are 2.4 (nobody must have one)
///   mark    which stencil the crate carries, 0-4, or -1 for a good that carries none
function brs_ware_spec(_id) {
    switch (_id) {
        /* -- GRAIN & PROVISION ------------------------------------------------------------- */
        case "grain_sack":   return { name: "Sack of Grain",     trade: "provision", body: "sackcloth", fitting: "leather", base:   9, bulk: 1.00, perish: 0.06, elast: 0.45, mark: 0 };
        case "flour_barrel": return { name: "Barrel of Flour",   trade: "provision", body: "pine",      fitting: "iron",    base:  16, bulk: 1.20, perish: 0.09, elast: 0.55, mark: 4 };
        case "bread_batch":  return { name: "Batch of Loaves",   trade: "provision", body: "clay",      fitting: "wool",    base:   4, bulk: 0.35, perish: 0.62, elast: 0.35, mark: -1 };
        case "cheese_wheel": return { name: "Wheel of Cheese",   trade: "provision", body: "wax",       fitting: "sackcloth",   base:  22, bulk: 0.55, perish: 0.18, elast: 0.90, mark: -1 };
        case "salt_block":   return { name: "Block of Salt",     trade: "provision", body: "stone",     fitting: "iron", base: 31, bulk: 0.70, perish: 0.01, elast: 0.60, mark: 2 };
        case "honey_pot":    return { name: "Pot of Honey",      trade: "provision", body: "clay",      fitting: "wax",     base:  27, bulk: 0.30, perish: 0.03, elast: 1.15, mark: -1 };
        /* -- CLOTH & FIBRE ----------------------------------------------------------------- */
        case "linen_bolt":   return { name: "Bolt of Linen",     trade: "cloth",     body: "linen",     fitting: "leather",    base:  34, bulk: 0.80, perish: 0.02, elast: 1.05, mark: -1 };
        case "wool_bale":    return { name: "Bale of Wool",      trade: "cloth",     body: "wool",      fitting: "leather", base:  26, bulk: 1.45, perish: 0.04, elast: 0.85, mark: 1 };
        case "dyed_silk":    return { name: "Dyed Silk",         trade: "cloth",     body: "glass",     fitting: "wax",     base:  96, bulk: 0.25, perish: 0.02, elast: 2.05, mark: -1 };
        case "hemp_coil":    return { name: "Coil of Hemp Rope", trade: "cloth",     body: "sackcloth", fitting: "iron",    base:  18, bulk: 0.95, perish: 0.02, elast: 0.75, mark: -1 };
        case "raw_fleece":   return { name: "Raw Fleece",        trade: "cloth",     body: "wool",      fitting: "sackcloth", base: 12, bulk: 1.30, perish: 0.07, elast: 0.80, mark: -1 };
        case "thread_rack":  return { name: "Rack of Thread",    trade: "cloth",     body: "wax",       fitting: "pine",    base:  21, bulk: 0.30, perish: 0.01, elast: 1.25, mark: -1 };
        /* -- METAL & ORE ------------------------------------------------------------------- */
        case "iron_ingot":   return { name: "Iron Ingot",        trade: "metal",     body: "iron",      fitting: "stone",   base:  40, bulk: 0.70, perish: 0.00, elast: 0.70, mark: -1 };
        case "copper_stack": return { name: "Copper Billets",    trade: "metal",     body: "copper",    fitting: "iron",    base:  62, bulk: 0.80, perish: 0.00, elast: 0.95, mark: -1 };
        case "silver_bar":   return { name: "Silver Bar",        trade: "metal",     body: "tin",       fitting: "iron",    base: 210, bulk: 0.35, perish: 0.00, elast: 1.60, mark: 3 };
        case "ore_basket":   return { name: "Basket of Ore",     trade: "metal",     body: "sackcloth", fitting: "iron",   base:  15, bulk: 1.35, perish: 0.00, elast: 0.65, mark: -1 };
        case "nail_keg":     return { name: "Keg of Nails",      trade: "metal",     body: "oak",       fitting: "iron",    base:  24, bulk: 0.60, perish: 0.00, elast: 0.80, mark: 4 };
        case "shoe_ring":    return { name: "Ring of Horseshoes", trade: "metal",    body: "iron",      fitting: "pine", base:  29, bulk: 0.65, perish: 0.00, elast: 0.90, mark: -1 };
        /* -- DRINK ------------------------------------------------------------------------- */
        case "wine_cask":    return { name: "Cask of Wine",      trade: "drink",     body: "oak",       fitting: "iron",    base:  58, bulk: 1.60, perish: 0.03, elast: 1.30, mark: 0 };
        case "ale_barrel":   return { name: "Barrel of Ale",     trade: "drink",     body: "pine",      fitting: "iron",    base:  23, bulk: 1.55, perish: 0.11, elast: 0.75, mark: -1 };
        case "spirit_bottle": return { name: "Bottle of Spirit", trade: "drink",     body: "glass",     fitting: "wax",     base:  44, bulk: 0.20, perish: 0.00, elast: 1.55, mark: -1 };
        case "water_skin":   return { name: "Water Skin",        trade: "drink",     body: "leather",   fitting: "tin",  base:   7, bulk: 0.30, perish: 0.05, elast: 0.40, mark: -1 };
        case "cider_jug":    return { name: "Jug of Cider",      trade: "drink",     body: "clay",      fitting: "wax",     base:  13, bulk: 0.45, perish: 0.14, elast: 0.95, mark: -1 };
        case "mead_amphora": return { name: "Amphora of Mead",   trade: "drink",     body: "clay",      fitting: "pine",    base:  37, bulk: 0.85, perish: 0.04, elast: 1.35, mark: 2 };
        /* -- SPICE & APOTHECARY ------------------------------------------------------------ */
        case "spice_jar":    return { name: "Jar of Spice",      trade: "spice",     body: "clay",      fitting: "linen",   base:  73, bulk: 0.25, perish: 0.03, elast: 1.75, mark: -1 };
        case "pepper_sack":  return { name: "Sack of Pepper",    trade: "spice",     body: "sackcloth", fitting: "leather", base:  88, bulk: 0.40, perish: 0.02, elast: 1.80, mark: 3 };
        case "saffron_box":  return { name: "Box of Saffron",    trade: "spice",     body: "pine",      fitting: "bronze",  base: 260, bulk: 0.12, perish: 0.05, elast: 2.30, mark: -1 };
        case "herb_bundle":  return { name: "Bundle of Herbs",   trade: "spice",     body: "wool",      fitting: "sackcloth", base: 11, bulk: 0.35, perish: 0.24, elast: 1.10, mark: -1 };
        case "oil_flask":    return { name: "Flask of Oil",      trade: "spice",     body: "glass",     fitting: "sackcloth", base:  35, bulk: 0.30, perish: 0.02, elast: 1.20, mark: -1 };
        case "incense_cakes": return { name: "Incense Cakes",    trade: "spice",     body: "wax",       fitting: "sackcloth",   base:  54, bulk: 0.20, perish: 0.06, elast: 1.95, mark: -1 };
        /* -- TIMBER & STONE ---------------------------------------------------------------- */
        case "plank_stack":  return { name: "Stack of Planks",   trade: "timber",    body: "pine",      fitting: "iron",    base:  19, bulk: 1.70, perish: 0.01, elast: 0.70, mark: -1 };
        case "log_bundle":   return { name: "Bundle of Logs",    trade: "timber",    body: "oak",       fitting: "iron",    base:  10, bulk: 1.85, perish: 0.01, elast: 0.55, mark: -1 };
        case "charcoal_sack": return { name: "Sack of Charcoal", trade: "timber",    body: "sackcloth", fitting: "iron",   base:  14, bulk: 0.90, perish: 0.03, elast: 0.65, mark: 1 };
        case "cut_stone":    return { name: "Cut Ashlar",        trade: "timber",    body: "stone",     fitting: "iron",    base:  33, bulk: 1.95, perish: 0.00, elast: 0.60, mark: 2 };
        case "slate_tiles":  return { name: "Stack of Slate",    trade: "timber",    body: "stone",     fitting: "wool",    base:  17, bulk: 1.25, perish: 0.02, elast: 0.75, mark: -1 };
        case "lime_bucket":  return { name: "Bucket of Lime",    trade: "timber",    body: "pine",      fitting: "iron",    base:   8, bulk: 0.50, perish: 0.10, elast: 0.60, mark: -1 };
        /* -- HIDE & CRAFT ------------------------------------------------------------------ */
        case "hide_roll":    return { name: "Rolled Hide",       trade: "hide",      body: "leather",   fitting: "sackcloth", base: 28, bulk: 1.10, perish: 0.05, elast: 0.95, mark: -1 };
        case "tanned_stack": return { name: "Tanned Leather",    trade: "hide",      body: "leather",   fitting: "linen",   base:  46, bulk: 0.75, perish: 0.02, elast: 1.15, mark: 4 };
        case "candle_box":   return { name: "Box of Candles",    trade: "hide",      body: "pine",      fitting: "wax",     base:  20, bulk: 0.45, perish: 0.04, elast: 1.00, mark: -1 };
        case "tallow_tub":   return { name: "Tub of Tallow",     trade: "hide",      body: "oak",       fitting: "wax",     base:  12, bulk: 0.65, perish: 0.12, elast: 0.70, mark: -1 };
        case "tool_chest":   return { name: "Chest of Tools",    trade: "hide",      body: "oak",       fitting: "iron",    base:  85, bulk: 1.15, perish: 0.00, elast: 1.30, mark: 3 };
        case "wax_tablets":  return { name: "Wax Tablets",       trade: "hide",      body: "pine",      fitting: "wax",     base:   9, bulk: 0.15, perish: 0.02, elast: 1.05, mark: -1 };
        /* -- LUXURY ------------------------------------------------------------------------ */
        case "pearl_casket": return { name: "Casket of Pearls",  trade: "luxury",    body: "leather",   fitting: "tin",  base: 420, bulk: 0.10, perish: 0.00, elast: 2.40, mark: -1 };
        case "glass_beads":  return { name: "Strings of Beads",  trade: "luxury",    body: "glass",     fitting: "pine",    base:  67, bulk: 0.20, perish: 0.00, elast: 1.85, mark: -1 };
        case "indigo_pot":   return { name: "Pot of Indigo",     trade: "luxury",    body: "clay",      fitting: "iron",    base: 118, bulk: 0.35, perish: 0.02, elast: 1.90, mark: -1 };
        case "lacquer_box":  return { name: "Lacquer Box",       trade: "luxury",    body: "oak",       fitting: "tin",  base: 152, bulk: 0.20, perish: 0.00, elast: 2.10, mark: -1 };
        case "gilt_icon":    return { name: "Gilt Icon",         trade: "luxury",    body: "pine",      fitting: "bronze",  base: 305, bulk: 0.25, perish: 0.00, elast: 2.25, mark: -1 };
        default:             return { name: "Perfume Vial",      trade: "luxury",    body: "glass",     fitting: "tin",  base: 190, bulk: 0.08, perish: 0.03, elast: 2.35, mark: -1 };
    }
}

/// Which trade a ware belongs to. One lookup, so a caller never re-derives it from the id.
function brs_ware_trade(_id) { return brs_ware_spec(_id).trade; }

/// Every ware in a trade, in corpus order.
function brs_trade_wares(_trade) {
    var _ids = brs_ware_ids(), _out = [];
    for (var _i = 0; _i < array_length(_ids); _i++) {
        if (brs_ware_spec(_ids[_i]).trade == _trade) array_push(_out, _ids[_i]);
    }
    return _out;
}

/// ============================================================================================
/// TRADE ONE - GRAIN & PROVISION
/// ============================================================================================

/// A slumped sack: wide and heavy at the bottom, gathered to a tied neck.
function brs_w_grain_sack() {
    var _hw = brs_profile_curve(0.31, 15, 0.66, 0.78, 0.30, 0.05);
    var _o = brs_ware_shadow(0, 0.30);
    brs_append(_o, brs_body(0, -0.33, BRS_STAND, _hw, 0.052));
    brs_append(_o, brs_sheen(0, -0.33, BRS_STAND, _hw, 0.52, 0.055, "m3"));
    // The two creases that make cloth read as cloth rather than as a bag of stone: they run from
    // the tie down toward the widest point and stop there, because that is where the weight is.
    brs_append(_o, brs_incise(brs_qbez([-0.10, -0.16], [-0.15, 0.04], [-0.18, 0.20], 6), false, 0.014));
    brs_append(_o, brs_incise(brs_qbez([0.09, -0.16], [0.15, 0.02], [0.17, 0.18], 6), false, 0.014));
    brs_append(_o, brs_tie(0, -0.20, 0.085, 0.10));
    brs_append(_o, brs_stencil(0.005, 0.15, 0.095, 0));
    return _o;
}

/// A small open barrel with flour heaped above the rim - the one provision good you can see INTO.
function brs_w_flour_barrel() {
    var _hw = brs_profile_curve(0.27, 12, 0.20, 0.52, 0.0, 0.0);
    var _o = brs_ware_shadow(0, 0.27);
    brs_append(_o, brs_body(0, -0.10, BRS_STAND, _hw, 0.040));
    brs_append(_o, brs_sheen(0, -0.10, BRS_STAND, _hw, 0.46, 0.050, "m3"));
    brs_append(_o, brs_staves(0, -0.08, BRS_STAND - 0.02, 0.26, 5));
    brs_append(_o, brs_hoop(0, 0.02, 0.268, 0.022));
    brs_append(_o, brs_hoop(0, 0.30, 0.262, 0.022));
    // The heap. Drawn in the timber's own specular stop, which is the palest value the ware owns -
    // flour has no ramp of its own and inventing one for a single good is how a corpus grows a
    // fourteenth material nothing else uses.
    var _heap = brs_ellipse_pts(0, -0.11, 0.245, 0.075, 18);
    brs_append(_o, brs_raise(_heap, 0.055, 3, "m4"));
    brs_append(_o, brs_incise([[-0.12, -0.15], [-0.02, -0.13]], false, 0.012));
    brs_append(_o, brs_incise([[0.04, -0.16], [0.13, -0.13]], false, 0.012));
    return _o;
}

/// Three loaves, two below and one on top, each scored across the crown.
function brs_w_bread_batch() {
    var _o = brs_ware_shadow(0, 0.31);
    var _at = [[-0.17, 0.30, 0.155, 0.115], [0.17, 0.30, 0.155, 0.115], [0.0, 0.10, 0.170, 0.125]];
    for (var _i = 0; _i < 3; _i++) {
        var _a = _at[_i];
        var _pts = brs_ellipse_pts(_a[0], _a[1], _a[2], _a[3], 16);
        brs_append(_o, brs_raise(_pts, 0.048, 3, "m2"));
        // Two slashes, not one: a single score reads as a crack in a stone. And they are INCISED,
        // so the lamp puts a lit wall on the far side of each - which is exactly what a scored
        // loaf does when it opens in the oven.
        for (var _k = -1; _k <= 1; _k += 2) {
            brs_append(_o, brs_incise([[_a[0] - _a[2] * 0.42 + _k * 0.018, _a[1] - _a[3] * 0.30 + _k * 0.022],
                                       [_a[0] + _a[2] * 0.42 + _k * 0.018, _a[1] - _a[3] * 0.44 + _k * 0.022]],
                                      false, 0.020));
        }
    }
    return _o;
}

/// A wheel on its side: the round face, the thickness behind it, and one wedge cut away.
function brs_w_cheese_wheel() {
    var _o = brs_ware_shadow(-0.02, 0.29);
    // The thickness first, as a shifted copy - the face is painted over its right-hand half, so
    // what survives is a crescent of rind, which is how a cylinder seen three-quarters on reads.
    var _back = brs_ellipse_pts(0.075, 0.10, 0.265, 0.265, 22);
    brs_append(_o, brs_raise(_back, 0.05, 2, "m1"));
    var _face = brs_ellipse_pts(-0.03, 0.13, 0.275, 0.275, 24);
    brs_append(_o, brs_raise(_face, 0.055, 3, "m2"));
    // The cut wedge: a sector taken out of the face, floor first then the two cut walls. The floor
    // is the deep stop because a cut cheese is darker inside than its waxed rind is outside.
    var _sec = [[-0.03, 0.13]];
    var _arc = brs_arc_pts(-0.03, 0.13, 0.275, -BRS_TAU * 0.30, -BRS_TAU * 0.16, 6);
    brs_append(_sec, _arc);
    array_push(_sec, [-0.03, 0.13]);
    array_push(_o, brs_fill(_sec, "m0"));
    brs_append(_o, brs_incise([[-0.03, 0.13], _arc[0]], false, 0.016));
    brs_append(_o, brs_incise([[-0.03, 0.13], _arc[array_length(_arc) - 1]], false, 0.016));
    // The cloth binding round the rind.
    brs_append(_o, brs_as_fitting(brs_ridge(brs_arc_pts(0.075, 0.10, 0.245,
        -BRS_TAU * 0.10, BRS_TAU * 0.22, 8), false, 0.030)));
    return _o;
}

/// A rock-salt block: an angular three-quarter cube with one corner knocked off.
///
/// ⛔ THE ONLY WARE IN THE CORPUS WITH THREE AUTHORED FACES, and it earns them: salt is the one
/// provision good that is a crystal, and a crystal drawn as a bevelled rounded box is a bar of
/// soap. The three faces are separate closed outlines at three ramp stops, so the lamp does not
/// have to imply a corner it cannot see.
function brs_w_salt_block() {
    var _o = brs_ware_shadow(0, 0.36);
    // ⛔ A CRYSTAL, NOT A CUBE. The first version was a neat three-quarter box with three authored
    // faces - which is exactly what the cut ashlar six goods later is, and the corpus distinctness
    // check measured the pair at 0.23 and called them the same picture. It was right: they were
    // built from the same four-sided top, front and side. Rock salt CLEAVES, so its faces are
    // uneven and its silhouette is a lump, and authoring that truth is what separates them.
    var _face = [[-0.37, 0.10], [-0.20, -0.06], [0.06, -0.12], [0.20, -0.02], [0.16, 0.16],
                 [0.06, BRS_STAND], [-0.26, BRS_STAND], [-0.36, 0.28]];
    brs_append(_o, brs_raise(_face, 0.040, 3, "m2"));
    // The lit cleavage planes: three flat facets across the mass, each at a different ramp stop, so
    // the block reads as broken crystal rather than as a bevelled pebble.
    array_push(_o, brs_ring_fill([[-0.20, -0.06], [0.06, -0.12], [0.02, 0.09], [-0.24, 0.13]],
                                 "m4", undefined, undefined));
    array_push(_o, brs_ring_fill([[-0.36, 0.20], [-0.22, 0.13], [-0.18, 0.36], [-0.31, BRS_STAND]],
                                 "m1", undefined, undefined));
    array_push(_o, brs_ring_fill([[0.02, 0.10], [0.16, 0.16], [0.06, BRS_STAND], [-0.05, 0.38]],
                                 "m3", undefined, undefined));
    brs_append(_o, brs_incise([[-0.22, 0.13], [0.02, 0.10]], false, 0.014));
    brs_append(_o, brs_incise([[-0.05, 0.38], [0.02, 0.10]], false, 0.014));
    // Two loose crystals knocked off the mass, on the counter beside it.
    brs_append(_o, brs_raise(brs_star_pts(0.28, 0.35, 0.085, 6, 0.7), 0.028, 2, "m3"));
    brs_append(_o, brs_raise(brs_star_pts(0.36, 0.24, 0.055, 5, 1.9), 0.020, 2, "m4"));
    // The cutter's wedge, in iron, leaning against the block - and the only fitting on this good.
    brs_append(_o, brs_as_fitting(brs_raise(
        [[0.20, 0.02], [0.30, 0.06], [0.24, BRS_STAND - 0.06], [0.17, BRS_STAND - 0.09]],
        0.024, 3, "m2")));
    brs_append(_o, brs_stencil(-0.24, 0.24, 0.062, 2));
    return _o;
}

/// A squat pot with a flared mouth, a wax seal over it, and one drip down the shoulder.
function brs_w_honey_pot() {
    var _hw = brs_profile_curve(0.26, 13, 0.40, 0.64, 0.0, 0.10);
    var _o = brs_ware_shadow(0, 0.24);
    brs_append(_o, brs_body(0, -0.14, BRS_STAND, _hw, 0.045));
    brs_append(_o, brs_sheen(0, -0.14, BRS_STAND, _hw, 0.44, 0.048, "m3"));
    // The flared rim, wider than the neck it sits on, so the silhouette steps. Two masses read as
    // two when their SILHOUETTE steps, never when only their fill changes.
    var _rim = brs_ellipse_pts(0, -0.15, 0.205, 0.052, 16);
    brs_append(_o, brs_raise(_rim, 0.030, 2, "m3"));
    // The wax seal, in the fitting material, domed over the mouth.
    var _seal = brs_ellipse_pts(0, -0.175, 0.165, 0.042, 14);
    brs_append(_o, brs_as_fitting(brs_raise(_seal, 0.034, 3, "m3")));
    // The drip: a var-width ribbon, fat where it left the rim and thin where it stopped.
    var _drip = brs_qbez([0.15, -0.13], [0.185, 0.00], [0.16, 0.14], 6);
    brs_append(_o, brs_as_fitting(brs_taper_ribbon(_drip, 0.026, 0.007, "m3")));
    return _o;
}

/// ============================================================================================
/// TRADE TWO - CLOTH & FIBRE
/// ============================================================================================

/// A bolt lying on its side, the rolled end toward the viewer.
/// ⛔ THE DRAPE IS WHAT MAKES CLOTH READ AS CLOTH. The first version was two rounded rectangles
/// with a small spiral scratched on one end, and on the corpus sheet it read as a pair of grey
/// BOXES - correct as a description of a bolt and useless as a picture of one. Nothing about a
/// rectangle says fabric. A length hanging off the front with three folds in it says nothing else.
function brs_w_linen_bolt() {
    var _o = brs_ware_shadow(0, 0.32);
    // The bolt lying flat, and the roll's spiral at its left end - larger and deeper than before,
    // because the spiral is the second thing that says "wound cloth".
    var _bolt = brs_round_rect_pts(-0.30, 0.06, 0.33, 0.30, 0.055, 3);
    brs_append(_o, brs_raise(_bolt, 0.048, 3, "m2"));
    for (var _i = 0; _i < 5; _i++) {
        var _r = 0.108 - _i * 0.021;
        brs_append(_o, brs_incise(brs_arc_pts(-0.245 + _i * 0.014, 0.185, _r,
            -BRS_TAU * 0.26, BRS_TAU * 0.26, 8), false, 0.014));
    }
    // The drape: a length unrolled off the front edge, falling to the counter, with three folds.
    var _dr = [];
    brs_append(_dr, brs_qbez([-0.14, 0.28], [-0.20, 0.36], [-0.17, BRS_STAND], 6));
    brs_append(_dr, brs_qbez([0.26, BRS_STAND], [0.24, 0.35], [0.29, 0.28], 6));
    brs_append(_o, brs_raise(_dr, 0.038, 3, "m3"));
    for (var _i = 0; _i < 3; _i++) {
        var _fx = -0.09 + _i * 0.105;
        brs_append(_o, brs_incise(brs_qbez([_fx, 0.29], [_fx - 0.022, 0.37],
                                           [_fx + 0.012, BRS_STAND - 0.01], 5), false, 0.014));
    }
    // ⚠️ A SECOND BOLT STANDING ON END WAS TRIED HERE AND REMOVED. It made the good read as a
    // STEPPED grey object rather than as two bolts - two masses read as two when their silhouette
    // steps, and this pair stepped in a way that suggested one shape with a notch in it. A second
    // bolt lying BEHIND the first, parallel and offset, keeps the "this is stock" reading without
    // inventing a corner. Adding a thing is not the same as adding information.
    var _b2 = brs_round_rect_pts(-0.22, -0.08, 0.35, 0.09, 0.045, 3);
    brs_append(_o, brs_raise(_b2, 0.040, 3, "m1"));
    for (var _i = 0; _i < 4; _i++) {
        var _r2 = 0.078 - _i * 0.018;
        brs_append(_o, brs_incise(brs_arc_pts(-0.175 + _i * 0.012, 0.005, _r2,
            -BRS_TAU * 0.26, BRS_TAU * 0.26, 8), false, 0.013));
    }
    // The binding tapes.
    brs_append(_o, brs_as_fitting(brs_ridge([[0.05, 0.05], [0.05, 0.31]], false, 0.028)));
    brs_append(_o, brs_as_fitting(brs_ridge([[0.14, -0.08], [0.14, 0.09]], false, 0.024)));
    return _o;
}

/// A pressed bale: a hard-edged cube with cords biting into it and fibre escaping at the top.
function brs_w_wool_bale() {
    var _o = brs_ware_shadow(0, 0.31);
    brs_append(_o, brs_box(-0.30, -0.16, 0.30, BRS_STAND, 0.030, 0.048));
    // Two cords, and the bale bulges BETWEEN them - the bulge is drawn as a lighter inset panel,
    // which is the cheapest honest way to say "this is compressed" without a second outline.
    var _bulge = brs_round_rect_pts(-0.26, -0.05, 0.26, 0.31, 0.10, 4);
    array_push(_o, brs_ring_fill(_bulge, "m3", undefined, undefined));
    brs_append(_o, brs_hoop(0, -0.02, 0.305, 0.020));
    brs_append(_o, brs_hoop(0, 0.28, 0.305, 0.020));
    // ⛔ THE ESCAPING FIBRE IS A MASS, NOT SEVEN SCRATCHES. Drawn as short strokes over the top edge
    // it was invisible on the corpus sheet and the bale read as a plain white box with a stencil on
    // it - because the renderer floors every stroke at one pixel, so seven one-pixel hairs against a
    // pale face are nothing at all. A lobed cap of wool bursting out of the top edge is a difference
    // in SILHOUETTE, which is the only kind of difference that survives shelf size.
    var _fl = array_create(30);
    for (var _i = 0; _i < 30; _i++) {
        var _a = (_i / 30) * BRS_TAU;
        var _rr = 1.0 + 0.16 * cos(_a * 7) + 0.09 * cos(_a * 3 + 0.8);
        _fl[_i] = [cos(_a) * 0.265 * _rr, -0.175 + sin(_a) * 0.085 * _rr];
    }
    brs_append(_o, brs_raise(_fl, 0.034, 3, "m4"));
    // And a smaller tuft escaping the right-hand side, so the burst is not symmetrical.
    var _tf = array_create(18);
    for (var _i = 0; _i < 18; _i++) {
        var _a = (_i / 18) * BRS_TAU;
        var _rr = 1.0 + 0.20 * cos(_a * 5 + 1.4);
        _tf[_i] = [0.285 + cos(_a) * 0.075 * _rr, 0.075 + sin(_a) * 0.062 * _rr];
    }
    brs_append(_o, brs_raise(_tf, 0.026, 3, "m3"));
    brs_append(_o, brs_stencil(0.0, 0.13, 0.085, 1));
    return _o;
}

/// Silk over a rod: two draped falls, one behind the other, and nothing else. The only ware in the
/// corpus whose silhouette is entirely curve.
function brs_w_dyed_silk() {
    var _o = brs_ware_shadow(0.02, 0.26);
    // The back fall first, so the front one overlaps it and the pair reads as depth rather than as
    // two flags side by side.
    var _b = [];
    brs_append(_b, brs_qbez([-0.10, -0.20], [-0.30, 0.05], [-0.22, BRS_STAND], 8));
    brs_append(_b, brs_qbez([0.02, BRS_STAND], [0.06, 0.05], [0.14, -0.20], 8));
    brs_append(_o, brs_raise(_b, 0.040, 3, "m1"));
    var _f = [];
    brs_append(_f, brs_qbez([-0.02, -0.22], [-0.16, 0.10], [-0.06, BRS_STAND], 8));
    brs_append(_f, brs_qbez([0.26, BRS_STAND], [0.22, 0.06], [0.20, -0.22], 8));
    brs_append(_o, brs_raise(_f, 0.042, 3, "m2"));
    // Three folds down the front fall, each a ridge not a groove: silk catches light on the fold.
    for (var _i = 0; _i < 3; _i++) {
        var _x = -0.01 + _i * 0.085;
        brs_append(_o, brs_ridge(brs_qbez([_x, -0.18], [_x - 0.035, 0.08], [_x + 0.01, 0.36], 6),
                                 false, 0.016));
    }
    // The rod it hangs over.
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.16, -0.26, 0.26, -0.20, 0.028, 3), 0.022, 2, "m3")));
    return _o;
}

/// Rope coiled into a standing cylinder - six turns stacked, the lay ticked across the front of
/// each, an iron thimble spliced into the eye, and the tail lying on the counter.
///
/// ⛔ STACKED, NOT FLAT, AND THAT IS THE SECOND TIME THIS CORPUS PAID FOR THE SAME MISTAKE. The
/// first version was a flat spiral of concentric ellipses, which is a wide low mass - and so is a
/// shorn fleece four goods earlier, so the distinctness check measured them at 0.29 and was right
/// to. Two goods cannot both be "a wide low pile". A chandler coils rope into a drum, so this one
/// stands up.
function brs_w_hemp_coil() {
    var _o = brs_ware_shadow(0, 0.31);
    // ⛔ EACH TURN IS A ROW OF OVERLAPPING ROUND SECTIONS, NOT A FLAT RING. Drawn as six bevelled
    // ellipses the coil read as a stack of PANCAKES on the corpus sheet - because a rope's whole
    // visual signature is that it is round IN SECTION and repeats at a fixed pitch, and an ellipse
    // outline has neither. Nine circles per turn, overlapping by a third, is unmistakably rope at
    // any size where the circles are more than a pixel across.
    for (var _i = 0; _i < 6; _i++) {
        var _y = BRS_STAND - 0.062 - _i * 0.098;
        var _sq = (_i % 2 == 0) ? -0.014 : 0.014;
        var _w = 0.290 - abs(_i - 2.2) * 0.014;
        for (var _k = 0; _k < 9; _k++) {
            var _x = _sq + lerp(-_w, _w, _k / 8);
            var _r = 0.062;
            brs_append(_o, brs_raise(brs_ellipse_pts(_x, _y, _r, _r * 0.86, 12), _r * 0.52, 2,
                                     (_k % 2 == 0) ? "m2" : "m3"));
            // The lay of the strands: one short diagonal across each section, which is what makes a
            // rope read as TWISTED rather than as a row of beads.
            brs_append(_o, brs_incise([[_x - 0.030, _y + 0.030], [_x + 0.026, _y - 0.030]],
                                      false, 0.013));
        }
    }
    // The thimble: an iron eye seized into the standing end, high on the left.
    brs_append(_o, brs_as_fitting(brs_ridge(brs_ellipse_pts(-0.235, -0.235, 0.070, 0.050, 14),
                                            true, 0.026)));
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.270, -0.180, -0.200, -0.100, 0.018, 2), 0.018, 2, "m3")));
    // The tail, running off the coil and lying on the counter.
    // ⚠️ IT STOPS SHORT OF THE COUNTER LINE BY THE STROKE'S OWN HALF WIDTH. A ridge is three
    // strokes offset either side of its path, so a path that ENDS on the line puts ink below it -
    // measured at +0.036 against a 0.030 tolerance, which is the assertion doing exactly its job.
    brs_append(_o, brs_ridge(brs_qbez([0.29, 0.24], [0.36, 0.34], [0.20, BRS_STAND - 0.035], 6),
                             false, 0.034));
    return _o;
}

/// A fleece: one closed outline with fourteen deep lobes, and no straight line anywhere in it.
///
/// ⛔ LOW AND WIDE, NOT ROUND. The first version was a tall lobed ball and the corpus distinctness
/// check measured it at 0.19 against the cut ashlar - because a ball and a cube seen three-quarters
/// on fill nearly the same cells, whatever their edges are doing. A shorn fleece is a PILE: it
/// spreads on the counter and its height is a third of its width, and authoring that truth is also
/// what separates the two silhouettes.
function brs_w_raw_fleece() {
    var _o = brs_ware_shadow(0, 0.34);
    // ⛔ SIX POINTS PER LOBE, NOT TWO, AND THE DIFFERENCE IS AN EXPLOSION VERSUS A FLEECE. A ripple
    // sampled at two points per cycle has no shoulder: every lobe is a straight run out to a sharp
    // tip and straight back, so the outline reads as a starburst, and the bevel - which insets by a
    // fixed depth - eats the tips and leaves them ragged. MEASURED by opening the material sheet,
    // where wool's sample ware was plainly a cartoon explosion. Fewer lobes, sampled far more
    // finely, and a shallower amplitude: the outline is then a soft cloud with a texture on it,
    // which is what a shorn fleece is.
    var _n1 = 60;
    var _pts = array_create(_n1);
    for (var _i = 0; _i < _n1; _i++) {
        var _a = (_i / _n1) * BRS_TAU;
        var _rr = 1.0 + 0.062 * cos(_a * 10) + 0.045 * cos(_a * 3 + 1.1);
        _pts[_i] = [cos(_a) * 0.350 * _rr, 0.265 + sin(_a) * 0.150 * _rr];
    }
    brs_append(_o, brs_raise(_pts, 0.040, 3, "m2"));
    // A second, smaller fleece thrown on top of the first - two masses, so the good reads as a
    // QUANTITY, which is what a bale of anything has to do on a market shelf.
    var _n2 = 44;
    var _top = array_create(_n2);
    for (var _i = 0; _i < _n2; _i++) {
        var _a = (_i / _n2) * BRS_TAU;
        var _rr = 1.0 + 0.070 * cos(_a * 8 + 0.6) + 0.040 * cos(_a * 3 - 0.4);
        _top[_i] = [-0.04 + cos(_a) * 0.220 * _rr, 0.060 + sin(_a) * 0.125 * _rr];
    }
    brs_append(_o, brs_raise(_top, 0.036, 3, "m3"));
    // Staple locks: seven short curls inside the mass, in the light stop, spaced not sized.
    for (var _i = 0; _i < 7; _i++) {
        var _a = 0.4 + (_i / 7) * BRS_TAU;
        var _cx = cos(_a) * 0.20, _cy = 0.265 + sin(_a) * 0.075;
        brs_append(_o, brs_ridge(brs_arc_pts(_cx, _cy, 0.055, _a, _a + BRS_TAU * 0.42, 5),
                                 false, 0.015));
    }
    // ⛔ THE TWINE IS WHY THIS IS NOT A BATCH OF LOAVES. A shorn fleece and three round loaves are
    // both a wide lumpy mass and the distinctness check measured them at 0.31 - which is a fair
    // reading of two shapes, and the answer is not to make the fleece rounder or the bread lumpier.
    // A fleece comes off the board TIED, so it gets two crossed cords in the fitting material, and
    // the check compares where each good's fittings are as well as what shape it is. The bread has
    // no fittings at all, so the pair separates completely - and the picture is more truthful.
    brs_append(_o, brs_as_fitting(brs_ridge(
        brs_qbez([-0.24, 0.115], [-0.04, 0.215], [0.20, 0.135], 8), false, 0.030)));
    brs_append(_o, brs_as_fitting(brs_ridge(
        brs_qbez([-0.15, 0.055], [-0.10, 0.245], [-0.02, BRS_STAND - 0.03], 8), false, 0.026)));
    return _o;
}

/// Three bobbins on a rack. The silhouette is a comb, which nothing else in the corpus is.
function brs_w_thread_rack() {
    var _o = brs_ware_shadow(0, 0.31);
    // The rack: two feet and a rail, in the fitting timber.
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.34, 0.34, 0.34, BRS_STAND, 0.020, 2), 0.026, 2, "m2")));
    for (var _i = 0; _i < 3; _i++) {
        var _x = -0.21 + _i * 0.21;
        var _h = 0.30 + ((_i == 1) ? 0.06 : 0.0);
        // The spindle.
        brs_append(_o, brs_as_fitting(brs_raise(
            brs_round_rect_pts(_x - 0.018, BRS_STAND - _h - 0.03, _x + 0.018, 0.35, 0.014, 2),
            0.014, 2, "m3")));
        // The wound thread: a barrel with flared ends, in the body colour, so the rack and the
        // goods on it are different materials at a glance.
        var _hw = brs_profile_curve(0.072, 9, -0.55, 0.5, 0.0, 0.0);
        brs_append(_o, brs_body(_x, BRS_STAND - _h + 0.02, 0.33, _hw, 0.022));
        // The wind: four incised turns. Spacing again - eight would fill in.
        for (var _k = 0; _k < 4; _k++) {
            var _y = BRS_STAND - _h + 0.06 + _k * (_h - 0.10) / 4;
            brs_append(_o, brs_incise([[_x - 0.050, _y], [_x + 0.050, _y + 0.010]], false, 0.011));
        }
    }
    return _o;
}

/// ============================================================================================
/// TRADE THREE - METAL & ORE
/// ============================================================================================

/// Two heavy bars, the second behind and to the left, each seen three-quarters on: the top face
/// and the long front wall.
///
/// ⚠️ TWO, BECAUSE ONE WAS TOO LITTLE OF THE PLATE. The corpus ink floor measured a single bar at
/// 0.15 of its own frame against a corpus mean of 0.24, and a good that fills a seventh of its
/// plate looks lost beside its neighbours on a shelf. Adding a second bar is the fix that is also
/// the better picture: a market sells ingots by the cartload, not one at a time.
function brs_w_iron_ingot() {
    var _o = brs_ware_shadow(0, 0.35);
    var _btop = [[-0.36, -0.03], [0.14, -0.11], [0.26, -0.03], [-0.24, 0.05]];
    var _bfront = [[-0.24, 0.05], [0.26, -0.03], [0.26, 0.11], [-0.24, 0.19]];
    brs_append(_o, brs_raise(_bfront, 0.026, 3, "m0"));
    brs_append(_o, brs_raise(_btop, 0.028, 3, "m2"));
    var _top = [[-0.30, 0.16], [0.22, 0.08], [0.34, 0.16], [-0.18, 0.24]];
    var _front = [[-0.18, 0.24], [0.34, 0.16], [0.34, 0.33], [-0.18, BRS_STAND]];
    brs_append(_o, brs_raise(_front, 0.030, 3, "m1"));
    brs_append(_o, brs_raise(_top, 0.032, 3, "m3"));
    // The mould's draft angle, as one incised line along the top edge, and the pour ripple.
    brs_append(_o, brs_incise([[-0.15, 0.225], [0.31, 0.155]], false, 0.014));
    for (var _i = 0; _i < 3; _i++) {
        var _t = 0.25 + _i * 0.22;
        brs_append(_o, brs_incise([[lerp(-0.28, 0.32, _t) - 0.02, lerp(0.165, 0.155, _t)],
                                   [lerp(-0.20, 0.34, _t) + 0.02, lerp(0.235, 0.215, _t)]],
                                  false, 0.012));
    }
    return _o;
}

/// Three billets stacked two-and-one. A pyramid silhouette - the tell against the single bar is
/// the OUTLINE, which is the only tell that survives shelf size.
function brs_w_copper_stack() {
    var _o = brs_ware_shadow(0, 0.36);
    // Six billets, three-two-one. Enlarged from a three-billet pyramid that filled 0.14 of its own
    // plate against a corpus mean of 0.24 - the fix for a thin good is more of it, never a lower
    // floor, and a merchant's copper comes in a heap.
    var _at = [[-0.24, 0.335], [0.00, 0.335], [0.24, 0.335], [-0.12, 0.165], [0.12, 0.165],
               [0.00, -0.005]];
    for (var _i = 0; _i < 6; _i++) {
        var _cx = _at[_i][0], _cy = _at[_i][1];
        var _top = [[_cx - 0.130, _cy - 0.055], [_cx + 0.085, _cy - 0.090],
                    [_cx + 0.135, _cy - 0.050], [_cx - 0.080, _cy - 0.015]];
        var _front = [[_cx - 0.080, _cy - 0.015], [_cx + 0.135, _cy - 0.050],
                      [_cx + 0.135, _cy + 0.055], [_cx - 0.080, _cy + 0.090]];
        brs_append(_o, brs_raise(_front, 0.022, 2, "m1"));
        brs_append(_o, brs_raise(_top, 0.024, 3, "m3"));
    }
    // Two assay nicks on the top billet, sunk rather than incised: an assayer takes a chip out.
    brs_append(_o, brs_pit(-0.040, -0.062, 0.022, 10));
    brs_append(_o, brs_pit(0.035, -0.078, 0.018, 10));
    return _o;
}

/// A slim bar standing on end against a block, stamped. The only vertical metal good, and the only
/// one with a mark struck INTO it.
function brs_w_silver_bar() {
    var _o = brs_ware_shadow(0.02, 0.20);
    // The counterweight block behind, in the fitting material, so the bar has something to lean on
    // and the silhouette is not a lone rectangle.
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(0.06, 0.20, 0.30, BRS_STAND, 0.022, 3), 0.030, 2, "m1")));
    var _bar = [[-0.13, -0.30], [0.10, -0.34], [0.17, BRS_STAND], [-0.06, BRS_STAND]];
    brs_append(_o, brs_raise(_bar, 0.038, 3, "m2"));
    // The lit face of the bar: a narrow inset panel down its left, which is what a flat polished
    // face does under a lamp up and to the left.
    array_push(_o, brs_ring_fill([[-0.11, -0.27], [-0.01, -0.29], [0.03, 0.36], [-0.05, 0.37]],
                                 "m4", undefined, undefined));
    brs_append(_o, brs_stencil(0.035, -0.13, 0.062, 3));
    // The assay flat: a sunk rectangle two thirds down, where the bar was tested.
    brs_append(_o, brs_sink(brs_round_rect_pts(-0.03, 0.08, 0.11, 0.20, 0.014, 2), 0.016, 2, "m1"));
    return _o;
}

/// A wicker basket heaped with broken ore. Trapezoid silhouette, woven, spilling.
function brs_w_ore_basket() {
    var _o = brs_ware_shadow(0, 0.31);
    var _bask = [[-0.32, 0.06], [0.32, 0.06], [0.22, BRS_STAND], [-0.22, BRS_STAND]];
    brs_append(_o, brs_raise(_bask, 0.045, 3, "m2"));
    // The weave: four courses, each a shallow sag, and five uprights. Spacing carries it.
    //
    // ⚠️ A SAGGED BEZIER, NOT AN ARC SEGMENT. The first version sampled a circle and its deepest
    // point sat a quarter of the basket's own width BELOW the course it belonged to - so the lowest
    // course put ink 0.066 under the counter line. A three-point bezier says "dip by this much" in
    // the units the author is thinking in, and cannot be off by a radius.
    for (var _i = 0; _i < 4; _i++) {
        var _t = (_i + 0.5) / 4;
        var _y = lerp(0.10, BRS_STAND - 0.03, _t);
        var _w = lerp(0.30, 0.205, _t);
        brs_append(_o, brs_incise(brs_qbez([-_w, _y - 0.020], [0, _y + 0.045], [_w, _y - 0.020], 6),
                                  false, 0.013));
    }
    for (var _i = 0; _i < 5; _i++) {
        var _f = -1 + 2 * ((_i + 0.5) / 5);
        brs_append(_o, brs_incise([[_f * 0.30, 0.08], [_f * 0.205, BRS_STAND - 0.01]], false, 0.012));
    }
    // The ore: five angular lumps in the fitting material, heaped over the rim so the silhouette
    // is broken. A basket with a flat top is a box.
    var _lump = [[-0.20, 0.00, 0.105], [-0.02, -0.06, 0.125], [0.17, -0.01, 0.100],
                 [0.07, 0.05, 0.085], [-0.11, 0.05, 0.078]];
    for (var _i = 0; _i < 5; _i++) {
        var _l = _lump[_i];
        var _pts = brs_star_pts(_l[0], _l[1], _l[2], 6, 0.4 + _i * 0.7);
        brs_append(_o, brs_as_fitting(brs_raise(_pts, _l[2] * 0.42, 2, (_i % 2 == 0) ? "m2" : "m3")));
    }
    return _o;
}

/// A short wide keg with the lid off and nails standing out of it.
function brs_w_nail_keg() {
    var _hw = brs_profile_curve(0.245, 11, 0.16, 0.50, 0.0, 0.0);
    var _o = brs_ware_shadow(0, 0.25);
    brs_append(_o, brs_body(0, 0.02, BRS_STAND, _hw, 0.038));
    brs_append(_o, brs_sheen(0, 0.02, BRS_STAND, _hw, 0.44, 0.045, "m3"));
    brs_append(_o, brs_staves(0, 0.04, BRS_STAND - 0.01, 0.235, 4));
    brs_append(_o, brs_hoop(0, 0.10, 0.240, 0.019));
    brs_append(_o, brs_hoop(0, 0.34, 0.236, 0.019));
    // The nails: eleven, in the fitting metal, leaning at different angles out of the open top.
    // Eleven rather than four, because a keg of nails is a QUANTITY and four nails is a repair job.
    for (var _i = 0; _i < 11; _i++) {
        var _f = -1 + 2 * (_i / 10);
        var _x = _f * 0.185;
        var _lean = _f * 0.075 + (((_i * 5) % 3) - 1) * 0.020;
        var _h = 0.135 + ((_i * 3) % 4) * 0.022;
        brs_append(_o, brs_as_fitting(brs_ridge([[_x, 0.03], [_x + _lean, 0.03 - _h]], false, 0.016)));
        brs_append(_o, brs_as_fitting(brs_ridge(
            [[_x + _lean - 0.020, 0.03 - _h], [_x + _lean + 0.020, 0.03 - _h - 0.008]], false, 0.014)));
    }
    return _o;
}

/// Three horseshoes hung on a peg. A U-shaped silhouette repeated - the only ware in the corpus
/// built entirely from open strokes, because a horseshoe fill would need a concave fan.
///
/// ⛔ THE POST IS NOT DECORATION AND WAS NOT IN THE FIRST VERSION. Hung shoes touch nothing, so the
/// good floated a third of the box above the counter - which reads to a player as a z-order fault
/// in their own shelf code. A hanging good needs the thing it hangs FROM to be part of the good.
function brs_w_shoe_ring() {
    var _o = brs_ware_shadow(0, 0.26);
    // The post and its foot, in the fitting timber, standing on the counter line.
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.040, -0.40, 0.040, BRS_STAND - 0.05, 0.016, 2), 0.026, 3, "m2")));
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.165, BRS_STAND - 0.06, 0.165, BRS_STAND, 0.018, 2), 0.024, 2, "m3")));
    // The peg the ring hangs on.
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(0.030, -0.38, 0.150, -0.335, 0.018, 2), 0.020, 2, "m3")));
    // The ring, drawn before the shoes so they hang in front of it.
    brs_append(_o, brs_ridge(brs_arc_pts(0.095, -0.27, 0.085, 0, BRS_TAU, 14), true, 0.026));
    var _at = [[-0.19, 0.06, 0.185, -0.30], [0.19, 0.05, 0.180, 0.28], [0.00, 0.16, 0.205, 0.0]];
    for (var _i = 0; _i < 3; _i++) {
        var _a = _at[_i];
        var _r = _a[2];
        // The shoe: a thick arc open at the bottom, with the two heels squared off.
        var _arc = brs_arc_pts(_a[0], _a[1], _r, BRS_TAU * 0.54 + _a[3] * 0.16,
                                              BRS_TAU * 0.96 + _a[3] * 0.16, 12);
        brs_append(_o, brs_ridge(_arc, false, 0.062));
        brs_append(_o, brs_incise(brs_arc_pts(_a[0], _a[1], _r, BRS_TAU * 0.56 + _a[3] * 0.16,
                                              BRS_TAU * 0.94 + _a[3] * 0.16, 10), false, 0.014));
        // Four nail holes per shoe, punched.
        for (var _k = 0; _k < 4; _k++) {
            var _t = BRS_TAU * (0.60 + _k * 0.10) + _a[3] * 0.16;
            brs_append(_o, brs_pit(_a[0] + cos(_t) * _r, _a[1] + sin(_t) * _r, 0.017, 8));
        }
    }
    return _o;
}

/// ============================================================================================
/// TRADE FOUR - DRINK
/// ============================================================================================

/// The big standing cask: three hoops, six staves, a bung and a stencil. The corpus reference for
/// a body of revolution.
function brs_w_wine_cask() {
    var _hw = brs_profile_curve(0.30, 15, 0.26, 0.50, 0.0, 0.0);
    var _o = brs_ware_shadow(0, 0.28);
    brs_append(_o, brs_body(0, -0.30, BRS_STAND, _hw, 0.050));
    brs_append(_o, brs_sheen(0, -0.30, BRS_STAND, _hw, 0.46, 0.058, "m3"));
    brs_append(_o, brs_staves(0, -0.27, BRS_STAND - 0.02, 0.29, 6));
    brs_append(_o, brs_hoop(0, -0.22, 0.263, 0.024));
    brs_append(_o, brs_hoop(0, 0.06, 0.302, 0.028));
    brs_append(_o, brs_hoop(0, 0.34, 0.263, 0.024));
    // The head: the top ellipse, sunk, so the cask is seen slightly from above like everything
    // else on this counter.
    brs_append(_o, brs_sink(brs_ellipse_pts(0, -0.30, 0.222, 0.062, 16), 0.030, 2, "m1"));
    // The bung, proud of the belly.
    brs_append(_o, brs_as_fitting(brs_boss(0.155, 0.02, 0.040, 12)));
    brs_append(_o, brs_stencil(-0.075, 0.09, 0.080, 0));
    return _o;
}

/// A barrel on its side in a cradle: the round END faces the viewer, so the silhouette is a circle
/// on legs and cannot be confused with the standing cask at any size.
function brs_w_ale_barrel() {
    var _o = brs_ware_shadow(0, 0.30);
    // The cradle first.
    brs_append(_o, brs_as_fitting(brs_raise(
        [[-0.30, 0.30], [0.30, 0.30], [0.24, BRS_STAND], [-0.24, BRS_STAND]], 0.030, 2, "m1")));
    // The barrel body running back-right, then the end face over it.
    var _body = brs_ellipse_pts(0.065, 0.02, 0.245, 0.275, 20);
    brs_append(_o, brs_raise(_body, 0.045, 2, "m1"));
    var _endf = brs_ellipse_pts(-0.045, 0.05, 0.255, 0.285, 22);
    brs_append(_o, brs_raise(_endf, 0.048, 3, "m2"));
    // The head boards: three parallel incisions across the end face, and the two hoops as rings.
    for (var _i = 0; _i < 3; _i++) {
        var _x = -0.16 + _i * 0.115;
        var _dy = sqrt(max(0.0, 1 - (_x + 0.045) * (_x + 0.045) / (0.255 * 0.255))) * 0.255;
        brs_append(_o, brs_incise([[_x, 0.05 - _dy], [_x, 0.05 + _dy]], false, 0.014));
    }
    brs_append(_o, brs_as_fitting(brs_ridge(brs_ellipse_pts(-0.045, 0.05, 0.225, 0.252, 20),
                                            true, 0.026)));
    brs_append(_o, brs_as_fitting(brs_ridge(brs_ellipse_pts(0.075, 0.03, 0.230, 0.258, 20),
                                            true, 0.022)));
    // The tap, low and forward, which is the one detail that says ALE rather than WINE.
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.085, 0.20, -0.020, 0.26, 0.014, 2), 0.016, 2, "m3")));
    brs_append(_o, brs_as_fitting(brs_ridge([[-0.052, 0.26], [-0.052, 0.33]], false, 0.020)));
    return _o;
}

/// A tall bottle with a wax-dipped neck. Narrow silhouette, and the only ware whose brightest
/// value is on its shoulder rather than its face.
function brs_w_spirit_bottle() {
    var _hw = brs_profile_curve(0.150, 17, 0.80, 0.80, 0.0, 0.04);
    var _o = brs_ware_shadow(0, 0.15);
    brs_append(_o, brs_body(0, -0.40, BRS_STAND, _hw, 0.032));
    brs_append(_o, brs_sheen(0, -0.36, BRS_STAND - 0.02, _hw, 0.40, 0.032, "m4"));
    // Glass reads off its highlight, so the sheen above is the specular stop and there is a second
    // narrow one on the shoulder. On any other material this would be too much light.
    brs_append(_o, brs_ridge([[-0.055, -0.20], [-0.075, 0.10], [-0.060, 0.30]], false, 0.020));
    // The wax over the cork: a dipped cap with a ragged lower edge.
    var _cap = [];
    for (var _i = 0; _i <= 10; _i++) {
        var _t = _i / 10;
        array_push(_cap, [lerp(-0.062, 0.062, _t), -0.28 + ((_i % 2 == 0) ? 0.018 : -0.006)]);
    }
    array_push(_cap, [0.062, -0.44]);
    array_push(_cap, [-0.062, -0.44]);
    brs_append(_o, brs_as_fitting(brs_raise(_cap, 0.026, 3, "m2")));
    // The punt: a sunk disc in the base, seen as a shallow ellipse.
    brs_append(_o, brs_sink(brs_ellipse_pts(0, BRS_STAND - 0.015, 0.105, 0.030, 14), 0.018, 2, "m0"));
    return _o;
}

/// A skin: a soft irregular bladder with a strap and a horn stopper. No straight edge, and unlike
/// the fleece its lobes are large and few.
function brs_w_water_skin() {
    var _o = brs_ware_shadow(0.01, 0.24);
    var _pts = array_create(20);
    for (var _i = 0; _i < 20; _i++) {
        var _a = (_i / 20) * BRS_TAU;
        var _rr = 1.0 + 0.13 * cos(_a * 3 + 0.6) + 0.06 * cos(_a * 2 - 0.4);
        _pts[_i] = [cos(_a) * 0.245 * _rr, 0.16 + sin(_a) * 0.255 * _rr];
    }
    brs_append(_o, brs_raise(_pts, 0.052, 3, "m2"));
    brs_append(_o, brs_sheen(-0.02, -0.10, 0.36, brs_profile_curve(0.150, 9, 0.55, 0.45, 0.10, 0.10),
                             1.0, 0.045, "m3"));
    // The neck and the stopper, in the fitting metal.
    brs_append(_o, brs_raise([[-0.055, -0.16], [0.055, -0.16], [0.040, -0.30], [-0.040, -0.30]],
                             0.026, 2, "m1"));
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.052, -0.38, 0.052, -0.28, 0.020, 3), 0.024, 3, "m3")));
    // The strap, running over the shoulder and away - it leaves the silhouette, which is what says
    // "this is carried" rather than "this is stored".
    brs_append(_o, brs_as_fitting(brs_taper_ribbon(
        brs_qbez([-0.20, -0.06], [-0.30, 0.16], [-0.16, BRS_STAND - 0.02], 8), 0.030, 0.018, "m2")));
    return _o;
}

/// A round jug with one loop handle. The handle is the whole tell: it is the only ware in the
/// corpus with a hole through its silhouette.
function brs_w_cider_jug() {
    var _hw = brs_profile_curve(0.235, 13, 0.58, 0.66, 0.20, 0.08);
    var _o = brs_ware_shadow(-0.01, 0.23);
    // The handle first, so the body overlaps its inner end and the join is not a butt.
    var _h = brs_arc_pts(0.185, 0.05, 0.135, -BRS_TAU * 0.22, BRS_TAU * 0.22, 10);
    brs_append(_o, brs_ridge(_h, false, 0.046));
    brs_append(_o, brs_body(0, -0.28, BRS_STAND, _hw, 0.046));
    brs_append(_o, brs_sheen(0, -0.28, BRS_STAND, _hw, 0.48, 0.048, "m3"));
    // The rim, flared and rolled.
    brs_append(_o, brs_raise(brs_ellipse_pts(0, -0.28, 0.105, 0.034, 14), 0.024, 2, "m3"));
    // The glaze line: where the dip stopped, two thirds up. A flat wear band, not a groove.
    array_push(_o, brs_ring_fill(brs_profile_pts(0, 0.05, BRS_STAND - 0.01,
        brs_profile_curve(0.222, 8, 0.30, 0.35, 0.0, 0.10)), "wear", undefined, undefined));
    brs_append(_o, brs_as_fitting(brs_ridge([[-0.075, -0.245], [0.075, -0.245]], false, 0.022)));
    return _o;
}

/// A pointed amphora resting in a timber stand. Its base is a POINT, so it cannot stand alone -
/// which is why the stand is part of the good and not scenery.
function brs_w_mead_amphora() {
    var _o = brs_ware_shadow(0, 0.22);
    // The stand: two crossed timbers.
    brs_append(_o, brs_as_fitting(brs_raise(
        [[-0.26, 0.28], [-0.14, 0.28], [-0.02, BRS_STAND], [-0.16, BRS_STAND]], 0.022, 2, "m2")));
    brs_append(_o, brs_as_fitting(brs_raise(
        [[0.14, 0.28], [0.26, 0.28], [0.16, BRS_STAND], [0.02, BRS_STAND]], 0.022, 2, "m2")));
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.24, 0.26, 0.24, 0.31, 0.018, 2), 0.020, 2, "m3")));
    var _hw = brs_profile_curve(0.215, 16, 0.92, 0.36, 0.14, 0.30);
    brs_append(_o, brs_body(0, -0.36, 0.36, _hw, 0.044));
    brs_append(_o, brs_sheen(0, -0.34, 0.32, _hw, 0.46, 0.042, "m3"));
    // Two ear handles, high on the shoulder.
    for (var _k = -1; _k <= 1; _k += 2) {
        brs_append(_o, brs_ridge(brs_arc_pts(_k * 0.165, -0.20, 0.085,
            (_k > 0) ? -BRS_TAU * 0.20 : BRS_TAU * 0.30,
            (_k > 0) ? BRS_TAU * 0.20 : BRS_TAU * 0.70, 8), false, 0.032));
    }
    brs_append(_o, brs_raise(brs_ellipse_pts(0, -0.36, 0.070, 0.024, 12), 0.018, 2, "m3"));
    brs_append(_o, brs_stencil(0, -0.06, 0.075, 2));
    return _o;
}

/// ============================================================================================
/// TRADE FIVE - SPICE & APOTHECARY
/// ============================================================================================

/// A lidded jar with cloth tied over the mouth. Squat, shouldered, and the cloth is the tell.
function brs_w_spice_jar() {
    var _hw = brs_profile_curve(0.225, 13, 0.44, 0.58, 0.10, 0.14);
    var _o = brs_ware_shadow(0, 0.22);
    brs_append(_o, brs_body(0, -0.22, BRS_STAND, _hw, 0.044));
    brs_append(_o, brs_sheen(0, -0.22, BRS_STAND, _hw, 0.46, 0.044, "m3"));
    // The cloth cap: a domed lobed outline, in the fitting linen, tied below the rim.
    var _cap = array_create(14);
    for (var _i = 0; _i < 14; _i++) {
        var _a = (_i / 14) * BRS_TAU;
        var _rr = 1.0 + 0.10 * cos(_a * 7);
        _cap[_i] = [cos(_a) * 0.150 * _rr, -0.245 + sin(_a) * 0.085 * _rr];
    }
    brs_append(_o, brs_as_fitting(brs_raise(_cap, 0.034, 3, "m3")));
    brs_append(_o, brs_tie(0, -0.185, 0.115, 0.075));
    // Three shallow flutes down the belly. Flutes, not staves: spacing wider, count lower.
    for (var _i = -1; _i <= 1; _i++) {
        brs_append(_o, brs_incise([[_i * 0.105, -0.06], [_i * 0.115, 0.28]], false, 0.015));
    }
    return _o;
}

/// A small tight sack tied at the corners into ears. Half the grain sack's size and twice its
/// tension - and the ears break the outline, which is the tell.
function brs_w_pepper_sack() {
    var _hw = brs_profile_curve(0.215, 13, 0.40, 0.66, 0.22, 0.06);
    var _o = brs_ware_shadow(0, 0.21);
    brs_append(_o, brs_body(0, -0.12, BRS_STAND, _hw, 0.042));
    brs_append(_o, brs_sheen(0, -0.12, BRS_STAND, _hw, 0.50, 0.040, "m3"));
    // The two ears: the corners of the cloth pulled up past the tie.
    brs_append(_o, brs_raise([[-0.055, -0.14], [-0.135, -0.28], [-0.175, -0.22], [-0.085, -0.10]],
                             0.024, 2, "m3"));
    brs_append(_o, brs_raise([[0.055, -0.14], [0.150, -0.26], [0.185, -0.19], [0.090, -0.10]],
                             0.024, 2, "m1"));
    brs_append(_o, brs_tie(0, -0.115, 0.070, 0.085));
    brs_append(_o, brs_stencil(0.0, 0.16, 0.078, 3));
    return _o;
}

/// A tiny hinged box, open, with the threads inside catching the lamp. The smallest good in the
/// corpus, and it is small ON PURPOSE - the price gauge beside it is doing the talking.
function brs_w_saffron_box() {
    var _o = brs_ware_shadow(0, 0.20);
    // The lid, hinged back and seen from behind.
    brs_append(_o, brs_raise([[-0.185, -0.02], [0.185, -0.02], [0.215, -0.20], [-0.215, -0.20]],
                             0.026, 3, "m1"));
    // The box.
    brs_append(_o, brs_box(-0.195, 0.00, 0.195, BRS_STAND, 0.018, 0.036));
    // The interior: a sunk well, then the threads.
    brs_append(_o, brs_sink(brs_round_rect_pts(-0.160, 0.03, 0.160, 0.14, 0.012, 2), 0.020, 2, "m0"));
    for (var _i = 0; _i < 13; _i++) {
        var _x = -0.140 + _i * 0.0235;
        var _y = 0.055 + ((_i * 7) % 4) * 0.017;
        brs_append(_o, brs_as_fitting(brs_ridge(
            [[_x, _y], [_x + 0.020 - ((_i % 3) * 0.014), _y + 0.030]], false, 0.010)));
    }
    // The clasp and the corner irons - what makes a small box read as a VALUABLE small box.
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.032, 0.15, 0.032, 0.24, 0.012, 2), 0.014, 2, "m3")));
    brs_append(_o, brs_batten(-0.195, 0.34, -0.130, BRS_STAND));
    brs_append(_o, brs_batten(0.130, 0.34, 0.195, BRS_STAND));
    return _o;
}

/// A bundle of dried stalks hanging heads-down from a cord. The only ware that hangs, and the only
/// one whose mass is at the TOP of the box.
function brs_w_herb_bundle() {
    var _o = brs_ware_shadow(0, 0.20);
    // Eleven stalks, fanning from the tie. The fan is what makes this read as a bundle rather than
    // as a broom: the ANGLE spread is the tell, and it is wide.
    //
    // ⚠️ THE STALKS REACH THE COUNTER. The first version hung the bundle in mid-air a third of the
    // box above the counter line, which the corpus assertion caught - a hanging good either brings
    // what it hangs from (see the horseshoes) or it rests its own tips on the wood, and a bundle of
    // drying herbs resting on its heads is the truer picture of the two.
    // ⛔ SEVEN THICK STALKS, EVERY ONE WITH A HEAD - THE FIRST VERSION WAS ELEVEN THIN ONES WITH
    // THREE. It read as a wire whisk, plainly, on the corpus sheet: eleven one-pixel lines (the
    // renderer floors every stroke there) fanning to three small balls is a kitchen tool, not a
    // bunch of drying herbs. What makes a herb read as a herb is FOLIAGE - mass at the loose end -
    // so every stalk now carries a head and a pair of leaves halfway down, and the stalks are wide
    // enough to survive the floor.
    // ⛔ ONE FOLIAGE MASS, NOT SEVEN FLOWER HEADS. Giving every stalk its own lobed head produced a
    // fan of thin stems ending in seven small stars - a whisk, or a firework, and on the corpus
    // sheet it read as both. What a hanging bunch of herbs actually presents to the eye is BARE
    // STALK at the top and a single dense body of leaf below, and a silhouette made of one mass is
    // legible at any size while seven small ones are noise at every size below hero.
    for (var _i = 0; _i < 7; _i++) {
        var _f = -1 + 2 * (_i / 6);
        var _sp = _f * 0.235;
        var _pts = brs_qbez([0, -0.32], [_sp * 0.6, -0.16], [_sp, 0.04], 6);
        brs_append(_o, brs_one(brs_taper_ribbon(_pts, 0.028, 0.016, "m2")));
    }
    // The leaf body: one lobed mass, wide and low, sitting on the counter.
    var _n = 46;
    var _leaf = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _a = (_i / _n) * BRS_TAU;
        var _rr = 1.0 + 0.115 * cos(_a * 9) + 0.075 * cos(_a * 4 + 0.9);
        _leaf[_i] = [cos(_a) * 0.315 * _rr, 0.235 + sin(_a) * 0.185 * _rr];
    }
    brs_append(_o, brs_raise(_leaf, 0.046, 3, "m2"));
    // Leaf veins: five ribs radiating from where the stalks enter the mass. Ridges, not grooves -
    // a leaf's rib stands proud of the blade.
    for (var _i = 0; _i < 5; _i++) {
        var _a = BRS_TAU * (0.30 + _i * 0.10);
        brs_append(_o, brs_ridge([[0, 0.06], [cos(_a) * 0.235, 0.235 + sin(_a) * 0.150]],
                                 false, 0.016));
    }
    // Two lighter leaves overlapping the mass, so it is not one flat blob.
    brs_append(_o, brs_raise(brs_ellipse_pts(-0.135, 0.185, 0.115, 0.062, 14), 0.026, 3, "m3"));
    brs_append(_o, brs_raise(brs_ellipse_pts(0.145, 0.265, 0.105, 0.058, 14), 0.026, 3, "m3"));
    brs_append(_o, brs_as_fitting(brs_ridge(brs_arc_pts(0, -0.37, 0.055, 0, BRS_TAU, 12),
                                            true, 0.020)));
    brs_append(_o, brs_tie(0, -0.29, 0.055, 0.09));
    return _o;
}

/// A narrow-necked flask with a leather sleeve round its foot. Tall, but round-shouldered where
/// the spirit bottle is square - two glass goods, told apart by outline.
function brs_w_oil_flask() {
    var _hw = brs_profile_curve(0.190, 15, 0.86, 0.68, 0.06, 0.16);
    var _o = brs_ware_shadow(0, 0.19);
    brs_append(_o, brs_body(0, -0.36, BRS_STAND, _hw, 0.036));
    brs_append(_o, brs_sheen(0, -0.30, 0.34, _hw, 0.42, 0.034, "m4"));
    // The oil inside: a flat fill to a level line, in the wear role, which is the one place in the
    // corpus where a flat mass is CORRECT - liquid has no surface normal worth lighting.
    array_push(_o, brs_ring_fill(brs_profile_pts(0, 0.02, BRS_STAND - 0.02,
        brs_profile_curve(0.172, 8, 0.55, 0.30, 0.0, 0.18)), "wear", undefined, undefined));
    // The stopper.
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.048, -0.44, 0.048, -0.34, 0.016, 3), 0.022, 3, "m3")));
    // The sleeve: a woven guard round the foot, four courses. Sagged beziers rather than sampled
    // circle arcs, for the reason the ore basket records - an arc's deepest point is a radius below
    // its centre, and the bottom course then puts ink under the counter line.
    for (var _i = 0; _i < 4; _i++) {
        var _y = 0.24 + _i * 0.040;
        brs_append(_o, brs_as_fitting(brs_ridge(
            brs_qbez([-0.175, _y - 0.016], [0, _y + 0.036], [0.175, _y - 0.016], 6), false, 0.020)));
    }
    return _o;
}

/// A stack of pressed cakes, each thinner than the last is wide. Pure horizontal banding - the
/// silhouette is a squat ziggurat and nothing else in the corpus is.
function brs_w_incense_cakes() {
    var _o = brs_ware_shadow(0, 0.29);
    // ⚠️ THE STACK IS ANCHORED BY ITS BOTTOM CAKE'S BOTTOM, NOT ITS CENTRE. An ellipse placed at
    // the counter line hangs half of itself below it - the same half-height mistake as the wrapper
    // below and as the ore basket's arcs, and the third time this session that a shape was anchored
    // where the author was thinking rather than where its ink ends.
    // ⛔ THE GAP BETWEEN CAKES IS DRAWN, NOT IMPLIED. Five ellipses stacked at a pitch close to
    // their own bevel depth merge into one smooth mass - the corpus sheet showed a sandbag, not a
    // stack of pressed cakes. A dark sliver under each cake's leading edge is what says "these are
    // separate objects", and it is the same move a draughtsman makes to part two overlapping forms.
    for (var _i = 0; _i < 5; _i++) {
        var _r = 0.300 - _i * 0.034;
        var _y = BRS_STAND - 0.020 - _r * 0.30 - _i * 0.084;
        array_push(_o, brs_ring_fill(brs_ellipse_pts(_i * 0.010, _y + 0.028, _r * 1.02,
                                                     _r * 0.30, 18), "m0", undefined, undefined));
        var _e = brs_ellipse_pts(_i * 0.010, _y, _r, _r * 0.30, 18);
        brs_append(_o, brs_raise(_e, 0.026, 3, (_i % 2 == 0) ? "m2" : "m3"));
    }
    // The pressed device on the top cake, stamped INTO it, and the leaf wrapper under the stack.
    brs_append(_o, brs_sink(brs_star_pts(0.040, BRS_STAND - 0.376, 0.078, 6, 0.3), 0.018, 2, "m1"));
    // The wrapper under the stack. Its CENTRE sits a full half-height above the counter line: an
    // ellipse anchored at the line puts half of itself below it, which the corpus assertion caught
    // at +0.058 - the same arithmetic mistake as an arc's radius, in a different shape.
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_ellipse_pts(0, BRS_STAND - 0.078, 0.325, 0.070, 18), 0.024, 2, "m2")));
    return _o;
}

/// ============================================================================================
/// TRADE SIX - TIMBER & STONE
/// ============================================================================================

/// Sawn boards stacked with their ends toward the viewer, strapped. Horizontal, low and long.
function brs_w_plank_stack() {
    var _o = brs_ware_shadow(0, 0.34);
    for (var _i = 0; _i < 5; _i++) {
        var _y = BRS_STAND - 0.040 - _i * 0.055;
        var _off = ((_i % 2 == 0) ? 0.0 : 0.022) + _i * 0.008;
        brs_append(_o, brs_raise([[-0.36 + _off, _y - 0.048], [0.34 + _off, _y - 0.056],
                                  [0.34 + _off, _y], [-0.36 + _off, _y]], 0.022, 2,
                                 (_i % 2 == 0) ? "m2" : "m3"));
        // The end grain: two short arcs on the left end of every board, which is what makes this a
        // stack of BOARDS and not a stack of bricks.
        brs_append(_o, brs_incise(brs_arc_pts(-0.33 + _off, _y - 0.024, 0.020,
            -BRS_TAU * 0.25, BRS_TAU * 0.25, 5), false, 0.011));
    }
    brs_append(_o, brs_batten(-0.13, 0.06, -0.08, BRS_STAND));
    brs_append(_o, brs_batten(0.14, 0.05, 0.19, BRS_STAND - 0.01));
    return _o;
}

/// Round logs tied in a bundle, end grain forward. Circles where the planks were lines.
function brs_w_log_bundle() {
    var _o = brs_ware_shadow(0, 0.32);
    var _at = [[-0.20, 0.30, 0.115], [0.03, 0.31, 0.105], [0.24, 0.29, 0.098],
               [-0.09, 0.11, 0.120], [0.14, 0.10, 0.108], [0.02, -0.08, 0.100]];
    for (var _i = 0; _i < 6; _i++) {
        var _a = _at[_i];
        brs_append(_o, brs_raise(brs_ellipse_pts(_a[0], _a[1], _a[2], _a[2], 14), 0.030, 3, "m2"));
        // Growth rings: two, not five. Five at this size is a smudge.
        brs_append(_o, brs_incise(brs_arc_pts(_a[0] - _a[2] * 0.10, _a[1] - _a[2] * 0.08,
            _a[2] * 0.55, 0, BRS_TAU, 12), true, 0.011));
        brs_append(_o, brs_incise(brs_arc_pts(_a[0] - _a[2] * 0.14, _a[1] - _a[2] * 0.12,
            _a[2] * 0.24, 0, BRS_TAU, 10), true, 0.011));
        // The split from the heart, on half of them.
        if (_i % 2 == 0) {
            brs_append(_o, brs_incise([[_a[0] - _a[2] * 0.10, _a[1] - _a[2] * 0.08],
                                       [_a[0] + _a[2] * 0.72, _a[1] + _a[2] * 0.50]], false, 0.013));
        }
    }
    brs_append(_o, brs_as_fitting(brs_ridge(
        [[-0.33, 0.02], [-0.05, -0.13], [0.31, 0.05], [0.30, 0.26], [-0.02, 0.40], [-0.32, 0.24]],
        true, 0.024)));
    return _o;
}

/// An open sack with charcoal heaped above the mouth, and soot on the cloth below it.
function brs_w_charcoal_sack() {
    var _hw = brs_profile_curve(0.275, 13, 0.34, 0.72, 0.06, 0.05);
    var _o = brs_ware_shadow(0, 0.28);
    brs_append(_o, brs_body(0, -0.16, BRS_STAND, _hw, 0.048));
    brs_append(_o, brs_sheen(0, -0.16, BRS_STAND, _hw, 0.50, 0.048, "m3"));
    // The rolled-down mouth.
    brs_append(_o, brs_raise(brs_ellipse_pts(0, -0.17, 0.255, 0.062, 16), 0.030, 2, "m3"));
    // Soot: a flat wear band down the front of the sack, wide at the top and narrowing. This is
    // the only good in the corpus that is DIRTY, and the wear role exists for it.
    array_push(_o, brs_ring_fill([[-0.14, -0.14], [0.16, -0.14], [0.10, 0.34], [-0.08, 0.34]],
                                 "wear", undefined, undefined));
    // The charcoal itself: seven angular black lumps, in the fitting stone, over the rim.
    var _l = [[-0.18, -0.22, 0.085], [-0.02, -0.29, 0.098], [0.15, -0.23, 0.082],
              [0.06, -0.17, 0.070], [-0.10, -0.16, 0.066], [0.22, -0.15, 0.058],
              [-0.24, -0.14, 0.055]];
    for (var _i = 0; _i < 7; _i++) {
        brs_append(_o, brs_as_fitting(brs_raise(
            brs_star_pts(_l[_i][0], _l[_i][1], _l[_i][2], 5, 0.3 + _i), _l[_i][2] * 0.40, 2,
            (_i % 2 == 0) ? "m0" : "m1")));
    }
    return _o;
}

/// A squared ashlar block with a tooled face and a lewis hole. Hard, flat, heavy - the only ware
/// with a perfectly straight top edge.
function brs_w_cut_stone() {
    var _o = brs_ware_shadow(0, 0.33);
    var _top = [[-0.28, 0.02], [0.16, -0.06], [0.34, 0.04], [-0.10, 0.12]];
    var _front = [[-0.28, 0.02], [-0.10, 0.12], [-0.10, BRS_STAND], [-0.28, 0.32]];
    var _side = [[-0.10, 0.12], [0.34, 0.04], [0.34, 0.34], [-0.10, BRS_STAND]];
    brs_append(_o, brs_raise(_side, 0.028, 2, "m1"));
    brs_append(_o, brs_raise(_front, 0.028, 2, "m2"));
    brs_append(_o, brs_raise(_top, 0.026, 2, "m3"));
    // The tooling: eleven chisel runs across the side face, evenly spaced. This is the one place a
    // fine repeated stroke IS the material, and it survives because the spacing is the signal.
    for (var _i = 0; _i < 11; _i++) {
        var _t = (_i + 0.5) / 11;
        brs_append(_o, brs_incise([[lerp(-0.08, 0.32, _t), lerp(0.135, 0.055, _t)],
                                   [lerp(-0.08, 0.32, _t), lerp(0.405, 0.325, _t)]], false, 0.011));
    }
    // The lewis hole, cut into the top so a crane can lift it - and the iron lewis sitting in it,
    // which is this good's only fitting and the reason a mason pays for a squared block rather than
    // a rock. It is also what tells the stone apart from the salt in the FITTING comparison: one
    // has its iron up top, the other has its wedge leaning against its right flank.
    brs_append(_o, brs_sink([[0.02, 0.015], [0.10, 0.000], [0.13, 0.020], [0.05, 0.035]],
                            0.014, 2, "m0"));
    brs_append(_o, brs_as_fitting(brs_raise(
        [[0.045, -0.115], [0.105, -0.125], [0.115, 0.020], [0.055, 0.030]], 0.018, 3, "m2")));
    brs_append(_o, brs_as_fitting(brs_ridge(brs_arc_pts(0.080, -0.150, 0.052, 0, BRS_TAU, 12),
                                            true, 0.020)));
    brs_append(_o, brs_stencil(-0.19, 0.24, 0.062, 2));
    return _o;
}

/// Thin tiles leaning in a stack. The silhouette is a parallelogram with a combed top edge - the
/// count is visible from across the room, which is the point.
function brs_w_slate_tiles() {
    var _o = brs_ware_shadow(0, 0.33);
    for (var _i = 0; _i < 9; _i++) {
        var _x = -0.30 + _i * 0.070;
        var _lean = 0.11;
        brs_append(_o, brs_raise([[_x, BRS_STAND], [_x + _lean, -0.14],
                                  [_x + _lean + 0.052, -0.15], [_x + 0.052, BRS_STAND]],
                                 0.018, 2, (_i % 2 == 0) ? "m2" : "m1"));
    }
    // The prop that stops them sliding, and one broken tile leaning against it.
    brs_append(_o, brs_as_fitting(brs_raise(
        [[0.28, BRS_STAND], [0.34, BRS_STAND], [0.30, -0.02], [0.25, -0.02]], 0.020, 2, "m2")));
    brs_append(_o, brs_raise([[-0.36, BRS_STAND], [-0.30, 0.16], [-0.24, 0.20], [-0.30, BRS_STAND]],
                             0.018, 2, "m3"));
    return _o;
}

/// A bucket with a bail handle and lime slaked to a crust round the rim.
function brs_w_lime_bucket() {
    var _o = brs_ware_shadow(0, 0.24);
    // The bail, behind the bucket.
    brs_append(_o, brs_as_fitting(brs_ridge(brs_arc_pts(0, -0.02, 0.235, BRS_TAU * 0.54,
                                                        BRS_TAU * 0.96, 12), false, 0.020)));
    var _bk = [[-0.245, -0.04], [0.245, -0.04], [0.185, BRS_STAND], [-0.185, BRS_STAND]];
    brs_append(_o, brs_raise(_bk, 0.042, 3, "m2"));
    brs_append(_o, brs_sheen(0, -0.02, BRS_STAND - 0.01,
                             brs_profile_curve(0.185, 8, 0.10, 0.5, 0.0, 0.0), 0.52, 0.045, "m3"));
    // Two bands and the stave lines between them.
    brs_append(_o, brs_hoop(0, 0.06, 0.228, 0.019));
    brs_append(_o, brs_hoop(0, 0.34, 0.192, 0.019));
    brs_append(_o, brs_staves(0, 0.10, 0.32, 0.205, 5));
    // The lime: a pale crust over the rim, lobed, in the timber's own specular stop.
    var _cr = array_create(16);
    for (var _i = 0; _i < 16; _i++) {
        var _a = (_i / 16) * BRS_TAU;
        var _rr = 1.0 + 0.14 * cos(_a * 8 + 0.5);
        _cr[_i] = [cos(_a) * 0.225 * _rr, -0.055 + sin(_a) * 0.055 * _rr];
    }
    brs_append(_o, brs_raise(_cr, 0.030, 3, "m4"));
    return _o;
}

/// ============================================================================================
/// TRADE SEVEN - HIDE & CRAFT
/// ============================================================================================

/// A hide rolled and tied, standing on end. The spiral at the top is the tell against the linen
/// bolt, which shows its spiral at the side.
function brs_w_hide_roll() {
    var _o = brs_ware_shadow(0, 0.24);
    var _hw = brs_profile_curve(0.225, 11, 0.14, 0.5, 0.0, 0.0);
    brs_append(_o, brs_body(0, -0.30, BRS_STAND, _hw, 0.044));
    brs_append(_o, brs_sheen(0, -0.30, BRS_STAND, _hw, 0.46, 0.046, "m3"));
    // The rolled top: three tightening ellipses seen from slightly above.
    for (var _i = 0; _i < 3; _i++) {
        brs_append(_o, brs_raise(brs_ellipse_pts(_i * 0.012, -0.30 + _i * 0.008,
            0.215 - _i * 0.058, (0.215 - _i * 0.058) * 0.30, 16), 0.024, 2,
            (_i % 2 == 0) ? "m1" : "m3"));
    }
    // The loose flap where the hide was not rolled all the way in - the one asymmetry.
    brs_append(_o, brs_raise([[0.20, -0.10], [0.34, 0.02], [0.31, 0.20], [0.19, 0.14]],
                             0.028, 2, "m1"));
    brs_append(_o, brs_tie(0, -0.02, 0.235, 0.10));
    brs_append(_o, brs_tie(0, 0.28, 0.230, 0.09));
    return _o;
}

/// Folded sheets in a stack, edges toward the viewer. Every fold is a lit half-round, which is
/// what leather does and paper does not.
function brs_w_tanned_stack() {
    var _o = brs_ware_shadow(0, 0.37);
    // Nine sheets, not six, and each a little deeper - measured at 0.15 of its plate against a
    // corpus mean of 0.24. A stack of leather is a stack; six thin slices read as a sandwich.
    for (var _i = 0; _i < 9; _i++) {
        var _y = BRS_STAND - 0.020 - _i * 0.062;
        var _w = 0.365 - _i * 0.011;
        brs_append(_o, brs_raise(brs_round_rect_pts(-_w, _y - 0.056, _w, _y, 0.023, 3),
                                 0.022, 3, (_i % 2 == 0) ? "m2" : "m3"));
        // The fold: a half-round bump on alternating ends, so the stack reads as folded sheets
        // rather than as slices of cake.
        var _fx = (_i % 2 == 0) ? -_w : _w;
        brs_append(_o, brs_raise(brs_ellipse_pts(_fx, _y - 0.028, 0.022, 0.028, 10),
                                 0.014, 2, "m3"));
    }
    brs_append(_o, brs_batten(-0.07, -0.15, -0.01, BRS_STAND));
    brs_append(_o, brs_stencil(0.21, 0.10, 0.062, 4));
    return _o;
}

/// An open box with candles standing in it, of three different heights. A comb silhouette, like
/// the thread rack - and told apart from it by the box beneath and the taper of each candle.
function brs_w_candle_box() {
    var _o = brs_ware_shadow(0, 0.30);
    for (var _i = 0; _i < 9; _i++) {
        var _x = -0.245 + _i * 0.061;
        var _h = 0.40 + ((_i * 7) % 3) * 0.055;
        var _hw = brs_profile_curve(0.024, 7, 0.30, 0.9, 0.0, 0.0);
        brs_append(_o, brs_as_fitting(brs_body(_x, BRS_STAND - _h, 0.30, _hw, 0.012)));
        // The wick: one dark stroke, and a bead of spent wax on three of them.
        brs_append(_o, brs_incise([[_x, BRS_STAND - _h], [_x + 0.004, BRS_STAND - _h - 0.030]],
                                  false, 0.010));
        if (_i % 3 == 0) {
            brs_append(_o, brs_as_fitting(brs_boss(_x + 0.016, BRS_STAND - _h + 0.040, 0.017, 8)));
        }
    }
    var _bx = [[-0.30, 0.20], [0.30, 0.20], [0.27, BRS_STAND], [-0.27, BRS_STAND]];
    brs_append(_o, brs_raise(_bx, 0.036, 3, "m2"));
    brs_append(_o, brs_sink(brs_round_rect_pts(-0.265, 0.215, 0.265, 0.265, 0.014, 2),
                            0.018, 2, "m0"));
    brs_append(_o, brs_batten(-0.30, 0.30, 0.30, 0.345));
    return _o;
}

/// A wide low tub with a lid slightly ajar and tallow standing proud of the gap.
function brs_w_tallow_tub() {
    var _o = brs_ware_shadow(0, 0.32);
    var _tb = [[-0.32, 0.06], [0.32, 0.06], [0.27, BRS_STAND], [-0.27, BRS_STAND]];
    brs_append(_o, brs_raise(_tb, 0.046, 3, "m2"));
    brs_append(_o, brs_sheen(0, 0.08, BRS_STAND - 0.01,
                             brs_profile_curve(0.270, 8, 0.10, 0.5, 0.0, 0.0), 0.50, 0.052, "m3"));
    brs_append(_o, brs_staves(0, 0.10, 0.38, 0.290, 7));
    brs_append(_o, brs_hoop(0, 0.13, 0.305, 0.021));
    brs_append(_o, brs_hoop(0, 0.36, 0.276, 0.021));
    // The lid, pushed back and up on the left, so a wedge of the inside shows.
    brs_append(_o, brs_as_fitting(brs_raise(
        [[-0.30, -0.02], [0.30, 0.02], [0.32, 0.055], [-0.28, 0.030]], 0.028, 3, "m3")));
    // The tallow in the gap: pale, flat, filling the wedge the lid leaves.
    array_push(_o, brs_ring_fill([[-0.26, 0.038], [0.10, 0.050], [0.10, 0.070], [-0.26, 0.062]],
                                 "m4", undefined, undefined));
    brs_append(_o, brs_as_fitting(brs_boss(-0.02, 0.010, 0.032, 10)));
    return _o;
}

/// A chest with a domed lid, corner irons and a hasp. Four fitting pieces, which is more metal
/// than any other ware carries - a tool chest should look like it costs something.
function brs_w_tool_chest() {
    var _o = brs_ware_shadow(0, 0.34);
    brs_append(_o, brs_box(-0.34, 0.02, 0.34, BRS_STAND, 0.022, 0.048));
    // The domed lid, as a separate mass with its own bevel, stepping the silhouette.
    var _lid = [];
    brs_append(_lid, brs_qbez([-0.35, 0.06], [0.0, -0.20], [0.35, 0.06], 10));
    array_push(_lid, [0.35, 0.12]);
    array_push(_lid, [-0.35, 0.12]);
    brs_append(_o, brs_raise(_lid, 0.040, 3, "m3"));
    // Three bands over the lid and down the body.
    for (var _k = -1; _k <= 1; _k++) {
        var _x = _k * 0.215;
        brs_append(_o, brs_as_fitting(brs_ridge(
            [[_x, -0.115 + abs(_k) * 0.115], [_x, BRS_STAND - 0.01]], false, 0.032)));
    }
    // Corner irons, and the hasp with its staple.
    brs_append(_o, brs_batten(-0.34, 0.36, -0.25, BRS_STAND));
    brs_append(_o, brs_batten(0.25, 0.36, 0.34, BRS_STAND));
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.055, 0.09, 0.055, 0.23, 0.018, 3), 0.020, 3, "m3")));
    brs_append(_o, brs_as_fitting(brs_pit(0, 0.185, 0.026, 10)));
    brs_append(_o, brs_stencil(0.145, 0.28, 0.070, 3));
    return _o;
}

/// A hinged pair of tablets STOOD OPEN like a book on its edge, with a stylus laid across the
/// lower leaf. The only good in the corpus that is WRITING rather than a commodity.
///
/// ⛔ THE OPEN ANGLE IS WHY THIS IS A DIFFERENT OBJECT FROM THE LACQUER BOX. Laid flat, the two
/// were a wide low rounded rectangle each and the corpus distinctness check measured them at 0.11 -
/// two goods on the same shelf that a player would read as the same thing. Nothing about the
/// materials or the surface detail would have fixed that, because a difference drawn INSIDE a
/// filled mass is not a difference in the mass: the fix has to be the SILHOUETTE, and standing one
/// leaf up turns a rectangle into an L.
function brs_w_wax_tablets() {
    var _o = brs_ware_shadow(0.02, 0.28);
    // The standing leaf: a tall parallelogram leaning back, hinged at the bottom right.
    var _up = [[-0.30, -0.34], [0.02, -0.40], [0.11, BRS_STAND - 0.055], [-0.21, BRS_STAND - 0.02]];
    brs_append(_o, brs_raise(_up, 0.034, 3, "m2"));
    brs_append(_o, brs_as_fitting(brs_sink(
        [[-0.265, -0.295], [-0.005, -0.345], [0.070, BRS_STAND - 0.105], [-0.185, BRS_STAND - 0.075]],
        0.024, 2, "m2")));
    // Six ruled lines of writing on the standing leaf, scratched through the wax to the dark board
    // beneath - so they take the ink role and are FLAT, like a stencil on a crate.
    for (var _i = 0; _i < 6; _i++) {
        var _t = (_i + 0.6) / 7;
        var _y0 = lerp(-0.285, BRS_STAND - 0.115, _t);
        var _y1 = lerp(-0.335, BRS_STAND - 0.090, _t);
        var _w = (_i == 5) ? 0.135 : 0.230;
        array_push(_o, brs_poly([[-0.240, _y0], [-0.240 + _w, _y1 - (0.230 - _w) * 0.14]],
                                false, 0.010, "mark"));
    }
    // The leaf lying flat, foreshortened, hinged to the first at the near corner.
    var _flat = [[-0.20, BRS_STAND - 0.075], [0.13, BRS_STAND - 0.115],
                 [0.36, BRS_STAND - 0.025], [0.03, BRS_STAND + 0.015]];
    brs_append(_o, brs_raise(_flat, 0.028, 3, "m3"));
    brs_append(_o, brs_as_fitting(brs_sink(
        [[-0.155, BRS_STAND - 0.070], [0.120, BRS_STAND - 0.103],
         [0.310, BRS_STAND - 0.030], [0.035, BRS_STAND + 0.003]], 0.020, 2, "m2")));
    // The hinge, and the stylus lying across the flat leaf.
    brs_append(_o, brs_as_fitting(brs_ridge(
        [[-0.21, BRS_STAND - 0.020], [-0.16, BRS_STAND - 0.075]], false, 0.026)));
    brs_append(_o, brs_as_fitting(brs_one(brs_taper_ribbon(
        [[-0.11, BRS_STAND - 0.010], [0.30, BRS_STAND - 0.062]], 0.011, 0.022, "m3"))));
    return _o;
}

/// ============================================================================================
/// TRADE EIGHT - LUXURY
/// ============================================================================================

/// A small domed casket with a clasp, open, with pearls in it. Everything about it is SMALL and
/// finished - the luxury goods are told from the bulk goods by how much of the box they fill.
function brs_w_pearl_casket() {
    var _o = brs_ware_shadow(0, 0.23);
    // The lid, hinged open and back.
    var _lid = [];
    brs_append(_lid, brs_qbez([-0.215, -0.02], [0.0, -0.30], [0.215, -0.02], 9));
    array_push(_lid, [0.200, 0.04]);
    array_push(_lid, [-0.200, 0.04]);
    brs_append(_o, brs_raise(_lid, 0.032, 3, "m1"));
    // The lining, in the fitting metal, showing under the open lid.
    brs_append(_o, brs_as_fitting(brs_sink(
        brs_round_rect_pts(-0.185, 0.02, 0.185, 0.16, 0.020, 3), 0.024, 2, "m1")));
    // The pearls: nine, in the pale specular stop, each a boss. Nine is the count that reads as
    // MANY at shelf size; five reads as a handful and twenty as gravel.
    var _p = [[-0.13, 0.10], [-0.05, 0.07], [0.04, 0.09], [0.12, 0.06], [-0.10, 0.14],
              [-0.01, 0.14], [0.09, 0.14], [0.15, 0.12], [-0.16, 0.06]];
    for (var _i = 0; _i < 9; _i++) {
        brs_append(_o, brs_map_roles(brs_boss(_p[_i][0], _p[_i][1], 0.040, 10),
                                     { m0: "m3", m1: "m3", m2: "m4", m3: "m4", m4: "m4" }));
    }
    brs_append(_o, brs_box(-0.215, 0.14, 0.215, BRS_STAND, 0.020, 0.038));
    brs_append(_o, brs_batten(-0.215, 0.16, -0.155, 0.36));
    brs_append(_o, brs_batten(0.155, 0.16, 0.215, 0.36));
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.040, 0.20, 0.040, 0.30, 0.014, 2), 0.016, 2, "m4")));
    return _o;
}

/// A tray heaped with beads, and two strings hanging over its front edge. The ware whose value the
/// player can literally count.
///
/// ⛔ THE TALL STAND HAD TO GO. A vertical post with three sagging strings hanging off a crossbar
/// read, unmistakably, as a small TREE on the corpus sheet - the post was a trunk, the strings were
/// branches and the beads were fruit. A silhouette does not care what the author meant. A low wide
/// tray full of glinting beads reads as beads and nothing else, and it puts far more of them on
/// screen, which is the whole point of the good.
function brs_w_glass_beads() {
    var _o = brs_ware_shadow(0, 0.34);
    // The tray, in the fitting timber.
    brs_append(_o, brs_as_fitting(brs_raise(
        [[-0.35, 0.10], [0.35, 0.10], [0.30, BRS_STAND], [-0.30, BRS_STAND]], 0.040, 3, "m2")));
    brs_append(_o, brs_as_fitting(brs_sink(
        brs_round_rect_pts(-0.315, 0.135, 0.315, 0.335, 0.030, 3), 0.026, 2, "m1")));
    // The heap: twenty-six beads in the tray, in three sizes, each with its own glint. The COUNT is
    // the value on display, so it is high and the beads overlap the way loose beads do.
    var _bx = [-0.26, -0.18, -0.10, -0.02, 0.06, 0.14, 0.22, 0.27,
               -0.23, -0.14, -0.06, 0.02, 0.10, 0.18, 0.25,
               -0.20, -0.11, -0.03, 0.05, 0.13, 0.21,
               -0.16, -0.07, 0.01, 0.09, 0.17];
    var _by = [0.30, 0.31, 0.30, 0.31, 0.30, 0.31, 0.30, 0.29,
               0.25, 0.26, 0.25, 0.26, 0.25, 0.26, 0.25,
               0.21, 0.20, 0.21, 0.20, 0.21, 0.20,
               0.165, 0.155, 0.165, 0.155, 0.165];
    for (var _i = 0; _i < 26; _i++) {
        var _r = 0.036 + ((_i * 7) % 3) * 0.008;
        brs_append(_o, brs_raise(brs_ellipse_pts(_bx[_i], _by[_i], _r, _r, 10), _r * 0.55, 2,
                                 (_i % 3 == 0) ? "m1" : "m2"));
        // The glint: one bright dot up and left of centre on each bead. It is the ONLY reason
        // glass reads as glass at this size.
        array_push(_o, brs_dot(_bx[_i] - _r * 0.30, _by[_i] - _r * 0.32, _r * 0.28, "m4"));
    }
    // Two strings hanging over the front rim, so the good says "strings" as well as "beads".
    var _cfg = [[-0.20, 7, 0.040], [0.16, 6, 0.046]];
    for (var _s = 0; _s < 2; _s++) {
        var _sx = _cfg[_s][0], _n = _cfg[_s][1], _r2 = _cfg[_s][2];
        var _path = brs_qbez([_sx - 0.075, 0.09], [_sx + 0.02, -0.10 - _s * 0.06],
                             [_sx + 0.115, 0.09], _n - 1);
        array_push(_o, brs_poly(_path, false, 0.010, "mark"));
        for (var _i = 0; _i < _n; _i++) {
            brs_append(_o, brs_raise(brs_ellipse_pts(_path[_i][0], _path[_i][1], _r2, _r2, 10),
                                     _r2 * 0.55, 2, "m2"));
            array_push(_o, brs_dot(_path[_i][0] - _r2 * 0.30, _path[_i][1] - _r2 * 0.32,
                                   _r2 * 0.28, "m4"));
        }
    }
    return _o;
}

/// A dye pot with the indigo crusted over its rim and run down the outside. The only ware whose
/// wear role is its SELLING POINT rather than its damage.
function brs_w_indigo_pot() {
    var _hw = brs_profile_curve(0.245, 13, 0.36, 0.60, 0.04, 0.16);
    var _o = brs_ware_shadow(0, 0.24);
    brs_append(_o, brs_body(0, -0.24, BRS_STAND, _hw, 0.046));
    brs_append(_o, brs_sheen(0, -0.24, BRS_STAND, _hw, 0.46, 0.048, "m3"));
    brs_append(_o, brs_raise(brs_ellipse_pts(0, -0.245, 0.230, 0.062, 16), 0.028, 2, "m3"));
    // The dye: the surface inside the mouth, then the crust over the rim, then three runs down the
    // side of different lengths. Length, not width, carries the difference.
    brs_append(_o, brs_as_fitting(brs_sink(brs_ellipse_pts(0, -0.240, 0.190, 0.050, 16),
                                           0.024, 2, "m0")));
    var _cr = array_create(18);
    for (var _i = 0; _i < 18; _i++) {
        var _a = (_i / 18) * BRS_TAU;
        var _rr = 1.0 + 0.16 * cos(_a * 5 + 0.9);
        _cr[_i] = [cos(_a) * 0.235 * _rr, -0.245 + sin(_a) * 0.062 * _rr];
    }
    brs_append(_o, brs_as_fitting(brs_raise(_cr, 0.022, 2, "m2")));
    var _run = [[-0.185, 0.16], [-0.060, 0.30], [0.135, 0.10], [0.215, 0.22]];
    for (var _i = 0; _i < 4; _i++) {
        brs_append(_o, brs_as_fitting(brs_taper_ribbon(
            brs_qbez([_run[_i][0], -0.20], [_run[_i][0] * 1.05, _run[_i][1] * 0.5],
                     [_run[_i][0] * 0.92, _run[_i][1]], 6), 0.028, 0.008, "m1")));
    }
    return _o;
}

/// A flat lacquer box with an inlaid panel. Nothing protrudes; the whole good is one plane and a
/// pattern, which is exactly why it needs the deepest relief on its border in the corpus.
function brs_w_lacquer_box() {
    var _o = brs_ware_shadow(0, 0.33);
    brs_append(_o, brs_box(-0.33, 0.10, 0.33, BRS_STAND, 0.026, 0.055));
    // The inlaid panel: a sunk field with a raised border of the fitting metal.
    brs_append(_o, brs_sink(brs_round_rect_pts(-0.255, 0.145, 0.255, 0.355, 0.018, 3),
                            0.026, 2, "m0"));
    brs_append(_o, brs_as_fitting(brs_ridge(
        brs_round_rect_pts(-0.255, 0.145, 0.255, 0.355, 0.018, 3), true, 0.020)));
    // The inlay itself: a four-fold knot, built from two overlapping diamonds and four studs.
    brs_append(_o, brs_as_fitting(brs_ridge(brs_star_pts(0, 0.25, 0.115, 4, 0), true, 0.018)));
    brs_append(_o, brs_as_fitting(brs_ridge(brs_star_pts(0, 0.25, 0.088, 4, BRS_TAU * 0.125),
                                            true, 0.016)));
    for (var _i = 0; _i < 4; _i++) {
        var _a = BRS_TAU * (_i / 4);
        brs_append(_o, brs_as_fitting(brs_boss(cos(_a) * 0.185, 0.25 + sin(_a) * 0.078, 0.024, 8)));
    }
    // The lid line, one incision all the way round the box below the panel.
    brs_append(_o, brs_incise([[-0.325, 0.385], [0.325, 0.385]], false, 0.013));
    return _o;
}

/// A small painted panel on a folding stand. Upright, framed, and the only ware that FACES the
/// viewer squarely - which is what an icon is for.
function brs_w_gilt_icon() {
    var _o = brs_ware_shadow(0.01, 0.20);
    // The stand legs, behind.
    brs_append(_o, brs_raise([[-0.06, 0.10], [0.02, 0.10], [0.20, BRS_STAND], [0.10, BRS_STAND]],
                             0.020, 2, "m1"));
    brs_append(_o, brs_raise([[0.02, 0.10], [0.10, 0.10], [-0.06, BRS_STAND], [-0.16, BRS_STAND]],
                             0.020, 2, "m1"));
    // The frame, in the fitting metal, and the panel sunk inside it.
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.235, -0.40, 0.235, 0.20, 0.024, 3), 0.048, 3, "m3")));
    brs_append(_o, brs_sink(brs_round_rect_pts(-0.180, -0.345, 0.180, 0.145, 0.014, 2),
                            0.026, 2, "m1"));
    // The figure: a haloed bust, drawn as three masses. It must read as a FIGURE at shelf size, so
    // it is a disc, a dome and two shoulders and nothing finer.
    brs_append(_o, brs_as_fitting(brs_ridge(brs_arc_pts(0, -0.195, 0.098, 0, BRS_TAU, 14),
                                            true, 0.016)));
    brs_append(_o, brs_raise(brs_ellipse_pts(0, -0.195, 0.070, 0.082, 14), 0.026, 3, "m3"));
    brs_append(_o, brs_raise([[-0.135, 0.135], [-0.105, -0.055], [0.105, -0.055], [0.135, 0.135]],
                             0.030, 3, "m2"));
    // The gilding: four rays in the corners of the sunk field.
    for (var _i = 0; _i < 4; _i++) {
        var _sx = (_i % 2 == 0) ? -1 : 1;
        var _sy = (_i < 2) ? -1 : 1;
        brs_append(_o, brs_as_fitting(brs_ridge(
            [[_sx * 0.150, -0.10 + _sy * 0.215], [_sx * 0.105, -0.10 + _sy * 0.175]], false, 0.014)));
    }
    return _o;
}

/// A tiny vial held in a filigree cradle. The smallest ware in the corpus - and the cradle exists
/// so that "smallest" does not become "invisible on the shelf".
function brs_w_perfume_vial() {
    var _o = brs_ware_shadow(0, 0.26);
    // The cradle: three legs and a bowl ring, in the fitting metal. Enlarged from a version that
    // filled 0.14 of its plate: "the smallest ware in the corpus" is a design intent and "lost on
    // the shelf" is a defect, and the cradle is where the difference is bought.
    for (var _i = 0; _i < 3; _i++) {
        var _a = BRS_TAU * (0.12 + _i * 0.333);
        brs_append(_o, brs_as_fitting(brs_one(brs_taper_ribbon(
            brs_qbez([cos(_a) * 0.075, 0.10], [cos(_a) * 0.245, 0.28],
                     [cos(_a) * 0.275, BRS_STAND], 7), 0.024, 0.038, "m2"))));
    }
    brs_append(_o, brs_as_fitting(brs_ridge(brs_ellipse_pts(0, 0.095, 0.200, 0.070, 18),
                                            true, 0.028)));
    brs_append(_o, brs_as_fitting(brs_raise(
        brs_round_rect_pts(-0.245, BRS_STAND - 0.045, 0.245, BRS_STAND, 0.020, 2), 0.022, 2, "m3")));
    // The vial: a round body with a long neck and a faceted stopper.
    var _hw = brs_profile_curve(0.165, 15, 0.86, 0.74, 0.04, 0.10);
    brs_append(_o, brs_body(0, -0.38, 0.26, _hw, 0.034));
    brs_append(_o, brs_sheen(0, -0.34, 0.24, _hw, 0.40, 0.032, "m4"));
    // The scent inside: a level line, flat, in the wear role.
    array_push(_o, brs_ring_fill(brs_profile_pts(0, 0.03, 0.24,
        brs_profile_curve(0.146, 8, 0.55, 0.30, 0.0, 0.16)), "wear", undefined, undefined));
    brs_append(_o, brs_as_fitting(brs_raise(brs_star_pts(0, -0.425, 0.078, 6, 0.26),
                                            0.030, 3, "m3")));
    brs_append(_o, brs_as_fitting(brs_ridge(brs_ellipse_pts(0, -0.355, 0.062, 0.024, 12),
                                            true, 0.018)));
    return _o;
}

/// ============================================================================================
/// THE DISPATCHER
///
/// ⛔ ONE SWITCH, AND IT IS EXHAUSTIVE. GameMaker will happily compile a call to a function that
/// does not exist for a case never taken, so the corpus is walked whole by brs_selftest - every id
/// in brs_ware_ids() is built, measured and asserted. A ware that is in the id list and not in this
/// switch would otherwise ship as the DEFAULT ware, silently, on someone else's shelf.
/// ============================================================================================

function brs_ware_parts(_id) {
    switch (_id) {
        case "grain_sack":    return brs_w_grain_sack();
        case "flour_barrel":  return brs_w_flour_barrel();
        case "bread_batch":   return brs_w_bread_batch();
        case "cheese_wheel":  return brs_w_cheese_wheel();
        case "salt_block":    return brs_w_salt_block();
        case "honey_pot":     return brs_w_honey_pot();
        case "linen_bolt":    return brs_w_linen_bolt();
        case "wool_bale":     return brs_w_wool_bale();
        case "dyed_silk":     return brs_w_dyed_silk();
        case "hemp_coil":     return brs_w_hemp_coil();
        case "raw_fleece":    return brs_w_raw_fleece();
        case "thread_rack":   return brs_w_thread_rack();
        case "iron_ingot":    return brs_w_iron_ingot();
        case "copper_stack":  return brs_w_copper_stack();
        case "silver_bar":    return brs_w_silver_bar();
        case "ore_basket":    return brs_w_ore_basket();
        case "nail_keg":      return brs_w_nail_keg();
        case "shoe_ring":     return brs_w_shoe_ring();
        case "wine_cask":     return brs_w_wine_cask();
        case "ale_barrel":    return brs_w_ale_barrel();
        case "spirit_bottle": return brs_w_spirit_bottle();
        case "water_skin":    return brs_w_water_skin();
        case "cider_jug":     return brs_w_cider_jug();
        case "mead_amphora":  return brs_w_mead_amphora();
        case "spice_jar":     return brs_w_spice_jar();
        case "pepper_sack":   return brs_w_pepper_sack();
        case "saffron_box":   return brs_w_saffron_box();
        case "herb_bundle":   return brs_w_herb_bundle();
        case "oil_flask":     return brs_w_oil_flask();
        case "incense_cakes": return brs_w_incense_cakes();
        case "plank_stack":   return brs_w_plank_stack();
        case "log_bundle":    return brs_w_log_bundle();
        case "charcoal_sack": return brs_w_charcoal_sack();
        case "cut_stone":     return brs_w_cut_stone();
        case "slate_tiles":   return brs_w_slate_tiles();
        case "lime_bucket":   return brs_w_lime_bucket();
        case "hide_roll":     return brs_w_hide_roll();
        case "tanned_stack":  return brs_w_tanned_stack();
        case "candle_box":    return brs_w_candle_box();
        case "tallow_tub":    return brs_w_tallow_tub();
        case "tool_chest":    return brs_w_tool_chest();
        case "wax_tablets":   return brs_w_wax_tablets();
        case "pearl_casket":  return brs_w_pearl_casket();
        case "glass_beads":   return brs_w_glass_beads();
        case "indigo_pot":    return brs_w_indigo_pot();
        case "lacquer_box":   return brs_w_lacquer_box();
        case "gilt_icon":     return brs_w_gilt_icon();
        default:              return brs_w_perfume_vial();
    }
}

/// The surface a ware is drawn on, in a given hall, with a given price direction.
function brs_ware_surface(_id, _hall, _dir) {
    var _s = brs_ware_spec(_id);
    return brs_surface(_s.body, _s.fitting, _hall, _dir);
}

/// A ware's parts WITHOUT its cast shadow.
///
/// ⛔ THE SHADOW IS NOT PART OF THE OBJECT AND MUST NOT BE MEASURED AS IF IT WERE. The first run of
/// brs_selftest reported all forty-eight goods standing 0.04 to 0.07 BELOW the counter line, which
/// read as a corpus-wide authoring mistake and was a mistake in the QUESTION: the shadow is an
/// ellipse lying ON the counter, so of course it reaches past the point where the good touches it.
/// A false red costs exactly what a false green does - it sent this session looking for a bug in
/// forty-eight functions that were correct.
function brs_ware_solid_parts(_id) {
    var _all = brs_ware_parts(_id);
    var _out = [];
    for (var _i = 0; _i < array_length(_all); _i++) {
        if (_all[_i].role != "shadow") array_push(_out, _all[_i]);
    }
    return _out;
}

/// How far the LOWEST point of a ware's own geometry sits from the counter line. The corpus
/// contract, asserted for all forty-eight: a good that floats reads as a bug in the buyer's shelf
/// code, and one that sinks reads as a z-order mistake. Both would be ours.
function brs_ware_stand_error(_id) {
    var _bb = brs_render_bounds(brs_ware_solid_parts(_id));
    return _bb[3] - BRS_STAND;
}

/// Where the cast shadow sits, so removing it from the measurement above cannot hide a missing one.
/// Returns [found, centre y].
function brs_ware_shadow_at(_id) {
    var _all = brs_ware_parts(_id);
    for (var _i = 0; _i < array_length(_all); _i++) {
        if (_all[_i].role == "shadow") {
            var _bb = brs_render_bounds([_all[_i]]);
            return [true, (_bb[1] + _bb[3]) * 0.5];
        }
    }
    return [false, 0];
}

/// The widest a ware gets, as a fraction of the unit box. Used to lay out a shelf without measuring
/// every ware at draw time, and asserted so nothing in the corpus escapes its own frame.
function brs_ware_extent(_id) {
    var _bb = brs_render_bounds(brs_ware_parts(_id));
    return [_bb[0], _bb[1], _bb[2], _bb[3]];
}
