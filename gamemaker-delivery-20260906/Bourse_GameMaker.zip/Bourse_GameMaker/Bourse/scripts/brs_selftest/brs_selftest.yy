{
  "$GMScript": "v1",
  "%Name": "brs_selftest",
  "isCompatibility": false,
  "isDnD": false,
  "name": "brs_selftest",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}