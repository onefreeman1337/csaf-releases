/// BOURSE - brs_selftest. The engine testing itself, headless, on a real Igor-built executable.
///
/// GML cannot be unit-tested outside the engine: there is no Node-mockable core and no batch mode
/// that runs a function. So the product ships a mode - `Bourse.exe -selftest` - that runs every
/// assertion in this file and writes brs_selftest.json into %LOCALAPPDATA%\Bourse\. That file is
/// the evidence; a green compile is not.
///
/// ⛔ WHAT THIS CAN AND CANNOT SEE. It can prove the simulation is deterministic, that no two wares
/// collapse onto the same silhouette, that every role a part asks for exists on the surface it will
/// be drawn with, and that no good floats above the counter. It CANNOT see whether a cask looks
/// like a cask. Every product in this wing that shipped a visual defect shipped it past a green
/// suite - 369 assertions on one, 218 on another - and every one was found by opening the picture
/// and looking at it. The suite is a floor under the work, never a substitute for it.
///
/// ⛔ AND A TEST THAT HAS ONLY EVER PASSED IS NOT A TEST. The epsilon assertions below were written
/// to go RED on purpose first (see BRS_ST_EPS), because this wing has shipped a suite in which
/// every distinctness check passed vacuously - the tolerance was below GML's own comparison epsilon
/// and could never fire in either direction.
/// ============================================================================================

/// The one tolerance in this file. TEN TIMES the runtime's comparison epsilon (0.00001, printed
/// into the result file every run), because a tolerance AT the epsilon is unusable in both
/// directions: `abs(a - b) < 0.00001` goes RED on two values that are the same object, and
/// `abs(a - b) < 0.0000001` goes GREEN on every pair of numbers there has ever been.
#macro BRS_ST_EPS 0.0001

/// Every ware must fit inside this half-extent of the unit box.
#macro BRS_ST_BOX 0.520

/// A ware may stand at most this far off the counter line, either way.
#macro BRS_ST_STAND 0.030

/// The Jaccard distance below which two wares are the same picture. See brs_st_occupancy for what
/// this measures and, more importantly, for what it does not.
#macro BRS_ST_DISTINCT 0.34

/// The fraction of its own bounding box a ware must put ink into. Catches a good that is technically
/// present and visually a wisp - it cannot catch one that is ugly.
#macro BRS_ST_INK 0.16

/// The occupancy grid resolution, per axis.
#macro BRS_ST_GRID 32

function brs_st_new() {
    return { pass: 0, fail: 0, failures: [] };
}

function brs_st_ok(_r, _cond, _what) {
    if (_cond) { _r.pass += 1; return true; }
    _r.fail += 1;
    if (array_length(_r.failures) < 60) array_push(_r.failures, _what);
    return false;
}

/// ============================================================================================
/// STAGE 1 - THE RUNTIME ITSELF
/// ============================================================================================

function brs_st_runtime(_r) {
    var _e = math_get_epsilon();

    // ⛔ TWO CLAUSES, DELIBERATELY NOT ONE. The natural way to write this is
    // `_e > 0 && _e < TOL`, and the FIRST clause goes red: the difference between the epsilon and
    // zero IS the epsilon, GML therefore calls them equal, and equal is not greater-than. Written
    // as a positive assertion, `!(_e > 0)` PROVES the runtime still applies an epsilon and goes red
    // the day a release stops - which is the only version of this test worth having.
    brs_st_ok(_r, !(_e > 0), "epsilon: math_get_epsilon() compared greater than zero - the runtime "
        + "no longer applies a comparison epsilon, and every tolerance in this file needs revisiting");
    brs_st_ok(_r, _e < 0.001, "epsilon: larger than 0.001 (" + string(_e) + ") - tolerances unsafe");

    // The tolerance this file uses must be clear of the epsilon in the direction it is used.
    brs_st_ok(_r, BRS_ST_EPS > _e * 5, "epsilon: BRS_ST_EPS is not clear of the runtime epsilon");
    // And it must actually fire. A tolerance that cannot separate two genuinely different numbers
    // is the vacuous-green failure this wing has already paid for.
    brs_st_ok(_r, !(abs(1.0 - 1.01) < BRS_ST_EPS), "epsilon: BRS_ST_EPS passed two numbers 0.01 apart");
    brs_st_ok(_r, abs(1.0 - 1.0) < BRS_ST_EPS, "epsilon: BRS_ST_EPS refused two identical numbers");
}

/// ============================================================================================
/// STAGE 2 - GEOMETRY AND RELIEF
/// ============================================================================================

/// Total turning of a closed polygon, in revolutions. One for a simple polygon, ZERO for a
/// figure-of-eight - which is the cheap test that catches a self-crossing outline before it draws
/// corner hooks and throws its inset points outside the shape.
function brs_st_turning(_pts) {
    var _n = array_length(_pts);
    var _sum = 0;
    for (var _i = 0; _i < _n; _i++) {
        var _a = _pts[(_i + _n - 1) % _n], _b = _pts[_i], _c = _pts[(_i + 1) % _n];
        var _t1 = arctan2(_b[1] - _a[1], _b[0] - _a[0]);
        var _t2 = arctan2(_c[1] - _b[1], _c[0] - _b[0]);
        var _d = _t2 - _t1;
        while (_d > pi) _d -= BRS_TAU;
        while (_d < -pi) _d += BRS_TAU;
        _sum += _d;
    }
    return _sum / BRS_TAU;
}

function brs_st_relief(_r) {
    // The rounded rectangle every panel, well and plate on the screen is built from.
    var _rr = brs_round_rect_pts(-0.4, -0.2, 0.4, 0.2, 0.08, 4);
    brs_st_ok(_r, abs(abs(brs_st_turning(_rr)) - 1.0) < 0.02,
        "relief: brs_round_rect_pts does not turn exactly once - it is self-crossing");

    // The five profile shapes the corpus is built on, each checked the same way.
    var _shapes = ["cask", "sack", "bottle", "jar", "cylinder"];
    var _cfg = [[0.30, 15, 0.26, 0.50, 0.0, 0.0], [0.31, 15, 0.66, 0.78, 0.30, 0.05],
                [0.15, 17, 0.80, 0.80, 0.0, 0.04], [0.225, 13, 0.44, 0.58, 0.10, 0.14],
                [0.27, 12, 0.20, 0.52, 0.0, 0.0]];
    for (var _i = 0; _i < 5; _i++) {
        var _c = _cfg[_i];
        var _hw = brs_profile_curve(_c[0], _c[1], _c[2], _c[3], _c[4], _c[5]);
        var _p = brs_profile_pts(0, -0.3, 0.4, _hw);
        brs_st_ok(_r, abs(abs(brs_st_turning(_p)) - 1.0) < 0.06,
            "relief: the " + _shapes[_i] + " profile is self-crossing");
        // And no half width may be zero, or the inset pass reads a neighbour's normal.
        var _minw = 99;
        for (var _k = 0; _k < array_length(_hw); _k++) _minw = min(_minw, _hw[_k]);
        brs_st_ok(_r, _minw >= 0.0 && array_length(_hw) == _c[1],
            "relief: the " + _shapes[_i] + " profile has the wrong sample count");
    }

    // A bevel produces steps * n quads and nothing else.
    var _sq = [[-0.2, -0.2], [0.2, -0.2], [0.2, 0.2], [-0.2, 0.2]];
    brs_st_ok(_r, array_length(brs_bevel(_sq, 0.05, 3, false)) == 12,
        "relief: brs_bevel on a square at 3 steps did not produce 12 quads");
    brs_st_ok(_r, array_length(brs_bevel(_sq, 0.0, 3, false)) == 0,
        "relief: brs_bevel with zero depth produced parts");

    // The inset must WRAP. An inset that clamps at the array ends puts a notch at the seam, which
    // on a circle is at three o'clock and in plain view.
    var _ring = brs_ellipse_pts(0, 0, 0.3, 0.3, 16);
    var _in = brs_inset(_ring, 0.05, brs_out_sign(_ring));
    var _d0 = point_distance(0, 0, _in[0][0], _in[0][1]);
    var _d8 = point_distance(0, 0, _in[8][0], _in[8][1]);
    brs_st_ok(_r, abs(_d0 - _d8) < 0.004,
        "relief: brs_inset does not wrap - the seam vertex moved a different distance ("
        + string(_d0) + " vs " + string(_d8) + ")");

    // The lamp is a unit vector, and it points up-left. If either goes, every shape in the package
    // is lit from somewhere else and nothing else in this suite would notice.
    brs_st_ok(_r, abs(BRS_LX * BRS_LX + BRS_LY * BRS_LY - 1.0) < BRS_ST_EPS,
        "relief: the lamp vector is not unit length");
    brs_st_ok(_r, BRS_LX < 0 && BRS_LY < 0, "relief: the lamp no longer points up and to the left");

    // A wall facing the lamp must land on a brighter ramp stop than one facing away. This is the
    // one assertion that proves the relief engine is doing its job at all.
    brs_st_ok(_r, brs_relief_role(BRS_LX, BRS_LY, 1.0) == "m4",
        "relief: a wall facing straight into the lamp is not the specular stop");
    brs_st_ok(_r, brs_relief_role(-BRS_LX, -BRS_LY, 1.0) == "m0",
        "relief: a wall facing straight away from the lamp is not the deep stop");
    brs_st_ok(_r, brs_relief_role(BRS_LX, BRS_LY, 0.0) == "m2",
        "relief: a flat wall does not show the face value");
}

/// ============================================================================================
/// STAGE 3 - MATERIALS AND HALLS
/// ============================================================================================

function brs_st_materials(_r) {
    var _ids = brs_material_ids();
    brs_st_ok(_r, array_length(_ids) == 14, "materials: the table is not fourteen entries");

    var _tight = brs_material_tightest_ramp();
    brs_st_ok(_r, _tight[0] >= BRS_RAMP_FLOOR,
        "materials: ramp stops collapse at " + _tight[1] + " (" + string(_tight[0]) + ")");

    // Every material's ramp must ASCEND. A ramp authored out of order lights a shape backwards and
    // reads as a hole rather than as an object.
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _m = brs_material(_ids[_i]);
        brs_st_ok(_r, _m.L.m0 < _m.L.m1 && _m.L.m1 < _m.L.m2 && _m.L.m2 < _m.L.m3 && _m.L.m3 < _m.L.m4,
            "materials: " + _ids[_i] + " ramp does not ascend");
    }

    // Every hall must separate its paper from its cloth, or a ledger cannot be read on a counter.
    var _halls = brs_hall_ids();
    brs_st_ok(_r, array_length(_halls) == 6, "halls: the table is not six entries");
    for (var _i = 0; _i < array_length(_halls); _i++) {
        var _h = brs_hall(_halls[_i]);
        brs_st_ok(_r, abs(_h.L.paper - _h.L.cloth) > 0.30,
            "halls: " + _halls[_i] + " paper and cloth are within 0.30 lightness");
        brs_st_ok(_r, abs(_h.L.line - _h.L.panel) > 0.30,
            "halls: " + _halls[_i] + " text does not clear its own panel");
    }

    // ⛔ THE TWO-SIDED VISIBILITY RULE. Fourteen materials span most of the lightness axis and no
    // single cloth clears all of them - so a flat floor here would be a WRONG MEASURE, not a wrong
    // palette. A ware is legible either because its face clears the cloth OR because its ramp
    // brackets it, and the assertion is written as that disjunction rather than as a number nobody
    // can satisfy.
    var _worstPair = "";
    var _bad = 0;
    for (var _a = 0; _a < array_length(_ids); _a++) {
        for (var _b = 0; _b < array_length(_halls); _b++) {
            var _clear = brs_material_visibility(_ids[_a], _halls[_b]) >= BRS_GROUND_FLOOR;
            var _brack = brs_material_brackets(_ids[_a], _halls[_b]);
            if (!_clear && !_brack) { _bad += 1; _worstPair = _ids[_a] + " on " + _halls[_b]; }
        }
    }
    brs_st_ok(_r, _bad == 0, "materials: " + string(_bad) + " material/hall pairs neither clear the "
        + "cloth nor bracket it, e.g. " + _worstPair);

    // And every ware's own pair must separate, or its fittings vanish into its body.
    var _wares = brs_ware_ids();
    for (var _i = 0; _i < array_length(_wares); _i++) {
        var _sp = brs_ware_spec(_wares[_i]);
        brs_st_ok(_r, brs_pair_separation(_sp.body, _sp.fitting) >= BRS_PAIR_FLOOR,
            "materials: " + _wares[_i] + " body and fitting are within " + string(BRS_PAIR_FLOOR)
            + " (" + _sp.body + "/" + _sp.fitting + " = "
            + string(brs_pair_separation(_sp.body, _sp.fitting)) + ")");
    }
}

/// ============================================================================================
/// STAGE 4 - THE CORPUS
/// ============================================================================================

/// Mark every grid cell whose centre lies inside a triangle. The rasteriser the occupancy grid is
/// built on.
function brs_st_tri(_g, _a, _b, _c) {
    var _x0 = clamp(floor((min(_a[0], _b[0], _c[0]) + 0.5) * BRS_ST_GRID), 0, BRS_ST_GRID - 1);
    var _x1 = clamp(floor((max(_a[0], _b[0], _c[0]) + 0.5) * BRS_ST_GRID), 0, BRS_ST_GRID - 1);
    var _y0 = clamp(floor((min(_a[1], _b[1], _c[1]) + 0.5) * BRS_ST_GRID), 0, BRS_ST_GRID - 1);
    var _y1 = clamp(floor((max(_a[1], _b[1], _c[1]) + 0.5) * BRS_ST_GRID), 0, BRS_ST_GRID - 1);
    var _d = (_b[1] - _c[1]) * (_a[0] - _c[0]) + (_c[0] - _b[0]) * (_a[1] - _c[1]);
    if (abs(_d) < 0.0000001) return;
    for (var _gy = _y0; _gy <= _y1; _gy++) {
        for (var _gx = _x0; _gx <= _x1; _gx++) {
            if (_g[_gy * BRS_ST_GRID + _gx]) continue;
            var _px = (_gx + 0.5) / BRS_ST_GRID - 0.5;
            var _py = (_gy + 0.5) / BRS_ST_GRID - 0.5;
            var _u = ((_b[1] - _c[1]) * (_px - _c[0]) + (_c[0] - _b[0]) * (_py - _c[1])) / _d;
            var _v = ((_c[1] - _a[1]) * (_px - _c[0]) + (_a[0] - _c[0]) * (_py - _c[1])) / _d;
            if (_u >= 0 && _v >= 0 && _u + _v <= 1) _g[_gy * BRS_ST_GRID + _gx] = true;
        }
    }
}

/// Where a ware puts ink, as a bitmask over a BRS_ST_GRID square grid covering the unit box.
///
/// ⛔ IT RASTERISES THE FILLS, AND THE FIRST VERSION ONLY MARKED VERTICES. That version reported a
/// mean coverage of 0.13 and a minimum of 0.05 on a corpus that is visibly solid - because a fan of
/// a hundred points puts a hundred dots on a grid and says nothing about the area between them. A
/// coverage floor over a vertex cloud is a floor over the sampling rate, not over the picture, and
/// the honest fix was to rasterise rather than to lower the number.
///
/// ⚠️ AND IT STILL CANNOT SEE WHETHER TWO WARES LOOK DIFFERENT TO A HUMAN. It answers "do these two
/// occupy the same area", which catches a corpus where two goods came from one builder with a
/// parameter changed. A difference drawn INSIDE a filled mass moves nothing here and moves nothing
/// on screen either - this wing recorded exactly that on a mushroom pair that scored zero distance
/// while its authors believed it differed. The number is a floor; the sheet is the evidence.
function brs_st_occupancy(_parts) {
    var _g = array_create(BRS_ST_GRID * BRS_ST_GRID, false);
    var _n = array_length(_parts);
    for (var _i = 0; _i < _n; _i++) {
        var _p = _parts[_i];
        switch (_p.kind) {
            case BRS_FILL: {
                // A fan: pts[0] is the hub and every consecutive pair after it is a triangle.
                for (var _k = 1; _k < array_length(_p.pts) - 1; _k++) {
                    brs_st_tri(_g, _p.pts[0], _p.pts[_k], _p.pts[_k + 1]);
                }
            } break;
            case BRS_STRIP: {
                var _m = min(array_length(_p.a), array_length(_p.b));
                for (var _k = 0; _k < _m - 1; _k++) {
                    brs_st_tri(_g, _p.a[_k], _p.b[_k], _p.a[_k + 1]);
                    brs_st_tri(_g, _p.b[_k], _p.b[_k + 1], _p.a[_k + 1]);
                }
            } break;
            case BRS_DOT: {
                var _gx = clamp(floor((_p.cx + 0.5) * BRS_ST_GRID), 0, BRS_ST_GRID - 1);
                var _gy = clamp(floor((_p.cy + 0.5) * BRS_ST_GRID), 0, BRS_ST_GRID - 1);
                _g[_gy * BRS_ST_GRID + _gx] = true;
            } break;
            case BRS_ARC: {
                var _ap = brs_arc_pts(_p.cx, _p.cy, _p.r, _p.a0, _p.a1, 24);
                for (var _k = 0; _k < array_length(_ap); _k++) {
                    var _ax = clamp(floor((_ap[_k][0] + 0.5) * BRS_ST_GRID), 0, BRS_ST_GRID - 1);
                    var _ay = clamp(floor((_ap[_k][1] + 0.5) * BRS_ST_GRID), 0, BRS_ST_GRID - 1);
                    _g[_ay * BRS_ST_GRID + _ax] = true;
                }
            } break;
            default: {
                // A stroke: mark along it rather than only at its vertices, or a long incision
                // between two far-apart points marks two cells and skips everything between.
                for (var _k = 0; _k < array_length(_p.pts) - 1; _k++) {
                    var _q0 = _p.pts[_k], _q1 = _p.pts[_k + 1];
                    var _steps = max(1, ceil(point_distance(_q0[0], _q0[1], _q1[0], _q1[1])
                                             * BRS_ST_GRID));
                    for (var _t = 0; _t <= _steps; _t++) {
                        var _f = _t / _steps;
                        var _sx = clamp(floor((lerp(_q0[0], _q1[0], _f) + 0.5) * BRS_ST_GRID),
                                        0, BRS_ST_GRID - 1);
                        var _sy = clamp(floor((lerp(_q0[1], _q1[1], _f) + 0.5) * BRS_ST_GRID),
                                        0, BRS_ST_GRID - 1);
                        _g[_sy * BRS_ST_GRID + _sx] = true;
                    }
                }
            } break;
        }
    }
    return _g;
}

/// Jaccard distance between two occupancy grids: 0 identical, 1 disjoint.
function brs_st_jaccard(_a, _b) {
    var _both = 0, _either = 0;
    for (var _i = 0; _i < BRS_ST_GRID * BRS_ST_GRID; _i++) {
        if (_a[_i] && _b[_i]) _both += 1;
        if (_a[_i] || _b[_i]) _either += 1;
    }
    if (_either == 0) return 0;
    return 1.0 - (_both / _either);
}

/// The parts of a ware drawn in a given ramp: "m" for the body, "n" for the fittings.
function brs_st_by_ramp(_parts, _prefix) {
    var _out = [];
    for (var _i = 0; _i < array_length(_parts); _i++) {
        if (string_char_at(_parts[_i].role, 1) == _prefix) array_push(_out, _parts[_i]);
    }
    return _out;
}

/// How different two wares look, as the BETTER of two shape comparisons.
///
/// ⛔ ONE FILLED-AREA COMPARISON IS TOO BLUNT, AND THE FIRST VERSION WAS EXACTLY THAT. A wine cask
/// and a sack of charcoal are both a big rounded mass filling most of a plate, so their areas
/// overlap 85% and the measure called them the same picture - which they are not, in any sense a
/// player would recognise: one has three iron hoops banded across its middle and the other has a
/// heap of black lumps spilling over its mouth. The area measure cannot see that, because both
/// FILL the same cells.
///
/// So the comparison is run twice, once over the parts drawn in the BODY ramp and once over the
/// parts drawn in the FITTING ramp, and two wares are distinct if EITHER differs. That is the
/// honest reading of the question: goods are told apart by their outline OR by where their metal
/// is, and a rule that demands both is a rule that would ban every barrel after the first.
///
/// ⚠️ AND IT STILL SEES ONLY GEOMETRY. Colour, stencils, tone and every difference drawn inside a
/// filled mass are invisible to it. It is a floor under the corpus, not a judgement of it.
function brs_st_ware_distance(_a_parts, _b_parts) {
    var _ab = brs_st_occupancy(brs_st_by_ramp(_a_parts, "m"));
    var _bb = brs_st_occupancy(brs_st_by_ramp(_b_parts, "m"));
    var _af = brs_st_occupancy(brs_st_by_ramp(_a_parts, "n"));
    var _bf = brs_st_occupancy(brs_st_by_ramp(_b_parts, "n"));
    return max(brs_st_jaccard(_ab, _bb), brs_st_jaccard(_af, _bf));
}

function brs_st_corpus(_r) {
    var _ids = brs_ware_ids();
    brs_st_ok(_r, array_length(_ids) == 48, "corpus: the id list is not forty-eight entries");

    // Every id must be its own entry in the dispatcher. A missing case silently ships the DEFAULT
    // ware on somebody else's shelf, and nothing else in this suite would see it - so the test is
    // that the picture differs, not that the function returned.
    var _grids = array_create(48);
    var _worst = 99, _who = "";
    var _inkMin = 99, _inkWho = "", _inkUnder = 0, _inkSum = 0, _inkThin = "";
    var _seenTrade = {};

    for (var _i = 0; _i < 48; _i++) {
        var _id = _ids[_i];
        var _parts = brs_ware_parts(_id);
        brs_st_ok(_r, array_length(_parts) > 6,
            "corpus: " + _id + " drew fewer than seven parts - it is probably a stub");

        var _bb = brs_render_bounds(_parts);
        brs_st_ok(_r, _bb[0] > -BRS_ST_BOX && _bb[2] < BRS_ST_BOX
                   && _bb[1] > -BRS_ST_BOX && _bb[3] < BRS_ST_BOX,
            "corpus: " + _id + " escapes the unit box (" + string(_bb[0]) + "," + string(_bb[1])
            + " to " + string(_bb[2]) + "," + string(_bb[3]) + ")");

        // THE COUNTER LINE. A good that floats reads as a bug in the buyer's shelf code, and a good
        // that sinks reads as a z-order mistake. Both are ours.
        //
        // ⚠️ MEASURED ON THE SOLID PARTS, NOT THE WHOLE LIST - see brs_ware_solid_parts. The cast
        // shadow lies ON the counter and legitimately reaches past the contact point, and the first
        // version of this assertion counted it and reported all forty-eight goods as broken.
        var _err = brs_ware_stand_error(_id);
        brs_st_ok(_r, abs(_err) <= BRS_ST_STAND,
            "corpus: " + _id + " does not stand on the counter line (off by " + string(_err) + ")");

        // And the shadow must still BE there, at the counter line - otherwise excluding it above
        // would quietly license a corpus with no shadows at all.
        var _sh = brs_ware_shadow_at(_id);
        brs_st_ok(_r, _sh[0] && abs(_sh[1] - BRS_STAND) < 0.06,
            "corpus: " + _id + " has no cast shadow at the counter line");

        // Every role every part asks for must exist on the surface it will be drawn with. The
        // renderer falls back to `line` on a miss - loudly wrong rather than invisible - and that
        // fallback is a diagnostic, not a licence.
        var _sp = brs_ware_spec(_id);
        var _pal = brs_ware_surface(_id, "counting-house", 0);
        var _roles = brs_roles_used(_parts);
        for (var _k = 0; _k < array_length(_roles); _k++) {
            brs_st_ok(_r, variable_struct_exists(_pal, _roles[_k]),
                "corpus: " + _id + " asks for role '" + _roles[_k] + "' which no surface carries");
        }

        // Economics sanity - a buyer's own table will end up here too.
        brs_st_ok(_r, _sp.base > 0 && _sp.elast > 0.10 && _sp.bulk > 0,
            "corpus: " + _id + " has a nonsense spec");
        brs_st_ok(_r, _sp.perish >= 0 && _sp.perish < 1.0,
            "corpus: " + _id + " spoils at " + string(_sp.perish) + " per season");
        variable_struct_set(_seenTrade, _sp.trade, true);

        // The occupancy is measured WITHOUT the shadow, for the same reason the stand is: every
        // ware casts a near-identical ellipse, and leaving it in adds the same area to all
        // forty-eight - which inflates every coverage figure and drags every pairwise distance
        // toward zero, i.e. makes both numbers wrong in the flattering direction on one and the
        // alarming direction on the other.
        _grids[_i] = brs_ware_solid_parts(_id);
        var _cells = 0;
        var _og = brs_st_occupancy(_grids[_i]);
        for (var _c = 0; _c < BRS_ST_GRID * BRS_ST_GRID; _c++) if (_og[_c]) _cells += 1;
        var _ink = _cells / (BRS_ST_GRID * BRS_ST_GRID);
        _inkSum += _ink;
        if (_ink < _inkMin) { _inkMin = _ink; _inkWho = _id; }
        // NAMED, not just counted. "4 wares below the floor" sends the next session hunting; the
        // names send it straight to the four functions that need more in them.
        if (_ink < BRS_ST_INK) {
            _inkUnder += 1;
            _inkThin += (_inkThin == "" ? "" : " ") + _id + "@" + string_format(_ink, 1, 2);
        }
    }

    brs_st_ok(_r, variable_struct_names_count(_seenTrade) == 8,
        "corpus: the eight trades are not all represented");
    brs_st_ok(_r, _inkUnder == 0, "corpus: " + string(_inkUnder)
        + " ware(s) below the ink floor: " + _inkThin);

    // No two wares may be the same picture. See brs_st_ware_distance for what "same" means here and
    // for the two whole categories of difference it cannot see.
    for (var _a = 0; _a < 48; _a++) {
        for (var _b = _a + 1; _b < 48; _b++) {
            var _d = brs_st_ware_distance(_grids[_a], _grids[_b]);
            if (_d < _worst) { _worst = _d; _who = _ids[_a] + "/" + _ids[_b]; }
        }
    }
    brs_st_ok(_r, _worst >= BRS_ST_DISTINCT,
        "corpus: two wares collapse onto the same picture - " + _who + " at " + string(_worst));
    global.brs_st_worst = _worst;
    global.brs_st_worst_who = _who;
    global.brs_st_ink_min = _inkMin;
    global.brs_st_ink_who = _inkWho;
    global.brs_st_ink_mean = _inkSum / 48;
}

/// ============================================================================================
/// STAGE 5 - THE SIMULATION
/// ============================================================================================

function brs_st_market(_r) {
    // DETERMINISM. Two markets from one seed, stepped the same distance, must be identical - it is
    // what makes every other assertion in this stage reproducible and what lets a buyer save a game
    // as a seed and a day count.
    var _a = brs_market_new(4242, "cellar", undefined);
    var _b = brs_market_new(4242, "cellar", undefined);
    brs_market_step(_a, 300);
    brs_market_step(_b, 300);
    var _drift = 0;
    for (var _i = 0; _i < array_length(_a.rows); _i++) {
        if (abs(_a.rows[_i].price - _b.rows[_i].price) > BRS_ST_EPS) _drift += 1;
    }
    brs_st_ok(_r, _drift == 0, "market: not deterministic - " + string(_drift)
        + " ware(s) diverged over 300 days from the same seed");
    brs_st_ok(_r, _a.day == 300, "market: day count wrong after 300 steps");

    // PRICES STAY IN THEIR BAND, over a long run with events firing.
    var _c = brs_market_new(99, "harbour", undefined);
    brs_market_step(_c, 1200);
    var _out = 0;
    for (var _i = 0; _i < array_length(_c.rows); _i++) {
        var _sp = brs_ware_spec(_c.rows[_i].id);
        var _k = _c.rows[_i].price / _sp.base;
        if (_k < BRS_PRICE_MIN * 0.92 || _k > BRS_PRICE_MAX * 1.08) _out += 1;
        if (_c.rows[_i].stock < 0) _out += 1;
    }
    brs_st_ok(_r, _out == 0, "market: " + string(_out) + " price(s) or stock(s) left the legal band "
        + "over 1200 days");

    // PRICES MOVE AT ALL. A simulation whose prices sit at base is a price table with extra steps.
    //
    // ⛔ MEASURED AS THE RANGE THE PRICE VISITED, NOT ITS DISTANCE FROM BASE TODAY. The first
    // version asked how far each price sat from base at one instant, which was a fair test of a
    // BROKEN market - prices were pinned against their clamps and every one was far from base - and
    // is exactly the wrong test of a working one, where a healthy price oscillates ABOUT base and
    // is near it whenever you happen to look. The assertion would have gone red on the fix.
    var _moved = 0, _widest = 0;
    for (var _i = 0; _i < array_length(_c.rows); _i++) {
        var _sp = brs_ware_spec(_c.rows[_i].id);
        var _bd = brs_market_band(_c, _c.rows[_i].id);
        var _span = (_bd[1] - _bd[0]) / max(0.0001, _sp.base);
        if (_span > 0.10) _moved += 1;
        _widest = max(_widest, _span);
    }
    brs_st_ok(_r, _moved >= 24, "market: only " + string(_moved)
        + " of 48 wares swung more than 10% of base across their remembered history");
    // And nothing may swing absurdly - a range wider than the whole legal band means the clamp is
    // being hit in both directions, which is a runaway rather than a market.
    brs_st_ok(_r, _widest < (BRS_PRICE_MAX - BRS_PRICE_MIN),
        "market: one ware swung " + string(_widest) + "x base - wider than the legal band");

    // ⛔ THE ELASTICITY LAW, AND IT IS THE PRODUCT'S CENTRAL CLAIM. The same shortage must move an
    // INELASTIC staple further than an ELASTIC luxury, because the exponent is 1/elasticity. If
    // this ever goes red the simulation has become a multiplier and the file header is a lie.
    var _m = brs_market_new(7, "cellar", ["bread_batch", "pearl_casket"]);
    var _rb = brs_market_row(_m, "bread_batch");
    var _rp = brs_market_row(_m, "pearl_casket");
    _rb.stock *= 0.35;
    _rp.stock *= 0.35;
    var _pb = brs_market_target(_m, _rb) / brs_ware_spec("bread_batch").base;
    var _pp = brs_market_target(_m, _rp) / brs_ware_spec("pearl_casket").base;
    brs_st_ok(_r, _pb > _pp * 1.30,
        "market: a 65% shortage did not hit the inelastic good harder - bread x" + string(_pb)
        + " vs pearls x" + string(_pp));
    global.brs_st_shock_bread = _pb;
    global.brs_st_shock_pearl = _pp;

    // SCARCITY IS MONOTONIC: less stock is never cheaper.
    var _m2 = brs_market_new(11, "cellar", ["wine_cask"]);
    var _row = brs_market_row(_m2, "wine_cask");
    var _last = -1;
    var _mono = true;
    for (var _s = 10; _s >= 1; _s--) {
        _row.stock = _row.daily * BRS_COVER * (_s / 10.0);
        var _p = brs_market_target(_m2, _row);
        if (_p < _last - BRS_ST_EPS) _mono = false;
        _last = _p;
    }
    brs_st_ok(_r, _mono, "market: price is not monotonic in scarcity");

    // THE SPREAD WIDENS WHEN STOCK RUNS OUT, and buy is always above sell.
    _row.stock = _row.daily * BRS_COVER;
    var _sp1 = brs_market_spread(_row);
    _row.stock = _row.daily * BRS_COVER * 0.10;
    var _sp2 = brs_market_spread(_row);
    brs_st_ok(_r, _sp2 > _sp1, "market: the spread did not widen as stock ran out");
    brs_st_ok(_r, brs_market_buy_price(_m2, "wine_cask") > brs_market_sell_price(_m2, "wine_cask"),
        "market: buy price is not above sell price");

    // PARTIAL FILL. A player who asks for more than the shelf holds gets what there is, and is told.
    var _m3 = brs_market_new(3, "cellar", ["grain_sack"]);
    var _g = brs_market_row(_m3, "grain_sack");
    _g.stock = 4;
    _m3.purse = 100000;
    var _res = brs_market_do_buy(_m3, "grain_sack", 40);
    brs_st_ok(_r, _res.ok && _res.qty == 4 && _res.why == "partial fill",
        "market: a partial fill was refused or mis-reported (" + string(_res.qty) + ", '"
        + _res.why + "')");
    brs_st_ok(_r, _g.stock < 0.5, "market: a filled order did not leave the shelf empty");
    // And buying moved the price IMMEDIATELY.
    var _m4 = brs_market_new(3, "cellar", ["grain_sack"]);
    var _g4 = brs_market_row(_m4, "grain_sack");
    var _before = _g4.price;
    _m4.purse = 100000;
    brs_market_do_buy(_m4, "grain_sack", floor(_g4.stock * 0.8));
    brs_st_ok(_r, _g4.price > _before,
        "market: clearing four fifths of the shelf did not move the price");

    // SAVE AND LOAD, INCLUDING THE HISTORY. A market restored with a flat chart reads to a player
    // as an economy that reset when they loaded.
    var _m5 = brs_market_new(1234, "guildhall", undefined);
    brs_market_step(_m5, 420);
    var _blob = brs_market_save(_m5);
    var _m6 = brs_market_load(_blob);
    var _bad = 0;
    for (var _i = 0; _i < array_length(_m5.rows); _i++) {
        if (abs(_m5.rows[_i].price - _m6.rows[_i].price) > BRS_ST_EPS) _bad += 1;
        if (abs(_m5.rows[_i].stock - _m6.rows[_i].stock) > BRS_ST_EPS) _bad += 1;
        if (_m5.rows[_i].hh != _m6.rows[_i].hh) _bad += 1;
        for (var _k = 0; _k < BRS_HIST; _k += 7) {
            if (abs(_m5.rows[_i].hist[_k] - _m6.rows[_i].hist[_k]) > BRS_ST_EPS) _bad += 1;
        }
    }
    brs_st_ok(_r, _bad == 0, "market: save/load lost " + string(_bad) + " field(s)");
    brs_st_ok(_r, _m6.day == _m5.day && _m6.evLeft == _m5.evLeft,
        "market: save/load lost the calendar or the event window");
    // A loaded market must CONTINUE identically, which is a stronger claim than matching on load.
    brs_market_step(_m5, 40);
    brs_market_step(_m6, 40);
    var _bad2 = 0;
    for (var _i = 0; _i < array_length(_m5.rows); _i++) {
        if (abs(_m5.rows[_i].price - _m6.rows[_i].price) > BRS_ST_EPS) _bad2 += 1;
    }
    brs_st_ok(_r, _bad2 == 0, "market: a loaded market diverged over the next 40 days ("
        + string(_bad2) + " wares)");

    // EVENTS FIRE, and land on a trade that exists.
    var _m7 = brs_market_new(88, "cellar", undefined);
    var _fired = 0;
    var _tr = brs_trade_ids();
    for (var _d = 0; _d < 1500; _d++) {
        brs_market_day(_m7);
        if (_m7.ev >= 0) {
            _fired += 1;
            var _known = false;
            for (var _k = 0; _k < array_length(_tr); _k++) if (_tr[_k] == _m7.evTrade) _known = true;
            if (!_known) { brs_st_ok(_r, false, "market: event landed on unknown trade '"
                + _m7.evTrade + "'"); break; }
        }
    }
    brs_st_ok(_r, _fired > 200, "market: events almost never fire (" + string(_fired)
        + " event-days in 1500)");

    // THE TREND NEEDS EIGHT DAYS, and a market at rest reports steady rather than flickering.
    var _m8 = brs_market_new(5, "cellar", ["salt_block"]);
    brs_st_ok(_r, brs_market_trend(_m8, "salt_block") == 0,
        "market: a market at rest reports a trend");

    // THE NEEDLE stays inside its own track whatever the band does.
    var _m9 = brs_market_new(17, "frost-market", undefined);
    brs_market_step(_m9, 600);
    var _off = 0;
    for (var _i = 0; _i < array_length(_m9.rows); _i++) {
        var _nd = brs_market_needle(_m9, _m9.rows[_i].id);
        if (_nd < 0 || _nd > 1) _off += 1;
        var _bnd = brs_market_band(_m9, _m9.rows[_i].id);
        if (_bnd[1] <= _bnd[0]) _off += 1;
    }
    brs_st_ok(_r, _off == 0, "market: " + string(_off) + " needle(s) or band(s) out of range");
}

/// ============================================================================================
/// STAGE 6 - THE INTERFACE'S OWN ARITHMETIC
/// ============================================================================================

function brs_st_interface(_r) {
    var _m = brs_market_new(31, "counting-house", undefined);
    var _st = brs_counter_state("counting-house");

    // Every trade must have exactly six wares, or the three-by-two shelf has a hole in it.
    var _tr = brs_trade_ids();
    for (var _i = 0; _i < array_length(_tr); _i++) {
        brs_st_ok(_r, array_length(brs_trade_wares(_tr[_i])) == 6,
            "interface: trade " + _tr[_i] + " does not hold exactly six wares");
    }

    // ⛔ THE HIT TEST MUST AGREE WITH THE DRAW. The two share their arithmetic by construction, and
    // this assertion is what proves the sharing survived the last edit: click the centre of every
    // plate the draw would put on screen and require the id back.
    var _x = 24, _y = 86, _w = 1232, _h = 590;
    var _rw = _w * 0.17, _lw = _w * 0.31;
    var _sx = _x + _rw + 14, _sw = _w - _rw - _lw - 28;
    var _pw = (_sw - 24) / 3, _ph = (_h - 16) / 2;
    var _w6 = brs_trade_wares(_st.trade);
    for (var _i = 0; _i < 6; _i++) {
        var _px = _sx + (_i % 3) * (_pw + 12) + _pw * 0.5;
        var _py = _y + floor(_i / 3) * (_ph + 16) + _ph * 0.5;
        var _hit = brs_counter_click(_m, _st, _px, _py, _x, _y, _w, _h);
        brs_st_ok(_r, _hit == "ware:" + _w6[_i],
            "interface: clicking plate " + string(_i) + " returned '" + _hit + "'");
    }
    // And every tab.
    var _th = _h / array_length(_tr);
    for (var _i = 0; _i < array_length(_tr); _i++) {
        var _hit2 = brs_counter_click(_m, _st, _x + _rw * 0.5, _y + _i * _th + _th * 0.5,
                                      _x, _y, _w, _h);
        brs_st_ok(_r, _hit2 == "trade:" + _tr[_i],
            "interface: clicking tab " + string(_i) + " returned '" + _hit2 + "'");
    }
    // A click outside everything must return nothing rather than the nearest thing.
    brs_st_ok(_r, brs_counter_click(_m, _st, _x + _w - 20, _y + 10, _x, _y, _w, _h) == "",
        "interface: a click on the ledger returned a shelf hit");

    // The hottest-first list is actually sorted, and respects its trade filter.
    brs_market_step(_m, 500);
    var _hot = brs_market_hottest(_m, "provision", 6);
    brs_st_ok(_r, array_length(_hot) == 6, "interface: hottest returned the wrong count");
    var _sorted = true;
    for (var _i = 1; _i < array_length(_hot); _i++) {
        var _ka = brs_market_row(_m, _hot[_i - 1]).price / brs_ware_spec(_hot[_i - 1]).base;
        var _kb = brs_market_row(_m, _hot[_i]).price / brs_ware_spec(_hot[_i]).base;
        if (_kb > _ka + BRS_ST_EPS) _sorted = false;
        if (brs_ware_spec(_hot[_i]).trade != "provision") _sorted = false;
    }
    brs_st_ok(_r, _sorted, "interface: hottest is not sorted, or leaked another trade");
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

function brs_selftest_run() {
    var _r = brs_st_new();
    global.brs_st_worst = 0; global.brs_st_worst_who = "";
    global.brs_st_ink_min = 0; global.brs_st_ink_who = ""; global.brs_st_ink_mean = 0;
    global.brs_st_shock_bread = 0; global.brs_st_shock_pearl = 0;

    global.brs_stage = 1; brs_st_runtime(_r);
    global.brs_stage = 2; brs_st_relief(_r);
    global.brs_stage = 3; brs_st_materials(_r);
    global.brs_stage = 4; brs_st_corpus(_r);
    global.brs_stage = 5; brs_st_market(_r);
    global.brs_stage = 6; brs_st_interface(_r);

    var _ramp = brs_material_tightest_ramp();
    var _gnd = brs_material_worst_ground();

    var _s = "{\"crash\":false,\"product\":\"Bourse\"";
    _s += ",\"pass\":" + string(_r.pass) + ",\"fail\":" + string(_r.fail);
    // Twelve decimals, so the epsilon is EVIDENCE in the result file rather than a claim in a
    // comment. The figure in this wing's constitution was wrong by ten times until a run printed it.
    _s += ",\"epsilon\":\"" + string_format(math_get_epsilon(), 1, 12) + "\"";
    _s += ",\"wares\":" + string(array_length(brs_ware_ids()));
    _s += ",\"materials\":" + string(array_length(brs_material_ids()));
    _s += ",\"halls\":" + string(array_length(brs_hall_ids()));
    _s += ",\"tightestRamp\":" + string(_ramp[0]) + ",\"tightestRampAt\":\"" + _ramp[1] + "\"";
    _s += ",\"worstGround\":" + string(_gnd[0]) + ",\"worstGroundAt\":\"" + _gnd[1] + "\"";
    _s += ",\"minWareDistance\":" + string(global.brs_st_worst)
        + ",\"minWareAt\":\"" + global.brs_st_worst_who + "\"";
    _s += ",\"minInk\":" + string(global.brs_st_ink_min)
        + ",\"minInkAt\":\"" + global.brs_st_ink_who + "\""
        + ",\"meanInk\":" + string(global.brs_st_ink_mean);
    _s += ",\"shockBread\":" + string(global.brs_st_shock_bread)
        + ",\"shockPearl\":" + string(global.brs_st_shock_pearl);
    _s += ",\"failures\":[";
    for (var _i = 0; _i < array_length(_r.failures); _i++) {
        if (_i > 0) _s += ",";
        _s += "\"" + string_replace_all(_r.failures[_i], "\"", "'") + "\"";
    }
    _s += "]}";

    var _f = file_text_open_write("brs_selftest.json");
    file_text_write_string(_f, _s);
    file_text_close(_f);
    return _r;
}
