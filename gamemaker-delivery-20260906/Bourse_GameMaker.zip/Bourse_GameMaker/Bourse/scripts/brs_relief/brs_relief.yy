{
  "$GMScript": "v1",
  "%Name": "brs_relief",
  "isCompatibility": false,
  "isDnD": false,
  "name": "brs_relief",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}