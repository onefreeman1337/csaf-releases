/// BOURSE - brs_material. What a trade good is MADE of, as colour.
///
/// A ware in this package is never "brown". It is a five-stop RAMP - the darkness deep between two
/// barrel staves, the shade on the turn of the belly, the face the lamp lights squarely, the
/// highlight on the rim, and the one specular stop where the wood is worn smooth by handling. The
/// relief engine picks among those five by surface normal, so the ramp is what makes a cask read as
/// oak and an ingot read as iron while both are drawn by exactly the same code.
///
/// -- WHY EVERY WARE CARRIES TWO MATERIALS ------------------------------------------------------
/// Almost nothing in a real market is one substance. A cask is oak AND iron. A sack is hemp AND
/// cord. An amphora is clay AND wax. So a ware resolves to TWO ramps: `m0`-`m4` for its body and
/// `n0`-`n4` for its fittings, and the corpus author picks a role per part rather than a colour.
/// That is also what makes the corpus cheap to re-skin: the same crate geometry drawn with pine and
/// tin instead of oak and iron is a different object on the shelf, and neither one is a new file.
///
/// -- AND WHY THE HALL IS A THIRD THING ---------------------------------------------------------
/// The counter, the shelf, the ledger paper and the cloth are the ROOM, not the goods, and they
/// come from a `hall` - six of them, from a dim cellar to a bright harbour office. A buyer who
/// wants the market to feel like their game changes one string. The ware ramps do not move when the
/// hall does, which is the entire point: a copper ingot is the same copper in every hall, and if it
/// were not, the price gauge beside it would be lying about what it is looking at.
///
/// ⚠️ HUE DRIFTS WARM INTO SHADOW ON WARM MATERIALS AND COOL INTO SHADOW ON COLD ONES, by a few
/// degrees per stop. It is a small thing and it is the difference between "five greys tinted
/// orange" and copper.
///
/// ⛔ NOTHING HERE IS A COLOUR CONSTANT PICKED BY EYE IN HEX. Every stop is authored in Oklch -
/// lightness, chroma, hue - because the one property that has to survive re-hueing is EVEN SPACING
/// IN APPARENT LIGHTNESS, and hex has no opinion about that. brs_selftest asserts a per-stop
/// separation floor across all fourteen materials, and that assertion only means something because
/// the numbers below are perceptual.
/// ============================================================================================

/// The minimum apparent-lightness gap between consecutive stops of a ramp. Below this the relief
/// engine's five bands stop being five bands and a bevelled edge reads as a flat fill.
#macro BRS_RAMP_FLOOR 0.11

/// The minimum gap between a ware's BODY face and its FITTING face. Two materials that land on the
/// same face value make an iron hoop invisible against its own stave.
#macro BRS_PAIR_FLOOR 0.07

/// How far a ware's face must clear the cloth it stands on before it is legible at shelf size.
#macro BRS_GROUND_FLOOR 0.13

/// ============================================================================================
/// THE FOURTEEN MATERIALS
/// ============================================================================================

/// Every material id, in no particular order - there is no ladder here, unlike a tier chain. The
/// array is the single definition of "what materials exist" and everything else derives from it.
function brs_material_ids() {
    return ["oak", "pine", "iron", "copper", "bronze", "tin", "sackcloth", "linen",
            "wool", "leather", "clay", "glass", "wax", "stone"];
}

/// [L, C, hue] per stop: m0 deep shadow, m1 shade, m2 FACE, m3 light, m4 specular, then wear.
///
/// The sixth row is WEAR - the stain a good picks up in a warehouse. It is not a sixth ramp stop
/// and is never lit by the relief engine; it is a flat role the corpus paints with deliberately
/// (a water line on a cask, a salt bloom on a hide, soot on a charcoal sack), and it is authored
/// per material because grime on pale linen and grime on green glass are not the same colour.
function brs_material_spec(_id) {
    switch (_id) {
        //                       m0 deep shadow      m1 shade            m2 FACE
        //                       m3 light            m4 specular         wear
        case "oak":       return [[0.14,0.020, 62],[0.26,0.036, 64],[0.40,0.048, 66],
                                  [0.55,0.040, 68],[0.70,0.024, 70],[0.30,0.020, 96]];
        case "pine":      return [[0.26,0.020, 78],[0.40,0.034, 80],[0.56,0.044, 82],
                                  [0.71,0.035, 84],[0.86,0.019, 86],[0.44,0.018,100]];
        // ⛔ IRON IS DARK, AND THE FIRST VERSION HAD IT AT 0.43 - LIGHTER THAN OAK. Measured by
        // brs_selftest, which reported sixteen wares whose body and fitting were within the pairing
        // floor, and eight of them were "oak + iron": a cask hoop the same value as the stave it is
        // nailed to. Wrought iron is nearly black and the fix is the honest one - not a looser
        // floor. One table edit cleared eight of the sixteen at once, which is the tell that the
        // DATA was wrong rather than the test.
        case "iron":      return [[0.08,0.005,248],[0.19,0.007,250],[0.31,0.008,252],
                                  [0.45,0.006,254],[0.62,0.004,256],[0.30,0.055, 44]];
        case "copper":    return [[0.18,0.050, 38],[0.31,0.080, 42],[0.46,0.100, 46],
                                  [0.62,0.078, 50],[0.79,0.042, 54],[0.48,0.055,168]];
        case "bronze":    return [[0.16,0.040, 58],[0.29,0.062, 62],[0.44,0.082, 66],
                                  [0.60,0.066, 70],[0.77,0.036, 74],[0.52,0.052,162]];
        // LOW CHROMA ON PURPOSE. Tin sits beside iron on the shelf and the two are told apart by
        // LIGHTNESS, not hue - a tin authored bluer than iron reads as painted metal.
        case "tin":       return [[0.28,0.003,242],[0.42,0.004,244],[0.58,0.005,246],
                                  [0.74,0.004,248],[0.90,0.002,250],[0.46,0.030, 60]];
        case "sackcloth": return [[0.22,0.018, 74],[0.35,0.030, 76],[0.50,0.038, 78],
                                  [0.65,0.031, 80],[0.81,0.017, 82],[0.38,0.026, 68]];
        case "linen":     return [[0.35,0.008, 88],[0.50,0.013, 90],[0.66,0.017, 92],
                                  [0.80,0.013, 94],[0.94,0.007, 96],[0.54,0.024, 74]];
        case "wool":      return [[0.30,0.010, 66],[0.44,0.016, 68],[0.60,0.021, 70],
                                  [0.75,0.017, 72],[0.90,0.009, 74],[0.48,0.020, 56]];
        case "leather":   return [[0.12,0.030, 40],[0.24,0.050, 42],[0.37,0.064, 44],
                                  [0.51,0.052, 46],[0.66,0.030, 48],[0.28,0.026, 66]];
        case "clay":      return [[0.20,0.045, 44],[0.33,0.072, 46],[0.48,0.092, 48],
                                  [0.63,0.074, 50],[0.79,0.040, 52],[0.40,0.030, 84]];
        // GREEN BOTTLE GLASS. The specular stop is lifted far above the face - glass has no diffuse
        // middle to speak of and reads entirely off its highlight, and a glass ramp authored evenly
        // like a timber one looks like painted wood.
        case "glass":     return [[0.16,0.045,158],[0.28,0.062,156],[0.42,0.070,154],
                                  [0.62,0.052,152],[0.88,0.024,150],[0.34,0.030,120]];
        case "wax":       return [[0.34,0.030, 84],[0.48,0.048, 86],[0.64,0.060, 88],
                                  [0.78,0.048, 90],[0.92,0.026, 92],[0.50,0.022, 70]];
        default:          return [[0.24,0.006,236],[0.37,0.008,238],[0.52,0.010,240],
                                  [0.67,0.008,242],[0.83,0.005,244],[0.42,0.022, 76]];
    }
}

/// Resolve a material to the five stops plus wear, and keep the AUTHORED lightnesses beside them.
///
/// The `L` sub-struct is STORED rather than recovered from the resolved colour, because brs_oklch
/// performs gamut reduction: reading the lightness back out of the returned colour would measure
/// what sRGB could represent, not what was authored, and the separation assertion would then be
/// testing the gamut rather than the ramp.
function brs_material(_id) {
    var _s = brs_material_spec(_id);
    return {
        m0: brs_oklch(_s[0][0], _s[0][1], _s[0][2]),
        m1: brs_oklch(_s[1][0], _s[1][1], _s[1][2]),
        m2: brs_oklch(_s[2][0], _s[2][1], _s[2][2]),
        m3: brs_oklch(_s[3][0], _s[3][1], _s[3][2]),
        m4: brs_oklch(_s[4][0], _s[4][1], _s[4][2]),
        wear: brs_oklch(_s[5][0], _s[5][1], _s[5][2]),
        id: _id,
        L: { m0: _s[0][0], m1: _s[1][0], m2: _s[2][0], m3: _s[3][0], m4: _s[4][0] },
        H: _s[2][2],
        C: _s[2][1]
    };
}

/// The tightest consecutive-stop gap across all fourteen materials, as [value, "id m1/m2"].
///
/// Exists so brs_selftest can assert a floor over the WHOLE table rather than a sampled row. A
/// spot-checked ramp table is a table with one collapsed ramp in it.
function brs_material_tightest_ramp() {
    var _ids = brs_material_ids();
    var _worst = 99, _where = "";
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _m = brs_material(_ids[_i]);
        var _L = [_m.L.m0, _m.L.m1, _m.L.m2, _m.L.m3, _m.L.m4];
        for (var _k = 0; _k < 4; _k++) {
            var _d = _L[_k + 1] - _L[_k];
            if (_d < _worst) { _worst = _d; _where = _ids[_i] + " m" + string(_k) + "/m" + string(_k + 1); }
        }
    }
    return [_worst, _where];
}

/// ============================================================================================
/// THE SIX HALLS - the room the market is in
/// ============================================================================================

function brs_hall_ids() {
    return ["cellar", "counting-house", "harbour", "caravanserai", "guildhall", "frost-market"];
}

/// [L,C,H] per row: ground, panel, edge, line, dim, accent, cloth, paper.
///
/// `cloth` is the counter covering a ware stands on and `paper` is the ledger. They are separate
/// because a ledger written on the same value as the cloth is a ledger nobody can read, and that
/// was the first version.
function brs_hall_spec(_id) {
    switch (_id) {
        //                            ground              panel               edge
        //                            line                dim                 accent
        //                            cloth               paper
        case "cellar":         return [[0.10,0.012, 60],[0.17,0.016, 58],[0.25,0.020, 56],
                                       [0.74,0.020, 68],[0.44,0.014, 62],[0.72,0.100, 62],
                                       [0.20,0.024, 30],[0.80,0.020, 84]];
        case "counting-house": return [[0.14,0.010, 96],[0.22,0.014, 94],[0.31,0.018, 92],
                                       [0.80,0.014, 96],[0.50,0.010, 94],[0.74,0.090,150],
                                       [0.26,0.020,140],[0.87,0.014, 92]];
        case "harbour":        return [[0.12,0.016,236],[0.19,0.020,234],[0.28,0.024,232],
                                       [0.78,0.016,224],[0.47,0.014,230],[0.76,0.085,214],
                                       [0.24,0.026,222],[0.84,0.012,226]];
        case "caravanserai":   return [[0.16,0.020, 52],[0.24,0.028, 50],[0.34,0.034, 48],
                                       [0.83,0.022, 62],[0.53,0.018, 52],[0.78,0.110, 36],
                                       [0.30,0.038, 26],[0.88,0.018, 74]];
        case "guildhall":      return [[0.13,0.018,318],[0.20,0.024,316],[0.29,0.030,314],
                                       [0.79,0.018,310],[0.49,0.016,314],[0.75,0.095,290],
                                       [0.25,0.030,332],[0.85,0.016,308]];
        default:               return [[0.18,0.008,242],[0.27,0.010,240],[0.37,0.012,238],
                                       [0.86,0.010,236],[0.56,0.008,238],[0.70,0.080,252],
                                       [0.33,0.014,244],[0.93,0.008,238]];
    }
}

function brs_hall(_id) {
    var _s = brs_hall_spec(_id);
    return {
        ground: brs_oklch(_s[0][0], _s[0][1], _s[0][2]),
        panel:  brs_oklch(_s[1][0], _s[1][1], _s[1][2]),
        edge:   brs_oklch(_s[2][0], _s[2][1], _s[2][2]),
        line:   brs_oklch(_s[3][0], _s[3][1], _s[3][2]),
        dim:    brs_oklch(_s[4][0], _s[4][1], _s[4][2]),
        accent: brs_oklch(_s[5][0], _s[5][1], _s[5][2]),
        cloth:  brs_oklch(_s[6][0], _s[6][1], _s[6][2]),
        paper:  brs_oklch(_s[7][0], _s[7][1], _s[7][2]),
        id: _id,
        L: { ground: _s[0][0], panel: _s[1][0], line: _s[3][0], cloth: _s[6][0], paper: _s[7][0] }
    };
}

/// How far a material's FACE clears a hall's cloth, in apparent lightness. Signed, because which
/// way it clears matters to nothing except a human reading the number.
function brs_material_visibility(_material_id, _hall_id) {
    return abs(brs_material(_material_id).L.m2 - brs_hall(_hall_id).L.cloth);
}

/// The worst material-on-cloth pairing in the whole product, as [value, "material on hall"].
///
/// ⚠️ A FLOOR THAT NO HALL CAN SATISFY WOULD BE A WRONG MEASURE, NOT A WRONG HALL. Fourteen
/// materials span two thirds of the lightness axis, so no single cloth clears all of them by a
/// wide margin - which is why every ware in this package is BEVELLED. A good is unmistakable
/// either because its face clears the cloth, or because its ramp BRACKETS the cloth (darker walls
/// and lighter walls than the ground it stands on, so its outline is drawn twice over). This
/// function measures the first; the second is what carries the hard cases, and brs_selftest
/// asserts both rather than pretending one number covers it.
function brs_material_worst_ground() {
    var _mi = brs_material_ids(), _hi = brs_hall_ids();
    var _worst = 99, _where = "";
    for (var _a = 0; _a < array_length(_mi); _a++) {
        for (var _b = 0; _b < array_length(_hi); _b++) {
            var _d = brs_material_visibility(_mi[_a], _hi[_b]);
            if (_d < _worst) { _worst = _d; _where = _mi[_a] + " on " + _hi[_b]; }
        }
    }
    return [_worst, _where];
}

/// Does this material BRACKET this cloth - is its darkest stop below the cloth and its brightest
/// above it? A bracketed ware cannot disappear whatever its face value does, because its own bevel
/// draws its outline in two directions at once.
function brs_material_brackets(_material_id, _hall_id) {
    var _m = brs_material(_material_id), _h = brs_hall(_hall_id);
    return (_m.L.m0 < _h.L.cloth - 0.03) && (_m.L.m4 > _h.L.cloth + 0.03);
}

/// ============================================================================================
/// THE SURFACE - one flat struct, handed to the renderer
///
/// ⛔ ONE STRUCT, NOT A CHAIN OF LOOKUPS. The renderer resolves a role by asking this struct and
/// nothing else, so a missing role is always a typo and never a plumbing question. An earlier
/// generation of this drawing layer let the renderer consult a second struct on a miss and spent a
/// session on a "colour bug" that was a lookup falling through to the wrong table.
/// ============================================================================================

/// _body and _fitting are material ids; _hall is a hall id. `_dir` is the price direction the
/// gauge is showing right now: 1 rising, -1 falling, 0 steady - it selects the `trend` role so the
/// gauge does not need to know how to mix a colour.
function brs_surface(_body, _fitting, _hall, _dir) {
    var _b = brs_material(_body);
    var _f = brs_material(_fitting);
    var _h = brs_hall(_hall);
    var _hs = brs_hall_spec(_hall);
    // The shadow a ware casts onto the counter cloth: the cloth, taken down. Derived rather than
    // authored, because one authored grey is right on one hall out of six and reads as a smear on
    // the other five.
    var _sh = brs_oklch(max(0.020, _hs[6][0] - 0.085), _hs[6][1] * 0.70, _hs[6][2]);
    // Rise and fall are authored AGAINST THE HALL's lightness rather than as two fixed colours,
    // for the same reason: a green that reads on a near-black cellar wall is invisible on a frost
    // market's pale counter. Hue is fixed (a market's up is green and its down is red, in every
    // hall); lightness tracks the hall so both always clear the panel they sit on.
    var _lp = _hs[1][0];
    var _riseL = clamp(_lp + 0.42, 0.42, 0.88);
    var _fallL = clamp(_lp + 0.36, 0.38, 0.82);
    return {
        m0: _b.m0, m1: _b.m1, m2: _b.m2, m3: _b.m3, m4: _b.m4, wear: _b.wear,
        n0: _f.m0, n1: _f.m1, n2: _f.m2, n3: _f.m3, n4: _f.m4, nwear: _f.wear,
        ground: _h.ground, panel: _h.panel, edge: _h.edge, line: _h.line,
        dim: _h.dim, accent: _h.accent, cloth: _h.cloth, paper: _h.paper,
        shadow: _sh,
        // The stencil a crate is branded with, and the chalk a price is written in. Both are the
        // ledger paper, so a mark on a good and a figure in the book are the same ink.
        mark: brs_oklch(max(0.06, _hs[7][0] - 0.46), _hs[7][1] * 1.4, _hs[7][2] - 14),
        chalk: _h.paper,
        // ⚠️ CHROMA RAISED FROM 0.115/0.135 AFTER LOOKING AT THE BAKED GAUGE SHEET. At the lower
        // figures a rising needle and a falling one were both a pale grey wedge on a dim hall - the
        // hue was there and the SATURATION was not, so the one piece of colour-coded information on
        // the screen was carrying no information at all. The chroma ceiling in brs_palette still
        // pulls these back at the extremes of the lightness axis, so raising them cannot produce
        // the fluorescent green a fixed hex would.
        rise: brs_oklch(_riseL, 0.155, 148),
        fall: brs_oklch(_fallL, 0.175, 28),
        trend: (_dir > 0) ? brs_oklch(_riseL, 0.155, 148)
             : ((_dir < 0) ? brs_oklch(_fallL, 0.175, 28) : _h.dim),
        bodyId: _body, fittingId: _fitting, hallId: _hall,
        L: { m2: _b.L.m2, m4: _b.L.m4, n2: _f.L.m2,
             cloth: _h.L.cloth, ground: _h.L.ground, panel: _h.L.panel, paper: _h.L.paper }
    };
}

/// The gap between a ware's body face and its fitting face, for the pairing floor.
function brs_pair_separation(_body, _fitting) {
    return abs(brs_material(_body).L.m2 - brs_material(_fitting).L.m2);
}
