{
  "$GMScript": "v1",
  "%Name": "brs_material",
  "isCompatibility": false,
  "isDnD": false,
  "name": "brs_material",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}