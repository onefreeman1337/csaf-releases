{
  "$GMScript": "v1",
  "%Name": "brs_bake",
  "isCompatibility": false,
  "isDnD": false,
  "name": "brs_bake",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}