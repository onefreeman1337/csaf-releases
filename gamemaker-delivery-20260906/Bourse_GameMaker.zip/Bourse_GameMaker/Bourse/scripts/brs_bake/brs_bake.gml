/// BOURSE - brs_bake. The store gallery, rendered BY THE PRODUCT.
///
/// `Bourse.exe -bake` draws every sheet on this page onto a surface with the shipped GML - the same
/// corpus, the same palettes, the same relief engine, the same public functions a buyer calls - and
/// surface_saves them. Nothing here is a screenshot and nothing is a mock-up, so the listing can
/// say "every image on this page was rendered by the product itself" and have it be literally true.
///
/// ⛔ A GALLERY DRAWN BY A SIDE PREVIEWER IS A PICTURE OF A RE-IMPLEMENTATION. This wing has the
/// receipt: a previous product's JavaScript previewer had a defect that was invisible in the
/// previewer and plainly visible in engine, and the store images were of the previewer.
///
/// -- THE CHECKS, AND WHAT EACH ONE IS BLIND TO --------------------------------------------------
/// Every sheet is measured after it is drawn:
///   * the INK BOX catches an EMPTY sheet and a CLIPPED one. It cannot catch a SPARSE one - a
///     bounding box cannot see the space inside itself - and the answer to a sparse sheet is more
///     content, never a lower threshold.
///   * the box is measured TWICE: `full` for the clip test, so a clipped one-pixel hairline is
///     caught, and `content` below the title rule for the coverage floors, so a full-width rule
///     under the title cannot satisfy them on its own.
///   * y is stepped by ONE, not two. A hairline occupies a single row and an even-only scan walks
///     past it on odd rows - measured, on a shipped product.
///   * NONE of this sees whether the picture is any good. Open the PNG.
/// ============================================================================================

#macro BRS_BK_W      1600
#macro BRS_BK_TOL      10   // per-channel difference from the page that counts as ink
#macro BRS_BK_EDGE      6   // px: ink this close to any border is a clip
#macro BRS_BK_WFLOOR 0.72   // content box must span this much of the width
#macro BRS_BK_HFLOOR 0.72   // ...and this much of its height

/// The page colour, read back THROUGH the GPU rather than assumed.
///
/// ⚠️ A COLOUR CONSTANT IS NOT WHAT LANDS IN THE BUFFER. Channel order and any driver-side
/// conversion are answered by drawing the colour onto a one-pixel surface and reading it back, and
/// that is the only version of this that has ever been right.
function brs_bk_probe(_col) {
    var _s = surface_create(1, 1);
    surface_set_target(_s);
    draw_clear_alpha(_col, 1);
    surface_reset_target();
    var _b = buffer_create(4, buffer_fixed, 1);
    buffer_get_surface(_b, _s, 0);
    var _v = buffer_peek(_b, 0, buffer_u32);
    buffer_delete(_b);
    surface_free(_s);
    return _v;
}

/// The ink bounding box, twice: `full` over the whole sheet, `content` below the title rule.
function brs_bk_ink_bounds(_surf, _ground, _ctop) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf);
    var _buf = buffer_create(_w * _h * 4, buffer_fixed, 1);
    buffer_get_surface(_buf, _surf, 0);

    var _g0 =  _ground        & 255;
    var _g1 = (_ground >>  8) & 255;
    var _g2 = (_ground >> 16) & 255;
    var _g3 = (_ground >> 24) & 255;

    var _fx0 = _w, _fy0 = _h, _fx1 = -1, _fy1 = -1;
    var _cx0 = _w, _cy0 = _h, _cx1 = -1, _cy1 = -1;

    for (var _y = 0; _y < _h; _y++) {
        var _row = _y * _w * 4;
        for (var _x = 0; _x < _w; _x += 2) {
            var _v = buffer_peek(_buf, _row + _x * 4, buffer_u32);
            if (_v == _ground) continue;
            if (abs(( _v        & 255) - _g0) <= BRS_BK_TOL
             && abs(((_v >>  8) & 255) - _g1) <= BRS_BK_TOL
             && abs(((_v >> 16) & 255) - _g2) <= BRS_BK_TOL
             && abs(((_v >> 24) & 255) - _g3) <= BRS_BK_TOL) continue;
            if (_x < _fx0) _fx0 = _x;
            if (_x > _fx1) _fx1 = _x;
            if (_y < _fy0) _fy0 = _y;
            if (_y > _fy1) _fy1 = _y;
            if (_y >= _ctop) {
                if (_x < _cx0) _cx0 = _x;
                if (_x > _cx1) _cx1 = _x;
                if (_y < _cy0) _cy0 = _y;
                if (_y > _cy1) _cy1 = _y;
            }
        }
    }
    buffer_delete(_buf);
    return {
        full:    (_fx1 < 0) ? undefined : [_fx0, _fy0, _fx1, _fy1],
        content: (_cx1 < 0) ? undefined : [_cx0, _cy0, _cx1, _cy1]
    };
}

/// _bleed inverts the edge test. A GALLERY SHEET must not touch its own border - ink there means
/// something was clipped. A COVER must: it is full-bleed by design, and a cover with a clean margin
/// all round is a cover that will show a letterboxed rectangle inside a storefront's own frame.
///
/// ⚠️ THIS IS A DIFFERENT QUESTION, NOT A LOWER BAR. The bleed path still fails an EMPTY cover and
/// still fails one whose content does not span the frame; what it stops doing is calling deliberate
/// full-bleed art "clipped". Writing it as a flag rather than as a skipped check is the difference
/// between an artefact with its own rule and an artefact with no rule.
function brs_bk_judge(_name, _surf, _ground, _ctop, _bleed) {
    var _w = surface_get_width(_surf), _h = surface_get_height(_surf);
    var _bb = brs_bk_ink_bounds(_surf, _ground, _ctop);
    var _res = { sheet: _name, ok: false, reason: "", full: _bb.full, content: _bb.content };

    if (is_undefined(_bb.full)) { _res.reason = "the sheet is EMPTY - no ink at all"; return _res; }
    if (is_undefined(_bb.content)) {
        _res.reason = "nothing below the title rule - the sheet is a header and no content";
        return _res;
    }
    var _f = _bb.full;
    if (_bleed) {
        // The cover must REACH at least three of its four edges, or it is not full bleed.
        var _touch = 0;
        if (_f[0] <= BRS_BK_EDGE) _touch += 1;
        if (_f[1] <= BRS_BK_EDGE) _touch += 1;
        if (_f[2] >= _w - 1 - BRS_BK_EDGE) _touch += 1;
        if (_f[3] >= _h - 1 - BRS_BK_EDGE) _touch += 1;
        if (_touch < 3) {
            _res.reason = "cover touches only " + string(_touch)
                        + " of 4 edges - it is not full bleed";
            return _res;
        }
        _res.ok = true;
        _res.reason = "full bleed on " + string(_touch) + " edges";
        return _res;
    }
    if (_f[0] < BRS_BK_EDGE || _f[1] < BRS_BK_EDGE
     || _f[2] > _w - 1 - BRS_BK_EDGE || _f[3] > _h - 1 - BRS_BK_EDGE) {
        _res.reason = _name + " has ink at x=" + string(_f[0]) + ".." + string(_f[2])
                    + " y=" + string(_f[1]) + ".." + string(_f[3])
                    + " on a " + string(_w) + "x" + string(_h) + " surface - CLIPPED";
        return _res;
    }
    var _c = _bb.content;
    var _cw = (_c[2] - _c[0]) / _w;
    var _ch = (_c[3] - _c[1]) / max(1, _h - _ctop);
    if (_cw < BRS_BK_WFLOOR) {
        _res.reason = "content spans only " + string(round(_cw * 100)) + "% of the width";
        return _res;
    }
    if (_ch < BRS_BK_HFLOOR) {
        _res.reason = "content spans only " + string(round(_ch * 100)) + "% of the content height";
        return _res;
    }
    _res.ok = true;
    _res.reason = "w=" + string(round(_cw * 100)) + "% h=" + string(round(_ch * 100)) + "%";
    return _res;
}

/// One line of free text, MEASURED against the space it has and scaled down if it does not fit.
///
/// ⛔ EVERY STRING ON EVERY SHEET GOES THROUGH HERE, AND THE FIRST VERSION HAD FOUR THAT DID NOT.
/// Three of eight sheets came back CLIPPED with ink at x=1598 on a 1600px surface, and the cause
/// was not layout arithmetic - it was two subtitles and two explanatory lines drawn at a fixed
/// scale with no idea how wide they were. A caption that CAN overflow WILL, and this wing has
/// shipped that defect twice on live products; the fix that lasts is to make overflow impossible
/// rather than to shorten today's string.
function brs_bk_text(_font, _x, _y, _maxw, _px_scale, _text, _col) {
    draw_set_font(_font);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_colour(_col);
    var _sc = _px_scale;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    draw_text_transformed(_x, _y, _text, _sc, _sc, 0);
    return _sc;
}

function brs_bk_title(_sur, _x, _y, _w, _text, _sub) {
    brs_bk_text(fnt_bourse_title, _x, _y, _w, 2.05, _text, _sur.line);
    brs_bk_text(fnt_bourse, _x, _y + 62, _w, 1.18, _sub, _sur.dim);
    draw_set_colour(_sur.accent);
    draw_line_width(_x, _y + 104, _x + _w, _y + 104, 1);
    return _y + 132;
}

/// A caption, MEASURED and scaled to the cell it must fit.
///
/// ⛔ THIS WING HAS SHIPPED AN OVERPRINTED CAPTION TWICE - "WickthorSt Cuthman's" on one product and
/// "HEDGEHOG FUNGUSCAULIFLOWER FUNGUS" on the next - and the second time was because the first fix
/// shortened the DATA instead of making the caption honest about its width. No ink check will ever
/// catch this: overprinted text is ink exactly where ink belongs.
function brs_bk_caption(_sur, _cx, _y, _text, _sub, _maxw, _scale) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_top);
    draw_set_font(fnt_bourse_title);
    draw_set_colour(_sur.line);
    var _sc = is_undefined(_scale) ? 1.14 : _scale;
    var _w = string_width(_text) * _sc;
    if (_w > _maxw && _w > 0) _sc *= _maxw / _w;
    draw_text_transformed(_cx, _y, _text, _sc, _sc, 0);

    if (_sub != "") {
        draw_set_font(fnt_bourse);
        draw_set_colour(_sur.dim);
        var _ss = 0.96;
        var _sw = string_width(_sub) * _ss;
        if (_sw > _maxw && _sw > 0) _ss *= _maxw / _sw;
        draw_text_transformed(_cx, _y + 32, _sub, _ss, _ss, 0);
    }
    draw_set_halign(fa_left);
}

function brs_bk_open(_sur, _h, _bg) {
    var _c = is_undefined(_bg) ? _sur.panel : _bg;
    var _surf = surface_create(BRS_BK_W, _h);
    surface_set_target(_surf);
    draw_clear_alpha(_c, 1);
    return _surf;
}

/// ============================================================================================
/// SHEET 1 - THE WHOLE CORPUS
/// ============================================================================================

function brs_bk_sheet_corpus() {
    var _sur = brs_surface("oak", "iron", "counting-house", 0);
    var _h = 1240;
    var _s = brs_bk_open(_sur, _h, _sur.panel);
    var _ctop = brs_bk_title(_sur, 56, 44, BRS_BK_W - 112,
        "FORTY-EIGHT TRADE GOODS",
        "every one drawn from data by the shipped GML - no sprite, no atlas, no texture page");

    var _ids = brs_ware_ids();
    var _cols = 8, _rows = 6;
    var _cw = (BRS_BK_W - 112) / _cols;
    var _ch = (_h - _ctop - 40) / _rows;
    for (var _i = 0; _i < 48; _i++) {
        var _cx = 56 + (_i % _cols) * _cw;
        var _cy = _ctop + floor(_i / _cols) * _ch;
        var _pal = brs_ware_surface(_ids[_i], "counting-house", 0);
        // The cloth each good stands on, so the grid reads as a market and not as a contact sheet.
        brs_render_parts_raw(brs_map_roles(
            brs_ui_well(_cx + 6, _cy + 4, _cx + _cw - 6, _cy + _ch - 34, 8, 5, "cloth"),
            { m0: "ground", m1: "edge", m2: "cloth", m3: "edge", m4: "line" }), _sur);
        brs_render_in_rect(brs_ware_parts(_ids[_i]), _pal,
                           _cx + 16, _cy + 8, _cw - 32, _ch - 46, 0, undefined);
        brs_bk_caption(_sur, _cx + _cw * 0.5, _cy + _ch - 30,
                       string_upper(brs_ware_spec(_ids[_i]).name), "", _cw - 12, 0.80);
    }
    return { surf: _s, ctop: _ctop, ground: _sur.panel, name: "corpus" };
}

/// ============================================================================================
/// SHEET 2 - THE MARKET SCREEN
/// ============================================================================================

function brs_bk_sheet_counter() {
    var _sur = brs_surface("oak", "iron", "counting-house", 0);
    var _h = 1080;
    var _s = brs_bk_open(_sur, _h, _sur.ground);
    var _ctop = brs_bk_title(_sur, 56, 44, BRS_BK_W - 112,
        "THE MARKET SCREEN",
        "no windowskin and no nine-slice - every panel here is an outline bevelled against the same lamp as the goods");

    // ⚠️ STEPPED PAST A FULL HISTORY WINDOW BEFORE THE PICTURE IS TAKEN, AND THAT IS HONESTY RATHER
    // THAN STAGING. A market younger than BRS_HIST * BRS_HIST_EVERY days still has its opening
    // base-price fill inside the remembered history, so every needle reads against a band that is
    // half invented and the whole shelf pins to one end - which is what the first bake showed, six
    // needles hard left, and it is not what the widget does once the window is real.
    var _m = brs_market_new(20260826, "counting-house", undefined);
    brs_market_step(_m, BRS_HIST * BRS_HIST_EVERY + 180);
    var _st = brs_counter_state("counting-house");
    _st.trade = "drink";
    _st.sel = "wine_cask";
    brs_counter_header(_m, _st, 56, _ctop, BRS_BK_W - 112, 64);
    brs_counter_draw(_m, _st, 56, _ctop + 78, BRS_BK_W - 112, _h - _ctop - 118);
    return { surf: _s, ctop: _ctop, ground: _sur.ground, name: "counter" };
}

/// ============================================================================================
/// SHEET 3 - THE SIMULATION
/// ============================================================================================

function brs_bk_sheet_simulation() {
    var _sur = brs_surface("oak", "iron", "cellar", 0);
    var _h = 1180;
    var _s = brs_bk_open(_sur, _h, _sur.panel);
    var _ctop = brs_bk_title(_sur, 56, 44, BRS_BK_W - 112,
        "PRICES MOVE BECAUSE STOCK AND DEMAND MOVE",
        "one seeded market, " + string(BRS_HIST * BRS_HIST_EVERY)
        + " days per chart - no price table anywhere in this product");

    var _m = brs_market_new(515, "cellar", undefined);
    brs_market_step(_m, 900);

    var _pick = ["bread_batch", "wine_cask", "iron_ingot", "spice_jar", "linen_bolt", "pearl_casket"];
    var _cw = (BRS_BK_W - 112) / 2;
    var _ch = (_h - _ctop - 40) / 3;
    for (var _i = 0; _i < 6; _i++) {
        var _x = 56 + (_i % 2) * _cw;
        var _y = _ctop + floor(_i / 2) * _ch;
        var _id = _pick[_i];
        var _sp = brs_ware_spec(_id);
        var _dir = brs_market_trend(_m, _id);
        var _pal = brs_ware_surface(_id, "cellar", _dir);
        // The good itself beside its own chart, so the picture and the number are one object.
        brs_render_parts_raw(brs_map_roles(
            brs_ui_well(_x + 8, _y + 8, _x + 150, _y + _ch - 40, 8, 5, "cloth"),
            { m0: "ground", m1: "edge", m2: "cloth", m3: "edge", m4: "line" }), _sur);
        brs_render_in_rect(brs_ware_parts(_id), _pal, _x + 16, _y + 14, 126, _ch - 60, 0, undefined);
        draw_set_font(fnt_bourse_title);
        draw_set_colour(_sur.line);
        brs_bk_text(fnt_bourse_title, _x + 166, _y + 10, _cw - 190, 1.10,
                    string_upper(_sp.name), _sur.line);
        brs_bk_text(fnt_bourse, _x + 166, _y + 40, _cw - 190, 0.94,
                    "base " + string(_sp.base) + "   elasticity " + string(_sp.elast)
                    + "   spoilage " + string(round(_sp.perish * 100)) + "%/season", _sur.dim);
        brs_spark_draw(_m, _id, _sur, _x + 166, _y + 68, _cw - 200, _ch - 132);
        brs_gauge_draw(_sur, _x + 166, _y + _ch - 58, _cw - 200, 46,
                       brs_market_needle(_m, _id), _dir, "TODAY", brs_market_row(_m, _id).price);
    }
    return { surf: _s, ctop: _ctop, ground: _sur.panel, name: "simulation" };
}

/// ============================================================================================
/// SHEET 4 - ONE GOOD, SIX HALLS
/// ============================================================================================

function brs_bk_sheet_halls() {
    var _sur = brs_surface("oak", "iron", "guildhall", 0);
    var _h = 1120;
    var _s = brs_bk_open(_sur, _h, _sur.panel);
    var _ctop = brs_bk_title(_sur, 56, 44, BRS_BK_W - 112,
        "SIX HALLS, ONE LINE OF CODE",
        "the same cask and the same counter in every hall - the goods keep their own materials, the room does not");

    var _halls = brs_hall_ids();
    var _cw = (BRS_BK_W - 112) / 3;
    var _ch = (_h - _ctop - 40) / 2;
    for (var _i = 0; _i < 6; _i++) {
        var _x = 56 + (_i % 3) * _cw;
        var _y = _ctop + floor(_i / 3) * _ch;
        var _hs = brs_hall(_halls[_i]);
        var _chrome = brs_surface("oak", "iron", _halls[_i], 1);
        // The hall's own ground, as the tile the sample sits on.
        draw_set_colour(_hs.ground);
        draw_rectangle(_x + 8, _y + 6, _x + _cw - 8, _y + _ch - 46, false);
        brs_render_parts_raw(brs_map_roles(
            brs_ui_panel(_x + 22, _y + 18, _x + _cw - 22, _y + _ch - 58, 10, 7, "panel"),
            { m0: "ground", m1: "edge", m2: "panel", m3: "edge", m4: "line" }), _chrome);
        // ⚠️ THREE GOODS AND A FULL WIDGET COLUMN, NOT ONE GOOD AND A GAUGE. The first version left
        // about a fifth of every tile empty - which passed the ink floor (a bounding box cannot see
        // the space inside itself) and failed the question that matters, which is whether a buyer
        // learns anything from the image. A hall sheet exists to show a ROOM, and a room with one
        // barrel in it is a store cupboard.
        brs_render_parts_raw(brs_map_roles(
            brs_ui_well(_x + 30, _y + 34, _x + _cw - 30, _y + _ch - 162, 8, 5, "cloth"),
            { m0: "ground", m1: "edge", m2: "cloth", m3: "edge", m4: "line" }), _chrome);
        var _three = ["wine_cask", "grain_sack", "spice_jar"];
        var _tw = (_cw - 76) / 3;
        for (var _k = 0; _k < 3; _k++) {
            brs_render_in_rect(brs_ware_parts(_three[_k]),
                               brs_ware_surface(_three[_k], _halls[_i], 1),
                               _x + 38 + _k * _tw, _y + 40, _tw, _ch - 214, 0, undefined);
        }
        // ⚠️ EVERY y BELOW IS MEASURED BACK FROM THE CAPTION, which sits at _ch - 40. The first
        // attempt at filling this tile stacked two gauges downward from the well and ran the second
        // one straight through the hall's own name; the pips then ran through the gauge beside
        // them. Adding content to a sparse tile is only an improvement if the additions are placed
        // against the things already in it.
        brs_gauge_draw(_chrome, _x + 30, _y + _ch - 152, _cw * 0.50, 44, 0.62, 1, "WINE", 71);
        brs_gauge_draw(_chrome, _x + 30, _y + _ch - 104, _cw * 0.50, 44, 0.24, -1, "GRAIN", 12);
        brs_pips_draw(_chrome, _x + _cw * 0.56, _y + _ch - 130, 5, 0.6);
        brs_pips_draw(_chrome, _x + _cw * 0.56, _y + _ch - 82, 5, 0.3);
        brs_bk_text(fnt_bourse, _x + _cw * 0.56 + 142, _y + _ch - 139, _cw * 0.22, 0.86,
                    "in stock", _chrome.dim);
        brs_bk_text(fnt_bourse, _x + _cw * 0.56 + 142, _y + _ch - 91, _cw * 0.22, 0.86,
                    "running out", _chrome.dim);
        brs_bk_caption(_sur, _x + _cw * 0.5, _y + _ch - 40, string_upper(_halls[_i]), "",
                       _cw - 24, 1.02);
    }
    return { surf: _s, ctop: _ctop, ground: _sur.panel, name: "halls" };
}

/// ============================================================================================
/// SHEET 5 - RELIEF, AT SIZE
/// ============================================================================================

function brs_bk_sheet_relief() {
    var _sur = brs_surface("oak", "iron", "cellar", 0);
    var _h = 1120;
    var _s = brs_bk_open(_sur, _h, _sur.panel);
    var _ctop = brs_bk_title(_sur, 56, 44, BRS_BK_W - 112,
        "EVERY EDGE IS A LIT WALL",
        "one fixed lamp, up and to the left - a closed outline is the top of a raised shape, never a silhouette");

    // ⛔ THE SECOND ROW EXISTS BECAUSE THE FIRST VERSION WAS A THIRD FULL. Four goods in four tall
    // wells scored 0.11 ink on the gallery density floor - a bounding box cannot see the space
    // inside itself, and this sheet had a great deal of it. The answer to a sparse sheet is more
    // content and never a lower threshold, and the content that belonged here was already implied
    // by the claim: relief is only worth anything if it survives being SMALL, so the sheet now
    // proves that too.
    var _pick = ["wine_cask", "grain_sack", "iron_ingot", "mead_amphora"];
    var _sub = ["six staves, three iron hoops, a bung proud of the belly",
                "the creases stop where the weight is",
                "two authored faces, and the pour ripple across the top",
                "a pointed base, so the stand is part of the good"];
    var _heroBot = _h - 400;
    var _cw = (BRS_BK_W - 112) / 4;
    for (var _i = 0; _i < 4; _i++) {
        var _x = 56 + _i * _cw;
        var _pal = brs_ware_surface(_pick[_i], "cellar", 0);
        brs_render_parts_raw(brs_map_roles(
            brs_ui_well(_x + 10, _ctop + 10, _x + _cw - 10, _heroBot, 10, 7, "cloth"),
            { m0: "ground", m1: "edge", m2: "cloth", m3: "edge", m4: "line" }), _sur);
        brs_render_in_rect(brs_ware_parts(_pick[_i]), _pal,
                           _x + 24, _ctop + 20, _cw - 48, _heroBot - _ctop - 40, 0, undefined);
        brs_bk_caption(_sur, _x + _cw * 0.5, _heroBot + 16,
                       string_upper(brs_ware_spec(_pick[_i]).name), _sub[_i], _cw - 20, 1.05);
    }

    // -- AND THE SAME ENGINE AT SHELF SIZE --------------------------------------------------------
    var _sy = _heroBot + 96;
    brs_bk_text(fnt_bourse_title, 56, _sy, BRS_BK_W - 112, 1.30,
                "AND IT STILL READS AT A TENTH THE SIZE", _sur.line);
    brs_bk_text(fnt_bourse, 56, _sy + 44, BRS_BK_W - 112, 1.02,
                "the same twelve goods, the same code, drawn into a 110px cell - which is the size "
                + "they will be on your shelf", _sur.dim);
    _sy += 78;
    var _small = ["wine_cask", "grain_sack", "iron_ingot", "mead_amphora", "cheese_wheel",
                  "hemp_coil", "tool_chest", "spice_jar", "linen_bolt", "charcoal_sack",
                  "gilt_icon", "shoe_ring"];
    var _sw = (BRS_BK_W - 112) / 12;
    for (var _i = 0; _i < 12; _i++) {
        var _x2 = 56 + _i * _sw;
        brs_render_parts_raw(brs_map_roles(
            brs_ui_well(_x2 + 4, _sy, _x2 + _sw - 4, _sy + 128, 6, 4, "cloth"),
            { m0: "ground", m1: "edge", m2: "cloth", m3: "edge", m4: "line" }), _sur);
        brs_render_in_rect(brs_ware_parts(_small[_i]),
                           brs_ware_surface(_small[_i], "cellar", 0),
                           _x2 + 10, _sy + 6, _sw - 20, 116, 0, undefined);
    }

    // The lamp, stated, bottom left - a legend the picture can be checked against.
    brs_bk_text(fnt_bourse, 56, _h - 46, BRS_BK_W - 112, 1.0,
                "lamp: (" + string_format(BRS_LX, 1, 3) + ", " + string_format(BRS_LY, 1, 3)
                + ")   five ramp stops per material   fourteen materials   forty-eight goods",
                _sur.dim);
    return { surf: _s, ctop: _ctop, ground: _sur.panel, name: "relief" };
}

/// ============================================================================================
/// SHEET 6 - THE GAUGE
/// ============================================================================================

function brs_bk_sheet_gauge() {
    var _sur = brs_surface("oak", "iron", "harbour", 0);
    var _h = 900;
    var _s = brs_bk_open(_sur, _h, _sur.panel);
    var _ctop = brs_bk_title(_sur, 56, 44, BRS_BK_W - 112,
        "A NUMBER SAYS WHAT IT COSTS. A GAUGE SAYS WHETHER TO BUY",
        "a price means nothing until you know the year it sat in - the needle answers that without arithmetic");

    var _m = brs_market_new(2026, "harbour", undefined);
    brs_market_step(_m, 640);

    // ⛔ THE SHEET IS TWO COLUMNS AND THE FIRST VERSION WAS ONE-AND-A-HALF. Everything below the
    // three sample gauges was laid out down the left at a running y, and the history chart was then
    // hung off the RIGHT at a y computed backwards from the bottom - so the "STOCK, AGAINST THE
    // COVER" heading was painted straight across the chart. Two explicit columns cannot do that.
    // ⛔ THE COLUMNS DO NOT TOUCH, AND THE FIRST TWO-COLUMN VERSION STILL DID. Left content ended at
    // x=976 and the right column began at 860, so "CHEAP - low in its own year" ran underneath the
    // right-hand heading. A column boundary has to be ONE number that both sides are measured
    // against - here BRS_BK_GUT - or the two drift apart on the next edit.
    var _colw = 690;                    // left content: 96 .. 96+_colw
    var _rx = 96 + _colw + 70;          // right column starts here, and nothing on the left crosses it
    var _y = _ctop + 10;
    var _lab = ["CHEAP", "MIDDLE", "DEAR"];
    var _pick = ["grain_sack", "wine_cask", "spice_jar"];
    var _t = [0.10, 0.50, 0.92];
    var _dir = [-1, 0, 1];
    for (var _i = 0; _i < 3; _i++) {
        var _row = brs_market_row(_m, _pick[_i]);
        brs_gauge_draw(_sur, 96, _y, _colw - 180, 78, _t[_i], _dir[_i],
                       string_upper(brs_ware_spec(_pick[_i]).name), _row.price);
        brs_trend_draw(_sur, 96 + _colw - 140, _y + 52, 26, _dir[_i]);
        brs_bk_text(fnt_bourse_title, 96 + _colw - 112, _y + 40, 112, 1.10, _lab[_i], _sur.line);
        _y += 106;
    }
    brs_bk_text(fnt_bourse, 96, _y - 6, _colw, 1.04,
                "same good, same scale, three different days - the needle is the whole widget",
                _sur.dim);
    _y += 34;

    // -- LEFT COLUMN, continued: the spread, then the stock pips -------------------------------
    brs_bk_text(fnt_bourse_title, 96, _y + 6, _colw, 1.30,
                "THE MERCHANT'S CUT, SHOWN", _sur.line);
    _y += 60;
    brs_spread_draw(_m, "spice_jar", _sur, 96, _y, _colw - 30, 44);
    _y += 62;
    brs_bk_text(fnt_bourse, 96, _y, _colw, 1.04,
                "the gap widens as stock runs out - no shop asset on the shelf shows this at all",
                _sur.dim);
    _y += 44;

    brs_bk_text(fnt_bourse_title, 96, _y, _colw, 1.30,
                "STOCK, AGAINST THE COVER THE MARKET WANTS", _sur.line);
    _y += 46;
    var _fr = [1.0, 0.6, 0.2];
    for (var _i = 0; _i < 3; _i++) {
        brs_pips_draw(_sur, 104, _y + 14, 9, _fr[_i]);
        brs_bk_text(fnt_bourse, 380, _y + 2, 260, 1.04,
                    string(round(_fr[_i] * 100)) + "% of cover", _sur.dim);
        _y += 46;
    }

    // -- RIGHT COLUMN: the year the needle is read against, and the good it belongs to ---------
    var _rw = BRS_BK_W - _rx - 56;
    var _ry = _ctop + 10;
    brs_bk_text(fnt_bourse_title, _rx, _ry, _rw, 1.30, "THE YEAR BEHIND THE NEEDLE", _sur.line);
    _ry += 40;
    // Two short lines rather than one long one: a single sentence scaled to fit this column comes
    // out at half the size of everything around it and reads as fine print.
    brs_bk_text(fnt_bourse, _rx, _ry, _rw, 1.02,
                "the needle's band is the tenth to ninetieth percentile", _sur.dim);
    _ry += 26;
    brs_bk_text(fnt_bourse, _rx, _ry, _rw, 1.02,
                "so one caravan cannot flatten the scale for a year", _sur.dim);
    _ry += 34;
    brs_spark_draw(_m, "wine_cask", _sur, _rx, _ry, _rw, 292);
    _ry += 312;
    // The good itself, in a well, so the right column is not a chart floating on its own.
    brs_render_parts_raw(brs_map_roles(
        brs_ui_well(_rx, _ry, BRS_BK_W - 56, _h - 60, 10, 7, "cloth"),
        { m0: "ground", m1: "edge", m2: "cloth", m3: "edge", m4: "line" }), _sur);
    brs_render_in_rect(brs_ware_parts("wine_cask"), brs_ware_surface("wine_cask", "harbour", 1),
                       _rx + 30, _ry + 14, (BRS_BK_W - 86 - _rx) * 0.44, _h - 88 - _ry, 0, undefined);
    brs_bk_caption(_sur, _rx + (BRS_BK_W - 56 - _rx) * 0.72, _ry + 40, "CASK OF WINE",
                   "base 58   elasticity 1.30   oak + iron",
                   (BRS_BK_W - 56 - _rx) * 0.52, 1.06);
    return { surf: _s, ctop: _ctop, ground: _sur.panel, name: "gauge" };
}

/// ============================================================================================
/// SHEET 7 - THE EIGHT TRADES
/// ============================================================================================

function brs_bk_sheet_trades() {
    var _sur = brs_surface("oak", "iron", "caravanserai", 0);
    // 1080, not 1020: the bottom row's season labels and the legend under them were within three
    // pixels of touching. A layout that is CLOSE to colliding is one edit from colliding.
    var _h = 1080;
    var _s = brs_bk_open(_sur, _h, _sur.panel);
    var _ctop = brs_bk_title(_sur, 56, 44, BRS_BK_W - 112,
        "EIGHT TRADES, AND THE SEASONS MOVE THEM DIFFERENTLY",
        "a harvest floods provisions and does nothing to metal - production and demand are authored separately on purpose");

    var _tr = brs_trade_ids();
    var _cw = (BRS_BK_W - 112) / 4;
    var _ch = (_h - _ctop - 30) / 2;
    var _seasons = ["SPR", "SUM", "HAR", "WIN"];
    for (var _i = 0; _i < 8; _i++) {
        var _x = 56 + (_i % 4) * _cw;
        var _y = _ctop + floor(_i / 4) * _ch;
        var _w6 = brs_trade_wares(_tr[_i]);
        var _pal = brs_ware_surface(_w6[0], "caravanserai", 0);
        brs_render_parts_raw(brs_map_roles(
            brs_ui_well(_x + 8, _y + 6, _x + _cw - 8, _y + _ch * 0.40, 8, 5, "cloth"),
            { m0: "ground", m1: "edge", m2: "cloth", m3: "edge", m4: "line" }), _sur);
        brs_render_in_rect(brs_ware_parts(_w6[0]), _pal,
                           _x + 20, _y + 12, _cw - 40, _ch * 0.40 - 22, 0, undefined);
        // ⛔ THE CAPTION SITS ABOVE THE BARS' TALLEST REACH, AND THE FIRST VERSION DID NOT. The bars
        // grow UPWARD from their baseline by up to 1.95 x the bar unit, and the trade name was
        // placed a fixed distance under the well - so on all eight tiles the bars were painted
        // straight through the words and "GRAIN & PROVISION" was unreadable. Found by opening the
        // sheet; no ink check can see it, because overprinted text is ink exactly where ink belongs.
        brs_bk_caption(_sur, _x + _cw * 0.5, _y + _ch * 0.44, string_upper(brs_trade_name(_tr[_i])),
                       "", _cw - 16, 1.00);
        // The season bars: production over demand, four seasons, as paired bevelled bars.
        var _by = _y + _ch * 0.92;
        var _bw = (_cw - 60) / 4;
        for (var _k = 0; _k < 4; _k++) {
            var _bx = _x + 30 + _k * _bw;
            var _yv = brs_season_yield(_tr[_i], _k);
            var _wv = brs_season_want(_tr[_i], _k);
            var _hy = _yv * 44, _hw2 = _wv * 44;
            brs_render_parts_raw(brs_map_roles(
                brs_raise([[_bx, _by - _hy], [_bx + _bw * 0.36, _by - _hy],
                           [_bx + _bw * 0.36, _by], [_bx, _by]], 3, 2, "rise"),
                { m0: "ground", m1: "edge", m2: "rise", m3: "rise", m4: "paper" }), _sur);
            brs_render_parts_raw(brs_map_roles(
                brs_raise([[_bx + _bw * 0.42, _by - _hw2], [_bx + _bw * 0.78, _by - _hw2],
                           [_bx + _bw * 0.78, _by], [_bx + _bw * 0.42, _by]], 3, 2, "fall"),
                { m0: "ground", m1: "edge", m2: "fall", m3: "fall", m4: "paper" }), _sur);
            brs_bk_text(fnt_bourse, _bx + _bw * 0.10, _by + 6, _bw * 0.72, 0.80,
                        _seasons[_k], _sur.dim);
        }
    }
    brs_bk_text(fnt_bourse, 56, _h - 40, BRS_BK_W - 112, 1.02,
                "left bar: production   right bar: demand   both per season, per trade, "
                + "from one readable table", _sur.dim);
    return { surf: _s, ctop: _ctop, ground: _sur.panel, name: "trades" };
}

/// ============================================================================================
/// SHEET 8 - THE MATERIALS
/// ============================================================================================

function brs_bk_sheet_materials() {
    var _sur = brs_surface("oak", "iron", "frost-market", 0);
    var _h = 1000;
    var _s = brs_bk_open(_sur, _h, _sur.panel);
    var _ctop = brs_bk_title(_sur, 56, 44, BRS_BK_W - 112,
        "FOURTEEN MATERIALS, FIVE STOPS EACH",
        "authored in Oklch so the spacing survives re-hueing - a ware picks two of these and its geometry never changes");

    var _ids = brs_material_ids();
    var _cw = (BRS_BK_W - 112) / 7;
    var _ch = (_h - _ctop - 40) / 2;
    for (var _i = 0; _i < 14; _i++) {
        var _x = 56 + (_i % 7) * _cw;
        var _y = _ctop + floor(_i / 7) * _ch;
        var _m = brs_material(_ids[_i]);
        // The ramp, as five bevelled tiles - drawn with the relief engine so the swatch is made of
        // the same thing the goods are.
        var _sw = (_cw - 24) / 5;
        for (var _k = 0; _k < 5; _k++) {
            var _role = "m" + string(_k);
            brs_render_parts_raw(brs_map_roles(
                brs_raise(brs_round_rect_pts(_x + 12 + _k * _sw, _y + 8,
                                             _x + 12 + (_k + 1) * _sw - 3, _y + 78, 5, 3),
                          5, 2, _role),
                { m0: "ground", m1: "edge", m2: _role, m3: _role, m4: "paper" }),
                brs_surface(_ids[_i], _ids[_i], "frost-market", 0));
        }
        // A ware made of it, so a swatch is never just a swatch.
        var _demo = ["wine_cask", "plank_stack", "iron_ingot", "copper_stack", "shoe_ring",
                     "silver_bar", "grain_sack", "linen_bolt", "raw_fleece", "hide_roll",
                     "honey_pot", "spirit_bottle", "cheese_wheel", "cut_stone"];
        var _pal2 = brs_surface(_ids[_i], "iron", "frost-market", 0);
        brs_render_parts_raw(brs_map_roles(
            brs_ui_well(_x + 12, _y + 88, _x + _cw - 12, _y + _ch - 52, 8, 5, "cloth"),
            { m0: "ground", m1: "edge", m2: "cloth", m3: "edge", m4: "line" }), _sur);
        brs_render_in_rect(brs_ware_parts(_demo[_i]), _pal2,
                           _x + 20, _y + 94, _cw - 40, _ch - 158, 0, undefined);
        brs_bk_caption(_sur, _x + _cw * 0.5, _y + _ch - 46, string_upper(_ids[_i]),
                       "L " + string_format(_m.L.m2, 1, 2), _cw - 16, 0.92);
    }
    return { surf: _s, ctop: _ctop, ground: _sur.panel, name: "materials" };
}

/// ============================================================================================
/// THE COVER
///
/// ⛔ THE COVER IS DRAWN BY THE PRODUCT, NOT BY AN IMAGE MODEL AND NOT BY A SCREENSHOT. For this
/// package that is not a preference, it is a consistency requirement: the licence states that no
/// good in it was generated by or derived from any image dataset, and the listing's headline claim
/// is that everything you can see was drawn from data by the shipped GML. A cover made any other
/// way would be the one picture on the page that the product did not make.
///
/// It is DESIGNED rather than captured: a chosen arrangement of six goods on a counter, a title
/// set in the package's own face, and one gauge - not a frame of the demo with a band over it.
/// ============================================================================================

#macro BRS_COVER_W 630
#macro BRS_COVER_H 500

function brs_bk_sheet_cover() {
    var _sur = brs_surface("oak", "iron", "cellar", 1);
    var _s = surface_create(BRS_COVER_W, BRS_COVER_H);
    surface_set_target(_s);
    draw_clear_alpha(_sur.ground, 1);

    var _m = brs_market_new(20260826, "cellar", undefined);
    brs_market_step(_m, BRS_HIST * BRS_HIST_EVERY + 240);

    // -- THE PRICE CURVE AS THE HORIZON ----------------------------------------------------------
    // The product's signature graphic, drawn full width and bleeding off both edges, filled as a
    // solid mass so it reads as a landscape rather than as a chart with a frame. It is a REAL
    // trace from the market built above, not a decorative squiggle - which matters, because the
    // whole page's claim is that everything on it was drawn by the product from its own data.
    {
        var _r = brs_market_row(_m, "wine_cask");
        var _bd = brs_market_range(_m, "wine_cask");
        var _n = array_length(_r.hist);
        // The curve's ceiling sits BELOW the type block, so its tallest spike cannot run through
        // the subtitle. A background graphic that collides with the words over it is not layering,
        // it is a collision that happens to be behind something.
        var _top = 252, _bot = 356;
        draw_set_colour(brs_render_colour(_sur, "edge"));
        draw_primitive_begin(pr_trianglestrip);
        for (var _i = 0; _i < _n; _i++) {
            var _v = _r.hist[(_r.hh + _i) % _n];
            var _px2 = -20 + (_i / (_n - 1)) * (BRS_COVER_W + 40);
            var _py2 = _bot - ((_v - _bd[0]) / max(0.0001, _bd[1] - _bd[0])) * (_bot - _top);
            draw_vertex(_px2, _py2);
            draw_vertex(_px2, BRS_COVER_H + 20);
        }
        draw_primitive_end();
        // The line itself, brighter, so the horizon has an edge.
        draw_set_colour(brs_render_colour(_sur, "accent"));
        for (var _i = 1; _i < _n; _i++) {
            var _v0 = _r.hist[(_r.hh + _i - 1) % _n], _v1 = _r.hist[(_r.hh + _i) % _n];
            draw_line_width(-20 + ((_i - 1) / (_n - 1)) * (BRS_COVER_W + 40),
                            _bot - ((_v0 - _bd[0]) / max(0.0001, _bd[1] - _bd[0])) * (_bot - _top),
                            -20 + (_i / (_n - 1)) * (BRS_COVER_W + 40),
                            _bot - ((_v1 - _bd[0]) / max(0.0001, _bd[1] - _bd[0])) * (_bot - _top),
                            2);
        }
    }

    // -- THE COUNTER, AND FIVE GOODS ON IT, LARGE -------------------------------------------------
    brs_render_parts_raw(brs_map_roles(
        brs_ui_panel(-20, 356, BRS_COVER_W + 20, BRS_COVER_H + 20, 16, 10, "panel"),
        { m0: "ground", m1: "edge", m2: "panel", m3: "edge", m4: "line" }), _sur);
    var _pick = ["wine_cask", "grain_sack", "copper_stack", "hemp_coil", "gilt_icon"];
    var _cw = BRS_COVER_W / 5;
    for (var _i = 0; _i < 5; _i++) {
        var _id = _pick[_i];
        var _dir = brs_market_trend(_m, _id);
        // The goods OVERLAP the counter's top edge and are cut by the bottom of the frame, which is
        // what puts them in the room rather than in a row of thumbnails.
        brs_render_in_rect(brs_ware_parts(_id), brs_ware_surface(_id, "cellar", _dir),
                           _i * _cw + 6, 300, _cw - 12, 214, 0, undefined);
    }

    // -- THE TITLE BLOCK, LEFT ALIGNED ------------------------------------------------------------
    //
    // ⛔ NO EMBOSS ON THE WORDMARK, AND brs_text_fit IS NOT USED HERE. The relief lettering that
    // suits a legend struck round a medal does not suit a cover wordmark: brs_text_relief scales
    // its offset with the point size, so at seventy-odd pixels the two passes separate far enough
    // to read as a double exposure rather than as depth - measured by looking at two covers. One
    // crisp pass, and the depth on this cover comes from the OBJECTS, which is where it should.
    //
    // Left aligned, all three lines on one margin. Centring the title over a left-aligned subtitle
    // is two competing axes on a 630px canvas, and the eye finds neither.
    // ⚠️ THE TWO LINES BELOW THE TITLE ARE PLACED FROM ITS MEASURED HEIGHT, NOT FROM A GUESSED
    // OFFSET. A hand-picked y under a scaled string is a y that is correct at exactly one scale:
    // the first draft put the subtitle at 126 under a title that turned out to be 94px tall from
    // y=40, and the wordmark was painted straight through both lines under it. brs_bk_text returns
    // the scale it actually used, which is the only number that knows what happened.
    var _ty = 36;
    var _tsc = brs_bk_text(fnt_bourse_title, 44, _ty, BRS_COVER_W - 88, 4.6, "BOURSE",
                           brs_render_colour(_sur, "paper"));
    draw_set_font(fnt_bourse_title);
    _ty += string_height("BOURSE") * _tsc + 10;
    brs_bk_text(fnt_bourse, 46, _ty, BRS_COVER_W - 92, 1.24,
                "a living market that draws its own goods", brs_render_colour(_sur, "line"));
    draw_set_font(fnt_bourse);
    _ty += string_height("M") * 1.24 + 8;
    brs_bk_text(fnt_bourse_title, 46, _ty, BRS_COVER_W - 92, 1.00,
                "48 TRADE GOODS  -  DRAWN FROM DATA  -  PURE GML, NO SPRITES",
                brs_render_colour(_sur, "accent"));

    return { surf: _s, ctop: 150, ground: _sur.ground, name: "cover", bleed: true };
}

/// ============================================================================================
/// THE GIF - the one thing a still image cannot show
///
/// A listing GIF for this product has exactly one job: prove the prices MOVE. Everything else on
/// the page is a still, and a still of a market is indistinguishable from a still of a price table.
/// ============================================================================================

#macro BRS_GIF_W 660
#macro BRS_GIF_H 372
#macro BRS_GIF_N 72

function brs_gif_frame(_m, _sur, _w, _h) {
    draw_clear_alpha(brs_render_colour(_sur, "ground"), 1);
    var _pick = ["wine_cask", "spice_jar"];
    var _pw = _w * 0.46;

    // Left: two goods with live gauges.
    for (var _i = 0; _i < 2; _i++) {
        var _id = _pick[_i];
        var _dir = brs_market_trend(_m, _id);
        var _pal = brs_ware_surface(_id, "cellar", _dir);
        var _py = 12 + _i * (_h - 24) * 0.5;
        var _ph = (_h - 34) * 0.5;
        brs_render_parts_raw(brs_map_roles(
            brs_ui_well(12, _py, 12 + _pw, _py + _ph * 0.70, 8, 5, "cloth"),
            { m0: "ground", m1: "edge", m2: "cloth", m3: "edge", m4: "line" }), _sur);
        brs_render_in_rect(brs_ware_parts(_id), _pal, 24, _py + 6, _pw - 24, _ph * 0.70 - 12,
                           0, undefined);
        brs_text_line(brs_ware_spec(_id).name, 14, _py + _ph * 0.72, _pw - 20, 13,
                      brs_render_colour(_sur, "line"), false);
        brs_gauge_draw(_sur, 12, _py + _ph * 0.78, _pw, _ph * 0.22, brs_market_needle(_m, _id),
                       _dir, "", brs_market_row(_m, _id).price);
    }

    // Right: the year, the spread, and the calendar.
    var _rx = 24 + _pw;
    var _rw = _w - _rx - 12;
    brs_text_line("PRICE, LAST " + string(BRS_HIST * BRS_HIST_EVERY) + " DAYS", _rx, 12, _rw, 12,
                  brs_render_colour(_sur, "dim"), true);
    brs_spark_draw(_m, "wine_cask", _sur, _rx, 30, _rw, _h * 0.38);
    brs_spread_draw(_m, "wine_cask", _sur, _rx, 30 + _h * 0.38 + 14, _rw, 24);
    var _season = (_m.day div BRS_SEASON_DAYS) % BRS_SEASONS;
    brs_text_line(string_upper(brs_season_name(_season)) + ", DAY "
                  + string(_m.day mod BRS_SEASON_DAYS), _rx, 30 + _h * 0.38 + 48, _rw, 16,
                  brs_render_colour(_sur, "accent"), true);
    if (_m.ev >= 0) {
        var _tab = brs_event_table();
        brs_text_line(string_upper(_m.evName) + " - " + string_upper(_m.evTrade),
                      _rx, 30 + _h * 0.38 + 72, _rw, 14,
                      brs_render_colour(_sur, (_tab[_m.ev].yield < 1) ? "fall" : "rise"), true);
    } else {
        brs_text_line("STOCK AND DEMAND, EVERY DAY", _rx, 30 + _h * 0.38 + 72, _rw, 14,
                      brs_render_colour(_sur, "dim"), false);
    }
    // Stock, under the calendar - it fills the quadrant that was otherwise empty, and it is the one
    // number that explains why the price above it is moving.
    var _sr = brs_market_row(_m, "wine_cask");
    brs_text_line("STOCK", _rx, 30 + _h * 0.38 + 100, _rw, 12,
                  brs_render_colour(_sur, "dim"), true);
    brs_pips_draw(_sur, _rx + 8, 30 + _h * 0.38 + 126, 6,
                  _sr.stock / max(0.0001, _sr.daily * BRS_COVER));
    brs_text_line(string(floor(_sr.stock)) + " units of cover " + string(BRS_COVER) + " days",
                  _rx, 30 + _h * 0.38 + 146, _rw, 12, brs_render_colour(_sur, "dim"), false);
    brs_text_line("48 goods drawn from data - no sprites", _rx, _h - 22, _rw, 12,
                  brs_render_colour(_sur, "dim"), false);
}

function brs_gif_run() {
    var _sur = brs_surface("oak", "iron", "cellar", 0);
    var _m = brs_market_new(20260826, "cellar", undefined);
    brs_market_step(_m, BRS_HIST * BRS_HIST_EVERY + 120);
    var _saved = 0;
    for (var _f = 0; _f < BRS_GIF_N; _f++) {
        global.brs_stage = 200 + _f;
        var _s = surface_create(BRS_GIF_W, BRS_GIF_H);
        surface_set_target(_s);
        brs_gif_frame(_m, _sur, BRS_GIF_W, BRS_GIF_H);
        surface_reset_target();
        // Zero-padded, so a lexical sort is a temporal sort - ffmpeg globs, and frame 10 sorting
        // before frame 2 is a GIF that plays its own history out of order.
        var _n = string(_f);
        while (string_length(_n) < 3) _n = "0" + _n;
        surface_save(_s, "gif_" + _n + ".png");
        surface_free(_s);
        _saved += 1;
        // Six days per frame: seventy-two frames is more than a year, so the GIF contains at least
        // one full seasonal swing and usually two events.
        brs_market_step(_m, 6);
    }
    var _f2 = file_text_open_write("brs_gif.json");
    file_text_write_string(_f2, "{\"crash\":false,\"frames\":" + string(_saved)
        + ",\"w\":" + string(BRS_GIF_W) + ",\"h\":" + string(BRS_GIF_H) + "}");
    file_text_close(_f2);
}

/// ============================================================================================
/// THE RUNNER
/// ============================================================================================

/// ⛔ ONE SHEET AT A TIME: DRAW, POP THE TARGET, MEASURE, SAVE, FREE.
///
/// The first version built all eight sheets and then judged them in a second loop, which is how the
/// donor's runner is written and which CANNOT work here, because surface_set_target is a STACK.
/// Eight sheets built back to back leave eight targets pushed; one surface_reset_target per
/// iteration pops the LAST one, so the first sheet is still on the stack when the loop tries to
/// free it and the run dies with "Surface in use via surface_set_target(). It can not be freed
/// until it has been removed from the surface stack." - at stage 108, pointing at the last sheet,
/// when the fault was in the first. Popping each target immediately is also six fewer 6 MB surfaces
/// alive at once.
function brs_bake_run() {
    var _json = "{\"crash\":false,\"product\":\"Bourse\",\"sheets\":[";
    var _bad = 0;
    var _n = 9;
    for (var _i = 0; _i < _n; _i++) {
        global.brs_stage = 101 + _i;
        var _sh;
        switch (_i) {
            case 8: _sh = brs_bk_sheet_cover(); break;
            case 0: _sh = brs_bk_sheet_corpus(); break;
            case 1: _sh = brs_bk_sheet_counter(); break;
            case 2: _sh = brs_bk_sheet_simulation(); break;
            case 3: _sh = brs_bk_sheet_halls(); break;
            case 4: _sh = brs_bk_sheet_relief(); break;
            case 5: _sh = brs_bk_sheet_gauge(); break;
            case 6: _sh = brs_bk_sheet_trades(); break;
            default: _sh = brs_bk_sheet_materials(); break;
        }
        surface_reset_target();
        var _g = brs_bk_probe(_sh.ground);
        var _res = brs_bk_judge(_sh.name, _sh.surf, _g, _sh.ctop,
                                variable_struct_exists(_sh, "bleed") ? _sh.bleed : false);
        if (!_res.ok) _bad += 1;
        surface_save(_sh.surf, "sheet_" + string(_i + 1) + "_" + _sh.name + ".png");
        surface_free(_sh.surf);
        if (_i > 0) _json += ",";
        _json += "{\"n\":\"" + _sh.name + "\",\"ok\":" + (_res.ok ? "true" : "false")
              + ",\"why\":\"" + string_replace_all(_res.reason, "\"", "'") + "\"}";
    }
    _json += "],\"bad\":" + string(_bad) + "}";
    var _f = file_text_open_write("brs_bake.json");
    file_text_write_string(_f, _json);
    file_text_close(_f);
}
