{
  "$GMScript": "v1",
  "%Name": "brs_geom",
  "isCompatibility": false,
  "isDnD": false,
  "name": "brs_geom",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}