{
  "$GMScript": "v1",
  "%Name": "brs_gauge",
  "isCompatibility": false,
  "isDnD": false,
  "name": "brs_gauge",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}