/// BOURSE - brs_gauge. A price you can read without reading a number.
///
/// ⛔ THE GAUGE IS THE PRODUCT'S ONE INTERFACE OPINION, AND IT IS THIS: A NUMBER TELLS YOU WHAT A
/// THING COSTS AND A GAUGE TELLS YOU WHETHER TO BUY IT. "41 coin" answers nothing on its own - 41
/// against a year that ran from 28 to 63 is a bargain, and 41 against a year that ran from 12 to 44
/// is the top of the market. The needle says which, at a glance, from across the room, and the
/// number is printed beside it for the player who wants to do the arithmetic anyway.
///
/// Three widgets, and they are drawn with the SAME relief engine as the goods, against the same
/// lamp: a track sunk into the counter, a needle raised out of it, pips punched into the wood.
/// That is the whole reason this does not look like a GameMaker default - there is no windowskin
/// here, no nine-slice and no sprite, only outlines handed to brs_bevel.
///
/// -- COORDINATES ARE PIXELS IN THIS FILE --------------------------------------------------------
/// The corpus is authored in a unit box and placed by the renderer. The interface is not: a panel
/// is built at the pixel coordinates it will occupy and drawn with brs_render_parts_raw, because a
/// bevel that scales with a widget's width is a bevel that is four pixels thick on a wide gauge and
/// one pixel thick on a narrow one, and the two then read as different materials.
/// ============================================================================================

/// The height of a gauge track, as a fraction of the gauge's own height.
#macro BRS_TRACK_H 0.44

/// ============================================================================================
/// THE PRICE GAUGE
/// ============================================================================================

/// A sunk track, the historic band inside it, and the needle at today's price.
///
/// _dir is the trend from brs_market_trend, and it selects the needle's colour through the `trend`
/// role - so a rising price is green whatever hall the market is in, and the palette decided how
/// bright that green has to be to clear this hall's panel.
/// ⚠️ AN EMPTY LABEL MEANS "NO CAPTION ROW", NOT "A BLANK CAPTION ROW". Measured by looking at the
/// baked market screen: a plate draws the ware's name itself at heading size and passed "" here, so
/// every gauge reserved a caption row it never used, the track was squeezed into the bottom of it,
/// and the price figure floated in mid-air a long way above its own bar. Reserving nothing when
/// there is nothing to reserve lets the track take the whole widget and puts the figure ON it.
function brs_gauge_draw(_pal, _x, _y, _w, _h, _t, _dir, _label, _price) {
    var _bare = (_label == "");
    var _th = _bare ? _h * 0.80 : _h * BRS_TRACK_H;
    var _ty = _y + _h - _th;
    var _parts = [];

    // The track: a sunk well, in the hall's panel colour, with the bevel lit from inside.
    brs_append(_parts, brs_map_roles(
        brs_ui_well(_x, _ty, _x + _w, _ty + _th, _th * 0.45, _th * 0.28, "panel"),
        { m0: "ground", m1: "edge", m2: "panel", m3: "edge", m4: "line" }));
    brs_render_parts_raw(_parts, _pal);

    // The band: the part of the track the price has actually visited. Drawn as a flat fill rather
    // than in relief, because it is INFORMATION printed on the track and not a physical thing -
    // the same distinction the stencil on a crate makes against the crate.
    var _inx = _x + _th * 0.30;
    var _inw = _w - _th * 0.60;
    draw_set_colour(brs_render_colour(_pal, "dim"));
    draw_rectangle(_inx, _ty + _th * 0.34, _inx + _inw, _ty + _th * 0.66, false);

    // The needle. A raised wedge, not a line: a line at this size is one pixel and vanishes on a
    // busy shelf, and the wedge carries the trend colour across enough area to be seen.
    var _nx = _inx + clamp(_t, 0, 1) * _inw;
    var _nh = _th * 0.92;
    var _pt = [[_nx, _ty - _nh * 0.30], [_nx + _th * 0.24, _ty + _th * 0.42],
               [_nx, _ty + _th * 0.86], [_nx - _th * 0.24, _ty + _th * 0.42]];
    brs_render_parts_raw(brs_map_roles(brs_raise(_pt, _th * 0.20, 2, "trend"),
        // ⚠️ FOUR OF THE FIVE STOPS CARRY THE TREND COLOUR, AND THE FIRST VERSION GAVE IT TWO. A
        // needle is a small wedge, so most of its pixels are BEVEL WALL rather than face - with the
        // walls painted in neutral greys the whole widget read as silver whichever way the market
        // was going, which is the one thing this widget exists not to do. Measured by looking at the
        // baked gauge sheet: three needles, three directions, one colour.
        { m0: "shadow", m1: "trend", m2: "trend", m3: "trend", m4: "paper" }), _pal);

    // The two end stops, so a needle pinned at an extreme still reads as pinned AT something.
    draw_set_colour(brs_render_colour(_pal, "line"));
    draw_rectangle(_inx - 1, _ty + _th * 0.18, _inx + 1, _ty + _th * 0.82, false);
    draw_rectangle(_inx + _inw - 1, _ty + _th * 0.18, _inx + _inw + 1, _ty + _th * 0.82, false);

    // The label and the figure. The label is scaled to its own space (see brs_render's header: this
    // wing has shipped an overprinted caption twice), and the figure is right-aligned so a column of
    // gauges lines its numbers up.
    var _px = _bare ? max(10, _th * 0.62) : max(9, _h * 0.30);
    var _fig = string(round(_price));
    draw_set_font(fnt_bourse_title);
    var _base = max(1, string_height("M"));
    var _fw = string_width(_fig) * (_px / _base);
    if (_bare) {
        // No caption row: the figure sits INSIDE the track, hard against its right stop, where a
        // merchant would chalk it.
        brs_text_line(_fig, _x + _w - _fw - _th * 0.42, _ty + _th * 0.18, _w * 0.42, _px,
                      brs_render_colour(_pal, "trend"), true);
    } else {
        brs_text_line(_label, _x, _y, _w * 0.62, _px, brs_render_colour(_pal, "line"), false);
        brs_text_line(_fig, _x + _w - _fw, _y, _w * 0.36, _px,
                      brs_render_colour(_pal, "trend"), true);
    }
    return _th;
}

/// ============================================================================================
/// THE HISTORY TRACE
/// ============================================================================================

/// The remembered price history as a filled trace under a stroked line.
///
/// ⚠️ THE FILL IS WHY THIS READS AT SIXTY PIXELS TALL. A bare polyline of ninety-six samples is one
/// pixel wide everywhere - the renderer floors it there - so at a glance it is a grey smear at some
/// height. Filling the area beneath turns the chart into a SHAPE, and a shape has a silhouette the
/// eye reads before it reads anything else.
function brs_spark_draw(_m, _id, _pal, _x, _y, _w, _h) {
    var _r = brs_market_row(_m, _id);
    if (is_undefined(_r)) return;
    // THE FULL RANGE, not the needle's trimmed band - see brs_market_range for why the two differ
    // and for the trace that ran out of its own panel when they did not.
    var _b = brs_market_range(_m, _id);
    var _n = array_length(_r.hist);

    // The chart ground: a sunk panel, so the trace sits IN the counter.
    brs_render_parts_raw(brs_map_roles(
        brs_ui_well(_x, _y, _x + _w, _y + _h, 4, 3, "panel"),
        { m0: "ground", m1: "edge", m2: "panel", m3: "edge", m4: "line" }), _pal);

    // The base line at the ware's base price, if it falls inside the band. This is the reference a
    // trader actually wants: above it the good is dear, below it cheap.
    var _base = brs_ware_spec(_id).base;
    if (_base > _b[0] && _base < _b[1]) {
        var _by = _y + _h - ((_base - _b[0]) / max(0.0001, _b[1] - _b[0])) * _h;
        draw_set_colour(brs_render_colour(_pal, "dim"));
        for (var _i = 0; _i < _w; _i += 6) draw_rectangle(_x + _i, _by, _x + _i + 3, _by + 1, false);
    }

    // The trace. Oldest sample first: the ring buffer's head is the NEXT slot to write, so the
    // oldest sample is at the head and reading from index 0 draws the year in the wrong order -
    // which looks entirely plausible and is exactly backwards.
    var _pts = array_create(_n);
    for (var _i = 0; _i < _n; _i++) {
        var _v = _r.hist[(_r.hh + _i) % _n];
        _pts[_i] = [_x + (_i / (_n - 1)) * _w,
                    _y + _h - ((_v - _b[0]) / max(0.0001, _b[1] - _b[0])) * _h];
    }
    draw_set_colour(brs_render_colour(_pal, "accent"));
    draw_set_alpha(0.34);
    draw_primitive_begin(pr_trianglestrip);
    for (var _i = 0; _i < _n; _i++) {
        draw_vertex(_pts[_i][0], _pts[_i][1]);
        draw_vertex(_pts[_i][0], _y + _h);
    }
    draw_primitive_end();
    draw_set_alpha(1.0);
    draw_set_colour(brs_render_colour(_pal, "accent"));
    for (var _i = 1; _i < _n; _i++) {
        draw_line_width(_pts[_i - 1][0], _pts[_i - 1][1], _pts[_i][0], _pts[_i][1], 2);
    }
    // Today, as a dot on the end of the trace.
    draw_set_colour(brs_render_colour(_pal, "trend"));
    draw_circle(_pts[_n - 1][0], _pts[_n - 1][1], 3.5, false);
}

/// ============================================================================================
/// STOCK PIPS
/// ============================================================================================

/// Ten pips punched into the counter, filled to show stock against the cover a market wants to
/// hold. Ten is the count a player can read WITHOUT COUNTING - the shape of the filled run carries
/// it, exactly like a health bar made of hearts.
function brs_pips_draw(_pal, _x, _y, _r, _frac) {
    var _n = 10;
    var _lit = clamp(round(_frac * _n), 0, _n);
    for (var _i = 0; _i < _n; _i++) {
        var _cx = _x + _i * (_r * 2.6);
        if (_i < _lit) {
            brs_render_parts_raw(brs_map_roles(brs_boss(_cx, _y, _r, 8),
                { m0: "edge", m1: "dim", m2: "accent", m3: "accent", m4: "paper" }), _pal);
        } else {
            brs_render_parts_raw(brs_map_roles(brs_pit(_cx, _y, _r * 0.86, 8),
                { m0: "ground", m1: "ground", m2: "edge", m3: "edge", m4: "panel" }), _pal);
        }
    }
    return _n * _r * 2.6;
}

/// ============================================================================================
/// THE TREND ARROW
/// ============================================================================================

/// A raised chevron, up or down, or a flat bar for steady. Drawn beside a gauge where a number
/// would go in a lesser shop screen.
function brs_trend_draw(_pal, _x, _y, _s, _dir) {
    if (_dir == 0) {
        brs_render_parts_raw(brs_map_roles(
            brs_raise([[_x - _s * 0.6, _y - _s * 0.12], [_x + _s * 0.6, _y - _s * 0.12],
                       [_x + _s * 0.6, _y + _s * 0.12], [_x - _s * 0.6, _y + _s * 0.12]],
                      _s * 0.10, 2, "dim"),
            { m0: "ground", m1: "edge", m2: "dim", m3: "dim", m4: "panel" }), _pal);
        return;
    }
    var _k = (_dir > 0) ? -1 : 1;
    var _pt = [[_x, _y + _k * _s * 0.62], [_x + _s * 0.60, _y - _k * _s * 0.30],
               [_x + _s * 0.30, _y - _k * _s * 0.42], [_x, _y - _k * _s * 0.02],
               [_x - _s * 0.30, _y - _k * _s * 0.42], [_x - _s * 0.60, _y - _k * _s * 0.30]];
    brs_render_parts_raw(brs_map_roles(brs_raise(_pt, _s * 0.14, 2, "trend"),
        // ⚠️ FOUR OF THE FIVE STOPS CARRY THE TREND COLOUR, AND THE FIRST VERSION GAVE IT TWO. A
        // needle is a small wedge, so most of its pixels are BEVEL WALL rather than face - with the
        // walls painted in neutral greys the whole widget read as silver whichever way the market
        // was going, which is the one thing this widget exists not to do. Measured by looking at the
        // baked gauge sheet: three needles, three directions, one colour.
        { m0: "shadow", m1: "trend", m2: "trend", m3: "trend", m4: "paper" }), _pal);
}

/// ============================================================================================
/// THE SPREAD BAR - what the merchant keeps
/// ============================================================================================

/// Buy price, sell price, and the merchant's cut between them, on one track.
///
/// ⛔ NO SHOP ASSET THIS WING COULD FIND SHOWS THE SPREAD AT ALL, and hiding it is why players think
/// shop systems cheat. It is one bar: the sell price at the left stop, the buy price at the right,
/// and the gap between them shaded. A player who watches that gap widen during a shortage has
/// learned the whole mechanic without a tutorial.
function brs_spread_draw(_m, _id, _pal, _x, _y, _w, _h) {
    var _r = brs_market_row(_m, _id);
    if (is_undefined(_r)) return;
    var _sp = brs_market_spread(_r);
    brs_render_parts_raw(brs_map_roles(
        brs_ui_well(_x, _y, _x + _w, _y + _h, _h * 0.4, _h * 0.26, "panel"),
        { m0: "ground", m1: "edge", m2: "panel", m3: "edge", m4: "line" }), _pal);
    // The cut, centred, its width the spread as a fraction of the whole track. At the base spread
    // it is a sixth of the bar; at the cap it is most of it, and the picture is the point.
    var _cw = _w * clamp(_sp * 2.4, 0.06, 0.86);
    draw_set_colour(brs_render_colour(_pal, "fall"));
    draw_set_alpha(0.55);
    draw_rectangle(_x + (_w - _cw) * 0.5, _y + _h * 0.30, _x + (_w + _cw) * 0.5, _y + _h * 0.70, false);
    draw_set_alpha(1.0);
    var _px = max(8, _h * 0.62);
    brs_text_line(string(round(brs_market_sell_price(_m, _id))), _x + _h * 0.3, _y + _h * 0.18,
                  _w * 0.3, _px, brs_render_colour(_pal, "line"), false);
    var _bs = string(round(brs_market_buy_price(_m, _id)));
    draw_set_font(fnt_bourse);
    var _base = max(1, string_height("M"));
    var _bw = string_width(_bs) * (_px / _base);
    brs_text_line(_bs, _x + _w - _bw - _h * 0.3, _y + _h * 0.18, _w * 0.3, _px,
                  brs_render_colour(_pal, "line"), false);
}
