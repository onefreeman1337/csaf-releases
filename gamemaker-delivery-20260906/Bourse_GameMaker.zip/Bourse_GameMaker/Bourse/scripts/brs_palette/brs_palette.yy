{
  "$GMScript": "v1",
  "%Name": "brs_palette",
  "isCompatibility": false,
  "isDnD": false,
  "name": "brs_palette",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}