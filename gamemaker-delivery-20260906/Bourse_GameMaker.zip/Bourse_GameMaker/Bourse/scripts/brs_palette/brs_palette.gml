/// BOURSE - brs_palette. Part of the shared drawing foundation.
///
/// This file is the studio's cross-product drawing/colour layer, carried forward with more
/// than 1,900 in-engine assertions behind it - including the GML default-epsilon fix
/// described below, which had produced a suite of assertions that could never go red.
///
/// ⛔ GML APPLIES A DEFAULT EPSILON TO NUMERIC COMPARISONS, and it is 0.00001 on this runtime
/// - MEASURED by brs_selftest, which prints math_get_epsilon() into its own result file at
/// twelve decimals. Any tolerance at or below about 0.00001 can NEVER fire, in either
/// direction, so a distinctness assertion written that way passes vacuously forever and an
/// equality assertion written that way goes red on two values that are the same object.
/// Never write one here. And GML has no exponent-literal syntax at all: `1e-5` is a lexer
/// error that reads like a bracket bug.
///
/// The colour MATHS only. Oklab -> linear sRGB, the gamma transfer, a per-lightness chroma
/// ceiling, and brs_oklch.
///
/// -- WHY OKLCH AND NOT HSV -------------------------------------------------------------
/// A material is not a colour, it is a RAMP: five stops from the deepest shadow between two
/// barrel staves to the highlight on a wet clay shoulder. What makes oak read as oak is that
/// those five stops are evenly spaced in APPARENT lightness, and that the spacing survives
/// being re-hued from oak to iron to sackcloth to green bottle glass. In HSV, "same
/// saturation" means wildly different apparent contrast across the hue circle, so a ramp
/// tuned on timber collapses on tin - and those two sit side by side on the same shelf.
/// Oklab spaces colour by how it LOOKS, for about twenty lines of matrix arithmetic, which
/// is the only reason brs_material can assert a per-stop separation floor and have that
/// assertion mean something.
///
/// ⛔ Bourse's own materials, stencil inks and counter timbers live in brs_material, built
/// on the four functions below. Nothing product-specific belongs in this file.
/// ============================================================================================
#macro BRS_GOLDEN_ANGLE 137.50776405003785
#macro BRS_SAT_FLOOR 0.045

/// Oklab -> linear sRGB. Bjorn Ottosson's matrices.
function brs_oklab_linear(_L, _a, _b) {
    var _l = _L + 0.3963377774 * _a + 0.2158037573 * _b;
    var _m = _L - 0.1055613458 * _a - 0.0638541728 * _b;
    var _s = _L - 0.0894841775 * _a - 1.2914855480 * _b;
    _l = _l * _l * _l; _m = _m * _m * _m; _s = _s * _s * _s;
    return [
         4.0767416621 * _l - 3.3077115913 * _m + 0.2309699292 * _s,
        -1.2684380046 * _l + 2.6097574011 * _m - 0.3413193965 * _s,
        -0.0041960863 * _l - 0.7034186147 * _m + 1.7076147010 * _s
    ];
}

function brs_gamma(_c) {
    return (_c <= 0.0031308) ? (12.92 * _c) : (1.055 * power(_c, 1 / 2.4) - 0.055);
}

/// Chroma ceiling near white and near black.
///
/// Oklab will happily hand back a fully-saturated colour at L 0.95 and sRGB renders it as neon.
/// Real ink gets LESS chromatic as it approaches paper-white or lamp-black; this curve puts that
/// back, and it is what keeps the top two rarities looking expensive instead of radioactive.
function brs_chroma_ceiling(_L, _C) {
    var _hi = max(0, (_L - 0.68) / 0.32);
    var _lo = max(0, (0.22 - _L) / 0.22);
    return _C * (1 - _hi * 0.62) * (1 - _lo * 0.45);
}

/// Oklch -> a GameMaker colour, with GAMUT REDUCTION rather than clipping.
///
/// Clipping an out-of-gamut colour shifts its HUE - a too-saturated blue clips to purple - which
/// would quietly undo the perceptual spacing this whole file exists to provide. Walking chroma
/// down until the colour fits keeps the hue exactly where it was put.
function brs_oklch(_L, _C, _hdeg) {
    var _h = degtorad(_hdeg);
    var _c = brs_chroma_ceiling(_L, _C);
    var _rgb;
    for (var _i = 0; _i < 24; _i++) {
        _rgb = brs_oklab_linear(_L, cos(_h) * _c, sin(_h) * _c);
        if (_rgb[0] >= -0.0015 && _rgb[1] >= -0.0015 && _rgb[2] >= -0.0015
         && _rgb[0] <=  1.0015 && _rgb[1] <=  1.0015 && _rgb[2] <=  1.0015) break;
        _c *= 0.92;
    }
    _rgb = brs_oklab_linear(_L, cos(_h) * _c, sin(_h) * _c);
    return make_colour_rgb(
        round(clamp(brs_gamma(clamp(_rgb[0], 0, 1)), 0, 1) * 255),
        round(clamp(brs_gamma(clamp(_rgb[1], 0, 1)), 0, 1) * 255),
        round(clamp(brs_gamma(clamp(_rgb[2], 0, 1)), 0, 1) * 255)
    );
}
