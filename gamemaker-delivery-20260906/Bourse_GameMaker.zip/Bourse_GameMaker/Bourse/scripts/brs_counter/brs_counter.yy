{
  "$GMScript": "v1",
  "%Name": "brs_counter",
  "isCompatibility": false,
  "isDnD": false,
  "name": "brs_counter",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}