/// BOURSE - brs_counter. The market screen: the counter, the shelf, the ledger.
///
/// ⛔ THERE IS NO WINDOWSKIN IN THIS PACKAGE AND NO NINE-SLICE. Every panel, well, rail and tab on
/// this screen is a rounded outline handed to the same brs_bevel that shades a cask, lit by the
/// same lamp, filled from the same hall palette. That is the whole reason the interface does not
/// look like a GameMaker default, and it is the reason it cannot: there is no default here to fall
/// back to. A buyer who changes the hall changes the wood the counter is made of.
///
/// -- THE LAYOUT, AND WHY IT IS THIS ONE ---------------------------------------------------------
/// A trade rail down the left, six ware plates on the counter, and the ledger on the right. The
/// plates are LARGE - a market screen that shows forty-eight goods at once shows forty-eight goods
/// nobody can tell apart, and the whole argument for drawing them at all is that a player should
/// recognise a cask of wine without reading the word "cask".
///
/// -- WHAT IS PUBLIC ------------------------------------------------------------------------------
///   brs_counter_state()               a fresh interface state struct
///   brs_counter_draw(m, st, x,y,w,h)  draw the whole screen into a rectangle
///   brs_counter_click(m, st, mx,my)   hit-test; returns what was hit, or ""
/// Everything else is a private drawing helper. A buyer who wants their own layout calls
/// brs_plate_draw and brs_ledger_draw directly and never touches this file.
/// ============================================================================================

/// Interface state, kept apart from the market: a market is a simulation and can be stepped by a
/// server with no screen at all, which is exactly the separation a buyer needs when they put this
/// behind their own UI.
function brs_counter_state(_hall) {
    return {
        hall: is_undefined(_hall) ? "counting-house" : _hall,
        trade: "provision", sel: "grain_sack",
        toast: "", toastT: 0, hot: ""
    };
}

/// The surface for the CHROME - the counter itself, which is not made of any ware's material.
/// Oak and iron, always, so the room does not change when the selected good does.
function brs_counter_surface(_st, _dir) {
    return brs_surface("oak", "iron", _st.hall, _dir);
}

/// ============================================================================================
/// ONE WARE PLATE
/// ============================================================================================

/// A ware standing in a sunk well, with its name and its price gauge under it.
///
/// ⚠️ THE WARE IS FITTED TO THE WELL BY ITS UNIT BOX, NOT BY ITS CONTENT. A tight fit makes a
/// perfume vial and a wine cask the same size on the shelf, which destroys the one proportion that
/// says the cask is bulk and the vial is precious. The corpus is authored in a shared frame
/// precisely so this call can be the dumb one.
function brs_plate_draw(_m, _id, _st, _x, _y, _w, _h, _selected) {
    var _dir = brs_market_trend(_m, _id);
    var _pal = brs_ware_surface(_id, _st.hall, _dir);
    var _chrome = brs_counter_surface(_st, _dir);
    var _gh = _h * 0.30;
    var _wh = _h - _gh;

    // The well the ware stands in, in the COUNTER's materials.
    brs_render_parts_raw(brs_map_roles(
        brs_ui_well(_x, _y, _x + _w, _y + _wh, 10, 7, "cloth"),
        { m0: "ground", m1: "edge", m2: "cloth", m3: "edge", m4: "line" }), _chrome);

    // A selected plate is RAISED out of the counter rather than outlined. An outline is a decal; a
    // raised edge is the same physical language as everything else on the screen.
    if (_selected) {
        brs_render_parts_raw(brs_map_roles(
            brs_bevel(brs_round_rect_pts(_x - 3, _y - 3, _x + _w + 3, _y + _wh + 3, 12, 4), 5, 2, false),
            { m0: "edge", m1: "dim", m2: "accent", m3: "accent", m4: "paper" }), _chrome);
    }

    // The ware. Inset from the well so its own bevel never touches the well's.
    var _pad = _w * 0.10;
    brs_render_in_rect(brs_ware_parts(_id), _pal, _x + _pad, _y + _pad * 0.6,
                       _w - _pad * 2, _wh - _pad * 1.2, 0, undefined);

    // Name and gauge.
    var _sp = brs_ware_spec(_id);
    var _r = brs_market_row(_m, _id);
    brs_text_line(_sp.name, _x + 6, _y + _wh - 2, _w - 12, max(10, _h * 0.085),
                  brs_render_colour(_chrome, "line"), false);
    if (!is_undefined(_r)) {
        brs_gauge_draw(_chrome, _x + 6, _y + _wh + _h * 0.085, _w - 12, _gh - _h * 0.085,
                       brs_market_needle(_m, _id), _dir, "", _r.price);
    }
}

/// ============================================================================================
/// THE LEDGER
/// ============================================================================================

/// The detail panel: the selected good large, its year of prices, the spread, the stock, and what
/// the market is doing to its trade right now.
function brs_ledger_draw(_m, _id, _st, _x, _y, _w, _h) {
    var _dir = brs_market_trend(_m, _id);
    var _chrome = brs_counter_surface(_st, _dir);
    var _pal = brs_ware_surface(_id, _st.hall, _dir);
    var _sp = brs_ware_spec(_id);
    var _r = brs_market_row(_m, _id);

    brs_render_parts_raw(brs_map_roles(
        brs_ui_panel(_x, _y, _x + _w, _y + _h, 12, 8, "panel"),
        { m0: "ground", m1: "edge", m2: "panel", m3: "edge", m4: "line" }), _chrome);

    var _ix = _x + 18, _iw = _w - 36;
    var _cy = _y + 24;

    // ⛔ THE HEADING GOES ABOVE THE WELL, NOT ON IT. The first version drew the name, the trade and
    // the materials INSIDE the hero well's rectangle on the left and the good on the right - which
    // on the baked sheet read as three captions floating over the top edge of a recessed panel,
    // because a well is a HOLE and text does not sit in a hole. Found by opening the PNG.
    // CENTRE coordinates - brs_text_fit is halign-centre and valign-middle. Passing a left edge
    // here is what made this heading hang off the panel on the first baked market screen.
    brs_text_fit(_sp.name, _ix + _iw * 0.5, _cy + 12, _iw * 0.80, 26,
                 brs_render_colour(_chrome, "ground"), brs_render_colour(_chrome, "paper"));
    brs_text_line(string_upper(brs_trade_name(_sp.trade)) + "   -   " + _sp.body + " + "
                  + _sp.fitting, _ix + 2, _cy + 32, _iw * 0.94, 14,
                  brs_render_colour(_chrome, "dim"), false);
    _cy += 54;

    // The hero: the good at four times shelf size, in a well of its own, centred.
    var _hh = _h * 0.28;
    brs_render_parts_raw(brs_map_roles(
        brs_ui_well(_ix, _cy, _ix + _iw, _cy + _hh, 10, 7, "cloth"),
        { m0: "ground", m1: "edge", m2: "cloth", m3: "edge", m4: "line" }), _chrome);
    brs_render_in_rect(brs_ware_parts(_id), _pal, _ix + _iw * 0.27, _cy + 8,
                       _iw * 0.46, _hh - 16, 0, undefined);

    _cy += _hh + 14;

    // The years. The window is samples x sampling interval, computed rather than written down -
    // the caption said "LAST 96 DAYS" for one edit after the interval changed, which is a listing
    // claim that would have shipped wrong.
    brs_text_line("PRICE, LAST " + string(BRS_HIST * BRS_HIST_EVERY) + " DAYS",
                  _ix, _cy, _iw * 0.7, 13, brs_render_colour(_chrome, "dim"), true);
    _cy += 18;
    brs_spark_draw(_m, _id, _chrome, _ix, _cy, _iw, _h * 0.20);
    _cy += _h * 0.20 + 16;

    // The spread.
    brs_text_line("SELL / MERCHANT'S CUT / BUY", _ix, _cy, _iw * 0.8, 13,
                  brs_render_colour(_chrome, "dim"), true);
    _cy += 18;
    brs_spread_draw(_m, _id, _chrome, _ix, _cy, _iw, 26);
    _cy += 38;

    // Stock, as pips, against the cover the market wants.
    brs_text_line("STOCK", _ix, _cy, _iw * 0.4, 13, brs_render_colour(_chrome, "dim"), true);
    if (!is_undefined(_r)) {
        var _frac = _r.stock / max(0.0001, _r.daily * BRS_COVER);
        brs_pips_draw(_chrome, _ix + 62, _cy + 8, 6, _frac);
        brs_text_line(string(floor(_r.stock)) + " units", _ix + 62 + 10 * 6 * 2.6 + 10, _cy,
                      _iw * 0.3, 13, brs_render_colour(_chrome, "line"), false);
    }
    _cy += 26;

    // What is happening to this trade. The event line is the one piece of text on the screen that
    // is allowed to be a sentence, because a market event is news and news is written down.
    if (_m.ev >= 0 && _m.evTrade == _sp.trade) {
        var _tab = brs_event_table();
        brs_text_line(string_upper(_m.evName) + " - " + string(_m.evLeft) + " DAYS LEFT",
                      _ix, _cy, _iw, 15,
                      brs_render_colour(_chrome, (_tab[_m.ev].yield < 1) ? "fall" : "rise"), true);
    } else {
        brs_text_line("NO EVENT IN THIS TRADE", _ix, _cy, _iw, 15,
                      brs_render_colour(_chrome, "dim"), false);
    }
    _cy += 30;

    // ⛔ THE TRADE BOARD, AND IT EXISTS BECAUSE THE PANEL WAS A THIRD EMPTY. Measured by opening the
    // baked market screen: everything above ended two hundred pixels short of the bottom, and a
    // bounding-box check cannot see the space inside itself. The answer to a sparse panel is more
    // content, never a smaller panel - so the ledger now ends with the whole trade ranked dearest
    // first against its own base, which is the question a trader asks next and the one thing the
    // screen could not previously answer without six clicks.
    brs_text_line("THE TRADE, DEAREST FIRST", _ix, _cy, _iw * 0.7, 13,
                  brs_render_colour(_chrome, "dim"), true);
    _cy += 20;
    var _hot = brs_market_hottest(_m, _sp.trade, 6);
    var _rowh = min(34, max(20, (_y + _h - 14 - _cy) / max(1, array_length(_hot))));
    for (var _i = 0; _i < array_length(_hot); _i++) {
        var _hid = _hot[_i];
        var _hr = brs_market_row(_m, _hid);
        if (is_undefined(_hr)) continue;
        var _hy = _cy + _i * _rowh;
        var _hd = brs_market_trend(_m, _hid);
        var _hs = brs_ware_surface(_hid, _st.hall, _hd);
        // The good itself at row height, so even the list is drawn rather than written.
        brs_render_in_rect(brs_ware_parts(_hid), _hs, _ix, _hy - 2, _rowh * 0.9, _rowh * 0.9,
                           0, undefined);
        brs_text_line(brs_ware_spec(_hid).name, _ix + _rowh, _hy + _rowh * 0.18,
                      _iw * 0.46, 14,
                      brs_render_colour(_chrome, (_hid == _id) ? "accent" : "line"), _hid == _id);
        brs_gauge_draw(_chrome, _ix + _iw * 0.56, _hy, _iw * 0.44, _rowh * 0.92,
                       brs_market_needle(_m, _hid), _hd, "", _hr.price);
    }
}

/// ============================================================================================
/// THE TRADE RAIL
/// ============================================================================================

/// Eight tabs down the left, each a raised panel, the selected one pushed forward.
function brs_rail_draw(_m, _st, _x, _y, _w, _h) {
    var _chrome = brs_counter_surface(_st, 0);
    var _ids = brs_trade_ids();
    var _n = array_length(_ids);
    var _th = _h / _n;
    for (var _i = 0; _i < _n; _i++) {
        var _ty = _y + _i * _th;
        var _on = (_ids[_i] == _st.trade);
        var _pts = brs_round_rect_pts(_x + (_on ? 0 : 8), _ty + 3, _x + _w, _ty + _th - 3, 9, 3);
        brs_render_parts_raw(brs_map_roles(brs_raise(_pts, 6, 3, _on ? "accent" : "panel"),
            { m0: "ground", m1: "edge", m2: _on ? "accent" : "panel", m3: "edge", m4: "line" }),
            _chrome);
        brs_text_line(brs_trade_name(_ids[_i]), _x + (_on ? 14 : 22), _ty + _th * 0.22,
                      _w - 32, 18,
                      brs_render_colour(_chrome, _on ? "ground" : "line"), _on);
        // What the trade is DOING, under its name - the rail is the first thing a player looks at
        // and a rail of eight identical labels tells them nothing about where to go.
        var _hot6 = brs_market_hottest(_m, _ids[_i], 1);
        if (array_length(_hot6) > 0) {
            var _hrow = brs_market_row(_m, _hot6[0]);
            var _hk = (is_undefined(_hrow)) ? 1
                    : _hrow.price / max(0.0001, brs_ware_spec(_hot6[0]).base);
            brs_text_line("dearest x" + string_format(_hk, 1, 2),
                          _x + (_on ? 14 : 22), _ty + _th * 0.56, _w - 32, 13,
                          brs_render_colour(_chrome, _on ? "ground" : "dim"), false);
        }
    }
}

/// Which tab or plate a point is over. Returns "trade:<id>", "ware:<id>", or "".
///
/// ⚠️ THE HIT TEST USES THE SAME ARITHMETIC AS THE DRAW, AND IT IS WRITTEN ONCE. An interface whose
/// hit boxes are computed a second time in a second function is an interface that will be one
/// layout change away from clickable areas that do not match what is on the screen, and that bug is
/// invisible in a screenshot.
function brs_counter_click(_m, _st, _mx, _my, _x, _y, _w, _h) {
    var _rw = _w * 0.17;
    var _lw = _w * 0.31;
    var _sx = _x + _rw + 14;
    var _sw = _w - _rw - _lw - 28;
    var _ids = brs_trade_ids();
    var _th = _h / array_length(_ids);
    if (_mx >= _x && _mx <= _x + _rw) {
        var _i = floor((_my - _y) / _th);
        if (_i >= 0 && _i < array_length(_ids)) return "trade:" + _ids[_i];
    }
    var _w6 = brs_trade_wares(_st.trade);
    var _pw = (_sw - 24) / 3, _ph = (_h - 16) / 2;
    for (var _i = 0; _i < array_length(_w6); _i++) {
        var _px = _sx + (_i % 3) * (_pw + 12);
        var _py = _y + floor(_i / 3) * (_ph + 16);
        if (_mx >= _px && _mx <= _px + _pw && _my >= _py && _my <= _py + _ph) {
            return "ware:" + _w6[_i];
        }
    }
    return "";
}

/// ============================================================================================
/// THE WHOLE SCREEN
/// ============================================================================================

function brs_counter_draw(_m, _st, _x, _y, _w, _h) {
    var _chrome = brs_counter_surface(_st, 0);

    // The counter itself: the whole rectangle as one raised slab, then the cloth laid on it.
    draw_set_colour(brs_render_colour(_chrome, "ground"));
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);

    var _rw = _w * 0.17;
    var _lw = _w * 0.31;
    var _sx = _x + _rw + 14;
    var _sw = _w - _rw - _lw - 28;

    brs_rail_draw(_m, _st, _x, _y, _rw, _h);

    // The shelf: six plates, three across.
    var _w6 = brs_trade_wares(_st.trade);
    var _pw = (_sw - 24) / 3, _ph = (_h - 16) / 2;
    for (var _i = 0; _i < array_length(_w6); _i++) {
        var _px = _sx + (_i % 3) * (_pw + 12);
        var _py = _y + floor(_i / 3) * (_ph + 16);
        brs_plate_draw(_m, _w6[_i], _st, _px, _py, _pw, _ph, _w6[_i] == _st.sel);
    }

    brs_ledger_draw(_m, _st.sel, _st, _x + _w - _lw, _y, _lw, _h);
}

/// The header strip: hall, day, season, purse. Drawn separately so a buyer can put it anywhere,
/// or not at all.
function brs_counter_header(_m, _st, _x, _y, _w, _h) {
    var _chrome = brs_counter_surface(_st, 0);
    brs_render_parts_raw(brs_map_roles(
        brs_ui_panel(_x, _y, _x + _w, _y + _h, 8, 6, "panel"),
        { m0: "ground", m1: "edge", m2: "panel", m3: "edge", m4: "line" }), _chrome);
    var _season = (_m.day div BRS_SEASON_DAYS) % BRS_SEASONS;
    // CENTRE coordinates, again - see brs_text_fit. Centred on the left sixth of the strip.
    brs_text_fit("BOURSE", _x + _w * 0.09, _y + _h * 0.50, _w * 0.15, _h * 0.52,
                 brs_render_colour(_chrome, "ground"), brs_render_colour(_chrome, "paper"));
    brs_text_line(string_upper(_st.hall), _x + _w * 0.19, _y + _h * 0.30, _w * 0.20, _h * 0.34,
                  brs_render_colour(_chrome, "dim"), false);
    brs_text_line(brs_season_name(_season) + ", DAY " + string(_m.day mod BRS_SEASON_DAYS),
                  _x + _w * 0.42, _y + _h * 0.30, _w * 0.22, _h * 0.34,
                  brs_render_colour(_chrome, "line"), false);
    var _p = "PURSE " + string(round(_m.purse));
    draw_set_font(fnt_bourse_title);
    var _base = max(1, string_height("M"));
    var _pw2 = string_width(_p) * ((_h * 0.40) / _base);
    brs_text_line(_p, _x + _w - _pw2 - 16, _y + _h * 0.26, _w * 0.24, _h * 0.40,
                  brs_render_colour(_chrome, "accent"), true);
}
