{
  "$GMScript": "v1",
  "%Name": "brs_market",
  "isCompatibility": false,
  "isDnD": false,
  "name": "brs_market",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}