/// BOURSE - brs_market. THE SYSTEM: why a price is what it is today, and different tomorrow.
///
/// Every shop asset for every engine sets a price in a table and reads it back. This one does not
/// have a price table. It has STOCK and DEMAND, and the price is what falls out of the two - so a
/// player who buys forty sacks of grain finds grain dearer when they come back, and a player who
/// waits out a blight pays for waiting.
///
/// -- THE PRICE, IN ONE LINE ---------------------------------------------------------------------
///     price = base * scarcity ^ (1 / elasticity)
///
/// `scarcity` is how far stock has fallen below the cover a market likes to hold. The exponent is
/// the interesting half and it is why this is a simulation rather than a multiplier: a good with
/// LOW elasticity is one buyers must have at any price, so a shortage of it goes vertical, and a
/// good with HIGH elasticity is one buyers simply do without, so the same shortage barely moves it.
/// Bread is 0.35 and pearls are 2.4. A famine doubles the price of pearls and quadruples the price
/// of bread, out of the same arithmetic, with nothing special-cased.
///
/// ⛔ AND THE LISTED PRICE IS NOT THE COMPUTED PRICE. Real prices are STICKY: a merchant moves a
/// figure toward what the market says, a little each day, and that lag is what makes a price CHART
/// worth drawing. Snapping to the computed value gives a chart that is a step function and a shop
/// that feels like a spreadsheet. BRS_STICK is the whole of that mechanism.
///
/// -- WHAT IS DETERMINISTIC, AND WHY IT MATTERS --------------------------------------------------
/// A market is built from a seed and steps in whole days. Two markets built from the same seed and
/// stepped the same number of days are identical to the last decimal - which is what lets
/// brs_selftest assert the simulation's behaviour at all, and what lets a buyer save a game by
/// writing down a seed and a day count.
///
/// ⚠️ THE RNG IS THE PACKAGE'S OWN, NOT GameMaker's. random() reads a global sequence that the
/// buyer's game also draws from, so a market seeded in a project that rolls dice elsewhere would
/// not reproduce. brs_rng carries its own state in an array.
/// ============================================================================================

/// How many days of demand a market likes to hold. Stock at exactly this level prices at base.
#macro BRS_COVER 26

/// How far the listed price moves toward the computed price each day. 0.18 is about a week to
/// three quarters of the way, which reads as a market reacting rather than a switch flipping.
#macro BRS_STICK 0.18

/// The price band, as multiples of base. A market that can go to zero or to infinity is a market
/// that will, on someone's twelve-hour idle save.
#macro BRS_PRICE_MIN 0.34
#macro BRS_PRICE_MAX 4.00

/// The merchant's cut, at rest. Widens with scarcity (see brs_market_spread) because a merchant
/// who cannot replace stock quotes a wider spread - which is the one bit of shop behaviour every
/// player already understands without being told.
#macro BRS_SPREAD_BASE 0.085

/// Days in a season, and seasons in a year.
#macro BRS_SEASON_DAYS 90
#macro BRS_SEASONS 4

/// How many price samples the history keeps, and how many days each sample covers.
///
/// ⛔ ONE SAMPLE PER DAY WAS THE WRONG UNIT AND IT MADE THE PRODUCT LOOK BROKEN. Ninety-six daily
/// samples is ONE SEASON, and inside a single season a price does exactly one thing: drift to that
/// season's resting point. Every chart on the store sheet was therefore a smooth slide into a flat
/// line - a truthful picture of a window too short to contain the mechanic the product is sold on.
/// Sampling every fourth day puts FOUR SEASONS on the same chart, and the seasonal swing, the
/// events and the recoveries are all in frame.
#macro BRS_HIST 96
#macro BRS_HIST_EVERY 4

/// ============================================================================================
/// SEASONS
/// ============================================================================================

/// Where a day falls in the year, as a season index and a fraction into it - with a per-ware
/// PHASE so that two goods in the same trade do not move in lockstep.
///
/// ⛔ WITHOUT THE PHASE, A WHOLE TRADE IS ONE PRICE. Measured by opening the baked market screen:
/// all six drink goods sat at the bottom of their own gauges on the same day, because the seasonal
/// table is per TRADE and every ware in a trade was reading the same cell on the same day. It is
/// not what a market looks like and it is not even true - cider is pressed in one short autumn,
/// ale is brewed all year, and wine is sold out of a cellar filled two years ago. A phase of up to
/// a season, derived from the ware's own id, is one line and it de-synchronises the shelf.
///
/// ⛔ AND THE FRACTION MATTERS AS MUCH AS THE PHASE. Reading a four-cell table by index makes the
/// year a STEP function: production jumps 250% overnight at every boundary, which draws a chart
/// made of plateaus and cliffs and reads as a bug rather than as a harvest. Interpolating between
/// the cell a day is in and the next one costs a lerp and turns the same table into a curve.
function brs_season_at(_day, _phase) {
    var _t = ((_day + _phase) % (BRS_SEASON_DAYS * BRS_SEASONS)) / BRS_SEASON_DAYS;
    var _i = floor(_t) % BRS_SEASONS;
    return { i: _i, f: _t - floor(_t) };
}

/// The phase, in days, a ware's own seasons are offset by. Derived from its id, so it is the same
/// on every machine and in every save without being stored.
function brs_ware_phase(_id) {
    return (brs_hash32(_id) % BRS_SEASON_DAYS);
}

function brs_season_name(_s) {
    switch (_s % BRS_SEASONS) {
        case 0:  return "Spring";
        case 1:  return "Summer";
        case 2:  return "Harvest";
        default: return "Winter";
    }
}

/// What a season does to a trade's PRODUCTION, as a multiplier.
///
/// ⚠️ THESE ARE THE ONLY HAND-AUTHORED NUMBERS IN THE SIMULATION and they are the ones a buyer is
/// most likely to want to change, so they are one readable table rather than scattered constants.
/// Everything else - price, spread, consumption, spoilage - is derived.
/// ⚠️ THE ROW IS PULLED INTO A LOCAL BEFORE IT IS INDEXED, AND THAT IS NOT STYLE. GML does not
/// index an array LITERAL - `[1,2,3][_i]` is a parse error, not a subscript - and the failure reads
/// as a bracket problem several lines away, which this wing has already paid for once on an
/// exponent literal. One local per branch costs nothing and cannot be misread.
function brs_season_yield(_trade, _season) {
    var _s = _season % BRS_SEASONS;
    var _row = brs_season_yield_row(_trade);
    return _row[_s];
}

/// The four production cells for a trade. Split out from the lookup above so the interpolating
/// reader can take two adjacent cells without calling the switch twice.
function brs_season_yield_row(_trade) {
    var _row;
    switch (_trade) {
        //                spring summer harvest winter
        case "provision": _row = [0.55, 0.85, 1.95, 0.45]; break;
        case "cloth":     _row = [1.30, 1.45, 0.90, 0.60]; break;   // shearing, then retting
        case "metal":     _row = [1.00, 1.20, 1.05, 0.80]; break;   // water for the wheels
        case "drink":     _row = [0.70, 0.75, 1.85, 0.95]; break;   // pressed at harvest
        case "spice":     _row = [0.80, 1.10, 1.35, 0.70]; break;   // the caravans run in the dry
        case "timber":    _row = [0.85, 1.05, 1.10, 1.25]; break;   // felled on frozen ground
        case "hide":      _row = [0.75, 0.95, 1.55, 1.05]; break;   // the autumn cull
        default:          _row = [1.05, 1.15, 1.00, 0.95]; break;
    }
    return _row;
}

/// What a season does to a trade's DEMAND. Deliberately NOT the inverse of yield - the whole point
/// of the harvest is that supply and demand move independently, and a market where they cancel is
/// a market with no prices worth watching.
function brs_season_want(_trade, _season) {
    var _s = _season % BRS_SEASONS;
    var _row = brs_season_want_row(_trade);
    return _row[_s];
}

/// The four demand cells for a trade.
function brs_season_want_row(_trade) {
    var _row;
    switch (_trade) {
        case "provision": _row = [1.15, 0.95, 0.85, 1.35]; break;   // the hungry gap is spring
        case "cloth":     _row = [0.95, 0.80, 1.15, 1.45]; break;
        case "metal":     _row = [1.20, 1.15, 0.95, 0.85]; break;   // the campaign season
        case "drink":     _row = [1.00, 1.30, 1.10, 1.25]; break;
        case "spice":     _row = [0.90, 0.95, 1.05, 1.55]; break;   // preserving, and the feast
        case "timber":    _row = [1.25, 1.20, 1.00, 1.30]; break;   // building, then burning
        case "hide":      _row = [0.95, 0.85, 1.20, 1.40]; break;
        default:          _row = [1.05, 1.00, 1.10, 1.30]; break;
    }
    return _row;
}

/// The two seasonal factors a ware sees TODAY, interpolated across the boundary and shifted by the
/// ware's own phase. Returns [yield, want].
function brs_season_factors(_id, _trade, _day) {
    var _at = brs_season_at(_day, brs_ware_phase(_id));
    var _yr = brs_season_yield_row(_trade);
    var _wr = brs_season_want_row(_trade);
    var _n = (_at.i + 1) % BRS_SEASONS;
    // Smoothstep rather than a straight lerp: a season eases in and out, and a linear ramp between
    // two plateaus still puts a visible corner in the chart at each boundary.
    var _f = _at.f * _at.f * (3 - 2 * _at.f);
    return [lerp(_yr[_at.i], _yr[_n], _f), lerp(_wr[_at.i], _wr[_n], _f)];
}

/// ============================================================================================
/// EVENTS - the eight things that happen to a market
/// ============================================================================================

/// { name, trade, yield multiplier, want multiplier, days, weight }
///
/// An event is a WINDOW, not a spike. A caravan that dumps stock in one tick produces a price
/// cliff and a chart nobody can read; a caravan that unloads over twelve days produces a slide the
/// player can see coming and trade against, which is the entire reason the events exist.
function brs_event_table() {
    return [
        { name: "Caravan In",     yield: 2.60, want: 0.95, days: 14, weight: 16 },
        { name: "Blight",         yield: 0.25, want: 1.10, days: 34, weight: 10 },
        { name: "Festival",       yield: 0.90, want: 2.10, days: 10, weight: 14 },
        { name: "Embargo",        yield: 0.35, want: 1.35, days: 44, weight:  7 },
        { name: "Shipwreck",      yield: 0.45, want: 1.05, days: 20, weight:  9 },
        { name: "Bumper Season",  yield: 1.95, want: 0.90, days: 40, weight: 12 },
        { name: "Guild Strike",   yield: 0.30, want: 1.00, days: 24, weight:  9 },
        { name: "Road Reopened",  yield: 1.55, want: 1.05, days: 30, weight: 13 }
    ];
}

/// ============================================================================================
/// BUILDING A MARKET
/// ============================================================================================

/// A market at rest: every ware at exactly its cover, so every price starts at base and the first
/// thing a player sees is a market that MOVES rather than one that was already lopsided.
///
/// _wares is an optional array of ware ids. Pass one to run a market in a subset of the corpus -
/// a village that trades in provisions and timber and nothing else is one array literal.
function brs_market_new(_seed, _hall, _wares) {
    var _ids = is_undefined(_wares) ? brs_ware_ids() : _wares;
    var _rng = brs_rng(_seed);
    var _rows = array_create(array_length(_ids));
    for (var _i = 0; _i < array_length(_ids); _i++) {
        var _sp = brs_ware_spec(_ids[_i]);
        // Daily demand is derived from bulk, not authored: a market moves more sacks of grain than
        // caskets of pearls, and tying it to bulk means a buyer who adds a ware gets a sane volume
        // without a second number to tune.
        var _daily = 0.60 + _sp.bulk * 2.10;
        // A little scatter, so a fresh market is not forty-eight identical rows. Seeded, so it is
        // the SAME scatter every time for a given seed.
        var _jit = 0.86 + brs_rng_next(_rng) * 0.28;
        var _hist = array_create(BRS_HIST, _sp.base);
        _rows[_i] = {
            id: _ids[_i], daily: _daily * _jit, stock: _daily * _jit * BRS_COVER,
            price: _sp.base, target: _sp.base, prev: _sp.base,
            hist: _hist, hh: 0, sold: 0, bought: 0,
            bandLo: _sp.base, bandHi: _sp.base
        };
    }
    return {
        seed: _seed, hall: is_undefined(_hall) ? "counting-house" : _hall,
        day: 0, rng: _rng, rows: _rows,
        ev: -1, evTrade: "", evLeft: 0, evName: "",
        purse: 400, ledger: []
    };
}

/// The row for a ware id, or undefined. Linear, and that is correct at forty-eight rows: a struct
/// index would have to be rebuilt every time a buyer adds a ware, and this is called once per draw.
function brs_market_row(_m, _id) {
    for (var _i = 0; _i < array_length(_m.rows); _i++) {
        if (_m.rows[_i].id == _id) return _m.rows[_i];
    }
    return undefined;
}

/// ============================================================================================
/// THE PRICE
/// ============================================================================================

/// How scarce a ware is: cover wanted over stock held. 1.0 is exactly at cover.
function brs_scarcity(_row) {
    var _cover = max(0.0001, _row.daily * BRS_COVER);
    return _cover / max(_row.daily * 0.35, _row.stock);
}

/// What the market SAYS a ware is worth today, before stickiness.
///
/// The exponent is 1/elasticity - see the file header. It is clamped at both ends because an
/// elasticity a buyer types as 0.05 would otherwise produce an exponent of twenty and a price that
/// overflows on the first shortage, and refusing to defend against a buyer's own data is how an
/// asset earns a support ticket that cannot be reproduced.
function brs_market_target(_m, _row) {
    var _sp = brs_ware_spec(_row.id);
    var _ex = clamp(1.0 / max(0.20, _sp.elast), 0.35, 2.90);
    var _k = power(brs_scarcity(_row), _ex);
    return _sp.base * clamp(_k, BRS_PRICE_MIN, BRS_PRICE_MAX);
}

/// The merchant's spread, which widens as stock runs out.
function brs_market_spread(_row) {
    // ⛔ REFUSE, NEVER THROW. The documented way to get a row is brs_market_row(), which returns
    // UNDEFINED for an id it does not know - so brs_market_spread(brs_market_row(m, id)) is a
    // two-call chain straight out of the Readme that a typo turns into a crash. It threw
    // "Variable <unknown_object>.daily cannot be resolved" inside brs_scarcity. A row that does not
    // exist has no scarcity, so the honest answer is the base spread.
    if (is_undefined(_row)) return clamp(BRS_SPREAD_BASE * 0.75, 0.05, 0.32);
    return clamp(BRS_SPREAD_BASE * (0.75 + 0.55 * brs_scarcity(_row)), 0.05, 0.32);
}

function brs_market_buy_price(_m, _id) {
    var _r = brs_market_row(_m, _id);
    if (is_undefined(_r)) return 0;
    return _r.price * (1 + brs_market_spread(_r));
}

function brs_market_sell_price(_m, _id) {
    var _r = brs_market_row(_m, _id);
    if (is_undefined(_r)) return 0;
    return _r.price * (1 - brs_market_spread(_r));
}

/// -1 falling, 0 steady, +1 rising, measured over the last three SAMPLES rather than yesterday.
///
/// ⚠️ A ONE-DAY TREND IS NOISE. The first version compared today with yesterday and the arrow beside
/// every gauge flickered every tick, which reads as a broken widget rather than as a market.
/// ⚠️ AND THE UNIT IS SAMPLES, NOT DAYS. The history samples every BRS_HIST_EVERY days, so "eight
/// back" silently became thirty-two days when that changed - long enough to still report RISING
/// halfway down a crash. Three samples is twelve days: a direction, not a tick, and short enough to
/// turn inside an event window.
function brs_market_trend(_m, _id) {
    var _r = brs_market_row(_m, _id);
    if (is_undefined(_r)) return 0;
    var _n = array_length(_r.hist);
    var _then = _r.hist[(_r.hh - 3 + _n * 2) % _n];
    var _d = (_r.price - _then) / max(0.0001, _then);
    if (_d > 0.020) return 1;
    if (_d < -0.020) return -1;
    return 0;
}

/// ============================================================================================
/// THE STEP
/// ============================================================================================

/// Advance the market one day. Everything that changes, changes here.
function brs_market_day(_m) {
    // The CALENDAR season, which is what the header shows the player. Each ware's own seasonal
    // response is phase-shifted from it (see brs_season_factors) - the calendar is the same for
    // everyone, the harvest is not.
    var _season = (_m.day div BRS_SEASON_DAYS) % BRS_SEASONS;

    // -- the event window ----------------------------------------------------------------------
    if (_m.evLeft > 0) {
        _m.evLeft -= 1;
        if (_m.evLeft <= 0) { _m.ev = -1; _m.evTrade = ""; _m.evName = ""; }
    } else if (brs_rng_next(_m.rng) < 0.045) {
        var _pool = brs_event_table();
        var _tot = 0;
        for (var _i = 0; _i < array_length(_pool); _i++) _tot += _pool[_i].weight;
        var _pick = brs_rng_next(_m.rng) * _tot;
        var _acc = 0, _sel = 0;
        for (var _i = 0; _i < array_length(_pool); _i++) {
            _acc += _pool[_i].weight;
            if (_pick <= _acc) { _sel = _i; break; }
        }
        var _tr = brs_trade_ids();
        _m.ev = _sel;
        _m.evTrade = _tr[min(array_length(_tr) - 1, floor(brs_rng_next(_m.rng) * array_length(_tr)))];
        _m.evLeft = _pool[_sel].days;
        _m.evName = _pool[_sel].name;
    }

    // ⚠️ A SECOND LOCAL, NOT A REUSED ONE. `var` in GML is FUNCTION scoped, not block scoped, so
    // declaring the same name inside the branch above and again here is one declaration with two
    // initialisers - legal, confusing, and exactly the kind of thing that reads as correct until
    // someone moves a line.
    var _tab = brs_event_table();
    for (var _i = 0; _i < array_length(_m.rows); _i++) {
        var _r = _m.rows[_i];
        var _sp = brs_ware_spec(_r.id);
        var _evOn = (_m.ev >= 0 && _m.evTrade == _sp.trade);
        var _ey = _evOn ? _tab[_m.ev].yield : 1.0;
        var _ew = _evOn ? _tab[_m.ev].want : 1.0;

        // PRODUCTION. A market produces toward its cover, not without limit: a workshop that has
        // filled the warehouse stops, which is why prices here find a floor instead of collapsing.
        //
        // ⛔ THE SLACK CURVE DECIDES WHERE THE WHOLE MARKET SETTLES, AND THE FIRST ONE PUT IT AT THE
        // WRONG END OF THE BAND. Written as `1.6 - stock/cover`, a market at exactly its cover was
        // still producing at 0.6 of capacity while consuming at 1.0 - so stock ran away upward until
        // production stalled, every price sat on its clamp, every needle pinned at one end of its
        // gauge and every chart was a single slide into a flat line. MEASURED by looking at the
        // baked simulation sheet, not by any assertion: six charts, six transients, no seasons.
        //
        // `2 - stock/cover` puts production at exactly 1.0 when stock is exactly at cover, so the
        // resting point solves to stock = 2*yield/(yield+want) - within a few per cent of cover for
        // every trade in the table - and the seasons then swing the price ABOUT its base instead of
        // pressing it against a clamp. The arithmetic is worth stating because it is the difference
        // between a simulation and a decay curve.
        var _sf = brs_season_factors(_r.id, _sp.trade, _m.day);
        var _cover = _r.daily * BRS_COVER;
        var _slack = clamp(2.0 - _r.stock / max(0.0001, _cover), 0.0, 2.0);
        var _prod = _r.daily * _sf[0] * _ey * _slack;

        // CONSUMPTION. Buyers answer the price with their own elasticity - the same number that
        // sets the price exponent, used the other way round, which is why the two cannot drift
        // apart into an inconsistent model.
        var _rel = _r.price / max(0.0001, _sp.base);
        var _cons = _r.daily * _sf[1] * _ew
                  * clamp(power(max(0.05, _rel), -_sp.elast), 0.15, 2.60);

        _r.stock = max(0, _r.stock + _prod - _cons);
        // SPOILAGE, per day, from the per-season figure in the spec.
        if (_sp.perish > 0) _r.stock *= (1 - _sp.perish / BRS_SEASON_DAYS);

        _r.prev = _r.price;
        _r.target = brs_market_target(_m, _r);
        _r.price = _r.price + (_r.target - _r.price) * BRS_STICK;

        if (_m.day % BRS_HIST_EVERY == 0) {
            _r.hist[_r.hh] = _r.price;
            _r.hh = (_r.hh + 1) % array_length(_r.hist);
            brs_market_reband(_r);
        }
    }
    _m.day += 1;
}

/// Advance _n days. Separate from brs_market_day so a caller can step a year in a loop without
/// re-deriving the season every frame, and so the self-test can assert on both.
function brs_market_step(_m, _n) {
    for (var _i = 0; _i < _n; _i++) brs_market_day(_m);
}

/// ============================================================================================
/// TRADING
/// ============================================================================================

/// Buy _qty units. Returns a struct: { ok, spent, qty, why }.
///
/// ⛔ A PARTIAL FILL IS A SUCCESS, NOT A FAILURE, and getting that wrong is the single most common
/// shop bug in this genre. A player who asks for forty sacks when the market holds twelve should
/// get twelve and be told so - refusing the whole order because the tail cannot be filled is what
/// makes a shop feel like a form validator.
function brs_market_do_buy(_m, _id, _qty) {
    var _r = brs_market_row(_m, _id);
    if (is_undefined(_r)) return { ok: false, spent: 0, qty: 0, why: "no such ware" };
    // ⛔ REFUSE, NEVER THROW. This function already answers a bad WARE with a named refusal, so a
    // bad QUANTITY must answer the same way. Without this, brs_market_do_buy(m, id, undefined) died
    // inside min() with "min argument 1 incorrect type (undefined) expecting a Number (YYGR)" - a
    // crash inside a bought library, which is the support ticket a seller cannot debug remotely.
    if (!is_real(_qty) || is_nan(_qty)) return { ok: false, spent: 0, qty: 0, why: "bad quantity" };
    var _have = floor(_r.stock);
    var _n = min(_qty, _have);
    if (_n <= 0) return { ok: false, spent: 0, qty: 0, why: "out of stock" };
    var _unit = brs_market_buy_price(_m, _id);
    var _afford = floor(_m.purse / max(0.0001, _unit));
    _n = min(_n, _afford);
    if (_n <= 0) return { ok: false, spent: 0, qty: 0, why: "cannot afford one" };
    var _spent = _unit * _n;
    _m.purse -= _spent;
    _r.stock -= _n;
    _r.bought += _n;
    // The purchase moves the price IMMEDIATELY, not at the next day boundary. A player who clears
    // the shelf and sees the same price is a player who has learned the simulation is decorative.
    _r.target = brs_market_target(_m, _r);
    _r.price = _r.price + (_r.target - _r.price) * BRS_STICK;
    array_push(_m.ledger, { day: _m.day, id: _id, qty: _n, unit: _unit, buy: true });
    return { ok: true, spent: _spent, qty: _n, why: (_n < _qty) ? "partial fill" : "" };
}

/// Sell _qty units into the market. Selling depresses the price for the same reason buying lifts
/// it, and a player who dumps two hundred sacks will find out.
function brs_market_do_sell(_m, _id, _qty) {
    var _r = brs_market_row(_m, _id);
    if (is_undefined(_r)) return { ok: false, got: 0, qty: 0, why: "no such ware" };
    // Guarded symmetrically with do_buy: `_qty <= 0` below is a COMPARISON, and comparing undefined
    // is not something to rely on. The two halves of one API must refuse the same way.
    if (!is_real(_qty) || is_nan(_qty)) return { ok: false, got: 0, qty: 0, why: "bad quantity" };
    if (_qty <= 0) return { ok: false, got: 0, qty: 0, why: "nothing to sell" };
    var _unit = brs_market_sell_price(_m, _id);
    var _got = _unit * _qty;
    _m.purse += _got;
    _r.stock += _qty;
    _r.sold += _qty;
    _r.target = brs_market_target(_m, _r);
    _r.price = _r.price + (_r.target - _r.price) * BRS_STICK;
    array_push(_m.ledger, { day: _m.day, id: _id, qty: _qty, unit: _unit, buy: false });
    return { ok: true, got: _got, qty: _qty, why: "" };
}

/// ============================================================================================
/// SAVE AND LOAD
///
/// ⚠️ THE HISTORY IS SAVED, AND THE FIRST VERSION DID NOT SAVE IT. A market restored without its
/// price history draws a flat chart for its first ninety-six days, which reads to a player as "the
/// economy reset when I loaded" - the one thing a persistent simulation must never appear to do.
/// ============================================================================================

function brs_market_save(_m) {
    var _rows = array_create(array_length(_m.rows));
    for (var _i = 0; _i < array_length(_m.rows); _i++) {
        var _r = _m.rows[_i];
        var _h = array_create(array_length(_r.hist));
        array_copy(_h, 0, _r.hist, 0, array_length(_r.hist));
        _rows[_i] = { id: _r.id, stock: _r.stock, price: _r.price, target: _r.target,
                      prev: _r.prev, daily: _r.daily, hist: _h, hh: _r.hh,
                      sold: _r.sold, bought: _r.bought };
    }
    return { v: 1, seed: _m.seed, hall: _m.hall, day: _m.day, rngState: _m.rng[0],
             ev: _m.ev, evTrade: _m.evTrade, evLeft: _m.evLeft, evName: _m.evName,
             purse: _m.purse, rows: _rows };
}

/// Restore a market from a brs_market_save() blob. Returns UNDEFINED if the blob is not one.
///
/// ⛔ REFUSE, NEVER THROW — and this is the guard that matters most in the package, because it sits
/// on the SAVE path. A buyer ships their game, changes their save format, and a player's old file
/// arrives here: without this the load died with "Variable <unknown_object>.hall cannot be
/// resolved" (or, for a number, "Unable to find instance for object index 42"), i.e. a crash in the
/// player's game on load. Undefined is the convention this file already uses for "no such thing"
/// (brs_market_row), so a caller checks it the same way they already check a row.
function brs_market_load(_s) {
    if (is_undefined(_s) || !is_struct(_s)) return undefined;
    // Every field read below, named once. A blob missing any of them is not one of ours.
    var _need = ["seed", "hall", "day", "rngState", "ev", "evTrade", "evLeft", "evName", "purse", "rows"];
    for (var _k = 0; _k < array_length(_need); _k++) {
        if (!variable_struct_exists(_s, _need[_k])) return undefined;
    }
    if (!is_array(_s.rows)) return undefined;
    var _m = brs_market_new(_s.seed, _s.hall, undefined);
    _m.day = _s.day;
    _m.rng = brs_rng(_s.rngState);
    _m.ev = _s.ev; _m.evTrade = _s.evTrade; _m.evLeft = _s.evLeft; _m.evName = _s.evName;
    _m.purse = _s.purse;
    for (var _i = 0; _i < array_length(_s.rows); _i++) {
        var _sr = _s.rows[_i];
        var _r = brs_market_row(_m, _sr.id);
        if (is_undefined(_r)) continue;
        _r.stock = _sr.stock; _r.price = _sr.price; _r.target = _sr.target;
        _r.prev = _sr.prev; _r.daily = _sr.daily; _r.hh = _sr.hh;
        _r.sold = _sr.sold; _r.bought = _sr.bought;
        array_copy(_r.hist, 0, _sr.hist, 0, array_length(_sr.hist));
        // The band is DERIVED from the history, so it is recomputed rather than saved. One fewer
        // field that can be restored inconsistent with the data it summarises.
        brs_market_reband(_r);
    }
    return _m;
}

/// ============================================================================================
/// READING A MARKET - what the interface asks it
/// ============================================================================================

/// Recompute a row's price band from its remembered history. Called when a sample is written, not
/// when the gauge is drawn - a sort per widget per frame is not a thing to do sixty times a second.
///
/// ⛔ THE BAND IS THE TENTH TO NINETIETH PERCENTILE, NOT THE MINIMUM AND MAXIMUM, AND THAT WAS A
/// REAL DEFECT IN THE WIDGET. Measured by opening the baked market screen twice: with a min/max
/// band, ONE caravan spike stretches the top of the scale for the next year and every needle on the
/// shelf then sits in the bottom fifth of its own gauge for months - so the instrument that exists
/// to answer "is this dear today" answers "no" almost always, and answers it about an event that is
/// long over. Trimming a tenth off each end costs one sort per four days per ware and makes the
/// needle read against a NORMAL year, which is the question a trader is actually asking.
///
/// ⚠️ The price can now sit OUTSIDE its own band, and that is correct: a needle pinned hard against
/// a stop means genuinely exceptional, which under a min/max band it could never mean.
function brs_market_reband(_r) {
    var _n = array_length(_r.hist);
    var _s = array_create(_n);
    array_copy(_s, 0, _r.hist, 0, _n);
    for (var _i = 1; _i < _n; _i++) {
        var _v = _s[_i], _k = _i - 1;
        while (_k >= 0 && _s[_k] > _v) { _s[_k + 1] = _s[_k]; _k -= 1; }
        _s[_k + 1] = _v;
    }
    _r.bandLo = _s[floor(_n * 0.10)];
    _r.bandHi = _s[min(_n - 1, floor(_n * 0.90))];
}

/// The FULL range a ware's price has visited, as [lo, hi]. What a CHART is drawn against.
///
/// ⛔ THE CHART AND THE NEEDLE USE DIFFERENT SCALES ON PURPOSE, AND CONFLATING THEM PUT A TRACE
/// THROUGH THE SHEET TITLE. A chart must show what HAPPENED, spikes and all, so it needs the true
/// extremes; a needle answers "is this dear in a normal year", so it needs a trimmed band. When the
/// band became a percentile, the chart inherited it and every value outside the tenth-to-ninetieth
/// range mapped outside the panel and was drawn there - measured by opening the baked gauge sheet,
/// where a caravan spike ran straight up out of its own well and across the heading above it.
function brs_market_range(_m, _id) {
    var _r = brs_market_row(_m, _id);
    if (is_undefined(_r)) return [0, 1];
    var _lo = 999999, _hi = 0;
    for (var _i = 0; _i < array_length(_r.hist); _i++) {
        _lo = min(_lo, _r.hist[_i]);
        _hi = max(_hi, _r.hist[_i]);
    }
    if (_hi - _lo < 0.02 * max(0.5, _r.price)) {
        var _pad = max(0.01, 0.05 * _r.price);
        _lo = _r.price - _pad; _hi = _r.price + _pad;
    }
    return [_lo, _hi];
}

/// The band a ware's price is read against, as [lo, hi].
function brs_market_band(_m, _id) {
    var _r = brs_market_row(_m, _id);
    if (is_undefined(_r)) return [0, 1];
    var _lo = _r.bandLo, _hi = _r.bandHi;
    // A band with no width divides by zero in the gauge. Open it symmetrically about the price
    // rather than clamping to a floor, so a market that has genuinely never moved draws a needle
    // in the MIDDLE - which is the truth - instead of pinned at one end.
    if (_hi - _lo < 0.02 * max(0.5, _r.price)) {
        var _pad = max(0.01, 0.05 * _r.price);
        _lo = _r.price - _pad; _hi = _r.price + _pad;
    }
    return [_lo, _hi];
}

/// Where the price sits in its own band, 0 at the historic low and 1 at the historic high.
function brs_market_needle(_m, _id) {
    var _b = brs_market_band(_m, _id);
    var _r = brs_market_row(_m, _id);
    if (is_undefined(_r)) return 0.5;
    return clamp((_r.price - _b[0]) / max(0.0001, _b[1] - _b[0]), 0, 1);
}

/// The wares of a trade, sorted dearest first relative to their own base - which is the question a
/// trader actually asks, and not the same as sorted by price.
function brs_market_hottest(_m, _trade, _n) {
    var _cand = [];
    for (var _i = 0; _i < array_length(_m.rows); _i++) {
        var _r = _m.rows[_i];
        var _sp = brs_ware_spec(_r.id);
        if (_trade != "" && _sp.trade != _trade) continue;
        array_push(_cand, { id: _r.id, k: _r.price / max(0.0001, _sp.base) });
    }
    // Insertion sort: forty-eight rows at most, called on a click, and it is four lines a buyer can
    // read rather than a comparator struct they cannot.
    for (var _i = 1; _i < array_length(_cand); _i++) {
        var _v = _cand[_i], _k = _i - 1;
        while (_k >= 0 && _cand[_k].k < _v.k) { _cand[_k + 1] = _cand[_k]; _k -= 1; }
        _cand[_k + 1] = _v;
    }
    var _out = [];
    for (var _i = 0; _i < min(_n, array_length(_cand)); _i++) array_push(_out, _cand[_i].id);
    return _out;
}
