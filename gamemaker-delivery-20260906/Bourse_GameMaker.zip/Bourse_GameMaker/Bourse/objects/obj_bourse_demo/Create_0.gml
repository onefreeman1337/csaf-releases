/// @description Create - the demo room, and the two headless entry points

// Scanned from 0 to parameter_count() INCLUSIVE. GameMaker has never been consistent about
// whether index 0 is the program name or the first argument, an out-of-range read returns "",
// and every product in this wing that ships a headless mode does it this way.
global.brs_stage = 0;
global.brs_mode  = "demo";
var _pc = parameter_count();
for (var _i = 0; _i <= _pc; _i++) {
    var _p = string_lower(parameter_string(_i));
    if (_p == "-selftest") global.brs_mode = "selftest";
    if (_p == "-bake")     global.brs_mode = "bake";
    if (_p == "-gif")      global.brs_mode = "gif";
}

if (global.brs_mode != "demo") {
    // ⛔ A GML RUNTIME ERROR OPENS A MODAL DIALOG, and headless there is nobody to dismiss it, so
    // the process never exits and the runner reports a meaningless timeout. Installing this
    // handler is what turns an opaque 240 second hang into a stage number and a message.
    exception_unhandled_handler(function(_ex) {
        var _name = "brs_selftest.json";
        if (global.brs_mode == "bake") _name = "brs_bake.json";
        if (global.brs_mode == "gif")  _name = "brs_gif.json";
        var _msg = string(_ex.message) + "  [" + string(_ex.script) + ":" + string(_ex.line) + "]";
        var _f = file_text_open_write(_name);
        file_text_write_string(_f,
            "{\"crash\":true,\"stage\":" + string(global.brs_stage)
            + ",\"message\":\"" + string_replace_all(_msg, "\"", "'") + "\"}");
        file_text_close(_f);
        game_end();
    });

    if (global.brs_mode == "bake")     brs_bake_run();
    else if (global.brs_mode == "gif") brs_gif_run();
    else                               brs_selftest_run();
    game_end();
    exit;
}

// ---- the interactive demo --------------------------------------------------------------------
//
// A runnable demo room is mandatory in this wing, and not as a courtesy: GML cannot be tested
// outside the engine, so this room is simultaneously the buyer's quickstart, the source of the
// store GIF, and the only hands-on smoke test that exists. Everything below is a public call the
// Readme documents - nothing here reaches into an internal.
//
// ⚠️ THE MARKET IS STEPPED PAST A FULL HISTORY WINDOW BEFORE THE FIRST FRAME. A market at rest
// prices every good at base and draws forty-eight flat charts, which is a truthful picture of a
// simulation that has not run yet and a terrible first impression of one that works. Worse, a
// market younger than the remembered window still has its opening base-price fill inside that
// window, so every price gauge reads against a band that is half invented and the whole shelf pins
// to one end - measured, on the first baked market screen. Past the window, every needle is
// answering a question about prices that actually happened.
hall_ix   = 1;
hall_ids  = brs_hall_ids();
market    = brs_market_new(20260826, hall_ids[hall_ix], undefined);
ui        = brs_counter_state(hall_ids[hall_ix]);
brs_market_step(market, BRS_HIST * BRS_HIST_EVERY + 180);

running   = true;
speed     = 6;       // frames per simulated day
tick      = 0;
toast     = "";
toast_t   = 0;
