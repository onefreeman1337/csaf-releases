/// @description Step - time, and the mouse

if (global.brs_mode != "demo") exit;

// -- time ---------------------------------------------------------------------------------------
if (running) {
    tick += 1;
    if (tick >= speed) { tick = 0; brs_market_day(market); }
}
if (keyboard_check_pressed(vk_space)) running = !running;
if (keyboard_check_pressed(vk_right)) brs_market_step(market, 1);
if (keyboard_check_pressed(vk_up))    speed = max(1, speed - 1);
if (keyboard_check_pressed(vk_down))  speed = min(30, speed + 1);

// -- the hall: one key changes every colour on the screen and no geometry at all ----------------
if (keyboard_check_pressed(ord("H"))) {
    hall_ix = (hall_ix + 1) % array_length(hall_ids);
    ui.hall = hall_ids[hall_ix];
    market.hall = hall_ids[hall_ix];
    toast = "HALL: " + string_upper(ui.hall);
    toast_t = 90;
}

// -- trading ------------------------------------------------------------------------------------
if (keyboard_check_pressed(ord("B"))) {
    var _r = brs_market_do_buy(market, ui.sel, 5);
    toast = _r.ok ? ("BOUGHT " + string(_r.qty) + " FOR " + string(round(_r.spent)))
                  : ("CANNOT BUY: " + _r.why);
    toast_t = 90;
}
if (keyboard_check_pressed(ord("S"))) {
    var _r = brs_market_do_sell(market, ui.sel, 5);
    toast = _r.ok ? ("SOLD " + string(_r.qty) + " FOR " + string(round(_r.got)))
                  : ("CANNOT SELL: " + _r.why);
    toast_t = 90;
}

// -- the shelf ----------------------------------------------------------------------------------
// The hit test is the interface's own, so a layout change can never leave the click boxes behind.
var _gy = 86;
var _gh = display_get_gui_height() - _gy - 44;
var _hit = brs_counter_click(market, ui, device_mouse_x_to_gui(0), device_mouse_y_to_gui(0),
                             24, _gy, display_get_gui_width() - 48, _gh);
ui.hot = _hit;
if (mouse_check_button_pressed(mb_left) && _hit != "") {
    var _kind = string_copy(_hit, 1, string_pos(":", _hit) - 1);
    var _id = string_delete(_hit, 1, string_pos(":", _hit));
    if (_kind == "trade") {
        ui.trade = _id;
        var _w6 = brs_trade_wares(_id);
        ui.sel = _w6[0];
    } else {
        ui.sel = _id;
    }
}

if (toast_t > 0) toast_t -= 1;
