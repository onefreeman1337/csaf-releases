/// @description Draw GUI - the whole market screen

if (global.brs_mode != "demo") exit;

var _gw = display_get_gui_width();
var _gh = display_get_gui_height();
var _pal = brs_counter_surface(ui, 0);

draw_set_colour(brs_render_colour(_pal, "ground"));
draw_rectangle(0, 0, _gw, _gh, false);

brs_counter_header(market, ui, 24, 18, _gw - 48, 52);
brs_counter_draw(market, ui, 24, 86, _gw - 48, _gh - 86 - 44);

// The key line. It is on screen rather than in the Readme alone because the demo room IS the
// quickstart, and a quickstart nobody can drive is a video.
brs_text_line("SPACE pause   RIGHT step a day   UP/DOWN speed   H hall   B buy 5   S sell 5"
              + "   CLICK a trade or a ware",
              24, _gh - 32, _gw - 48, 15, brs_render_colour(_pal, "dim"), false);

if (toast_t > 0) {
    var _a = min(1.0, toast_t / 22.0);
    draw_set_alpha(_a);
    brs_render_parts_raw(brs_map_roles(
        brs_ui_panel(_gw * 0.5 - 190, _gh - 96, _gw * 0.5 + 190, _gh - 52, 10, 7, "accent"),
        { m0: "ground", m1: "edge", m2: "accent", m3: "accent", m4: "paper" }), _pal);
    brs_text_line(toast, _gw * 0.5 - 172, _gh - 84, 344, 20,
                  brs_render_colour(_pal, "ground"), true);
    draw_set_alpha(1.0);
}
