# Bourse — a living market that draws its own goods

**GameMaker · pure GML · no sprites, no atlas, no texture page.**

Bourse is a market for your game. It does not read a price table — it simulates **stock and
demand**, and the price falls out of the two. And it draws its own stock: **forty-eight trade
goods**, every one built from data by the GML in this package and shaded in relief against a single
fixed lamp, so a cask reads as a cask on any counter, in any of six halls.

---

## COMPATIBILITY — read this first

| | |
| --- | --- |
| **Built and tested against** | GameMaker runtime **2024.14.4.268** (the current stable GMS2 runtime) |
| **Language** | 100% GML. No extensions, no DLLs, no shaders, no external tools. |
| **Assets it adds** | 11 scripts, 1 demo object, 1 demo room, 2 font resources. Nothing else. |
| **Assets it needs from you** | none |
| **Sprites / texture pages** | **none.** There is no `sprites/` folder. Everything is drawn from geometry. |
| **Networking, files, services** | none. It never touches the disk or the network by itself. |
| **GMRT** | Bourse is a pure-GML runtime library and uses no engine feature outside the documented GML surface. It is built and verified against the **stable** runtime; treat GMRT as untested until you have tried it. |
| **Namespacing** | every function, macro and global is prefixed `brs_` / `BRS_`. GML's global namespace is flat, so this matters — nothing here can collide with your code or with another package. |

**Import:** `Tools > Import Local Package…` and pick `Bourse.yymps`. Import everything. Open
`rm_bourse_demo` and press Play.

---

## THE DEMO ROOM IS THE QUICKSTART

`rm_bourse_demo` is a working market screen driving the real public API — nothing in it reaches
into an internal.

| key | what it does |
| --- | --- |
| **SPACE** | pause / resume time |
| **RIGHT** | step one day |
| **UP / DOWN** | faster / slower |
| **H** | change hall — one string, every colour on the screen changes, no geometry moves |
| **B** | buy 5 of the selected good |
| **S** | sell 5 of the selected good |
| **click** | a trade on the left rail, or a good on the counter |

---

## THE SHORTEST USEFUL PROGRAM

```gml
// Create
market = brs_market_new(12345, "counting-house", undefined);   // seed, hall, wares (undefined = all 48)
ui     = brs_counter_state("counting-house");
brs_market_step(market, 400);                                  // give it a history to show

// Step
brs_market_day(market);                                        // one day

// Draw GUI
brs_counter_header(market, ui, 24, 18, display_get_gui_width() - 48, 52);
brs_counter_draw(market, ui, 24, 86, display_get_gui_width() - 48,
                 display_get_gui_height() - 130);
```

That is the whole product on screen. Everything below is for when you want your own interface.

---

## THE MODEL, IN ONE LINE

```
price = base * scarcity ^ (1 / elasticity)
```

`scarcity` is how far stock has fallen below the cover the market likes to hold. The exponent is
the interesting half:

- a good with **low elasticity** is one buyers must have at any price, so a shortage of it goes
  vertical — **bread is 0.35**;
- a good with **high elasticity** is one buyers simply do without, so the same shortage barely
  moves it — **pearls are 2.4**.

A 65% shortage multiplies bread by about **4** and pearls by about **1.5**, out of the same
arithmetic, with nothing special-cased. (Those two numbers are asserted in the shipped self-test.)

Around that sit the things that make a market feel alive:

- **The listed price is sticky.** A merchant moves a figure toward what the market says a little
  each day, so a price chart is a curve and not a step function.
- **Four seasons**, interpolated rather than stepped, with **production and demand authored
  separately** — a harvest floods provisions and does nothing to metal.
- **A per-ware phase.** Two goods in the same trade do not move in lockstep: cider is pressed in one
  short autumn, ale is brewed all year.
- **Eight events** — caravan, blight, festival, embargo, shipwreck, bumper season, guild strike,
  road reopened — each a WINDOW of days rather than a spike, so a player can see one coming and
  trade against it.
- **Spoilage**, per good, per season. Bread does not keep.
- **A spread that widens as stock runs out**, and it is shown on screen rather than hidden.

---

## THE PUBLIC API

### The market

```gml
brs_market_new(seed, hall, wares)      // wares: an array of ids, or undefined for all 48
brs_market_day(m)                      // advance one day
brs_market_step(m, n)                  // advance n days
brs_market_row(m, id)                  // { id, stock, price, daily, hist, ... } or undefined

brs_market_buy_price(m, id)            // what the player pays
brs_market_sell_price(m, id)           // what the player gets
brs_market_spread(row)                 // the merchant's cut, 0..1
brs_market_do_buy(m, id, qty)          // -> { ok, spent, qty, why }
brs_market_do_sell(m, id, qty)         // -> { ok, got,   qty, why }

brs_market_trend(m, id)                // -1 falling, 0 steady, +1 rising
brs_market_needle(m, id)               // 0..1, where the price sits in a NORMAL year
brs_market_band(m, id)                 // [lo, hi] the needle is read against (10th-90th pct)
brs_market_range(m, id)                // [lo, hi] the full remembered range - what a CHART uses
brs_market_hottest(m, trade, n)        // ids, dearest first against their own base

brs_market_save(m)                     // -> a plain struct. Where it goes is yours.
brs_market_load(blob)                  // -> a market that continues identically, or undefined
                                       //    if blob is not a brs_market_save() blob. Check it the
                                       //    same way you already check brs_market_row().
```

**A partial fill is a success.** A player who asks for forty sacks when the shelf holds twelve gets
twelve and is told so (`why == "partial fill"`). Refusing the whole order because the tail cannot be
filled is what makes a shop feel like a form validator.

**Buying moves the price immediately**, not at the next day boundary. A player who clears the shelf
and sees the same price has learned the simulation is decorative.

### The goods

```gml
brs_ware_ids()                         // 48 ids, grouped six per trade
brs_ware_spec(id)                      // { name, trade, body, fitting, base, bulk, perish, elast, mark }
brs_ware_parts(id)                     // the PICTURE: a part list in the unit box
brs_ware_surface(id, hall, dir)        // the palette to draw it with
brs_trade_ids() / brs_trade_name(t) / brs_trade_wares(t)
```

### Drawing

```gml
brs_render_in_rect(parts, pal, x, y, w, h, rot, map)     // fit the unit box into a rectangle
brs_render_parts(parts, pal, cx, cy, scale, rot, wscale, map)
brs_render_bounds(parts)                                  // [x0,y0,x1,y1] in unit-box space
```

### The widgets — usable without the rest of the interface

```gml
brs_gauge_draw(pal, x, y, w, h, t, dir, label, price)   // label "" = no caption row
brs_spark_draw(m, id, pal, x, y, w, h)                  // the price history
brs_spread_draw(m, id, pal, x, y, w, h)                 // sell / cut / buy
brs_pips_draw(pal, x, y, r, frac)                       // stock against cover
brs_trend_draw(pal, x, y, size, dir)                    // the chevron
```

### The screen

```gml
brs_counter_state(hall)
brs_counter_draw(m, st, x, y, w, h)
brs_counter_header(m, st, x, y, w, h)
brs_counter_click(m, st, mx, my, x, y, w, h)   // -> "trade:<id>", "ware:<id>", or ""
brs_plate_draw(m, id, st, x, y, w, h, selected)
brs_ledger_draw(m, id, st, x, y, w, h)
```

The hit test uses **the same arithmetic as the draw**, written once, so a layout change can never
leave the click boxes behind.

---

## MAKING IT YOURS

**Re-skin a good — no geometry changes.** Every good picks two materials from a table of fourteen.
Change the pair in `brs_ware_spec` and the same crate is now pine and tin instead of oak and iron:

```gml
case "wine_cask": return { name: "Cask of Wine", trade: "drink",
                           body: "pine", fitting: "tin",       // <- this line
                           base: 58, bulk: 1.60, perish: 0.03, elast: 1.30, mark: 0 };
```

**Change the room.** Six halls — `cellar`, `counting-house`, `harbour`, `caravanserai`,
`guildhall`, `frost-market`. One string changes the counter, the cloth, the ledger paper, the rails
and the text colour. **The goods keep their own materials**, deliberately: a copper ingot is the
same copper in every hall, and if it were not, the price gauge beside it would be lying about what
it is looking at.

**Add your own good.** Two entries: one in `brs_ware_spec` for the economics, one function returning
a part list for the picture, plus its id in `brs_ware_ids()` and its case in `brs_ware_parts()`.
Nine shared form builders make all forty-eight existing goods — `brs_body`, `brs_box`, `brs_hoop`,
`brs_batten`, `brs_staves`, `brs_stencil`, `brs_tie`, `brs_sheen`, `brs_ware_shadow` — so a new
sack is about fifteen lines.

**Only want the simulation?** `brs_market` depends on `brs_ware` for the specs and on nothing else.
Drive it from your own UI and never call the drawing layer.

**Only want the pictures?** `brs_ware_parts(id)` + `brs_render_in_rect(...)` is two calls. You do not
need a market to draw a barrel.

---

## THE TUNING YOU ARE MOST LIKELY TO WANT

All in `brs_market`, all named, all at the top of the file:

| macro | default | what it does |
| --- | --- | --- |
| `BRS_COVER` | 26 | days of demand a market likes to hold. Stock at cover prices at base. |
| `BRS_STICK` | 0.18 | how far the listed price moves toward the computed one each day |
| `BRS_PRICE_MIN` / `MAX` | 0.34 / 4.00 | the legal band, as multiples of base |
| `BRS_SPREAD_BASE` | 0.085 | the merchant's cut at rest |
| `BRS_SEASON_DAYS` | 90 | days per season |
| `BRS_HIST` / `BRS_HIST_EVERY` | 96 / 4 | the remembered window: 96 samples, one every 4 days |

The two seasonal tables — production and demand, per trade, per season — are one readable switch
each in the same file. They are the numbers you are most likely to want to change, so they are a
table and not scattered constants.

---

## HOW THIS PACKAGE WAS VERIFIED, AND WHAT THAT DOES NOT COVER

GML cannot be unit-tested outside the engine, so this package ships its own tests **inside** it and
runs them on a real build:

- **The Igor gate:** exit 0, 0 errors, 0 warnings, 358 resources compiled, runtime 2024.14.4.268.
- **`Bourse.exe -selftest`: 931 assertions, 0 failures**, run against that Igor-built executable.
  It covers the runtime's own comparison epsilon, the relief engine's lamp and ramp, all fourteen
  material ramps and six halls, every one of the forty-eight goods (each builds, stands on the
  counter line, stays inside its frame, casts a shadow, asks only for roles the surface carries,
  and is a distinct picture from all forty-seven others), the simulation (determinism over 300 days
  from one seed, price bounds over 1200 days, monotonic scarcity, the elasticity law, partial
  fills, save/load round-trip **including the price history**, event firing) and the interface's own
  hit-test arithmetic.
- **`Bourse.exe -bake`** renders every image on the store page from this same GML.

**What that does not cover:** whether it looks right. Every image was opened and reviewed by eye,
and several defects that every mechanical check passed were found only that way. If something looks
wrong in your project, it is a real report — write to the store page.

---

## LICENCE

See `LICENSE.txt`. Short version: use it in unlimited games, commercial or free, forever; the goods
it draws are yours, including in your marketing; do not resell the package itself.

Fonts: Open Sans, Apache-2.0. See `Bourse/fonts/THIRD-PARTY-NOTICES.txt`.

---

*Core Systems Asset Factory — Bourse v1.0.0*
