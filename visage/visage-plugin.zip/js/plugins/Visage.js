//=============================================================================
// Visage.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Visage [4/4] — the scenes, parameters and commands. Every spirit and beast in your database is carved a mask, and your players see it. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Visage — every spirit and beast is carved a mask
 * ============================================================================
 * Load this LAST, after VisageRender, VisageRead and VisageCarve.
 *
 * WHAT IT DOES
 * Visage reads the enemies and actors already in your database and carves each
 * one a mask: a face structure from what it is, a superstructure from where it
 * stands in YOUR OWN database, pigment from what it strikes with, inlay from
 * the house it belongs to, and wear from how long it has stood. Nothing is an
 * image file and nothing is shipped art — change a record and the mask changes.
 *
 * INSTALL
 * 1. Copy the four .js files into js/plugins and enable them in this order:
 *    VisageRender, VisageRead, VisageCarve, Visage.
 * 2. Copy the two .woff2 files from fonts/ into your project's fonts/ folder.
 *    (Optional. Without them the placard falls back to a serif — never to RPG
 *    Maker's own font, and a missing font can never stop your game booting.)
 *
 * THE THREE PLACES PLAYERS MEET A MASK
 *   The Unmasking  A full-screen reveal. Happens by itself the first time the
 *                  party defeats a creature (turn it off below), or on the
 *                  plugin command "Unmask".
 *   The Rack       A wall of pegs the player fills. Menu command "Masks", or
 *                  the plugin command "Open Rack". Empty pegs show, so the
 *                  collection reads as incomplete — that is the point.
 *   A picture      "Show Mask Picture" puts a mask in a Game_Picture, so it can
 *                  be moved, tinted and timed like any other picture in a
 *                  cutscene.
 *
 * NOTETAGS — on any Enemy or Actor. The hand always wins.
 *   <visage type: beast>        beast humanoid undead spirit construct
 *                               dragon insect aquatic plant fiend
 *   <visage rank: 9>            0-11, instead of the database percentile
 *   <visage element: fire>      by name or by index
 *   <visage faction: Barrow Kin>
 *   <visage age: ancient>       green seasoned old ancient relic
 *   <visage name: The Bog Wight>   engraved on the placard
 *   <visage: skip>              never carve this record
 *
 * SCRIPT
 *   CSAF.Visage.unmask(id)              reveal an enemy's mask
 *   CSAF.Visage.unmaskActor(id)         reveal an actor's mask
 *   CSAF.Visage.openRack()              open the wall
 *   CSAF.Visage.taken()                 how many the player has found
 *   CSAF.Visage.read(id)                the profile, for your own UI
 *
 * COMPATIBILITY
 * Adds two scenes (Scene_VisageUnmask, Scene_VisageRack). Extends seven core
 * methods, every one by saving the original and CALLING it — nothing is
 * replaced, nothing is overwritten:
 *   Game_System.prototype.initialize              the versioned save record
 *   Scene_Boot.prototype.start                    reads your database once
 *   Window_MenuCommand.prototype.addOriginalCommands   the "Masks" command
 *   Scene_Menu.prototype.createCommandWindow      its handler
 *   Scene_Map.prototype.update                    shows a queued reveal
 *   BattleManager.processVictory                  queues it after a victory
 *   ImageManager.loadPicture                      hands back a carved mask for
 *                                                 a "$csafVisage..." name, and
 *                                                 calls the original for every
 *                                                 other name
 * Only this file touches RPG Maker at all. VisageRead, VisageCarve and
 * VisageRender are a reader, a carver and a drawing kit, and none of them knows
 * the engine exists. Switch this file off and nothing is patched.
 * ============================================================================
 *
 * @param menuCommand
 * @text Menu command
 * @desc The wording of the command added to the main menu. Blank adds nothing.
 * @type string
 * @default Masks
 *
 * @param rackTitle
 * @text Rack heading
 * @desc The heading across the top of the wall.
 * @type string
 * @default The Rack
 *
 * @param unmaskOnDefeat
 * @text Unmask on first defeat
 * @desc The first time the party defeats a creature, its mask is revealed.
 * @type boolean
 * @default true
 *
 * @param unmaskEyebrow
 * @text Reveal caption
 * @desc The small line above the name on a reveal. Leave blank for none.
 * @type string
 * @default Its true face
 *
 * @param continueHint
 * @text Continue hint
 * @desc The quiet line at the foot of a reveal. Leave blank for none.
 * @type string
 * @default OK to continue
 *
 * @param includeActors
 * @text Carve the party too
 * @desc Party members get masks as well, and start already taken.
 * @type boolean
 * @default true
 *
 * @param revealSize
 * @text Reveal height
 * @desc How tall a mask is drawn on the Unmasking, in pixels.
 * @type number
 * @min 160
 * @max 560
 * @default 420
 *
 * @param factions
 * @text Faction table
 * @desc Your houses. A creature in one wears its inlay. Leave empty and Visage reads a house from what each creature carries.
 * @type struct<Faction>[]
 * @default []
 *
 * @param fontFolder
 * @text Font folder
 * @desc Where the two shipped .woff2 files live, relative to the game root.
 * @type string
 * @default fonts/
 *
 * @command unmask
 * @text Unmask
 * @desc Reveal one creature's mask, full screen.
 *
 * @arg enemyId
 * @text Enemy
 * @type enemy
 * @default 0
 *
 * @command unmaskActor
 * @text Unmask Party Member
 * @desc Reveal one party member's mask, full screen.
 *
 * @arg actorId
 * @text Actor
 * @type actor
 * @default 0
 *
 * @command openRack
 * @text Open Rack
 * @desc Open the wall of masks the player has found.
 *
 * @command showMaskPicture
 * @text Show Mask Picture
 * @desc Draw a mask into a Game_Picture, for a cutscene.
 *
 * @arg enemyId
 * @text Enemy
 * @type enemy
 * @default 0
 *
 * @arg pictureId
 * @text Picture number
 * @type number
 * @min 1
 * @max 100
 * @default 1
 *
 * @arg x
 * @text X
 * @type number
 * @min -9999
 * @default 408
 *
 * @arg y
 * @text Y
 * @type number
 * @min -9999
 * @default 312
 *
 * @arg height
 * @text Mask height
 * @type number
 * @min 48
 * @max 624
 * @default 300
 *
 * @command takeMask
 * @text Take Mask
 * @desc Add a mask to the rack without showing it.
 *
 * @arg enemyId
 * @text Enemy
 * @type enemy
 * @default 0
 */
/*~struct~Faction:
 * @param name
 * @text Name
 * @desc The house's name. It is engraved on the placard.
 * @type string
 * @default
 *
 * @param treatment
 * @text Inlay
 * @desc How this house binds its masks.
 * @type select
 * @option Gold wire
 * @value goldWire
 * @option Verdigris
 * @value verdigris
 * @option Iron rivet
 * @value ironRivet
 * @option Shell
 * @value shell
 * @option Bone pin
 * @value bonePin
 * @option Lacquer thread
 * @value lacquerThread
 * @default goldWire
 *
 * @param members
 * @text Enemies
 * @desc The enemies of this house. A creature can also be tagged <visage faction: NAME>.
 * @type enemy[]
 * @default []
 */

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};
var CSAF = globalThis.CSAF;

CSAF.Visage = (function () {
  'use strict';

  var PLUGIN = 'Visage';
  var SAVE_VERSION = 1;

  /* ⛔ wing §8 trap 2: siblings at FIRST USE. `mz_harness build` loads the
   * plugin folder ALPHABETICALLY, so this file — which is [4/4] — is parsed
   * FIRST of the four. Nothing below touches a sibling at load time. */
  var _R = null; var _D = null; var _C = null;
  function deps() {
    if (!_R) { _R = CSAF.VisageRender; _D = CSAF.VisageRead; _C = CSAF.VisageCarve; }
    if (!_R || !_D || !_C) throw new Error('Visage: enable VisageRender, VisageRead and VisageCarve too.');
    return _R;
  }

  /**
   * Plugin parameters.
   * ⛔ wing §16: parameters arrive as STRINGS, `Number('')` is 0 rather than
   * NaN, and `"0"` is TRUTHY — a raw id tested for truthiness is how Augury's
   * headline feature was disabled with every headless check green. Nothing here
   * tests a raw property for truth; ids go through `Number()` and are compared
   * against zero.
   * @returns {object} Parsed parameters.
   */
  function params() {
    var raw = (typeof PluginManager !== 'undefined' && PluginManager.parameters)
      ? PluginManager.parameters(PLUGIN) : {};
    function str(k, dflt) {
      var v = raw[k];
      return (v === undefined || v === null || String(v).trim() === '') ? dflt : String(v);
    }
    function strAllowBlank(k, dflt) {
      var v = raw[k];
      return (v === undefined || v === null) ? dflt : String(v);
    }
    function bool(k, dflt) {
      var v = raw[k];
      if (v === undefined || v === null || String(v).trim() === '') return dflt;
      return String(v) === 'true';
    }
    function num(k, dflt) {
      var v = raw[k];
      if (v === undefined || v === null || String(v).trim() === '') return dflt;
      var n = Number(v);
      return isNaN(n) ? dflt : n;
    }
    return {
      menuCommand: strAllowBlank('menuCommand', 'Masks'),
      rackTitle: str('rackTitle', 'The Rack'),
      unmaskOnDefeat: bool('unmaskOnDefeat', true),
      unmaskEyebrow: strAllowBlank('unmaskEyebrow', 'Its true face'),
      continueHint: strAllowBlank('continueHint', 'OK to continue'),
      includeActors: bool('includeActors', true),
      revealSize: num('revealSize', 420),
      fontFolder: str('fontFolder', 'fonts/'),
      factions: parseFactions(raw.factions)
    };
  }

  /**
   * Parse the faction table.
   * ⛔ wing §16: a `struct<T>[]` parameter is DOUBLE-encoded — a JSON string of
   * JSON strings, and every leaf is a string no matter what `@type` says. The
   * `members` list inside each struct is therefore a THIRD level of encoding.
   * A malformed table is EMPTY, never an error: a buyer who typed something odd
   * into a parameter gets houses read from what creatures carry, not a crash.
   * @param {*} rawValue The parameter as received.
   * @returns {object[]} `{name, treatment, members[], kind}` rows.
   */
  function parseFactions(rawValue) {
    var outer = [];
    try { outer = rawValue && String(rawValue).trim() ? JSON.parse(rawValue) : []; } catch (e) { outer = []; }
    if (!Array.isArray(outer)) return [];
    var out = [];
    for (var i = 0; i < outer.length; i++) {
      var row = outer[i];
      try { row = (typeof row === 'string') ? JSON.parse(row) : row; } catch (e) { row = null; }
      if (!row || !row.name) continue;
      var members = [];
      try {
        var m = (typeof row.members === 'string' && row.members.trim()) ? JSON.parse(row.members) : (row.members || []);
        if (Array.isArray(m)) {
          for (var k = 0; k < m.length; k++) {
            var n = Number(m[k]);
            if (n > 0) members.push(n);
          }
        }
      } catch (e2) { members = []; }
      out.push({
        name: String(row.name),
        treatment: String(row.treatment || 'goldWire'),
        members: members,
        kind: 'enemy'
      });
    }
    return out;
  }

  var _params = null;
  /** @returns {object} Parameters, parsed once. */
  function P() {
    if (!_params) {
      _params = params();
      deps();
      _D.useFactions(_params.factions);
    }
    return _params;
  }

  /** The suite injects its own; the engine uses `$data*`. */
  function _setParamsForTest(p) { _params = p; if (p) { deps(); _D.useFactions(p.factions || []); } }

  /* ------------------------------------------------------------ save data --
   * ⛔ A VERSIONED, LOSSLESS SCHEMA. Which masks the player has taken is real
   * play history and is saved normally. Nothing here is a runtime object: a
   * baked Bitmap would be walked by `JsonEx._encode` and written into the save
   * file (wing §13), so the cache lives on the module, not on `$gameSystem`. */
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return { v: SAVE_VERSION, taken: {} };
    if (!$gameSystem._csafVisage || typeof $gameSystem._csafVisage !== 'object') {
      $gameSystem._csafVisage = { v: SAVE_VERSION, taken: {} };
    }
    var s = $gameSystem._csafVisage;
    if (!s.taken || typeof s.taken !== 'object' || Array.isArray(s.taken)) s.taken = {};
    if (typeof s.v !== 'number') s.v = SAVE_VERSION;
    return s;
  }

  /** @param {string} kind @param {number} id @returns {string} the save key */
  function keyOf(kind, id) { return (kind === 'actor' ? 'a' : 'e') + Number(id); }

  /** @param {string} kind @param {number} id @returns {boolean} */
  function isTaken(kind, id) { return store().taken[keyOf(kind, id)] === true; }

  /** @param {string} kind @param {number} id @returns {boolean} true if this was NEW */
  function take(kind, id) {
    var s = store();
    var k = keyOf(kind, id);
    if (s.taken[k] === true) return false;
    s.taken[k] = true;
    return true;
  }

  /** @returns {number} how many masks the player has taken */
  function taken() {
    var s = store();
    var n = 0;
    for (var k in s.taken) { if (s.taken[k] === true) n++; }
    return n;
  }

  /* ------------------------------------------------------------- profiles --
   * ⛔ Read ONCE per boot and cached. `readAll` computes percentiles over the
   * whole database, so calling it per mask would be quadratic AND would make a
   * mask's rank depend on how many masks had been drawn — the profile has to be
   * a property of the database, not of the session. */
  var _profiles = null;
  function profiles() {
    deps();
    if (!_profiles) {
      _profiles = _D.readAll(null, { enemies: true, actors: P().includeActors });
    }
    return _profiles;
  }

  /** Drop the cache — the suite and a database reload need this. */
  function invalidate() { _profiles = null; _bitmaps = {}; }

  /**
   * @param {number} id An enemy id.
   * @returns {object|null} Its profile.
   */
  function read(id) {
    var list = profiles();
    for (var i = 0; i < list.length; i++) {
      if (list[i].kind === 'enemy' && list[i].id === Number(id)) return list[i];
    }
    return null;
  }

  /** @param {number} id An actor id. @returns {object|null} Its profile. */
  function readActor(id) {
    var list = profiles();
    for (var i = 0; i < list.length; i++) {
      if (list[i].kind === 'actor' && list[i].id === Number(id)) return list[i];
    }
    return null;
  }

  /* -------------------------------------------------------------- bitmaps --
   * ⛔ ZERO ALLOCATION IN A PER-FRAME PATH (wing §3). A mask costs 11 ms to
   * carve at rack size and 86 ms at reveal size (MEASURED, `_probe/preview.js
   * time`), so it is baked ONCE into a Bitmap and cached by profile key AND
   * size. Nothing in an `update()` below carves, allocates an array, or builds
   * a string. */
  var _bitmaps = {};

  /**
   * @param {object} profile A profile.
   * @param {number} size Height in px.
   * @returns {Bitmap} The mask, baked.
   */
  function bitmapFor(profile, size) {
    deps();
    var key = profile.key + '@' + Math.round(size);
    if (_bitmaps[key]) return _bitmaps[key];
    var cv = _C.carve(profile, size);
    var bmp = new Bitmap(cv.width, cv.height);
    bmp.context.drawImage(cv, 0, 0);
    bmp._baseTexture.update();
    /* ⛔ The knot travels WITH the bitmap. A Bitmap is not a canvas, so the
     * property `carve()` reports has to be carried across explicitly or every
     * caller goes back to guessing at a fraction of the bounding box. */
    bmp.visageKnot = cv.visageKnot;
    _bitmaps[key] = bmp;
    return bmp;
  }

  /* --------------------------------------------------------------- the API -- */

  /** @param {number} id Enemy id. @returns {boolean} whether a scene was pushed */
  function unmask(id) {
    var p = read(id);
    if (!p) return false;
    take('enemy', p.id);
    SceneManager.push(Scene_VisageUnmask);
    SceneManager.prepareNextScene(p);
    return true;
  }

  /** @param {number} id Actor id. @returns {boolean} */
  function unmaskActor(id) {
    var p = readActor(id);
    if (!p) return false;
    take('actor', p.id);
    SceneManager.push(Scene_VisageUnmask);
    SceneManager.prepareNextScene(p);
    return true;
  }

  /** Open the wall. */
  function openRack() { SceneManager.push(Scene_VisageRack); }

  /**
   * Every profile the player has taken, plus the empty pegs.
   * @returns {object[]} Profiles in database order, `null` where not yet found.
   */
  function rackRows() {
    var all = profiles();
    var out = [];
    for (var i = 0; i < all.length; i++) {
      out.push(isTaken(all[i].kind, all[i].id) ? all[i] : null);
    }
    return out;
  }

  return {
    PLUGIN: PLUGIN,
    SAVE_VERSION: SAVE_VERSION,
    deps: deps,
    params: params,
    parseFactions: parseFactions,
    P: P,
    _setParamsForTest: _setParamsForTest,
    store: store,
    keyOf: keyOf,
    isTaken: isTaken,
    take: take,
    taken: taken,
    profiles: profiles,
    invalidate: invalidate,
    read: read,
    readActor: readActor,
    bitmapFor: bitmapFor,
    unmask: unmask,
    unmaskActor: unmaskActor,
    openRack: openRack,
    rackRows: rackRows
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.Visage;

/* ===========================================================================
 * Everything below needs the engine. ⛔ Guarded so the headless suite can
 * `require` this file for its parameter parsing and save schema without
 * `Scene_Base` existing (wing §12.7: a module that half-loads is worse than
 * one that does not load — this half is all-or-nothing).
 * ======================================================================== */
if (typeof Scene_Base !== 'undefined') {
  (function () {
    'use strict';
    var VS = CSAF.Visage;

    /* ------------------------------------------------------- the save slot -- */
    var _Game_System_initialize = Game_System.prototype.initialize;
    Game_System.prototype.initialize = function () {
      _Game_System_initialize.apply(this, arguments);
      this._csafVisage = { v: VS.SAVE_VERSION, taken: {} };
    };

    /* Fonts, and the party's own masks, once the database exists. */
    var _Scene_Boot_start = Scene_Boot.prototype.start;
    Scene_Boot.prototype.start = function () {
      _Scene_Boot_start.apply(this, arguments);
      try { VS.deps().ensureFonts(VS.P().fontFolder); } catch (e) { /* reported on first use */ }
    };

    /* ------------------------------------------------------ the menu entry -- */
    var _Window_MenuCommand_addOriginalCommands = Window_MenuCommand.prototype.addOriginalCommands;
    Window_MenuCommand.prototype.addOriginalCommands = function () {
      _Window_MenuCommand_addOriginalCommands.apply(this, arguments);
      var label = VS.P().menuCommand;
      if (label && String(label).trim() !== '') this.addCommand(String(label), 'csafVisage', true);
    };

    var _Scene_Menu_createCommandWindow = Scene_Menu.prototype.createCommandWindow;
    Scene_Menu.prototype.createCommandWindow = function () {
      _Scene_Menu_createCommandWindow.apply(this, arguments);
      this._commandWindow.setHandler('csafVisage', function () {
        SceneManager.push(Scene_VisageRack);
      });
    };

    /* -------------------------------------------- the mask on first defeat --
     * ⛔ `BattleManager.processVictory` is the seam, and it is verified against
     * `rmmz_managers.js` rather than remembered (wing §8 trap 10, §23a: a typo
     * here creates a method NOTHING CALLS and every test still passes). The
     * reveal is QUEUED rather than pushed: pushing a scene from inside victory
     * processing lands underneath the victory messages. */
    var _BattleManager_processVictory = BattleManager.processVictory;
    BattleManager.processVictory = function () {
      if (VS.P().unmaskOnDefeat && $gameTroop) {
        var members = $gameTroop.members();
        for (var i = 0; i < members.length; i++) {
          var id = members[i].enemyId();
          if (!VS.isTaken('enemy', id) && VS.read(id)) {
            if (!$gameTemp._csafVisageQueue) $gameTemp._csafVisageQueue = [];
            if ($gameTemp._csafVisageQueue.indexOf(id) < 0) $gameTemp._csafVisageQueue.push(id);
          }
        }
      }
      _BattleManager_processVictory.apply(this, arguments);
    };

    var _Scene_Map_update = Scene_Map.prototype.update;
    Scene_Map.prototype.update = function () {
      _Scene_Map_update.apply(this, arguments);
      var q = $gameTemp && $gameTemp._csafVisageQueue;
      if (q && q.length && !SceneManager.isSceneChanging() && !$gameMessage.isBusy()
        && $gameMap && !$gameMap.isEventRunning()) {
        var id = q.shift();
        VS.unmask(id);
      }
    };

    /* ---------------------------------------------------- the plugin commands -- */
    PluginManager.registerCommand(VS.PLUGIN, 'unmask', function (args) {
      var id = Number(args.enemyId);
      if (id > 0) VS.unmask(id);
    });
    PluginManager.registerCommand(VS.PLUGIN, 'unmaskActor', function (args) {
      var id = Number(args.actorId);
      if (id > 0) VS.unmaskActor(id);
    });
    PluginManager.registerCommand(VS.PLUGIN, 'openRack', function () {
      VS.openRack();
    });
    PluginManager.registerCommand(VS.PLUGIN, 'takeMask', function (args) {
      var id = Number(args.enemyId);
      if (id > 0 && VS.read(id)) VS.take('enemy', id);
    });
    PluginManager.registerCommand(VS.PLUGIN, 'showMaskPicture', function (args) {
      var id = Number(args.enemyId);
      var p = id > 0 ? VS.read(id) : null;
      if (!p) return;
      var pid = Math.max(1, Number(args.pictureId) || 1);
      var h = Math.max(48, Number(args.height) || 300);
      /* ⛔ A Game_Picture names a FILE. The mask is not a file, so it is put
       * into `ImageManager`'s cache under a private key and the picture is
       * pointed at that key — which is how a generated image becomes a picture
       * the event editor can move, tint and time like any other. */
      var name = '$csafVisage' + p.key.replace(/[^A-Za-z0-9]/g, '_') + '_' + Math.round(h);
      var bmp = VS.bitmapFor(p, h);
      ImageManager._cache = ImageManager._cache || {};
      ImageManager._cache['img/pictures/' + name + '.png'] = bmp;
      $gameScreen.showPicture(pid, name, 1, Number(args.x) || 0, Number(args.y) || 0, 100, 100, 255, 0);
    });

    /* ⛔ `ImageManager.loadPicture` goes through `loadBitmap`, which builds a
     * url and a cache key. Rather than guess at that key, the loader is
     * extended to hand back our own bitmap when the name is one of ours — and
     * it CALLS the original for every other name. */
    var _ImageManager_loadPicture = ImageManager.loadPicture;
    ImageManager.loadPicture = function (filename) {
      var hit = this._cache && this._cache['img/pictures/' + filename + '.png'];
      if (hit && String(filename).indexOf('$csafVisage') === 0) return hit;
      return _ImageManager_loadPicture.apply(this, arguments);
    };

    /* =====================================================================
     * Scene_VisageUnmask — the reveal
     * ⛔ A `Scene_Base` that draws its own wall. NO `Window_Base` ANYWHERE,
     * and every stock `Sprite_Button` detached (wing §15: `windowsDrawn: 0` is
     * blind to MZ's touch-UI buttons, which are Sprites, and
     * `Scene_Map.updateMenuButton` re-shows them every frame).
     * ================================================================== */
    function Scene_VisageUnmask() { this.initialize.apply(this, arguments); }
    Scene_VisageUnmask.prototype = Object.create(Scene_Base.prototype);
    Scene_VisageUnmask.prototype.constructor = Scene_VisageUnmask;
    globalThis.Scene_VisageUnmask = Scene_VisageUnmask;

    Scene_VisageUnmask.prototype.initialize = function () {
      Scene_Base.prototype.initialize.call(this);
      this._profile = null;
      this._ready = false;
    };

    Scene_VisageUnmask.prototype.prepare = function (profile) { this._profile = profile; };

    Scene_VisageUnmask.prototype.create = function () {
      Scene_Base.prototype.create.call(this);
      this._plate = new Sprite(new Bitmap(Graphics.width, Graphics.height));
      this.addChild(this._plate);
      this.drawPlate();
      this._ready = true;
    };

    Scene_VisageUnmask.prototype.drawPlate = function () {
      var R = VS.deps();
      var p = this._profile;
      var b = this._plate.bitmap;
      var ctx = b.context;
      var W = b.width; var H = b.height;
      R.wall(ctx, W, H, p ? p.seed : 1, 96);
      if (!p) { b._baseTexture.update(); return; }

      var size = VS.P().revealSize;
      var m = VS.bitmapFor(p, size);
      var cx = Math.round(W * 0.5);

      /* ⛔⛔ THE LAYOUT IS DERIVED FROM THE MASK, NOT FROM FRACTIONS OF THE
       * SCREEN. Peg at 0.147H and centre at 0.53H are fixed points, and the
       * object hung between them is NOT a fixed height: a `bare` mask is about
       * `size` tall and a `sunDisc` or `antlerFrame` is half as tall again. The
       * two consequences both shipped in the build stage's own screenshots —
       * a tall crown rose THROUGH the peg so the mask hung from a peg buried
       * inside it, and the cord, whatever was left of it, was a stub of a dozen
       * pixels (the inherited art-defect list, items 5 and 6: "the placard
       * crowds the continue hint", "the cord is short and nearly vertical").
       *
       * ⛔ wing §25b is the same lesson one object over: size a frame from the
       * long run, not the short one. So the whole assembly — cord, mask, gap,
       * placard — is measured as a STACK and the stack is centred in the space
       * that is actually available, with the cord given a real length first and
       * the peg placed from the knot rather than the knot from the peg. */
      var cordLen = Math.max(30, Math.round(size * 0.125));
      var plH = 44; var plGap = 14;
      var hintRoom = 26;                       /* the continue hint owns the last rows */
      var stack = cordLen + m.height + plGap + plH;
      var top = Math.round((H - hintRoom - stack) / 2);
      if (top < 18) top = 18;                  /* a very tall mask sits high, never clipped */
      var maskTop = top + cordLen;
      var cy = Math.round(maskTop + m.height / 2);

      var k = m.visageKnot || [m.width * 0.30, m.height * 0.10];
      var knotX = Math.round(cx - m.width / 2 + k[0]);
      var knotY = Math.round(maskTop + k[1]);
      /* ⛔ The peg clears the TOP OF THE OBJECT as well as the knot: on a crown
       * that is tallest at the centre — a crest, a plume — the knot column is
       * off to one side and lower, so hanging the peg a cord's length above the
       * KNOT alone still buries it in the middle of the crown. */
      var pegY = Math.max(20, Math.min(knotY - cordLen, maskTop - 10));

      var cordW = Math.max(2, Math.round(size * 0.0075));
      R.peg(ctx, cx, pegY, Math.max(6, Math.round(size * 0.031)));
      R.cord(ctx, cx, pegY, knotX, knotY, cordW, 'run');

      ctx.save();
      ctx.shadowColor = 'rgba(0,0,0,0.62)';
      ctx.shadowBlur = size * 0.062;
      ctx.shadowOffsetX = size * 0.034;
      ctx.shadowOffsetY = size * 0.038;
      ctx.drawImage(m.canvas || m._canvas, cx - m.width / 2, maskTop);
      ctx.restore();
      R.cord(ctx, cx, pegY, knotX, knotY, cordW, 'knot');

      var pp = VS.P();
      ctx.textAlign = 'center';
      if (pp.unmaskEyebrow && pp.unmaskEyebrow.trim() !== '') {
        ctx.font = '15px ' + R.FACES.body;
        ctx.fillStyle = 'rgba(201,162,74,0.85)';
        ctx.fillText(String(pp.unmaskEyebrow).toUpperCase(), cx, Math.round(H * 0.072));
      }
      R.placard(ctx, {
        x: cx - 150, y: Math.min(H - hintRoom - plH, maskTop + m.height + plGap), w: 300, h: plH,
        title: p.name, readings: p.readings
      });
      if (pp.continueHint && pp.continueHint.trim() !== '') {
        ctx.font = '13px ' + R.FACES.body;
        ctx.fillStyle = 'rgba(230,217,190,0.45)';
        ctx.fillText(String(pp.continueHint), cx, H - 14);
      }
      b._baseTexture.update();
    };

    Scene_VisageUnmask.prototype.update = function () {
      Scene_Base.prototype.update.call(this);
      if (!this._ready || this.isBusy()) return;
      if (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered()) {
        SoundManager.playCancel();
        this.popScene();
      }
    };

    /* =====================================================================
     * Scene_VisageRack — the wall the player fills
     * ================================================================== */
    function Scene_VisageRack() { this.initialize.apply(this, arguments); }
    Scene_VisageRack.prototype = Object.create(Scene_Base.prototype);
    Scene_VisageRack.prototype.constructor = Scene_VisageRack;
    globalThis.Scene_VisageRack = Scene_VisageRack;

    Scene_VisageRack.prototype.initialize = function () {
      Scene_Base.prototype.initialize.call(this);
      this._index = 0;
      this._page = 0;
      this._rows = null;
      this._dirty = true;
    };

    /**
     * ⛔ wing §18b: SOLVE the peg grid, never hard-code a column count. Glaze
     * shipped `cols = 6` and put twelve vessels at 114 px into 266 px rows. Try
     * every plausible column count, keep the LARGEST cell, break ties on fewest
     * empty cells, and reserve a foot margin — the row pitch is the FRAME'S,
     * not the cell's.
     * @returns {{cols:number, rows:number, cell:number, x0:number, y0:number, perPage:number}}
     */
    Scene_VisageRack.prototype.solveGrid = function () {
      var W = Graphics.width;
      var headH = 62;
      var footH = 30;
      var availW = W - 48;
      var availH = Graphics.height - headH - footH;
      var best = null;
      for (var cols = 3; cols <= 7; cols++) {
        for (var rows = 2; rows <= 4; rows++) {
          var cw = Math.floor(availW / cols);
          var ch = Math.floor(availH / rows);
          var cell = Math.min(cw, ch);
          if (cell < 140) continue;                 /* the brief's floor: never icon scale */
          var per = cols * rows;
          var empty = (per - (this.rowCount() % per || per)) % per;
          /* ⛔ MAXIMISE CELLS PER PAGE, NOT CELL SIZE. Wing §18b says keep the
           * largest cell, and that is right for a grid whose danger is being
           * too SMALL. A collection screen's danger is the opposite: "keep the
           * largest cell" chose 3x2 at 256 px, and the in-engine Rack came back
           * six masks adrift in a lot of empty wall, when the brief asks for
           * 4x3. The 140 px floor is what protects against icon scale; above
           * it, showing more of the collection wins. */
          if (!best || per > best.per || (per === best.per && cell > best.cell)
            || (per === best.per && cell === best.cell && empty < best.empty)) {
            best = { cols: cols, rows: rows, cell: cell, empty: empty, per: per };
          }
        }
      }
      if (!best) best = { cols: 3, rows: 2, cell: 140, empty: 0 };
      var gridW = best.cols * best.cell;
      var gridH = best.rows * best.cell;
      return {
        cols: best.cols,
        rows: best.rows,
        cell: best.cell,
        x0: Math.round((W - gridW) / 2),
        y0: headH + Math.round((availH - gridH) / 2),
        perPage: best.cols * best.rows
      };
    };

    Scene_VisageRack.prototype.rowCount = function () {
      if (!this._rows) this._rows = VS.rackRows();
      return this._rows.length;
    };

    Scene_VisageRack.prototype.create = function () {
      Scene_Base.prototype.create.call(this);
      this._rows = VS.rackRows();
      this._plate = new Sprite(new Bitmap(Graphics.width, Graphics.height));
      this.addChild(this._plate);
    };

    Scene_VisageRack.prototype.update = function () {
      Scene_Base.prototype.update.call(this);
      this.processInput();
      if (this._dirty) { this.drawPlate(); this._dirty = false; }
    };

    /** ⛔ Zero allocation: no array literal, no closure, no string built here. */
    Scene_VisageRack.prototype.processInput = function () {
      if (this.isBusy()) return;
      var g = this.solveGrid();
      var n = this._rows.length;
      var moved = false;
      if (Input.isRepeated('right')) { this._index = (this._index + 1) % n; moved = true; }
      if (Input.isRepeated('left')) { this._index = (this._index - 1 + n) % n; moved = true; }
      if (Input.isRepeated('down')) { this._index = Math.min(n - 1, this._index + g.cols); moved = true; }
      if (Input.isRepeated('up')) { this._index = Math.max(0, this._index - g.cols); moved = true; }
      if (Input.isTriggered('pagedown')) { this._index = Math.min(n - 1, this._index + g.perPage); moved = true; }
      if (Input.isTriggered('pageup')) { this._index = Math.max(0, this._index - g.perPage); moved = true; }
      if (moved) {
        SoundManager.playCursor();
        this._page = Math.floor(this._index / g.perPage);
        this._dirty = true;
      }
      if (Input.isTriggered('ok')) {
        var p = this._rows[this._index];
        if (p) {
          SoundManager.playOk();
          SceneManager.push(Scene_VisageUnmask);
          SceneManager.prepareNextScene(p);
        } else {
          SoundManager.playBuzzer();
        }
      }
      if (Input.isTriggered('cancel')) { SoundManager.playCancel(); this.popScene(); }
    };

    Scene_VisageRack.prototype.drawPlate = function () {
      var R = VS.deps();
      var b = this._plate.bitmap;
      var ctx = b.context;
      var W = b.width; var H = b.height;
      var g = this.solveGrid();
      var rows = this._rows;
      var pp = VS.P();
      R.wall(ctx, W, H, 4242, 96);

      var first = this._page * g.perPage;
      var pages = Math.max(1, Math.ceil(rows.length / g.perPage));

      for (var i = 0; i < g.perPage; i++) {
        var idx = first + i;
        if (idx >= rows.length) break;
        var col = i % g.cols;
        var row = Math.floor(i / g.cols);
        var cx = g.x0 + col * g.cell + Math.round(g.cell / 2);
        var cellTop = g.y0 + row * g.cell;
        var p = rows[idx];

        /* ⛔ THE SAME DERIVED STACK AS THE UNMASKING, PER CELL. Fixed fractions
         * of the cell put the peg at 0.10 and the mask's centre at 0.56 whatever
         * was hanging there, so a bare mask left a wide band of empty wall under
         * its peg while a tall crown crowded it — and the cord, at rack scale,
         * came out as a stub with a bead on the end. Each mask is measured and
         * its own cord-plus-object stack is centred in its cell. */
        var cellCordLen = Math.max(9, Math.round(g.cell * 0.125));
        var pegR = Math.max(3, Math.round(g.cell * 0.034));
        var pegY = cellTop + Math.round(g.cell * 0.07);

        if (p) {
          var mm = VS.bitmapFor(p, Math.round(g.cell * 0.64));
          var stackH = cellCordLen + mm.height;
          var sTop = cellTop + Math.round((g.cell - stackH) / 2);
          if (sTop < cellTop + 3) sTop = cellTop + 3;
          var mTop = sTop + cellCordLen;
          var kk = mm.visageKnot || [mm.width * 0.28, mm.height * 0.10];
          var kX = Math.round(cx - mm.width / 2 + kk[0]);
          var kY = Math.round(mTop + kk[1]);
          var cW = Math.max(1.5, g.cell * 0.016);
          pegY = Math.max(cellTop + 3, Math.min(kY - cellCordLen, mTop - 4));

          R.peg(ctx, cx, pegY, pegR);
          R.cord(ctx, cx, pegY, kX, kY, cW, 'run');
          ctx.save();
          if (idx === this._index) {
            /* ⛔ THE SELECTION IS A WARM RIM, NEVER A CURSOR RECTANGLE — a
             * `Window_Selectable` cursor is the single most recognisable piece
             * of MZ chrome there is (wing §7). */
            ctx.shadowColor = 'rgba(255,208,130,0.95)';
            ctx.shadowBlur = g.cell * 0.14;
            ctx.drawImage(mm.canvas || mm._canvas, cx - mm.width / 2, mTop);
            ctx.shadowBlur = g.cell * 0.09;
          } else {
            ctx.shadowColor = 'rgba(0,0,0,0.55)';
            ctx.shadowBlur = g.cell * 0.055;
            ctx.shadowOffsetX = g.cell * 0.032;
            ctx.shadowOffsetY = g.cell * 0.036;
          }
          ctx.drawImage(mm.canvas || mm._canvas, cx - mm.width / 2, mTop);
          ctx.restore();
          R.cord(ctx, cx, pegY, kX, kY, cW, 'knot');
          continue;
        }

        R.peg(ctx, cx, pegY, pegR);
        /* ⛔ AN EMPTY PEG IS DRAWN, NOT SKIPPED. The collection has to read as
         * incomplete or the wall says nothing about what is left to find. */
        ctx.save();
        ctx.strokeStyle = 'rgba(140,43,36,0.35)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cx, pegY + 4);
        ctx.lineTo(cx - g.cell * 0.04, pegY + g.cell * 0.16);
        ctx.stroke();
        ctx.restore();
      }

      /* the brass count plate, top left */
      R.placard(ctx, {
        x: 24, y: 14, w: 168, h: 38,
        title: VS.taken() + ' OF ' + rows.length, readings: null
      });
      ctx.textAlign = 'center';
      ctx.font = '600 26px ' + R.FACES.display;
      ctx.fillStyle = 'rgba(230,217,190,0.92)';
      ctx.fillText(String(pp.rackTitle), Math.round(W / 2), 40);

      /* the selected mask's name, on the foot, and the page marks */
      var sel = rows[this._index];
      ctx.font = '16px ' + R.FACES.body;
      ctx.fillStyle = 'rgba(230,217,190,0.75)';
      ctx.fillText(sel ? sel.name : '—', Math.round(W / 2), H - 12);
      if (pages > 1) {
        ctx.textAlign = 'right';
        ctx.font = '13px ' + R.FACES.body;
        ctx.fillStyle = 'rgba(201,162,74,0.75)';
        ctx.fillText((this._page + 1) + ' / ' + pages, W - 20, H - 12);
      }
      b._baseTexture.update();
    };
  })();
}
