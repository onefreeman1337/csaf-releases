//=============================================================================
// VisageRead.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Visage [1/4] — the reading. Turns an enemy, actor or troop record into a mask profile: structure, superstructure, pigment, house, age, break. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Visage — the reading
 * ============================================================================
 * Load this FIRST. It defines no scene, adds no command and patches no core
 * method. It is pure derivation and can be read end to end in an afternoon.
 *
 * THIS FILE IS THE PRODUCT'S ARGUMENT. A mask pack ships five masks. A face
 * pack ships a hundred faces and your own creature is not one of them. This
 * reads the record YOU wrote and derives what the mask IS, so a Bog Wight and
 * a Cinder Drake do not merely get different labels — they get a different
 * face structure, a different superstructure, a different pigment, a different
 * inlay and a different amount of wear, and every one of those is traceable
 * back to a field in your database.
 *
 * THE SIX AXES
 *   STRUCTURE (10)      what the creature IS       from its name, then its note,
 *                       then the shape of its own parameters
 *   SUPERSTRUCTURE (12) what it has EARNED         from its rank: where its power
 *                       sits as a percentile of YOUR OWN database
 *   PIGMENT (9)         what it STRIKES WITH       from its attack element, the
 *                       elements of its skills, or what it resists
 *   HOUSE (6)           what it BELONGS TO         from your faction table, else
 *                       from the goods it carries
 *   AGE (5)             how long it has STOOD      from rank and hardiness
 *   BREAK (6)           the one asymmetry          hashed from the record, so a
 *                       creature's mask is always the same mask
 *
 * NOTETAGS — every axis can be written by hand and the hand always wins.
 *   <visage type: beast>          <visage rank: 9>       (0-11)
 *   <visage element: fire>        <visage faction: Thornwood Clan>
 *   <visage age: ancient>         <visage: skip>         (never carve this one)
 *   <visage name: The Bog Wight>  (the name engraved on the placard)
 *
 * SCRIPT
 *   CSAF.VisageRead.readEnemy(enemyId)   -> profile
 *   CSAF.VisageRead.readActor(actorId)   -> profile
 *   CSAF.VisageRead.readAll()            -> every carveable record
 * ============================================================================
 */

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};
var CSAF = globalThis.CSAF;

CSAF.VisageRead = (function () {
  'use strict';

  /* ══════════════════════════════════════════════════════ the vocabularies ══
   * ⛔ Each of these lists is ORDERED and the order is the meaning: the index
   * IS the value the renderer draws. Nothing downstream may reorder them
   * without a save-schema bump. */

  /** The ten face structures. */
  var STRUCTURES = ['beast', 'humanoid', 'undead', 'spirit', 'construct',
    'dragon', 'insect', 'aquatic', 'plant', 'fiend'];

  /**
   * The twelve superstructures, HUMBLEST → GRANDEST. ⛔ wing §25g: standing has
   * to be VISIBLE, so rank does not tint a mask — it grows a different thing
   * out of its brow. Band 0 is bare because a rat is not owed a crown.
   */
  var CROWNS = ['bare', 'browRidge', 'twinHorns', 'crest', 'fan', 'antlerFrame',
    'plume', 'haloRing', 'tuskPair', 'crownOfThorns', 'mane', 'sunDisc'];

  /**
   * Pigment by `System.json` element INDEX. Index 0 is the engine's blank row
   * and index 1 is Physical — neither is a colour, and both leave the mask
   * unpainted so the base material reads (the brief: "Physical = unpainted").
   * ⛔ An index BEYOND this table derives a hue from its index and is never
   * left unpainted: a buyer who added "Blood" as element 10 must see it.
   */
  var PIGMENTS = [
    { id: 'none', label: '', hex: null },
    { id: 'physical', label: 'PHYSICAL', hex: null },
    { id: 'fire', label: 'FIRE', hex: '#C8452A' },
    { id: 'ice', label: 'ICE', hex: '#8CC1DA' },
    { id: 'thunder', label: 'THUNDER', hex: '#E2B83A' },
    { id: 'water', label: 'WATER', hex: '#2F6F8F' },
    { id: 'earth', label: 'EARTH', hex: '#8A6A3D' },
    { id: 'wind', label: 'WIND', hex: '#8FBF8A' },
    { id: 'light', label: 'LIGHT', hex: '#F2E6B8' },
    { id: 'darkness', label: 'DARKNESS', hex: '#4A2F5E' }
  ];

  /** The six inlay-and-binding treatments. */
  var HOUSES = ['goldWire', 'verdigris', 'ironRivet', 'shell', 'bonePin', 'lacquerThread'];

  /** The five wear states, GREENEST → most worn. */
  var AGES = ['green', 'seasoned', 'old', 'ancient', 'relic'];

  /** The six seeded structural breaks. Exactly one is carried by every mask. */
  var BREAKS = ['brokenHorn', 'faceCrack', 'cordScar', 'chippedJaw', 'boundCrack', 'scorch'];

  /* ═══════════════════════════════════════════════════ the name classifier ══
   * ⛔ wing §21f-5 and §12.10: every matcher here is word-BOUNDED and carries
   * controls in both directions (phantoms it must reject, targets it must
   * accept) in `visage_read.test.js`. An unbounded `ant` matches "Giant",
   * "Servant" and "Elephant"; an unbounded `imp` matches "Impaler". The tests
   * pin all of those as phantoms.
   * ⛔ NAME_GUARD: a word under three letters is REFUSED, never guessed — but
   * wing §2b (Refectory's "ox") records that a refusal which silently kills a
   * declared row is its own defect, so `deadWords()` below PRINTS any row this
   * guard would kill and the suite asserts the list is empty.
   */
  var NAME_GUARD = 3;

  var TYPE_WORDS = {
    beast: ['wolf', 'wolves', 'bear', 'boar', 'lion', 'tiger', 'hound', 'dog', 'fox', 'rat',
      'bat', 'ape', 'goat', 'stag', 'deer', 'horse', 'oxen', 'bull', 'hare', 'rabbit', 'badger',
      'lynx', 'panther', 'jackal', 'hyena', 'beast', 'brute', 'fang', 'claw', 'mane', 'wildcat',
      'cougar', 'weasel', 'ferret', 'mole', 'boarhound', 'warg', 'direwolf', 'chimera'],
    humanoid: ['goblin', 'orc', 'ogre', 'troll', 'bandit', 'brigand', 'soldier', 'knight',
      'mage', 'witch', 'warlock', 'thief', 'guard', 'cultist', 'pirate', 'gnome', 'dwarf',
      'elf', 'giant', 'hobgoblin', 'kobold', 'lord', 'king', 'queen', 'priest', 'monk',
      'warrior', 'raider', 'mercenary', 'assassin', 'archer', 'sellsword', 'marauder'],
    undead: ['skeleton', 'zombie', 'ghoul', 'wight', 'lich', 'mummy', 'revenant', 'corpse',
      'bone', 'undead', 'draugr', 'vampire', 'necromancer', 'barrow', 'grave', 'crypt',
      'tomb', 'rotting', 'risen', 'cadaver', 'ossuary'],
    spirit: ['ghost', 'spirit', 'shade', 'wraith', 'phantom', 'spectre', 'specter', 'banshee',
      'soul', 'apparition', 'poltergeist', 'haunt', 'revenance', 'shadeling', 'ethereal'],
    construct: ['golem', 'automaton', 'statue', 'puppet', 'doll', 'machine', 'mech', 'sentinel',
      'construct', 'clockwork', 'idol', 'effigy', 'colossus', 'gargoyle', 'servitor', 'engine',
      'juggernaut', 'armature'],
    dragon: ['dragon', 'wyvern', 'drake', 'wyrm', 'lindworm', 'hydra', 'basilisk', 'salamander',
      'draconic', 'serpent', 'naga', 'behemoth'],
    insect: ['beetle', 'spider', 'wasp', 'bee', 'mantis', 'moth', 'scorpion', 'centipede',
      'locust', 'roach', 'insect', 'larva', 'grub', 'hornet', 'weaver', 'swarm', 'carapace',
      'chitin', 'arachnid', 'antlion'],
    aquatic: ['fish', 'shark', 'squid', 'octopus', 'kraken', 'crab', 'eel', 'siren', 'mermaid',
      'turtle', 'jellyfish', 'leviathan', 'toad', 'frog', 'newt', 'urchin', 'whale', 'lamprey',
      'barnacle', 'tidal', 'brine', 'drowned', 'reef'],
    plant: ['treant', 'vine', 'mold', 'mould', 'fungus', 'shroom', 'mushroom', 'flower',
      'bloom', 'root', 'thorn', 'sprout', 'moss', 'plant', 'bramble', 'dryad', 'creeper',
      'husk', 'blight', 'mandrake', 'thistle', 'briar'],
    fiend: ['demon', 'devil', 'fiend', 'imp', 'succubus', 'incubus', 'hell', 'infernal',
      'abyss', 'daemon', 'archfiend', 'nightmare', 'damned', 'pit', 'brimstone', 'horned']
  };

  /**
   * Word-bounded, case-insensitive, punctuation-tolerant containment.
   * ⛔ wing §21f-5: written as a built RegExp with an escaped source, never as
   * a substring `indexOf` — an unbounded matcher invents a territory. A word
   * shorter than NAME_GUARD is refused outright rather than guessed.
   * ⛔ THE SUFFIX RULE IS `(e?s)?` AND NOTHING WIDER. The first draft allowed
   * `[a-z]{0,2}`, which reads as "tolerate an inflection" and is really "match
   * two junk letters": MEASURED, it made `bat` match "Bathhouse" and `pit`
   * match "Pith". A plural is a plural; anything else is a different word.
   *
   * @param {string} text Any haystack.
   * @param {string} word The needle.
   * @returns {boolean} True only on a whole-word (or plural) match.
   */
  function namesWord(text, word) {
    if (!text || !word) return false;
    var w = String(word);
    if (w.length < NAME_GUARD) return false;
    var esc = w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp('(^|[^a-z0-9])' + esc + '(e?s)?([^a-z0-9]|$)', 'i').test(String(text));
  }

  /** @returns {string[]} declared words this guard silently kills. Must be empty. */
  function deadWords() {
    var dead = [];
    for (var k in TYPE_WORDS) {
      if (!Object.prototype.hasOwnProperty.call(TYPE_WORDS, k)) continue;
      for (var i = 0; i < TYPE_WORDS[k].length; i++) {
        if (TYPE_WORDS[k][i].length < NAME_GUARD) dead.push(k + ':' + TYPE_WORDS[k][i]);
      }
    }
    return dead;
  }

  /* ════════════════════════════════════════════════════ deterministic seam ══
   * ⛔ wing rule 2: never `Math.random()` in game logic. Every choice below
   * that is not read from the database is hashed from a stable record key, so
   * a creature's mask is the same mask on every machine and in every session,
   * and the contact sheet the store shows is the wall the buyer gets. */

  /**
   * FNV-1a, 32-bit, unsigned.
   * @param {string} str Key.
   * @returns {number} 0 … 4294967295.
   */
  function hash(str) {
    var h = 2166136261;
    var s = String(str);
    for (var i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
    }
    return h >>> 0;
  }

  /**
   * mulberry32. A generator, not a global — the renderer takes its own.
   * @param {number} seed Any uint32.
   * @returns {function(): number} () => [0,1)
   */
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ═════════════════════════════════════════════════════════════ notetags ══ */

  /**
   * Read one `<visage KEY: VALUE>` (or bare `<visage: VALUE>`) out of a note.
   * @param {string} note The record's note field.
   * @param {string} [key] The key, or omitted for the bare form.
   * @returns {string|null} The trimmed value, or null.
   */
  function tag(note, key) {
    if (!note) return null;
    var re = key
      ? new RegExp('<\\s*visage\\s+' + key + '\\s*:([^>]*)>', 'i')
      : /<\s*visage\s*:([^>]*)>/i;
    var m = String(note).match(re);
    return m ? String(m[1]).trim() : null;
  }

  /* ══════════════════════════════════════════════════════════ 1. STRUCTURE ══ */

  /**
   * The parameter-SHAPE fallback, for a record whose name says nothing.
   *
   * ⛔ wing §21i: a decision tree returns one answer per branch, which is how a
   * 32,400-mask corpus collapses to five pictures in a buyer's project. This is
   * therefore a 3×3 GRID over two independent axes rather than a chain of ifs,
   * plus one outlier rule — all ten structures are reachable, and the suite
   * asserts every one of them is actually reached by some parameter shape.
   *
   *   axis A  physicality  (atk+def) / (atk+def+mat+mdf)
   *   axis B  quickness    agi / (agi + mhp/10)
   *   outlier luck share more than 1.6× the mean share → fiend
   *
   * @param {number[]} params The engine's eight-slot params array.
   * @returns {string} A structure id.
   */
  function structureFromShape(params) {
    var p = params || [];
    var mhp = Math.max(1, Number(p[0]) || 1);
    var atk = Math.max(0, Number(p[2]) || 0);
    var def = Math.max(0, Number(p[3]) || 0);
    var mat = Math.max(0, Number(p[4]) || 0);
    var mdf = Math.max(0, Number(p[5]) || 0);
    var agi = Math.max(0, Number(p[6]) || 0);
    var luk = Math.max(0, Number(p[7]) || 0);

    var four = atk + def + mat + mdf;
    var six = four + agi + luk;
    if (six > 0 && luk / six > (1.6 / 6)) return 'fiend';

    var a = four > 0 ? (atk + def) / four : 0.5;
    var b = agi + mhp / 10 > 0 ? agi / (agi + mhp / 10) : 0.5;
    var ai = a < 0.42 ? 0 : (a < 0.58 ? 1 : 2);
    var bi = b < 0.25 ? 0 : (b < 0.45 ? 1 : 2);
    var GRID = [
      ['spirit', 'undead', 'aquatic'],
      ['plant', 'humanoid', 'insect'],
      ['construct', 'dragon', 'beast']
    ];
    return GRID[ai][bi];
  }

  /**
   * Score the record's own words against the ten vocabularies.
   * @param {object} rec A normalised record (see `normalise`).
   * @returns {{id:string|null,score:number,hits:string[]}} Best structure.
   */
  function structureFromWords(rec) {
    var fields = [
      [rec.name, 3],
      [rec.battlerName, 2],
      [rec.note, 2],
      [rec.className, 1],
      [rec.nickname, 1]
    ];
    var best = null; var bestScore = 0; var bestHits = [];
    for (var t = 0; t < STRUCTURES.length; t++) {
      var id = STRUCTURES[t];
      var words = TYPE_WORDS[id];
      var score = 0; var hits = [];
      for (var f = 0; f < fields.length; f++) {
        var text = fields[f][0];
        if (!text) continue;
        for (var w = 0; w < words.length; w++) {
          if (namesWord(text, words[w])) { score += fields[f][1]; hits.push(words[w]); }
        }
      }
      if (score > bestScore) { bestScore = score; best = id; bestHits = hits; }
    }
    return { id: best, score: bestScore, hits: bestHits };
  }

  /* ═══════════════════════════════════════════════════════════════ 2. RANK ══
   * ⛔ The brief is explicit and it is the whole point: rank is a PERCENTILE
   * within the BUYER'S OWN database, never a taste threshold typed here. A
   * project whose toughest creature has 400 HP and a project whose toughest has
   * 90,000 both get a full spread of superstructures. */

  /**
   * A single comparable power figure for a record.
   * @param {object} rec Normalised record.
   * @returns {number} Power, in arbitrary but monotone units.
   */
  function power(rec) {
    var p = rec.params || [];
    var n = function (i) { return Math.max(0, Number(p[i]) || 0); };
    var offence = n(2) + n(4);
    var defence = n(3) + n(5);
    var body = n(0) + n(1) * 0.5;
    var lvl = Math.max(0, Number(rec.level) || 0);
    var exp = Math.max(0, Number(rec.exp) || 0);
    return body + (offence + defence) * 6 + exp * 2 + lvl * 40;
  }

  /**
   * Percentile of `value` within `all`, as a fraction in [0,1].
   * ⛔ Ties share a percentile: two identical creatures are SIBLINGS BY DESIGN
   * (wing §25g) and must not be spread apart by their database order.
   * @param {number} value The record's power.
   * @param {number[]} all Every power in the same cohort.
   * @returns {number} 0 … 1.
   */
  function percentile(value, all) {
    if (!all || all.length <= 1) return 0.5;
    var below = 0; var equal = 0;
    for (var i = 0; i < all.length; i++) {
      if (all[i] < value) below++;
      else if (all[i] === value) equal++;
    }
    return (below + (equal - 1) / 2) / (all.length - 1 || 1);
  }

  /** @param {number} pct 0…1 @returns {number} rank band 0…11 */
  function bandOf(pct) {
    var b = Math.floor(pct * CROWNS.length);
    if (b < 0) b = 0;
    if (b > CROWNS.length - 1) b = CROWNS.length - 1;
    return b;
  }

  /* ════════════════════════════════════════════════════════════ 3. PIGMENT ══ */

  /**
   * The element a record fights AS, by preference order:
   *   1 an explicit `<visage element:>` tag
   *   2 the Attack Element trait (code 31) — what it strikes with
   *   3 the commonest damage element among its own action skills
   *   4 the element it resists hardest (code 11 with a rate below 1) — a thing
   *     made of fire does not burn
   *   5 nothing: unpainted
   *
   * ⛔ It deliberately does NOT read a WEAKNESS as an identity. The stock
   * Treant takes double Fire; that makes it a plant, not a fire elemental, and
   * an earlier draft that read "strongest element rate" would have painted it
   * red. MEASURED against `BlankProject/data/Enemies.json` id 4.
   *
   * @param {object} rec Normalised record.
   * @param {object} db Injected database tables.
   * @returns {{index:number,why:string}} Element index, and which rule fired.
   */
  function elementOf(rec, db) {
    var names = (db && db.elements) || [];
    var t = tag(rec.note, 'element');
    if (t) {
      for (var i = 0; i < names.length; i++) {
        if (names[i] && String(names[i]).toLowerCase() === t.toLowerCase()) return { index: i, why: 'notetag' };
      }
      var asNum = Number(t);
      if (asNum > 0) return { index: asNum, why: 'notetag' };
    }
    var traits = rec.traits || [];
    var k;
    /* ⛔ `dataId > 1`, NOT `> 0`. Element 1 is Physical, and MEASURED in
     * `BlankProject/data/Weapons.json` id 31 every stock weapon carries
     * `{code:31, dataId:1}` — the engine's default "hits with no element". Read
     * as an identity it is a TRUE value that means nothing, and it short-
     * circuited this whole function: every armed actor came back unpainted and
     * the class-learnings rule below was unreachable (wing §25f — a field read
     * inside another branch is only as alive as that branch). */
    for (k = 0; k < traits.length; k++) {
      if (traits[k].code === 31 && Number(traits[k].dataId) > 1) {
        return { index: Number(traits[k].dataId), why: 'attack element' };
      }
    }
    var tally = {};
    var acts = rec.actions || [];
    for (k = 0; k < acts.length; k++) {
      var sk = (db && db.skills) ? db.skills[acts[k].skillId] : null;
      var eid = sk && sk.damage ? Number(sk.damage.elementId) : 0;
      if (eid > 1) tally[eid] = (tally[eid] || 0) + (Number(acts[k].rating) || 1);
    }
    var bestE = 0; var bestN = 0;
    for (var key in tally) {
      if (!Object.prototype.hasOwnProperty.call(tally, key)) continue;
      if (tally[key] > bestN) { bestN = tally[key]; bestE = Number(key); }
    }
    if (bestE > 1) return { index: bestE, why: 'its own skills' };

    var lowest = null; var lowestRate = 1;
    for (k = 0; k < traits.length; k++) {
      if (traits[k].code === 11 && Number(traits[k].dataId) > 1) {
        var rate = Number(traits[k].value);
        if (rate < lowestRate) { lowestRate = rate; lowest = Number(traits[k].dataId); }
      }
    }
    if (lowest !== null) return { index: lowest, why: 'what it resists' };
    return { index: 1, why: 'unpainted' };
  }

  /**
   * The pigment for an element index, deriving a hue for any index the shipped
   * table does not cover. ⛔ The brief: an index beyond the table is NEVER left
   * unpainted — a buyer who added "Blood" as element 10 must see it.
   * @param {number} index Element index.
   * @param {string[]} names `System.json` element names, for the label.
   * @returns {{id:string,label:string,hex:string|null,index:number}} Pigment.
   */
  function pigmentOf(index, names) {
    var i = Number(index) || 0;
    if (i >= 0 && i < PIGMENTS.length) {
      var p = PIGMENTS[i];
      var label = (names && names[i]) ? String(names[i]).toUpperCase() : p.label;
      return { id: p.id, label: label, hex: p.hex, index: i };
    }
    /* Golden-angle hue walk keeps consecutive custom elements far apart. */
    var hue = ((i * 137.508) % 360 + 360) % 360;
    return {
      id: 'custom' + i,
      label: (names && names[i]) ? String(names[i]).toUpperCase() : ('ELEMENT ' + i),
      hex: hslHex(hue, 0.46, 0.46),
      index: i
    };
  }

  /**
   * @param {number} h Degrees. @param {number} s 0…1. @param {number} l 0…1.
   * @returns {string} `#rrggbb`.
   */
  function hslHex(h, s, l) {
    var c = (1 - Math.abs(2 * l - 1)) * s;
    var hp = (h % 360) / 60;
    var x = c * (1 - Math.abs((hp % 2) - 1));
    var r = 0; var g = 0; var b = 0;
    if (hp < 1) { r = c; g = x; } else if (hp < 2) { r = x; g = c; } else if (hp < 3) { g = c; b = x; } else if (hp < 4) { g = x; b = c; } else if (hp < 5) { r = x; b = c; } else { r = c; b = x; }
    var m = l - c / 2;
    var hx = function (v) {
      var n = Math.round(Math.min(1, Math.max(0, v + m)) * 255).toString(16);
      return n.length < 2 ? '0' + n : n;
    };
    return '#' + hx(r) + hx(g) + hx(b);
  }

  /* ══════════════════════════════════════════════════════════════ 4. HOUSE ══
   * ⛔ wing §25f: a field read inside ANOTHER field's branch is only as alive
   * as that branch is exhaustive. The house must therefore not be derived from
   * the structure or the element — it reads a third, independent thing: what
   * the record CARRIES. The six treatments are six material cultures, and the
   * goods table below reaches all six. */

  /* ⛔ THESE ARE TYPE IDS, READ OUT OF `System.json`, NOT DATABASE IDS. MEASURED
   * against the BlankProject 2026-09-11: weapon TYPE 1 is Dagger and 2 is
   * Sword, but weapon IDS 1, 2, 4 and 5 are all Swords, and armour ids 1-6 are
   * all General Armor. Confusing the two is how the demo roster's drops came to
   * cover four of six houses with `shell` unreachable — caught by the IN-ENGINE
   * run, not by the headless spread check (wing §24a: read the vocabulary out
   * of the engine, never guess at it).
   * ⛔ Index 0 is deliberately absent from both tables: a blank type is the
   * engine's empty row, it says nothing about a culture, and it casts NO VOTE
   * rather than a default one. */
  var WTYPE_HOUSE = {
    1: 'shell', 2: 'ironRivet', 3: 'ironRivet', 4: 'ironRivet', 5: 'lacquerThread',
    6: 'goldWire', 7: 'shell', 8: 'lacquerThread', 9: 'lacquerThread', 10: 'lacquerThread',
    11: 'lacquerThread', 12: 'ironRivet'
  };
  var ATYPE_HOUSE = {
    1: 'verdigris', 2: 'goldWire', 3: 'shell', 4: 'ironRivet', 5: 'shell', 6: 'verdigris'
  };

  /**
   * @param {object} rec Normalised record.
   * @param {object} db Injected tables.
   * @param {object[]} factions The buyer's faction table.
   * @returns {{id:string,name:string,why:string}} House.
   */
  function houseOf(rec, db, factions) {
    var list = factions || [];
    var i;
    var t = tag(rec.note, 'faction');
    if (t) {
      for (i = 0; i < list.length; i++) {
        if (list[i] && String(list[i].name).toLowerCase() === t.toLowerCase()) {
          return { id: normHouse(list[i].treatment, list[i].name), name: list[i].name, why: 'notetag' };
        }
      }
      /* An undeclared faction is still a faction — it keeps its NAME on the
       * placard and takes a stable treatment, rather than being discarded. */
      return { id: HOUSES[hash('house:' + t) % HOUSES.length], name: t, why: 'notetag (undeclared)' };
    }
    for (i = 0; i < list.length; i++) {
      var mem = (list[i] && list[i].members) || [];
      for (var m = 0; m < mem.length; m++) {
        if (Number(mem[m]) === Number(rec.id) && list[i].kind === rec.kind) {
          return { id: normHouse(list[i].treatment, list[i].name), name: list[i].name, why: 'faction table' };
        }
      }
    }
    var goods = goodsHouse(rec, db);
    if (goods) return { id: goods.id, name: goods.name, why: goods.why };
    return { id: HOUSES[hash('house:' + rec.key) % HOUSES.length], name: '', why: 'unaffiliated' };
  }

  /** @param {string} treat @param {string} name @returns {string} a valid house id */
  function normHouse(treat, name) {
    if (treat && HOUSES.indexOf(treat) >= 0) return treat;
    return HOUSES[hash('house:' + String(name || '')) % HOUSES.length];
  }

  /**
   * The house read out of the goods a record carries — an enemy's drops, an
   * actor's equipment. A creature that leaves behind a staff belonged to a
   * different house than one that leaves behind an axe.
   * @param {object} rec Normalised record.
   * @param {object} db Injected tables.
   * @returns {{id:string,name:string,why:string}|null} House, or null.
   */
  function goodsHouse(rec, db) {
    var votes = {};
    var add = function (id, weight) { if (id) votes[id] = (votes[id] || 0) + weight; };
    var weapons = (db && db.weapons) || [];
    var armors = (db && db.armors) || [];
    var i; var g;

    /* ⛔ THE WEAPON OUTWEIGHS THE ARMOUR, 2 TO 1, AND THE WEIGHTS ARE THE FIX
     * FOR A REAL DEFECT. With every vote worth 1, Reid (sword + plate) and
     * Priscilla (dagger + robe) both came back `ironRivet` — a one-all TIE that
     * was silently settled by JavaScript's object key ORDER, which is not a
     * decision, is invisible, and made two party members carve the same mask
     * (MEASURED 2026-09-11 on the stock Actors.json). What a person FIGHTS with
     * says more about their house than what they happen to be wearing. */
    var drops = rec.dropItems || [];
    for (i = 0; i < drops.length; i++) {
      g = drops[i];
      if (!g || !Number(g.dataId)) continue;
      if (Number(g.kind) === 2 && weapons[g.dataId]) add(WTYPE_HOUSE[Number(weapons[g.dataId].wtypeId)], 2);
      else if (Number(g.kind) === 3 && armors[g.dataId]) add(ATYPE_HOUSE[Number(armors[g.dataId].atypeId)], 1);
      else if (Number(g.kind) === 1) add('bonePin', 1);
    }
    var eq = rec.equips || [];
    for (i = 0; i < eq.length; i++) {
      var id = Number(eq[i]);
      if (!id) continue;
      if (i === 0 && weapons[id]) add(WTYPE_HOUSE[Number(weapons[id].wtypeId)], 2);
      else if (i > 0 && armors[id]) add(ATYPE_HOUSE[Number(armors[id].atypeId)], 1);
    }
    /* ⛔ A REMAINING TIE IS BROKEN BY THE RECORD'S OWN SEED, NEVER BY KEY ORDER.
     * `HOUSES` order is stable, the seed is stable, so the answer is stable —
     * and two tied records get DIFFERENT answers rather than the same one. */
    var best = null; var bestN = 0;
    for (var h = 0; h < HOUSES.length; h++) {
      var id2 = HOUSES[(h + (hash(rec.key) % HOUSES.length)) % HOUSES.length];
      var v = votes[id2] || 0;
      if (v > bestN) { bestN = v; best = id2; }
    }
    return best ? { id: best, name: '', why: 'what it carries' } : null;
  }

  /* ════════════════════════════════════════════════════════════════ 5. AGE ══ */

  /**
   * How hard the record is to hurt, as a fraction of the elements and states it
   * shrugs off. A thing that has survived a great deal looks like it.
   * @param {object} rec Normalised record.
   * @param {number} elementCount How many elements the project declares.
   * @returns {number} 0 … 1.
   */
  function hardiness(rec, elementCount) {
    var traits = rec.traits || [];
    var resisted = 0; var immune = 0; var states = 0;
    for (var i = 0; i < traits.length; i++) {
      var c = traits[i].code;
      if (c === 11) {
        var v = Number(traits[i].value);
        if (v <= 0) immune++; else if (v < 1) resisted++;
      } else if (c === 14) states++;
      else if (c === 13 && Number(traits[i].value) < 1) states++;
    }
    var elems = Math.max(1, (elementCount || 10) - 1);
    var elemShare = Math.min(1, (resisted + immune * 2) / elems);
    var stateShare = Math.min(1, states / 6);
    return Math.min(1, elemShare * 0.65 + stateShare * 0.35);
  }

  /**
   * @param {object} rec Normalised record.
   * @param {number} rankPct 0…1.
   * @param {number} elementCount Declared elements.
   * @returns {{id:string,index:number,why:string}} Age.
   */
  function ageOf(rec, rankPct, elementCount) {
    var t = tag(rec.note, 'age');
    if (t) {
      var want = String(t).toLowerCase();
      for (var i = 0; i < AGES.length; i++) {
        if (AGES[i] === want) return { id: AGES[i], index: i, why: 'notetag' };
      }
      var n = Number(t);
      if (n >= 0 && n < AGES.length) return { id: AGES[n], index: n, why: 'notetag' };
    }
    var score = rankPct * 0.55 + hardiness(rec, elementCount) * 0.45;
    var idx = Math.min(AGES.length - 1, Math.max(0, Math.floor(score * AGES.length)));
    return { id: AGES[idx], index: idx, why: 'rank and hardiness' };
  }

  /* ══════════════════════════════════════════════════════════ normalising ══ */

  /**
   * Bring an enemy or actor record into one shape, so every rule above reads
   * one kind of object. ⛔ Nothing downstream may touch `$data*` directly.
   * @param {object} raw The database record.
   * @param {string} kind `'enemy'` or `'actor'`.
   * @param {object} db Injected tables.
   * @returns {object} Normalised record.
   */
  function normalise(raw, kind, db) {
    var rec = {
      kind: kind,
      id: Number(raw.id),
      key: kind + ':' + Number(raw.id) + ':' + String(raw.name || ''),
      name: String(raw.name || ''),
      note: String(raw.note || ''),
      nickname: String(raw.nickname || ''),
      battlerName: String(raw.battlerName || ''),
      traits: raw.traits || [],
      actions: raw.actions || [],
      dropItems: raw.dropItems || [],
      equips: raw.equips || [],
      params: null,
      exp: Number(raw.exp) || 0,
      level: 0,
      className: ''
    };
    if (kind === 'enemy') {
      rec.params = raw.params || [];
    } else {
      var cls = (db && db.classes) ? db.classes[raw.classId] : null;
      rec.className = cls ? String(cls.name || '') : '';
      rec.level = Number(raw.initialLevel) || 1;
      rec.params = classParams(cls, rec.level);
      /* ⛔ An actor's own record is nearly empty — MEASURED on
       * `BlankProject/data/Actors.json`, all eight carry `nickname: ""`, no
       * note and two traits. Everything that makes a party member THAT party
       * member lives in its CLASS and its EQUIPMENT, so all three are read
       * (wing §25a: an axis whose source is never read is a declared axis
       * nothing draws). */
      rec.traits = (raw.traits || []).concat((cls && cls.traits) || []);
      var eq = raw.equips || [];
      var weapons = (db && db.weapons) || [];
      var armors = (db && db.armors) || [];
      for (var e = 0; e < eq.length; e++) {
        var gid = Number(eq[e]);
        if (!gid) continue;
        var gear = e === 0 ? weapons[gid] : armors[gid];
        if (gear && gear.traits) rec.traits = rec.traits.concat(gear.traits);
      }
      /* A class's LEARNINGS are the spells this person will actually cast, and
       * they are the strongest statement an actor record makes about its
       * element. MEASURED: Sorcerer learns six Fire skills, Priest four Light,
       * Magic Swordsman four Ice — a real reading, from the stock database. */
      var learn = (cls && cls.learnings) || [];
      var acts = [];
      for (var l = 0; l < learn.length; l++) acts.push({ skillId: learn[l].skillId, rating: 1 });
      rec.actions = acts;
    }
    return rec;
  }

  /**
   * The engine stores a class's parameter CURVE as `params[paramId][level]`.
   * ⛔ MEASURED against `BlankProject/data/Classes.json`: it is an 8×100 table
   * indexed by level, so reading `params[level]` instead would return an array
   * where a number belongs and quietly make every actor identical.
   * @param {object} cls A class record.
   * @param {number} level The actor's level.
   * @returns {number[]} Eight parameters at that level.
   */
  function classParams(cls, level) {
    if (!cls || !cls.params) return [];
    var out = [];
    for (var i = 0; i < 8; i++) {
      var row = cls.params[i] || [];
      var lv = Math.min(Math.max(1, Number(level) || 1), row.length - 1);
      out.push(Number(row[lv]) || 0);
    }
    return out;
  }

  /* ════════════════════════════════════════════════════════════ the tables ══ */

  var _db = null;

  /**
   * Point the reader at a database. With no argument it uses the engine's live
   * `$data*` globals; the headless suite and the store capture inject their own.
   * @param {object} [tables] `{enemies, actors, classes, skills, weapons, armors, elements}`
   * @returns {object} The tables in use.
   */
  function useDatabase(tables) {
    if (tables) { _db = tables; return _db; }
    if (_db) return _db;
    return {
      enemies: (typeof $dataEnemies !== 'undefined' && $dataEnemies) ? $dataEnemies : [],
      actors: (typeof $dataActors !== 'undefined' && $dataActors) ? $dataActors : [],
      classes: (typeof $dataClasses !== 'undefined' && $dataClasses) ? $dataClasses : [],
      skills: (typeof $dataSkills !== 'undefined' && $dataSkills) ? $dataSkills : [],
      weapons: (typeof $dataWeapons !== 'undefined' && $dataWeapons) ? $dataWeapons : [],
      armors: (typeof $dataArmors !== 'undefined' && $dataArmors) ? $dataArmors : [],
      elements: (typeof $dataSystem !== 'undefined' && $dataSystem) ? $dataSystem.elements : []
    };
  }

  /** Forget any injected database (the suite calls this between arms). */
  function resetDatabase() { _db = null; }

  var _factions = [];
  /** @param {object[]} list The parsed faction table from the plugin parameter. */
  function useFactions(list) { _factions = Array.isArray(list) ? list : []; }
  /** @returns {object[]} The faction table in use. */
  function factions() { return _factions; }

  /* ══════════════════════════════════════════════════════════════ the read ══ */

  /**
   * Every carveable record in one cohort, with its power, so percentiles are
   * computed ONCE per read rather than per record (wing §11: the two paths that
   * must agree agree by construction because there is only one).
   * @param {string} kind `'enemy'` or `'actor'`.
   * @param {object} db Tables.
   * @returns {{recs:object[],powers:number[]}} Cohort.
   */
  function cohort(kind, db) {
    var table = kind === 'enemy' ? (db.enemies || []) : (db.actors || []);
    var recs = []; var powers = [];
    for (var i = 0; i < table.length; i++) {
      var raw = table[i];
      if (!raw || !raw.id) continue;
      if (String(tag(raw.note) || '').toLowerCase() === 'skip') continue;
      var rec = normalise(raw, kind, db);
      recs.push(rec);
      powers.push(power(rec));
    }
    return { recs: recs, powers: powers };
  }

  /**
   * The profile for one normalised record.
   * @param {object} rec Normalised record.
   * @param {number[]} powers The cohort's powers.
   * @param {object} db Tables.
   * @returns {object} The mask profile.
   */
  function profileOf(rec, powers, db) {
    var words = structureFromWords(rec);
    var forced = tag(rec.note, 'type');
    var structure;
    var structureWhy;
    if (forced && STRUCTURES.indexOf(String(forced).toLowerCase()) >= 0) {
      structure = String(forced).toLowerCase();
      structureWhy = 'notetag';
    } else if (words.id) {
      structure = words.id;
      structureWhy = 'its name (' + words.hits.slice(0, 3).join(', ') + ')';
    } else if (rec.kind === 'actor') {
      /* ⛔ A PARTY MEMBER IS A PERSON. The parameter-shape grid below is a
       * MONSTER fallback and applying it to an actor is nonsense with a
       * straight face: MEASURED 2026-09-11 on the stock database, six of the
       * eight actors matched no word, fell into the grid, and came back as
       * `dragon` (Gale, Michelle) and `undead` (Albert, Kasey). Every gate was
       * green; only the contact sheet would ever have shown it. An actor whose
       * name and class say nothing is a humanoid. */
      structure = 'humanoid';
      structureWhy = 'a party member, unless its name says otherwise';
    } else {
      structure = structureFromShape(rec.params);
      structureWhy = 'the shape of its parameters';
    }

    var pct = percentile(power(rec), powers);
    var band = bandOf(pct);
    var rankWhy = 'percentile of your own database';
    var rankTag = tag(rec.note, 'rank');
    if (rankTag !== null && rankTag !== '' && !isNaN(Number(rankTag))) {
      band = Math.min(CROWNS.length - 1, Math.max(0, Math.floor(Number(rankTag))));
      pct = band / (CROWNS.length - 1);
      rankWhy = 'notetag';
    }

    var el = elementOf(rec, db);
    var pig = pigmentOf(el.index, db.elements);
    var house = houseOf(rec, db, _factions);
    var age = ageOf(rec, pct, (db.elements || []).length);
    var seed = hash(rec.key);
    var nameTag = tag(rec.note, 'name');

    return {
      kind: rec.kind,
      id: rec.id,
      key: rec.key,
      name: nameTag || rec.name,
      structure: structure,
      structureIndex: STRUCTURES.indexOf(structure),
      crown: CROWNS[band],
      crownIndex: band,
      rank: band,
      rankPct: pct,
      pigment: pig,
      house: house.id,
      houseIndex: HOUSES.indexOf(house.id),
      houseName: house.name,
      age: age.id,
      ageIndex: age.index,
      /* ⛔ A SHIFTED HASH MODULO SIX IS NOT A DRAW. The first version was
       * `BREAKS[(seed >>> 7) % 6]` and MEASURED over the 56-record demo it
       * returned chippedJaw 16, oneSidedInlay 16 and cordScar TWICE — an FNV
       * hash is not uniform in its low bits after a shift, and wing §21g is
       * this exact shape: the tail of a small vocabulary contains a degenerate
       * case that no mean will show. The generator is uniform; use it. */
      breakKind: BREAKS[Math.floor(rng(seed ^ 0x9E3779B9)() * BREAKS.length) % BREAKS.length],
      seed: seed,
      why: {
        structure: structureWhy,
        rank: rankWhy,
        pigment: el.why,
        house: house.why,
        age: age.why
      },
      /* The four readings engraved on the placard, in order. */
      readings: [
        structure.toUpperCase(),
        crownLabel(band),
        pig.hex ? pig.label : 'UNPAINTED',
        house.name ? house.name.toUpperCase() : houseLabel(house.id)
      ]
    };
  }

  /** @param {number} band 0…11 @returns {string} the standing, in words */
  function crownLabel(band) {
    var L = ['LEAST', 'LESSER', 'COMMON', 'MARKED', 'NOTED', 'RISEN',
      'HIGH', 'HALLOWED', 'TUSKED', 'CROWNED', 'MANED', 'ELDER'];
    return L[Math.min(L.length - 1, Math.max(0, band))];
  }

  /** @param {string} id House id @returns {string} the house, in words */
  function houseLabel(id) {
    var L = {
      goldWire: 'GOLD WIRE', verdigris: 'VERDIGRIS', ironRivet: 'IRON RIVET',
      shell: 'SHELL INLAY', bonePin: 'BONE PIN', lacquerThread: 'LACQUER THREAD'
    };
    return L[id] || 'UNAFFILIATED';
  }

  /**
   * @param {number} id Enemy id.
   * @param {object} [tables] Optional injected tables.
   * @returns {object|null} Profile, or null if there is no such record.
   */
  function readEnemy(id, tables) {
    var db = useDatabase(tables);
    var c = cohort('enemy', db);
    for (var i = 0; i < c.recs.length; i++) {
      if (c.recs[i].id === Number(id)) return profileOf(c.recs[i], c.powers, db);
    }
    return null;
  }

  /**
   * @param {number} id Actor id.
   * @param {object} [tables] Optional injected tables.
   * @returns {object|null} Profile, or null.
   */
  function readActor(id, tables) {
    var db = useDatabase(tables);
    var c = cohort('actor', db);
    for (var i = 0; i < c.recs.length; i++) {
      if (c.recs[i].id === Number(id)) return profileOf(c.recs[i], c.powers, db);
    }
    return null;
  }

  /**
   * Every carveable record in the project, enemies then actors.
   * @param {object} [tables] Optional injected tables.
   * @param {object} [opts] `{enemies:boolean, actors:boolean}`
   * @returns {object[]} Profiles.
   */
  function readAll(tables, opts) {
    var db = useDatabase(tables);
    var o = opts || {};
    var out = [];
    var i;
    if (o.enemies !== false) {
      var ce = cohort('enemy', db);
      for (i = 0; i < ce.recs.length; i++) out.push(profileOf(ce.recs[i], ce.powers, db));
    }
    if (o.actors !== false) {
      var ca = cohort('actor', db);
      for (i = 0; i < ca.recs.length; i++) out.push(profileOf(ca.recs[i], ca.powers, db));
    }
    return out;
  }

  /**
   * The five axis values as one string, for collision counting.
   * ⛔ wing §21i: the corpus size is what the product COULD make; this is what
   * a buyer's own database RESOLVES to, and it is the only number worth
   * printing. `_probe/spread_check.js` counts distinct values of this.
   * @param {object} prof A profile.
   * @returns {string} The profile signature.
   */
  function signature(prof) {
    return [prof.structure, prof.crown, prof.pigment.id, prof.house, prof.age].join('|');
  }

  return {
    STRUCTURES: STRUCTURES,
    CROWNS: CROWNS,
    PIGMENTS: PIGMENTS,
    HOUSES: HOUSES,
    AGES: AGES,
    BREAKS: BREAKS,
    TYPE_WORDS: TYPE_WORDS,
    NAME_GUARD: NAME_GUARD,
    namesWord: namesWord,
    deadWords: deadWords,
    hash: hash,
    rng: rng,
    tag: tag,
    hslHex: hslHex,
    structureFromShape: structureFromShape,
    structureFromWords: structureFromWords,
    power: power,
    percentile: percentile,
    bandOf: bandOf,
    elementOf: elementOf,
    pigmentOf: pigmentOf,
    houseOf: houseOf,
    goodsHouse: goodsHouse,
    hardiness: hardiness,
    ageOf: ageOf,
    normalise: normalise,
    classParams: classParams,
    cohort: cohort,
    profileOf: profileOf,
    crownLabel: crownLabel,
    houseLabel: houseLabel,
    useDatabase: useDatabase,
    resetDatabase: resetDatabase,
    useFactions: useFactions,
    factions: factions,
    readEnemy: readEnemy,
    readActor: readActor,
    readAll: readAll,
    signature: signature
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.VisageRead;
