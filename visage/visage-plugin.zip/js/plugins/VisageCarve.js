//=============================================================================
// VisageCarve.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Visage [3/4] — the carving. Strikes a mask from a profile: ten face structures, twelve superstructures, banded pigment, inlay, wear, one break. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Visage — the carving
 * ============================================================================
 * Load this THIRD, after VisageRead and VisageRender. It defines no scene, adds
 * no command and patches no core method.
 *
 * ONE DRAW PATH, SCALED. `carve()` is the only function that puts a mask on a
 * bitmap. The full-screen Unmasking calls it at 420 px; the Rack calls the SAME
 * function at 140 px; the picture command calls it at whatever the buyer asks
 * for. ⛔ There is deliberately no second, "simpler" renderer for small sizes —
 * wing §11: two code paths that must agree should agree by construction, and
 * the one that re-implements is the one that drifts.
 *
 * WHAT A MASK IS MADE OF
 *   the SILHOUETTE   a half-width curve sampled down the face, mirrored, with a
 *                    seeded asymmetry so no mask is perfectly symmetrical
 *   the RELIEF       masses — a forehead, a brow, two cheekbones, a nose ridge,
 *                    a jaw — summed into a height field and LIT, so the
 *                    highlight and the shadow are consequences of the form
 *   the VOIDS        eye-holes and a mouth, cut THROUGH, with a lit inner rim
 *                    on the upper-left edge only. A mask has holes; a portrait
 *                    has eyes. This product draws masks.
 *   the SUPERSTRUCTURE  grows out of the brow under the same light
 *   the PIGMENT      banded paint that follows the planes and wears thin on the
 *                    ridges, so the base material shows at every edge
 *   the INLAY        one side only — the second of the three asymmetries
 *   the WEAR         grain, chips on the lit edge, a crack that lengthens
 *   the BREAK        exactly one seeded structural break per mask
 * ============================================================================
 */

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};
var CSAF = globalThis.CSAF;

CSAF.VisageCarve = (function () {
  'use strict';

  /* ⛔ wing §8 trap 2: siblings are resolved at FIRST USE, never at load time —
   * the Plugin Manager order is the BUYER'S choice and the harness loads the
   * folder alphabetically, so `VisageCarve.js` may well be parsed first. */
  var _R = null; var _D = null;
  function deps() {
    if (!_R) { _R = CSAF.VisageRender; _D = CSAF.VisageRead; }
    if (!_R || !_D) throw new Error('Visage: enable VisageRender and VisageRead as well.');
    return _R;
  }

  /* ══════════════════════════════════════════════════════ the ten silhouettes ══
   * Sampled top (y = 0) to chin (y = 1) as HALF-widths in face units. The whole
   * argument of the structure axis is here: a construct is a slab, a spirit
   * tapers to nothing, an insect is narrow at the crown and wide at the
   * mandible. ⛔ wing §21a: a palette is not a composition — these differ in
   * SHAPE, and `_probe/axis_reads.js` asserts each one puts different pixels
   * down under one fixed palette. */
  var SILHOUETTE = {
    humanoid: [0.52, 0.72, 0.80, 0.78, 0.70, 0.56, 0.36, 0.12],
    beast: [0.46, 0.70, 0.86, 0.82, 0.66, 0.46, 0.34, 0.22],
    undead: [0.50, 0.70, 0.78, 0.70, 0.58, 0.50, 0.44, 0.20],
    spirit: [0.38, 0.58, 0.68, 0.64, 0.56, 0.42, 0.26, 0.08],
    construct: [0.66, 0.78, 0.82, 0.82, 0.80, 0.74, 0.62, 0.46],
    dragon: [0.44, 0.72, 0.88, 0.80, 0.66, 0.52, 0.40, 0.26],
    insect: [0.34, 0.56, 0.72, 0.80, 0.84, 0.70, 0.46, 0.24],
    aquatic: [0.54, 0.76, 0.88, 0.86, 0.78, 0.62, 0.42, 0.16],
    plant: [0.58, 0.74, 0.84, 0.82, 0.76, 0.66, 0.50, 0.28],
    fiend: [0.56, 0.80, 0.84, 0.76, 0.64, 0.48, 0.32, 0.10]
  };

  /* ═════════════════════════════════════════════════════════════ the relief ══
   * Each structure's masses, in face units. A negative amplitude is a hollow.
   * The nose ridge carries the one specular in every set — it is the highest
   * thing on the face and it is what tells a viewer this is an object rather
   * than a drawing of one. */
  function massesFor(structure) {
    var common = [
      { x: 0, y: 0.16, rx: 0.74, ry: 0.22, amp: 0.50 },                        // forehead
      { x: 0, y: 0.34, rx: 0.82, ry: 0.075, amp: 0.70, kind: 'ridge' },        // brow
      { x: -0.44, y: 0.56, rx: 0.32, ry: 0.21, amp: 0.58 },                    // left cheek
      { x: 0.44, y: 0.56, rx: 0.32, ry: 0.21, amp: 0.58 },                     // right cheek
      { x: 0, y: 0.50, rx: 0.105, ry: 0.25, amp: 0.98, kind: 'ridge' },        // nose ridge
      { x: 0, y: 0.86, rx: 0.38, ry: 0.15, amp: 0.44 },                        // chin
      { x: -0.40, y: 0.43, rx: 0.23, ry: 0.115, amp: -0.66, kind: 'hollow' },  // left socket
      { x: 0.40, y: 0.43, rx: 0.23, ry: 0.115, amp: -0.66, kind: 'hollow' },   // right socket
      { x: 0, y: 0.745, rx: 0.26, ry: 0.075, amp: -0.30, kind: 'hollow' }      // mouth hollow
    ];
    var extra = {
      /* a muzzle that comes forward, and a browline that slopes back */
      beast: [{ x: 0, y: 0.70, rx: 0.26, ry: 0.20, amp: 0.62 },
        { x: 0, y: 0.62, rx: 0.13, ry: 0.13, amp: 0.40 }],
      /* nothing added: the human face is the reference the other nine depart from */
      humanoid: [],
      /* the skull: temples hollowed, cheekbones sharpened, no soft tissue */
      undead: [{ x: -0.62, y: 0.30, rx: 0.16, ry: 0.14, amp: -0.34, kind: 'hollow' },
        { x: 0.62, y: 0.30, rx: 0.16, ry: 0.14, amp: -0.34, kind: 'hollow' },
        { x: -0.46, y: 0.54, rx: 0.20, ry: 0.09, amp: 0.40, kind: 'ridge' },
        { x: 0.46, y: 0.54, rx: 0.20, ry: 0.09, amp: 0.40, kind: 'ridge' }],
      /* barely there: a shallow relief, all of it in the brow */
      spirit: [{ x: 0, y: 0.28, rx: 0.50, ry: 0.16, amp: 0.22 }],
      /* plates and a seam, not bone */
      construct: [{ x: 0, y: 0.50, rx: 0.90, ry: 0.035, amp: 0.34, kind: 'ridge' },
        { x: -0.52, y: 0.70, rx: 0.24, ry: 0.16, amp: 0.30 },
        { x: 0.52, y: 0.70, rx: 0.24, ry: 0.16, amp: 0.30 }],
      /* a long snout and two brow horns' roots */
      dragon: [{ x: 0, y: 0.72, rx: 0.22, ry: 0.24, amp: 0.70, kind: 'ridge' },
        { x: -0.54, y: 0.30, rx: 0.14, ry: 0.10, amp: 0.46 },
        { x: 0.54, y: 0.30, rx: 0.14, ry: 0.10, amp: 0.46 }],
      /* mandibles, and a segmented crown */
      insect: [{ x: -0.52, y: 0.80, rx: 0.18, ry: 0.16, amp: 0.56 },
        { x: 0.52, y: 0.80, rx: 0.18, ry: 0.16, amp: 0.56 },
        { x: 0, y: 0.22, rx: 0.36, ry: 0.05, amp: 0.30, kind: 'ridge' }],
      /* a rounded skull and a gill ridge each side */
      aquatic: [{ x: -0.66, y: 0.62, rx: 0.12, ry: 0.18, amp: 0.34, kind: 'ridge' },
        { x: 0.66, y: 0.62, rx: 0.12, ry: 0.18, amp: 0.34, kind: 'ridge' },
        { x: 0, y: 0.30, rx: 0.60, ry: 0.26, amp: 0.26 }],
      /* knots and burls, placed off the centre line on purpose */
      plant: [{ x: -0.34, y: 0.24, rx: 0.16, ry: 0.13, amp: 0.44 },
        { x: 0.48, y: 0.36, rx: 0.13, ry: 0.11, amp: 0.38 },
        { x: -0.20, y: 0.80, rx: 0.15, ry: 0.12, amp: 0.34 }],
      /* a brow driven down to a point between the eyes */
      fiend: [{ x: -0.30, y: 0.38, rx: 0.30, ry: 0.06, amp: 0.54, rot: -0.42, kind: 'ridge' },
        { x: 0.30, y: 0.38, rx: 0.30, ry: 0.06, amp: 0.54, rot: 0.42, kind: 'ridge' },
        { x: 0, y: 0.92, rx: 0.16, ry: 0.12, amp: 0.40 }]
    };
    return common.concat(extra[structure] || []);
  }

  /** How deep the relief reads, by material. Lacquer is flatter and glossier. */
  var RELIEF = { oak: 0.44, bone: 0.38, lacquer: 0.30 };

  /**
   * ⛔ HOW LONG ONE FACE UNIT OF X IS, RELATIVE TO ONE OF Y. The silhouette
   * table holds HALF-widths around 0.8, so a face is 1.6 x-units across and
   * 1.0 y-units tall. Mapping both axes at the same pixel scale — which the
   * first draft did — produces a mask HALF AS TALL AS IT IS WIDE, and the
   * contact sheet showed ten letterboxes with eye-holes in them. No counter
   * could see it and the canvas reported a perfectly sensible size; it took
   * baking the sheet and looking at it (wing §9.5, and the brief's order of
   * work: bake the board and LOOK before tuning one parameter).
   *
   * At 0.46 a mask of half-width 0.80 comes out 0.74 as wide as it is tall,
   * which is a mask.
   *
   * ⛔⛔ AND INTRODUCING AN ANISOTROPIC SPACE SILENTLY DISTORTS EVERY OTHER
   * THING ALREADY AUTHORED IN IT. Fixing the silhouette fixed the silhouette
   * and left the crowns, the eye-holes and the mouths squeezed to 46% of their
   * intended width: a halo ring came out narrower than the head it was meant
   * to surround, sun rays floated detached, and every almond eye became a
   * round dot. The face-space numbers LOOKED untouched and every one of them
   * had changed meaning. So: anything shaped like a real object is authored in
   * REAL units and passed through `fx()` / `fpts()` below, exactly once, at the
   * boundary. Only the silhouette table itself is native face-x.
   */
  var FACE_ASPECT = 0.46;

  /** @param {number} realX A width in units of the mask's HEIGHT. @returns {number} face-x */
  function fx(realX) { return realX / FACE_ASPECT; }

  /** @param {number[][]} pts Real-space points. @returns {number[][]} face-space points. */
  function fpts(pts) {
    var out = [];
    for (var i = 0; i < pts.length; i++) out.push([fx(pts[i][0]), pts[i][1]]);
    return out;
  }

  /**
   * A void spec with its WIDTH converted from real units to face-x. Copied, not
   * mutated — the EYE and MOUTH tables are module-level constants and mutating
   * one would make every mask after the first read a doubly-converted width.
   * @param {object} spec An `EYE` or `MOUTH` row.
   * @returns {object} The same spec with `w` in face-x.
   */
  function aniso(spec) {
    var out = {};
    for (var k in spec) { if (Object.prototype.hasOwnProperty.call(spec, k)) out[k] = spec[k]; }
    out.w = fx(spec.w);
    return out;
  }

  /* ══════════════════════════════════════════════════════════════ the voids ══
   * ⛔ THE HOLES ARE HOLES. The brief's fourth "avoid" is a face portrait —
   * pupils, nostrils, lips — and the difference between a mask and a portrait
   * is exactly this: you can see the wall through it. */
  var EYE = {
    humanoid: { w: 0.20, h: 0.085, tilt: 0.06, form: 'almond' },
    beast: { w: 0.22, h: 0.070, tilt: 0.26, form: 'almond' },
    undead: { w: 0.19, h: 0.145, tilt: 0.00, form: 'round' },
    spirit: { w: 0.085, h: 0.170, tilt: 0.10, form: 'slit' },
    construct: { w: 0.24, h: 0.055, tilt: 0.00, form: 'slot' },
    dragon: { w: 0.24, h: 0.055, tilt: 0.30, form: 'slit' },
    insect: { w: 0.25, h: 0.165, tilt: 0.14, form: 'round' },
    aquatic: { w: 0.20, h: 0.150, tilt: 0.00, form: 'round' },
    plant: { w: 0.19, h: 0.105, tilt: 0.18, form: 'leaf' },
    fiend: { w: 0.23, h: 0.095, tilt: 0.34, form: 'wedge' }
  };
  var MOUTH = {
    humanoid: { w: 0.26, h: 0.055, form: 'slot', teeth: 0 },
    beast: { w: 0.24, h: 0.095, form: 'snarl', teeth: 5 },
    undead: { w: 0.34, h: 0.075, form: 'grin', teeth: 7 },
    spirit: { w: 0.12, h: 0.100, form: 'slot', teeth: 0 },
    construct: { w: 0.40, h: 0.045, form: 'grille', teeth: 6 },
    dragon: { w: 0.30, h: 0.090, form: 'snarl', teeth: 6 },
    insect: { w: 0.22, h: 0.110, form: 'grin', teeth: 4 },
    aquatic: { w: 0.30, h: 0.115, form: 'round', teeth: 0 },
    plant: { w: 0.22, h: 0.085, form: 'leaf', teeth: 0 },
    fiend: { w: 0.30, h: 0.080, form: 'grin', teeth: 8 }
  };

  /* ═══════════════════════════════════════════════ the twelve superstructures ══
   * Each returns a list of LIMBS — closed polygons in face units, which the one
   * per-pixel pass lights exactly like the face — plus the masses that give
   * them their own relief. ⛔ They are NOT drawn separately with their own
   * highlight: a horn lit by a different rule than the cheek it grows out of is
   * the thing that makes generated art look assembled. */

  /** @param {number} n @param {function(number): number[]} f @returns {number[][]} */
  function poly(n, f) {
    var pts = [];
    for (var i = 0; i < n; i++) pts.push(f(i / (n - 1)));
    return pts;
  }

  /**
   * A tapered horn as a closed polygon.
   * @param {number} bx Base x. @param {number} by Base y.
   * @param {number} len Length in face units. @param {number} thick Base half-width.
   * @param {number} sweep Curvature, radians of total bend.
   * @param {number} dir −1 left, +1 right.
   * @param {number} [ang0] Where it points at the root, in radians. ⛔ DEFAULTS
   *   to the original `-π/2 + dir · 0.42` so every call that predates this
   *   argument produces byte-identical geometry; it exists because a FAN has to
   *   point along its own arc and the old form could only ever point upward with
   *   a lean, which is why five of its seven blades used to converge into what
   *   the crowns sheet showed as a handful of sticks.
   * @returns {number[][]} The polygon.
   */
  function horn(bx, by, len, thick, sweep, dir, ang0) {
    var left = []; var right = [];
    var ang = (ang0 === undefined || ang0 === null) ? (-Math.PI / 2 + dir * 0.42) : ang0;
    var x = bx; var y = by;
    var steps = 14;
    for (var i = 0; i <= steps; i++) {
      var t = i / steps;
      var w = thick * (1 - t) * (1 - t * 0.35);
      var nx = Math.cos(ang + Math.PI / 2) * w;
      var ny = Math.sin(ang + Math.PI / 2) * w;
      left.push([x + nx, y + ny]);
      right.push([x - nx, y - ny]);
      ang += sweep / steps;
      x += Math.cos(ang) * (len / steps);
      y += Math.sin(ang) * (len / steps);
    }
    return left.concat(right.reverse());
  }

  /**
   * A RIDGE ALONG AN ARBITRARY AXIS, built out of circles.
   *
   * ⛔⛔ WHY CIRCLES. A mass is authored in REAL units and `crownOf` converts only
   * its `x` and `rx` at the boundary, so `rx === ry` is a true circle on the
   * finished bitmap — and a circle is the one shape that needs no rotation, which
   * is what `crownOf` throws on. A run of overlapping circles is a ridge at ANY
   * angle with no new maths, and it is what gives a crest, a fan blade, a feather
   * and a sun-disc plate a lit plane and a shadow plane under the one light. The
   * alternative — an ellipse elongated in face Y — is a ridge only for limbs that
   * happen to point straight up, and the sun-disc's old spine lay ACROSS the
   * plates nearest the ears for exactly that reason.
   *
   * ⛔ THE COUNT IS DERIVED FROM THE RUN, NOT TYPED (§24d, Icon_Doctrine
   * §22b-1a). Three masses over a blade leaves gaps between them, and a gap
   * between two round swells is not a ridge — it is a string of BEADS, which is
   * Icon_Doctrine §22a-2b: a mass round enough to take a specular of its own
   * stops being a swell in a surface and becomes an object on it. MEASURED by
   * looking at the crowns sheet at 3x with three per blade: pale beads on every
   * crest and fan blade. The pitch is a fraction of the radius, so the circles
   * always overlap and the count follows from how long the run actually is.
   *
   * ⛔ And the amplitude is PER CIRCLE while the height is their SUM, so it is
   * deliberately about half what a lone mass would carry: at a pitch of 0.85 r
   * each neighbour adds roughly 0.45 of itself, and a ridge that sums past the
   * brow's own 0.70 stops reading as a detail on a crown and starts reading as
   * the crown.
   *
   * @param {object[]} masses The crown's mass list, appended to.
   * @param {number} x0 @param {number} y0 Root of the run, real units.
   * @param {number} x1 @param {number} y1 Tip of the run, real units.
   * @param {number} rad Ridge radius in real units.
   * @param {number} amp Height per circle.
   */
  function spine(masses, x0, y0, x1, y1, rad, amp) {
    var run = Math.sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0));
    var pitch = Math.max(1e-4, rad * 0.85);
    var n = Math.max(2, Math.round(run / pitch));
    for (var i = 0; i <= n; i++) {
      var t = i / n;
      masses.push({
        x: x0 + (x1 - x0) * t,
        y: y0 + (y1 - y0) * t,
        rx: rad, ry: rad, amp: amp
      });
    }
  }

  /**
   * The superstructure for a crown id.
   *
   * ⛔ EVERY NUMBER BELOW IS IN REAL UNITS — fractions of the mask's HEIGHT —
   * and the whole set is converted to face-x exactly once, at the return. For
   * scale: the face is about 0.40 of its height in half-width, and its temples
   * sit near ±0.26. A horn based at 0.26 grows out of a temple; the same 0.26
   * written in face-x would grow out of the middle of the forehead.
   *
   * @param {string} crown A `VisageRead.CROWNS` id.
   * @param {function(): number} r The mask's own generator.
   * @returns {{limbs:number[][][], masses:object[]}} Geometry, in FACE space.
   */
  function crownOf(crown, r) {
    var jitter = function (a, b) { return a + (b - a) * r(); };
    var limbs = []; var masses = [];
    switch (crown) {
      case 'bare':
        break;
      case 'browRidge':
        /* ⛔ A SHELF THAT STANDS PROUD OF THE FACE, NOT AN ARC INSIDE IT. The
         * first version drew its arc at radius 0.38 while the face's own
         * half-width at brow height is 0.37 — so band 1 added FIVE sample
         * points of material over band 0 and, at the 140 px rack scale where a
         * relief difference is invisible, a `browRidge` creature and a `bare`
         * one were the same picture. wing §25g: the genuine defect is standing
         * being INVISIBLE. Silhouette is what reads small; the ridge now
         * overhangs the brow and clears the temples. */
        masses.push({ x: 0, y: 0.255, rx: 0.33, ry: 0.06, amp: 0.70, kind: 'ridge' });
        limbs.push(poly(28, function (t) {
          var a = Math.PI * (1 + t);
          return [Math.cos(a) * 0.47, 0.295 + Math.sin(a) * 0.225];
        }).concat([[0.40, 0.36], [-0.40, 0.36]]));
        break;
      case 'twinHorns':
        limbs.push(horn(-0.26, 0.17, 0.42, 0.055, jitter(0.30, 0.55), -1));
        limbs.push(horn(0.26, 0.17, 0.42, 0.055, -jitter(0.30, 0.55), 1));
        masses.push({ x: -0.26, y: 0.14, rx: 0.07, ry: 0.10, amp: 0.5 });
        masses.push({ x: 0.26, y: 0.14, rx: 0.07, ry: 0.10, amp: 0.5 });
        break;
      case 'crest': {
        /* ⛔⛔ A CREST AS WIDE AS THE HEAD IS NOT A CREST, IT IS A FLAT TOP.
         * The art-director review of 2026-09-13 grouped `crest`, `plume` and
         * `fan` as "under-drawn, collapsing toward bare at rack scale", which is
         * wing §25g on the middle of every buyer's database: standing is the axis
         * the brief promised would be VISIBLE, and COMMON/MARKED/NOTED are the
         * three bands most records land in. LOOKED AT on `_probe/out/crowns.png`
         * at 3x: the old crest was a half-ellipse of half-width 0.135 — over half
         * the face's own half-width at that height — and only 0.34-0.46 tall, so
         * it read as the skull having been sawn off square, not as a blade.
         *
         * A comb is TALL, NARROW and NOTCHED, and it has a spine. The width is
         * cut to 0.072 and the height raised to 0.42-0.54; the outline is
         * scalloped so it reads as something carved rather than a fin; and four
         * round masses run up the centre line so the blade has a lit side and a
         * shadow side under the one light, the way the mane's spikes already do.
         *
         * ⛔ ROUND masses, not an elongated one. A mass is authored in real units
         * and only its `x` and `rx` are converted at the boundary, so `rx == ry`
         * IS a circle on the finished bitmap — and a circle needs no rotation,
         * which is the trap `crownOf` throws on. A chain of circles along an axis
         * is a ridge along that axis, at any angle, with no new maths. */
        var h = jitter(0.42, 0.54);
        var cw = 0.072;
        limbs.push(poly(34, function (t) {
          var a = Math.PI * t;
          var notch = 1 - 0.17 * Math.abs(Math.sin(a * 4.5));
          return [Math.cos(a) * cw * (0.62 + 0.38 * Math.sin(a)),
            0.12 - Math.sin(a) * h * notch];
        }).concat([[-cw * 0.62, 0.26], [cw * 0.62, 0.26]]));
        spine(masses, 0, 0.10 - h * 0.10, 0, 0.10 - h * 0.86, cw * 0.60, 0.26);
        masses.push({ x: 0, y: 0.13, rx: 0.085, ry: 0.075, amp: 0.46 });
        break;
      }
      case 'fan': {
        /* ⛔ SEVEN BLADES 0.030 WIDE, ALL GROWN FROM ONE POINT, READ AS A
         * HANDFUL OF STICKS — measured by looking at the crowns sheet at 3x,
         * where the fan is a broken umbrella. Two things were wrong: the blades
         * were quadrilaterals with parallel sides (so nothing tapers and nothing
         * is lit as a form), and there were too many of them to separate at the
         * 153 px rack cell.
         *
         * Five tapered blades on the same arc, each a `horn` pointing along ITS
         * OWN radius — which is what the new `ang0` argument is for — and each
         * with a chain of round masses up it, so a fan reads as five carved
         * paddles rather than as splinters. */
        var blades = 5;
        for (var b = 0; b < blades; b++) {
          var u2 = b / (blades - 1);
          var a2 = -Math.PI * (0.16 + 0.68 * u2);
          var len = 0.30 + Math.sin(Math.PI * u2) * 0.24;
          var bx = Math.cos(a2) * 0.17;
          var by = 0.17 + Math.sin(a2) * 0.10;
          limbs.push(horn(bx, by, len, 0.052, jitter(-0.18, 0.18),
            a2 < -Math.PI / 2 ? -1 : 1, a2));
          spine(masses, bx + Math.cos(a2) * len * 0.16, by + Math.sin(a2) * len * 0.16,
            bx + Math.cos(a2) * len * 0.78, by + Math.sin(a2) * len * 0.78, 0.028, 0.24);
        }
        masses.push({ x: 0, y: 0.12, rx: 0.20, ry: 0.08, amp: 0.46, kind: 'ridge' });
        break;
      }
      case 'antlerFrame': {
        for (var s = -1; s <= 1; s += 2) {
          limbs.push(horn(s * 0.23, 0.15, 0.50, 0.034, -s * jitter(0.5, 0.8), s));
          limbs.push(horn(s * 0.30, -0.06, 0.26, 0.021, -s * 0.4, s));
          limbs.push(horn(s * 0.19, -0.16, 0.22, 0.019, -s * 0.9, s));
        }
        break;
      }
      case 'plume': {
        /* ⛔ FIVE SPROUTS OF HALF-WIDTH 0.034 ARE DEBRIS, NOT A PLUME. And the
         * old shape carried a real bug behind the look: the RIGHT edge of each
         * feather used `jitter(0.38, 0.50)` — a fresh random draw INSIDE the
         * per-point callback, so every one of the sixteen samples got a
         * different length — while the LEFT edge used a flat 0.44. The two sides
         * of one feather were not the same feather. Nothing threw, and at 0.034
         * wide nobody could see it.
         *
         * Three feathers, half again as wide, each with its length drawn ONCE and
         * both edges built from that one number, and a shaft of round masses up
         * the middle so a feather has a lit side and a shadow side. */
        var n = 3;
        for (var p = 0; p < n; p++) {
          var lean = (p - 1) * 0.155;
          var plen = (p === 1 ? 0.62 : 0.50) * jitter(0.92, 1.08);
          var pw = 0.052;
          limbs.push(poly(18, function (t) {
            var w = pw * Math.sin(Math.PI * t) * (1 - t * 0.22);
            return [lean * (0.3 + t) + w, 0.12 - t * plen];
          }).concat(poly(18, function (t) {
            var u = 1 - t;
            var w = pw * Math.sin(Math.PI * u) * (1 - u * 0.22);
            return [lean * (0.3 + u) - w, 0.12 - u * plen];
          })));
          spine(masses, lean * 0.48, 0.12 - 0.18 * plen,
            lean * 1.14, 0.12 - 0.84 * plen, pw * 0.50, 0.24);
        }
        masses.push({ x: 0, y: 0.10, rx: 0.12, ry: 0.09, amp: 0.42 });
        break;
      }
      case 'haloRing': {
        /* ⛔ A RING IS A STRIP OF QUADS, NOT AN OUTER LOOP WITH A REVERSED
         * INNER LOOP CONCATENATED ONTO IT. The concatenated form relies on the
         * winding rule of whatever tests it, and `inPoly` here is an even-odd
         * ray cast over a SINGLE point list — so the two seam edges joining the
         * loops changed the parity along part of the ring and most of it simply
         * did not exist. MEASURED: the halo rendered as two small stubs at the
         * temples and nothing else, and `sunDisc`, built the same way, lost its
         * whole disc while its rays (plain triangles) drew perfectly. A shape
         * that only works under a winding rule you did not choose is a shape
         * that will break again. */
        for (var i2 = 0; i2 < 44; i2++) {
          var a3 = Math.PI * 2 * (i2 / 44);
          var a3b = Math.PI * 2 * ((i2 + 1) / 44);
          limbs.push([
            [Math.cos(a3) * 0.47, 0.06 + Math.sin(a3) * 0.44],
            [Math.cos(a3b) * 0.47, 0.06 + Math.sin(a3b) * 0.44],
            [Math.cos(a3b) * 0.395, 0.06 + Math.sin(a3b) * 0.365],
            [Math.cos(a3) * 0.395, 0.06 + Math.sin(a3) * 0.365]
          ]);
        }
        break;
      }
      case 'tuskPair':
        limbs.push(horn(-0.30, 0.62, 0.38, 0.042, -0.75, -1));
        limbs.push(horn(0.30, 0.62, 0.38, 0.042, 0.75, 1));
        break;
      case 'crownOfThorns': {
        var count = 11;
        for (var c = 0; c < count; c++) {
          var a4 = Math.PI * (1.06 + 0.88 * (c / (count - 1)));
          var l2 = 0.16 + (c % 3) * 0.07;
          limbs.push(horn(Math.cos(a4) * 0.37, 0.26 + Math.sin(a4) * 0.32, l2, 0.018,
            (c % 2 ? 0.5 : -0.5), c < count / 2 ? -1 : 1));
        }
        break;
      }
      case 'mane': {
        var locks = 13;
        for (var m2 = 0; m2 < locks; m2++) {
          var a5 = Math.PI * (1.02 + 0.96 * (m2 / (locks - 1)));
          var l3 = 0.20 + Math.sin(Math.PI * (m2 / (locks - 1))) * 0.26 + (m2 % 2) * 0.05;
          limbs.push(horn(Math.cos(a5) * 0.39, 0.34 + Math.sin(a5) * 0.36, l3, 0.036,
            (m2 % 2 ? 0.35 : -0.30), Math.cos(a5) < 0 ? -1 : 1));
        }
        break;
      }
      case 'sunDisc': {
        /* ⛔⛔ THIS IS THE MASK THAT PROVED THE RECORD'S OWN GATE 1 WARNING RIGHT.
         * Baked into the Unmasking it read as a child's drawing of a SUN with a
         * face in it — §22a glyph-snap in its purest form, on the product's
         * single most important image. Three things were wrong and only the
         * third is obvious once seen:
         *
         * (1) ⛔ THE RAYS WERE BUILT APEX-INWARD. The triangle had one point at
         *     radius 0.58 and a BASE at 0.76, so every ray grew WIDER as it went
         *     out — the silhouette of a cogwheel or a virus, not of a ray. Real
         *     radiance tapers to nothing at the tip (Icon_Doctrine §22a-2:
         *     hatching that does not ramp to zero reads as a ribcage, or as
         *     teeth). They now taper outward to a point.
         * (2) ⛔ SIXTEEN RAYS AT ONE LENGTH, EVENLY SPACED, IS A CLIP-ART SUN.
         *     Icon_Doctrine §22b-1a: a repeated treatment declares a PITCH and
         *     derives its count; and §22a wants asymmetry, so the blades
         *     alternate long and short, the crown is WEIGHTED TO THE TOP (a
         *     nimbus is not a wheel), and two seeded blades are broken short.
         * (3) ⛔ THE DISC WAS CENTRED ON THE FACE AND WIDER THAN IT, so the face
         *     sat INSIDE the sun and the mask stopped being the subject. It now
         *     sits behind and ABOVE, as a backing plate the jaw hangs below.
         */
        /* ⛔ PASS 2, AND THE FIX IS THE SHAPE OF THE RAY, NOT ITS ARITHMETIC.
         * Tapering the blades outward and thinning the crown stopped it reading
         * as a clip-art sun and it immediately read as a SPIKED BALL instead —
         * a sea urchin, which is the same failure wearing different clothes.
         * Icon_Doctrine §22a-5b: when the failures are DIFFERENT each time the
         * subject is wrong, and a subject whose identity is a radial spike ring
         * cannot be rescued by spacing it better.
         *
         * ⛔ So the ray stops being a SPIKE and becomes a PLATE. Every carved
         * sun-disc that does not read as clip-art — Bronze-Age, Egyptian,
         * Mesoamerican — builds its radiance out of broad overlapping worked
         * plates with blunt ends, not needles: a wrought crown, which is what
         * the top rank is supposed to say. Two further rules keep it out of
         * glyph territory: the plates occupy only the UPPER ARC, because a
         * corona under a hanging mask's chin is exactly what turns a face into a
         * ball; and the disc is small enough that the jaw hangs clear below it,
         * so the face is the subject and the disc is its backing. */
        var cy = 0.21;
        var disc = [];
        for (var i3 = 0; i3 < 56; i3++) {
          var a6 = Math.PI * 2 * (i3 / 56);
          var wob = 1 + Math.sin(a6 * 3 + r() * 6.28) * 0.030;
          disc.push([Math.cos(a6) * 0.470 * wob, cy + Math.sin(a6) * 0.430 * wob]);
        }
        limbs.push(disc);
        var plates = 11;
        for (var q = 0; q < plates; q++) {
          /* the upper arc only: -172° … -8°, so nothing grows below the ears */
          var a7 = Math.PI * (1.045 + 0.91 * (q / (plates - 1)));
          var top = Math.sin(Math.PI * (q / (plates - 1)));        /* 0 at the ears, 1 at the crown */
          var len = 0.24 + 0.20 * top;
          if (q === 2 + Math.floor(r() * 3) || q === 7 + Math.floor(r() * 3)) len *= 0.62;
          /* ⛔⛔ PASS 3, AND THIS TIME IT IS THE ONE THING NEITHER EARLIER PASS
           * TOUCHED: WHETHER A PLATE IS A FORM OR A SHAPE. The art-director
           * review of 2026-09-13 opened the hero at 2x and wrote "flat
           * rectangular tabs with a faint gradient — cardboard cut-outs … no lit
           * plane, no shadow plane and no taper, while the mane's triangular
           * spikes read as carved", and graded it major because g1 is the first
           * in-game image a buyer sees.
           *
           * ⛔ The cause is in this file's own lighting model and is worth
           * stating plainly, because it will catch the next crown too: a limb
           * outside the silhouette is lit from its OWN EDGE (see the `inFace`
           * branch in `carve` — four `inside()` probes, which round a horn into
           * a tube). That works while the limb is thin. At half-width 0.085 on a
           * 0.430 radius the eleven plates were WIDER than the 0.112 spacing
           * between them, so they fused into one continuous collar: `inside()`
           * answered true at all four probes across every plate's interior, the
           * edge normal came out zero, and the only shading left was the
           * silhouette of the whole ring. A flat tab is what that renders as, and
           * no counter in this wing can see it — the shape, the spacing and the
           * palette were all exactly as designed.
           *
           * Two fixes, both needed. The plates are cut to less than half the
           * spacing so there is real wall between them and each is its own limb
           * again; and each gets a SPINE of three round masses up its axis, so it
           * has a lit plane and a shadow plane meeting on a ridge under the one
           * light — the same construction the crest, the fan and the plume now
           * use, and the reason the mane always read. */
          /* ⛔ AND THE TAPER IS WHAT TELLS A RAY FROM A PILL. At tip 0.50 of the
           * base the plate holds most of its width to the end, and with a ridge
           * running up the middle that silhouette is a CAPSULE — LOOKED AT on
           * the re-rendered hero, where the crown read as a ring of pale
           * lozenges laid round the disc. A ray is wide where it leaves the disc
           * and nearly gone at the tip; blunt means the tip has width, not that
           * the sides are parallel.
           *
           * ⛔⛔ AND THE ROOT GOES INSIDE THE DISC, NOT ONTO ITS RIM. With the
           * root at 0.430 against a disc of 0.470 the join was right at the
           * edge, where the disc's own silhouette shading and the ray's
           * edge-normal rounding both turn — so the eye read the junction, and
           * eleven short pale objects sitting on a dark painted rim are
           * BEADS ON A NECKLACE however well each one is carved. Rooted at 0.34
           * the base is buried inside the disc's interior, where `inside()` is
           * true on every probe and nothing shades, so the ray simply emerges:
           * there is no junction to see. Icon_Doctrine §22a-2b — ornament laid ON
           * a form detaches; this one is cut THROUGH it. */
          var half = 0.046 - 0.009 * top;
          var rIn = 0.340;
          var cA = Math.cos(a7); var sA = Math.sin(a7);
          /* ⛔⛔ THE RAY IS A `horn`, WHICH IS THE ONE RADIAL CONSTRUCTION IN THIS
           * FILE THAT IS MEASURED TO READ. Four passes have now been spent on
           * this crown and each produced a DIFFERENT wrong object — a cogwheel,
           * a sea urchin, fused cardboard tabs, then pale lozenges laid on a rim
           * and finally pins stuck into one. The comment two screens up already
           * names the rule that predicts this: when the failures are different
           * every time, the SUBJECT is wrong, and no amount of respacing rescues
           * it. So the subject stops being "a plate" and becomes the thing the
           * mane and the crown of thorns are made of — a tapered horn, rooted
           * INSIDE the disc so no junction shows, carrying its own sweep so no
           * two are parallel. `horn` tapers continuously and the limb's own edge
           * normal rounds it; that is why thirteen of them read as a mane while
           * eleven quadrilaterals read as cut paper. */
          limbs.push(horn(cA * rIn, cy + sA * rIn * 0.92, len + (rIn * 0.34), half * 1.35,
            (q % 2 ? 0.22 : -0.26), cA < 0 ? -1 : 1, a7));
          /* ⛔ ROUND, AND THERE ARE THREE OF THEM. The previous version pushed a
           * single mass of `rx: half * 0.42, ry: len * 0.80` — an ellipse
           * elongated in FACE Y — which is a ridge down the plate only for the
           * plates that happen to point straight up. For the plates near the ears
           * the plate runs sideways and that mass lay ACROSS it. Rotating a mass
           * is what `crownOf` throws on, so the spine is built the way every
           * other crown here now builds one: a chain of circles along the axis,
           * which is a ridge at any angle and needs no rotation at all.
           * ⛔ And they are small: a mass round enough and deep enough to take a
           * specular of its own stops being a swell in a surface and becomes an
           * object ON it — the pale-beans reading the previous pass recorded. */
          /* ⛔ NO SPINE ON A HORN. A `horn` is already a form: it tapers, and the
           * limb edge-normal in `carve` rounds it under the one light. Adding a
           * chain of circles down a shape that is already round is what turned
           * these into capsules — a ridge belongs on something FLAT (the crest's
           * blade, a fan's paddle, a feather), which is where `spine` is used. */
        }
        masses.push({ x: 0, y: cy, rx: 0.34, ry: 0.36, amp: 0.24 });
        break;
      }
      default:
        break;
    }
    /* ⛔ THE CONVERSION HAPPENS EXACTLY ONCE, HERE, AT THE BOUNDARY. Every
     * number above is real; everything downstream is face space. A crown mass
     * with a `rot` would need its angle converted too — none has one, and if
     * one is ever added this is where that has to be handled. */
    var outLimbs = [];
    for (var L = 0; L < limbs.length; L++) outLimbs.push(fpts(limbs[L]));
    for (var M = 0; M < masses.length; M++) {
      if (masses[M].rot) throw new Error('crownOf: a rotated crown mass needs an anisotropy conversion');
      masses[M].x = fx(masses[M].x);
      masses[M].rx = fx(masses[M].rx);
    }
    return { limbs: outLimbs, masses: masses };
  }

  /* ═══════════════════════════════════════════════════════════════ geometry ══ */

  /**
   * Half-width of the silhouette at a given height, interpolated smoothly
   * between the eight sampled control points.
   * @param {number[]} table The structure's silhouette samples.
   * @param {number} y 0 … 1 down the face.
   * @returns {number} Half-width in face units.
   */
  function halfWidth(table, y) {
    if (y < 0 || y > 1) return 0;
    var n = table.length - 1;
    var f = y * n;
    var i = Math.min(n - 1, Math.floor(f));
    var t = f - i;
    var s = t * t * (3 - 2 * t);
    return table[i] + (table[i + 1] - table[i]) * s;
  }

  /** @param {number[][]} pts @param {number} x @param {number} y @returns {boolean} */
  function inPoly(pts, x, y) {
    var inside = false;
    for (var i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      var xi = pts[i][0]; var yi = pts[i][1];
      var xj = pts[j][0]; var yj = pts[j][1];
      if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / ((yj - yi) || 1e-9) + xi)) inside = !inside;
    }
    return inside;
  }

  /**
   * The void test: is this point inside an eye-hole or the mouth?
   * @param {object} geo The geometry bundle.
   * @param {number} x @param {number} y
   * @returns {number} 0 outside, 1 inside, and a value between on the rim.
   */
  function inVoid(geo, x, y) {
    var e = geo.eye;
    var s;
    for (s = -1; s <= 1; s += 2) {
      var ex = s * geo.eyeX + (s > 0 ? geo.eyeSkew : 0);
      var dx = x - ex; var dy = y - geo.eyeY;
      var c = Math.cos(s * e.tilt); var sn = Math.sin(s * e.tilt);
      var u = (dx * c - dy * sn) / (e.w / 2);
      var v = (dx * sn + dy * c) / (e.h / 2);
      var d = e.form === 'wedge'
        ? Math.abs(u) + Math.abs(v) * 1.3
        : (e.form === 'leaf' ? Math.pow(Math.abs(u), 1.6) + Math.pow(Math.abs(v), 1.0) : Math.sqrt(u * u + v * v));
      if (e.form === 'slot') d = Math.max(Math.abs(u), Math.abs(v) * 1.1);
      if (d < 1) return 1;
      if (d < 1.10) return (1.10 - d) / 0.10;
    }
    var m = geo.mouth;
    var mx = (x - geo.mouthSkew) / (m.w / 2);
    var my = (y - geo.mouthY) / (m.h / 2);
    var md;
    if (m.form === 'grin' || m.form === 'grille') md = Math.max(Math.abs(mx), Math.abs(my));
    else if (m.form === 'snarl') md = Math.sqrt(mx * mx + Math.pow(Math.max(0, my) * 0.7 + Math.max(0, -my), 2));
    else if (m.form === 'leaf') md = Math.pow(Math.abs(mx), 1.7) + Math.abs(my);
    else md = Math.sqrt(mx * mx + my * my);
    if (md < 1) {
      /* ⛔ TEETH ARE INTERLOCKING TRIANGLES, NOT BARS. The first version left
       * solid vertical bars standing across the opening at an even duty cycle,
       * and every mouth on the contact sheet read as a BARCODE — the §22a
       * glyph-snap hazard arriving through the one part of the face most likely
       * to be read as a symbol. Alternating triangles from the upper and lower
       * edge read as a jaw. A `grille` keeps bars, because a machine's mouth is
       * a grille, but at a 30% duty so it reads as slats rather than stripes. */
      if (m.teeth > 0) {
        if (m.form === 'grille') {
          var band = (x - geo.mouthSkew + m.w / 2) / (m.w / (m.teeth * 2));
          if ((band - Math.floor(band)) < 0.34 && Math.abs(my) > 0.12) return 0;
        } else {
          /* ⛔⛔ PERFECTLY INTERLOCKING TRIANGLES ARE A ZIGZAG, AND A ZIGZAG IS A
           * CARTOON MONSTER MOUTH. Alternating a triangle from the top edge with
           * one from the bottom edge fixed the BARCODE it replaced and created a
           * new glyph in its place — the inherited art-defect list calls it "a
           * cartoon zigzag rather than a jaw". A zigzag is what you get whenever
           * two facing sawtooths are in perfect antiphase with equal amplitude,
           * and no amount of tuning the amplitude escapes it (Icon_Doctrine
           * §22d: when a number does not change the symptom, the SHAPE is wrong).
           *
           * ✅ A real jaw is told from a zigzag by three things, all of them
           * asymmetries, and the dentition table on `geo` carries all three:
           * the two rows are INDEPENDENT (an upper tooth does not imply a gap
           * below it), the teeth VARY in length within a row, and there are real
           * GAPS where a tooth is missing. Teeth are also blunt rather than
           * needle-pointed except where the structure wants fangs, which is what
           * `geo.teeth.point` carries. The table is built once per mask in
           * `geometry()` — this runs per pixel. */
          /* ⛔ A hand-built `geo` from a test that predates the dentition table
           * would read `undefined.n` here and throw inside the hot path, where a
           * throw is a black canvas rather than a failed assertion. Teeth are a
           * decoration: absent table, no teeth, and the mask is still a mask. */
          var T = geo.teeth;
          if (!T) return 1;
          var f = ((mx + 1) / 2) * T.n;
          var ci = Math.floor(f);
          if (ci < 0) ci = 0;
          if (ci >= T.n) ci = T.n - 1;
          var cell = f - ci;
          var tri = 1 - Math.abs(cell * 2 - 1);
          var prof = Math.min(1, tri * T.point);        /* blunt: flat-topped above 1/point */
          var up = T.top[ci] * prof;
          var dn = T.bot[ci] * prof;
          if (up > 0 && my < -1 + up * 2) return 0;
          if (dn > 0 && my > 1 - dn * 2) return 0;
        }
      }
      return 1;
    }
    return md < 1.10 ? (1.10 - md) / 0.10 : 0;
  }

  /**
   * The dentition for one mouth: two INDEPENDENT rows of tooth depths, built
   * once per mask so the per-pixel void test is a pair of array reads.
   *
   * ⛔ Each mouth form gets its own dentition, because "teeth" is not one thing:
   * a skull grins with an even row of blunt separated teeth, a predator snarls
   * with long canines at the corners, an insect has two mandibles and nothing
   * between them, and a fiend has irregular needles. Icon_Doctrine §22b-5: for
   * every noun a corpus note names, grep the renderer for something that draws
   * it — these are those draws.
   *
   * ⛔ Gaps are deliberate and are what stops a row reading as a strip: a tooth
   * of depth 0 is a MISSING tooth, and every form has some.
   *
   * @param {object} mouth The `MOUTH` row, already anisotropy-converted.
   * @param {function(): number} r The mask's own generator.
   * @returns {{n:number, point:number, top:number[], bot:number[]}}
   */
  function dentition(mouth, r) {
    var n = Math.max(2, mouth.teeth);
    var top = []; var bot = []; var i; var u;
    var point = 1.55;                 /* > 1 flattens the tip; higher is blunter */
    switch (mouth.form) {
      case 'snarl':
        /* canines at the corners, small teeth between, lower jaw sparse */
        point = 1.05;
        for (i = 0; i < n; i++) {
          u = Math.abs((i + 0.5) / n * 2 - 1);              /* 0 centre … 1 corner */
          top.push((0.30 + 0.52 * u * u) * (0.85 + r() * 0.30));
          bot.push(r() < 0.45 ? 0 : (0.14 + 0.34 * u) * (0.8 + r() * 0.4));
        }
        break;
      case 'grin':
        /* the skull: an even row, blunt, with real gaps where teeth are lost */
        point = 2.1;
        for (i = 0; i < n; i++) {
          top.push(r() < 0.18 ? 0 : 0.34 + r() * 0.22);
          bot.push(r() < 0.34 ? 0 : 0.26 + r() * 0.20);
        }
        break;
      case 'leaf':
      case 'round':
      case 'slot':
        point = 1.9;
        for (i = 0; i < n; i++) { top.push(r() < 0.5 ? 0.22 + r() * 0.16 : 0); bot.push(0); }
        break;
      default:
        /* needles, irregular, both rows, nothing lining up */
        point = 1.0;
        for (i = 0; i < n; i++) {
          top.push(r() < 0.22 ? 0 : 0.24 + r() * 0.44);
          bot.push(r() < 0.30 ? 0 : 0.20 + r() * 0.40);
        }
        break;
    }
    return { n: n, point: point, top: top, bot: bot };
  }

  /**
   * Build every piece of geometry a mask needs, in face units.
   * @param {object} profile A `VisageRead` profile.
   * @returns {object} The geometry bundle.
   */
  function geometry(profile) {
    var R = deps();
    var r = R.rng(profile.seed);
    var sil = SILHOUETTE[profile.structure] || SILHOUETTE.humanoid;
    var crown = crownOf(profile.crown, r);
    var masses = massesFor(profile.structure).concat(crown.masses);

    /* ⛔ THE FIRST OF THE THREE ASYMMETRIES, AND IT IS CONSTRUCTION, NOT
     * DECORATION (the brief's third "avoid"). A mask is vertically symmetric by
     * definition, and vertical symmetry is exactly what snaps the eye to a
     * known glyph — two holes and a slot is a SMILEY. Every mask is therefore
     * built slightly wider on one side, with its eyes at slightly different
     * heights, hashed from its own record. */
    var lean = fx((r() - 0.5) * 0.045);
    var eyeSkew = (r() - 0.5) * 0.05;

    var geo = {
      profile: profile,
      sil: sil,
      lean: lean,
      crownLimbs: crown.limbs,
      field: R.field(masses),
      relief: RELIEF[R.STRUCTURE_MATERIAL[profile.structure] || 'oak'],
      material: R.MATERIALS[R.STRUCTURE_MATERIAL[profile.structure] || 'oak'],
      /* ⛔ THE VOID WIDTHS ARE AUTHORED IN REAL UNITS TOO. `EYE.humanoid.w` of
       * 0.20 against `h` of 0.085 is an almond — but only if the 0.20 is a real
       * width. Read as face-x it is 0.092 real, which is very nearly a circle,
       * and the whole ten-structure sheet came back wearing identical round
       * dots (2026-09-11). Converted here, once, exactly like the crowns. */
      eye: aniso(EYE[profile.structure] || EYE.humanoid),
      mouth: aniso(MOUTH[profile.structure] || MOUTH.humanoid),
      eyeX: fx(0.185),
      eyeY: 0.44,
      eyeSkew: fx(eyeSkew),
      mouthY: 0.745,
      mouthSkew: fx((r() - 0.5) * 0.014),
      inlaySide: r() < 0.5 ? -1 : 1,
      crackX: (r() - 0.5) * 0.9,
      crackWobble: R.noise1(profile.seed ^ 0x2C41, 3),
      grain: R.noise1(profile.seed ^ 0x7A3B, 3),
      chip: R.noise2(profile.seed ^ 0x11D7),
      tilt: (r() < 0.5 ? -1 : 1) * (3 + r() * 4) * Math.PI / 180,
      rng: r
    };

    geo.teeth = dentition(geo.mouth, r);

    /* ⛔ A BOUNDING BOX PER LIMB, BECAUSE `inside()` RUNS FOUR TIMES PER PIXEL.
     * A sunDisc is seventeen polygons of up to a hundred points; without this
     * cull a 420 px bake is hundreds of millions of point-in-polygon steps and
     * the Rack would stutter for a second every time it opened. */
    var minX = -1.05; var maxX = 1.05; var minY = 0; var maxY = 1.02;
    geo.limbBox = [];
    for (var i = 0; i < crown.limbs.length; i++) {
      var lx0 = Infinity; var lx1 = -Infinity; var ly0 = Infinity; var ly1 = -Infinity;
      for (var k = 0; k < crown.limbs[i].length; k++) {
        var p = crown.limbs[i][k];
        if (p[0] < lx0) lx0 = p[0];
        if (p[0] > lx1) lx1 = p[0];
        if (p[1] < ly0) ly0 = p[1];
        if (p[1] > ly1) ly1 = p[1];
      }
      geo.limbBox.push([lx0, ly0, lx1, ly1]);
      if (lx0 < minX) minX = lx0;
      if (lx1 > maxX) maxX = lx1;
      if (ly0 < minY) minY = ly0;
      if (ly1 > maxY) maxY = ly1;
    }
    geo.bounds = { minX: minX - 0.04, maxX: maxX + 0.04, minY: minY - 0.04, maxY: maxY + 0.04 };

    /* ⛔ THE BREAK MUST BE ABLE TO HAPPEN, AND `brokenHorn` CANNOT HAPPEN TO A
     * BARE BROW. A break that silently does nothing on a whole rank band is
     * wing §17c-1 exactly: the call executes, the counter counts it and no
     * pixel changes. So the SUBSTITUTION IS EXPLICIT and it is RECORDED —
     * `breakDeclared` is what the profile says, `breakDrawn` is what the mask
     * actually carries, and `_probe/axis_reads.js` asserts they only differ
     * where a limb genuinely does not exist. */
    geo.breakDeclared = profile.breakKind;
    geo.breakDrawn = profile.breakKind;
    if (geo.breakDrawn === 'brokenHorn') {
      if (crown.limbs.length === 0) {
        geo.breakDrawn = 'chippedJaw';
      } else {
        geo.brokenLimb = Math.floor(r() * crown.limbs.length);
        var box = geo.limbBox[geo.brokenLimb];
        /* ⛔⛔ HOW DEEP THE SNAP CUTS DEPENDS ON HOW MANY LIMBS THERE ARE TO
         * LOSE, AND UNTIL 2026-09-13 IT DID NOT. Taking 34-60% off one of a
         * mane's thirteen locks reads as a snapped lock. Taking 34-60% off a
         * `crest` or a `browRidge` — the two crowns built from a SINGLE limb —
         * removes the standing axis itself: the mask comes out bare, and a bare
         * mask is what band 0 means. wing §25g names this exactly, "the genuine
         * defect is standing being INVISIBLE", and it was firing on 1 in 6 of
         * every MARKED record in a buyer's database, because `brokenHorn` is one
         * of six breaks drawn uniformly.
         *
         * ⛔ Found by LOOKING at `_probe/out/crowns.png`, where `crest` read as a
         * stub — and the sheet had been baking every one of the twelve crowns
         * with `breakKind: 'brokenHorn'`, so the contact sheet the art director
         * graded the crowns on was photographing the BREAK. wing §12 rule 3: a
         * test can be the bug, and here both the test and the product were.
         *
         * A snapped horn has to leave a horn. One limb: take the tip only. */
        var deep = crown.limbs.length > 1 ? (0.34 + r() * 0.26) : (0.13 + r() * 0.13);
        geo.brokenY = box[1] + (box[3] - box[1]) * deep;
      }
    }
    return geo;
  }

  /**
   * How much of this pixel is mask, 0 … 1 — the silhouette AND the voids,
   * sampled on a 2×2 grid.
   *
   * ⛔ A HARD INSIDE/OUTSIDE TEST PRODUCES A STAIRCASE, AND A STAIRCASE IS A
   * GATE 1 FAILURE. MEASURED by baking the contact sheet: every mask had a
   * visibly pixel-stepped edge against the wall, which is the single loudest
   * "drawn in code" signal a generated object can carry — and no instrument in
   * this wing can see it, because the shape, the shading and the palette are
   * all exactly right. Both boundaries are antialiased by the SAME sampler, so
   * an eye-hole cannot be sharp while a jaw is soft.
   *
   * @param {object} geo @param {number} x @param {number} y
   * @param {number} px @param {number} py Texel size in face units.
   * @returns {number} 0, 0.25, 0.5, 0.75 or 1.
   */
  function coverage(geo, x, y, px, py) {
    var n = 0;
    for (var j = 0; j < 2; j++) {
      for (var i = 0; i < 2; i++) {
        var sx = x + (i - 0.5) * px * 0.5;
        var sy = y + (j - 0.5) * py * 0.5;
        if (inside(geo, sx, sy) && inVoid(geo, sx, sy) < 1) n++;
      }
    }
    return n * 0.25;
  }

  /**
   * Is this point part of the object? The silhouette, or any crown limb — with
   * one limb truncated when the mask's break is a broken horn.
   * @param {object} geo @param {number} x @param {number} y @returns {boolean}
   */
  function inside(geo, x, y) {
    if (y >= 0 && y <= 1) {
      var hw = halfWidth(geo.sil, y);
      if (Math.abs(x - geo.lean * y) <= hw) return true;
    }
    var boxes = geo.limbBox;
    for (var i = 0; i < geo.crownLimbs.length; i++) {
      var b = boxes[i];
      if (x < b[0] || x > b[2] || y < b[1] || y > b[3]) continue;
      if (geo.brokenLimb === i && y < geo.brokenY) continue;   /* snapped off */
      if (inPoly(geo.crownLimbs[i], x, y)) return true;
    }
    return false;
  }

  /* ══════════════════════════════════════════════════════════════ the paint ══ */

  /**
   * How much pigment sits on this point.
   *
   * ⛔ NEVER A FLAT TINT. The brief is explicit: banded paint that FOLLOWS the
   * planes and WEARS THIN on the ridges, so the base material shows at every
   * edge. Coverage is therefore a function of the relief height (the bands),
   * the slope (the ridges rub through first) and the distance to an edge.
   *
   * @param {number} h Relief height at the point.
   * @param {number} slope Gradient magnitude there.
   * @param {number} edge Distance to the silhouette, in face units.
   * @param {number} ageIndex 0 … 4.
   * @param {number} grain Grain noise, −1 … 1.
   * @returns {number} Coverage, 0 … 1.
   */
  function paintAt(h, slope, edge, ageIndex, grain) {
    var wear = 0.10 + ageIndex * 0.175;
    /* ⛔ BROAD ZONES, NOT STRIPES. At 2.6 cycles across the relief range the
     * bands were narrower than the masses they were supposed to follow, so the
     * paint read as hatching rather than as a painted mask. The brief asks for
     * "banded paint that FOLLOWS THE PLANES": a plane is a zone, so the
     * frequency belongs near one cycle per major mass. */
    /* ⛔ AND THE BARE MATERIAL MUST SHOW BETWEEN THE BANDS. The brief is explicit
     * — "banded paint that follows the planes and wears thin on the ridges (base
     * material shows at every edge), NEVER a flat tint" — and at a duty of 0.78
     * the paint covered better than nine tenths of the face: the oak stopped
     * being visible at all and every mask on the crowns sheet read as painted
     * plaster rather than as painted wood. The material is one of the six axes;
     * burying it to rescue another one is not a fix, it is a trade. */
    var band = (h * 1.45 + 0.25) % 1;
    var duty = 0.56 - wear * 0.14;
    var cover = band < duty ? 1 : Math.max(0, 1 - (band - duty) * 4.2);
    /* ⛔⛔ `slope` IS A GRADIENT MAGNITUDE OF THE RELIEF FIELD, NOT A 0…1
     * FRACTION — MEASURED p50 2.22, p90 8.82 (`_probe/paint_terms.js`, 2026-09-12,
     * humanoid at 420 px). The first version multiplied it by 0.34 and capped at
     * 0.78 as though it ran 0…1, so `min()` SATURATED over almost the whole face
     * and the term was a flat x0.22 everywhere instead of the "ridges rub
     * through first" it is named for: the mean multiplier measured 29.9% at age
     * 0 and 22.3% at `relic` while every other term sat above 56%. That single
     * unit error is what put 44 of 48 element readings under the bar in
     * `_probe/pigment_read.js` — the element is one of the four things the
     * placard NAMES (wing §17c), and it was not on the mask.
     *
     * ⛔ wing §1c: a guessed constant inside a guard is a guard that does not
     * guard. So the slope is normalised into 0…1 FIRST, by a soft saturation
     * whose constant is set from the measured distribution (K = 5 puts the
     * median at 0.31 and the p90 at 0.64, which is the ordering the effect
     * wants), and only then scaled by wear. */
    var rub = slope / (slope + 5.0);
    cover *= 1 - rub * (0.30 + wear * 0.58);                    /* ridges rub through */
    cover *= Math.min(1, edge / (0.030 + wear * 0.048));        /* edges never hold paint */
    cover *= 1 - Math.max(0, grain) * wear * 0.45;

    /* ⛔ OLD PAINT FLAKES OFF; IT DOES NOT FADE. Thinning the coverage evenly
     * with age is what made a `relic` read as a mask with no element on it: the
     * inherited art defect list says "a DARKNESS pigment on a bone mask is still
     * barely readable at high age", and measured it was — mean 9.8 with the
     * placard naming DARKNESS. Fading multiplies every pixel toward the base
     * material, which is exactly the wash that averages to nothing.
     *
     * A worn painted object loses paint in PATCHES and the paint that is left is
     * as strong as the day it was put on. So the coverage is re-shaped rather
     * than scaled: the window narrows with age, values above it go fully opaque
     * and values below it go to bare material. Area falls, opacity does not, and
     * the element stays nameable at every age — which is the whole point, since
     * the placard names it on all five (wing §17c). */
    /* ⛔⛔ AND THE WINDOW WAS STILL TOO NARROW AT THE OLD END — MEASURED 2026-09-13, POLISH.
     * The art session's own record says `pigment_read` cleared 48 of 48. On the bytes that
     * reached polish it read 20 of 48 BELOW the bar, and every one of the twenty was age 4:
     * `lo` climbed 0.085 per band, so a relic's surviving paint fell under the 25%-of-face
     * legibility floor that same probe derived. The claim in the devlog was true when it was
     * written and false about what shipped, which is why a polish stage re-runs every
     * instrument instead of quoting one (master §2b: a stale measurement is a green lie with
     * a date on it).
     *
     * MEASURED, every step, with the probe's own bar UNTOUCHED (wing §18: never raise a
     * threshold to pass): slope 0.085 -> 20 of 48 below · 0.058 -> 9 · 0.038 -> 5 · 0.028 -> 4
     * but `_probe/age_delta.js` goes RED there (19% new-to-relic move, floor 20). Two
     * instruments that genuinely oppose: wearing a relic less makes its element legible and
     * its AGE invisible. 0.038 is the last value where both hold, and the last five were
     * cleared on the axis neither probe owns — per-pixel separation that rises with age
     * (see the `separate` call in `carve`). Final: pigment 48/48, age 46%. */
    var lo = -0.05 + ageIndex * 0.038;
    var hi = 0.78 - ageIndex * 0.040;
    cover = (cover - lo) / (hi - lo);
    return Math.max(0, Math.min(1, cover));
  }

  /* ⛔⛔ WHERE THE PAINT STOPS, AND HOW FAST.
   *
   * `paintAt` is a smooth field and a smooth field mixed straight onto a surface
   * is an AIRBRUSH — the art-director review of 2026-09-13 graded exactly that a
   * major defect on three of the seven store plates, on bytes where
   * `_probe/pigment_read.js` was scoring 48 of 48. A share-of-pixels-moved bar
   * cannot tell paint from spray, because spray moves pixels too.
   *
   * `PAINT_T` is where the layer's edge falls in the field, and `PAINT_EDGE` is
   * how wide the transition is IN FIELD UNITS. It is not a pixel count: how many
   * pixels that width occupies depends on how fast the band is moving there, so
   * the edge is tight where the relief turns (a brow, the nose) and can be soft
   * across a flat plane — which is what a brushed edge on a carving does.
   *
   * ⛔ `PAINT_T` IS DERIVED, NOT CHOSEN, AND THE FIRST VALUE WAS A GUESS THAT
   * WENT RED. Thresholding throws away every pixel the smooth version painted at
   * partial strength, which is most of a band's area — the fix for a beauty
   * defect must not be paid for by deleting the axis the placard names.
   * MEASURED: at 0.34, `_probe/pigment_read.js` put EIGHT of 48 readings under
   * its bar, every one of them oak at age 4, at 22-23% against a 25% floor, and
   * uniform across all eight elements — so it was area, not colour (the run is in
   * the devlog).
   *
   * The value that belongs here is the coverage at which the OLD smooth paint
   * was already moving a pixel past that probe's own 12-level detection
   * threshold, because at or below that, hardening changes nothing the probe can
   * see, and above it the paint is opaque instead of a wash. A pigment sits
   * 45-55 levels from its material after `separate()`, so 12/50 ≈ 0.24 is where
   * the two regimes meet. Set there, and then MEASURED at that value rather than
   * believed. ⛔ The bar it is measured against is untouched (wing §18: never
   * raise a threshold to pass — and never lower one either; move the thing being
   * measured). */
  var PAINT_T = 0.24;
  var PAINT_EDGE = 0.155;

  /** How many texels along the light the lip is looked for. */
  var LIP_TEXELS = 1.25;

  /**
   * The hard edge of the paint layer.
   * @param {number} cover `paintAt`'s smooth coverage, 0 … 1.
   * @returns {number} 0 bare, 1 painted, a short ramp between.
   */
  function paintInk(cover) {
    var v = (cover - PAINT_T) / PAINT_EDGE + 0.5;
    return v <= 0 ? 0 : (v >= 1 ? 1 : v);
  }

  var _light2 = null;
  /**
   * The one light's direction projected into the picture plane and renormalised,
   * so a step of N texels "toward the light" is a step of N texels.
   * ⛔ DERIVED from `VisageRender.LIGHT`, never typed: wing-wide there is one
   * light, and a second copy of a constant does not drift, it WINS (§11a).
   * @returns {number[]} `[x, y]`, unit length.
   */
  function light2() {
    if (!_light2) {
      var L = deps().LIGHT;
      var m = Math.sqrt(L[0] * L[0] + L[1] * L[1]) || 1;
      _light2 = [L[0] / m, L[1] / m];
    }
    return _light2;
  }

  /**
   * The colour a mask's paint is actually laid in, separated from its own ground.
   *
   * ⛔⛔ THIS IS A FUNCTION SO A TEST CAN REACH IT, AND IT EXISTS BECAUSE 279 GREEN
   * ASSERTIONS COULD NOT SEE ALL NINE ELEMENTS RENDER THE SAME NEAR-WHITE. Inline in
   * `carve`, the want was written `46 + ageIndex * 8` against the LOCAL `ageIndex`, which
   * `var` hoists and which is assigned three lines further down — so the want was NaN,
   * every `got >= want` test in `separate()` was false, and it returned its most extreme
   * candidate for every pigment. White is maximally distant from oak, so
   * `_probe/pigment_read.js` scored it 48 of 48. A perfect score over a mask with no
   * element on it. Caught by opening `_probe/out/elements.png` and LOOKING, which is
   * exactly what that probe's passing message tells the reader to do (wing §9.5).
   *
   * ⛔ The want RISES WITH AGE on purpose: a relic's paint is sparse by design, so the
   * legibility failure there is AREA, and the honest answer is to make what survives more
   * distinct rather than to wear the mask less — wearing it less costs the age axis
   * (`_probe/age_delta.js`). MEASURED both ways; see `paintAt`'s window comment.
   *
   * @param {object} profile A VisageRead profile.
   * @param {number[]} cMid The mask's own mid material colour, `[r,g,b]`.
   * @returns {{colour:number[], got:number, moved:number, cleared:boolean}|null} null when
   *   the record carries no pigment at all (Physical is left unpainted, by design).
   */
  function paintColour(profile, cMid) {
    var R = deps();
    if (!profile || !profile.pigment || !profile.pigment.hex) return null;
    /* ⛔ `rgb()` returns null for anything that is not a readable colour (wing §21c). An
     * unreadable pigment means UNPAINTED, which is a state the product already draws well,
     * rather than a NaN travelling into `separate()` and out onto the bitmap. */
    var base = R.rgb(profile.pigment.hex);
    if (!base) return null;
    var age = Number(profile.ageIndex);
    if (!isFinite(age)) age = 0;              /* ⛔ never let a NaN reach `separate`'s want */
    return R.separate(base, cMid, PAINT_WANT + age * PAINT_WANT_AGE);
  }

  /* ⛔⛔ THE WANT IS A PROPERTY OF HOW THE PAINT IS LAID DOWN, SO IT HAD TO MOVE
   * WHEN THAT CHANGED — AND THE CAUSE RECORDED AGAINST IT WAS WRONG.
   *
   * The 2026-09-13 art-director review recorded, as a minor defect, that FIRE
   * reads salmon on every beast- and dragon-structure mask while the brief's hex
   * is #C8452A, and inferred — labelling it INFERRED, and asking the polish stage
   * to measure it — that "the same hex lands lighter on the higher-relief
   * structures through separate()'s lift". MEASURED with
   * `_probe/pigment_hue.js`, which reports the mean of the pixels the pigment
   * actually moved:
   *
   *     humanoid/oak   fire   brief #C8452A   after separate() #fb5735
   *     beast/oak      fire   brief #C8452A   after separate() #fb5735
   *     dragon/oak     fire   brief #C8452A   after separate() #fb5735
   *     undead/bone    fire   brief #C8452A   after separate() #C8452A
   *     construct/lac  fire   brief #C8452A   after separate() #C8452A
   *
   * ⛔ The lift is not structure-dependent at all — all three oak structures get
   * the identical #fb5735 and the two non-oak ones are untouched. It is MATERIAL
   * dependent: fire's raw distance from oak is 32.3, the want was 46, so every
   * oak mask in the product wore a coral instead of the cover's oxblood, and the
   * three plates the review named (g4 dragon, g5 beast, the GIF's beast) are
   * simply the three oak specimens in the gallery. The elements probe sheet the
   * review compared them against is humanoid/OAK, so it carried the same coral;
   * what differed there was the white lift at high relief, fixed separately in
   * `carve`. Symptom real, cause falsified — wing §21g-1, the obvious diagnosis
   * was innocent.
   *
   * A want of 46 was measured when paint was a smooth field mixed on at partial
   * strength: a band covering 40% needed a very loud colour to survive the
   * multiply. `paintInk` now lays the layer opaque with a hard edge, so the same
   * legibility arrives from AREA rather than from shouting, and the pigment can
   * be the colour the brief names. MEASURED against `_probe/pigment_read.js`
   * with its own bar UNTOUCHED (wing §18) — the run is in the devlog.
   *
   * ⛔⛔ AND THE AGE SLOPE HAD TO ABSORB THE WHOLE OF THAT CUT, BECAUSE THE
   * DEFECT WAS AT THE YOUNG END AND THE LEGIBILITY FLOOR IS AT THE OLD ONE.
   * Dropping the base 46 → 30 at the old slope of 8 took a relic's want from 78
   * to 62, and `pigment_read` answered immediately: with the area recovered, the
   * weakest reading — oak at age 4, uniformly across all eight elements — sat at
   * exactly 25% against a 25% bar. A number sitting ON its bar is a pass with no
   * headroom, and the honest reading of that is not "it passes", it is "the
   * change was paid for at the far end from where it was needed".
   *
   * The age term always encoded one idea: a relic's paint survives in patches, so
   * what survives has to be more distinct than a new mask's does. Steepening the
   * slope to 12 restores a relic's want to exactly the 78 it was measured at,
   * while a NEW mask — which is what g4, g5 and the GIF photograph, and what the
   * review graded salmon — gets 30 and therefore keeps the brief's own #C8452A
   * on oak. Both ends measured, neither bar moved. */
  var PAINT_WANT = 30;
  var PAINT_WANT_AGE = 12;

  /* ═══════════════════════════════════════════════════════════════ the bake ══ */

  /**
   * Strike the mask. ⛔ THE ONE DRAW PATH — the Unmasking, the Rack and the
   * picture command all arrive here, and the only thing that differs is `size`.
   *
   * @param {object} profile A `VisageRead` profile.
   * @param {number} size The object's height in pixels, crown included.
   * @param {object} [opts] `{tilt:boolean}` — false pins the tilt to zero, which
   *   is what the contact sheet wants and what nothing a player sees wants.
   * @returns {HTMLCanvasElement} A canvas holding the mask, transparent around it.
   */
  function carve(profile, size, opts) {
    var R = deps();
    var o = opts || {};
    /* ⛔ A SIZE THAT IS NOT A NUMBER MUST NOT REACH THE CANVAS. `Math.max(8, Math.ceil(NaN))`
     * is NaN, and `createImageData(NaN, NaN)` THROWS — inside a scene's `create()`, which in
     * MZ means a dead game on a black screen, from a plugin the buyer will blame. Every
     * shipped call site guards its own argument, so this is the belt to those braces:
     * MEASURED by `_probe/break_it.js`, which called `carve(p, Number('not a number'))` and
     * got "Failed to execute 'createImageData'... Value is not of type 'long'". The reveal
     * height's own default is what an unreadable size falls back to. */
    var px = Number(size);
    if (!isFinite(px) || px <= 0) px = 420;
    size = Math.min(4096, Math.max(8, px));
    var geo = geometry(profile);
    var b = geo.bounds;
    var unitsTall = b.maxY - b.minY;
    var unitsWide = b.maxX - b.minX;
    var scale = size / unitsTall;              /* px per Y face unit */
    var scaleX = scale * FACE_ASPECT;          /* px per X face unit */
    var W = Math.max(8, Math.ceil(unitsWide * scaleX));
    var H = Math.max(8, Math.ceil(size));
    var cv = R.canvas(W, H);
    var ctx = cv.getContext('2d');
    var img = ctx.createImageData(W, H);
    var data = img.data;

    var mat = geo.material;
    var cMid = R.rgb(mat.mid);
    var cLit = R.rgb(mat.lit);
    var cSha = R.rgb(mat.shadow);
    /* ⛔ THE PIGMENT IS SEPARATED FROM ITS MATERIAL ONCE PER MASK, HERE — not
     * per pixel (this runs 75,000 times on a 420 px reveal) and not at the
     * palette, because the SAME element lands on three different materials and
     * `light` on bone is invisible while `light` on lacquer is not. The want of
     * 46 is the measured gap: readings a human eye called "no element on it at
     * all" sat under 18, the two anyone could name by eye sat at 24 and 31, and
     * 46 of raw pigment-to-material distance is what carries a band of paint
     * through the coverage terms to land above that (`_probe/pigment_read.js`). */
    /* ⛔ ONE DECISION, ONE FUNCTION, so the suite can reach it — see `paintColour` above
     * for the NaN that made all nine elements render the same white under 279 green
     * assertions and a 48-of-48 probe score. */
    var sep = paintColour(profile, cMid);
    var pig = sep ? sep.colour : null;
    var ageIndex = profile.ageIndex;
    var fld = geo.field;
    var relief = geo.relief;
    var LIGHT2 = light2();

    /* one texel of face space, for the rim test and the edge distance */
    var px = unitsWide / W;
    var py = unitsTall / H;

    for (var y = 0; y < H; y++) {
      var fy = b.minY + (y + 0.5) * py;
      for (var x = 0; x < W; x++) {
        var fx = b.minX + (x + 0.5) * px;
        var idx = (y * W + x) * 4;
        var cov = coverage(geo, fx, fy, px, py);
        if (cov <= 0) continue;                     /* the hole: the wall shows through */
        var v = inVoid(geo, fx, fy);

        /* ⛔ THE GRADIENT MUST BE TAKEN IN REAL SPACE, NOT FACE SPACE. The face
         * is squeezed horizontally by FACE_ASPECT, so the same height change
         * happens over a SHORTER real distance across than down — the x slope
         * is steeper by exactly 1/FACE_ASPECT. Light the face-space gradient
         * directly and every mask is lit as though it were the wide shape the
         * silhouette table describes rather than the one on screen. */
        var g0 = fld.grad(fx, fy);
        var gX = g0[0] / FACE_ASPECT;
        var gY = g0[1];
        /* ⛔ THE PAINT'S EDGE IS FOUND FROM THE RELIEF'S OWN GRADIENT, TAKEN
         * BEFORE THE LIMB FIX-UP BELOW REPLACES IT. That fix-up substitutes a
         * synthetic normal built from four `inside()` probes so a horn rounds
         * into a tube; it is a LIGHTING normal, not a height derivative, and
         * stepping the band coordinate along it would be a made-up distance.
         * A limb sits on flat field, so its band is constant and it has no
         * paint edge to find — which is the honest answer there. */
        var rgX = gX; var rgY = gY;

        /* ⛔ A SUPERSTRUCTURE MUST BE LIT LIKE THE FACE IT GROWS OUT OF. The
         * relief masses live on the FACE, so a horn, a ray or a halo segment
         * sits on flat field and came out of the engine looking like cut paper
         * stuck to a carved object — the exact "assembled" reading the brief
         * forbids, and one no counter can see. Outside the silhouette the
         * normal is taken from the LIMB'S OWN EDGE instead, which rounds every
         * limb into a tube under the same light. Four extra `inside()` calls,
         * and only for limb pixels, which are a small minority. */
        var inFace = (fy >= 0 && fy <= 1
          && Math.abs(fx - geo.lean * fy) <= halfWidth(geo.sil, fy));
        if (!inFace) {
          var e1 = px * 2.5; var e2 = py * 2.5;
          var ex = (inside(geo, fx + e1, fy) ? 1 : 0) - (inside(geo, fx - e1, fy) ? 1 : 0);
          var ey = (inside(geo, fx, fy + e2) ? 1 : 0) - (inside(geo, fx, fy - e2) ? 1 : 0);
          gX -= ex * 1.9;
          gY -= ey * 1.9;
        }
        var g = [gX, gY];
        var sh = R.shade(g, relief);
        var h = fld.at(fx, fy);

        /* base material, lit */
        var t = sh.diffuse;
        var col = t > 0.62
          ? R.mix(cMid, cLit, Math.min(1, (t - 0.62) / 0.38))
          : R.mix(cSha, cMid, Math.min(1, t / 0.62));

        /* ⛔ THE GRAIN RUNS WITH THE LOG, WHICH IS DOWN THE FACE, NOT ACROSS IT.
         * Until 2026-09-13 the noise was sampled at `fy * 26 + fx * 3.5` — an
         * argument dominated by the Y term, so the bands ran HORIZONTALLY, which
         * is the one direction no carver ever cuts a mask from. At 420 px the
         * result read as a smooth plastic dome with faint corduroy: the store
         * cover promises a carved wooden object and the engine delivered moulded
         * toffee (LOOKED AT, `_probe/fresh_install.js`, the stock Goblin).
         *
         * Two octaves, X-dominant, plus a sparse HARD LINE — real grain is mostly
         * even tone with occasional dark figure, and it is the dark figure that
         * says "wood". `gr` keeps its −1…1 range because `paintAt` reads it.
         *
         * ⛔ SAMPLED HERE, LAID DOWN AFTER THE PAINT. See the grain block below
         * the pigment: until the polish pass the figure was drawn first and the
         * pigment mixed over it at 95%, so the wood vanished under every painted
         * band and the mask read as coloured plaster. */
        var grC = geo.grain(fx * 23 + fy * 2.4);
        var gr = grC * 0.72 + geo.grain(fx * 57 + fy * 5.5) * 0.28;

        /* ⛔ CAVITY, WRITTEN AGAINST A MEASURED DISTRIBUTION (wing §26a). The
         * relief height `h` does NOT run 0…1: over all 56 demo masks it is
         * p10 0.131, p25 0.226, p50 0.337, p90 0.672 (`_probe/relief_terms.js`).
         * A term keyed on "below half" would have been a flat multiply over the
         * whole face — the exact shape of the paintAt defect. Full strength at or
         * below p10, gone by p50: the deep ground beside the brow, beside the nose
         * and around the sockets holds shadow, which is what separates a carved
         * form from an inflated one. */
        var cav = (0.34 - h) / 0.21;
        if (cav > 0) col = R.mix(col, cSha, Math.min(1, cav) * CAVITY);

        /* ══════════════════════════════════════════════════════ banded pigment ══
         * ⛔ `paintCover`, NOT `cov`. `var` IS FUNCTION-SCOPED, so a second
         * `var cov` inside this block is the SAME VARIABLE as the pixel's alpha
         * coverage above — the paint coverage was being written out as the
         * ALPHA, and every mask carrying a pigment came out 97% transparent.
         * MEASURED by bisection (`_probe/_diag_alpha.js`): 15,806 opaque pixels
         * unpainted, 280 painted. Nothing threw, no gate could see it, and the
         * unpainted contact sheet rendered perfectly — the earlier sheet simply
         * never entered this branch because its pigment was `none`.
         *
         * ⛔⛔ AND PAINT IS A LAYER WITH AN EDGE, NOT A TINT WITH A FALLOFF.
         * `paintAt` returns a smooth 0…1 field and this block used to mix it
         * straight in, so every band faded out over a third of a cheek and the
         * store plates came back reading as AIRBRUSH: darkness in soft purple
         * puddles on Vetch, ice as a blue wash on the culture crops, fire as a
         * salmon haze on Cinder Drake (art-director review 2026-09-13, graded
         * major — the cover promises a carved object and the product did not
         * keep the promise). No instrument in this wing could see it:
         * `pigment_read` scored 48 of 48 on those exact bytes, because a wash
         * moves pixels just as well as paint does.
         *
         * Three things separate paint on wood from colour sprayed onto it, and
         * all three are here: the coverage is THRESHOLDED so the edge lands in
         * a texel or two instead of a centimetre; the edge is given a LIT LIP on
         * the light's side and a dark one away from it, so the layer has
         * thickness; and the grain is laid down AFTER, so the figure of the wood
         * runs through the paint exactly as it does on the cover. */
        var ink = 0;
        if (pig) {
          var edge = edgeDistance(geo, fx, fy) * FACE_ASPECT;
          var paintCover = paintAt(h, sh.slope, edge, ageIndex, gr);
          ink = paintInk(paintCover);
          /* ⛔ THE STEP IS TAKEN ALONG THE LIGHT, IN REAL UNITS, AND THE HEIGHT
           * AT THE NEIGHBOUR IS THE GRADIENT TIMES THAT STEP — never a second
           * `field.grad`, which would triple the cost of the one hot loop in the
           * product for a one-pixel mark. `px` is a face-x texel, so its real
           * width is `px * FACE_ASPECT`; `py` is already real. */
          var dh = rgX * (LIGHT2[0] * LIP_TEXELS * px * FACE_ASPECT)
            + rgY * (LIGHT2[1] * LIP_TEXELS * py);
          var inkL = paintInk(paintAt(h + dh, sh.slope, edge, ageIndex, gr));
          var inkD = paintInk(paintAt(h - dh, sh.slope, edge, ageIndex, gr));
          if (ink > 0) {
            /* ⛔ AND THE PAINT KEEPS ITS HUE IN THE LIGHT. The lift toward white
             * was 0.30, which on a pigment `separate()` had already scaled up
             * turned the cover's oxblood FIRE into salmon wherever the relief
             * stood proud — measured on g4, g5 and the GIF, all three of them
             * beast- and dragon-structure masks, which carry the deepest relief
             * in the set. A painted highlight is the paint, lit; it is not the
             * paint mixed with the lamp. */
            var pl = R.mix(R.mix(pig, [0, 0, 0], 0.38), R.mix(pig, [255, 252, 244], 0.16),
              Math.min(1, t));
            col = R.mix(col, pl, ink * 0.97);
            var lip = ink * (1 - inkL);          /* paint meeting bare on the light's side */
            if (lip > 0.02) col = R.mix(col, [255, 247, 228], lip * 0.40);
            var back = ink * (1 - inkD);         /* the layer's own far edge, turned away */
            if (back > 0.02) col = R.mix(col, [24, 13, 7], back * 0.32);
          }
          var cast = (1 - ink) * inkL;           /* bare wood lying in the paint's shadow */
          if (cast > 0.02) col = R.mix(col, [20, 11, 6], cast * 0.26);
        }

        /* ⛔ THE FIGURE RUNS THROUGH THE PAINT. On bare material the grain mixes
         * toward that material's own lit and shadow tones, which is measured-good
         * and unchanged; on a painted band it lightens and darkens WHAT IS THERE
         * instead, because mixing a red band toward oak-lit is not wood showing
         * through paint, it is the paint being rubbed off. */
        var gAmt = Math.abs(gr) * mat.grain * 0.17;
        if (ink < 1) col = R.mix(col, gr > 0 ? cLit : cSha, gAmt * (1 - ink));
        if (ink > 0) col = R.mix(col, gr > 0 ? [255, 248, 232] : [14, 9, 6], gAmt * ink * 0.66);
        var line = (Math.abs(grC) - 0.62) / 0.38;
        if (line > 0) {
          var lineAmt = Math.min(1, line) * mat.grain * 0.26;
          col = R.mix(col, ink > 0.5 ? [14, 9, 6] : cSha, lineAmt * (ink > 0.5 ? 0.74 : 1));
        }

        /* ⛔ ONE SPECULAR, ON WHATEVER STANDS HIGHEST — AND IT IS A GLINT, NOT
         * A SWEEP. At the first draft's strength the three lacquer structures
         * came out of the contact sheet looking like CHROME: a broad white
         * sweep down the whole cheek, which is the one reading that turns a
         * carved object back into a rendered blob. Capped, and tightened by
         * squaring the term so the falloff is sharp. */
        if (sh.spec > 0.02) {
          col = R.mix(col, [255, 246, 226], Math.min(0.52, sh.spec * sh.spec * (0.45 + mat.gloss)));
        }

        /* the lit rim: two pixels of bright edge where the form turns away, on
         * the light's side only — this is what separates the mask from the wall */
        var rim = rimAt(geo, fx, fy, px, py);
        if (rim > 0) col = R.mix(col, [255, 240, 214], rim * 0.55);

        /* the inner rim of a void, upper-left only (the brief: one pixel, lit) */
        if (v > 0) col = R.mix(col, [255, 236, 206], v * 0.5);

        /* wear: chips out of the lit edge, and the crack */
        var wear = wearAt(geo, fx, fy, ageIndex, px);
        if (wear === 2) continue;                   /* chipped away entirely */
        if (wear === 1) col = R.mix(col, cSha, 0.72);

        data[idx] = col[0];
        data[idx + 1] = col[1];
        data[idx + 2] = col[2];
        data[idx + 3] = Math.round(cov * 255);
      }
    }
    ctx.putImageData(img, 0, 0);

    /* the inlay and the binding run down ONE side — the second asymmetry */
    inlay(ctx, geo, W, H, b, scale, scaleX);

    /* ⛔ WHERE THE CORD TIES, IN PIXELS, REPORTED BY THE THING THAT KNOWS.
     * The scenes were computing the knot from the canvas BOUNDING BOX — a
     * fraction of `m.width` in from the centre — and for any mask with a wide
     * superstructure the bounding box is much wider than the face, so the cord
     * ended in mid-air beside the mask. MEASURED in the engine: on a sun-disc
     * mask the knot floated a clear 90 px off the object. A caller cannot know
     * where a mask's upper corner is; only the geometry can. */
    var knotY = 0.055;
    var knotX = geo.lean * knotY - halfWidth(geo.sil, knotY) * 0.70;
    var kx = Math.round((knotX - b.minX) * scaleX);
    var ky = (knotY - b.minY) * scale;

    /* ⛔⛔ AND THE KNOT IS TIED OVER THE TOP EDGE OF WHATEVER IS ACTUALLY THERE,
     * WHICH IS FOUND BY READING THE PIXELS. Taking the knot at the FACE's upper
     * corner is right for a bare mask and wrong for every crowned one: a
     * `sunDisc` or an `antlerFrame` rises far above the face, so the face's
     * corner is deep inside the object and the peg — placed a cord's length
     * above the knot — came out BURIED IN THE CROWN (measured: peg y 174 on a
     * mask whose top edge was y 75). The previous version of this code fixed the
     * opposite error, a knot floating 90 px clear of the object because it came
     * from the BOUNDING BOX, and its comment is right that a caller cannot know
     * where a mask's upper corner is.
     *
     * ⛔ Both errors are the same mistake: asking a MODEL of the shape where its
     * edge is. wing §15c-1 — "measure" means the pixels, not the rect you meant.
     * The column is already rendered, so walk it and take the first opaque row.
     * That is where a person tying this object to a peg would put the cord, for
     * every crown, with no special case per crown. */
    /* ⛔⛔ AND IT IS THE HIGHEST POINT OF THE UPPER-LEFT SHOULDER, NOT THE TOP OF
     * ONE CHOSEN COLUMN. Reading the first opaque pixel straight down the face's
     * own corner column assumes that column meets the object near its top, and
     * for any mask whose crown is narrow — a crest, a plume, an insect's
     * silhouette that pinches at the crown — that column misses the crown
     * entirely and first meets the object HALFWAY DOWN THE CHEEK. Measured on
     * the derivation plate, 2026-09-12: the knot rendered as a red blob tied to
     * the middle of a Gilt Beetle's face.
     *
     * A cord is tied over the highest thing on the side it hangs from, so the
     * band is scanned and the column with the topmost edge wins. Same instrument
     * as before — the rendered pixels, never a model of them (wing §15c-1) — but
     * asking the question the object can actually answer. */
    var bandLo = Math.max(0, Math.round(W * 0.12));
    var bandHi = Math.min(W - 1, Math.round(W * 0.48));
    var bestY = H; var bestX = kx;
    for (var cxs = bandLo; cxs <= bandHi; cxs++) {
      for (var cys = 0; cys < bestY; cys++) {
        if (data[(cys * W + cxs) * 4 + 3] > 8) {
          if (cys < bestY) { bestY = cys; bestX = cxs; }
          break;
        }
      }
    }
    if (bestY < H) {
      kx = bestX;
      /* seated ON the object, not balanced on its outline: a knot tangent to the
       * top edge reads as a bead resting there rather than as a binding */
      ky = bestY + Math.max(2, scale * 0.030);
    }

    if (o.tilt !== false) {
      /* ⛔ THE ROTATED BOUNDING BOX IS `W|cos| + H|sin|` BY `H|cos| + W|sin|`,
       * AND BOTH TERMS MATTER. A first draft used `H + 8` for the height, which
       * on a 420 px mask at 7° silently sliced ~50 px — a horn tip and a chin —
       * off every tilted mask, with the canvas reporting a perfectly good size
       * (wing §15c-1: "measure" means the pixels, not the rect you meant). */
      var ca = Math.abs(Math.cos(geo.tilt));
      var sa = Math.abs(Math.sin(geo.tilt));
      var out = R.canvas(Math.ceil(W * ca + H * sa) + 4, Math.ceil(H * ca + W * sa) + 4);
      var octx = out.getContext('2d');
      octx.translate(out.width / 2, out.height / 2);
      octx.rotate(geo.tilt);
      octx.drawImage(cv, -W / 2, -H / 2);
      out.visageTilt = geo.tilt;
      out.visageGeo = geo;
      /* the knot travels with the mask: rotate it about the same centre */
      var rx = kx - W / 2; var ry = ky - H / 2;
      var cs = Math.cos(geo.tilt); var sn = Math.sin(geo.tilt);
      out.visageKnot = [out.width / 2 + rx * cs - ry * sn, out.height / 2 + rx * sn + ry * cs];
      return out;
    }
    cv.visageTilt = 0;
    cv.visageGeo = geo;
    cv.visageKnot = [kx, ky];
    return cv;
  }

  /**
   * Distance from a point to the silhouette edge, in face units. Crown limbs
   * count as edge-free so a horn does not lose its paint along its whole length.
   * @param {object} geo @param {number} x @param {number} y
   * @returns {number} Distance, clamped at 0.3.
   */
  function edgeDistance(geo, x, y) {
    if (y < 0 || y > 1) return 0.3;
    var hw = halfWidth(geo.sil, y);
    var d = hw - Math.abs(x - geo.lean * y);
    if (d < 0) return 0.3;
    return Math.min(0.3, Math.min(d, Math.min(y, 1 - y) * 1.4));
  }

  /**
   * The lit rim. ⛔ It is computed from the SILHOUETTE, not painted along a
   * path: a stroke on top of a shaded form is the thing that reads as a sticker.
   * @param {object} geo @param {number} x @param {number} y
   * @param {number} px @param {number} py Texel size in face units.
   * @returns {number} 0 … 1.
   */
  function rimAt(geo, x, y, px, py) {
    var out = 0;
    if (!inside(geo, x - px * 2, y)) out += 0.5;
    if (!inside(geo, x, y - py * 2)) out += 0.5;
    if (!inside(geo, x - px * 1.2, y - py * 1.2)) out += 0.4;
    return Math.min(1, out);
  }

  /* The run a BOUND crack takes, in face units: where it starts, where it ends. */
  var BOUND_TOP = 0.16, BOUND_BOTTOM = 0.68;

  /* ⛔ HOW DEEP THE CAVITY SHADOW GOES, AND WHY IT IS NOT DEEPER.
   * A cavity term is what stops a shaded form reading as an inflated balloon, and at 0.30 it
   * did that well — and COST the product something measurable somewhere else: a relic mask's
   * paint is worn back to 13% coverage by design, and darkening the ground under it dropped
   * 20 of 48 element readings under `_probe/pigment_read.js`'s bar (share >= 25% of the face
   * moved). Every one of the 20 was age 4. The placard NAMES the element on every mask, so an
   * element a buyer cannot see is wing §17c on the most visible surface the product has.
   * MEASURED, not chosen: 0.30 -> 20 failures, 0.18 -> see the run recorded in the devlog.
   * The trade is real and it is declared here rather than hidden in a magic number. */
  var CAVITY = 0.18;

  /**
   * Where a bound crack sits at a given height.
   *
   * ⛔ ONE FUNCTION, TWO CONSUMERS, BY CONSTRUCTION (wing §11). The pixel pass cuts
   * the crack and `breakMark` staples it shut, and until 2026-09-13 they were two
   * different formulas — in fact the pixel pass had NO formula at all for this break,
   * so the staples were three grey sticks lying on an unbroken cheek. That is wing
   * §17c-1 in its purest form: the draw call ran, the mark landed, and it referred to
   * something the object did not contain. Found on the very first mask a buyer sees
   * (the stock Goblin, `_probe/fresh_install.js`).
   *
   * @param {object} geo @param {number} y Height in face units.
   * @returns {number} x in face units.
   */
  function boundCrackX(geo, y) {
    var sign = geo.crackX < 0 ? -1 : 1;
    return geo.crackX * 0.92 + (y - BOUND_TOP) * 0.30 * sign
      + geo.crackWobble(y * 5.5 + 2) * 0.040;
  }

  /**
   * Wear at a point: 0 sound, 1 bruised, 2 gone.
   * ⛔ wing §14a: the temptation with wear is to make it more violent until an
   * instrument can see it. The instrument here is `_probe/wear_delta.js`, which
   * measures the mask's OWN change between ages rather than a perceptual hash
   * of the whole plate.
   * @param {object} geo @param {number} x @param {number} y
   * @param {number} ageIndex 0 … 4. @param {number} px Texel width.
   * @returns {number} 0, 1 or 2.
   */
  function wearAt(geo, x, y, ageIndex, px) {
    var brk = geo.breakDrawn;
    var hw; var d;
    /* ⛔ THE THREE BREAKS THAT ARE CUT RATHER THAN PAINTED ARE CUT HERE. An
     * earlier draft of this file carried a comment saying exactly that while
     * the code did nothing of the kind — which is wing §17c-1 in one file: the
     * caption names a property, the draw call is absent, and every counter
     * stays green because a counter cannot read a comment. */
    if (brk === 'chippedJaw' && y > 0.70) {
      hw = halfWidth(geo.sil, y);
      d = hw - Math.abs(x - geo.lean * y);
      var bite = 0.16 * (1 - Math.abs(y - 0.86) / 0.18);
      if (x > 0 && d < bite) return 2;
      if (x > 0 && d < bite + 0.02) return 1;
    }
    if (brk === 'faceCrack') {
      /* ⛔ A CRACK IS A HAIRLINE THAT WANDERS A LITTLE. At a 0.075 wobble on a
       * face 1.6 units wide it wandered a tenth of the face and read as a
       * BRANCH growing down every mask (contact sheet, 2026-09-11). The wobble
       * is now a twentieth of that, and the width is pinned in pixels so a 140
       * px rack mask and a 420 px reveal get the same hairline. */
      /* ⛔ AND IT MUST NOT BE VERTICAL, CENTRED, OR FULL-HEIGHT. Tightened to a
       * hairline, the crack came back as a dead-straight SEAM splitting each
       * mask into two halves — symmetric, which is the §22a glyph-snap hazard
       * arriving through the one mark that was supposed to defeat it. A crack
       * runs from ONE edge, at an angle, and stops. */
      var run = 0.14 + 0.62 * Math.min(1, Math.max(0, (y - 0.06) / 0.80));
      var fcx = geo.crackX * 0.9 + (y - 0.06) * 0.42 * (geo.crackX < 0 ? -1 : 1)
        + geo.crackWobble(y * 5 + 3) * 0.045;
      if (y > 0.06 && y < 0.06 + run * 1.02) {
        if (Math.abs(x - fcx) < px * 0.9) return 2;        /* a crack you can see through */
        if (Math.abs(x - fcx) < px * 2.1) return 1;
      }
    }

    /* ⛔ A BOUND CRACK IS A CRACK FIRST. Cut here, in the pixel pass, exactly where
     * `breakMark` will lay its staples across it — and cut REGARDLESS of age, because
     * the break is the record's own, not a consequence of wear. A hairline that goes
     * right through (2) with a bruised shoulder (1), the same treatment `faceCrack`
     * gets, so the two breaks are the same kind of mark and only the binding differs. */
    if (brk === 'boundCrack' && y > BOUND_TOP && y < BOUND_BOTTOM) {
      var bcx = boundCrackX(geo, y);
      if (Math.abs(x - bcx) < px * 0.9) return 2;
      if (Math.abs(x - bcx) < px * 2.0) return 1;
    }

    if (ageIndex <= 0) return 0;
    /* chips, on the upper-left edge where a mask gets knocked */
    if (y >= 0 && y <= 1) {
      hw = halfWidth(geo.sil, y);
      d = hw - Math.abs(x - geo.lean * y);
      var lit = x < 0 || y < 0.35;
      /* ⛔ FEWER, LARGER CHIPS. The first thresholds put a chip anywhere the
       * noise cleared 0.54 at `relic`, and the in-engine reveal came back
       * covered in black speckles that read as MOULD rather than as a knocked
       * edge — the wall showing through a hundred tiny holes. The noise is
       * sampled coarser (larger chips) and the bar is much higher. */
      if (d < 0.032 * ageIndex && lit) {
        var n = geo.chip(x * 11, y * 11);
        if (n > 0.95 - ageIndex * 0.055) return 2;
        if (n > 0.88 - ageIndex * 0.050) return 1;
      }
    }
    /* the crack of AGE: off-centre, and it lengthens with every age band */
    var reach = 0.18 + ageIndex * 0.19;
    if (y < reach) {
      var cx = geo.crackX + (y * 0.30) * (geo.crackX < 0 ? -1 : 1) + geo.crackWobble(y * 6) * 0.030;
      var w = px * (0.7 + ageIndex * 0.22);
      if (Math.abs(x - cx) < w) return 1;
    }
    return 0;
  }

  /**
   * The inlay and the binding, down ONE side.
   * @param {CanvasRenderingContext2D} ctx Target.
   * @param {object} geo @param {number} W @param {number} H
   * @param {object} b The face-space bounds. @param {number} scale px per face unit.
   */
  function inlay(ctx, geo, W, H, b, scale, scaleX) {
    var R = deps();
    var house = geo.profile.house;
    var side = geo.inlaySide;
    var toPx = function (fx, fy) {
      return [(fx - b.minX) * scaleX, (fy - b.minY) * scale];
    };
    var studs = [];
    for (var i = 0; i <= 16; i++) {
      var fy = 0.10 + (i / 16) * 0.80;
      /* ⛔ INSET, NOT ON THE EDGE. At 0.055 the studs sat half off the
       * silhouette and read as loose rivets floating beside the mask rather
       * than inlay set INTO it (contact sheet, 2026-09-11). */
      var hw = halfWidth(geo.sil, fy);
      var fx = geo.lean * fy + side * (hw - 0.135);
      studs.push(toPx(fx, fy));
    }
    ctx.save();
    var lw = Math.max(1, scale * 0.016);
    if (house === 'goldWire' || house === 'lacquerThread') {
      var wire = house === 'goldWire' ? R.PALETTE.goldWire : '#2A1A14';
      ctx.strokeStyle = 'rgba(0,0,0,0.45)';
      ctx.lineWidth = lw * 1.9;
      ctx.beginPath();
      for (var k = 0; k < studs.length; k++) {
        if (k === 0) ctx.moveTo(studs[k][0] + 1.5, studs[k][1] + 1.5);
        else ctx.lineTo(studs[k][0] + 1.5, studs[k][1] + 1.5);
      }
      ctx.stroke();
      ctx.strokeStyle = wire;
      ctx.lineWidth = lw * 1.3;
      ctx.beginPath();
      for (var k2 = 0; k2 < studs.length; k2++) {
        var wob = Math.sin(k2 * 0.8) * lw * 0.55;
        if (k2 === 0) ctx.moveTo(studs[k2][0] + wob, studs[k2][1]);
        else ctx.lineTo(studs[k2][0] + wob, studs[k2][1]);
      }
      ctx.stroke();
      if (house === 'goldWire') {
        ctx.strokeStyle = 'rgba(255,244,206,0.6)';
        ctx.lineWidth = Math.max(0.6, lw * 0.45);
        ctx.stroke();
      }
    } else {
      setInlay(ctx, studs, house, scale, geo);
    }
    ctx.restore();
    breakMark(ctx, geo, b, scale, scaleX);
  }

  /**
   * Pieces SET INTO the surface, down one side.
   *
   * ⛔ THE FIRST VERSION DREW A RAISED BALL AND THE BOARD READ AS POLKA DOTS.
   * It put the drop shadow at the lower right and the catchlight at the upper
   * left, which is the lighting of a dome sitting ON TOP of the mask; the
   * inherited art-defect list calls them "white dots … polka dots rather than
   * inlay set into the surface", and on a pale mask they read as pustules.
   * Icon_Doctrine §22a-2b: ornament laid ON a form detaches — cut it INTO the
   * form. So the light is INVERTED against the socket: the wall the light cannot
   * reach is the UPPER-LEFT one (this pack lights from upper left, wing-wide),
   * the piece itself sits flat and slightly proud of the socket floor, and the
   * only catch is on the LOWER-RIGHT inner edge. That inversion is the whole
   * difference between a bead and an inlay, and it is not visible to any counter.
   *
   * ⛔ AND EACH HOUSE GETS ITS OWN SHAPE, NOT ONE ELLIPSE IN FOUR COLOURS
   * (wing §21a: a palette is not a composition). Shell is cut in irregular
   * plates, bone is pinned in lozenges, verdigris is a cast diamond plaque, and
   * an iron rivet is the one that genuinely IS raised — a rivet is hammered
   * proud — so it keeps the dome and is told from the rest by being the only
   * one that does.
   *
   * @param {CanvasRenderingContext2D} ctx @param {number[][]} studs Pixel run.
   * @param {string} house The faction treatment id.
   * @param {number} scale px per face unit. @param {object} geo
   */
  function setInlay(ctx, studs, house, scale, geo) {
    var R = deps();
    var fill = {
      verdigris: R.PALETTE.verdigris,
      ironRivet: R.PALETTE.ironRivet,
      shell: R.PALETTE.shellInlay,
      bonePin: R.PALETTE.bone
    }[house] || R.PALETTE.ironRivet;
    var rad = Math.max(1.1, scale * 0.026);

    /* ⛔ Icon_Doctrine §22b-1a: A REPEATED TREATMENT DECLARES A PITCH AND DERIVES
     * ITS COUNT FROM THE REAL RUN — a count cannot express a worked band. The
     * old code stepped the sample list two at a time, which is a count of eight
     * however long the run actually is, so a 140 px rack mask and a 420 px
     * reveal got the same eight pieces at wildly different spacings. */
    var run = 0;
    for (var i = 1; i < studs.length; i++) {
      run += Math.sqrt(Math.pow(studs[i][0] - studs[i - 1][0], 2)
        + Math.pow(studs[i][1] - studs[i - 1][1], 2));
    }
    var pitch = Math.max(rad * 2 + 2.6, rad * 3.4);   /* §22a-2d: paper is absolute px */
    var count = Math.max(3, Math.floor(run / pitch));

    for (var k = 0; k < count; k++) {
      var u = (k + 0.5) / count;
      var fi = u * (studs.length - 1);
      var i0 = Math.floor(fi); var ft = fi - i0;
      var i1 = Math.min(studs.length - 1, i0 + 1);
      var x = studs[i0][0] + (studs[i1][0] - studs[i0][0]) * ft;
      var y = studs[i0][1] + (studs[i1][1] - studs[i0][1]) * ft;
      /* ⛔ EVENLY SPACED PIECES OF ONE SIZE READ AS A DASHED LINE — a zipper
       * running down the cheek, which the first shaped version did on the hero.
       * Regularity is the tell: real inlay is cut and fitted by hand, so each
       * piece takes its own size and sits a little off the line. */
      var jig = geo.grain(u * 17 + 4);
      var siz = 0.74 + Math.abs(geo.grain(u * 29 + 11)) * 0.62;
      x += jig * rad * 0.55;
      y += geo.grain(u * 13 + 7) * rad * 0.30;
      var rr = rad * siz;

      if (house === 'ironRivet') {
        /* the one that is genuinely proud of the surface */
        ctx.fillStyle = 'rgba(0,0,0,0.42)';
        ctx.beginPath();
        ctx.ellipse(x + rr * 0.38, y + rr * 0.44, rr * 0.82, rr * 0.74, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = fill;
        ctx.beginPath();
        ctx.ellipse(x, y, rr * 0.80, rr * 0.72, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = 'rgba(236,238,244,0.45)';
        ctx.beginPath();
        ctx.ellipse(x - rr * 0.26, y - rr * 0.28, rr * 0.30, rr * 0.24, 0, 0, Math.PI * 2);
        ctx.fill();
        continue;
      }

      /* the socket, cut into the face: dark on the light's side */
      ctx.save();
      ctx.beginPath();
      piecePath(ctx, x, y, rr * 1.14, house, geo, u);
      ctx.fillStyle = 'rgba(0,0,0,0.42)';
      ctx.fill();
      ctx.restore();

      /* the piece itself, flat — no dome gradient, that is what made it a bead.
       * ⛔ And it is set at less than full opacity: a pearl-white plate at 100%
       * on a dark mask is a hole punched in the object, not a thing set into it. */
      ctx.save();
      ctx.globalAlpha = 0.86;
      ctx.beginPath();
      piecePath(ctx, x + rr * 0.10, y + rr * 0.12, rr * 0.92, house, geo, u);
      ctx.fillStyle = fill;
      ctx.fill();
      /* the one catch, on the LOWER-RIGHT inner edge of the socket */
      ctx.clip();
      ctx.beginPath();
      piecePath(ctx, x + rr * 0.30, y + rr * 0.34, rr * 0.92, house, geo, u);
      ctx.fillStyle = 'rgba(255,252,242,0.26)';
      ctx.fill();
      ctx.restore();
    }
  }

  /**
   * The outline of one inlaid piece, by house. ⛔ Traced into the CURRENT path
   * so the caller can fill it once — Icon_Doctrine §22d: opening a hole with the
   * bounding box fills the box minus the hole.
   * @param {CanvasRenderingContext2D} ctx @param {number} x @param {number} y
   * @param {number} r Radius in px. @param {string} house @param {object} geo
   * @param {number} u Position along the run, 0…1, so no two pieces are identical.
   */
  function piecePath(ctx, x, y, r, house, geo, u) {
    var i;
    if (house === 'verdigris') {                      /* a cast diamond plaque */
      ctx.moveTo(x, y - r);
      ctx.lineTo(x + r * 0.74, y);
      ctx.lineTo(x, y + r);
      ctx.lineTo(x - r * 0.74, y);
      ctx.closePath();
      return;
    }
    if (house === 'bonePin') {                        /* a pin, lying along the run */
      var a = 0.42 + geo.grain(u * 23) * 0.30;
      ctx.save();
      ctx.translate(x, y); ctx.rotate(a); ctx.translate(-x, -y);
      ctx.moveTo(x - r * 0.34, y - r * 1.05);
      ctx.lineTo(x + r * 0.34, y - r * 1.05);
      ctx.lineTo(x + r * 0.30, y + r * 1.05);
      ctx.lineTo(x - r * 0.30, y + r * 1.05);
      ctx.closePath();
      ctx.restore();
      return;
    }
    /* shell: an irregular cut plate, never the same twice */
    var n = 7;
    for (i = 0; i < n; i++) {
      var th = Math.PI * 2 * (i / n);
      var rr = r * (0.74 + Math.abs(geo.grain(u * 31 + i * 2.3)) * 0.50);
      var px2 = x + Math.cos(th) * rr;
      var py2 = y + Math.sin(th) * rr * 0.88;
      if (i === 0) ctx.moveTo(px2, py2); else ctx.lineTo(px2, py2);
    }
    ctx.closePath();
  }

  /**
   * The one seeded structural break — the third asymmetry, and the reason no
   * two masks in the demo database are the same picture even when they are
   * classified identically (wing §25g: siblings, told apart by their break).
   * @param {CanvasRenderingContext2D} ctx Target.
   * @param {object} geo @param {object} b Bounds. @param {number} scale px/unit.
   */
  function breakMark(ctx, geo, b, scale, scaleX) {
    var R = deps();
    var toPx = function (fx, fy) { return [(fx - b.minX) * scaleX, (fy - b.minY) * scale]; };
    var kind = geo.breakDrawn;
    ctx.save();
    if (kind === 'cordScar') {
      var a = toPx(-0.85, 0.50);
      var c = toPx(0.35, 0.82);
      ctx.lineCap = 'round';
      ctx.strokeStyle = 'rgba(0,0,0,0.45)';
      ctx.lineWidth = Math.max(2, scale * 0.030);
      ctx.beginPath(); ctx.moveTo(a[0] + 2, a[1] + 2); ctx.lineTo(c[0] + 2, c[1] + 2); ctx.stroke();
      ctx.strokeStyle = R.PALETTE.cord;
      ctx.lineWidth = Math.max(1.5, scale * 0.022);
      ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(c[0], c[1]); ctx.stroke();
    } else if (kind === 'boundCrack') {
      /* A crack bound shut with iron staples, laid ACROSS the crack the pixel pass
       * cut — `boundCrackX` is the same function both halves read (wing §11).
       *
       * ⛔ THE COUNT IS DERIVED, NOT TYPED (§24d): a repeated treatment declares a
       * PITCH and takes its count from the real run, or a 140 px rack mask and a
       * 420 px reveal wear the same three staples at different spacings. The pitch
       * is absolute pixels, because a staple is a real object the size of a staple.
       * ⛔ And they are not evenly identical: a smith sets each one by hand. */
      var runPx = (BOUND_BOTTOM - BOUND_TOP) * scale;
      var pitchPx = Math.max(scale * 0.13, 16);
      var n = Math.max(2, Math.min(6, Math.round(runPx / pitchPx)));
      var halfLen = Math.max(2.5, scale * 0.052);
      var thick = Math.max(1.2, scale * 0.013);
      for (var i = 0; i < n; i++) {
        var fy = BOUND_TOP + (i + 0.5) * (BOUND_BOTTOM - BOUND_TOP) / n;
        var jitter = geo.grain(fy * 19 + 5) * 0.012;
        var p = toPx(boundCrackX(geo, fy) + jitter, fy + geo.grain(fy * 7 + 1) * 0.008);
        var tilt = geo.grain(fy * 23 + 9) * 0.30;          /* each staple sits its own way */
        var len = halfLen * (0.82 + Math.abs(geo.grain(fy * 31 + 3)) * 0.42);
        var dx = Math.cos(tilt) * len, dy = Math.sin(tilt) * len;
        /* the shadow it casts into the crack, down-right of the light */
        ctx.strokeStyle = 'rgba(0,0,0,0.55)';
        ctx.lineWidth = thick * 1.7;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(p[0] - dx + 1.2, p[1] - dy + 1.4);
        ctx.lineTo(p[0] + dx + 1.2, p[1] + dy + 1.4);
        ctx.stroke();
        /* the iron itself, and one catch on its lit upper-left edge */
        ctx.strokeStyle = R.PALETTE.ironRivet;
        ctx.lineWidth = thick;
        ctx.beginPath();
        ctx.moveTo(p[0] - dx, p[1] - dy);
        ctx.lineTo(p[0] + dx, p[1] + dy);
        ctx.stroke();
        ctx.strokeStyle = 'rgba(236,238,244,0.40)';
        ctx.lineWidth = Math.max(0.6, thick * 0.40);
        ctx.beginPath();
        ctx.moveTo(p[0] - dx, p[1] - dy - thick * 0.42);
        ctx.lineTo(p[0] + dx, p[1] + dy - thick * 0.42);
        ctx.stroke();
      }
    } else if (kind === 'scorch') {
      var s = toPx(-0.40, 0.62);
      var g = ctx.createRadialGradient(s[0], s[1], scale * 0.02, s[0], s[1], scale * 0.30);
      g.addColorStop(0, 'rgba(10,6,4,0.80)');
      g.addColorStop(0.6, 'rgba(24,14,8,0.40)');
      g.addColorStop(1, 'rgba(24,14,8,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(s[0], s[1], scale * 0.30, scale * 0.24, 0.3, 0, Math.PI * 2);
      ctx.fill();
    }
    /* brokenHorn, faceCrack and chippedJaw are cut in the pixel pass, where
     * they belong: a break that is PAINTED ON rather than taken OUT is the
     * defect wing §17c-1 names — the call happens, the object does not change. */
    ctx.restore();
  }

  return {
    SILHOUETTE: SILHOUETTE,
    EYE: EYE,
    MOUTH: MOUTH,
    RELIEF: RELIEF,
    deps: deps,
    massesFor: massesFor,
    crownOf: crownOf,
    horn: horn,
    halfWidth: halfWidth,
    inPoly: inPoly,
    inVoid: inVoid,
    inside: inside,
    geometry: geometry,
    edgeDistance: edgeDistance,
    boundCrackX: boundCrackX,
    BOUND_TOP: BOUND_TOP,
    BOUND_BOTTOM: BOUND_BOTTOM,
    rimAt: rimAt,
    wearAt: wearAt,
    paintAt: paintAt,
    paintInk: paintInk,
    light2: light2,
    paintColour: paintColour,
    carve: carve
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.VisageCarve;
