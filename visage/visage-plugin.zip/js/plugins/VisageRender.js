//=============================================================================
// VisageRender.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Visage [2/4] — the surface. Colour, the shipped faces, seeded grain, and the relief field every mask is lit from. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Visage — the surface
 * ============================================================================
 * Load this SECOND. It defines no scene, adds no command and patches no core
 * method. Nothing here knows what a mask is; it knows what wood is, what brass
 * is, and how a convex form behaves under one light.
 *
 * THE ONE LIGHT
 * Every mask, every peg, every placard and every plate in this product is lit
 * from the UPPER LEFT and from slightly in front. One direction, pack-wide, is
 * what makes a wall of forty masks read as one wall rather than forty stickers.
 *
 * HOW THE CARVING IS DRAWN
 * Not as shapes with a highlight painted on. `field()` builds a RELIEF — a sum
 * of smooth masses (a brow, two cheekbones, a nose ridge, a jaw) minus the
 * hollows (the eye sockets) — and `shade()` lights that relief per pixel from
 * its own surface normal. Move a cheekbone and the highlight, the shadow and
 * the worn edge all move with it, because all three are consequences of the
 * same number.
 * ============================================================================
 */

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};
var CSAF = globalThis.CSAF;

CSAF.VisageRender = (function () {
  'use strict';

  /* ═══════════════════════════════════════════════════════════ the palette ══
   * The art director's palette, by role. ⛔ Nothing downstream types a hex. */
  var PALETTE = {
    wallDark: '#231A14',
    wallLit: '#3A2A1E',
    oak: '#7A5230', oakLit: '#B07C4A', oakShadow: '#4A3120',
    bone: '#E6D9BE', boneShadow: '#B9A98A',
    lacquer: '#15100D',
    brass: '#C9A24A', brassDeep: '#7E5F22',
    cord: '#8C2B24',
    goldWire: '#D9B85C', verdigris: '#5E8F7A', ironRivet: '#6E6E72', shellInlay: '#E8D8D0'
  };

  /**
   * The three base materials a mask is struck from, by structure. The brief
   * assigns them: oak for things that grew, bone for things that died or never
   * lived, lacquer for things that were made.
   */
  var MATERIALS = {
    oak: { mid: PALETTE.oak, lit: PALETTE.oakLit, shadow: PALETTE.oakShadow, gloss: 0.10, grain: 0.85 },
    bone: { mid: PALETTE.bone, lit: '#F4EBD6', shadow: PALETTE.boneShadow, gloss: 0.16, grain: 0.30 },
    lacquer: { mid: PALETTE.lacquer, lit: '#3C332C', shadow: '#090707', gloss: 0.55, grain: 0.12 }
  };

  /** Which material each of the ten structures is cut from. */
  var STRUCTURE_MATERIAL = {
    beast: 'oak', humanoid: 'oak', plant: 'oak', dragon: 'oak',
    undead: 'bone', spirit: 'bone', aquatic: 'bone',
    construct: 'lacquer', fiend: 'lacquer', insect: 'lacquer'
  };

  /* ⛔ ONE LIGHT DIRECTION, PACK-WIDE, AND IT IS A CONSTANT ON PURPOSE. Upper
   * left and in front: x negative, y negative, z positive, normalised. */
  var LIGHT = (function () {
    var v = [-0.52, -0.68, 0.52];
    var m = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    return [v[0] / m, v[1] / m, v[2] / m];
  })();

  /* ═════════════════════════════════════════════════════════════════ colour ══ */

  /** @param {string} hex `#rrggbb` @returns {number[]} `[r,g,b]` 0…255 */
  function rgb(hex) {
    var h = String(hex).replace('#', '');
    /* ⛔ wing §21c: AN UNPARSEABLE COLOUR FAILS SILENTLY AND IN THE WORST DIRECTION.
     * `parseInt('no', 16)` is NaN, and a NaN channel travels: it makes every distance
     * comparison in `separate()` false, so the solver returns its most extreme candidate,
     * and a `fillStyle` built from it is INVALID — which canvas answers by keeping the
     * PREVIOUS colour, so the mask is painted in whatever was last set. Nothing throws and
     * nothing logs. MEASURED 2026-09-13 by `_probe/break_it.js`, which fed it
     * "not-a-colour" and got back [NaN, NaN, 10].
     * Three hex digits are also legal in CSS and in a buyer's head, so they are read here
     * rather than producing two NaNs and a number. Anything still unreadable returns null,
     * and every caller treats null as "no pigment" — the one safe reading. */
    if (/^[0-9a-fA-F]{3}$/.test(h)) {
      return [parseInt(h[0] + h[0], 16), parseInt(h[1] + h[1], 16), parseInt(h[2] + h[2], 16)];
    }
    if (!/^[0-9a-fA-F]{6}$/.test(h)) return null;
    return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)];
  }

  /** @param {number[]} c `[r,g,b]` @returns {string} `#rrggbb` */
  function hex(c) {
    var f = function (v) {
      var n = Math.round(Math.min(255, Math.max(0, v))).toString(16);
      return n.length < 2 ? '0' + n : n;
    };
    return '#' + f(c[0]) + f(c[1]) + f(c[2]);
  }

  /**
   * @param {number[]} a First colour. @param {number[]} b Second.
   * @param {number} t 0 = a, 1 = b. @returns {number[]} Mixed.
   */
  function mix(a, b, t) {
    var u = Math.min(1, Math.max(0, t));
    return [a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u];
  }

  /**
   * Relative luminance, GAMMA-EXPANDED.
   * ⛔ wing §25h: `inkFor` once picked its direction from a plain channel
   * average and chose BLACK at 4.01:1 where WHITE was worth 5.24:1. Contrast is
   * not linear in sRGB and an average is not a luminance.
   * @param {number[]} c `[r,g,b]` 0…255.
   * @returns {number} 0 … 1.
   */
  function luminance(c) {
    var f = function (v) {
      var s = v / 255;
      return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
    };
    return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
  }

  /** @param {number[]} a @param {number[]} b @returns {number} WCAG contrast ratio. */
  function contrast(a, b) {
    var la = luminance(a); var lb = luminance(b);
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  }

  /**
   * The ink to write on a given surface: try BOTH directions and keep the first
   * that clears the bar, else the better of the two (wing §25h).
   * @param {string} surface The background, `#rrggbb`.
   * @param {number} [want] The ratio wanted. Default 4.5 (AA).
   * @returns {{hex:string,ratio:number,cleared:boolean}} The ink.
   */
  function inkFor(surface, want) {
    /* `rgb()` returns null for an unreadable colour rather than NaN channels (see it for
     * why). A surface nobody can read is treated as mid-grey: the ink solver then picks
     * whichever of the two inks has more contrast against it, which is still a legible
     * answer, and the placard gets text instead of the caller getting an exception. */
    var bg = rgb(surface) || [128, 128, 128];
    var bar = want || 4.5;
    var light = rgb(PALETTE.bone);
    var dark = rgb('#120C08');
    var cl = contrast(bg, light);
    var cd = contrast(bg, dark);
    if (cd >= bar) return { hex: hex(dark), ratio: cd, cleared: true };
    if (cl >= bar) return { hex: hex(light), ratio: cl, cleared: true };
    return cl > cd
      ? { hex: hex(light), ratio: cl, cleared: false }
      : { hex: hex(dark), ratio: cd, cleared: false };
  }

  /** Mean per-channel distance between two colours, 0 … 255. */
  function channelDistance(a, b) {
    return (Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) + Math.abs(a[2] - b[2])) / 3;
  }

  /**
   * Push a pigment away from the material it is painted on until the two are
   * visibly different, keeping as much of the pigment's hue as the separation
   * allows.
   *
   * ⛔ Icon_Doctrine §22e-1: a MULTIPLIER is a hard-coded contrast RATIO. Any
   * tint whose job is to make something VISIBLE must state its separation in
   * ABSOLUTE terms and SOLVE for it. The separation here is a mean per-channel
   * distance — the same quantity `_probe/pigment_read.js` reports, so the guard
   * and the instrument speak one language.
   *
   * ⛔ Measured 2026-09-12, and it is the reason this function exists: `light`
   * (#F2E6B8) painted on a `bone` mask (#E6D9BE) moved the picture by a mean of
   * 1.4 levels at full coverage. The placard read "… · LIGHT · …" over a mask
   * with no light on it (wing §17c). `earth` on oak and `darkness` on lacquer
   * are the same defect in other pairings.
   *
   * ⛔ §22e-1 again, both halves: TRY BOTH DIRECTIONS and keep the first that
   * clears, else the better of the two — and the bar is `min(want, headroom)`,
   * because on a near-white material nothing is much lighter and on a near-black
   * one nothing is much darker. Overshoot is a real failure mode in the
   * permissive direction, so the solve stops at the FIRST step that clears
   * rather than running to the end.
   *
   * @param {number[]} pigment `[r,g,b]` the element's own colour.
   * @param {number[]} material `[r,g,b]` the surface it is painted on.
   * @param {number} want Minimum mean per-channel distance wanted.
   * @returns {{colour:number[], got:number, moved:number, cleared:boolean}}
   */
  function separate(pigment, material, want) {
    var have = channelDistance(pigment, material);
    if (have >= want) return { colour: pigment, got: have, moved: 0, cleared: true };
    var best = { colour: pigment, got: have, moved: 0, cleared: false };

    /* ⛔ SEPARATE BY SCALING THE CHANNELS, NOT BY BLENDING TOWARD WHITE OR BLACK.
     * A blend toward white is a blend toward NO HUE: `earth` (#8A6A3D) needed a
     * long move to clear oak and came out as pale cream, so the mask stopped
     * looking like painted oak and started looking like plaster, and EARTH — the
     * thing the placard names — was no longer an earth colour at all. Measured
     * on `_probe/out/crowns.png`, 2026-09-12: every one of the twelve read as the
     * same pale tan face.
     *
     * Multiplying every channel by one factor moves luminance while holding the
     * ratios between channels, so the pigment gets lighter or darker and stays
     * the colour it is named for. Scaled up, `earth` becomes a bright ochre;
     * blended to white it becomes nothing.
     *
     * ⛔ §22e-1's both-directions rule still binds, and so does `min(want,
     * headroom)`: a pigment that is already near white cannot be scaled lighter
     * and one near black cannot be scaled darker, so a blend toward the extreme
     * remains as the LAST resort for colours with no multiplicative headroom
     * left — better a desaturated pigment than an invisible one.
     */
    var clamp = function (v) { return v < 0 ? 0 : (v > 255 ? 255 : v); };
    var scaled = function (k) {
      return [clamp(pigment[0] * k), clamp(pigment[1] * k), clamp(pigment[2] * k)];
    };
    var lum = luminance(material);
    var up = [];
    var down = [];
    var i;
    for (i = 1; i <= 24; i++) { up.push(1 + i * 0.085); down.push(1 - i * 0.035); }
    var orders = lum > 0.18 ? [down, up] : [up, down];
    var d; var step; var c; var got;
    for (d = 0; d < orders.length; d++) {
      for (step = 0; step < orders[d].length; step++) {
        c = scaled(orders[d][step]);
        got = channelDistance(c, material);
        if (got > best.got) best = { colour: c, got: got, moved: orders[d][step], cleared: got >= want };
        if (got >= want) return { colour: c, got: got, moved: orders[d][step], cleared: true };
      }
    }
    /* last resort: give up some chroma rather than ship an invisible element */
    var ext = lum > 0.18 ? [8, 6, 5] : [255, 252, 244];
    for (step = 1; step <= 20; step++) {
      c = mix(pigment, ext, step / 20);
      got = channelDistance(c, material);
      if (got > best.got) best = { colour: c, got: got, moved: step / 20, cleared: got >= want };
      if (got >= want) return { colour: c, got: got, moved: step / 20, cleared: true };
    }
    return best;
  }

  /* ════════════════════════════════════════════════════════════════ the RNG ══
   * ⛔ wing rule 2: never `Math.random()`. A generator is made per mask, from
   * that mask's own seed, and never shared — a shared generator would make a
   * mask depend on how many masks were drawn before it. */

  /** @param {number} seed @returns {function(): number} () => [0,1) */
  function rng(seed) {
    var a = (seed >>> 0) || 1;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /**
   * Smooth 1D value noise, for grain running along the cut of the wood.
   * @param {number} seed Any uint32.
   * @param {number} octaves How many halvings. 3 is plenty at mask scale.
   * @returns {function(number): number} x => −1 … 1
   */
  function noise1(seed, octaves) {
    var oct = octaves || 3;
    var perm = new Float64Array(256);
    var r = rng(seed);
    for (var i = 0; i < 256; i++) perm[i] = r() * 2 - 1;
    return function (x) {
      var sum = 0; var amp = 1; var norm = 0; var f = 1;
      for (var o = 0; o < oct; o++) {
        var xf = x * f;
        var i0 = Math.floor(xf) & 255;
        var i1 = (i0 + 1) & 255;
        var t = xf - Math.floor(xf);
        var s = t * t * (3 - 2 * t);
        sum += (perm[i0] + (perm[i1] - perm[i0]) * s) * amp;
        norm += amp; amp *= 0.5; f *= 2.1;
      }
      return sum / (norm || 1);
    };
  }

  /**
   * Smooth 2D value noise, for the wall's grain and for chipping.
   * @param {number} seed Any uint32.
   * @returns {function(number, number): number} (x,y) => −1 … 1
   */
  function noise2(seed) {
    var perm = new Float64Array(4096);
    var r = rng(seed);
    for (var i = 0; i < 4096; i++) perm[i] = r() * 2 - 1;
    var at = function (ix, iy) { return perm[(((ix & 63) << 6) | (iy & 63)) & 4095]; };
    return function (x, y) {
      var x0 = Math.floor(x); var y0 = Math.floor(y);
      var tx = x - x0; var ty = y - y0;
      var sx = tx * tx * (3 - 2 * tx); var sy = ty * ty * (3 - 2 * ty);
      var a = at(x0, y0); var b = at(x0 + 1, y0);
      var c = at(x0, y0 + 1); var d = at(x0 + 1, y0 + 1);
      return (a + (b - a) * sx) + ((c + (d - c) * sx) - (a + (b - a) * sx)) * sy;
    };
  }

  /* ═══════════════════════════════════════════════════════════ the relief ══
   * A mask is a sum of MASSES. Each is a smooth bump (or hollow) in the plane
   * of the face, and the surface is their sum. Nothing is drawn from this
   * directly — `shade()` lights it, so the highlight and the shadow are
   * CONSEQUENCES of the form rather than decisions about it. */

  /**
   * Build a relief field from a list of masses.
   *
   * Each mass: `{x, y, rx, ry, amp, rot, kind}` in face space, where x is −1 …
   * 1 across the face and y is 0 (top) … 1 (bottom). `kind` is `'bump'`
   * (default, a smooth dome), `'ridge'` (a long crease, sharper across than
   * along) or `'hollow'` (a negative dome, for an eye socket).
   *
   * @param {object[]} masses The masses.
   * @returns {{at: function(number, number): number, grad: function(number, number): number[]}}
   *   `at(x,y)` is the surface height; `grad(x,y)` its slope, by central
   *   difference so that a mass added later cannot be forgotten in the normal.
   */
  function field(masses) {
    var list = masses || [];
    var at = function (x, y) {
      var h = 0;
      for (var i = 0; i < list.length; i++) {
        var m = list[i];
        var dx = x - m.x; var dy = y - m.y;
        if (m.rot) {
          var c = Math.cos(m.rot); var s = Math.sin(m.rot);
          var rx = dx * c - dy * s; var ry = dx * s + dy * c;
          dx = rx; dy = ry;
        }
        var u = dx / (m.rx || 0.2); var v = dy / (m.ry || 0.2);
        var d2 = u * u + v * v;
        if (d2 > 9) continue;             /* beyond three sigma it is nothing */
        var g = Math.exp(-d2 * (m.kind === 'ridge' ? 1.6 : 1.1));
        h += (m.amp || 0) * g;
      }
      return h;
    };
    /* ⛔ CENTRAL DIFFERENCE, NOT AN ANALYTIC GRADIENT PER MASS. An analytic
     * gradient has to be updated every time a mass kind is added, and the one
     * that gets forgotten produces a surface whose shading does not match its
     * silhouette — visible, and invisible to every counter. */
    var eps = 0.004;
    return {
      at: at,
      grad: function (x, y) {
        return [(at(x + eps, y) - at(x - eps, y)) / (2 * eps),
          (at(x, y + eps) - at(x, y - eps)) / (2 * eps)];
      }
    };
  }

  /**
   * Light one point of a relief.
   * @param {number[]} g The gradient `[dx, dy]` at that point.
   * @param {number} relief How much real depth the field stands for, 0 … 1.
   * @returns {{diffuse:number, spec:number, slope:number}} Lighting terms.
   */
  function shade(g, relief) {
    var k = relief || 0.35;
    var nx = -g[0] * k; var ny = -g[1] * k; var nz = 1;
    var m = Math.sqrt(nx * nx + ny * ny + 1) || 1;
    nx /= m; ny /= m; nz /= m;
    var d = nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2];
    /* half-vector specular against a viewer straight on */
    var hx = LIGHT[0]; var hy = LIGHT[1]; var hz = LIGHT[2] + 1;
    var hm = Math.sqrt(hx * hx + hy * hy + hz * hz) || 1;
    var s = nx * (hx / hm) + ny * (hy / hm) + nz * (hz / hm);
    return {
      diffuse: Math.max(0, d),
      spec: Math.pow(Math.max(0, s), 22),
      slope: Math.sqrt(g[0] * g[0] + g[1] * g[1])
    };
  }

  /* ══════════════════════════════════════════════════════════════ the faces ══ */

  var DISPLAY_FAMILY = 'VisageDisplay';
  var BODY_FAMILY = 'VisageBody';
  /* ⛔ wing §15a: a real fallback stack, and NEVER `rmmz-mainfont` — MZ's own
   * face is a monospace and is the loudest "this is RPG Maker" signal there is.
   * A buyer who never copies the fonts across still gets an inscriptional serif
   * and a book serif; they get a worse product, never a broken one. */
  var FACES = {
    display: '"' + DISPLAY_FAMILY + '", Cinzel, "Trajan Pro", "Palatino Linotype", Palatino, Georgia, serif',
    body: '"' + BODY_FAMILY + '", "Crimson Pro", "Crimson Text", Georgia, "Times New Roman", serif'
  };

  var _fontState = 'idle';

  /**
   * Load the two shipped faces, once, without ever being able to break a boot.
   *
   * ⛔ DO NOT USE `FontManager.load` FOR A SHIPPED FONT. MEASURED in the engine
   * source, `rmmz_managers.js:806`: a failed load sets the family's state to
   * "error", and `FontManager.isReady()` — which `Scene_Boot` polls every frame
   * — calls `throwLoadError()`, which THROWS. A buyer who forgets to copy
   * `fonts/` across would get a crashed title screen instead of a fallback.
   * `new FontFace(...)` with our own `.catch()` cannot do that.
   *
   * @param {string} [dir] Folder the faces live in, relative to the game root.
   * @returns {boolean} True if loading started or has already finished.
   */
  function ensureFonts(dir) {
    if (_fontState !== 'idle') return true;
    if (typeof document === 'undefined' || typeof FontFace === 'undefined') {
      _fontState = 'unavailable';
      return false;
    }
    _fontState = 'loading';
    /* ⛔ No regex trimming the slash here. MEASURED in Refectory 2026-09-10: a
     * `/\/*$/` literal reads as a BLOCK COMMENT OPENER to any source scanner
     * that strips comments, which ate the rest of that file and reported its
     * font loader missing. */
    var base = String(dir || 'fonts/');
    if (base.charAt(base.length - 1) !== '/') base += '/';
    var want = [
      [DISPLAY_FAMILY, base + 'Visage-Display.woff2'],
      [BODY_FAMILY, base + 'Visage-Body.woff2']
    ];
    var done = 0;
    for (var i = 0; i < want.length; i++) {
      (function (family, url) {
        try {
          var face = new FontFace(family, 'url(' + url + ')');
          face.load().then(function (f) {
            document.fonts.add(f);
            done++;
            if (done === want.length) _fontState = 'loaded';
            return 0;
          }).catch(function () {
            /* ⛔ Silent by design: the stack falls back, the game does not stop. */
            _fontState = 'fallback';
          });
        } catch (e) {
          _fontState = 'fallback';
        }
      })(want[i][0], want[i][1]);
    }
    return true;
  }

  /** @returns {string} idle | loading | loaded | fallback | unavailable */
  function fontState() { return _fontState; }

  /* ═══════════════════════════════════════════════════════════ the surfaces ══ */

  /**
   * The wall every mask hangs on: dark walnut planks, grain, vignette.
   * ⛔ wing §21b: "the code ran" and "the picture changed" are different claims.
   * The grain alpha here is deliberately above the 4% that vanished on a
   * near-black ground in Vista, and `_probe/contrast_check.js` MEASURES it on
   * the rendered PNG rather than trusting the number.
   * @param {CanvasRenderingContext2D} ctx Target.
   * @param {number} w Width. @param {number} h Height.
   * @param {number} seed For the grain.
   * @param {number} [plank] Plank pitch in px. Default 96.
   */
  function wall(ctx, w, h, seed, plank) {
    var pitch = plank || 96;
    var g = ctx.createLinearGradient(0, 0, w * 0.75, h);
    g.addColorStop(0, PALETTE.wallLit);
    g.addColorStop(1, PALETTE.wallDark);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);

    var n = noise1(seed ^ 0x51ED, 3);
    ctx.save();
    for (var y = 0; y < h; y += pitch) {
      /* the shadowed groove between two boards */
      ctx.fillStyle = 'rgba(8,5,3,0.55)';
      ctx.fillRect(0, y, w, 2);
      ctx.fillStyle = 'rgba(255,226,190,0.055)';
      ctx.fillRect(0, y + 2, w, 1);
      /* grain: long strokes running with the board */
      var rows = Math.floor(pitch / 7);
      for (var k = 0; k < rows; k++) {
        var yy = y + 5 + k * 7 + n(k * 3.1 + y) * 2;
        ctx.strokeStyle = 'rgba(214,178,134,' + (0.055 + Math.abs(n(k + y * 0.02)) * 0.055).toFixed(3) + ')';
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (var x = 0; x <= w; x += 16) {
          var yo = yy + n(x * 0.02 + k * 7.3 + y) * 1.8;
          if (x === 0) ctx.moveTo(x, yo); else ctx.lineTo(x, yo);
        }
        ctx.stroke();
      }
    }
    ctx.restore();

    /* vignette to the corners, so the eye goes to the mask */
    var v = ctx.createRadialGradient(w * 0.42, h * 0.40, Math.min(w, h) * 0.18,
      w * 0.5, h * 0.5, Math.max(w, h) * 0.78);
    v.addColorStop(0, 'rgba(0,0,0,0)');
    v.addColorStop(1, 'rgba(0,0,0,0.62)');
    ctx.fillStyle = v;
    ctx.fillRect(0, 0, w, h);
  }

  /**
   * An iron peg, with its own short cast shadow down-right.
   * @param {CanvasRenderingContext2D} ctx Target.
   * @param {number} x Centre. @param {number} y Top of the peg.
   * @param {number} r Peg radius in px.
   */
  function peg(ctx, x, y, r) {
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.beginPath();
    ctx.ellipse(x + r * 0.9, y + r * 1.0, r * 1.15, r * 0.7, 0, 0, Math.PI * 2);
    ctx.fill();
    var g = ctx.createLinearGradient(x - r, y - r, x + r, y + r);
    g.addColorStop(0, '#8A8A90');
    g.addColorStop(0.45, '#5A5A60');
    g.addColorStop(1, '#26262B');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(x, y, r, r * 0.92, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,248,230,0.55)';
    ctx.beginPath();
    ctx.ellipse(x - r * 0.32, y - r * 0.34, r * 0.26, r * 0.20, -0.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  /**
   * The single knotted cord — the motif, and one of the three asymmetries.
   * @param {CanvasRenderingContext2D} ctx Target.
   * @param {number} px Peg x. @param {number} py Peg y.
   * @param {number} kx Knot x, on the mask. @param {number} ky Knot y.
   * @param {number} width Cord width in px.
   */
  function cord(ctx, px, py, kx, ky, width, part) {
    var w = width || 3;
    /* ⛔ THE RUN GOES BEHIND THE MASK AND THE KNOT GOES IN FRONT OF IT, so this
     * is called twice with the object drawn between. Drawn in one pass before
     * the mask, the binding — the one mark that says a person tied this up — is
     * covered by the very object it is tying, and all a viewer sees is a red
     * line vanishing into the top edge, which reads as a scratch. Drawn in one
     * pass after, the cord lies ON the mask like a stripe. A cord passing over
     * an edge is in front of some of the object and behind the rest, and that is
     * two draws, not a compromise between them. */
    var doRun = part !== 'knot';
    var doKnot = part !== 'run';
    ctx.save();
    ctx.lineCap = 'round';

    /* ⛔ THE SAG CAME FROM THE HORIZONTAL RUN, SO A CORD HANGING NEARLY STRAIGHT
     * DOWN HAD NONE AND ONE RUNNING SIDEWAYS HAD A LOT — the exact opposite of
     * how a loaded cord behaves. The inherited art-defect list reads "the cord
     * is short and nearly vertical … the brief asks for a hanging cord with a
     * visible knot and a few degrees of tilt reading as weight", and on the
     * first hero plate it came out as a red squiggle lying sideways in mid-air.
     * A cord under load sags along its OWN LENGTH: the slack is a property of
     * how much cord there is between two points, not of how far apart they are
     * left to right. */
    var span = Math.sqrt((kx - px) * (kx - px) + (ky - py) * (ky - py));
    var sag = Math.max(2.5, span * 0.085);

    /* ⛔ AND A CORD IS NOT A LINE. Two laid strands and a slight taper are what
     * separate a cord from a drawn stroke; without them this is a red pen mark
     * whatever its curve (Icon_Doctrine §22b-1a: a flat stroke is an OUTLINE). */
    var mx = (px + kx) / 2;
    var my = (py + ky) / 2 + sag;
    var at = function (t) {
      var u = 1 - t;
      return [u * u * px + 2 * u * t * mx + t * t * kx, u * u * py + 2 * u * t * my + t * t * ky];
    };
    var draw = function (colour, lw, dx, dy) {
      ctx.strokeStyle = colour;
      ctx.lineWidth = lw;
      ctx.beginPath();
      ctx.moveTo(px + dx, py + dy);
      ctx.quadraticCurveTo(mx + dx, my + dy, kx + dx, ky + dy);
      ctx.stroke();
    };
    if (doRun) {
      draw('rgba(0,0,0,0.45)', w + 2.0, 2, 2.4);
      draw(PALETTE.cord, w, 0, 0);
      draw('rgba(255,214,196,0.26)', Math.max(1, w * 0.32), -0.7, -0.7);

      /* the lay of the rope: ticks across it at a PITCH derived from the real
       * length, never a typed count (Icon_Doctrine §22b-1a) */
      var pitch = Math.max(3.2, w * 1.9);
      var turns = Math.max(2, Math.floor(span / pitch));
      ctx.strokeStyle = 'rgba(0,0,0,0.26)';
      ctx.lineWidth = Math.max(0.7, w * 0.26);
      for (var i = 1; i < turns; i++) {
        var a = at(i / turns);
        var b2 = at(Math.min(1, i / turns + 0.012));
        var dx2 = b2[0] - a[0]; var dy2 = b2[1] - a[1];
        var L = Math.sqrt(dx2 * dx2 + dy2 * dy2) || 1;
        var nx = -dy2 / L; var ny = dx2 / L;
        ctx.beginPath();
        ctx.moveTo(a[0] - nx * w * 0.5 + dx2 * 2, a[1] - ny * w * 0.5 + dy2 * 2);
        ctx.lineTo(a[0] + nx * w * 0.5 - dx2 * 2, a[1] + ny * w * 0.5 - dy2 * 2);
        ctx.stroke();
      }
    }
    if (!doKnot) { ctx.restore(); return; }

    /* ⛔ THE KNOT IS A BOUND LUMP WITH TAILS, NOT A BEAD. An ellipse on the end
     * of a line is a pin head; what says "tied" is the two short cut ends
     * hanging out of the binding, and they are the cheapest possible signal that
     * this object was hung by a person. */
    /* ⛔ A KNOT IS SEVERAL TIMES THE DIAMETER OF THE CORD THAT MAKES IT. At 1.25
     * cord-widths it was a pin head four pixels across on a 420 px mask and did
     * not register at all — the brief fixes the CORD at 3 px, which is a thread,
     * and a thread's knot is the only part of it with any mass. Two and a half
     * widths with tails that read is what makes the cord look tied rather than
     * drawn. */
    var tailA = Math.atan2(ky - my, kx - mx);
    ctx.strokeStyle = 'rgba(0,0,0,0.4)';
    ctx.lineWidth = Math.max(1.2, w * 1.0);
    for (var s0 = -1; s0 <= 1; s0 += 2) {
      ctx.beginPath();
      ctx.moveTo(kx + 1.2, ky + 1.4);
      ctx.quadraticCurveTo(
        kx + Math.cos(tailA + s0 * 0.55) * w * 2.6 + 1.2, ky + Math.sin(tailA + s0 * 0.55) * w * 2.6 + 1.4,
        kx + Math.cos(tailA + s0 * 1.05) * w * 4.6 + 1.2, ky + Math.sin(tailA + s0 * 1.05) * w * 4.6 + 1.4
      );
      ctx.stroke();
    }
    ctx.strokeStyle = PALETTE.cord;
    ctx.lineWidth = Math.max(1, w * 0.85);
    for (var s = -1; s <= 1; s += 2) {
      ctx.beginPath();
      ctx.moveTo(kx, ky);
      ctx.quadraticCurveTo(
        kx + Math.cos(tailA + s * 0.55) * w * 2.6, ky + Math.sin(tailA + s * 0.55) * w * 2.6,
        kx + Math.cos(tailA + s * 1.05) * w * 4.6, ky + Math.sin(tailA + s * 1.05) * w * 4.6
      );
      ctx.stroke();
    }
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.beginPath();
    ctx.ellipse(kx + w * 0.5, ky + w * 0.55, w * 2.7, w * 2.1, 0.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = PALETTE.cord;
    ctx.beginPath();
    ctx.ellipse(kx, ky, w * 2.5, w * 1.9, 0.5, 0, Math.PI * 2);
    ctx.fill();
    /* the two turns of the binding, and one catch on the light's side */
    ctx.strokeStyle = 'rgba(0,0,0,0.34)';
    ctx.lineWidth = Math.max(0.8, w * 0.34);
    for (var t2 = -1; t2 <= 1; t2 += 2) {
      ctx.beginPath();
      ctx.moveTo(kx - w * 1.9 + t2 * w * 0.5, ky - w * 0.9 + t2 * w * 0.55);
      ctx.quadraticCurveTo(kx + t2 * w * 0.4, ky + t2 * w * 0.2,
        kx + w * 1.9 + t2 * w * 0.5, ky + w * 0.9 + t2 * w * 0.55);
      ctx.stroke();
    }
    ctx.fillStyle = 'rgba(255,206,188,0.30)';
    ctx.beginPath();
    ctx.ellipse(kx - w * 0.7, ky - w * 0.6, w * 0.9, w * 0.5, 0.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  /**
   * A brass placard, engraved: dark letters with a one-pixel light offset
   * beneath, which is what an engraved letter actually looks like.
   * @param {CanvasRenderingContext2D} ctx Target.
   * @param {object} o `{x, y, w, h, title, readings}`
   */
  function placard(ctx, o) {
    var x = o.x; var y = o.y; var w = o.w; var h = o.h;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.fillRect(x + 3, y + 4, w, h);
    var g = ctx.createLinearGradient(x, y, x + w * 0.4, y + h);
    g.addColorStop(0, '#E3C271');
    g.addColorStop(0.5, PALETTE.brass);
    g.addColorStop(1, PALETTE.brassDeep);
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = 'rgba(255,240,200,0.45)';
    ctx.lineWidth = 1;
    ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
    ctx.strokeStyle = 'rgba(60,40,10,0.5)';
    ctx.strokeRect(x + 2.5, y + 2.5, w - 5, h - 5);

    var ink = inkFor(PALETTE.brass, 4.5);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    var engrave = function (text, font, cy) {
      ctx.font = font;
      ctx.fillStyle = 'rgba(255,238,200,0.55)';
      ctx.fillText(text, x + w / 2, cy + 1);
      ctx.fillStyle = ink.hex;
      ctx.fillText(text, x + w / 2, cy);
    };
    if (o.title) engrave(o.title, '600 ' + Math.round(h * 0.46) + 'px ' + FACES.display, y + h * 0.52);
    if (o.readings && o.readings.length) {
      engrave(o.readings.join('  ·  '), Math.round(h * 0.26) + 'px ' + FACES.body, y + h * 0.84);
    }
    ctx.restore();
  }

  /**
   * A rounded rectangle path. ⛔ wing §8 trap 3: `arcTo` THROWS on a negative
   * radius, so the radius is clamped to the box and to zero, here, once.
   * @param {CanvasRenderingContext2D} ctx Target.
   * @param {number} x @param {number} y @param {number} w @param {number} h
   * @param {number} r Corner radius, clamped.
   */
  function roundRect(ctx, x, y, w, h, r) {
    var rr = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.beginPath();
    ctx.moveTo(x + rr, y);
    ctx.arcTo(x + w, y, x + w, y + h, rr);
    ctx.arcTo(x + w, y + h, x, y + h, rr);
    ctx.arcTo(x, y + h, x, y, rr);
    ctx.arcTo(x, y, x + w, y, rr);
    ctx.closePath();
  }

  /**
   * A canvas of the given size, in the engine or headless.
   * @param {number} w @param {number} h
   * @returns {HTMLCanvasElement} A canvas.
   */
  function canvas(w, h) {
    var c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w));
    c.height = Math.max(1, Math.round(h));
    return c;
  }

  return {
    PALETTE: PALETTE,
    MATERIALS: MATERIALS,
    STRUCTURE_MATERIAL: STRUCTURE_MATERIAL,
    LIGHT: LIGHT,
    FACES: FACES,
    DISPLAY_FAMILY: DISPLAY_FAMILY,
    BODY_FAMILY: BODY_FAMILY,
    rgb: rgb,
    hex: hex,
    mix: mix,
    luminance: luminance,
    contrast: contrast,
    inkFor: inkFor,
    channelDistance: channelDistance,
    separate: separate,
    rng: rng,
    noise1: noise1,
    noise2: noise2,
    field: field,
    shade: shade,
    ensureFonts: ensureFonts,
    fontState: fontState,
    wall: wall,
    peg: peg,
    cord: cord,
    placard: placard,
    roundRect: roundRect,
    canvas: canvas
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.VisageRender;
