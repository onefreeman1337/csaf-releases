extends Node2D
## Fogbank demo: walk the crypt and push the fog back. WASD / arrows walk · Tab / Shift+Tab (or Q / E) change the look ·
## M changes the memory mode · C switches between a lantern radius and a flashlight cone (aimed with the mouse) ·
## F reveals the whole map · R forgets everything · G marks the tile under the mouse explored (the grid-game call).
## Copyright (c) 2026 Core Systems Asset Factory.

const PixelLabel := preload("pixel_label.gd")

const MEMORY_NAMES := ["NONE (line of sight)", "DIM (remember)", "KEEP (stays clear)", "FADE (forgets)"]

var crypt: DemoCrypt
var walker: DemoWalker
var rv: FogRevealer
var bank: FogBank
var cam: Camera2D
var label: PixelLabel
var index := 0
var ids: Array[String] = []


func _ready() -> void:
	for p in FogbankCatalog.PRESETS:
		ids.append(p["id"])
	crypt = DemoCrypt.new()
	add_child(crypt)
	crypt.build()
	walker = DemoWalker.new()
	walker.crypt = crypt
	walker.controllable = true
	walker.position = Vector2(72, 280)
	add_child(walker)
	rv = FogRevealer.new()
	rv.radius = 104.0
	rv.near_radius = 22.0
	rv.position = Vector2(0, -6)
	walker.add_child(rv)
	bank = FogBank.new()
	bank.fog_rect = Rect2(Vector2.ZERO, crypt.map_size)
	bank.wall_layer = crypt.ground
	bank.look = FogbankCatalog.look(ids[0])
	add_child(bank)
	cam = Camera2D.new()
	cam.position = crypt.map_size * 0.5 + Vector2(0, -20)
	cam.zoom = Vector2(1.75, 1.75)
	add_child(cam)
	cam.make_current()
	var ui := CanvasLayer.new()
	ui.layer = 20
	add_child(ui)
	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.05, 0.08, 0.86)
	sb.border_color = Color(0.85, 0.7, 0.4)
	sb.border_width_bottom = 2
	sb.content_margin_left = 14
	sb.content_margin_right = 14
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	panel.add_theme_stylebox_override("panel", sb)
	panel.position = Vector2(16, 12)
	ui.add_child(panel)
	label = PixelLabel.new()
	label.add_theme_color_override("font_color", Color(0.96, 0.9, 0.78))
	label.add_theme_font_size_override("font_size", 15)
	panel.add_child(label)
	_show()


func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey) or not event.pressed or event.echo:
		return
	var k := (event as InputEventKey).physical_keycode
	if k == KEY_TAB or k == KEY_E:
		index = (index + (ids.size() - 1 if (event as InputEventKey).shift_pressed else 1)) % ids.size()
	elif k == KEY_Q:
		index = (index + ids.size() - 1) % ids.size()
	elif k == KEY_M:
		bank.memory = ((int(bank.memory) + 1) % 4) as FogBank.Memory
	elif k == KEY_C:
		rv.cone_degrees = 70.0 if rv.cone_degrees >= 359.5 else 360.0
		rv.radius = 170.0 if rv.cone_degrees < 359.5 else 104.0
		rv.auto_face = false
	elif k == KEY_F:
		bank.reveal_all()
	elif k == KEY_R:
		bank.reset()
	elif k == KEY_G:
		bank.reveal_tile(crypt.ground, crypt.ground.local_to_map(crypt.ground.get_local_mouse_position()))
	else:
		return
	bank.look = FogbankCatalog.look(ids[index])
	_show()


func _process(_delta: float) -> void:
	if rv != null and rv.cone_degrees < 359.5:
		rv.face(get_global_mouse_position() - rv.global_position)


func _show() -> void:
	var p: Dictionary = FogbankCatalog.PRESETS[index]
	label.text = "FOGBANK   %d / %d   %s   (%s)   memory: %s\nWASD walk   Tab / Q / E look   M memory   C cone   F reveal all   R reset   G reveal tile" % [index + 1, ids.size(), p["name"], p["family"], MEMORY_NAMES[int(bank.memory)]]
