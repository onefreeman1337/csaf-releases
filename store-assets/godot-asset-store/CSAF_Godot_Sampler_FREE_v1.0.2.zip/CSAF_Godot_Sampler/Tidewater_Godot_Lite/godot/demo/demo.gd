extends Node2D
## Tidewater demo: every preset in a small world of its own.
##   Left / Right   previous / next preset         1 2 3 4   top-down, side-on, falls, underwater
##   Click / Space  splash the side-on water       V         dive the camera through the surface and back
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const PixelLabel := preload("pixel_label.gd")

const FAMILY_TITLES := {"surface": "Top-down water", "side": "Side-on water", "fall": "Waterfalls and flows", "dive": "Underwater and light"}
const ORDER := ["surface", "side", "fall", "dive"]
const VIEW := Vector2(1280, 720)
const SURFACE_Y := 430.0

const THEMES := {
	"day": {},
	"sand": {"ground": Color(0.85, 0.77, 0.56), "ground2": Color(0.79, 0.69, 0.48), "beach": Color(0.94, 0.89, 0.72),
			"wet": Color(0.72, 0.63, 0.44), "tree": Color(0.18, 0.48, 0.24), "rock": Color(0.66, 0.6, 0.5)},
	"night": {"ground": Color(0.12, 0.2, 0.15), "ground2": Color(0.09, 0.16, 0.12), "beach": Color(0.3, 0.3, 0.32),
			"wet": Color(0.2, 0.2, 0.24), "tree": Color(0.05, 0.1, 0.08), "rock": Color(0.26, 0.28, 0.32),
			"sky_top": Color(0.03, 0.05, 0.12), "sky_low": Color(0.14, 0.2, 0.36), "hill": Color(0.08, 0.12, 0.2),
			"hill2": Color(0.05, 0.08, 0.12), "cloud": Color(0.6, 0.65, 0.8, 0.15)},
	"volcanic": {"ground": Color(0.16, 0.13, 0.12), "ground2": Color(0.23, 0.16, 0.14), "beach": Color(0.3, 0.23, 0.19),
			"wet": Color(0.12, 0.07, 0.05), "tree": Color(0.2, 0.12, 0.09), "rock": Color(0.33, 0.3, 0.3),
			"sky_top": Color(0.16, 0.05, 0.03), "sky_low": Color(0.63, 0.23, 0.09), "hill": Color(0.23, 0.1, 0.08),
			"hill2": Color(0.14, 0.06, 0.06), "cloud": Color(0.3, 0.2, 0.18, 0.55), "cliff": Color(0.18, 0.14, 0.13),
			"under_top": Color(0.23, 0.1, 0.06), "grass_edge": Color(0.25, 0.12, 0.08)},
	"sewer": {"ground": Color(0.29, 0.29, 0.31), "ground2": Color(0.24, 0.24, 0.26), "beach": Color(0.36, 0.36, 0.37),
			"wet": Color(0.22, 0.22, 0.24), "tree": Color(0.18, 0.23, 0.16), "rock": Color(0.4, 0.4, 0.42),
			"sky_top": Color(0.08, 0.09, 0.1), "sky_low": Color(0.23, 0.25, 0.27), "hill": Color(0.16, 0.17, 0.19),
			"hill2": Color(0.13, 0.14, 0.15), "cloud": Color(0, 0, 0, 0), "cliff": Color(0.27, 0.27, 0.29),
			"grass_edge": Color(0.2, 0.26, 0.18)},
	"snow": {"ground": Color(0.9, 0.93, 0.96), "ground2": Color(0.82, 0.86, 0.9), "beach": Color(0.96, 0.97, 0.98),
			"wet": Color(0.72, 0.78, 0.83), "tree": Color(0.16, 0.29, 0.24), "rock": Color(0.54, 0.59, 0.63),
			"sky_top": Color(0.54, 0.7, 0.83), "sky_low": Color(0.91, 0.95, 0.97), "hill": Color(0.78, 0.85, 0.89),
			"hill2": Color(0.9, 0.93, 0.96), "cliff": Color(0.5, 0.56, 0.62), "grass_edge": Color(0.95, 0.97, 1.0)},
	"marsh": {"ground": Color(0.23, 0.27, 0.15), "ground2": Color(0.18, 0.22, 0.12), "beach": Color(0.29, 0.29, 0.17),
			"wet": Color(0.16, 0.18, 0.1), "tree": Color(0.12, 0.16, 0.09), "sky_top": Color(0.23, 0.16, 0.29),
			"sky_low": Color(0.54, 0.42, 0.48), "hill": Color(0.23, 0.19, 0.27), "hill2": Color(0.16, 0.16, 0.19)},
	"toxic": {"ground": Color(0.29, 0.29, 0.23), "ground2": Color(0.23, 0.23, 0.18), "beach": Color(0.35, 0.35, 0.25),
			"wet": Color(0.18, 0.18, 0.13), "tree": Color(0.23, 0.23, 0.16), "sky_top": Color(0.1, 0.12, 0.08),
			"sky_low": Color(0.33, 0.38, 0.22), "hill": Color(0.2, 0.22, 0.16), "hill2": Color(0.14, 0.15, 0.11),
			"cloud": Color(0.6, 0.7, 0.4, 0.2), "cliff": Color(0.22, 0.22, 0.18)},
	"sunset": {"sky_top": Color(0.23, 0.1, 0.29), "sky_low": Color(0.94, 0.56, 0.35), "hill": Color(0.42, 0.23, 0.35),
			"hill2": Color(0.23, 0.13, 0.25), "tree": Color(0.16, 0.08, 0.19), "cloud": Color(1.0, 0.78, 0.63, 0.65)},
	"cave": {"sky_top": Color(0.02, 0.03, 0.04), "sky_low": Color(0.08, 0.12, 0.14), "hill": Color(0.05, 0.08, 0.09),
			"hill2": Color(0.04, 0.05, 0.06), "tree": Color(0.03, 0.04, 0.05), "cloud": Color(0, 0, 0, 0),
			"cliff": Color(0.12, 0.13, 0.15), "grass_edge": Color(0.1, 0.16, 0.16), "under_top": Color(0.1, 0.16, 0.18)},
	"dusk": {"sky_top": Color(0.1, 0.06, 0.19), "sky_low": Color(0.35, 0.23, 0.42), "hill": Color(0.2, 0.13, 0.26),
			"hill2": Color(0.12, 0.08, 0.16), "tree": Color(0.08, 0.05, 0.1), "cloud": Color(0.6, 0.45, 0.7, 0.3)},
	"magic": {"sky_top": Color(0.07, 0.05, 0.19), "sky_low": Color(0.29, 0.23, 0.54), "hill": Color(0.14, 0.12, 0.3),
			"hill2": Color(0.1, 0.08, 0.2), "tree": Color(0.06, 0.05, 0.14), "cloud": Color(0.7, 0.6, 1.0, 0.3),
			"cliff": Color(0.16, 0.14, 0.26), "grass_edge": Color(0.3, 0.25, 0.6)},
}

const PRESET_THEME := {
	"open_sea": "sand", "lagoon": "sand", "sewer": "sewer", "lava": "volcanic", "swamp": "marsh", "frozen_pond": "snow",
	"moonlit_bay": "night", "toxic_pool": "toxic", "hot_spring": "snow",
	"murky_canal": "sewer", "lava_flow": "volcanic", "acid_vat": "toxic", "cave_water": "cave", "mud_bog": "marsh",
	"arctic_water": "snow", "sunset_sea": "sunset", "poison_marsh": "dusk",
	"lavafall": "volcanic", "sewer_outflow": "sewer", "frozen_fall": "snow", "mana_fall": "magic", "drip_ledge": "cave",
	"slime_fall": "toxic",
}

const FALL_POOL := {"lavafall": "lava_flow", "sewer_outflow": "murky_canal", "frozen_fall": "arctic_water",
		"slime_fall": "acid_vat", "mana_fall": "cave_water", "pixel_fall": "pixel_water", "drip_ledge": "cave_water"}
const FALL_SIZE := {"thin_cascade": Vector2(200, 450), "drip_ledge": Vector2(420, 450),
		"fountain_jet": Vector2(380, 360), "rapids_chute": Vector2(200, 450), "mist_veil": Vector2(260, 450),
		"sewer_outflow": Vector2(230, 430)}

var family := "surface"
var index := 0
var current: Node2D
var pool: TidewaterSide
var dive_layer: TidewaterLayer
var _diving := false

@onready var backdrop = $Backdrop
@onready var world: Node2D = $World
@onready var cam: Camera2D = $Camera
@onready var title: PixelLabel = $UI/Title
@onready var hint: PixelLabel = $UI/Hint


func _ready() -> void:
	show_preset("surface", 0)


func ids() -> Array[String]:
	return TidewaterCatalog.ids_for_family(family)


## The lake outline used by the top-down page: wide, with a bay and a point.
func lake_shape() -> PackedVector2Array:
	var out := PackedVector2Array()
	var n := 40
	for i in n:
		var a := TAU * float(i) / float(n)
		var r := 1.0 + 0.12 * sin(3.0 * a + 0.4) + 0.07 * sin(5.0 * a + 2.0) + 0.04 * sin(8.0 * a + 1.0)
		out.append(Vector2(640, 380) + Vector2(cos(a) * 430.0, sin(a) * 215.0) * r)
	return out


func show_preset(p_family: String, p_index: int) -> void:
	family = p_family
	var list := ids()
	index = wrapi(p_index, 0, list.size())
	var id: String = list[index]
	for c in world.get_children():
		c.queue_free()
	current = null
	pool = null
	dive_layer = null
	_diving = false
	cam.position = VIEW * 0.5
	var th: Dictionary = THEMES.get(PRESET_THEME.get(id, "day"), {})
	var node := TidewaterCatalog.instantiate(id)
	match family:
		"surface":
			var body := node as TidewaterBody
			body.position = Vector2.ZERO
			body.polygon = lake_shape()
			body.depth = 120.0
			backdrop.setup("surface", th, body.polygon, SURFACE_Y)
		"side":
			var side := node as TidewaterSide
			side.position = Vector2(640, SURFACE_Y)
			side.size = Vector2(1400, 900)
			backdrop.setup("side", th, PackedVector2Array(), SURFACE_Y)
		"fall":
			var fall := node as TidewaterFall
			var sz: Vector2 = FALL_SIZE.get(id, Vector2(150, 450))
			fall.size = sz
			fall.position = Vector2(640, 600 - sz.y * 0.5)
			backdrop.setup("fall", th, PackedVector2Array(), 600.0)
			var pool_id: String = FALL_POOL.get(id, "clear_pool")
			if TidewaterCatalog.path_of(pool_id) == "":
				pool_id = "clear_pool"
			if TidewaterCatalog.path_of(pool_id) != "":
				pool = TidewaterCatalog.instantiate(pool_id) as TidewaterSide
				pool.position = Vector2(640, 600)
				pool.size = Vector2(1400, 200)
				pool.preview_splash = false
				world.add_child(pool)
		"dive":
			backdrop.setup("dive", THEMES["day"], PackedVector2Array(), SURFACE_Y)
	world.add_child(node)
	current = node
	title.text = "%s  -  %s   (%d / %d)" % [FAMILY_TITLES[family], _pretty(id), index + 1, list.size()]
	hint.text = "Left / Right: preset    1-4: family    Click / Space: splash    V: dive" if family == "side" else "Left / Right: preset    1-4: family"


func _pretty(id: String) -> String:
	for p in TidewaterCatalog.PRESETS:
		if p["id"] == id:
			return p["name"]
	return id


func _unhandled_input(event: InputEvent) -> void:
	var key := event as InputEventKey
	if key and key.pressed and not key.echo:
		match key.keycode:
			KEY_RIGHT, KEY_D:
				show_preset(family, index + 1)
			KEY_LEFT, KEY_A:
				show_preset(family, index - 1)
			KEY_1:
				show_preset("surface", 0)
			KEY_2:
				show_preset("side", 0)
			KEY_3:
				show_preset("fall", 0)
			KEY_4:
				show_preset("dive", 0)
			KEY_SPACE:
				if current is TidewaterSide:
					(current as TidewaterSide).splash(640.0, 1.5)
			KEY_V:
				toggle_dive()
	elif event is InputEventMouseButton and (event as InputEventMouseButton).pressed and current is TidewaterSide:
		(current as TidewaterSide).splash(get_global_mouse_position().x, 1.5)


## Side-on page only: sends the camera down through the surface with a Deep Dive filter that follows the waterline.
func toggle_dive() -> void:
	if family != "side":
		return
	if dive_layer == null:
		if TidewaterCatalog.path_of("deep_dive") == "":
			return
		dive_layer = TidewaterCatalog.instantiate("deep_dive") as TidewaterLayer
		dive_layer.surface = current
		dive_layer.blend_px = 120.0
		world.add_child(dive_layer)
	_diving = not _diving
	var tw := create_tween()
	tw.tween_property(cam, "position:y", 760.0 if _diving else VIEW.y * 0.5, 1.6).set_trans(Tween.TRANS_SINE)


## Capture hook (store plates, tests): show a preset frozen `seconds` into its animation.
func page(p_family: String, p_index: int, seconds := 2.0) -> void:
	show_preset(p_family, p_index)
	freeze(seconds)


func freeze(seconds: float) -> void:
	backdrop.freeze_at(seconds)
	if current and current.has_method("seek"):
		if current is TidewaterSide:
			(current as TidewaterSide).seek_preview()
		current.call("seek", seconds)
	if pool:
		pool.seek(seconds)


func set_ui_visible(v: bool) -> void:
	$UI.visible = v
