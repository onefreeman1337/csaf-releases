extends Node2D
## Jigsaw for Godot 4 - demo: every style, playable. Run this scene (F5 / F6).
##   Q / E or the arrows in the bar ... previous / next style      R ... a new cut      W ... next picture
##   S ... solve now      T ... rotation on / off      PgUp (hold) ... the box lid      Esc ... set the puzzle aside
## The board below the bar is an ordinary JigsawBoard; read jigsaw_board.gd for the API.
## Copyright (c) 2026 Core Systems Asset Factory. Terms of use: LICENSE.txt.

const PixelLabel := preload("pixel_label.gd")

const BAR := 46.0
const PICTURES := ["harbour", "night_market", "autumn_shrine", "pixel_valley"]

var styles: Array[JigsawStyle] = []
var style_index := 0
var picture_index := 0
var rotation_on := false
var board: JigsawBoard
var last := ""
var _buttons := {}


func _ready() -> void:
	var dir := "res://addons/jigsaw/styles"
	var names: Array[String] = []
	for f in DirAccess.get_files_at(dir):
		var n := f.trim_suffix(".remap")
		if n.ends_with(".tres") and not names.has(n):
			names.append(n)
	names.sort()
	if names.has("parlour.tres"):
		names.erase("parlour.tres")
		names.push_front("parlour.tres")
	for n in names:
		var s: Variant = load(dir.path_join(n))
		if s is JigsawStyle:
			styles.append(s)
	get_viewport().size_changed.connect(_restart)
	_restart()


func _restart() -> void:
	if board:
		board.queue_free()
	board = JigsawBoard.new()
	board.fit_viewport = false
	var vs := get_viewport_rect().size
	board.board_size = Vector2(vs.x, vs.y - BAR)
	board.position = Vector2(0, BAR)
	board.picture = load("res://addons/jigsaw/pictures/%s.jpg" % PICTURES[picture_index])
	board.style = styles[style_index] if styles.size() > 0 else null
	board.pieces = 48
	board.rotation_enabled = rotation_on
	board.finished.connect(_on_finished)
	add_child(board)
	queue_redraw()


func _on_finished(result: Dictionary) -> void:
	if result.get("solved", false):
		var sec := int(result.seconds)
		last = "Solved: %d pieces in %d:%02d, %d moves, %d peeks" % [result.pieces, floori(sec / 60.0), sec % 60, result.moves, result.peeks]
	else:
		last = "Set aside with %d of %d placed" % [result.placed, result.pieces]
	_restart()


func _step_style(d: int) -> void:
	if styles.is_empty():
		return
	style_index = posmod(style_index + d, styles.size())
	last = ""
	_restart()


func _input(event: InputEvent) -> void:
	var k := event as InputEventKey
	if k and k.pressed and not k.echo:
		match k.keycode:
			KEY_Q:
				_step_style(-1)
			KEY_E:
				_step_style(1)
			KEY_R:
				last = ""
				_restart()
			KEY_W:
				picture_index = (picture_index + 1) % PICTURES.size()
				_restart()
			KEY_S:
				board.solve_now()
			KEY_T:
				rotation_on = not rotation_on
				_restart()
	var mb := event as InputEventMouseButton
	if mb and mb.pressed and mb.button_index == MOUSE_BUTTON_LEFT and mb.position.y < BAR:
		for id in _buttons:
			if (_buttons[id] as Rect2).has_point(mb.position):
				match id:
					"prev":
						_step_style(-1)
					"next":
						_step_style(1)
					"cut":
						last = ""
						_restart()
					"picture":
						picture_index = (picture_index + 1) % PICTURES.size()
						_restart()
					"solve":
						board.solve_now()
		get_viewport().set_input_as_handled()


func _draw() -> void:
	var w := get_viewport_rect().size.x
	var s: JigsawStyle = styles[style_index] if styles.size() > 0 else null
	var ink := s.plaque_ink if s else Color(0.95, 0.9, 0.8)
	var bg := s.plaque_color if s else Color(0.12, 0.1, 0.08)
	draw_rect(Rect2(0, 0, w, BAR), Color(bg, 1.0).darkened(0.25))
	draw_rect(Rect2(0, BAR - 2, w, 2), Color(ink, 0.35))
	var title := "%s   %d / %d" % [s.display_name if s else "-", style_index + 1, styles.size()]
	var sub := ""
	if s:
		sub = "%s cut, %s sides, %s pieces, %s table" % [JigsawCut.TILING_NAMES[s.tiling], JigsawCut.EDGE_NAMES[s.edge],
			JigsawStyle.FINISH_NAMES[s.finish], JigsawStyle.TABLE_NAMES[s.table]]
	PixelLabel.put(self, Vector2(70, 21), title, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, ink)
	PixelLabel.put(self, Vector2(70, 38), last if last != "" else sub, HORIZONTAL_ALIGNMENT_LEFT, -1, 7, Color(ink, 0.85))
	_buttons.clear()
	_button("prev", Rect2(10, 8, 24, 30), "<", ink)
	_button("next", Rect2(38, 8, 24, 30), ">", ink)
	var x := w - 10.0
	for b in [["solve", "Solve (S)"], ["picture", "Picture (W)"], ["cut", "New cut (R)"]]:
		var bw := PixelLabel.width_of(b[1], PixelLabel.unit_of(13)) + 20.0
		x -= bw
		_button(b[0], Rect2(x, 9, bw, 28), b[1], ink)
		x -= 8.0
	PixelLabel.put(self, Vector2(x - 360, 28), "Q/E style  T rotation %s  PgUp box lid  Esc set aside" % ("on" if rotation_on else "off"),
		HORIZONTAL_ALIGNMENT_LEFT, -1, 7, Color(ink, 0.8))


func _button(id: String, r: Rect2, text: String, ink: Color) -> void:
	_buttons[id] = r
	draw_rect(r, Color(ink, 0.12))
	draw_rect(r, Color(ink, 0.45), false, 1.0)
	var tw := PixelLabel.width_of(text, PixelLabel.unit_of(13))
	PixelLabel.put(self, Vector2(r.position.x + (r.size.x - tw) * 0.5, r.position.y + r.size.y * 0.5 + 5), text, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, ink)
