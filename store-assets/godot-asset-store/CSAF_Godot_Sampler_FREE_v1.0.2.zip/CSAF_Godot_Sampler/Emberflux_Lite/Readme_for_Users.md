# Emberflux Lite - 12 free 2D combat VFX for Godot 4

A free, MIT-licensed sampler of Emberflux: 12 real presets from the full pack, in two elements (Fire and Frost) across
six effect families (Impact, Slash, Nova, Shockwave, Orb, Aura). Every effect is a shader computed at runtime; there are
no frame sheets. Recolour any preset by swapping its palette resource.

- **Godot version:** built and tested on **Godot 4.7.2**, under **both renderers: Forward+ and Compatibility**. Older
  4.x versions were NOT run.
- **Presets:** `fire_impact`, `fire_slash`, `fire_nova`, `fire_shockwave`, `fire_orb`, `fire_aura`, `frost_impact`,
  `frost_slash`, `frost_nova`, `frost_shockwave`, `frost_orb`, `frost_aura`.

## Install

Copy `godot/addons/emberflux/` into your project's `addons/` folder. No plugin to enable. Instance a scene from
`res://addons/emberflux/presets/<element>/`, or in code:

```gdscript
var fx := EmberfluxCatalog.instantiate("fire_impact")
fx.position = where
fx.free_when_finished = true
add_child(fx)
```

Each preset's root is an `EmberfluxEffect` with exported `palette`, `duration`, `looping`, `autoplay`, `speed_scale`,
`effect_scale`, `intensity`, `additive` and `free_when_finished`. Open `godot/` as a project and press Play for the demo.

## The full pack

**Emberflux - 120 2D Combat VFX for Godot 4** adds four more element shape grammars (Storm, Venom, Void, Radiant) and
fourteen more families (heavy impact, cross slash, flurry, thrust, eruption, scatter, dissolve, missile, beam, shield,
charge, status marks, ground sigils, vortex): 120 presets, the same API.
https://csaf.itch.io/emberflux

## Changes

- **1.0.2:** `frost_impact`, `frost_nova` and `frost_shockwave` drew wrong under Forward+ (they had lost their ice spikes)
  and now match Compatibility. The only addon file that changed is `shaders/ef_common.gdshaderinc`.
- **1.0.1:** the demo's lettering. The addon did not change.

## Licence

MIT (see `LICENSE.txt`). This lite is AI-generated: the shaders, scenes and scripts were written by an AI.

Core Systems Asset Factory
