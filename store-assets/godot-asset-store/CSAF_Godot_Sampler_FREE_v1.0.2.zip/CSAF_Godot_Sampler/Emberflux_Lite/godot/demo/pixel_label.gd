extends Control
## The demo's lettering: a 5x7 face with descenders, drawn as squares, so the demo is not in the engine's fallback font.
## It reads a Label's usual settings (text, font size, colours, outline, shadow), and only the demo uses it.
## No font file ships. Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const ADVANCE := 6
const LINE := 10
const MARGIN := 16.0

const G := {
	"A": [14, 17, 17, 31, 17, 17, 17], "B": [30, 17, 17, 30, 17, 17, 30], "C": [14, 17, 16, 16, 16, 17, 14],
	"D": [30, 17, 17, 17, 17, 17, 30], "E": [31, 16, 16, 30, 16, 16, 31], "F": [31, 16, 16, 30, 16, 16, 16],
	"G": [14, 17, 16, 23, 17, 17, 15], "H": [17, 17, 17, 31, 17, 17, 17], "I": [14, 4, 4, 4, 4, 4, 14],
	"J": [7, 2, 2, 2, 2, 18, 12], "K": [17, 18, 20, 24, 20, 18, 17], "L": [16, 16, 16, 16, 16, 16, 31],
	"M": [17, 27, 21, 21, 17, 17, 17], "N": [17, 25, 21, 19, 17, 17, 17], "O": [14, 17, 17, 17, 17, 17, 14],
	"P": [30, 17, 17, 30, 16, 16, 16], "Q": [14, 17, 17, 17, 21, 18, 13], "R": [30, 17, 17, 30, 20, 18, 17],
	"S": [15, 16, 16, 14, 1, 1, 30], "T": [31, 4, 4, 4, 4, 4, 4], "U": [17, 17, 17, 17, 17, 17, 14],
	"V": [17, 17, 17, 17, 17, 10, 4], "W": [17, 17, 17, 21, 21, 27, 17], "X": [17, 17, 10, 4, 10, 17, 17],
	"Y": [17, 17, 10, 4, 4, 4, 4], "Z": [31, 1, 2, 4, 8, 16, 31],
	"a": [0, 0, 14, 1, 15, 17, 15], "b": [16, 16, 22, 25, 17, 17, 30], "c": [0, 0, 14, 16, 16, 17, 14],
	"d": [1, 1, 13, 19, 17, 17, 15], "e": [0, 0, 14, 17, 31, 16, 14], "f": [6, 9, 8, 28, 8, 8, 8],
	"g": [0, 0, 15, 17, 17, 17, 15, 1, 14], "h": [16, 16, 22, 25, 17, 17, 17], "i": [4, 0, 12, 4, 4, 4, 14],
	"j": [2, 0, 6, 2, 2, 2, 2, 18, 12], "k": [16, 16, 18, 20, 24, 20, 18], "l": [12, 4, 4, 4, 4, 4, 14],
	"m": [0, 0, 26, 21, 21, 17, 17], "n": [0, 0, 22, 25, 17, 17, 17], "o": [0, 0, 14, 17, 17, 17, 14],
	"p": [0, 0, 30, 17, 17, 17, 30, 16, 16], "q": [0, 0, 15, 17, 17, 17, 15, 1, 1], "r": [0, 0, 22, 25, 16, 16, 16],
	"s": [0, 0, 14, 16, 14, 1, 30], "t": [8, 8, 28, 8, 8, 9, 6], "u": [0, 0, 17, 17, 17, 19, 13],
	"v": [0, 0, 17, 17, 17, 10, 4], "w": [0, 0, 17, 17, 21, 21, 10], "x": [0, 0, 17, 10, 4, 10, 17],
	"y": [0, 0, 17, 17, 17, 17, 15, 1, 14], "z": [0, 0, 31, 2, 4, 8, 31],
	"0": [14, 17, 19, 21, 25, 17, 14], "1": [4, 12, 4, 4, 4, 4, 14], "2": [14, 17, 1, 2, 4, 8, 31],
	"3": [31, 2, 4, 2, 1, 17, 14], "4": [2, 6, 10, 18, 31, 2, 2], "5": [31, 16, 30, 1, 1, 17, 14],
	"6": [6, 8, 16, 30, 17, 17, 14], "7": [31, 1, 2, 4, 8, 8, 8], "8": [14, 17, 17, 14, 17, 17, 14],
	"9": [14, 17, 17, 15, 1, 2, 12],
	".": [0, 0, 0, 0, 0, 12, 12], ",": [0, 0, 0, 0, 12, 4, 8], ":": [0, 12, 12, 0, 12, 12, 0],
	";": [0, 12, 12, 0, 12, 4, 8], "-": [0, 0, 0, 31, 0, 0, 0], "_": [0, 0, 0, 0, 0, 0, 31],
	"/": [1, 1, 2, 4, 8, 16, 16], "\\": [16, 16, 8, 4, 2, 1, 1], "(": [2, 4, 8, 8, 8, 4, 2], ")": [8, 4, 2, 2, 2, 4, 8],
	"[": [14, 8, 8, 8, 8, 8, 14], "]": [14, 2, 2, 2, 2, 2, 14], "{": [2, 4, 4, 8, 4, 4, 2], "}": [8, 4, 4, 2, 4, 4, 8],
	"<": [2, 4, 8, 16, 8, 4, 2], ">": [8, 4, 2, 1, 2, 4, 8], "=": [0, 0, 31, 0, 31, 0, 0], "+": [0, 4, 4, 31, 4, 4, 0],
	"*": [0, 4, 21, 14, 21, 4, 0], "!": [4, 4, 4, 4, 4, 0, 4], "?": [14, 17, 1, 2, 4, 0, 4], "'": [12, 4, 8, 0, 0, 0, 0],
	"\"": [10, 10, 10, 0, 0, 0, 0], "#": [10, 10, 31, 10, 31, 10, 10], "%": [24, 25, 2, 4, 8, 19, 3], "&": [12, 18, 20, 8, 21, 18, 13],
	"|": [4, 4, 4, 4, 4, 4, 4], "^": [4, 10, 17, 0, 0, 0, 0], "~": [0, 0, 8, 21, 2, 0, 0], "@": [14, 17, 1, 13, 21, 21, 14],
	"$": [4, 15, 20, 14, 5, 30, 4], "·": [0, 0, 0, 12, 12, 0, 0], "×": [0, 17, 10, 4, 10, 17, 0], "°": [6, 9, 9, 6, 0, 0, 0],
}
## A character the face does not hold prints as an empty box, so a gap in the face shows when the page is looked at.
const NONE := [31, 17, 17, 17, 17, 17, 31]

## What the label says. A new line starts a new row, and a row too long for the window wraps at a space.
@export var text := "":
	set(value):
		if value == text:
			return
		text = value
		_refresh()
## Wrap inside this many pixels, for a label in a panel. 0 wraps at the window's edge.
@export var max_width := 0.0:
	set(value):
		max_width = value
		_refresh()


func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _notification(what: int) -> void:
	if what == NOTIFICATION_THEME_CHANGED or what == NOTIFICATION_ENTER_TREE:
		_refresh()


func _get_minimum_size() -> Vector2:
	var unit := unit_of(_font_px())
	var rows := _rows(unit)
	var widest := 0
	for row in rows:
		widest = maxi(widest, width_of(row, unit))
	return Vector2(widest, rows.size() * LINE * unit - unit if not rows.is_empty() else 0)


func _draw() -> void:
	var unit := unit_of(_font_px())
	var rows := _rows(unit)
	var outline := _const(&"outline_size")
	var shadow := _col(&"font_shadow_color")
	var edge := _col(&"font_outline_color")
	var main := _col(&"font_color")
	var off := Vector2(_const(&"shadow_offset_x"), _const(&"shadow_offset_y"))
	for i in rows.size():
		var at := Vector2(0, i * LINE * unit)
		if shadow.a > 0.0:
			paint(self, at + off, rows[i], unit, shadow, 0)
		if outline > 0:
			paint(self, at, rows[i], unit, edge, maxi(1, outline / 2))
	for i in rows.size():
		paint(self, Vector2(0, i * LINE * unit), rows[i], unit, main, 0)


## Stands where draw_string stood: `pos` is the baseline, `width` and `align` as draw_string takes them.
static func put(on: CanvasItem, pos: Vector2, line: String, align: int, width: float, font_px: int, col: Color) -> void:
	var unit := unit_of(font_px)
	var x := pos.x
	if width > 0.0:
		if align == HORIZONTAL_ALIGNMENT_CENTER:
			x += (width - width_of(line, unit)) * 0.5
		elif align == HORIZONTAL_ALIGNMENT_RIGHT:
			x += width - width_of(line, unit)
	paint(on, Vector2(x, pos.y - 7 * unit), line, unit, col, 0)


## One square of the face, in screen pixels, for a font size: rounded to a whole number so every stroke stays even.
static func unit_of(font_px: int) -> int:
	return maxi(1, roundi(font_px / 7.0))


static func width_of(line: String, unit: int) -> int:
	return line.length() * ADVANCE * unit - unit if not line.is_empty() else 0


## Each run of lit squares in a row is one rectangle, so a page of labels stays a few thousand rectangles.
static func paint(on: CanvasItem, pos: Vector2, line: String, unit: int, col: Color, grow: int) -> void:
	var x := floorf(pos.x)
	var y := floorf(pos.y)
	for ch in line:
		if ch != " ":
			var rows: Array = G.get(ch, NONE)
			for r in rows.size():
				var bits: int = rows[r]
				var b := 0
				while b < 5:
					if bits & (16 >> b):
						var run := 1
						while b + run < 5 and bits & (16 >> (b + run)):
							run += 1
						on.draw_rect(Rect2(x + b * unit - grow, y + r * unit - grow, run * unit + grow * 2, unit + grow * 2), col)
						b += run
					else:
						b += 1
		x += ADVANCE * unit


func _refresh() -> void:
	update_minimum_size()
	queue_redraw()


func _font_px() -> int:
	return get_theme_font_size(&"font_size") if has_theme_font_size_override(&"font_size") else get_theme_font_size(&"font_size", &"Label")


func _col(key: StringName) -> Color:
	return get_theme_color(key) if has_theme_color_override(key) else get_theme_color(key, &"Label")


func _const(key: StringName) -> int:
	return get_theme_constant(key) if has_theme_constant_override(key) else get_theme_constant(key, &"Label")


func _rows(unit: int) -> PackedStringArray:
	var room := 100000.0
	if max_width > 0.0:
		room = max_width
	elif is_inside_tree():
		room = maxf(get_viewport_rect().size.x - global_position.x - MARGIN, 40.0)
	var fit := maxi(1, int((room + unit) / (ADVANCE * unit)))
	var out := PackedStringArray()
	for raw in text.split("\n"):
		var line: String = raw
		while line.length() > fit:
			var cut := line.rfind(" ", fit)
			if cut <= 0:
				cut = fit
			out.append(line.substr(0, cut).strip_edges(false, true))
			line = line.substr(cut).strip_edges(true, false)
		out.append(line)
	return out
