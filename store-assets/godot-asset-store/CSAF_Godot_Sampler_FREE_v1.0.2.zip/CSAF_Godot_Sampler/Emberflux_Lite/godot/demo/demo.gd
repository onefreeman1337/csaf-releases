extends Node2D
## Emberflux demo browser. Run demo/demo.tscn (it is the project's main scene).
##
##   Left / Right   previous / next page
##   Tab            switch view: one FAMILY in both elements, or one ELEMENT in all six families
##   Up / Down      previous / next element (element view)
##   P              cycle the palette (every preset recolours from one palette resource)
##   H              hold every preset on its showcase frame (compare them side by side); H again to play
##   Space          replay everything
##   Click          cast the preset under the mouse at the mouse
##   F12            save a screenshot to user://
## Copyright (c) 2026 Core Systems Asset Factory. See LICENSE.txt.

const PixelLabel := preload("pixel_label.gd")

const PALETTE_DIR := "res://addons/emberflux/palettes/"
const PALETTES: Array[String] = ["", "blood", "shadow", "emerald", "sunset", "ghost", "azure_flame",
	"fire", "frost", "storm", "venom", "void", "radiant"]
const TOP := 96.0
const BOTTOM := 56.0
const MARGIN := 24.0

var _family_view := true
var _page := 0
var _element := 0
var _palette := 0
var _hold := false
var _cells: Array[Dictionary] = []
var _title := ""
var _sub := ""
var _hints: Array[String] = []
var _labels: Array[Dictionary] = []
var _ui: CanvasLayer
var _text: Control


func _ready() -> void:
	_ui = CanvasLayer.new()
	add_child(_ui)
	_text = Control.new()
	_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_text.set_anchors_preset(Control.PRESET_FULL_RECT)
	_text.draw.connect(_draw_text)
	_ui.add_child(_text)
	_rebuild()
	get_viewport().size_changed.connect(_rebuild)


func _draw_text() -> void:
	var view := get_viewport_rect().size
	_put(Vector2(MARGIN, 14), _title, 4, Color(1.0, 0.93, 0.8))
	_put(Vector2(MARGIN, 58), _sub, 2, Color(0.7, 0.74, 0.82))
	for i in _hints.size():
		_put(Vector2(MARGIN, view.y - 46 + i * 20), _hints[i], 2, Color(0.55, 0.58, 0.66))
	for l in _labels:
		_put(l["at"], l["text"], 2, Color(0.78, 0.8, 0.88))


func _put(at: Vector2, line: String, size: int, colour: Color) -> void:
	PixelLabel.paint(_text, at + Vector2(0, size), line, size, Color(0, 0, 0, 0.6), 0)
	PixelLabel.paint(_text, at, line, size, colour, 0)


func _ids() -> Array[String]:
	if _family_view:
		return EmberfluxCatalog.ids_for_family(EmberfluxCatalog.FAMILIES[_page])
	return EmberfluxCatalog.ids_for_element(EmberfluxCatalog.ELEMENTS[_element])


func _grid() -> Vector2i:
	return Vector2i(2, 1) if _family_view else Vector2i(3, 2)


func _rebuild() -> void:
	for c in _cells:
		(c["fx"] as Node).queue_free()
	_cells.clear()
	_labels.clear()
	var view := get_viewport_rect().size
	var g := _grid()
	var cw := (view.x - MARGIN * 2.0) / g.x
	var ch := (view.y - TOP - BOTTOM) / g.y
	var ids := _ids()
	for i in ids.size():
		var cell := Rect2(MARGIN + (i % g.x) * cw, TOP + (i / g.x) * ch, cw, ch)
		var fx := EmberfluxCatalog.instantiate(ids[i])
		if fx == null:
			continue
		_fit(fx, cell)
		add_child(fx)
		_apply_palette(fx)
		if _hold:
			fx.seek_preview()
		_cells.append({"fx": fx, "rect": cell, "id": ids[i], "wait": 0.08 * (i % 4)})
		# A whole id fits a family page's wide cell; on an element page the sub line names the prefix and the cell names the rest.
		var label: String = ids[i] if _family_view else ids[i].trim_prefix(EmberfluxCatalog.ELEMENTS[_element] + "_")
		_labels.append({"at": cell.position + Vector2(12, cell.size.y - 28), "text": label})
	if _family_view:
		var fam: String = EmberfluxCatalog.FAMILIES[_page]
		_title = "Emberflux · %s" % fam.capitalize()
		_sub = "one family in both elements  ·  page %d of %d" % [_page + 1, EmberfluxCatalog.FAMILIES.size()]
	else:
		var el: String = EmberfluxCatalog.ELEMENTS[_element]
		_title = "Emberflux · %s" % el.capitalize()
		_sub = "every family in one element  ·  %d presets  ·  each id starts %s_" % [ids.size(), el]
	_hints = [
		"Left/Right page   Tab view   Up/Down element   P palette (%s)" % _palette_name(),
		"H hold%s   Space replay   Click cast   F12 screenshot" % (" (on)" if _hold else ""),
	]
	queue_redraw()
	_text.queue_redraw()


func _fit(fx: EmberfluxEffect, cell: Rect2) -> void:
	var layer := fx.get_node_or_null("Layer") as Control
	var size := Vector2(200, 200)
	var centre := Vector2.ZERO
	if layer:
		size = layer.size
		centre = layer.position + layer.size / 2.0
	var s := minf((cell.size.x - 16.0) / size.x, (cell.size.y - 40.0) / size.y)
	s = minf(s, 1.6)
	fx.effect_scale = s
	fx.position = cell.get_center() + Vector2(0, -12) - centre * s


func _palette_name() -> String:
	return "element" if PALETTES[_palette] == "" else PALETTES[_palette]


func _apply_palette(fx: EmberfluxEffect) -> void:
	if PALETTES[_palette] == "":
		return
	var p := load(PALETTE_DIR + PALETTES[_palette] + ".tres") as EmberfluxPalette
	if p:
		fx.palette = p


func _process(delta: float) -> void:
	if _hold:
		return
	for c in _cells:
		var fx := c["fx"] as EmberfluxEffect
		if fx.looping or fx.is_playing():
			continue
		c["wait"] = float(c["wait"]) - delta
		if float(c["wait"]) <= 0.0:
			fx.play()
			c["wait"] = 0.2


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var k := (event as InputEventKey).keycode
		match k:
			KEY_RIGHT:
				_turn(1)
			KEY_LEFT:
				_turn(-1)
			KEY_UP:
				_element = posmod(_element - 1, EmberfluxCatalog.ELEMENTS.size())
				_family_view = false
				_rebuild()
			KEY_DOWN:
				_element = posmod(_element + 1, EmberfluxCatalog.ELEMENTS.size())
				_family_view = false
				_rebuild()
			KEY_TAB:
				_family_view = not _family_view
				_rebuild()
			KEY_P:
				_palette = (_palette + 1) % PALETTES.size()
				_rebuild()
			KEY_H:
				_hold = not _hold
				_rebuild()
			KEY_SPACE:
				_hold = false
				for c in _cells:
					(c["fx"] as EmberfluxEffect).play()
			KEY_F12:
				_screenshot()
	elif event is InputEventMouseButton and event.pressed and (event as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
		_cast((event as InputEventMouseButton).position)


func _turn(step: int) -> void:
	if _family_view:
		_page = posmod(_page + step, EmberfluxCatalog.FAMILIES.size())
	else:
		_element = posmod(_element + step, EmberfluxCatalog.ELEMENTS.size())
	_rebuild()


func _cast(at: Vector2) -> void:
	for c in _cells:
		if (c["rect"] as Rect2).has_point(at):
			var fx := EmberfluxCatalog.instantiate(c["id"])
			fx.position = at
			fx.free_when_finished = not fx.looping
			add_child(fx)
			_apply_palette(fx)
			if fx.looping:
				get_tree().create_timer(2.0).timeout.connect(fx.queue_free)
			return


func _screenshot() -> void:
	var img := get_viewport().get_texture().get_image()
	var f := "user://emberflux_%s.png" % Time.get_datetime_string_from_system().replace(":", "-")
	img.save_png(f)
	print("Emberflux: saved ", ProjectSettings.globalize_path(f))


func _draw() -> void:
	var view := get_viewport_rect().size
	var bands := 24
	for i in bands:
		var t := float(i) / bands
		var c := Color(0.075, 0.08, 0.11).lerp(Color(0.03, 0.03, 0.045), t)
		draw_rect(Rect2(0, view.y * t, view.x, view.y / bands + 1.0), c)
	draw_line(Vector2(MARGIN, TOP - 10), Vector2(view.x - MARGIN, TOP - 10), Color(1.0, 0.6, 0.25, 0.35), 2.0)
	for c in _cells:
		var r: Rect2 = c["rect"]
		var inner := r.grow(-6.0)
		draw_rect(inner, Color(1, 1, 1, 0.025), true)
		draw_rect(inner, Color(1, 1, 1, 0.07), false, 1.0)
