AETHERBOUND VOL. I - FREE PREVIEW
Core Systems Asset Factory

Three of the fourteen tracks, complete and unmodified, with their editable MIDI sources.

  The Sunken Choir
    title · D aeolian · 66 BPM · 2:11
    loops seamlessly: LOOPSTART 320727, LOOPLENGTH 5452364

  Nine Hundred Names
    catacomb · A phrygian · 60 BPM · 2:24
    loops seamlessly: LOOPSTART 352800, LOOPLENGTH 5997600

  The Gnawing
    battle · E phrygian · 156 BPM · 0:52
    loops seamlessly: LOOPSTART 135692, LOOPLENGTH 2171077

  The Sunken Choir Sings
    boss · D harmonicMinor · 144 BPM · 1:00
    loops seamlessly: LOOPSTART 147000, LOOPLENGTH 2499000

WHY THESE THREE
---------------
The title states the album's main theme plainly. The town theme is the track a player hears most
in any RPG, so it is the one that has to be hummable. And the boss theme is the battle theme
transformed - augmented, re-harmonised, moved a major third from home - which is the claim the
full album is actually selling, and the only one you can check by ear.

These are the real files, not clips. The OGGs carry the same sample-accurate LOOPSTART and
LOOPLENGTH tags RPG Maker MV and MZ read. Drop one into audio/bgm/ and it will loop correctly.

THE LICENCE ON THESE THREE
--------------------------
Free to evaluate. If you want to ship them in a game, buy the pack - the full licence is in
LICENSE.txt there, and it is royalty-free with no per-title fee and no attribution requirement.

The full album is 14 tracks covering title, town, field, forest, cave, dungeon, battle, boss,
sacred, inn, three stingers and an ambient bed, in one musical voice built from one family of
eight themes.

  https://csaf.itch.io/aetherbound-vol-1
