/* GENERATED from art/parts.json by Internal_Ops/make_loadable.js — do not edit.
 * sourceSha256 eabacc248c0bd652a9970095ad590ce9275685840dfdaba65ae9466e55959f08
 * WHY: the paid build is a zip a buyer opens from file://, where fetch() is blocked. Loading
 * this as a <script> makes the http demo and the local download the same program. */
window.AUGUR_PARTS = {
  "sprite": {
    "w": 32,
    "h": 32
  },
  "layout": {
    "crest": {
      "x": 12,
      "y": 6
    },
    "engine": {
      "x": 12,
      "y": 2
    },
    "hull": {
      "y": 8
    },
    "wingLeft": {
      "x": 1,
      "y": 10
    },
    "wingRight": {
      "x": 23,
      "y": 10,
      "mirror": true
    },
    "mountY": 17,
    "noseMount": {
      "x": 12,
      "y": 22
    }
  },
  "cell": 16,
  "factions": {
    "meadow": {
      "sheet": "parts_meadow.png",
      "w": 256,
      "h": 80,
      "cellW": 16,
      "cellH": 16,
      "index": {
        "HULLS/wedge": {
          "x": 1,
          "y": 0,
          "w": 14,
          "h": 14
        },
        "HULLS/barrel": {
          "x": 17,
          "y": 0,
          "w": 14,
          "h": 14
        },
        "HULLS/delta": {
          "x": 32,
          "y": 0,
          "w": 16,
          "h": 12
        },
        "HULLS/spindle": {
          "x": 52,
          "y": 0,
          "w": 8,
          "h": 16
        },
        "HULLS/crescent": {
          "x": 65,
          "y": 0,
          "w": 14,
          "h": 14
        },
        "HULLS/bastion": {
          "x": 79,
          "y": 0,
          "w": 18,
          "h": 14
        },
        "WINGS/swept": {
          "x": 4,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/broad": {
          "x": 20,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/forked": {
          "x": 36,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/finned": {
          "x": 52,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/ribbed": {
          "x": 68,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/stub": {
          "x": 84,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "PODS/slot_a": {
          "x": 4,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/slot_b": {
          "x": 20,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/slot_c": {
          "x": 36,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/slot_d": {
          "x": 52,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/barrel_a": {
          "x": 68,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/barrel_b": {
          "x": 84,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/barrel_c": {
          "x": 100,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/barrel_d": {
          "x": 116,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/fan_a": {
          "x": 132,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/fan_b": {
          "x": 148,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/fan_c": {
          "x": 164,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/fan_d": {
          "x": 180,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/drum_a": {
          "x": 196,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/drum_b": {
          "x": 212,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/drum_c": {
          "x": 228,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/drum_d": {
          "x": 244,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "ENGINES/twin": {
          "x": 4,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/block": {
          "x": 20,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/spike": {
          "x": 36,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/triple": {
          "x": 52,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/wide": {
          "x": 68,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/none": {
          "x": 84,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "CRESTS/none": {
          "x": 4,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/nub": {
          "x": 20,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/horns": {
          "x": 36,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/comb": {
          "x": 52,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/crown": {
          "x": 68,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/banner": {
          "x": 84,
          "y": 64,
          "w": 8,
          "h": 3
        }
      }
    },
    "harbour": {
      "sheet": "parts_harbour.png",
      "w": 256,
      "h": 80,
      "cellW": 16,
      "cellH": 16,
      "index": {
        "HULLS/wedge": {
          "x": 1,
          "y": 0,
          "w": 14,
          "h": 14
        },
        "HULLS/barrel": {
          "x": 17,
          "y": 0,
          "w": 14,
          "h": 14
        },
        "HULLS/delta": {
          "x": 32,
          "y": 0,
          "w": 16,
          "h": 12
        },
        "HULLS/spindle": {
          "x": 52,
          "y": 0,
          "w": 8,
          "h": 16
        },
        "HULLS/crescent": {
          "x": 65,
          "y": 0,
          "w": 14,
          "h": 14
        },
        "HULLS/bastion": {
          "x": 79,
          "y": 0,
          "w": 18,
          "h": 14
        },
        "WINGS/swept": {
          "x": 4,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/broad": {
          "x": 20,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/forked": {
          "x": 36,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/finned": {
          "x": 52,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/ribbed": {
          "x": 68,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/stub": {
          "x": 84,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "PODS/slot_a": {
          "x": 4,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/slot_b": {
          "x": 20,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/slot_c": {
          "x": 36,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/slot_d": {
          "x": 52,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/barrel_a": {
          "x": 68,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/barrel_b": {
          "x": 84,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/barrel_c": {
          "x": 100,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/barrel_d": {
          "x": 116,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/fan_a": {
          "x": 132,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/fan_b": {
          "x": 148,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/fan_c": {
          "x": 164,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/fan_d": {
          "x": 180,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/drum_a": {
          "x": 196,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/drum_b": {
          "x": 212,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/drum_c": {
          "x": 228,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/drum_d": {
          "x": 244,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "ENGINES/twin": {
          "x": 4,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/block": {
          "x": 20,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/spike": {
          "x": 36,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/triple": {
          "x": 52,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/wide": {
          "x": 68,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/none": {
          "x": 84,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "CRESTS/none": {
          "x": 4,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/nub": {
          "x": 20,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/horns": {
          "x": 36,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/comb": {
          "x": 52,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/crown": {
          "x": 68,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/banner": {
          "x": 84,
          "y": 64,
          "w": 8,
          "h": 3
        }
      }
    },
    "scarp": {
      "sheet": "parts_scarp.png",
      "w": 256,
      "h": 80,
      "cellW": 16,
      "cellH": 16,
      "index": {
        "HULLS/wedge": {
          "x": 1,
          "y": 0,
          "w": 14,
          "h": 14
        },
        "HULLS/barrel": {
          "x": 17,
          "y": 0,
          "w": 14,
          "h": 14
        },
        "HULLS/delta": {
          "x": 32,
          "y": 0,
          "w": 16,
          "h": 12
        },
        "HULLS/spindle": {
          "x": 52,
          "y": 0,
          "w": 8,
          "h": 16
        },
        "HULLS/crescent": {
          "x": 65,
          "y": 0,
          "w": 14,
          "h": 14
        },
        "HULLS/bastion": {
          "x": 79,
          "y": 0,
          "w": 18,
          "h": 14
        },
        "WINGS/swept": {
          "x": 4,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/broad": {
          "x": 20,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/forked": {
          "x": 36,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/finned": {
          "x": 52,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/ribbed": {
          "x": 68,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "WINGS/stub": {
          "x": 84,
          "y": 16,
          "w": 8,
          "h": 12
        },
        "PODS/slot_a": {
          "x": 4,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/slot_b": {
          "x": 20,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/slot_c": {
          "x": 36,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/slot_d": {
          "x": 52,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/barrel_a": {
          "x": 68,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/barrel_b": {
          "x": 84,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/barrel_c": {
          "x": 100,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/barrel_d": {
          "x": 116,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/fan_a": {
          "x": 132,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/fan_b": {
          "x": 148,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/fan_c": {
          "x": 164,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/fan_d": {
          "x": 180,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/drum_a": {
          "x": 196,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/drum_b": {
          "x": 212,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/drum_c": {
          "x": 228,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "PODS/drum_d": {
          "x": 244,
          "y": 32,
          "w": 8,
          "h": 8
        },
        "ENGINES/twin": {
          "x": 4,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/block": {
          "x": 20,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/spike": {
          "x": 36,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/triple": {
          "x": 52,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/wide": {
          "x": 68,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "ENGINES/none": {
          "x": 84,
          "y": 48,
          "w": 8,
          "h": 5
        },
        "CRESTS/none": {
          "x": 4,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/nub": {
          "x": 20,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/horns": {
          "x": 36,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/comb": {
          "x": 52,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/crown": {
          "x": 68,
          "y": 64,
          "w": 8,
          "h": 3
        },
        "CRESTS/banner": {
          "x": 84,
          "y": 64,
          "w": 8,
          "h": 3
        }
      }
    }
  },
  "motifs": 40,
  "podClass": {
    "slot_a": "beam",
    "slot_b": "beam",
    "slot_c": "beam",
    "slot_d": "beam",
    "barrel_a": "aimed",
    "barrel_b": "aimed",
    "barrel_c": "aimed",
    "barrel_d": "aimed",
    "fan_a": "spread",
    "fan_b": "spread",
    "fan_c": "spread",
    "fan_d": "spread",
    "drum_a": "mine",
    "drum_b": "mine",
    "drum_c": "mine",
    "drum_d": "mine"
  },
  "podsByClass": {
    "beam": [
      "slot_a",
      "slot_b",
      "slot_c",
      "slot_d"
    ],
    "aimed": [
      "barrel_a",
      "barrel_b",
      "barrel_c",
      "barrel_d"
    ],
    "spread": [
      "fan_a",
      "fan_b",
      "fan_c",
      "fan_d"
    ],
    "mine": [
      "drum_a",
      "drum_b",
      "drum_c",
      "drum_d"
    ]
  },
  "engineNames": [
    "twin",
    "block",
    "spike",
    "triple",
    "wide",
    "none"
  ],
  "hulls": {
    "wedge": {
      "move": "dive",
      "mounts": 2,
      "bulk": 1,
      "geometry": {
        "hx": 9,
        "hy": 8,
        "hw": 14,
        "hh": 14,
        "mounts": [
          {
            "x": 4,
            "y": 17
          },
          {
            "x": 20,
            "y": 17
          },
          {
            "x": 12,
            "y": 22
          }
        ]
      }
    },
    "barrel": {
      "move": "hover",
      "mounts": 3,
      "bulk": 2,
      "geometry": {
        "hx": 9,
        "hy": 8,
        "hw": 14,
        "hh": 14,
        "mounts": [
          {
            "x": 4,
            "y": 17
          },
          {
            "x": 20,
            "y": 17
          },
          {
            "x": 12,
            "y": 22
          }
        ]
      }
    },
    "delta": {
      "move": "strafe",
      "mounts": 3,
      "bulk": 2,
      "geometry": {
        "hx": 8,
        "hy": 8,
        "hw": 16,
        "hh": 12,
        "mounts": [
          {
            "x": 3,
            "y": 17
          },
          {
            "x": 21,
            "y": 17
          },
          {
            "x": 12,
            "y": 22
          }
        ]
      }
    },
    "spindle": {
      "move": "dive",
      "mounts": 1,
      "bulk": 1,
      "geometry": {
        "hx": 12,
        "hy": 8,
        "hw": 8,
        "hh": 16,
        "mounts": [
          {
            "x": 7,
            "y": 17
          },
          {
            "x": 17,
            "y": 17
          },
          {
            "x": 12,
            "y": 22
          }
        ]
      }
    },
    "crescent": {
      "move": "strafe",
      "mounts": 2,
      "bulk": 2,
      "geometry": {
        "hx": 9,
        "hy": 8,
        "hw": 14,
        "hh": 14,
        "mounts": [
          {
            "x": 4,
            "y": 17
          },
          {
            "x": 20,
            "y": 17
          },
          {
            "x": 12,
            "y": 22
          }
        ]
      }
    },
    "bastion": {
      "move": "hover",
      "mounts": 3,
      "bulk": 3,
      "geometry": {
        "hx": 7,
        "hy": 8,
        "hw": 18,
        "hh": 14,
        "mounts": [
          {
            "x": 2,
            "y": 17
          },
          {
            "x": 22,
            "y": 17
          },
          {
            "x": 12,
            "y": 22
          }
        ]
      }
    }
  },
  "wings": {
    "swept": {
      "speed": 1.35
    },
    "broad": {
      "speed": 0.75
    },
    "forked": {
      "speed": 1
    },
    "finned": {
      "speed": 1.15
    },
    "ribbed": {
      "speed": 0.9
    },
    "stub": {
      "speed": 1.2
    }
  },
  "crests": {
    "none": {
      "rank": 0
    },
    "nub": {
      "rank": 1
    },
    "horns": {
      "rank": 2
    },
    "comb": {
      "rank": 3
    },
    "crown": {
      "rank": 4
    },
    "banner": {
      "rank": 5
    }
  }
};
