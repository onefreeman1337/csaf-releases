/* GENERATED from art/tiles/tiles.json by Internal_Ops/make_loadable.js — do not edit.
 * sourceSha256 2b5e6122727200dbb3f9c7583e23aeda6da06d9d385f49c1790574422720f8f3
 * WHY: the paid build is a zip a buyer opens from file://, where fetch() is blocked. Loading
 * this as a <script> makes the http demo and the local download the same program. */
window.AUGUR_TILES = {
  "cell": 16,
  "coordUnits": "pixels-on-sheet",
  "note": "Every id is <packId>/<tileId>. The loader cannot express an unqualified id — see stage_art.js.",
  "packs": [
    "verdant01",
    "verdant10",
    "verdant12"
  ],
  "tiles": [
    {
      "id": "verdant01/grass_1",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 0,
      "y": 0,
      "role": "terrain-fill",
      "material": "grass"
    },
    {
      "id": "verdant01/grass_2",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 16,
      "y": 0,
      "role": "terrain-fill",
      "material": "grass"
    },
    {
      "id": "verdant01/grass_3",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 32,
      "y": 0,
      "role": "terrain-fill",
      "material": "grass"
    },
    {
      "id": "verdant01/grass_4",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 48,
      "y": 0,
      "role": "terrain-fill",
      "material": "grass"
    },
    {
      "id": "verdant01/dirt_1",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 64,
      "y": 0,
      "role": "terrain-fill",
      "material": "dirt"
    },
    {
      "id": "verdant01/dirt_2",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 80,
      "y": 0,
      "role": "terrain-fill",
      "material": "dirt"
    },
    {
      "id": "verdant01/dirt_3",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 96,
      "y": 0,
      "role": "terrain-fill",
      "material": "dirt"
    },
    {
      "id": "verdant01/dirt_4",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 112,
      "y": 0,
      "role": "terrain-fill",
      "material": "dirt"
    },
    {
      "id": "verdant01/sand_1",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 128,
      "y": 0,
      "role": "terrain-fill",
      "material": "sand"
    },
    {
      "id": "verdant01/sand_2",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 144,
      "y": 0,
      "role": "terrain-fill",
      "material": "sand"
    },
    {
      "id": "verdant01/sand_3",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 160,
      "y": 0,
      "role": "terrain-fill",
      "material": "sand"
    },
    {
      "id": "verdant01/sand_4",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 176,
      "y": 0,
      "role": "terrain-fill",
      "material": "sand"
    },
    {
      "id": "verdant01/stone_1",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 0,
      "y": 16,
      "role": "terrain-fill",
      "material": "stone"
    },
    {
      "id": "verdant01/stone_2",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 16,
      "y": 16,
      "role": "terrain-fill",
      "material": "stone"
    },
    {
      "id": "verdant01/stone_3",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 32,
      "y": 16,
      "role": "terrain-fill",
      "material": "stone"
    },
    {
      "id": "verdant01/stone_4",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 48,
      "y": 16,
      "role": "terrain-fill",
      "material": "stone"
    },
    {
      "id": "verdant01/water_1",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 64,
      "y": 16,
      "role": "terrain-fill",
      "material": "water"
    },
    {
      "id": "verdant01/water_2",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 80,
      "y": 16,
      "role": "terrain-fill",
      "material": "water"
    },
    {
      "id": "verdant01/water_3",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 96,
      "y": 16,
      "role": "terrain-fill",
      "material": "water"
    },
    {
      "id": "verdant01/water_4",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 112,
      "y": 16,
      "role": "terrain-fill",
      "material": "water"
    },
    {
      "id": "verdant01/grass_bloom_red",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 128,
      "y": 16,
      "role": "terrain-fill",
      "material": "grass"
    },
    {
      "id": "verdant01/grass_bloom_gold",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 144,
      "y": 16,
      "role": "terrain-fill",
      "material": "grass"
    },
    {
      "id": "verdant01/grass_bloom_violet",
      "pack": "verdant01",
      "sheet": "verdant01/terrain.png",
      "x": 160,
      "y": 16,
      "role": "terrain-fill",
      "material": "grass"
    },
    {
      "id": "verdant01/tree_1",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 0,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/tree_2",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 32,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/tree_3",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 64,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/bush_1",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 96,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/bush_2",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 128,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/bush_3",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 160,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/rock_1",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 192,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/rock_2",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 224,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/rock_3",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 256,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/stump",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 288,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/log",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 320,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/flowers_red_1",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 352,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/flowers_red_2",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 0,
      "y": 32,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/flowers_gold_1",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 32,
      "y": 32,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/flowers_gold_2",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 64,
      "y": 32,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/flowers_violet_1",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 96,
      "y": 32,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/flowers_violet_2",
      "pack": "verdant01",
      "sheet": "verdant01/props.png",
      "x": 128,
      "y": 32,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/tree_1_grounded",
      "pack": "verdant01",
      "sheet": "verdant01/props_grounded.png",
      "x": 0,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/tree_2_grounded",
      "pack": "verdant01",
      "sheet": "verdant01/props_grounded.png",
      "x": 32,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/tree_3_grounded",
      "pack": "verdant01",
      "sheet": "verdant01/props_grounded.png",
      "x": 64,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/bush_1_grounded",
      "pack": "verdant01",
      "sheet": "verdant01/props_grounded.png",
      "x": 96,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/bush_2_grounded",
      "pack": "verdant01",
      "sheet": "verdant01/props_grounded.png",
      "x": 128,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/bush_3_grounded",
      "pack": "verdant01",
      "sheet": "verdant01/props_grounded.png",
      "x": 160,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/rock_1_grounded",
      "pack": "verdant01",
      "sheet": "verdant01/props_grounded.png",
      "x": 192,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/rock_2_grounded",
      "pack": "verdant01",
      "sheet": "verdant01/props_grounded.png",
      "x": 224,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/rock_3_grounded",
      "pack": "verdant01",
      "sheet": "verdant01/props_grounded.png",
      "x": 256,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/stump_grounded",
      "pack": "verdant01",
      "sheet": "verdant01/props_grounded.png",
      "x": 288,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant01/log_grounded",
      "pack": "verdant01",
      "sheet": "verdant01/props_grounded.png",
      "x": 320,
      "y": 0,
      "role": "prop",
      "material": null
    },
    {
      "id": "verdant10/basin_1",
      "pack": "verdant10",
      "sheet": "verdant10/water.png",
      "x": 0,
      "y": 0,
      "role": "terrain-fill",
      "material": "brine"
    },
    {
      "id": "verdant10/basin_2",
      "pack": "verdant10",
      "sheet": "verdant10/water.png",
      "x": 16,
      "y": 0,
      "role": "terrain-fill",
      "material": "brine"
    },
    {
      "id": "verdant10/basin_3",
      "pack": "verdant10",
      "sheet": "verdant10/water.png",
      "x": 32,
      "y": 0,
      "role": "terrain-fill",
      "material": "brine"
    },
    {
      "id": "verdant10/basin_4",
      "pack": "verdant10",
      "sheet": "verdant10/water.png",
      "x": 48,
      "y": 0,
      "role": "terrain-fill",
      "material": "brine"
    },
    {
      "id": "verdant10/sett_1",
      "pack": "verdant10",
      "sheet": "verdant10/quay.png",
      "x": 0,
      "y": 0,
      "role": "terrain-fill",
      "material": "sett"
    },
    {
      "id": "verdant10/sett_2",
      "pack": "verdant10",
      "sheet": "verdant10/quay.png",
      "x": 16,
      "y": 0,
      "role": "terrain-fill",
      "material": "sett"
    },
    {
      "id": "verdant10/sett_3",
      "pack": "verdant10",
      "sheet": "verdant10/quay.png",
      "x": 32,
      "y": 0,
      "role": "terrain-fill",
      "material": "sett"
    },
    {
      "id": "verdant10/sett_4",
      "pack": "verdant10",
      "sheet": "verdant10/quay.png",
      "x": 48,
      "y": 0,
      "role": "terrain-fill",
      "material": "sett"
    },
    {
      "id": "verdant10/wharf_1",
      "pack": "verdant10",
      "sheet": "verdant10/quay.png",
      "x": 64,
      "y": 0,
      "role": "terrain-fill",
      "material": "plank"
    },
    {
      "id": "verdant10/wharf_2",
      "pack": "verdant10",
      "sheet": "verdant10/quay.png",
      "x": 80,
      "y": 0,
      "role": "terrain-fill",
      "material": "plank"
    },
    {
      "id": "verdant10/wharf_3",
      "pack": "verdant10",
      "sheet": "verdant10/quay.png",
      "x": 96,
      "y": 0,
      "role": "terrain-fill",
      "material": "plank"
    },
    {
      "id": "verdant10/wharf_4",
      "pack": "verdant10",
      "sheet": "verdant10/quay.png",
      "x": 112,
      "y": 0,
      "role": "terrain-fill",
      "material": "plank"
    },
    {
      "id": "verdant10/ashlar_1",
      "pack": "verdant10",
      "sheet": "verdant10/walls.png",
      "x": 0,
      "y": 0,
      "role": "terrain-fill",
      "material": "mason"
    },
    {
      "id": "verdant10/ashlar_2",
      "pack": "verdant10",
      "sheet": "verdant10/walls.png",
      "x": 16,
      "y": 0,
      "role": "terrain-fill",
      "material": "mason"
    },
    {
      "id": "verdant10/ashlar_3",
      "pack": "verdant10",
      "sheet": "verdant10/walls.png",
      "x": 32,
      "y": 0,
      "role": "terrain-fill",
      "material": "mason"
    },
    {
      "id": "verdant10/ashlar_4",
      "pack": "verdant10",
      "sheet": "verdant10/walls.png",
      "x": 48,
      "y": 0,
      "role": "terrain-fill",
      "material": "mason"
    },
    {
      "id": "verdant10/board_1",
      "pack": "verdant10",
      "sheet": "verdant10/walls.png",
      "x": 64,
      "y": 0,
      "role": "terrain-fill",
      "material": "drift"
    },
    {
      "id": "verdant10/board_2",
      "pack": "verdant10",
      "sheet": "verdant10/walls.png",
      "x": 80,
      "y": 0,
      "role": "terrain-fill",
      "material": "drift"
    },
    {
      "id": "verdant10/board_3",
      "pack": "verdant10",
      "sheet": "verdant10/walls.png",
      "x": 96,
      "y": 0,
      "role": "terrain-fill",
      "material": "drift"
    },
    {
      "id": "verdant10/board_4",
      "pack": "verdant10",
      "sheet": "verdant10/walls.png",
      "x": 112,
      "y": 0,
      "role": "terrain-fill",
      "material": "drift"
    },
    {
      "id": "verdant10/slate_1",
      "pack": "verdant10",
      "sheet": "verdant10/roofs.png",
      "x": 0,
      "y": 0,
      "role": "terrain-fill",
      "material": "flag"
    },
    {
      "id": "verdant10/slate_2",
      "pack": "verdant10",
      "sheet": "verdant10/roofs.png",
      "x": 16,
      "y": 0,
      "role": "terrain-fill",
      "material": "flag"
    },
    {
      "id": "verdant10/slate_3",
      "pack": "verdant10",
      "sheet": "verdant10/roofs.png",
      "x": 32,
      "y": 0,
      "role": "terrain-fill",
      "material": "flag"
    },
    {
      "id": "verdant10/slate_4",
      "pack": "verdant10",
      "sheet": "verdant10/roofs.png",
      "x": 48,
      "y": 0,
      "role": "terrain-fill",
      "material": "flag"
    },
    {
      "id": "verdant10/pantile_1",
      "pack": "verdant10",
      "sheet": "verdant10/roofs.png",
      "x": 64,
      "y": 0,
      "role": "terrain-fill",
      "material": "wood"
    },
    {
      "id": "verdant10/pantile_2",
      "pack": "verdant10",
      "sheet": "verdant10/roofs.png",
      "x": 80,
      "y": 0,
      "role": "terrain-fill",
      "material": "wood"
    },
    {
      "id": "verdant10/pantile_3",
      "pack": "verdant10",
      "sheet": "verdant10/roofs.png",
      "x": 96,
      "y": 0,
      "role": "terrain-fill",
      "material": "wood"
    },
    {
      "id": "verdant10/pantile_4",
      "pack": "verdant10",
      "sheet": "verdant10/roofs.png",
      "x": 112,
      "y": 0,
      "role": "terrain-fill",
      "material": "wood"
    },
    {
      "id": "verdant10/bollard",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 0,
      "y": 0,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/bollard_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 32,
      "y": 0,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/bollard_roped",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 64,
      "y": 0,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/bollard_roped_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 96,
      "y": 0,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/cleat",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 128,
      "y": 0,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/cleat_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 160,
      "y": 0,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/mooring_ring",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 192,
      "y": 0,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/mooring_ring_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 224,
      "y": 0,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/capstan",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 256,
      "y": 0,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/capstan_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 288,
      "y": 0,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/harbour_bell",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 320,
      "y": 0,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/harbour_bell_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 352,
      "y": 0,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/signboard",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 0,
      "y": 48,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/signboard_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 32,
      "y": 48,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/derrick",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 64,
      "y": 48,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/derrick_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 96,
      "y": 48,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/handcart",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 128,
      "y": 48,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/handcart_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 160,
      "y": 48,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/water_butt",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 192,
      "y": 48,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/water_butt_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 224,
      "y": 48,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/pile",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 256,
      "y": 48,
      "role": "prop",
      "material": "basin"
    },
    {
      "id": "verdant10/pile_on_basin",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 288,
      "y": 48,
      "role": "prop",
      "material": "basin"
    },
    {
      "id": "verdant10/pile_cluster",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 320,
      "y": 48,
      "role": "prop",
      "material": "basin"
    },
    {
      "id": "verdant10/pile_cluster_on_basin",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 352,
      "y": 48,
      "role": "prop",
      "material": "basin"
    },
    {
      "id": "verdant10/crate",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 0,
      "y": 96,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/crate_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 32,
      "y": 96,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/crate_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 64,
      "y": 96,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/crate_stack",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 96,
      "y": 96,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/crate_stack_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 128,
      "y": 96,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/crate_stack_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 160,
      "y": 96,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/barrel",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 192,
      "y": 96,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/barrel_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 224,
      "y": 96,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/barrel_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 256,
      "y": 96,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/tar_barrel",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 288,
      "y": 96,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/tar_barrel_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 320,
      "y": 96,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/tar_barrel_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 352,
      "y": 96,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/sack",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 0,
      "y": 144,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/sack_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 32,
      "y": 144,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/sack_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 64,
      "y": 144,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/sack_pile",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 96,
      "y": 144,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/sack_pile_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 128,
      "y": 144,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/sack_pile_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 160,
      "y": 144,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/rope_coil",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 192,
      "y": 144,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/rope_coil_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 224,
      "y": 144,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/rope_coil_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 256,
      "y": 144,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/net_pile",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 288,
      "y": 144,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/net_pile_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 320,
      "y": 144,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/net_pile_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 352,
      "y": 144,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/lobster_pot",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 0,
      "y": 192,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/lobster_pot_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 32,
      "y": 192,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/lobster_pot_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 64,
      "y": 192,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/anchor",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 96,
      "y": 192,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/anchor_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 128,
      "y": 192,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/anchor_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 160,
      "y": 192,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/chain",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 192,
      "y": 192,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/chain_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 224,
      "y": 192,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/chain_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 256,
      "y": 192,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/fish_crate",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 288,
      "y": 192,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/fish_crate_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 320,
      "y": 192,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/fish_crate_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 352,
      "y": 192,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/pallet",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 0,
      "y": 240,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/pallet_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 32,
      "y": 240,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/pallet_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 64,
      "y": 240,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/tarp_bundle",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 96,
      "y": 240,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/tarp_bundle_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 128,
      "y": 240,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/tarp_bundle_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 160,
      "y": 240,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/oar_stack",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 192,
      "y": 240,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/oar_stack_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 224,
      "y": 240,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/oar_stack_on_sett",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 256,
      "y": 240,
      "role": "prop",
      "material": "sett"
    },
    {
      "id": "verdant10/gangplank",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 288,
      "y": 240,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant10/gangplank_on_wharf",
      "pack": "verdant10",
      "sheet": "verdant10/props.png",
      "x": 320,
      "y": 240,
      "role": "prop",
      "material": "wharf"
    },
    {
      "id": "verdant12/meadow_1",
      "pack": "verdant12",
      "sheet": "verdant12/grounds.png",
      "x": 0,
      "y": 0,
      "role": "terrain-fill",
      "material": "meadow"
    },
    {
      "id": "verdant12/meadow_2",
      "pack": "verdant12",
      "sheet": "verdant12/grounds.png",
      "x": 16,
      "y": 0,
      "role": "terrain-fill",
      "material": "meadow"
    },
    {
      "id": "verdant12/meadow_3",
      "pack": "verdant12",
      "sheet": "verdant12/grounds.png",
      "x": 32,
      "y": 0,
      "role": "terrain-fill",
      "material": "meadow"
    },
    {
      "id": "verdant12/meadow_4",
      "pack": "verdant12",
      "sheet": "verdant12/grounds.png",
      "x": 48,
      "y": 0,
      "role": "terrain-fill",
      "material": "meadow"
    },
    {
      "id": "verdant12/upland_1",
      "pack": "verdant12",
      "sheet": "verdant12/grounds.png",
      "x": 64,
      "y": 0,
      "role": "terrain-fill",
      "material": "upland"
    },
    {
      "id": "verdant12/upland_2",
      "pack": "verdant12",
      "sheet": "verdant12/grounds.png",
      "x": 80,
      "y": 0,
      "role": "terrain-fill",
      "material": "upland"
    },
    {
      "id": "verdant12/upland_3",
      "pack": "verdant12",
      "sheet": "verdant12/grounds.png",
      "x": 96,
      "y": 0,
      "role": "terrain-fill",
      "material": "upland"
    },
    {
      "id": "verdant12/upland_4",
      "pack": "verdant12",
      "sheet": "verdant12/grounds.png",
      "x": 112,
      "y": 0,
      "role": "terrain-fill",
      "material": "upland"
    },
    {
      "id": "verdant12/face_1",
      "pack": "verdant12",
      "sheet": "verdant12/rock.png",
      "x": 0,
      "y": 0,
      "role": "terrain-fill",
      "material": "face"
    },
    {
      "id": "verdant12/face_2",
      "pack": "verdant12",
      "sheet": "verdant12/rock.png",
      "x": 16,
      "y": 0,
      "role": "terrain-fill",
      "material": "face"
    },
    {
      "id": "verdant12/face_3",
      "pack": "verdant12",
      "sheet": "verdant12/rock.png",
      "x": 32,
      "y": 0,
      "role": "terrain-fill",
      "material": "face"
    },
    {
      "id": "verdant12/face_4",
      "pack": "verdant12",
      "sheet": "verdant12/rock.png",
      "x": 48,
      "y": 0,
      "role": "terrain-fill",
      "material": "face"
    },
    {
      "id": "verdant12/talus_1",
      "pack": "verdant12",
      "sheet": "verdant12/rock.png",
      "x": 64,
      "y": 0,
      "role": "terrain-fill",
      "material": "talus"
    },
    {
      "id": "verdant12/talus_2",
      "pack": "verdant12",
      "sheet": "verdant12/rock.png",
      "x": 80,
      "y": 0,
      "role": "terrain-fill",
      "material": "talus"
    },
    {
      "id": "verdant12/talus_3",
      "pack": "verdant12",
      "sheet": "verdant12/rock.png",
      "x": 96,
      "y": 0,
      "role": "terrain-fill",
      "material": "talus"
    },
    {
      "id": "verdant12/talus_4",
      "pack": "verdant12",
      "sheet": "verdant12/rock.png",
      "x": 112,
      "y": 0,
      "role": "terrain-fill",
      "material": "talus"
    },
    {
      "id": "verdant12/track_1",
      "pack": "verdant12",
      "sheet": "verdant12/ways.png",
      "x": 0,
      "y": 0,
      "role": "terrain-fill",
      "material": "track"
    },
    {
      "id": "verdant12/track_2",
      "pack": "verdant12",
      "sheet": "verdant12/ways.png",
      "x": 16,
      "y": 0,
      "role": "terrain-fill",
      "material": "track"
    },
    {
      "id": "verdant12/track_3",
      "pack": "verdant12",
      "sheet": "verdant12/ways.png",
      "x": 32,
      "y": 0,
      "role": "terrain-fill",
      "material": "track"
    },
    {
      "id": "verdant12/track_4",
      "pack": "verdant12",
      "sheet": "verdant12/ways.png",
      "x": 48,
      "y": 0,
      "role": "terrain-fill",
      "material": "track"
    },
    {
      "id": "verdant12/bracken_1",
      "pack": "verdant12",
      "sheet": "verdant12/ways.png",
      "x": 64,
      "y": 0,
      "role": "terrain-fill",
      "material": "bracken"
    },
    {
      "id": "verdant12/bracken_2",
      "pack": "verdant12",
      "sheet": "verdant12/ways.png",
      "x": 80,
      "y": 0,
      "role": "terrain-fill",
      "material": "bracken"
    },
    {
      "id": "verdant12/bracken_3",
      "pack": "verdant12",
      "sheet": "verdant12/ways.png",
      "x": 96,
      "y": 0,
      "role": "terrain-fill",
      "material": "bracken"
    },
    {
      "id": "verdant12/bracken_4",
      "pack": "verdant12",
      "sheet": "verdant12/ways.png",
      "x": 112,
      "y": 0,
      "role": "terrain-fill",
      "material": "bracken"
    },
    {
      "id": "verdant12/boulder",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 0,
      "y": 0,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/boulder_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 16,
      "y": 0,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/boulder_on_upland",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 32,
      "y": 0,
      "role": "prop",
      "material": "upland"
    },
    {
      "id": "verdant12/boulder_on_talus",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 48,
      "y": 0,
      "role": "prop",
      "material": "talus"
    },
    {
      "id": "verdant12/stones",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 64,
      "y": 0,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/stones_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 80,
      "y": 0,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/stones_on_upland",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 96,
      "y": 0,
      "role": "prop",
      "material": "upland"
    },
    {
      "id": "verdant12/stones_on_track",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 112,
      "y": 0,
      "role": "prop",
      "material": "track"
    },
    {
      "id": "verdant12/cairn",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 128,
      "y": 0,
      "role": "prop",
      "material": "upland"
    },
    {
      "id": "verdant12/cairn_on_upland",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 144,
      "y": 0,
      "role": "prop",
      "material": "upland"
    },
    {
      "id": "verdant12/cairn_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 160,
      "y": 0,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/cairn_on_talus",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 176,
      "y": 0,
      "role": "prop",
      "material": "talus"
    },
    {
      "id": "verdant12/standing_stone",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 0,
      "y": 16,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/standing_stone_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 16,
      "y": 16,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/standing_stone_on_upland",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 32,
      "y": 16,
      "role": "prop",
      "material": "upland"
    },
    {
      "id": "verdant12/milestone",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 48,
      "y": 16,
      "role": "prop",
      "material": "track"
    },
    {
      "id": "verdant12/milestone_on_track",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 64,
      "y": 16,
      "role": "prop",
      "material": "track"
    },
    {
      "id": "verdant12/milestone_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 80,
      "y": 16,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/rowan",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 96,
      "y": 16,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/rowan_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 128,
      "y": 16,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/rowan_on_upland",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 160,
      "y": 16,
      "role": "prop",
      "material": "upland"
    },
    {
      "id": "verdant12/thorn",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 48,
      "y": 32,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/thorn_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 64,
      "y": 32,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/thorn_on_upland",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 80,
      "y": 32,
      "role": "prop",
      "material": "upland"
    },
    {
      "id": "verdant12/thorn_on_bracken",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 0,
      "y": 48,
      "role": "prop",
      "material": "bracken"
    },
    {
      "id": "verdant12/gorse",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 16,
      "y": 48,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/gorse_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 32,
      "y": 48,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/gorse_on_upland",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 48,
      "y": 48,
      "role": "prop",
      "material": "upland"
    },
    {
      "id": "verdant12/gorse_on_talus",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 64,
      "y": 48,
      "role": "prop",
      "material": "talus"
    },
    {
      "id": "verdant12/bracken_clump",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 80,
      "y": 48,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/bracken_clump_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 96,
      "y": 48,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/bracken_clump_on_upland",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 112,
      "y": 48,
      "role": "prop",
      "material": "upland"
    },
    {
      "id": "verdant12/bracken_clump_on_talus",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 128,
      "y": 48,
      "role": "prop",
      "material": "talus"
    },
    {
      "id": "verdant12/thistle",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 144,
      "y": 48,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/thistle_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 160,
      "y": 48,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/thistle_on_upland",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 176,
      "y": 48,
      "role": "prop",
      "material": "upland"
    },
    {
      "id": "verdant12/thistle_on_track",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 0,
      "y": 64,
      "role": "prop",
      "material": "track"
    },
    {
      "id": "verdant12/stump",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 16,
      "y": 64,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/stump_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 32,
      "y": 64,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/stump_on_bracken",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 48,
      "y": 64,
      "role": "prop",
      "material": "bracken"
    },
    {
      "id": "verdant12/stump_on_track",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 64,
      "y": 64,
      "role": "prop",
      "material": "track"
    },
    {
      "id": "verdant12/log",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 80,
      "y": 64,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/log_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 96,
      "y": 64,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/log_on_bracken",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 112,
      "y": 64,
      "role": "prop",
      "material": "bracken"
    },
    {
      "id": "verdant12/log_on_talus",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 128,
      "y": 64,
      "role": "prop",
      "material": "talus"
    },
    {
      "id": "verdant12/drystone_ew",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 144,
      "y": 64,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/drystone_ns",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 160,
      "y": 64,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/gate",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 176,
      "y": 64,
      "role": "prop",
      "material": "track"
    },
    {
      "id": "verdant12/gate_on_track",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 0,
      "y": 80,
      "role": "prop",
      "material": "track"
    },
    {
      "id": "verdant12/gate_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 16,
      "y": 80,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/signpost",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 32,
      "y": 80,
      "role": "prop",
      "material": "track"
    },
    {
      "id": "verdant12/signpost_on_track",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 48,
      "y": 80,
      "role": "prop",
      "material": "track"
    },
    {
      "id": "verdant12/signpost_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 64,
      "y": 80,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/trough",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 80,
      "y": 80,
      "role": "prop",
      "material": "track"
    },
    {
      "id": "verdant12/trough_on_track",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 96,
      "y": 80,
      "role": "prop",
      "material": "track"
    },
    {
      "id": "verdant12/trough_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 112,
      "y": 80,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/trough_on_upland",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 128,
      "y": 80,
      "role": "prop",
      "material": "upland"
    },
    {
      "id": "verdant12/spring",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 144,
      "y": 80,
      "role": "prop",
      "material": "talus"
    },
    {
      "id": "verdant12/spring_on_talus",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 160,
      "y": 80,
      "role": "prop",
      "material": "talus"
    },
    {
      "id": "verdant12/spring_on_meadow",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 176,
      "y": 80,
      "role": "prop",
      "material": "meadow"
    },
    {
      "id": "verdant12/spring_on_upland",
      "pack": "verdant12",
      "sheet": "verdant12/props.png",
      "x": 0,
      "y": 96,
      "role": "prop",
      "material": "upland"
    }
  ]
};
