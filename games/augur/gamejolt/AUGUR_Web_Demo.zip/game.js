/* ================================================================================================
 * AUGUR — game.js. The core loop.
 * ================================================================================================
 * Read `Internal_Ops/DESIGN.md` before changing anything in here; the numbers below are not taste.
 *
 * THE TWO BUILD RULES, both measured at candidate stage before this file existed:
 *   RULE 1 — A BOLTED-ON PART ADDS FIREPOWER AND BULK, NEVER PROTECTION. A hit costs HP and knocks
 *            a part loose. When parts absorbed hits instead, the value of reading an enemy fell
 *            from 2.57x to 1.25x: the power-up layer covered the same job as the knowledge layer
 *            and cannibalised it. This is the single rule that decides what the game is about.
 *   RULE 2 — AT LEAST ONE ATTACK IN FIVE MUST BE INSTANT (travel 0); target one in three. Measured
 *            lift from reading by instant share: 0.00 -> 0.80x (foreknowledge WORSE than useless),
 *            0.20 -> 1.71x, 0.35 -> 2.57x. Below 0.20 the game has no reason to exist.
 *            `content_gate.js` measures the REALISED share of what ships. A target is not a
 *            measurement — and it now measures the share of the ACTUAL WAVE TABLE below, not of a
 *            single global constant, because that constant stopped being what ships the day waves
 *            arrived (master §2b: an assert must re-derive, never restate).
 *
 * Everything a ship does comes from `derive.js`, which the art pipeline also uses. There is no
 * behaviour table here to drift out of sync with the sprites.
 * ---------------------------------------------------------------------------------------------- */
'use strict';

const VIEW = { w: 256, h: 320 };
const FPS = 60;

const CFG = {
  player: {
    speed: 2.6,
    baseR: 3,          // the naked hitbox, in playfield pixels
    partR: 2.0,        // every bolted part enlarges the silhouette AND the hitbox
    maxR: 11,
    hp: 4,
    /* ⚠️ THESE ARE REAL DPS FIGURES AND THEY ARE NOW HONEST. The first build wrote `baseDps: 34/60`
     * and then multiplied every landed shot by SIX on impact, so the constant a reader would quote
     * (34) was exactly one sixth of the damage the game did (204). A number that has to be
     * multiplied somewhere else to mean anything is not a measurement, it is a coincidence waiting
     * to be tuned twice. One shot now does `dps * fireEvery` and nothing scales it afterwards. */
    baseDps: 150 / FPS,
    partDps: 90 / FPS,
    fireEvery: 6,
  },
  instantShare: 0.35,  // RULE 2 — the DEFAULT for a wave that does not state its own
  contactR: 11,        // ramming a hull hurts. A 'dive' hull is a threat, not scenery.
  beamHoldFrames: 9,   // how long a fired beam stays lethal
  bossCool: 0.60,      // a capital ship fires faster than its escorts, before enrage
  /* ⛔⛔ THE LEGIBILITY GOVERNOR, AND IT IS THE MOST IMPORTANT NUMBER IN THIS FILE.
   * A game whose entire claim is that you READ a threat in the half second before it fires cannot
   * ask you to read six at once — at that point the correct play is to stop reading and flail, and
   * the design is gone. MEASURED before it existed: five hulls on screen at ~0.5 attacks each per
   * second put 2-3 TARGETED attacks a second on a 4-hp ship, and both bot models died in the wave
   * ranks with the boss unreached in two runs of three. Density was doing the killing, not
   * information.
   * So the number of unresolved attacks in the world is CAPPED. Enemies still swarm; they queue to
   * shoot. An attack that comes off cooldown while the world is full simply waits. This makes
   * "how many things must be read at once" a designed constant instead of an emergent accident,
   * and it is the reason a region can add ships without becoming noise. */
  maxLiveHazards: 4,     // region 1. +1 per region — see regionDef()/liveHazardCap()

  lullFrames: 105,     // the breath between waves — where the WAVE card is shown
};

/* ================================================================================================
 * THE REGIONS. Each is a faction sprite sheet + its own first-party ground pack + its own boss.
 * ================================================================================================
 * ⚠️ THE FREE DEMO IS REGION 1 AND NOTHING ELSE. Master §2b, 2026-09-03: a $14.99 title reached
 * "cleared for publish" with its only artefact being the free demo zip, because nothing in the
 * factory asserts that a paid listing owns paid bytes. Here the difference is CONTENT, and it is
 * mechanical: `edition.js` sets how many of these three the build may enter, the demo ships one
 * faction sheet and one ground pack, and `edition_gate.js` measures that the two packages differ.
 */
const REGIONS = [
  { id: 'meadow',  title: 'THE MEADOW REACH',    faction: 'meadow',  pack: 'verdant01', hpMul: 1.00, coolMul: 1.00 },
  { id: 'harbour', title: 'THE DROWNED HARBOUR', faction: 'harbour', pack: 'verdant10', hpMul: 1.32, coolMul: 0.86 },
  { id: 'scarp',   title: 'THE BLACK SCARP',     faction: 'scarp',   pack: 'verdant12', hpMul: 1.70, coolMul: 0.74 },
];

/* ================================================================================================
 * THE WAVES. One table, walked once per region, scaled by that region's multipliers.
 * ================================================================================================
 * The arc is a teaching order, not a difficulty ramp for its own sake. Wave 1 is nearly all
 * TRAVELLING attacks on one-mount hulls, so the player learns to dodge by reacting and learns what
 * a pod looks like. The instant share then climbs, because §4d measured that reading is worth
 * NOTHING (0.80x, worse than useless) until part of the mix cannot be answered by reaction.
 *
 * ⚠️ `instantShare` here is the probability each pod is drawn as a beam, so the REALISED share is
 * an outcome, not a setting. `content_gate.js` measures the realised share over this exact table.
 */
const WAVES = [
  { count: 6,  every: 74, instantShare: 0.20, hulls: ['spindle', 'wedge'] },
  { count: 8,  every: 66, instantShare: 0.30, hulls: ['wedge', 'crescent', 'delta'] },
  { count: 9,  every: 58, instantShare: 0.38, hulls: ['delta', 'barrel', 'crescent'] },
  { count: 10, every: 52, instantShare: 0.42, hulls: ['barrel', 'bastion', 'delta'] },
  { count: 11, every: 48, instantShare: 0.44, hulls: ['bastion', 'barrel', 'crescent', 'delta'] },
];

/* ================================================================================================
 * THE BOSSES — three hulls bolted into one capital ship.
 * ================================================================================================
 * ⭐ WHY THIS SHAPE. No hull in the part library carries more than THREE mounts, and that ceiling is
 * load-bearing: `derive()` refuses a spec with more pods than the sprite can draw, which is the one
 * mechanical guarantee behind the game's whole promise. A boss with six guns could therefore only be
 * built by breaking that guarantee — or by being three ships. It is three ships.
 *
 * The payoff is exactly the mechanic, scaled up: reading a boss means reading three silhouettes at
 * once, and because each section is a real enemy, SHOOTING A SECTION APART REMOVES THE ATTACKS IT
 * WAS ADVERTISING. DESIGN.md §4e held destructible pods back from region 1's rank and file so the
 * reading is taught before it is complicated; the boss is where it is complicated.
 */
const BOSSES = [
  {
    /* ⚠️ THESE HP FIGURES ARE MEASURED, NOT CHOSEN. The first table (340/460/340) produced a boss
     * fight of 3.3 SECONDS, and a 4x sweep only took it to 8 s while EVERY bot that reached the
     * boss still beat it — i.e. the entire difficulty of the region lived in the rank and file and
     * the boss was a cutscene. `_balance.js --sweep-boss` prints the surface these came off. */
    name: 'HARROW', hp: [1200, 1650, 1200],
    sections: [
      { hull: 'barrel',  wing: 'broad',  engine: 'wide',   crest: 'comb',   pods: ['fan_a', 'barrel_a'] },
      { hull: 'bastion', wing: 'ribbed', engine: 'triple', crest: 'crown',  pods: ['slot_a', 'drum_a', 'slot_b'] },
      { hull: 'barrel',  wing: 'broad',  engine: 'wide',   crest: 'comb',   pods: ['barrel_b', 'fan_b'] },
    ],
  },
  {
    name: 'TIDEREEVE', hp: [1500, 2050, 1500],
    sections: [
      { hull: 'crescent', wing: 'finned', engine: 'spike',  crest: 'horns',  pods: ['slot_c', 'fan_c'] },
      { hull: 'bastion',  wing: 'broad',  engine: 'block',  crest: 'banner', pods: ['slot_d', 'barrel_c', 'slot_a'] },
      { hull: 'crescent', wing: 'finned', engine: 'spike',  crest: 'horns',  pods: ['fan_d', 'slot_b'] },
    ],
  },
  {
    name: 'THE LAST ASSAY', hp: [1850, 2500, 1850],
    sections: [
      { hull: 'bastion', wing: 'stub',   engine: 'triple', crest: 'crown',  pods: ['slot_a', 'drum_c', 'slot_b'] },
      { hull: 'bastion', wing: 'ribbed', engine: 'wide',   crest: 'banner', pods: ['slot_c', 'slot_d', 'barrel_d'] },
      { hull: 'bastion', wing: 'stub',   engine: 'triple', crest: 'crown',  pods: ['drum_d', 'fan_a', 'slot_c'] },
    ],
  },
];

const BOSS_SCALE = 2;          // a capital ship is DRAWN at 2x. Integer scale only — no smoothing.
const BOSS_SPACING = 48;       // 2x sprite is 64 wide, so sections overlap and read as one vessel
const BOSS_SETTLE_Y = 66;

/* ---------------------------------------------------------------- tiny helpers */
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

/* ================================================================================================
 * SpriteCache — compose a ship from the part sheet, once per distinct spec.
 * ================================================================================================
 * ⚠️ The composition arithmetic is NOT repeated here. `parts.json` carries the geometry that
 * `compose.geometry()` produced at bake time, per hull, so this and the Node baker place parts by
 * reading the same numbers rather than by each doing the same sum.
 */
class SpriteCache {
  constructor(manifest, sheets) {
    this.manifest = manifest;
    this.sheets = sheets;          // faction -> HTMLImageElement/ImageBitmap
    this.cache = new Map();
  }
  key(spec, faction, tint) {
    return faction + '|' + (tint || '-') + '|' + spec.hull + '|' + spec.wing + '|' + spec.engine + '|' + spec.crest + '|' +
      spec.pods.map((p) => p.motif + '@' + p.mount).join(',');
  }
  get(spec, faction, tint, halo) {
    const k = this.key(spec, faction, tint) + '|' + (halo || '-');
    let c = this.cache.get(k);
    if (c) return c;
    c = this.outline(this.compose(spec, faction), tint, halo);
    this.cache.set(k, c);
    return c;
  }

  /* ⛔⛔ EVERY SHIP GETS A DARK OUTLINE, AND IT IS THE DESIGN'S LOAD-BEARING FIX, NOT A FLOURISH.
   * AUGUR asks the player to READ A SILHOUETTE in the half second before an attack fires. MEASURED
   * by photographing the real game: the meadow faction's tan hulls sitting on the pack's brown dirt
   * band were close to camouflaged — same family, similar luma — so the one thing the player must
   * read was the hardest thing on screen to see. The wing's own doctrine names the statistic
   * (CAMOUFLAGE: the fraction of a sprite's opaque pixels within a few luma of the ground behind
   * it) and warns that a mean cannot detect it, because bright and dark cancel.
   * An outline is immune to all of it: the sprite carries its own contrast, so legibility stops
   * depending on which of twelve ground sheets happens to be scrolling past.
   *
   * ⚠️ TINT IS FOR THE PLAYER ONLY. Player and enemies are composed from the SAME part sheet — that
   * is the whole grammar — so without it the ship you control is drawn in the same palette as the
   * things shooting at you, and in a photograph of a real fight I could not immediately tell which
   * was which. The tint keeps the shapes identical and changes only the colour. */
  /* ⛔ `halo` EXISTS BECAUSE CONTRAST IS A RELATION, NOT A PROPERTY (wing §0z rule b).
   * The player was first separated from the enemies with a cyan tint, chosen while looking at the
   * MEADOW faction, whose ships are tan — and it worked. Then region 2 was reached and photographed
   * and the DROWNED HARBOUR's ships are steel blue: against them the cyan player was the same
   * colour as the things shooting at it. A tint is a claim about a specific background, and this
   * game has three factions and twelve ground sheets. A CREAM HALO is a claim about none of them —
   * it is the same near-white as the player's own bullets, no faction uses it, and it separates the
   * player from every ground the game can draw. */
  outline(src, tint, halo) {
    const w = src.width, h = src.height;
    const cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    const g = cv.getContext('2d');
    g.imageSmoothingEnabled = false;
    /* 1. dilate the silhouette by one pixel in eight directions ... */
    for (let dx = -1; dx <= 1; dx++) {
      for (let dy = -1; dy <= 1; dy++) {
        if (!dx && !dy) continue;
        g.drawImage(src, dx, dy);
      }
    }
    /* 2. ... and recolour ONLY what that dilation painted, which is the halo plus the body */
    g.globalCompositeOperation = 'source-in';
    g.fillStyle = halo || 'rgba(9,7,16,0.92)';
    g.fillRect(0, 0, w, h);
    /* 3. then the real sprite on top, so the halo survives only where the body is not */
    g.globalCompositeOperation = 'source-over';
    g.drawImage(src, 0, 0);
    if (tint) {
      g.globalCompositeOperation = 'source-atop';
      g.fillStyle = tint;
      g.fillRect(0, 0, w, h);
      g.globalCompositeOperation = 'source-over';
    }
    return cv;
  }
  compose(spec, faction) {
    const S = this.manifest.sprite;
    const cv = document.createElement('canvas');
    cv.width = S.w; cv.height = S.h;
    const g = cv.getContext('2d');
    g.imageSmoothingEnabled = false;
    const atlas = this.manifest.factions[faction];
    const sheet = this.sheets[faction];
    if (!atlas) throw new Error('compose: no atlas for faction ' + faction);
    if (!sheet) throw new Error('compose: faction sheet not loaded: ' + faction);
    const geo = this.manifest.hulls[spec.hull].geometry;
    const L = this.manifest.layout;

    const put = (famName, motif, dx, dy, mirror) => {
      const cell = atlas.index[famName + '/' + motif];
      if (!cell) throw new Error('compose: no atlas cell for ' + famName + '/' + motif);
      if (mirror) {
        g.save(); g.translate(dx + cell.w, dy); g.scale(-1, 1);
        g.drawImage(sheet, cell.x, cell.y, cell.w, cell.h, 0, 0, cell.w, cell.h);
        g.restore();
      } else {
        g.drawImage(sheet, cell.x, cell.y, cell.w, cell.h, dx, dy, cell.w, cell.h);
      }
      return cell;
    };

    // back to front, exactly the order the Node renderer uses.
    put('CRESTS', spec.crest, L.crest.x, L.crest.y, false);
    put('ENGINES', spec.engine, L.engine.x, L.engine.y, false);
    put('WINGS', spec.wing, L.wingLeft.x, L.wingLeft.y, false);
    put('WINGS', spec.wing, L.wingRight.x, L.wingRight.y, true);
    put('HULLS', spec.hull, geo.hx, geo.hy, false);
    spec.pods.forEach((p, i) => {
      const m = geo.mounts[p.mount == null ? i : p.mount];
      put('PODS', p.motif, m.x, m.y, false);
    });
    return cv;
  }
}

/* ================================================================================================
 * The world.
 * ============================================================================================= */
class Game {
  /**
   * @param opts.regions  how many of REGIONS this BUILD may enter. 1 = the free demo.
   */
  constructor(manifest, sprites, opts) {
    opts = opts || {};
    this.manifest = manifest;
    this.sprites = sprites;
    this.D = (typeof AugurDerive !== 'undefined') ? AugurDerive : require('./derive.js');
    this.regionCount = clamp(opts.regions == null ? REGIONS.length : opts.regions, 1, REGIONS.length);
    this.seed = opts.seed == null ? 1 : opts.seed;
    this.reset();
  }

  reset() {
    const P = CFG.player;
    this.rnd = this.D.mulberry32(this.seed);
    this.frame = 0;
    this.player = { x: VIEW.w / 2, y: VIEW.h - 38, r: P.baseR, hp: P.hp, parts: [], dps: P.baseDps, inv: 0 };
    this.enemies = [];
    this.hazards = [];
    this.salvage = [];
    this.shots = [];
    this.over = null;              // 'dead' | 'cleared' — a TRI-STATE, never !alive
    this.stats = {
      kills: 0, hits: 0, partsTaken: 0, partsLost: 0, attacksFired: 0, beamsFired: 0,
      spawned: 0, bossPodsShotOff: 0, bossSectionsKilled: 0, regionsCleared: 0,
      bossDamage: 0, bossTotalHp: 0, bossPhaseFrames: 0,
    };
    /* SFX and music are driven from EVENTS the model emits, so the audio layer is testable
     * headlessly and game.js stays free of any audio dependency (§1.1b `audio`). */
    this.events = [];
    this.region = 0;
    this.wave = 0;
    this.waveSpawned = 0;
    this.phase = 'wave';           // 'wave' | 'lull' | 'boss' | 'regionclear'
    this.lullLeft = CFG.lullFrames;
    this.boss = null;
    this.bossStartedAt = 0;
    this.nextId = 1;
  }

  /* ---------------------------------------------------------------- accessors the view uses */
  regionDef() { return REGIONS[this.region]; }
  faction() { return REGIONS[this.region].faction; }
  isFinalRegion() { return this.region === this.regionCount - 1; }
  emit(kind, extra) { this.events.push(extra ? Object.assign({ kind }, extra) : { kind }); }

  /* ---- the player's silhouette IS the hitbox. More parts, bigger target. */
  playerRadius() {
    return Math.min(CFG.player.maxR, CFG.player.baseR + this.player.parts.length * CFG.player.partR);
  }

  waveDef() { return WAVES[Math.min(this.wave, WAVES.length - 1)]; }

  spawn() {
    const w = this.waveDef();
    const R = this.regionDef();
    const g = this.D.generate(this.manifest,
      (this.seed * 7919 + this.stats.spawned * 104729 + this.region * 31337) >>> 0,
      { instantShare: w.instantShare, hullPool: w.hulls });
    const e = {
      id: this.nextId++,
      spec: g.spec, stats: g.stats,
      x: 22 + this.rnd() * (VIEW.w - 44),
      y: -20,
      hold: 34 + this.rnd() * 86,
      /* ⛔ EVERY SHIP MUST LEAVE. Without this a non-diving hull parks at its hold row forever, the
       * field silts up, and a wave can never end — which would make the wave state machine below
       * unreachable and the run unfinishable. Measured on the pre-wave build: enemies accumulated
       * until the screen was unreadable. */
      linger: 380 + Math.floor(this.rnd() * 260),
      leaving: false,
      hp: g.stats.hp * R.hpMul, maxHp: g.stats.hp * R.hpMul,
      cool: g.stats.attacks.map(() => Math.round((40 + Math.floor(this.rnd() * 70)) * R.coolMul)),
      phaseOff: this.rnd() * Math.PI * 2,
      hw: 12, hh: 12, scale: 1,
    };
    this.enemies.push(e);
    this.stats.spawned++;
    this.waveSpawned++;
    return e;
  }

  spawnBoss() {
    const B = BOSSES[this.region];
    const R = this.regionDef();
    this.bossStartedAt = this.frame;
    this.boss = {
      name: B.name, x: VIEW.w / 2, y: -46, settled: false,
      sway: 0, podsTotal: 0, sections: [],
    };
    B.sections.forEach((s, i) => {
      const spec = {
        hull: s.hull, wing: s.wing, engine: s.engine, crest: s.crest,
        pods: s.pods.map((m, k) => ({ motif: m, mount: k })),
      };
      /* derive() is the SAME call the rank and file go through, so a boss cannot carry an attack
       * its sprite does not draw either. If a section here ever exceeds its hull's mounts this
       * throws at boot rather than shipping a lying capital ship. */
      const stats = this.D.derive(this.manifest, spec);
      const e = {
        id: this.nextId++, boss: true, section: i,
        spec, stats,
        offX: (i - 1) * BOSS_SPACING,
        x: VIEW.w / 2 + (i - 1) * BOSS_SPACING, y: -46,
        hp: B.hp[i] * R.hpMul, maxHp: B.hp[i] * R.hpMul,
        cool: stats.attacks.map((_, k) => Math.round((70 + k * 34) * R.coolMul)),
        shedAt: spec.pods.map((_, k) => (B.hp[i] * R.hpMul) * (1 - (k + 1) / (spec.pods.length + 1))),
        hold: BOSS_SETTLE_Y, linger: Infinity, leaving: false,
        phaseOff: i * 0.9, hw: 22, hh: 20, scale: BOSS_SCALE,
      };
      this.boss.podsTotal += spec.pods.length;
      this.stats.bossTotalHp += e.maxHp;
      this.boss.sections.push(e);
      this.enemies.push(e);
    });
    this.emit('boss', { name: B.name, region: this.region });
    return this.boss;
  }

  /** How many attacks are currently asking to be read (winding up or in flight). */
  liveHazards() {
    let n = 0;
    for (const h of this.hazards) if (!h.done) n++;
    return n;
  }

  /* The governor, widened by one per region: later regions ask you to read more at once.
   * ⛔⛔ AND WIDENED BY BOSS PRESSURE, BECAUSE OTHERWISE THE GOVERNOR SILENTLY CANCELS THE
   * STALEMATE BREAKER. MEASURED: with the rate ramp unbounded, the boss's cooldowns fell to 0.18x
   * and the timeout count did not move at all (8 of 40, unchanged across three different fixes) —
   * because a cap of FIVE unresolved attacks is a cap on the pressure itself, however fast the guns
   * cycle. Two mechanisms, each correct alone, one quietly neutralising the other; the only tell
   * was a number that refused to move. Rate escalation and legibility escalation have to rise
   * together or neither does anything. */
  liveHazardCap() {
    const base = CFG.maxLiveHazards + this.region + (this.phase === 'boss' ? 1 : 0);
    return base + Math.floor((1 - this.bossPressure()) * 6);
  }

  /* ⛔⛔ THE STALEMATE BREAKER, AND IT HAD TO BE UNBOUNDED TO WORK.
   * A capital ship you can neither kill nor be killed by is not a hard boss, it is a game with no
   * ending — and 8 of 40 automated runs sat in exactly that state at the 7-minute cap. Two
   * bounded fixes were built and MEASURED USELESS before this one: a rate ramp that bottomed out at
   * 0.55x (a faster gun is dodged by the same player who was already dodging) and a descent that
   * stopped at y=150 while the player's own floor is y=134, so it never entered the band the player
   * actually occupies — it changed the picture and not one outcome, byte for byte, across 40 seeds.
   * A cap on the pressure is a cap on whether the game can end. This one keeps going: by 150
   * seconds the boss is firing at roughly five times its opening rate, and something eventually
   * gives. `_balance.js` counts TIMEOUT as its own outcome precisely so this cannot be hidden. */
  bossPressure() {
    if (!this.boss) return 1;
    const held = this.frame - this.bossStartedAt;
    return Math.max(0.18, 1 - held / (150 * FPS));
  }

  bossPodsLeft() {
    if (!this.boss) return 0;
    return this.boss.sections.reduce((n, s) => n + (s.hp > 0 ? s.spec.pods.length : 0), 0);
  }

  /* ---- one frame. Returns false once the run is over. */
  step(input) {
    if (this.over) return false;
    this.events.length = 0;
    const f = this.frame++;

    this.stepDirector(f);

    // ---- enemies move and schedule attacks
    const R = this.regionDef();
    for (const e of this.enemies) {
      if (e.boss) {
        e.x = this.boss.x + e.offX;
        e.y = this.boss.y;
      } else if (e.y < e.hold) {
        e.y += 1.4 * e.stats.speed;
      } else if (e.leaving) {
        e.y += 1.7 * e.stats.speed;
      } else {
        if (--e.linger <= 0) e.leaving = true;
        /* ⛔ A 'dive' HULL MUST ACTUALLY DIVE. It used to creep down at 0.3 px/frame and then turn
         * into a `leaving` ship before it ever reached the player, so the contact-damage branch
         * below fired ZERO times across 24 measured runs — an untested code path masquerading as a
         * mechanic (master §2b, the dead-reader row). A dive is now a commitment: the hull crosses
         * the screen and exits, and the hull shape is therefore a third honest tell alongside the
         * pods. */
        if (e.stats.move === 'strafe') e.x += Math.sin((f + e.phaseOff * 60) / 38) * 0.9 * e.stats.speed;
        else if (e.stats.move === 'dive') e.y += 1.05 * e.stats.speed;
        else e.x += Math.sin((f + e.phaseOff * 60) / 55) * 0.45;
      }
      if (!e.boss) e.x = clamp(e.x, 14, VIEW.w - 14);

      /* ⛔ A HULL IS A THREAT. Without contact damage a 'dive' hull flies through the player and
       * nothing happens, which makes a whole movement class scenery and makes the bottom of the
       * screen a safe corner. */
      if (this.player.inv <= 0 && !e.leaving && e.hp > 0) {
        const rr = CFG.contactR * e.scale + this.playerRadius();
        if (Math.abs(e.x - this.player.x) < rr && Math.abs(e.y - this.player.y) < rr * 0.8) this.takeHit('ram');
      }

      /* ⛔ ENRAGE IS LEGIBLE, NOT HIDDEN: the boss fires faster as it loses the pods it was firing
       * with, so "shoot the guns off" stays a real choice instead of a free win. */
      /* ⛔ A BOSS THAT CAN BE OUT-WAITED IS A STALEMATE, AND A STALEMATE IS NOT AN ENDING.
       * MEASURED before `pressure` existed: 3 of 24 reading-bot runs hit the 7-minute cap alive,
       * dodging a boss they never shot. Master §2b records a gate that read 38 stalemates as
       * healthy because it counted wins and called everything else a loss — so the harness counts
       * timeouts as their own outcome, and the game removes the state that produces them. Pressure
       * is a straight ramp on the boss's rate of fire over its first 90 seconds; nothing hidden. */
      const enrage = e.boss
        ? CFG.bossCool
          * (0.58 + 0.42 * (this.bossPodsLeft() / Math.max(1, this.boss.podsTotal)))
          * this.bossPressure()
        : 1;
      for (let i = 0; i < e.stats.attacks.length; i++) {
        e.cool[i]--;
        if (e.cool[i] > 0 || e.y < 4 || e.leaving) continue;
        if (this.liveHazards() >= this.liveHazardCap()) { e.cool[i] = 10; continue; }  // queue, don't flood
        this.beginAttack(e, e.stats.attacks[i], i);
        /* ⚠️ MEASURED, not chosen: at the first cooldown (120+d90) the field put 2-4 attacks a
         * second on a 3-hp ship and both bot models died inside 30 s, in waves 1-3, before the boss
         * existed for them. A wall of fire is not a reading game — the player never gets the half
         * second the whole design is about. */
        e.cool[i] = Math.round((190 + Math.floor(this.rnd() * 130)) * R.coolMul * enrage);
      }
    }

    this.stepHazards(f);
    this.stepPlayer(input, f);
    this.stepShots();
    this.stepSalvage();

    if (this.player.hp <= 0) { this.over = 'dead'; this.emit('dead'); }
    return !this.over;
  }

  /* ================================================================================================
   * THE DIRECTOR — waves, the lull between them, the boss, and the only path to 'cleared'.
   * ============================================================================================= */
  stepDirector(f) {
    if (this.phase === 'wave') {
      const w = this.waveDef();
      if (this.waveSpawned < w.count && f % w.every === 0) this.spawn();
      if (this.waveSpawned >= w.count && this.enemies.length === 0) {
        this.wave++;
        this.waveSpawned = 0;
        this.phase = 'lull';
        this.lullLeft = CFG.lullFrames;
        this.emit('wavecleared', { wave: this.wave, of: WAVES.length });
      }
      return;
    }
    if (this.phase === 'lull') {
      if (--this.lullLeft > 0) return;
      if (this.wave >= WAVES.length) { this.phase = 'boss'; this.spawnBoss(); }
      else this.phase = 'wave';
      return;
    }
    if (this.phase === 'boss') {
      this.stats.bossPhaseFrames++;
      const b = this.boss;
      if (b.y < BOSS_SETTLE_Y) { b.y += 0.9; }
      else {
        b.settled = true;
        b.sway += 0.011;
        b.x = VIEW.w / 2 + Math.sin(b.sway) * 42;
        /* ⛔ AND AFTER A MINUTE IT COMES DOWN ON YOU. The rate-of-fire ramp alone did not close the
         * stalemate — MEASURED, 8 of 40 reading-bot runs still sat at the 7-minute cap alive. A
         * faster gun can be dodged by the same player who was already dodging; taking the ROOM away
         * cannot. The descent is slow (3 px/s), visible, and stops well above the player's floor,
         * so it squeezes rather than crushes: a stalemate becomes a death, which is a real ending. */
        const held = this.frame - this.bossStartedAt;
        if (held > 60 * FPS) b.y = Math.min(BOSS_SETTLE_Y + 84, b.y + 0.05);
      }
      if (b.sections.every((s) => s.hp <= 0)) {
        this.stats.regionsCleared++;
        this.boss = null;
        if (this.isFinalRegion()) {
          this.over = 'cleared';
          this.emit('cleared', { regions: this.stats.regionsCleared });
        } else {
          this.phase = 'regionclear';
          this.lullLeft = 170;
          this.emit('regioncleared', { region: this.region });
        }
      }
      return;
    }
    if (this.phase === 'regionclear') {
      if (--this.lullLeft > 0) return;
      this.region++;
      this.wave = 0;
      this.waveSpawned = 0;
      this.hazards.length = 0;
      this.salvage.length = 0;
      this.phase = 'wave';
      /* a region is a fresh start for the field but NOT for the ship: parts and hp carry, which is
       * what makes the run a run rather than three levels. */
      this.emit('regionstart', { region: this.region, title: this.regionDef().title });
      return;
    }
  }

  /* ---- an attack begins its WINDUP here. The telegraph is what the player reads; for a beam it is
   * the only warning there will ever be, because a beam has no travel time. */
  beginAttack(e, cls, idx) {
    const A = this.D.ATTACK[cls];
    const geo = this.manifest.hulls[e.spec.hull].geometry;
    const S = this.manifest.sprite;
    const mount = geo.mounts[idx] || geo.mounts[0];
    const offX = ((mount.x + 4) - S.w / 2) * e.scale;   // where the pod sits on the sprite
    this.hazards.push({
      id: this.nextId++, cls, e,
      x: e.x + offX, y: e.y,
      windup: A.windup, fireAt: this.frame + A.windup,
      travel: A.travel, width: A.width,
      arriveAt: this.frame + A.windup + A.travel,
      fired: false, done: false, hitY: e.y,
    });
    this.emit('windup', { cls });
  }

  /* ================================================================================================
   * HAZARDS. ⛔ THE COLLISION IS PER FRAME AND FOLLOWS THE DRAWN PROJECTILE.
   * ============================================================================================= */
  /* The first version resolved every hazard at a single instant, comparing the player's COLUMN only
   * and testing a y condition (`|player.y - VIEW.h| < VIEW.h`) that is true for every reachable
   * player position — i.e. vacuously. A travelling shot therefore could not be dodged by moving out
   * of its path, only by leaving its column, so reaction and pre-positioning answered the SAME way
   * and the design's central distinction was not in the build at all. It is now: a beam is a lethal
   * column for `beamHoldFrames`, and a travelling shot is a moving box that hits what it passes
   * through. */
  stepHazards(f) {
    const r = this.playerRadius();
    for (const h of this.hazards) {
      if (h.done) continue;
      if (!h.fired && f >= h.fireAt) {
        h.fired = true;
        this.stats.attacksFired++;
        if (h.cls === 'beam') this.stats.beamsFired++;
        if (h.cls === 'aimed') h.x = this.player.x;   // an aimed shot locks on at FIRE time
        this.emit('fire', { cls: h.cls });
      }
      if (!h.fired) continue;

      if (h.travel === 0) {
        // a beam: the whole column, lethal for a short hold. Nothing to dodge into — only out of.
        if (f >= h.fireAt + CFG.beamHoldFrames) { h.done = true; continue; }
        if (this.player.inv <= 0 && Math.abs(this.player.x - h.x) < h.width / 2 + r) this.takeHit(h.cls);
      } else {
        const k = (f - h.fireAt) / h.travel;
        if (k >= 1) { h.done = true; continue; }
        h.hitY = h.y + (VIEW.h + 12 - h.y) * k;
        if (this.player.inv <= 0 &&
            Math.abs(this.player.x - h.x) < h.width / 2 + r &&
            Math.abs(this.player.y - h.hitY) < 5 + r) {
          this.takeHit(h.cls);
          h.done = true;
        }
      }
    }
    if (this.hazards.length > 200) this.hazards = this.hazards.filter((h) => !h.done);
  }

  /* ⛔ RULE 1 LIVES HERE, AND IT IS THE WHOLE DESIGN.
   * A hit costs HP. It ALSO knocks a part loose — the ship visibly comes apart — but the part buys
   * no protection whatsoever. If this ever becomes "lose a part INSTEAD of hp", the measured value
   * of reading an enemy collapses from 2.57x to 1.25x and AUGUR becomes a game about hoarding. */
  takeHit(cause) {
    this.stats.hits++;
    this.player.hp--;
    this.player.inv = 48;
    this.emit('playerhit', { cause: cause || 'shot' });
    if (this.player.parts.length > 0) {
      this.player.parts.pop();
      this.stats.partsLost++;
      this.recomputeDps();
    }
  }

  recomputeDps() {
    this.player.dps = CFG.player.baseDps + this.player.parts.length * CFG.player.partDps;
  }

  stepPlayer(input, f) {
    const P = CFG.player;
    if (this.player.inv > 0) this.player.inv--;
    const dx = (input.right ? 1 : 0) - (input.left ? 1 : 0);
    const dy = (input.down ? 1 : 0) - (input.up ? 1 : 0);
    this.player.x = clamp(this.player.x + dx * P.speed, 8, VIEW.w - 8);
    this.player.y = clamp(this.player.y + dy * P.speed, VIEW.h * 0.42, VIEW.h - 12);
    this.player.r = this.playerRadius();

    if (input.fire && f % P.fireEvery === 0) {
      const lanes = 1 + Math.min(2, Math.floor(this.player.parts.length / 2));
      for (let i = 0; i < lanes; i++) {
        const spread = (i - (lanes - 1) / 2) * 7;
        this.shots.push({ x: this.player.x + spread, y: this.player.y - 8, dmg: this.player.dps * P.fireEvery });
      }
      this.emit('shoot', { lanes });
    }
  }

  stepShots() {
    for (let i = this.shots.length - 1; i >= 0; i--) {
      const s = this.shots[i];
      s.y -= 7;
      if (s.y < -8) { this.shots.splice(i, 1); continue; }
      let hit = false;
      for (const e of this.enemies) {
        if (e.hp <= 0) continue;
        if (Math.abs(e.x - s.x) < e.hw && Math.abs(e.y - s.y) < e.hh) {
          /* count the damage that LANDED, not the damage that was dealt: overkill on a section's
           * last 12 hp is not 42 points of progress, and a time-to-kill derived from it would be
           * optimistic by exactly the overkill. */
          if (e.boss) this.stats.bossDamage += Math.min(s.dmg, Math.max(0, e.hp));
          e.hp -= s.dmg;
          if (e.boss) this.bossShed(e);
          hit = true;
          break;
        }
      }
      if (hit) { this.shots.splice(i, 1); this.emit('enemyhit'); }
    }
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (e.hp > 0 && e.y < VIEW.h + 30) continue;
      if (e.hp <= 0) {
        this.stats.kills++;
        if (e.boss) this.stats.bossSectionsKilled++;
        this.emit(e.boss ? 'bosssection' : 'kill');
        // a killed ship drops ITS OWN pods as salvage — what you saw it shoot with is what you get
        e.spec.pods.forEach((p, k) => this.salvage.push({
          x: clamp(e.x + (k - (e.spec.pods.length - 1) / 2) * 10, 8, VIEW.w - 8), y: e.y, motif: p.motif,
        }));
      }
      this.enemies.splice(i, 1);
      // ⚠️ hazards belonging to a dead ship stay in flight. Killing the shooter does NOT unfire a
      // beam that is already winding up; that is what makes reading it worth anything.
    }
  }

  /* ⭐ THE BOSS COMES APART, AND WHAT IT LOSES IS WHAT IT CAN NO LONGER DO.
   * A pod is shed at a pre-computed hp threshold. Because the attack table is DERIVED from the pod
   * list, removing the pod removes the attack by construction — there is no second table to update
   * and therefore no way for the sprite and the behaviour to disagree. The pod falls as salvage. */
  bossShed(e) {
    while (e.spec.pods.length > 1 && e.hp > 0 && e.hp <= e.shedAt[e.spec.pods.length - 1]) {
      const gone = e.spec.pods.pop();
      e.stats = this.D.derive(this.manifest, e.spec);
      e.cool = e.cool.slice(0, e.stats.attacks.length);
      this.stats.bossPodsShotOff++;
      this.salvage.push({ x: clamp(e.x, 8, VIEW.w - 8), y: e.y + 8, motif: gone.motif });
      this.emit('bosspod', { motif: gone.motif });
    }
  }

  stepSalvage() {
    for (let i = this.salvage.length - 1; i >= 0; i--) {
      const s = this.salvage[i];
      s.y += 1.1;
      if (s.y > VIEW.h + 10) { this.salvage.splice(i, 1); continue; }
      if (Math.abs(s.y - this.player.y) < 8 && Math.abs(s.x - this.player.x) < 10 + this.player.r) {
        // ⛔ THE CAP IS THE PLAYER HULL'S MOUNT COUNT (delta = 3), not an arbitrary number. A part
        // the ship carries but cannot DRAW would be the player's own silhouette lying about its
        // armament — the one thing this game asks the player to trust.
        if (this.player.parts.length < 3) {
          this.player.parts.push(s.motif);
          this.stats.partsTaken++;
          this.recomputeDps();
          this.emit('salvage', { motif: s.motif });
          this.salvage.splice(i, 1);
        }
      }
    }
  }
}

if (typeof module === 'object' && module.exports) {
  module.exports = { Game, SpriteCache, CFG, VIEW, FPS, REGIONS, WAVES, BOSSES, BOSS_SCALE, BOSS_SPACING };
}
