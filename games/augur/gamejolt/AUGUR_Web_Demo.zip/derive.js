/* ================================================================================================
 * derive.js — the ONE implementation of "what does this ship do?", shared by the game and the tools.
 * ================================================================================================
 * AUGUR's whole promise is that a ship's appearance is an honest statement of its behaviour. That
 * promise has exactly one way to break: two implementations of the derivation drifting apart — the
 * baker deciding a slot pod is a beam while the game decides it is something else. The player would
 * experience that as the game LYING, which does not damage the design, it deletes it.
 *
 * So this file is loaded by BOTH the browser game and the Node art pipeline, and neither has a
 * private copy. It is data-driven: everything it needs arrives in the manifest that `bake_parts.js`
 * writes beside the sprite sheets, so the tables it reads are the same bytes the art was baked from.
 *
 * ⚠️ It is deliberately dependency-free and side-effect-free so it can be loaded with a <script> tag
 * or a require() without a build step (§3: Product_Release ships raw and human-auditable).
 * ---------------------------------------------------------------------------------------------- */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.AugurDerive = factory();
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /**
   * @param manifest  parts.json — carries podClass, hulls, wings, crests
   * @param spec      { hull, wing, engine, crest, pods:[{motif, mount}] }
   * @returns the ship's complete behaviour, every field a function of a VISIBLE part.
   */
  function derive(manifest, spec) {
    const hull = manifest.hulls[spec.hull];
    const wing = manifest.wings[spec.wing];
    const crest = manifest.crests[spec.crest];
    if (!hull) throw new Error('derive: unknown hull ' + spec.hull);
    if (!wing) throw new Error('derive: unknown wing ' + spec.wing);
    if (!crest) throw new Error('derive: unknown crest ' + spec.crest);
    if (spec.pods.length > hull.mounts) {
      throw new Error('derive: ' + spec.hull + ' has ' + hull.mounts + ' mounts, ' + spec.pods.length +
        ' pods given - the art could not show them all');
    }
    const attacks = spec.pods.map(function (p) {
      const cls = manifest.podClass[p.motif];
      if (!cls) throw new Error('derive: unknown pod ' + p.motif);
      return cls;
    });
    return {
      attacks: attacks,
      instantShare: attacks.length ? attacks.filter(function (a) { return a === 'beam'; }).length / attacks.length : 0,
      move: hull.move,
      speed: wing.speed,
      hp: 26 * hull.bulk + 8 * crest.rank,
      bulk: hull.bulk,
      rank: crest.rank,
    };
  }

  /* The attack classes, and the ONE property that matters to the design: `travel`.
   * ⛔ travel === 0 is the commit-before-fire class. The candidate model measured that reading is
   * worth 0.80x (i.e. WORSE than useless) when nothing in the mix is instant, and 2.57x at a 0.35
   * share. These numbers are the reason the game exists in this shape, so the table lives beside
   * the derivation rather than in the renderer. */
  const ATTACK = {
    beam: { windup: 50, travel: 0, width: 26, damage: 1, colour: '#ff4fd8' },
    /* ⚠️ `aimed` travel was 46 and it was doing 87% of ALL damage to a bot that could read every
     * telegraph in the game — MEASURED over 24 runs. It locks onto the player's column at the fire
     * frame, so its whole dodge window IS its travel time, and at 46 frames from a hull sitting at
     * y~60 the shot reached the player's row in about half a second. At 62 it is a reaction test,
     * which is the job this class exists to do; the beam remains the class reaction cannot answer. */
    aimed: { windup: 45, travel: 62, width: 7, damage: 1, colour: '#ffd23f' },
    spread: { windup: 55, travel: 52, width: 30, damage: 1, colour: '#4fe3ff' },
    mine: { windup: 40, travel: 90, width: 18, damage: 1, colour: '#7cff62' },
  };

  /** deterministic rng, shared so a seed means the same run in the game and in the harness. */
  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /**
   * Generate a ship. The pods a hull may carry are bounded by its MOUNT COUNT, so the constraint
   * runs from the art to the behaviour and never the other way: there is no ship whose attacks the
   * sprite could not show.
   */
  function generate(manifest, seed, opts) {
    opts = opts || {};
    const rnd = mulberry32(seed);
    const instantShare = opts.instantShare == null ? 0.35 : opts.instantShare;
    const hullNames = opts.hullPool || Object.keys(manifest.hulls);
    const wingNames = Object.keys(manifest.wings);
    const crestNames = Object.keys(manifest.crests);
    const engineNames = manifest.engineNames;
    const byClass = manifest.podsByClass;

    const hull = hullNames[Math.floor(rnd() * hullNames.length)];
    const mounts = manifest.hulls[hull].mounts;
    const nPods = 1 + Math.floor(rnd() * mounts);
    const pods = [];
    for (let i = 0; i < nPods; i++) {
      const cls = rnd() < instantShare ? 'beam' : ['aimed', 'spread', 'mine'][Math.floor(rnd() * 3)];
      const pool = byClass[cls];
      pods.push({ motif: pool[Math.floor(rnd() * pool.length)], mount: i });
    }
    const spec = {
      hull: hull,
      wing: wingNames[Math.floor(rnd() * wingNames.length)],
      engine: engineNames[Math.floor(rnd() * engineNames.length)],
      crest: crestNames[Math.floor(rnd() * crestNames.length)],
      pods: pods,
    };
    return { spec: spec, stats: derive(manifest, spec) };
  }

  return { derive: derive, generate: generate, ATTACK: ATTACK, mulberry32: mulberry32 };
}));
