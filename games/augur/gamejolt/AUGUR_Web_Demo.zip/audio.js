/* ================================================================================================
 * audio.js — AUGUR's sound. Two completely separate paths, and the separation is not stylistic.
 * ================================================================================================
 * ⛔ THE MUSIC IS A BARE <audio> ELEMENT AND NEVER ENTERS THE WEBAUDIO GRAPH. Wing §2a, measured
 * on GLASSWRIGHT: the textbook shape — `crossOrigin='anonymous'` then `createMediaElementSource` so
 * the track obeys a master gain — fails on `file://` in real Chromium, and it fails in the PAID
 * DOWNLOAD ONLY while the http-served free demo sounds perfect. Two hazards at once: setting
 * `crossOrigin` turns a plain media load into a CORS request a `file://` origin can never satisfy,
 * and even without it Chrome treats every `file://` document as an OPAQUE origin, so feeding the
 * element into the graph yields a tainted node and silence. Backwards, invisible to an iframe
 * probe, and exactly the shape master §2b calls a local fix that is not a published fix.
 *
 * ✅ So: music plays through `el.volume`, SFX are synthesised in-process through WebAudio (no origin
 * to be wrong about), and THE MUTE CONTROL MUST DRIVE BOTH EXPLICITLY — the master gain cannot
 * reach the music. That line is written in the same file as the decision, because §2a records that
 * forgetting it stops mute working for music only, silently.
 *
 * ⚠️ NO AUTOPLAY. Browsers refuse audio before a gesture and an itch embed is the strictest case of
 * it, so nothing sounds until `unlock()` is called from a real key or touch (§1b).
 *
 * LICENCE: every note is CSAF's own, composed as data in Internal_Ops/Audio/compose.js and rendered
 * by oscillator; every SFX is synthesised here from code. No sample, no soundfont, no AI music
 * service — so no attribution is owed and itch's Gen-AI audio tag does not apply (master §4.1).
 * ---------------------------------------------------------------------------------------------- */
'use strict';

var AugurAudio = (function () {
  var ctx = null;
  var master = null;
  var muted = false;
  var unlocked = false;
  var tracks = {};            // name -> HTMLAudioElement
  var meta = {};              // name -> { seconds, loopEnd }
  var current = null;         // the looping element currently playing
  /* ⛔ A REFUSED play() MUST LEAVE A NAME BEHIND. Browsers reject `play()` outside a user gesture,
   * and the idiomatic `.catch(function(){})` throws that away — so a game with no sound and a game
   * whose sound is merely gated look IDENTICAL from every instrument, including this file's own
   * state accessor. Master §2b: a silent refusal is correct behaviour that cannot be told apart
   * from a failure. Name it. MEASURED: a scripted unlock reported `paused: true, currentTime: 0`
   * with no explanation anywhere, and only a real key press separated the two stories. */
  var lastPlayError = null;
  var MUSIC_GAIN = 0.62;
  var STORE_KEY = 'augur.muted';

  try { muted = window.localStorage.getItem(STORE_KEY) === '1'; } catch (e) { muted = false; }

  /* ---------------------------------------------------------------- SFX: synthesised in process */
  function ensureCtx() {
    if (ctx) return ctx;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = muted ? 0 : 0.5;
    master.connect(ctx.destination);
    return ctx;
  }

  /** one voice: an oscillator or a noise burst through a shaped gain. */
  function blip(o) {
    if (!unlocked || muted) return;
    var c = ensureCtx();
    if (!c) return;
    var t0 = c.currentTime;
    var g = c.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, o.gain), t0 + (o.attack || 0.005));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
    var node;
    if (o.noise) {
      var n = Math.floor(c.sampleRate * o.dur);
      var buf = c.createBuffer(1, n, c.sampleRate);
      var d = buf.getChannelData(0);
      /* a deterministic-ish shaped noise: brighter at the head, so a hit reads as an impact */
      for (var i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
      node = c.createBufferSource();
      node.buffer = buf;
      var bp = c.createBiquadFilter();
      bp.type = o.filter || 'bandpass';
      bp.frequency.value = o.freq;
      bp.Q.value = o.q == null ? 1.1 : o.q;
      node.connect(bp); bp.connect(g);
    } else {
      node = c.createOscillator();
      node.type = o.wave || 'square';
      node.frequency.setValueAtTime(o.freq, t0);
      if (o.to) node.frequency.exponentialRampToValueAtTime(Math.max(20, o.to), t0 + o.dur);
      node.connect(g);
    }
    g.connect(master);
    node.start(t0);
    node.stop(t0 + o.dur + 0.02);
  }

  /* ⭐ THE SFX BANK IS A TABLE, AND ITS KEYS ARE THE GAME'S EVENT NAMES. game.js emits events and
   * knows nothing about sound; this file turns them into noise. That is what lets a headless test
   * count "did the game ask for a beam-warning cue" without an audio device existing. */
  var BANK = {
    shoot:      function () { blip({ wave: 'square',   freq: 880,  to: 660,  dur: 0.05, gain: 0.055 }); },
    enemyhit:   function () { blip({ noise: true,      freq: 2600, dur: 0.045, gain: 0.05, q: 0.8 }); },
    kill:       function () { blip({ noise: true,      freq: 900,  dur: 0.22, gain: 0.17, filter: 'lowpass', q: 0.7 }); },
    /* the warning cue is the audible half of the telegraph — the beam gets its own rising tone,
     * because a beam is the one attack reaction cannot answer (DESIGN.md §4d). */
    windup:     function (e) {
      if (e && e.cls === 'beam') blip({ wave: 'sawtooth', freq: 210, to: 720, dur: 0.55, gain: 0.075 });
      else blip({ wave: 'triangle', freq: 300, to: 380, dur: 0.16, gain: 0.045 });
    },
    fire:       function (e) {
      if (e && e.cls === 'beam') blip({ noise: true, freq: 1500, dur: 0.30, gain: 0.20, filter: 'bandpass', q: 0.5 });
      else blip({ wave: 'square', freq: 300, to: 170, dur: 0.09, gain: 0.07 });
    },
    playerhit:  function () { blip({ noise: true, freq: 420, dur: 0.42, gain: 0.30, filter: 'lowpass', q: 0.6 }); },
    salvage:    function () { blip({ wave: 'triangle', freq: 700, to: 1320, dur: 0.13, gain: 0.11 }); },
    bosspod:    function () { blip({ noise: true, freq: 700, dur: 0.34, gain: 0.22, filter: 'lowpass', q: 0.6 }); },
    bosssection: function () { blip({ noise: true, freq: 380, dur: 0.65, gain: 0.30, filter: 'lowpass', q: 0.5 }); },
    wavecleared: function () { blip({ wave: 'triangle', freq: 520, to: 880, dur: 0.20, gain: 0.09 }); },
  };

  function sfx(kind, e) { var f = BANK[kind]; if (f) f(e); }

  /* ---------------------------------------------------------------- music: bare elements */
  function load(manifest, base) {
    meta = {};
    (manifest.tracks || []).forEach(function (t) {
      meta[t.name] = { seconds: t.seconds, loopEnd: t.loopEnd };
      var el = new Audio();
      /* ⛔ NO `crossOrigin` HERE. See the header — setting it is what produced a CORS failure on
       * file:// and a silent paid build. */
      el.src = base + t.name + '.ogg';
      el.preload = 'auto';
      el.volume = muted ? 0 : MUSIC_GAIN;
      tracks[t.name] = el;
    });
  }

  /** A looping cue. The .ogg was BAKED so its last sample meets its first (compose.js). */
  function playMusic(name) {
    var el = tracks[name];
    if (!el) return false;
    if (current === el && !el.paused) return true;
    stopMusic();
    el.loop = true;
    el.currentTime = 0;
    el.volume = muted ? 0 : MUSIC_GAIN;
    current = el;
    if (unlocked) { var p = el.play(); if (p && p.catch) p.catch(function (err) { lastPlayError = String(err && err.name || err); }); }
    return true;
  }

  /** A one-shot. NOT baked, because baking a sting smears its ending over its opening (§0z). */
  function sting(name) {
    var el = tracks[name];
    if (!el) return false;
    stopMusic();
    el.loop = false;
    el.currentTime = 0;
    el.volume = muted ? 0 : MUSIC_GAIN;
    current = el;
    if (unlocked) { var p = el.play(); if (p && p.catch) p.catch(function (err) { lastPlayError = String(err && err.name || err); }); }
    return true;
  }

  function stopMusic() {
    if (current) { try { current.pause(); current.currentTime = 0; } catch (e) { /* ignore */ } }
    current = null;
  }

  /* ---------------------------------------------------------------- gating and mute */
  function unlock() {
    if (unlocked) return;
    unlocked = true;
    var c = ensureCtx();
    if (c && c.state === 'suspended') c.resume();
    if (current && !muted) { var p = current.play(); if (p && p.catch) p.catch(function (err) { lastPlayError = String(err && err.name || err); }); }
  }

  /* ⛔ MUTE MUST DRIVE BOTH PATHS. The master gain cannot reach the music, because the music was
   * deliberately kept out of the graph — so a mute that only touches `master` leaves the score
   * playing, and it does so silently enough that nobody notices until a buyer does. */
  function setMuted(v) {
    muted = !!v;
    if (master) master.gain.value = muted ? 0 : 0.5;
    Object.keys(tracks).forEach(function (k) { tracks[k].volume = muted ? 0 : MUSIC_GAIN; });
    if (muted) { if (current) { try { current.pause(); } catch (e) { /* ignore */ } } }
    else if (current && unlocked) { var p = current.play(); if (p && p.catch) p.catch(function (err) { lastPlayError = String(err && err.name || err); }); }
    try { window.localStorage.setItem(STORE_KEY, muted ? '1' : '0'); } catch (e) { /* ignore */ }
    return muted;
  }
  function isMuted() { return muted; }
  function toggleMute() { return setMuted(!muted); }

  return {
    load: load, sfx: sfx, playMusic: playMusic, sting: sting, stopMusic: stopMusic,
    unlock: unlock, setMuted: setMuted, isMuted: isMuted, toggleMute: toggleMute,
    _bank: BANK, _meta: function () { return meta; },
    /* ⚠️ AN AUDIO LAYER THAT CANNOT BE INSPECTED CANNOT BE MEASURED, AND §1.1b REQUIRES IT TO BE.
     * These elements are created with `new Audio()` and never attached to the document, so
     * `querySelectorAll('audio')` finds nothing and a probe written the obvious way reports zero
     * elements and zero playback on a game that is playing perfectly — a false RED, which costs the
     * same as a false green. Read-only accessors, no behaviour. */
    _tracks: function () { return tracks; },
    _state: function () {
      return { unlocked: unlocked, muted: muted, lastPlayError: lastPlayError,
        current: current ? current.src.split('/').pop() : null,
        currentTime: current ? +current.currentTime.toFixed(2) : 0, paused: current ? current.paused : null,
        looping: current ? current.loop : null, volume: current ? current.volume : null };
    },
  };
}());

if (typeof module === 'object' && module.exports) module.exports = AugurAudio;
