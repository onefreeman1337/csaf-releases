/* GENERATED from audio/tracks.json by Internal_Ops/make_loadable.js — do not edit.
 * sourceSha256 75527a6acfa23e3a70b67f52c662e6d316268ee3d7d95ece4a4a794cb0e5aceb
 * WHY: the paid build is a zip a buyer opens from file://, where fetch() is blocked. Loading
 * this as a <script> makes the http demo and the local download the same program. */
window.AUGUR_TRACKS = {
  "what": "AUGUR score. CSAF original, composed as note data and rendered by oscillator.",
  "licence": "CSAF owns this outright. No sample, no soundfont, no AI music service — so no attribution is owed and itch's Gen-AI audio tag does NOT apply (master §4.1).",
  "tailSeconds": 1.6,
  "renderedAt": "2026-09-04T06:22:09.586Z",
  "tracks": [
    {
      "name": "mus_flight",
      "title": "What It Is Wearing",
      "seconds": 50.526,
      "loopEnd": 50.526
    },
    {
      "name": "mus_boss",
      "title": "The One That Does Not Come Apart",
      "seconds": 34.286,
      "loopEnd": 34.286
    },
    {
      "name": "mus_clear",
      "title": "Read And Answered",
      "seconds": 8.457,
      "loopEnd": 6.86
    },
    {
      "name": "mus_down",
      "title": "Come Apart",
      "seconds": 10.489,
      "loopEnd": 8.89
    }
  ]
};
