//=================================================================================================
// SpecieScene.js
//=================================================================================================
/*:
 * @target MZ
 * @plugindesc [Specie] The purse: your party's gold drawn as struck coins, in a cabinet tray, each piece its own object. Requires the other Specie files.
 * @author Core Systems Asset Factory
 *
 * @param openKey
 * @text Open with key
 * @desc A key the player can press on the map to open the purse. Leave blank for none.
 * @type select
 * @option (none)
 * @value
 * @option pageup
 * @value pageup
 * @option pagedown
 * @value pagedown
 * @option shift
 * @value shift
 * @default
 *
 * @param circulation
 * @text Circulation
 * @desc How old the money in this realm is. Every setting still mixes ages: a purse is never one coin repeated.
 * @type select
 * @option A working currency - every age in one purse
 * @value mixed
 * @option A new coinage - recently struck, lightly handled
 * @value fresh
 * @option An old coinage - long in circulation
 * @value ancient
 * @default mixed
 *
 * @param title
 * @text Heading
 * @desc The heading drawn at the top of the scene. The realm's own name is drawn beneath it.
 * @type string
 * @default THE PURSE
 *
 * @param quality
 * @text Mint quality
 * @desc How careful this realm's mint is. Low means more off-centre and double-struck pieces. 0 to 100.
 * @type number
 * @min 0
 * @max 100
 * @default 55
 *
 * @command openPurse
 * @text Open the purse
 * @desc Pushes the purse scene.
 *
 * @command close
 * @text Close the purse
 * @desc Pops back, if the purse is the active scene.
 *
 * @command setRealm
 * @text Name the realm
 * @desc Overrides the realm this coinage is struck by. Changes every device, metal and legend. Saved.
 *
 * @arg realm
 * @text Realm name
 * @type string
 * @default
 *
 * @command clearRealm
 * @text Clear the realm override
 * @desc Goes back to reading the realm out of the project's own data.
 *
 * @command setDebased
 * @text Debase the coinage
 * @desc ON strikes the whole ladder in base metal - iron up to silver - instead of copper up to gold. Saved.
 *
 * @arg debased
 * @text Debased
 * @type boolean
 * @default true
 *
 * @help
 * SpecieScene.js
 * =============================================================================
 * The buyer-facing half of Specie. Everything on this screen is drawn by the
 * plugin at runtime: there is not one image file in this product.
 *
 * WHAT IT SHOWS
 *   - a TRAY: a coin cabinet with a well per physical piece, holding the money
 *     the party is actually carrying, made up out of this realm's denominations
 *   - a PLATE: the selected piece struck large, OBVERSE AND REVERSE side by
 *     side, with its legend, its metal, its flan and how worn it is
 *   - a READING: what produced this piece, in the realm's own terms
 *
 * CONTROLS
 *   arrows           move through the tray
 *   ok               nothing destructive; re-centres the plate
 *   cancel           leave
 *
 * OPENING IT
 *   Plugin command "Open the purse", or SceneManager.push(Scene_Specie).
 *
 * WHAT IT DOES NOT DO, ON PURPOSE
 *   Specie owns the OBJECT, never the VALUE. It reads $gameParty.gold() and
 *   never writes it, adds no currency conversion, no shop scene and no popup.
 *   Keep your gold display plugin: this is the part that draws the coin.
 *
 * COMPATIBILITY
 *   This file adds a scene and extends Scene_Map.updateScene by SAVED-ORIGINAL
 *   prototype extension, calling through in every case. It replaces no core
 *   method, so it co-exists with plugins that patch the same seams. It stores
 *   its two saved settings in a plain slot on $gameSystem, created lazily, so a
 *   save made before this plugin was installed loads without migration.
 *
 * =============================================================================
 * GATE 1 IS THE POINT OF THIS FILE, SO THE REASONING IS HERE RATHER THAN IN A
 * DEVLOG NOBODY READS AT THE STOREFRONT.
 *
 * Wing 1.1a: a screenshot mistakable for stock RPG Maker FAILS, and that is a
 * blocking gate. So:
 *
 *  - NOT ONE `Window_Base`. The scene is `Scene_Base` plus three Sprites the
 *    plugin draws into, which makes `windowsDrawn: 0` true BY CONSTRUCTION
 *    rather than by care. A windowskin cannot reach the screen without a Window.
 *
 *  - AND `windowsDrawn: 0` IS BLIND TO `Sprite_Button` (wing 15). MZ's touch-UI
 *    controls are Sprites, and three of them hang off a plain `Sprite` reachable
 *    through no scene property at all, so naming the properties does not work
 *    and neither does `visible = false`. `stripEngineChrome` WALKS THE DISPLAY
 *    LIST and detaches every instance, and keeps the count so the in-engine
 *    probe can assert a positive control first.
 *
 *  - AND IT IS BLIND TO THE FONT TOO (wing 15a). `$gameSystem.mainFontFace()` is
 *    the single loudest "this is RPG Maker" signal and no mechanical check in
 *    this factory has an opinion about a typeface. Both roles below are explicit
 *    stacks with real fallbacks and neither is ever `rmmz-mainfont`. This scene
 *    draws its text with `ctx.font` on its own 2D context rather than through
 *    `Bitmap.fontFace`, so GREP THIS FILE FOR `ctx.font` - every hit ends in
 *    FONT_DISPLAY or FONT_MONO and there is no third typeface in it.
 *
 *  - The layout is a cabinet drawer beside a catalogue plate, not a
 *    `Window_Selectable` grid, and the grid inside the drawer is SOLVED rather
 *    than typed (wing 18b).
 *
 * PER-FRAME COST. Wing doctrine: zero allocation in per-frame hot paths, draw
 * calls <= 60, display-object growth <= 4. A coin is hundreds of path
 * operations and the tray may show a dozen at once, so:
 *   - every drawn surface lives on ONE Bitmap redrawn only when the selection
 *     changes;
 *   - every coin is BAKED once through `SpecieRender.bake` and cached, then
 *     blitted;
 *   - `update` allocates nothing and creates no display object.
 * The display list is built entirely in `create()` and never grows.
 */

var SpecieScene = SpecieScene || {};

(function (X) {
    'use strict';

    // =============================================================================================
    // SIBLINGS, RESOLVED AT FIRST USE - NEVER AT LOAD TIME
    //
    // Wing 8 trap 2: `mz_harness build` loads the plugin folder ALPHABETICALLY, which is also what a
    // buyer gets for dragging files into the Plugin Manager in the wrong order. `SpecieScene` sorts
    // AFTER every sibling here except `SpecieStrike`, so a load-time capture would be `undefined`
    // for that one and the whole scene would no-op behind a single console line. The product ships
    // NO plugin_order.json on purpose (8 trap 2b) so the harness exercises the worst order every run.
    // =============================================================================================

    var _deps = null;
    function deps() {
        if (_deps) return _deps;
        if (typeof SpecieCoinage === 'undefined' || typeof SpecieDevices === 'undefined'
            || typeof SpecieMetals === 'undefined' || typeof SpecieFlan === 'undefined'
            || typeof SpecieLetters === 'undefined' || typeof SpecieStrike === 'undefined'
            || typeof SpecieRender === 'undefined') return null;
        _deps = {
            C: SpecieCoinage, D: SpecieDevices, M: SpecieMetals, F: SpecieFlan,
            L: SpecieLetters, S: SpecieStrike, R: SpecieRender
        };
        return _deps;
    }
    X.deps = deps;

    // ---- parameters -----------------------------------------------------------------------------
    // Blank means ABSENT, never 0 and never false: `Number('')` is 0, not NaN (wing 16). And `"0"`
    // is TRUTHY, which is how Augury's headline feature was disabled with every headless check
    // green, so a number is coerced and compared rather than tested for truthiness.

    function str(v) {
        return (v === undefined || v === null || String(v).trim() === '') ? null : String(v).trim();
    }
    function num(v, dflt) {
        var s = str(v);
        if (s === null) return dflt;
        var n = Number(s);
        return isFinite(n) ? n : dflt;
    }
    function bool(v, dflt) {
        var s = str(v);
        if (s === null) return dflt;
        return s === 'true' || s === 'on' || s === '1';
    }

    var _params = null;
    function params() {
        if (_params) return _params;
        var p = {};
        if (typeof PluginManager !== 'undefined' && PluginManager.parameters) {
            p = PluginManager.parameters('SpecieScene') || {};
        }
        var circ = str(p.circulation);
        _params = {
            openKey: str(p.openKey),
            circulation: (circ && X.CIRCULATIONS[circ]) ? circ : 'mixed',
            title: str(p.title) || 'THE PURSE',
            // 0 is a legitimate value here - the sloppiest mint - so it is coerced and clamped,
            // never defaulted away by a truthiness test.
            quality: Math.max(0, Math.min(1, num(p.quality, 55) / 100))
        };
        return _params;
    }
    X.params = params;
    /** Test seam: forget the cached parameter block so a probe can vary it. */
    X.resetParams = function () { _params = null; };

    // =============================================================================================
    // TYPOGRAPHY - wing 15a. Two roles, two explicit stacks, never the engine's font.
    //
    // A serif display face because a coin catalogue is set in one, and this whole product is a
    // catalogue plate. The mono carries VALUES and MEASUREMENTS - denominations, weights, stage
    // readings - where a proportional face makes a column of figures ragged.
    // =============================================================================================

    var FONT_DISPLAY = 'Georgia, "Iowan Old Style", "Palatino Linotype", Palatino, '
                     + '"Book Antiqua", serif';
    var FONT_MONO = 'Consolas, "SF Mono", Menlo, "DejaVu Sans Mono", "Courier New", monospace';
    X.FONT_DISPLAY = FONT_DISPLAY;
    X.FONT_MONO = FONT_MONO;

    // =============================================================================================
    // THE PALETTE - a cabinet in dark stained oak, wells lined in oxblood felt, brass fittings.
    //
    // Every ink is picked against WHAT IT SITS ON (wing 22e), and where a mark has to be READ the
    // separation is stated absolutely rather than as a multiplier (22e-1). Nothing in this file
    // types a colour string.
    // =============================================================================================

    var C = {
        wood:     [46, 34, 26],       // the cabinet carcass
        woodDeep: [28, 20, 15],
        felt:     [74, 30, 30],       // the tray lining
        feltDeep: [48, 18, 19],
        card:     [232, 224, 205],    // the catalogue leaf
        cardEdge: [198, 186, 160],
        brass:    [178, 142, 76],
        brassDim: [116, 92, 48],
        ink:      [30, 26, 22],
        inkPale:  [104, 95, 82]
    };

    function css(c) { return 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')'; }
    X.css = css;
    // Exported so a probe can ask what a surface is SUPPOSED to be rather than sampling a pixel and
    // hoping it landed on bare ground. The in-engine arm that checks the pocket paints nothing under
    // a coin first used a reference pixel from inside the card, and on one layout that pixel landed
    // on the condition note - a false red from a fixture, not from the product.
    X.PALETTE = C;

    // =============================================================================================
    // THE CIRCULATION MODEL
    //
    // THIS IS THE WHOLE REASON THIS FILE EXISTS, AND IT IS A RECORDED FINDING RATHER THAN A DESIGN
    // PREFERENCE. `_probe/wear_ladder.js` renders twelve pieces of ONE issue - same realm,
    // denomination, metal and device - and its third sheet holds wear at ZERO. Looked at:
    //
    //     twelve mint pieces read as TWELVE VERY SIMILAR COINS.
    //
    // The die shifts a few pixels and one in six is visibly double struck, and a player would still
    // call them the same coin. So THE STRIKE AXIS ALONE DOES NOT CARRY THE PRODUCT'S PROMISE, and a
    // project that declares no ages would get a near-uniform purse. That is wing 21i exactly: the
    // corpus size is what the product COULD make, and what a buyer sees is what their own data
    // RESOLVES to.
    //
    // THE FIX IS NOT TO RAISE THE STRIKE MAGNITUDES. That is wing 14a's trap - raising the wear
    // until the metric separates, obeying the symptom and making the picture worse while the number
    // improves. An off-centre strike of a quarter of the flan does not read as "hand struck", it
    // reads as a rendering bug.
    //
    // The fix is that A CIRCULATING CURRENCY IS A MIXTURE OF AGES. A purse holds coins struck across
    // decades, so the variety is real rather than manufactured, and it is the scene's job to know
    // that because the scene is the only thing that knows a purse exists.
    //
    // AND IT IS BUILT AS A CONSTRUCTION THAT CANNOT COLLAPSE, NOT AS INDEPENDENT DRAWS (wing 21g).
    // Song Sheets measured a work song falling to THREE DISTINCT PITCHES in fifteen notes while its
    // mean sat at 5.1 and every test was green: "anywhere a generator picks per-element from a small
    // vocabulary, the tail contains a degenerate case". Independent draws over five wear stages are
    // exactly that shape - the birthday problem 25g names - so the stage is not drawn at all. It
    // CYCLES through a shuffled enumeration of the stages, which makes n pieces occupy min(n, span)
    // DISTINCT stages arithmetically, with no distribution to have a tail.
    // =============================================================================================

    /**
     * The age bands a realm's money can sit in, as fractions of the stage table.
     *
     * Expressed as fractions rather than as stage indices so a change to `SpecieStrike.STAGES`
     * cannot desynchronise them (wing 11a: a second copy of a constant does not drift, it WINS).
     *
     * EVERY BAND SPANS AT LEAST THREE STAGES, and that is the load-bearing property rather than the
     * exact numbers: no setting of this parameter may produce a purse of one repeated coin, because
     * that is the defect the whole model exists to remove. `_probe/purse_spread.js` asserts it for
     * every declared value (wing 25f: "does this field move the picture" and "does each of its
     * VALUES" are different questions, and the first passes over a dead corpus).
     */
    X.CIRCULATIONS = {
        mixed:   { lo: 0.00, hi: 1.00, name: 'Working currency',
                   note: 'Struck across generations and still passing hand to hand.' },
        fresh:   { lo: 0.00, hi: 0.55, name: 'New coinage',
                   note: 'Recently struck. The oldest pieces are barely handled.' },
        ancient: { lo: 0.40, hi: 1.00, name: 'Old coinage',
                   note: 'Long in circulation. Little of it is younger than the last war.' }
    };

    /**
     * The stage indices a circulation band covers, derived from the live stage table.
     *
     * @param {string} id a key of X.CIRCULATIONS.
     * @returns {{from:number, to:number, span:number}}
     */
    X.band = function (id) {
        var d = deps();
        var n = d ? d.S.STAGES.length : 5;
        var b = X.CIRCULATIONS[id] || X.CIRCULATIONS.mixed;
        var from = Math.floor(b.lo * (n - 1));
        var to = Math.round(b.hi * (n - 1));
        if (to < from) to = from;
        return { from: from, to: to, span: to - from + 1 };
    };

    /**
     * The half-open wear interval a stage covers, read off the stage table itself.
     *
     * ONE READER OF THE STAGE BOUNDARIES. The table declares only each stage's `max`, so the floor
     * of stage i is the ceiling of stage i-1 and deriving it here means the two cannot disagree.
     *
     * @param {number} i
     * @returns {{lo:number, hi:number}}
     */
    X.stageRange = function (i) {
        var d = deps();
        if (!d) return { lo: 0, hi: 1 };
        var S = d.S.STAGES;
        var k = Math.max(0, Math.min(S.length - 1, i));
        var lo = k === 0 ? 0 : S[k - 1].max;
        var hi = Math.min(1, S[k].max);
        return { lo: lo, hi: hi < lo ? lo : hi };
    };

    /**
     * A step that walks every residue of `span` exactly once - a shuffled enumeration.
     *
     * Any step coprime with the span generates the whole cycle, so the pieces cannot bunch. Chosen
     * from the realm's own hash so two realms do not deal their ages in the same order, and it
     * falls back to 1 (which is coprime with everything) rather than to a random retry.
     *
     * @param {number} span
     * @param {number} h a hash.
     * @returns {number}
     */
    X.cycleStep = function (span, h) {
        function gcd(a, b) { while (b) { var t = a % b; a = b; b = t; } return a; }
        if (span < 2) return 1;
        var start = 1 + (Math.abs(h | 0) % (span - 1));
        for (var k = 0; k < span; k++) {
            var s = 1 + ((start - 1 + k) % (span - 1));
            if (gcd(s, span) === 1) return s;
        }
        return 1;
    };

    /**
     * How worn one physical piece is.
     *
     * TWO AXES, NEITHER OF WHICH CAN COLLAPSE, AND THEY ARE INDEPENDENT ON PURPOSE:
     *
     *   1. A BASE STAGE from the DENOMINATION, which is what spreads a purse holding exactly ONE
     *      piece of each denomination, where axis 2 is constant and cannot help.
     *
     *      ⚠️ IT IS A DIFFERENT STAGE, NOT RELIABLY AN OLDER ONE, AND THIS COMMENT USED TO CLAIM
     *      OTHERWISE. It said "monotonically across the whole band" - but the base is added to the
     *      realm's offset and taken MOD the span, and the wrap destroys monotonicity in the absolute
     *      stage. `scene.test.js` measured the smallest denomination at wear 0.09 against the
     *      largest at 0.14 and went red on my own sentence. Third time in this build that a doc
     *      comment asserted more than the code did (wing §22a-2e), and the honest claim is the one
     *      that survives measurement: the denominations are SPREAD across stages, and the
     *      "small change circulates harder" story is carried by axis 3, WITHIN a stage, where it is
     *      genuinely monotone and is asserted as such.
     *
     *   2. A CYCLING OFFSET from the piece's ORDINAL within its denomination, through a shuffled
     *      enumeration of the band. This is what stops twelve pieces of ONE denomination reading as
     *      one coin repeated, which is the case `wear_ladder.js` measured as failing.
     *
     * A small per-piece jitter is added last so two pieces sharing a stage AND a denomination still
     * differ, but it is deliberately the weakest term: it is variation, not the mechanism.
     *
     * The result is QUANTISED to two decimals, and that is not cosmetic - it is the cache key. One
     * number, one reader: if this rounded and the cache did not, the cache would key on a wear the
     * renderer never drew (wing 11a).
     *
     * @param {object} coinage from SpecieCoinage.coinage
     * @param {number} denomIndex 0 = smallest.
     * @param {number} ordinal which piece of that denomination this is, 0-based.
     * @param {string} circulation a key of X.CIRCULATIONS.
     * @returns {number} wear, 0..1, rounded to 0.01.
     */
    /**
     * How hard a denomination is used: 1 at the smallest, 0 at the largest.
     *
     * ONE READER. Both the stage choice and the position within that stage are statements about the
     * same fact, and a second copy of it would not drift, it would WIN (wing §11a).
     *
     * @param {object} coinage
     * @param {number} denomIndex
     * @returns {number} 0..1
     */
    X.useFor = function (coinage, denomIndex) {
        var count = coinage.pieces.length;
        return count > 1 ? (1 - denomIndex / (count - 1)) : 0.5;
    };

    /**
     * WHICH wear stage a piece sits in. Exported because it is half of a fact whose other half is
     * the wear number itself, and a suite has to be able to check the two agree.
     *
     * ⛔ THE ROUND TRIP IS AN INVARIANT, NOT A COINCIDENCE, AND THE FIRST CHECK OF IT WAS TOO WEAK.
     * It asserted the returned wear read back inside the BAND - but `mixed`'s band is the whole
     * stage table, so a wear that rounded one stage high was still inside it and the check could not
     * fail there at all. A sabotage removing the clamp stayed GREEN. The invariant that actually
     * matters is that `stage(wearFor(...))` is the stage THIS function chose, which is only
     * checkable because the choice is exported.
     *
     * @returns {number} an index into SpecieStrike.STAGES.
     */
    X.stageIndexFor = function (coinage, denomIndex, ordinal, circulation) {
        var d = deps();
        if (!d) return 0;
        var b = X.band(circulation);
        var h = d.C.hash(coinage.realm + '|circ|' + circulation);
        var step = X.cycleStep(b.span, h);
        var offset = h % b.span;
        var base = b.span > 1 ? Math.round(X.useFor(coinage, denomIndex) * (b.span - 1)) : 0;
        return b.from + ((base + ordinal * step + offset) % b.span);
    };

    X.wearFor = function (coinage, denomIndex, ordinal, circulation) {
        var d = deps();
        if (!d) return 0;
        // 1 at the smallest denomination, 0 at the largest: how hard this coin is used.
        var use = X.useFor(coinage, denomIndex);

        // ⛔ THE DENOMINATION MOVES THE STAGE, AND THE FIRST VERSION ONLY MOVED THE POSITION INSIDE
        // ONE. This function used to compute the stage from the ordinal alone and let the
        // denomination nudge the wear WITHIN that stage - and the doc comment claimed that was "what
        // spreads a purse holding exactly ONE piece of each denomination". MEASURED FALSE by
        // `_probe/purse_spread.js`: with every ordinal at 0 the cycling term is constant, so all
        // five denominations landed in ONE stage and three of the five were the same picture. A
        // within-stage nudge is below the resolution of the thing it was supposed to separate -
        // wing 22a-2e, a declared axis that does not reach the bitmap, with the axis's own
        // documentation asserting the opposite.
        //
        // A copper bit and a gold sovereign are not the same coin at slightly different wear. They
        // are in different CONDITION CLASSES, because small change passes through a hundred hands a
        // week while big money sits in a chest. So the denomination picks the base stage
        // MONOTONICALLY across the whole band, and the ordinal cycles on top of it.
        //
        // Both properties survive, which is why this shape and not another:
        //   - fixed denomination, varying ordinal -> adding a constant to a full cycle is still a
        //     full cycle, so several pieces of one denomination still visit every stage;
        //   - fixed ordinal, varying denomination -> the base walks the band monotonically, so a
        //     purse of one piece each is spread even though the cycling term cannot help.
        // Where a coinage has more denominations than the band has stages, two adjacent rungs share
        // a stage. That is honest rather than a defect: they really are in the same condition, and
        // the `use` term below still separates them inside it.
        var stage = X.stageIndexFor(coinage, denomIndex, ordinal, circulation);
        var r = X.stageRange(stage);

        var rng = d.S.rng(d.C.hash(coinage.realm + '|' + denomIndex + '|' + ordinal));
        var jitter = rng();
        var t = 0.62 * use + 0.30 * jitter + 0.08;
        if (t < 0) t = 0; else if (t > 1) t = 1;

        var w = r.lo + t * (r.hi - r.lo);
        if (w < 0) w = 0; else if (w > 1) w = 1;

        // ⛔ THE QUANTISED NUMBER MUST STILL READ BACK AS THE STAGE THIS FUNCTION CHOSE, AND THE
        // FIRST VERSION DID NOT. `SpecieStrike.stage` is half-open (`w < max`), so a wear that
        // rounds UP onto a boundary lands in the NEXT stage: a piece assigned Mint at t near 1
        // computed 0.0996, rounded to 0.10, and read back as Fine. MEASURED by
        // `_probe/purse_spread.js` as a five-stage cycle visiting only FOUR stages - the model was
        // choosing correctly and its own output disagreed with it.
        //
        // That is the two-readers defect (wing 11a) inside ONE function: the stage index and the
        // wear number are two statements of one fact, so the number is clamped back inside its own
        // stage rather than the round trip being left to luck. The probe now asserts the trip
        // directly, because a boundary bug is invisible everywhere except at the boundary.
        var q = Math.round(w * 100) / 100;
        var top = r.hi >= 1 ? 1 : Math.round((r.hi - 0.01) * 100) / 100;
        if (q > top) q = top;
        if (q < r.lo) q = Math.round(r.lo * 100) / 100;
        return q;
    };

    // =============================================================================================
    // THE PURSE
    //
    // Specie owns the OBJECT and never the VALUE (ARCHITECTURE 1). This reads `$gameParty.gold()`
    // and never writes it, and the change it makes is a DISPLAY fact: the same number, shown as the
    // pieces a person would actually be carrying. No conversion, no popup, no shop scene - all
    // three are occupied by structural incumbents and contesting one head-on is the error this wing
    // has never once got away with.
    // =============================================================================================

    /**
     * Break a sum into physical pieces of a coinage, largest first, as a purse actually is.
     *
     * A GREEDY WALK IS CORRECT HERE AND IT IS WORTH SAYING WHY. Greedy change-making is not optimal
     * for an arbitrary denomination set, and that does not matter: a person paying with coins does
     * not solve an optimisation, they hand over the biggest pieces they have. The remainder below
     * the smallest coin is reported rather than hidden, because a coinage whose base unit cannot
     * make change for the project's cheapest item is a fact about that project, not a rounding error.
     *
     * @param {object} coinage
     * @param {number} gold
     * @returns {{holdings:Array<{index:number,count:number}>, total:number, remainder:number}}
     */
    X.purse = function (coinage, gold) {
        var out = [];
        var left = Math.max(0, Math.floor(gold || 0));
        var total = 0;
        for (var i = coinage.pieces.length - 1; i >= 0; i--) {
            var v = coinage.pieces[i].value;
            var n = v > 0 ? Math.floor(left / v) : 0;
            if (n > 0) { left -= n * v; total += n; out.push({ index: i, count: n }); }
        }
        return { holdings: out, total: total, remainder: left };
    };

    /**
     * The physical pieces to lay in the tray.
     *
     * AN EMPTY TRAY IS A PRODUCT DEFECT, NOT AN EDGE CASE (wing 18b - a scene that wastes its frame
     * is a design defect and cropping cannot fix it). A stock MZ project starts the party with ZERO
     * gold, and wing 24a is the measured warning that most projects ship the stock database - so the
     * commonest first thing a buyer would ever see is an empty drawer. When the purse cannot fill
     * the tray the scene shows the COINAGE instead, one specimen of each denomination, and SAYS SO.
     * That is truthful in both directions: it is what the realm strikes, and the heading does not
     * claim the party is carrying it.
     *
     * @param {object} coinage
     * @param {number} gold
     * @param {number} capacity how many wells the tray has.
     * @param {string} circulation
     * @returns {{mode:string, pieces:Array<object>, hidden:number, purse:object}}
     */
    X.tray = function (coinage, gold, capacity, circulation) {
        // A missing sibling gives an EMPTY tray, never an array with holes in it: `X.physical`
        // cannot build a piece without the corpus, and a null in this list would surface as a crash
        // three functions away from its cause.
        if (!deps()) return { mode: 'unavailable', pieces: [], hidden: 0,
                              purse: { holdings: [], total: 0, remainder: 0 } };
        var p = X.purse(coinage, gold);
        var pieces = [];
        var hidden = 0;
        var cap = Math.max(1, capacity | 0);
        var i, j, h, rec;

        if (p.total > 0) {
            // Largest denomination first, so the drawer reads the way a cabinet is laid out.
            for (i = 0; i < p.holdings.length; i++) {
                h = p.holdings[i];
                for (j = 0; j < h.count; j++) {
                    if (pieces.length >= cap) { hidden++; continue; }
                    pieces.push(X.physical(coinage, h.index, j, circulation));
                }
            }
            return { mode: 'purse', pieces: pieces, hidden: hidden, purse: p };
        }

        for (i = coinage.pieces.length - 1; i >= 0 && pieces.length < cap; i--) {
            pieces.push(X.physical(coinage, i, 0, circulation));
        }
        rec = { mode: 'coinage', pieces: pieces, hidden: 0, purse: p };
        return rec;
    };

    /**
     * One physical coin: a denomination, which piece of it this is, and everything drawn from that.
     *
     * THE SERIAL IS THE ORDINAL AND NOTHING IS SAVED. A piece's identity is (realm, denomination,
     * ordinal), so the same purse always looks the same, spending money removes coins from the end
     * rather than reshuffling the drawer, and a save file carries no per-coin state at all. The
     * wing's quality bar asks for a deterministic RNG seam and a lossless save; this satisfies both
     * by having nothing to lose.
     *
     * @param {object} coinage
     * @param {number} index denomination index.
     * @param {number} ordinal
     * @param {string} circulation
     * @returns {object}
     */
    X.physical = function (coinage, index, ordinal, circulation) {
        var d = deps();
        if (!d) return null;
        var piece = coinage.pieces[index];
        var wear = X.wearFor(coinage, index, ordinal, circulation);
        return {
            index: index,
            ordinal: ordinal,
            piece: piece,
            wear: wear,
            stage: d ? d.S.stage(wear) : null,
            // The strike seed is the DIE's identity plus this piece's ordinal, so two pieces of one
            // issue are struck by the same die at different moments rather than being two issues.
            seed: (piece.seed ^ d.C.hash('piece|' + ordinal)) | 0
        };
    };

    // =============================================================================================
    // THE COINAGE THIS PROJECT WOULD HAVE STRUCK
    //
    // Wing 24a: A READING OF A BUYER'S PROJECT MUST SCORE ONLY WHAT THE BUYER CHANGED. Frontispiece
    // measured a house reading returning the SAME answer twelve times out of twelve because
    // System.json already contains Axe, Shield, Spear, Ice and Staff. `SpecieCoinage` does that
    // subtraction; this function's only job is to hand it every field a project might have renamed,
    // in a stable order, without reading anything the engine ships unchanged.
    // =============================================================================================

    /** Strings a project may have renamed. Order is fixed so the reading is deterministic. */
    function projectWords() {
        var out = [];
        function push(list, key) {
            if (!list) return;
            for (var i = 0; i < list.length; i++) {
                var v = list[i];
                if (v === null || v === undefined) continue;
                var s = key ? v[key] : v;
                if (typeof s === 'string' && s.length) out.push(s);
            }
        }
        if (typeof $dataSystem !== 'undefined' && $dataSystem) {
            push($dataSystem.elements);
            push($dataSystem.skillTypes);
            push($dataSystem.weaponTypes);
            push($dataSystem.armorTypes);
            push($dataSystem.equipTypes);
        }
        if (typeof $dataActors !== 'undefined') push($dataActors, 'name');
        if (typeof $dataClasses !== 'undefined') push($dataClasses, 'name');
        if (typeof $dataItems !== 'undefined') push($dataItems, 'name');
        if (typeof $dataWeapons !== 'undefined') push($dataWeapons, 'name');
        if (typeof $dataArmors !== 'undefined') push($dataArmors, 'name');
        return out;
    }

    /** Every price the project declares, so the denomination ladder is the project's own. */
    function projectPrices() {
        var out = [];
        function push(list) {
            if (!list) return;
            for (var i = 0; i < list.length; i++) {
                var v = list[i];
                if (v && typeof v.price === 'number' && v.price > 0) out.push(v.price);
            }
        }
        if (typeof $dataItems !== 'undefined') push($dataItems);
        if (typeof $dataWeapons !== 'undefined') push($dataWeapons);
        if (typeof $dataArmors !== 'undefined') push($dataArmors);
        return out;
    }

    var _coinage = null;
    var _coinageKey = '';

    /**
     * @returns {?object} the coinage, cached against the settings that can change it at runtime.
     */
    X.coinage = function () {
        var d = deps();
        if (!d) return null;
        var s = X.settings();
        var key = (s.realm || '') + '|' + (s.debased ? '1' : '0');
        if (_coinage && _coinageKey === key) return _coinage;
        var sys = (typeof $dataSystem !== 'undefined' && $dataSystem) ? $dataSystem : {};
        _coinage = d.C.coinage({
            // An explicit realm is fed in as the CURRENCY UNIT rather than written over the answer,
            // because `SpecieCoinage.realmWord` reads the currency unit first by design. One reader
            // of "what is this realm called", not two that have to agree (wing 11).
            title: sys.gameTitle || '',
            currencyUnit: s.realm || sys.currencyUnit || '',
            words: projectWords(),
            prices: projectPrices(),
            obverses: d.D.OBVERSE_IDS,
            reverses: d.D.REVERSE_IDS,
            flans: d.F.IDS,
            alphabets: d.L.IDS,
            debased: s.debased
        });
        _coinageKey = key;
        return _coinage;
    };
    /** Test seam, and what the plugin commands call after changing a setting. */
    X.invalidate = function () { _coinage = null; _coinageKey = ''; X.cacheClear(); };

    // =============================================================================================
    // SAVED SETTINGS
    //
    // A plain, enumerable slot on `$gameSystem`, created LAZILY on first read. Lazy creation is what
    // makes an old save load: there is no `initialize` extension to have missed, so a save written
    // before this plugin existed simply grows the slot the first time the purse is opened.
    //
    // Wing 13 is about the OPPOSITE case and is worth naming so the difference is deliberate: a
    // RUNTIME wrapper must be hidden with `enumerable: false` or `JsonEx` double-writes it. This is
    // genuine save data and is meant to be walked. The one thing that must never be saved - the
    // baked bitmap cache - lives in this closure and is not reachable from any game object at all,
    // so `JsonEx` cannot find it whatever it walks.
    // =============================================================================================

    X.SAVE_VERSION = 1;

    /**
     * @returns {{v:number, realm:?string, debased:boolean}}
     */
    X.settings = function () {
        if (typeof $gameSystem === 'undefined' || !$gameSystem) {
            return { v: X.SAVE_VERSION, realm: null, debased: false };
        }
        var s = $gameSystem._specie;
        if (!s || typeof s !== 'object') {
            s = { v: X.SAVE_VERSION, realm: null, debased: false };
            $gameSystem._specie = s;
        }
        // Forward migration. A slot from an older version keeps every field it had and gains the
        // defaults for the ones it did not, so a round trip through an old save is lossless.
        if (s.v !== X.SAVE_VERSION) {
            if (typeof s.realm === 'undefined') s.realm = null;
            if (typeof s.debased === 'undefined') s.debased = false;
            s.v = X.SAVE_VERSION;
        }
        return s;
    };

    // =============================================================================================
    // THE BAKED-COIN CACHE
    //
    // ARCHITECTURE 5: a coin is hundreds of path operations and a purse may show a dozen at once, so
    // a coin is baked ONCE and blitted. The cache is BOUNDED and evicts in INSERTION ORDER, which is
    // deterministic - an LRU would make what is in memory depend on where the player pointed, and a
    // capture would then not be reproducible.
    //
    // Every field in the key is a field the picture depends on. WEAR IS ALREADY QUANTISED BY
    // `wearFor`, so the key uses the same number the renderer is handed and cannot key on a wear
    // that was never drawn.
    // =============================================================================================

    X.CACHE_MAX = 48;
    var _cache = {};
    var _cacheOrder = [];

    X.cacheClear = function () { _cache = {}; _cacheOrder.length = 0; };
    X.cacheSize = function () { return _cacheOrder.length; };

    /**
     * @param {object} phys a physical piece from X.physical.
     * @param {string} side 'obverse' or 'reverse'.
     * @param {number} diameter px.
     * @param {object} coinage
     * @returns {?Bitmap}
     */
    X.coinBitmap = function (phys, side, diameter, coinage) {
        var d = deps();
        if (!d || typeof Bitmap === 'undefined') return null;
        var p = phys.piece;
        var dia = Math.max(8, Math.round(diameter));
        var id = side === 'reverse' ? p.reverse : p.obverse;
        var key = side + '|' + id + '|' + p.metal + '|' + p.flan + '|' + p.alphabet + '|'
                + coinage.legend + '|' + phys.wear + '|' + phys.seed + '|' + dia;
        if (_cache[key]) return _cache[key];

        var baked = d.R.bake(dia, {
            side: side,
            id: id,
            metal: p.metal,
            wear: phys.wear,
            flan: p.flan,
            // The obverse carries the realm; the reverse carries the denomination, which is what a
            // real coin does and what makes the two faces worth showing side by side.
            text: side === 'reverse' ? String(p.name).toUpperCase() : coinage.legend,
            alphabet: p.alphabet,
            seed: phys.seed,
            quality: params().quality
        });
        var bmp = new Bitmap(baked.size, baked.size);
        bmp.context.drawImage(baked.canvas, 0, 0);
        // `Bitmap.prototype._setDirty` is MV; MZ's seam is the base texture (wing 8).
        if (bmp._baseTexture && bmp._baseTexture.update) bmp._baseTexture.update();
        bmp.specieReport = baked.report;

        if (_cacheOrder.length >= X.CACHE_MAX) {
            var oldest = _cacheOrder.shift();
            delete _cache[oldest];
        }
        _cache[key] = bmp;
        _cacheOrder.push(key);
        return bmp;
    };

    // =============================================================================================
    // DRAWING HELPERS
    // =============================================================================================

    /** `arcTo` throws on a negative radius - clamp it (wing 8 trap 3). */
    function roundRect(ctx, x, y, w, h, r) {
        var rr = Math.max(0, Math.min(r, w / 2, h / 2));
        ctx.beginPath();
        ctx.moveTo(x + rr, y);
        ctx.arcTo(x + w, y, x + w, y + h, rr);
        ctx.arcTo(x + w, y + h, x, y + h, rr);
        ctx.arcTo(x, y + h, x, y, rr);
        ctx.arcTo(x, y, x + w, y, rr);
        ctx.closePath();
    }

    /**
     * Fit text into a width by giving up SIZE, and say whether it worked.
     *
     * A FITTER THAT CAN FAIL TO FIT MUST SAY SO (wing 22f). The version of this that shipped
     * "SEVEN OF WAND" shrank to its minimum, returned a still-too-wide result, and the caller drew
     * it anyway. This reports, and every caller either accepts the smaller size or clips knowingly.
     */
    function fitText(ctx, text, maxW, px, font, minPx) {
        var size = Math.max(8, Math.round(px));
        var floor = Math.max(8, Math.round(minPx || px * 0.62));
        while (size >= floor) {
            ctx.font = '600 ' + size + 'px ' + font;
            if (ctx.measureText(text).width <= maxW) return { size: size, fitted: true };
            size -= 1;
        }
        ctx.font = '600 ' + floor + 'px ' + font;
        return { size: floor, fitted: false };
    }

    /**
     * A quarter-sawn oak grain band.
     *
     * THE PITCH IS DECLARED AND THE COUNT IS DERIVED (wing 22b-1a). Escutcheon declared `marks: 18`
     * for a whole bezel and got eighteen specks 39px apart, and all seven of its treatments rendered
     * as the same yellow rectangle. The right number of figures changes with the run they cover.
     */
    function grain(ctx, x, y, w, h, pitchPx, alpha) {
        var lines = Math.max(3, Math.round(h / Math.max(4, pitchPx)));
        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.strokeStyle = css(C.woodDeep);
        ctx.lineWidth = 1;
        for (var i = 1; i < lines; i++) {
            var yy = y + (h * i) / lines;
            ctx.beginPath();
            for (var k = 0; k <= 12; k++) {
                var t = k / 12;
                var xx = x + w * t;
                var wob = Math.sin(t * 5.2 + i * 1.7) * Math.max(1, h * 0.006);
                if (k === 0) ctx.moveTo(xx, yy + wob); else ctx.lineTo(xx, yy + wob);
            }
            ctx.stroke();
        }
        ctx.restore();
    }

    // =============================================================================================
    // THE SCENE
    // =============================================================================================

    // ONLY THE PROTOTYPE CHAIN IS CONDITIONAL, AND THE GUARD IS NOT DEFENSIVE PADDING.
    //
    // `Object.create(Scene_Base.prototype)` runs at LOAD time, so unguarded this file throws a
    // ReferenceError the moment it is read anywhere but inside a running MZ page - which would make
    // the whole product unloadable by the offline probes that judge it. ARCHITECTURE 4 is explicit
    // that the corpus must be renderable and diffable before a Bitmap exists, and the circulation
    // model above is pure arithmetic belonging to that half.
    //
    // The CLASS and every method on it are declared unconditionally, so there is no second code path
    // and nothing to re-indent; offline the chain is simply absent and the scene is not instantiable,
    // which is honest. It is deliberately NOT a stubbed `Scene_Base`: wing 3a measured 142 green
    // headless checks over a stub that implemented an engine method differently from the engine, and
    // a fixture that lies is the one thing nothing headless can catch.
    //
    // The hazard is the obvious one, named so nobody has to guess: a guard FALSE inside the engine
    // would ship a scene with no base class. In MZ `rmmz_scenes.js` loads before any plugin so it
    // cannot be false there - and `_probe/in_engine.js` asserts `window.Scene_Specie` really derives
    // from `Scene_Base` in the real runtime rather than trusting that sentence (wing 12.7: name the
    // symbol and print its type; a diagnostic that cannot fail is none).

    function Scene_Specie() { this.initialize.apply(this, arguments); }
    X.sceneUnavailable = null;
    if (typeof Scene_Base === 'undefined') {
        X.sceneUnavailable = 'Scene_Base is not defined: this is not a running RPG Maker MZ page.';
    } else {
        Scene_Specie.prototype = Object.create(Scene_Base.prototype);
        Scene_Specie.prototype.constructor = Scene_Specie;
    }
    X.Scene_Specie = Scene_Specie;

    Scene_Specie.prototype.initialize = function () {
        Scene_Base.prototype.initialize.call(this);
        this._index = 0;
        this._dirty = true;
        this._lastIndex = -1;
        this._chromeRemoved = null;
        // Pre-declared so `update` never builds an object. Wing doctrine: zero allocation in
        // per-frame hot paths - no literals, no .map/.filter/.slice in an update loop.
        this._trayCache = null;
        this._trayKey = '';
    };

    Scene_Specie.prototype.create = function () {
        Scene_Base.prototype.create.call(this);
        // ONE bitmap for every drawn surface, redrawn only when the selection changes.
        this._paper = new Sprite(new Bitmap(Graphics.width, Graphics.height));
        this.addChild(this._paper);
        // The two plate faces are BLITS of baked bitmaps, so they are their own sprites.
        this._obv = new Sprite();
        this._rev = new Sprite();
        this.addChild(this._obv);
        this.addChild(this._rev);
        // The display list is complete here and never grows. The gate's display-object GROWTH proxy
        // (<= 4) is about what a frame ADDS, and this scene adds nothing after create().
    };

    Scene_Specie.prototype.start = function () {
        Scene_Base.prototype.start.call(this);
        this.stripEngineChrome();
        this._dirty = true;
        this.refresh();
    };

    /**
     * Detach every stock touch-UI control in this scene's display list.
     *
     * NAMING THE PROPERTIES IS NOT ENOUGH AND NEITHER IS `visible = false` (wing 15). MZ's touch UI
     * is `Sprite_Button`, not `Window_Base`, so `windowsDrawn: 0` is blind to it; three of the
     * buttons hang off a plain `Sprite` reachable through no scene property at all, and
     * `Scene_Map.prototype.updateMenuButton` re-assigns visibility EVERY FRAME so a hide is undone
     * on frame 2. Walking the tree and removing the instances is the only thing that holds. The
     * count is kept so the in-engine probe can assert a POSITIVE CONTROL first - a one-arm probe
     * proves nothing.
     */
    Scene_Specie.prototype.stripEngineChrome = function () {
        var removed = [];
        function walk(node) {
            if (!node || !node.children) return;
            for (var i = node.children.length - 1; i >= 0; i--) {
                var child = node.children[i];
                if (typeof Sprite_Button !== 'undefined' && child instanceof Sprite_Button) {
                    removed.push(child._buttonType || 'button');
                    node.removeChild(child);
                    continue;
                }
                walk(child);
            }
        }
        walk(this);
        this._chromeRemoved = removed;
        return removed;
    };

    // ---- layout, derived from the screen ---------------------------------------------------------
    //
    // GEOMETRY IS ARITHMETIC - DERIVE IT AND ASSERT IT, NEVER EYEBALL IT (wing 22h, 18). `layout()`
    // is exported and the in-engine probe checks the bands tile the screen with no overlap and no
    // gap, so a later edit cannot silently push a band off the frame.

    Scene_Specie.prototype.layout = function () {
        var W = Graphics.width, H = Graphics.height;
        var pad = Math.round(W * 0.026);
        var headH = Math.round(H * 0.115);
        var bodyY = headH;
        var bodyH = H - headH - Math.round(pad * 0.6);
        var trayW = Math.round(W * 0.395);
        return {
            W: W, H: H, pad: pad,
            headX: pad, headY: 0, headW: W - pad * 2, headH: headH,
            trayX: pad, trayY: bodyY, trayW: trayW, trayH: bodyH,
            plateX: pad + trayW + pad,
            plateY: bodyY,
            plateW: W - (pad + trayW + pad) - pad,
            plateH: bodyH
        };
    };

    /**
     * Solve the tray grid rather than typing it (wing 18b).
     *
     * Glaze hard-coded `cols = 6` and left twelve vessels width-bound at 114px in rows 266px tall -
     * a third of the frame empty air, and the pots the smallest the layout could possibly make them.
     * Cropping cannot fix that. So: try every plausible column count, keep the one giving the
     * LARGEST well, and break ties on FEWEST EMPTY WELLS, because a half-populated last row argues
     * the purse is emptier than it is.
     *
     * @param {number} n how many pieces there are to lay out.
     * @returns {{cols:number, rows:number, cell:number, capacity:number}}
     */
    /** The usable interior of the drawer. ONE READER, so the grid and the capacity cannot disagree. */
    Scene_Specie.prototype.drawerBox = function () {
        var Lo = this.layout();
        var inset = Math.round(Lo.pad * 0.85);
        var labelH = Math.round(Lo.trayH * 0.10);
        return {
            inset: inset,
            labelH: labelH,
            w: Lo.trayW - inset * 2,
            h: Lo.trayH - inset * 2 - labelH        // the wells sit below the drawer label
        };
    };

    /**
     * The smallest well this scene will draw, DERIVED from the corpus rather than typed.
     *
     * `SpecieDevices.PURSE_PX` is the product's own declared "diameter in an item list - where most
     * of a device cannot exist", measured when the device corpus was authored: at that size ZERO of
     * the eighteen limbed devices keep every limb above the 5px resolution floor. A drawer well
     * smaller than that is a speck, not an object, and the whole promise of this scene is that a
     * purse holds objects.
     */
    Scene_Specie.prototype.minCell = function () {
        var d = deps();
        return d ? d.D.PURSE_PX : 32;
    };

    Scene_Specie.prototype.solveGrid = function (n) {
        var box = this.drawerBox();
        var floorCell = this.minCell();
        var want = Math.max(1, n | 0);
        var best = null;
        for (var cols = 1; cols <= 8; cols++) {
            var rows = Math.ceil(want / cols);
            var cell = Math.floor(Math.min(box.w / cols, box.h / rows) * 0.88);
            if (cell < floorCell) continue;
            var empty = cols * rows - want;
            if (!best || cell > best.cell || (cell === best.cell && empty < best.empty)) {
                best = { cols: cols, rows: rows, cell: cell, empty: empty };
            }
        }
        if (!best) {
            var c = Math.min(8, want);
            best = { cols: c, rows: Math.ceil(want / c), cell: floorCell, empty: 0 };
        }
        return { cols: best.cols, rows: best.rows, cell: best.cell };
    };

    /**
     * How many wells the drawer holds.
     *
     * ⛔ THIS WAS `solveGrid(1).capacity` AND IT WAS CIRCULAR, WHICH IS A DEFECT ONLY THE REAL ENGINE
     * COULD SHOW. `solveGrid` sizes the grid FOR A GIVEN PIECE COUNT, so asking it about ONE piece
     * gave one enormous 251px well and it then reported that exactly one well fits - and a
     * five-denomination coinage displayed a SINGLE specimen, with the selection unable to move
     * because `(0 + 1) % 1` is 0. The capacity depended on the cell size, which depended on the
     * count, which is the thing the capacity exists to decide.
     *
     * ⚠️ AND THE OFFLINE PROBE COULD NOT HAVE CAUGHT IT, because it passes `X.tray(..., 12, ...)`
     * with the capacity TYPED. A fixture that supplies the value under test proves only that the
     * rest of the function works - the same shape as a harness that only ever constructs one input
     * (master §2b). The number is now derived from the drawer and the resolution floor, and both
     * readers take the box from `drawerBox()` so they cannot drift (wing §11a).
     */
    Scene_Specie.prototype.capacity = function () {
        var box = this.drawerBox();
        var pitch = this.minCell() / 0.88;
        var cols = Math.max(1, Math.min(8, Math.floor(box.w / pitch)));
        var rows = Math.max(1, Math.floor(box.h / pitch));
        return cols * rows;
    };

    // ---- state -----------------------------------------------------------------------------------

    /**
     * The tray, computed once per (gold, settings) and reused.
     *
     * The key includes the gold, so spending money in a parallel event re-lays the drawer, and
     * nothing else can change it while the scene is open.
     */
    Scene_Specie.prototype.tray = function () {
        var d = deps();
        if (!d) return null;
        var coinage = X.coinage();
        if (!coinage) return null;
        var gold = (typeof $gameParty !== 'undefined' && $gameParty && $gameParty.gold)
            ? $gameParty.gold() : 0;
        var p = params();
        var key = gold + '|' + coinage.realm + '|' + p.circulation + '|' + this.capacity();
        if (this._trayCache && this._trayKey === key) return this._trayCache;
        this._trayCache = X.tray(coinage, gold, this.capacity(), p.circulation);
        this._trayCache.coinage = coinage;
        this._trayKey = key;
        return this._trayCache;
    };

    Scene_Specie.prototype.current = function () {
        var t = this.tray();
        if (!t || !t.pieces.length) return null;
        var i = Math.min(Math.max(this._index, 0), t.pieces.length - 1);
        return t.pieces[i];
    };

    // ---- update: allocates nothing ---------------------------------------------------------------

    Scene_Specie.prototype.update = function () {
        Scene_Base.prototype.update.call(this);
        this.processInput();
        if (this._dirty || this._index !== this._lastIndex) this.refresh();
    };

    Scene_Specie.prototype.processInput = function () {
        if (typeof Input === 'undefined') return;
        var t = this.tray();
        var n = t ? t.pieces.length : 0;
        if (!n) {
            if (Input.isTriggered('cancel')) this.popMe();
            return;
        }
        var g = this.solveGrid(n);
        if (Input.isRepeated('right')) { this._index = (this._index + 1) % n; }
        else if (Input.isRepeated('left')) { this._index = (this._index + n - 1) % n; }
        else if (Input.isRepeated('down')) { this._index = Math.min(n - 1, this._index + g.cols); }
        else if (Input.isRepeated('up')) { this._index = Math.max(0, this._index - g.cols); }
        else if (Input.isTriggered('ok')) { this._dirty = true; }
        else if (Input.isTriggered('cancel')) { this.popMe(); }
    };

    Scene_Specie.prototype.popMe = function () {
        if (typeof SceneManager !== 'undefined' && SceneManager.pop) {
            if (typeof SoundManager !== 'undefined' && SoundManager.playCancel) SoundManager.playCancel();
            SceneManager.pop();
        }
    };

    // ---- the redraw ------------------------------------------------------------------------------

    Scene_Specie.prototype.refresh = function () {
        var d = deps();
        this._lastIndex = this._index;
        this._dirty = false;
        if (!d) return;                                 // a missing sibling must not throw

        var Lo = this.layout();
        var bmp = this._paper.bitmap;
        var ctx = bmp.context;
        bmp.clear();

        var t = this.tray();
        this.drawCabinet(ctx, Lo);
        this.drawHead(ctx, Lo, t);
        this.drawTray(ctx, Lo, t);
        this.drawPlatePanel(ctx, Lo, t);

        if (bmp._baseTexture && bmp._baseTexture.update) bmp._baseTexture.update();
        this.placePlateFaces(Lo, t);
    };

    Scene_Specie.prototype.drawCabinet = function (ctx, Lo) {
        var g = ctx.createLinearGradient(0, 0, 0, Lo.H);
        g.addColorStop(0, css(C.wood));
        g.addColorStop(1, css(C.woodDeep));
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, Lo.W, Lo.H);
        grain(ctx, 0, 0, Lo.W, Lo.H, Math.round(Lo.H * 0.048), 0.30);
    };

    Scene_Specie.prototype.drawHead = function (ctx, Lo, t) {
        var coinage = t ? t.coinage : null;
        var p = params();

        ctx.fillStyle = css(C.brass);
        ctx.font = '600 ' + Math.round(Lo.headH * 0.30) + 'px ' + FONT_DISPLAY;
        ctx.fillText(p.title, Lo.headX, Lo.headY + Math.round(Lo.headH * 0.40));

        if (coinage) {
            var sub = t.mode === 'purse'
                ? 'STRUCK BY THE MINT OF ' + coinage.realm.toUpperCase()
                : 'THE COINAGE OF ' + coinage.realm.toUpperCase() + ' - THE PARTY CARRIES NONE OF IT';
            var f = fitText(ctx, sub, Lo.headW * 0.66, Math.round(Lo.headH * 0.155), FONT_MONO);
            ctx.font = f.size + 'px ' + FONT_MONO;
            ctx.fillStyle = css(C.inkPale);
            ctx.fillText(sub, Lo.headX, Lo.headY + Math.round(Lo.headH * 0.68));
        }

        // The total, right-aligned in the project's OWN currency unit. Specie never changes this
        // number and never converts it; it only draws what it is made of.
        if (typeof $gameParty !== 'undefined' && $gameParty && $gameParty.gold) {
            var unit = (typeof $dataSystem !== 'undefined' && $dataSystem && $dataSystem.currencyUnit)
                ? $dataSystem.currencyUnit : '';
            ctx.textAlign = 'right';
            ctx.fillStyle = css(C.card);
            ctx.font = '600 ' + Math.round(Lo.headH * 0.26) + 'px ' + FONT_MONO;
            ctx.fillText(String($gameParty.gold()) + ' ' + unit,
                Lo.headX + Lo.headW, Lo.headY + Math.round(Lo.headH * 0.40));
            if (t) {
                ctx.font = Math.round(Lo.headH * 0.145) + 'px ' + FONT_MONO;
                ctx.fillStyle = css(C.inkPale);
                var n = t.purse.total;
                var line = t.mode === 'purse'
                    ? (n + (n === 1 ? ' piece' : ' pieces')
                        + (t.hidden ? ' - ' + t.hidden + ' not shown' : ''))
                    : 'no pieces';
                ctx.fillText(line, Lo.headX + Lo.headW, Lo.headY + Math.round(Lo.headH * 0.68));
            }
            ctx.textAlign = 'left';
        }

        // A brass rule under the head, the full width, so the band closes.
        ctx.fillStyle = css(C.brassDim);
        ctx.fillRect(Lo.headX, Lo.headY + Lo.headH - 3, Lo.headW, 2);
    };

    /**
     * The cabinet drawer: one felt-lined well per physical piece.
     *
     * THIS BAND IS THE PRODUCT'S WHOLE ARGUMENT IN ONE GLANCE, and it is the thing the recorded
     * finding is about. Twelve pieces at wear zero read as twelve very similar coins; twelve pieces
     * whose ages come out of the circulation model read as a handful of money. A buyer looking at a
     * screenshot should be able to see, without being told, that no two of these are the same object.
     */
    Scene_Specie.prototype.drawTray = function (ctx, Lo, t) {
        // ONE READER OF THE DRAWER'S INTERIOR. This used to recompute the inset and the available
        // box for itself, which is the shape wing §11a warns about: a second copy of a constant does
        // not drift, it WINS, and a correct edit to the other copy changes nothing on screen.
        var box = this.drawerBox();
        var inset = box.inset;

        // The drawer: a recess in the carcass, lined in felt.
        roundRect(ctx, Lo.trayX, Lo.trayY, Lo.trayW, Lo.trayH, Math.round(Lo.pad * 0.35));
        var g = ctx.createLinearGradient(Lo.trayX, Lo.trayY, Lo.trayX, Lo.trayY + Lo.trayH);
        g.addColorStop(0, css(C.feltDeep));
        g.addColorStop(1, css(C.felt));
        ctx.fillStyle = g;
        ctx.fill();
        ctx.strokeStyle = css(C.brassDim);
        ctx.lineWidth = 2;
        ctx.stroke();

        var labelH = box.labelH;
        ctx.fillStyle = css(C.brass);
        ctx.font = Math.round(labelH * 0.44) + 'px ' + FONT_MONO;
        ctx.fillText(t && t.mode === 'coinage' ? 'THE COINAGE' : 'THE DRAWER',
            Lo.trayX + inset, Lo.trayY + inset + Math.round(labelH * 0.5));

        if (!t || !t.pieces.length) return;

        var n = t.pieces.length;
        var grid = this.solveGrid(n);
        var cellW = box.w / grid.cols;
        var cellH = box.h / grid.rows;
        var top = Lo.trayY + inset + labelH;

        for (var i = 0; i < n; i++) {
            var col = i % grid.cols, row = Math.floor(i / grid.cols);
            var cx = Lo.trayX + inset + cellW * (col + 0.5);
            var cy = top + cellH * (row + 0.5);
            var well = grid.cell * 0.62;

            // The well itself: a shadowed depression, so a coin sits IN the tray rather than on it.
            ctx.beginPath();
            ctx.arc(cx, cy, well, 0, Math.PI * 2);
            ctx.fillStyle = css(C.feltDeep);
            ctx.fill();
            ctx.strokeStyle = 'rgba(0,0,0,0.35)';
            ctx.lineWidth = Math.max(1, grid.cell * 0.03);
            ctx.stroke();

            var bmp = X.coinBitmap(t.pieces[i], 'obverse', grid.cell, t.coinage);
            if (bmp) {
                // Drawn straight onto the shared bitmap: these change only when the drawer is
                // re-laid, and giving each a Sprite would grow the display list with the buyer's
                // gold total.
                ctx.drawImage(bmp.canvas || bmp._canvas,
                    Math.round(cx - bmp.width / 2), Math.round(cy - bmp.height / 2));
            }

            if (i === this._index) {
                ctx.strokeStyle = css(C.brass);
                ctx.lineWidth = Math.max(2, grid.cell * 0.045);
                ctx.beginPath();
                ctx.arc(cx, cy, well + ctx.lineWidth, 0, Math.PI * 2);
                ctx.stroke();
            }
        }

        if (t.hidden) {
            ctx.fillStyle = css(C.brass);
            ctx.font = Math.round(labelH * 0.40) + 'px ' + FONT_MONO;
            ctx.textAlign = 'right';
            ctx.fillText('+' + t.hidden + ' more', Lo.trayX + Lo.trayW - inset,
                Lo.trayY + Lo.trayH - Math.round(inset * 0.5));
            ctx.textAlign = 'left';
        }
    };

    /**
     * Where the plate's two faces sit, and how big they are.
     *
     * ONE GEOMETRY, TWO READERS. The panel furniture and the sprite placement both call this, so a
     * caption cannot end up describing a coin that is somewhere else (wing 11a).
     */
    Scene_Specie.prototype.plateGeometry = function (Lo) {
        var d = deps();
        var pad = Math.round(Lo.pad * 0.9);
        var innerX = Lo.plateX + pad;
        var innerW = Lo.plateW - pad * 2;
        var headH = Math.round(Lo.plateH * 0.17);
        var footH = Math.round(Lo.plateH * 0.30);
        var midY = Lo.plateY + headH;
        var midH = Lo.plateH - headH - footH;
        var gap = Math.round(innerW * 0.055);
        // Two faces side by side, capped at the size the corpus is JUDGED at. Above that a coin
        // gains nothing and the card loses its margins.
        var wanted = Math.min((innerW - gap) / 2, midH * 0.86);
        var dia = Math.max(48, Math.min(d ? d.D.INSPECT_PX : 260, Math.floor(wanted)));
        return {
            innerX: innerX, innerW: innerW,
            headH: headH, footH: footH,
            cy: midY + Math.round(midH * 0.46),
            obvCX: Math.round(innerX + innerW / 2 - gap / 2 - dia / 2),
            revCX: Math.round(innerX + innerW / 2 + gap / 2 + dia / 2),
            dia: dia,
            capY: midY + Math.round(midH * 0.46) + Math.round(dia * 0.5) + Math.round(midH * 0.10),
            readY: Lo.plateY + Lo.plateH - Math.round(pad * 0.9)
        };
    };

    /**
     * The shadow a coin lying on the catalogue leaf casts, plus the faint impression of its rim.
     *
     * The offset is DOWN-RIGHT because `SpecieRender` reads every strike by one fixed light from the
     * upper left, and a shadow that disagreed with the relief would make the coin read as a sticker.
     * The radius is taken from the coin's own diameter so it cannot drift from what is blitted.
     *
     * @param {CanvasRenderingContext2D} ctx
     * @param {number} cx
     * @param {number} cy
     * @param {number} dia rendered diameter of the piece, px.
     */
    Scene_Specie.prototype.drawPocket = function (ctx, cx, cy, dia) {
        var r = dia * 0.5;
        var off = Math.max(2, dia * 0.022);

        // ⛔ THE SHADOW MUST NOT BE PAINTED UNDER THE COIN, AND THE FIRST VERSION WAS. A radial
        // gradient fills everything INSIDE its inner radius with the colour at stop 0, so a gradient
        // running from `r * 0.82` outward laid a translucent brown DISC across the whole piece. On a
        // solid flan that is invisible - the coin covers it - and on a PIERCED flan it showed
        // straight through the hole as a flat grey plug where the buyer should see the card.
        //
        // ⚠️ It was found by LOOKING at the in-engine capture, and only because that run happened to
        // roll a pierced coinage: on the previous run's flans the identical defect was there and
        // completely invisible. Wing §21b - "the code ran" and "the picture changed" are different
        // claims - and the tray was the control that proved the alpha was fine everywhere else,
        // because a piercing over dark red felt read correctly in the same frame.
        //
        // Clipped to the annulus OUTSIDE the coin's own radius, so nothing dark can land inside the
        // silhouette whatever the flan does with its middle.
        ctx.save();
        ctx.beginPath();
        ctx.arc(cx + off, cy + off, r * 1.14, 0, Math.PI * 2);
        ctx.arc(cx, cy, r, 0, Math.PI * 2, true);      // counterclockwise: punch the coin out
        ctx.clip('evenodd');
        var g = ctx.createRadialGradient(cx + off, cy + off, r * 0.96,
                                         cx + off, cy + off, r * 1.14);
        g.addColorStop(0, 'rgba(58,44,28,0.38)');
        g.addColorStop(1, 'rgba(58,44,28,0)');
        ctx.beginPath();
        ctx.arc(cx + off, cy + off, r * 1.14, 0, Math.PI * 2);
        ctx.fillStyle = g;
        ctx.fill();
        ctx.restore();
        // A hairline where the coin meets the paper, so even a pale metal has an edge to end at.
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(96,80,54,0.42)';
        ctx.lineWidth = Math.max(1, dia * 0.006);
        ctx.stroke();
    };

    Scene_Specie.prototype.drawPlatePanel = function (ctx, Lo, t) {
        var d = deps();
        // The catalogue leaf: the one light surface on screen.
        roundRect(ctx, Lo.plateX, Lo.plateY, Lo.plateW, Lo.plateH, Math.round(Lo.pad * 0.3));
        ctx.fillStyle = css(C.card);
        ctx.fill();
        ctx.strokeStyle = css(C.cardEdge);
        ctx.lineWidth = 2;
        ctx.stroke();

        var G = this.plateGeometry(Lo);
        var phys = this.current();
        if (!phys) {
            ctx.fillStyle = css(C.inkPale);
            ctx.font = Math.round(Lo.plateH * 0.045) + 'px ' + FONT_DISPLAY;
            ctx.fillText('This project declares no coinage.',
                G.innerX, Lo.plateY + Math.round(Lo.plateH * 0.5));
            return;
        }

        var p = phys.piece;

        // The name, fitted rather than assumed (wing 22f).
        var nf = fitText(ctx, p.name, G.innerW * 0.62, Math.round(Lo.plateH * 0.085), FONT_DISPLAY);
        ctx.font = '600 ' + nf.size + 'px ' + FONT_DISPLAY;
        ctx.fillStyle = css(C.ink);
        ctx.fillText(p.name, G.innerX, Lo.plateY + Math.round(G.headH * 0.62));

        // The value, right-aligned, in the project's own unit.
        var unit = (typeof $dataSystem !== 'undefined' && $dataSystem && $dataSystem.currencyUnit)
            ? $dataSystem.currencyUnit : '';
        ctx.textAlign = 'right';
        ctx.font = '600 ' + Math.round(Lo.plateH * 0.062) + 'px ' + FONT_MONO;
        ctx.fillStyle = css(C.brassDim);
        ctx.fillText(p.value + ' ' + unit, G.innerX + G.innerW, Lo.plateY + Math.round(G.headH * 0.62));
        ctx.textAlign = 'left';

        // ⛔ A COIN NEEDS A GROUND OR ITS EDGE DOES NOT EXIST, AND THIS WAS FOUND BY LOOKING AT THE
        // IN-ENGINE CAPTURE. Struck on the bare cream leaf, a GOLD piece has almost no silhouette -
        // gold and cream sit close in luminance - so the eye cannot find where the coin ends, and the
        // pale legend arcing near the rim reads as letters floating off the edge onto the card.
        //
        // ⚠️ THE OBVIOUS DIAGNOSIS WAS WRONG AND THE MEASUREMENT SAVED A CORRECT FUNCTION FROM BEING
        // "FIXED". It looked exactly like the legend radius being too large - wing §25c's bleed, and
        // that is a real defect this factory has shipped before. `_probe/legend_bleed.js` isolates it
        // per flan form against that form's own band-only counterfactual: the legend adds **0 px**
        // outside the flan on all six forms, with a squared planchet's corners at +36.2px proving the
        // detector can see a real excursion. So nothing was wrong with the geometry; what was wrong
        // was the GROUND, which is wing §22e - never pick an ink, or a surface, without asking what
        // it sits against.
        //
        // The pocket is a shadow and a faint rim, cast from the same upper-left light the strike
        // itself is read by, so the edge reads for every metal BY CONSTRUCTION rather than for the
        // metals that happened to be looked at.
        this.drawPocket(ctx, G.obvCX, G.cy, G.dia);
        this.drawPocket(ctx, G.revCX, G.cy, G.dia);

        // The two face captions, under the coins the sprites will be placed at.
        ctx.textAlign = 'center';
        ctx.font = Math.round(Lo.plateH * 0.040) + 'px ' + FONT_MONO;
        ctx.fillStyle = css(C.inkPale);
        ctx.fillText('OBVERSE', G.obvCX, G.capY);
        ctx.fillText('REVERSE', G.revCX, G.capY);
        ctx.textAlign = 'left';

        // The reading: what actually produced this piece. Mono, because it is a column of facts.
        var lh = Math.round(Lo.plateH * 0.046);
        var stage = phys.stage || (d ? d.S.stage(phys.wear) : null);
        var lines = [
            'METAL      ' + String(p.metal).toUpperCase(),
            'FLAN       ' + String(p.flan).toUpperCase(),
            'LETTERING  ' + String(p.alphabet).toUpperCase(),
            'CONDITION  ' + (stage ? stage.name.toUpperCase() : '')
        ];
        ctx.font = Math.round(lh * 0.66) + 'px ' + FONT_MONO;
        for (var m = 0; m < lines.length; m++) {
            ctx.fillStyle = css(C.inkPale);
            ctx.fillText(lines[m], G.innerX, G.readY - (lines.length - 1 - m) * lh - lh * 0.9);
        }

        // The condition note, in the display face: the one line on the card that is prose. It is
        // authored per stage in SpecieStrike, so the card cannot describe a condition the strike
        // model does not have.
        if (stage && stage.note) {
            var f = fitText(ctx, stage.note, G.innerW, Math.round(lh * 0.72), FONT_DISPLAY,
                Math.round(lh * 0.52));
            ctx.font = f.size + 'px ' + FONT_DISPLAY;
            ctx.fillStyle = css(C.ink);
            ctx.fillText(stage.note, G.innerX, G.readY);
        }

        // A wear scale: a shape, not a number (wing 8 - "what number is the whole point, and can it
        // be a shape instead?"). Five stops, one per declared stage, filled to where this piece is.
        if (d) {
            var stages = d.S.STAGES;
            var sx = G.innerX + G.innerW;
            var lz = Math.max(3, Math.round(Lo.plateH * 0.016));
            var idx = stages.indexOf(stage);
            for (var q = 0; q < stages.length; q++) {
                var bx = sx - (stages.length - 1 - q) * lz * 2.6;
                ctx.beginPath();
                ctx.arc(bx, G.readY - lh * 3.6, lz, 0, Math.PI * 2);
                ctx.fillStyle = (q <= idx) ? css(C.brass) : 'rgba(116,92,48,0.22)';
                ctx.fill();
            }
        }
    };

    /**
     * Blit the two baked faces onto the card.
     *
     * A baked coin carries its lighting round with it - Specie strikes under one fixed light from
     * the upper left - so neither face is ever rotated or mirrored. A mirrored coin would be lit
     * from the wrong side and a rotated one from below.
     */
    Scene_Specie.prototype.placePlateFaces = function (Lo, t) {
        var phys = this.current();
        if (!phys || !t) { this._obv.bitmap = null; this._rev.bitmap = null; return; }
        var G = this.plateGeometry(Lo);
        var o = X.coinBitmap(phys, 'obverse', G.dia, t.coinage);
        var r = X.coinBitmap(phys, 'reverse', G.dia, t.coinage);
        this._obv.bitmap = o;
        this._rev.bitmap = r;
        if (o) {
            this._obv.x = Math.round(G.obvCX - o.width / 2);
            this._obv.y = Math.round(G.cy - o.height / 2);
        }
        if (r) {
            this._rev.x = Math.round(G.revCX - r.width / 2);
            this._rev.y = Math.round(G.cy - r.height / 2);
        }
    };

    // =============================================================================================
    // ENGINE SEAMS - saved-original prototype extension, and it CALLS THROUGH.
    //
    // Wing 24c: a saved handle that is never invoked is a REPLACEMENT with a courtesy handle, and a
    // listing claiming "extends, co-exists" on that basis is FALSE. This genuinely extends, so
    // `compat_block.js` prints the honest sentence.
    // =============================================================================================

    if (typeof Scene_Map !== 'undefined' && Scene_Map.prototype.updateScene) {
        var _updateScene = Scene_Map.prototype.updateScene;
        Scene_Map.prototype.updateScene = function () {
            _updateScene.apply(this, arguments);          // apply(arguments), never call(a, b)
            var key = params().openKey;
            if (!key) return;
            if (typeof SceneManager === 'undefined' || SceneManager.isSceneChanging()) return;
            if (typeof Input !== 'undefined' && Input.isTriggered(key)) {
                SceneManager.push(Scene_Specie);
            }
        };
    }

    // =============================================================================================
    // PLUGIN COMMANDS - wing 24b: `mz_gate` reports NOT CLEAN when a product registers zero commands
    // and every run measures a stock MZ scene. The honest fix is to give the product the commands it
    // should have had anyway, never to edit the gate.
    // =============================================================================================

    if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
        PluginManager.registerCommand('SpecieScene', 'openPurse', function () {
            if (typeof SceneManager !== 'undefined') SceneManager.push(Scene_Specie);
        });
        PluginManager.registerCommand('SpecieScene', 'close', function () {
            if (typeof SceneManager !== 'undefined'
                && SceneManager._scene instanceof Scene_Specie) SceneManager.pop();
        });
        PluginManager.registerCommand('SpecieScene', 'setRealm', function (args) {
            var name = str(args && args.realm);
            X.settings().realm = name;
            X.invalidate();
        });
        PluginManager.registerCommand('SpecieScene', 'clearRealm', function () {
            X.settings().realm = null;
            X.invalidate();
        });
        PluginManager.registerCommand('SpecieScene', 'setDebased', function (args) {
            X.settings().debased = bool(args && args.debased, true);
            X.invalidate();
        });
    }

    // Exposed for the capture prelude and the in-engine probe.
    if (typeof window !== 'undefined') window.Scene_Specie = Scene_Specie;

}(SpecieScene));
