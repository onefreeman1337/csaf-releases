/*:
 * @target MZ
 * @plugindesc [Specie] Device corpus — 18 obverse + 18 reverse struck devices as pure geometry. Library file; no parameters.
 * @author Core Systems Asset Factory
 *
 * @help
 * SpecieDevices.js
 *
 * The 36 devices a coin can be struck with, authored as geometry rather than as
 * pictures. An OBVERSE says who struck the coin; a REVERSE says what that power
 * claims.
 *
 * It has NO dependency on RPG Maker MZ and makes no engine calls. A device emits
 * primitives into a recorder, so the whole corpus can be counted, measured,
 * rendered to a contact sheet and judged offline before any of it reaches a
 * Bitmap.
 *
 * Load order does not matter. Nothing here resolves a sibling file.
 */

var SpecieDevices = SpecieDevices || {};

(function (D) {
    'use strict';

    // =============================================================================================
    // COORDINATES AND THE EXTENT BUDGET
    //
    // Unit box [-0.5, 0.5] on both axes, y DOWN, origin at the centre of the flan.
    //
    // ⛔ THE BUDGET IS A DISC, NOT A SQUARE. A device is struck inside a ROUND coin, so the test is
    // hypot(x, y) <= DEVICE_BOX. A square budget lets a corner escape a round field, and on a coin
    // that reads as a device running off the flan - which is a real striking artefact, but only
    // when we ASK for it (see SpecieStrike off-centre), never by accident.
    //
    // ⛔ AND IT IS TIGHTER THAN THE FLAN, because the legend runs around the rim. The device owns
    // the CENTRE; the rim belongs to the inscription. Wing §25c is the record of what happens when
    // three different scales meet at an edge and two of them get conflated: 26 of 26 corner
    // treatments drew OUTSIDE the window rect, worst overhang 64 px, and a contact sheet
    // STRUCTURALLY COULD NOT SHOW IT because a sheet has gutters and the overhang ran into the
    // margin. Only a pixel readback outside the declared rect can see that class of defect.
    // =============================================================================================
    D.DEVICE_BOX = 0.34;          // device field radius, in flan units
    D.RIM_INNER = 0.38;           // the legend band starts here; nothing structural may cross it

    // ⛔ THE RESOLUTION FLOOR IS A NUMBER AND IT IS MEASURED, NOT CHOSEN.
    //
    // Wing §22a-2b: below ~0.05 unit half-width an appendage stops reading as itself and the eye
    // assigns it to the nearest common category - a thin vertical becomes a LEG, a thin stroke
    // beside a form becomes a floating scratch rather than part of it. Three figures in the quarry
    // corpus burned three passes each on geometry that was simply too thin to read.
    //
    // A coin is the worst case for this in the whole wing, because it is seen at ~32 px in a purse.
    // At that size 0.05 unit is 1.6 px. So anything that MUST read at purse size has to clear
    // MIN_LIMB, and anything finer is declared `detailOnly` and is dropped by the renderer below
    // the size at which it can exist - §17c-1: a feature that cannot resolve at the product's own
    // scale must move to a scale where it can, or be deleted. It is never simply drawn anyway,
    // because a correct rule executed below the resolution floor produces a confident wrong
    // picture (§22a-3b).
    D.MIN_LIMB_PX = 5.0;

    // ⛔ THE FLOOR IS IN PIXELS AND IT MUST BE, BECAUSE THIS PRODUCT HAS THREE COORDINATE SPACES
    // AND CONFLATING TWO OF THEM KILLS THE AXIS (wing §25c, measured on Cartouche: the pen came
    // from the shape, the reach came from the wrong edge, and 26 of 26 treatments rendered as nicks).
    //
    // The first version of this constant was `0.050` in FLAN units, copied straight out of
    // §22a-2b - and that section's own last line says "re-measure the floor if the render size
    // changes; it is a function of r*0.030, not a constant". It flagged 48 structural limbs as too
    // thin, ALL OF THEM FALSE: §22a-2b's 0.05 is a fraction of a figure that fills its cell, while a
    // device here occupies only DEVICE_BOX of the flan, so a 0.030 flan-unit limb is 0.088 of the
    // device's own field - comfortably above the floor. An invented bar manufactures false reds
    // exactly as readily as it hides true ones (§22a-6).
    //
    // Derivation of the 5 px: §22a-2b measured the floor on a figure judged at 120 px whose preview
    // maps 1.0 unit to r = canvas * 0.42, i.e. 1.0 unit = 50.4 px. Half-width 0.05 unit is therefore
    // ~2.5 px, i.e. a stroke ~5 px wide. That is the number, and it is about the EYE, so it does not
    // move when our coordinate system does.
    D.INSPECT_PX = 260;           // the diameter of the inspect plate - where a device is judged
    D.PURSE_PX = 32;              // the diameter in an item list - where most of it cannot exist

    /**
     * A device is authored in whatever scale reads clearly in source, then FITTED to the device
     * field. Fitting by construction beats fitting by care (wing §11) - and it means a device's
     * coordinates can be edited for legibility without anyone having to remember the budget.
     *
     * `fill` is a real design property, not a fudge: a temple front should occupy more of the field
     * than a bee does, and that difference is what stops the corpus looking mechanically uniform.
     *
     * @param {string} side
     * @param {string} id
     * @returns {{scale:number, raw:number, fitted:number, fill:number}}
     */
    D.field = function (side, id) {
        var dev = D.get(side, id);
        var raw = D.measure(side, id).extent;
        var fill = typeof dev.fill === 'number' ? dev.fill : 0.95;
        var target = D.DEVICE_BOX * fill;
        var scale = raw > 0 ? target / raw : 1;
        return { scale: scale, raw: raw, fitted: raw * scale, fill: fill };
    };

    /**
     * The narrowest STRUCTURAL limb in a device, expressed in pixels at a given rendered diameter.
     * This is the number the resolution floor is actually about.
     *
     * @param {string} side
     * @param {string} id
     * @param {number} diameterPx rendered diameter of the whole flan.
     * @returns {number} full stroke width in px of the thinnest structural limb, or Infinity if the
     *          device has no structural limbs at all.
     */
    D.thinnestStructuralPx = function (side, id, diameterPx) {
        var P = D.recorder();
        D.get(side, id).draw(P);
        var f = D.field(side, id);
        var thinnest = Infinity;
        for (var i = 0; i < P.ops.length; i++) {
            var o = P.ops[i];
            if (o.op !== 'limb' || o.detailOnly) continue;
            var halfWidthUnits = Math.max(o.w0, o.w1) * f.scale;   // flan units after fitting
            var fullPx = halfWidthUnits * 2 * diameterPx;          // 1.0 flan unit == diameterPx
            if (fullPx < thinnest) thinnest = fullPx;
        }
        return thinnest;
    };

    // =============================================================================================
    // THE PRIMITIVE RECORDER
    //
    // A device never touches a canvas. It calls these, and the caller decides what to do with the
    // calls - fill them onto a Bitmap, count them, or measure their extent.
    //
    // ⭐ WING §22b-1b IS WHY THE RECORDER COUNTS: if any count in a product is derived from size,
    // then rendering the same corpus at two sizes CANNOT produce the same number of drawing ops.
    // Colophon obeyed the pitch law at six sites and drew NONE of the marks, because `repeatsFor`
    // returns {count,pitch,floored} and the call sites read it as a scalar - `0 < {}` is false, so
    // the loop body never ran. Nothing threw and no counter read zero, because the shapes AROUND
    // the dead bands drew normally. Both sheets reported exactly path:119 fill:71 stroke:96, and
    // the Gate 1 review blamed the draughtsmanship. Comparing the op signature at two sizes is one
    // line and it distinguishes "the derivation is dead" from "the art is weak", which no amount of
    // looking can do.
    // =============================================================================================

    /**
     * A recorder that collects primitives and measures them. Pure data in, pure data out.
     * @returns {object} recorder with the primitive vocabulary and a `report()`.
     */
    D.recorder = function () {
        var ops = [];
        var maxR = 0;
        var detailDepth = 0;      // >0 while inside a detail() block

        function reach(x, y) {
            var r = Math.sqrt(x * x + y * y);
            if (r > maxR) maxR = r;
        }

        // Every op records whether it is detail-only, so the resolution-floor check knows what it
        // may exempt. Without this the checker cannot tell a too-thin SHIPPED mark from a mark that
        // is correctly dropped below its own minimum size, and it would false-red on every device
        // carrying fine work (§22a-6: an invented bar manufactures false reds as readily as it
        // hides true ones).
        function tag(o) {
            o.detailOnly = detailDepth > 0;
            ops.push(o);
        }

        // ⛔ EVERY PRIMITIVE REFUSES AN ARGUMENT IT DOES NOT IMPLEMENT, AND THIS IS NOT PEDANTRY -
        // IT IS THE FIX FOR A DEVICE THAT SHIPPED AS A BLANK EGG.
        //
        // MEASURED 2026-09-04 on the first contact sheet: `crescentStar` declared
        //     P.disc(-0.02, 0.00, 0.245);
        //     P.disc( 0.09,-0.04, 0.205, { subtract: true });
        // and rendered as a featureless oval, because `disc` takes THREE parameters and JavaScript
        // silently discards the fourth. The device carried a nine-line comment explaining that the
        // crescent is CUT rather than stacked, citing wing §22d by name - and the relationship it
        // described was expressed in a parameter that nothing anywhere read.
        //
        // Every instrument was green and each was honest about its own question: the suite counts
        // ops and measures extents, and two filled discs are two well-formed ops inside the budget.
        // This is wing §22a-2e (a corpus field nothing draws is an axis that does not exist) and
        // §17c (an id, a count and a test are three statements about a table; none of them is a mark
        // on a bitmap) arriving through the CALLING CONVENTION, where no amount of looking at the
        // corpus would have found it - the source reads correctly.
        //
        // ⇒ The class fix is to make the mistake impossible rather than to fix the one device.
        function argc(want, got, name) {
            if (got !== want) {
                throw new Error('SpecieDevices.' + name + ' takes ' + want + ' arguments, got ' + got
                    + '. An option a primitive does not implement is silently dropped by JavaScript, '
                    + 'and that is how a crescent shipped as an egg.');
            }
        }

        return {
            ops: ops,

            /** A filled disc. Heads, berries, pommels, bosses. */
            disc: function (x, y, r) {
                argc(3, arguments.length, 'disc');
                tag({ op: 'disc', x: x, y: y, r: r });
                reach(x + r, y); reach(x - r, y); reach(x, y + r); reach(x, y - r);
                return this;
            },

            /**
             * A disc of metal that is NOT THERE - a bite taken out of the mass, showing the field
             * through it. This is how a crescent is struck, and it is the only correct way to put a
             * hole in a shape here.
             *
             * ⛔ Wing §22d lists the two obvious versions and both are wrong: `destination-out`
             * erases to TRANSPARENT through everything already drawn, and opening an even-odd path
             * with the motif's bounding box fills the box minus the holes - a solid black square.
             * A hole is therefore an OP, resolved by the renderer against the metal that is actually
             * there.
             *
             * ⛔ AND IT CUTS ONLY WHAT PRECEDES IT. §22d's third trap is that a biting circle poking
             * outside the outer one fills the overhang too and turns a crescent into a RING; the
             * fix recorded there is to clip to the outer disc first. Order-based scoping is that
             * rule made structural: the renderer clips a hole to the union of the raised ops BEFORE
             * it, so a device can bite one mass and then lay another beside it - which is exactly
             * what crescent-and-star is. Clipping to the whole device instead would let the bite eat
             * the star, and the two shapes genuinely do overlap here.
             *
             * A hole does not extend the device's reach: it removes metal, it never adds any.
             */
            hole: function (x, y, r) {
                argc(3, arguments.length, 'hole');
                tag({ op: 'hole', x: x, y: y, r: r });
                return this;
            },

            /** A closed filled polygon. The workhorse: every silhouette mass. */
            poly: function (pts) {
                argc(1, arguments.length, 'poly');
                tag({ op: 'poly', pts: pts });
                for (var i = 0; i < pts.length; i++) reach(pts[i][0], pts[i][1]);
                return this;
            },

            /**
             * A TAPERED limb from (x0,y0) to (x1,y1), half-width w0 at the root and w1 at the tip.
             *
             * ⛔ A limb of CONSTANT width reads as a tube, and a chain of abutting masses reads as a
             * chain (wing §22a-1b: the mammoth read as "a circle, an oval, four posts and a floating
             * hook"). Taper is not decoration - it is what makes an appendage read as growing out of
             * the mass rather than being parked next to it. Roots are therefore drawn INSIDE the
             * mass they grow from, never abutting it.
             */
            limb: function (x0, y0, x1, y1, w0, w1) {
                argc(6, arguments.length, 'limb');
                tag({ op: 'limb', x0: x0, y0: y0, x1: x1, y1: y1, w0: w0, w1: w1 });
                reach(x0, y0); reach(x1, y1);
                reach(x1 + w1, y1 + w1); reach(x1 - w1, y1 - w1);
                return this;
            },

            /** An arc band - rims, collars, ground lines, the bow of a key. */
            arc: function (cx, cy, r, a0, a1, w) {
                argc(6, arguments.length, 'arc');
                tag({ op: 'arc', cx: cx, cy: cy, r: r, a0: a0, a1: a1, w: w });
                var steps = 8;
                for (var i = 0; i <= steps; i++) {
                    var a = a0 + (a1 - a0) * (i / steps);
                    reach(cx + Math.cos(a) * (r + w), cy + Math.sin(a) * (r + w));
                }
                return this;
            },

            /**
             * An INCUSE cut - a groove sunk INTO the relief, not another mass laid on top of it.
             *
             * ⛔ THIS IS THE PRIMITIVE THE FIRST CONTACT SHEET WAS MISSING, AND ITS ABSENCE FAILED
             * TEN DEVICES AT ONCE. MEASURED 2026-09-04: with only additive primitives every device
             * is a flat plateau, and wing §22c is exact about what that costs - "in a one-colour
             * silhouette two shapes only read as two if their outlines break each other" and "a face
             * in flat fill is always an emoticon, because a face is read from its INTERIOR and a
             * silhouette has no interior." The eagle read as a shoe, the lion as a caterpillar, the
             * stag as crumpled paper, the bull as a comma. Not one of them was drawn badly; each was
             * drawn without the thing that makes a struck coin legible.
             *
             * A real die cuts the eye, the mane, the drapery fold, the grain division and the wing
             * feather INTO the raised metal. That groove is a recess, so it takes the metal's patina
             * exactly as the field does - which means adding this primitive also makes the corrosion
             * axis read on the device and not only around it.
             *
             * ⛔ AND A CUT IS CLIPPED TO THE METAL IT IS CUT INTO. The renderer clips every incise op
             * to the union of the raised masses, so a groove can never float on the field. That is
             * not tidiness: §22a-2b measured that a stroke laid BESIDE a form detaches from it and
             * reads as a floating scratch (the ibex's ridge strokes became scratches above a deer),
             * and the fix there was to cut the ornament INTO the form. Making that structural means
             * the primitive cannot be misused.
             *
             * @param {number[][]} pts polyline in device coordinates.
             * @param {number} w half-width of the groove.
             */
            incise: function (pts, w) {
                argc(2, arguments.length, 'incise');
                tag({ op: 'incise', pts: pts, w: w });
                for (var i = 0; i < pts.length; i++) reach(pts[i][0], pts[i][1]);
                return this;
            },

            /**
             * An incuse cut following an arc. Sugar over `incise` - it samples the arc and emits ONE
             * incise op, so the renderer keeps a single code path for cuts (wing §11: prefer a shape
             * where the second path CALLS the first to one that re-implements it).
             */
            inciseArc: function (cx, cy, r, a0, a1, w) {
                argc(6, arguments.length, 'inciseArc');
                var pts = [];
                var steps = 12;
                for (var i = 0; i <= steps; i++) {
                    var a = a0 + (a1 - a0) * (i / steps);
                    pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
                }
                return this.incise(pts, w);
            },

            /**
             * A mark that only exists above a given rendered diameter, in PIXELS.
             * ⛔ §17c-1 / §22a-3b: a feature that cannot resolve at the product's own scale must
             * move to a scale where it can, or be deleted - never drawn anyway.
             */
            detail: function (minPx, fn) {
                argc(2, arguments.length, 'detail');
                tag({ op: 'detail', minPx: minPx });
                detailDepth++;
                try { fn(this); } finally { detailDepth--; }   // restore even if the device throws
                return this;
            },

            report: function () {
                var counts = {};
                var structural = 0;
                for (var i = 0; i < ops.length; i++) {
                    counts[ops[i].op] = (counts[ops[i].op] || 0) + 1;
                    // ⛔ STRUCTURAL means "survives to purse size": not a detail marker, not INSIDE
                    // a detail block, and NOT AN INCUSE CUT. Counting only the markers is wrong and
                    // it made the corresponding sabotage arm undetectable - a device of nothing but
                    // detail marks still scored 2 structural ops and passed. Master §2b: a check
                    // that cannot fail on the defect it names reports coverage that does not exist.
                    //
                    // An incise is excluded because a groove is INTERIOR MODELLING and can never
                    // carry a silhouette: at purse size the whole device is ~20px and a cut is
                    // sub-pixel. A hole is excluded because it is ABSENCE - it removes metal and
                    // can draw nothing. Counting either as structural would let a device satisfy
                    // "has something that survives to purse size" with marks that provably do not
                    // (§17c-1), which is the same vacuous pass the detail-marker bug produced.
                    //
                    // ⚠️ `hole` WAS COUNTED HERE UNTIL THE SUITE CAUGHT IT. The exclusion was
                    // written for `incise` when that primitive was added, and `hole` - added in the
                    // same session, for the same reason - was simply not added to the list. Wing
                    // §12b: a check earns its place by going red once, on the real defect. It did.
                    if (ops[i].op !== 'detail' && ops[i].op !== 'incise' && ops[i].op !== 'hole'
                        && !ops[i].detailOnly) structural++;
                }
                return { total: ops.length, counts: counts, extent: maxR, structural: structural };
            }
        };
    };

    // =============================================================================================
    // OBVERSE — WHO STRUCK THE COIN (18)
    //
    // ⛔ AUTHORED AGAINST §22a's TABLE OF MISREADINGS, WHICH IS A LIST OF THINGS THE EYE DOES
    // WHETHER OR NOT WE INTENDED THEM: two equal rings read as SPECTACLES; radial spikes around a
    // disc read as a SUN; two curved points from a rounded base read as a CRESCENT; equal legs under
    // a rounded body read as a CATERPILLAR; a circle with two dots and a line is a SMILEY.
    //
    // ⭐ PREFER ASYMMETRY. Vertical-axis symmetry is the hazard - a padlock, a fist and a trumpet all
    // survived the Oracle Deck sheet precisely because nothing in them pairs. That is why most of
    // this side is drawn in PROFILE: a profile head has no pair to make, and it is also what real
    // coinage does, for the same reason.
    // =============================================================================================

    /** Shared: a profile head facing right, from a chin point around to the nape. */
    function profileSkull(P, cx, cy, s) {
        P.poly([
            [cx - 0.10 * s, cy - 0.15 * s],   // crown, back
            [cx + 0.02 * s, cy - 0.19 * s],   // crown, front
            [cx + 0.11 * s, cy - 0.10 * s],   // brow
            [cx + 0.10 * s, cy - 0.03 * s],   // bridge
            [cx + 0.15 * s, cy + 0.03 * s],   // nose tip  <- the asymmetry that carries the read
            [cx + 0.09 * s, cy + 0.06 * s],   // upper lip
            [cx + 0.10 * s, cy + 0.11 * s],   // chin
            [cx + 0.02 * s, cy + 0.16 * s],   // jaw
            [cx - 0.09 * s, cy + 0.15 * s],   // neck front
            [cx - 0.13 * s, cy + 0.02 * s]    // nape
        ]);

        // ⛔ THE CUTS ARE PART OF THE HEAD, NOT AN OPTIONAL EXTRA, AND THEY LIVE HERE SO ALL FOUR
        // SOVEREIGNS GET THEM FROM ONE EDIT (wing §11: prefer a shape where the second path CALLS
        // the first to one that re-implements it - a second copy does not drift, it WINS, §11a).
        //
        // MEASURED 2026-09-04 on the first contact sheet: every one of these heads was a flat pale
        // plateau, and §22c is exact about why that fails - "a face in flat fill is always an
        // emoticon, because a face is read from its INTERIOR and a silhouette has no interior."
        // A die cuts the eye, the brow and the hair line INTO the relief; without those a profile
        // head is a wedge, and the four sovereigns were separable only by their headgear.
        P.detail(90, function (Q) {
            Q.inciseArc(cx + 0.055 * s, cy - 0.055 * s, 0.030 * s,
                Math.PI * 0.8, Math.PI * 2.5, 0.009 * s);          // eye socket
            Q.incise([[cx + 0.005 * s, cy - 0.10 * s],
                      [cx + 0.075 * s, cy - 0.075 * s]], 0.009 * s);  // brow ridge
        });
        P.detail(130, function (Q) {
            Q.incise([[cx - 0.10 * s, cy - 0.04 * s],
                      [cx - 0.03 * s, cy - 0.09 * s]], 0.008 * s);    // hair line
            Q.incise([[cx - 0.09 * s, cy + 0.03 * s],
                      [cx - 0.02 * s, cy - 0.01 * s]], 0.008 * s);
            Q.incise([[cx + 0.055 * s, cy + 0.075 * s],
                      [cx + 0.095 * s, cy + 0.075 * s]], 0.008 * s);  // the mouth
        });
    }

    D.OBVERSE = {
        sovereign: {
            name: 'Laureate Sovereign',
            fill: 0.93,
            draw: function (P) {
                profileSkull(P, -0.01, 0.00, 1.0);
                // a laurel wreath sits ON the skull line, following it - not floating above it
                P.arc(-0.01, -0.02, 0.155, Math.PI * 1.05, Math.PI * 1.85, 0.020);
                P.detail(120, function (Q) {
                    Q.limb(-0.14, -0.06, -0.20, -0.02, 0.016, 0.008);   // wreath ties
                    Q.limb(-0.14, -0.04, -0.19, 0.03, 0.014, 0.007);
                });
            }
        },
        crowned: {
            name: 'Crowned Sovereign',
            fill: 0.93,
            draw: function (P) {
                profileSkull(P, -0.01, 0.02, 1.0);
                // ⛔ THREE points of UNEQUAL height. Equal points would pair and read as a comb.
                P.poly([[-0.13, -0.13], [0.05, -0.17], [0.07, -0.25],
                        [0.01, -0.20], [-0.02, -0.28], [-0.06, -0.19],
                        [-0.11, -0.24], [-0.13, -0.17]]);
            }
        },
        helmed: {
            name: 'Helmed Sovereign',
            fill: 0.93,
            draw: function (P) {
                profileSkull(P, -0.01, 0.03, 0.95);
                P.poly([[-0.14, -0.10], [0.04, -0.16], [0.11, -0.09], [0.06, -0.06], [-0.13, -0.03]]);
                // the crest sweeps BACK, so the mass is off-axis and the head cannot read as round
                P.poly([[-0.02, -0.16], [0.03, -0.26], [-0.10, -0.24], [-0.19, -0.13], [-0.14, -0.11]]);
            }
        },
        veiled: {
            name: 'Veiled Sovereign',
            fill: 0.93,
            draw: function (P) {
                profileSkull(P, 0.01, 0.01, 0.92);
                // drapery falls BEHIND and below - a long asymmetric tail no other obverse has
                P.poly([[-0.11, -0.15], [0.02, -0.19], [0.04, -0.13], [-0.06, -0.08],
                        [-0.08, 0.06], [-0.03, 0.20], [-0.14, 0.22], [-0.19, 0.04], [-0.17, -0.09]]);
            }
        },
        eagle: {
            name: 'Eagle Head',
            fill: 0.90,
            draw: function (P) {
                // ⛔ THE FIRST VERSION READ AS A SHOE. Two causes, both in wing doctrine: the nape
                // was a SEPARATE polygon parked against the skull (§22a-1b - a chain of abutting
                // masses reads as a chain, and the heel of a shoe is exactly what an abutting wedge
                // at the back of a wedge looks like), and there was no CERE STEP, so beak and skull
                // were one smooth taper. A raptor is read from the step where the beak leaves the
                // face, not from the hook alone.
                P.poly([
                    [-0.21, 0.03],    // nape, back - ONE outline all the way round, no seam
                    [-0.13, -0.09],
                    [-0.01, -0.14],   // crown
                    [0.06, -0.12],    // brow ridge, overhanging the eye
                    [0.10, -0.09],    // THE CERE STEP - the beak becomes a separate structure here
                    [0.19, -0.06],
                    [0.24, 0.02],     // the HOOK tip
                    [0.16, 0.035],
                    [0.10, 0.015],    // gape
                    [0.06, 0.07],     // lower mandible
                    [-0.02, 0.13],    // throat
                    [-0.15, 0.16]     // nape, bottom
                ]);
                // ⭐ THE EYE AS A DIE ACTUALLY CUTS ONE: a raised boss inside an incuse socket. A
                // raised disc alone is the same colour as the face and therefore invisible (§22c -
                // a silhouette has no interior); the socket is what makes it exist.
                P.detail(90, function (Q) {
                    Q.inciseArc(0.03, -0.05, 0.042, Math.PI * 0.85, Math.PI * 2.45, 0.010);
                    Q.disc(0.03, -0.05, 0.022);
                });
                // nape feathering CUT INTO the metal, never laid beside it - §22a-2b measured that
                // a stroke placed next to a form detaches and reads as a floating scratch.
                P.detail(110, function (Q) {
                    Q.incise([[-0.18, -0.02], [-0.08, 0.02]], 0.009);
                    Q.incise([[-0.17, 0.05], [-0.06, 0.08]], 0.009);
                    Q.incise([[-0.14, 0.11], [-0.04, 0.12]], 0.009);
                    Q.incise([[0.095, -0.10], [0.105, -0.005]], 0.008);   // the cere line
                });
            }
        },
        lion: {
            name: 'Lion Head',
            fill: 0.92,
            draw: function (P) {
                // ⛔⛔ THIS DEVICE TOOK TWO FAILED PASSES AS A WHOLE-BODY `Lion Passant` AND THE
                // THIRD CHANGED THE SUBJECT, WHICH IS WHAT WING §22a-5 SAYS TO DO AND SAYS TO DO
                // EARLIER THAN THIS.
                //
                // Pass 1: three near-equal legs under a tube read as a CATERPILLAR - §22a's table
                // verbatim ("equal legs under a rounded body -> a caterpillar").
                // Pass 2: a mane was added as the positional escape (§22a-2c). It read as a HUMP ON
                // THE BACK and the animal became a hippo, because on a walking quadruped the mane
                // sits over the SPINE and the spine is the skyline.
                //
                // ⭐ §22a-5 is the diagnosis and it was available before either pass: "a silhouette
                // corpus cannot carry many mammals - mammal bodies differ from one another mainly
                // in PROPORTION, and proportion is the first thing to go at reading size." A
                // walking lion and a walking anything are the same picture at 210 px.
                //
                // ⭐ AND THE COUNTER-EXAMPLE WAS ALREADY ON THE SAME SHEET: `horse` and `eagle` both
                // read on their first fix, and both are HEADS IN PROFILE. A head has the one thing
                // a body does not - a face - and a face is where a mammal's identity actually lives.
                // So the recipe that works in this corpus is the profile head, and the mane then
                // does its job properly: on a head it is a RUFF around the neck, which is a position
                // (§22a-2c) that nothing else here occupies. §22a-4: the lion owns it, so `horse`
                // keeps its mane flat behind the crest and never as a ruff.
                // ⚠️ PASS 4, and the correction is one measurement: the ruff must not reach the
                // MUZZLE. Pass 3's ruff came forward to x=0.15 while the muzzle ended at x=0.30, so
                // half the face sat inside the mane and the device read as a round fluffy mass with
                // a face in it - a hedgehog, or a sunflower. §22a-1b in reverse: two masses that
                // are meant to read as two only do so if the outline STEPS between them, and the
                // ruff was swallowing the step.
                P.poly([
                    [0.34, 0.05],     // muzzle, front - carried WELL clear of the ruff
                    [0.32, -0.05],
                    [0.19, -0.11],    // the short broad nose - NOT a horse's long nasal bone
                    [0.10, -0.17],    // brow
                    [-0.02, -0.18],
                    [-0.04, -0.06],   // skull, back
                    [0.02, 0.07],
                    [0.12, 0.17],     // deep jaw
                    [0.26, 0.16]
                ]);
                // the ruff: ONE mass whose outer edge is a ring of unequal points, overlapping the
                // skull rather than abutting it (§22a-1b) - and stopping BEHIND the jaw
                P.poly([
                    [0.09, -0.14], [0.06, -0.26], [-0.05, -0.29], [-0.16, -0.23],
                    [-0.23, -0.11], [-0.25, 0.03], [-0.19, 0.17], [-0.08, 0.25],
                    [0.04, 0.26], [0.11, 0.19], [0.03, 0.11], [-0.03, -0.02], [-0.01, -0.13]
                ]);
                P.limb(0.02, -0.15, -0.03, -0.24, 0.030, 0.020);        // ears, UNEQUAL, on the ruff
                P.limb(-0.05, -0.13, -0.14, -0.20, 0.028, 0.018);
                P.detail(90, function (Q) {
                    Q.inciseArc(0.16, -0.05, 0.030, Math.PI * 0.8, Math.PI * 2.5, 0.009);
                    Q.incise([[0.29, -0.01], [0.32, 0.01]], 0.010);      // nostril
                    Q.incise([[0.23, 0.09], [0.32, 0.07]], 0.010);       // the mouth line
                });
                // the ruff's locks, CUT rather than laid on (§22a-2b) - a stroke placed beside a
                // form detaches from it; a notch can only ever read as part of the shape it bites.
                P.detail(125, function (Q) {
                    Q.incise([[0.05, -0.22], [0.03, -0.12]], 0.009);
                    Q.incise([[-0.08, -0.21], [-0.04, -0.10]], 0.009);
                    Q.incise([[-0.16, -0.12], [-0.07, -0.05]], 0.009);
                    Q.incise([[-0.17, 0.04], [-0.06, 0.04]], 0.009);
                    Q.incise([[-0.11, 0.16], [-0.02, 0.10]], 0.009);
                    Q.incise([[0.01, 0.21], [0.05, 0.12]], 0.009);
                });
            }
        },
        stag: {
            name: 'Stag Head',
            fill: 0.94,
            draw: function (P) {
                // ⛔ THE FIRST VERSION READ AS CRUMPLED PAPER. The head was a small lump and the
                // antlers were 6.35 px at inspect size - just above the 5 px floor, which is to say
                // AT it. §22a-2b: below the floor the eye assigns a thin mark to the nearest common
                // category, and six thin marks radiating off a small mass is not a stag, it is
                // debris. The geometry pass called this clean, which is §12b exactly: a check that
                // cannot fail on the defect it names reports coverage that does not exist.
                //
                // ⭐ ANTLERS BRANCH, AND NO EAR DOES (§22a-2c) - that is a POSITIONAL escape and it
                // is still the right one. What was wrong was the SCALE, not the idea.
                // ⚠️ PASS 3. Pass 2 thickened the antlers and it read as a BIRD HEAD WITH STICKS,
                // because thickening them made them the largest thing in the cell while the head
                // stayed a 0.33-wide lump. §22a-2b's floor is a MINIMUM, and obeying a minimum by
                // growing a feature past the mass it grows from is the §14a trap in another
                // material - raising a number until the check passes, and making the picture worse.
                //
                // ⭐ The head is now in PROFILE and as large as the horse's, which is the recipe
                // that works in this corpus (see `lion`), and the antlers are SHORTER than the head
                // is long. A stag's antlers are read from their BRANCHING, not their size, and
                // branching is a positional escape no ear has (§22a-2c).
                P.poly([
                    [0.28, 0.09],     // muzzle
                    [0.26, 0.00],
                    [0.14, -0.05],    // the fine nasal line - narrower than the lion's
                    [0.03, -0.09],
                    [-0.08, -0.08],   // brow
                    [-0.15, 0.01],
                    [-0.13, 0.13],    // the throat
                    [0.02, 0.17],
                    [0.16, 0.16]
                ]);
                P.limb(-0.11, -0.06, -0.16, -0.19, 0.028, 0.017);      // ears, back and UNEQUAL
                P.limb(-0.03, -0.09, -0.02, -0.21, 0.026, 0.016);      // antler beams
                P.limb(-0.13, -0.07, -0.24, -0.15, 0.026, 0.016);
                P.detail(105, function (Q) {
                    Q.limb(-0.025, -0.17, -0.10, -0.26, 0.017, 0.010);  // the TINES - the whole read
                    Q.limb(-0.02, -0.20, 0.07, -0.28, 0.016, 0.009);
                    Q.limb(-0.21, -0.13, -0.28, -0.24, 0.016, 0.009);
                    Q.limb(-0.19, -0.12, -0.31, -0.09, 0.015, 0.009);
                });
                P.detail(90, function (Q) {
                    Q.inciseArc(0.02, 0.02, 0.030, Math.PI * 0.8, Math.PI * 2.5, 0.009);
                    Q.incise([[0.24, 0.04], [0.27, 0.05]], 0.010);      // the nostril
                    Q.incise([[0.10, 0.11], [0.24, 0.10]], 0.009);      // the mouth line
                });
            }
        },
        serpent: {
            name: 'Coiled Serpent',
            fill: 0.95,
            draw: function (P) {
                // ⛔ THE FIRST VERSION READ AS THE LETTER G. One arc with a wedge on the end is a
                // letterform before it is an animal, and §22a's whole point is that the eye takes
                // the CHEAPEST interpretation available.
                //
                // ⭐ Two changes, both structural. (1) The coil crosses OVER itself - a snake is the
                // one subject whose identity is that its body passes its own body, and a crossing
                // is something no letter does. (2) The head OVERLAPS the coil rather than
                // terminating it (§22a-1b: an appendage must overlap the mass it grows from, never
                // abut it), so the outline flows into the head instead of stopping at a seam.
                //
                // ⛔ STILL NO INTERIOR HATCHING AS PARALLEL BARS. §22a-2 records that hatching
                // inside a coil read as TEETH IN AN OPEN MOUTH, which is how a coiled snake came to
                // look like a bowl. Scale marks here are CHEVRONS cut into the body, which cannot
                // line up into a row of bars.
                // ⚠️ PASS 3. Pass 2 kept the COIL and added a crossing; it still read as a spiral
                // with a bird stuck on it, because a near-closed ring is a letterform whatever is
                // attached to it, and the attachment is the smallest part of the picture.
                //
                // ⭐ The subject changes shape rather than identity (§22a-5b): an UNDULATING serpent
                // with the head raised. Three reversing curves is a motion no letter and no other
                // device here makes, the body is continuous so nothing abuts (§22a-1b), and the
                // taper from a thick neck to a fine tail is the one proportion a snake is read from.
                //
                // ⛔ STILL NO PARALLEL-BAR HATCHING. §22a-2 records that hatching inside a coil read
                // as TEETH IN AN OPEN MOUTH, which is how a coiled snake came to look like a bowl.
                // The scale marks are CHEVRONS, which cannot line up into a row of bars.
                P.limb(-0.30, 0.30, -0.17, 0.20, 0.016, 0.030);         // tail, fine to thick
                P.limb(-0.17, 0.20, -0.02, 0.24, 0.030, 0.038);
                P.limb(-0.02, 0.24, 0.13, 0.13, 0.038, 0.042);
                P.limb(0.13, 0.13, 0.10, -0.03, 0.042, 0.044);
                P.limb(0.10, -0.03, -0.05, -0.11, 0.044, 0.042);        // the reversing curve
                P.limb(-0.05, -0.11, -0.09, -0.24, 0.042, 0.036);       // the reared neck
                // ⚠️ PASS 4, AND IT WAS FOUND ON A STORE PLATE. Pass 3's head was a rounded blob
                // WIDER than its own neck, with a single straight tongue sticking out of the front -
                // which is a BIRD'S HEAD WITH A BEAK, and that is how it read once it was promoted
                // to the hero of the twelve-piece plate. §22a: the eye takes the cheapest
                // interpretation, and "round head + projecting spike on a curving neck" is a bird
                // long before it is a snake.
                //
                // ⚠️ §22a-1 warns that a doctrine entry recording a fix is a claim about a RENDERED
                // IMAGE and decays the moment the figure is edited. The comment above says the pass-3
                // head read correctly; on this plate it did not. Re-render before trusting any
                // "and then it read correctly" - including this sentence.
                //
                // The head is now a WEDGE: it leaves the neck no wider than the neck is, swells at
                // the jaw, and tapers to a blunt snout. A snake's identity is that its head is a
                // continuation of its body, not a bulb on the end of it (§22a-1b).
                P.poly([[-0.13, -0.20], [-0.10, -0.29], [0.06, -0.30], [0.15, -0.25],
                        [0.08, -0.19], [-0.06, -0.16]]);                // head, OVERLAPPING the neck
                // ⚠️ THE TONGUE IS DETAIL, NOT STRUCTURE, AND THE GEOMETRY PASS SAID SO. At 0.012
                // half-width it measures 4.75 px at inspect size against the 5.0 px floor, so as a
                // top-level mark it was a §22a-2b violation the moment it was written. §17c-1: a
                // feature that cannot resolve at the product's own scale must move to a scale where
                // it can - so it moves into a detail block and simply does not exist below it,
                // rather than being drawn anyway as a confident wrong mark (§22a-3b).
                // ⛔ THE TONGUE IS FORKED, AND THAT IS THE WHOLE CUE. A SINGLE straight bar leaving
                // the snout is a BEAK - it was, and it is what made this device read as a bird. A
                // fork is a mark nothing else in this corpus makes and no bird has, so it separates
                // the subject by itself (§22a: prefer the cue only one thing owns). Cheap, and it
                // survives at any size the detail block draws at.
                P.detail(120, function (Q) {
                    Q.limb(0.14, -0.25, 0.24, -0.28, 0.010, 0.005);     // the flicked tongue, upper
                    Q.limb(0.14, -0.25, 0.24, -0.21, 0.010, 0.005);     // and lower
                });
                P.detail(90, function (Q) {
                    Q.inciseArc(0.01, -0.25, 0.026, Math.PI * 0.8, Math.PI * 2.5, 0.009);
                });
                P.detail(120, function (Q) {
                    Q.incise([[-0.14, 0.16], [-0.10, 0.22], [-0.06, 0.17]], 0.008);
                    Q.incise([[-0.02, 0.19], [0.02, 0.25], [0.06, 0.19]], 0.008);
                    Q.incise([[0.06, 0.05], [0.12, 0.08], [0.09, 0.02]], 0.008);
                    Q.incise([[-0.02, -0.06], [0.03, -0.02], [0.01, -0.08]], 0.008);
                });
            }
        },
        sceptre: {
            name: 'Sceptre of Office',
            fill: 0.95,
            // ⛔ THIS DEVICE WAS CALLED `handOfOffice` AND DREW A HAND GRIPPING A ROD. On the first
            // contact sheet it read as a SCEPTRE - unambiguously, and rather well. The fist was a
            // five-point polygon about 20 px across at inspect size, which is below the size at
            // which fingers are available as a cue at all, so the grip could never have read.
            //
            // ⭐ Wing §22a-5b is explicit that this is the cheapest legitimate move: "changing the
            // subject to something that says the same thing is a legitimate move, and it is the
            // cheapest one available. Ask on pass 2, not pass 5." A sceptre says what a hand of
            // office says - who holds authority - so the RENAME is the fix and the drawing barely
            // moves. What it gains instead is a shaft heavy enough to carry a cut.
            draw: function (P) {
                P.limb(-0.20, 0.28, 0.17, -0.22, 0.030, 0.024);
                // the grip: a collar that OVERLAPS the shaft (§22a-1b), not a fist beside it
                P.poly([[-0.09, 0.00], [0.02, -0.08], [0.10, -0.02], [0.06, 0.09], [-0.05, 0.11]]);
                P.disc(0.19, -0.25, 0.055);      // finial, so the rod terminates rather than exits
                P.detail(120, function (Q) {
                    Q.incise([[-0.06, 0.02], [0.06, -0.05]], 0.010);      // collar bindings
                    Q.incise([[-0.04, 0.07], [0.07, 0.00]], 0.010);
                    Q.inciseArc(0.19, -0.25, 0.030, 0, Math.PI * 2, 0.009);
                });
            }
        },
        tower: {
            name: 'Keep',
            fill: 0.97,
            draw: function (P) {
                P.poly([[-0.17, -0.10], [0.17, -0.10], [0.20, 0.28], [-0.20, 0.28]]);
                // battlements: FOUR merlons over an ODD gap spacing, so the top does not pair
                P.poly([[-0.19, -0.10], [-0.19, -0.20], [-0.12, -0.20], [-0.12, -0.10]]);
                P.poly([[-0.06, -0.10], [-0.06, -0.22], [0.01, -0.22], [0.01, -0.10]]);
                P.poly([[0.07, -0.10], [0.07, -0.20], [0.14, -0.20], [0.14, -0.10]]);
                // door OFF CENTRE - the one line that stops the whole device being mirror-symmetric
                P.poly([[-0.09, 0.28], [-0.09, 0.10], [-0.01, 0.06], [0.03, 0.10], [0.03, 0.28]]);
            }
        },
        temple: {
            name: 'Temple Front',
            fill: 0.99,
            draw: function (P) {
                P.poly([[-0.26, -0.04], [0.00, -0.20], [0.26, -0.04]]);       // pediment
                P.poly([[-0.28, -0.04], [0.28, -0.04], [0.28, 0.02], [-0.28, 0.02]]);
                P.limb(-0.20, 0.02, -0.20, 0.24, 0.030, 0.030);
                P.limb(-0.07, 0.02, -0.07, 0.24, 0.030, 0.030);
                P.limb(0.07, 0.02, 0.07, 0.24, 0.030, 0.030);
                P.limb(0.20, 0.02, 0.20, 0.24, 0.030, 0.030);
                P.poly([[-0.28, 0.24], [0.28, 0.24], [0.28, 0.30], [-0.28, 0.30]]);
            }
        },
        anchor: {
            name: 'Anchor',
            fill: 0.94,
            draw: function (P) {
                // ⛔ THIS IS DELIBERATELY NOT A SHIP. Wing §22a-5b killed a ship in a 90px circle
                // after three passes: face-on it read as a SMILEY (hull=mouth, sails=eyes), and in
                // profile a shallow hull crescent read as A BOWL WITH A HOOK. A ship's identity is
                // its PROPORTION, and proportion is the first thing to go at reading size. The
                // anchor says "maritime power" just as well and landed first try. Changing the
                // subject is a legitimate move and it is the cheapest one available.
                P.limb(0.00, -0.20, 0.00, 0.22, 0.026, 0.026);
                P.arc(0.00, -0.24, 0.070, Math.PI * 0.10, Math.PI * 0.90, 0.020);
                P.poly([[-0.13, -0.12], [0.13, -0.12], [0.13, -0.06], [-0.13, -0.06]]);   // stock
                P.arc(0.00, 0.10, 0.185, Math.PI * 0.12, Math.PI * 0.88, 0.030);          // arms
                P.poly([[-0.21, 0.16], [-0.14, 0.09], [-0.11, 0.19]]);                    // flukes
                P.poly([[0.21, 0.16], [0.14, 0.09], [0.11, 0.19]]);
            }
        },
        sunWheel: {
            name: 'Sun in Splendour',
            fill: 1.00,
            draw: function (P) {
                // §22a says radial spikes around a disc READ AS A SUN. Here that is the intended
                // reading, so the misreading table is being used rather than fought - but nothing
                // ELSE in this corpus may use a radial spike arrangement, or it collides with this.
                P.disc(0.00, 0.00, 0.115);
                for (var i = 0; i < 12; i++) {
                    var a = (i / 12) * Math.PI * 2;
                    var r0 = 0.115, r1 = (i % 2 === 0) ? 0.275 : 0.215;   // alternating, so it is
                    P.limb(Math.cos(a) * r0, Math.sin(a) * r0,             // not a plain starburst
                           Math.cos(a) * r1, Math.sin(a) * r1, 0.026, 0.008);
                }
            }
        },
        crescentStar: {
            name: 'Crescent and Star',
            fill: 0.98,
            draw: function (P) {
                // ⛔ THE CRESCENT IS CUT, NOT STACKED, AND `hole` IS HOW. Wing §22d: opening an
                // evenodd path with the motif's whole BOUNDING BOX fills the box minus the holes -
                // a solid black square - and a biting circle poking outside the outer one fills the
                // overhang too and turns the crescent into a RING.
                //
                // ⚠️ THIS DEVICE SHIPPED AS A FEATURELESS EGG AND THE COMMENT ABOVE WAS ALREADY
                // HERE. The bite was written as `P.disc(0.09, -0.04, 0.205, { subtract: true })`,
                // and `disc` takes three arguments, so JavaScript discarded the fourth in silence.
                // The recorder now REFUSES an argument it does not implement (see `argc`), which is
                // the class fix; this is the instance.
                P.disc(-0.02, 0.00, 0.245);
                P.hole(0.09, -0.04, 0.205);
                // the star is laid AFTER the bite, and the bite's own circle covers most of where it
                // sits - which is exactly why a hole is scoped to what precedes it and not to the
                // finished device.
                P.poly([[0.17, -0.02], [0.20, -0.10], [0.23, -0.02], [0.31, 0.00],
                        [0.23, 0.03], [0.20, 0.11], [0.17, 0.03], [0.09, 0.00]]);
            }
        },
        oak: {
            name: 'Oak',
            fill: 0.92,
            draw: function (P) {
                P.limb(-0.01, 0.30, 0.01, 0.02, 0.036, 0.026);
                P.limb(0.00, 0.10, -0.16, -0.02, 0.020, 0.011);
                P.limb(0.00, 0.06, 0.15, -0.06, 0.020, 0.011);
                // ⛔ CANOPY DELIBERATELY OFF CENTRE AND UNEQUAL. A symmetric canopy on a straight
                // trunk is the letter-Y failure from §22a's table ("two big leaves at the top of a
                // short shaft" read as a Y).
                P.disc(-0.13, -0.08, 0.115);
                P.disc(0.06, -0.14, 0.145);
                P.disc(0.17, -0.02, 0.095);
            }
        },
        bee: {
            name: 'Bee',
            fill: 0.86,
            draw: function (P) {
                // ⛔ §22a-5 SAYS ARTHROPODS LAND FIRST OR SECOND PASS BECAUSE THEIR WHOLE OUTLINE IS
                // THE ANIMAL - AND THIS ONE READ AS A PAPER DART, WHICH IS THE EXCEPTION THAT PROVES
                // the rule's real content. The outline was two straight-edged triangles either side
                // of a tapering wedge: mirror-symmetric about the vertical, which §22a names as THE
                // hazard, and every edge straight. A dart is the cheapest reading of that shape.
                //
                // ⭐ What makes a bee a bee at reading size is not the outline at all - it is the
                // BANDED ABDOMEN, and a band is a cut, not a mass. That is the whole reason this
                // device could not have been fixed by reshaping: the identifying feature did not
                // exist as a primitive until `incise` did.
                //
                // The wings are also now UNEQUAL and swept back at different angles, so nothing
                // pairs (§22a).
                P.poly([[0.00, -0.22], [0.075, -0.17], [0.085, -0.05],
                        [0.055, 0.10], [0.00, 0.21], [-0.055, 0.10],
                        [-0.085, -0.05], [-0.075, -0.17]]);
                P.poly([[-0.05, -0.15], [-0.24, -0.27], [-0.32, -0.16], [-0.22, -0.06], [-0.09, -0.04]]);
                P.poly([[0.05, -0.13], [0.27, -0.21], [0.31, -0.09], [0.19, -0.02], [0.09, -0.03]]);
                P.detail(110, function (Q) {
                    Q.limb(-0.025, -0.21, -0.085, -0.31, 0.012, 0.007);   // antennae, UNEQUAL
                    Q.limb(0.03, -0.21, 0.10, -0.29, 0.012, 0.007);
                });
                // the bands. Three, unequal, narrowing toward the sting, because a real abdomen
                // tapers - equal bands would pair and read as a stack.
                P.detail(95, function (Q) {
                    Q.incise([[-0.081, -0.02], [0.081, -0.02]], 0.011);
                    Q.incise([[-0.070, 0.04], [0.070, 0.04]], 0.010);
                    Q.incise([[-0.048, 0.10], [0.048, 0.10]], 0.009);
                    Q.incise([[-0.070, -0.135], [0.070, -0.135]], 0.009);  // thorax division
                });
            }
        },
        horse: {
            name: 'Horse Head',
            fill: 0.91,
            draw: function (P) {
                // ⛔ THE FIRST VERSION READ AS TWO BLOBS WITH EARS. The mane was a separate
                // quadrilateral parked against the neck - §22a-1b's abutting-masses failure, and
                // the same one the eagle's nape had - so the eye saw two shapes and had to be told
                // which was the animal.
                //
                // ⭐ ONE OUTLINE, muzzle to poll to crest to withers, with the mane's OUTER edge
                // part of it. A horse is read from the long straight nasal bone into a deep jaw,
                // and that only survives if the jaw's step is in the same outline as the muzzle.
                //
                // ⚠️ §22a-4: the lion owns the skyline mane in this corpus, so this one falls
                // BEHIND the neck and never rises above the crest.
                P.poly([
                    [0.24, 0.10],     // muzzle, front
                    [0.25, -0.01],    // nostril step
                    [0.14, -0.11],
                    [0.02, -0.15],    // the straight nasal bone
                    [-0.08, -0.14],   // poll
                    [-0.16, -0.19],   // the crest of the neck, carried BACK
                    [-0.30, -0.02],   // the mane's outer edge, part of the SAME outline
                    [-0.26, 0.13],
                    [-0.12, 0.10],    // the deep jaw
                    [0.06, 0.16],     // throat latch
                    [0.17, 0.17]
                ]);
                P.limb(-0.06, -0.13, -0.11, -0.26, 0.026, 0.011);      // ears, UNEQUAL
                P.limb(0.03, -0.14, 0.02, -0.28, 0.024, 0.010);
                P.detail(90, function (Q) {
                    Q.inciseArc(0.06, -0.05, 0.030, Math.PI * 0.8, Math.PI * 2.5, 0.009);
                    Q.incise([[0.21, 0.02], [0.24, 0.04]], 0.010);       // the nostril
                });
                P.detail(120, function (Q) {
                    Q.incise([[-0.13, -0.15], [-0.23, -0.02]], 0.009);   // mane locks, CUT
                    Q.incise([[-0.08, -0.11], [-0.19, 0.04]], 0.009);
                    Q.incise([[-0.04, -0.07], [-0.14, 0.07]], 0.009);
                    Q.incise([[0.00, 0.05], [0.14, 0.11]], 0.008);       // the cheekbone
                });
            }
        },
        bull: {
            name: 'Bull Forepart',
            fill: 0.91,
            draw: function (P) {
                // ⛔ THE FIRST VERSION READ AS A COMMA. Its horns were a single 0.024-wide ARC BAND
                // spanning half a turn behind the head - one thin curve above a rounded mass, which
                // is a tail or a hook long before it is a pair of horns. §22a-2c is the diagnosis:
                // the eye assigns a shape to a body part BY POSITION FIRST, and a curve sitting on
                // TOP of a head is an ear or a crest, so it took the nearest such reading.
                //
                // ⭐ A bull is read from TWO horns that sweep FORWARD past the muzzle line, which is
                // a position nothing else in this corpus occupies, plus the boss between them. Two
                // separate tapered horns cannot be mistaken for one hook. And a FOREPART - the
                // animal cut at the shoulder - is a real coinage device and is strongly asymmetric,
                // so it cannot pair with the horse.
                // ⚠️ PASS 3, AND THE SAME MISTAKE AS `stag` PASS 2: horns long enough to be safely
                // above the floor became TWO ARMS WITH HOOKS and the device read as a turret. A
                // horn that is longer than the skull is wide has stopped being a horn.
                //
                // ⭐ A bull's horns are read as a LYRE - a single continuous sweep out and up, both
                // sides, meeting over the boss - and that shape is short, thick, and unmistakable.
                // §22a-2c: it is also a position nothing else here occupies, because it sits
                // ABOVE-AND-OUTSIDE the skull rather than on top of it (on top = ears).
                P.poly([[-0.28, -0.02], [-0.12, -0.11], [0.05, -0.10], [0.19, 0.00],
                        [0.22, 0.12], [0.12, 0.20], [-0.08, 0.18], [-0.28, 0.18]]);
                // the boss between the horns, OVERLAPPING the skull rather than sitting on it
                P.poly([[-0.13, -0.09], [-0.02, -0.15], [0.08, -0.11], [0.06, -0.05], [-0.10, -0.04]]);
                P.limb(-0.11, -0.11, -0.20, -0.19, 0.032, 0.020);      // the lyre, left
                P.limb(-0.20, -0.19, -0.19, -0.28, 0.020, 0.010);
                P.limb(0.05, -0.12, 0.15, -0.19, 0.030, 0.019);        // the lyre, right - UNEQUAL
                P.limb(0.15, -0.19, 0.17, -0.27, 0.019, 0.010);
                P.detail(90, function (Q) {
                    Q.inciseArc(0.08, -0.01, 0.030, Math.PI * 0.8, Math.PI * 2.5, 0.009);
                    Q.incise([[0.16, 0.07], [0.20, 0.06]], 0.010);      // nostril
                });
                P.detail(125, function (Q) {
                    Q.incise([[-0.09, -0.09], [0.03, -0.11]], 0.009);   // the curls on the boss
                    Q.incise([[-0.08, -0.06], [0.04, -0.08]], 0.009);
                    Q.incise([[-0.20, 0.04], [-0.06, 0.09]], 0.008);   // the dewlap
                });
            }
        }
    };

    // =============================================================================================
    // REVERSE — WHAT THE POWER CLAIMS (18)
    //
    // Grain, wine, oil, fish, trade, law, craft, land, water, faith, plenty, access, defence,
    // learning, rite, height. A reverse is the realm's argument for itself.
    // =============================================================================================

    D.REVERSE = {
        wheat: {
            name: 'Ear of Wheat',
            fill: 0.95,
            draw: function (P) {
                // ⛔ THE FIRST VERSION READ AS A FISHBONE - or a signpost. The grains were flat
                // quadrilaterals stuck out sideways from a straight stalk, and a straight line with
                // flat flags on it is a bone before it is an ear of corn.
                //
                // ⭐ A grain is PLUMP and it hugs the stalk, leaning upward; it is a swelling, not a
                // flag. And the awns - the long bristles at the top - are the one feature no other
                // plant in this corpus has, so they carry the read the way the stag's branching
                // does (§22a-2c: an unoccupied position).
                P.limb(0.00, 0.32, 0.00, -0.04, 0.022, 0.016);
                // grains alternate down the stalk, never paired across it
                for (var i = 0; i < 6; i++) {
                    var y = -0.18 + i * 0.072;
                    var s = (i % 2 === 0) ? 1 : -1;
                    P.poly([[0.00, y + 0.005],
                            [s * 0.045, y - 0.030], [s * 0.105, y - 0.010],
                            [s * 0.120, y + 0.035], [s * 0.075, y + 0.062],
                            [s * 0.025, y + 0.055]]);
                }
                P.limb(0.00, -0.18, 0.00, -0.28, 0.016, 0.008);
                // the awns: three fine bristles, unequal, springing from the top of the ear
                P.detail(105, function (Q) {
                    Q.limb(0.00, -0.24, -0.09, -0.36, 0.011, 0.005);
                    Q.limb(0.00, -0.25, 0.02, -0.38, 0.011, 0.005);
                    Q.limb(0.00, -0.24, 0.10, -0.34, 0.011, 0.005);
                });
                // the crease down each grain - the cut that makes a swelling read as a SEED
                P.detail(135, function (Q) {
                    for (var j = 0; j < 6; j++) {
                        var yy = -0.18 + j * 0.072;
                        var ss = (j % 2 === 0) ? 1 : -1;
                        Q.incise([[ss * 0.035, yy + 0.030], [ss * 0.095, yy + 0.012]], 0.008);
                    }
                });
            }
        },
        vine: {
            name: 'Vine and Grapes',
            fill: 0.90,
            draw: function (P) {
                P.limb(-0.04, -0.26, 0.00, -0.12, 0.014, 0.011);
                // a bunch TAPERS to a point - that shape is the whole read
                var rows = [3, 3, 2, 1], y = -0.10;
                for (var r = 0; r < rows.length; r++) {
                    for (var i = 0; i < rows[r]; i++) {
                        var x = (i - (rows[r] - 1) / 2) * 0.085;
                        P.disc(x, y, 0.048);
                    }
                    y += 0.078;
                }
                // ⛔ THE LEAF WAS A FLAT SLAB and read as a paddle. A vine leaf's identity is its
                // LOBES and its palmate VEINS, and neither existed: the lobes are a silhouette fact
                // that a quadrilateral cannot state, and the veins are cuts, which had no primitive.
                P.poly([[0.02, -0.13], [0.09, -0.20], [0.16, -0.18], [0.19, -0.25],
                        [0.25, -0.19], [0.32, -0.19], [0.28, -0.11], [0.31, -0.05],
                        [0.22, -0.05], [0.17, -0.01], [0.13, -0.07]]);
                P.detail(115, function (Q) {
                    Q.incise([[0.06, -0.10], [0.20, -0.20]], 0.009);        // palmate veins, from
                    Q.incise([[0.06, -0.10], [0.27, -0.16]], 0.009);        // ONE point, as a leaf's
                    Q.incise([[0.06, -0.10], [0.24, -0.07]], 0.009);        // veins actually run
                    Q.incise([[0.06, -0.10], [0.16, -0.03]], 0.009);
                });
                P.detail(140, function (Q) {
                    Q.limb(0.00, -0.13, -0.10, -0.22, 0.010, 0.005);        // the tendril
                    Q.limb(-0.10, -0.22, -0.16, -0.16, 0.008, 0.004);
                });
            }
        },
        olive: {
            name: 'Olive Branch',
            fill: 0.93,
            draw: function (P) {
                // ⛔ THE FIRST VERSION READ AS A RIFLE. A dead-straight shaft with angular
                // triangles alternating off it is a stock, a barrel and a sight - and §22a-3b is
                // the reason the obvious repair does not work: a leaf's serration is finer than a
                // pixel here, so serrating them would have produced a SAW, exactly as the quill's
                // barbs did on the Wanted Posters sheet.
                //
                // ⭐ What separates a branch from a weapon at this size is that a branch CURVES and
                // its leaves are ROUNDED and all sweep the same way. A rifle is straight; a bough
                // bends under its own weight. The leaves are ellipse-like polys rather than
                // triangles, and their midribs are cut in, which is the one leaf cue that survives.
                P.limb(-0.30, 0.16, -0.10, 0.02, 0.024, 0.018);
                P.limb(-0.10, 0.02, 0.10, -0.06, 0.018, 0.014);
                P.limb(0.10, -0.06, 0.28, -0.20, 0.014, 0.008);
                var pts = [[-0.20, 0.11], [-0.06, 0.00], [0.08, -0.05], [0.20, -0.13]];
                for (var i = 0; i < pts.length; i++) {
                    var s = (i % 2 === 0) ? 1 : -1;
                    var x = pts[i][0], y = pts[i][1];
                    // a rounded lanceolate leaf, swept back toward the stem, never a triangle
                    P.poly([[x, y],
                            [x + 0.02, y + s * 0.05], [x + 0.05, y + s * 0.10],
                            [x + 0.10, y + s * 0.12], [x + 0.12, y + s * 0.09],
                            [x + 0.10, y + s * 0.04], [x + 0.05, y + s * 0.01]]);
                }
                P.detail(110, function (Q) {
                    Q.disc(0.00, 0.05, 0.032); Q.disc(-0.13, -0.01, 0.029);   // the olives
                });
                P.detail(130, function (Q) {
                    for (var j = 0; j < pts.length; j++) {
                        var t = (j % 2 === 0) ? 1 : -1;
                        Q.incise([[pts[j][0] + 0.01, pts[j][1] + t * 0.02],
                                  [pts[j][0] + 0.10, pts[j][1] + t * 0.08]], 0.008);
                    }
                });
            }
        },
        fish: {
            name: 'Fish',
            fill: 0.88,
            draw: function (P) {
                P.poly([[-0.30, -0.01], [-0.19, 0.09], [-0.05, 0.12], [0.12, 0.08],
                        [0.24, 0.00], [0.11, -0.08], [-0.06, -0.11], [-0.19, -0.08]]);
                P.poly([[-0.28, -0.01], [-0.34, -0.13], [-0.32, 0.11]]);       // tail
                P.poly([[-0.04, -0.10], [0.02, -0.21], [0.10, -0.07]]);        // dorsal
                P.detail(100, function (Q) { Q.disc(0.15, -0.01, 0.019); });
            }
        },
        amphora: {
            name: 'Amphora',
            fill: 0.89,
            draw: function (P) {
                P.poly([[-0.09, -0.22], [0.09, -0.22], [0.13, -0.10], [0.15, 0.06],
                        [0.07, 0.24], [-0.07, 0.24], [-0.15, 0.06], [-0.13, -0.10]]);
                P.arc(-0.14, -0.12, 0.085, Math.PI * 0.45, Math.PI * 1.45, 0.018);
                P.arc(0.14, -0.12, 0.085, Math.PI * 1.55, Math.PI * 2.55, 0.018);
                P.poly([[-0.11, -0.26], [0.11, -0.26], [0.09, -0.20], [-0.09, -0.20]]);
            }
        },
        balance: {
            name: 'Balance',
            fill: 0.96,
            draw: function (P) {
                // ⛔ TILTED ON PURPOSE. A level balance is two equal masses either side of a
                // vertical axis, which is §22a's spectacles failure exactly. Tilting it makes the
                // two pans different heights and different apparent sizes, and it also reads as a
                // balance IN USE rather than as a symbol.
                // ⛔ AND THE FIRST VERSION READ AS SCATTERED STICKS AND TWO HOOKS. Every part of it
                // was 6.37 px at inspect size - the thinnest structural mark in the whole corpus,
                // and just above the 5 px floor, which is to say AT it. §22a-2b: at the floor the
                // eye assigns a mark to the nearest common category, and a thin line beside another
                // thin line is not an instrument, it is debris. The geometry pass called this clean,
                // which is §12b in one row: a check that cannot fail on the defect it names reports
                // coverage that does not exist.
                //
                // ⭐ The pans are now SOLID DISHES rather than thin arcs, because a pan is read from
                // its mass and a thin arc is read as a hook. The beam and post are heavy enough to
                // be joinery. The cords are the only fine marks left, and they hang between two
                // things that already read, which is the one job a fine mark can do.
                P.limb(0.00, -0.28, 0.00, 0.10, 0.030, 0.024);
                P.limb(-0.27, -0.16, 0.27, -0.02, 0.024, 0.024);
                P.poly([[-0.35, -0.06], [-0.15, -0.06], [-0.19, 0.07], [-0.31, 0.07]]);  // pans, SOLID
                P.poly([[0.14, 0.07], [0.32, 0.07], [0.29, 0.18], [0.17, 0.18]]);        // and unequal
                P.poly([[-0.10, 0.10], [0.10, 0.10], [0.13, 0.20], [-0.13, 0.20]]);      // the foot
                P.detail(110, function (Q) {
                    Q.limb(-0.26, -0.15, -0.26, -0.07, 0.010, 0.010);    // the cords
                    Q.limb(0.24, -0.02, 0.24, 0.06, 0.010, 0.010);
                    Q.disc(0.00, -0.28, 0.036);                          // the finial
                });
                P.detail(130, function (Q) {
                    Q.incise([[-0.33, -0.02], [-0.17, -0.02]], 0.009);   // the dishes' rims
                    Q.incise([[0.16, 0.11], [0.30, 0.11]], 0.009);
                });
            }
        },
        hammer: {
            name: 'Hammer and Tongs',
            fill: 0.92,
            draw: function (P) {
                P.limb(-0.22, 0.24, 0.10, -0.18, 0.022, 0.016);
                P.poly([[0.00, -0.20], [0.20, -0.28], [0.27, -0.15], [0.07, -0.08]]);   // head
                P.limb(0.22, 0.24, -0.02, -0.10, 0.018, 0.011);                          // tongs
                P.limb(0.22, 0.24, 0.10, -0.12, 0.018, 0.011);
            }
        },
        sickle: {
            name: 'Sickle',
            fill: 0.88,
            draw: function (P) {
                // ⛔ THE FIRST VERSION READ AS A HOCKEY STICK: one thin beam, one flat quad on the
                // end, one thin handle. §22c is the diagnosis - "a tool is read from the JOINT; a
                // blade NEAR a shaft is abstract marks, a blade GROWING OUT OF a shaft is a scythe"
                // - and nothing here grew out of anything.
                //
                // ⭐ A plough is read from THREE parts meeting at one point: the beam coming down,
                // the curved mouldboard turning the soil, and the pair of stilts a ploughman holds.
                // The stilts are what no other tool in this corpus has, and they must be a PAIR at
                // different angles, because a single handle is a stick.
                // ⛔⛔ THIS WAS `plough` AND IT FAILED THREE PASSES. The subject changed on the
                // fourth, which wing §22a-5b says to do on the SECOND: "changing the subject to
                // something that says the same thing is a legitimate move and it is the cheapest
                // one available. Ask on pass 2, not pass 5."
                //
                //   pass 1  beam + flat quad + handle          -> a HOCKEY STICK
                //   pass 2  beam down-right, stilts up-left    -> SCISSORS (two crossing bars)
                //   pass 3  one long sole, nothing crossing    -> a FOLDED FLAG
                //
                // ⚠️ And §22a-5b's own tell was present from pass 2: "the failures were different
                // each time, which is the sign that the SUBJECT is wrong rather than the numbers."
                // A plough is four members meeting at angles, and at 130 px four thin members are a
                // jumble whatever the angles are - the same reason §22a-5b killed a full-rigged ship
                // and replaced it with an anchor.
                //
                // ⭐ A SICKLE SAYS WHAT A PLOUGH SAYS - this power's claim is the land and its
                // harvest - and it is ONE continuous shape with a deep asymmetric curve, which is
                // the easiest thing in this whole corpus to read. Note it does NOT collide with
                // `wheat`: that is a plant, this is a tool, and the two share no silhouette feature.
                // ⛔ THE FIRST SICKLE COLLIDED WITH `cornucopia`, WHICH IS THE THING §22b EXISTS TO
                // CATCH AND WHICH I INTRODUCED WHILE FIXING SOMETHING ELSE. Both were a SOLID
                // TAPERING CURL, and §22a-4 is the law: a strong silhouette feature outranks every
                // difference beneath it, so a haft and a mouth are differences BENEATH "a thick
                // curved horn" and could not separate them. Changing the subject fixed the plough
                // and broke the set - which is why a change of subject is re-judged on the SHEET.
                //
                // ⭐ A sickle's blade is not a mass, it is an EDGE: a thin crescent of steel with
                // daylight inside the curve. Biting the inner curve out with `hole` makes that
                // literal, and a thin open crescent and a fat closed horn are different pictures at
                // any size - which no amount of reshaping a solid blade would have achieved.
                P.poly([
                    [-0.28, -0.14],                                  // the point of the blade
                    [-0.10, -0.26], [0.10, -0.24], [0.24, -0.10],    // the outer edge of the curve
                    [0.27, 0.06], [0.13, 0.08], [0.10, -0.06], [-0.04, -0.15]
                ]);
                P.hole(0.03, 0.06, 0.215);                           // daylight INSIDE the curve
                P.limb(0.20, 0.02, 0.12, 0.30, 0.044, 0.034);        // the haft, at a clear angle
                P.detail(110, function (Q) {
                    Q.disc(0.17, 0.14, 0.032);                       // the ferrule
                    Q.incise([[-0.22, -0.16], [0.04, -0.17]], 0.010);  // the edge bevel, CUT in
                    Q.incise([[0.15, 0.21], [0.13, 0.28]], 0.010);     // the grip's binding
                });
            }
        },
        bridge: {
            name: 'Bridge',
            fill: 0.99,
            draw: function (P) {
                // ⛔ THE FIRST VERSION READ AS A HAMBURGER: a bar, three lumps, another bar. The
                // arches were drawn as arc BANDS - thin raised curves sitting under a deck - so the
                // bridge was made of the same additive marks as everything else, and an arch that
                // is a raised line is a lump rather than an opening.
                //
                // ⭐ AN ARCH IS A HOLE. That is not a stylistic reading; it is what an arch IS, and
                // it became expressible only when `hole` did. The masonry is now ONE solid block and
                // the three openings are bitten out of it, so the piers between them are real
                // remaining metal and the light passes through where a bridge is open.
                //
                // ⚠️ The bites are scoped to the ops BEFORE them (see `hole`), which is why the
                // water below can be laid afterwards without being eaten.
                P.poly([[-0.32, -0.10], [0.32, -0.10], [0.32, 0.12], [-0.32, 0.12]]);
                // THREE arches of UNEQUAL span, so the span reads as a bridge rather than an arcade
                P.hole(-0.19, 0.13, 0.098);
                P.hole(0.03, 0.13, 0.128);
                P.hole(0.24, 0.13, 0.082);
                P.poly([[-0.34, -0.10], [0.34, -0.10], [0.34, -0.03], [-0.34, -0.03]]);  // the parapet
                P.poly([[-0.32, 0.22], [0.32, 0.22], [0.32, 0.28], [-0.32, 0.28]]);      // water
                P.detail(120, function (Q) {
                    Q.incise([[-0.30, 0.02], [-0.26, 0.02]], 0.010);    // coursed masonry, CUT
                    Q.incise([[-0.09, 0.00], [-0.05, 0.00]], 0.010);
                    Q.incise([[0.13, 0.00], [0.17, 0.00]], 0.010);
                    Q.incise([[0.29, 0.02], [0.32, 0.02]], 0.010);
                });
            }
        },
        gate: {
            name: 'City Gate',
            fill: 0.97,
            draw: function (P) {
                // ⛔ THE FIRST VERSION READ AS A SACK WITH LEGS, and §22a-2c names the cause
                // exactly: "the eye assigns a shape to a body part by POSITION FIRST - under the
                // body = leg." Three thin raised bars hanging below a rounded mass are legs before
                // they are a portcullis, whatever they are called, and no amount of reshaping them
                // helps while they are raised marks in that position.
                //
                // ⭐ Two fixes, both structural. The gateway is a HOLE bitten out of the wall, so
                // the opening is an opening; and the portcullis is CUT INTO the metal that remains
                // above it, so the grille can never detach and become a limb.
                P.poly([[-0.26, -0.14], [0.26, -0.14], [0.28, 0.28], [-0.28, 0.28]]);
                P.hole(0.00, 0.30, 0.145);
                P.poly([[-0.28, -0.14], [-0.28, -0.24], [-0.18, -0.24], [-0.18, -0.14]]);
                P.poly([[0.18, -0.14], [0.18, -0.26], [0.28, -0.26], [0.28, -0.14]]);   // unequal
                P.poly([[-0.05, -0.14], [-0.05, -0.22], [0.05, -0.22], [0.05, -0.14]]);
                P.detail(110, function (Q) {
                    Q.incise([[-0.09, 0.02], [-0.09, 0.16]], 0.011);     // the portcullis, CUT
                    Q.incise([[0.00, 0.00], [0.00, 0.16]], 0.011);
                    Q.incise([[0.09, 0.02], [0.09, 0.16]], 0.011);
                    Q.incise([[-0.13, 0.10], [0.13, 0.10]], 0.010);
                });
                P.detail(140, function (Q) {
                    Q.incise([[-0.26, -0.06], [-0.16, -0.06]], 0.009);   // coursed stone
                    Q.incise([[0.16, -0.06], [0.26, -0.06]], 0.009);
                    Q.incise([[-0.24, 0.06], [-0.16, 0.06]], 0.009);
                    Q.incise([[0.17, 0.06], [0.25, 0.06]], 0.009);
                });
            }
        },
        star: {
            name: 'Star of Rays',
            fill: 1.00,
            draw: function (P) {
                // EIGHT even points, distinct from sunWheel's twelve alternating ones plus its
                // central disc. §22a-4: only one device in a corpus may own a given skyline shape,
                // so the sun keeps its boss and the star has none.
                var pts = [];
                for (var i = 0; i < 16; i++) {
                    var a = (i / 16) * Math.PI * 2 - Math.PI / 2;
                    var r = (i % 2 === 0) ? 0.300 : 0.105;
                    pts.push([Math.cos(a) * r, Math.sin(a) * r]);
                }
                P.poly(pts);
            }
        },
        flame: {
            name: 'Altar Flame',
            fill: 0.96,
            draw: function (P) {
                // ⛔⛔ A REAL COLLISION, AND THE ONLY KIND OF DEFECT A CONTACT SHEET EXISTS TO FIND:
                // this device read as A MOUNTAIN, and `mountain` sits THREE CELLS AWAY ON THE SAME
                // SHEET. Wing §22b: two entries that read as the same picture are worse than one
                // weak entry, because a visible duplicate makes the whole set look generated.
                //
                // The cause was that the flame was a single closed polygon with a broad base and a
                // point at the top - which is a peak. §22a-4: a strong silhouette feature outranks
                // every difference beneath it, and "a filled mass rising to a point" was the
                // feature both shapes shared.
                //
                // ⭐ The escape is that a flame has SEPARATE TONGUES with paper between them, and a
                // mountain never does. Three tongues of unequal height, all leaning the same way,
                // rising from a fire that is WIDER than the altar it stands on - a peak cannot
                // overhang its own base, so an overhang is a shape only fire makes.
                P.poly([[-0.24, 0.30], [0.24, 0.30], [0.19, 0.19], [-0.19, 0.19]]);     // altar
                P.detail(120, function (Q) {
                    Q.incise([[-0.16, 0.245], [0.16, 0.245]], 0.011);                    // its moulding
                });
                P.poly([[-0.15, 0.19], [0.15, 0.19], [0.12, 0.13], [-0.12, 0.13]]);
                // the tongues, all leaning right, none touching another above the fire bed
                P.poly([[-0.13, 0.13], [-0.20, 0.02], [-0.10, 0.05], [-0.11, -0.09],
                        [-0.03, 0.04], [-0.02, 0.13]]);
                P.poly([[-0.03, 0.13], [-0.02, -0.02], [0.05, -0.30], [0.06, -0.05],
                        [0.13, -0.13], [0.08, 0.13]]);
                P.poly([[0.10, 0.13], [0.17, -0.02], [0.22, -0.07], [0.20, 0.06],
                        [0.24, 0.09], [0.18, 0.13]]);
            }
        },
        cornucopia: {
            name: 'Cornucopia',
            fill: 0.93,
            draw: function (P) {
                // ⛔ THE FIRST VERSION READ AS A COMMA. A tapering curve with a couple of discs
                // near the fat end is a punctuation mark long before it is a horn of plenty, and
                // §22a says the eye takes the cheapest reading available.
                //
                // ⭐ Two things make a cornucopia: it is RIBBED, and the fruit SPILLS OUT past the
                // mouth rather than sitting inside it. The ribs are cuts - they did not exist as a
                // primitive until `incise` did - and they are the single feature that separates a
                // horn from a comma at any size.
                // ⚠️ PASS 3. Pass 2 added the ribs and the spilling fruit and the horn still read as
                // a TORCH, because the horn itself was three limbs in a nearly straight line: a
                // straight tapering shaft with things coming out of the wide end is a torch, a
                // rocket or a bouquet, and the ribs only made it a fluted one.
                //
                // ⭐ The read is the CURL, and nothing else. A cornucopia is a horn that turns
                // through most of a half-circle and tucks its point back under its own belly - so
                // the tip ends up BEHIND the body of the horn, which is a relationship no straight
                // object can have. That needed the limbs laid along a real arc rather than a line.
                P.limb(-0.04, 0.30, -0.16, 0.24, 0.022, 0.040);      // the tip, tucked back UNDER
                P.limb(-0.16, 0.24, -0.22, 0.12, 0.040, 0.058);
                P.limb(-0.22, 0.12, -0.20, -0.02, 0.058, 0.076);     // the belly of the curl
                P.limb(-0.20, -0.02, -0.10, -0.14, 0.076, 0.092);
                P.limb(-0.10, -0.14, 0.04, -0.20, 0.092, 0.100);     // the mouth end, wide
                P.poly([[0.00, -0.30], [0.16, -0.26], [0.20, -0.12],
                        [0.08, -0.06], [-0.02, -0.10]]);             // the mouth, opening UP-RIGHT
                // the fruit, spilling FORWARD and DOWN out of the mouth, unequal
                P.disc(0.18, -0.28, 0.058);
                P.disc(0.27, -0.16, 0.048);
                P.detail(110, function (Q) {
                    Q.disc(0.29, -0.03, 0.040);
                    Q.disc(0.09, -0.34, 0.036);
                });
                // the ribs - they follow the curl, which is what tells the eye the horn is turning
                P.detail(100, function (Q) {
                    Q.incise([[-0.20, 0.20], [-0.11, 0.17]], 0.010);
                    Q.incise([[-0.23, 0.07], [-0.13, 0.06]], 0.011);
                    Q.incise([[-0.18, -0.06], [-0.09, -0.09]], 0.012);
                });
            }
        },
        key: {
            name: 'Key',
            fill: 0.87,
            draw: function (P) {
                // ⛔ §22a's table: "a round bow above a tapering shaft" read as a KEYHOLE. The
                // escape is the BIT - real teeth cut on one side only, at the far end, which no
                // keyhole has and which makes the whole device asymmetric along its length.
                P.arc(-0.02, -0.20, 0.100, 0, Math.PI * 2, 0.028);
                P.limb(-0.02, -0.10, -0.02, 0.24, 0.026, 0.022);
                P.poly([[0.00, 0.06], [0.14, 0.06], [0.14, 0.13], [0.00, 0.13]]);
                P.poly([[0.00, 0.16], [0.10, 0.16], [0.10, 0.23], [0.00, 0.23]]);
            }
        },
        spearShield: {
            name: 'Spear and Shield',
            fill: 0.92,
            draw: function (P) {
                P.limb(0.22, -0.30, -0.14, 0.30, 0.018, 0.014);
                P.poly([[0.22, -0.30], [0.29, -0.16], [0.17, -0.18]]);
                P.poly([[-0.22, -0.16], [0.10, -0.16], [0.10, 0.06],
                        [-0.06, 0.24], [-0.22, 0.06]]);
                P.detail(120, function (Q) { Q.disc(-0.06, 0.00, 0.045); });
            }
        },
        codex: {
            name: 'Codex',
            fill: 0.94,
            draw: function (P) {
                // pages of UNEQUAL fan on the two sides, so it cannot pair down the spine
                P.poly([[-0.30, -0.10], [-0.02, -0.16], [-0.02, 0.14], [-0.30, 0.20]]);
                P.poly([[0.02, -0.16], [0.28, -0.06], [0.28, 0.24], [0.02, 0.14]]);
                P.limb(0.00, -0.16, 0.00, 0.15, 0.014, 0.014);
                P.detail(130, function (Q) {
                    Q.limb(-0.24, -0.02, -0.08, -0.05, 0.007, 0.007);
                    Q.limb(-0.24, 0.05, -0.08, 0.02, 0.007, 0.007);
                    Q.limb(0.08, 0.02, 0.22, 0.07, 0.007, 0.007);
                });
            }
        },
        chalice: {
            name: 'Chalice',
            fill: 0.90,
            draw: function (P) {
                // ⛔ THE FIRST VERSION READ AS A BUCKET ON A STAND. A straight-sided tapering box on
                // a stem is a pail; what makes a chalice is that the bowl FLARES outward at the lip
                // and pinches at the foot of the bowl, and that it carries a KNOP - the swelling
                // partway down the stem that a hand grips. A pail has neither.
                P.poly([[-0.21, -0.22], [0.21, -0.22], [0.17, -0.12],
                        [0.09, 0.00], [-0.09, 0.00], [-0.17, -0.12]]);
                P.limb(0.00, 0.00, 0.00, 0.20, 0.022, 0.026);
                P.disc(0.00, 0.09, 0.048);                                   // the knop
                P.poly([[-0.22, 0.30], [0.22, 0.30], [0.15, 0.20], [-0.15, 0.20]]);
                P.detail(105, function (Q) {
                    Q.incise([[-0.20, -0.17], [0.20, -0.17]], 0.011);        // the lip band
                    Q.inciseArc(0.00, 0.09, 0.030, 0, Math.PI * 2, 0.009);   // the knop's collar
                });
                P.detail(140, function (Q) {
                    Q.incise([[-0.10, -0.14], [-0.06, -0.03]], 0.008);       // the bowl's flutes
                    Q.incise([[0.00, -0.14], [0.00, -0.02]], 0.008);
                    Q.incise([[0.10, -0.14], [0.06, -0.03]], 0.008);
                });
            }
        },
        mountain: {
            name: 'Mountain',
            fill: 0.97,
            draw: function (P) {
                // ⛔ §22b-1's warning: `peak` owns the pointed skyline in a map corpus, so nothing
                // else may be triangular AT ANY SIZE. Here the mountain is the only triangular
                // silhouette on the reverse side, and the star (which is spiky, not triangular)
                // is its nearest neighbour - they are separated by having a BASE.
                P.poly([[-0.32, 0.24], [-0.10, -0.20], [0.02, 0.02], [0.12, -0.12], [0.32, 0.24]]);
                P.poly([[-0.15, -0.08], [-0.10, -0.20], [-0.04, -0.08], [-0.09, -0.05]]);  // snow
                P.poly([[-0.32, 0.24], [0.32, 0.24], [0.32, 0.30], [-0.32, 0.30]]);
            }
        }
    };

    D.OBVERSE_IDS = Object.keys(D.OBVERSE);
    D.REVERSE_IDS = Object.keys(D.REVERSE);

    /**
     * @param {string} side 'obverse' | 'reverse'
     * @param {string} id device id
     * @returns {object} the device record. Throws on an unknown id - wing §21c: an unknown motif
     *          that is silently SKIPPED is a defect that fails in the flattering direction.
     */
    D.get = function (side, id) {
        var t = (side === 'obverse') ? D.OBVERSE : (side === 'reverse') ? D.REVERSE : null;
        if (!t) throw new Error('SpecieDevices: unknown side "' + side + '"');
        if (!t[id]) throw new Error('SpecieDevices: unknown ' + side + ' device "' + id + '"');
        return t[id];
    };

    /**
     * Run a device into a fresh recorder and return its report.
     * @returns {{total:number, counts:object, extent:number}}
     */
    D.measure = function (side, id) {
        var P = D.recorder();
        D.get(side, id).draw(P);
        return P.report();
    };

    /**
     * AUTHORED entity count on this axis. Never a multiplication (master §1.1 q3, wing §21i).
     * @returns {number}
     */
    D.volume = function () { return D.OBVERSE_IDS.length + D.REVERSE_IDS.length; };

})(SpecieDevices);
