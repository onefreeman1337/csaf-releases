/*:
 * @target MZ
 * @plugindesc [Specie] Letterform corpus — authored alphabets and the level-of-detail law for a rim legend. Library file; no parameters.
 * @author Core Systems Asset Factory
 *
 * @help
 * SpecieLetters.js
 *
 * The lettering a realm strikes its own name in, and the arithmetic that decides
 * whether a legend can exist at all at a given size.
 *
 * ⛔ THIS IS THE FILE THE ARCHITECTURE NAMED AS THE ONE THAT COULD SINK THE
 * PRODUCT, and the reason is a level of detail problem rather than a font
 * problem. A coin is seen at two wildly different sizes:
 *
 *   purse / item icon   ~32 px   a legend here is NOT letters. It is grey mush.
 *   inspect plate      ~260 px   real letterforms, readable
 *
 * So the legend is a level-of-detail TABLE WITH ARITHMETIC THRESHOLDS, and
 * `fitGlyphs()` is the function that owns them. Below the count it returns, the
 * rim degrades to an honest RHYTHM BAND - the beading a legend sits on - rather
 * than to fake letters. Wing §17c-1: a feature that cannot exist at the product's
 * own scale must move to a scale where it can, or be deleted; it is never simply
 * drawn anyway, because a correct rule executed below the resolution floor
 * produces a CONFIDENT WRONG PICTURE (§22a-3b).
 *
 * It has NO dependency on RPG Maker MZ and makes no engine calls.
 *
 * Load order does not matter. Nothing here resolves a sibling file.
 */

var SpecieLetters = SpecieLetters || {};

(function (L) {
    'use strict';

    // =============================================================================================
    // THE MEASURED LAW: PITCH IS `ink + PAPER_MIN`, IN ABSOLUTE PIXELS, NEVER A RATIO
    //
    // Wing §22a-2d, measured on Shipwright across 4 ink widths x 21 pitches. The first pitch that
    // leaves real paper is NOT one ratio - it moves by 1.8x across the range (3.6 at 1px ink, 2.0
    // at 3px) - but subtract the ink and all four rows collapse: every FAILING case left <= 2.4px
    // of paper and every PASSING case >= 2.49px.
    //
    // ⛔ A ratio tuned at a comfortable size is always too tight at the thumbnail, and the thumbnail
    // is exactly where this product lives half the time. So every threshold below is in PIXELS.
    // =============================================================================================

    L.PAPER_MIN_PX = 2.6;         // the measured gap between two strokes that still reads as a gap
    L.STROKE_MIN_PX = 1.15;       // below this a letter stroke is a smear, not a stroke
    L.EM_MIN_PX = 9.0;            // below this cap height NO alphabet resolves, whatever its ink

    /**
     * How many glyphs of a given size actually RESOLVE along a run, and at what pitch.
     *
     * ⛔ THE RETURN IS AN OBJECT AND CALLERS MUST NOT READ IT AS A SCALAR. Wing §22b-1b: Colophon's
     * `repeatsFor` returned {count,pitch,floored}, six call sites read it as a number, `0 < {}` is
     * FALSE, and every one of those loops silently never ran - while the shapes around the dead
     * bands drew normally, so no counter read zero and the Gate 1 review blamed the draughtsmanship.
     *
     * @param {number} runPx the length of the run in pixels (an arc length, for a rim legend).
     * @param {number} emPx the cap height in pixels.
     * @param {number} inkPx the stroke width in pixels.
     * @returns {{count:number, pitch:number, advance:number, resolves:boolean, why:string}}
     */
    L.fitGlyphs = function (runPx, emPx, inkPx) {
        // A letter is not one stroke: it is several, and the ones that matter are the two uprights
        // of an H or an N. So the legibility question is whether TWO strokes plus the paper between
        // them fit inside one glyph's width - which is the §22a-2d law applied inside the letterform
        // rather than between letterforms.
        var advance = emPx * L.ADVANCE;                   // nominal width of one glyph
        var innerGap = advance - 2 * inkPx;               // the counter of an H, in px
        var pitch = advance + Math.max(L.PAPER_MIN_PX, inkPx);   // glyph + the space after it

        var why = '';
        if (emPx < L.EM_MIN_PX) why = 'cap height ' + emPx.toFixed(1) + 'px below the ' + L.EM_MIN_PX + 'px floor';
        else if (inkPx < L.STROKE_MIN_PX) why = 'ink ' + inkPx.toFixed(2) + 'px below the ' + L.STROKE_MIN_PX + 'px floor';
        else if (innerGap < L.PAPER_MIN_PX) why = 'counter ' + innerGap.toFixed(2) + 'px below the ' + L.PAPER_MIN_PX + 'px paper floor';
        else if (runPx < pitch * 4) why = 'run fits fewer than 4 glyphs';

        var resolves = why === '';
        return {
            count: resolves ? Math.floor(runPx / pitch) : 0,
            pitch: pitch,
            advance: advance,
            resolves: resolves,
            why: why || 'resolves'
        };
    };

    L.ADVANCE = 0.72;             // a glyph's width as a fraction of its cap height

    /**
     * Set a KNOWN NUMBER OF GLYPHS into a known run, and say honestly whether they fit.
     *
     * ⛔⛔ THIS FUNCTION EXISTS BECAUSE `fitGlyphs` ALONE SHIPPED "AURELIA IMPERATRIX" AS
     * "AURELIA IMP", WHICH IS WING §22f VERBATIM: "a fitter that can fail to fit MUST SAY SO" -
     * `fitTracked` shrank to its minimum size, returned a still-too-wide result, and the caller drew
     * it anyway, so "SEVEN OF WANDS" shipped as "SEVEN OF WAND".
     *
     * `fitGlyphs` answers "how many glyphs COULD go here", which is a fact about the run. It cannot
     * answer "does THIS text fit", and a caller that takes the first N characters of a legend has
     * silently invented an abbreviation nobody chose. Real coin legends ARE abbreviated - IMP CAES
     * DIVI F AVG - but that is an authoring decision, not a rendering accident.
     *
     * ⇒ Tracking is surrendered FIRST, down to the measured paper floor and no further (§22a-2d),
     * and only then does it report an overflow. The caller must read `overflow` and act.
     *
     * @param {number} runPx
     * @param {number} emPx
     * @param {number} inkPx
     * @param {number} n how many glyphs the caller actually wants to set.
     * @returns {{resolves:boolean, fits:boolean, count:number, overflow:number, pitch:number,
     *            squeezed:boolean, why:string}}
     */
    L.setText = function (runPx, emPx, inkPx, n) {
        var base = L.fitGlyphs(runPx, emPx, inkPx);
        if (!base.resolves || n <= 0) {
            return {
                resolves: base.resolves, fits: false, count: 0, overflow: n,
                pitch: base.pitch, squeezed: false, why: base.why
            };
        }
        // The tightest legal pitch: one glyph plus the measured minimum paper after it. Below this
        // the letters touch, which is the §22a-2d failure and is not a legend.
        var minPitch = base.advance + L.PAPER_MIN_PX;
        var want = runPx / n;
        var pitch = Math.max(minPitch, Math.min(base.pitch, want));
        var fits = pitch * n <= runPx + 0.5;
        var maxN = Math.max(0, Math.floor(runPx / minPitch));
        return {
            resolves: true,
            fits: fits,
            count: fits ? n : maxN,
            overflow: fits ? 0 : (n - maxN),
            pitch: pitch,
            squeezed: pitch < base.pitch - 1e-9,
            why: fits
                ? (pitch < base.pitch - 1e-9 ? 'fits, tracking surrendered to the paper floor' : 'fits')
                : (n - maxN) + ' glyph(s) DO NOT FIT - abbreviate the legend or lengthen the arc'
        };
    };

    // =============================================================================================
    // THE ALPHABETS
    //
    // A glyph is a list of POLYLINES in a unit em box: x from 0 (left) to 1 (right), y from 0 (cap
    // line) to 1 (baseline). Strokes only - no fills - because a struck letter IS a stroke, and
    // because a stroke can be given a width in absolute pixels and therefore obey the law above.
    //
    // ⛔ AND THE ALPHABET IS THE PRODUCT'S IDENTITY AXIS, NOT A FONT PICKER. "A legend around the rim
    // in the realm's own lettering" is the claim, so the families are chosen to be different in
    // CONSTRUCTION rather than in style: one is built from straight strokes and arcs, one from
    // straight strokes ONLY, one from a vertical stave with branches. That difference survives at
    // rim size, where a difference of stroke modulation or serif treatment does not (§22a-3b: check
    // that a cue SURVIVES the size before relying on it).
    // =============================================================================================

    /** A circle approximated as a polyline, in em-box coordinates. */
    function ring(cx, cy, rx, ry, from, to, steps) {
        var pts = [], n = steps || 12;
        for (var i = 0; i <= n; i++) {
            var a = from + (to - from) * (i / n);
            pts.push([cx + Math.cos(a) * rx, cy + Math.sin(a) * ry]);
        }
        return pts;
    }

    // ---------------------------------------------------------------------------------------------
    // LAPIDARY — Roman square capitals. The default, and the most legible thing a rim can carry.
    // ---------------------------------------------------------------------------------------------
    var LAPIDARY = {
        A: [[[0.02, 1], [0.5, 0], [0.98, 1]], [[0.19, 0.62], [0.81, 0.62]]],
        B: [[[0.06, 0], [0.06, 1]], [[0.06, 0], [0.62, 0], [0.82, 0.14], [0.82, 0.34], [0.62, 0.48], [0.06, 0.48]],
            [[0.06, 0.48], [0.68, 0.48], [0.9, 0.64], [0.9, 0.84], [0.68, 1], [0.06, 1]]],
        C: [[[0.94, 0.16], [0.7, 0.0], [0.34, 0.0], [0.08, 0.24], [0.02, 0.5], [0.08, 0.76], [0.34, 1], [0.7, 1], [0.94, 0.84]]],
        D: [[[0.06, 0], [0.06, 1]], [[0.06, 0], [0.54, 0], [0.92, 0.3], [0.92, 0.7], [0.54, 1], [0.06, 1]]],
        E: [[[0.92, 0], [0.06, 0], [0.06, 1], [0.92, 1]], [[0.06, 0.5], [0.74, 0.5]]],
        F: [[[0.92, 0], [0.06, 0], [0.06, 1]], [[0.06, 0.5], [0.72, 0.5]]],
        G: [[[0.94, 0.16], [0.7, 0.0], [0.34, 0.0], [0.08, 0.24], [0.02, 0.5], [0.08, 0.76], [0.34, 1], [0.72, 1], [0.94, 0.8], [0.94, 0.56], [0.56, 0.56]]],
        H: [[[0.08, 0], [0.08, 1]], [[0.92, 0], [0.92, 1]], [[0.08, 0.52], [0.92, 0.52]]],
        I: [[[0.5, 0], [0.5, 1]]],
        J: [[[0.78, 0], [0.78, 0.76], [0.6, 1], [0.3, 1], [0.1, 0.8]]],
        K: [[[0.08, 0], [0.08, 1]], [[0.94, 0], [0.1, 0.56]], [[0.36, 0.38], [0.96, 1]]],
        L: [[[0.1, 0], [0.1, 1], [0.92, 1]]],
        M: [[[0.04, 1], [0.04, 0], [0.5, 0.74], [0.96, 0], [0.96, 1]]],
        N: [[[0.08, 1], [0.08, 0], [0.92, 1], [0.92, 0]]],
        O: [ring(0.5, 0.5, 0.46, 0.5, 0, Math.PI * 2, 14)],
        P: [[[0.08, 0], [0.08, 1]], [[0.08, 0], [0.66, 0], [0.88, 0.16], [0.88, 0.38], [0.66, 0.54], [0.08, 0.54]]],
        Q: [ring(0.5, 0.5, 0.46, 0.5, 0, Math.PI * 2, 14), [[0.6, 0.7], [0.98, 1.08]]],
        R: [[[0.08, 0], [0.08, 1]], [[0.08, 0], [0.66, 0], [0.88, 0.16], [0.88, 0.36], [0.66, 0.52], [0.08, 0.52]],
            [[0.44, 0.52], [0.96, 1]]],
        S: [[[0.92, 0.16], [0.68, 0.0], [0.32, 0.02], [0.12, 0.18], [0.16, 0.38], [0.44, 0.48],
             [0.72, 0.56], [0.9, 0.7], [0.86, 0.88], [0.62, 1], [0.26, 0.98], [0.06, 0.82]]],
        T: [[[0.02, 0], [0.98, 0]], [[0.5, 0], [0.5, 1]]],
        U: [[[0.08, 0], [0.08, 0.72], [0.28, 1], [0.72, 1], [0.92, 0.72], [0.92, 0]]],
        V: [[[0.02, 0], [0.5, 1], [0.98, 0]]],
        W: [[[0.0, 0], [0.24, 1], [0.5, 0.34], [0.76, 1], [1.0, 0]]],
        X: [[[0.04, 0], [0.96, 1]], [[0.96, 0], [0.04, 1]]],
        Y: [[[0.04, 0], [0.5, 0.52], [0.96, 0]], [[0.5, 0.52], [0.5, 1]]],
        Z: [[[0.06, 0], [0.94, 0], [0.06, 1], [0.94, 1]]],
        '0': [ring(0.5, 0.5, 0.42, 0.5, 0, Math.PI * 2, 14)],
        '1': [[[0.28, 0.18], [0.52, 0], [0.52, 1]], [[0.24, 1], [0.8, 1]]],
        '2': [[[0.1, 0.2], [0.34, 0.0], [0.7, 0.0], [0.9, 0.2], [0.86, 0.44], [0.1, 1], [0.94, 1]]],
        '3': [[[0.1, 0.14], [0.36, 0.0], [0.74, 0.0], [0.9, 0.18], [0.74, 0.44], [0.4, 0.48]],
              [[0.5, 0.48], [0.84, 0.56], [0.94, 0.78], [0.74, 1], [0.34, 1], [0.08, 0.86]]],
        '4': [[[0.72, 0], [0.06, 0.7], [0.96, 0.7]], [[0.72, 0.34], [0.72, 1]]],
        '5': [[[0.88, 0], [0.2, 0], [0.14, 0.42], [0.5, 0.36], [0.84, 0.5], [0.9, 0.76], [0.66, 1], [0.28, 1], [0.06, 0.86]]],
        '6': [[[0.86, 0.08], [0.5, 0.0], [0.18, 0.24], [0.12, 0.66], [0.32, 0.98], [0.7, 1], [0.9, 0.78], [0.78, 0.52], [0.4, 0.46], [0.14, 0.62]]],
        '7': [[[0.06, 0], [0.94, 0], [0.4, 1]]],
        '8': [ring(0.5, 0.25, 0.34, 0.25, 0, Math.PI * 2, 12), ring(0.5, 0.74, 0.42, 0.26, 0, Math.PI * 2, 12)],
        '9': [[[0.14, 0.92], [0.5, 1], [0.82, 0.76], [0.88, 0.34], [0.68, 0.02], [0.3, 0.0], [0.1, 0.22], [0.22, 0.48], [0.6, 0.54], [0.86, 0.38]]]
    };

    // ---------------------------------------------------------------------------------------------
    // STAVE — a runic family. Every glyph is a vertical STAVE with angular branches, and there is
    // not one curve in it.
    //
    // ⭐ This is the alphabet that proves the axis is real, because the difference from LAPIDARY is
    // CONSTRUCTIONAL rather than stylistic: a stave-and-branch letter has a different SILHOUETTE
    // from a bowl-and-stem letter at any size, while a difference of serif or stroke modulation
    // would vanish by 14px (§22a-3b: check the cue survives the size).
    // ---------------------------------------------------------------------------------------------
    // ⛔⛔ THIS TABLE WAS REDRAWN ON 2026-09-04 BECAUSE THE ALPHABET DID NOT SPELL. The first version
    // set the realm AUREUS as **FUREUF** and BASILISK as **Bᚠ≤ILI≤K** on every coin it struck, and
    // half of all buyers get this family because `SpecieCoinage` picks the alphabet by realm hash.
    //
    // THE CAUSE WAS ONE TEMPLATE REUSED. `A` and `F` were both "a stave with two branches going
    // right and down", differing by 0.02 in stave position; `1` and `I` were BYTE-IDENTICAL; and
    // `S` was a zigzag whose left extremes formed the same near-vertical edge, so it read as an
    // epsilon. `_probe/glyph_collide.js` then swept all 1,260 pairs and found ten more I had not
    // noticed - wing §22b-2 exactly: the eye finds the pair it happens to land on, the sweep finds
    // the pair that is actually worst.
    //
    // ⛔ AND NOTHING IN THE PRODUCT COULD SEE IT. `_probe/legend_ladder.js` reports "17 of 17 glyphs
    // struck, overflow 0" - true, and a count of DRAW CALLS (master §2b rule 2). Wing §17c: an id, a
    // count and a test are three statements about a table, and none of them is a mark on a bitmap.
    //
    // THE RULES THE REDRAW OBEYS, so a future addition cannot reintroduce the defect:
    //
    //  1. NO TWO LETTERS SHARE A BRANCH SCHEME. A stave letter is identified by the TRIPLE (which
    //     side the branches leave from, where up the stave they attach, how many there are), and no
    //     triple is used twice. Wing §22a-2c: the eye assigns a mark to a role by POSITION FIRST and
    //     geometry second, and no amount of reshaping beats an occupied position - which is why
    //     `A` moved to the LEFT of its stave rather than being redrawn on the right again.
    //
    //  2. A CLOSED SHAPE AND AN OPEN BRANCH ARE DIFFERENT MARKS, and the corpus uses both. `A` is a
    //     closed wedge, `F` is two open branches: that is a silhouette difference (§22a-3, the
    //     trailing edge separates two things of the same gross shape) rather than an interior one.
    //
    //  3. ⛔ EVERY DIGIT CARRIES A FULL-WIDTH BASE BAR AND NO LETTER HAS ONE. That is the fix for
    //     `1`/`I`, `5`/`H`, `5`/`N` and `2`/`3` as a CLASS rather than one pair at a time (wing §11:
    //     prefer a shape where two things agree by construction to one where they agree by care). A
    //     digit cannot collide with a letter, whatever is drawn above the bar.
    //
    // ⚠️ Digits never actually reach a legend today - `SpecieCoinage` strips non-letters when it
    // reads a realm, and denomination names are words - so this rule is about the corpus staying
    // honest for a buyer who calls `transliterate` with a date on it, which is a thing a coin has.
    var STAVE = {
        // stave + CLOSED WEDGE on the LEFT, upper: the only left-side closed mark in the family.
        A: [[[0.78, 0], [0.78, 1]], [[0.78, 0.02], [0.12, 0.24], [0.78, 0.46]]],
        // stave + TWO closed wedges, right: the only two-wedge letter.
        B: [[[0.2, 1], [0.2, 0]], [[0.2, 0.02], [0.8, 0.24], [0.2, 0.46]],
            [[0.2, 0.52], [0.8, 0.74], [0.2, 0.96]]],
        // an angular bracket with NO stave. It carried a stave and two horizontals, which is E minus
        // one branch - and a difference of COUNT is the weakest cue there is at rim size (measured
        // 0.160 from E at em 9). Dropping the stave makes it a SILHOUETTE difference instead, which
        // is §22a-3's law: two things of the same gross shape are separated by what their outline
        // does, never by what is drawn inside.
        C: [[[0.86, 0.08], [0.24, 0.28], [0.24, 0.72], [0.86, 0.92]]],
        // stave + ONE closed wedge spanning the FULL height: the largest closed mark.
        D: [[[0.16, 0], [0.16, 1]], [[0.16, 0.02], [0.9, 0.5], [0.16, 0.98]]],
        // stave + THREE horizontal branches: the only three-branch letter.
        E: [[[0.2, 0], [0.2, 1]], [[0.2, 0.06], [0.86, 0.06]], [[0.2, 0.5], [0.7, 0.5]],
            [[0.2, 0.94], [0.86, 0.94]]],
        // stave + two OPEN branches slanting down-right from the top half.
        F: [[[0.22, 0], [0.22, 1]], [[0.22, 0.06], [0.88, 0.28]], [[0.22, 0.42], [0.88, 0.64]]],
        // ⛔ NOT A BARE CROSS. It was one - the rune gebo, which is historically correct for 'g' -
        // and SOVEREIGN read as **SOVEREIXN**, because to anyone who reads Latin a cross IS the
        // letter X and this alphabet HAS an X. Wing §22a: the eye resolves the cheapest
        // interpretation, and a glyph that reads as another glyph OF THE SAME SET is the kill
        // condition, not a stylistic quibble.
        //
        // ⚠️ AND NO DISTANCE COULD HAVE CAUGHT IT: a cross and a bowtie are geometrically far apart,
        // so `glyph_collide.js` scored the pair 0.42 and was right. The sweep answers "are two marks
        // the same picture"; it has no opinion about which LETTER a mark looks like. Only reading the
        // words does, which is why that sheet is the verdict and the metric is the ranker.
        //
        // G is now C plus a bar - the Latin relation, mirroring lapidary's - and X takes the cross.
        G: [[[0.86, 0.08], [0.24, 0.28], [0.24, 0.72], [0.86, 0.92]], [[0.52, 0.6], [0.86, 0.6]]],
        // two staves + a HORIZONTAL rung.
        H: [[[0.16, 0], [0.16, 1]], [[0.84, 0], [0.84, 1]], [[0.16, 0.5], [0.84, 0.5]]],
        // a bare stave. Nothing else in the family is bare.
        I: [[[0.5, 0], [0.5, 1]]],
        // stave + a closed lozenge at mid: the only lozenge ON a stave.
        J: [[[0.5, 0], [0.5, 1]], [[0.5, 0.32], [0.84, 0.5], [0.5, 0.68], [0.16, 0.5], [0.5, 0.32]]],
        // stave + two open branches from ONE point at mid, opening right.
        K: [[[0.2, 0], [0.2, 1]], [[0.2, 0.5], [0.88, 0.04]], [[0.2, 0.5], [0.88, 0.96]]],
        // stave + ONE horizontal branch at the foot.
        L: [[[0.22, 0], [0.22, 1]], [[0.22, 0.96], [0.86, 0.96]]],
        // two staves + a V hanging from the tops.
        M: [[[0.12, 0], [0.12, 1]], [[0.88, 0], [0.88, 1]], [[0.12, 0.04], [0.5, 0.5], [0.88, 0.04]]],
        // two staves + a DIAGONAL rung. Differs from H by direction, from M by count.
        N: [[[0.16, 0], [0.16, 1]], [[0.84, 0], [0.84, 1]], [[0.16, 0.9], [0.84, 0.14]]],
        // a closed diamond, full height, no stave.
        O: [[[0.5, 0], [0.9, 0.5], [0.5, 1], [0.1, 0.5], [0.5, 0]]],
        // stave + ONE closed wedge at MID only. Differs from A by side, from D by height.
        P: [[[0.2, 0], [0.2, 1]], [[0.2, 0.26], [0.82, 0.5], [0.2, 0.74]]],
        // the diamond + a tail below the baseline.
        Q: [[[0.5, 0], [0.9, 0.5], [0.5, 1], [0.1, 0.5], [0.5, 0]], [[0.62, 0.72], [0.96, 1.06]]],
        // stave + a top wedge + a LEG to the foot: the only wedge-and-leg letter.
        R: [[[0.2, 0], [0.2, 1]], [[0.2, 0.02], [0.8, 0.22], [0.2, 0.44]], [[0.3, 0.44], [0.88, 1]]],
        // a bolt with a HORIZONTAL jog. The first version's left extremes aligned into a stave and
        // it read as an epsilon; the jog is what breaks that vertical (§22a-3, the trailing edge).
        S: [[[0.84, 0.04], [0.3, 0.34], [0.7, 0.34], [0.16, 0.96]]],
        // centred stave + an arrowhead at the top.
        T: [[[0.5, 0.08], [0.5, 1]], [[0.12, 0.42], [0.5, 0.02], [0.88, 0.42]]],
        // an open U with angular shoulders.
        U: [[[0.16, 0], [0.16, 0.62], [0.5, 1], [0.84, 0.62], [0.84, 0]]],
        V: [[[0.16, 0], [0.5, 1], [0.84, 0]]],
        W: [[[0.06, 0], [0.28, 1], [0.5, 0.36], [0.72, 1], [0.94, 0]]],
        // the cross, which is what a reader calls an X. It was a closed bowtie while G held the
        // cross, and the pair read backwards (see G).
        X: [[[0.12, 0.06], [0.88, 0.94]], [[0.88, 0.06], [0.12, 0.94]]],
        // a V on a half stave.
        Y: [[[0.5, 0.46], [0.5, 1]], [[0.12, 0.0], [0.5, 0.46], [0.88, 0.0]]],
        Z: [[[0.86, 0.04], [0.14, 0.04], [0.86, 0.96], [0.14, 0.96]]],

        // ---- THE DIGITS. Every one carries the base bar; no letter does. ----
        '0': [[[0.08, 0.96], [0.92, 0.96]], [[0.08, 0.06], [0.92, 0.06]]],
        '1': [[[0.08, 0.96], [0.92, 0.96]], [[0.5, 0.04], [0.5, 0.96]]],
        '2': [[[0.08, 0.96], [0.92, 0.96]], [[0.22, 0.04], [0.22, 0.96]], [[0.22, 0.04], [0.84, 0.6]]],
        '3': [[[0.08, 0.96], [0.92, 0.96]], [[0.14, 0.96], [0.5, 0.06], [0.86, 0.96]]],
        // ⛔ NOT A CROSS: that is the letter G, and the base bar alone did NOT separate them (0.188 at
        // em 9). The rule above says a digit carries a bar no letter has; it does not license reusing
        // a letter's whole mark above it. A digit's mark must be unlike every LETTER too.
        '4': [[[0.08, 0.96], [0.92, 0.96]], [[0.08, 0.06], [0.92, 0.06]], [[0.5, 0.06], [0.5, 0.96]]],
        '5': [[[0.08, 0.96], [0.92, 0.96]], [[0.14, 0.06], [0.5, 0.9], [0.86, 0.06]]],
        '6': [[[0.08, 0.96], [0.92, 0.96]], [[0.5, 0.04], [0.86, 0.48], [0.5, 0.9], [0.14, 0.48], [0.5, 0.04]]],
        // ⛔ NOT A Z: the letter Z ENDS in a full-width bottom horizontal, which is exactly the base
        // bar that is supposed to mark a digit - so the two were one picture (0.154 at em 9). Rule 3
        // above claims no letter has a base bar and Z is the letter that falsifies it, which is why
        // the rule is enforced by this sweep rather than by the sentence that states it.
        '7': [[[0.08, 0.96], [0.92, 0.96]], [[0.2, 0.06], [0.86, 0.06], [0.44, 0.82]]],
        '8': [[[0.08, 0.96], [0.92, 0.96]], [[0.16, 0.04], [0.84, 0.04], [0.16, 0.88], [0.84, 0.88], [0.16, 0.04]]],
        '9': [[[0.08, 0.96], [0.92, 0.96]], [[0.5, 0.04], [0.86, 0.4], [0.5, 0.76], [0.14, 0.4], [0.5, 0.04]],
              [[0.5, 0.76], [0.86, 0.9]]]
    };

    L.IDS = ['lapidary', 'stave'];

    L.TABLE = {
        lapidary: {
            name: 'Lapidary',
            glyphs: LAPIDARY,
            inkEm: 0.13,          // stroke width as a fraction of cap height
            note: 'Roman square capitals, cut with a chisel. The most legible thing a rim can carry '
                + 'and the default for any realm that does not declare otherwise.'
        },
        stave: {
            name: 'Stave',
            glyphs: STAVE,
            inkEm: 0.115,
            note: 'A runic hand: every glyph is a vertical stave with angular branches, and there is '
                + 'not one curve in it. The difference from Lapidary is CONSTRUCTIONAL rather than '
                + 'stylistic, which is why it survives at rim size where a serif treatment would not.'
        }
    };

    /**
     * @param {string} id alphabet id.
     * @returns {object} the alphabet record. Throws on an unknown id.
     */
    L.get = function (id) {
        var a = L.TABLE[id];
        if (!a) throw new Error('SpecieLetters: unknown alphabet "' + id + '"');
        return a;
    };

    /**
     * The polylines for one character, or null if this alphabet does not have it.
     *
     * ⛔ RETURNS null RATHER THAN A BOX OR A GUESS. Wing §21c: an unknown motif id is SKIPPED
     * deliberately, because a buyer's custom text must never crash a battle - and a substituted
     * glyph is worse than an absent one, because it looks like a decision somebody made.
     *
     * @param {string} alphabetId
     * @param {string} ch a single character; case is folded up.
     * @returns {?number[][][]}
     */
    L.glyph = function (alphabetId, ch) {
        var a = L.get(alphabetId);
        var key = String(ch).toUpperCase();
        return Object.prototype.hasOwnProperty.call(a.glyphs, key) ? a.glyphs[key] : null;
    };

    /**
     * Which characters of a string this alphabet can actually strike, and which it drops.
     * Spaces are legal and are struck as a word-space, never as a missing glyph.
     *
     * @param {string} alphabetId
     * @param {string} text
     * @returns {{struck:string, dropped:string[]}}
     */
    L.transliterate = function (alphabetId, text) {
        var out = '', dropped = [];
        var t = String(text).toUpperCase();
        for (var i = 0; i < t.length; i++) {
            var c = t.charAt(i);
            if (c === ' ') { out += ' '; continue; }
            if (L.glyph(alphabetId, c)) out += c;
            else dropped.push(c);
        }
        return { struck: out, dropped: dropped };
    };

    /**
     * Total authored entities on this axis: LETTERFORMS, not alphabets.
     *
     * ⚠️ Counted as authored things and never as a multiplication (master §1.1 q3, wing §21i:
     * volume() reports what the corpus COULD make while a buyer sees what their database RESOLVES
     * to). Each glyph is separately drawn, so each one is a real authored entity.
     * @returns {number}
     */
    L.volume = function () {
        var n = 0;
        for (var i = 0; i < L.IDS.length; i++) n += Object.keys(L.TABLE[L.IDS[i]].glyphs).length;
        return n;
    };

})(SpecieLetters);
