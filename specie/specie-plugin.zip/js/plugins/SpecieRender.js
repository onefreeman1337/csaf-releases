/*:
 * @target MZ
 * @plugindesc [Specie] Renderer — turns a device's recorded primitives into struck relief on a flan. Library file; no parameters.
 * @author Core Systems Asset Factory
 *
 * @help
 * SpecieRender.js
 *
 * The only file in this product that puts a mark on a surface. Everything above
 * it is data: a device is a list of primitives, a metal is a colour law. This is
 * where they become a struck coin.
 *
 * It takes a CanvasRenderingContext2D, so it works identically on an MZ Bitmap's
 * context and on a headless page's canvas. That is what makes the contact sheet
 * cheap enough to run every time.
 *
 * Load order does not matter. It resolves SpecieDevices and SpecieMetals at FIRST
 * USE, never at load time (wing CLAUDE.md 8 trap 2: mz_harness build loads the
 * plugin folder ALPHABETICALLY, which is the worst order a buyer can create by
 * dragging files into the Plugin Manager - and SpecieDevices sorts BEFORE
 * SpecieRender while SpecieStrike sorts after).
 */

var SpecieRender = SpecieRender || {};

(function (R) {
    'use strict';

    // =============================================================================================
    // SIBLING RESOLUTION - AT FIRST USE, NEVER AT LOAD TIME
    //
    // Wing 8 trap 2, MEASURED 2026-08-28: a four-file product captured its siblings at load time,
    // the harness loaded the folder alphabetically, the capture ran against `undefined`, and the
    // whole product no-oped behind one console line. That is exactly what a buyer gets for dragging
    // files into the Plugin Manager in the wrong order, and it would have shipped.
    //
    // No Internal_Ops/plugin_order.json ships either (trap 2b) - shipping one turns this test off,
    // because the harness would then load the safe order and stop exercising the alphabetical case.
    // =============================================================================================

    /** @returns {object} the device corpus. Throws with a useful name if the file is absent. */
    function DEV() {
        var d = (typeof SpecieDevices !== 'undefined') ? SpecieDevices : null;
        if (!d || !d.OBVERSE) throw new Error('SpecieRender: SpecieDevices.js is not loaded');
        return d;
    }

    /** @returns {object} the metal corpus. */
    function MET() {
        var m = (typeof SpecieMetals !== 'undefined') ? SpecieMetals : null;
        if (!m || !m.TABLE) throw new Error('SpecieRender: SpecieMetals.js is not loaded');
        return m;
    }

    /**
     * @returns {?object} the flan corpus, or null.
     * ⚠️ OPTIONAL BY DESIGN, and this is the one sibling that is. A buyer who loads only the device
     * and metal files gets plain round coins, which is a correct product; a missing flan file must
     * not throw in the middle of drawing a purse. The other two are not optional because there is
     * nothing to draw without them.
     */
    function FLA() {
        return (typeof SpecieFlan !== 'undefined' && SpecieFlan.TABLE) ? SpecieFlan : null;
    }

    /**
     * @returns {?object} the letterform corpus, or null.
     * ⚠️ Optional for the same reason the flan is: a buyer who loads only the device and metal files
     * gets plain unlettered coins, which is a correct product, and a missing file must not throw in
     * the middle of drawing a purse.
     */
    function LET() {
        return (typeof SpecieLetters !== 'undefined' && SpecieLetters.TABLE) ? SpecieLetters : null;
    }

    /** @returns {?object} the strike model, or null. Optional, like the flan and the letters. */
    function STR() {
        return (typeof SpecieStrike !== 'undefined' && SpecieStrike.rng) ? SpecieStrike : null;
    }

    /**
     * What this file can see, as a REPORT.
     *
     * ⛔ IT MUST NOT THROW, AND IT DID. `DEV()` and `MET()` throw a named error when a REQUIRED
     * sibling is absent, which is right at a draw call — it tells a buyer exactly which Plugin
     * Manager box to tick, and §21c warns that the silent alternative hides the mistake. But `deps`
     * is the DIAGNOSTIC, and a diagnostic that throws cannot report what is missing: MEASURED by
     * `_probe/break_it.js` enabling `SpecieRender.js` alone, where the one call meant to say
     * "SpecieDevices is not here" was the call that crashed.
     *
     * @returns {{devices:?object, metals:?object, flan:?object, letters:?object, strike:?object,
     *            missing:string[]}}
     */
    R.deps = function () {
        var devices = (typeof SpecieDevices !== 'undefined' && SpecieDevices.OBVERSE)
            ? SpecieDevices : null;
        var metals = (typeof SpecieMetals !== 'undefined' && SpecieMetals.TABLE)
            ? SpecieMetals : null;
        var out = { devices: devices, metals: metals, flan: FLA(), letters: LET(), strike: STR() };
        out.missing = [];
        if (!devices) out.missing.push('SpecieDevices.js');
        if (!metals) out.missing.push('SpecieMetals.js');
        return out;
    };

    // =============================================================================================
    // THE TRANSFORM
    //
    // A device is authored in flan units: origin at the centre of the coin, 1.0 unit == the flan's
    // DIAMETER (so the flan's own edge is at radius 0.5). SpecieDevices.thinnestStructuralPx uses
    // exactly that convention - `halfWidthUnits * 2 * diameterPx` - and this is the one place the
    // mapping is written down, so the two cannot disagree (wing 11a: a second copy of a constant
    // does not drift, it WINS, and the edit that provably reaches disk provably does not reach the
    // picture).
    // =============================================================================================

    /**
     * @param {number} cx centre x, px.
     * @param {number} cy centre y, px.
     * @param {number} diameterPx rendered diameter of the whole flan.
     * @returns {{cx:number, cy:number, d:number, x:function, y:function, s:function}}
     */
    R.transform = function (cx, cy, diameterPx) {
        return {
            cx: cx, cy: cy, d: diameterPx,
            x: function (u) { return cx + u * diameterPx; },
            y: function (u) { return cy + u * diameterPx; },
            s: function (u) { return u * diameterPx; }
        };
    };

    // =============================================================================================
    // THE RELIEF OFFSET
    //
    // A struck coin is read by ONE FIXED LIGHT from the upper left. The device is raised, so it
    // carries a lit sliver on its upper-left edge and casts a shadow to its lower right.
    //
    // The three passes are drawn as three INDEPENDENT fills of the same primitives at three
    // offsets - shadow down-right, highlight up-left, face at origin - rather than as an even-odd
    // symmetric difference. That is deliberate: a device is composed of many overlapping subpaths
    // (a limb rooted INSIDE the mass it grows from, wing 22a-1b), and an even-odd rule punches those
    // overlaps into HOLES. Three plain nonzero fills cannot do that.
    //
    // The offset is in ABSOLUTE PIXELS with a floor, never a fraction of the coin. Wing 22a-2d
    // measured that law on spacing and it is the same law here: a ratio tuned at a comfortable size
    // is always too tight at the thumbnail. Below the floor the bevel simply does not exist, and
    // the read is carried by the metal's own reliefMin separation between face and field - which is
    // why SpecieMetals.surface() exists and why this file never picks a tint of its own.
    // =============================================================================================

    R.BEVEL_MIN_PX = 0.75;        // below this a bevel is a grey smear, not an edge
    R.BEVEL_RATIO = 0.009;        // of the flan diameter, above the floor

    /**
     * @param {number} diameterPx
     * @returns {number} bevel offset in px, 0 when it cannot resolve at all.
     */
    R.bevelPx = function (diameterPx, wear) {
        // ⛔ WEAR IS A GEOMETRY FACT BEFORE IT IS A COLOUR FACT, AND THIS FUNCTION ONLY HAD THE SIZE
        // HALF. SpecieMetals.surface() softens the relief SEPARATION with wear - correct, and it is
        // what makes an old gold coin read as old without discolouring - but the bevel was a
        // function of SIZE ALONE, so a coin at wear 0.9 kept a mint-sharp bevelled edge on every
        // device and every letter while its colours said it was ancient. Two halves of one fact,
        // disagreeing inside one picture.
        //
        // SpecieStrike.reliefScale is the ONE reader of wear for geometry, so the two cannot drift
        // (wing §11a: a second copy of a constant does not drift, it WINS).
        var S = STR();
        var scale = (S && typeof wear === 'number') ? S.reliefScale(wear) : 1;
        var v = diameterPx * R.BEVEL_RATIO * scale;
        return v < R.BEVEL_MIN_PX ? 0 : v;
    };

    // =============================================================================================
    // PRIMITIVE -> PATH
    //
    // One function per primitive in SpecieDevices' recorder vocabulary. Each ADDS to the current
    // path and never fills, so a whole device can be laid down as one path and filled once per
    // lighting pass.
    // =============================================================================================

    function pathDisc(ctx, T, o, dx, dy) {
        var r = T.s(o.r);
        if (r <= 0) return;
        ctx.moveTo(T.x(o.x) + dx + r, T.y(o.y) + dy);
        ctx.arc(T.x(o.x) + dx, T.y(o.y) + dy, r, 0, Math.PI * 2);
    }

    function pathPoly(ctx, T, o, dx, dy) {
        var p = o.pts;
        if (!p || p.length < 3) return;
        ctx.moveTo(T.x(p[0][0]) + dx, T.y(p[0][1]) + dy);
        for (var i = 1; i < p.length; i++) ctx.lineTo(T.x(p[i][0]) + dx, T.y(p[i][1]) + dy);
        ctx.closePath();
    }

    /**
     * A tapered limb, plus a round cap at each end.
     *
     * The caps are not decoration. Wing 22a-1b: a chain of ABUTTING masses reads as a chain - the
     * mammoth read as "a circle, an oval, four posts and a floating hook" - and every appendage must
     * OVERLAP the mass it grows from rather than sit next to it. A round root cap is what makes the
     * join a change of direction instead of a seam.
     */
    function pathLimb(ctx, T, o, dx, dy) {
        var x0 = T.x(o.x0) + dx, y0 = T.y(o.y0) + dy;
        var x1 = T.x(o.x1) + dx, y1 = T.y(o.y1) + dy;
        var w0 = T.s(o.w0), w1 = T.s(o.w1);
        var vx = x1 - x0, vy = y1 - y0;
        var len = Math.sqrt(vx * vx + vy * vy);
        if (len < 1e-9) { // a degenerate limb is a disc, not a crash
            if (w0 > 0) { ctx.moveTo(x0 + w0, y0); ctx.arc(x0, y0, w0, 0, Math.PI * 2); }
            return;
        }
        var nx = -vy / len, ny = vx / len;
        ctx.moveTo(x0 + nx * w0, y0 + ny * w0);
        ctx.lineTo(x1 + nx * w1, y1 + ny * w1);
        ctx.lineTo(x1 - nx * w1, y1 - ny * w1);
        ctx.lineTo(x0 - nx * w0, y0 - ny * w0);
        ctx.closePath();
        if (w0 > 0) { ctx.moveTo(x0 + w0, y0); ctx.arc(x0, y0, w0, 0, Math.PI * 2); }
        if (w1 > 0) { ctx.moveTo(x1 + w1, y1); ctx.arc(x1, y1, w1, 0, Math.PI * 2); }
    }

    /** An arc BAND: half-width `w` either side of radius `r`. */
    function pathArc(ctx, T, o, dx, dy) {
        var cx = T.x(o.cx) + dx, cy = T.y(o.cy) + dy;
        var rOut = T.s(o.r + o.w), rIn = Math.max(0, T.s(o.r - o.w));
        if (rOut <= 0) return;
        ctx.moveTo(cx + Math.cos(o.a0) * rOut, cy + Math.sin(o.a0) * rOut);
        ctx.arc(cx, cy, rOut, o.a0, o.a1, false);
        ctx.lineTo(cx + Math.cos(o.a1) * rIn, cy + Math.sin(o.a1) * rIn);
        ctx.arc(cx, cy, rIn, o.a1, o.a0, true);
        ctx.closePath();
    }

    /**
     * Lay every primitive of a device into the current path, at one offset.
     *
     * ⛔ LEVEL OF DETAIL IS RESOLVED HERE AND NOWHERE ELSE. `detail(minPx, fn)` records a MARKER op
     * and tags the ops inside the block; there is no closing marker, so the rule is: a `detail` op
     * sets the current minimum, every following op tagged `detailOnly` inherits it, and the first
     * untagged op clears it. `detailReset` in the ops report proves that reading against the
     * recorder rather than assuming it.
     *
     * Wing 17c-1 / 22a-3b is why a below-floor mark is DROPPED rather than drawn smaller: a correct
     * rule executed below the resolution floor produces a confident wrong picture, which is worse
     * than an absent one because the render looks deliberate.
     *
     * @returns {{drawn:number, dropped:number}} counts, so a caller can prove the LOD is alive.
     */
    R.pathDevice = function (ctx, ops, T, dx, dy) {
        var curMin = Infinity;
        var drawn = 0, dropped = 0;
        for (var i = 0; i < ops.length; i++) {
            var o = ops[i];
            if (o.op === 'detail') { curMin = o.minPx; continue; }
            // cuts and bites are separate passes; see R.inciseDevice and R.holeDevice
            if (o.op === 'incise' || o.op === 'hole') continue;
            if (!o.detailOnly) curMin = Infinity;
            var min = o.detailOnly ? curMin : 0;
            if (T.d < min) { dropped++; continue; }
            switch (o.op) {
                case 'disc': pathDisc(ctx, T, o, dx, dy); break;
                case 'poly': pathPoly(ctx, T, o, dx, dy); break;
                case 'limb': pathLimb(ctx, T, o, dx, dy); break;
                case 'arc': pathArc(ctx, T, o, dx, dy); break;
                default: continue;   // an unknown op is SKIPPED, never a crash in a buyer's battle
            }
            drawn++;
        }
        return { drawn: drawn, dropped: dropped };
    };

    // =============================================================================================
    // THE INCUSE PASS
    //
    // ⛔ A GROOVE IS DRAWN IN THE RECESS COLOUR AND CLIPPED TO THE METAL IT IS CUT INTO.
    //
    // The colour is not a choice: SpecieMetals.surface(metal, wear, -1) is the same function the
    // FIELD is filled with, so a cut is separated from the face by exactly the metal's own
    // reliefMin - never by a tint this file invented (wing §22e-1: any tint whose job is to make
    // something visible must state its separation in ABSOLUTE terms, because a multiplier is a
    // hard-coded contrast RATIO and moved a bright wax 27 luma levels and a dark one 11). It also
    // means a cut takes PATINA exactly as the field does, so an old copper coin's incuse work goes
    // green with the rest of it. That is one function serving both, not two that must agree.
    //
    // The clip is not tidiness either. §22a-2b measured that a stroke laid BESIDE a form detaches
    // from it and reads as a floating scratch - the ibex's ridge strokes became scratches above a
    // deer - and the fix was to cut the ornament INTO the form. Clipping makes that structural, so
    // the primitive cannot be misused by a later device.
    // =============================================================================================

    /**
     * Take every declared BITE out of the raised metal.
     *
     * ⛔ A HOLE IS CLIPPED TO THE MASSES DRAWN BEFORE IT, NEVER TO THE WHOLE DEVICE. Wing §22d's
     * third trap: a biting circle that pokes outside the mass it bites will, on an even-odd path,
     * fill the overhang too and turn a crescent into a RING. Order-based scoping makes that
     * impossible - and it is also what the corpus needs, because crescent-and-star lays the star
     * INSIDE the bite circle's footprint. Clipping to the finished device would eat the star.
     *
     * The bite is filled with the FIELD colour, because a hole in the relief is the flan showing
     * through, and the field is what a flan's surface is. It gets the bevel run backwards: the
     * surrounding relief casts a shadow into the hole on the side the light comes from.
     *
     * @returns {{holes:number}}
     */
    R.holeDevice = function (ctx, ops, T, metal, wear, bevel) {
        var M = MET();
        var field = M.surface(metal, wear, -1);
        var lip = M.relief(field, -1, metal.reliefMin * 0.5);
        var holes = 0;

        for (var i = 0; i < ops.length; i++) {
            var o = ops[i];
            if (o.op !== 'hole') continue;
            var r = T.s(o.r);
            if (r <= 0.5) continue;      // a bite smaller than a pixel is not a bite

            ctx.save();
            ctx.beginPath();
            R.pathDevice(ctx, ops.slice(0, i), T, 0, 0);   // only what precedes it
            ctx.clip();

            if (bevel > 0) {
                ctx.fillStyle = R.css(lip);
                ctx.beginPath();
                ctx.arc(T.x(o.x), T.y(o.y), r, 0, Math.PI * 2);
                ctx.fill();
            }
            ctx.fillStyle = R.css(field);
            ctx.beginPath();
            ctx.arc(T.x(o.x) + bevel, T.y(o.y) + bevel, r, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();
            holes++;
        }
        return { holes: holes };
    };

    R.CUT_MIN_PX = 1.15;          // below this a groove is a grey smear, not a cut edge

    /**
     * Sink every incuse cut of a device into the raised metal.
     *
     * @param {CanvasRenderingContext2D} ctx
     * @param {object[]} ops the device's recorded primitives
     * @param {object} T transform, already scaled to the device field
     * @param {object} metal
     * @param {number} wear
     * @param {number} bevel px, from R.bevelPx
     * @returns {{cut:number, dropped:number}}
     */
    R.inciseDevice = function (ctx, ops, T, metal, wear, bevel) {
        var M = MET(), S = STR();
        var detailScale = S ? S.detailScale(wear) : 1;
        var recess = M.surface(metal, wear, -1);
        // The far wall of a groove catches the light, which is what makes a cut read as CUT rather
        // than as a line painted on. It is the raised bevel run backwards, and it costs one pass.
        var wall = M.relief(recess, +1, metal.reliefMin * 0.5);

        var cut = 0, dropped = 0;
        var curMin = Infinity;
        var live = [];
        for (var i = 0; i < ops.length; i++) {
            var o = ops[i];
            if (o.op === 'detail') { curMin = o.minPx; continue; }
            if (!o.detailOnly) { if (o.op !== 'incise') curMin = Infinity; }
            if (o.op !== 'incise') continue;
            var min = o.detailOnly ? curMin : 0;
            // ⛔ WEAR EATS THE CUTS FIRST, AND IT DOES IT THROUGH THE RESOLUTION FLOOR RATHER THAN
            // THROUGH A SECOND RULE. A coin does not fade uniformly - the high points go first, so
            // an old piece keeps its gross silhouette and loses its eye, its mane and its
            // lettering. Scaling the cut's WIDTH by SpecieStrike.detailScale lets the CUT_MIN_PX
            // floor below decide when a groove has stopped existing, which is one threshold doing
            // two jobs instead of two thresholds that have to agree (wing §11).
            var wpx = T.s(o.w) * 2 * detailScale;
            // §17c-1: a feature that cannot resolve at the product's own scale must move to a scale
            // where it can, or be deleted - never drawn anyway, because a correct rule executed
            // below the resolution floor produces a confident WRONG picture (§22a-3b).
            if (T.d < min || wpx < R.CUT_MIN_PX) { dropped++; continue; }
            live.push(o);
        }
        if (!live.length) return { cut: 0, dropped: dropped };

        ctx.save();
        ctx.beginPath();
        R.pathDevice(ctx, ops, T, 0, 0);
        ctx.clip();

        function strokeCuts(colour, dx, dy) {
            ctx.strokeStyle = R.css(colour);
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            for (var j = 0; j < live.length; j++) {
                var o = live[j];
                ctx.lineWidth = Math.max(R.CUT_MIN_PX, T.s(o.w) * 2 * detailScale);
                ctx.beginPath();
                ctx.moveTo(T.x(o.pts[0][0]) + dx, T.y(o.pts[0][1]) + dy);
                for (var k = 1; k < o.pts.length; k++) {
                    ctx.lineTo(T.x(o.pts[k][0]) + dx, T.y(o.pts[k][1]) + dy);
                }
                ctx.stroke();
            }
        }

        if (bevel > 0) strokeCuts(wall, bevel * 0.8, bevel * 0.8);
        strokeCuts(recess, 0, 0);
        cut = live.length;

        ctx.restore();
        return { cut: cut, dropped: dropped };
    };

    /** @param {number[]} c RGB triple. @returns {string} css colour. */
    R.css = function (c) { return 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')'; };

    // =============================================================================================
    // THE STRUCK DEVICE
    // =============================================================================================

    /**
     * Strike one device onto the surface, in relief, in a metal.
     *
     * @param {CanvasRenderingContext2D} ctx
     * @param {string} side 'obverse' | 'reverse'
     * @param {string} id device id
     * @param {object} T a transform from R.transform
     * @param {object} metal a record from SpecieMetals.TABLE
     * @param {number} wear 0 (mint) .. 1 (worn smooth)
     * @returns {{drawn:number, dropped:number, bevel:number, ops:number}}
     */
    R.strikeDevice = function (ctx, side, id, T, metal, wear) {
        var D = DEV(), M = MET();
        var P = D.recorder();
        D.get(side, id).draw(P);

        // Fit the authored geometry into the device field. `field()` owns that arithmetic; this file
        // must never compute a second copy of it (wing 11a).
        var f = D.field(side, id);
        var FT = R.transform(T.cx, T.cy, T.d * f.scale);

        var face = M.surface(metal, wear, +1);      // raised metal, lit
        var bevel = R.bevelPx(T.d, wear);

        var res = null;
        if (bevel > 0) {
            // shadow first, offset toward the light's far side
            ctx.fillStyle = R.css(M.relief(face, -1, metal.reliefMin * 0.55));
            ctx.beginPath();
            R.pathDevice(ctx, P.ops, FT, bevel, bevel);
            ctx.fill();

            // then the lit edge, offset toward the light
            ctx.fillStyle = R.css(M.relief(face, +1, metal.reliefMin * 0.45));
            ctx.beginPath();
            R.pathDevice(ctx, P.ops, FT, -bevel, -bevel);
            ctx.fill();
        }

        // then the face, which covers all but the two slivers
        ctx.fillStyle = R.css(face);
        ctx.beginPath();
        res = R.pathDevice(ctx, P.ops, FT, 0, 0);
        ctx.fill();

        // then the bites, which remove metal
        var hol = R.holeDevice(ctx, P.ops, FT, metal, wear, bevel);
        // and finally the die's own cuts, sunk into the metal that is left
        var inc = R.inciseDevice(ctx, P.ops, FT, metal, wear, bevel);

        return {
            drawn: res.drawn, dropped: res.dropped + inc.dropped,
            cut: inc.cut, holes: hol.holes, bevel: bevel, ops: P.ops.length
        };
    };

    // =============================================================================================
    // THE FLAN
    //
    // A plain struck disc. SpecieFlan will supply the six authored flan and edge forms and this
    // function will consume an outline from it; until then the default outline is a circle, which is
    // what five of the six forms are anyway. It is written to TAKE an outline rather than to draw
    // one, precisely so that adding SpecieFlan is a new argument and not a second renderer.
    // =============================================================================================

    /**
     * @param {CanvasRenderingContext2D} ctx
     * @param {object} T
     * @param {object} metal
     * @param {number} wear
     * @param {?function} outline optional (ctx, T) => void that lays the flan's own path.
     */
    R.flan = function (ctx, T, metal, wear, flanId) {
        var M = MET(), F = FLA();
        var flan = (F && flanId) ? F.get(flanId) : null;
        var field = M.surface(metal, wear, -1);      // the FIELD is the recess: this is where patina
                                                    // collects, and it is the whole reason a worn
                                                    // copper coin and a worn gold coin are two
                                                    // different pictures rather than one at two hues
        ctx.save();
        ctx.beginPath();
        if (flan && flan.outline) flan.outline(ctx, T);
        else ctx.arc(T.cx, T.cy, T.d / 2, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();

        ctx.fillStyle = R.css(field);
        ctx.fillRect(T.cx - T.d, T.cy - T.d, T.d * 2, T.d * 2);

        // THE DISH. A scyphate flan's outline is still a circle - what changes is that the field
        // curves away from the light, so the piece reads as CONCAVE. That is a SHADING fact rather
        // than a silhouette fact, which is why it is one gradient and not a second outline.
        var dish = flan ? (flan.dish || 0) : 0;
        if (dish > 0) {
            // ⚠️ A LINEAR GRADIENT WAS TOO WEAK TO READ, and the reason is that a linear ramp is
            // what a TILTED FLAT surface looks like, not what a CUP looks like. A cup is
            // rotationally symmetric: its whole rim catches light and its centre falls away. So the
            // dish is a RADIAL term (which says "bowl") with the linear light term over it (which
            // says "lit from the upper left") - two gradients, because they are two different facts.
            var rg = ctx.createRadialGradient(T.cx, T.cy, 0, T.cx, T.cy, T.d / 2);
            rg.addColorStop(0, R.css(M.relief(field, -1, metal.reliefMin * dish)));
            rg.addColorStop(0.62, R.css(field));
            rg.addColorStop(1, R.css(M.relief(field, +1, metal.reliefMin * dish * 0.9)));
            ctx.fillStyle = rg;
            ctx.fillRect(T.cx - T.d, T.cy - T.d, T.d * 2, T.d * 2);

            var dg = ctx.createLinearGradient(
                T.cx - T.d / 2, T.cy - T.d / 2, T.cx + T.d / 2, T.cy + T.d / 2);
            dg.addColorStop(0, 'rgba(0,0,0,0.22)');
            dg.addColorStop(0.5, 'rgba(0,0,0,0)');
            dg.addColorStop(1, 'rgba(255,255,255,0.16)');
            ctx.fillStyle = dg;
            ctx.fillRect(T.cx - T.d, T.cy - T.d, T.d * 2, T.d * 2);
        }

        // The rim: a raised collar the legend sits inside. Drawn as a stroked band so it reads as an
        // EDGE WITH THICKNESS rather than as an outline (wing 22b-1a - a flat stroke gives an
        // outline, and a rim only reads as raised when it runs from lit relief to shadowed relief
        // under the same fixed light as the field it surrounds).
        var rimW = Math.max(1, T.d * 0.028);
        var rimR = T.d / 2 - rimW / 2;
        if (rimR > 0) {
            var g = ctx.createLinearGradient(
                T.cx - T.d / 2, T.cy - T.d / 2, T.cx + T.d / 2, T.cy + T.d / 2);
            g.addColorStop(0, R.css(M.relief(field, +1, metal.reliefMin)));
            g.addColorStop(1, R.css(M.relief(field, -1, metal.reliefMin * 0.7)));
            ctx.strokeStyle = g;
            ctx.lineWidth = rimW;
            ctx.beginPath();
            // ⛔ THE RIM FOLLOWS THE FLAN'S OWN OUTLINE, NEVER A CIRCLE IT ASSUMED. The first
            // version always stroked a circle, so a SQUARED planchet rendered with a faint circular
            // arc floating inside its corners - the rim of a coin that was not this coin. It is the
            // §11a family in a new place: two places believed they knew the flan's shape, and only
            // one of them had asked.
            if (flan && flan.outline) flan.outline(ctx, T);
            else ctx.arc(T.cx, T.cy, rimR, 0, Math.PI * 2);
            ctx.closePath();
            ctx.stroke();
        }

        // THE EDGE TREATMENT, WITH ITS COUNT DERIVED FROM THE REAL PERIMETER AND NEVER TYPED.
        // Wing 22b-1a: a repeated treatment declares a PITCH, because the right count changes with
        // the size of the piece - Escutcheon declared `marks: 18` and got eighteen specks 39px
        // apart, and all seven of its treatments rendered as the same yellow rectangle.
        var marks = null;
        if (F && flan && flan.edge && flan.edge !== 'none' && flan.edge !== 'plain') {
            var scale = T.d / 260;                       // the treatment's px are quoted at inspect
            var markPx = flan.markPx * scale;
            var perim = Math.PI * (T.d - rimW);
            marks = F.fitMarks(perim, markPx, flan.pitchPx * scale);
            if (marks.resolves) {
                var ringR = T.d / 2 - rimW * 0.5;
                ctx.lineCap = 'butt';
                for (var i = 0; i < marks.count; i++) {
                    var a = (i / marks.count) * Math.PI * 2;
                    var ca = Math.cos(a), sa = Math.sin(a);
                    // A mark is lit or shadowed by WHERE ON THE RIM IT SITS, under the one fixed
                    // light - which is what makes a ring of them read as milling rather than as a
                    // dotted line. `facing` is the dot product with the light direction (-1,-1).
                    var facing = -(ca + sa) / Math.SQRT2;
                    ctx.strokeStyle = R.css(M.relief(field, facing >= 0 ? +1 : -1,
                        metal.reliefMin * (0.35 + 0.65 * Math.abs(facing))));
                    ctx.lineWidth = markPx;
                    ctx.beginPath();
                    ctx.moveTo(T.cx + ca * (ringR - rimW * 0.55), T.cy + sa * (ringR - rimW * 0.55));
                    ctx.lineTo(T.cx + ca * (ringR + rimW * 0.55), T.cy + sa * (ringR + rimW * 0.55));
                    ctx.stroke();
                }
            }
        }
        ctx.restore();

        return { field: field, rimW: rimW, marks: marks, hole: flan ? (flan.hole || 0) : 0 };
    };

    /**
     * Punch a flan's central piercing.
     *
     * ⛔ THIS IS A SEPARATE FUNCTION BECAUSE ORDER IS THE WHOLE POINT, AND THE FIRST VERSION GOT IT
     * WRONG IN A WAY NO COUNTER COULD SEE. The piercing was punched at the end of `flan()`, which
     * runs BEFORE the device is struck - so the device was then drawn straight over the hole and the
     * pierced blank rendered as a plain disc. Every number was right: the flan reported its hole
     * fraction, the device reported its marks, and the picture had no hole in it. Wing §21b: "the
     * code ran" and "the picture changed" are different claims.
     *
     * A piercing goes through the WHOLE PIECE - the field, the rim and the device - so it is punched
     * last, after everything that could fill it back in.
     *
     * ⚠️ Wing §22d warns that `destination-out` erases to TRANSPARENT through everything behind it.
     * That is exactly what is wanted HERE and nowhere else in this product: a piercing really is an
     * absence of coin, and the caller composites the coin over its own background.
     *
     * @returns {{punched:boolean, r:number}}
     */
    R.pierce = function (ctx, T, metal, wear, flanId) {
        var M = MET(), F = FLA();
        var flan = (F && flanId) ? F.get(flanId) : null;
        var holeFrac = flan ? (flan.hole || 0) : 0;
        if (!(holeFrac > 0)) return { punched: false, r: 0 };

        var field = M.surface(metal, wear, -1);
        var hr = T.d * holeFrac / 2;

        ctx.save();
        ctx.globalCompositeOperation = 'destination-out';
        ctx.beginPath();
        ctx.arc(T.cx, T.cy, hr, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // the wall of the piercing, lit from the same fixed direction as everything else, so the
        // hole reads as a hole through METAL rather than as a printed dot
        var hg = ctx.createLinearGradient(T.cx - hr, T.cy - hr, T.cx + hr, T.cy + hr);
        hg.addColorStop(0, R.css(M.relief(field, -1, metal.reliefMin * 0.9)));
        hg.addColorStop(1, R.css(M.relief(field, +1, metal.reliefMin * 0.6)));
        ctx.strokeStyle = hg;
        ctx.lineWidth = Math.max(1, T.d * 0.020);
        ctx.beginPath();
        ctx.arc(T.cx, T.cy, hr, 0, Math.PI * 2);
        ctx.stroke();
        return { punched: true, r: hr };
    };

    /**
     * A whole coin face: flan, then device.
     *
     * @returns {object} the device's own report, so a caller can assert the LOD moved.
     */
    R.strike = function (ctx, T, opt) {
        // ⛔ THE RENDERER NEVER THROWS ON DATA. THE CORPUS GETTERS STILL DO, AND THE SPLIT IS THE
        // RULE. Wing §21c: "an unknown motif id is SKIPPED, deliberately — a buyer's custom biome
        // must never crash a battle." This function runs inside a buyer's frame, so an id it does
        // not recognise degrades to something truthful (no device, a plain round blank, the first
        // metal) and is REPORTED in the return record. `SpecieDevices.get` and friends keep
        // throwing, because they are internal table lookups whose well-formedness is asserted by
        // the suites — §21c's other half is that a silent skip can hide a typo, and the loud
        // failure belongs where only our own code can trigger it.
        //
        // MEASURED: `_probe/break_it.js` fed it `no-such-device`, `no-such-flan` and
        // `no-such-metal` and all three threw, which in a buyer's game is a crash on a menu.
        var M = MET(), D = DEV(), F = FLA();
        var unknown = null;

        var metal = opt.metal;
        if (typeof metal === 'string') {
            metal = (M.TABLE && M.TABLE[metal]) ? M.get(metal) : null;
            if (!metal) { unknown = 'metal:' + opt.metal; metal = M.get(M.IDS[0]); }
        }
        var wear = typeof opt.wear === 'number' ? opt.wear : 0;

        var flanId = opt.flan || null;
        if (flanId && F && !F.TABLE[flanId]) { unknown = 'flan:' + flanId; flanId = 'round'; }
        var flan = (F && flanId) ? F.get(flanId) : null;

        // An unknown device is dropped rather than substituted: a coin with no device is an honest
        // blank, and substituting somebody else's device would be a picture nobody asked for.
        var deviceId = opt.id;
        if (deviceId && D) {
            var table = (opt.side === 'reverse') ? D.REVERSE : D.OBVERSE;
            if (!table[deviceId]) { unknown = 'device:' + deviceId; deviceId = null; }
        }

        var f = R.flan(ctx, T, metal, wear, flanId);

        // ⛔ A PIERCED FLAN CARRIES NO CENTRAL DEVICE, and that is a design fact rather than a
        // rendering convenience. The first render punched the hole straight through the sovereign's
        // face, which is what happens when a coin with a hole in the middle is asked to carry a
        // portrait in the middle. Real pierced coinage does not: a cash coin's identity is its
        // LEGEND, set around the piercing, and there is no central device at all. So the flan
        // declares it and the renderer obeys - one statement, one reader.
        var wantDevice = !flan || flan.centreDevice !== false;

        // ⭐ THE DIE MOVES, THE BLANK DOES NOT. A hammered coin is struck by hand: the die lands off
        // centre, or it bounces and lands twice, or the whole impression sits a degree or two off
        // square. That is what makes a purse of hand-struck coins read as OBJECTS rather than as one
        // sprite repeated - and it is why the offset is applied to the device and the legend and NOT
        // to the flan. Moving the blank would just move the coin.
        var S = STR();
        var st = (S && typeof opt.seed === 'number')
            ? S.strike(opt.seed, { wear: wear, quality: opt.quality })
            : null;

        function dieFace() {
            var dd = (wantDevice && deviceId)
                ? R.strikeDevice(ctx, opt.side || 'obverse', deviceId, T, metal, wear)
                : { drawn: 0, dropped: 0, cut: 0, holes: 0, bevel: R.bevelPx(T.d, wear), ops: 0, suppressed: true };
            dd.legend = (opt.text || opt.alphabet)
                ? R.legend(ctx, T, metal, wear, {
                    text: opt.text || '', alphabet: opt.alphabet || 'lapidary',
                    arc: opt.legendArc || null, radius: opt.legendRadius
                })
                : { mode: 'none', glyphs: 0, beads: 0, why: 'no text declared' };
            return dd;
        }

        /** Run `fn` with the die displaced, about the coin's own centre. */
        function underDie(dx, dy, rot, alpha, fn) {
            ctx.save();
            ctx.translate(T.cx, T.cy);
            ctx.rotate(rot);
            ctx.translate(-T.cx + dx, -T.cy + dy);
            if (typeof alpha === 'number') ctx.globalAlpha = alpha;
            var out = fn();
            ctx.restore();
            return out;
        }

        var d;
        if (st) {
            // ⚠️ THE GHOST GOES FIRST AND IT IS FAINT. A second impression at full strength is not a
            // double strike, it is two coins on top of each other, and it reads as one. Drawn first
            // so the real strike sits over it, exactly as the second blow of the hammer does.
            if (st.ghost) {
                underDie(st.ghost.dx * T.d, st.ghost.dy * T.d, st.rot * 1.7, st.ghost.alpha, dieFace);
            }
            d = underDie(st.offX * T.d, st.offY * T.d, st.rot, null, dieFace);
            d.strike = st;
        } else {
            d = dieFace();
            d.strike = null;
        }

        // ⛔ LAST, and the order is load-bearing: a piercing goes through the device too, so
        // punching it before the strike lets the device fill it straight back in. The first version
        // punched it inside flan() and the pierced blank rendered as a plain disc, with every
        // number correct (wing §21b: "the code ran" and "the picture changed" are different claims).
        d.pierce = R.pierce(ctx, T, metal, wear, flanId);
        d.flan = f;
        // ⛔ REPORTED, NOT SWALLOWED. §21c's warning about a silent skip is that it hides a typo, so
        // the degradation is named in the record every caller already reads. A probe or a suite can
        // then assert `unknown === null` and catch what a throw used to catch, without the crash.
        d.unknown = unknown;
        return d;
    };

    // =============================================================================================
    // THE LEGEND
    //
    // ⛔ THIS IS THE LEVEL-OF-DETAIL TABLE THE ARCHITECTURE SAID COULD SINK THE PRODUCT, AND ITS ONE
    // NON-NEGOTIABLE RULE IS THAT IT REFUSES.
    //
    // A rim legend at 260px is real letterforms. At 32px it is grey mush - and drawing it anyway is
    // the §22a-3b failure in its purest form, "a correct rule executed below the resolution floor
    // produces a confident wrong picture", which is worse than an absent one because the render
    // looks deliberate. So `SpecieLetters.fitGlyphs` is asked whether the legend can exist, and when
    // it says no the rim gets a RHYTHM BAND instead: the beading a legend is actually set on.
    //
    // ⭐ THE BAND IS NOT A CONSOLATION PRIZE. It is what a worn or a small coin honestly looks like -
    // you can see there is an inscription and you cannot read it - so the degraded form is a
    // truthful picture rather than a placeholder. §17c-1: the feature moves to a scale where it can
    // exist, and at the scale where it cannot, something true takes its place.
    // =============================================================================================

    R.LEGEND_EM = 0.088;          // cap height as a fraction of the flan diameter

    /**
     * Set a legend around the rim, or degrade honestly.
     *
     * @param {CanvasRenderingContext2D} ctx
     * @param {object} T transform for the whole flan
     * @param {object} metal
     * @param {number} wear
     * @param {object} opt {text, alphabet, arc:[from,to] radians, radius: fraction of diameter}
     * @returns {{mode:string, glyphs:number, beads:number, why:string}}
     */
    R.legend = function (ctx, T, metal, wear, opt) {
        var M = MET(), L = LET();
        var field = M.surface(metal, wear, -1);
        var face = M.surface(metal, wear, +1);
        var radius = (typeof opt.radius === 'number' ? opt.radius : 0.425) * T.d;
        // ⛔ THE DEFAULT ARC IS 259 DEGREES, NOT 115. The first version ran the legend across the
        // top quadrant only, which is a quarter of the room a real die uses and is why "AURELIA
        // IMPERATRIX" had nowhere to go. A struck legend runs almost the whole way round and breaks
        // at the bottom for the exergue - that gap is where the denomination or the mint mark goes,
        // so it is a feature of the layout rather than space left over.
        //
        // ⚠️ The arc must stay CENTRED ON THE TOP (-PI/2): each glyph is rotated by `a + PI/2`, so
        // its baseline points at the centre of the coin, and a legend centred anywhere else would
        // read upside down over part of its run.
        var a0 = opt.arc ? opt.arc[0] : -Math.PI * 1.22;
        var a1 = opt.arc ? opt.arc[1] : Math.PI * 0.22;
        var runPx = Math.abs(a1 - a0) * radius;

        var emPx = T.d * R.LEGEND_EM;
        var alpha = (L && opt.alphabet) ? L.get(opt.alphabet) : null;
        var inkPx = emPx * (alpha ? alpha.inkEm : 0.13);

        var trans = L && alpha ? L.transliterate(opt.alphabet, opt.text || '') : { struck: '', dropped: [] };
        var text = trans.struck;

        // ⛔ `setText`, NOT `fitGlyphs`. fitGlyphs answers "how many glyphs COULD go here"; only
        // setText answers "does THIS text fit", and taking the first N characters of a legend is
        // silently inventing an abbreviation nobody chose. Wing §22f: a fitter that can fail to fit
        // must SAY SO - and the caller must read what it says.
        var fit = L
            ? L.setText(runPx, emPx, inkPx, text.length)
            : { resolves: false, fits: false, count: 0, overflow: 0, pitch: 0, why: 'SpecieLetters.js not loaded' };

        // ⛔ THE REFUSAL BRANCH. It fires on SIZE, not on text - a legend that cannot resolve cannot
        // resolve whatever it says.
        if (!fit.resolves || !text.length) {
            var beads = R.rhythmBand(ctx, T, metal, wear, radius, a0, a1);
            return {
                mode: 'band', glyphs: 0, beads: beads, why: fit.why,
                overflow: 0, dropped: trans.dropped
            };
        }

        // The text is CENTRED on the arc it was given. A legend that starts at one end and runs out
        // is a legend somebody mis-measured; a real die centres its inscription.
        var n = Math.min(text.length, fit.count);
        var used = n * fit.pitch;
        var span = used / radius;                    // radians the text will actually occupy
        var mid = (a0 + a1) / 2;
        var start = mid - span / 2;
        var step = span / n;

        var bevel = R.bevelPx(T.d, wear);
        var drawn = 0;
        for (var i = 0; i < n; i++) {
            var ch = text.charAt(i);
            if (ch === ' ') continue;
            var g = L.glyph(opt.alphabet, ch);
            if (!g) continue;                        // §21c: skip, never substitute
            var a = start + step * (i + 0.5);
            ctx.save();
            ctx.translate(T.cx + Math.cos(a) * radius, T.cy + Math.sin(a) * radius);
            // A letter on a rim stands UP from the rim, so it is rotated to the radius, not to the
            // tangent - which is what makes a circular inscription read as struck INTO a coin
            // rather than as text bent along a path.
            ctx.rotate(a + Math.PI / 2);
            ctx.scale(emPx, emPx);
            ctx.lineWidth = (inkPx / emPx);
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';

            // relief, exactly as a device gets it: shadow, then lit edge, then the face
            var passes = bevel > 0
                ? [[M.relief(face, -1, metal.reliefMin * 0.55), bevel / emPx, bevel / emPx],
                   [M.relief(face, +1, metal.reliefMin * 0.45), -bevel / emPx, -bevel / emPx],
                   [face, 0, 0]]
                : [[face, 0, 0]];
            for (var q = 0; q < passes.length; q++) {
                ctx.strokeStyle = R.css(passes[q][0]);
                for (var s = 0; s < g.length; s++) {
                    var poly = g[s];
                    ctx.beginPath();
                    ctx.moveTo(poly[0][0] - 0.5 + passes[q][1], poly[0][1] - 0.5 + passes[q][2]);
                    for (var k = 1; k < poly.length; k++) {
                        ctx.lineTo(poly[k][0] - 0.5 + passes[q][1], poly[k][1] - 0.5 + passes[q][2]);
                    }
                    ctx.stroke();
                }
            }
            ctx.restore();
            drawn++;
        }
        // ⛔ `overflow` IS REPORTED, NEVER SWALLOWED. A caller that ignores it ships a legend that
        // has been abbreviated by arithmetic rather than by an author (wing §22f), and the probe
        // that renders this goes RED on any non-zero value.
        return {
            mode: 'legend', glyphs: drawn, beads: 0, why: fit.why, pitch: fit.pitch,
            overflow: fit.overflow, squeezed: fit.squeezed, dropped: trans.dropped,
            wanted: text.length
        };
    };

    /**
     * The honest degraded form: the beading a legend is set on.
     *
     * ⛔ ITS COUNT IS DERIVED FROM THE ARC, NEVER TYPED (wing §22b-1a - Escutcheon declared
     * `marks: 18` for a whole bezel and got eighteen specks 39px apart), and it declares a PITCH in
     * absolute pixels because a ratio tuned at a comfortable size is always too tight at the
     * thumbnail (§22a-2d).
     *
     * @returns {number} beads actually drawn.
     */
    R.rhythmBand = function (ctx, T, metal, wear, radius, a0, a1) {
        var M = MET();
        var field = M.surface(metal, wear, -1);
        var beadR = Math.max(0.6, T.d * 0.011);
        var pitch = beadR * 2 + Math.max(1.4, T.d * 0.008);
        var runPx = Math.abs(a1 - a0) * radius;
        if (beadR < 0.6 || runPx < pitch * 5) return 0;      // even the band can fail to resolve
        var n = Math.floor(runPx / pitch);
        var step = (a1 - a0) / n;
        var drawn = 0;
        for (var i = 0; i < n; i++) {
            var a = a0 + step * (i + 0.5);
            var ca = Math.cos(a), sa = Math.sin(a);
            var facing = -(ca + sa) / Math.SQRT2;
            ctx.fillStyle = R.css(M.relief(field, facing >= 0 ? +1 : -1,
                metal.reliefMin * (0.3 + 0.7 * Math.abs(facing))));
            ctx.beginPath();
            ctx.arc(T.cx + ca * radius, T.cy + sa * radius, beadR, 0, Math.PI * 2);
            ctx.fill();
            drawn++;
        }
        return drawn;
    };

    /**
     * Strike a coin into its OWN bitmap and return it.
     *
     * ⛔ THIS IS THE SHIPPED PATH, NOT A CONVENIENCE. ARCHITECTURE §5: a coin is hundreds of path
     * operations and a purse may show a dozen at once, so a coin is baked ONCE into a cached Bitmap
     * keyed by (realm, denomination, metal, wear, size) and then blitted.
     *
     * ⭐ AND IT IS WHAT MAKES A PIERCING CORRECT. `pierce` uses `destination-out`, which wing §22d
     * warns erases to TRANSPARENT through everything behind it - so punching a hole while drawing
     * straight onto a shared surface takes the SCENE with it. MEASURED: on the flan sheet the
     * piercing came out as a white disc, because it had erased the sheet's own background. On the
     * coin's own bitmap the transparency is exactly right and the blit composites over whatever the
     * scene has. ⇒ Any caller drawing more than one coin must go through here.
     *
     * @param {number} diameterPx
     * @param {object} opt as R.strike, plus optional `pad` px around the piece.
     * @returns {{canvas:HTMLCanvasElement, report:object, size:number, pad:number}}
     */
    R.bake = function (diameterPx, opt) {
        var pad = typeof opt.pad === 'number' ? opt.pad : Math.ceil(diameterPx * 0.04);
        var size = Math.ceil(diameterPx + pad * 2);
        var cv = (typeof document !== 'undefined')
            ? document.createElement('canvas')
            : null;
        if (!cv) throw new Error('SpecieRender.bake: no document to create a canvas on');
        cv.width = size; cv.height = size;
        var ctx = cv.getContext('2d');
        var T = R.transform(size / 2, size / 2, diameterPx);
        var report = R.strike(ctx, T, opt);
        return { canvas: cv, report: report, size: size, pad: pad };
    };

})(SpecieRender);
