/*:
 * @target MZ
 * @plugindesc [Specie] Coinage — reads the project's own database and decides what money it strikes. Library file; no parameters.
 * @author Core Systems Asset Factory
 *
 * @help
 * SpecieCoinage.js
 *
 * The classifier. It takes a project's System and Items data and returns the
 * coinage that project would actually have struck: how many denominations, what
 * each is worth, and which device, metal, flan and lettering each one carries.
 *
 * ⛔ THIS FILE, NOT THE CORPUS, DECIDES WHAT A BUYER SEES. Wing §21i: Glaze's
 * corpus reported 168 vessels and the in-engine shelf showed TWELVE ITEMS IN FIVE
 * FORMS WITH FOUR VISIBLE TWINS, because a generator's range dies in its
 * classifier and `volume()` cannot see it. Every instrument in this factory
 * measures the first number and a buyer sees the second.
 *
 * It takes its data as ARGUMENTS rather than reading $dataSystem directly, so the
 * whole classifier can be run over synthetic projects offline, which is what
 * `_probe/spread_check.js` does.
 *
 * Load order does not matter. Nothing here resolves a sibling file.
 */

var SpecieCoinage = SpecieCoinage || {};

(function (C) {
    'use strict';

    // =============================================================================================
    // THE LADDER IS ANCHORED TO THE ENGINE'S OWN DATABASE, NOT TO TASTE
    //
    // MEASURED 2026-09-04 out of Kernel/engines/RPGMakerMZ/BlankProject/data/Items.json:
    //
    //   Antidote 80 · Potion 100 · Dispel Herb 200 · Super Potion 250 · Magic Water 300
    //   Miracle Drop 450 · Stimulant 500 · Full Potion 550 · Elixir 1200 · Enhancements 3000
    //
    // ⛔ ARCHITECTURE.md quoted "Potion 500, Super Potion 1500" in the very paragraph telling us to
    // anchor to the database. Potion is 100. A ladder built on the remembered figures would have put
    // the commonest item in the wrong tier for every project shipping the stock database - and wing
    // §24a says that is MOST projects. A number remembered is not a number measured (§22a-6: an
    // invented threshold manufactures false reds and false passes alike).
    //
    // The real spread is 80 -> 3000, about 37x, and these are its rungs.
    // =============================================================================================

    C.STOCK_LOW = 80;             // Antidote, the cheapest real item in the stock database
    C.STOCK_HIGH = 3000;          // the Enhancement items, the dearest

    /**
     * The denomination ladder for a project, derived from its OWN price spread.
     *
     * ⛔ FIVE DENOMINATIONS IS NOT A TYPED CONSTANT EITHER. A realm whose whole economy spans 10x
     * does not strike five coins; one spanning 3000x needs more than three. The count comes from
     * the spread, and the spread comes from the buyer's items.
     *
     * @param {number} low the cheapest meaningful price in the project.
     * @param {number} high the dearest.
     * @returns {{count:number, values:number[]}}
     */
    C.ladder = function (low, high) {
        var lo = Math.max(1, low || C.STOCK_LOW);
        var hi = Math.max(lo * 2, high || C.STOCK_HIGH);
        // A coinage needs a unit small enough to make change for the cheapest thing, so the base is
        // an order of magnitude under the cheapest item rather than equal to it - which is what a
        // real small change coin IS.
        var base = Math.max(1, Math.pow(10, Math.floor(Math.log10(lo)) - 1));
        var decades = Math.log(hi / base) / Math.log(10);
        // one rung per ~0.85 decades, floored at 3 and capped at 6: below three a purse is not a
        // coinage, and above six the denominations stop being tellable apart by value alone.
        var count = Math.max(3, Math.min(6, Math.round(decades / 0.85)));
        var values = [];
        for (var i = 0; i < count; i++) {
            var v = base * Math.pow(hi / base, i / (count - 1));
            // round to something a mint would actually strike
            var mag = Math.pow(10, Math.floor(Math.log10(v)));
            values.push(Math.max(1, Math.round(v / mag) * mag));
        }
        // ⚠️ Rounding can collide two rungs (1 and 1 at the bottom of a tight spread). A coinage
        // with two coins of the same value is a defect a buyer would see immediately, so the
        // duplicates are pushed up rather than left to render as twins.
        for (var j = 1; j < values.length; j++) {
            if (values[j] <= values[j - 1]) values[j] = values[j - 1] * 2;
        }
        return { count: count, values: values };
    };

    // =============================================================================================
    // WHAT THE PROJECT SAYS ABOUT ITSELF
    //
    // ⛔ WING §24a: A READING OF A BUYER'S PROJECT MUST SCORE ONLY WHAT THE BUYER CHANGED. Measured
    // on Frontispiece: a house reading returned the SAME house twelve times out of twelve over twelve
    // different synthetic projects, because System.json already contains Axe, Shield, Spear, Ice and
    // Staff and those scored one house outright. The fallback written specifically to spread the
    // market was DEAD CODE for the common case.
    //
    // So the stock vocabulary is read OUT OF THE ENGINE and subtracted, rather than guessed at with
    // a hand-typed stopword list - a guessed list is a guessed classifier.
    // =============================================================================================

    /**
     * What Kadokawa ships. Anything in here says nothing about a particular game.
     *
     * ⛔⛔ THIS LIST IS DERIVED FROM THE ENGINE, NOT TYPED, AND THE HAND-TYPED VERSION SHIPPED A REAL
     * DEFECT. The in-engine capture of the blank project read **"THE COINAGE OF BREASTPLATE"**,
     * because `Breastplate` is a stock ARMOR, it is among the longest words the classifier can find,
     * and the old 42-word list covered items and actors but not weapons, armors, classes, enemies,
     * states or the terms table. Wing §24a measured that MOST MZ PROJECTS SHIP THE STOCK DATABASE,
     * so that was not an edge case - it was what most buyers would have seen.
     *
     * §24a also names the wrong fix: "read the stock vocabulary OUT OF THE ENGINE rather than typing
     * a guessed stopword list - a guessed list is a guessed classifier." So it is generated, and
     * regenerating it is one command:
     *
     *     node Internal_Ops/_probe/stock_words.js --write
     *
     * which reads every `name` in Actors, Classes, Skills, Items, Weapons, Armors, Enemies, Troops,
     * States and MapInfos plus System's title, currency unit, type vocabularies and terms, out of
     * `Kernel/engines/RPGMakerMZ/BlankProject/data`, and rewrites the block between the markers
     * below. ⛔ Do not hand-edit between the markers: a derived constant that can be edited by hand
     * is two sources of one fact and the hand copy wins (wing §11a).
     *
     * ⚠️ THE COST IS DELIBERATE AND WORTH STATING: a project that names its realm "Silver" or
     * "Thunder" loses that word, because Kadokawa uses it too. That is the correct trade - a word the
     * engine also ships says less about a particular game than one it does not - and the fallback
     * chain (currency unit, then title, then the rest, then the currency unit verbatim) means a
     * project is never left unnamed.
     *
     * MEASURED 2026-09-04: 364 words from 11 data files.
     */
    /* STOCK_WORDS:BEGIN — generated by Internal_Ops/_probe/stock_words.js, do not hand-edit */
    C.STOCK_WORDS = [
        'accessories', 'accessory', 'adventurer', 'agility', 'aid', 'ailment', 'albert',
        'alluring', 'always', 'and', 'antidote', 'armor', 'armors', 'artist', 'attack',
        'autosave', 'axe', 'bagh', 'bandana', 'bandit', 'bangle', 'bardiche', 'barrier', 'basic',
        'battle', 'bell', 'bgm', 'bgs', 'bizarre', 'blade', 'bless', 'blind', 'blizzard',
        'block', 'blood', 'blow', 'body', 'bodyslam', 'bow', 'breastplate', 'breath',
        'brigandine', 'bronze', 'buckler', 'burst', 'buy', 'call', 'cancel', 'cap', 'cestus',
        'chainmail', 'charm', 'circlet', 'claw', 'clear', 'cloak', 'cloth', 'clothing', 'coif',
        'command', 'confuse', 'confusion', 'continue', 'cost', 'cotton', 'counter',
        'counterattack', 'crash', 'crossbow', 'crow', 'cry', 'cure', 'current', 'curse',
        'daggar', 'dagger', 'damage', 'dance', 'darkness', 'dash', 'dead', 'decreaser',
        'defeated', 'defense', 'devil', 'dispel', 'divine', 'double', 'down', 'dragon', 'drain',
        'drained', 'drop', 'dual', 'dust', 'earth', 'earthquake', 'effect', 'elemental', 'eliot',
        'elixir', 'emerged', 'encounter', 'encounters', 'end', 'enemy', 'enhancement', 'equip',
        'escape', 'evaded', 'evasion', 'excellent', 'exp', 'eye', 'falchion', 'falcon',
        'feathered', 'fight', 'file', 'fire', 'first', 'flail', 'flame', 'flare', 'flash', 'fog',
        'force', 'formation', 'found', 'full', 'gained', 'gale', 'game', 'general', 'glove',
        'gnome', 'goblin', 'gold', 'got', 'guard', 'gun', 'guts', 'halberd', 'half', 'hand',
        'hard', 'has', 'hat', 'head', 'heal', 'heavy', 'helm', 'helmets', 'herb', 'hide', 'hit',
        'however', 'hunter', 'ice', 'iii', 'immortal', 'increase', 'increaser', 'iron', 'item',
        'items', 'kasey', 'keeper', 'key', 'kick', 'knife', 'knight', 'large', 'learned',
        'leather', 'level', 'life', 'light', 'like', 'linen', 'load', 'long', 'lost', 'luck',
        'lucky', 'lullaby', 'machete', 'made', 'magic', 'magical', 'maiden', 'mana', 'map',
        'martial', 'master', 'max', 'meditate', 'melody', 'mental', 'meteor', 'michelle', 'mind',
        'miracle', 'mirror', 'miss', 'mithril', 'money', 'monster', 'morning', 'movement',
        'naka', 'new', 'next', 'normal', 'now', 'nuke', 'nullified', 'optimize', 'options',
        'painful', 'paralysis', 'paralyze', 'party', 'petrify', 'physical', 'piercer', 'point',
        'pointed', 'poison', 'poke', 'possession', 'potion', 'power', 'priest', 'priscilla',
        'protect', 'protected', 'provoke', 'qigong', 'quake', 'quicken', 'radar', 'rage', 'rain',
        'raise', 'received', 'recover', 'recovered', 'recovery', 'reduce', 'reflected',
        'reflection', 'regeneration', 'reid', 'remember', 'reserved', 'resistance', 'returned',
        'ring', 'robe', 'rod', 'round', 'roundhouse', 'roza', 'sage', 'saint', 'sandstorm',
        'save', 'scratch', 'see', 'sell', 'shade', 'shield', 'shields', 'shock', 'shooter',
        'short', 'shot', 'shout', 'silence', 'silk', 'silver', 'skill', 'skills', 'slash',
        'sleep', 'slime', 'slow', 'small', 'song', 'sonic', 'sorcerer', 'spark', 'spear',
        'special', 'specialty', 'spectacles', 'speed', 'spell', 'spiked', 'spin', 'spirit',
        'staff', 'stance', 'star', 'starlight', 'started', 'status', 'stimulant', 'stocker',
        'stone', 'strong', 'stun', 'suck', 'super', 'surprised', 'sweep', 'sword', 'swordsman',
        'tactician', 'team', 'the', 'there', 'throw', 'thrust', 'thunder', 'tiger', 'title',
        'took', 'tornado', 'touch', 'toxic', 'tranquilizer', 'treant', 'triple', 'tsunami',
        'turban', 'unable', 'upper', 'uses', 'venom', 'vest', 'victorious', 'volume', 'wait',
        'wand', 'warm', 'warning', 'was', 'watchful', 'water', 'wave', 'weapon', 'went', 'which',
        'whip', 'wild', 'willpower', 'wind', 'windmill', 'wooden', 'would', 'yell', 'you'
    ];
    /* STOCK_WORDS:END */

    // ⛔ FUNCTION WORDS ARE NOT A GUESS ABOUT THE GAME, WHICH IS WHY THIS LIST IS LEGITIMATE WHERE
    // §24a FORBIDS A GUESSED STOPWORD LIST. §24a's objection is to inventing a list of what a GAME
    // might say - that is a guessed classifier. "the" and "of" are facts about ENGLISH, and they are
    // the reason two unrelated projects both resolved to a realm called "The" on the first run of
    // `_probe/spread_check.js`.
    C.FUNCTION_WORDS = ['the', 'and', 'for', 'of', 'a', 'an', 'in', 'on', 'at', 'to', 'from',
        'with', 'by', 'is', 'it', 'its', 'this', 'that', 'my', 'our', 'your'];

    /**
     * Split a field into candidate words. ⛔ EVERY SOURCE GOES THROUGH THE SAME SPLIT.
     *
     * The first version split `title` and `currencyUnit` and passed `words` through RAW, so a
     * project shipping the stock database got a realm called **"-----reserved"** - the name of a
     * separator row in Items.json. Two paths that must agree, agreeing by care rather than by
     * construction (wing §11), and the one nobody looked at was the one most buyers hit.
     *
     * @param {*} v
     * @returns {string[]}
     */
    function words(v) {
        return String(v == null ? '' : v).split(/[^A-Za-z]+/);
    }

    /**
     * @param {object} data {title, currencyUnit, words:string[]}
     * @returns {{all:string[], currency:string[], title:string[]}} this project's OWN words.
     */
    C.ownWords = function (data) {
        var stock = {};
        var i;
        for (i = 0; i < C.STOCK_WORDS.length; i++) stock[C.STOCK_WORDS[i]] = true;
        for (i = 0; i < C.FUNCTION_WORDS.length; i++) stock[C.FUNCTION_WORDS[i]] = true;

        var seen = {};
        function keep(list) {
            var out = [];
            for (var j = 0; j < list.length; j++) {
                var w = String(list[j]).toLowerCase().trim();
                if (w.length < 3) continue;             // "G" and "of" say nothing
                if (stock[w] || seen[w]) continue;
                seen[w] = true;
                out.push(w);
            }
            return out;
        }
        // Order matters: the CURRENCY UNIT is read first because on a coinage product it is the most
        // direct thing a project has ever said about its own money. A realm that calls its money the
        // "aureus" should strike aurei.
        var currency = keep(words(data.currencyUnit));
        var title = keep(words(data.title));
        var rest = [];
        var w = data.words || [];
        for (i = 0; i < w.length; i++) rest = rest.concat(keep(words(w[i])));
        return { all: currency.concat(title, rest), currency: currency, title: title };
    };

    /**
     * Pick the word a realm is named for.
     *
     * ⛔ NOT "THE FIRST ONE". The first version took `own[0]` and two unrelated projects both got a
     * realm called "The". Within each source the LONGEST word is preferred, which is a proxy for
     * distinctiveness that needs no corpus and cannot go stale.
     *
     * @param {object} own from C.ownWords
     * @param {string} fallback
     * @returns {string}
     */
    C.realmWord = function (own, fallback) {
        function longest(list) {
            var best = null;
            for (var i = 0; i < list.length; i++) {
                if (!best || list[i].length > best.length) best = list[i];
            }
            return best;
        }
        return longest(own.currency) || longest(own.title) || longest(own.all) || fallback;
    };

    // =============================================================================================
    // THE COINAGE
    //
    // ⛔ ONE CURRENCY MUST STILL PRODUCE A SET. ARCHITECTURE §3b: most MZ projects declare exactly
    // ONE currency, so if the realm were the unit of variation a buyer would get one coin. The realm
    // is the unit of IDENTITY (devices, metal family, lettering) and the DENOMINATION is the unit of
    // variation within it. That is how a single-currency project still gets a visibly varied purse,
    // and it is the honest reading of what a coinage IS.
    // =============================================================================================

    // Metal rises with denomination, which is what money actually does.
    C.METAL_LADDER = ['copper', 'bronze', 'billon', 'silver', 'electrum', 'gold'];
    C.DEBASED_LADDER = ['iron', 'copper', 'bronze', 'billon', 'brass', 'silver'];

    /**
     * A small deterministic hash, so a realm's choices are stable across saves and captures.
     * @param {string} s
     * @returns {number}
     */
    C.hash = function (s) {
        var h = 2166136261 >>> 0;
        var t = String(s);
        for (var i = 0; i < t.length; i++) {
            h ^= t.charCodeAt(i);
            h = Math.imul(h, 16777619) >>> 0;
        }
        return h >>> 0;
    };

    /**
     * Strike a whole coinage for a project.
     *
     * @param {object} data {title, currencyUnit, words, prices:number[], obverses:string[],
     *                       reverses:string[], flans:string[], alphabets:string[], debased:boolean}
     * @returns {{realm:string, alphabet:string, legend:string, debased:boolean,
     *            pieces:Array<object>}}
     */
    C.coinage = function (data) {
        var own = C.ownWords(data);
        // ⚠️ The fallback is the currency unit VERBATIM, not a made-up name. A project that has said
        // nothing about itself gets a coinage named after the one thing it did say - which for the
        // stock database is "G". That is honest; inventing "Realm" would be the product pretending
        // to know something it does not (§21c: skip, never substitute).
        var word = C.realmWord(own, data.currencyUnit ? String(data.currencyUnit) : 'Coin');
        var realm = word.charAt(0).toUpperCase() + word.slice(1);
        var h = C.hash(realm + '|' + own.all.join(','));

        var prices = (data.prices || []).filter(function (p) { return p > 0; }).sort(function (a, b) { return a - b; });
        var lad = C.ladder(prices.length ? prices[0] : C.STOCK_LOW,
                           prices.length ? prices[prices.length - 1] : C.STOCK_HIGH);

        var obv = data.obverses || [];
        var rev = data.reverses || [];
        var flans = data.flans || ['round'];
        var alphabets = data.alphabets || ['lapidary'];

        var alphabet = alphabets[h % alphabets.length];
        var debased = !!data.debased;
        var metals = debased ? C.DEBASED_LADDER : C.METAL_LADDER;

        var pieces = [];
        for (var i = 0; i < lad.count; i++) {
            var t = lad.count > 1 ? i / (lad.count - 1) : 0;
            // ⭐ EVERY AXIS MOVES WITH THE DENOMINATION, AND THE STEPS ARE COPRIME-ISH SO THEY DO NOT
            // MARCH IN LOCKSTEP. §25g measured the opposite failure on Cartouche - a rank window
            // widened to spread a crowd made collisions WORSE - so the spread here comes from the
            // axes advancing at DIFFERENT rates rather than from any one of them being wider.
            var oi = (h + i * 5) % Math.max(1, obv.length);
            var ri = (h + i * 7 + 3) % Math.max(1, rev.length);
            var fi = (h + i * 3 + 1) % Math.max(1, flans.length);
            var mi = Math.min(metals.length - 1, Math.round(t * (metals.length - 1)));
            pieces.push({
                index: i,
                value: lad.values[i],
                name: C.denominationName(realm, i, lad.count),
                metal: metals[mi],
                flan: flans[fi],
                obverse: obv.length ? obv[oi] : null,
                reverse: rev.length ? rev[ri] : null,
                alphabet: alphabet,
                // ⛔ THE SEED IS THE PIECE'S IDENTITY, so the same denomination of the same realm is
                // the same object every time a save is loaded (wing quality bar: deterministic RNG
                // seam). A SERIAL is added by the scene per physical coin in the purse.
                seed: C.hash(realm + '|' + i) | 0
            });
        }
        return {
            realm: realm,
            alphabet: alphabet,
            legend: realm.toUpperCase(),
            debased: debased,
            ownWordCount: own.all.length,
            pieces: pieces
        };
    };

    C.DENOM_NAMES = ['Bit', 'Penny', 'Groat', 'Mark', 'Crown', 'Sovereign'];

    /**
     * @param {string} realm
     * @param {number} i
     * @param {number} count
     * @returns {string}
     */
    C.denominationName = function (realm, i, count) {
        // ⭐ THE TOP COIN TAKES THE REALM'S OWN NAME, and that is not decoration. On the first run of
        // `_probe/spread_check.js` every one of twelve projects called its coins "Bit / Groat / Mark
        // / Sovereign" - the devices, metals and flans all spread properly and the NAMES were
        // identical, which is §21i one layer up: an identity axis that exists in the data and not in
        // what the buyer reads. A realm that calls its money the aureus strikes an Aureus, and that
        // is the single most legible thing a purse can say about where it came from.
        //
        // ⚠️ Only the TOP one. Giving every rung the realm's name would produce "Aureus, Aureus,
        // Aureus" - the opposite failure, and the reason a real coinage names its small change
        // separately.
        if (i === count - 1 && realm && realm.length >= 3) return realm;

        // ⚠️ AND THE LADDER MUST NOT OFFER A NAME THE REALM HAS ALREADY TAKEN. A project whose
        // currency unit is "mark" produced "Mark 200 / Mark 3000" - two coins of one purse with the
        // same name, which is a defect a buyer sees the moment they open their inventory. The realm
        // is removed from the pool rather than the collision being renamed afterwards, because a
        // rename after the fact is a second code path that has to agree with the first (wing §11).
        var pool = [];
        var lower = String(realm || '').toLowerCase();
        for (var i2 = 0; i2 < C.DENOM_NAMES.length; i2++) {
            if (C.DENOM_NAMES[i2].toLowerCase() !== lower) pool.push(C.DENOM_NAMES[i2]);
        }
        // Map the remaining rungs onto the pool proportionally, so a 3-coin realm still runs small
        // to large rather than using the first names and stopping partway up.
        var n = pool.length - 1;                       // the top slot belongs to the realm
        var k = count > 1 ? Math.round(i / (count - 1) * (n - 1)) : 0;
        return pool[Math.max(0, Math.min(n - 1, k))];
    };

    /**
     * Total authored entities on this axis: the denomination names. The COINAGE itself is derived,
     * so counting it would be counting the multiplication (wing §21i, master §1.1 q3).
     * @returns {number}
     */
    C.volume = function () { return C.DENOM_NAMES.length; };

})(SpecieCoinage);
