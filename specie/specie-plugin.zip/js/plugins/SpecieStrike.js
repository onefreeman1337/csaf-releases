/*:
 * @target MZ
 * @plugindesc [Specie] Strike — wear, off-centre, double-strike and clipping, deterministic per piece. Library file; no parameters.
 * @author Core Systems Asset Factory
 *
 * @help
 * SpecieStrike.js
 *
 * What happened to THIS piece. Two coins of the same realm, denomination and
 * metal are not the same object: one was struck square and one off-centre, one
 * has been in a purse for forty years and one was minted last week.
 *
 * ⛔ EVERY VALUE HERE IS DERIVED FROM A SEED, NEVER FROM Math.random(). Wing
 * quality bar: "deterministic RNG seam - never Math.random() in game logic." A
 * coin in a save file must look the same when the save is loaded, and a store
 * capture must be reproducible frame for frame.
 *
 * It has NO dependency on RPG Maker MZ and makes no engine calls.
 *
 * Load order does not matter. Nothing here resolves a sibling file.
 */

var SpecieStrike = SpecieStrike || {};

(function (S) {
    'use strict';

    // =============================================================================================
    // THE SEAM
    //
    // mulberry32. Cheap, well-distributed, and it takes an integer seed so a piece's identity can BE
    // its seed - (realm, denomination, serial) hashed once.
    //
    // ⚠️ NO WARM-UP, AND THAT IS MEASURED RATHER THAN ASSUMED. Wing §21g-1: the textbook complaint
    // about mulberry32 is that its first few outputs are correlated, and "discard the first eight"
    // was one edit away on Song Sheets. MEASURED over 20,000 seeds there: the first eight outputs
    // give chi-square 2.1 on five buckets (4 df) with serial correlation 0.0028, against 3.46 and
    // 0.0044 for outputs 100-108. The early stream is if anything the BETTER one. A warm-up would
    // have fixed nothing, changed every generated artefact, and left a false explanation in the
    // source. §12 rule 3 applies to DIAGNOSES, not only to tests.
    // =============================================================================================

    /**
     * @param {number} seed any integer.
     * @returns {function(): number} a generator in [0, 1).
     */
    S.rng = function (seed) {
        var a = (seed | 0) >>> 0;
        return function () {
            a |= 0; a = (a + 0x6D2B79F5) | 0;
            var t = Math.imul(a ^ (a >>> 15), 1 | a);
            t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    };

    /**
     * Hash a piece's identity into a seed, so the same coin is always the same coin.
     * @param {...(string|number)} parts
     * @returns {number}
     */
    S.seedOf = function () {
        var h = 2166136261 >>> 0;
        for (var i = 0; i < arguments.length; i++) {
            var s = String(arguments[i]);
            for (var j = 0; j < s.length; j++) {
                h ^= s.charCodeAt(j);
                h = Math.imul(h, 16777619) >>> 0;
            }
            h ^= 0x9E3779B9; h = Math.imul(h, 16777619) >>> 0;
        }
        return h | 0;
    };

    // =============================================================================================
    // WEAR
    //
    // ⛔ WEAR IS A GEOMETRY FACT BEFORE IT IS A COLOUR FACT, AND THE FIRST BUILD ONLY HAD THE COLOUR
    // HALF. SpecieMetals.surface() softens the RELIEF SEPARATION with wear - correct, and it is what
    // makes an old gold coin read as old without discolouring - but SpecieRender.bevelPx was a
    // function of SIZE ALONE. So a coin at wear 0.9 kept a mint-sharp bevelled edge on every device
    // and every letter while its colours said it was ancient, and the two halves of the same fact
    // disagreed inside one picture.
    //
    // That is wing §22a-2e's shape (a declared axis only half drawn) and §11's (two code paths that
    // must agree, agreeing by care rather than by construction). One function owns it now, and both
    // the renderer and any caller read THAT.
    // =============================================================================================

    S.STAGES = [
        { id: 'mint', max: 0.10, name: 'Mint', note: 'As struck. Every line sharp.' },
        { id: 'fine', max: 0.30, name: 'Fine', note: 'Handled, but the high points are untouched.' },
        { id: 'worn', max: 0.55, name: 'Worn', note: 'The highest relief is flattening.' },
        { id: 'poor', max: 0.80, name: 'Poor', note: 'The device is a shape rather than a picture.' },
        { id: 'smooth', max: 1.01, name: 'Worn Smooth', note: 'A disc with a ghost on it.' }
    ];

    /**
     * @param {number} wear 0..1
     * @returns {object} the stage record.
     */
    S.stage = function (wear) {
        var w = Math.max(0, Math.min(1, wear));
        for (var i = 0; i < S.STAGES.length; i++) if (w < S.STAGES[i].max) return S.STAGES[i];
        return S.STAGES[S.STAGES.length - 1];
    };

    /**
     * How much of the strike's RELIEF survives at a given wear.
     *
     * ⭐ THE ONE READER OF WEAR FOR GEOMETRY. The renderer multiplies its bevel by this, so a worn
     * coin's edges are genuinely shallower rather than merely duller, and the geometry and the
     * colour cannot drift apart (§11: prefer a shape where both paths call the same function to one
     * where they re-implement it - a second copy does not drift, it WINS, §11a).
     *
     * ⚠️ It never reaches zero. A coin worn perfectly flat is a blank disc, which is not a picture
     * of an old coin - it is a picture of nothing - so the floor is 0.18 and the DEVICE is what
     * disappears, not the metal.
     *
     * @param {number} wear 0..1
     * @returns {number} 0.18 .. 1
     */
    S.reliefScale = function (wear) {
        var w = Math.max(0, Math.min(1, wear));
        return 1 - 0.82 * w;
    };

    /**
     * How much of a device's FINE DETAIL survives - the incuse cuts and the detail-gated marks.
     *
     * ⛔ THIS FALLS FASTER THAN THE RELIEF, AND THAT IS THE WHOLE POINT OF WEAR. A coin does not fade
     * uniformly: the high points go first, so an old piece keeps its gross silhouette and loses its
     * eye, its mane and its lettering. Modelling it as one uniform fade is what makes generated
     * wear look like a brightness slider, which is §14a's trap - obeying the symptom rather than the
     * cause and making the picture worse while the number improves.
     *
     * @param {number} wear 0..1
     * @returns {number} 0 .. 1
     */
    S.detailScale = function (wear) {
        var w = Math.max(0, Math.min(1, wear));
        var v = 1 - 1.55 * w;
        return v < 0 ? 0 : v;
    };

    // =============================================================================================
    // THE STRIKE ITSELF
    //
    // A hammered coin is struck by hand. The die lands off centre, or it bounces and lands twice, or
    // the flan was not quite big enough for the die and part of the design ran off the edge. Those
    // are not defects to be avoided - they are the reason a purse of hand-struck coins looks like
    // objects rather than like one sprite repeated.
    //
    // ⚠️ EVERY MAGNITUDE IS SMALL. §22a's law cuts both ways: an off-centre strike of 0.25 of the
    // flan does not read as "hand struck", it reads as a rendering bug. The eye reads a coin as
    // CENTRED unless told otherwise, so the deviation has to be big enough to notice and small
    // enough to stay inside that reading.
    // =============================================================================================

    S.MAX_OFFSET = 0.055;         // of the flan diameter
    S.MAX_ROTATE = 0.10;          // radians
    S.MAX_GHOST = 0.035;          // of the flan diameter, for a double strike

    /**
     * Everything that happened to one piece, derived from its seed.
     *
     * @param {number} seed
     * @param {object} [opt] {wear, quality} - `quality` 0..1 biases how well this mint struck; a
     *        confident late mint strikes square and a frontier mint does not.
     * @returns {{offX:number, offY:number, rot:number, ghost:?{dx:number,dy:number,alpha:number},
     *            wear:number, reliefScale:number, detailScale:number, stage:object}}
     */
    S.strike = function (seed, opt) {
        var o = opt || {};
        var r = S.rng(seed);
        var quality = typeof o.quality === 'number' ? Math.max(0, Math.min(1, o.quality)) : 0.55;
        var slop = 1 - quality;

        // ⛔ THE RNG IS DRAWN IN A FIXED ORDER AND EVERY VALUE IS CONSUMED, whether or not it is
        // used. A conditional draw makes the stream depend on the branch, so two coins that differ
        // only in `quality` would get unrelated wear - and the piece would change identity when a
        // buyer edited an unrelated parameter.
        var ax = r(), ay = r(), arot = r(), adbl = r(), agx = r(), agy = r(), aga = r();

        var wear = typeof o.wear === 'number' ? Math.max(0, Math.min(1, o.wear)) : 0;
        var doubled = adbl < (0.06 + 0.22 * slop);

        return {
            offX: (ax * 2 - 1) * S.MAX_OFFSET * slop,
            offY: (ay * 2 - 1) * S.MAX_OFFSET * slop,
            rot: (arot * 2 - 1) * S.MAX_ROTATE * slop,
            ghost: doubled
                ? {
                    dx: (agx * 2 - 1) * S.MAX_GHOST * slop,
                    dy: (agy * 2 - 1) * S.MAX_GHOST * slop,
                    // ⚠️ A ghost is FAINT. A second impression at full strength is not a double
                    // strike, it is two coins on top of each other - and it reads as one.
                    alpha: 0.16 + 0.16 * aga
                }
                : null,
            wear: wear,
            reliefScale: S.reliefScale(wear),
            detailScale: S.detailScale(wear),
            stage: S.stage(wear)
        };
    };

    /**
     * Total authored entities on this axis, counted honestly: the named wear stages.
     *
     * ⚠️ NOT a multiplication of the continuous parameters. Wing §21i: volume() reports what the
     * corpus COULD make while a buyer sees what their database RESOLVES to, and "infinite because
     * the offsets are continuous" is exactly the kind of number that means nothing.
     * @returns {number}
     */
    S.volume = function () { return S.STAGES.length; };

})(SpecieStrike);
