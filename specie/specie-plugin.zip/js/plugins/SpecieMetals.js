/*:
 * @target MZ
 * @plugindesc [Specie] Metal corpus — 8 authored coinage metals: colour, lustre, and how each one corrodes. Library file; no parameters.
 * @author Core Systems Asset Factory
 *
 * @help
 * SpecieMetals.js
 *
 * Eight coinage metals as pure data, plus the two colour laws every other file in
 * this product is required to go through.
 *
 * It has NO dependency on RPG Maker MZ and makes no engine calls, so the whole
 * corpus can be read, diffed, rendered and checked offline before any of it
 * reaches a Bitmap.
 *
 * Load order does not matter. Nothing here resolves a sibling file.
 */

var SpecieMetals = SpecieMetals || {};

(function (M) {
    'use strict';

    // =============================================================================================
    // WHY A METAL IS NOT A COLOUR
    //
    // A struck coin is a RELIEF read by one fixed light. What separates gold from silver on screen
    // is only partly hue: it is also how hard the highlight is (lustre), and — the part nobody
    // draws — WHAT HAPPENS TO IT OVER TIME. Silver goes blue-black in the recesses. Copper goes
    // green. Gold does neither, which is most of why gold reads as gold.
    //
    // So corrosion is not decoration bolted on at the end. It is a property OF THE METAL, it lives
    // in the RECESSES rather than on the reliefs (that is what makes it read as age rather than as
    // dirt), and it is the axis that makes a worn copper piece and a worn gold piece two different
    // pictures instead of one picture at two hues.
    //
    // ⛔ WING §22a-2e IS THE TRAP THIS FILE EXISTS TO NOT FALL INTO: a corpus field that nothing
    // draws is a whole axis of the product that does not exist. Shipwright declared a `patch`
    // amount on five weathering states, tested the five states, captioned a plate about them, and
    // NOTHING TURNED THE NUMBER INTO A MARK. Every field below therefore has a named reader, and
    // the suite is required to assert that the reported mark count MOVES with the field — a number
    // that does not move with its input is not being read.
    // =============================================================================================

    /**
     * Rec. 601 luma. Used for every contrast decision in this product.
     *
     * ⛔ This is a WEIGHTED AVERAGE and it is NOT the same quantity as WCAG contrast, which is
     * computed on gamma-EXPANDED luminance. Wing §25h records what conflating them costs: a solver
     * picked its direction from a plain average, and on pine-plank at luma 157 it solved toward
     * BLACK for 4.01:1 when WHITE was worth 5.24:1 on the same surface, across 14 pairs. The two
     * disagree across the middle of the range, which is exactly where a coin's body colour sits.
     *
     * ⇒ Use `lum()` for RELIEF (how far have I moved this surface), and `pickContrast()` — which
     * tries BOTH directions and keeps the better — for INK. Never use lum() to choose a direction.
     *
     * @param {number[]} c RGB triple, each 0-255.
     * @returns {number} luma, 0-255.
     */
    M.lum = function (c) {
        return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2];
    };

    /**
     * How much room a colour has to move in a direction before it clips.
     *
     * ⛔ THIS FUNCTION IS THE REASON THE SUITE CAN BE HONEST. Wing §22e-1, corrected on Facet:
     * a flat `relief(base, +1, 30)` assertion goes RED on diamond, whose body colour [243,245,250]
     * sits at luma 244.9 with only 10.1 levels of headroom below white. Demanding 30 there is a
     * FALSE RED, not a defect — it is arithmetic. GOLD HAS THE SAME PROBLEM IN THIS PRODUCT.
     *
     * So every relief assertion is `min(want, headroom)` — "all the separation that exists" — and
     * it MUST be paired with a mid-grey control demanding the FULL delta, or that phrasing becomes
     * a loophole excusing a solver which has quietly stopped solving.
     *
     * @param {number[]} c RGB triple.
     * @param {number} dir +1 toward white, -1 toward black.
     * @returns {number} luma levels available in that direction, 0-255.
     */
    M.headroom = function (c, dir) {
        var l = M.lum(c);
        return dir > 0 ? (255 - l) : l;
    };

    /**
     * Move a colour toward white or black by AT LEAST `minDelta` luma levels, or by all the
     * headroom there is if that is less.
     *
     * ⛔ NEVER `shade(c, k)`. A multiplier is a hard-coded contrast RATIO, so its effect is
     * proportional to the base and it fails at both ends. Wing §22e-1 measured it: the same
     * multiplier moved a bright wax 27 luma levels and a dark one 11, and the device on the darkest
     * seal could not be made out at all. Every check was green throughout, because the shape was
     * drawn, filled and parsed correctly every time.
     *
     * A proportional term is kept as a FLOOR so bright metals still get a generous, natural relief
     * rather than the bare minimum.
     *
     * @param {number[]} c RGB triple.
     * @param {number} dir +1 lit, -1 shadowed.
     * @param {number} minDelta luma levels of separation required.
     * @returns {number[]} RGB triple.
     */
    M.relief = function (c, dir, minDelta) {
        var room = M.headroom(c, dir);
        var want = Math.min(minDelta, room);
        // Proportional floor: 12% of the distance to the limit, so a bright base is not left flat
        // just because the absolute requirement was already satisfied.
        var prop = room * 0.12;
        var need = Math.max(want, Math.min(prop, room));
        if (room <= 0.0001) return [c[0], c[1], c[2]];
        var t = need / room;                       // 0..1 of the way to the limit
        var target = dir > 0 ? 255 : 0;
        return [
            Math.round(c[0] + (target - c[0]) * t),
            Math.round(c[1] + (target - c[1]) * t),
            Math.round(c[2] + (target - c[2]) * t)
        ];
    };

    /**
     * Choose an ink that can actually be READ on `bg`, by trying both directions and keeping the
     * better one.
     *
     * ⛔ Wing §22e: card names were drawn in the palette's own `ground` colour — correct on a light
     * deck, and on four dark decks it was dark grey on dark grey with EVERY TITLE IN THE DECK
     * UNREADABLE. Nothing mechanical could see it: the text was drawn, sized, placed, and its
     * colour parsed.
     *
     * ⛔ And §25h: do not pick the direction by comparing lum(bg) to 127. Try both, measure both,
     * keep the winner. It cannot be worse than either arm alone and it costs one extra walk.
     *
     * @param {number[]} bg the surface the mark lands on.
     * @param {number} minDelta desired luma separation.
     * @returns {{ink:number[], delta:number, dir:number}}
     */
    M.pickContrast = function (bg, minDelta) {
        var up = M.relief(bg, +1, minDelta);
        var dn = M.relief(bg, -1, minDelta);
        var dUp = Math.abs(M.lum(up) - M.lum(bg));
        var dDn = Math.abs(M.lum(dn) - M.lum(bg));
        return dUp >= dDn
            ? { ink: up, delta: dUp, dir: +1 }
            : { ink: dn, delta: dDn, dir: -1 };
    };

    // =============================================================================================
    // THE CORPUS — 8 metals
    //
    // `body`      the flat colour of an unlit, unworn field.
    // `lustre`    0..1. How tight the specular highlight is. Gold and silver are polished metal;
    //             billon and iron are not. This drives highlight WIDTH, not brightness.
    // `patina`    the colour corrosion moves the RECESSES toward. null = this metal does not
    //             corrode in any way a player would recognise (gold).
    // `patinaRate` 0..1. How fast `patina` accumulates as wear rises. Copper greens fast; electrum
    //             barely at all.
    // `reliefMin` the luma separation this metal's relief must achieve where headroom allows.
    //             ⚠️ NOT a constant across metals on purpose: a dark metal needs more absolute
    //             separation to read as relief than a bright one does, because the eye is reading
    //             a RATIO while the drawing code works in levels.
    // =============================================================================================

    M.IDS = ['gold', 'electrum', 'silver', 'billon', 'copper', 'bronze', 'brass', 'iron'];

    M.TABLE = {
        gold: {
            name: 'Gold',
            body: [201, 164, 74],
            lustre: 0.92,
            patina: null,                 // ⭐ the whole reason gold reads as gold
            patinaRate: 0.0,
            reliefMin: 26,
            note: 'Does not corrode. Wear on gold is SOFTENING of the relief, never discolouration '
                + '- which is why an ancient gold piece still looks like gold and an ancient copper '
                + 'one does not.'
        },
        electrum: {
            name: 'Electrum',
            body: [214, 195, 130],
            lustre: 0.80,
            patina: [150, 140, 110],
            // ⛔ WAS 0.10, AND THAT MADE THIS A DEAD AXIS. MEASURED 2026-09-04: at 0.10 the recess
            // moved 5.7 over the full wear range while GOLD - which declares no patina at all -
            // moved 10.4 from relief-softening alone. A field whose effect is smaller than the
            // effect of the field it is supposed to be distinguishable from is not a field
            // (wing §22a-2e). Raised until the contribution is visible, and it stays the SLOWEST
            // of the corroding metals, which is what the material actually does.
            patinaRate: 0.30,
            reliefMin: 24,
            note: 'Natural gold-silver alloy, and the earliest coinage metal there is. Pale, and it '
                + 'tones slowly toward a dull grey-brown as its silver fraction tarnishes - the '
                + 'slowest of the corroding metals here, but not zero, which is what separates it '
                + 'from gold at high wear.'
        },
        silver: {
            name: 'Silver',
            body: [198, 201, 206],
            lustre: 0.88,
            patina: [46, 44, 58],         // tarnish is blue-BLACK, not grey
            patinaRate: 0.62,
            reliefMin: 30,
            note: 'Tarnishes blue-black in the recesses. The contrast between a bright relief and a '
                + 'black recess is what makes worn silver read as OLD rather than as dirty.'
        },
        billon: {
            name: 'Billon',
            body: [156, 152, 143],
            lustre: 0.38,
            patina: [72, 68, 62],
            patinaRate: 0.70,
            reliefMin: 32,
            note: 'Debased silver - more copper than silver. Dull from new. A realm that strikes '
                + 'billon is a realm in trouble, and that is a story the picture can tell.'
        },
        copper: {
            name: 'Copper',
            body: [166, 96, 58],
            lustre: 0.52,
            patina: [64, 122, 106],       // verdigris
            patinaRate: 0.88,
            reliefMin: 34,
            note: 'Greens hard and fast. The most visually dramatic wear axis in the corpus.'
        },
        bronze: {
            name: 'Bronze',
            body: [140, 98, 52],
            lustre: 0.46,
            patina: [70, 96, 74],
            patinaRate: 0.66,
            reliefMin: 34,
            note: 'Browner than copper and greens more slowly toward olive.'
        },
        brass: {
            name: 'Brass',
            body: [183, 148, 66],
            lustre: 0.64,
            patina: [104, 92, 48],
            patinaRate: 0.34,
            reliefMin: 28,
            note: 'Reads as cheap gold, which is exactly what it was usually meant to do. Dulls to '
                + 'a flat mustard rather than greening.'
        },
        iron: {
            name: 'Iron',
            body: [112, 112, 118],
            lustre: 0.30,
            patina: [122, 66, 34],        // rust is ORANGE, and it is the only warm patina here
            patinaRate: 0.95,
            reliefMin: 34,
            note: 'Rusts orange. The only patina in the corpus that gets WARMER and LIGHTER with '
                + 'age instead of darker, so a rusted piece cannot be confused with a tarnished one.'
        }
    };

    /**
     * @param {string} id metal id.
     * @returns {object} the metal record. Throws on an unknown id.
     */
    M.get = function (id) {
        var m = M.TABLE[id];
        if (!m) throw new Error('SpecieMetals: unknown metal "' + id + '"');
        return m;
    };

    /**
     * The colour of a surface at a given wear, for a given relief direction.
     *
     * This is THE reader for `patina` and `patinaRate`, and it is the function the suite points at
     * to prove those two fields are not §22a-2e dead axes.
     *
     * ⛔ PATINA GOES IN THE RECESSES ONLY. That is not a stylistic choice: corrosion sits where the
     * metal is not handled, and a coin's high points are polished by every purse it has been in.
     * Tinting the whole coin makes it read as a coin PAINTED green rather than an old copper coin.
     *
     * @param {object} metal a record from TABLE.
     * @param {number} wear 0 (mint) .. 1 (worn smooth).
     * @param {number} dir +1 raised/lit, -1 recessed/shadowed, 0 flat field.
     * @returns {number[]} RGB triple.
     */
    M.surface = function (metal, wear, dir) {
        var w = Math.max(0, Math.min(1, wear));
        var base = metal.body;

        // Recesses take the patina; raised metal keeps its colour.
        var c = base;
        if (metal.patina && dir < 0) {
            var t = Math.min(1, w * metal.patinaRate);
            c = [
                Math.round(base[0] + (metal.patina[0] - base[0]) * t),
                Math.round(base[1] + (metal.patina[1] - base[1]) * t),
                Math.round(base[2] + (metal.patina[2] - base[2]) * t)
            ];
        }

        if (dir === 0) return c;

        // Wear SOFTENS relief: an old coin's device is shallower, so the separation falls off.
        // This is the only wear effect gold gets, and it has to be enough to read on its own.
        var soften = 1 - 0.55 * w;
        return M.relief(c, dir, metal.reliefMin * soften);
    };

    /**
     * Total authored entities on this axis. Reported as a COUNT OF AUTHORED THINGS, never as a
     * multiplication (master §1.1 q3, wing §21i: `volume()` reports what the corpus COULD make,
     * while a buyer sees what their database RESOLVES to).
     * @returns {number}
     */
    M.volume = function () { return M.IDS.length; };

})(SpecieMetals);
