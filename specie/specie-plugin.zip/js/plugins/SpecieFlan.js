/*:
 * @target MZ
 * @plugindesc [Specie] Flan corpus — 6 authored blank forms and their edge treatments. Library file; no parameters.
 * @author Core Systems Asset Factory
 *
 * @help
 * SpecieFlan.js
 *
 * The blank a coin is struck on. Six forms, each with its own outline and its own
 * edge treatment, authored as pure geometry.
 *
 * A flan is not decoration. Before any device is struck, the SHAPE of the piece
 * already says which realm and which era made it: a scyphate (dished) coin is
 * Byzantine, a holed cash coin is eastern, a squared planchet is early or
 * emergency coinage, and a milled edge is late and industrial. It is the cheapest
 * variety in the whole product because it changes the silhouette rather than the
 * contents, and a purse of five denominations reads as a purse rather than as one
 * coin five times.
 *
 * It has NO dependency on RPG Maker MZ and makes no engine calls.
 *
 * Load order does not matter. Nothing here resolves a sibling file.
 */

var SpecieFlan = SpecieFlan || {};

(function (F) {
    'use strict';

    // =============================================================================================
    // COORDINATES
    //
    // Same convention as SpecieDevices: origin at the centre of the flan, 1.0 unit == the flan's
    // DIAMETER, so the edge of a plain round blank sits at radius 0.5. That is written once, here
    // and in SpecieRender.transform, and nowhere else (wing §11a: a second copy of a constant does
    // not drift, it WINS - and the edit that provably reaches disk provably does not reach the
    // picture).
    // =============================================================================================

    F.R = 0.5;                    // the radius of a plain blank, in flan units

    // ⛔ THE EDGE TREATMENT DECLARES A PITCH, NEVER A COUNT.
    //
    // Wing §22b-1a, measured on Escutcheon: a bezel corpus declared `marks: 18` for beading, and on
    // a ~700px perimeter that landed EIGHTEEN SPECKS 39 PX APART - all seven treatments rendered as
    // the same yellow rectangle, which was verbatim the thing that product was forbidden to ship.
    // A count cannot express a worked band, because the right count changes with the size of the
    // piece: milling reads as milling only when the ridges nearly touch, and "nearly touch" is a
    // statement about PITCH RELATIVE TO MARK SIZE.
    //
    // ⛔ And the pitch itself is `ink + PAPER_MIN` in ABSOLUTE PIXELS, never a ratio. Wing §22a-2d
    // measured that law on Shipwright's rigging across 4 ink widths x 21 pitches: the first usable
    // RATIO moves by 1.8x across the range (3.6 at 1px ink, 2.0 at 3px), while subtracting the ink
    // collapses all four rows - every failing case left <= 2.4px of paper and every passing case
    // >= 2.49px. A ratio tuned at a comfortable size is always too tight at the thumbnail.
    F.GAP_MIN_PX = 2.6;           // the measured gap that separates two marks
    F.MARK_MIN_PX = 1.1;          // below this a rim mark is a smear, not a mark

    /**
     * How many edge marks actually RESOLVE on a given perimeter, and at what pitch.
     *
     * ⛔ This is the function that stops §22b-1a happening here. It is the only place a count is
     * produced, and it is DERIVED from the real perimeter every time rather than typed.
     *
     * @param {number} perimeterPx the real perimeter in pixels at the rendered size.
     * @param {number} markPx the width of one mark in pixels.
     * @param {number} wantPitchPx the treatment's preferred pitch in pixels.
     * @returns {{count:number, pitch:number, floored:boolean, resolves:boolean}}
     */
    F.fitMarks = function (perimeterPx, markPx, wantPitchPx) {
        var floorPitch = markPx + F.GAP_MIN_PX;
        var pitch = Math.max(wantPitchPx, floorPitch);
        var floored = pitch > wantPitchPx + 1e-9;
        var resolves = markPx >= F.MARK_MIN_PX && perimeterPx >= pitch * 6;
        var count = resolves ? Math.max(6, Math.floor(perimeterPx / pitch)) : 0;
        // re-derive the pitch from the count that will actually be drawn, so the marks close the
        // ring exactly instead of leaving a gap where the division did not come out even
        var exact = count > 0 ? perimeterPx / count : 0;
        return { count: count, pitch: exact, floored: floored, resolves: resolves };
    };

    // =============================================================================================
    // THE CORPUS — 6 forms
    //
    // `outline(T, ctx)`  lays this form's path. Round forms do not define one; the renderer's
    //                    default circle is correct for them and a second copy would be §11a.
    // `edge`             'plain' | 'milled' | 'beaded' | 'cabled' | 'clipped' | 'none'
    // `markPx`/`pitchPx` the edge treatment's own scale, in PIXELS at a 260px inspect plate, scaled
    //                    with the piece. Absolute, per §22a-2d.
    // `hole`             a central piercing, as a fraction of the diameter, or 0.
    // `dish`             0 = flat, >0 = scyphate. Drives the FIELD's shading, not its outline.
    // =============================================================================================

    F.IDS = ['round', 'milled', 'scyphate', 'pierced', 'squared', 'clipped'];

    F.TABLE = {
        round: {
            name: 'Round',
            edge: 'beaded',
            markPx: 3.4,
            pitchPx: 7.2,
            hole: 0,
            dish: 0,
            note: 'The plain struck blank with a beaded rim. The baseline every other form is read '
                + 'against, and the one a buyer who declares nothing gets.'
        },
        milled: {
            name: 'Milled',
            edge: 'milled',
            markPx: 2.2,
            pitchPx: 4.9,
            hole: 0,
            dish: 0,
            note: 'Fine reeding cut across the edge. Milling exists to prove a coin has not been '
                + 'clipped, so it belongs to a late, confident, industrial coinage - and it reads '
                + 'as one. It is the finest treatment here, which makes it the one that hits the '
                + 'resolution floor first: fitMarks drops it to a plain edge rather than drawing a '
                + 'grey smear (§17c-1).'
        },
        scyphate: {
            name: 'Scyphate',
            edge: 'plain',
            markPx: 0,
            pitchPx: 0,
            hole: 0,
            dish: 0.55,
            note: 'A dished, cup-shaped flan. The outline is still a circle - what changes is that '
                + 'the FIELD curves away from the light, so the piece reads as concave. That is a '
                + 'shading fact, not a silhouette fact, which is exactly why it is declared here '
                + 'and drawn by the renderer rather than being an outline of its own.'
        },
        pierced: {
            name: 'Pierced',
            edge: 'plain',
            markPx: 0,
            pitchPx: 0,
            hole: 0.26,
            dish: 0,
            // ⛔ A COIN WITH A HOLE IN THE MIDDLE CANNOT CARRY A PORTRAIT IN THE MIDDLE, and the
            // first render proved it by punching the piercing straight through a sovereign's face.
            // Real pierced coinage does not try: a cash coin has NO central device, and its whole
            // identity is the legend set around the hole. This is the one flan that changes what a
            // coin is made of rather than only what shape it is.
            centreDevice: false,
            note: 'A central piercing, so the coins can be strung. It is the single most legible '
                + 'flan in the corpus at PURSE SIZE, because a hole survives when nothing else '
                + 'does - which is the answer to the measured finding that 21 of 36 devices cannot '
                + 'be drawn in full at 32px (§17c-1).'
        },
        squared: {
            name: 'Squared',
            outline: function (ctx, T) {
                // a squared planchet is HAND CUT, so the corners are unequal and none is square.
                // A true square reads as a UI element; an irregular one reads as struck metal.
                var d = T.d, cx = T.cx, cy = T.cy;
                var p = [
                    [-0.455, -0.430], [0.440, -0.462], [0.470, 0.425],
                    [-0.425, 0.455], [-0.470, 0.020]
                ];
                ctx.moveTo(cx + p[0][0] * d, cy + p[0][1] * d);
                for (var i = 1; i < p.length; i++) ctx.lineTo(cx + p[i][0] * d, cy + p[i][1] * d);
            },
            edge: 'none',
            markPx: 0,
            pitchPx: 0,
            hole: 0,
            dish: 0,
            note: 'A squared, hand-cut planchet - early coinage, or emergency money struck in a '
                + 'siege. No edge treatment is possible on a blank nobody rounded.'
        },
        clipped: {
            name: 'Clipped',
            outline: function (ctx, T) {
                // ⛔ THE CLIPS ARE CUT OFF THE CIRCLE, NOT DRAWN ONTO IT. A clipped coin is a round
                // coin somebody shaved silver from, so its outline is arcs of the ORIGINAL circle
                // interrupted by straight chords - and the chords must be of DIFFERENT depths,
                // because a thief clips where the metal is, not evenly (§22a: anything regular
                // pairs, and a regular polygon reads as a deliberate shape rather than as damage).
                // ⚠️ THE FIRST VERSION WAS INVISIBLE, AND THE CAUSE IS THAT A CLIP'S DEPTH IS NOT A
                // FREE PARAMETER. It declared a `depth` per clip (0.86-0.94 of the radius) and
                // `lineTo`'d a point at that depth - which is a radial nick of ZERO angular width,
                // so the flan rendered as a plain circle and the whole form was a §22a-2e dead axis
                // while every count stayed correct.
                //
                // ⭐ A clip is a CHORD. Somebody laid a blade across the coin and cut, so the shape
                // is a straight line between two points ON the original circle, and its depth is
                // therefore DERIVED from the angular width - `r * (1 - cos(halfAngle))`, not typed.
                // Wider clip, deeper bite, by construction (wing §22b-1a's law about counts, in
                // another unit: the number you are tempted to type is the one the geometry owes you).
                var d = T.d, cx = T.cx, cy = T.cy, r = 0.5 * d;
                // Three clips of DIFFERENT angular width, because a thief clips where the metal is,
                // not evenly - anything regular pairs, and a regular polygon reads as a deliberate
                // shape rather than as damage (§22a).
                var clips = [
                    { a0: 0.30, a1: 1.25 },
                    { a0: 2.15, a1: 2.72 },
                    { a0: 3.95, a1: 5.20 }
                ];
                var last = clips[clips.length - 1];
                ctx.moveTo(cx + Math.cos(last.a1) * r, cy + Math.sin(last.a1) * r);
                for (var i = 0; i < clips.length; i++) {
                    var c = clips[i];
                    var from = (i === 0) ? last.a1 : clips[i - 1].a1;
                    ctx.arc(cx, cy, r, from, c.a0 + (i === 0 ? Math.PI * 2 : 0), false);
                    ctx.lineTo(cx + Math.cos(c.a1) * r, cy + Math.sin(c.a1) * r);   // the CHORD
                }
            },
            edge: 'none',
            markPx: 0,
            pitchPx: 0,
            hole: 0,
            dish: 0,
            note: 'Silver shaved off the edge by somebody who wanted it. A clipped coin is a STORY '
                + 'about the economy it circulates in, and it is the one flan that says the realm '
                + 'is in trouble without any device having to say it.'
        }
    };

    /**
     * @param {string} id flan id.
     * @returns {object} the flan record. Throws on an unknown id.
     */
    F.get = function (id) {
        var f = F.TABLE[id];
        if (!f) throw new Error('SpecieFlan: unknown flan "' + id + '"');
        return f;
    };

    /**
     * Total authored entities on this axis. Reported as a COUNT OF AUTHORED THINGS, never as a
     * multiplication (master §1.1 q3, wing §21i).
     * @returns {number}
     */
    F.volume = function () { return F.IDS.length; };

})(SpecieFlan);
