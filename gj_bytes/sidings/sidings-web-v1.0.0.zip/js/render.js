/**
 * render.js — SIDINGS' screen. 960x600, canvas only, no DOM UI.
 *
 * ── THE SCREEN, AND WHY IT IS IN TWO HALVES ─────────────────────────────────────────────────
 * TOP: the valley in elevation. The actual railway, climbing left to right, with the trains on
 * it. This is the beautiful half and it is also the honest half — before the player buys Track
 * Circuits they CANNOT see a train inside a section, so the fells between stations are drawn
 * fogged and the train is simply not there. Buying the rails' own reporting is the moment the
 * mountain becomes legible, and it has to be a visible moment.
 *
 * BOTTOM: the signal box. Five station frames with the roads and what stands on them, four block
 * instruments between them with the staff and the snow, and one status line that always says why
 * the last thing you tried was refused.
 *
 * ⛔ LAYOUT IS COMPUTED ONCE PER FRAME AND HIT-TESTED FROM THE SAME NUMBERS. A hit region derived
 *    separately from the drawing is a bug waiting for a resize (wing §3d: test at the size the
 *    player actually gets).
 * ⛔ `setPaused` returns BEFORE draw(), never after (§3c-13: `if (paused) { draw(); return; }`
 *    kept painting and a store plate photographed the ending screen while the pixel check passed).
 */
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else root.RENDER = factory();
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const W = 960, H = 600;
  const HEAD_H = 40;
  const VALLEY_Y = HEAD_H, VALLEY_H = 258;
  const PANEL_Y = VALLEY_Y + VALLEY_H;           // 298
  const PANEL_H = H - PANEL_Y;                   // 302
  const BAR_H = 30;
  const STATUS_H = 34;

  function make(ART, LINE, SIM) {
    const P = ART.P;

    // Deterministic hash for snow/steam so a captured frame reproduces (§4.2a).
    function hash(i) {
      let x = (i * 374761393 + 668265263) | 0;
      x = (x ^ (x >>> 13)) * 1274126177;
      return Math.abs(x | 0);
    }

    // ── geometry ──────────────────────────────────────────────────────────────────────────
    // Stations are placed by their real km so the gradients read as distance, not as slots.
    const totalKm = LINE.STATIONS[LINE.STATIONS.length - 1].km;
    const MARGIN = 62;
    function stationX(id) {
      return MARGIN + (LINE.STATIONS[id].km / totalKm) * (W - MARGIN * 2);
    }
    // The line climbs: High Fell sits higher up the canvas than Lowgarth.
    function stationY(id) {
      const t = LINE.STATIONS[id].km / totalKm;
      return VALLEY_Y + VALLEY_H - 42 - t * 92;
    }
    function alongSection(secId, frac) {
      const a = LINE.SECTIONS[secId].from, b = LINE.SECTIONS[secId].to;
      return { x: stationX(a) + (stationX(b) - stationX(a)) * frac, y: stationY(a) + (stationY(b) - stationY(a)) * frac };
    }

    // ── the valley ────────────────────────────────────────────────────────────────────────
    /**
     * `opts.backdrop` draws the scenery with NO TYPOGRAPHY IN IT.
     *
     * ⛔ TEXT UNDER A SCRIM IS AN OVERPRINT (wing §3c-6). The title, the day-end sheet, the win
     *    and the yard all lay their own prose over a dimmed valley — and the valley draws five
     *    railway nameboards. "HAL" was printed through the middle of the title screen's opening
     *    sentence and "WIN" sat jammed against the subtitle, on a page every image check called
     *    clean. A scrim reduces contrast; it does not remove a string. So a valley drawn AS A
     *    BACKDROP now draws no lettering at all, and `test_layout.js` is what noticed.
     */
    function drawValley(ctx, s, d, t, opts) {
      const backdrop = !!(opts && opts.backdrop);
      // sky
      const g = ctx.createLinearGradient(0, VALLEY_Y, 0, VALLEY_Y + VALLEY_H);
      g.addColorStop(0, '#16202e');
      g.addColorStop(0.55, '#243349');
      g.addColorStop(1, '#3a4a60');
      ctx.fillStyle = g; ctx.fillRect(0, VALLEY_Y, W, VALLEY_H);

      // far fell silhouette, then the near one, both plated
      farFell(ctx, VALLEY_Y + 60, 34, 2.3, 0.14);
      farFell(ctx, VALLEY_Y + 92, 46, 7.0, 0.32);

      // The ground the line sits on: a snow-covered shoulder following the track profile.
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(0, VALLEY_Y + VALLEY_H);
      ctx.lineTo(0, stationY(0) + 12);
      for (let i = 0; i < LINE.STATIONS.length; i++) ctx.lineTo(stationX(i), stationY(i) + 12);
      ctx.lineTo(W, stationY(LINE.STATIONS.length - 1) + 12);
      ctx.lineTo(W, VALLEY_Y + VALLEY_H);
      ctx.closePath();
      ctx.clip();
      ctx.fillStyle = ART.plateFill(ctx, 'snow', P.snow);
      ctx.fillRect(0, VALLEY_Y, W, VALLEY_H);
      // ⛔ A LIGHT HAND. The first pass tinted the snow shoulder at 0.34 and the fells at 0.30 and
      //    0.55, and the captured frame showed a grey stone valley - the snow plate itself is pale
      //    blue-white and good (its 3x3 sheet was opened and looked at). The art was never the
      //    problem; the overlay was eating it.
      ctx.fillStyle = 'rgba(30,44,62,0.14)';
      ctx.fillRect(0, VALLEY_Y, W, VALLEY_H);
      // a crag outcrop or two, so the shoulder is not a flat band
      for (let k = 0; k < 5; k++) {
        const cx = 90 + k * 190 + (hash(k * 3) % 40);
        const cy = VALLEY_Y + VALLEY_H - 26 - (hash(k * 5) % 18);
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(cx - 34, VALLEY_Y + VALLEY_H);
        ctx.lineTo(cx - 12, cy);
        ctx.lineTo(cx + 10, cy + 6);
        ctx.lineTo(cx + 30, VALLEY_Y + VALLEY_H);
        ctx.closePath(); ctx.clip();
        ctx.fillStyle = ART.plateFill(ctx, 'crag', P.slate);
        ctx.fillRect(cx - 40, cy - 10, 80, 60);
        ctx.fillStyle = 'rgba(10,13,18,0.30)';
        ctx.fillRect(cx - 40, cy - 10, 80, 60);
        ctx.restore();
      }
      ctx.restore();

      // the permanent way
      for (const sec of LINE.SECTIONS) {
        const a = stationX(sec.from), b = stationX(sec.to);
        const ya = stationY(sec.from), yb = stationY(sec.to);
        ctx.save();
        ctx.translate(a, ya);
        ctx.rotate(Math.atan2(yb - ya, b - a));
        const len = Math.hypot(b - a, yb - ya);
        ART.track(ctx, 0, len, 0, { snow: s.snow[sec.id] });
        // a closed section is barred
        if (s.snow[sec.id] >= SIM.SNOW_CLOSED_AT) {
          ctx.fillStyle = 'rgba(232,241,248,0.80)';
          ctx.fillRect(0, -7, len, 14);
          ctx.fillStyle = 'rgba(143,166,189,0.75)';
          for (let x = 0; x < len; x += 9) ctx.fillRect(x, -7, 4, 14);
        }
        ctx.restore();
      }

      // stations
      for (const st of LINE.STATIONS) {
        const x = stationX(st.id), y = stationY(st.id);
        drawStationBuilding(ctx, x, y, st, s, backdrop);
      }

      // trains
      const sees = LINE.SIGNAL_TIERS[s.signalTier].sees;
      if (d) {
        for (const tr of d.trains) {
          if (tr.state === 'running') {
            if (!sees) continue;              // no track circuits: the fell keeps its secret
            const frac = Math.min(1, tr.progress);
            const f = tr.dir === LINE.UP ? frac : 1 - frac;
            const p = alongSection(tr.section, f);
            ART.train(ctx, p.x, p.y - 4, tr.dir, tr.cars, LINE.classOf(tr.cls).colour, { steam: true });
          } else if (tr.state === 'standing') {
            const x = stationX(tr.at), y = stationY(tr.at);
            const oy = tr.road === 'loop' ? 11 : 0;
            ART.train(ctx, x - 6, y - 4 + oy, tr.dir, tr.cars, LINE.classOf(tr.cls).colour, { steam: false });
          }
        }
        // A section that is occupied but unseen gets a fog band, so "I cannot see" is DRAWN
        // rather than merely absent — an absence the player cannot distinguish from an empty
        // line would be a lie told by omission.
        if (!sees) {
          for (const sec of LINE.SECTIONS) {
            if (!d.sectionOcc[sec.id].length) continue;
            const a = alongSection(sec.id, 0.12), b = alongSection(sec.id, 0.88);
            ctx.save();
            ctx.strokeStyle = 'rgba(207,90,78,0.35)';
            ctx.lineWidth = 16; ctx.lineCap = 'round';
            ctx.beginPath(); ctx.moveTo(a.x, a.y - 3); ctx.lineTo(b.x, b.y - 3); ctx.stroke();
            ctx.restore();
            if (backdrop) continue;
            const mid = alongSection(sec.id, 0.5);
            ART.text(ctx, 'OCCUPIED', mid.x, mid.y - 12, { align: 'center', size: 9, weight: 600, fill: P.crimsonLit });
          }
        }
      }

      ART.snowfall(ctx, 0, VALLEY_Y, W, VALLEY_H, t, 0.35 + Math.max(...s.snow) * 0.9, hash);

      // vignette so the panel below reads as the foreground
      const vg = ctx.createLinearGradient(0, VALLEY_Y + VALLEY_H - 46, 0, VALLEY_Y + VALLEY_H);
      vg.addColorStop(0, 'rgba(10,13,18,0)');
      vg.addColorStop(1, 'rgba(10,13,18,0.72)');
      ctx.fillStyle = vg; ctx.fillRect(0, VALLEY_Y + VALLEY_H - 46, W, 46);
    }

    function farFell(ctx, baseY, amp, step, dark) {
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(0, VALLEY_Y + VALLEY_H);
      ctx.lineTo(0, baseY);
      for (let x = 0; x <= W; x += 24) {
        const h = Math.sin(x * 0.0071 + step) * amp + Math.sin(x * 0.019 + step * 2) * (amp * 0.38);
        ctx.lineTo(x, baseY - h);
      }
      ctx.lineTo(W, VALLEY_Y + VALLEY_H);
      ctx.closePath(); ctx.clip();
      ctx.fillStyle = ART.plateFill(ctx, 'snow', P.snowDeep);
      ctx.fillRect(0, VALLEY_Y, W, VALLEY_H);
      ctx.fillStyle = 'rgba(18,23,31,' + dark + ')';
      ctx.fillRect(0, VALLEY_Y, W, VALLEY_H);
      ctx.restore();
    }

    function drawStationBuilding(ctx, x, y, st, s, backdrop) {
      const w = st.terminus ? 40 : 28;
      const h = st.terminus ? 24 : 18;
      const bx = x - w / 2, by = y - 10 - h;
      ctx.save();
      ctx.beginPath(); ctx.rect(bx, by, w, h); ctx.clip();
      ctx.fillStyle = ART.plateFill(ctx, 'crag', P.slate);
      ctx.fillRect(bx, by, w, h);
      ctx.fillStyle = 'rgba(30,38,50,0.42)'; ctx.fillRect(bx, by, w, h);
      ctx.restore();
      // roof
      ctx.save();
      ctx.beginPath(); ctx.rect(bx - 3, by - 5, w + 6, 6); ctx.clip();
      ctx.fillStyle = ART.plateFill(ctx, 'slate', P.slateLit);
      ctx.fillRect(bx - 3, by - 5, w + 6, 6);
      ctx.restore();
      ctx.fillStyle = 'rgba(232,241,248,0.66)';
      ctx.fillRect(bx - 3, by - 6, w + 6, 2);
      // lit windows
      ctx.fillStyle = '#e6c274';
      const wins = st.terminus ? 3 : 2;
      for (let i = 0; i < wins; i++) ctx.fillRect(bx + 5 + i * (w - 10) / wins, by + 6, 4, 5);
      // a loop drawn as a second road beside the main
      if (!st.terminus && s.loops[st.id] > 0) {
        const holds = LINE.LOOP_TIERS[s.loops[st.id]].holds;
        const half = Math.min(74, 16 + holds * 5);
        ART.track(ctx, x - half, x + half, y + 11, { snow: 0 });
      }
      // ⛔ A NAMEBOARD, NOT BARE TEXT. Pale letters sat directly on a snowfield were effectively
      //    invisible in the captured frame — the 1px drop shadow that carries text over the
      //    signal box's dark timber does nothing at all against white. A railway nameboard is
      //    both the legible answer and the authentic one (§0-ART-E: pick ink by luminance
      //    against WHAT IT SITS ON, not against the palette in the abstract).
      if (backdrop) return;                 // a backdrop carries no lettering (§3c-6)
      ctx.font = '600 10px ' + ART.FONT;
      const tw = ctx.measureText(st.short).width;
      const bw = tw + 12, bh = 14, bx2 = x - bw / 2, by2 = y + 20;
      ctx.fillStyle = 'rgba(10,13,18,0.86)';
      ctx.fillRect(bx2, by2, bw, bh);
      ctx.strokeStyle = 'rgba(224,187,96,0.55)';
      ctx.lineWidth = 1;
      ctx.strokeRect(bx2 + 0.5, by2 + 0.5, bw - 1, bh - 1);
      ART.text(ctx, st.short, x, by2 + 10, { align: 'center', size: 10, weight: 600, fill: P.snowLit, shadow: false });
    }

    // ── the signal box ────────────────────────────────────────────────────────────────────
    /**
     * Returns the hit regions as it draws them. `regions` entries are
     * { kind:'train'|'shunt'|'button', id, x, y, w, h }.
     */
    function drawPanel(ctx, s, d, ui) {
      const regions = [];
      ART.plated(ctx, 0, PANEL_Y, W, PANEL_H, 'timber', P.timber, 'rgba(10,13,18,0.30)', 1);
      ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(0, PANEL_Y, W, 2);
      ctx.fillStyle = 'rgba(224,187,96,0.22)'; ctx.fillRect(0, PANEL_Y + 2, W, 1);

      // ── the brass bar ──
      const barY = PANEL_Y + 6;
      ART.panel(ctx, 8, barY, W - 16, BAR_H, 'slate', P.slate, { tint: 'rgba(10,13,18,0.45)', alpha: 1 });
      ART.text(ctx, LINE.SIGNAL_TIERS[s.signalTier].name.toUpperCase(), 18, barY + 20,
        { size: 13, weight: 600, fill: P.brassLit });

      const speeds = [1, 2, 4];
      let bx = W - 24;
      for (let i = speeds.length - 1; i >= 0; i--) {
        const w = 34;
        bx -= w + 6;
        const r = ART.button(ctx, bx, barY + 4, w, BAR_H - 8, speeds[i] + 'x',
          { hot: ui.speed === speeds[i], size: 12 });
        regions.push({ kind: 'button', id: 'speed:' + speeds[i], x: r.x, y: r.y, w: r.w, h: r.h });
      }
      bx -= 84;
      const pr = ART.button(ctx, bx, barY + 4, 78, BAR_H - 8, ui.paused ? 'RESUME' : 'PAUSE', { size: 12 });
      regions.push({ kind: 'button', id: 'pause', x: pr.x, y: pr.y, w: pr.w, h: pr.h });

      // ── station frames ──
      const top = barY + BAR_H + 10;
      const bodyH = PANEL_Y + PANEL_H - STATUS_H - top - 8;
      const n = LINE.STATIONS.length;
      const colW = 128, gapW = (W - 16 - n * colW) / (n - 1);

      for (let i = 0; i < n; i++) {
        const st = LINE.STATIONS[i];
        const x = 8 + i * (colW + gapW);
        drawStationFrame(ctx, x, top, colW, bodyH, st, s, d, ui, regions);
        if (i < n - 1) drawSectionFrame(ctx, x + colW, top, gapW, bodyH, LINE.SECTIONS[i], s, d, ui);
      }

      // ── status line ──
      const sy = PANEL_Y + PANEL_H - STATUS_H;
      ART.panel(ctx, 8, sy, W - 16, STATUS_H - 6, 'slate', P.night, { tint: 'rgba(10,13,18,0.62)', alpha: 1 });
      const msg = ui.status || standingHint(s, d);
      ART.text(ctx, msg, 18, sy + 18, { size: 12, fill: ui.statusBad ? P.crimsonLit : P.snow });
      // the bell, rung by the last offer
      ART.bell(ctx, W - 30, sy + 13, 15, ui.bellSwing || 0);
      return regions;
    }

    function drawStationFrame(ctx, x, y, w, h, st, s, d, ui, regions) {
      ART.panel(ctx, x, y, w, h, 'slate', P.slate, { tint: 'rgba(12,17,24,0.55)', alpha: 1 });
      ART.text(ctx, st.name, x + w / 2, y + 16, { align: 'center', size: 11, weight: 600, fill: P.brassLit });

      const roads = st.terminus ? ['yard'] : ['main', 'loop'];
      let ry = y + 26;
      for (const road of roads) {
        // ⛔ A TERMINUS'S SINGLE ROAD USED TO BE `h - 36` AND SWALLOWED THE WHOLE PANEL, so the
        //    two end stations were a heading, a dash and 140px of nothing — the emptiest thing on
        //    the screen. A fixed road box leaves room for the same working board every other
        //    station gets.
        const rh = st.terminus ? 84 : 42;
        ctx.fillStyle = 'rgba(0,0,0,0.30)';
        ctx.fillRect(x + 6, ry, w - 12, rh);
        let label = road.toUpperCase();
        if (road === 'loop') {
          const tier = LINE.LOOP_TIERS[s.loops[st.id]];
          label = tier.holds === 0 ? 'NO LOOP' : 'LOOP (' + tier.holds + ')';
        }
        ART.text(ctx, label, x + 10, ry + 11, {
          size: 9, weight: 600,
          fill: road === 'loop' && LINE.LOOP_TIERS[s.loops[st.id]].holds === 0 ? '#6a6a68' : P.snowDeep,
        });

        const here = d ? d.trains.filter((t) => t.state === 'standing' && t.at === st.id && t.road === road) : [];
        here.forEach((t, k) => {
          const ty = ry + 24 + k * 20;
          if (ty > ry + rh - 4) return;
          const cls = LINE.classOf(t.cls);
          const hot = ui.hover === 'train:' + t.id;
          // ⛔ THE ROW HAS THREE THINGS IN 112 PIXELS AND THEY USED TO OVERLAP. A 6-car train
          //    sprite is ~74px wide, the shunt tab takes the right 20px, and the label was drawn
          //    RIGHT-ALIGNED into that tab — the first captured gallery plate reads "↑Pick-" and
          //    "↓T" because the class name ran under the button and off the row. Canvas text does
          //    not clip, so nothing but the picture shows it (§3e-3: the layout gate was blind to
          //    a string sitting in a button). Three cars in the icon, a 3-4 character class code,
          //    and the label stops short of the tab.
          ctx.fillStyle = hot ? 'rgba(224,187,96,0.20)' : 'rgba(255,255,255,0.05)';
          ctx.fillRect(x + 8, ty - 12, w - 16, 18);
          ART.train(ctx, x + 12, ty, t.dir, Math.min(t.cars, 3), cls.colour, { steam: false });
          ART.text(ctx, (t.dir === LINE.UP ? '↑' : '↓') + cls.short + ' ' + t.id,
            x + w - 26, ty + 2, { align: 'right', size: 9, weight: 600, fill: hot ? P.snowLit : P.snow });
          regions.push({ kind: 'train', id: t.id, x: x + 8, y: ty - 12, w: w - 16, h: 18 });
        });
        if (!here.length) {
          // ⛔ A road that DOES NOT EXIST is not "clear". The first build printed "NO LOOP" and
          //    "clear" one above the other in the same box, which reads as a usable empty loop —
          //    the exact opposite of the fact the player has to plan around.
          const noLoop = road === 'loop' && LINE.LOOP_TIERS[s.loops[st.id]].holds === 0;
          ART.text(ctx, st.terminus || noLoop ? '—' : 'clear', x + w / 2, ry + rh / 2 + 6,
            { align: 'center', size: 10, fill: '#5c6470' });
        }
        ry += rh + 6;
      }

      /* ── STILL TO PASS ────────────────────────────────────────────────────────────────────
       * ⛔ THE SIGNAL BOX IS HALF THE SCREEN AND ITS LOWER HALF WAS EMPTY. An independent
       *    reviewer measured the whole frame at 14.9% ink and a station panel's lower half at
       *    1.19% — a station panel drew two road boxes and then ~85px of nothing, on the screen
       *    the player spends the entire game looking at. Empty space in the middle of a working
       *    instrument is not restraint, it is an unanswered question, and the question this game
       *    is actually about is "what is coming, and will it fit in my loop?"
       * ⛔ IT IS DIFFERENT PER STATION BY CONSTRUCTION — the fit verdict is computed against THIS
       *    station's own loop length, so a four-carriage loop and a refuge siding do not show the
       *    same board. That is the loop-length mechanic, taught where the decision is made.
       */
      const bottom = y + h - 8;
      if (d && bottom - ry > 30) {
        const holds = st.terminus ? 99 : LINE.LOOP_TIERS[s.loops[st.id]].holds;
        ART.text(ctx, 'STILL TO PASS', x + 10, ry + 10, { size: 8, weight: 700, fill: P.brassDim });
        /* ⛔⛔ AND THIS BOARD REINTRODUCED THE DEFECT ITS OWN AUTHOR HAD JUST WRITTEN A RULE
         * ABOUT. A fixed four-or-five-row grid over a list that is 11 trains on a middling day
         * and 19 at the peak silently dropped the rest: 11 booked and 19 booked drew IDENTICAL
         * boards with no indication that anything was missing — the same silent truncation as
         * `catalogue.slice(0, 8)`, in the code written to fix the screen that one was found on.
         * Caught by the same independent reviewer, on the shipped GIF. The rule is not "count
         * more carefully", it is: ⛔ A LIST THAT DOES NOT FIT MUST SAY SO. */
        const all = d.trains
          .filter((t) => t.state !== 'arrived' && t.state !== 'cancelled'
            && !(t.state === 'standing' && t.at === st.id))
          .sort((a, b) => a.due - b.due);
        // ⛔ AND THE DISCLOSURE ITSELF WAS OFF BY ONE, TEN OBSERVATIONS OUT OF TEN. `hidden` was
        //    `total - roomFor` while the last slot is spent on the overflow LINE, so only
        //    `roomFor - 1` trains are actually shown: a board displaying 3 of 11 announced "and 7
        //    more". The reviewer counted it off the screenshot by eye after its own arithmetic
        //    went wrong, and inferred the exact cause. ⇒ DERIVE THE COUNT FROM WHAT WAS DRAWN,
        //    never from what there was room for.
        const roomFor = Math.max(0, Math.floor((bottom - ry - 14) / 15));
        const overflows = all.length > roomFor;
        const coming = all.slice(0, overflows ? Math.max(0, roomFor - 1) : roomFor);
        const hidden = all.length - coming.length;
        if (!all.length) {
          ART.text(ctx, 'nothing left today', x + 10, ry + 26, { size: 9, fill: '#5c6470' });
        }
        coming.forEach((t, i) => {
          const ty = ry + 26 + i * 15;
          const cls = LINE.classOf(t.cls);
          const fits = st.terminus || t.cars <= holds;
          ART.text(ctx, (t.dir === LINE.UP ? '↑' : '↓') + cls.short + ' ' + t.cars,
            x + 10, ty, { size: 9, weight: 600, fill: P.snow });
          // At a terminus every road is a yard road, so "fits" says nothing; what the signalman
          // wants there is WHEN. At a passing place the question is whether it will go in.
          // ⛔ "too long" AT A STATION WITH NO LOOP AT ALL IS THE WRONG REASON, and the reason is
          //    the whole lesson: nothing crosses here until you buy a road for it to cross on.
          ART.text(ctx, st.terminus ? SIM.clockOf(t.due) : holds === 0 ? 'no loop' : fits ? 'fits' : 'too long',
            x + w - 10, ty, {
              align: 'right', size: 9,
              fill: st.terminus ? P.snowDeep : fits ? P.greenLit : P.crimsonLit,
            });
        });
        if (hidden > 0) {
          const hy = ry + 26 + coming.length * 15;
          ART.text(ctx, 'and ' + hidden + ' more', x + 10, hy, { size: 9, fill: ART.P.brassDim });
          ART.text(ctx, String(all.length) + ' to pass', x + w - 10, hy,
            { align: 'right', size: 9, fill: ART.P.brassDim });
        }
      }
    }

    function drawSectionFrame(ctx, x, y, w, h, sec, s, d, ui) {
      const cx = x + w / 2;
      const occ = d ? d.sectionOcc[sec.id].length : 0;
      const closed = s.snow[sec.id] >= SIM.SNOW_CLOSED_AT;
      const state = closed ? 'closed' : occ ? 'occupied' : 'clear';
      ART.instrument(ctx, cx, y + 34, 19, state === 'closed' ? 'occupied' : state, { label: sec.name });

      // the staff, when the tier still uses one
      // ⛔ y+80, NOT y+68. The instrument's own label sits on a baseline at y+64 and 9px text
      //    rises about 9px above its baseline, so at y+68 the section name and the staff line
      //    were drawn THROUGH each other — visible in the first captured play screen as
      //    "LOW-CRA" with "staff: LOW" printed over it. Canvas text does not clip or reflow, so
      //    nothing but looking at the frame would have caught it (§3e-1).
      const tier = LINE.SIGNAL_TIERS[s.signalTier];
      if (tier.tokenReturn === 'carried' && d) {
        const at = d.staffAt[sec.id];
        const txt = at === -1 ? 'staff: on train' : 'staff: ' + LINE.STATIONS[at].short;
        ART.text(ctx, txt, cx, y + 80, { align: 'center', size: 9, fill: P.brass });
      } else if (d) {
        ART.text(ctx, 'token', cx, y + 80, { align: 'center', size: 9, fill: P.brassDim });
      }

      // snow gauge
      const gy = y + 92, gh = 40;
      ctx.fillStyle = 'rgba(0,0,0,0.42)'; ctx.fillRect(cx - 5, gy, 10, gh);
      const lvl = Math.min(1, s.snow[sec.id]);
      ctx.fillStyle = closed ? P.crimsonLit : lvl > SIM.SNOW_SLOW_AT ? P.snowLit : P.snowDeep;
      ctx.fillRect(cx - 5, gy + gh - gh * lvl, 10, gh * lvl);
      ctx.strokeStyle = 'rgba(224,187,96,0.55)'; ctx.lineWidth = 1;
      const slowY = gy + gh - gh * SIM.SNOW_CLOSED_AT;
      ctx.beginPath(); ctx.moveTo(cx - 7, slowY + 0.5); ctx.lineTo(cx + 7, slowY + 0.5); ctx.stroke();
      if (closed) ART.text(ctx, 'BLOCKED', cx, gy + gh + 12, { align: 'center', size: 9, weight: 600, fill: P.crimsonLit });

      // the signal arm for this section, so the panel and the valley agree
      ART.signal(ctx, cx - 1, y + h - 6, occ === 0 && !closed, { height: 20 });
    }

    // ── the header ────────────────────────────────────────────────────────────────────────
    /**
     * What the status line says when nothing has just happened.
     *
     * ⛔ IT USED TO BE ONE FIXED SENTENCE, AND A FIXED SENTENCE IS WALLPAPER. A reviewer working
     *    day one measured a minute and a half in which nothing was clickable and the line still
     *    read "Click a train standing at a signal", which is advice about something that is not
     *    on the screen. A player who cannot act needs to know WHEN they will be able to and HOW
     *    to get there sooner — so the hint is derived from the timetable, not typed.
     */
    function standingHint(s, d) {
      if (!d) return 'Click a train standing at a signal to clear it into the section ahead.';
      const standing = d.trains.filter((t) => t.state === 'standing').length;
      if (standing > 0) {
        return standing === 1
          ? 'Click the train standing at a signal to clear it into the section ahead.'
          : standing + ' trains are standing. Click one to clear it into the section ahead.';
      }
      const running = d.trains.filter((t) => t.state === 'running').length;
      const next = d.trains.filter((t) => t.state === 'booked')
        .reduce((a, t) => (a === null || t.due < a ? t.due : a), null);
      if (next !== null) {
        return 'Nothing to work until ' + SIM.clockOf(next) + '.'
          + (running ? ' ' + running + ' on the line.' : '')
          + ' Press 2 or 4 to run the clock on.';
      }
      if (running > 0) return running + ' still on the line. Press 2 or 4 to run the clock on.';
      return 'The day is done.';
    }

    function drawHeader(ctx, s, d) {
      ART.plated(ctx, 0, 0, W, HEAD_H, 'timber', P.timber, 'rgba(10,13,18,0.55)', 1);
      ART.text(ctx, 'SIDINGS', 18, 27, { size: 21, weight: 700, fill: P.brassLit });
      ART.text(ctx, 'Day ' + s.day, 150, 26, { size: 14, fill: P.snow });
      if (d) ART.text(ctx, SIM.clockOf(d.clock), 224, 26, { size: 14, fill: P.snowLit, weight: 600 });
      ART.text(ctx, '£' + s.money, W - 18, 26, { align: 'right', size: 16, weight: 600, fill: P.brassLit });
      if (d) {
        const arrived = d.trains.filter((t) => t.state === 'arrived').length;
        ART.text(ctx, arrived + '/' + d.trains.length + ' worked', W - 120, 26,
          { align: 'right', size: 12, fill: P.snowDeep });
      }
      ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(0, HEAD_H - 1, W, 1);
    }

    return {
      W, H, HEAD_H, VALLEY_Y, VALLEY_H, PANEL_Y, PANEL_H, STATUS_H,
      stationX, stationY, alongSection, hash,
      drawValley, drawPanel, drawHeader,
    };
  }

  return { make, W, H };
}));
