/**
 * audio.js — SIDINGS' sound. Files are pre-rendered OGG in Product_Release/audio/.
 *
 * ⛔ AUTOPLAY IS DENIED UNTIL THE PLAYER TOUCHES SOMETHING, and an itch embed is exactly where
 *    that bites. Nothing is played before the first gesture, `unlock()` is called from the first
 *    click or keypress, and every play path is guarded so a blocked or missing file can never
 *    throw into the game loop.
 * ⚠️ Wing §3c-12: because every audio call is try/catch, A MISSING CUE IS SILENT BY DESIGN — a
 *    source scan for quoted paths would report success over a game with no sound at all. So this
 *    module counts what actually LOADED and `report()` exposes it, and the runtime asset audit
 *    checks what the browser really requested.
 */
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else root.AUDIO = factory();
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const CUES = ['bell', 'lever', 'points', 'whistle', 'arrive', 'depart', 'wreck', 'buy', 'deny', 'snow', 'dayend'];
  const MUSIC = 'theme';

  const state = {
    base: 'audio/',
    loaded: {},        // name -> true when the element reached canplaythrough
    failed: {},
    els: {},
    music: null,
    unlocked: false,
    muted: false,
    volume: 0.62,
    musicVolume: 0.34,
  };

  function el(name, loop) {
    const a = new Audio();
    a.preload = 'auto';
    a.loop = !!loop;
    a.addEventListener('canplaythrough', () => { state.loaded[name] = true; }, { once: true });
    a.addEventListener('error', () => { state.failed[name] = true; }, { once: true });
    a.src = state.base + name + '.ogg';
    return a;
  }

  function init(base) {
    if (base) state.base = base;
    for (const c of CUES) {
      // Three voices per cue so a bell code's strokes overlap cleanly instead of cutting
      // each other off — the bell is rung in groups and it is the game's signature sound.
      state.els[c] = [el(c), el(c), el(c)];
    }
    state.music = el(MUSIC, true);
    state.music.volume = 0;
  }

  let rr = 0;
  function play(name, opts) {
    if (state.muted || !state.unlocked) return false;
    const bank = state.els[name];
    if (!bank) return false;
    const o = opts || {};
    try {
      const a = bank[(rr++) % bank.length];
      a.currentTime = 0;
      a.volume = Math.max(0, Math.min(1, state.volume * (o.gain === undefined ? 1 : o.gain)));
      a.playbackRate = o.rate || 1;
      const p = a.play();
      if (p && p.catch) p.catch(() => {});
      return true;
    } catch (e) { return false; }
  }

  /**
   * Ring a real signal-box bell code: groups of strokes separated by a pause.
   * [1,3] is "3-1" read the British way round in this game's tables: one group, then a group of
   * three. The player learns to recognise the Mail by its rhythm before they read the label.
   */
  const timers = [];
  function bellCode(code, onStroke) {
    if (!Array.isArray(code)) return;
    let t = 0;
    for (let g = 0; g < code.length; g++) {
      for (let i = 0; i < code[g]; i++) {
        const at = t;
        timers.push(setTimeout(() => {
          play('bell', { gain: 0.9, rate: 0.98 + (g * 0.02) });
          if (onStroke) onStroke();
        }, at));
        t += 230;
      }
      t += 260; // the gap between groups is what makes a code readable
    }
    while (timers.length > 240) clearTimeout(timers.shift());
  }

  function stopAll() {
    while (timers.length) clearTimeout(timers.pop());
  }

  function unlock() {
    if (state.unlocked) return;
    state.unlocked = true;
    try {
      if (state.music) {
        state.music.volume = state.muted ? 0 : state.musicVolume;
        const p = state.music.play();
        if (p && p.catch) p.catch(() => { state.unlocked = true; });
      }
    } catch (e) { /* a blocked autoplay is not a crash */ }
  }

  function setMuted(m) {
    state.muted = !!m;
    try { if (state.music) state.music.volume = state.muted ? 0 : state.musicVolume; } catch (e) { /* ignore */ }
    if (state.muted) stopAll();
  }
  function muted() { return state.muted; }

  /** Counts, not verdicts (master §2b). */
  function report() {
    return {
      // ⛔ The music loop is a loaded FILE too, so the denominator has to include it or the
      //    report reads 'loaded=12/11', which looks like a bug in the counter and undermines a
      //    number a test report is going to quote.
      cues: CUES.length + 1,
      loaded: Object.keys(state.loaded).length,
      failed: Object.keys(state.failed),
      unlocked: state.unlocked,
      muted: state.muted,
    };
  }

  return { init, play, bellCode, unlock, setMuted, muted, report, stopAll, CUES, MUSIC };
}));
