/**
 * line.js — SIDINGS: the railway itself, and the tables that describe it.
 *
 * Pure data + tiny helpers. No canvas, no DOM, no audio. Dual-mode (browser global + CommonJS)
 * so the Internal_Ops probes drive THE SHIPPED TABLES rather than a copy of them
 * (wing §3c-15: reimplementing a helper is not copying it).
 *
 * ── THE GEOGRAPHY ───────────────────────────────────────────────────────────────────────────
 * One single track up one valley. Five places, four block sections between them:
 *
 *    LOWGARTH ==1== CRAY BRIDGE ==2== HALLOWGILL ==3== WINTERSCAR ==4== HIGH FELL
 *    (yard, down end)                                                  (summit, up end)
 *
 * "UP" is toward High Fell, "DOWN" is toward Lowgarth, which is the British convention and also
 * literally true here: the line climbs. Gradient is not decoration — section 3 and 4 are steep,
 * so a heavy freight takes longer over them and a snowfall bites harder.
 *
 * ── WHY THE LOOP LENGTHS ARE THE WHOLE GAME ─────────────────────────────────────────────────
 * A passing loop is the ONLY place two trains travelling in opposite directions can meet. A loop
 * has a LENGTH in carriages, and a train longer than the loop physically cannot be put inside it.
 * So "where can these two trains cross?" is a question about geometry you paid for, and the
 * answer changes the moment you accept a freight contract. That is the interaction Gate 4 asks
 * for, and it lives in these numbers.
 */
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else root.LINE = factory();
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const UP = 1;
  const DOWN = -1;

  // ── Stations ──────────────────────────────────────────────────────────────────────────────
  // `loopTier` 0 means no loop at all: everything through here must use the single main line.
  // Lowgarth and High Fell are TERMINI — they have yard roads, so they always hold trains and
  // can never be the thing that jams the line. The middle three are where the game happens.
  const STATIONS = [
    { id: 0, name: 'LOWGARTH',   short: 'LOW', terminus: true,  km: 0,    canLoop: false },
    { id: 1, name: 'CRAY BRIDGE', short: 'CRA', terminus: false, km: 7.2,  canLoop: true },
    { id: 2, name: 'HALLOWGILL',  short: 'HAL', terminus: false, km: 15.8, canLoop: true },
    { id: 3, name: 'WINTERSCAR',  short: 'WIN', terminus: false, km: 23.1, canLoop: true },
    { id: 4, name: 'HIGH FELL',   short: 'HIF', terminus: true,  km: 31.0, canLoop: false },
  ];

  // ── Block sections ────────────────────────────────────────────────────────────────────────
  // One train at a time. `grade` multiplies the run time for heavy trains only, so a gradient
  // punishes freight and barely touches a light railcar — which is what makes a freight contract
  // a decision rather than free money.
  const SECTIONS = [
    { id: 0, from: 0, to: 1, name: 'LOW-CRA', lengthKm: 7.2, grade: 1.00, exposure: 0.35 },
    { id: 1, from: 1, to: 2, name: 'CRA-HAL', lengthKm: 8.6, grade: 1.15, exposure: 0.55 },
    { id: 2, from: 2, to: 3, name: 'HAL-WIN', lengthKm: 7.3, grade: 1.40, exposure: 0.85 },
    { id: 3, from: 3, to: 4, name: 'WIN-HIF', lengthKm: 7.9, grade: 1.55, exposure: 1.00 },
  ];

  // ── Train classes ─────────────────────────────────────────────────────────────────────────
  // `cars` is the physical length that a loop must be able to hold. `speed` is km per sim-minute.
  // `heavy` decides whether `grade` applies. `punctuality` is the fine multiplier for lateness —
  // the Mail is ruinous to delay, a pick-up goods barely cares.
  const CLASSES = {
    local:   { id: 'local',   name: 'Local Passenger', short: 'LOC', cars: 3, speed: 0.72, heavy: false, fare: 62,  punctuality: 1.0, colour: 'brass',  bell: [1, 3] },
    express: { id: 'express', name: 'Express',         short: 'EXP', cars: 4, speed: 1.05, heavy: false, fare: 148, punctuality: 2.4, colour: 'crimson', bell: [1, 4] },
    goods:   { id: 'goods',   name: 'Pick-up Goods',   short: 'GDS', cars: 6, speed: 0.44, heavy: true,  fare: 132, punctuality: 0.5, colour: 'rust',   bell: [3, 1] },
    mineral: { id: 'mineral', name: 'Mineral Train',   short: 'MIN', cars: 9, speed: 0.36, heavy: true,  fare: 310, punctuality: 0.4, colour: 'coal',   bell: [1, 2, 2] },
    mail:    { id: 'mail',    name: 'The Mail',        short: 'MAIL', cars: 4, speed: 0.98, heavy: false, fare: 214, punctuality: 4.0, colour: 'royal',  bell: [3, 1, 3] },
    plough:  { id: 'plough',  name: 'Snowplough',      short: 'PLW', cars: 2, speed: 0.60, heavy: true,  fare: 0,   punctuality: 0.0, colour: 'steel',  bell: [2, 2, 2] },
  };

  // ── Loop tiers ────────────────────────────────────────────────────────────────────────────
  // Buying a loop is buying the RIGHT TO CROSS at that place, and buying a longer one is buying
  // the right to cross the heavier trains there. `holds` is in cars, and it is compared against
  // the train's `cars` with no rounding and no mercy.
  const LOOP_TIERS = [
    { tier: 0, name: 'no loop',      holds: 0,  cost: 0 },
    { tier: 1, name: 'short loop',   holds: 4,  cost: 280 },
    { tier: 2, name: 'long loop',    holds: 7,  cost: 680 },
    { tier: 3, name: 'refuge siding', holds: 12, cost: 1420 },
  ];

  // ── The signalling ladder ─────────────────────────────────────────────────────────────────
  // The spine of the game. Each tier AUTOMATES THE VERB YOU WERE DOING BY HAND and unlocks a
  // timetable the previous tier could not have carried. Read `capacity` as "how many trains may
  // be moving on the running line at once", which is the number the whole economy hangs from.
  //
  // ⛔ `capacity` is enforced in sim.js `canAdmit()`, NOT here — wing §3h rule 1: a guard is
  //    where it is ENFORCED, never where it is DECLARED. These are the numbers it reads.
  const SIGNAL_TIERS = [
    {
      tier: 0, id: 'one-engine', name: 'One Engine In Steam', cost: 0,
      capacity: 1, sees: false, interlocked: false, auto: false, tokenReturn: 'carried',
      blurb: 'One train on the branch. Ever. The safest railway ever devised and the poorest.',
    },
    {
      tier: 1, id: 'staff-ticket', name: 'Staff & Ticket', cost: 170,
      capacity: 2, sees: false, interlocked: false, auto: false, tokenReturn: 'carried',
      blurb: 'A wooden staff per section. A second train may follow the first, but only if the staff is at the right end, and it comes back on a locomotive, not a wire.',
    },
    {
      tier: 2, id: 'electric-token', name: 'Electric Token', cost: 470,
      capacity: 3, sees: false, interlocked: false, auto: false, tokenReturn: 'electric',
      blurb: 'Paired instruments. Withdraw a token at either end and the section locks itself. The staff no longer has to ride home.',
    },
    {
      tier: 3, id: 'absolute-block', name: 'Absolute Block', cost: 1120,
      capacity: 4, sees: false, interlocked: false, auto: false, tokenReturn: 'electric',
      blurb: 'Bells and block instruments between every box. You offer, they accept, and nothing enters a section that is not clear.',
    },
    {
      tier: 4, id: 'track-circuit', name: 'Track Circuits', cost: 2300,
      capacity: 5, sees: true, interlocked: false, auto: false, tokenReturn: 'electric',
      blurb: 'The rails themselves report. For the first time the panel shows you WHERE a train is, not merely that the section is occupied.',
    },
    {
      tier: 5, id: 'interlocking', name: 'Interlocking Frame', cost: 2550,
      capacity: 6, sees: true, interlocked: true, auto: false, tokenReturn: 'electric',
      blurb: 'The levers are locked against each other. A signal that would put two trains in one section can no longer be pulled, however tired you are.',
    },
    {
      tier: 6, id: 'route-setting', name: 'Automatic Route Setting', cost: 4000,
      capacity: 7, sees: true, interlocked: true, auto: true, tokenReturn: 'electric',
      blurb: 'The panel reads the timetable and sets the road itself. You stop working the railway and start supervising it.',
    },
  ];

  // ── Doubling ──────────────────────────────────────────────────────────────────────────────
  // The endgame track spend: a doubled section carries one train in EACH direction at once.
  const DOUBLING_COST = [2400, 2800, 3400, 3900];

  function classOf(id) {
    const c = CLASSES[id];
    if (!c) throw new Error('unknown train class: ' + id);
    return c;
  }

  function sectionBetween(a, b) {
    const lo = Math.min(a, b);
    return SECTIONS[lo] && SECTIONS[lo].from === lo && SECTIONS[lo].to === lo + 1 ? SECTIONS[lo] : null;
  }

  /** The chain of section ids a train crosses going from station `a` to station `b`. */
  function pathSections(a, b) {
    const out = [];
    const dir = b > a ? 1 : -1;
    for (let s = a; s !== b; s += dir) out.push(dir > 0 ? s : s - 1);
    return out;
  }

  return {
    UP, DOWN, STATIONS, SECTIONS, CLASSES, LOOP_TIERS, SIGNAL_TIERS, DOUBLING_COST,
    classOf, sectionBetween, pathSections,
  };
}));
