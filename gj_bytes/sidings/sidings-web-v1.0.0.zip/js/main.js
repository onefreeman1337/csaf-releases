/**
 * main.js — SIDINGS: screens, input, the clock, and the wiring.
 *
 * ⛔ `setPaused` STOPS THE RENDERER, not merely the simulation (wing §3c-13: a paused game that
 *    kept painting photographed the wrong screen and the pixel check passed).
 * ⛔ Every storage key that is READ is WRITTEN by shipped code (master §2b: a dead reader is an
 *    untested code path, and it hid half of a game). The only key is SIM.SAVE_KEY.
 * ⛔ Every refusal NAMES ITSELF in the status line. `canAdmit` returns a reason for every no, and
 *    the player is told it. A guard that fails silently is indistinguishable from the thing it
 *    guards against.
 */
(function () {
  'use strict';

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d', { alpha: false });
  const R = RENDER.make(ART, LINE, SIM);

  const ui = {
    screen: 'title',        // title | play | dayend | yard | win | help
    speed: 1,
    paused: false,
    status: '',
    statusBad: false,
    hover: null,
    bellSwing: 0,
    regions: [],
    yardPage: 0,
    confirmNew: false,      // NEW RAILWAY is armed, not fired — it erases a save
    refusedItem: null, refusedWhy: '', refusedUntil: 0,   // a refusal is written ON the card
    lastResult: null,
    justWon: false,
  };

  let s = SIM.newGame();
  let d = null;
  let hasSave = false;
  let t0 = 0;
  let acc = 0;
  let simSeconds = 0;   // real worked time on the line — see window.__game.elapsed below

  try { hasSave = !!localStorage.getItem(SIM.SAVE_KEY); } catch (e) { hasSave = false; }

  ART.loadPlates('art/', () => { /* plates are decoration; the game runs without them */ });
  AUDIO.init('audio/');

  // ── status ────────────────────────────────────────────────────────────────────────────────
  let statusUntil = 0;
  function say(msg, bad) {
    ui.status = msg;
    ui.statusBad = !!bad;
    statusUntil = performance.now() + 4200;
  }
  /**
   * ⛔ A MESSAGE BELONGS TO THE SCREEN THAT RAISED IT. The status line survived a screen change,
   *    so a refusal raised at the frame ("Frame paused. The timetable is waiting.") was still
   *    sitting under the yard an hour of game time later, describing nothing on the page. It is
   *    the same shape as a stale caption: every mechanical check passes, because the string IS
   *    the string that was set. Cleared on every transition; the screens that have something to
   *    say (`toYard`, `beginDay`) say it immediately afterwards.
   */
  function goScreen(name) {
    if (ui.screen !== name) { ui.status = ''; ui.statusBad = false; statusUntil = 0; }
    ui.screen = name;
  }

  // ── day flow ──────────────────────────────────────────────────────────────────────────────
  function beginDay() {
    d = SIM.startDay(s);
    goScreen('play');
    ui.paused = false;
    say('Day ' + s.day + '. ' + d.trains.length + ' trains booked. '
      + LINE.SIGNAL_TIERS[s.signalTier].name + ' allows ' + LINE.SIGNAL_TIERS[s.signalTier].capacity
      + ' on the line at once.');
  }

  function finishDay() {
    /**
     * ⛔⛔ SETTLE THE DAY HERE, NOT AT EACH CALLER. `SIM.endDay` is the ONLY place that cancels the
     * trains left standing, charges the wreck fine, increments `s.wrecks`, computes `d.net` and
     * moves the money. `runMinutes` calls it when the clock runs out or the line deadlocks — but
     * the branch where a PLAYER causes a wreck by hand called `finishDay()` directly, so on that
     * path none of it ran: an independent reviewer measured the sheet drawing **"For the day
     * -£NaN"**, `lastResult` with no `net` key at all, money £1000 -> £1000 with the £900 fine and
     * £179 of cancellations never charged, `s.wrecks` still 0 — and ZERO console errors, because
     * `undefined` arithmetic is silent. The automatic wreck settled correctly, which is exactly
     * why nothing caught it: two paths into one screen and only one of them did the work.
     * `endDay` is idempotent (`if (d.finished) return`), so calling it here makes every route
     * into a result screen settled BY CONSTRUCTION rather than by each caller remembering (§11).
     */
    SIM.endDay(s, d);
    const won = SIM.checkWin(s, d);
    ui.justWon = won;
    ui.lastResult = {
      day: s.day, revenue: d.revenue, fines: d.fines, net: d.net,
      onTime: d.onTime, late: d.late,
      wreck: d.wreck ? d.wreck.text : null,
      blocked: d.blocked,
      cancelled: d.trains.filter((x) => x.state === 'cancelled').length,
    };
    SIM.save(s);
    hasSave = true;
    AUDIO.play(d.wreck ? 'wreck' : 'dayend');
    goScreen(won ? 'win' : 'dayend');
  }

  function toYard() {
    const fell = SIM.advanceDay(s);
    SIM.save(s);
    goScreen('yard');
    ui.yardPage = 0;
    if (fell.length) {
      const worst = fell.reduce((a, b) => (a.add > b.add ? a : b));
      say('Snow overnight on ' + LINE.SECTIONS[worst.section].name + '.');
      AUDIO.play('snow', { gain: 0.7 });
    } else say('A clear night.');
  }

  // ── input ─────────────────────────────────────────────────────────────────────────────────
  /**
   * ⛔⛔ MAP THE POINTER THROUGH THE **DRAWN PICTURE**, NEVER THE ELEMENT BOX.
   *
   * The canvas is displayed with `object-fit: contain`, so whenever the element's aspect differs
   * from 960x600 the picture is LETTERBOXED inside it and the element box is bigger than the
   * thing the player can see. The old two-line version scaled `clientX/clientY` by
   * `canvas.width / rect.width` and `canvas.height / rect.height` INDEPENDENTLY, which is a
   * stretch about the centre the moment those two ratios differ.
   *
   * MEASURED by an independent reviewer at 390x844: element box 390.4x600, drawn picture
   * 390.4x244, padY 178. A tap on HOW TO WORK IT (canvas y=400, screen y=462.7) read back as
   * canvas y=340.7 — which is inside NEW RAILWAY — so a returning player trying to read the
   * instructions **started a new game and wiped their railway**. The help screen was unreachable
   * on a phone unless you tapped 59px BELOW the button, in the black bar.
   *
   * One scale for both axes, and subtract the letterbox before dividing.
   */
  function canvasPos(ev) {
    const r = canvas.getBoundingClientRect();
    const src = ev.touches && ev.touches[0] ? ev.touches[0] : ev;
    const scale = Math.min(r.width / canvas.width, r.height / canvas.height) || 1;
    const padX = (r.width - canvas.width * scale) / 2;
    const padY = (r.height - canvas.height * scale) / 2;
    return {
      x: (src.clientX - r.left - padX) / scale,
      y: (src.clientY - r.top - padY) / scale,
    };
  }

  function hit(p) {
    for (let i = ui.regions.length - 1; i >= 0; i--) {
      const g = ui.regions[i];
      if (p.x >= g.x && p.x <= g.x + g.w && p.y >= g.y && p.y <= g.y + g.h) return g;
    }
    return null;
  }

  function clearTrain(id) {
    const tr = d.trains.find((x) => x.id === id);
    if (!tr) return;
    const v = SIM.canAdmit(s, d, tr);
    if (!v.ok) { say(v.reason, true); AUDIO.play('deny'); return; }
    if (v.wreck) {
      const r = SIM.admit(s, d, id);
      say(r.reason, true);
      AUDIO.play('wreck');
      finishDay();
      return;
    }
    const road = pickRoad(tr);
    if (road) SIM.setRoad(s, d, id, road);
    const r = SIM.admit(s, d, id);
    if (r.ok && !r.wreck) {
      AUDIO.play('lever');
      AUDIO.bellCode(LINE.classOf(tr.cls).bell, () => { ui.bellSwing = 1; });
      AUDIO.play('depart', { gain: 0.5 });
      say(SIM.label(tr) + ' cleared into ' + LINE.SECTIONS[SIM.nextSection(tr) >= 0 ? tr.section : tr.section].name + '.');
    }
  }

  /**
   * Which road the train takes at the far end. The player's default is the loop when anything is
   * coming the other way, because that is the decision the game is about and making them state
   * it every time would be busywork rather than skill; they override with the SHUNT verb.
   */
  function pickRoad(tr) {
    const secId = SIM.nextSection(tr);
    if (secId < 0) return null;
    const far = tr.dir === LINE.UP ? LINE.SECTIONS[secId].to : LINE.SECTIONS[secId].from;
    if (LINE.STATIONS[far].terminus) return 'main';
    const opposing = d.trains.some((x) => x.id !== tr.id && x.dir !== tr.dir
      && (x.state === 'standing' || x.state === 'running'));
    if (opposing && SIM.roadFree(s, d, far, 'loop', tr.cars, tr.id)) return 'loop';
    if (!SIM.roadFree(s, d, far, 'main', tr.cars, tr.id)
      && SIM.roadFree(s, d, far, 'loop', tr.cars, tr.id)) return 'loop';
    return 'main';
  }

  function onDown(ev) {
    AUDIO.unlock();
    const p = canvasPos(ev);
    const g = hit(p);
    ev.preventDefault();

    if (ui.screen === 'title') {
      if (g && g.id === 'start') {
        // With no save there is nothing to lose, so one click starts. With a save, the first
        // click only ARMS the button and the label says what the second one will do.
        if (hasSave && !ui.confirmNew) { ui.confirmNew = true; AUDIO.play('deny'); return; }
        ui.confirmNew = false;
        s = SIM.newGame(); SIM.clearSave(); hasSave = false; beginDay();
      } else if (g && g.id === 'continue') {
        ui.confirmNew = false;
        const l = SIM.load();
        if (l) { s = l; say('Resumed at day ' + s.day + '.'); beginDay(); }
        else say('No saved railway found.', true);
      } else if (g && g.id === 'help') { ui.confirmNew = false; goScreen('help'); }
      else ui.confirmNew = false;   // a click anywhere else disarms it
      return;
    }
    if (ui.screen === 'help') { if (g && g.id === 'back') goScreen(hasSave || d ? (d ? 'play' : 'title') : 'title'); return; }
    if (ui.screen === 'dayend') { if (g && g.id === 'yard') toYard(); return; }
    if (ui.screen === 'win') { if (g && g.id === 'continue') { goScreen('dayend'); } return; }
    if (ui.screen === 'yard') {
      if (!g) return;
      if (g.id === 'begin') { beginDay(); return; }
      if (g.id === 'page:prev') { ui.yardPage = Math.max(0, ui.yardPage - 1); AUDIO.play('lever', { gain: 0.5 }); return; }
      if (g.id === 'page:next') { ui.yardPage = ui.yardPage + 1; AUDIO.play('lever', { gain: 0.5 }); return; }
      if (g.kind === 'buy') {
        const r = SIM.buy(s, g.itemId);
        if (r.ok) {
          AUDIO.play('buy'); say('Bought: ' + r.item.name + '.'); SIM.save(s);
          ui.refusedItem = null;
        } else {
          AUDIO.play('deny');
          say(r.reason, true);
          ui.refusedItem = g.itemId;
          ui.refusedWhy = r.reason;
          ui.refusedUntil = performance.now() + 3600;
        }
      }
      return;
    }
    // play
    if (!g) return;
    if (g.kind === 'train') { if (!ui.paused) clearTrain(g.id); else say('The frame is paused.', true); return; }
    if (g.kind === 'shunt') {
      const r = SIM.shunt(s, d, g.id);
      if (r.ok) { AUDIO.play('points'); say(SIM.label(d.trains.find((x) => x.id === g.id)) + ' shunted to the ' + r.road + '.'); }
      else { AUDIO.play('deny'); say(r.reason, true); }
      return;
    }
    if (g.kind === 'button') {
      if (g.id === 'pause') { setPaused(!ui.paused); return; }
      if (g.id.indexOf('speed:') === 0) { ui.speed = parseInt(g.id.split(':')[1], 10); return; }
    }
  }

  function onMove(ev) {
    const p = canvasPos(ev);
    const g = hit(p);
    ui.hover = g ? (g.kind === 'train' ? 'train:' + g.id : g.id) : null;
    canvas.style.cursor = g ? 'pointer' : 'default';
  }

  function onKey(ev) {
    AUDIO.unlock();
    const k = ev.key;
    if (k === ' ') { if (ui.screen === 'play') setPaused(!ui.paused); ev.preventDefault(); }
    else if (k === '1' || k === '2' || k === '4') ui.speed = parseInt(k, 10);
    else if (k === 'm' || k === 'M') { AUDIO.setMuted(!AUDIO.muted()); say(AUDIO.muted() ? 'Sound off.' : 'Sound on.'); }
    // ⛔ THE README DOCUMENTED A KEY THAT DID NOT EXIST. `Readme_for_Users.md` told the player a
    //    train is "shunted (S)" while `onKey` bound Space/1/2/4/M/H/Escape and nothing else, so the
    //    only way to shunt was a 20x16px tab — the smallest target in the game — and the in-game
    //    help named no control at all. An independent reviewer found it by reading the shipped
    //    Readme against the shipped source. Binding the key is the honest fix: it makes the
    //    document true and gives the verb a target bigger than 320 square pixels.
    else if ((k === 's' || k === 'S') && ui.screen === 'play' && d) shuntByKey();
    else if (k === '?' || k === 'h' || k === 'H') goScreen(ui.screen === 'help' ? (d ? 'play' : 'title') : 'help');
    else if (k === 'Escape' && ui.screen === 'help') goScreen(d ? 'play' : 'title');
  }

  /**
   * The keyboard route to the shunt verb. Unambiguous when it can be: one candidate is shunted,
   * several ask which, none says so. ⛔ Every refusal NAMES ITSELF — a key that silently does
   * nothing is indistinguishable from a key that is not bound, which is the defect this fixes.
   */
  function shuntByKey() {
    if (ui.paused) { say('The frame is paused.', true); return; }
    const able = d.trains.filter((t) => SIM.canShunt(s, d, t));
    if (able.length === 0) { AUDIO.play('deny'); say('Nothing can be shunted just now.', true); return; }
    if (able.length > 1) {
      AUDIO.play('deny');
      say(able.length + ' trains can be shunted. Click the S tab beside the one you mean.', true);
      return;
    }
    const r = SIM.shunt(s, d, able[0].id);
    if (r.ok) { AUDIO.play('points'); say(SIM.label(able[0]) + ' shunted to the ' + r.road + '.'); }
    else { AUDIO.play('deny'); say(r.reason, true); }
  }

  /** ⛔ Stops the RENDERER as well as the clock (§3c-13). */
  function setPaused(v) {
    ui.paused = !!v;
    // ⛔ "FRAME PAUSED" NAMES A THING THE PLAYER HAS NOT BOUGHT. The interlocking FRAME is tier 6
    //    and costs £2,550; on day one this sentence describes equipment that does not exist yet.
    say(ui.paused ? 'Paused. The timetable is waiting.' : 'Working.');
  }

  canvas.addEventListener('mousedown', onDown);
  canvas.addEventListener('touchstart', onDown, { passive: false });
  canvas.addEventListener('mousemove', onMove);
  window.addEventListener('keydown', onKey);
  window.addEventListener('blur', () => { if (ui.screen === 'play') setPaused(true); });

  // ── screens ───────────────────────────────────────────────────────────────────────────────

  /**
   * A near snow bank across the foot of the screen, for the screens that have no signal box.
   *
   * ⛔ SHARED, NOT COPIED. The valley panel is only 258px tall because the signal box normally
   *    fills everything below it, so EVERY full-bleed screen has the same hole in the bottom
   *    half — the title had it and so did the win screen, and fixing only the one I happened to
   *    open first is exactly how the second one ships (§3c-10: the fix does not travel).
   */
  function foregroundBank() {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(0, R.H);
    ctx.lineTo(0, 334);
    ctx.quadraticCurveTo(R.W * 0.28, 300, R.W * 0.55, 332);
    ctx.quadraticCurveTo(R.W * 0.80, 358, R.W, 314);
    ctx.lineTo(R.W, R.H);
    ctx.closePath();
    ctx.clip();
    ART.plated(ctx, 0, 290, R.W, R.H - 290, 'snow', ART.P.snowDeep, 'rgba(14,20,30,0.58)', 1);
    ctx.restore();
  }

  function drawTitle() {
    const regions = [];
    R.drawValley(ctx, s, null, performance.now(), { backdrop: true });
    ctx.fillStyle = 'rgba(10,13,18,0.58)'; ctx.fillRect(0, 0, R.W, R.H);

    // ⛔ A NEAR SNOW BANK ACROSS THE FOOT OF THE SCREEN. The valley panel is only 258px tall
    //    because the signal box normally occupies everything below it — so on the TITLE, where
    //    there is no signal box, the first capture was a strip of mountain sitting on a dead
    //    black rectangle for the bottom half of the canvas. This gives the composition a
    //    foreground and somewhere for the studio line to sit.
    foregroundBank();

    ART.text(ctx, 'SIDINGS', R.W / 2, 168, { align: 'center', size: 74, weight: 700, fill: ART.P.brassLit });
    ART.text(ctx, 'A SINGLE LINE, A WINTER TIMETABLE, AND ONE TRAIN AT A TIME',
      R.W / 2, 200, { align: 'center', size: 13, weight: 600, fill: ART.P.snow });
    ART.paragraph(ctx,
      // ⛔ TWO COMMA SPLICES IN THREE SENTENCES, on the first screen anyone sees. A comma splice
      //    reads as haste, and this paragraph is the game's only chance to sound like it was
      //    written on purpose.
      'You are the signalman on a single track up a mountain valley. Two trains in one block '
      + 'section is not a setback. It is a wreck. Your capacity is not your mileage but your '
      + 'signalling, and you buy it one layer at a time.',
      R.W / 2 - 250, 246, 500, { size: 14, align: 'center' });

    /* ⛔ THE RETURNING PLAYER'S BUTTON GOES FIRST, AND THE DESTRUCTIVE ONE ASKS.
     * NEW RAILWAY sat ABOVE CONTINUE and called `SIM.clearSave()` on the first click, with no
     * confirmation — so the button nearest the top of a save-carrying title screen destroyed the
     * save. On a phone that was worse still, because the letterbox bug (see `canvasPos`) sent a
     * tap meant for HOW TO WORK IT into it. Order by what the player who HAS a railway wants, and
     * make the irreversible one a two-step: the label becomes the question. */
    const bw = 220, bh = 44;
    let y = 322;
    if (hasSave) {
      const b = ART.button(ctx, R.W / 2 - bw / 2, y, bw, bh, 'CONTINUE', { size: 16, hot: true });
      regions.push({ kind: 'button', id: 'continue', x: b.x, y: b.y, w: b.w, h: b.h });
      y += bh + 12;
    }
    const newLabel = !hasSave ? 'NEW RAILWAY'
      : ui.confirmNew ? 'THIS ERASES YOUR RAILWAY' : 'START A NEW RAILWAY';
    const a = ART.button(ctx, R.W / 2 - bw / 2, y, bw, bh, newLabel,
      { size: ui.confirmNew ? 13 : 16, hot: !hasSave });
    regions.push({ kind: 'button', id: 'start', x: a.x, y: a.y, w: a.w, h: a.h });
    if (ui.confirmNew) {
      ART.text(ctx, 'Click again to erase day ' + s.day + ' and everything you have built.',
        R.W / 2, y + bh + 16, { align: 'center', size: 12, fill: ART.P.crimsonLit });
    }
    y += bh + (ui.confirmNew ? 30 : 12);
    const c = ART.button(ctx, R.W / 2 - bw / 2, y, bw, bh, 'HOW TO WORK IT', { size: 16 });
    regions.push({ kind: 'button', id: 'help', x: c.x, y: c.y, w: c.w, h: c.h });
    /* ⛔ THE TITLE WAS THE ONE SCREEN THAT NEVER SHOWED THE LINE, AND THE LINE IS THE PRODUCT.
     * The band between the buttons and the shelf was a flat snowfield: an independent reviewer
     * called it the weakest screen precisely because everything around it had improved, and its
     * suggestion is the right one — draw the railway itself, unlit and static, so a visitor knows
     * what the game is before they click. Five places, four sections, at their real km spacing,
     * from the same tables the game plays on. */
    const mapY = 446;
    const totalKm = LINE.STATIONS[LINE.STATIONS.length - 1].km;
    const mx = (id) => 150 + (LINE.STATIONS[id].km / totalKm) * (R.W - 300);
    for (const sec of LINE.SECTIONS) ART.track(ctx, mx(sec.from) + 16, mx(sec.to) - 16, mapY, { snow: 0.25 });
    for (const st of LINE.STATIONS) {
      const px = mx(st.id);
      ART.panel(ctx, px - 15, mapY - 7, 30, 14, 'brass', st.terminus ? ART.P.brass : ART.P.brassDim,
        { tint: 'rgba(20,26,34,0.34)', alpha: 1 });
      ART.text(ctx, st.short, px, mapY + 4, { align: 'center', size: 9, weight: 700, fill: ART.P.snowLit });
      ART.text(ctx, st.name, px, mapY - 16, { align: 'center', size: 9, fill: ART.P.snowDeep });
    }
    ART.text(ctx, 'ONE TRACK · FIVE PLACES · FOUR BLOCK SECTIONS', R.W / 2, mapY + 24,
      { align: 'center', size: 10, weight: 600, fill: ART.P.brassDim });
    // ⛔ AND THE CREDIT ENDED UP STRADDLING A COLOUR CHANGE. Moving it out of a collision put it
    //    in the bottom-right corner, where the snowfield meets the timber shelf and one ink sits
    //    on two very different grounds — the same defect as the win copy, made by the fix for a
    //    different one. Centred on the snowfield, clear of both edges.
    ART.text(ctx, 'Core Systems Asset Factory', R.W - 24, 512,
      { align: 'right', size: 11, fill: ART.P.snowDeep });
    drawInstrumentShelf();
    return regions;
  }

  /**
   * THE SHELF. The bottom third of the title screen was a flat snowfield carrying two buttons and
   * a studio line — half the first thing anyone sees, saying nothing. A signalman's block shelf
   * is what is actually in front of you in this game, so the title now shows it: one brass block
   * instrument per section, needles at the states the game really uses, and the bell that rings
   * the codes. Drawn entirely by the game's own renderers at the real section names (§3e — the
   * fix for a thin screen is the game's own art at real data, never a stock icon set).
   */
  function drawInstrumentShelf() {
    const top = 496;
    ART.plated(ctx, 0, top, R.W, R.H - top, 'timber', ART.P.timber, 'rgba(10,13,18,0.42)', 1);
    ctx.fillStyle = 'rgba(224,187,96,0.30)';
    ctx.fillRect(0, top, R.W, 2);
    ctx.fillStyle = 'rgba(10,13,18,0.45)';
    ctx.fillRect(0, top + 2, R.W, 3);

    /* ⛔ THE SHELF WAS OFF-CENTRE BY 54px AND NOTHING COULD SEE IT — a reviewer measured content
     * centre 534 against a canvas centre of 480, margins 143 left and 35 right, on a screen whose
     * every other element is centred. The positions are derived from the content's own span now
     * rather than typed: four instruments, the bell and the two arms are laid out at a fixed
     * pitch and the whole row is shifted so its measured span is centred on the canvas. */
    const states = ['clear', 'occupied', 'normal', 'clear'];
    const r = 27;
    const cy = top + 50;
    const pitch = 146, bellGap = 134, armGap = 118, armSpacing = 42;
    const first = 0;
    const bellX = first + 3 * pitch + bellGap;
    const armA = bellX + armGap, armB = armA + armSpacing;
    const spanL = first - r, spanR = armB + 22;          // the ink, left edge to right edge
    const shift = R.W / 2 - (spanL + spanR) / 2;
    LINE.SECTIONS.forEach((sec, i) => {
      ART.instrument(ctx, shift + first + i * pitch, cy, r, states[i % states.length], { label: sec.name });
    });
    ART.bell(ctx, shift + bellX, cy - 4, 28, 0.16);
    ART.text(ctx, 'BLOCK BELL', shift + bellX, cy + r + 11, { align: 'center', size: 9, weight: 600, fill: ART.P.snowDeep });
    // The whole game in two objects: one arm saying yes, one saying no.
    ART.signal(ctx, shift + armA, cy + 20, true, { height: 46 });
    ART.signal(ctx, shift + armB, cy + 20, false, { height: 46 });
    ART.text(ctx, 'CLEAR', shift + armA - 2, cy + r + 11, { align: 'center', size: 9, weight: 600, fill: ART.P.greenLit });
    ART.text(ctx, 'DANGER', shift + armB + 6, cy + r + 11, { align: 'center', size: 9, weight: 600, fill: ART.P.crimsonLit });
  }

  function drawHelp() {
    ART.plated(ctx, 0, 0, R.W, R.H, 'timber', ART.P.timber, 'rgba(10,13,18,0.55)', 1);
    ART.text(ctx, 'HOW TO WORK THE LINE', 48, 62, { size: 28, weight: 700, fill: ART.P.brassLit });
    const lines = [
      ['The rule', 'One train in a block section. Put a second one in and they meet. Nothing else in the game matters as much as this.'],
      ['Clearing a train', 'Click a train standing at a station to clear it into the section ahead. If it cannot go, the status line tells you exactly why.'],
      ['Crossing', 'Two trains going opposite ways can only pass where there is a LOOP, and a loop has a LENGTH. A nine-wagon mineral train does not fit in a four-carriage loop. Buy loops before you buy traffic.'],
      ['Shunting', 'A train standing on the main can be shunted into the loop beside it to let another by. Click the small S tab beside the train, or press S when only one train can take it. It costs two minutes. It is also how you get out of trouble.'],
      ['The staff', 'On the first two tiers a wooden staff guards each section and it travels ON THE TRAIN. Until something comes back the other way, that section is one way only. Electric Token ends this.'],
      ['Snow', 'Snow builds on the exposed sections, slows trains, and eventually closes a section altogether. Order the plough from the yard.'],
      ['A bad day', 'A wreck or a blocked line ends the DAY, never the railway. Everything you have built stays built.'],
      ['Keys', 'Space pauses. 1, 2 and 4 set the speed. S shunts. M mutes. H opens this page. The bells are real signal-box codes.'],
    ];
    let y = 104;
    for (const [k, v] of lines) {
      ART.text(ctx, k, 48, y, { size: 14, weight: 700, fill: ART.P.brass });
      const p = ART.paragraph(ctx, v, 210, y, 700, { size: 13, fill: ART.P.paper });
      y += Math.max(24, p.height + 8);
    }
    // ⛔ THE IN-GAME DISCLOSURE MUST MATCH THE DECLARED ONE. This line used to read "Code and
    //    graphics are AI generated", while the listing declares code, graphics AND TEXT. The store
    //    tagging was right and the line the player actually reads was incomplete — a disclosure
    //    that is narrower than the truth is the half of master §4.1 that risks the account, and
    //    CREDITS.txt already said all three. One sentence, and it now says the same thing.
    // ── the bell codes, read off the same table the game rings them from ────────────────────
    // The help screen told the player "the bells are real signal box codes" and then never showed
    // one, leaving the bottom third of the page empty. This is the legend, drawn as the actual
    // groups of strokes, at the real codes in LINE.CLASSES — so it cannot drift from what the
    // speaker does (§3c-15: call the original, never retype it).
    // ⛔ THE INTERFACE SPEAKS IN CODES IT NEVER EXPANDS. The only clickable thing on day one is
    //    labelled "↑LOC 1" and the plough is "↑PLW"; nothing on any screen said what those were.
    //    This legend now carries the code as well as the bell, so it answers both questions at
    //    once — the arrow is direction, the letters are the class, the number is the train.
    ART.text(ctx, 'THE BELL CODES, AND WHAT THE LETTERS MEAN', 48, 444, { size: 14, weight: 700, fill: ART.P.brassLit });
    ART.text(ctx, '↑ is up to High Fell, ↓ is down to Lowgarth. One stroke calls attention first, every time.',
      48, 462, { size: 12, fill: ART.P.snowDeep });
    const CODED = ['local', 'express', 'goods', 'mineral', 'mail', 'plough'];
    CODED.forEach((key, i) => {
      const cls = LINE.classOf(key);
      const bx = 48 + (i % 3) * 296, by = 490 + Math.floor(i / 3) * 26;
      const pair = ART.CLASS_COLOUR[cls.colour] || ART.CLASS_COLOUR.brass;
      let dx = bx;
      cls.bell.forEach((group, gi) => {
        if (gi) { dx += 7; }                                   // a pause between groups
        for (let k = 0; k < group; k++) {
          // ⛔ PICK INK BY LUMINANCE AGAINST WHAT IT SITS ON (§0-ART-E). The mineral class's own
          //    colour is coal (#4a4340 lit) and on dark timber the strokes all but vanished, so
          //    every stroke carries a pale rule — the colour still identifies the train.
          ctx.fillStyle = pair[1];
          ctx.fillRect(dx, by - 7, 5, 5);
          ctx.strokeStyle = 'rgba(232,241,248,0.45)';
          ctx.lineWidth = 1;
          ctx.strokeRect(dx + 0.5, by - 6.5, 4, 4);
          dx += 8;
        }
      });
      ART.text(ctx, cls.bell.join('-'), bx + 104, by, { size: 11, weight: 700, fill: ART.P.snow });
      ART.text(ctx, cls.short, bx + 134, by, { size: 11, weight: 700, fill: ART.P.brassLit });
      ART.text(ctx, cls.name, bx + 172, by, { size: 11, fill: ART.P.paper });
    });

    // ⛔ AND IT IS A PARAGRAPH, NOT A LINE. Written as a single ART.text it ran straight through the
    //    BACK button — the layout gate caught it in the run after the edit, which is the second time
    //    in one session that a longer honest sentence was also a collision.
    ART.paragraph(ctx, 'Made by Core Systems Asset Factory. The code, the graphics and this text are '
      + 'AI generated; the music and every sound effect are procedurally synthesised by us and are not.',
    48, R.H - 62, 720, { size: 11, lineHeight: 16, fill: ART.P.snowDeep });
    const b = ART.button(ctx, R.W - 160, R.H - 60, 112, 38, 'BACK', { size: 14 });
    return [{ kind: 'button', id: 'back', x: b.x, y: b.y, w: b.w, h: b.h }];
  }

  function drawDayEnd() {
    R.drawValley(ctx, s, d, performance.now(), { backdrop: true });
    ctx.fillStyle = 'rgba(10,13,18,0.76)'; ctx.fillRect(0, 0, R.W, R.H);
    foregroundBank();
    const r = ui.lastResult || { day: s.day, revenue: 0, fines: 0, net: 0, onTime: 0, late: 0, cancelled: 0 };
    const panelX = 200, panelY = 96, panelW = 560, panelH = 400;
    ART.panel(ctx, panelX, panelY, panelW, panelH, 'slate', ART.P.slate, { tint: 'rgba(12,17,24,0.86)', alpha: 1 });
    // ⛔ A WRECK AND A DEADLOCK ARE NOT THE SAME ENDING AND MUST NOT SHARE A HEADLINE. Both
    //    branches of this ternary read "THE LINE IS BLOCKED", so the most dramatic thing that can
    //    happen in the game — two trains meeting head on — was announced with the words for a
    //    traffic jam. Found by opening the plate, invisible to every check.
    ART.text(ctx, r.wreck ? 'TWO TRAINS IN ONE SECTION' : r.blocked ? 'THE LINE IS BLOCKED' : 'DAY ' + r.day + ' WORKED',
      R.W / 2, panelY + 52, { align: 'center', size: 30, weight: 700, fill: r.wreck || r.blocked ? ART.P.crimsonLit : ART.P.brassLit });
    if (r.wreck) ART.paragraph(ctx, r.wreck, panelX + 40, panelY + 80, panelW - 80, { size: 14, align: 'center', fill: ART.P.crimsonLit });
    else if (r.blocked) ART.text(ctx, 'Nothing could move. The day was lost, the railway was not.',
      R.W / 2, panelY + 92, { align: 'center', size: 14, fill: ART.P.snow });
    else {
      // A GOOD DAY DESERVES A SENTENCE TOO. Only the two disasters had one, so the sheet a player
      // sees most often opened with a heading, a hole, and a table of numbers.
      const verdict = r.cancelled > 0
        ? r.cancelled + (r.cancelled === 1 ? ' train never left the yard.' : ' trains never left the yard.')
        : r.late > 0
          ? 'The line held. ' + r.late + (r.late === 1 ? ' train ran late.' : ' trains ran late.')
          : 'Every train ran, and every train ran on time.';
      ART.text(ctx, verdict, R.W / 2, panelY + 92,
        { align: 'center', size: 14, fill: r.cancelled > 0 ? ART.P.crimsonLit : r.late > 0 ? ART.P.snow : ART.P.greenLit });
    }

    const rows = [
      ['Trains on time', String(r.onTime)],
      ['Trains late', String(r.late)],
      ['Trains not run', String(r.cancelled)],
      ['Receipts', '£' + r.revenue],
      // A clean day should read "£0", not "-£0" — a minus sign in front of nothing looks like a
      // formatting bug and quietly undermines a screen whose whole job is to be trusted.
      ['Fines and cancellations', (r.fines > 0 ? '-£' : '£') + r.fines],
      ['For the day', (r.net >= 0 ? '£' : '-£') + Math.abs(r.net)],
    ];
    let y = panelY + 148;
    for (const [k, v] of rows) {
      const last = k === 'For the day';
      ART.text(ctx, k, panelX + 56, y, { size: last ? 17 : 14, weight: last ? 700 : 400, fill: last ? ART.P.brassLit : ART.P.paper });
      ART.text(ctx, v, panelX + panelW - 56, y, {
        align: 'right', size: last ? 17 : 14, weight: last ? 700 : 400,
        fill: last ? (r.net >= 0 ? ART.P.greenLit : ART.P.crimsonLit) : ART.P.snow,
      });
      y += last ? 34 : 27;
      if (k === 'Trains not run') y += 8;
    }
    const b = ART.button(ctx, R.W / 2 - 110, panelY + panelH - 62, 220, 44, 'TO THE YARD', { size: 16, hot: true });
    return [{ kind: 'button', id: 'yard', x: b.x, y: b.y, w: b.w, h: b.h }];
  }

  function drawWin() {
    R.drawValley(ctx, s, d, performance.now(), { backdrop: true });
    ctx.fillStyle = 'rgba(10,13,18,0.74)'; ctx.fillRect(0, 0, R.W, R.H);
    foregroundBank();
    // ⛔ ONE INK ACROSS A BACKGROUND THAT CHANGES LUMINANCE INSIDE A LINE. The win copy ran from
    //    dark sky onto a bright snowfield, so the same 16px paper-coloured text was crisp on the
    //    left of a line and nearly gone on the right. Contrast is a property of a PAIR, so the
    //    text gets a surface of its own to sit on rather than a colour tuned to an average.
    ART.panel(ctx, 96, 150, R.W - 192, 380, 'slate', ART.P.slate, { tint: 'rgba(10,13,18,0.86)', alpha: 1 });
    ART.text(ctx, 'THE WINTER TIMETABLE', R.W / 2, 190, { align: 'center', size: 46, weight: 700, fill: ART.P.brassLit });
    ART.paragraph(ctx,
      'You worked the heaviest day the valley has ever seen, by hand, on a fully interlocked '
      + 'frame, with the Mail and the mineral traffic running, and you did not put two trains in '
      + 'one section. Day ' + s.wonAtDay + '. The line is yours.',
      R.W / 2 - 300, 244, 600, { size: 16, align: 'center' });
    ART.paragraph(ctx,
      'Automatic Route Setting is still in the catalogue if you want to watch it run itself. '
      + 'The railway keeps going for as long as you do.',
      R.W / 2 - 280, 344, 560, { size: 13, align: 'center', fill: ART.P.snowDeep });

    /* ⛔ THE ENDING SHOWED NO NUMBERS WHILE AN ORDINARY DAY SHOWED SIX. The player has just worked
     * fifty-odd days; the screen that closes the campaign is the one place the whole run should be
     * counted. Read from the same state the yard ledger reads, so the two can never disagree. */
    const run = ['local', 'express', 'goods', 'mineral', 'mail']
      .reduce((a, k) => a + (s.contractsRun[k] || 0), 0);
    const stats = [
      ['Days worked', String(s.wonAtDay)],
      ['Trains run', String(run)],
      ['Earned in all', '£' + s.totalEarned],
      ['Best day', '£' + s.bestDay],
      ['Clean days', String(s.perfectDays)],
      ['Wrecks', String(s.wrecks)],
    ];
    stats.forEach(([k, v], i) => {
      const col = i % 3, row = Math.floor(i / 3);
      const sx2 = 128 + col * 240, sy2 = 396 + row * 26;
      ART.text(ctx, k, sx2, sy2, { size: 12, fill: ART.P.snowDeep });
      ART.text(ctx, v, sx2 + 176, sy2, {
        align: 'right', size: 12, weight: 700,
        fill: k === 'Wrecks' && s.wrecks > 0 ? ART.P.crimsonLit : ART.P.brassLit,
      });
    });

    const b = ART.button(ctx, R.W / 2 - 110, 470, 220, 44, 'CARRY ON', { size: 16, hot: true });
    return [{ kind: 'button', id: 'continue', x: b.x, y: b.y, w: b.w, h: b.h }];
  }

  // ── the yard ──────────────────────────────────────────────────────────────────────────────
  /**
   * ⛔⛔ `cat.slice(0, 8)` HID PART OF THE GAME AND NOTHING COULD SEE IT. The catalogue is 9
   *    items on the very first night and reaches THIRTEEN once track circuits allow doubling
   *    (measured: `node Internal_Ops/_catalogue_census.js`), so a fixed eight-card grid dropped
   *    the tail — and the tail begins with the SNOWPLOUGH, which the help screen tells the
   *    player to order from the yard. Every gate was green: the cards that were drawn were
   *    drawn correctly. A grid with a fixed capacity over a list with a variable length is a
   *    silent truncation, so the yard is now PAGED and the page count comes off the catalogue.
   *
   * ⛔ AND THE CARD IS SIZED FROM ITS OWN WRAPPED TEXT (§3e-1). The old card was a fixed 92px
   *    with a 322px text column; the Staff & Ticket blurb wraps to three lines in that column
   *    and its last line was drawn straight through the capacity footnote. `ART.wrap` measures
   *    first, the row takes the height its tallest card needs, and `test_layout.js` asserts no
   *    two strings intersect on any screen.
   */
  const YARD = {
    X0: 20, Y0: 86, COLS: 2, CW: 452, GAPX: 16, GAPY: 8,
    PER_PAGE: 8, MINH: 92, MAXB: 534, SIZES: [11, 10, 9],
  };

  /** Measure a page of cards. Returns row heights, wrapped line counts and the grid's bottom. */
  function yardLayout(items, size) {
    const lh = Math.round(size * 1.36);
    const lines = items.map((it) => ART.wrap(ctx, it.blurb, YARD.CW - 28, size, 400).length);
    const rows = Math.ceil(items.length / YARD.COLS) || 0;
    const rowH = [];
    for (let r = 0; r < rows; r++) {
      const n = Math.max(1, ...lines.slice(r * YARD.COLS, r * YARD.COLS + YARD.COLS));
      // 40 = first baseline, +4 for descenders, +46 for the footer row and the BUY button.
      rowH.push(Math.max(YARD.MINH, 40 + (n - 1) * lh + 4 + 46));
    }
    const total = rowH.reduce((a, b) => a + b, 0) + Math.max(0, rows - 1) * YARD.GAPY;
    return { size, lh, lines, rows, rowH, total, bottom: YARD.Y0 + total };
  }

  /** The largest text size at which this page of cards fits above the bottom bar. */
  function yardFit(items) {
    let L = null;
    for (const size of YARD.SIZES) {
      L = yardLayout(items, size);
      if (L.bottom <= YARD.MAXB) return L;
    }
    return L;
  }

  /**
   * THE LINE AS BUILT — the ledger that fills the yard once the catalogue runs short.
   *
   * ⛔ The late-game yard was ~60% empty void: by the time the signalling ladder is bought there
   *    are two or three cards left and the rest of the screen was black. Empty space is not
   *    restraint, it is an unanswered question — so the space now carries the one thing the game
   *    never otherwise shows you, which is WHAT YOU HAVE BOUGHT. Drawn from the game's own
   *    renderer at real state (§3e), never from a stock icon set.
   */
  /** The ledger's short form: one measured line for a gap too small to hold the panel. */
  function drawLedgerStrip(x, y, w) {
    ART.panel(ctx, x, y, w, 40, 'slate', ART.P.slate, { tint: 'rgba(10,14,20,0.80)', alpha: 1 });
    // ⛔ AN EM DASH STANDING IN FOR A NUMBER IS NOT A NUMBER, and it is banned typography besides.
    //    "loops CRA — · HAL —" reads as a formatting failure; "none" is the fact.
    const loops = LINE.STATIONS.filter((st) => st.canLoop)
      .map((st) => st.short + ' ' + (s.loops[st.id] ? LINE.LOOP_TIERS[s.loops[st.id]].holds : 'none')).join(' · ');
    const dbl = s.doubled.filter(Boolean).length;
    const run = ['local', 'express', 'goods', 'mineral', 'mail'].reduce((a, k) => a + (s.contractsRun[k] || 0), 0);
    const line = LINE.SIGNAL_TIERS[s.signalTier].name + ' · ' + LINE.SIGNAL_TIERS[s.signalTier].capacity
      + ' at once   ·   loops ' + loops + '   ·   ' + dbl + ' of 4 sections doubled   ·   '
      + run + ' trains run   ·   £' + s.totalEarned + ' earned';
    const fit = ART.wrap(ctx, line, w - 36, 12, 400)[0] || '';
    ART.text(ctx, fit, x + 18, y + 25, { size: 12, fill: ART.P.snowDeep });
  }

  function drawLedger(x, y, w, h) {
    ART.panel(ctx, x, y, w, h, 'slate', ART.P.slate, { tint: 'rgba(10,14,20,0.80)', alpha: 1 });
    ART.text(ctx, 'THE LINE AS BUILT', x + 18, y + 26, { size: 16, weight: 700, fill: ART.P.brassLit });
    ART.text(ctx, LINE.SIGNAL_TIERS[s.signalTier].name + ' · ' + LINE.SIGNAL_TIERS[s.signalTier].capacity
      + ' on the line at once', x + 186, y + 26, { size: 12, fill: ART.P.snowDeep });

    // ── the schematic: five places, four sections, drawn at real km spacing ──────────────────
    const mapY = y + 104;
    const left = x + 46, right = x + w - 312;
    const totalKm = LINE.STATIONS[LINE.STATIONS.length - 1].km;
    const sx = (id) => left + (LINE.STATIONS[id].km / totalKm) * (right - left);
    for (const sec of LINE.SECTIONS) {
      const a = sx(sec.from) + 18, b = sx(sec.to) - 18;
      const snow = s.snow[sec.id] || 0;
      const dbl = s.doubled[sec.id];
      if (dbl) { ART.track(ctx, a, b, mapY - 5, { snow }); ART.track(ctx, a, b, mapY + 5, { snow }); }
      else ART.track(ctx, a, b, mapY, { snow });
      ART.text(ctx, dbl ? 'two roads' : 'single', (a + b) / 2, mapY + 34,
        { align: 'center', size: 9, fill: dbl ? ART.P.greenLit : ART.P.steelLit });
      ART.text(ctx, snow > 0.02 ? Math.round(snow * 100) + '% snow' : 'clear', (a + b) / 2, mapY + 48,
        { align: 'center', size: 9, fill: snow > 0.6 ? ART.P.crimsonLit : ART.P.snowDeep });
    }
    for (const st of LINE.STATIONS) {
      const px = sx(st.id);
      const tier = st.canLoop ? s.loops[st.id] : 0;
      const hasLoop = tier > 0;
      // the loop is drawn as what it is: a second road alongside the main line
      if (hasLoop) ART.track(ctx, px - 24, px + 24, mapY - 15, { snow: 0 });
      ART.panel(ctx, px - 16, mapY - 8, 32, 16, 'brass', st.terminus ? ART.P.brass : ART.P.brassDim,
        { tint: 'rgba(20,26,34,0.30)', alpha: 1 });
      ART.text(ctx, st.short, px, mapY + 4, { align: 'center', size: 9, weight: 700, fill: ART.P.snowLit });
      ART.text(ctx, st.name, px, mapY - 30, { align: 'center', size: 10, fill: ART.P.snow });
      ART.text(ctx, st.canLoop ? (hasLoop ? LINE.LOOP_TIERS[tier].name + ' · holds ' + LINE.LOOP_TIERS[tier].holds : 'no loop')
        : 'yard roads', px, mapY + 20, { align: 'center', size: 9, fill: hasLoop || st.terminus ? ART.P.greenLit : ART.P.steelLit });
    }

    // ── the traffic actually worked, in the classes' own colours ────────────────────────────
    // The rest of the space is not a margin, it is the question "what do I actually run?".
    const chipY = y + h - 26;
    ART.text(ctx, 'TRAFFIC WORKED', x + 18, chipY - 26, { size: 11, weight: 700, fill: ART.P.brassLit });
    let chipX = x + 18;
    for (const key of ['local', 'express', 'goods', 'mineral', 'mail']) {
      const cls = LINE.classOf(key);
      const n = s.contractsRun[key] || 0;
      const on = !!s.unlocked[key];
      // ⛔ TAKE THE COLOUR FROM THE TABLE THE TRAINS ARE DRAWN FROM, NEVER FROM THE PALETTE BY
      //    NAME (§3c-15). `P[colour + 'Lit']` looked right and silently fell through for three of
      //    the five classes: the mineral chip resolved to `coal` (#241f1d) and was an invisible
      //    black square on a slate panel. `ART.CLASS_COLOUR` is what `ART.train` uses, so the
      //    chip and the train it stands for can never drift apart.
      const pair = ART.CLASS_COLOUR[cls.colour] || ART.CLASS_COLOUR.brass;
      ctx.fillStyle = on ? pair[1] : ART.P.steel;
      ctx.fillRect(chipX, chipY - 9, 10, 10);
      ctx.strokeStyle = 'rgba(232,241,248,0.35)';
      ctx.lineWidth = 1;
      ctx.strokeRect(chipX + 0.5, chipY - 8.5, 9, 9);
      const lbl = ART.text(ctx, cls.short + ' ' + n, chipX + 16, chipY,
        { size: 11, weight: on ? 700 : 400, fill: on ? ART.P.snow : ART.P.steelLit });
      chipX = lbl.x + lbl.w + 22;
    }

    // ── the ledger column ───────────────────────────────────────────────────────────────────
    // ⛔ `contractsRun` also counts the plough, which is a SERVICE and not a train. Summing the
    //    whole object would print a number the player can never reconcile with anything.
    const run = ['local', 'express', 'goods', 'mineral', 'mail']
      .reduce((a, k) => a + (s.contractsRun[k] || 0), 0);
    const rows = [
      ['Days worked', String(s.day - 1)],
      ['Trains run', String(run)],
      ['Best day', '£' + s.bestDay],
      ['Earned in all', '£' + s.totalEarned],
      ['Clean days', String(s.perfectDays)],
      ['Wrecks', String(s.wrecks)],
      ['Snowploughs ordered', String(s.contractsRun.plough || 0)],
    ];
    const lx = x + w - 274, lw = 256;
    const step = Math.min(30, Math.max(17, Math.floor((h - 78) / rows.length)));
    let ly = y + 58;
    for (const [k, v] of rows) {
      ART.text(ctx, k, lx, ly, { size: 12, fill: ART.P.paper });
      ART.text(ctx, v, lx + lw, ly, {
        align: 'right', size: 12, weight: 700,
        fill: k === 'Wrecks' && s.wrecks > 0 ? ART.P.crimsonLit : ART.P.snowLit,
      });
      ly += step;
    }
  }

  function drawYard() {
    const regions = [];
    R.drawValley(ctx, s, null, performance.now(), { backdrop: true });
    ctx.fillStyle = 'rgba(10,13,18,0.72)'; ctx.fillRect(0, 0, R.W, R.H);
    ART.plated(ctx, 0, 0, R.W, 70, 'timber', ART.P.timber, 'rgba(10,13,18,0.62)', 1);
    ART.text(ctx, 'THE YARD', 24, 42, { size: 28, weight: 700, fill: ART.P.brassLit });
    ART.text(ctx, 'Night before day ' + s.day, 190, 42, { size: 14, fill: ART.P.snow });
    ART.text(ctx, '£' + s.money, R.W - 24, 42, { align: 'right', size: 24, weight: 700, fill: ART.P.brassLit });

    // ⛔ THE VALLEY SHOWED THROUGH THE GUTTERS. 20px slivers of mountain and a dotted track ran
    //    between the card columns and rows, which reads as the cards floating on a photograph
    //    rather than as a board. The grid gets its own quiet ground.
    ART.plated(ctx, 12, 80, R.W - 24, YARD.MAXB - 74, 'slate', ART.P.night,
      'rgba(10,13,18,0.82)', 1);

    const cat = SIM.catalogue(s);
    const pages = Math.max(1, Math.ceil(cat.length / YARD.PER_PAGE));
    if (ui.yardPage > pages - 1) ui.yardPage = pages - 1;
    if (ui.yardPage < 0) ui.yardPage = 0;
    const first = ui.yardPage * YARD.PER_PAGE;
    const items = cat.slice(first, first + YARD.PER_PAGE);
    const L = yardFit(items);

    let yy = YARD.Y0;
    items.forEach((item, i) => {
      const col = i % YARD.COLS, row = Math.floor(i / YARD.COLS);
      if (col === 0 && row > 0) yy += L.rowH[row - 1] + YARD.GAPY;
      const cx = YARD.X0 + col * (YARD.CW + YARD.GAPX);
      const cy = yy, ch = L.rowH[row];
      const afford = s.money >= item.cost && !item.lockedBy;
      ART.panel(ctx, cx, cy, YARD.CW, ch, 'slate', ART.P.slate, {
        tint: afford ? 'rgba(12,17,24,0.72)' : 'rgba(8,10,14,0.86)', alpha: 1,
      });
      ART.text(ctx, item.name, cx + 14, cy + 22, { size: 15, weight: 700, fill: afford ? ART.P.brassLit : '#7d7b74' });
      ART.text(ctx, '£' + item.cost, cx + YARD.CW - 14, cy + 22,
        { align: 'right', size: 15, weight: 700, fill: afford ? ART.P.snowLit : ART.P.crimsonLit });
      ART.paragraph(ctx, item.blurb, cx + 14, cy + 40, YARD.CW - 28,
        { size: L.size, lineHeight: L.lh, fill: afford ? ART.P.paper : '#6f6d67' });
      if (item.detail) ART.text(ctx, item.detail, cx + 14, cy + ch - 12, { size: 10, fill: ART.P.snowDeep });
      if (item.lockedBy) {
        ART.text(ctx, item.lockedBy, cx + YARD.CW - 14, cy + ch - 12, { align: 'right', size: 10, fill: ART.P.crimsonLit });
        // ⛔ A LOCKED CARD USED TO REFUSE IN TOTAL SILENCE — no region, so no click, no message,
        //    no cue, on a product whose Readme says the game never refuses you silently. The
        //    whole card is a target now and it says why it cannot be bought.
        regions.push({ kind: 'buy', itemId: item.id, x: cx, y: cy, w: YARD.CW, h: ch });
      } else {
        const b = ART.button(ctx, cx + YARD.CW - 104, cy + ch - 34, 90, 26, 'BUY', { size: 12, enabled: afford });
        regions.push({ kind: 'buy', itemId: item.id, x: b.x, y: b.y, w: b.w, h: b.h });
      }
      // ⛔ THE REFUSAL APPEARED 733px FROM THE THING THAT REFUSED IT. The message goes to the
      //    status bar at the bottom-left while the card is anywhere on the page, so the player
      //    reads an answer nowhere near their question. It is now ALSO written on the card.
      if (ui.refusedItem === item.id && performance.now() < ui.refusedUntil) {
        ART.panel(ctx, cx + 8, cy + ch - 30, YARD.CW - 120, 22, 'slate', ART.P.crimson,
          { tint: 'rgba(143,50,50,0.55)', alpha: 1 });
        const fit = ART.wrap(ctx, ui.refusedWhy, YARD.CW - 136, 10, 400)[0] || '';
        ART.text(ctx, fit, cx + 16, cy + ch - 15, { size: 10, fill: ART.P.snowLit });
      }
    });

    // The space the cards did not need is the ledger's, never a void. A panel STRETCHED over a
    // gap has a hole in it; one sized to its content and centred in the gap reads as a decision.
    // ⛔ AND A PANEL SQUEEZED INTO A GAP TOO SMALL FOR IT OVERFLOWS THE GAP. The first version
    //    drew the full ledger into anything over 130px: at the catalogue peak the schematic
    //    landed on the traffic chips and two ledger rows were printed over the WORK DAY button.
    //    `test_layout.js` caught it in the run after the one that introduced it, which is the
    //    entire argument for having written the gate.
    const gridBottom = L.bottom;
    const avail = YARD.MAXB - gridBottom - 14;
    if (avail >= 208) {
      const lh2 = Math.min(avail, 252);
      drawLedger(YARD.X0, gridBottom + 14 + Math.floor((avail - lh2) / 2), R.W - YARD.X0 * 2, lh2);
    } else if (avail >= 46) {
      drawLedgerStrip(YARD.X0, gridBottom + 14 + Math.floor((avail - 40) / 2), R.W - YARD.X0 * 2);
    }

    // ── the bottom bar: pager on the left, message in the middle, the day on the right ───────
    let msgX = 24;
    if (pages > 1) {
      const prev = ART.button(ctx, 24, 550, 34, 30, '◂', { size: 15, enabled: ui.yardPage > 0 });
      regions.push({ kind: 'button', id: 'page:prev', x: prev.x, y: prev.y, w: prev.w, h: prev.h });
      const next = ART.button(ctx, 214, 550, 34, 30, '▸', { size: 15, enabled: ui.yardPage < pages - 1 });
      regions.push({ kind: 'button', id: 'page:next', x: next.x, y: next.y, w: next.w, h: next.h });
      ART.text(ctx, 'page ' + (ui.yardPage + 1) + ' of ' + pages + ' · ' + cat.length + ' for sale',
        136, 570, { align: 'center', size: 12, fill: ART.P.snow });
      msgX = 268;
    }
    const b = ART.button(ctx, R.W - 284, 548, 260, 42, 'WORK DAY ' + s.day, { size: 16, hot: true });
    regions.push({ kind: 'button', id: 'begin', x: b.x, y: b.y, w: b.w, h: b.h });
    // ⛔ THE MESSAGE IS BOUNDED BY THE BUTTON BESIDE IT. It used to be drawn at a fixed x with no
    //    width at all, so "Day 2. 3 trains booked. Staff & Ticket allows 2 on the line at once."
    //    ran straight underneath WORK DAY. A line of prose with no measured budget is a collision
    //    waiting for a longer sentence (§3e-3).
    if (ui.status) {
      const budget = (R.W - 284) - msgX - 20;
      const line = ART.wrap(ctx, ui.status, budget, 12, 400)[0] || '';
      const shown = line.length < String(ui.status).length ? line.replace(/[,.;:]$/, '') + '…' : line;
      ART.text(ctx, shown, msgX, 574, { size: 12, fill: ui.statusBad ? ART.P.crimsonLit : ART.P.snow });
    }
    return regions;
  }

  function drawPlay() {
    const now = performance.now();
    R.drawHeader(ctx, s, d);
    R.drawValley(ctx, s, d, now);
    const regions = R.drawPanel(ctx, s, d, ui);
    // a shunt tab beside every train that could take one
    for (const g of regions.slice()) {
      if (g.kind !== 'train') continue;
      const tr = d.trains.find((x) => x.id === g.id);
      if (!tr || !SIM.canShunt(s, d, tr)) continue;
      const bx = g.x + g.w - 22, by = g.y + 1;
      ART.panel(ctx, bx, by, 20, 16, 'brass', ART.P.brassDim, { tint: 'rgba(20,26,34,0.35)', alpha: 1 });
      ART.text(ctx, 'S', bx + 10, by + 12, { align: 'center', size: 10, weight: 700, fill: ART.P.snowLit });
      regions.push({ kind: 'shunt', id: tr.id, x: bx, y: by, w: 20, h: 16 });
    }
    if (ui.paused) {
      ctx.fillStyle = 'rgba(10,13,18,0.55)';
      ctx.fillRect(0, R.VALLEY_Y, R.W, R.VALLEY_H);
      ART.text(ctx, 'PAUSED', R.W / 2, R.VALLEY_Y + R.VALLEY_H / 2, {
        align: 'center', size: 44, weight: 700, fill: ART.P.brassLit,
      });
    }
    return regions;
  }

  // ── the loop ──────────────────────────────────────────────────────────────────────────────
  function frame(now) {
    if (!t0) t0 = now;
    const dt = Math.min(0.25, (now - t0) / 1000);
    t0 = now;
    if (statusUntil && now > statusUntil) { ui.status = ''; statusUntil = 0; }
    if (ui.bellSwing > 0) ui.bellSwing = Math.max(0, ui.bellSwing - dt * 2.2);

    if (ui.screen === 'play' && !ui.paused && d && !d.finished) {
      acc += dt * ui.speed;
      simSeconds += dt * ui.speed;
      const stepReal = 1 / 30;
      while (acc >= stepReal) {
        acc -= stepReal;
        const fired = SIM.runMinutes(s, d, stepReal * SIM.MINUTES_PER_SECOND);
        for (const f of fired) {
          if (f.kind === 'arrived') AUDIO.play('arrive', { gain: 0.7 });
          else if (f.kind === 'booked') AUDIO.play('whistle', { gain: 0.35 });
          else if (f.kind === 'auto' && f.bell) { AUDIO.bellCode(f.bell); ui.bellSwing = 1; }
          if (f.text && (f.kind === 'held' || f.kind === 'arrived')) say(f.text);
        }
        if (d.finished) { finishDay(); break; }
      }
    }

    ctx.fillStyle = ART.P.ink;
    ctx.fillRect(0, 0, R.W, R.H);
    if (ui.screen === 'title') ui.regions = drawTitle();
    else if (ui.screen === 'help') ui.regions = drawHelp();
    else if (ui.screen === 'yard') ui.regions = drawYard();
    else if (ui.screen === 'dayend') ui.regions = drawDayEnd();
    else if (ui.screen === 'win') ui.regions = drawWin();
    else ui.regions = drawPlay();

    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // ── the harness hook ──────────────────────────────────────────────────────────────────────
  // ⛔ ONE DRIVER. Wing §3c-16: a capture harness that steps with its own input while the game
  //    reads its own keys zeroes progress every frame. Everything a probe needs is exposed here
  //    and drives THE SAME functions the player's clicks drive.
  window.SIDINGS = {
    get state() { return s; },
    get day() { return d; },
    get ui() { return ui; },
    beginDay, finishDay, toYard, clearTrain, say, setPaused,
    // ⛔ THE HOOK GOES THROUGH `goScreen`, NOT ROUND IT. A harness that assigns `ui.screen`
    //    directly gets semantics the player never gets — that is how the yard was photographed
    //    with a status line left over from day 2 while the clock read day 58 (§3c-16, one driver).
    screen: (name) => { goScreen(name); },
    setSpeed: (v) => { ui.speed = v; },
    regions: () => ui.regions,
    audioReport: () => AUDIO.report(),
    missingPlates: () => ART.missingPlates(),
    version: '1.0.0',
  };

  // ── the factory's engine-gate surface (Kernel/engines/html5_gate.js) ──────────────────────
  // ⛔ STILL ONE DRIVER. This is a thin ALIAS onto the functions above, never a second code
  //    path: `begin` is the same beginDay the Start button calls, and `elapsed` is real worked
  //    time on the line — it only accumulates inside the same branch that steps SIM.runMinutes,
  //    so a frozen loop, a paused frame or a finished day cannot fake it moving.
  //    `inputProbe` dispatches a REAL keydown at window, which is where onKey is bound, and
  //    reads back the same `ui.speed` the renderer draws the speed control from.
  window.__game = {
    get elapsed() { return simSeconds; },
    begin() { if (!d || d.finished) beginDay(); ui.paused = false; },
    inputProbe: {
      events: [{ type: 'keydown', init: { key: '4', bubbles: true } }],
      read: () => ui.speed,
      settleMs: 300,
    },
  };
}());
