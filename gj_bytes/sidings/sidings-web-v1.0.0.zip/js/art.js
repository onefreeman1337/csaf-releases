/**
 * art.js — SIDINGS' drawing layer: palette, material plates, typography, chrome, rolling stock.
 *
 * ── WHY EVERY STRING AND EVERY BUTTON GOES THROUGH THIS FILE ────────────────────────────────
 * Canvas text does not wrap, reflow or clip. Wing §3e-1 measured 133 green assertions over text
 * drawn to x=1035 on a 960-wide canvas, and §3e-3 found a string sitting inside a button that
 * the layout gate could not see. So:
 *   · every string is drawn by `API.text`
 *   · every button is drawn by `API.button`, which records its rect AND its label
 *   · ⛔ a helper that calls a closure-local `text()` is INVISIBLE to the recorder — route
 *     everything through `API.text`, and the layout gate asserts a FLOOR on strings per screen
 *     so that "nothing overflowed" can never be satisfied by drawing nothing.
 * ⛔ `parseInt(ctx.font)` RETURNS THE FONT WEIGHT ("600 14px …" -> 600). Width/height come from
 *    `ctx.measureText` and a regex on /(\d+(?:\.\d+)?)px/ — never from parseInt (§3e-2).
 */
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else root.ART = factory();
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // ── palette ───────────────────────────────────────────────────────────────────────────────
  // One winter family. Brass is the ONLY warm accent, so anything brass reads as "an instrument
  // you can touch" — legibility outranks realism (§0-ART).
  const P = {
    ink:        '#0a0d12',
    night:      '#12171f',
    slate:      '#1c232e',
    slateLit:   '#2a3441',
    steel:      '#46566a',
    steelLit:   '#6b7f96',
    snowDeep:   '#8fa6bd',
    snow:       '#c3d4e3',
    snowLit:    '#e8f1f8',
    timber:     '#2e2118',
    timberLit:  '#4a3524',
    timberHi:   '#6d5034',
    brass:      '#b08a3e',
    brassLit:   '#e0bb60',
    brassDim:   '#6f5726',
    crimson:    '#8f3232',
    crimsonLit: '#cf5a4e',
    green:      '#3f7a4e',
    greenLit:   '#63b073',
    rust:       '#8a5a2e',
    royal:      '#3b4d8f',
    coal:       '#241f1d',
    paper:      '#d8cdb4',
  };

  const FONT = "'Iowan Old Style', 'Palatino Linotype', Palatino, 'Book Antiqua', Georgia, serif";

  // ── the recorder (§3e-1 / §3e-3) ──────────────────────────────────────────────────────────
  let rec = null;
  function record(on) { rec = on ? { texts: [], buttons: [] } : null; return rec; }
  function recording() { return rec; }

  function pxOf(font) {
    const m = /(\d+(?:\.\d+)?)px/.exec(font);
    return m ? parseFloat(m[1]) : 12;
  }

  // ── plates ────────────────────────────────────────────────────────────────────────────────
  const PLATES = {};
  const PLATE_NAMES = ['snow', 'crag', 'moor', 'timber', 'slate', 'brass'];
  let platesReady = false;

  function loadPlates(base, done) {
    let left = PLATE_NAMES.length;
    if (!left) { platesReady = true; done && done(); return; }
    for (const n of PLATE_NAMES) {
      const img = new Image();
      img.onload = () => { PLATES[n] = img; if (--left === 0) { platesReady = true; done && done(); } };
      // ⛔ A MISSING PLATE MUST NOT WEDGE THE BOOT. Wing §3c-12: every audio call is try/catch so
      //    a missing cue is silent by design; the same trap applies here. If a plate fails to
      //    load the game still runs on flat fills, and `missingPlates()` reports it rather than
      //    the title screen simply never appearing.
      img.onerror = () => { PLATES[n] = null; if (--left === 0) { platesReady = true; done && done(); } };
      img.src = base + 'plate_' + n + '.png';
    }
  }
  function missingPlates() { return PLATE_NAMES.filter((n) => !PLATES[n]); }

  const patCache = {};
  function plateFill(ctx, name, fallback) {
    const img = PLATES[name];
    if (!img) return fallback;
    if (!patCache[name]) patCache[name] = ctx.createPattern(img, 'repeat');
    return patCache[name] || fallback;
  }

  // ── primitives ────────────────────────────────────────────────────────────────────────────
  function rect(ctx, x, y, w, h, fill) {
    ctx.fillStyle = fill; ctx.fillRect(x, y, w, h);
  }

  function plated(ctx, x, y, w, h, name, fallback, tint, alpha) {
    ctx.save();
    ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
    ctx.fillStyle = plateFill(ctx, name, fallback);
    ctx.translate(x, y); ctx.fillRect(0, 0, w, h); ctx.translate(-x, -y);
    if (tint) { ctx.globalAlpha = alpha === undefined ? 0.35 : alpha; ctx.fillStyle = tint; ctx.fillRect(x, y, w, h); }
    ctx.restore();
  }

  /** A bevelled plate of material with an engraved edge — the game's one UI shape. */
  function panel(ctx, x, y, w, h, name, fallback, opts) {
    const o = opts || {};
    plated(ctx, x, y, w, h, name, fallback, o.tint, o.alpha);
    ctx.strokeStyle = o.hi || 'rgba(255,255,255,0.10)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x + 0.5, y + h - 0.5); ctx.lineTo(x + 0.5, y + 0.5); ctx.lineTo(x + w - 0.5, y + 0.5); ctx.stroke();
    ctx.strokeStyle = o.lo || 'rgba(0,0,0,0.55)';
    ctx.beginPath(); ctx.moveTo(x + w - 0.5, y + 0.5); ctx.lineTo(x + w - 0.5, y + h - 0.5); ctx.lineTo(x + 0.5, y + h - 0.5); ctx.stroke();
  }

  /**
   * Every string in the game. Returns the measured rect so callers can lay out from real ink.
   * ⛔ Layout is derived from ctx.measureText AT DRAW TIME — system fonts differ per OS and
   *    "measure once, hard-code the x" is wrong by construction (§3e-1).
   */
  function text(ctx, str, x, y, opts) {
    const o = opts || {};
    const size = o.size || 14;
    const weight = o.weight || 400;
    const align = o.align || 'left';
    ctx.font = weight + ' ' + size + 'px ' + FONT;
    ctx.textBaseline = o.baseline || 'alphabetic';
    const s = String(str);
    const m = ctx.measureText(s);
    const w = m.width;
    const px = pxOf(ctx.font);
    let dx = x;
    if (align === 'center') dx = x - w / 2;
    else if (align === 'right') dx = x - w;
    if (o.shadow !== false) {
      ctx.fillStyle = 'rgba(0,0,0,0.65)';
      ctx.fillText(s, dx + 1, y + 1);
    }
    ctx.fillStyle = o.fill || P.paper;
    ctx.fillText(s, dx, y);
    const asc = (m.actualBoundingBoxAscent || px * 0.75);
    const desc = (m.actualBoundingBoxDescent || px * 0.25);
    const r = { s, x: dx, y: y - asc, w, h: asc + desc, size: px };
    if (rec) rec.texts.push(r);
    return r;
  }

  /** Wrap `str` into lines no wider than `maxW`, returning the lines (does not draw). */
  function wrap(ctx, str, maxW, size, weight) {
    ctx.font = (weight || 400) + ' ' + (size || 14) + 'px ' + FONT;
    const words = String(str).split(/\s+/);
    const lines = [];
    let cur = '';
    for (const wd of words) {
      const t = cur ? cur + ' ' + wd : wd;
      if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = wd; }
      else cur = t;
    }
    if (cur) lines.push(cur);
    return lines;
  }

  /**
   * A wrapped block of prose in a box whose LEFT edge is `x` and whose width is `maxW`.
   *
   * ⛔ `align` is resolved AGAINST THE BOX, not against `x`. The first version passed `x` straight
   *    to `text()`, which centres on the coordinate it is given — so a centred paragraph laid out
   *    as (W/2 - 250, width 500) centred every line on the box's LEFT EDGE and the title screen
   *    shipped with its opening sentence running off the left of the canvas. It was invisible to
   *    every mechanical check and obvious the moment the screenshot was opened (§10b).
   */
  function paragraph(ctx, str, x, y, maxW, opts) {
    const o = opts || {};
    const size = o.size || 13;
    const lh = o.lineHeight || Math.round(size * 1.45);
    const lines = wrap(ctx, str, maxW, size, o.weight);
    const ax = o.align === 'center' ? x + maxW / 2 : o.align === 'right' ? x + maxW : x;
    lines.forEach((ln, i) => text(ctx, ln, ax, y + i * lh, o));
    return { lines: lines.length, height: lines.length * lh };
  }

  /**
   * A button. Records rect AND label so the layout gate can assert that no NON-LABEL string
   * intersects a button (§3e-3 — the gate was blind to a string sitting inside one).
   */
  function button(ctx, x, y, w, h, label, opts) {
    const o = opts || {};
    const on = o.enabled !== false;
    const hot = !!o.hot;
    panel(ctx, x, y, w, h, 'brass', on ? P.brass : P.brassDim, {
      tint: on ? (hot ? 'rgba(224,187,96,0.30)' : 'rgba(20,26,34,0.42)') : 'rgba(10,13,18,0.66)',
      alpha: 1,
    });
    const r = text(ctx, label, x + w / 2, y + h / 2 + 5, {
      align: 'center', size: o.size || 14, weight: 600,
      fill: on ? (hot ? P.snowLit : P.paper) : '#6a6a68',
    });
    if (rec) rec.buttons.push({ x, y, w, h, label: String(label), textRect: r });
    return { x, y, w, h };
  }

  // ── railway drawing ───────────────────────────────────────────────────────────────────────

  /** A run of track: two rails and sleepers, drawn along a horizontal span. */
  function track(ctx, x1, x2, y, opts) {
    const o = opts || {};
    const sleeper = o.sleeper || '#3a2c20';
    const rail = o.rail || P.steelLit;
    const snowy = o.snow || 0;
    for (let x = x1; x < x2; x += 7) {
      ctx.fillStyle = sleeper;
      ctx.fillRect(x, y - 2, 4, 5);
      if (snowy > 0.2) { ctx.fillStyle = 'rgba(232,241,248,' + Math.min(0.85, snowy) + ')'; ctx.fillRect(x, y - 3, 4, 2); }
    }
    ctx.fillStyle = rail;
    ctx.fillRect(x1, y - 3, x2 - x1, 1);
    ctx.fillRect(x1, y + 2, x2 - x1, 1);
  }

  const CLASS_COLOUR = {
    brass: [P.brass, P.brassLit], crimson: [P.crimson, P.crimsonLit], rust: [P.rust, '#b8813f'],
    // ⛔ THE MINERAL TRAIN WAS AN UNREADABLE SMEAR. `coal` lit at #4a4340 on a dark plate gave the
    //    longest and most consequential train in the game less contrast than any other class, in
    //    the gallery AND in the panel. It stays the darkest of the five — it is coal — but it is
    //    now visible as a train rather than as a shadow.
    coal: [P.coal, '#7d7166'], royal: [P.royal, '#5f74bd'], steel: [P.steel, P.steelLit],
  };

  /**
   * A little train, drawn from its ACTUAL car count so a nine-wagon mineral train is visibly
   * longer than a three-coach local. The length is the mechanic; it has to be visible.
   */
  function train(ctx, x, y, dir, cars, colourKey, opts) {
    const o = opts || {};
    const pair = CLASS_COLOUR[colourKey] || CLASS_COLOUR.brass;
    const body = pair[0], lit = pair[1];
    const carW = 7, gap = 1.5;
    const locoW = 11;
    const s = dir >= 0 ? 1 : -1;
    // Loco
    let cx = x;
    ctx.fillStyle = P.coal;
    ctx.fillRect(cx - (s > 0 ? 0 : locoW), y - 6, locoW, 8);
    ctx.fillStyle = lit;
    ctx.fillRect(cx - (s > 0 ? 0 : locoW), y - 6, locoW, 2);
    // chimney
    ctx.fillStyle = P.ink;
    ctx.fillRect(cx + (s > 0 ? locoW - 4 : -locoW + 2), y - 9, 2, 3);
    if (o.steam) {
      ctx.fillStyle = 'rgba(216,229,240,0.55)';
      ctx.fillRect(cx + (s > 0 ? locoW - 5 : -locoW + 1), y - 13, 4, 3);
    }
    // Cars
    for (let i = 0; i < cars; i++) {
      const ox = (locoW + gap) + i * (carW + gap);
      const bx = s > 0 ? cx + ox : cx - ox - carW;
      ctx.fillStyle = body;
      ctx.fillRect(bx, y - 5, carW, 7);
      ctx.fillStyle = lit;
      ctx.fillRect(bx, y - 5, carW, 1);
      ctx.fillStyle = 'rgba(0,0,0,0.45)';
      ctx.fillRect(bx + carW - 1, y - 5, 1, 7);
    }
    ctx.fillStyle = P.ink;
    const total = locoW + gap + cars * (carW + gap);
    ctx.fillRect(s > 0 ? cx : cx - total, y + 2, total, 1);
  }

  /** A semaphore signal: post, arm, lamp. `clear` drops the arm 45 degrees, as a real one does. */
  function signal(ctx, x, y, clear, opts) {
    const o = opts || {};
    const h = o.height || 22;
    ctx.fillStyle = P.slateLit;
    ctx.fillRect(x, y - h, 2, h);
    ctx.save();
    ctx.translate(x + 1, y - h + 4);
    ctx.rotate(clear ? Math.PI / 5 : 0);
    ctx.fillStyle = clear ? P.greenLit : P.crimsonLit;
    ctx.fillRect(0, -2, 13, 4);
    ctx.fillStyle = P.snowLit;
    ctx.fillRect(9, -2, 2, 4);
    ctx.restore();
    ctx.fillStyle = clear ? P.greenLit : P.crimsonLit;
    ctx.beginPath(); ctx.arc(x + 1, y - h + 10, 2.2, 0, Math.PI * 2); ctx.fill();
  }

  /** A block instrument dial — the brass face that says what a section is doing. */
  function instrument(ctx, x, y, r, state, opts) {
    const o = opts || {};
    ctx.save();
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.clip();
    ctx.fillStyle = plateFill(ctx, 'brass', P.brass);
    ctx.translate(x - r, y - r); ctx.fillRect(0, 0, r * 2, r * 2);
    ctx.restore();
    ctx.fillStyle = 'rgba(10,13,18,0.55)';
    ctx.beginPath(); ctx.arc(x, y, r * 0.72, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = P.brassDim; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(x, y, r - 0.75, 0, Math.PI * 2); ctx.stroke();
    // needle
    const ang = state === 'clear' ? -Math.PI / 2.6 : state === 'occupied' ? Math.PI / 2.6 : 0;
    ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
    ctx.fillStyle = state === 'occupied' ? P.crimsonLit : state === 'clear' ? P.greenLit : P.snow;
    ctx.fillRect(-1, -r * 0.62, 2, r * 0.62);
    ctx.restore();
    ctx.fillStyle = P.brassLit;
    ctx.beginPath(); ctx.arc(x, y, 1.6, 0, Math.PI * 2); ctx.fill();
    if (o.label) text(ctx, o.label, x, y + r + 11, { align: 'center', size: 9, fill: P.snowDeep, weight: 600 });
  }

  /** The bell. `swing` 0..1 animates a stroke. */
  function bell(ctx, x, y, size, swing) {
    const s = size || 14;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(Math.sin(swing * Math.PI) * 0.28);
    ctx.fillStyle = P.brass;
    ctx.beginPath();
    ctx.moveTo(-s * 0.5, s * 0.42);
    ctx.quadraticCurveTo(-s * 0.46, -s * 0.42, 0, -s * 0.46);
    ctx.quadraticCurveTo(s * 0.46, -s * 0.42, s * 0.5, s * 0.42);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = P.brassLit;
    ctx.fillRect(-s * 0.16, -s * 0.52, s * 0.32, s * 0.12);
    ctx.fillStyle = 'rgba(255,255,255,0.22)';
    ctx.fillRect(-s * 0.3, -s * 0.24, s * 0.1, s * 0.5);
    ctx.fillStyle = P.brassDim;
    ctx.fillRect(-s * 0.54, s * 0.42, s * 1.08, s * 0.1);
    ctx.restore();
  }

  /** Falling snow, deterministic in `t` so a captured frame is reproducible. */
  function snowfall(ctx, x, y, w, h, t, density, hash) {
    const n = Math.floor(density * 90);
    for (let i = 0; i < n; i++) {
      const seed = hash(i * 37 + 11);
      const sx = x + (seed % 1000) / 1000 * w;
      const drift = Math.sin((t * 0.0004) + i) * 9;
      const speed = 14 + (seed % 23);
      const sy = y + (((seed % 997) / 997 * h) + t * 0.001 * speed) % h;
      const a = 0.22 + ((seed % 61) / 61) * 0.5;
      ctx.fillStyle = 'rgba(232,241,248,' + a.toFixed(3) + ')';
      ctx.fillRect(sx + drift, sy, 1.4, 1.4);
    }
  }

  return {
    P, FONT, PLATE_NAMES, PLATES,
    loadPlates, missingPlates, plateFill,
    record, recording, pxOf,
    rect, plated, panel, text, wrap, paragraph, button, CLASS_COLOUR,
    track, train, signal, instrument, bell, snowfall,
  };
}));
