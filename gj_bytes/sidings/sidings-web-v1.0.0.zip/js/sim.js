/**
 * sim.js — SIDINGS' simulation. Pure logic: no canvas, no DOM, no audio.
 *
 * Dual-mode (browser global + CommonJS) so `Internal_Ops/` probes drive THE SHIPPED CODE rather
 * than a copy of it.
 *
 * ── THE ONE IDEA ────────────────────────────────────────────────────────────────────────────
 * Every other train game on the shelf is about making the railway BIGGER. This one is about the
 * fact that a single track holds ONE TRAIN AT A TIME. Your capacity is not your mileage, it is
 * your SIGNALLING, and the whole upgrade tree is the real historical ladder that Victorian
 * railways climbed for exactly this reason.
 *
 * ── THE FOUR SYSTEMS (the wing's Gate 4 record), and where each one lives ───────────────────
 *   1 NETWORK    section occupancy + station roads + loop LENGTH ....... canAdmit / roadFor
 *   2 TRAFFIC    the timetable, train classes, lengths, punctuality .... buildTimetable / settle
 *   3 SIGNALLING the ladder; each tier automates the last tier's verb .. canAdmit / autoRoute
 *   4 WEATHER    snow per section, removing capacity you paid for ...... rollWeather / runMinutes
 *
 * They INTERACT, which is the gate's actual requirement: a longer loop (1) lets you accept the
 * mineral contract (2), whose density forces the next signalling tier (3), and a snowfall (4)
 * closes the loop you were going to cross it in, so the contract you took jams your own line.
 *
 * ── THE STAFF IS NOT DECORATION ─────────────────────────────────────────────────────────────
 * On the first two signalling tiers a section is guarded by a PHYSICAL wooden staff. A train may
 * only enter a section from the end where the staff is standing, and the staff goes home on a
 * locomotive, not on a wire. So early SIDINGS forces trains to alternate direction — which is
 * why the player feels the Electric Token purchase in their hands rather than reading it in a
 * tooltip. `tokenReturn` in line.js decides which regime is in force.
 *
 * ── WHY A WRECK DOES NOT RESTART THE GAME ───────────────────────────────────────────────────
 * Wing standing rule (ledger B4): death returns the player to a meaningful checkpoint with
 * progress kept. A wreck ends the DAY, costs the day's earnings and a fine, and leaves every
 * pound of infrastructure you ever bought exactly where it was. The day is the loop; the
 * railway is permanent.
 */
(function (root, factory) {
  const L = (typeof module !== 'undefined' && module.exports) ? require('./line.js') : root.LINE;
  if (typeof module !== 'undefined' && module.exports) module.exports = factory(L);
  else root.SIM = factory(L);
}(typeof self !== 'undefined' ? self : this, function (L) {
  'use strict';

  const SAVE_KEY = 'csaf.sidings.v1';

  // Sim minutes per real second at 1x. A day is 260 sim-minutes ~ 05:00 to 09:20 of a working
  // timetable. ⛔ THE FIGURE THAT USED TO BE HERE — "roughly two and a half minutes at 1x" — WAS
  // WRONG BY 25%: 330 / 1.75 is 188.6 seconds, three minutes nine. A number in a comment is a
  // claim like any other and this one was never divided. MEASURED now, and it is no longer a
  // constant anyway: a day ends when the last train is home, so day one runs 106 clock minutes
  // (61 real seconds at 1x) and only a full timetable reaches the 330 cap.
  const MINUTES_PER_SECOND = 1.75;
  const DAY_MINUTES = 330;
  const DAY_START_MIN = 300; // 05:00, printed as clock time

  // Snow. `exposure` in line.js scales the accumulation; 1.0 is a whiteout on the summit section.
  const SNOW_SLOW_AT = 0.35;   // above this, trains lose time
  const SNOW_CLOSED_AT = 0.85; // above this, the section is impassable until ploughed
  const PLOUGH_CLEARS = 0.75;

  const FINE_WRECK = 900;
  const FINE_BLOCKED = 260;

  // ── seeded PRNG ───────────────────────────────────────────────────────────────────────────
  // Deterministic by construction so a probe run is reproducible and a balance table means
  // something. Never Math.random() anywhere in this file.
  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);

  function clockOf(min) {
    const t = Math.floor(DAY_START_MIN + min);
    const h = Math.floor(t / 60) % 24;
    const m = t % 60;
    return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
  }

  // ── new game ──────────────────────────────────────────────────────────────────────────────
  function newGame(seed) {
    const s = {
      seed: seed === undefined ? 20260908 : seed,
      day: 1,
      money: 260,
      signalTier: 0,
      loops: L.STATIONS.map(() => 0),        // loop tier per station
      doubled: L.SECTIONS.map(() => false),
      snow: L.SECTIONS.map(() => 0),
      unlocked: { local: true, express: false, goods: false, mineral: false, mail: false, plough: false },
      contractsRun: { local: 0, express: 0, goods: 0, mineral: 0, mail: 0, plough: 0 },
      bestDay: 0,
      totalEarned: 0,
      wrecks: 0,
      blockedDays: 0,
      perfectDays: 0,
      won: false,
      wonAtDay: 0,
      day_: null, // the live day, built by startDay()
    };
    return s;
  }

  // ── the timetable ─────────────────────────────────────────────────────────────────────────
  // Traffic grows with the day AND with what the player has unlocked, so density is something
  // they chose rather than something the clock did to them. Deterministic in (seed, day).
  function buildTimetable(s) {
    const rnd = mulberry32((s.seed * 7919) ^ (s.day * 104729));
    const out = [];
    const cap = L.SIGNAL_TIERS[s.signalTier].capacity;

    // Base service: locals shuttling up and down, rising with the day BUT CEILINGED BY THE
    // CAPACITY THE PLAYER HAS ACTUALLY BOUGHT.
    // ⛔ The ceiling is not politeness, it is the difference between a game and a punishment.
    //    Without it `balance.js` measured 9 locals a day against a capacity of 2 from day 18
    //    on: every campaign drowned in cancellations it had no legal way to prevent, and the
    //    day's outcome stopped depending on any decision the player made. Demand may outrun
    //    capacity — that is the pressure — but it may not outrun it without limit.
    const locals = clamp(2 + Math.floor(s.day / 2), 2, 2 + cap);
    // ⛔ THE SPREAD IS A FUNCTION OF HOW MANY TRAINS THERE ARE, NOT OF THE DAY'S LENGTH. Spreading
    //    every timetable across the whole 330-minute day put day one's two locals at 08 and 153,
    //    which is a minute and a half of empty valley between them at 1x. A light day should be a
    //    SHORT day, not a sparse one.
    // ⛔⛔ AND THE FIRST ATTEMPT AT THIS BROKE THE ENDING. `40 + locals * 24` compressed the HEAVY
    //    days too, so a 19-train day worked 6 of them and the campaign stopped winning at all —
    //    measured over 140 days, `onTime >= 10` was met ZERO times where it used to be met on day
    //    58 (`_probe_win_window.js`, and a one-variable A/B put it back at day 67 the moment the
    //    old spread returned). At `locals * 42` every day with 7 or more locals hits the cap and
    //    is IDENTICAL to before, so only the light early days compress. A pacing fix that changes
    //    the endgame is not a pacing fix.
    const spread = Math.min(DAY_MINUTES - 40, locals * 42);
    for (let i = 0; i < locals; i++) {
      const dir = i % 2 === 0 ? L.UP : L.DOWN;
      out.push(makeService(rnd, 'local', dir, 8 + i * spread / Math.max(1, locals)));
    }
    // Everything else only appears once the player has bought the right to run it.
    if (s.unlocked.express) {
      const n = clamp(1 + Math.floor(s.day / 6), 1, Math.max(1, Math.floor(cap / 2)));
      for (let i = 0; i < n; i++) out.push(makeService(rnd, 'express', i % 2 === 0 ? L.UP : L.DOWN, 26 + i * 74 + rnd() * 16));
    }
    if (s.unlocked.goods) {
      const n = clamp(1 + Math.floor(s.day / 7), 1, Math.max(1, Math.floor((cap - 1) / 2)));
      for (let i = 0; i < n; i++) out.push(makeService(rnd, 'goods', i % 2 === 0 ? L.DOWN : L.UP, 40 + i * 88 + rnd() * 20));
    }
    if (s.unlocked.mineral) {
      const n = clamp(1 + Math.floor(s.day / 9), 1, Math.max(1, Math.floor((cap - 2) / 2)));
      for (let i = 0; i < n; i++) out.push(makeService(rnd, 'mineral', L.DOWN, 58 + i * 92 + rnd() * 18));
    }
    if (s.unlocked.mail) {
      out.push(makeService(rnd, 'mail', L.UP, 96 + rnd() * 20));
      if (s.day >= 14 && cap >= 5) out.push(makeService(rnd, 'mail', L.DOWN, 240 + rnd() * 18));
    }
    // A plough only runs when the player pays for one at the yard; see `orderPlough`.

    out.sort((a, b) => a.due - b.due);
    out.forEach((t, i) => { t.id = i + 1; });
    // Capacity is a promise the timetable keeps: never schedule more simultaneous departures
    // than the signalling could conceivably carry, or the day is unwinnable through no decision
    // of the player's. ⚠️ This is a FLOOR on fairness, not a difficulty dial.
    return { services: out, cap };
  }

  function makeService(rnd, clsId, dir, due) {
    const cls = L.classOf(clsId);
    const origin = dir === L.UP ? 0 : L.STATIONS.length - 1;
    const dest = dir === L.UP ? L.STATIONS.length - 1 : 0;
    return {
      id: 0, cls: clsId, dir, origin, dest,
      due: Math.round(due),
      cars: cls.cars,
      // Booked time is generous enough that a clean run is on time and a single bad cross is not
      // instantly ruinous — the fine curve does the teaching, not an impossible schedule.
      booked: Math.round(runTimeAll(clsId) * 1.55) + 20,
    };
  }

  function runTimeAll(clsId) {
    let t = 0;
    for (const sec of L.SECTIONS) t += baseRunTime(clsId, sec.id, 0);
    return t;
  }

  /** Minutes for `clsId` to traverse section `secId` under `snow` (0..1). */
  function baseRunTime(clsId, secId, snow) {
    const cls = L.classOf(clsId);
    const sec = L.SECTIONS[secId];
    const grade = cls.heavy ? sec.grade : 1 + (sec.grade - 1) * 0.25;
    let t = (sec.lengthKm / cls.speed) * grade;
    if (snow > SNOW_SLOW_AT) {
      // Snow costs time smoothly from the slow threshold, so the player feels it coming on
      // rather than falling off a cliff. The cliff is SNOW_CLOSED_AT, which is a separate rule.
      t *= 1 + (snow - SNOW_SLOW_AT) * 1.9;
    }
    return t;
  }

  // ── starting a day ────────────────────────────────────────────────────────────────────────
  function startDay(s) {
    const tt = buildTimetable(s);
    const trains = tt.services.map((sv) => ({
      id: sv.id, cls: sv.cls, dir: sv.dir, origin: sv.origin, dest: sv.dest,
      due: sv.due, booked: sv.booked, cars: sv.cars,
      state: 'booked',        // booked -> standing -> running -> arrived | wrecked
      at: sv.origin,          // station id while standing
      road: 'main',           // 'main' | 'loop' | 'yard'
      nextRoad: null,         // the road the player has set for the station ahead
      section: -1,
      progress: 0,
      runTime: 0,
      startedAt: -1,
      arrivedAt: -1,
      delay: 0,
      earned: 0,
      offered: false,         // the bell has been rung for this train's next move
    }));

    s.day_ = {
      clock: 0,
      trains,
      // occupancy: sectionOcc[i] = array of train ids in that section (1, or 2 if doubled)
      sectionOcc: L.SECTIONS.map(() => []),
      // staff position per section: the station id that currently holds the staff.
      // Both staffs start at the down end, which is where the engine shed is.
      staffAt: L.SECTIONS.map((sec) => sec.from),
      wreck: null,
      blocked: false,
      events: [],
      revenue: 0,
      fines: 0,
      onTime: 0,
      late: 0,
      ploughOrdered: false,
      finished: false,
    };
    return s.day_;
  }

  // ── occupancy helpers ─────────────────────────────────────────────────────────────────────

  /** Trains standing at station `st` on road `road`. Termini have yards and never fill up. */
  function occupantsAt(d, st, road) {
    return d.trains.filter((t) => (t.state === 'standing') && t.at === st && t.road === road);
  }

  /**
   * Is `road` at station `st` free for a train of `cars` length?
   * ⛔ The loop LENGTH check is the point of the whole game: a train longer than the loop does
   *    not "fit badly", it does not fit at all.
   */
  function roadFree(s, d, st, road, cars, ignoreTrainId) {
    const station = L.STATIONS[st];
    if (station.terminus) return true; // yard roads
    if (road === 'loop') {
      const tier = L.LOOP_TIERS[s.loops[st]];
      if (!tier || tier.holds === 0) return false;
      if (cars > tier.holds) return false;
    }
    return occupantsAt(d, st, road).filter((t) => t.id !== ignoreTrainId).length === 0;
  }

  /** Every road at `st` that would physically accept a train of `cars` length, free or not. */
  function roadsFor(s, st, cars) {
    const station = L.STATIONS[st];
    if (station.terminus) return ['yard'];
    const out = ['main'];
    const tier = L.LOOP_TIERS[s.loops[st]];
    if (tier && tier.holds >= cars) out.push('loop');
    return out;
  }

  /**
   * How many trains are OUT ON THE RUNNING LINE right now.
   *
   * ⛔ A train standing in the yard at a terminus is NOT on the line — it is waiting to be let
   *    on to it. Counting it was the first defect `balance.js` found: at One Engine In Steam
   *    (capacity 1) the first train of the day counted ITSELF, so `canAdmit` refused it, so
   *    nothing ever moved and all 30 days of all 3 campaigns ended BLOCKED with zero revenue.
   *    A capacity rule must count the occupants of the thing it is limiting, never the applicant.
   */
  function trainsOnLine(d) {
    return d.trains.filter((t) => t.state === 'running'
      || (t.state === 'standing' && !L.STATIONS[t.at].terminus)).length;
  }

  function sectionCapacity(s, secId) { return s.doubled[secId] ? 2 : 1; }

  /** The section a train at station `at` would enter next, heading to `dest`. -1 if none. */
  function nextSection(t) {
    if (t.at === t.dest) return -1;
    return t.dir === L.UP ? t.at : t.at - 1;
  }

  // ── THE ADMISSION RULE — the single most important function in the game ───────────────────
  /**
   * May this train be cleared into the section ahead? Returns { ok, reason, wreck }.
   *
   * ⛔ EVERY REFUSAL NAMES ITSELF. Master §2b: a guard that fails closed silently is
   *    indistinguishable from the condition it guards against, and the only reason the
   *    lanternbound resume bug was ever found is that every refusal recorded a reason.
   * ⛔ `wreck: true` is NOT a refusal — it is the game letting the player make the mistake.
   *    Before the Interlocking Frame is bought, pulling a signal into an occupied section is
   *    exactly what a tired Victorian signalman could do, and the consequence is the game.
   */
  function canAdmit(s, d, t) {
    const tier = L.SIGNAL_TIERS[s.signalTier];
    if (t.state !== 'standing') return { ok: false, reason: 'that train is not standing at a signal' };
    const secId = nextSection(t);
    if (secId < 0) return { ok: false, reason: 'that train is already at its destination' };
    const sec = L.SECTIONS[secId];

    // 4 WEATHER — a closed section is closed to everything except the plough that clears it.
    if (s.snow[secId] >= SNOW_CLOSED_AT && t.cls !== 'plough') {
      return { ok: false, reason: sec.name + ' is blocked by snow. A plough must go through first.' };
    }

    // 3 SIGNALLING — the line-wide capacity of the current tier.
    // Only a train leaving a TERMINUS adds one to the line; a train already out there moving on
    // from an intermediate station does not change the count, so capacity never strands it.
    if (L.STATIONS[t.at].terminus && trainsOnLine(d) >= tier.capacity) {
      return {
        ok: false,
        reason: tier.name + ' allows ' + tier.capacity + ' train' + (tier.capacity === 1 ? '' : 's')
          + ' on the line at once, and there ' + (trainsOnLine(d) === 1 ? 'is 1' : 'are ' + trainsOnLine(d)) + '.',
      };
    }

    // 3 SIGNALLING — the physical staff, on the first two tiers only.
    if (tier.tokenReturn === 'carried') {
      const where = d.staffAt[secId];
      if (where === -1) {
        // The staff is riding through the section on the train that is in there. Nothing may
        // follow it, and that is the whole point of a staff.
        return { ok: false, reason: 'the staff for ' + sec.name + ' is on the train in the section.' };
      }
      if (where !== t.at) {
        return {
          ok: false,
          reason: 'the staff for ' + sec.name + ' is at ' + L.STATIONS[where].name
            + '. It has to be carried back before a train can go the other way.',
        };
      }
    }

    // 1 NETWORK — the section itself.
    const occ = d.sectionOcc[secId];
    if (occ.length >= sectionCapacity(s, secId)) {
      const other = d.trains.find((x) => x.id === occ[0]);
      if (tier.interlocked) {
        return { ok: false, reason: 'the frame is locked: ' + sec.name + ' is occupied by ' + label(other) + '.' };
      }
      return {
        ok: true, wreck: true,
        reason: 'SIGNAL PULLED INTO AN OCCUPIED SECTION',
        against: other ? other.id : 0,
        headOn: other ? other.dir !== t.dir : false,
      };
    }
    if (s.doubled[secId] && occ.length === 1) {
      // A doubled section takes one train each way; two the same way still conflict.
      const other = d.trains.find((x) => x.id === occ[0]);
      if (other && other.dir === t.dir) {
        if (tier.interlocked) return { ok: false, reason: 'the frame is locked: the ' + (t.dir === L.UP ? 'up' : 'down') + ' road of ' + sec.name + ' is occupied.' };
        return { ok: true, wreck: true, reason: 'SIGNAL PULLED INTO AN OCCUPIED ROAD', against: other.id, headOn: false };
      }
    }

    return { ok: true, wreck: false };
  }

  function label(t) {
    if (!t) return 'another train';
    return L.classOf(t.cls).name + ' ' + t.id;
  }

  // ── the player's verbs ────────────────────────────────────────────────────────────────────

  /** Pull the signal. Returns { ok, reason, wreck }. */
  function admit(s, d, trainId) {
    const t = d.trains.find((x) => x.id === trainId);
    if (!t) return { ok: false, reason: 'no such train' };
    const v = canAdmit(s, d, t);
    if (!v.ok) return v;

    const secId = nextSection(t);
    if (v.wreck) {
      const other = d.trains.find((x) => x.id === v.against);
      d.wreck = {
        section: secId, a: t.id, b: v.against, headOn: !!v.headOn,
        at: d.clock,
        text: v.headOn
          ? label(t) + ' met ' + label(other) + ' head on in ' + L.SECTIONS[secId].name + '.'
          : label(t) + ' ran into the back of ' + label(other) + ' in ' + L.SECTIONS[secId].name + '.',
      };
      t.state = 'wrecked';
      if (other) other.state = 'wrecked';
      d.events.push({ min: d.clock, kind: 'wreck', text: d.wreck.text });
      return { ok: true, wreck: true, reason: d.wreck.text };
    }

    // Leave the station road, enter the section.
    t.state = 'running';
    t.section = secId;
    t.progress = 0;
    t.runTime = baseRunTime(t.cls, secId, s.snow[secId]);
    if (t.startedAt < 0) t.startedAt = d.clock;
    d.sectionOcc[secId].push(t.id);
    if (L.SIGNAL_TIERS[s.signalTier].tokenReturn === 'carried') {
      // The staff goes with the train, so it is now at neither end until the train is out.
      d.staffAt[secId] = -1;
    }
    d.events.push({ min: d.clock, kind: 'enter', train: t.id, text: label(t) + ' entering ' + L.SECTIONS[secId].name + '.' });
    return { ok: true, wreck: false, bell: L.classOf(t.cls).bell };
  }

  /** Set the points for the road this train will take at the station ahead. */
  function setRoad(s, d, trainId, road) {
    const t = d.trains.find((x) => x.id === trainId);
    if (!t) return { ok: false, reason: 'no such train' };
    const ahead = t.dir === L.UP ? t.at + (t.state === 'running' ? 0 : 1) : t.at - (t.state === 'running' ? 0 : 1);
    const target = t.state === 'running' ? (t.dir === L.UP ? L.SECTIONS[t.section].to : L.SECTIONS[t.section].from) : ahead;
    if (target < 0 || target >= L.STATIONS.length) return { ok: false, reason: 'no station ahead' };
    if (road === 'loop') {
      const tier = L.LOOP_TIERS[s.loops[target]];
      if (!tier || tier.holds === 0) return { ok: false, reason: 'there is no loop at ' + L.STATIONS[target].name + '.' };
      if (t.cars > tier.holds) {
        return {
          ok: false,
          reason: L.STATIONS[target].name + "'s " + tier.name + ' holds ' + tier.holds
            + ' carriages. ' + label(t) + ' is ' + t.cars + '.',
        };
      }
    }
    t.nextRoad = road;
    return { ok: true };
  }

  /**
   * SHUNT — move a train that is STANDING at a station from the main to the loop, or back.
   *
   * ⛔ THIS VERB EXISTS BECAUSE THE GAME WAS UNPLAYABLE WITHOUT IT, and `balance.js` is what
   *    said so: 25 days of 45 ended with the line deadlocked. The cause was not the economy and
   *    not the policy — it was that `setRoad` only chooses a road at the moment a train is
   *    ADMITTED, so once a train was standing on the main it could never be got out of the way.
   *    Two opposing trains on two mains with a section between them was permanent, and no
   *    decision the player could make would clear it. A single line without a shunt is a puzzle
   *    with unreachable states; a real signalman would put the pick-up goods inside the loop and
   *    let the express by, so now so can the player.
   * ⚠️ Shunting costs the train two minutes of delay, so it is a recovery move with a price, not
   *    a free undo.
   */
  /** Could this train be shunted right now? Same rules as `shunt`, asked without doing it. */
  function canShunt(s, d, t) {
    if (!t || t.state !== 'standing') return false;
    if (L.STATIONS[t.at].terminus) return false;
    const want = t.road === 'loop' ? 'main' : 'loop';
    if (want === 'loop') {
      const tier = L.LOOP_TIERS[s.loops[t.at]];
      if (!tier || tier.holds === 0 || t.cars > tier.holds) return false;
    }
    return roadFree(s, d, t.at, want, t.cars, t.id);
  }

  function shunt(s, d, trainId) {
    const t = d.trains.find((x) => x.id === trainId);
    if (!t) return { ok: false, reason: 'no such train' };
    if (t.state !== 'standing') return { ok: false, reason: 'only a train standing at a station can be shunted' };
    if (L.STATIONS[t.at].terminus) return { ok: false, reason: L.STATIONS[t.at].name + ' is a terminus — its yard roads are not a loop' };
    const want = t.road === 'loop' ? 'main' : 'loop';
    if (want === 'loop') {
      const tier = L.LOOP_TIERS[s.loops[t.at]];
      if (!tier || tier.holds === 0) return { ok: false, reason: 'there is no loop at ' + L.STATIONS[t.at].name + '.' };
      if (t.cars > tier.holds) {
        return { ok: false, reason: L.STATIONS[t.at].name + "'s " + tier.name + ' holds ' + tier.holds + ' carriages. ' + label(t) + ' is ' + t.cars + '.' };
      }
    }
    if (!roadFree(s, d, t.at, want, t.cars, t.id)) {
      return { ok: false, reason: 'the ' + want + ' at ' + L.STATIONS[t.at].name + ' is occupied.' };
    }
    t.road = want;
    t.shunted = (t.shunted || 0) + 1;
    t.due -= 2; // two minutes of shunting, charged as lateness at settle()
    d.events.push({ min: d.clock, kind: 'shunt', train: t.id, text: label(t) + ' shunted to the ' + want + ' at ' + L.STATIONS[t.at].name + '.' });
    return { ok: true, road: want };
  }

  // ── the clock ─────────────────────────────────────────────────────────────────────────────
  /**
   * Advance the day by `dtMin` sim-minutes. Returns a list of events for the renderer/audio.
   *
   * ⛔ This function does NOT decide anything the player could have decided. Trains only move
   *    where a signal was pulled. The one automatic behaviour is `autoRoute`, and it exists
   *    only when the player has BOUGHT it (tier 6) — that is the idle layer, and it is bought.
   */
  function runMinutes(s, d, dtMin) {
    if (d.finished) return [];
    const fired = [];
    d.clock += dtMin;

    // Book trains on at their due time: they appear standing at their origin.
    for (const t of d.trains) {
      if (t.state === 'booked' && d.clock >= t.due) {
        t.state = 'standing';
        t.road = L.STATIONS[t.at].terminus ? 'yard' : 'main';
        fired.push({ kind: 'booked', train: t.id, text: label(t) + ' is ready at ' + L.STATIONS[t.at].name + '.' });
      }
    }

    // Move running trains.
    for (const t of d.trains) {
      if (t.state !== 'running') continue;
      t.progress += dtMin / Math.max(0.0001, t.runTime);
      if (t.progress < 1) continue;

      const sec = L.SECTIONS[t.section];
      const arriveAt = t.dir === L.UP ? sec.to : sec.from;
      const wantRoad = t.nextRoad || 'main';
      const cars = t.cars;

      // Does the far end have a road for it? If not, the train stands IN SECTION at the home
      // signal — realistic, and the source of every deadlock in the game.
      let road = null;
      if (L.STATIONS[arriveAt].terminus) road = 'yard';
      else if (roadFree(s, d, arriveAt, wantRoad, cars, t.id)) road = wantRoad;
      else if (wantRoad !== 'main' && roadFree(s, d, arriveAt, 'main', cars, t.id)) road = 'main';
      else if (wantRoad === 'main' && roadFree(s, d, arriveAt, 'loop', cars, t.id)) road = 'loop';

      if (road === null) {
        t.progress = 1; // held at the home signal, still occupying the section
        if (!t.heldLogged) {
          t.heldLogged = true;
          fired.push({ kind: 'held', train: t.id, text: label(t) + ' is held outside ' + L.STATIONS[arriveAt].name + ': no road is free.' });
        }
        continue;
      }
      t.heldLogged = false;

      // Clear the section.
      d.sectionOcc[t.section] = d.sectionOcc[t.section].filter((id) => id !== t.id);
      if (L.SIGNAL_TIERS[s.signalTier].tokenReturn === 'carried') d.staffAt[t.section] = arriveAt;
      t.at = arriveAt;
      t.road = road;
      t.section = -1;
      t.progress = 0;
      t.nextRoad = null;

      if (arriveAt === t.dest) {
        t.state = 'arrived';
        t.arrivedAt = d.clock;
        settle(s, d, t);
        fired.push({ kind: 'arrived', train: t.id, text: label(t) + ' arrived at ' + L.STATIONS[arriveAt].name + '.' });
      } else {
        t.state = 'standing';
        fired.push({ kind: 'standing', train: t.id, text: label(t) + ' standing at ' + L.STATIONS[arriveAt].name + '.' });
      }
    }

    // The bought automation.
    if (L.SIGNAL_TIERS[s.signalTier].auto) autoRoute(s, d, fired);

    // ⛔⛔ A DAY ENDS WHEN THE WORK IS DONE, NOT WHEN THE CLOCK RUNS OUT.
    //    Day one books two trains, due at 08 and 153 of a 330-minute day, and a day is 188 real
    //    seconds at 1x. So the first thing a new player did was work four clicks, then watch an
    //    empty valley for about ninety seconds with a blank status line, then work four more.
    //    An independent reviewer called it a blocking defect and was right: for a free browser
    //    game the first ninety seconds are the whole audition. Nothing can happen after the last
    //    train is home — no service is booked, no snow falls mid-day — so sitting there is not
    //    tension, it is an empty room. The clock cap stays as the outer bound.
    const allDone = d.trains.length > 0
      && d.trains.every((t) => t.state === 'arrived' || t.state === 'cancelled');
    if ((d.clock >= DAY_MINUTES || allDone) && !d.finished) endDay(s, d);
    else if (deadlocked(s, d)) {
      d.blocked = true;
      d.events.push({ min: d.clock, kind: 'blocked', text: 'THE LINE IS BLOCKED. Nothing can move.' });
      endDay(s, d);
    }
    return fired;
  }

  /** Money for a finished run, and the punctuality fine. */
  function settle(s, d, t) {
    const cls = L.classOf(t.cls);
    const actual = t.arrivedAt - t.due;
    const late = Math.max(0, actual - t.booked);
    t.delay = late;
    // The fine is a FRACTION of the fare, never an absolute figure — wing §3f-1 measured that an
    // absolute recurring cost scales the wrong way and made SWALLET unplayable twice.
    const penaltyFrac = clamp(late * 0.018 * cls.punctuality, 0, 1.10);
    const earned = Math.round(cls.fare * (1 - penaltyFrac));
    t.earned = earned;
    if (earned >= 0) d.revenue += earned; else d.fines += -earned;
    if (late <= 0) d.onTime++; else d.late++;
  }

  /**
   * Tier 6: the panel sets the road itself for anything it can prove is safe.
   * ⛔ It never takes a decision that could wreck: it only ever admits when `canAdmit` says the
   *    move is clean. The player still has to buy loops and choose contracts; what they stop
   *    doing is the clicking.
   */
  /**
   * ⛔⛔ ARS MUST KEEP THE MEET RULES THE PLAYER KEEPS, OR THE UPGRADE MAKES THE RAILWAY WORSE.
   *    The first version of this asked only `canAdmit` — "is the section clear right now?" — and
   *    then admitted. That is the greedy rule, and on a single line it fills both roads at a
   *    passing place while a train is already inside the section beyond, which is the one lock
   *    the whole game is built around. The player learns not to do it by tier 3. A 4,000 upgrade
   *    that un-learns it is a punishment sold as a reward, and `balance.js` was measuring the
   *    result as blocked days AFTER the purchase.
   *
   *    So ARS reserves a road for every train already committed to arriving the other way, and
   *    holds a train in the yard unless there is somewhere to cross what is already out. Same two
   *    rules a good signalman works to; the machine just never gets tired.
   */
  function autoRoute(s, d, fired) {
    // How many opposing trains are already inside a section and committed to arriving at `far`?
    const inboundOpposing = (t, far) => d.trains.filter((x) => x.id !== t.id && x.state === 'running'
      && x.dir !== t.dir
      && (x.dir === L.UP ? L.SECTIONS[x.section].to : L.SECTIONS[x.section].from) === far).length;

    const standing = d.trains.filter((t) => t.state === 'standing').sort((a, b) => {
      const ao = L.STATIONS[a.at].terminus ? 1 : 0;
      const bo = L.STATIONS[b.at].terminus ? 1 : 0;
      if (ao !== bo) return ao - bo;      // trains already on the line clear first
      const pa = L.classOf(a.cls).punctuality, pb = L.classOf(b.cls).punctuality;
      if (pb !== pa) return pb - pa;      // then the Mail, always
      return a.due - b.due;
    });

    for (const t of standing) {
      const secId = nextSection(t);
      if (secId < 0) continue;
      const far = t.dir === L.UP ? L.SECTIONS[secId].to : L.SECTIONS[secId].from;

      if (!L.STATIONS[far].terminus) {
        // Reserve a road for the meet.
        const roads = roadsFor(s, far, t.cars);
        const free = roads.filter((r) => roadFree(s, d, far, r, t.cars, t.id)).length;
        const inbound = inboundOpposing(t, far);
        if (free === 0 || free - 1 < inbound) continue;
        // Stand it in the loop if anything is coming the other way.
        const opposing = d.trains.some((x) => x.id !== t.id && x.dir !== t.dir
          && (x.state === 'standing' || x.state === 'running'));
        if (opposing && roadFree(s, d, far, 'loop', t.cars, t.id)) t.nextRoad = 'loop';
      }

      // Do not put a train on the line unless there is room to cross what is already out.
      if (L.STATIONS[t.at].terminus) {
        const opposing = d.trains.filter((x) => x.id !== t.id
          && (x.state === 'standing' || x.state === 'running') && x.dir !== t.dir).length;
        if (opposing > 0) {
          let places = 0;
          for (const st of L.STATIONS) {
            if (st.terminus) continue;
            if (roadsFor(s, st.id, t.cars).some((r) => roadFree(s, d, st.id, r, t.cars, t.id))) places++;
          }
          if (places <= opposing) continue;
        }
      }

      const v = canAdmit(s, d, t);
      if (v.ok && !v.wreck) {
        const r = admit(s, d, t.id);
        // ⛔ THE SIXTH ONE, and it fires at the tier the whole ladder aims at. Five event strings
        //    were punctuated and this one was missed; a reviewer read the source rather than the
        //    diff and found it.
        if (r.ok && !r.wreck) fired.push({ kind: 'auto', train: t.id, bell: r.bell, text: 'ARS cleared ' + label(t) + '.' });
      }
    }
  }

  /**
   * Is the line deadlocked — every remaining train unable to move, ever?
   * ⛔ Deliberately conservative: it must be true that NO train has any legal move AND at least
   *    one train is still on the line. A day that merely looks stuck to the player is not
   *    declared blocked; the clock is allowed to run out instead.
   */
  function deadlocked(s, d) {
    const live = d.trains.filter((t) => t.state === 'standing' || t.state === 'running');
    if (live.length === 0) return false;
    // ⛔⛔ A TRAIN THAT HAS NOT COME ON DUTY YET IS NOT A DEADLOCK, IT IS A TIMETABLE.
    //    On the staff tiers the line legitimately STOPS until a train comes the other way and
    //    carries the staff back — that is the whole of single-line working, not a failure. With
    //    this line missing, one train waiting at Lowgarth for a staff that was up at Cray Bridge
    //    was declared BLOCKED at 05:54 on an entirely empty railway, and it cost 48 days of 55
    //    across every seed. The tell was that all five seeds returned byte-identical results:
    //    the day was dying before the RNG could matter. A day is blocked only when nothing can
    //    move AND nothing more is coming.
    if (d.trains.some((t) => t.state === 'booked')) return false;
    // Anything still moving is not a deadlock.
    if (live.some((t) => t.state === 'running' && t.progress < 1)) return false;
    // Anything still to come can free things up by arriving; but a booked train cannot move a
    // standing one, so only count trains already out.
    for (const t of live) {
      if (t.state === 'running') {
        // ⛔⛔ A TRAIN HELD AT A HOME SIGNAL IS A TRAIN WITH A MOVE AVAILABLE THE INSTANT A ROAD
        //    FREES, AND THIS BRANCH DID NOT EXIST. The loop below only ever interrogated
        //    STANDING trains, so a day whose last live train was held in section was declared
        //    BLOCKED even with every station on the line empty — `_deadlock_dump.js` printed
        //    exactly that: one held local, five empty stations, four clear sections, day over
        //    and fined. It happened whenever the train occupying the far station cleared later
        //    in the same tick than the held train was examined. A false BLOCKED costs the player
        //    the day just as surely as a real one, and it cost 12 of 50 days here.
        const sec = L.SECTIONS[t.section];
        const far = t.dir === L.UP ? sec.to : sec.from;
        if (L.STATIONS[far].terminus) return false;
        for (const r of roadsFor(s, far, t.cars)) {
          if (roadFree(s, d, far, r, t.cars, t.id)) return false;
        }
        continue;
      }
      if (t.state !== 'standing') continue;
      const v = canAdmit(s, d, t);
      // ⛔ A WRECKING MOVE IS NOT A MOVE. This originally read `if (v.ok)`, and `canAdmit`
      //    returns ok:true with wreck:true for the un-interlocked signal-into-an-occupied-section
      //    case — so a line that could only be cleared by crashing two trains counted as a line
      //    that could still move. `balance.js` measured the consequence and it was invisible in
      //    every summary column: the day did not end BLOCKED, it silently ran out of clock with
      //    2 arrivals out of 14 while the "blocked" counter read 0. A player with nothing but a
      //    crash available is blocked, and the day should say so.
      if (v.ok && !v.wreck) return false;
      // A shunt is a move too — the line is not blocked if a train can still be got out of the
      // way. ⛔ Omitting this would declare a deadlock the player could personally have cleared.
      if (canShunt(s, d, t)) return false;
    }
    // A held-in-section train frees when a road frees; if nothing can move, nothing will.
    return true;
  }

  function endDay(s, d) {
    if (d.finished) return;
    d.finished = true;
    // Anything that never arrived earns nothing and costs a cancellation.
    for (const t of d.trains) {
      if (t.state === 'standing' || t.state === 'running' || t.state === 'booked') {
        // Keep what it WAS. A post-mortem cannot tell a cancelled-from-booked train from a
        // cancelled-from-standing one, and _deadlock_dump.js read the difference wrongly.
        t.cancelledFrom = t.state;
        t.state = 'cancelled';
        d.fines += Math.round(L.classOf(t.cls).fare * 0.18);
      }
    }
    if (d.wreck) { d.fines += FINE_WRECK; s.wrecks++; }
    else if (d.blocked) { d.fines += FINE_BLOCKED; s.blockedDays++; }
    d.net = d.revenue - d.fines;
    // ⛔ THE FLOOR AT ZERO IS A DESIGN RULE, NOT A ROUNDING CONVENIENCE. The wing's standing rule
    //    (ledger B4) is that failure returns the player to a meaningful checkpoint with progress
    //    kept. Unbounded debt is the opposite: `balance.js` measured -10,192 and then -2,663, and
    //    from there no purchase — including the snowplough that would have reopened the line —
    //    was ever affordable again. A bad day now costs you the day, never the campaign.
    s.money = Math.max(0, s.money + d.net);
    s.totalEarned += Math.max(0, d.net);
    if (d.net > s.bestDay) s.bestDay = d.net;
    if (!d.wreck && !d.blocked && d.late === 0 && d.onTime > 0) s.perfectDays++;
    for (const t of d.trains) if (t.state === 'arrived') s.contractsRun[t.cls]++;
  }

  // ── between days: weather, then the yard ──────────────────────────────────────────────────
  function rollWeather(s) {
    const rnd = mulberry32((s.seed * 31337) ^ (s.day * 6151));
    // A winter that gets worse. `severity` climbs to 1 by about day 20 and stays there, so the
    // weather is a rising floor under the whole economy rather than a random spike.
    // ⛔ The ramp is capped WELL BELOW 1 and the thaw is fast, because a section that closes and
    //    stays closed is a permanent penalty with no answer the player can buy — the exact shape
    //    wing §3f names as the thing that makes a campaign unplayable. `balance.js` measured it:
    //    snow pinned at 1.00 from day 21 and every remaining day ended BLOCKED. Snow must be a
    //    recurring bill, never a wall.
    const severity = clamp(0.16 + s.day * 0.028, 0, 0.78);
    const fell = [];
    for (const sec of L.SECTIONS) {
      const roll = rnd();
      let add = 0;
      if (roll < 0.16 + severity * 0.30) add = (0.08 + rnd() * 0.34) * sec.exposure * severity;
      s.snow[sec.id] = clamp(s.snow[sec.id] * 0.70 + add, 0, 1);
      if (add > 0.01) fell.push({ section: sec.id, add });
    }
    return fell;
  }

  function advanceDay(s) {
    s.day++;
    s.day_ = null;
    return rollWeather(s);
  }

  // ── the yard (the shop) ───────────────────────────────────────────────────────────────────
  // ⛔ Every cap and every prerequisite is ENFORCED HERE, in buy(), never merely declared in a
  //    table — wing §3h rule 1: ANAGAMA's kiln cap lived in buy(), not in the SHOP array, and a
  //    probe that read the array proved nothing.
  function catalogue(s) {
    const out = [];
    const nextTier = L.SIGNAL_TIERS[s.signalTier + 1];
    if (nextTier) {
      out.push({
        key: 'signal', id: 'signal:' + nextTier.id, kind: 'signal',
        name: nextTier.name, cost: nextTier.cost, blurb: nextTier.blurb,
        detail: 'Capacity ' + L.SIGNAL_TIERS[s.signalTier].capacity + ' → ' + nextTier.capacity + ' trains on the line'
          + (nextTier.sees && !L.SIGNAL_TIERS[s.signalTier].sees ? ' · shows train positions' : '')
          + (nextTier.interlocked && !L.SIGNAL_TIERS[s.signalTier].interlocked ? ' · refuses an unsafe signal' : '')
          + (nextTier.auto && !L.SIGNAL_TIERS[s.signalTier].auto ? ' · sets routes for you' : '')
          + (nextTier.tokenReturn === 'electric' && L.SIGNAL_TIERS[s.signalTier].tokenReturn === 'carried' ? ' · no more carrying the staff back' : ''),
      });
    }
    for (const st of L.STATIONS) {
      if (!st.canLoop) continue;
      const cur = s.loops[st.id];
      const nx = L.LOOP_TIERS[cur + 1];
      if (!nx) continue;
      out.push({
        key: 'loop', id: 'loop:' + st.id, kind: 'loop', station: st.id,
        name: st.name + ' — ' + nx.name, cost: nx.cost,
        // ⛔ SEVEN OF THIRTEEN CATALOGUE ENTRIES SHARED TWO SENTENCES. Three loop cards read "A
        //    second road at X. Two trains can finally pass each other here." verbatim and three
        //    more read "Lengthen X's loop...", so the yard looked like a copy-paste and gave the
        //    player nothing to choose between. Each station sits between two named sections with
        //    different gradients, and THAT is what decides which loop is worth buying first.
        blurb: (cur === 0
          ? 'A second road at ' + st.name + ', so two trains can finally pass each other here'
          : 'A longer road at ' + st.name + ', so a longer train can be crossed here')
          + ', between ' + L.SECTIONS[st.id - 1].name + ' and ' + L.SECTIONS[st.id].name + '.',
        detail: 'holds ' + (L.LOOP_TIERS[cur].holds || 0) + ' → ' + nx.holds + ' carriages · '
          + (nx.holds >= 9 ? 'takes the mineral train' : nx.holds >= 6 ? 'takes the goods, not the mineral'
            : 'takes a local or an express'),
      });
    }
    const stock = [
      { id: 'express', need: 1, cost: 390, name: 'Express working', blurb: 'A fast passenger service. It pays well and it will not wait.' },
      { id: 'goods',   need: 1, cost: 480, name: 'Pick-up goods',   blurb: 'Six wagons, slow, and it does not fit in a short loop.' },
      { id: 'mineral', need: 2, cost: 1250, name: 'Mineral contract', blurb: 'Nine wagons off the fell. The best money on the line and the worst thing to have to cross.' },
      { id: 'mail',    need: 3, cost: 1700, name: 'The Mail',        blurb: 'The travelling post office. Delay it and the fine is four times any other train\'s.' },
    ];
    for (const it of stock) {
      if (s.unlocked[it.id]) continue;
      // ⛔ ONE NOUN PER THING, INSIDE ONE CARD. The pick-up goods card read "Six wagons, slow" in
      //    its blurb and "6 carriages · fare 132" in its footnote — two words for one number, four
      //    lines apart. Freight runs in WAGONS and passengers ride in CARRIAGES, which is both
      //    correct and internally consistent; the loop cards keep "carriages" because a loop's
      //    length is quoted that way throughout.
      const freight = it.id === 'goods' || it.id === 'mineral';
      out.push({
        key: 'stock', id: 'stock:' + it.id, kind: 'stock', cls: it.id,
        name: it.name, cost: it.cost, blurb: it.blurb,
        detail: L.classOf(it.id).cars + (freight ? ' wagons · fare ' : ' carriages · fare ') + L.classOf(it.id).fare,
        lockedBy: s.signalTier < it.need ? 'Needs ' + L.SIGNAL_TIERS[it.need].name : null,
      });
    }
    for (const sec of L.SECTIONS) {
      if (s.doubled[sec.id]) continue;
      if (s.signalTier < 4) continue; // doubling is meaningless before track circuits
      // ⛔ FOUR CARDS THAT SAY THE SAME SENTENCE ARE ONE CARD PRINTED FOUR TIMES. The doubling
      //    items used one blurb and one footnote for every section, so the yard's whole second
      //    page read as a copy-paste and gave the player nothing to choose between. Each section
      //    already differs in the three numbers that decide whether doubling it is worth £3,900 —
      //    length, gradient and exposure — so the card says those instead of repeating itself.
      const grade = sec.grade >= 1.5 ? 'a hard climb' : sec.grade >= 1.3 ? 'a steady climb'
        : sec.grade >= 1.1 ? 'a rising grade' : 'easy going';
      // A CLAUSE, not an adjective: "it exposed in places" is what an adjective produced here,
      // and it went out in a screenshot before it was read (§10b — open the picture and LOOK).
      const wind = sec.exposure >= 0.95 ? 'takes the very worst of the weather'
        : sec.exposure >= 0.8 ? 'is badly exposed'
          : sec.exposure >= 0.5 ? 'is exposed in places' : 'is fairly sheltered';
      out.push({
        key: 'double', id: 'double:' + sec.id, kind: 'double', section: sec.id,
        name: 'Double ' + sec.name, cost: L.DOUBLING_COST[sec.id],
        blurb: 'A second road all the way through ' + sec.name + ', so one train each way can be '
          + 'in it at the same time. It is ' + grade + ' and it ' + wind + '.',
        // ⛔ A FIGURE THAT APPEARS ON THREE CARDS AND SILENTLY VANISHES FROM THE FOURTH READS AS A
        //    BUG, NOT AS A ZERO. Three doubling cards printed a snow percentage and HAL-WIN printed
        //    nothing, because nothing was the honest answer — so say the honest answer out loud.
        detail: sec.lengthKm + ' km · run times ×' + sec.grade.toFixed(2) + ' for heavy trains · '
          + (s.snow[sec.id] > 0.02 ? Math.round(s.snow[sec.id] * 100) + '% snow tonight' : 'clear tonight'),
      });
    }
    out.push({
      key: 'plough', id: 'plough', kind: 'plough',
      name: 'Order the snowplough', cost: 240,
      blurb: 'Runs tomorrow, ahead of the first service, and clears what it can reach.',
      detail: 'clears up to ' + Math.round(PLOUGH_CLEARS * 100) + '% of the snow on every section',
    });
    return out;
  }

  function buy(s, itemId) {
    const item = catalogue(s).find((i) => i.id === itemId);
    if (!item) return { ok: false, reason: 'nothing by that name is for sale' };
    if (item.lockedBy) return { ok: false, reason: item.lockedBy };
    // ⛔ A REFUSAL IS A SENTENCE THE GAME SAYS OUT LOUD, SO IT IS WRITTEN LIKE ONE. This read
    //    "that costs 280 and you have 260" — the only lowercase, unpunctuated, currency-less
    //    string in the product, printed on a screen where every other number carries a £.
    if (s.money < item.cost) {
      return { ok: false, reason: item.name + ' costs £' + item.cost + ' and you have £' + s.money + '.' };
    }

    if (item.kind === 'signal') s.signalTier++;
    else if (item.kind === 'loop') s.loops[item.station]++;
    else if (item.kind === 'stock') s.unlocked[item.cls] = true;
    else if (item.kind === 'double') s.doubled[item.section] = true;
    else if (item.kind === 'plough') {
      // The plough is a SERVICE, not a possession: it clears snow now, at a price, every time.
      for (const sec of L.SECTIONS) s.snow[sec.id] = clamp(s.snow[sec.id] * (1 - PLOUGH_CLEARS), 0, 1);
      s.unlocked.plough = true;
    }
    s.money -= item.cost;
    return { ok: true, item };
  }

  // ── the win ───────────────────────────────────────────────────────────────────────────────
  /**
   * THE WINTER TIMETABLE. A real ending, not a score: work the line to the top of the signalling
   * ladder and then run a full day of the heaviest traffic without a wreck and without blocking
   * the line. `checkWin` is called at the end of every day.
   */
  /**
   * ⭐ THE WIN SITS AT INTERLOCKING (tier 5), NOT AT AUTOMATIC ROUTE SETTING (tier 6), AND THAT
   *    IS A DESIGN DECISION RATHER THAN A BALANCE ONE. Requiring ARS would put the climax of the
   *    game on the far side of the upgrade that stops the player working the railway: you would
   *    earn the ending by watching the panel do it for you. So the Winter Timetable is worked BY
   *    HAND on a fully interlocked frame with the Mail and the mineral traffic running — the
   *    hardest day the player ever actually plays — and ARS remains buyable afterwards as the
   *    epilogue, which is the honest place for an idle layer: a reward for finishing, not the
   *    finish itself.
   */
  function checkWin(s, d) {
    if (s.won) return false;
    const ready = s.signalTier >= 5 && s.unlocked.mail && s.unlocked.mineral;
    if (!ready) return false;
    if (d.wreck || d.blocked) return false;
    const worked = d.onTime + d.late;
    if (d.onTime < 10) return false;
    // ⛔ A RATIO, NOT A COUNT. `late <= 2` was unpassable on a 19-train day (wing §3f-1:
    //    an absolute figure scales the wrong way), so no campaign could ever finish.
    if (d.onTime / Math.max(1, worked) < 0.70) return false;
    s.won = true;
    s.wonAtDay = s.day;
    return true;
  }

  // ── save / resume ─────────────────────────────────────────────────────────────────────────
  // ⛔ Wing standing rule: never a full restart. The save holds the RAILWAY (permanent) and the
  //    day number, never the half-finished day — a day is short and re-running it is the point.
  function serialise(s) {
    return JSON.stringify({
      v: 1, seed: s.seed, day: s.day, money: s.money, signalTier: s.signalTier,
      loops: s.loops, doubled: s.doubled, snow: s.snow, unlocked: s.unlocked,
      contractsRun: s.contractsRun, bestDay: s.bestDay, totalEarned: s.totalEarned,
      wrecks: s.wrecks, blockedDays: s.blockedDays, perfectDays: s.perfectDays,
      won: s.won, wonAtDay: s.wonAtDay,
    });
  }

  function deserialise(text) {
    const o = JSON.parse(text);
    if (!o || o.v !== 1) throw new Error('save is not version 1');
    const s = newGame(o.seed);
    s.day = o.day; s.money = o.money; s.signalTier = o.signalTier;
    s.loops = o.loops; s.doubled = o.doubled; s.snow = o.snow;
    s.unlocked = o.unlocked; s.contractsRun = o.contractsRun || s.contractsRun;
    s.bestDay = o.bestDay || 0; s.totalEarned = o.totalEarned || 0;
    s.wrecks = o.wrecks || 0; s.blockedDays = o.blockedDays || 0;
    s.perfectDays = o.perfectDays || 0;
    s.won = !!o.won; s.wonAtDay = o.wonAtDay || 0;
    return s;
  }

  // ⛔ Every storage key that is READ must be WRITTEN by shipped code (master §2b: a dead reader
  //    is an untested code path that hid half of a game). SAVE_KEY is written by save() and read
  //    by load(), both called from main.js.
  function save(s) {
    try { if (typeof localStorage !== 'undefined') localStorage.setItem(SAVE_KEY, serialise(s)); return true; }
    catch (e) { return false; }
  }
  function load() {
    try {
      if (typeof localStorage === 'undefined') return null;
      const t = localStorage.getItem(SAVE_KEY);
      return t ? deserialise(t) : null;
    } catch (e) { return null; }
  }
  function clearSave() {
    try { if (typeof localStorage !== 'undefined') localStorage.removeItem(SAVE_KEY); } catch (e) { /* nothing to do */ }
  }

  return {
    SAVE_KEY, MINUTES_PER_SECOND, DAY_MINUTES, DAY_START_MIN,
    SNOW_SLOW_AT, SNOW_CLOSED_AT, PLOUGH_CLEARS, FINE_WRECK, FINE_BLOCKED,
    mulberry32, clamp, clockOf,
    newGame, buildTimetable, startDay, runMinutes, endDay, advanceDay, rollWeather,
    canAdmit, admit, setRoad, shunt, canShunt, nextSection, roadFree, roadsFor, occupantsAt, trainsOnLine,
    sectionCapacity, baseRunTime, deadlocked, autoRoute, settle, label,
    catalogue, buy, checkWin,
    serialise, deserialise, save, load, clearSave,
  };
}));
