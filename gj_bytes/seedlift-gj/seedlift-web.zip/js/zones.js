/* SEEDLIFT — zones, strains and hybrid recipes. Pure data plus lookups; no DOM, no randomness.
 * Every number here is a STARTING value: the campaign probe sets the final ones.
 * Browser: window.ZONES. Node: module.exports. */
(function (root) {
  'use strict';

  /* Four raid zones, unlocked in order by a permit (coin + a codex milestone). */
  /* raidSec = how long the storm takes to cross the whole map. The terrain mix is what the map
   * generator draws: blocked (hedge, reed, tree, rock), bramble (slow) and bog (slower). */
  var ZONES = [
    { id: 'hedgerow', n: 1, name: 'Hedgerow', permitCoin: 0, permitCodex: 0, raidSec: 80, threats: [],
      blocked: 0.14, bramble: 0.10, bog: 0, orchard: false, boars: 0, crowEvery: 0, pods: 15, caches: 6,
      blurb: 'Field edges and hawthorn. Nothing here bites.' },
    { id: 'fen', n: 2, name: 'Fen', permitCoin: 200, permitCodex: 4, raidSec: 80, threats: ['bog', 'crow'],
      blocked: 0.08, bramble: 0.04, bog: 0.24, orchard: false, boars: 0, crowEvery: 12, pods: 16, caches: 6,
      blurb: 'Bog that drags your boots, and crows that rob your pack.' },
    { id: 'orchard', n: 3, name: 'Old Orchard', permitCoin: 900, permitCodex: 8, raidSec: 85, threats: ['boar', 'wall'],
      blocked: 0.05, bramble: 0.08, bog: 0, orchard: true, boars: 4, crowEvery: 0, pods: 16, caches: 7,
      blurb: 'Walled rows of old trees, and boars that charge in straight lines.' },
    /* raidSec 70: the card promises "a fast storm", and at 80 it was exactly the tutorial Hedgerow's
     * pace (the independent review read it off this table). The probes were re-run at 70. */
    { id: 'ridge', n: 4, name: 'Ridge Garden', permitCoin: 2400, permitCodex: 13, raidSec: 70, threats: ['bog', 'crow', 'boar'],
      blocked: 0.12, bramble: 0.08, bog: 0.10, orchard: false, boars: 3, crowEvery: 11, pods: 16, caches: 7,
      blurb: 'A ruined botanic garden on the high ground. Everything at once, and a fast storm.' },
  ];

  /* Sixteen wild strains, four per zone. growSec = seconds from sowing to mature at base speed.
   * coin = sale value of one harvest. tool = what the crop becomes in the raid pack (the one place the
   * two halves of the game touch). frame = needs a cold frame to grow at home. */
  var STRAINS = [
    { id: 'sweetroot', zone: 'hedgerow', name: 'Sweetroot', rarity: 1, growSec: 24, coin: 3, tool: 'lure', frame: false },
    { id: 'hedgepea', zone: 'hedgerow', name: 'Hedge Pea', rarity: 1, growSec: 20, coin: 2, tool: null, frame: false },
    { id: 'cornflower', zone: 'hedgerow', name: 'Cornflower', rarity: 2, growSec: 36, coin: 6, tool: null, frame: false },
    { id: 'wildoat', zone: 'hedgerow', name: 'Wild Oat', rarity: 1, growSec: 28, coin: 4, tool: null, frame: false },
    { id: 'smokeherb', zone: 'fen', name: 'Smokeherb', rarity: 1, growSec: 40, coin: 5, tool: 'smoke', frame: false },
    { id: 'marigold', zone: 'fen', name: 'Marsh Marigold', rarity: 2, growSec: 50, coin: 9, tool: null, frame: false },
    { id: 'fenreed', zone: 'fen', name: 'Fen Reed', rarity: 1, growSec: 34, coin: 6, tool: null, frame: false },
    { id: 'cottongrass', zone: 'fen', name: 'Cottongrass', rarity: 3, growSec: 70, coin: 16, tool: null, frame: false },
    { id: 'crabapple', zone: 'orchard', name: 'Crab Apple', rarity: 1, growSec: 60, coin: 12, tool: 'lure', frame: false },
    { id: 'medlar', zone: 'orchard', name: 'Medlar', rarity: 2, growSec: 80, coin: 18, tool: null, frame: false },
    { id: 'quince', zone: 'orchard', name: 'Quince', rarity: 2, growSec: 90, coin: 22, tool: null, frame: false },
    { id: 'damson', zone: 'orchard', name: 'Damson', rarity: 3, growSec: 110, coin: 30, tool: null, frame: false },
    { id: 'bluepoppy', zone: 'ridge', name: 'Blue Poppy', rarity: 2, growSec: 120, coin: 40, tool: null, frame: true },
    { id: 'ghostorchid', zone: 'ridge', name: 'Ghost Orchid', rarity: 3, growSec: 160, coin: 70, tool: null, frame: true },
    { id: 'cloudberry', zone: 'ridge', name: 'Cloudberry', rarity: 2, growSec: 130, coin: 46, tool: 'lure', frame: true },
    { id: 'gentian', zone: 'ridge', name: 'Snow Gentian', rarity: 3, growSec: 150, coin: 60, tool: 'smoke', frame: true },
  ];

  /* Eight hybrids. Two MATURE plants of the two parent strains side by side at harvest may yield
   * the hybrid's seed. Hybrids are stronger versions of a tool or simply valuable. */
  var HYBRIDS = [
    { id: 'honeyroot', a: 'sweetroot', b: 'cornflower', name: 'Honeyroot', growSec: 40, coin: 12, tool: 'lure2', frame: false },
    { id: 'oatpea', a: 'hedgepea', b: 'wildoat', name: 'Oatpea', growSec: 22, coin: 7, tool: null, frame: false },
    { id: 'peatsmoke', a: 'smokeherb', b: 'fenreed', name: 'Peatsmoke', growSec: 55, coin: 14, tool: 'smoke2', frame: false },
    { id: 'goldcotton', a: 'marigold', b: 'cottongrass', name: 'Goldcotton', growSec: 85, coin: 34, tool: null, frame: false },
    { id: 'wardenpear', a: 'medlar', b: 'quince', name: 'Warden Pear', growSec: 100, coin: 48, tool: null, frame: false },
    { id: 'bullace', a: 'crabapple', b: 'damson', name: 'Bullace', growSec: 95, coin: 44, tool: 'lure2', frame: false },
    { id: 'skypoppy', a: 'bluepoppy', b: 'gentian', name: 'Sky Poppy', growSec: 150, coin: 95, tool: null, frame: true },
    { id: 'mistberry', a: 'cloudberry', b: 'ghostorchid', name: 'Mistberry', growSec: 170, coin: 120, tool: null, frame: true },
  ];

  /* The ending: the Ridge Garden's centrepiece, grown at home under a frame. */
  var CENTREPIECE = { id: 'centrepiece', zone: 'ridge', name: 'The Centrepiece', growSec: 480, coin: 0, tool: null, frame: true, ending: true };

  var BY_ID = {};
  STRAINS.concat(HYBRIDS, [CENTREPIECE]).forEach(function (s) { BY_ID[s.id] = s; });

  function strain(id) { return BY_ID[id] || null; }
  function zone(id) { for (var i = 0; i < ZONES.length; i++) if (ZONES[i].id === id) return ZONES[i]; return null; }
  function strainsOf(zoneId) { return STRAINS.filter(function (s) { return s.zone === zoneId; }); }
  /* The hybrid two parents make, in either order, or null. */
  function hybridOf(x, y) {
    for (var i = 0; i < HYBRIDS.length; i++) {
      var h = HYBRIDS[i];
      if ((h.a === x && h.b === y) || (h.a === y && h.b === x)) return h;
    }
    return null;
  }
  /* The codex: every wild strain and every hybrid (24). The centrepiece is the ending, not an entry. */
  function codexIds() { return STRAINS.map(function (s) { return s.id; }).concat(HYBRIDS.map(function (h) { return h.id; })); }

  var API = { ZONES: ZONES, STRAINS: STRAINS, HYBRIDS: HYBRIDS, CENTREPIECE: CENTREPIECE, strain: strain, zone: zone, strainsOf: strainsOf, hybridOf: hybridOf, codexIds: codexIds };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else root.ZONES = API;
})(typeof window !== 'undefined' ? window : this);
