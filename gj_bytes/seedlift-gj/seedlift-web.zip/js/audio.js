/**
 * audio.js — SEEDLIFT's sound: two themes, the effects, and the storm's wind.
 *
 * Every sound is procedural synthesis written in this file (Web Audio oscillators and one noise
 * buffer filled from a SEEDED generator), so the same score renders to the same samples. The build
 * renders the themes and effects ONCE through an OfflineAudioContext into the OGG files in audio/,
 * and the game plays those files; live synthesis is only the fallback for a browser that cannot
 * decode OGG. The storm's wind is live, because its loudness follows how close the wall is.
 * No generative-AI audio.
 */
(function (root) {
  'use strict';

  var A = { ctx: null, muted: false, ready: false, played: {}, buffers: {}, song: null, SFX_NAMES: [], MUTE_KEY: 'seedlift.mute.v1' };
  try { A.muted = root.localStorage && root.localStorage.getItem(A.MUTE_KEY) === '1'; } catch (e) { A.muted = false; }

  var MAJ = [0, 2, 4, 5, 7, 9, 11], MIN = [0, 2, 3, 5, 7, 8, 10];
  /* root: MIDI key centre · prog: chord roots as scale degrees, one per bar · motif: lead line on
   * eighth notes as scale degrees (-1 = rest), two bars long, played over bars 3-4 and 7-8 */
  var SONGS = {
    farm: { bpm: 92, bars: 8, root: 55, scale: MAJ, prog: [0, 4, 5, 3, 0, 4, 3, 4],
      motif: [4, -1, 5, 4, 2, -1, 0, -1, 1, 2, -1, 4, 2, -1, -1, -1], feel: 'farm' },
    raid: { bpm: 116, bars: 8, root: 57, scale: MIN, prog: [0, 5, 3, 4, 0, 5, 6, 4],
      motif: [0, -1, 2, 3, -1, 4, 3, 2, 0, -1, -1, 6, 4, -1, 3, -1], feel: 'raid' },
  };
  A.SONGS = SONGS;
  function midiHz(n) { return 440 * Math.pow(2, (n - 69) / 12); }
  function deg(song, d, oct) { var s = song.scale, n = s.length, o = Math.floor(d / n), i = ((d % n) + n) % n; return song.root + s[i] + 12 * (o + (oct || 0)); }

  function makeBuses(ctx) {
    var master = ctx.createGain(); master.gain.value = 0.85;
    var comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14; comp.knee.value = 10; comp.ratio.value = 4; comp.attack.value = 0.004; comp.release.value = 0.2;
    master.connect(comp); comp.connect(ctx.destination);
    var music = ctx.createGain(); music.gain.value = 0.6; music.connect(master);
    var sfx = ctx.createGain(); sfx.gain.value = 0.9; sfx.connect(master);
    var len = ctx.sampleRate, buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0), s = 0x5eed1f7;
    for (var i = 0; i < len; i++) { s = (Math.imul(s, 1103515245) + 12345) | 0; d[i] = ((s >>> 8) & 0xffff) / 32768 - 1; }
    return { master: master, music: music, sfx: sfx, noise: buf };
  }
  function env(g, t, a, peak, dec, sus, rel, hold) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak * sus), t + a + dec);
    if (hold) g.gain.setValueAtTime(Math.max(0.0002, peak * sus), t + a + dec + hold);
    g.gain.exponentialRampToValueAtTime(0.0001, t + a + dec + (hold || 0) + rel);
    return t + a + dec + (hold || 0) + rel;
  }
  function osc(ctx, type, hz, t, end, dest, detune) {
    var o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(hz, t);
    if (detune) o.detune.value = detune;
    o.connect(dest); o.start(t); o.stop(end + 0.02); return o;
  }
  function noise(ctx, B, t, end, dest) { var n = ctx.createBufferSource(); n.buffer = B.noise; n.loop = true; n.connect(dest); n.start(t, (t * 7.31) % 0.9); n.stop(end + 0.02); return n; }
  function filt(ctx, type, hz, q, dest) { var f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = hz; if (q) f.Q.value = q; f.connect(dest); return f; }
  function gain(ctx, dest) { var g = ctx.createGain(); g.connect(dest); return g; }

  /* ── instruments ─────────────────────────────────────────────────────────────────── */
  var INST = {
    pluck: function (ctx, B, t, v, note) { var g = gain(ctx, B.music), f = filt(ctx, 'lowpass', 2600, 2, g); var end = env(g, t, 0.003, 0.2 * v, 0.22, 0.12, 0.2); osc(ctx, 'triangle', midiHz(note), t, end, f); osc(ctx, 'square', midiHz(note), t, t + 0.03, filt(ctx, 'lowpass', 1200, 0, g)); },
    pad: function (ctx, B, t, v, notes, dur) { var g = gain(ctx, B.music), f = filt(ctx, 'lowpass', 1300, 0, g); var end = env(g, t, dur * 0.3, 0.075 * v, dur * 0.3, 0.8, dur * 0.3, dur * 0.1); notes.forEach(function (n) { osc(ctx, 'triangle', midiHz(n), t, end, f, -6); osc(ctx, 'sawtooth', midiHz(n), t, end, filt(ctx, 'lowpass', 700, 0, g), 6); }); },
    bassSoft: function (ctx, B, t, v, note, dur) { var g = gain(ctx, B.music); var end = env(g, t, 0.01, 0.36 * v, dur * 0.4, 0.55, 0.1, dur * 0.4); osc(ctx, 'sine', midiHz(note), t, end, g); osc(ctx, 'triangle', midiHz(note + 12), t, end, filt(ctx, 'lowpass', 500, 0, g)); },
    bassDrive: function (ctx, B, t, v, note, dur) { var g = gain(ctx, B.music), f = filt(ctx, 'lowpass', 520, 7, g); f.frequency.setValueAtTime(900, t); f.frequency.exponentialRampToValueAtTime(260, t + dur); var end = env(g, t, 0.004, 0.34 * v, dur * 0.4, 0.6, 0.06, dur * 0.35); osc(ctx, 'sawtooth', midiHz(note), t, end, f); osc(ctx, 'square', midiHz(note - 12), t, end, f); },
    flute: function (ctx, B, t, v, note, dur) { var g = gain(ctx, B.music); var end = env(g, t, 0.03, 0.15 * v, dur * 0.5, 0.6, 0.14); var o = osc(ctx, 'sine', midiHz(note), t, end, g); var lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 5; lg.gain.value = 7; lfo.connect(lg); lg.connect(o.detune); lfo.start(t); lfo.stop(end + 0.02); osc(ctx, 'triangle', midiHz(note + 12), t, end, filt(ctx, 'lowpass', 1800, 0, gain(ctx, g))); var br = gain(ctx, g); env(br, t, 0.01, 0.02 * v, 0.08, 0.1, 0.05); noise(ctx, B, t, t + 0.15, filt(ctx, 'bandpass', 3000, 1, br)); },
    lead: function (ctx, B, t, v, note, dur) { var g = gain(ctx, B.music), f = filt(ctx, 'lowpass', 2200, 3, g); var end = env(g, t, 0.006, 0.12 * v, dur * 0.4, 0.5, 0.08); osc(ctx, 'square', midiHz(note), t, end, f, -5); osc(ctx, 'square', midiHz(note), t, end, f, 5); },
    kick: function (ctx, B, t, v) { var g = gain(ctx, B.music); var end = env(g, t, 0.002, 0.8 * v, 0.14, 0.2, 0.1); var o = osc(ctx, 'sine', 140, t, end, g); o.frequency.exponentialRampToValueAtTime(45, t + 0.12); },
    shaker: function (ctx, B, t, v) { var g = gain(ctx, B.music), f = filt(ctx, 'highpass', 6500, 0, g); var end = env(g, t, 0.004, 0.09 * v, 0.05, 0.2, 0.03); noise(ctx, B, t, end, f); },
    hat: function (ctx, B, t, v) { var g = gain(ctx, B.music), f = filt(ctx, 'highpass', 8000, 0, g); var end = env(g, t, 0.001, 0.14 * v, 0.03, 0.2, 0.02); noise(ctx, B, t, end, f); },
    snare: function (ctx, B, t, v) { var g = gain(ctx, B.music), f = filt(ctx, 'bandpass', 1900, 0.8, g); var end = env(g, t, 0.002, 0.34 * v, 0.1, 0.25, 0.08); noise(ctx, B, t, end, f); osc(ctx, 'triangle', 190, t, t + 0.08, gain(ctx, g)); },
  };

  /* Schedule `bars` bars of a song into any context from time t0. */
  function schedule(ctx, B, name, t0, bars) {
    var S = SONGS[name], beat = 60 / S.bpm, bar = beat * 4, e8 = beat / 2;
    for (var b = 0; b < bars; b++) {
      var tb = t0 + b * bar, ch = S.prog[b % S.prog.length];
      var triad = [deg(S, ch, 0), deg(S, ch + 2, 0), deg(S, ch + 4, 0)];
      INST.pad(ctx, B, tb, S.feel === 'farm' ? 1 : 0.8, triad, bar);
      for (var q = 0; q < 8; q++) {
        var tq = tb + q * e8;
        if (S.feel === 'farm') {
          if (q % 4 === 0) INST.bassSoft(ctx, B, tq, 1, deg(S, ch, -2), beat * 1.8);
          var arp = [0, 2, 4, 7, 4, 2, 4, 2][q];
          INST.pluck(ctx, B, tq, q % 2 ? 0.7 : 1, deg(S, ch + arp, 1));
          INST.shaker(ctx, B, tq, q % 2 ? 0.6 : 1);
        } else {
          INST.bassDrive(ctx, B, tq, q % 2 ? 0.75 : 1, deg(S, ch, -2), e8 * 0.9);
          if (q % 2 === 0) INST.kick(ctx, B, tq, 1);
          if (q === 2 || q === 6) INST.snare(ctx, B, tq, 1);
          INST.hat(ctx, B, tq, 0.8); INST.hat(ctx, B, tq + e8 / 2, 0.5);
        }
      }
      if (b % 4 === 2 || b % 4 === 3) {
        var half = (b % 4 === 3) ? 8 : 0;
        for (var m = 0; m < 8; m++) {
          var d = S.motif[half + m]; if (d < 0) continue;
          var len = 1; while (m + len < 8 && S.motif[half + m + len] < 0) len++;
          if (S.feel === 'farm') INST.flute(ctx, B, tb + m * e8, 1, deg(S, d, 1), len * e8);
          else INST.lead(ctx, B, tb + m * e8, 1, deg(S, d, 1), len * e8);
        }
      }
    }
    return t0 + bars * bar;
  }

  /* ── effects ────────────────────────────────────────────────────────────────────── */
  function blip(ctx, B, t, type, f0, f1, dur, vol, fq) {
    var g = gain(ctx, B.sfx), dest = fq ? filt(ctx, 'lowpass', fq, 1, g) : g;
    var end = env(g, t, 0.004, vol, dur * 0.6, 0.3, dur * 0.4);
    var o = osc(ctx, type, f0, t, end, dest); if (f1) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    return end;
  }
  function whoosh(ctx, B, t, f0, f1, dur, vol, type) {
    var g = gain(ctx, B.sfx), f = filt(ctx, type || 'bandpass', f0, 1.2, g);
    f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    var end = env(g, t, dur * 0.2, vol, dur * 0.5, 0.3, dur * 0.3); noise(ctx, B, t, end, f); return end;
  }
  function notes(ctx, B, t, list, step, type, vol) { list.forEach(function (n, i) { blip(ctx, B, t + i * step, type || 'triangle', midiHz(n), 0, step * 1.6, vol || 0.25); }); }
  var SFX = {
    plant: function (ctx, B, t) { whoosh(ctx, B, t, 900, 300, 0.12, 0.25, 'lowpass'); blip(ctx, B, t + 0.05, 'sine', 330, 440, 0.1, 0.2); },
    harvest: function (ctx, B, t) { whoosh(ctx, B, t, 2500, 800, 0.1, 0.18); notes(ctx, B, t + 0.04, [72, 79], 0.06, 'triangle', 0.24); },
    cross: function (ctx, B, t) { notes(ctx, B, t, [72, 76, 79, 84, 88], 0.07, 'triangle', 0.22); notes(ctx, B, t + 0.02, [84, 91], 0.2, 'sine', 0.1); },
    pickup: function (ctx, B, t) { notes(ctx, B, t, [76, 83], 0.05, 'square', 0.14); },
    fresh: function (ctx, B, t) { notes(ctx, B, t, [74, 78, 81, 86], 0.08, 'triangle', 0.26); },
    coin: function (ctx, B, t) { notes(ctx, B, t, [88, 93], 0.05, 'square', 0.12); },
    packfull: function (ctx, B, t) { blip(ctx, B, t, 'square', 220, 180, 0.12, 0.15, 900); blip(ctx, B, t + 0.13, 'square', 200, 160, 0.14, 0.15, 900); },
    swap: function (ctx, B, t) { notes(ctx, B, t, [79, 74, 81], 0.05, 'triangle', 0.2); },
    spill: function (ctx, B, t) { blip(ctx, B, t, 'sawtooth', 180, 60, 0.25, 0.3, 700); whoosh(ctx, B, t, 1500, 300, 0.2, 0.25, 'lowpass'); },
    steal: function (ctx, B, t) { blip(ctx, B, t, 'square', 1200, 700, 0.08, 0.14, 3000); blip(ctx, B, t + 0.09, 'square', 1100, 600, 0.1, 0.14, 3000); },
    recover: function (ctx, B, t) { notes(ctx, B, t, [67, 71, 74, 79], 0.05, 'triangle', 0.22); },
    lure: function (ctx, B, t) { whoosh(ctx, B, t, 600, 1800, 0.18, 0.2); blip(ctx, B, t + 0.15, 'sine', 520, 260, 0.12, 0.2); },
    smoke: function (ctx, B, t) { whoosh(ctx, B, t, 400, 2400, 0.5, 0.35, 'lowpass'); },
    dash: function (ctx, B, t) { whoosh(ctx, B, t, 900, 3500, 0.16, 0.75); blip(ctx, B, t, 'triangle', 300, 700, 0.12, 0.22); },
    boarAim: function (ctx, B, t) { blip(ctx, B, t, 'sawtooth', 110, 90, 0.3, 0.26, 600); whoosh(ctx, B, t, 300, 200, 0.3, 0.18, 'lowpass'); },
    boarCharge: function (ctx, B, t) { for (var i = 0; i < 4; i++) blip(ctx, B, t + i * 0.07, 'sine', 90, 50, 0.07, 0.35); },
    crowIn: function (ctx, B, t) { blip(ctx, B, t, 'sawtooth', 900, 700, 0.12, 0.12, 2400); blip(ctx, B, t + 0.14, 'sawtooth', 850, 620, 0.16, 0.12, 2400); },
    liftopen: function (ctx, B, t) { notes(ctx, B, t, [69, 76, 81], 0.1, 'sine', 0.2); },
    lifted: function (ctx, B, t) { notes(ctx, B, t, [67, 71, 74, 79, 83, 86], 0.08, 'triangle', 0.25); whoosh(ctx, B, t, 300, 3000, 0.7, 0.2, 'lowpass'); },
    lost: function (ctx, B, t) { notes(ctx, B, t, [64, 60, 57, 52], 0.16, 'sawtooth', 0.14); whoosh(ctx, B, t, 2000, 200, 0.9, 0.3, 'lowpass'); },
    buy: function (ctx, B, t) { notes(ctx, B, t, [76, 81, 88], 0.06, 'square', 0.14); },
    refuse: function (ctx, B, t) { blip(ctx, B, t, 'square', 180, 150, 0.14, 0.16, 800); },
    permit: function (ctx, B, t) { notes(ctx, B, t, [60, 64, 67, 72, 76, 79], 0.09, 'triangle', 0.24); },
    menuMove: function (ctx, B, t) { blip(ctx, B, t, 'triangle', 660, 0, 0.06, 0.34); },
    menuSelect: function (ctx, B, t) { notes(ctx, B, t, [74, 79], 0.04, 'triangle', 0.16); },
    ending: function (ctx, B, t) { notes(ctx, B, t, [60, 64, 67, 72, 76, 79, 84, 88], 0.14, 'triangle', 0.24); notes(ctx, B, t + 0.07, [48, 55, 60], 0.5, 'sine', 0.22); },
  };
  A.SFX_NAMES = Object.keys(SFX);

  /* Render for the build (and for the tests that MEASURE): a song or one effect, into an offline context. */
  A.renderSong = function (Offline, name, bars) {
    var S = SONGS[name], secs = bars * 4 * 60 / S.bpm + 1.5, ctx = new Offline(2, Math.ceil(secs * 44100), 44100);
    schedule(ctx, makeBuses(ctx), name, 0.05, bars);
    return ctx.startRendering();
  };
  A.renderSfx = function (Offline, name) {
    var ctx = new Offline(2, Math.ceil(1.6 * 44100), 44100);
    SFX[name](ctx, makeBuses(ctx), 0.02);
    return ctx.startRendering();
  };

  /* ── live playback ──────────────────────────────────────────────────────────────── */
  A.init = function () {
    if (A.ctx) { if (A.ctx.state === 'suspended') A.ctx.resume(); return; }
    var AC = root.AudioContext || root.webkitAudioContext; if (!AC) return;
    A.ctx = new AC(); A.B = makeBuses(A.ctx); A.ready = true;
    A.B.master.gain.value = A.muted ? 0 : 0.85;
    /* the storm's wind: live noise through a lowpass whose gain follows the wall */
    var w = A.ctx.createBufferSource(); w.buffer = A.B.noise; w.loop = true;
    var wf = A.ctx.createBiquadFilter(); wf.type = 'lowpass'; wf.frequency.value = 500;
    var wg = A.ctx.createGain(); wg.gain.value = 0; w.connect(wf); wf.connect(wg); wg.connect(A.B.sfx); w.start();
    A.wind = { f: wf, g: wg };
    ['theme_farm', 'theme_raid'].concat(A.SFX_NAMES.map(function (n) { return 'sfx_' + n; })).forEach(load);
    if (A.want) { var s = A.want; A.want = null; A.playSong(s); }
  };
  function load(key) {
    if (!root.fetch) return;
    root.fetch('audio/' + key + '.ogg').then(function (r) { if (!r.ok) throw new Error(r.status); return r.arrayBuffer(); })
      .then(function (ab) { return new Promise(function (ok, bad) { A.ctx.decodeAudioData(ab, ok, bad); }); })
      .then(function (buf) { A.buffers[key] = buf; if (key === 'theme_' + A.song && !A.songSrc) A.playSong(A.song, true); })
      .catch(function () { A.missing = (A.missing || []).concat(key); });
  }
  A.setMuted = function (m) {
    A.muted = !!m;
    try { root.localStorage.setItem(A.MUTE_KEY, A.muted ? '1' : '0'); } catch (e) { /* private mode: the toggle still works this session */ }
    if (A.B) A.B.master.gain.setTargetAtTime(A.muted ? 0 : 0.85, A.ctx.currentTime, 0.03);
  };
  /* Loop a theme: the file when it has decoded, the live score until then. */
  A.playSong = function (name, force) {
    if (!A.ctx) { A.want = name; A.song = name; return; }
    if (A.song === name && !force && (A.songSrc || A.liveUntil > A.ctx.currentTime)) return;
    A.song = name;
    var t = A.ctx.currentTime;
    if (A.songGain) { var og = A.songGain; og.gain.setTargetAtTime(0.0001, t, 0.25); var os = A.songSrc; setTimeout(function () { try { if (os) os.stop(); og.disconnect(); } catch (e) { /* already stopped */ } }, 1200); }
    A.songSrc = null; A.liveUntil = 0;
    var g = A.ctx.createGain(); g.gain.value = 0.0001; g.connect(A.B.music); g.gain.setTargetAtTime(1, t, 0.3); A.songGain = g;
    var buf = A.buffers['theme_' + name];
    if (buf) {
      var src = A.ctx.createBufferSource(); src.buffer = buf; src.loop = true; src.connect(g); src.start(t + 0.02); A.songSrc = src;
    } else {
      /* fallback: schedule the live score for its 8 bars into this song's own bus */
      var B2 = { music: g, sfx: A.B.sfx, noise: A.B.noise, master: A.B.master };
      A.liveUntil = schedule(A.ctx, B2, name, t + 0.05, SONGS[name].bars);
    }
    A.played['song_' + name] = (A.played['song_' + name] || 0) + 1;
  };
  A.sfx = function (name) {
    A.played[name] = (A.played[name] || 0) + 1;
    if (!A.ctx || A.muted || !SFX[name]) return;
    var buf = A.buffers['sfx_' + name], t = A.ctx.currentTime + 0.005;
    if (buf) { var s = A.ctx.createBufferSource(); s.buffer = buf; s.connect(A.B.sfx); s.start(t); }
    else SFX[name](A.ctx, A.B, t);
  };
  /* 0..1: how loud the storm's wind is (0 away from the raid) */
  A.storm = function (level) {
    if (!A.wind) return;
    var t = A.ctx.currentTime, l = Math.max(0, Math.min(1, level));
    A.wind.g.gain.setTargetAtTime(0.35 * l * l, t, 0.2);
    A.wind.f.frequency.setTargetAtTime(300 + 1400 * l, t, 0.2);
  };
  /* keep the fallback score going when files never decoded */
  A.pump = function () { if (A.ctx && !A.songSrc && A.song && A.liveUntil && A.liveUntil - A.ctx.currentTime < 0.5) A.playSong(A.song, true); };

  root.AUDIO = A;
}(typeof self !== 'undefined' ? self : this));
