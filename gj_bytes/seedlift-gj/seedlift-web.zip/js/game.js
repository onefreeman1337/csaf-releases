/**
 * game.js — SEEDLIFT's shell: screens, input, the frame loop, saving.
 *
 * The farm (sim.js) and the raid (raid.js) decide everything; this file only asks them questions
 * and draws answers. The raid hears input through ONE door, RAID.setKey — the keyboard, the pointer
 * (hold on the map to walk toward it), the on-screen buttons and the bot all use it.
 *
 * Two layout shapes: WIDE 960x540 (desktop, landscape phone, the itch embed) and TALL 540x960
 * (an upright phone). The canvas element always has the aspect of the logical surface, so one scale
 * maps both axes and no letterbox inside the element can mis-map a tap.
 *
 * Saving: the farm is the checkpoint. It saves every 10 s, on every return home, on every purchase
 * and when the tab hides. A raid in progress is not saved: its kit is recorded as AWAY, and a load
 * that finds an away kit settles it as a quit (the pack is lost, the belt comes home).
 */
(function () {
  'use strict';
  var SIM = window.SIM, Z = window.ZONES, RAID = window.RAID, R = window.R, A = window.AUDIO;
  var canvas = document.getElementById('game');
  var ctx = canvas.getContext('2d');
  var C = R.C;
  var CLOCK_KEY = 'seedlift.clock.v1';

  var G = {
    screen: 'loading', shape: 'wide', W: 960, H: 540, st: null, rd: null, playing: false,
    sel: 'sweetroot', cur: { c: 0, r: 0 }, focus: 0, t: 0, fade: 0, overlay: null, pops: [], banners: [],
    loaded: 0, toLoad: 0, frozen: false, hitsCache: [], touchSeen: false, steer: null, held: {},
    result: null, lastSave: 0, flash: 0, welcome: null, lastFarmLog: 0, lastRaidLog: 0, saveRefused: null,
    zoneId: 'hedgerow', codexPage: 0,
  };

  /* ── assets ───────────────────────────────────────────────────────────────────────── */
  function loadImg(key, src) {
    G.toLoad++;
    var im = new Image();
    im.onload = function () { G.loaded++; R.img[key] = im; };
    im.onerror = function () { G.loaded++; G.missing = (G.missing || []).concat(src); };
    im.src = src;
  }
  Z.STRAINS.concat(Z.HYBRIDS, [Z.CENTREPIECE]).forEach(function (s) { loadImg('plant_' + s.id, 'art/plants/' + s.id + '.png'); });
  ['hedge', 'reeds', 'tree', 'rock', 'ruin', 'bramble'].forEach(function (o) { loadImg('obj_' + o, 'art/objects/' + o + '.png'); });
  ['balloon', 'coin', 'lure', 'pod', 'smoke'].forEach(function (p) { loadImg('prop_' + p, 'art/props/' + p + '.png'); });
  ['farmer_s', 'farmer_n', 'farmer_e', 'boar', 'crow'].forEach(function (c) { loadImg('chr_' + c, 'art/chars/' + c + '.png'); });
  Z.ZONES.forEach(function (z) { ['ground', 'bramble', 'bog'].forEach(function (t) { loadImg('gnd_' + z.id + '_' + t, 'art/ground/' + z.id + '_' + t + '.png'); }); });
  ['wall', 'farm_grass', 'farm_soil', 'farm_path'].forEach(function (g) { loadImg('gnd_' + g, 'art/ground/' + g + '.png'); });
  loadImg('key_title', 'art/key/title.jpg');
  var fontsReady = false;
  if (document.fonts && document.fonts.load) {
    /* The display face is two files: 'Cc5' names the one that carries only C, c and 5 (Pixelify's C
     * reads as O and its 5 is the same glyph as its S), so it loads too. */
    Promise.all([document.fonts.load("600 40px 'SL Display'", 'SEEDLIFT 01234689'), document.fonts.load("600 40px 'SL Display'", 'Cc57()'), document.fonts.load("800 20px 'SL Body'"), document.fonts.load("600 20px 'SL Body'")])
      .then(function () { fontsReady = true; }, function () { fontsReady = true; });
  } else fontsReady = true;

  /* ── fitting the canvas ───────────────────────────────────────────────────────────── */
  function fit() {
    var vw = document.documentElement.clientWidth || window.innerWidth, vh = document.documentElement.clientHeight || window.innerHeight;
    var shape = G.forceShape || (vw / vh < 0.9 ? 'tall' : 'wide');
    G.shape = shape; G.W = shape === 'tall' ? 540 : 960; G.H = shape === 'tall' ? 960 : 540;
    var s = Math.min(vw / G.W, vh / G.H);
    G.scale = s;
    var cw = Math.floor(G.W * s), ch = Math.floor(G.H * s);
    canvas.style.width = cw + 'px'; canvas.style.height = ch + 'px';
    var dpr = Math.min(3, window.devicePixelRatio || 1);
    canvas.width = Math.round(cw * dpr); canvas.height = Math.round(ch * dpr);
    R.init(ctx, G.W, G.H);
    R._pat = {};
  }
  window.addEventListener('resize', fit);
  fit();

  /* ── saving ───────────────────────────────────────────────────────────────────────── */
  function readSave() {
    var txt = null;
    try { txt = window.localStorage.getItem(SIM.SAVE_KEY); } catch (e) { txt = null; }
    if (!txt) return null;
    var r = SIM.deserialise(txt);
    if (!r.ok) { G.saveRefused = r.why; return null; }
    return r.st;
  }
  function readClock() { try { var v = +window.localStorage.getItem(CLOCK_KEY); return isFinite(v) && v > 0 ? v : 0; } catch (e) { return 0; } }
  function save() {
    if (!G.st) return;
    /* a raid in progress writes what its Oilskin Pouch holds into the away record, so a tab closed or
     * reloaded mid-raid keeps exactly what TURN BACK would have kept (final review: the reload path
     * settled an EMPTY pack, so the pouch could never apply) */
    if (G.screen === 'raid' && G.rd && !G.rd.over && G.st.away) {
      var np = Math.min(G.st.upgrades.pouch | 0, G.rd.pack.length);
      if (np > 0) G.st.away.pouch = G.rd.pack.slice(0, np).map(function (it) { return it.kind === 'coin' ? { kind: 'coin', amount: it.amount | 0 } : { kind: 'pod', strain: it.strain }; });
      else delete G.st.away.pouch;
    }
    try { window.localStorage.setItem(SIM.SAVE_KEY, SIM.serialise(G.st)); window.localStorage.setItem(CLOCK_KEY, String(Date.now())); } catch (e) { G.saveFailed = true; }
    G.lastSave = G.t;
  }
  G.hasSave = !!readSave();

  function beginPlay(fresh) {
    if (fresh) {
      /* G.seedFix is the test door's way to replay one farm exactly; play never sets it */
      G.st = SIM.create(G.seedFix || ((Date.now() >>> 0) ^ 0x5eed));
      G.st.log = [];
      G.welcome = null;
    } else {
      G.st = readSave() || SIM.create((Date.now() >>> 0) ^ 0x5eed);
      var away = readClock() ? (Date.now() - readClock()) / 1000 : 0;
      var h0 = G.st.stats.harvests, c0 = G.st.coin, notes = [];
      if (G.st.away) {
        var pouchItems = (G.st.away.pouch || []).map(function (it) { return it.kind === 'coin' ? { kind: 'coin', amount: it.amount, w: 1 } : { kind: 'pod', strain: it.strain, w: 1 }; });
        var settled = SIM.settleRaid(G.st, 'quit', pouchItems, {});
        notes.push(settled.kept.length ? 'Your last raid was cut short: the pouch came home with ' + settled.kept.map(function (it) { return it.kind === 'coin' ? nf(it.amount) + ' coin' : Z.strain(it.strain).name; }).join(' and ') + ', the rest of the pack was lost, the tools came home.' : 'Your last raid was cut short: the pack was lost, the tools came home.');
      }
      var credited = away > 60 ? SIM.creditOffline(G.st, away) : 0;
      if (credited > 0 || notes.length) G.welcome = { secs: credited, capped: away > SIM.OFFLINE_CAP_SEC, harvests: G.st.stats.harvests - h0, coin: G.st.coin - c0, notes: notes };
    }
    G.lastFarmLog = G.st.log.length;
    G.playing = true;
    if (!Z.strain(G.sel) || !(G.st.bank[G.sel] > 0)) G.sel = firstSeed();
    save();
    go('farm');
    if (G.welcome) G.overlay = 'welcome';
  }
  function firstSeed() { var ids = bankIds(); for (var i = 0; i < ids.length; i++) if (G.st.bank[ids[i]] > 0) return ids[i]; return ids[0] || 'sweetroot'; }
  /* the seed bank's order: codex order, then the centrepiece; only strains the player has held */
  function bankIds() {
    var st = G.st, out = [];
    Z.codexIds().forEach(function (id) { if (st.codex[id] || st.bank[id] > 0) out.push(id); });
    if (st.bank.centrepiece > 0) out.push('centrepiece');
    return out;
  }

  /* ── screens ──────────────────────────────────────────────────────────────────────── */
  function go(screen) {
    /* banners belong to the screen that raised them: the raid's intro banner was still drawn over the
     * YOU TURNED BACK card (independent review). Every banner is pushed AFTER its go(). */
    if (screen !== G.screen) { G.fade = 1; G.pops = []; G.banners = []; }
    G.screen = screen; G.focus = 0; G.overlay = null;
    if (screen === 'raid') A.playSong('raid'); else if (screen !== 'loading') A.playSong('farm');
    if (screen !== 'raid') A.storm(0);
  }
  function banner(text, life, hot) { G.banners.push({ text: text, life: life || 1.8, max: life || 1.8, hot: !!hot }); if (G.banners.length > 3) G.banners.shift(); }
  /* the cap is a full field's worth (48 plots, a coin pop and a tool pop each): at 14, HARVEST ALL
   * popped only the last 14 plots and the first 34 were reaped with no feedback (final review) */
  function pop(text, x, y, color) { G.pops.push({ text: text, x: x, y: y, life: 1.1, color: color || C.ink }); if (G.pops.length > 100) G.pops.shift(); }

  /* ── the raid ─────────────────────────────────────────────────────────────────────── */
  function startRaid(zoneId) {
    var st = G.st, z = Z.zone(zoneId);
    if (!z || Z.ZONES.indexOf(z) >= st.permits) return;
    G.zoneId = zoneId;
    var kit = SIM.takeKit(st);
    var seed = ((Math.floor(st.t * 1000) >>> 0) ^ Math.imul(st.stats.raids + 1, 2654435761)) >>> 0;
    G.rd = RAID.create({ zone: zoneId, seed: seed, slots: SIM.packSlots(st), weight: SIM.packWeight(st), kit: kit,
      boots: st.upgrades.boots, pouch: st.upgrades.pouch, missing: Z.codexIds().filter(function (id) { return !st.codex[id]; }), wantCentrepiece: !SIM.hasCentrepiece(st) });
    G.lastRaidLog = 0; G.acc = 0; G.steer = null; G.held = {};
    save();
    go('raid');
    banner(z.name.toUpperCase() + ' · THE STORM COMES FROM THE WEST', 2.6, true);
  }
  function finishRaid() {
    var rd = G.rd, st = G.st;
    /* tools thrown were already taken off the away kit as they were used; settle returns the rest */
    var res = SIM.settleRaid(st, rd.outcome, rd.pack, {});
    G.result = { outcome: rd.outcome, res: res, zone: rd.zone, secs: rd.t };
    A.sfx(rd.outcome === 'lifted' ? 'lifted' : 'lost');
    if (res.got.newStrains.length) setTimeout(function () { A.sfx('fresh'); }, 700);
    save();
    go('result');
  }
  function raidInput(verb, v) { if (G.rd && !G.rd.over) RAID.setKey(G.rd, verb, v); }

  /* ── the frame ────────────────────────────────────────────────────────────────────── */
  var last = 0;
  function loop(now) {
    requestAnimationFrame(loop);
    if (G.frozen) return;
    var dt = last ? Math.min(0.05, (now - last) / 1000) : 1 / 60;
    last = now;
    update(dt);
    draw();
  }
  function update(dt) {
    G.t += dt;
    if (G.screen === 'loading') { if (fontsReady && G.toLoad > 0 && G.loaded >= G.toLoad) go('title'); return; }
    var paused = G.overlay === 'pause' || G.overlay === 'welcome' || G.overlay === 'ending' || G.overlay === 'confirmNew';
    if (G.playing && !paused) {
      SIM.tick(G.st, dt);
      reactFarm();
      if (G.screen === 'raid' && G.rd && !G.rd.over) updateRaid(dt);
      if (G.t - G.lastSave > 10 && G.screen !== 'raid') save();
    }
    for (var i = G.pops.length - 1; i >= 0; i--) { G.pops[i].life -= dt; if (G.pops[i].life <= 0) G.pops.splice(i, 1); }
    for (var j = G.banners.length - 1; j >= 0; j--) { G.banners[j].life -= dt; if (G.banners[j].life <= 0) G.banners.splice(j, 1); }
    if (G.fade > 0) G.fade = Math.max(0, G.fade - dt / 0.3);
    if (G.flash > 0) G.flash = Math.max(0, G.flash - dt * 2);
    A.pump();
  }
  function updateRaid(dt) {
    var rd = G.rd;
    steerFromPointer();
    G.acc = (G.acc || 0) + dt;
    var n = Math.floor(G.acc / RAID.H); G.acc -= n * RAID.H;
    for (var i = 0; i < n && !rd.over; i++) { if (G.autoplay) RAID.bot(rd, { tools: true }); RAID.tick(rd); }
    reactRaid();
    var ahead = Math.max(0, rd.p.x - rd.stormX);
    A.storm(Math.max(0, 1 - ahead / 14));
    if (rd.over) finishRaid();
  }
  function steerFromPointer() {
    if (!G.steer || !G.rd) return;
    var cam = R.camera(G.rd), px = G.rd.p.x * R.TILE - cam.x, py = G.rd.p.y * R.TILE - cam.y;
    var dx = G.steer.x - px, dy = G.steer.y - py, d = Math.hypot(dx, dy);
    RAID.setKey(G.rd, 'stick', d < 14 ? { x: 0, y: 0 } : { x: dx / d, y: dy / d });
  }

  /* ⛔ THE HYBRID WALL, found by the release playthrough on 3 of 10 seeds: every wild strain the open
   * zones hold was in the codex, the next permit wanted one more entry, and only a HYBRID could be
   * it; nothing said so, and the campaign stalled at 12 of 13 forever. When exactly that state
   * holds, the game says it once per sitting and the locked zone card says it for as long as it holds. */
  function crossNeeded() {
    var st = G.st, pr = SIM.nextPermit(st);
    if (!pr || pr.haveCodex) return false;
    for (var i = 0; i < st.permits; i++) {
      var zs = Z.strainsOf(Z.ZONES[i].id);
      for (var k = 0; k < zs.length; k++) if (!st.codex[zs[k].id]) return false;
    }
    return true;
  }
  G.crossNeeded = crossNeeded;
  /* Everything the farm logged becomes a sound and a picture. */
  function reactFarm() {
    var st = G.st;
    if (!G.hintedCross && G.screen === 'farm' && !G.overlay && crossNeeded()) { G.hintedCross = true; banner('EVERY WILD STRAIN HERE IS FOUND: CROSS TWO FOR A HYBRID', 4.5, true); }
    for (var i = G.lastFarmLog; i < st.log.length; i++) {
      var e = st.log[i];
      if (e.ev === 'harvest') {
        var at = plotCentre(e.c, e.r);
        if (at && G.screen === 'farm') pop('+' + e.coin, at.x, at.y - 18, C.goldDeep);
        if (e.hybrids && e.hybrids.length) { A.sfx('cross'); banner('A CROSS: ' + e.hybrids.map(function (h) { return Z.strain(h).name; }).join(', ').toUpperCase() + ' SEED!', 2.6, true); }
        else if (G.screen === 'farm' && !e.byHands) A.sfx('harvest');
        /* tool pops sit BELOW the coin pop and stagger by column: two neighbours read "+1 LURE+1 LURE" as
         * one string (final review), and above the coin pop a top-row "+1 LURE" rose into the HUD's codex
         * chip (seen in the store GIF once HARVEST ALL popped every plot) */
        if (e.tool) { var tn = e.tool === 'lure' ? 'LURE' : 'SMOKE POT'; if (at && G.screen === 'farm') pop('+' + (e.toolN || 1) + ' ' + tn, at.x, at.y + 4 + (e.c % 2) * 18, C.leaf); }
      } else if (e.ev === 'ending') {
        A.sfx('ending'); G.overlay = 'ending'; G.focus = 0;
      } else if (e.ev === 'buy') { A.sfx('buy'); }
      else if (e.ev === 'permit') { A.sfx('permit'); banner(Z.zone(e.zone).name.toUpperCase() + ' IS OPEN', 2.4, true); }
    }
    G.lastFarmLog = st.log.length;
    if (st.log.length > 400) { st.log.splice(0, st.log.length - 200); G.lastFarmLog = st.log.length; }
  }
  var SEEN_NAME = function (it) { return it.kind === 'coin' ? it.amount + ' COIN' : Z.strain(it.strain).name.toUpperCase(); };
  function reactRaid() {
    var rd = G.rd;
    for (var i = G.lastRaidLog; i < rd.log.length; i++) {
      var e = rd.log[i];
      if (e.ev === 'pickup') { A.sfx(e.fresh ? 'fresh' : (e.kind === 'coin' ? 'coin' : 'pickup')); if (e.fresh) banner('NEW STRAIN: ' + Z.strain(e.strain).name.toUpperCase(), 2, true); }
      else if (e.ev === 'swap') { A.sfx('swap'); banner('SWAPPED ' + nameOf(e.left) + ' FOR ' + nameOf(e.took), 1.6); }
      else if (e.ev === 'packfull') { A.sfx('packfull'); banner('PACK FULL', 1.1); }
      else if (e.ev === 'spill') { A.sfx('spill'); G.flash = 0.5; banner('A BOAR KNOCKED ' + nameOf(e.strain || 'coin') + ' OUT OF YOUR PACK', 1.8); }
      else if (e.ev === 'steal') { A.sfx('steal'); banner('A CROW TOOK ' + nameOf(e.strain || 'coin') + ': CATCH IT!', 1.8); }
      else if (e.ev === 'recover') { A.sfx('recover'); }
      else if (e.ev === 'crowLost') { banner('THE CROW GOT AWAY WITH ' + nameOf(e.strain || 'coin'), 1.8); }
      else if (e.ev === 'lure') { A.sfx('lure'); if (G.st.away) G.st.away.lure = Math.max(0, G.st.away.lure - 1); }
      else if (e.ev === 'smoke') { A.sfx('smoke'); if (G.st.away) G.st.away.smoke = Math.max(0, G.st.away.smoke - 1); }
      else if (e.ev === 'empty') { A.sfx('refuse'); banner(e.what === 'lure' ? 'NO LURES: GROW SWEETROOT' : 'NO SMOKE: GROW SMOKEHERB', 1.4); }
      else if (e.ev === 'dash') A.sfx('dash');
      else if (e.ev === 'boarAim') A.sfx('boarAim');
      else if (e.ev === 'boarCharge') A.sfx('boarCharge');
      else if (e.ev === 'crowIn') A.sfx('crowIn');
      else if (e.ev === 'liftopen') A.sfx('liftopen');
    }
    G.lastRaidLog = rd.log.length;
  }
  function nameOf(id) { return id === 'coin' ? 'COIN' : (Z.strain(id) ? Z.strain(id).name.toUpperCase() : String(id).toUpperCase()); }

  /* ── drawing ──────────────────────────────────────────────────────────────────────── */
  function draw() {
    var k = canvas.width / G.W;
    ctx.setTransform(k, 0, 0, k, 0, 0);
    ctx.imageSmoothingEnabled = false;
    /* the focus ring marks the button ENTER will fire; the farm and the raid have their own keys
     * (a plot cursor, the raid's verbs), so no menu ring is drawn there unless an overlay is up */
    var fids = menuIds(), menuMode = G.overlay || (G.screen !== 'farm' && G.screen !== 'raid');
    R.focusId = menuMode && fids.length ? fids[((G.focus % fids.length) + fids.length) % fids.length] : null;
    R.hits = [];
    if (G.screen === 'loading') drawLoading();
    else if (G.screen === 'title') drawTitle();
    else if (G.screen === 'farm') drawFarm();
    else if (G.screen === 'zones') drawZones();
    else if (G.screen === 'raid') drawRaid();
    else if (G.screen === 'result') drawResult();
    else if (G.screen === 'shop') drawShop();
    else if (G.screen === 'codex') drawCodex();
    else if (G.screen === 'howto') drawHowto();
    else if (G.screen === 'credits') drawCredits();
    drawPops(); drawBanners();
    if (G.overlay === 'pause') drawPause();
    else if (G.overlay === 'welcome') drawWelcome();
    else if (G.overlay === 'ending') drawEnding();
    else if (G.overlay === 'confirmNew') drawConfirmNew();
    if (G.fade > 0) { ctx.fillStyle = 'rgba(27,22,34,' + (G.fade * G.fade * 0.85).toFixed(3) + ')'; ctx.fillRect(0, 0, G.W, G.H); }
    G.hitsCache = R.hits.slice();
  }

  function drawLoading() {
    var W = G.W, H = G.H;
    ctx.fillStyle = C.ink; ctx.fillRect(0, 0, W, H);
    var p = G.toLoad ? G.loaded / G.toLoad : 0;
    ctx.fillStyle = 'rgba(246,239,217,0.25)'; ctx.fillRect(W / 2 - 120, H / 2 + 20, 240, 6);
    ctx.fillStyle = C.gold; ctx.fillRect(W / 2 - 120, H / 2 + 20, 240 * p, 6);
    R.text('SOWING', W / 2, H / 2 - 4, { font: R.font(20, true), align: 'center', color: C.paper });
  }

  /* a backdrop for menus: the painted key art when present, the farm's grass otherwise */
  function backdrop(dim) {
    var W = G.W, H = G.H, im = R.img.key_title;
    if (im && im.width) {
      var s = Math.max(W / im.width, H / im.height), w = im.width * s, h = im.height * s;
      ctx.save(); ctx.imageSmoothingEnabled = true; ctx.drawImage(im, (W - w) / 2, (H - h) / 2, w, h); ctx.restore();
    } else R.fillPattern('gnd_farm_grass', 0, 0, W, H, '#6f9a4a');
    if (dim) { ctx.fillStyle = 'rgba(27,22,34,' + dim + ')'; ctx.fillRect(0, 0, W, H); }
  }
  function header(title, sub) {
    var W = G.W, tall = G.shape === 'tall';
    /* a title never reaches the top-left BACK button: fitted between the two 130 px margins */
    R.text(title, W / 2, tall ? 66 : 56, { font: R.fit(title, tall ? 38 : 40, W - 272, true), align: 'center', color: C.paper, stroke: C.ink, strokeW: 7 });
    if (sub) {
      var f = R.font(tall ? 17 : 17, false, 800), lines = R.wrap(sub, f, W - 48);
      for (var i = 0; i < lines.length; i++) R.text(lines[i], W / 2, (tall ? 96 : 84) + i * 21, { font: f, align: 'center', color: C.paper, stroke: C.ink, strokeW: 5 });
      return (tall ? 96 : 84) + lines.length * 21;
    }
    return tall ? 84 : 70;
  }

  /* THE LOCKUP: SEEDLIFT in the display face, the dot of the i a rising balloon */
  function lockup(cx, y, px) {
    var f = R.font(px, true);
    var w = R.measure('SEEDLIFT', f);
    R.text('SEEDLIFT', cx, y, { font: f, align: 'center', color: C.gold, stroke: C.ink, strokeW: Math.max(5, px * 0.16), shadow: 'rgba(27,22,34,0.45)', sh: px * 0.07 });
    var bob = Math.sin(G.t * 1.6) * 4;
    R.sprite('prop_balloon', cx + w / 2 + px * 0.35, y - px * 0.25 + bob, Math.max(1, Math.round(px / 40)), { rec: true });
    return w;
  }

  function drawTitle() {
    var W = G.W, H = G.H, tall = G.shape === 'tall';
    backdrop(0.05);
    /* the panel is sized from what it holds (a fixed panel let the second line of the subtitle
     * hang out of its bottom edge), and sits over the storm so the key art's balloon stays clear */
    var pw = tall ? 500 : 520, lpx = tall ? 76 : 80;
    /* broken at the sentence, never mid-phrase ("Beat the / storm to the lift." read as a fragment) */
    var sub = ['Farm at home. Raid the wilds for new seed.', 'Beat the storm to the lift.'];
    var f = R.font(tall ? 18 : 18, false, 800), lines = [];
    sub.forEach(function (sent) { lines = lines.concat(R.wrap(sent, f, pw - 48)); });
    /* wide: 46 px down, so the lockup's balloon (the dot of the i, ~96 px tall at x2) clears the canvas
     * top instead of being cut flat by it */
    var ph = lpx + 44 + lines.length * 24 + 18, ppx = tall ? W / 2 - pw / 2 : 28, ppy = tall ? 110 : 46;
    R.paper(ppx, ppy, pw, ph, { r: 16, fill: 'rgba(246,239,217,0.92)' });
    var ly = ppy + 26 + lpx * 0.8;
    lockup(ppx + pw / 2 - (tall ? 22 : 24), ly, lpx);
    for (var i = 0; i < lines.length; i++) R.text(lines[i], ppx + pw / 2, ly + 36 + i * 24, { font: f, align: 'center', color: C.ink });
    var items = [];
    if (G.hasSave) items.push(['continue', 'CONTINUE']);
    items.push(['newfarm', G.hasSave ? 'NEW FARM' : 'START A FARM']);
    items.push(['howto', 'HOW TO PLAY']); items.push(['credits', 'CREDITS']);
    var bw = tall ? 320 : 200, bh = tall ? 62 : 54, gap = 14;
    if (tall) {
      var y0 = 520;
      for (var j = 0; j < items.length; j++) R.button(items[j][0], items[j][1], W / 2 - bw / 2, y0 + j * (bh + gap), bw, bh, { display: j === 0, gold: j === 0, px: 24 });
    } else {
      var total = items.length * bw + (items.length - 1) * gap, x0 = W / 2 - total / 2;
      for (var q = 0; q < items.length; q++) R.button(items[q][0], items[q][1], x0 + q * (bw + gap), H - 92, bw, bh, { display: q === 0, gold: q === 0, px: 22 });
    }
    soundChip(W - 16 - 136, 16);
    if (G.saveRefused) R.text('Your save could not be read (' + G.saveRefused + '), so a new farm starts.', W / 2, H - (tall ? 60 : 16), { font: R.font(14, false, 800), align: 'center', color: C.paper, stroke: C.ink, strokeW: 4 });
  }
  function soundChip(x, y) { R.button('sound', A.muted ? 'SOUND OFF' : 'SOUND ON', x, y, 136, 40, { px: 16 }); }

  /* ── the farm ─────────────────────────────────────────────────────────────────────── */
  function farmLayout() {
    var st = G.st, tall = G.shape === 'tall', W = G.W;
    /* the bed is the size of the field the player OWNS: a bed drawn for the largest field showed an
     * empty strip of bare earth around a small one */
    if (!tall) {
      var P = 60, fx = 24 + (8 - st.cols) * P / 2, fy = 78 + (6 - st.rows) * P / 2;
      return { P: P, fx: fx, fy: fy, bed: { x: fx - 8, y: fy - 8, w: st.cols * P + 16, h: st.rows * P + 16 }, panel: { x: 528, y: 70, w: 416, h: 454 }, actY: 70 + 6 * P + 30 };
    }
    var P2 = 56, fx2 = (W - st.cols * P2) / 2, fy2 = 128 + (6 - st.rows) * P2 / 2;
    return { P: P2, fx: fx2, fy: fy2, bed: { x: fx2 - 8, y: fy2 - 8, w: st.cols * P2 + 16, h: st.rows * P2 + 16 }, panel: { x: 16, y: 540, w: W - 32, h: 406 }, actY: 120 + 6 * P2 + 26 };
  }
  function plotCentre(c, r) { if (!G.st) return null; var L = farmLayout(); return { x: L.fx + c * L.P + L.P / 2, y: L.fy + r * L.P + L.P / 2 }; }

  function chip(x, y, w, h, icon, value, owner) {
    R.paper(x, y, w, h, { r: 10, owner: owner });
    R.icon(icon, x + 22, y + h / 2, 24);
    R.text(value, x + 40, y + h / 2 + 1, { font: R.fit(value, 20, w - 48, true, 600, 11), base: 'middle', owner: owner });
  }
  function farmTop() {
    var st = G.st, W = G.W, tall = G.shape === 'tall';
    var coin = Math.floor(st.coin).toLocaleString('en-US');
    if (!tall) {
      chip(16, 12, 150, 44, 'coin', coin, 'coin');
      chip(174, 12, 150, 44, 'codex', SIM.codexCount(st) + '/24', 'codex');
      chip(332, 12, 118, 44, 'prop_lure', st.tools.lure + ' LURE', 'lure');
      chip(458, 12, 132, 44, 'prop_smoke', st.tools.smoke + ' SMOKE', 'smoke');
      soundChip(W - 16 - 96 - 10 - 136, 14);
      R.button('pause', 'MENU', W - 16 - 96, 14, 96, 40, { px: 16 });
    } else {
      chip(16, 12, 164, 46, 'coin', coin, 'coin');
      chip(188, 12, 150, 46, 'codex', SIM.codexCount(st) + '/24', 'codex');
      R.button('pause', 'MENU', W - 16 - 100, 14, 100, 42, { px: 16 });
      chip(16, 66, 164, 44, 'prop_lure', st.tools.lure + ' LURE', 'lure');
      chip(188, 66, 164, 44, 'prop_smoke', st.tools.smoke + ' SMOKE', 'smoke');
      soundChip(W - 16 - 136, 68);
    }
  }
  function drawFarm() {
    var st = G.st, W = G.W, H = G.H, L = farmLayout(), P = L.P, tall = G.shape === 'tall';
    R.fillPattern('gnd_farm_grass', 0, 0, W, H, '#6f9a4a');
    /* the bed: a packed-earth border with a split-rail fence */
    var b = L.bed;
    ctx.save();
    ctx.fillStyle = 'rgba(27,22,34,0.30)'; R.rr(b.x + 3, b.y + 5, b.w, b.h, 10); ctx.fill();
    ctx.fillStyle = R.pattern('gnd_farm_path') || '#a88257'; R.rr(b.x, b.y, b.w, b.h, 10); ctx.fill();
    ctx.restore();
    for (var fxp = b.x + 6; fxp <= b.x + b.w - 6; fxp += 30) { ctx.fillStyle = '#4a3326'; ctx.fillRect(fxp - 3, b.y - 8, 6, 12); ctx.fillRect(fxp - 3, b.y + b.h - 4, 6, 12); ctx.fillStyle = '#8c6441'; ctx.fillRect(fxp - 2, b.y - 8, 3, 10); }
    ctx.fillStyle = '#6e4e37'; ctx.fillRect(b.x, b.y - 4, b.w, 3); ctx.fillRect(b.x, b.y + b.h + 1, b.w, 3);
    if (R.rec) R.rec.push({ kind: 'picture', what: 'bed', x: b.x, y: b.y - 8, w: b.w, h: b.h + 16 });
    for (var r = 0; r < st.rows; r++) for (var c = 0; c < st.cols; c++) drawPlot(c, r, L);
    /* the keyboard cursor */
    var cx = L.fx + G.cur.c * P, cy = L.fy + G.cur.r * P;
    if (G.lastInput === 'keys') { ctx.save(); ctx.strokeStyle = C.gold; ctx.lineWidth = 3; R.rr(cx + 1, cy + 1, P - 2, P - 2, 8); ctx.stroke(); ctx.restore(); }
    farmTop();
    drawFarmActions(L);
    drawSeedBank(L);
    drawFarmHint(L);
    drawFirstPrompt(L);
  }
  /* A brand-new farm said nothing about its first move: an empty grid and a permit bar, with "choose a
   * seed and click a plot" only behind HOW TO PLAY (final review). While the field is bare and nothing
   * has ever been harvested, the bed itself says what to do; the first seed sown takes it away. */
  function drawFirstPrompt(L) {
    var st = G.st;
    if (st.stats.harvests > 0 || st.stats.raids > 0 || st.plots.some(function (p) { return !!p; })) return;
    var b = L.bed, verb = G.touchSeen ? 'tap' : 'click';
    var txt = 'Pick a seed in the SEED BANK, then ' + verb + ' an empty plot to sow it.' + (G.touchSeen ? '' : ' SOW ALL (F) fills the field.');
    var f = R.font(16, false, 800), maxW = Math.min(b.w - 48, 340), lines = R.wrap(txt, f, maxW - 28);
    var lw = Math.max.apply(null, lines.map(function (ln) { return R.measure(ln, f); })), bw = lw + 28, bh = lines.length * 20 + 20;
    var x = b.x + (b.w - bw) / 2, y = b.y + (b.h - bh) / 2;
    R.paper(x, y, bw, bh, { r: 10, owner: 'firstmove' });
    for (var i = 0; i < lines.length; i++) R.text(lines[i], x + 14, y + 25 + i * 20, { font: f, owner: 'firstmove' });
  }
  function drawPlot(c, r, L) {
    var st = G.st, P = L.P, x = L.fx + c * P, y = L.fy + r * P, p = st.plots[r * st.cols + c];
    ctx.save();
    ctx.fillStyle = R.pattern('gnd_farm_soil') || '#6f4c33'; R.rr(x + 3, y + 3, P - 6, P - 6, 6); ctx.fill();
    ctx.strokeStyle = 'rgba(27,22,34,0.35)'; ctx.lineWidth = 2; R.rr(x + 3, y + 3, P - 6, P - 6, 6); ctx.stroke();
    ctx.restore();
    if (p) {
      var prog = SIM.progress(st, p), ripe = prog >= 1;
      if (ripe) { ctx.save(); ctx.globalAlpha = 0.35 + 0.15 * Math.sin(G.t * 3 + c + r); ctx.fillStyle = C.gold; R.rr(x + 5, y + 5, P - 10, P - 10, 6); ctx.fill(); ctx.restore(); }
      R.plant(p.strain, prog, x, y, P, G.t, ripe ? 1 : undefined);
      if (!ripe) {
        ctx.save(); ctx.strokeStyle = 'rgba(27,22,34,0.35)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(x + P - 12, y + 12, 6, 0, 7); ctx.stroke();
        ctx.strokeStyle = C.paper; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x + P - 12, y + 12, 6, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * prog); ctx.stroke(); ctx.restore();
      } else {
        var tw = Math.sin(G.t * 5 + c * 2 + r) > 0.2;
        if (tw) { ctx.fillStyle = '#fff08a'; ctx.fillRect(x + P - 14, y + 8, 3, 9); ctx.fillRect(x + P - 17, y + 11, 9, 3); }
      }
    }
    R.hit('plot_' + c + '_' + r, x, y, P, P);
  }
  function drawFarmActions(L) {
    var W = G.W, tall = G.shape === 'tall';
    /* the two field buttons sit on a FIXED line under the largest field, so they never move as the
     * field grows */
    var x0 = tall ? 16 : 16, span = tall ? W - 32 : 8 * L.P + 16, y = L.actY, bw = (span - 12) / 2;
    R.button('harvestAll', keyLabel('HARVEST ALL', 'H'), x0, y, bw, 42, { px: 17 });
    R.button('sowAll', keyLabel('SOW ALL', 'F'), x0 + bw + 12, y, bw, 42, { px: 17 });
  }
  function drawSeedBank(L) {
    var st = G.st, p = L.panel, tall = G.shape === 'tall', ids = bankIds();
    R.paper(p.x, p.y, p.w, p.h, { r: 14, owner: 'bank' });
    R.text('SEED BANK', p.x + 20, p.y + 34, { font: R.font(22, true), owner: 'bank' });
    if (!G.touchSeen) R.text('(Q / E to choose)', p.x + 20 + R.measure('SEED BANK', R.font(22, true)) + 12, p.y + 33, { font: R.font(14, false, 800), color: C.mute, owner: 'bank' });
    /* laid out TOP-DOWN from measured heights: with all 25 strains held, a fixed goal box and fixed
     * buttons landed on the fourth row of seed chips (the layout gate's fixture found it) */
    var cols = 8, cw = Math.floor((p.w - 32) / cols), ch = 46, x0 = p.x + 16, y0 = p.y + 46;
    var rows = Math.ceil(Math.max(1, ids.length) / cols);
    for (var i = 0; i < ids.length; i++) {
      var id = ids[i], cx = x0 + (i % cols) * cw, cy = y0 + Math.floor(i / cols) * ch, n = st.bank[id] | 0, sel = id === G.sel;
      ctx.save();
      ctx.fillStyle = sel ? 'rgba(247,195,90,0.55)' : 'rgba(84,57,42,0.08)'; R.rr(cx + 2, cy + 2, cw - 4, ch - 4, 8); ctx.fill();
      if (sel) { ctx.strokeStyle = C.goldDeep; ctx.lineWidth = 2.5; R.rr(cx + 2, cy + 2, cw - 4, ch - 4, 8); ctx.stroke(); }
      if (n === 0) ctx.globalAlpha = 0.35;
      R.icon('plant_' + id, cx + cw / 2 - 3, cy + ch / 2 - 2, 36);
      ctx.restore();
      R.text(String(n), cx + cw - 7, cy + ch - 7, { font: R.font(15, true), align: 'right', color: n ? C.ink : C.mute, stroke: C.paper, strokeW: 3, owner: 'seed_' + id });
      R.hit('seed_' + id, cx, cy, cw, ch);
      if (R.rec) R.rec.push({ kind: 'button', id: 'seed_' + id, label: String(n), x: cx, y: cy, w: cw, h: ch });
    }
    /* the chosen seed, in words */
    var s = Z.strain(G.sel), iy = y0 + rows * ch + 22;
    if (s) {
      R.text(s.name.toUpperCase(), p.x + 20, iy, { font: R.fit(s.name.toUpperCase(), 18, p.w - 40, true), owner: 'info' });
      var grow = Math.round(s.growSec / SIM.speed(st));
      var line = s.ending ? 'The flower you came for: a Cold Frame and ' + fmtTime(grow) + '.'
        : fmtTime(grow) + ' to ripen · sells for ' + Math.round(s.coin * SIM.yieldMul(st)) + ' coin' + (s.tool ? ' · makes ' + (s.tool.indexOf('lure') === 0 ? 'LURES' : 'SMOKE') : '') + (s.frame ? ' · needs a Cold Frame' : '');
      R.text(line, p.x + 20, iy + 21, { font: R.fit(line, 15, p.w - 40, false, 800, 11), owner: 'info' });
    }
    /* the goal, then the three doors out of the farm on ONE row */
    var gy = iy + 34, bw = p.w - 32, by = p.y + p.h - 62;
    drawGoal(p.x + 16, gy, bw, Math.min(72, by - gy - 10));
    var sw = tall ? 110 : 96, rw = bw - 2 * sw - 16;
    R.button('raid', keyLabel('GO RAIDING', 'R'), p.x + 16, by, rw, 50, { gold: true, display: true, px: 22, icon: 'prop_balloon' });
    R.button('shop', keyLabel('SHOP', 'B'), p.x + 16 + rw + 8, by, sw, 50, { px: 16 });
    R.button('codex', keyLabel('CODEX', 'C'), p.x + 16 + rw + sw + 16, by, sw, 50, { px: 16 });
  }
  /* NEXT GOAL: the next permit's two halves as bars, or the road to the ending once all are open */
  function drawGoal(x, y, w, h) {
    var st = G.st, pr = SIM.nextPermit(st);
    ctx.save(); ctx.fillStyle = 'rgba(63,122,69,0.12)'; R.rr(x, y, w, h, 10); ctx.fill(); ctx.restore();
    var bar = function (by, label, have, need, col) {
      var f = Math.max(0, Math.min(1, have / need)), bx = x + 150, bw2 = w - 162;
      R.text(label, x + 12, by + 9, { font: R.fit(label, 14, 132, false, 800), owner: 'goal' });
      ctx.fillStyle = 'rgba(27,22,34,0.15)'; ctx.fillRect(bx, by, bw2, 10);
      ctx.fillStyle = f >= 1 ? C.leaf : col; ctx.fillRect(bx, by, bw2 * f, 10);
    };
    if (pr && h < 66) {
      /* COMPACT: a short box (a full seed bank on a phone) gets one fitted line, never bars that
       * overrun the button row below it */
      var line = pr.zone.name.toUpperCase() + ' PERMIT: ' + nf(Math.min(Math.floor(st.coin), pr.coin)) + '/' + nf(pr.coin) + ' coin · ' + Math.min(SIM.codexCount(st), pr.codex) + '/' + pr.codex + ' strains';
      R.text(line, x + 12, y + h / 2 + 6, { font: R.fit(line, 15, w - 24, false, 800, 10), owner: 'goal' });
    } else if (pr) {
      R.text('NEXT: THE ' + pr.zone.name.toUpperCase() + ' PERMIT', x + 12, y + 22, { font: R.fit('NEXT: THE ' + pr.zone.name.toUpperCase() + ' PERMIT', 16, w - 24, true), owner: 'goal' });
      bar(y + 36, nf(Math.min(Math.floor(st.coin), pr.coin)) + '/' + nf(pr.coin) + ' coin', st.coin, pr.coin, C.gold);
      bar(y + 54, Math.min(SIM.codexCount(st), pr.codex) + '/' + pr.codex + ' strains', SIM.codexCount(st), pr.codex, C.amber);
    } else {
      var step = st.ended ? 'The centrepiece has flowered. Keep the farm growing.' : (SIM.hasCentrepiece(st) ? (st.upgrades.frame ? 'Plant the centrepiece and let it flower.' : 'Buy a Cold Frame, then plant the centrepiece.') : 'Find the centrepiece deep in the Ridge Garden, on the storm side.');
      R.text(st.ended ? 'IN FLOWER' : 'NEXT: THE CENTREPIECE', x + 12, y + 22, { font: R.font(16, true), owner: 'goal' });
      R.paragraph(step, x + 12, y + 42, w - 24, R.font(14, false, 800), 17, C.ink, null, 'goal');
    }
  }
  /* a key in a button label only where keys exist: once a finger has touched the screen the "(H)"
   * is noise (the review found every farm button carrying one on a touch-only phone) */
  function keyLabel(label, key) { return G.touchSeen ? label : label + ' (' + key + ')'; }
  /* every coin figure grouped the way the HUD groups it ("1,623", never "1623") */
  function nf(n) { return Math.floor(n).toLocaleString('en-US'); }
  function fmtTime(s) { s = Math.max(0, Math.round(s)); if (s < 60) return s + ' s'; var m = Math.floor(s / 60), r = s % 60; if (m < 60) return m + ' m' + (r ? ' ' + r + ' s' : ''); var h = Math.floor(m / 60); return h + ' h ' + (m % 60) + ' m'; }
  function drawFarmHint(L) {
    var st = G.st, tall = G.shape === 'tall', b = L.bed, p = st.plots[G.cur.r * st.cols + G.cur.c];
    if (G.lastInput !== 'keys') return;
    var txt;
    if (!p) txt = 'Empty plot: ENTER sows ' + (Z.strain(G.sel) ? Z.strain(G.sel).name : 'a seed') + '.';
    else if (SIM.mature(st, p)) txt = Z.strain(p.strain).name + ' is ripe: ENTER harvests.';
    else txt = Z.strain(p.strain).name + ': ' + fmtTime((1 - SIM.progress(st, p)) * Z.strain(p.strain).growSec / SIM.speed(st)) + ' to ripen.';
    if (G.shape === 'tall') return;            /* an upright phone is a touch device: no key hints */
    var y = L.actY + 66, x0 = 16, span = 8 * L.P + 16;
    /* on paper, like every other string in the game (bare outlined text on the grass read as debug) */
    var hf = R.fit(txt, 15, span - 28, false, 800), hw = R.measure(txt, hf);
    R.paper(x0, y - 20, hw + 24, 28, { r: 8, owner: 'farmhint' });
    R.text(txt, x0 + 12, y, { font: hf, color: C.ink, owner: 'farmhint' });
  }
  function farmAct(c, r) {
    var st = G.st, p = st.plots[r * st.cols + c];
    G.cur = { c: c, r: r };
    if (p && SIM.mature(st, p)) { SIM.harvest(st, c, r); return; }
    if (p) { var at0 = plotCentre(c, r); pop(fmtTime((1 - SIM.progress(st, p)) * Z.strain(p.strain).growSec / SIM.speed(st)), at0.x, at0.y - 10, C.paper); return; }
    var res = SIM.plant(st, c, r, G.sel), at = plotCentre(c, r);
    if (res.ok) { A.sfx('plant'); nextSeedIfOut(); }
    else { A.sfx('refuse'); pop(res.why === 'no-seed' ? 'NO SEED' : (res.why === 'needs-frame' ? 'NEEDS A COLD FRAME' : 'NO'), at.x, at.y - 10, C.red); }
  }
  function harvestAll() { var st = G.st, n = 0; for (var r = 0; r < st.rows; r++) for (var c = 0; c < st.cols; c++) { var p = st.plots[r * st.cols + c]; if (p && SIM.mature(st, p) && SIM.harvest(st, c, r).ok) n++; } if (!n) { A.sfx('refuse'); banner('NOTHING IS RIPE YET', 1.2); } }
  /* When the chosen seed runs out, the choice moves to the next seed that has stock, and SOW ALL says
   * so: a new farm pressed F, sowed its 2 Sweetroot, then answered NO SWEETROOT SEED LEFT with 28 plots
   * empty and 2 Hedge Pea unused (final review). SOW ALL still sows the CHOSEN seed only: where a seed
   * goes decides which hybrids can cross, so it never spends a seed the player did not pick. */
  function nextSeedIfOut() {
    var st = G.st;
    if (st.bank[G.sel] > 0) return null;
    var ids = bankIds(), i = ids.indexOf(G.sel);
    for (var k = 1; k <= ids.length; k++) { var id = ids[(i + k + ids.length) % ids.length]; if (id !== 'centrepiece' && st.bank[id] > 0) { G.sel = id; return id; } }
    return null;
  }
  function sowAll() {
    var st = G.st, n = 0, why = null, was = G.sel;
    for (var r = 0; r < st.rows; r++) for (var c = 0; c < st.cols; c++) { if (st.plots[r * st.cols + c]) continue; var res = SIM.plant(st, c, r, G.sel); if (res.ok) n++; else why = res.why; }
    var next = nextSeedIfOut(), empty = st.plots.indexOf(null) >= 0;
    if (n) {
      A.sfx('plant');
      if (next && empty) banner((Z.strain(was) ? Z.strain(was).name.toUpperCase() : 'THAT SEED') + ' USED UP: ' + Z.strain(next).name.toUpperCase() + ' IS CHOSEN', 2.2);
    } else {
      A.sfx('refuse');
      banner(why === 'needs-frame' ? 'THAT SEED NEEDS A COLD FRAME' : (why === 'no-seed' ? (next ? 'NO ' + (Z.strain(was) ? Z.strain(was).name.toUpperCase() : '') + ' LEFT: ' + Z.strain(next).name.toUpperCase() + ' IS CHOSEN' : 'NO SEED LEFT: RAID FOR MORE') : 'NO EMPTY PLOTS'), 1.8);
    }
  }
  function cycleSeed(d) { var ids = bankIds(); if (!ids.length) return; var i = ids.indexOf(G.sel); G.sel = ids[((i < 0 ? 0 : i + d) + ids.length) % ids.length]; A.sfx('menuMove'); }

  /* ── where to ─────────────────────────────────────────────────────────────────────── */
  function drawZones() {
    var st = G.st, W = G.W, H = G.H, tall = G.shape === 'tall';
    R.fillPattern('gnd_farm_grass', 0, 0, W, H, '#6f9a4a'); ctx.fillStyle = 'rgba(27,22,34,0.35)'; ctx.fillRect(0, 0, W, H);
    var kit = SIM.kit(st);
    var bottom = header('WHERE TO?', 'You carry ' + kit.lure + ' lure' + (kit.lure === 1 ? '' : 's') + ' and ' + kit.smoke + ' smoke pot' + (kit.smoke === 1 ? '' : 's') + ' · pack ' + SIM.packSlots(st) + ' slots, weight ' + SIM.packWeight(st));
    var cols = tall ? 2 : 4, cw = tall ? 244 : 218, ch = tall ? 330 : 350, gx = 16, x0 = W / 2 - (cols * cw + (cols - 1) * gx) / 2, y0 = bottom + 14;
    Z.ZONES.forEach(function (z, i) {
      var x = x0 + (i % cols) * (cw + gx), y = y0 + Math.floor(i / cols) * (ch + 14);
      drawZoneCard(z, i, x, y, cw, ch);
    });
    R.button('back', 'BACK TO THE FARM', 16, H - (tall ? 76 : 58), tall ? W - 32 : 240, 46, { px: 18 });
  }
  function drawZoneCard(z, i, x, y, w, h) {
    var st = G.st, open = i < st.permits, next = i === st.permits;
    R.paper(x, y, w, h, { r: 12, fill: open ? C.paper : C.paperShade, owner: 'zone' + i });
    /* the picture band: the zone's own ground, its strains standing on it */
    var bh = 108;
    ctx.save(); R.rr(x + 8, y + 8, w - 16, bh, 8); ctx.clip();
    ctx.fillStyle = R.pattern('gnd_' + z.id + '_ground') || '#7d9a55'; ctx.fillRect(x + 8, y + 8, w - 16, bh);
    var strains = Z.strainsOf(z.id);
    strains.forEach(function (s, k) {
      var sx = x + 8 + (w - 16) * (k + 0.5) / 4, known = st.codex[s.id];
      ctx.save(); if (!known) { ctx.globalAlpha = 0.9; ctx.filter = 'brightness(0) opacity(0.45)'; }
      R.sprite('plant_' + s.id, sx, y + 8 + bh - 12, 1);
      ctx.restore();
    });
    if (!open) { ctx.fillStyle = 'rgba(227,215,184,0.55)'; ctx.fillRect(x + 8, y + 8, w - 16, bh); }
    ctx.restore();
    if (R.rec) R.rec.push({ kind: 'picture', what: 'zoneband', x: x + 8, y: y + 8, w: w - 16, h: bh });
    var ty = y + bh + 42;
    R.text(z.n + '', x + 16, ty, { font: R.font(26, true), color: open ? C.goldDeep : C.mute, owner: 'zone' + i });
    R.text(z.name.toUpperCase(), x + 44, ty, { font: R.fit(z.name.toUpperCase(), 21, w - 60, true), color: open ? C.ink : C.mute, owner: 'zone' + i });
    var found = Z.strainsOf(z.id).filter(function (s) { return st.codex[s.id]; }).length;
    R.text(found + ' of 4 strains found', x + 16, ty + 24, { font: R.font(14, false, 800), color: C.mute, owner: 'zone' + i });
    R.paragraph(z.blurb, x + 16, ty + 48, w - 32, R.font(15, false, 600), 19, C.ink, null, 'zone' + i);
    var by = y + h - 56;
    /* ONE size for every footer line on this screen, fitted to the LONGEST lock line any card can
     * print: each line used to fit itself, so "Open Old Orchard first" sat visibly smaller than "Open
     * Fen first" beside it and the permit line (the key progression requirement) was the smallest
     * text in the game at ~9 px (final review) */
    var footPx = zoneFootPx(w);
    if (open) R.button('raid_' + z.id, 'RAID ' + z.name.toUpperCase(), x + 12, by, w - 24, 44, { gold: true, px: 17 });
    else if (next) {
      var pr = SIM.nextPermit(st), can = pr.haveCoin && pr.haveCodex;
      /* no "Permit:" prefix: BUY PERMIT is the button right under it */
      var permitTxt = nf(z.permitCoin) + ' coin · ' + z.permitCodex + ' strains in the codex';
      if (R.measure(permitTxt, R.font(footPx, false, 800)) > w - 32) permitTxt = nf(z.permitCoin) + ' coin · ' + z.permitCodex + ' strains';
      R.text(permitTxt, x + 16, by - 12, { font: R.fit(permitTxt, footPx, w - 32, false, 800, 12), color: can ? C.leaf : C.red, owner: 'zone' + i });
      /* the hybrid hint rides on the picture band (under the blurb it collided with the fourth line) */
      if (crossNeeded()) {
        var hx = x + 14, hw = w - 28, hyy = y + 8 + bh - 30;
        R.paper(hx, hyy, hw, 26, { r: 7, fill: '#fff08a', owner: 'zonehint' + i });
        R.text('Grow a hybrid: cross two strains', hx + hw / 2, hyy + 18, { font: R.fit('Grow a hybrid: cross two strains', 14, hw - 16, false, 800), align: 'center', color: C.ink, owner: 'zonehint' + i });
      }
      R.button('permit', 'BUY PERMIT', x + 12, by, w - 24, 44, { off: !can, clickableOff: true, px: 17 });
    } else {
      /* the lock and its line are centred TOGETHER in the empty footer (a locked card has no button) */
      var lockTxt = 'Open ' + Z.ZONES[i - 1].name + ' first', lf = R.font(footPx, false, 800), lw = R.measure(lockTxt, lf), lx = x + w / 2 - (lw + 28) / 2;
      R.icon('lock', lx + 11, by + 22, 22);
      R.text(lockTxt, lx + 28, by + 28, { font: lf, color: C.mute, owner: 'zone' + i });
    }
  }
  /* the footer size: the largest (15 px at most, 12 at least) at which EVERY lock line fits beside its
   * lock icon on this card width */
  function zoneFootPx(w) {
    var px = 15;
    var widest = function (p) { return Math.max.apply(null, Z.ZONES.slice(0, -1).map(function (zz) { return R.measure('Open ' + zz.name + ' first', R.font(p, false, 800)); })); };
    while (px > 12 && widest(px) + 28 > w - 24) px--;
    return px;
  }

  /* ── the raid ─────────────────────────────────────────────────────────────────────── */
  function raidButtons() {
    var W = G.W, H = G.H, tall = G.shape === 'tall';
    var s = tall ? 92 : 76, g = 10, x1 = W - 16 - s * 2 - g, y1 = H - 16 - s * 2 - g;
    return [
      { id: 'b_lift', verb: 'action', label: 'LIFT', x: x1 + s + g, y: y1 + s + g, w: s, h: s, icon: 'lift' },
      { id: 'b_lure', verb: 'lure', label: 'LURE', x: x1, y: y1 + s + g, w: s, h: s, icon: 'prop_lure' },
      { id: 'b_smoke', verb: 'smoke', label: 'SMOKE', x: x1 + s + g, y: y1, w: s, h: s, icon: 'prop_smoke' },
      { id: 'b_dash', verb: 'dash', label: 'DASH', x: x1, y: y1, w: s, h: s, icon: 'dash' },
    ];
  }
  function drawRaid() {
    var rd = G.rd, W = G.W, H = G.H, tall = G.shape === 'tall';
    /* how far the view may run past each map edge: the depth of the HUD papers on that side, so a
     * player in any corner stands clear of them (a release test holds this to every
     * walkable tile). Wide: the button block is 178 deep at the right and bottom; the pack is 100 at
     * the top. Tall: the button block is 210 wide; a corner player clears the minimap sideways. */
    R.camPad = tall ? { l: 40, r: 230, t: 120, b: 40 } : { l: 40, r: 200, t: 120, b: 200 };
    R.drawRaid(rd, G.t, { flash: G.flash });
    /* the HUD is a layer OVER the world: its opaque papers hide world words beneath them */
    R.layer('hud');
    /* the pack */
    var slotS = tall ? 46 : 44, px = 12, py = 12, pw = 16 + rd.slots * (slotS + 6) + 4;
    R.paper(px, py, Math.max(pw, 180), slotS + 44, { r: 10, owner: 'pack' });
    for (var i = 0; i < rd.slots; i++) {
      var sx = px + 10 + i * (slotS + 6), sy = py + 10, it = rd.pack[i];
      ctx.save(); ctx.fillStyle = i < rd.pouch ? 'rgba(83,176,160,0.25)' : 'rgba(84,57,42,0.12)'; R.rr(sx, sy, slotS, slotS, 7); ctx.fill();
      if (i < rd.pouch) { ctx.strokeStyle = '#2e7a78'; ctx.lineWidth = 2; R.rr(sx, sy, slotS, slotS, 7); ctx.stroke(); }
      ctx.restore();
      if (it) R.icon(it.kind === 'coin' ? 'prop_coin' : 'plant_' + it.strain, sx + slotS / 2, sy + slotS / 2, slotS - 8);
    }
    /* the weight bar says WEIGHT in words: beside five slot boxes a bare "6/8" read as six of eight
     * SLOTS (final review), and a rare pod weighs 2, the centrepiece 3 */
    var wt = RAID.packWeight(rd), wy = py + slotS + 22, PW = Math.max(pw, 180);
    var wTxt = 'WEIGHT ' + wt + '/' + rd.weightCap, wf = R.font(14, false, 800), wW = R.measure(wTxt, wf), barW = Math.max(40, PW - 32 - wW - 22);
    R.icon('weight', px + 18, wy + 2, 16);
    ctx.fillStyle = 'rgba(27,22,34,0.15)'; ctx.fillRect(px + 32, wy - 4, barW, 10);
    ctx.fillStyle = wt / rd.weightCap > 0.75 ? C.red : C.leaf; ctx.fillRect(px + 32, wy - 4, barW * Math.min(1, wt / rd.weightCap), 10);
    R.text(wTxt, px + PW - 10, wy + 6, { font: wf, align: 'right', owner: 'pack' });
    /* the minimap and the storm's distance */
    var ms = tall ? 3 : 3, mx = W - 16 - RAID.MW * ms, my = 18;
    if (tall) my = py + slotS + 70;
    var gap = Math.max(0, rd.p.x - rd.stormX);
    var sy2 = my + RAID.MH * ms + 16;
    /* a lift under the minimap or the storm chip was hidden by them (final review: an OPEN lift's
     * balloon under the minimap). While any lift or the farmer is beneath that block, the block turns
     * see-through, so the world under it reads; the numbers on it stay legible at this alpha */
    var mapRect = { x: mx - 6, y: my - 6, w: RAID.MW * ms + 12, h: sy2 + 36 - (my - 6) };
    /* each thing is tested by its DRAWN extent, not its ground point: a closed lift's ghost balloon
     * hangs ~140 px above its ring, so testing the ring left the balloon tucked under the storm chip
     * with the block opaque (caught looking at the raid screen after the first fix) */
    var camNow = R.camera(rd), under = function (wx, wy, hw, up, down) {
      var sx = wx * R.TILE - camNow.x, sy = wy * R.TILE - camNow.y;
      return sx + hw > mapRect.x && sx - hw < mapRect.x + mapRect.w && sy + down > mapRect.y && sy - up < mapRect.y + mapRect.h;
    };
    G.hudSeeThrough = rd.lifts.some(function (L) { return !RAID.swallowed(rd, L.x + 1) && under(L.x, L.y, RAID.LIFT_R * R.TILE + 6, 150, 24); }) || under(rd.p.x, rd.p.y, 18, 44, 10);
    /* 0.55: at 0.38 the storm chip's own words were too faint to read at play size */
    ctx.save(); if (G.hudSeeThrough) ctx.globalAlpha = 0.55;
    R.minimap(rd, mx, my, ms);
    R.paper(mx - 6, sy2, RAID.MW * ms + 12, 36, { r: 8, fill: gap < 5 ? '#f7b7cf' : C.paper, owner: 'storm' });
    R.icon('storm', mx + 12, sy2 + 18, 22);
    R.text(gap < 1 ? 'IN THE STORM' : 'STORM ' + gap.toFixed(0) + ' STEPS BEHIND', mx + 28, sy2 + 24, { font: R.fit('STORM ' + gap.toFixed(0) + ' STEPS BEHIND', 15, RAID.MW * ms - 30, false, 800), owner: 'storm' });
    ctx.restore();
    var pauseX = tall ? W - 16 - 56 : W / 2 - 28;
    var bb = raidButtons(), bx0 = Math.min.apply(null, bb.map(function (b) { return b.x; })), by0 = Math.min.apply(null, bb.map(function (b) { return b.y; }));
    var showHint = !tall && !G.touchSeen;
    /* every HUD paper, so the lift pointer can stay off all of them (it was drawn over the pack's
     * lower corner when the lift lay up and to the left) */
    var hud = [[px, py, Math.max(pw, 180), slotS + 44], [mx - 6, my - 6, RAID.MW * ms + 12, sy2 + 36 - (my - 6)], [pauseX, 12, 56, 44], [bx0, by0, W - 16 - bx0, H - 16 - by0]];
    if (showHint) hud.push([10, H - 44, W - 200, 32]);
    G.hudRects = hud;
    /* the lift pointer: an arrow at the edge of the view toward the best open-or-opening lift */
    liftPointer(hud);
    R.button('pause', 'II', pauseX, 12, 56, 44, { px: 20 });
    /* the four buttons */
    raidButtons().forEach(function (b) {
      var down = !!G.held[b.id], count = b.verb === 'lure' ? rd.kit.lure - rd.used.lure : (b.verb === 'smoke' ? rd.kit.smoke - rd.used.smoke : null);
      var off = (count !== null && count <= 0) || (b.verb === 'dash' && rd.boots < 1);
      /* a used-up button is an OPAQUE grey paper: a faded one let dark bog show through and ate
       * the grey label (found in the store capture) */
      ctx.save(); ctx.globalAlpha = off ? 1 : (down ? 1 : 0.88);
      R.paper(b.x, b.y, b.w, b.h, { r: 14, fill: down ? C.gold : (off ? C.paperShade : C.paper), noRec: true });
      if (off) ctx.globalAlpha = 0.4;
      R.icon(b.icon, b.x + b.w / 2, b.y + b.h / 2 - 10, b.w * 0.36);
      ctx.restore();
      var lab = b.label + (count !== null ? ' ' + count : '');
      R.text(lab, b.x + b.w / 2, b.y + b.h - 13, { font: R.fit(lab, 15, b.w - 10, false, 800), align: 'center', color: off ? C.mute : C.ink, owner: b.id });
      if (R.rec) R.rec.push({ kind: 'button', id: b.id, label: lab, x: b.x, y: b.y, w: b.w, h: b.h });
    });
    if (showHint) {
      /* on paper like every other string in the game: bare outlined text on the grass read as a
       * debug line */
      var hint = 'WASD or hold the mouse to walk · stand in an open lift and HOLD SPACE · Q lure · E smoke · SHIFT dash';
      var hf = R.fit(hint, 14, W - 236, false, 800), hw = R.measure(hint, hf);
      R.paper(10, H - 44, hw + 24, 32, { r: 8, owner: 'hint' });
      R.text(hint, 22, H - 23, { font: hf, color: C.ink, owner: 'hint' });
    }
  }
  function liftPointer(hud) {
    var rd = G.rd, cam = R.camera(rd), best = null, bt = 1e9;
    rd.lifts.forEach(function (L) {
      if (RAID.swallowed(rd, L.x + 1)) return;
      var lt = RAID.liftTiming(rd, L), d = Math.hypot(L.x - rd.p.x, L.y - rd.p.y), score = (lt.open ? 0 : lt.next) + d / 4;
      if (score < bt) { bt = score; best = L; }
    });
    if (!best) return;
    var sx = best.x * R.TILE - cam.x, sy = best.y * R.TILE - cam.y;
    if (sx > 30 && sx < G.W - 30 && sy > 30 && sy < G.H - 30) return;
    var cx = G.W / 2, cy = G.H / 2, ang = Math.atan2(sy - cy, sx - cx);
    var ex = Math.max(40, Math.min(G.W - 40, cx + Math.cos(ang) * 2000)), ey = Math.max(40, Math.min(G.H - 40, cy + Math.sin(ang) * 2000));
    /* walk back along the SAME line toward the centre until the arrow (reach 22) clears every HUD
     * paper: it still points at the lift, it just sits nearer the middle */
    var near = function (x, y) { return (hud || []).some(function (r) { return x > r[0] - 22 && x < r[0] + r[2] + 22 && y > r[1] - 22 && y < r[1] + r[3] + 22; }); };
    for (var k = 0; k < 80 && near(ex, ey); k++) { ex = cx + (ex - cx) * 0.96; ey = cy + (ey - cy) * 0.96; }
    G.liftPointerAt = { x: ex, y: ey, clear: !near(ex, ey) };
    ctx.save(); ctx.translate(ex, ey); ctx.rotate(ang);
    ctx.fillStyle = RAID.liftOpen(rd, best) ? C.gold : C.paper; ctx.strokeStyle = C.ink; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(18, 0); ctx.lineTo(-10, -13); ctx.lineTo(-4, 0); ctx.lineTo(-10, 13); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.restore();
  }

  function drawResult() {
    var W = G.W, H = G.H, tall = G.shape === 'tall', r = G.result, res = r.res;
    R.fillPattern('gnd_farm_grass', 0, 0, W, H, '#6f9a4a'); ctx.fillStyle = 'rgba(27,22,34,0.40)'; ctx.fillRect(0, 0, W, H);
    R.layer('result');
    var lifted = r.outcome === 'lifted', pw = tall ? W - 32 : 640, cols0 = tall ? 2 : 3;
    /* the card is as tall as what it says: measured first, drawn second (a fixed card left a dead
     * third of itself empty after a small haul) */
    var tipF = R.font(15, false, 600), lostF = R.font(16, false, 800);
    /* one ROW per strain ("Damson x2") and one for all the coin: listing duplicates as separate rows
     * put NEW TO THE CODEX under every copy of a strain that added ONE entry (independent review) */
    function grouped(items) {
      var rows = [], byStrain = {}, coin = null;
      items.forEach(function (it) {
        if (it.kind === 'coin') { if (!coin) { coin = { kind: 'coin', amount: 0 }; rows.push(coin); } coin.amount += it.amount; return; }
        if (!byStrain[it.strain]) { byStrain[it.strain] = { kind: 'pod', strain: it.strain, n: 0 }; rows.push(byStrain[it.strain]); }
        byStrain[it.strain].n++;
      });
      return rows;
    }
    function rowName(row) { return row.kind === 'coin' ? nf(row.amount) + ' coin' : Z.strain(row.strain).name + (row.n > 1 ? ' x' + row.n : ''); }
    var lostNames = grouped(res.lost).map(rowName).join(', ');
    /* the centrepiece is the ending, not another seed: it grows only under a Cold Frame, so the card
     * says THAT (final review: it read "every harvest returns more of it", which is false for it) */
    var hasCentre = res.kept.some(function (it) { return it.kind === 'pod' && it.strain === 'centrepiece'; });
    var gotFrame = G.st && G.st.upgrades.frame > 0;
    /* a loss tip names only the tools the player can grow: smokeherb comes from the Fen, and a first
     * Hedgerow loss told a new player to grow a seed they cannot have yet (final review) */
    var knowsSmoke = G.st && (G.st.codex.smokeherb || G.st.bank.smokeherb > 0);
    var tipTxt = lifted ? (hasCentre ? (gotFrame ? 'The centrepiece! Plant it under your Cold Frame and watch it flower.' : 'The centrepiece! Buy a Cold Frame in the shop, then plant it under glass.')
      : (res.got.newStrains.length ? 'Plant the new seed at home: every harvest returns more of it.' : 'Rarer seed grows near where the storm starts.'))
      : (knowsSmoke ? 'The farm is untouched. Grow sweetroot for lures and smokeherb for smoke.' : 'The farm is untouched. Grow sweetroot for lures to pull boars away.');
    var keptRows = grouped(res.kept);
    var need = 136 + (keptRows.length ? Math.ceil(keptRows.length / cols0) * 54 + 8 : 50) + 16
      + (res.lost.length ? 32 + R.wrap(lostNames, lostF, pw - 60).length * 20 : 0)
      + R.wrap(tipTxt, tipF, pw - 60).length * 19 + 24 + (tall ? 120 : 70);
    /* the floor is low: a one-item haul under a 360 floor left a band of empty paper mid-card */
    var ph = Math.min(H - (tall ? 120 : 24), Math.max(tall ? 420 : 290, need)), px = W / 2 - pw / 2, py = Math.max(12, (H - ph) / 2);
    R.paper(px, py, pw, ph, { r: 16 });
    R.text(lifted ? 'LIFTED OUT' : (r.outcome === 'quit' ? 'YOU TURNED BACK' : 'THE STORM TOOK YOU'), W / 2, py + 54, { font: R.font(34, true), align: 'center', color: lifted ? C.leaf : C.storm });
    R.text(r.zone.name + ' · ' + fmtTime(r.secs), W / 2, py + 82, { font: R.font(17, false, 800), align: 'center', color: C.mute });
    var y = py + 124;
    R.text(lifted ? 'IN YOUR PACK' : 'KEPT IN THE POUCH', px + 30, y, { font: R.font(18, true) });
    y += 12;
    var list = keptRows;
    /* the pouch line only when something WAS lost: after an empty-pack raid it read as a lecture */
    if (!list.length) { R.text(lifted ? 'Nothing: an empty pack still gets you home.' : (res.lost.length ? (G.st && G.st.upgrades.pouch > 0 ? 'Nothing: the pouch slot was empty.' : 'Nothing. An Oilskin Pouch keeps the first slot.') : 'Nothing: the pack was empty.'), px + 30, y + 30, { font: R.font(16, false, 800), color: C.mute }); y += 50; }
    var cols = tall ? 2 : 3, cw = (pw - 60) / cols;
    /* ONE size for every name on the card, the largest that fits them ALL: fitting each name on its
     * own set "Marsh Marigold x2" two sizes smaller than "Cottongrass" beside it (own Gate 1 look at
     * the store's result shot, 2026-09-19) */
    var pxOf = function (f) { return +/(\d+(?:\.\d+)?)px/.exec(f)[1]; };
    var nameF = list.reduce(function (f, it) { var g = R.fit(rowName(it), 17, cw - 60, false, 800); return pxOf(g) < pxOf(f) ? g : f; }, R.font(17, false, 800));
    list.forEach(function (it, i) {
      var cx = px + 30 + (i % cols) * cw, cy = y + 8 + Math.floor(i / cols) * 54;
      R.icon(it.kind === 'coin' ? 'prop_coin' : 'plant_' + it.strain, cx + 22, cy + 22, 40);
      var nm = rowName(it), fresh = it.kind === 'pod' && res.got.newStrains.indexOf(it.strain) >= 0;
      R.text(nm, cx + 50, cy + 22, { font: nameF });
      if (fresh) R.text('NEW TO THE CODEX', cx + 50, cy + 42, { font: R.font(12, true), color: C.goldDeep });
      else if (it.kind === 'pod' && it.strain === 'centrepiece') R.text('THE ENDING SEED', cx + 50, cy + 42, { font: R.font(12, true), color: C.goldDeep });
    });
    y += 8 + Math.ceil(list.length / cols) * 54 + 16;
    if (res.lost.length) {
      /* only a raid the storm ENDED lost anything to it; turning back leaves the pack behind */
      R.text(r.outcome === 'lost' ? 'LOST TO THE STORM' : 'LEFT BEHIND', px + 30, y, { font: R.font(18, true), color: C.storm });
      y += 12 + R.paragraph(lostNames, px + 30, y + 24, pw - 60, lostF, 20, C.mute);
    }
    /* (no separate "+N coin to the farm" line: the kept coin is already its own row above, and the
     * store review read the pair as the same number twice) */
    var by = py + ph - (tall ? 130 : 62), bw = tall ? pw - 48 : (pw - 60) / 2;
    /* the tip sits ABOVE the buttons by its own measured height (a fixed offset put its second line
     * across BACK TO THE FARM on a phone) */
    var tipLines = R.wrap(tipTxt, tipF, pw - 60).length;
    R.paragraph(tipTxt, px + 30, Math.max(y + 24, by - 14 - (tipLines - 1) * 19), pw - 60, tipF, 19, C.ink);
    if (tall) { R.button('home', 'BACK TO THE FARM', px + 24, by, bw, 48, { gold: true, display: true, px: 20 }); R.button('again', 'RAID ' + r.zone.name.toUpperCase() + ' AGAIN', px + 24, by + 58, bw, 44, { px: 17 }); }
    else { R.button('home', 'BACK TO THE FARM', px + 20, by, bw, 46, { gold: true, display: true, px: 20 }); R.button('again', 'RAID ' + r.zone.name.toUpperCase() + ' AGAIN', px + 40 + bw, by, bw, 46, { px: 17 }); }
  }

  /* ── the shop ─────────────────────────────────────────────────────────────────────── */
  function drawShop() {
    var st = G.st, W = G.W, H = G.H, tall = G.shape === 'tall';
    R.fillPattern('gnd_farm_path', 0, 0, W, H, '#a88257'); ctx.fillStyle = 'rgba(27,22,34,0.30)'; ctx.fillRect(0, 0, W, H);
    var bottom = header('SHED AND SHOP', null);
    var coin = Math.floor(st.coin).toLocaleString('en-US');
    chip(W / 2 - 80, bottom + 6, 160, 40, 'coin', coin, 'coin');
    var cols = tall ? 1 : 2, gx = 14, rw = tall ? W - 32 : (W - 32 - gx) / 2, rh = tall ? 88 : 92, y0 = bottom + 56;
    SIM.UPGRADES.forEach(function (u, i) {
      var x = 16 + (i % cols) * (rw + gx), y = y0 + Math.floor(i / cols) * (rh + 8), lvl = st.upgrades[u.id], cost = SIM.costOf(u.id, lvl);
      R.paper(x, y, rw, rh, { r: 12, owner: 'up' + i });
      R.text(u.name.toUpperCase(), x + 16, y + 30, { font: R.font(19, true), owner: 'up' + i });
      var pipX = x + 22 + R.measure(u.name.toUpperCase(), R.font(19, true));
      for (var p = 0; p < u.cost.length; p++) { ctx.fillStyle = p < lvl ? C.leaf : 'rgba(27,22,34,0.2)'; ctx.beginPath(); ctx.arc(pipX + 6 + p * 15, y + 23, 5, 0, 7); ctx.fill(); }
      var bw = 124, lines = R.wrap(u.blurb, R.font(14, false, 600), rw - bw - 44);
      for (var l = 0; l < lines.length && l < 3; l++) R.text(lines[l], x + 16, y + 52 + l * 17, { font: R.font(14, false, 600), owner: 'up' + i });
      var label = cost === null ? 'DONE' : cost.toLocaleString('en-US');
      R.button('buy_' + u.id, label, x + rw - bw - 12, y + rh / 2 - 22, bw, 44, { off: cost === null || st.coin < cost, clickableOff: cost !== null, px: 18, icon: cost === null ? null : 'coin' });
    });
    R.button('back', 'BACK', 16, 14, 110, 42, { px: 17 });
  }

  /* ── the codex ────────────────────────────────────────────────────────────────────── */
  /* A CENSUS of every string a codex card can ever print (every name, both forms of a hybrid's
   * parent line, every stat line), measured at the width the grid gives: the largest size at which
   * ALL of them fit. Taken over the whole codex, not the page on screen, so a size never jumps
   * when the page turns or a strain is found. Cached per width. */
  var codexSizeCache = {};
  function codexSizes(ids, tw) {
    if (codexSizeCache[tw]) return codexSizeCache[tw];
    var names = ['???'], lines = ['a cross of two strains'];
    ids.forEach(function (id) {
      var s = Z.strain(id), hy = Z.HYBRIDS.filter(function (h) { return h.id === id; })[0];
      names.push(s.name);
      lines.push(hy ? Z.strain(hy.a).name + ' x ' + Z.strain(hy.b).name : (s.ending ? 'deep in the Ridge Garden' : 'found in the ' + Z.zone(s.zone).name));
      /* the widest this line can ever print: base growth (sprinklers only shorten it) and the price at
       * full compost (the most digits), so the size never changes when an upgrade is bought */
      if (!s.ending) lines.push(fmtTime(s.growSec) + ' · ' + Math.round(s.coin * 2) + ' coin' + (s.tool ? ' · ' + (s.tool.indexOf('lure') === 0 ? 'lure' : 'smoke') : ''));
    });
    function largest(list, hi, lo, display) {
      for (var p = hi; p >= lo; p -= 0.5) {
        var f = R.font(p, display, 800), ok = true;
        for (var i = 0; i < list.length && ok; i++) if (R.measure(list[i], f) > tw) ok = false;
        if (ok) return p;
      }
      return lo;
    }
    return (codexSizeCache[tw] = { name: largest(names, 17, 12, true), line: largest(lines, 14, 10, false) });
  }
  function drawCodex() {
    var st = G.st, W = G.W, H = G.H, tall = G.shape === 'tall';
    R.fillPattern('gnd_farm_grass', 0, 0, W, H, '#6f9a4a'); ctx.fillStyle = 'rgba(27,22,34,0.42)'; ctx.fillRect(0, 0, W, H);
    var bottom = header('SEED CODEX ' + SIM.codexCount(st) + '/24', 'Wild strains come from raids. Hybrids come from two ripe parents side by side at harvest.');
    var ids = Z.codexIds().concat(['centrepiece']);
    /* The grid is chosen from the LONGEST line the codex can print, not from how many cards fit:
     * "Marsh Marigold x Cottongrass" is 172 px at 12 px, and a five-across grid gave it 109 px, so
     * every card shrank on its own and the longest still ran into the card edge. Three across (two
     * on a tall screen), paged; ONE size per kind of line for the whole codex. */
    var by = H - (tall ? 64 : 50);
    /* wide: three across, five down — a 667 px phone in landscape shows this at 0.695 scale, so a line
     * needs ~13 logical px to stay at 9 css px, and only a column this wide gives it room */
    var cols = tall ? 2 : 3, rowsPer = tall ? 8 : 5, cw = Math.floor((W - 32 - (cols - 1) * 8) / cols), y0 = bottom + 10;
    var ch = Math.min(84, Math.floor((by - 8 - y0 - (rowsPer - 1) * 6) / rowsPer));
    var per = cols * rowsPer, pages = Math.ceil(ids.length / per);
    G.codexPage = Math.min(G.codexPage, pages - 1);
    var slice = ids.slice(G.codexPage * per, G.codexPage * per + per);
    var ICON = 42, TX = 52, tw = cw - TX - 8;
    function line1Of(id, s) {
      var hy = Z.HYBRIDS.filter(function (h) { return h.id === id; })[0];
      return hy ? (st.codex[hy.a] && st.codex[hy.b] ? Z.strain(hy.a).name + ' x ' + Z.strain(hy.b).name : 'a cross of two strains') : (s.ending ? 'deep in the Ridge Garden' : 'found in the ' + Z.zone(s.zone).name);
    }
    /* the SAME numbers the farm panel prints: growth after sprinklers, price after compost (the codex
     * printed base values while the farm printed upgraded ones, so one seed had two prices) */
    function line2Of(s) { return fmtTime(Math.round(s.growSec / SIM.speed(st))) + ' · ' + Math.round(s.coin * SIM.yieldMul(st)) + ' coin' + (s.tool ? ' · ' + (s.tool.indexOf('lure') === 0 ? 'lure' : 'smoke') : ''); }
    var sz = codexSizes(ids, tw);
    var fName = R.font(sz.name, true), fLine = R.font(sz.line, false, 800);
    slice.forEach(function (id, i) {
      var s = Z.strain(id), known = id === 'centrepiece' ? SIM.hasCentrepiece(st) : !!st.codex[id];
      var x = 16 + (i % cols) * (cw + 8), y = y0 + Math.floor(i / cols) * (ch + 6);
      R.paper(x, y, cw, ch, { r: 10, fill: known ? C.paper : C.paperShade, owner: 'cx_' + id });
      ctx.save(); if (!known) ctx.filter = 'brightness(0) opacity(0.35)';
      R.icon('plant_' + id, x + 27, y + ch / 2, ICON);
      ctx.restore();
      var tx = x + TX, mid = y + ch / 2;
      R.text(known ? s.name : '???', tx, mid - 12, { font: fName, owner: 'cx_' + id });
      R.text(line1Of(id, s), tx, mid + 8, { font: fLine, color: C.mute, owner: 'cx_' + id });
      if (known && !s.ending) R.text(line2Of(s), tx, mid + 26, { font: fLine, owner: 'cx_' + id });
    });
    if (pages > 1) R.text((G.codexPage + 1) + ' / ' + pages, W - 16 - 250 - 16, by + 27, { font: R.font(16, false, 800), align: 'right', color: C.paper, stroke: C.ink, strokeW: 4 });
    R.button('back', 'BACK', 16, 14, 110, 42, { px: 17 });
    if (pages > 1) { R.button('cxPrev', 'PREV', W - 16 - 250, by, 120, 42, { off: G.codexPage === 0, px: 16 }); R.button('cxNext', 'NEXT', W - 16 - 120, by, 120, 42, { off: G.codexPage >= pages - 1, px: 16 }); }
  }

  /* ── how to play, credits ─────────────────────────────────────────────────────────── */
  var HOWTO = [
    ['plant_sweetroot', 'THE FARM', 'Choose a seed and click an empty plot to sow it. Ripe plots glow: click to harvest for coin and one or two seeds back. The farm keeps growing while you raid, and for up to 8 hours while you are away.'],
    ['prop_balloon', 'THE RAID', 'New strains only come from the wilds. Walk with WASD or by holding the mouse or a finger on the map. Walk over seed pods and coin to pack them. The pack has slots AND a weight limit (the bar under it): a rare pod weighs 2, the centrepiece 3. A full pack swaps its worst item for a better one.'],
    ['storm', 'STORM AND LIFTS', 'The storm crosses the map from the west. Balloon lifts open and close in turn; the number over a closed lift is the seconds until it opens. Stand in an OPEN one and hold SPACE or LIFT to fly home. If the storm catches you, you lose the pack, never the farm.'],
    ['chr_boar', 'BOARS AND CROWS', 'Boars wind up, then charge in a straight line: step aside. A LURE (Q, grown from sweetroot) pulls them away. Crows steal from your pack: chase them down, or throw SMOKE (E, grown from smokeherb). SHIFT dashes once you own boots.'],
    ['plant_honeyroot', 'CROSSING', 'Two different strains ripe side by side can cross when you harvest one: a hybrid seed. The codex says which parents make which.'],
  ];
  function drawHowto() {
    var W = G.W, H = G.H, tall = G.shape === 'tall';
    backdrop(0.5);
    header('HOW TO PLAY', null);
    /* wide rows are packed tighter since the pack-weight and lift-countdown lines went in: at the old
     * spacing the BACK button ran 5 px off the bottom of the canvas */
    var x0 = tall ? 16 : 60, w = W - 2 * x0, y = tall ? 96 : 74, f = R.font(tall ? 16 : 14, false, 600), lh = tall ? 20 : 17;
    HOWTO.forEach(function (row, i) {
      var lines = R.wrap(row[2], f, w - 96), rowH = (tall ? 40 : 33) + lines.length * lh;
      R.paper(x0, y, w, rowH, { r: 10, owner: 'how' + i });
      R.icon(row[0], x0 + 40, y + rowH / 2, 44);
      R.text(row[1], x0 + 80, y + (tall ? 27 : 24), { font: R.font(tall ? 19 : 17, true), owner: 'how' + i });
      for (var l = 0; l < lines.length; l++) R.text(lines[l], x0 + 80, y + (tall ? 48 : 42) + l * lh, { font: f, owner: 'how' + i });
      y += rowH + (tall ? 10 : 5);
    });
    R.button('back', 'BACK', W / 2 - 70, Math.max(y + 4, H - (tall ? 76 : 50)), 140, tall ? 48 : 40, { px: 18 });
  }
  function drawCredits() {
    var W = G.W, H = G.H, tall = G.shape === 'tall';
    backdrop(0.5);
    header('CREDITS', null);
    var x0 = tall ? 16 : 130, w = W - 2 * x0, y = tall ? 100 : 84;
    var rows = [
      ['SEEDLIFT', R.font(28, true)],
      ['A game by Core Systems Asset Factory, made for the Bezi Mega Jam (theme: genre collision, a farming incremental crossed with an extraction raid).', R.font(16, false, 600)],
      ['', null],
      ['MADE WITH AI, SAID PLAINLY', R.font(18, true)],
      ['The code and the text were written with AI tools and reviewed before release. The plants, the wild objects, the balloon and the key art were generated as images and reduced to one fixed pixel palette; the farmer, the boar and the crow were generated as pixel art. The ground textures are drawn by our own procedural code.', R.font(16, false, 600)],
      ['The music and every sound effect are synthesised by this game’s own code. No AI audio.', R.font(16, false, 600)],
      ['', null],
      ['TYPE', R.font(18, true)],
      ['Pixelify Sans (with its C, 5, 7 and round brackets from Tiny5) and Nunito, all under the SIL Open Font Licence; the licence texts ship with the game.', R.font(16, false, 600)],
    ];
    var wrapped = rows.map(function (r2) { return r2[1] ? R.wrap(r2[0], r2[1], w - 48) : null; });
    var need = 44;
    rows.forEach(function (r2, i) { need += r2[1] ? wrapped[i].length * (r2[1].indexOf('SL Display') >= 0 ? 32 : 21) + 4 : 8; });
    R.paper(x0, y, w, need, { r: 12 });
    var yy = y + 40;
    rows.forEach(function (r2, i) {
      if (!r2[1]) { yy += 8; return; }
      wrapped[i].forEach(function (ln) { R.text(ln, x0 + 24, yy, { font: r2[1] }); yy += r2[1].indexOf('SL Display') >= 0 ? 32 : 21; });
      yy += 4;
    });
    R.button('back', 'BACK', W / 2 - 70, Math.max(y + need + 12, H - (tall ? 76 : 52)), 140, 42, { px: 18 });
  }

  /* ── overlays ─────────────────────────────────────────────────────────────────────── */
  function modal(w, h) {
    var W = G.W, H = G.H;
    ctx.fillStyle = 'rgba(27,22,34,0.6)'; ctx.fillRect(0, 0, W, H); R.layer('modal'); R.hits = [];
    var pw = Math.min(W - 32, w), px = W / 2 - pw / 2, py = H / 2 - h / 2;
    R.paper(px, py, pw, h, { r: 16 });
    return { x: px, y: py, w: pw, h: h };
  }
  function drawPause() {
    /* both cards hold four buttons ending at +326, so both are one height (the farm's 330 left its last
     * button 4 px off the card edge) */
    var raid = G.screen === 'raid', m = modal(440, 354), W = G.W;
    R.text('PAUSED', W / 2, m.y + 56, { font: R.font(34, true), align: 'center' });
    var sub = raid ? 'The storm waits while you do.' : 'The farm waits while you do.';
    R.text(sub, W / 2, m.y + 88, { font: R.font(16, false, 800), align: 'center', color: C.mute });
    var y = m.y + 112, bw = m.w - 48;
    R.button('resume', raid ? 'KEEP RAIDING' : 'BACK TO THE FARM', m.x + 24, y, bw, 52, { gold: true, display: true, px: 20 });
    R.button('howto', 'HOW TO PLAY', m.x + 24, y + 62, bw, 44, { px: 17 });
    R.button('sound', A.muted ? 'SOUND OFF' : 'SOUND ON', m.x + 24, y + 116, bw, 44, { px: 17 });
    /* an Oilskin Pouch keeps its slots on a turn-back, so the label says so (final review) */
    if (raid) R.button('leaveRaid', G.st && G.st.upgrades.pouch > 0 ? 'TURN BACK (ONLY THE POUCH IS KEPT)' : 'TURN BACK (THE PACK IS LOST)', m.x + 24, y + 170, bw, 44, { px: 16 });
    else R.button('toTitle', 'TO THE TITLE', m.x + 24, y + 170, bw, 44, { px: 17 });
  }
  function drawWelcome() {
    var w = G.welcome, W = G.W;
    var lines = [];
    if (w.secs > 0) lines.push('You were away ' + fmtTime(w.secs) + (w.capped ? ' (the farm counts up to 8 hours).' : '.'));
    /* grouped like every other coin figure in the game (the HUD reads 1,850; this card read +3120) */
    if (w.harvests > 0) lines.push('The farm hands brought in ' + w.harvests.toLocaleString('en-US') + ' harvests: +' + Math.floor(w.coin).toLocaleString('en-US') + ' coin.');
    else if (w.secs > 0) lines.push('Your crops kept growing. Hire Farm Hands in the shop to harvest while you are away.');
    lines = lines.concat(w.notes);
    /* the card is as tall as what it says, measured before it is drawn (a fixed 290 left a band of
     * empty paper above the button) */
    var cardW = Math.min(480, G.W - 32), wrapped = 0;
    lines.forEach(function (ln) { wrapped += R.wrap(ln, R.font(16, false, 800), cardW - 56).length; });
    var m = modal(480, Math.max(210, 92 + wrapped * 21 + 96));
    R.text('WELCOME BACK', W / 2, m.y + 54, { font: R.font(32, true), align: 'center' });
    var y = m.y + 92;
    lines.forEach(function (ln) { y += R.paragraph(ln, m.x + 28, y, m.w - 56, R.font(16, false, 800), 21, C.ink); });
    R.button('welcomeOk', 'TO THE FARM', m.x + 24, m.y + m.h - 70, m.w - 48, 48, { gold: true, display: true, px: 20 });
  }
  function drawEnding() {
    var st = G.st, m = modal(560, 430), W = G.W;
    R.sprite('plant_centrepiece', W / 2, m.y + 110, 1, { rec: true });
    R.text('IN FLOWER', W / 2, m.y + 150, { font: R.font(38, true), align: 'center', color: C.goldDeep });
    R.paragraph('The centrepiece from the Ridge Garden has bloomed on your farm. The wilds keep their seed and the storm keeps coming; the farm is yours to keep growing.', m.x + 28, m.y + 186, m.w - 56, R.font(16, false, 700), 21, C.ink, 'center');
    var s = st.stats, stats = [['RAIDS', s.raids], ['LIFTED', s.lifted], ['CROSSES', s.crosses], ['CODEX', SIM.codexCount(st) + '/24']];
    stats.forEach(function (row, i) { var x = m.x + 28 + i * (m.w - 56) / 4; R.text(row[0], x, m.y + 290, { font: R.font(13, false, 800), color: C.mute }); R.text(String(row[1]), x, m.y + 316, { font: R.font(22, true) }); });
    R.button('endingOk', 'KEEP FARMING', m.x + 24, m.y + m.h - 70, m.w - 48, 48, { gold: true, display: true, px: 20 });
  }
  function drawConfirmNew() {
    var m = modal(480, 240), W = G.W;
    R.text('START A NEW FARM?', W / 2, m.y + 54, { font: R.font(28, true), align: 'center' });
    R.paragraph('This replaces the farm saved in this browser.', m.x + 28, m.y + 84, m.w - 56, R.font(16, false, 800), 21, C.ink, 'center');
    R.button('newYes', 'YES, A NEW FARM', m.x + 24, m.y + 124, m.w - 48, 44, { px: 18 });
    R.button('newNo', 'KEEP MY FARM', m.x + 24, m.y + 176, m.w - 48, 44, { gold: true, px: 18 });
  }

  function drawPops() {
    G.pops.forEach(function (p) {
      var a = Math.min(1, p.life / 0.4), rise = (1.1 - p.life) * 28;
      ctx.save(); ctx.globalAlpha = a;
      R.text(p.text, p.x, p.y - rise, { font: R.font(17, true), align: 'center', color: p.color, stroke: C.paper, strokeW: 4 });
      ctx.restore();
    });
  }
  function drawBanners() {
    if (!G.banners.length) return;
    /* an opaque paper OVER the screen: its own layer, so the layout gate does not flag the words it
     * deliberately hides for a moment; a separate cross-layer check keeps it off every button */
    R.layer('banner');
    var W = G.W, b = G.banners[G.banners.length - 1], a = Math.min(1, b.life / 0.3, (b.max - b.life) / 0.2 + 0.2);
    ctx.save(); ctx.globalAlpha = Math.max(0, Math.min(1, a));
    /* off the main buttons: on the farm the banner sits over the field's lower rows, just above the
     * HARVEST ALL / SOW ALL / GO RAIDING row it answers (it used to be drawn ON those buttons) */
    var tall = G.shape === 'tall', sc = G.screen;
    var f = R.fit(b.text, 22, W - 80, true), w = R.measure(b.text, f) + 44;
    /* every other screen: the first height, from the top, where the banner covers NO control drawn
     * last frame (mid-screen it sat on the shop's price buttons; a fixed top slot would cross BACK on
     * a tall screen once the text is long) */
    var y = sc === 'raid' ? (tall ? 330 : 100) : (sc === 'farm' ? (tall ? 410 : 396) : -1);
    if (y < 0) {
      var cands = tall ? [12, 116, 168] : [12, 64, 116], bx = W / 2 - w / 2, hits = G.hitsCache || [];
      for (var ci = 0; ci < cands.length && y < 0; ci++) {
        var cy = cands[ci];
        if (!hits.some(function (h) { return bx < h.x + h.w && h.x < bx + w && cy < h.y + h.h && h.y < cy + 46; })) y = cy;
      }
      if (y < 0) y = cands[0];
    }
    /* good news on yellow; a refusal is a dark toast — on cream paper it read as one more card label
     * sitting on the zone cards */
    R.paper(W / 2 - w / 2, y, w, 46, { r: 12, fill: b.hot ? '#fff08a' : C.ink2, edge: b.hot ? null : 'rgba(246,239,217,0.35)', owner: 'banner' });
    R.text(b.text, W / 2, y + 31, { font: f, align: 'center', color: b.hot ? C.ink : C.paper, owner: 'banner' });
    ctx.restore();
  }

  /* ── actions ──────────────────────────────────────────────────────────────────────── */
  function act(id) {
    A.init();
    if (id === 'sound') { A.setMuted(!A.muted); return; }
    if (id.indexOf('plot_') === 0) { var q = id.split('_'); farmAct(+q[1], +q[2]); return; }
    if (id.indexOf('seed_') === 0) { G.sel = id.slice(5); A.sfx('menuMove'); return; }
    A.sfx('menuSelect');
    if (id === 'continue') { beginPlay(false); return; }
    if (id === 'newfarm') { if (G.hasSave) { G.overlay = 'confirmNew'; G.focus = 1; } else beginPlay(true); return; }
    if (id === 'newYes') { G.overlay = null; beginPlay(true); return; }
    if (id === 'newNo') { G.overlay = null; return; }
    if (id === 'howto') { G.howFrom = G.screen; G.overlay = null; go('howto'); return; }
    if (id === 'credits') { go('credits'); return; }
    if (id === 'back') {
      /* HOW TO PLAY opened from the raid's pause menu goes back INTO that raid, still paused. It used
       * to go to the farm and leave the raid neither finished nor settled — no result, the kit stuck
       * "away", and the next raid's takeKit overwrote it (found by the independent review) */
      if (G.screen === 'howto' && G.howFrom === 'raid' && G.playing && G.rd && !G.rd.over) { go('raid'); G.overlay = 'pause'; G.focus = 0; return; }
      if (G.screen === 'howto' && G.howFrom && G.howFrom !== 'title' && G.howFrom !== 'raid' && G.playing) go(G.howFrom);
      else go(G.playing && G.screen !== 'credits' && G.screen !== 'howto' ? 'farm' : 'title');
      return;
    }
    if (id === 'pause') { G.overlay = 'pause'; G.focus = 0; releaseRaidKeys(); save(); return; }
    if (id === 'resume') { G.overlay = null; last = 0; return; }
    if (id === 'toTitle') { save(); G.hasSave = true; G.playing = false; go('title'); return; }
    if (id === 'leaveRaid') { G.overlay = null; RAID.quit(G.rd); finishRaid(); return; }
    if (id === 'welcomeOk' || id === 'endingOk') { G.overlay = null; return; }
    if (id === 'harvestAll') { harvestAll(); return; }
    if (id === 'sowAll') { sowAll(); return; }
    if (id === 'raid') { go('zones'); return; }
    if (id === 'shop') { go('shop'); return; }
    if (id === 'codex') { go('codex'); return; }
    if (id === 'cxPrev') { G.codexPage = Math.max(0, G.codexPage - 1); return; }
    if (id === 'cxNext') { G.codexPage++; return; }
    if (id === 'permit') { var pr = SIM.buyPermit(G.st); if (!pr.ok) { A.sfx('refuse'); banner(pr.why === 'codex' ? 'FIND MORE STRAINS FIRST' : 'NOT ENOUGH COIN', 1.4); } else save(); return; }
    if (id.indexOf('raid_') === 0) { startRaid(id.slice(5)); return; }
    if (id.indexOf('buy_') === 0) { var r = SIM.buy(G.st, id.slice(4)); if (!r.ok) { A.sfx('refuse'); banner(r.why === 'maxed' ? 'ALREADY DONE' : 'NOT ENOUGH COIN', 1.2); } else save(); return; }
    if (id === 'home') { go('farm'); return; }
    if (id === 'again') { startRaid(G.result.zone.id); return; }
  }
  function releaseRaidKeys() { if (!G.rd) return; RAID.VERBS.forEach(function (v) { RAID.setKey(G.rd, v, false); }); RAID.setKey(G.rd, 'stick', { x: 0, y: 0 }); G.steer = null; G.held = {}; }

  /* ── input ────────────────────────────────────────────────────────────────────────── */
  var RAIDKEYS = { KeyW: 'up', ArrowUp: 'up', KeyS: 'down', ArrowDown: 'down', KeyA: 'left', ArrowLeft: 'left', KeyD: 'right', ArrowRight: 'right',
    Space: 'action', KeyQ: 'lure', KeyE: 'smoke', ShiftLeft: 'dash', ShiftRight: 'dash', KeyK: 'dash' };
  function menuIds() { return G.hitsCache.map(function (h) { return h.id; }).filter(function (id) { return id !== 'sound' && id !== 'pause' && id.indexOf('plot_') !== 0 && id.indexOf('seed_') !== 0; }); }
  window.addEventListener('keydown', function (e) {
    var code = e.code;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].indexOf(code) >= 0) e.preventDefault();
    A.init();
    G.lastInput = 'keys';
    if (code === 'KeyM') { A.setMuted(!A.muted); return; }
    if (!G.overlay && G.screen === 'raid') {
      if (code === 'Escape' || code === 'KeyP') { act('pause'); return; }
      var v = RAIDKEYS[code];
      if (v && !e.repeat) raidInput(v, true);
      return;
    }
    if (!G.overlay && G.screen === 'farm') {
      var st = G.st, cur = G.cur;
      if (code === 'ArrowLeft' || code === 'KeyA') { cur.c = (cur.c - 1 + st.cols) % st.cols; return; }
      if (code === 'ArrowRight' || code === 'KeyD') { cur.c = (cur.c + 1) % st.cols; return; }
      if (code === 'ArrowUp' || code === 'KeyW') { cur.r = (cur.r - 1 + st.rows) % st.rows; return; }
      if (code === 'ArrowDown' || code === 'KeyS') { cur.r = (cur.r + 1) % st.rows; return; }
      if (code === 'Enter' || code === 'Space') { farmAct(cur.c, cur.r); return; }
      if (code === 'KeyQ' || code === 'BracketLeft') { cycleSeed(-1); return; }
      if (code === 'KeyE' || code === 'BracketRight') { cycleSeed(1); return; }
      if (code === 'KeyH') { act('harvestAll'); return; }
      if (code === 'KeyF') { act('sowAll'); return; }
      if (code === 'KeyR') { act('raid'); return; }
      if (code === 'KeyB') { act('shop'); return; }
      if (code === 'KeyC') { act('codex'); return; }
      if (code === 'Escape' || code === 'KeyP') { act('pause'); return; }
      return;
    }
    if (code === 'KeyP' && G.overlay === 'pause') { act('resume'); return; }
    var ids = menuIds();
    if (!ids.length) return;
    if (code === 'ArrowDown' || code === 'ArrowRight' || code === 'Tab') { G.focus = (G.focus + 1) % ids.length; A.sfx('menuMove'); }
    else if (code === 'ArrowUp' || code === 'ArrowLeft') { G.focus = (G.focus - 1 + ids.length) % ids.length; A.sfx('menuMove'); }
    else if (code === 'Enter' || code === 'Space') act(ids[Math.min(G.focus, ids.length - 1)]);
    else if (code === 'Escape') {
      if (G.overlay === 'pause') act('resume');
      else if (G.overlay === 'confirmNew') act('newNo');
      else if (G.overlay) G.overlay = null;
      else if (G.screen === 'result') act('home');
      else if (G.screen !== 'title') act('back');
    }
  });
  window.addEventListener('keyup', function (e) {
    if (G.screen !== 'raid' || G.overlay) return;
    var v = RAIDKEYS[e.code];
    if (v) raidInput(v, false);
  });
  function logical(e) { var r = canvas.getBoundingClientRect(), s = r.width / G.W; return { x: (e.clientX - r.left) / s, y: (e.clientY - r.top) / s }; }
  function hitAt(p, list) { for (var i = list.length - 1; i >= 0; i--) { var h = list[i]; if (p.x >= h.x && p.x <= h.x + h.w && p.y >= h.y && p.y <= h.y + h.h) return h; } return null; }
  canvas.addEventListener('pointerdown', function (e) {
    e.preventDefault();
    A.init();
    if (e.pointerType === 'touch') G.touchSeen = true;
    G.lastInput = e.pointerType || 'mouse';
    var p = logical(e);
    if (G.screen === 'raid' && !G.overlay) {
      var hp = hitAt(p, G.hitsCache);
      if (hp && hp.id === 'pause') { act('pause'); return; }
      var b = hitAt(p, raidButtons());
      if (b) { G.held[b.id] = e.pointerId; raidInput(b.verb, true); if (b.verb !== 'action') raidInput(b.verb, false); try { canvas.setPointerCapture(e.pointerId); } catch (x) { /* ok */ } return; }
      G.steer = { id: e.pointerId, x: p.x, y: p.y };
      try { canvas.setPointerCapture(e.pointerId); } catch (x2) { /* ok */ }
      return;
    }
    var h = hitAt(p, G.hitsCache);
    if (h) act(h.id);
  });
  canvas.addEventListener('pointermove', function (e) { if (G.steer && G.steer.id === e.pointerId) { var p = logical(e); G.steer.x = p.x; G.steer.y = p.y; } });
  function pointerEnd(e) {
    if (G.steer && G.steer.id === e.pointerId) { G.steer = null; if (G.rd) RAID.setKey(G.rd, 'stick', { x: 0, y: 0 }); }
    Object.keys(G.held).forEach(function (k) { if (G.held[k] === e.pointerId) { delete G.held[k]; if (k === 'b_lift') raidInput('action', false); } });
  }
  canvas.addEventListener('pointerup', pointerEnd);
  canvas.addEventListener('pointercancel', pointerEnd);
  canvas.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  document.addEventListener('visibilitychange', function () { if (document.hidden) { if (G.playing && !G.overlay && (G.screen === 'raid' || G.screen === 'farm')) act('pause'); save(); } });
  window.addEventListener('pagehide', function () { save(); });

  /* ── the test door: state reads and the capture clock, nothing that bypasses the game ─── */
  window.GAME = {
    G: G, act: act, go: go, fit: fit, draw: draw, update: update, save: save, readSave: readSave, beginPlay: beginPlay, startRaid: startRaid,
    raidButtons: raidButtons, farmLayout: farmLayout,
    setShape: function (s) { G.forceShape = s; fit(); },
    setPaused: function (p) { G.frozen = !!p; last = 0; },
    frame: function (dt) { update(dt || 1 / 60); draw(); },
    state: function () {
      var st = G.st, rd = G.rd;
      return { screen: G.screen, overlay: G.overlay, shape: G.shape, W: G.W, H: G.H, focus: G.focus, sel: G.sel,
        hits: G.hitsCache.map(function (h) { return h.id; }), loaded: G.loaded, toLoad: G.toLoad, missing: G.missing || [],
        farm: st ? JSON.parse(SIM.serialise(st)) : null,
        raid: rd ? { zone: rd.zone.id, t: rd.t, over: rd.over, outcome: rd.outcome, p: { x: rd.p.x, y: rd.p.y }, pack: rd.pack.length, stormX: rd.stormX, log: rd.log.length } : null,
        result: G.result ? { outcome: G.result.outcome, kept: G.result.res.kept.length, lost: G.result.res.lost.length, fresh: G.result.res.got.newStrains } : null,
        muted: A.muted, audioReady: A.ready, played: A.played, saveRefused: G.saveRefused };
    },
  };
  /* An automated build check's contract: a simulated clock, a way to start play, and an input probe
   * made of REAL key events whose effect must show up in the game's own log. */
  window.__game = {
    get elapsed() { return G.st ? G.st.t : 0; },
    begin: function () { beginPlay(true); startRaid('hedgerow'); },
    inputProbe: {
      /* the key is HELD through the settle window: a keydown and keyup dispatched in the same tick
       * leave no frame in which the raid ever saw it down, and the farmer never moves */
      events: [{ type: 'keydown', init: { code: 'KeyD', key: 'd' } }],
      read: function () { return G.rd ? Math.round(G.rd.p.x * 1000) : 0; },
      settleMs: 250,
    },
  };

  requestAnimationFrame(loop);
}());
