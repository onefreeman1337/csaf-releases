/* SEEDLIFT — the farm simulation. Pure and deterministic: no DOM, no Date, no Math.random.
 * This file holds the FARM half: plots, growth, harvest, cross-breeding, the shop, permits, the
 * farm hands, offline growth and the save. The RAID half lives in raid.js and hands its haul back
 * through settleRaid(), the one place a raid changes the farm.
 * Browser: window.SIM (needs window.ZONES). Node: module.exports. */
(function (root) {
  'use strict';
  var Z = (typeof module !== 'undefined' && module.exports) ? require('./zones.js') : root.ZONES;

  var SAVE_KEY = 'seedlift.save.v1';
  var OFFLINE_CAP_SEC = 8 * 3600;       // growth credited for time away, at most eight hours
  var CROSS_CHANCE = 0.35;              // per harvest, per qualifying neighbour pair
  var LINGER_SEC = 12;                  // farm hands leave a ripe plant standing this long, so a slower neighbour can ripen beside it and cross
  var TOOL_CAP = 9;                     // lures and smoke pots kept in the shed, each
  var START_COLS = 6, START_ROWS = 5, MAX_COLS = 8, MAX_ROWS = 6;
  var FIELD_SIZES = [[6, 5], [7, 5], [7, 6], [8, 6]];

  /* The shop. Each line changes how the game already plays; cost[i] buys level i+1. */
  var UPGRADES = [
    { id: 'field', name: 'More Field', cost: [90, 300, 780], blurb: 'Clear more ground: 30 plots become 35, then 42, then 48.' },
    { id: 'sprinkler', name: 'Sprinklers', cost: [60, 200, 500, 1200, 2500], blurb: 'Every crop grows a quarter faster per level.' },
    { id: 'compost', name: 'Compost', cost: [75, 240, 600, 1400, 2800], blurb: 'Every harvest sells for a fifth more per level.' },
    { id: 'pack', name: 'Bigger Pack', cost: [120, 420, 1080], blurb: 'One more pack slot and two more carry weight per level.' },
    { id: 'boots', name: 'Field Boots', cost: [220, 900], blurb: 'Level 1: a DASH in the wilds. Level 2: you walk faster.' },
    { id: 'pouch', name: 'Oilskin Pouch', cost: [330, 1250], blurb: 'Keeps the first pack slot (then two) even when the storm takes you.' },
    { id: 'hands', name: 'Farm Hands', cost: [450, 1800], blurb: 'Level 1 harvests ripe crops while you are away. Level 2 sows them again.' },
    { id: 'frame', name: 'Cold Frame', cost: [1400], blurb: 'Glass over the beds: Ridge Garden strains will grow at home.' },
  ];
  var UP_BY_ID = {};
  UPGRADES.forEach(function (u) { UP_BY_ID[u.id] = u; });

  /* mulberry32: small, fast, and the same sequence on every machine. */
  function rng(st) {
    st.seed = (st.seed + 0x6D2B79F5) >>> 0;
    var t = st.seed;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  function freshUpgrades() { var o = {}; UPGRADES.forEach(function (u) { o[u.id] = 0; }); return o; }
  function freshStats() { return { raids: 0, lifted: 0, lost: 0, harvests: 0, crosses: 0, podsLifted: 0, coinEarned: 0 }; }

  function create(seed) {
    var st = {
      v: 1, seed: (seed >>> 0) || 1, t: 0, coin: 0,
      cols: START_COLS, rows: START_ROWS, plots: [],
      bank: { sweetroot: 2, hedgepea: 2 },   // the first two strains, so the first minute is planting, not reading
      codex: { sweetroot: true, hedgepea: true },
      upgrades: freshUpgrades(),
      tools: { lure: 0, smoke: 0 }, away: null,
      stats: freshStats(),
      permits: 1, ended: false, log: [],
    };
    for (var i = 0; i < st.cols * st.rows; i++) st.plots.push(null);
    return st;
  }

  function idx(st, c, r) { return (c < 0 || r < 0 || c >= st.cols || r >= st.rows) ? -1 : r * st.cols + c; }

  function speed(st) { return 1 + 0.25 * st.upgrades.sprinkler; }
  function yieldMul(st) { return 1 + 0.2 * st.upgrades.compost; }
  function growSecOf(st, p) { return Z.strain(p.strain).growSec / speed(st); }

  function progress(st, p) {
    if (!p) return 0;
    return Math.min(1, (st.t - p.at) / growSecOf(st, p));
  }
  function mature(st, p) { return !!p && progress(st, p) >= 1; }
  function ripeSince(st, p) { return st.t - (p.at + growSecOf(st, p)); }

  /* Every refusal is named, so a test can tell WHICH rule said no. */
  function plant(st, c, r, strainId) {
    var i = idx(st, c, r);
    if (i < 0) return { ok: false, why: 'off-grid' };
    if (st.plots[i]) return { ok: false, why: 'occupied' };
    var s = Z.strain(strainId);
    if (!s) return { ok: false, why: 'unknown-strain' };
    if (!(st.bank[strainId] > 0)) return { ok: false, why: 'no-seed' };
    if (s.frame && st.upgrades.frame < 1) return { ok: false, why: 'needs-frame' };
    st.bank[strainId]--;
    st.plots[i] = { strain: strainId, at: st.t };
    return { ok: true };
  }

  /* The tools a crop becomes: what the two halves of the game trade. */
  var TOOL_YIELD = { lure: ['lure', 1], lure2: ['lure', 2], smoke: ['smoke', 1], smoke2: ['smoke', 2] };

  /* Harvest a mature plot: coin, 1-2 seeds of its own strain, the tool it makes (if any), and a
   * chance of a hybrid seed for each orthogonal neighbour that is ALSO mature and makes a recipe. */
  function harvest(st, c, r) {
    var i = idx(st, c, r);
    if (i < 0) return { ok: false, why: 'off-grid' };
    var p = st.plots[i];
    if (!p) return { ok: false, why: 'empty' };
    if (!mature(st, p)) return { ok: false, why: 'not-ripe' };
    var s = Z.strain(p.strain);
    if (s.ending) { st.plots[i] = null; st.ended = true; st.log.push({ t: st.t, ev: 'ending' }); return { ok: true, ending: true, coin: 0, seeds: 0, hybrids: [], tool: null }; }
    var coin = Math.round(s.coin * yieldMul(st));
    var seeds = 1 + (rng(st) < 0.5 ? 1 : 0);
    st.coin += coin;
    st.stats.coinEarned += coin;
    st.stats.harvests++;
    st.bank[p.strain] = (st.bank[p.strain] || 0) + seeds;
    var tool = null, toolN = 0;
    if (s.tool && TOOL_YIELD[s.tool]) {
      var ty = TOOL_YIELD[s.tool];
      var before = st.tools[ty[0]];
      st.tools[ty[0]] = Math.min(TOOL_CAP, before + ty[1]);
      if (st.tools[ty[0]] > before) { tool = ty[0]; toolN = st.tools[ty[0]] - before; }
    }
    var hybrids = [];
    [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (d) {
      var j = idx(st, c + d[0], r + d[1]);
      if (j < 0) return;
      var q = st.plots[j];
      if (!q || q.strain === p.strain || !mature(st, q)) return;
      var h = Z.hybridOf(p.strain, q.strain);
      if (h && rng(st) < CROSS_CHANCE) {
        st.bank[h.id] = (st.bank[h.id] || 0) + 1;
        st.codex[h.id] = true;
        st.stats.crosses++;
        hybrids.push(h.id);
      }
    });
    st.plots[i] = null;
    st.log.push({ t: st.t, ev: 'harvest', strain: p.strain, coin: coin, seeds: seeds, hybrids: hybrids, tool: tool, toolN: toolN, c: c, r: r });
    return { ok: true, coin: coin, seeds: seeds, hybrids: hybrids, tool: tool };
  }

  /* Farm hands: level 1 harvests anything that has stood ripe for LINGER_SEC; level 2 sows the same
   * strain again when a seed is in the bank. Only crops hands can see are touched: the ending's
   * flower is always the player's to pick. */
  function hands(st) {
    var lvl = st.upgrades.hands;
    if (lvl < 1) return 0;
    var n = 0;
    for (var r = 0; r < st.rows; r++) for (var c = 0; c < st.cols; c++) {
      var p = st.plots[r * st.cols + c];
      if (!p || Z.strain(p.strain).ending || !mature(st, p) || ripeSince(st, p) < LINGER_SEC) continue;
      var strain = p.strain;
      var res = harvest(st, c, r);
      if (res.ok) {
        n++;
        st.log[st.log.length - 1].byHands = true;
        if (lvl >= 2 && st.bank[strain] > 0) plant(st, c, r, strain);
      }
    }
    return n;
  }

  /* The clock. Growth is a function of time; only the hands need per-tick work. */
  function tick(st, dt) { st.t += dt; hands(st); }
  /* Time away (a closed tab): credited in 2-second steps so the hands work through it in order. */
  function creditOffline(st, secondsAway) {
    var s = Math.max(0, Math.min(OFFLINE_CAP_SEC, +secondsAway || 0));
    var left = s;
    while (left > 0) { var d = Math.min(2, left); tick(st, d); left -= d; }
    return s;
  }

  /* ── the shop and the permits ─────────────────────────────────────────────────────────── */
  function costOf(id, level) {
    var u = UP_BY_ID[id]; if (!u) return null;
    return level < u.cost.length ? u.cost[level] : null;
  }
  function resizeGrid(st, cols, rows) {
    var np = [];
    for (var r = 0; r < rows; r++) for (var c = 0; c < cols; c++) np.push(c < st.cols && r < st.rows ? st.plots[r * st.cols + c] : null);
    st.cols = cols; st.rows = rows; st.plots = np;
  }
  function buy(st, id) {
    var u = UP_BY_ID[id];
    if (!u) return { ok: false, why: 'unknown-upgrade' };
    var lvl = st.upgrades[id], cost = costOf(id, lvl);
    if (cost === null) return { ok: false, why: 'maxed' };
    if (st.coin < cost) return { ok: false, why: 'too-poor' };
    st.coin -= cost;
    st.upgrades[id] = lvl + 1;
    if (id === 'field') { var sz = FIELD_SIZES[lvl + 1]; resizeGrid(st, sz[0], sz[1]); }
    st.log.push({ t: st.t, ev: 'buy', id: id, level: lvl + 1, cost: cost });
    return { ok: true, level: lvl + 1, cost: cost };
  }
  function codexCount(st) { return Z.codexIds().filter(function (id) { return st.codex[id]; }).length; }
  /* The next zone's permit: coin AND a codex milestone. */
  function nextPermit(st) {
    if (st.permits >= Z.ZONES.length) return null;
    var z = Z.ZONES[st.permits];
    return { zone: z, coin: z.permitCoin, codex: z.permitCodex, haveCoin: st.coin >= z.permitCoin, haveCodex: codexCount(st) >= z.permitCodex };
  }
  function buyPermit(st) {
    var p = nextPermit(st);
    if (!p) return { ok: false, why: 'all-open' };
    if (!p.haveCodex) return { ok: false, why: 'codex' };
    if (!p.haveCoin) return { ok: false, why: 'too-poor' };
    st.coin -= p.coin;
    st.permits++;
    st.log.push({ t: st.t, ev: 'permit', zone: p.zone.id });
    return { ok: true, zone: p.zone.id };
  }

  /* ── the raid's door into the farm ────────────────────────────────────────────────────── */
  /* What the shed WOULD send with the player: at most 3 of each tool. */
  function kit(st) { return { lure: Math.min(3, st.tools.lure), smoke: Math.min(3, st.tools.smoke) }; }
  /* Setting out: the kit leaves the shed and is recorded as AWAY, so a tab closed mid-raid cannot
   * refund what was thrown; the next load settles an away kit as a quit (pack lost, belt home). */
  function takeKit(st) {
    /* a kit still AWAY belongs to a raid nobody settled: it goes back in the shed first, never
     * overwritten (the overwrite deleted three lures in the independent review's play) */
    if (st.away) { ['lure', 'smoke'].forEach(function (t) { st.tools[t] = Math.min(TOOL_CAP, st.tools[t] + (st.away[t] | 0)); }); st.away = null; }
    var k = kit(st);
    st.tools.lure -= k.lure; st.tools.smoke -= k.smoke;
    st.away = { lure: k.lure, smoke: k.smoke };
    return k;
  }
  function packSlots(st) { return 4 + st.upgrades.pack; }
  function packWeight(st) { return 6 + 2 * st.upgrades.pack; }
  /* Settle a finished raid. outcome 'lifted' keeps the whole pack; 'lost' and 'quit' keep only the
   * pouch's slots. Tools USED are gone; the rest of the away kit comes back to the shed (the belt
   * comes home with you; only the pack is the storm's). */
  function settleRaid(st, outcome, pack, toolsUsed) {
    var keep = outcome === 'lifted' ? pack.length : Math.min(pack.length, st.upgrades.pouch);
    var kept = pack.slice(0, keep), lostItems = pack.slice(keep);
    var got = { coin: 0, pods: [], newStrains: [] };
    kept.forEach(function (it) {
      if (it.kind === 'coin') { st.coin += it.amount; st.stats.coinEarned += it.amount; got.coin += it.amount; }
      else if (it.kind === 'pod' && Z.strain(it.strain)) {
        if (!st.codex[it.strain] && Z.codexIds().indexOf(it.strain) >= 0) { st.codex[it.strain] = true; got.newStrains.push(it.strain); }
        st.bank[it.strain] = (st.bank[it.strain] || 0) + 1;
        got.pods.push(it.strain);
        st.stats.podsLifted++;
      }
    });
    toolsUsed = toolsUsed || {};
    var away = st.away || { lure: 0, smoke: 0 };
    ['lure', 'smoke'].forEach(function (k) { st.tools[k] = Math.min(TOOL_CAP, st.tools[k] + Math.max(0, (away[k] | 0) - (toolsUsed[k] | 0))); });
    st.away = null;
    st.stats.raids++;
    if (outcome === 'lifted') st.stats.lifted++; else st.stats.lost++;
    st.log.push({ t: st.t, ev: 'raid', outcome: outcome, kept: kept.length, lost: lostItems.length });
    return { outcome: outcome, kept: kept, lost: lostItems, got: got };
  }
  /* Is the ending's seed anywhere the player owns it? (Then no raid offers another.) */
  function hasCentrepiece(st) {
    if (st.ended || st.bank.centrepiece > 0) return true;
    for (var i = 0; i < st.plots.length; i++) if (st.plots[i] && st.plots[i].strain === 'centrepiece') return true;
    return false;
  }

  /* ── save / load. deserialise refuses anything a player could not have reached by playing ── */
  function serialise(st) {
    return JSON.stringify({ v: 1, seed: st.seed, t: st.t, coin: st.coin, cols: st.cols, rows: st.rows, plots: st.plots,
      bank: st.bank, codex: st.codex, upgrades: st.upgrades, tools: st.tools, away: st.away, stats: st.stats, permits: st.permits, ended: st.ended });
  }
  function deserialise(text) {
    var o;
    try { o = JSON.parse(text); } catch (e) { return { ok: false, why: 'not-json' }; }
    if (!o || o.v !== 1) return { ok: false, why: 'version' };
    var num = function (x) { return typeof x === 'number' && isFinite(x) && x >= 0; };
    var cnt = function (x) { return Number.isInteger(x) && x >= 0; };
    if (!num(o.t) || !num(o.coin) || !num(o.seed)) return { ok: false, why: 'bad-number' };
    var up = freshUpgrades();
    if (!o.upgrades || typeof o.upgrades !== 'object') return { ok: false, why: 'bad-upgrade' };
    for (var u in o.upgrades) if (!(u in up) || !cnt(o.upgrades[u]) || o.upgrades[u] > UP_BY_ID[u].cost.length) return { ok: false, why: 'bad-upgrade' };
    var fl = o.upgrades.field | 0, size = FIELD_SIZES[fl];
    if (!(o.cols === size[0] && o.rows === size[1])) return { ok: false, why: 'bad-grid' };
    if (!Array.isArray(o.plots) || o.plots.length !== o.cols * o.rows) return { ok: false, why: 'bad-plots' };
    for (var i = 0; i < o.plots.length; i++) {
      var p = o.plots[i];
      if (p === null) continue;
      if (!p || !Z.strain(p.strain) || !num(p.at) || p.at > o.t) return { ok: false, why: 'bad-plot' };
    }
    if (!o.bank || typeof o.bank !== 'object') return { ok: false, why: 'bad-bank' };
    for (var k in o.bank) if (!Z.strain(k) || !cnt(o.bank[k])) return { ok: false, why: 'bad-bank' };
    var known = Z.codexIds();
    if (!o.codex || typeof o.codex !== 'object') return { ok: false, why: 'bad-codex' };
    for (var c in o.codex) if (known.indexOf(c) < 0 || o.codex[c] !== true) return { ok: false, why: 'bad-codex' };
    if (!o.tools || !cnt(o.tools.lure) || !cnt(o.tools.smoke) || o.tools.lure > TOOL_CAP || o.tools.smoke > TOOL_CAP || Object.keys(o.tools).length !== 2) return { ok: false, why: 'bad-tools' };
    var fs = freshStats();
    if (!o.stats || typeof o.stats !== 'object') return { ok: false, why: 'bad-stats' };
    for (var s in o.stats) if (!(s in fs) || !cnt(o.stats[s])) return { ok: false, why: 'bad-stats' };
    if (!(Number.isInteger(o.permits) && o.permits >= 1 && o.permits <= Z.ZONES.length)) return { ok: false, why: 'bad-permits' };
    if (typeof o.ended !== 'boolean') return { ok: false, why: 'bad-ended' };
    /* the away kit, and (since a mid-raid save records it) what the Oilskin Pouch held: no more items
     * than the pouch has slots, each a real strain or a plausible coin cache */
    var awayPouchOk = function (a) {
      if (!('pouch' in a)) return Object.keys(a).length === 2;
      if (Object.keys(a).length !== 3 || !Array.isArray(a.pouch) || a.pouch.length < 1 || a.pouch.length > ((o.upgrades && o.upgrades.pouch) | 0)) return false;
      return a.pouch.every(function (it) { return it && ((it.kind === 'coin' && cnt(it.amount) && it.amount <= 500 && Object.keys(it).length === 2) || (it.kind === 'pod' && Z.strain(it.strain) && Object.keys(it).length === 2)); });
    };
    if (o.away !== null && (!o.away || !cnt(o.away.lure) || !cnt(o.away.smoke) || o.away.lure > 3 || o.away.smoke > 3 || !awayPouchOk(o.away))) return { ok: false, why: 'bad-away' };
    var st = create(o.seed);
    st.t = o.t; st.coin = o.coin; st.cols = o.cols; st.rows = o.rows; st.plots = o.plots;
    st.bank = o.bank; st.codex = o.codex; st.upgrades = Object.assign(up, o.upgrades);
    st.tools = { lure: o.tools.lure, smoke: o.tools.smoke }; st.stats = Object.assign(fs, o.stats);
    st.permits = o.permits; st.ended = o.ended; st.away = o.away ? { lure: o.away.lure, smoke: o.away.smoke } : null;
    if (st.away && o.away.pouch) st.away.pouch = o.away.pouch.map(function (it) { return it.kind === 'coin' ? { kind: 'coin', amount: it.amount } : { kind: 'pod', strain: it.strain }; });
    return { ok: true, st: st };
  }

  var API = { SAVE_KEY: SAVE_KEY, OFFLINE_CAP_SEC: OFFLINE_CAP_SEC, CROSS_CHANCE: CROSS_CHANCE, LINGER_SEC: LINGER_SEC, TOOL_CAP: TOOL_CAP,
    UPGRADES: UPGRADES, FIELD_SIZES: FIELD_SIZES,
    create: create, plant: plant, harvest: harvest, hands: hands, tick: tick, creditOffline: creditOffline,
    progress: progress, mature: mature, ripeSince: ripeSince, codexCount: codexCount, speed: speed, yieldMul: yieldMul,
    costOf: costOf, buy: buy, nextPermit: nextPermit, buyPermit: buyPermit,
    kit: kit, takeKit: takeKit, packSlots: packSlots, packWeight: packWeight, settleRaid: settleRaid, hasCentrepiece: hasCentrepiece,
    serialise: serialise, deserialise: deserialise, rng: rng };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else root.SIM = API;
})(typeof window !== 'undefined' ? window : this);
