/* SEEDLIFT — the raid simulation. Pure and deterministic: no DOM, no Date, no Math.random.
 *
 * A raid is a top-down map generated from a seed. The storm wall crosses it from the west in
 * zone.raidSec seconds; lifts open and close in a rhythm; you pick up seed pods and coin caches
 * into a pack with slots and a weight limit, and stand in an OPEN lift holding LIFT to get out.
 * Boars charge in straight lines and spill an item; crows steal one and fly for the edge.
 * The farm's crops are the only tools: a LURE pulls boars away, SMOKE scatters crows.
 *
 * Input reaches the raid through ONE door, RAID.setKey(rd, verb, value): keyboard, touch stick
 * and buttons, and the bot all use it. Units are TILES and SECONDS; one tick is RAID.H seconds.
 * Browser: window.RAID (needs window.ZONES). Node: module.exports. */
(function (root) {
  'use strict';
  var Z = (typeof module !== 'undefined' && module.exports) ? require('./zones.js') : root.ZONES;

  var H = 1 / 60;
  var MW = 56, MH = 34;                         // map size in tiles
  var T_OPEN = 0, T_BLOCK = 1, T_BRAMBLE = 2, T_BOG = 3;
  var SLOW = [1, 0, 0.55, 0.45];                // speed multiplier per terrain
  var PR = 0.3;                                 // the player's collision half-size, tiles
  var WALK = 4.0;                               // base walking speed, tiles/s
  var LIFT_PERIOD = 24, LIFT_OPEN = 10, LIFT_HOLD = 1.4, LIFT_R = 1.1;
  var LURE_SEC = 7, LURE_PULL = 8, SMOKE_SEC = 4.5, SMOKE_R = 3.6;
  var DASH_SEC = 0.2, DASH_CD = 2.4, DASH_MUL = 3;
  var BOAR_SEE = 6.5, BOAR_AIM = 0.65, BOAR_CHARGE = 8.5, BOAR_RUN = 9, BOAR_STUN = 1.3, BOAR_REST = 0.9;
  var CROW_SEEK = 5.0, CROW_FLEE = 3.3, CROW_MAX = 2, CROW_GRACE = 0.35;
  var VERBS = ['up', 'down', 'left', 'right', 'action', 'lure', 'smoke', 'dash'];

  function rnd(rd) {
    rd.seed = (rd.seed + 0x6D2B79F5) >>> 0;
    var t = rd.seed;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  function hash2(x, y, s) {
    var n = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(s | 0, 2147483647);
    n = Math.imul(n ^ (n >>> 13), 1274126177);
    return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
  }
  /* Smooth value noise at a cell size, for patches of bog and bramble. */
  function vnoise(x, y, cell, s) {
    var gx = x / cell, gy = y / cell, x0 = Math.floor(gx), y0 = Math.floor(gy), fx = gx - x0, fy = gy - y0;
    fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
    var a = hash2(x0, y0, s), b = hash2(x0 + 1, y0, s), c = hash2(x0, y0 + 1, s), d = hash2(x0 + 1, y0 + 1, s);
    return (a + (b - a) * fx) + ((c + (d - c) * fx) - (a + (b - a) * fx)) * fy;
  }

  function tileAt(rd, x, y) {
    var tx = Math.floor(x), ty = Math.floor(y);
    if (tx < 0 || ty < 0 || tx >= MW || ty >= MH) return T_BLOCK;
    return rd.map[ty * MW + tx];
  }
  function blockedAt(rd, x, y) { return tileAt(rd, x, y) === T_BLOCK; }
  function boxBlocked(rd, x, y, r) {
    return blockedAt(rd, x - r, y - r) || blockedAt(rd, x + r, y - r) || blockedAt(rd, x - r, y + r) || blockedAt(rd, x + r, y + r);
  }

  /* ── the map ─────────────────────────────────────────────────────────────────────────── */
  function genMap(rd, zone) {
    var s = rd.mapSeed, map = new Array(MW * MH);
    for (var y = 0; y < MH; y++) for (var x = 0; x < MW; x++) {
      var t = T_OPEN;
      var clump = vnoise(x, y, 3.2, s) * 0.65 + vnoise(x, y, 1.6, s + 7) * 0.35;
      var bogN = vnoise(x, y, 5.0, s + 13) * 0.7 + vnoise(x, y, 2.2, s + 17) * 0.3;
      var brN = vnoise(x, y, 2.6, s + 23);
      if (zone.bog && bogN > 1 - zone.bog * 1.55) t = T_BOG;
      if (brN > 1 - zone.bramble * 2.2) t = T_BRAMBLE;
      if (clump > 1 - zone.blocked * 1.6) t = T_BLOCK;
      if (zone.orchard) {
        /* rows of old trees on a 4-tile lattice, with a jittered gap, and two long garden walls */
        if (x % 4 === 2 && y % 4 === 2 && hash2(x, y, s + 31) < 0.8) t = T_BLOCK;
      }
      map[y * MW + x] = t;
    }
    if (zone.orchard) {
      for (var w = 0; w < 2; w++) {
        var wy = 8 + w * 13 + Math.floor(hash2(w, 1, s + 41) * 3);
        for (var wx = 6; wx < MW - 4; wx++) {
          var gap = (wx % 11) === Math.floor(hash2(w, 2, s + 43) * 11) || (wx % 11) === ((Math.floor(hash2(w, 2, s + 43) * 11) + 1) % 11);
          if (!gap) map[wy * MW + wx] = T_BLOCK;
        }
      }
    }
    for (var e = 0; e < MW; e++) { map[e] = T_BLOCK; map[(MH - 1) * MW + e] = T_BLOCK; }
    for (var f = 0; f < MH; f++) { map[f * MW] = T_BLOCK; map[f * MW + MW - 1] = T_BLOCK; }
    rd.map = map;
  }
  function carve(rd, cx, cy, r, keepSlow) {
    for (var y = cy - r; y <= cy + r; y++) for (var x = cx - r; x <= cx + r; x++) {
      if (x < 1 || y < 1 || x >= MW - 1 || y >= MH - 1) continue;
      var i = y * MW + x;
      if (!keepSlow || rd.map[i] === T_BLOCK) rd.map[i] = T_OPEN;
    }
  }
  /* Travel cost in tile-lengths over walkable tiles (slow ground costs more), 8-way without cutting
   * corners: Dijkstra on a binary heap, exact. */
  function distField(rd, sx, sy) {
    var n = MW * MH, d = new Float32Array(n); d.fill(1e9);
    var s = sy * MW + sx; if (sx < 0 || sy < 0 || sx >= MW || sy >= MH || rd.map[s] === T_BLOCK) return d;
    var hk = new Float32Array(n * 8), hv = new Int32Array(n * 8), hn = 0;
    function push(k, v) { var i = hn++; hk[i] = k; hv[i] = v; while (i > 0) { var pa = (i - 1) >> 1; if (hk[pa] <= hk[i]) break; var tk = hk[pa]; hk[pa] = hk[i]; hk[i] = tk; var tv = hv[pa]; hv[pa] = hv[i]; hv[i] = tv; i = pa; } }
    function pop() {
      var v = hv[0]; hn--; hk[0] = hk[hn]; hv[0] = hv[hn]; var i = 0;
      for (;;) { var l = 2 * i + 1, r = l + 1, m = i; if (l < hn && hk[l] < hk[m]) m = l; if (r < hn && hk[r] < hk[m]) m = r; if (m === i) break; var tk = hk[m]; hk[m] = hk[i]; hk[i] = tk; var tv = hv[m]; hv[m] = hv[i]; hv[i] = tv; i = m; }
      return v;
    }
    d[s] = 0; push(0, s);
    while (hn > 0) {
      var key = hk[0], i = pop();
      if (key > d[i] + 1e-6) continue;
      var x = i % MW, y = (i / MW) | 0;
      for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        var nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= MW || ny >= MH) continue;
        var j = ny * MW + nx; if (rd.map[j] === T_BLOCK) continue;
        if (dx && dy && (rd.map[y * MW + nx] === T_BLOCK || rd.map[ny * MW + x] === T_BLOCK)) continue;
        var nd = d[i] + (dx && dy ? 1.414 : 1) / Math.max(0.3, SLOW[rd.map[j]]);
        if (nd < d[j] - 1e-6) { d[j] = nd; if (hn < hk.length) push(nd, j); }
      }
    }
    return d;
  }

  /* ── a new raid ──────────────────────────────────────────────────────────────────────── */
  /* opts: { zone, seed, slots, weight, kit:{lure,smoke}, boots, pouch, wantCentrepiece, missing:[strain ids not yet in the codex] } */
  function create(opts) {
    var zone = Z.zone(opts.zone) || Z.ZONES[0];
    var rd = {
      zone: zone, seed: (opts.seed >>> 0) || 1, mapSeed: 0, t: 0, over: false, outcome: null,
      slots: opts.slots || 4, weightCap: opts.weight || 6, kit: { lure: (opts.kit && opts.kit.lure) | 0, smoke: (opts.kit && opts.kit.smoke) | 0 },
      used: { lure: 0, smoke: 0 }, boots: opts.boots | 0, pouch: opts.pouch | 0, missing: (opts.missing || []).slice(),
      keys: {}, stick: { x: 0, y: 0 }, presses: [],
      pack: [], items: [], lifts: [], boars: [], crows: [], lures: [], smokes: [],
      p: { x: 0, y: 0, face: { x: 1, y: 0 }, inv: 0, dashT: 0, dashCd: 0, kx: 0, ky: 0, kt: 0, moving: false },
      hold: 0, holdLift: -1, crowClock: 0, log: [], stormX: -1.5, fullWarn: 0,
    };
    rd.mapSeed = Math.floor(rnd(rd) * 1e9);
    VERBS.forEach(function (v) { rd.keys[v] = false; });
    genMap(rd, zone);
    /* spawn near the storm's side: the rare seed is back there, and the clock starts at once */
    var sx = Math.floor(MW * 0.16), sy = Math.floor(MH / 2 + (rnd(rd) - 0.5) * 8);
    carve(rd, sx, sy, 2, false);
    rd.p.x = sx + 0.5; rd.p.y = sy + 0.5; rd.spawn = { x: sx, y: sy };
    /* four lifts, west to east, staggered so one is usually opening somewhere ahead of the storm */
    var lx = [0.36, 0.54, 0.72, 0.9];
    for (var i = 0; i < 4; i++) {
      var tx = Math.max(3, Math.min(MW - 4, Math.round(MW * lx[i] + (rnd(rd) - 0.5) * 4)));
      var ty = Math.max(4, Math.min(MH - 5, Math.round(4 + rnd(rd) * (MH - 9))));
      carve(rd, tx, ty, 1, false);
      rd.lifts.push({ x: tx + 0.5, y: ty + 0.5, phase: (i * LIFT_PERIOD / 4 + rnd(rd) * 3) % LIFT_PERIOD, wasOpen: false });
    }
    var reach = distField(rd, sx, sy);
    /* a lift the spawn cannot walk to gets a corridor carved toward the spawn (never an unreachable exit) */
    rd.lifts.forEach(function (L) {
      if (reach[Math.floor(L.y) * MW + Math.floor(L.x)] < 1e8) return;
      var x = Math.floor(L.x), y = Math.floor(L.y);
      while (x !== sx || y !== sy) { carve(rd, x, y, 0, true); if (x !== sx) x += x > sx ? -1 : 1; else y += y > sy ? -1 : 1; }
      reach = distField(rd, sx, sy);
    });
    rd.reach = reach;
    placeItems(rd, zone, opts);
    for (var b = 0; b < zone.boars; b++) {
      var spot = freeSpot(rd, 0.4, 0.95, 3);
      if (spot) rd.boars.push({ x: spot.x, y: spot.y, hx: spot.x, hy: spot.y, state: 'roam', t: 0, dx: 0, dy: 0, run: 0, wx: spot.x, wy: spot.y });
    }
    rd.crowClock = zone.crowEvery ? zone.crowEvery * 0.6 : 0;
    rd.liftField = rd.lifts.map(function (L) { return distField(rd, Math.floor(L.x), Math.floor(L.y)); });
    return rd;
  }
  /* A reachable, walkable tile inside an x band (fractions of the width), away from the spawn and
   * from other things by `gap` tiles. */
  function freeSpot(rd, fx0, fx1, gap) {
    for (var tries = 0; tries < 400; tries++) {
      var x = Math.floor(MW * fx0 + rnd(rd) * MW * (fx1 - fx0)), y = Math.floor(2 + rnd(rd) * (MH - 4));
      var i = y * MW + x;
      if (rd.map[i] === T_BLOCK || rd.reach[i] > 1e8) continue;
      var cx = x + 0.5, cy = y + 0.5, near = false;
      if (Math.hypot(cx - rd.p.x, cy - rd.p.y) < 3) continue;
      for (var k = 0; k < rd.items.length && !near; k++) if (Math.hypot(rd.items[k].x - cx, rd.items[k].y - cy) < gap) near = true;
      for (var m = 0; m < rd.lifts.length && !near; m++) if (Math.hypot(rd.lifts[m].x - cx, rd.lifts[m].y - cy) < 2) near = true;
      if (!near) return { x: cx, y: cy };
    }
    return null;
  }
  function weightOf(it) {
    if (it.kind === 'coin') return 1;
    var s = Z.strain(it.strain);
    return s.ending ? 3 : (s.rarity >= 3 ? 2 : 1);
  }
  function placeItems(rd, zone, opts) {
    var strains = Z.strainsOf(zone.id);
    var add = function (it, fx0, fx1) { var sp = freeSpot(rd, fx0, fx1, 2.4); if (sp) { it.x = sp.x; it.y = sp.y; it.w = weightOf(it); rd.items.push(it); } };
    /* the ending's seed, once, far back on the storm's side */
    if (opts.wantCentrepiece && zone.id === 'ridge') add({ kind: 'pod', strain: 'centrepiece' }, 0.06, 0.22);
    /* at least one pod of each strain this zone still owes the codex (one per raid), so every raid can progress */
    (opts.missing || []).filter(function (id) { var s = Z.strain(id); return s && s.zone === zone.id; }).slice(0, 1)
      .forEach(function (id) { add({ kind: 'pod', strain: id }, 0.1, 0.8); });
    var want = zone.pods;
    while (rd.items.filter(function (i) { return i.kind === 'pod'; }).length < want) {
      /* rarity leans toward the storm's side: the rare seed is where the danger is */
      var fx = rnd(rd), weights = strains.map(function (s) { return s.rarity === 1 ? 6 : (s.rarity === 2 ? 3 : 1.3 * (1.9 - 1.5 * fx)); });
      var tot = weights.reduce(function (a, b) { return a + b; }, 0), pick = rnd(rd) * tot, k = 0;
      while (pick > weights[k] && k < weights.length - 1) { pick -= weights[k]; k++; }
      /* a strain the codex still lacks is SCARCE in the open (the one guaranteed pod aside): the
       * codex is a milestone, and a raid that hands over a whole zone at once makes it none */
      if (rd.missing.indexOf(strains[k].id) >= 0 && rnd(rd) < 0.8) continue;
      var before = rd.items.length;
      add({ kind: 'pod', strain: strains[k].id }, Math.max(0.05, fx - 0.08), Math.min(0.97, fx + 0.08));
      if (rd.items.length === before) want--;              // no room there: one fewer, never a hang
    }
    for (var c = 0; c < zone.caches; c++) add({ kind: 'coin', amount: Math.round(zone.n * (6 + rnd(rd) * 8)) }, 0.12, 0.95);
  }

  /* ── state questions ─────────────────────────────────────────────────────────────────── */
  function liftOpen(rd, L, t) { var ph = ((t === undefined ? rd.t : t) + L.phase) % LIFT_PERIOD; return ph < LIFT_OPEN; }
  /* seconds until this lift next opens (0 when open) and how long it stays open from now */
  function liftTiming(rd, L) {
    var ph = (rd.t + L.phase) % LIFT_PERIOD;
    return ph < LIFT_OPEN ? { open: true, left: LIFT_OPEN - ph, next: 0 } : { open: false, left: 0, next: LIFT_PERIOD - ph };
  }
  function stormAt(rd, t) { return -1.5 + (MW + 3) * (t / rd.zone.raidSec); }
  function stormTimeAt(rd, x) { return (x + 1.5) / (MW + 3) * rd.zone.raidSec; }
  function swallowed(rd, x) { return x < rd.stormX + 0.4; }
  function packWeight(rd) { return rd.pack.reduce(function (a, it) { return a + it.w; }, 0); }
  function fits(rd, it) { return rd.pack.length < rd.slots && packWeight(rd) + it.w <= rd.weightCap; }
  /* What an item is worth to THIS player: a strain the codex lacks beats any rarity; the ending's
   * seed beats everything; coin is worth half its face against a pod that multiplies at home. */
  function valueOf(rd, it) {
    if (it.kind === 'coin') return it.amount / 2;
    var s = Z.strain(it.strain);
    if (s.ending) return 1000;
    var fresh = rd.missing.indexOf(it.strain) >= 0 && !rd.pack.some(function (q) { return q !== it && q.strain === it.strain; });
    return (fresh ? 100 : 0) + 10 * (s.rarity || 1);
  }
  /* SWAP UP: with a full pack, walking over something better than the worst thing in it trades
   * them (the worst goes on the ground where you stand). The pouch's slots are never traded. */
  function swapFor(rd, it) {
    var from = Math.min(rd.pouch, rd.pack.length), worst = -1, wv = Infinity;
    for (var i = from; i < rd.pack.length; i++) { var v = valueOf(rd, rd.pack[i]); if (v < wv) { wv = v; worst = i; } }
    if (worst < 0 || valueOf(rd, it) <= wv + 0.5) return -1;
    var w = packWeight(rd) - rd.pack[worst].w + it.w;
    return w <= rd.weightCap ? worst : -1;
  }
  function speedAt(rd) {
    var w = packWeight(rd) / rd.weightCap;
    var s = WALK * (rd.boots >= 2 ? 1.15 : 1) * (1 - 0.35 * w * w) * SLOW[tileAt(rd, rd.p.x, rd.p.y)] ;
    return s * (rd.p.dashT > 0 ? DASH_MUL : 1);
  }

  /* ── the one input door ──────────────────────────────────────────────────────────────── */
  function setKey(rd, verb, v) {
    if (verb === 'stick') { rd.stick.x = +v.x || 0; rd.stick.y = +v.y || 0; return; }
    if (VERBS.indexOf(verb) < 0) return;
    if (v && !rd.keys[verb] && (verb === 'lure' || verb === 'smoke' || verb === 'dash')) rd.presses.push(verb);
    rd.keys[verb] = !!v;
  }

  function log(rd, ev, extra) { var e = { t: rd.t, ev: ev }; if (extra) for (var k in extra) e[k] = extra[k]; rd.log.push(e); return e; }

  function dropNear(rd, it, x, y, dx, dy) {
    /* put a spilled item on the ground a little way off, on a walkable tile, never inside a wall */
    for (var d = 1.8; d >= 0; d -= 0.3) {
      var nx = x + dx * d, ny = y + dy * d;
      if (!blockedAt(rd, nx, ny) && nx > 1 && ny > 1 && nx < MW - 1 && ny < MH - 1) { it.x = nx; it.y = ny; rd.items.push(it); return it; }
    }
    it.x = x; it.y = y; rd.items.push(it); return it;
  }
  function takeRandom(rd) {
    if (!rd.pack.length) return null;
    /* the pouch's slots are sewn shut: a boar or a crow never takes from them */
    var from = Math.min(rd.pouch, rd.pack.length);
    if (from >= rd.pack.length) return null;
    var i = from + Math.floor(rnd(rd) * (rd.pack.length - from));
    return rd.pack.splice(i, 1)[0];
  }

  /* ── one tick ────────────────────────────────────────────────────────────────────────── */
  function tick(rd) {
    if (rd.over) return;
    rd.t += H;
    rd.stormX = stormAt(rd, rd.t);
    var p = rd.p;
    /* presses: tools and the dash */
    while (rd.presses.length) {
      var v = rd.presses.shift();
      if (v === 'lure') {
        if (rd.kit.lure - rd.used.lure > 0) {
          rd.used.lure++;
          var lx = p.x + p.face.x * 2.5, ly = p.y + p.face.y * 2.5;
          if (blockedAt(rd, lx, ly)) { lx = p.x; ly = p.y; }
          rd.lures.push({ x: lx, y: ly, t: LURE_SEC });
          log(rd, 'lure', { x: lx, y: ly });
        } else log(rd, 'empty', { what: 'lure' });
      } else if (v === 'smoke') {
        if (rd.kit.smoke - rd.used.smoke > 0) {
          rd.used.smoke++;
          rd.smokes.push({ x: p.x, y: p.y, t: SMOKE_SEC });
          log(rd, 'smoke', { x: p.x, y: p.y });
        } else log(rd, 'empty', { what: 'smoke' });
      } else if (v === 'dash') {
        if (rd.boots >= 1 && p.dashCd <= 0) { p.dashT = DASH_SEC; p.dashCd = DASH_CD; p.inv = Math.max(p.inv, DASH_SEC); log(rd, 'dash'); }
      }
    }
    /* movement: keys or the stick, normalised; a knockback overrides both */
    var mx = (rd.keys.right ? 1 : 0) - (rd.keys.left ? 1 : 0) + rd.stick.x;
    var my = (rd.keys.down ? 1 : 0) - (rd.keys.up ? 1 : 0) + rd.stick.y;
    var ml = Math.hypot(mx, my);
    if (ml > 1) { mx /= ml; my /= ml; ml = 1; }
    if (ml > 0.15) { p.face.x = mx / (ml || 1); p.face.y = my / (ml || 1); }
    p.moving = ml > 0.15;
    var sp = speedAt(rd), vx = mx * sp, vy = my * sp;
    if (p.dashT > 0 && ml <= 0.15) { vx = p.face.x * sp; vy = p.face.y * sp; }
    if (p.kt > 0) { vx = p.kx; vy = p.ky; p.kt -= H; }
    var nx = p.x + vx * H; if (!boxBlocked(rd, nx, p.y, PR)) p.x = nx;
    var ny = p.y + vy * H; if (!boxBlocked(rd, p.x, ny, PR)) p.y = ny;
    p.inv = Math.max(0, p.inv - H); p.dashT = Math.max(0, p.dashT - H); p.dashCd = Math.max(0, p.dashCd - H);

    /* pickups on contact */
    for (var i = rd.items.length - 1; i >= 0; i--) {
      var it = rd.items[i];
      if (swallowed(rd, it.x)) { rd.items.splice(i, 1); continue; }
      if (Math.hypot(it.x - p.x, it.y - p.y) > 0.75) continue;
      if (it.cool && rd.t < it.cool) continue;
      if (fits(rd, it)) {
        /* NEW only for the first of a codex-missing strain in the pack: a second one is just seed */
        var fresh = it.kind === 'pod' && rd.missing.indexOf(it.strain) >= 0 && !rd.pack.some(function (q) { return q.strain === it.strain; });
        rd.items.splice(i, 1); rd.pack.push(it); log(rd, 'pickup', { kind: it.kind, strain: it.strain || null, amount: it.amount || 0, fresh: fresh }); continue;
      }
      var sw = swapFor(rd, it);
      if (sw >= 0) {
        var out = rd.pack.splice(sw, 1)[0];
        rd.items.splice(i, 1); rd.pack.push(it);
        out.x = p.x; out.y = p.y; out.cool = rd.t + 1.5; rd.items.push(out);
        log(rd, 'swap', { took: it.strain || 'coin', left: out.strain || 'coin' });
      } else if (rd.t >= rd.fullWarn) { rd.fullWarn = rd.t + 1.5; log(rd, 'packfull'); }
    }

    /* lures and smoke clouds burn down */
    for (var a = rd.lures.length - 1; a >= 0; a--) { rd.lures[a].t -= H; if (rd.lures[a].t <= 0) rd.lures.splice(a, 1); }
    for (var s = rd.smokes.length - 1; s >= 0; s--) { rd.smokes[s].t -= H; if (rd.smokes[s].t <= 0) rd.smokes.splice(s, 1); }

    tickBoars(rd);
    tickCrows(rd);

    /* lifts: a lift opening ahead of the storm is announced; standing in an open one holding LIFT gets you out */
    var inLift = -1;
    rd.lifts.forEach(function (L, k) {
      var open = liftOpen(rd, L) && !swallowed(rd, L.x);
      if (open && !L.wasOpen) log(rd, 'liftopen', { lift: k });
      if (!open && L.wasOpen && !swallowed(rd, L.x)) log(rd, 'liftclose', { lift: k });
      L.wasOpen = open;
      if (open && Math.hypot(L.x - p.x, L.y - p.y) <= LIFT_R) inLift = k;
    });
    if (inLift >= 0 && rd.keys.action) {
      if (rd.holdLift !== inLift) { rd.holdLift = inLift; rd.hold = 0; log(rd, 'lifthold', { lift: inLift }); }
      rd.hold += H;
      if (rd.hold >= LIFT_HOLD) { rd.over = true; rd.outcome = 'lifted'; log(rd, 'lifted', { lift: inLift }); return; }
    } else { rd.hold = 0; rd.holdLift = -1; }

    /* the storm */
    if (p.x - PR < rd.stormX) { rd.over = true; rd.outcome = 'lost'; log(rd, 'lost'); }
  }

  function lineClear(rd, x0, y0, x1, y1) {
    var d = Math.hypot(x1 - x0, y1 - y0), n = Math.ceil(d / 0.25);
    for (var i = 1; i < n; i++) if (blockedAt(rd, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n)) return false;
    return true;
  }
  function inSmoke(rd, x, y) { return rd.smokes.some(function (s) { return Math.hypot(s.x - x, s.y - y) < SMOKE_R; }); }

  function tickBoars(rd) {
    var p = rd.p;
    for (var i = rd.boars.length - 1; i >= 0; i--) {
      var b = rd.boars[i];
      if (swallowed(rd, b.x)) { rd.boars.splice(i, 1); continue; }
      b.t -= H;
      var lure = null, ld = LURE_PULL;
      rd.lures.forEach(function (l) { var d = Math.hypot(l.x - b.x, l.y - b.y); if (d < ld) { ld = d; lure = l; } });
      if (lure && b.state !== 'charge') {
        if (b.state !== 'lured') log(rd, 'boarLured');
        b.state = 'lured';
        if (ld > 0.6) stepBoar(rd, b, (lure.x - b.x) / ld, (lure.y - b.y) / ld, 3);
        continue;
      }
      if (b.state === 'lured') { b.state = 'roam'; b.t = 0; }
      if (b.state === 'roam') {
        var dp = Math.hypot(p.x - b.x, p.y - b.y);
        if (dp < BOAR_SEE && lineClear(rd, b.x, b.y, p.x, p.y)) { b.state = 'aim'; b.t = BOAR_AIM; log(rd, 'boarAim'); continue; }
        var dw = Math.hypot(b.wx - b.x, b.wy - b.y);
        if (dw < 0.3 || b.t <= 0) {
          b.wx = Math.max(1.5, Math.min(MW - 1.5, b.hx + (rnd(rd) - 0.5) * 10)); b.wy = Math.max(1.5, Math.min(MH - 1.5, b.hy + (rnd(rd) - 0.5) * 10)); b.t = 4;
        } else if (!stepBoar(rd, b, (b.wx - b.x) / dw, (b.wy - b.y) / dw, 1.3)) b.t = 0;
      } else if (b.state === 'aim') {
        /* the charge line is fixed at the END of the wind-up: sidestepping during it is the counterplay */
        if (b.t <= 0) {
          var d = Math.hypot(p.x - b.x, p.y - b.y) || 1;
          b.dx = (p.x - b.x) / d; b.dy = (p.y - b.y) / d; b.run = 0; b.state = 'charge'; log(rd, 'boarCharge');
        }
      } else if (b.state === 'charge') {
        var moved = stepBoar(rd, b, b.dx, b.dy, BOAR_CHARGE);
        b.run += BOAR_CHARGE * H;
        if (Math.hypot(p.x - b.x, p.y - b.y) < 0.75 && p.inv <= 0) {
          p.kx = b.dx * 7; p.ky = b.dy * 7; p.kt = 0.2; p.inv = 1.2;
          var it = takeRandom(rd);
          if (it) { dropNear(rd, it, p.x, p.y, b.dx, b.dy); log(rd, 'spill', { kind: it.kind, strain: it.strain || null }); }
          else log(rd, 'bump');
          b.state = 'rest'; b.t = BOAR_REST;
        } else if (!moved) { b.state = 'stun'; b.t = BOAR_STUN; log(rd, 'boarStun'); }
        else if (b.run >= BOAR_RUN) { b.state = 'rest'; b.t = BOAR_REST; }
      } else if (b.state === 'stun' || b.state === 'rest') {
        if (b.t <= 0) { b.state = 'roam'; b.t = 0; }
      }
    }
  }
  function stepBoar(rd, b, dx, dy, spd) {
    var nx = b.x + dx * spd * H, ny = b.y + dy * spd * H, ok = true;
    if (!boxBlocked(rd, nx, b.y, 0.35)) b.x = nx; else ok = false;
    if (!boxBlocked(rd, b.x, ny, 0.35)) b.y = ny; else ok = false;
    return ok;
  }

  function tickCrows(rd) {
    var p = rd.p, z = rd.zone;
    if (z.crowEvery) {
      rd.crowClock -= H;
      if (rd.crowClock <= 0 && rd.crows.length < CROW_MAX) {
        rd.crowClock = z.crowEvery * (0.8 + rnd(rd) * 0.4);
        var top = rnd(rd) < 0.5, cx = Math.max(rd.stormX + 4, 2) + rnd(rd) * Math.max(1, MW - 4 - Math.max(rd.stormX + 4, 2));
        rd.crows.push({ x: Math.min(MW - 2, cx), y: top ? -0.5 : MH + 0.5, state: 'seek', carry: null, t: 0 });
        log(rd, 'crowIn');
      }
    }
    for (var i = rd.crows.length - 1; i >= 0; i--) {
      var c = rd.crows[i], d = Math.hypot(p.x - c.x, p.y - c.y) || 0.001;
      c.t += H;
      if (c.state === 'seek') {
        if (inSmoke(rd, c.x, c.y) || inSmoke(rd, p.x, p.y) && d < SMOKE_R + 1) { c.state = 'leave'; log(rd, 'crowScared'); continue; }
        c.x += (p.x - c.x) / d * CROW_SEEK * H; c.y += (p.y - c.y) / d * CROW_SEEK * H;
        if (d < 0.6) {
          var it = p.inv > 0 ? null : takeRandom(rd);
          if (it) { c.carry = it; c.state = 'flee'; c.grace = CROW_GRACE; c.ty = c.y < MH / 2 ? -1 : MH + 1; log(rd, 'steal', { kind: it.kind, strain: it.strain || null }); }
          else { c.state = 'leave'; log(rd, 'crowMiss'); }
        }
      } else if (c.state === 'flee') {
        /* a thief gets a head start: the touch radius (0.7) is wider than the steal radius (0.6), so
         * without it every theft was taken back on the very next tick (40 of 40 in the Fen) and no
         * crow ever got away. Now the farmer has to CHASE it; smoke still drops the item at once. */
        c.grace = Math.max(0, (c.grace || 0) - H);
        if (inSmoke(rd, c.x, c.y) || (d < 0.7 && c.grace <= 0)) {
          dropNear(rd, c.carry, c.x, Math.max(1.5, Math.min(MH - 1.5, c.y)), 0, 0);
          log(rd, 'recover', { kind: c.carry.kind, strain: c.carry.strain || null });
          c.carry = null; c.state = 'leave'; continue;
        }
        var dy = c.ty - c.y; c.y += Math.sign(dy) * CROW_FLEE * H; c.x += Math.sin(c.t * 3) * 0.6 * H;
        if (c.y < -0.8 || c.y > MH + 0.8) { log(rd, 'crowLost', { kind: c.carry.kind, strain: c.carry.strain || null }); rd.crows.splice(i, 1); }
      } else if (c.state === 'leave') {
        c.y += (c.y < MH / 2 ? -1 : 1) * 6 * H;
        if (c.y < -2 || c.y > MH + 2) rd.crows.splice(i, 1);
      }
    }
  }

  /* Walk away from a raid in progress: the same stake as the storm. */
  function quit(rd) { if (!rd.over) { rd.over = true; rd.outcome = 'quit'; log(rd, 'quit'); } }

  /* ── the bot: plays through the one door. Used by the campaign probe, the A/B and the store
   * clip. policy: { tools: true|false }. It collects while a lift it can reach is still safe,
   * then walks to that lift and holds LIFT. It sidesteps a boar winding up in either policy, so
   * the only difference between the arms is whether it THROWS what the farm grew. ──────────── */
  function bot(rd, policy) {
    policy = policy || {};
    var p = rd.p;
    if (rd.over) return;
    if (!rd._bf || rd.t >= rd._bfAt) { rd._bf = distField(rd, Math.floor(p.x), Math.floor(p.y)); rd._bfAt = rd.t + 0.25; }
    var here = rd._bf, sp = WALK * (rd.boots >= 2 ? 1.15 : 1) * 0.72;
    /* the best lift: earliest time we could be out through it, with the storm still short of it */
    function liftPlan(fromField, fromDist, startT) {
      var best = null;
      rd.lifts.forEach(function (L, k) {
        var dd = fromField ? rd.liftField[k][fromField] : here[Math.floor(L.y) * MW + Math.floor(L.x)];
        if (dd > 1e8) return;
        var arrive = startT + (fromDist + dd) / sp;
        var ph = (arrive + L.phase) % LIFT_PERIOD, start = arrive;
        if (ph >= LIFT_OPEN - LIFT_HOLD - 0.3) start = arrive + (LIFT_PERIOD - ph);
        var out = start + LIFT_HOLD + 0.2;
        if (out > stormTimeAt(rd, L.x - 1.2)) return;
        if (!best || out < best.out) best = { k: k, out: out };
      });
      return best;
    }
    var direct = liftPlan(null, 0, rd.t);
    var target = null, margin = 3.5;
    if (direct) {
      var bestV = 0;
      rd.items.forEach(function (it) {
        if (swallowed(rd, it.x + 1) || (it.cool && rd.t < it.cool)) return;
        var sw = fits(rd, it) ? -2 : swapFor(rd, it);
        if (sw === -1) return;
        var ti = Math.floor(it.y) * MW + Math.floor(it.x), di = here[ti];
        if (di > 1e8) return;
        var tArr = rd.t + di / sp;
        if (stormTimeAt(rd, it.x - 1.5) < tArr) return;
        var via = liftPlan(ti, di, rd.t);
        if (!via || via.out + margin > stormTimeAt(rd, rd.lifts[via.k].x - 1.2)) return;
        var val = valueOf(rd, it) - (sw >= 0 ? valueOf(rd, rd.pack[sw]) : 0);
        var v = val / (3 + di);
        if (v > bestV) { bestV = v; target = { x: it.x, y: it.y, kind: 'item' }; }
      });
    }
    var goLift = !target;
    if (goLift && direct) target = { x: rd.lifts[direct.k].x, y: rd.lifts[direct.k].y, kind: 'lift', k: direct.k };
    if (!target) { var far = rd.lifts[rd.lifts.length - 1]; target = { x: far.x, y: far.y, kind: 'lift', k: rd.lifts.length - 1 }; }
    /* steer: to the target along the field from the target (a gradient descent in its distance) */
    var tf = target.kind === 'lift' ? rd.liftField[target.k] : null;
    var mx = target.x - p.x, my = target.y - p.y;
    if (Math.hypot(mx, my) > 1.2) {
      if (!tf) { rd._tf = rd._tfKey === target.x + ',' + target.y ? rd._tf : distField(rd, Math.floor(target.x), Math.floor(target.y)); rd._tfKey = target.x + ',' + target.y; tf = rd._tf; }
      var cx = Math.floor(p.x), cy = Math.floor(p.y), bestD = tf[cy * MW + cx], bx = 0, by = 0;
      for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        var nx = cx + dx, ny = cy + dy; if (nx < 0 || ny < 0 || nx >= MW || ny >= MH) continue;
        if (dx && dy && (rd.map[cy * MW + nx] === T_BLOCK || rd.map[ny * MW + cx] === T_BLOCK)) continue;
        var dv = tf[ny * MW + nx]; if (dv < bestD) { bestD = dv; bx = dx; by = dy; }
      }
      mx = cx + bx + 0.5 - p.x; my = cy + by + 0.5 - p.y;
    }
    /* a boar winding up at us: step across its line (both policies) */
    var threat = null;
    rd.boars.forEach(function (b) { if ((b.state === 'aim' || b.state === 'charge') && Math.hypot(b.x - p.x, b.y - p.y) < 7) threat = b; });
    if (threat) {
      var ax = p.x - threat.x, ay = p.y - threat.y, al = Math.hypot(ax, ay) || 1;
      var sx = -ay / al, sy = ax / al;
      if (boxBlocked(rd, p.x + sx, p.y + sy, PR)) { sx = -sx; sy = -sy; }
      mx = sx * 2 + mx * 0.2; my = sy * 2 + my * 0.2;
      if (rd.boots >= 1 && threat.state === 'charge') setKey(rd, 'dash', true);
    }
    if (policy.tools) {
      var near = rd.boars.filter(function (b) { return b.state !== 'lured' && Math.hypot(b.x - p.x, b.y - p.y) < 6; })[0];
      if (near && !rd.lures.length && rd.kit.lure - rd.used.lure > 0) {
        /* throw it AWAY from the boar's line: face away before the press */
        var fx = p.x - near.x, fy = p.y - near.y, fl = Math.hypot(fx, fy) || 1;
        p.face.x = -fy / fl; p.face.y = fx / fl;
        setKey(rd, 'lure', true); setKey(rd, 'lure', false);
      }
      var crow = rd.crows.filter(function (c) { return c.state === 'seek' && Math.hypot(c.x - p.x, c.y - p.y) < 4; })[0];
      if (crow && !rd.smokes.length && rd.kit.smoke - rd.used.smoke > 0 && rd.pack.length) { setKey(rd, 'smoke', true); setKey(rd, 'smoke', false); }
    }
    /* chase a crow that is carrying our item, if it is close */
    rd.crows.forEach(function (c) { if (c.state === 'flee' && Math.hypot(c.x - p.x, c.y - p.y) < 5 && c.y > 0.5 && c.y < MH - 0.5) { mx = c.x - p.x; my = c.y - p.y; } });
    var l = Math.hypot(mx, my) || 1;
    var atLift = target.kind === 'lift' && Math.hypot(target.x - p.x, target.y - p.y) <= LIFT_R * 0.7;
    setKey(rd, 'stick', atLift && !threat ? { x: 0, y: 0 } : { x: mx / l, y: my / l });
    setKey(rd, 'action', target.kind === 'lift' && Math.hypot(target.x - p.x, target.y - p.y) <= LIFT_R);
    if (rd.keys.dash) setKey(rd, 'dash', false);
  }

  var API = { H: H, MW: MW, MH: MH, T_OPEN: T_OPEN, T_BLOCK: T_BLOCK, T_BRAMBLE: T_BRAMBLE, T_BOG: T_BOG,
    LIFT_PERIOD: LIFT_PERIOD, LIFT_OPEN: LIFT_OPEN, LIFT_HOLD: LIFT_HOLD, LIFT_R: LIFT_R, SMOKE_R: SMOKE_R, LURE_PULL: LURE_PULL, VERBS: VERBS,
    create: create, tick: tick, setKey: setKey, quit: quit, bot: bot,
    tileAt: tileAt, liftOpen: liftOpen, liftTiming: liftTiming, stormAt: stormAt, stormTimeAt: stormTimeAt, swallowed: swallowed,
    packWeight: packWeight, fits: fits, weightOf: weightOf, distField: distField, hash2: hash2 };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else root.RAID = API;
})(typeof window !== 'undefined' ? window : this);
