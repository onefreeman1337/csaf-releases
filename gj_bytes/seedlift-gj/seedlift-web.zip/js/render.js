/**
 * render.js — SEEDLIFT's drawing layer: the paper UI, the farm field, the raid map and its storm.
 *
 * Nothing here decides anything: the renderer reads the farm (SIM) and the raid (RAID) and never
 * writes either. EVERY STRING GOES THROUGH R.text() and every button through R.button(), so the
 * layout gate can record what was drawn from the one door that draws it; pictures that can cover a
 * string are recorded as kind 'picture'.
 *
 * The raid map (ground, terrain and every blocked object) is BAKED once per raid into one offscreen
 * canvas; each frame draws that bake, then the living things over it, then the storm.
 */
(function (root) {
  'use strict';
  var Z = root.ZONES, SIM = root.SIM, RAID = root.RAID;

  var C = {
    /* mute was #8a8398, 3.3:1 on paper, and the store review found the grey secondary lines hard to
     * read; #6a6278 is ~5:1 on paper and still reads as secondary beside ink */
    ink: '#1b1622', ink2: '#2a2233', paper: '#f6efd9', paperShade: '#e3d7b8', cream: '#fffaf0',
    gold: '#f7c35a', goldDeep: '#c4652e', amber: '#eb9a3d', leaf: '#3f7a45', leafLight: '#86b951',
    storm: '#5e4a8a', stormDeep: '#3e2c5a', stormLight: '#bba6e6', red: '#d0483f', mute: '#6a6278', soil: '#54392a',
    sky: '#9cc6ef',
  };
  var FONT_D = "'SL Display', 'Trebuchet MS', sans-serif";
  var FONT_B = "'SL Body', 'Trebuchet MS', sans-serif";
  var TILE = 32;

  var R = { C: C, FONT_D: FONT_D, FONT_B: FONT_B, TILE: TILE, ctx: null, W: 960, H: 540, rec: null, img: {}, hits: [], focusId: null };

  R.init = function (ctx, W, H) { R.ctx = ctx; R.W = W; R.H = H; };
  R.layer = function (name) { if (R.rec) R.rec.push({ kind: 'layer', name: name }); };

  /* ── text and paper ────────────────────────────────────────────────────────────────── */
  function fontPx(font) { var m = /(\d+(?:\.\d+)?)px/.exec(font); return m ? parseFloat(m[1]) : 16; }
  /* The display face joins "fl" and "fi" into one glyph that reads as an A ("CornAower"). A zero-width
   * non-joiner after each f keeps the letters apart; it has no width, and the recorder keeps the
   * string as written. Measure and draw both go through this, so widths always match what is drawn. */
  function shape(str, font) { return font && font.indexOf('SL Display') >= 0 ? str.replace(/f/g, 'f‌') : str; }
  R.shape = shape;
  R.font = function (px, display, weight) { return display ? ('600 ' + px + 'px ' + FONT_D) : ((weight || 800) + ' ' + px + 'px ' + FONT_B); };
  R.measure = function (str, font) { var c = R.ctx; c.font = font; return c.measureText(shape(String(str), font)).width; };
  R.fit = function (str, px, maxW, display, weight, minPx) {
    var p = px, f = R.font(p, display, weight);
    while (p > (minPx || 9) && R.measure(str, f) > maxW) { p -= 1; f = R.font(p, display, weight); }
    return f;
  };
  R.text = function (str, x, y, o) {
    o = o || {};
    var c = R.ctx; str = String(str);
    c.font = o.font || R.font(16);
    c.textAlign = o.align || 'left';
    c.textBaseline = o.base || 'alphabetic';
    var ds = shape(str, c.font);
    var w = c.measureText(ds).width, px = fontPx(c.font);
    if (o.shadow) { c.fillStyle = o.shadow; c.fillText(ds, x + (o.sh || 2), y + (o.sh || 2)); }
    if (o.stroke) { c.lineJoin = 'round'; c.lineWidth = o.strokeW || 4; c.strokeStyle = o.stroke; c.strokeText(ds, x, y); }
    c.fillStyle = o.color || C.ink;
    c.fillText(ds, x, y);
    if (R.rec) {
      var l = o.align === 'center' ? x - w / 2 : (o.align === 'right' ? x - w : x);
      var top = o.base === 'middle' ? y - px * 0.5 : (o.base === 'top' ? y : y - px * 0.8);
      R.rec.push({ kind: 'text', t: str, x: l, y: top, w: w, h: px, owner: o.owner || null, sw: o.stroke ? (o.strokeW || 4) / 2 : 0 });
    }
    return w;
  };
  R.wrap = function (str, font, maxW) {
    var words = String(str).split(/ +/), lines = [], cur = '';
    for (var i = 0; i < words.length; i++) {
      var t = cur ? cur + ' ' + words[i] : words[i];
      if (R.measure(t, font) > maxW && cur) { lines.push(cur); cur = words[i]; } else cur = t;
    }
    if (cur) lines.push(cur);
    return lines;
  };
  R.paragraph = function (str, x, y, maxW, font, lh, color, align, owner) {
    var lines = R.wrap(str, font, maxW);
    for (var i = 0; i < lines.length; i++) R.text(lines[i], align === 'center' ? x + maxW / 2 : x, y + i * lh, { font: font, color: color || C.ink, align: align, owner: owner });
    return lines.length * lh;
  };
  function rr(x, y, w, h, r) {
    var c = R.ctx; r = Math.max(0, Math.min(r, w / 2, h / 2));
    c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
  }
  R.rr = rr;
  /* Seed-packet paper: a soft drop, a stitched inner line. The one panel this game draws. */
  R.paper = function (x, y, w, h, o) {
    o = o || {};
    var c = R.ctx;
    c.save();
    c.fillStyle = 'rgba(27,22,34,0.30)'; rr(x + 2, y + 4, w, h, o.r || 10); c.fill();
    c.fillStyle = o.fill || C.paper; rr(x, y, w, h, o.r || 10); c.fill();
    c.strokeStyle = o.edge || 'rgba(84,57,42,0.35)'; c.lineWidth = 1.5; c.setLineDash([5, 4]);
    rr(x + 4.5, y + 4.5, w - 9, h - 9, Math.max(2, (o.r || 10) - 4)); c.stroke(); c.setLineDash([]);
    c.restore();
    if (R.rec && !o.noRec) R.rec.push({ kind: 'box', x: x, y: y, w: w, h: h, owner: o.owner || null });
  };
  R.button = function (id, label, x, y, w, h, o) {
    o = o || {};
    var c = R.ctx, fill = o.off ? C.paperShade : (o.gold ? C.gold : (o.fill || C.paper));
    R.paper(x, y, w, h, { r: 12, fill: fill, noRec: true });
    if (R.focusId === id) { c.save(); c.strokeStyle = C.goldDeep; c.lineWidth = 3; rr(x - 4, y - 4, w + 8, h + 8, 15); c.stroke(); c.restore(); }
    var iconW = o.icon ? Math.min(h - 14, 30) + 8 : 0;
    var f = R.fit(label, o.px || Math.min(22, Math.round(h * 0.42)), w - 20 - iconW, !!o.display, 800, 10);
    var tw = R.measure(label, f), tx = x + w / 2 + iconW / 2;
    if (o.icon) { var s = Math.min(h - 14, 30); R.icon(o.icon, tx - tw / 2 - iconW + s / 2 + 2, y + h / 2, s); }
    R.text(label, tx, y + h / 2 + 1, { font: f, align: 'center', base: 'middle', color: o.off ? C.mute : C.ink, owner: id });
    if (R.rec) R.rec.push({ kind: 'button', id: id, label: label, x: x, y: y, w: w, h: h });
    if (!o.off || o.clickableOff) R.hits.push({ id: id, x: x, y: y, w: w, h: h });
  };
  R.hit = function (id, x, y, w, h) { R.hits.push({ id: id, x: x, y: y, w: w, h: h }); };

  /* ── pictures ──────────────────────────────────────────────────────────────────────── */
  R.has = function (k) { var im = R.img[k]; return !!(im && im.width); };
  /* Draw a sprite bottom-centred at (x, y), at integer scale when asked, never smoothed. */
  R.sprite = function (k, x, y, scale, o) {
    var im = R.img[k]; if (!im || !im.width) return null;
    o = o || {};
    var c = R.ctx, s = scale || 1, w = im.width * s, h = im.height * s;
    c.save();
    c.imageSmoothingEnabled = false;
    if (o.alpha !== undefined) c.globalAlpha *= o.alpha;
    if (o.flip) { c.translate(Math.round(x), 0); c.scale(-1, 1); c.drawImage(im, Math.round(-w / 2), Math.round(y - h), w, h); }
    else c.drawImage(im, Math.round(x - w / 2), Math.round(y - h), w, h);
    c.restore();
    if (R.rec && o.rec) R.rec.push({ kind: 'picture', what: k, x: x - w / 2, y: y - h, w: w, h: h });
    return { w: w, h: h };
  };
  /* Small UI icons: plants by id, the tools, coin, and a few drawn marks. */
  R.icon = function (kind, cx, cy, size) {
    var c = R.ctx;
    var key = kind.indexOf('plant_') === 0 || kind.indexOf('prop_') === 0 || kind.indexOf('chr_') === 0 ? kind : null;
    if (key && R.has(key)) {
      var im = R.img[key], s = size / Math.max(im.width, im.height);
      c.save(); c.imageSmoothingEnabled = false;
      c.drawImage(im, Math.round(cx - im.width * s / 2), Math.round(cy - im.height * s / 2), Math.round(im.width * s), Math.round(im.height * s));
      c.restore(); return;
    }
    c.save();
    if (kind === 'coin') {
      c.fillStyle = C.goldDeep; c.beginPath(); c.arc(cx + 1, cy + 1.5, size * 0.38, 0, 7); c.fill();
      c.fillStyle = C.gold; c.beginPath(); c.arc(cx, cy, size * 0.38, 0, 7); c.fill();
      c.fillStyle = '#fff08a'; c.fillRect(cx - size * 0.12, cy - size * 0.22, size * 0.1, size * 0.3);
    } else if (kind === 'codex') {
      c.fillStyle = C.leaf; rr(cx - size * 0.32, cy - size * 0.4, size * 0.64, size * 0.8, 3); c.fill();
      c.fillStyle = C.paper; c.fillRect(cx - size * 0.2, cy - size * 0.28, size * 0.4, size * 0.08); c.fillRect(cx - size * 0.2, cy - size * 0.1, size * 0.3, size * 0.08);
    } else if (kind === 'storm') {
      c.fillStyle = C.storm; c.beginPath(); c.arc(cx - size * 0.15, cy, size * 0.25, 0, 7); c.arc(cx + size * 0.15, cy - size * 0.05, size * 0.3, 0, 7); c.fill();
      c.fillStyle = C.gold; c.beginPath(); c.moveTo(cx, cy + size * 0.05); c.lineTo(cx - size * 0.1, cy + size * 0.42); c.lineTo(cx + size * 0.12, cy + size * 0.2); c.closePath(); c.fill();
    } else if (kind === 'weight') {
      c.fillStyle = C.ink2; c.beginPath(); c.moveTo(cx - size * 0.35, cy + size * 0.35); c.lineTo(cx + size * 0.35, cy + size * 0.35); c.lineTo(cx + size * 0.22, cy - size * 0.15); c.lineTo(cx - size * 0.22, cy - size * 0.15); c.closePath(); c.fill();
      c.strokeStyle = C.ink2; c.lineWidth = 2; c.beginPath(); c.arc(cx, cy - size * 0.2, size * 0.12, 0, 7); c.stroke();
    } else if (kind === 'lock') {
      c.strokeStyle = C.mute; c.lineWidth = 3; c.beginPath(); c.arc(cx, cy - size * 0.1, size * 0.18, Math.PI, 0); c.stroke();
      c.fillStyle = C.mute; rr(cx - size * 0.26, cy - size * 0.1, size * 0.52, size * 0.42, 3); c.fill();
    } else if (kind === 'dash') {
      c.fillStyle = C.ink2; for (var i = 0; i < 3; i++) { c.fillRect(cx - size * 0.35 + i * size * 0.08, cy - size * 0.2 + i * size * 0.14, size * 0.5, size * 0.07); }
    } else if (kind === 'lift') {
      c.fillStyle = C.gold; c.beginPath(); c.arc(cx, cy - size * 0.12, size * 0.3, 0, 7); c.fill();
      c.strokeStyle = C.ink2; c.lineWidth = 1.5; c.beginPath(); c.moveTo(cx - size * 0.2, cy + 0.05 * size); c.lineTo(cx - size * 0.12, cy + size * 0.28); c.moveTo(cx + size * 0.2, cy + 0.05 * size); c.lineTo(cx + size * 0.12, cy + size * 0.28); c.stroke();
      c.fillStyle = '#8c6441'; c.fillRect(cx - size * 0.14, cy + size * 0.26, size * 0.28, size * 0.16);
    }
    c.restore();
  };

  /* A seed-rarity pip row. */
  R.rarity = function (x, y, n, color) {
    var c = R.ctx;
    for (var i = 0; i < 3; i++) { c.fillStyle = i < n ? (color || C.goldDeep) : 'rgba(27,22,34,0.18)'; c.beginPath(); c.arc(x + i * 9, y, 3, 0, 7); c.fill(); }
  };

  /* ── the farm ──────────────────────────────────────────────────────────────────────── */
  function pattern(key) {
    var im = R.img[key]; if (!im || !im.width) return null;
    R._pat = R._pat || {};
    if (!R._pat[key]) R._pat[key] = R.ctx.createPattern(im, 'repeat');
    return R._pat[key];
  }
  R.pattern = pattern;
  R.fillPattern = function (key, x, y, w, h, fallback) {
    var c = R.ctx, p = pattern(key);
    c.save(); c.imageSmoothingEnabled = false;
    c.fillStyle = p || fallback || '#6f8f4f';
    c.fillRect(x, y, w, h); c.restore();
  };
  /* plant stage for a progress in 0..1: 0 sprout, 1 young, 2 grown */
  R.stageOf = function (p) { return p >= 1 ? 2 : (p >= 0.45 ? 1 : 0); };
  /* Draw a plant in a plot whose top-left is (x, y), size s. */
  R.plant = function (id, prog, x, y, s, t, ripeFor) {
    var c = R.ctx, key = 'plant_' + id, im = R.img[key], st = R.stageOf(prog);
    var cx = x + s / 2, base = y + s - 7;
    var strain = Z.strain(id);
    if (st === 0) {
      /* the sprout: two leaves in the strain's own leaf colour, sampled from its grown sprite */
      var lc = R.leafOf(id), h = 5 + prog * 16;
      c.save(); c.fillStyle = C.leaf; c.fillRect(Math.round(cx) - 1, Math.round(base - h), 2, Math.round(h));
      c.fillStyle = lc; c.beginPath(); c.ellipse(cx - 5, base - h + 2, 5, 2.6, -0.5, 0, 7); c.ellipse(cx + 5, base - h + 2, 5, 2.6, 0.5, 0, 7); c.fill();
      c.restore();
      return;
    }
    if (!im || !im.width) return;
    var maxH = s - 6, sc = Math.min(1, maxH / im.height, (s - 4) / im.width);
    var grow = st === 1 ? 0.55 + 0.45 * ((prog - 0.45) / 0.55) : 1;
    var sway = st === 2 ? Math.sin(t * 2 + x * 0.13) * 0.035 : 0;
    var bob = st === 2 && ripeFor !== undefined ? Math.abs(Math.sin(t * 3 + y * 0.1)) * 1.5 : 0;
    var w = Math.round(im.width * sc * grow), hh = Math.round(im.height * sc * grow);
    c.save();
    c.imageSmoothingEnabled = false;
    c.translate(cx, base - bob);
    c.transform(1, 0, sway, 1, 0, 0);
    if (st === 1) c.globalAlpha = 0.95;
    c.drawImage(im, -Math.round(w / 2), -hh, w, hh);
    c.restore();
    if (strain && strain.ending && st === 2) { c.save(); c.globalAlpha = 0.35 + 0.25 * Math.sin(t * 2.4); c.fillStyle = C.gold; c.beginPath(); c.arc(cx, base - hh * 0.75, hh * 0.35, 0, 7); c.fill(); c.restore(); }
  };
  /* The dominant leaf green of a sprite (cached): the sprout wears the grown plant's colour. */
  R.leafOf = function (id) {
    R._leaf = R._leaf || {};
    if (R._leaf[id]) return R._leaf[id];
    var im = R.img['plant_' + id], col = C.leafLight;
    try {
      if (im && im.width) {
        var cv = document.createElement('canvas'); cv.width = im.width; cv.height = im.height;
        var x = cv.getContext('2d'); x.drawImage(im, 0, 0);
        var d = x.getImageData(0, 0, im.width, im.height).data, best = 0, cnt = {};
        for (var i = 0; i < d.length; i += 4) if (d[i + 3] > 0 && d[i + 1] > d[i] && d[i + 1] > d[i + 2]) { var k = d[i] + ',' + d[i + 1] + ',' + d[i + 2]; cnt[k] = (cnt[k] || 0) + 1; if (cnt[k] > best) { best = cnt[k]; col = 'rgb(' + k + ')'; } }
      }
    } catch (e) { /* a tainted canvas keeps the default */ }
    R._leaf[id] = col;
    return col;
  };

  /* ── the raid map, baked ───────────────────────────────────────────────────────────── */
  var OBJ = { hedgerow: ['hedge', 'hedge', 'tree'], fen: ['reeds', 'reeds', 'hedge'], orchard: ['tree', 'tree', 'hedge'], ridge: ['rock', 'ruin', 'rock'] };
  /* Round the corners of a terrain patch where it meets different ground, so bog and bramble read as
   * patches rather than squares. One path per terrain, filled with that terrain's plate. */
  function patchPath(c, rd, type) {
    var MW = RAID.MW, MH = RAID.MH, T = TILE, rad = 11;
    var is = function (x, y) { return x >= 0 && y >= 0 && x < MW && y < MH && rd.map[y * MW + x] === type; };
    c.beginPath();
    for (var y = 0; y < MH; y++) for (var x = 0; x < MW; x++) {
      if (!is(x, y)) continue;
      var X = x * T, Y = y * T;
      var tl = !is(x - 1, y) && !is(x, y - 1) ? rad : 0, tr = !is(x + 1, y) && !is(x, y - 1) ? rad : 0;
      var br = !is(x + 1, y) && !is(x, y + 1) ? rad : 0, bl = !is(x - 1, y) && !is(x, y + 1) ? rad : 0;
      c.moveTo(X + tl, Y); c.lineTo(X + T - tr, Y); if (tr) c.arcTo(X + T, Y, X + T, Y + tr, tr); else c.lineTo(X + T + 0.5, Y);
      c.lineTo(X + T + 0.5, Y + T - br); if (br) c.arcTo(X + T, Y + T, X + T - br, Y + T, br); else c.lineTo(X + T + 0.5, Y + T + 0.5);
      c.lineTo(X + bl, Y + T + 0.5); if (bl) c.arcTo(X, Y + T, X, Y + T - bl, bl); else c.lineTo(X, Y + T + 0.5);
      c.lineTo(X, Y + tl); if (tl) c.arcTo(X, Y, X + tl, Y, tl); else c.lineTo(X, Y);
      c.closePath();
    }
  }
  R.bakeRaid = function (rd) {
    var MW = RAID.MW, MH = RAID.MH, T = TILE, z = rd.zone.id;
    var cv = document.createElement('canvas'); cv.width = MW * T; cv.height = MH * T;
    var c = cv.getContext('2d'); c.imageSmoothingEnabled = false;
    var pat = function (k, fb) { var im = R.img[k]; return im && im.width ? c.createPattern(im, 'repeat') : fb; };
    c.fillStyle = pat('gnd_' + z + '_ground', '#7d9a55'); c.fillRect(0, 0, cv.width, cv.height);
    /* bog: a darker rim a little below, then the water plate (reads as a sunken pool) */
    patchPath(c, rd, RAID.T_BOG);
    c.save(); c.translate(0, 3); c.fillStyle = 'rgba(27,22,34,0.35)'; c.fill(); c.restore();
    c.fillStyle = pat('gnd_' + z + '_bog', '#3f5a52'); c.fill();
    patchPath(c, rd, RAID.T_BRAMBLE);
    c.fillStyle = pat('gnd_' + z + '_bramble', '#4d5a34'); c.fill();
    /* broad light: soft sunlit and shaded patches several tiles across, so the field has a shape at
     * the scale a player reads, not only a grain (a plate is 4 tiles; the map is 56) */
    var dec = DECOR[z] || DECOR.hedgerow;
    /* ⛔ v1 hashed one value per 5-tile CELL and showed its square edges; this is smooth value
     * noise sampled every 8 px, so light rises and falls with no edge to see */
    var smooth = function (x, y, cell, s) {
      var gx = x / cell, gy = y / cell, x0 = Math.floor(gx), y0 = Math.floor(gy), fx = gx - x0, fy = gy - y0;
      fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
      var a0 = RAID.hash2(x0, y0, s), b0 = RAID.hash2(x0 + 1, y0, s), c0 = RAID.hash2(x0, y0 + 1, s), d0 = RAID.hash2(x0 + 1, y0 + 1, s);
      return (a0 + (b0 - a0) * fx) * (1 - fy) + (c0 + (d0 - c0) * fx) * fy;
    };
    for (var ly = 0; ly < MH * T; ly += 8) for (var lx = 0; lx < MW * T; lx += 8) {
      var n = smooth(lx, ly, 6 * T, rd.mapSeed + 71) * 0.65 + smooth(lx, ly, 2.5 * T, rd.mapSeed + 73) * 0.35;
      var a = (n - 0.5) * 0.2;
      c.fillStyle = a > 0 ? 'rgba(247,195,90,' + a.toFixed(3) + ')' : 'rgba(27,22,34,' + (-a).toFixed(3) + ')';
      c.fillRect(lx, ly, 8, 8);
    }
    /* the small life of the open ground: flower clusters, tall-grass tufts, pebbles */
    for (var dy = 1; dy < MH - 1; dy++) for (var dx = 1; dx < MW - 1; dx++) {
      if (rd.map[dy * MW + dx] !== RAID.T_OPEN) continue;
      var hh = RAID.hash2(dx, dy, rd.mapSeed + 91);
      if (hh < 0.16) decorate(c, dx * T + 4 + Math.floor(RAID.hash2(dx, dy, 3) * 20), dy * T + 6 + Math.floor(RAID.hash2(dx, dy, 4) * 18), hh / 0.16, dec);
    }
    /* orchard walls: a raised stone course with a lit top face */
    for (var y = 0; y < MH; y++) for (var x = 0; x < MW; x++) {
      var t = rd.map[y * MW + x];
      if (t !== RAID.T_BLOCK) continue;
      var edge = x === 0 || y === 0 || x === MW - 1 || y === MH - 1;
      var wall = z === 'orchard' && !edge && ((rd.map[y * MW + x - 1] === RAID.T_BLOCK && rd.map[y * MW + x + 1] === RAID.T_BLOCK) && !(x % 4 === 2 && y % 4 === 2));
      if (edge || wall) {
        c.fillStyle = pat('gnd_wall', '#8a8398'); c.fillRect(x * T, y * T - (wall ? 8 : 0), T, T + (wall ? 8 : 0));
        c.fillStyle = 'rgba(27,22,34,0.35)'; c.fillRect(x * T, y * T + T - 4, T, 4);
        c.fillStyle = 'rgba(255,250,240,0.18)'; c.fillRect(x * T, y * T - (wall ? 8 : 0), T, 3);
      }
    }
    /* bramble tufts on bramble ground, and the blocked objects, north to south so overlaps are right */
    var list = OBJ[z] || OBJ.hedgerow;
    for (var yy = 0; yy < MH; yy++) for (var xx = 0; xx < MW; xx++) {
      var tt = rd.map[yy * MW + xx], h = RAID.hash2(xx, yy, rd.mapSeed + 5);
      if (tt === RAID.T_BRAMBLE) drawObj(c, 'obj_bramble', xx, yy, 0.72 + h * 0.3, h);
      if (tt !== RAID.T_BLOCK) continue;
      if (xx === 0 || yy === 0 || xx === MW - 1 || yy === MH - 1) continue;
      var isWall = z === 'orchard' && rd.map[yy * MW + xx - 1] === RAID.T_BLOCK && rd.map[yy * MW + xx + 1] === RAID.T_BLOCK && !(xx % 4 === 2 && yy % 4 === 2);
      if (isWall) continue;
      drawObj(c, 'obj_' + list[Math.floor(h * list.length)], xx, yy, 0.9 + h * 0.2, h);
    }
    rd._bake = cv;
    return cv;
  };
  /* Per-zone decoration colours: the flowers and stones that make open ground a PLACE. */
  var DECOR = {
    hedgerow: { flowers: ['#fffaf0', '#f4d94b', '#f7b7cf', '#e27aa4'], stem: '#3f7a45', tuft: ['#5c9a48', '#86b951'], stone: ['#bdb6c6', '#8a8398'] },
    fen: { flowers: ['#f4d94b', '#fffaf0', '#9cc6ef'], stem: '#2c5a3f', tuft: ['#6d8a73', '#9db59a'], stone: ['#8a8398', '#5e586a'] },
    orchard: { flowers: ['#d0483f', '#eb9a3d', '#fffaf0', '#f7b7cf'], stem: '#3f7a45', tuft: ['#5c9a48', '#86b951'], stone: ['#c9a45c', '#8c6441'] },
    ridge: { flowers: ['#8a74c0', '#9cc6ef', '#fffaf0', '#bba6e6'], stem: '#2c5a3f', tuft: ['#6d8a73', '#9db59a'], stone: ['#e9e6ee', '#bdb6c6'] },
  };
  function decorate(c, x, y, r, d) {
    if (r < 0.45) {        /* a flower cluster: three to five blooms on 2 px stems */
      var n = 3 + Math.floor(r * 5), col = d.flowers[Math.floor(r * 97) % d.flowers.length];
      for (var i = 0; i < n; i++) {
        var fx = x + Math.round(Math.cos(i * 2.4 + r * 9) * 4), fy = y + Math.round(Math.sin(i * 2.4 + r * 9) * 3);
        c.fillStyle = d.stem; c.fillRect(fx, fy + 1, 1, 2);
        c.fillStyle = col; c.fillRect(fx - 1, fy, 3, 1); c.fillRect(fx, fy - 1, 1, 3);
        c.fillStyle = '#fff08a'; c.fillRect(fx, fy, 1, 1);
      }
    } else if (r < 0.8) {  /* a tall-grass tuft */
      for (var j = -3; j <= 3; j++) { var hgt = 5 + ((j * 7 + Math.floor(r * 50)) % 4); c.fillStyle = j % 2 ? d.tuft[0] : d.tuft[1]; c.fillRect(x + j, y + 6 - hgt + Math.abs(j), 1, hgt - Math.abs(j)); }
    } else {               /* two pebbles */
      c.fillStyle = 'rgba(27,22,34,0.3)'; c.fillRect(x, y + 3, 5, 1); c.fillRect(x + 6, y + 5, 3, 1);
      c.fillStyle = d.stone[1]; c.fillRect(x, y, 5, 3); c.fillRect(x + 6, y + 3, 3, 2);
      c.fillStyle = d.stone[0]; c.fillRect(x + 1, y, 3, 1); c.fillRect(x + 6, y + 3, 2, 1);
    }
  }
  function drawObj(c, k, x, y, s, h) {
    var im = R.img[k]; if (!im || !im.width) { c.fillStyle = '#2c5a3f'; c.beginPath(); c.arc(x * TILE + 16, y * TILE + 16, 15 * s, 0, 7); c.fill(); return; }
    var w = Math.round(im.width * s), hh = Math.round(im.height * s);
    c.save(); c.imageSmoothingEnabled = false;
    c.fillStyle = 'rgba(27,22,34,0.28)'; c.beginPath(); c.ellipse(x * TILE + 17, y * TILE + 22, w * 0.45, hh * 0.28, 0, 0, 7); c.fill();
    if (h > 0.5) { c.translate(x * TILE + 16, 0); c.scale(-1, 1); c.drawImage(im, -Math.round(w / 2), y * TILE + 16 - Math.round(hh / 2) - 2, w, hh); }
    else c.drawImage(im, x * TILE + 16 - Math.round(w / 2), y * TILE + 16 - Math.round(hh / 2) - 2, w, hh);
    c.restore();
  }

  /* The camera: follow the player, clamp to the map. */
  R.camera = function (rd) {
    /* R.camLock holds the view still (set only by the store-clip capture: a still camera lets the
     * clip spend its bytes on what moves; gameplay never sets it) */
    if (R.camLock) return R.camLock;
    var T = TILE, mw = RAID.MW * T, mh = RAID.MH * T;
    var cx = rd.p.x * T - R.W / 2, cy = rd.p.y * T - R.H / 2;
    /* The view may run PAST the map edge by the depth of the HUD on that side (R.camPad, set by the
     * shell from its own layout): clamped at the edge, a player in the east corner stood under the
     * LIFT and LURE buttons, and the storm drives every raid east. */
    var pad = R.camPad || { l: 0, r: 0, t: 0, b: 0 };
    cx = Math.max(-pad.l, Math.min(mw - R.W + pad.r, cx)); cy = Math.max(-pad.t, Math.min(mh - R.H + pad.b, cy));
    if (mw < R.W) cx = (mw - R.W) / 2; if (mh < R.H) cy = (mh - R.H) / 2;
    return { x: Math.round(cx), y: Math.round(cy) };
  };

  R.drawRaid = function (rd, t, fx) {
    var c = R.ctx, T = TILE, cam = R.camera(rd);
    /* words in the WORLD (lift countdowns, NEW, a boar's !) are queued in map units and drawn after
     * the camera is undone, in screen units, and only when they fit wholly on screen: drawn inside
     * the translated context they were recorded at map coordinates, off any canvas the gate knows */
    var labels = [];
    var wlabel = function (s, x, y, o) { labels.push([s, x, y, o]); };
    if (!rd._bake) R.bakeRaid(rd);
    /* beyond the map edge: the zone's own ground, dimmed hard — never the storm's colour, which
     * would say "storm" on the side the storm is not */
    R.fillPattern('gnd_' + rd.zone.id + '_ground', 0, 0, R.W, R.H, '#4d6b3a');
    c.fillStyle = 'rgba(27,22,34,0.62)'; c.fillRect(0, 0, R.W, R.H);
    c.save(); c.imageSmoothingEnabled = false;
    /* the source rectangle clipped to the bake by hand: an out-of-bounds source rect is legal in the
     * current spec, but older engines drew nothing at all */
    var bw = rd._bake.width, bh = rd._bake.height;
    var sx0 = Math.max(0, cam.x), sy0 = Math.max(0, cam.y), sx1 = Math.min(bw, cam.x + R.W), sy1 = Math.min(bh, cam.y + R.H);
    if (sx1 > sx0 && sy1 > sy0) c.drawImage(rd._bake, sx0, sy0, sx1 - sx0, sy1 - sy0, sx0 - cam.x, sy0 - cam.y, sx1 - sx0, sy1 - sy0);
    c.translate(-cam.x, -cam.y);
    /* bog sheen: a slow moving highlight line on bog tiles in view */
    var x0 = Math.floor(cam.x / T), y0 = Math.floor(cam.y / T), x1 = Math.ceil((cam.x + R.W) / T), y1 = Math.ceil((cam.y + R.H) / T);
    c.fillStyle = 'rgba(156,198,239,0.20)';
    for (var yy = y0; yy < y1; yy++) for (var xx = x0; xx < x1; xx++) {
      if (RAID.tileAt(rd, xx + 0.5, yy + 0.5) !== RAID.T_BOG) continue;
      var ph = (t * 0.6 + RAID.hash2(xx, yy, 9) * 6) % 6;
      if (ph < 1) c.fillRect(xx * T + 6 + ph * 14, yy * T + 12 + ((xx + yy) % 3) * 5, 8, 2);
    }
    /* lures and smoke */
    rd.lures.forEach(function (l) {
      c.strokeStyle = 'rgba(247,195,90,' + (0.25 + 0.2 * Math.sin(t * 6)) + ')'; c.lineWidth = 2;
      c.beginPath(); c.arc(l.x * T, l.y * T, (RAID.LURE_PULL * 0.25 + (t * 2 % 1) * 1.2) * T, 0, 7); c.stroke();
      R.sprite('prop_lure', l.x * T, l.y * T + 8, 1);
    });
    /* lifts: a stone ring on the ground; the balloon above it, low and glowing when open */
    rd.lifts.forEach(function (L, k) {
      if (RAID.swallowed(rd, L.x)) return;
      var lt = RAID.liftTiming(rd, L), X = L.x * T, Y = L.y * T;
      c.save();
      c.fillStyle = 'rgba(27,22,34,0.25)'; c.beginPath(); c.ellipse(X, Y + 4, RAID.LIFT_R * T, RAID.LIFT_R * T * 0.55, 0, 0, 7); c.fill();
      /* a dark underlay under the dashes: a light-grey closed ring alone was lost on the Ridge's
       * pale ground (independent review) */
      c.strokeStyle = 'rgba(27,22,34,0.5)'; c.lineWidth = 7;
      c.beginPath(); c.ellipse(X, Y, RAID.LIFT_R * T, RAID.LIFT_R * T * 0.55, 0, 0, 7); c.stroke();
      c.strokeStyle = lt.open ? C.gold : '#bdb6c6'; c.lineWidth = 4; c.setLineDash([7, 5]);
      c.beginPath(); c.ellipse(X, Y, RAID.LIFT_R * T, RAID.LIFT_R * T * 0.55, 0, 0, 7); c.stroke(); c.setLineDash([]);
      if (lt.open) {
        /* the time left, as an arc that empties */
        c.strokeStyle = C.gold; c.lineWidth = 3;
        c.beginPath(); c.arc(X, Y - 60, 30, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (lt.left / RAID.LIFT_OPEN)); c.stroke();
        c.fillStyle = 'rgba(247,195,90,0.18)'; c.beginPath(); c.ellipse(X, Y, RAID.LIFT_R * T, RAID.LIFT_R * T * 0.55, 0, 0, 7); c.fill();
      }
      c.restore();
      var hover = lt.open ? Math.sin(t * 2 + k) * 3 : -40 + Math.sin(t + k) * 4;
      /* an open lift's balloon is down and drawn at 2x (at 1x it read as a fruit on the map); a
       * closed one is away up high, small and faint */
      R.sprite('prop_balloon', X, Y - 6 + (lt.open ? hover : -46 + hover), lt.open ? 2 : 1, { alpha: lt.open ? 1 : 0.5 });
      if (!lt.open) {
        var s = Math.ceil(lt.next) + '';
        wlabel(s, X, Y - 70, { font: R.font(18, true), align: 'center', color: C.paper, stroke: C.ink, strokeW: 4 });
      }
    });
    /* items on the ground */
    rd.items.forEach(function (it) {
      if (RAID.swallowed(rd, it.x)) return;
      var X = it.x * T, Y = it.y * T, bob = Math.sin(t * 3 + it.x * 1.7) * 2;
      if (it.kind === 'coin') { c.fillStyle = 'rgba(27,22,34,0.25)'; c.beginPath(); c.ellipse(X, Y + 6, 10, 4, 0, 0, 7); c.fill(); R.sprite('prop_coin', X, Y + 6 + bob, 1); return; }
      var s = Z.strain(it.strain), fresh = rd.missing.indexOf(it.strain) >= 0;
      var glow = s.ending ? C.gold : (fresh ? '#fff08a' : (s.rarity >= 3 ? '#bba6e6' : (s.rarity === 2 ? '#9cc6ef' : '#fffaf0')));
      /* a dark ground shadow and an ink rim under the glow: a pale glow alone vanished on the Ridge's
       * grey speckle (independent review), and the rim reads on every zone's ground */
      c.save(); c.fillStyle = 'rgba(27,22,34,0.34)'; c.beginPath(); c.ellipse(X, Y + 6, 16, 7, 0, 0, 7); c.fill();
      c.globalAlpha = 0.55 + 0.2 * Math.sin(t * 4 + it.y); c.fillStyle = glow;
      c.beginPath(); c.ellipse(X, Y + 5, 14, 6, 0, 0, 7); c.fill();
      c.globalAlpha = 0.7; c.strokeStyle = C.ink; c.lineWidth = 1.5; c.stroke(); c.restore();
      var im = R.img['plant_' + it.strain];
      if (im && im.width) { var sc = (s.ending ? 30 : 24) / Math.max(im.width, im.height); c.save(); c.imageSmoothingEnabled = false; c.drawImage(im, Math.round(X - im.width * sc / 2), Math.round(Y + 6 + bob - im.height * sc), Math.round(im.width * sc), Math.round(im.height * sc)); c.restore(); }
      if (fresh || s.ending) wlabel(s.ending ? '!' : 'NEW', X, Y - 20 + bob, { font: R.font(11, true), align: 'center', color: C.ink, stroke: '#fff08a', strokeW: 3 });
    });
    /* smoke clouds */
    rd.smokes.forEach(function (sm) {
      var a = Math.min(1, sm.t / 1.2);
      for (var i = 0; i < 9; i++) {
        var ang = i * 0.7 + t * 0.3, rr2 = RAID.SMOKE_R * T * (0.35 + 0.55 * ((i * 37) % 10) / 10);
        c.fillStyle = 'rgba(189,182,198,' + (0.28 * a) + ')';
        c.beginPath(); c.arc(sm.x * T + Math.cos(ang) * rr2 * 0.6, sm.y * T + Math.sin(ang) * rr2 * 0.45, rr2 * 0.55, 0, 7); c.fill();
      }
    });
    /* boars */
    rd.boars.forEach(function (b) {
      var X = b.x * T, Y = b.y * T;
      var face = b.state === 'charge' || b.state === 'aim' ? (b.state === 'aim' ? rd.p.x - b.x : b.dx) : (b.wx - b.x);
      if (b.state === 'lured' && rd.lures[0]) face = rd.lures[0].x - b.x;
      c.fillStyle = 'rgba(27,22,34,0.3)'; c.beginPath(); c.ellipse(X, Y + 12, 17, 5, 0, 0, 7); c.fill();
      var shake = b.state === 'aim' ? Math.sin(t * 60) * 1.5 : 0;
      R.sprite('chr_boar', X + shake, Y + 14 + (b.state === 'charge' ? Math.abs(Math.sin(t * 30)) * -2 : 0), 1, { flip: face < 0 });
      if (b.state === 'aim') {
        var d = Math.hypot(rd.p.x - b.x, rd.p.y - b.y) || 1;
        c.save(); c.strokeStyle = 'rgba(208,72,63,0.75)'; c.lineWidth = 3; c.setLineDash([8, 6]);
        c.beginPath(); c.moveTo(X, Y); c.lineTo(X + (rd.p.x - b.x) / d * 9 * T, Y + (rd.p.y - b.y) / d * 9 * T); c.stroke(); c.restore();
        wlabel('!', X, Y - 30, { font: R.font(22, true), align: 'center', color: C.red, stroke: C.paper, strokeW: 4 });
      }
      if (b.state === 'stun') for (var q = 0; q < 3; q++) { var a2 = t * 5 + q * 2.1; c.fillStyle = C.gold; c.fillRect(X + Math.cos(a2) * 12 - 2, Y - 24 + Math.sin(a2) * 4, 4, 4); }
      if (b.state === 'lured') { /* a drawn heart: the bundled faces carry no heart glyph */
        var hy = Y - 28 + Math.sin(t * 4) * 2;
        c.fillStyle = C.paper; c.beginPath(); c.arc(X - 4, hy, 6, 0, 7); c.arc(X + 4, hy, 6, 0, 7); c.moveTo(X - 10, hy + 1); c.lineTo(X, hy + 12); c.lineTo(X + 10, hy + 1); c.fill();
        c.fillStyle = '#e27aa4'; c.beginPath(); c.arc(X - 3.5, hy, 4, 0, 7); c.arc(X + 3.5, hy, 4, 0, 7); c.moveTo(X - 7.5, hy + 1); c.lineTo(X, hy + 9); c.lineTo(X + 7.5, hy + 1); c.fill();
      }
    });
    /* the player */
    var p = rd.p, PX = p.x * T, PY = p.y * T;
    var f = Math.abs(p.face.x) > Math.abs(p.face.y) ? (p.face.x > 0 ? 'e' : 'w') : (p.face.y < 0 ? 'n' : 's');
    var step = p.moving ? Math.abs(Math.sin(t * 12)) * 2 : 0;
    c.fillStyle = 'rgba(27,22,34,0.32)'; c.beginPath(); c.ellipse(PX, PY + 12, 11, 4, 0, 0, 7); c.fill();
    if (p.dashT > 0) for (var k2 = 1; k2 <= 3; k2++) R.sprite('chr_farmer_' + (f === 'w' ? 'e' : f), PX - p.face.x * k2 * 9, PY + 14, 1, { flip: f === 'w', alpha: 0.25 });
    var blink = p.inv > 0 && p.dashT <= 0 && Math.floor(t * 16) % 2 === 0;
    if (!blink) R.sprite('chr_farmer_' + (f === 'w' ? 'e' : f), PX, PY + 14 - step, 1, { flip: f === 'w' });
    if (rd.hold > 0) {
      c.strokeStyle = C.gold; c.lineWidth = 4; c.beginPath();
      c.arc(PX, PY - 4, 26, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.min(1, rd.hold / RAID.LIFT_HOLD)); c.stroke();
    }
    /* crows, over everything on the ground */
    rd.crows.forEach(function (cr) {
      var X = cr.x * T, Y = cr.y * T;
      c.fillStyle = 'rgba(27,22,34,0.22)'; c.beginPath(); c.ellipse(X + 10, Y + 26, 12, 4, 0, 0, 7); c.fill();
      /* a THIEF reads on any ground: a black crow over dark bog vanished at play size (own Gate 1 look
       * at the store's crow shot), and since a thief can now get away, the player has to find it fast */
      if (cr.carry) {
        var pulse = 0.5 + 0.5 * Math.sin(t * 8);
        c.save(); c.globalAlpha = 0.42 + 0.18 * pulse; c.fillStyle = C.paper; c.beginPath(); c.arc(X, Y + 8, 21, 0, 7); c.fill();
        c.globalAlpha = 0.9; c.strokeStyle = C.red; c.lineWidth = 2.5; c.beginPath(); c.arc(X, Y + 8, 22 + pulse * 3, 0, 7); c.stroke(); c.restore();
      }
      var flap = 0.8 + 0.2 * Math.abs(Math.sin(t * 14 + cr.x));
      c.save(); c.translate(X, Y);
      var ang = cr.state === 'seek' ? Math.atan2(rd.p.y - cr.y, rd.p.x - cr.x) - Math.PI / 2 : (cr.y < RAID.MH / 2 ? Math.PI : 0);
      c.rotate(ang); c.scale(flap, 1);
      R.sprite('chr_crow', 0, 20, 1);
      c.restore();
      if (cr.carry) {
        var ci = cr.carry.kind === 'coin' ? 'prop_coin' : 'plant_' + cr.carry.strain;
        R.icon(ci, X, Y + 14, 16);
      }
    });
    c.restore();
    labels.forEach(function (L) {
      var sx0 = L[1] - cam.x, sy0 = L[2] - cam.y, w = R.measure(L[0], L[3].font), hpx = 24;
      /* and clear of the bottom row, where the key hint and the buttons live (a lift's countdown
       * printed straight through the hint line) */
      if (sx0 - w / 2 - 4 < 0 || sx0 + w / 2 + 4 > R.W || sy0 - hpx < 0 || sy0 + 6 > R.H - 40) return;
      R.text(L[0], sx0, sy0, L[3]);
    });
    /* the storm: a violet curtain from the west edge to stormX, with a torn bright edge */
    var sx = rd.stormX * T - cam.x;
    if (sx > -40) {
      var g = c.createLinearGradient(sx - 160, 0, sx + 6, 0);
      g.addColorStop(0, 'rgba(62,44,90,0.96)'); g.addColorStop(0.75, 'rgba(94,74,138,0.88)'); g.addColorStop(1, 'rgba(187,166,230,0.0)');
      c.fillStyle = 'rgba(62,44,90,0.96)'; c.fillRect(0, 0, Math.max(0, sx - 160), R.H);
      c.fillStyle = g; c.fillRect(Math.max(0, sx - 160), 0, Math.min(166, sx + 166), R.H);
      c.save(); c.strokeStyle = 'rgba(187,166,230,0.85)'; c.lineWidth = 3; c.beginPath();
      for (var yy2 = -10; yy2 <= R.H + 10; yy2 += 10) {
        var ex = sx + Math.sin(yy2 * 0.05 + t * 3) * 6 + Math.sin(yy2 * 0.13 - t * 5) * 4;
        if (yy2 === -10) c.moveTo(ex, yy2); else c.lineTo(ex, yy2);
      }
      c.stroke(); c.restore();
      /* rain streaks inside the storm */
      c.strokeStyle = 'rgba(233,230,238,0.35)'; c.lineWidth = 1.2;
      for (var i2 = 0; i2 < 70; i2++) {
        var rx = (RAID.hash2(i2, 1, 3) * (sx + 40)) - (t * 60 % 40), ry = (RAID.hash2(i2, 2, 3) * R.H + t * 700) % (R.H + 30) - 15;
        if (rx < sx) { c.beginPath(); c.moveTo(rx, ry); c.lineTo(rx - 5, ry + 16); c.stroke(); }
      }
      if (fx && fx.flash > 0) { c.fillStyle = 'rgba(233,230,238,' + (fx.flash * 0.5) + ')'; c.fillRect(0, 0, Math.max(0, sx), R.H); }
    }
    return cam;
  };

  /* The minimap: the map at a few px per tile, the storm, the lifts, you. */
  R.minimap = function (rd, x, y, s) {
    var c = R.ctx, MW = RAID.MW, MH = RAID.MH;
    if (!rd._mini) {
      var cv = document.createElement('canvas'); cv.width = MW; cv.height = MH;
      var m = cv.getContext('2d'), col = ['#86b951', '#2c5a3f', '#5c7a3a', '#35609a'];
      for (var yy = 0; yy < MH; yy++) for (var xx = 0; xx < MW; xx++) { m.fillStyle = col[rd.map[yy * MW + xx]]; m.fillRect(xx, yy, 1, 1); }
      rd._mini = cv;
    }
    R.paper(x - 6, y - 6, MW * s + 12, MH * s + 12, { r: 8, owner: 'minimap' });
    c.save(); c.imageSmoothingEnabled = false; c.drawImage(rd._mini, x, y, MW * s, MH * s);
    var sx = Math.max(0, Math.min(MW, rd.stormX)) * s;
    c.fillStyle = 'rgba(62,44,90,0.85)'; c.fillRect(x, y, sx, MH * s);
    rd.items.forEach(function (it) { if (it.kind === 'pod' && (rd.missing.indexOf(it.strain) >= 0 || Z.strain(it.strain).ending)) { c.fillStyle = '#fff08a'; c.fillRect(x + it.x * s - 1.5, y + it.y * s - 1.5, 3, 3); } });
    rd.lifts.forEach(function (L) {
      if (RAID.swallowed(rd, L.x)) return;
      var open = RAID.liftOpen(rd, L);
      c.fillStyle = open ? C.gold : '#e9e6ee'; c.strokeStyle = C.ink; c.lineWidth = 1;
      c.beginPath(); c.arc(x + L.x * s, y + L.y * s, open ? 4 : 3, 0, 7); c.fill(); c.stroke();
    });
    c.fillStyle = C.red; c.fillRect(x + rd.p.x * s - 2, y + rd.p.y * s - 2, 4, 4);
    c.restore();
    if (R.rec) R.rec.push({ kind: 'picture', what: 'minimap', x: x, y: y, w: MW * s, h: MH * s });
  };

  root.R = R;
}(typeof self !== 'undefined' ? self : this));
