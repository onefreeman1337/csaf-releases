# SEEDLIFT

A free browser game where a farming incremental meets an extraction raid. Your farm grows
while you are away, and the only way to get new seed is to raid the wilds for it. Grab what you
can carry and ride a balloon lift home before the storm closes in.

## The farm

- Choose a seed in the SEED BANK and click an empty plot to sow it. Ripe plots glow: click them
  to harvest for coin and one or two seeds back. HARVEST ALL (H) and SOW ALL (F) do the whole field.
- The farm keeps growing during raids, and for up to eight hours while the game is closed.
- Sweetroot makes LURES and smokeherb makes SMOKE POTS: the crops you grow are the only tools
  you take into the wilds.
- Two different strains ripe side by side can cross when you harvest one of them, giving a
  hybrid seed. The CODEX shows which parents make which.
- The SHOP sells more field, sprinklers, compost, a bigger pack, boots, an oilskin pouch, farm
  hands and a cold frame.

## The raid

- Walk with WASD or the arrow keys, or hold the mouse or a finger on the map to walk toward it.
- Walk over seed pods and coin to pack them. The pack has slots and a weight limit. When it is
  full, walking over something better swaps out the worst thing in it.
- The storm crosses the map from the west. Balloon lifts open and close in turn: stand in an
  OPEN one and hold SPACE (or the LIFT button) to fly home.
- Boars wind up, then charge in a straight line. Step aside, or throw a LURE (Q).
- Crows steal from your pack. Chase them down, or throw SMOKE (E). SHIFT dashes once you own
  the Field Boots.
- If the storm catches you, you lose the pack but never the farm. An Oilskin Pouch keeps the
  first slot.

## Where to

Four places to raid, opened in order by a permit that costs coin and a number of strains in
your codex: the Hedgerow, the Fen, the Old Orchard and the Ridge Garden. Somewhere in the
Ridge Garden grows the centrepiece; bring it home, grow it under glass, and see it flower.

## Keys

Farm: arrows or WASD move the plot cursor, ENTER sows or harvests, Q and E choose a seed, H
harvests all, F sows all, R goes raiding, B opens the shop, C the codex. Anywhere: P or ESCAPE
pauses, M mutes.

## Saving

Your farm saves in this browser automatically: every ten seconds, after every raid and every
purchase, and when you leave the page. A raid in progress is not saved; closing the page during
one counts as turning back, so the pack is lost and the tools come home. Clearing your browser's
site data for this page clears the save.

## Made with AI, said plainly

The code and the text were written with AI tools and checked before release. The plants, the
wild objects, the balloon and the key art were generated as images and reduced to one fixed pixel
palette; the farmer, the boar and the crow were generated as pixel art. The ground textures are
drawn by our own procedural code. The music and every sound effect are synthesised by the game's
own code. No AI audio.

## Type

Pixelify Sans (with its C, c, 5, 7 and round brackets taken from Tiny5, for legibility) and Nunito, all under the SIL
Open Font License 1.1. The licence texts are in the `fonts` folder.

---

Made for the Bezi Mega Jam. A game by Core Systems Asset Factory. More of our games and tools:
https://csaf.itch.io
