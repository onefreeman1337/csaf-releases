/**
 * GLASSWRIGHT — the game.
 *
 * A season of twelve commissions. Each one: read the patron, go to the bench, design a window,
 * fire it, and be judged on what actually came out of the kiln.
 *
 * ⛔ THE ARCHITECTURE RULE: this file owns STATE and SCREENS. It never draws glass — glass is
 *    drawn by GW.paint() through a Surface, so the browser, the contact sheet and the store
 *    capture all render identically. If you find yourself reaching for ctx directly to tweak how
 *    a window looks, the change belongs in glass.js.
 *
 * ⛔ AND NOTHING HERE CALLS Math.random(). Every window is a pure function of its spec, which is
 *    what lets the gallery redraw a finished window from six stored fields, and what lets the
 *    store capture reproduce a window the player would actually see.
 */
(function (root) {
  'use strict';

  const D = root.document;
  const GW = root.GW;
  const S = root.GW_SOUND;
  const MOTIFS = root.GW_MOTIFS;
  const PALETTES = root.GW_PALETTES;
  const GLASS = root.GW_GLASS;
  const COMMISSIONS = root.GW_COMMISSIONS;

  /**
   * ⛔ THE SOURCE TREE IS ALWAYS 'full', AND THE PACKAGER PATCHES THE STAGED COPY DOWN TO 'demo'.
   *    Never the other way round. The paid desktop build is made from THIS tree, so a source
   *    left on 'demo' ships a paid download walled after four commissions — an inversion that
   *    looks completely normal from the outside and would be found by a buyer, not by us.
   *    package_web.js asserts the direction in both directions and refuses if either is wrong.
   */
  const GLASSWRIGHT_EDITION = 'demo';
  const EDITION = GLASSWRIGHT_EDITION;
  const DEMO_COMMISSIONS = 4;      // wing §1: the demo ends where the buying decision is honestly made

  const $ = (id) => D.getElementById(id);
  const el = (tag, cls, txt) => { const e = D.createElement(tag); if (cls) e.className = cls; if (txt !== undefined) e.textContent = txt; return e; };

  const FLOURISHES = [
    { id: 'none', name: 'Plain' },
    { id: 'jewels', name: 'Set Jewels' },
    { id: 'rondel', name: 'Crown Rondel' },
    { id: 'silver-stain', name: 'Silver Stain' },
    { id: 'grisaille', name: 'Painted Vine' }
  ];

  // The eight patterns a journeyman already knows. Chosen to span the families so the first
  // commissions are never blocked on a device the player has no way to draw.
  // ⚠️ 'lozenge-net' was here until it was RETIRED from the pattern book (motifs.js) for being
  //    weak. A starting motif that no longer exists would leave the new player with seven chips
  //    and no explanation, so it is replaced rather than simply dropped.
  const STARTING_MOTIFS = ['wheel-spoke', 'quarry-diamond', 'honeycomb', 'latin-cross',
    'vine-scroll', 'chequy', 'medallion-column', 'star-of-n'];
  /**
   * ⛔ ORDER MATTERS: palettes[0] IS THE DEFAULT LOADOUT ON THE BENCH, so it decides what happens
   *    to a player who reads the brief, presses Fire, and learns the game from the result.
   *
   *    It used to be Chartres Blue, because Chartres is the famous one. MEASURED on commission 1
   *    with everything else left at its default: Chartres costs 324 against a 300 budget, comes
   *    out too dark for a patron asking for light, and nets −242 coin. Every other starting
   *    palette nets positive. The opening loadout was the single worst choice available, and two
   *    of those in a row is bankruptcy before the tutorial finishes — which is exactly what the
   *    demo verifier hit.
   *
   *    Marigold nets +90 and HANDSOMELY DONE at defaults, and it is warm and golden rather than
   *    grey, so the first window a player sees is also a good-looking one. Chartres stays in the
   *    set: it is iconic AND expensive, and finding that out is a real lesson — just not one to
   *    teach by ambush on move one.
   */
  const STARTING_PALETTES = ['marigold', 'chartres', 'grisaillon', 'seaglass', 'martyr'];

  /* ============================== state ============================== */

  let st = null;
  let frames = 0;
  let titleAngle = 0;

  function newGame() {
    return {
      day: 1,
      coin: 400,
      rep: 0,
      index: 0,                         // which commission we are on
      motifs: STARTING_MOTIFS.slice(),
      palettes: STARTING_PALETTES.slice(),
      market: buildMarket(1),
      design: null,
      gallery: [],
      totalScore: 0,
      seed: 'season-1'
    };
  }

  // Glass prices drift by season. The same design is cheap one commission and dear the next,
  // which is the whole reason the market is on screen: it is the management decision that is
  // not a slider.
  function buildMarket(season) {
    const r = new root.GWRng('market-' + season);
    const m = {};
    for (const id of Object.keys(GLASS)) {
      m[id] = Math.round((0.72 + r.next() * 0.66) * 100) / 100;
    }
    return m;
  }

  function marketCostFor(state, win) {
    let c = 0;
    for (const gid of Object.keys(win.stats.units)) {
      c += win.stats.units[gid] * GLASS[gid].cost * ((state.market && state.market[gid]) || 1);
    }
    return Math.round(c + win.stats.leadCost);
  }
  function marketCost(win) { return marketCostFor(st, win); }

  function commission() { return COMMISSIONS[st.index]; }
  function isDemoWall() { return EDITION === 'demo' && st.index >= DEMO_COMMISSIONS; }

  /* ============================== save ============================== */

  const SAVE = 'glasswright_save_v1';
  function save() {
    try { root.localStorage.setItem(SAVE, JSON.stringify(st)); } catch (e) { /* private mode: play on */ }
  }
  function load() {
    try {
      const raw = root.localStorage.getItem(SAVE);
      if (!raw) return null;
      const s = JSON.parse(raw);
      return (s && typeof s.index === 'number' && Array.isArray(s.motifs)) ? s : null;
    } catch (e) { return null; }
  }
  function clearSave() { try { root.localStorage.removeItem(SAVE); } catch (e) { /* ignore */ } }

  /* ============================== screens ============================== */

  let current = 's-title';
  function show(id) {
    const prev = $(current);
    if (prev) prev.classList.remove('active');
    const next = $(id);
    if (next) next.classList.add('active');
    current = id;
    if (root.GLASSWRIGHT) root.GLASSWRIGHT.screen = id;
  }

  function drawInto(canvas, spec, opts) {
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const surf = new root.GW_CanvasSurface(ctx, canvas.width, canvas.height);
    const win = GW.glaze(spec);
    const o = Object.assign({ size: Math.min(canvas.width, canvas.height) * 0.92 }, opts || {});
    GW.paint(surf, win, o);
    return win;
  }

  /* ------------------------------ workshop ------------------------------ */

  function renderWorkshop() {
    const c = commission();
    $('w-day').textContent = st.day;
    $('w-coin').textContent = st.coin;
    $('w-rep').textContent = (st.rep > 0 ? '+' : '') + st.rep;
    $('w-done').textContent = st.gallery.length + '/' + COMMISSIONS.length;

    const patron = root.GW_PATRON_OF(c);
    const card = $('patron-card');
    card.innerHTML = '';
    card.appendChild(el('p', 'who', patron.name));
    card.appendChild(el('h3', null, c.title));
    card.appendChild(el('p', 'said', '“' + c.brief + '”'));

    const terms = el('div', 'terms');
    const form = root.GW_FORM_BY_ID[c.form];
    [['Form', form.name], ['Fee', c.fee + ' coin'], ['Budget', c.budget + ' coin'], ['Due in', c.days + ' days']]
      .forEach((t) => {
        const d = el('div', 'term');
        d.appendChild(el('b', null, t[1]));
        d.appendChild(el('i', null, t[0]));
        terms.appendChild(d);
      });
    card.appendChild(terms);
    if (c.teaches) card.appendChild(el('p', 'teaches', c.teaches));

    // the market
    const mk = $('market');
    mk.innerHTML = '';
    Object.keys(GLASS).forEach((id) => {
      const g = GLASS[id], mult = st.market[id];
      const row = el('div', 'mrow');
      const sw = el('span', 'swatch');
      sw.style.background = 'hsl(' + g.h + ',' + g.s + '%,' + g.l + '%)';
      row.appendChild(sw);
      row.appendChild(el('span', 'nm', g.name));
      const price = el('span', 'pr ' + (mult > 1.08 ? 'up' : mult < 0.92 ? 'dn' : ''), (g.cost * mult).toFixed(1));
      row.appendChild(price);
      mk.appendChild(row);
    });

    $('pattern-count').textContent = st.motifs.length + ' of ' + MOTIFS.length +
      ' traceries known, ' + st.palettes.length + ' of ' + PALETTES.length + ' palettes.';

    renderOffers();
    show('s-workshop');
    S.musicStart('workshop');
    save();

    // ⛔ SOFTLOCK GUARD. fire() refuses a window the player cannot pay for — correct on its own,
    // but if NO design is affordable the player is left on the bench with every button dead and
    // no way to end the run. The playtest's "changes nothing" bot goes bankrupt in 5 of 5 seasons,
    // so this is a state a real player will reach. Bankruptcy is an honest ending for a
    // management game; a frozen screen is a bug.
    if (!canAffordAnything()) { st.bankrupt = true; showEnding(); }
  }

  // The cheapest window this workshop could possibly cut, over the patterns and palettes it
  // actually knows. Sampled at lead 1 (no quarry ground) because that is always the cheap end.
  function canAffordAnything() {
    const c = commission();
    let min = Infinity;
    for (const pid of st.palettes) {
      for (const mid of st.motifs.slice(0, 4)) {
        const win = GW.glaze({ motifId: mid, paletteId: pid, formId: c.form, lead: 1,
          flourish: 'none', tilt: -2, seed: 'afford' });
        const cost = marketCost(win);
        if (cost < min) min = cost;
        if (min <= st.coin) return true;
      }
    }
    return false;
  }

  // After each delivered window the guild offers two new patterns. Choosing one is free and is
  // the run's real progression: by the finale you know maybe twenty of the fifty-three, and a
  // second season is a different set. That is also why the motif list on the bench stays legible.
  function renderOffers() {
    const box = $('offers');
    box.innerHTML = '';
    if (!st.pendingOffers || !st.pendingOffers.length) {
      const p = el('p', 'hint', st.gallery.length === 0
        ? 'Deliver a window and the guild will share a new pattern.'
        : 'Nothing new is on offer this season.');
      box.appendChild(p);
      return;
    }
    const h = el('p', 'hint', 'The guild offers you one of these:');
    box.appendChild(h);
    st.pendingOffers.forEach((mid) => {
      const m = MOTIFS.find((x) => x.id === mid);
      if (!m) return;
      const row = el('div', 'offer');
      const cv = el('canvas');
      cv.width = 46; cv.height = 46;
      drawInto(cv, { motifId: mid, paletteId: st.palettes[0], formId: 'oculus', lead: 2, flourish: 'none', tilt: 0, seed: mid },
        { size: 42, stone: false });
      row.appendChild(cv);
      const nm = el('div', 'nm');
      nm.appendChild(el('div', null, m.name));
      nm.appendChild(el('div', 'fam', m.family));
      row.appendChild(nm);
      row.addEventListener('click', () => {
        S.play('select');
        if (st.motifs.indexOf(mid) < 0) st.motifs.push(mid);
        st.pendingOffers = null;
        renderWorkshop();
      });
      box.appendChild(row);
    });
  }

  function offerPatterns() {
    const unknown = MOTIFS.filter((m) => st.motifs.indexOf(m.id) < 0);
    if (!unknown.length) { st.pendingOffers = null; return; }
    const r = new root.GWRng('offer-' + st.index + '-' + st.seed);
    const pick = [];
    // Prefer families the player is short of, so the offers stay useful for device briefs.
    const have = {};
    st.motifs.forEach((id) => { const m = MOTIFS.find((x) => x.id === id); if (m) have[m.family] = (have[m.family] || 0) + 1; });
    const sorted = unknown.slice().sort((a, b) => (have[a.family] || 0) - (have[b.family] || 0));
    const pool = sorted.slice(0, Math.max(2, Math.ceil(sorted.length / 2)));
    while (pick.length < 2 && pool.length) pick.push(pool.splice(r.int(0, pool.length - 1), 1)[0].id);
    st.pendingOffers = pick;

    /**
     * A palette every third window — but in a CURATED ORDER, not at random.
     *
     * ⛔ THIS WAS A RANDOM DRAW AND IT COULD MAKE A COMMISSION IMPOSSIBLE. Found by hand-playing
     *    a full season rather than by any bot: c11 requires VIOLET to dominate the window, and
     *    NOT ONE of the five starting palettes contains violet at all — it lives only in Vespers,
     *    Sainte Lumiere, Nocturn and Lenten. With random unlocks a player can arrive at the
     *    eleventh commission holding nothing that could possibly satisfy it, and the brief then
     *    reads as unfair rather than hard.
     *
     *    solve.js could not see this. It searches all twelve palettes, because it is asking
     *    whether a DESIGN exists; the player only owns the ones the run has handed them. A
     *    solvability proof over the full space is not a solvability proof over the player's
     *    inventory, and that distinction is the whole finding.
     *
     *    Vespers is first, so a violet palette is in hand from the fourth commission onward.
     */
    const UNLOCK_ORDER = ['vesper', 'canterbury', 'nocturn', 'orchard', 'reliquary', 'sainte', 'lenten'];
    if (st.gallery.length % 3 === 0) {
      const next = UNLOCK_ORDER.filter((id) => st.palettes.indexOf(id) < 0)[0];
      if (next) st.palettes.push(next);
      else {
        const unk = PALETTES.filter((p) => st.palettes.indexOf(p.id) < 0);
        if (unk.length) st.palettes.push(unk[r.int(0, unk.length - 1)].id);
      }
    }
  }

  /* ------------------------------ bench ------------------------------ */

  function defaultDesign() {
    const c = commission();
    return {
      motifId: st.motifs[0], paletteId: st.palettes[0], formId: c.form,
      lead: 3, flourish: 'none', tilt: 0,
      seed: 'w-' + c.id + '-' + st.seed
    };
  }

  function renderBench() {
    if (!st.design || st.design.formId !== commission().form) st.design = defaultDesign();
    const c = commission();
    $('d-brief').textContent = '“' + c.brief + '”';
    $('d-coin').textContent = st.coin;

    // motifs
    const ml = $('motif-list');
    ml.innerHTML = '';
    st.motifs.forEach((mid) => {
      const m = MOTIFS.find((x) => x.id === mid);
      if (!m) return;
      const chip = el('div', 'chip' + (st.design.motifId === mid ? ' on' : ''));
      const cv = el('canvas');
      cv.width = 26; cv.height = 26;
      cv.className = 'dot';
      cv.style.width = '26px'; cv.style.height = '26px';
      drawInto(cv, { motifId: mid, paletteId: st.design.paletteId, formId: 'oculus', lead: 1, flourish: 'none', tilt: 0, seed: mid },
        { size: 25, stone: false, glow: 0 });
      chip.appendChild(cv);
      chip.appendChild(el('span', null, m.name));
      chip.title = m.name + ' — ' + m.family;
      // A stable id for harnesses. Selecting a chip by its DISPLAY NAME is how _handplay.js
      // silently picked the wrong tracery five times ('wheel-spoke' vs 'Spoked Wheel').
      chip.dataset.motif = mid;
      chip.addEventListener('click', () => { st.design.motifId = mid; S.play('tick'); renderBench(); });
      ml.appendChild(chip);
    });

    // palettes
    const pl = $('palette-list');
    pl.innerHTML = '';
    st.palettes.forEach((pid) => {
      const p = PALETTES.find((x) => x.id === pid);
      if (!p) return;
      const chip = el('div', 'chip' + (st.design.paletteId === pid ? ' on' : ''));
      const dot = el('span', 'dot');
      const stops = p.glasses.slice(0, 4).map((gid, i) => {
        const g = GLASS[gid];
        return 'hsl(' + g.h + ',' + g.s + '%,' + g.l + '%) ' + (i * 25) + '% ' + ((i + 1) * 25) + '%';
      });
      dot.style.background = 'linear-gradient(135deg,' + stops.join(',') + ')';
      chip.appendChild(dot);
      chip.appendChild(el('span', null, p.name));
      chip.dataset.palette = pid;
      chip.addEventListener('click', () => { st.design.paletteId = pid; S.play('tick'); renderBench(); });
      pl.appendChild(chip);
    });

    // flourishes
    const fl = $('flourish-list');
    fl.innerHTML = '';
    FLOURISHES.forEach((f) => {
      const chip = el('div', 'chip text-only' + (st.design.flourish === f.id ? ' on' : ''), f.name);
      chip.dataset.flourish = f.id;
      chip.addEventListener('click', () => { st.design.flourish = f.id; S.play('tick'); renderBench(); });
      fl.appendChild(chip);
    });

    $('lead').value = st.design.lead;
    $('tilt').value = st.design.tilt;
    $('lead-val').textContent = st.design.lead;
    $('tilt-val').textContent = ['cheapest', 'cheaper', 'even', 'dearer', 'dearest'][st.design.tilt + 2];

    repaintPreview();
  }

  let lastWin = null;
  function repaintPreview() {
    lastWin = drawInto($('preview'), st.design, { size: 430, y: 250 });
    const c = commission();
    const cost = marketCost(lastWin);
    const days = firingDays(lastWin);
    const affordable = cost <= st.coin;

    const led = $('ledger');
    led.innerHTML = '';
    /**
     * ⛔ EVERY PROPERTY A PATRON JUDGES IS SHOWN HERE, BEFORE FIRING. A clause the player is
     *    scored on but cannot see is a trap, not a difficulty.
     *
     *    Wages were the first version of that mistake — a large cost discovered only on the
     *    reveal screen. LEADING GLASS was the second, and it was found by hand-playing a whole
     *    season: "X is present but not dominant" came back FOUR times out of twelve, even on
     *    commissions where I had deliberately chosen the palette in which that glass is
     *    top-weighted. It is achievable — the bots find dominant designs constantly — but it
     *    depends on the TRACERY, because the motif decides how much area each role covers, and
     *    nothing on screen said so. The player was guessing at the one clause they could have
     *    reasoned about.
     */
    const dom = lastWin.stats.dominant;
    const domName = dom && GLASS[dom] ? GLASS[dom].name : '—';
    const wantGlass = (c.wants && c.wants.mustUse) || null;
    const items = [
      ['Pieces', lastWin.stats.pieces, lastWin.stats.pieces >= 220 ? 'good' : lastWin.stats.pieces < 140 ? 'over' : ''],
      ['Leading glass', domName + ' ' + Math.round(lastWin.stats.share * 100) + '%',
        wantGlass ? (dom === wantGlass ? 'good' : 'over') : ''],
      ['Light', Math.round(lastWin.stats.luminosity), ''],
      ['Contrast', lastWin.stats.contrast.toFixed(1), ''],
      ['Glass + lead', cost + ' coin', cost > c.budget ? 'over' : 'good'],
      ['Budget', c.budget + ' coin', ''],
      ['Firing', days + (days === 1 ? ' day' : ' days'), days > c.days ? 'over' : 'good'],
      ['Wages', (days * UPKEEP) + ' coin', ''],
      ['Fee if accepted', c.fee + ' coin', '']
    ];
    items.forEach((it) => {
      const d = el('div', 'li ' + it[2]);
      d.appendChild(el('b', null, String(it[1])));
      d.appendChild(el('i', null, it[0]));
      led.appendChild(d);
    });

    const btn = $('btn-fire');
    btn.disabled = !affordable;
    btn.textContent = affordable ? 'Fire the Window — ' + cost + ' coin'
      : 'Too dear: you have ' + st.coin + ' coin';
  }

  // Firing time: fine cutting takes longer. This is what stops lead density being free.
  function firingDays(win) {
    return Math.max(1, Math.ceil(win.stats.pieces / 130) + Math.round(win.lead * 0.8));
  }

  // Journeymen's wages and charcoal for the kiln, per day. MEASURED NECESSITY, not flavour: with
  // no upkeep the playtest bots finished a season holding 5,000 coin, so after the third window
  // money stopped being a decision and the market panel was ornamental. Upkeep also gives lead
  // density its third cost — coin, then wages, then the deadline — which is what makes the
  // slider a real trade rather than a quality dial.
  const UPKEEP = 30;

  /**
   * settle() — the whole economic consequence of firing one window.
   *
   * ⛔ IT LIVES HERE, AND THE HEADLESS PLAYTEST CALLS THIS EXACT FUNCTION. An earlier version of
   *    playtest.js re-implemented the settlement inline, which is the defect this factory has
   *    already paid for twice: a test that re-codes the thing it is testing proves only that the
   *    test agrees with itself. If the economy changes, both the game and its bots change with it,
   *    because there is only one of them.
   */
  function settle(state, com, win) {
    const cost = marketCostFor(state, win);
    if (cost > state.coin) return null;                 // cannot afford: the caller must refuse
    const days = firingDays(win);
    const wages = days * UPKEEP;
    const result = root.GW_SCORE(com, win);
    const late = Math.max(0, days - com.days);
    let fee = result.fee;
    if (late > 0) fee = Math.round(fee * Math.max(0.35, 1 - late * 0.12));

    state.coin -= cost;
    state.coin -= wages;
    state.coin += fee;
    state.day += days;
    state.rep += result.reputation;
    state.totalScore += result.total;
    return { cost: cost, days: days, wages: wages, fee: fee, late: late, result: result };
  }

  /* ------------------------------ fire and reveal ------------------------------ */

  function fire() {
    const c = commission();
    const win = GW.glaze(st.design);

    // Being late is a real cost, not a fail state: a slow window still gets built, the patron
    // just pays less for it. All of that lives in settle(), which the bots call too.
    const out = settle(st, c, win);
    if (!out) { S.play('deny'); return; }

    S.play('cut');
    setTimeout(() => S.play('lead'), 190);
    setTimeout(() => S.play('kiln'), 430);

    st.gallery.push({
      spec: st.design, title: c.title, verdict: out.result.verdict,
      pct: out.result.pct, fee: out.fee, patron: root.GW_PATRON_OF(c).name
    });

    showReveal(c, win, out.result, out.fee, out.late, out.cost, out.wages);
    st.index++;
    st.design = null;
    offerPatterns();
    st.market = buildMarket(st.index + 1);
    save();
  }

  function showReveal(c, win, result, fee, late, cost, wages) {
    show('s-reveal');
    // Both shipped tracks get used: the unveiling has its own, opened-up setting of the same mode.
    S.musicStart('reveal');
    const cv = $('reveal-canvas');
    const ctx = cv.getContext('2d');
    ctx.clearRect(0, 0, cv.width, cv.height);

    $('r-patron').textContent = root.GW_PATRON_OF(c).name + ' — ' + c.title;
    $('r-verdict').textContent = '';
    $('r-clauses').innerHTML = '';
    $('r-payment').textContent = '';

    // The window is unveiled rather than simply appearing: the glow comes up over ~900ms. It is
    // the one moment in the game that is purely a picture, so it gets a beat of its own.
    const t0 = performance.now();
    const surf = new root.GW_CanvasSurface(ctx, cv.width, cv.height);
    function frame() {
      const t = Math.min(1, (performance.now() - t0) / 900);
      ctx.clearRect(0, 0, cv.width, cv.height);
      GW.paint(surf, win, { size: 520, y: 330, glow: 0.15 + t * 0.85 });
      if (t < 1) requestAnimationFrame(frame);
      else finishReveal();
    }
    frame();
    // Also draw once immediately, so a hidden tab (where rAF never fires) still shows the window.
    GW.paint(surf, win, { size: 520, y: 330, glow: 1 });

    function finishReveal() {
      S.play(result.pct >= 0.92 ? 'triumph' : result.pct < 0.36 ? 'refuse' : 'reveal');
    }
    setTimeout(finishReveal, 60);

    $('r-verdict').textContent = result.verdict;
    const ul = $('r-clauses');
    // ⚠️ THREE STATES, NOT TWO. The scoring gives PARTIAL credit — a window that misses the
    // patron's light by a little still earns most of the clause — but the reveal rendered every
    // non-pass as a red cross, so the first screen showed "Too dark for the brief  ✗  +15".
    // A cross beside a positive number makes the player distrust the scoreboard, and they are
    // right to: the mark was saying something the number contradicted.
    result.clauses.forEach((cl) => {
      const cls = cl.ok ? 'ok' : (cl.points > 0 ? 'partial' : 'miss');
      const li = el('li', cls);
      li.appendChild(el('span', 'mark', cls === 'ok' ? '✓' : cls === 'partial' ? '~' : '✗'));
      li.appendChild(el('span', 'txt', cl.label));
      li.appendChild(el('span', 'pts', (cl.points >= 0 ? '+' : '') + cl.points));
      ul.appendChild(li);
    });
    if (late > 0) {
      const li = el('li', 'miss');
      li.appendChild(el('span', 'mark', '✗'));
      li.appendChild(el('span', 'txt', late + (late === 1 ? ' day late' : ' days late')));
      li.appendChild(el('span', 'pts', ''));
      ul.appendChild(li);
    }
    $('r-payment').textContent = 'Glass and lead ' + cost + ', wages ' + wages + '. The patron pays ' + fee + ' coin.';
    setTimeout(() => S.play('coin'), 700);

    $('btn-next').textContent = (st.index + 1 >= COMMISSIONS.length || isDemoWallNext())
      ? 'Close the Season' : 'Back to the Workshop';
  }

  function isDemoWallNext() { return EDITION === 'demo' && (st.index + 1) >= DEMO_COMMISSIONS; }

  /* ------------------------------ gallery ------------------------------ */

  function renderGallery(targetId, small) {
    const grid = $(targetId || 'gallery-grid');
    grid.innerHTML = '';
    const size = small ? 116 : 176;
    st.gallery.forEach((g) => {
      const f = el('div', 'gframe');
      const cv = el('canvas');
      cv.width = size; cv.height = size;
      drawInto(cv, g.spec, { size: size * 0.90 });
      f.appendChild(cv);
      if (!small) {
        f.appendChild(el('div', 'gt', g.title));
        f.appendChild(el('div', 'gv', g.verdict));
      }
      grid.appendChild(f);
    });
    const empty = $('gallery-empty');
    if (empty) empty.hidden = st.gallery.length > 0;
  }

  /* ------------------------------ ending ------------------------------ */

  function showEnding() {
    show('s-end');
    const demo = isDemoWall();
    const best = st.gallery.reduce((a, g) => (!a || g.pct > a.pct ? g : a), null);
    const masterworks = st.gallery.filter((g) => g.pct >= 0.92).length;

    if (st.bankrupt) {
      $('e-title').textContent = 'THE SHOP IS SOLD';
      $('e-body').textContent = 'The glass merchant will not extend you another sheet, and there is ' +
        'nothing in the box to pay the journeymen. ' + st.gallery.length +
        (st.gallery.length === 1 ? ' window stands' : ' windows stand') + ' with your lead in them, ' +
        'and they will outlast the debt. Wages and glass both have to come out of the fee — ' +
        'a window nobody can afford to build is not a design, it is a loss.';
      $('e-demo').hidden = true;
      $('e-score').textContent = 'Standing ' + (st.rep > 0 ? '+' : '') + st.rep +
        '  ·  ' + st.gallery.length + ' windows  ·  ' + st.coin + ' coin';
      $('btn-again').textContent = 'Take Another Workshop';
      renderGallery('e-strip', true);
      return;
    }

    if (demo) {
      $('e-title').textContent = 'The Season Turns';
      $('e-body').textContent = 'Four windows delivered, and the guild has taken notice. ' +
        'Eight more commissions wait in the full season — the Bishop’s Rose, the Almoner’s Gift, ' +
        'and the West Window itself, which is the last thing the Bishop will ever commission and the ' +
        'first thing anyone will see.';
      $('e-demo').hidden = false;
      $('e-demo').textContent = 'This is the free demo: the first four commissions of twelve. ' +
        'The full season is the paid download on this page.';
      $('btn-again').textContent = 'Play the Demo Again';
    } else {
      const title = st.rep >= 22 ? 'MASTER OF THE GLAZIERS'
        : st.rep >= 14 ? 'MASTER GLAZIER'
          : st.rep >= 7 ? 'GLAZIER OF THE TOWN'
            : st.rep >= 0 ? 'A WORKING GLAZIER'
              : 'THE SHOP IS SOLD';
      $('e-title').textContent = title;
      $('e-body').textContent = st.rep >= 7
        ? 'Twelve windows, and the town knows your lead by sight. ' +
          masterworks + (masterworks === 1 ? ' masterwork' : ' masterworks') +
          ' among them, and ' + st.coin + ' coin left in the box.'
        : 'Twelve windows, and a hard season. ' + st.coin + ' coin left in the box, and ' +
          'a reputation you will have to build again from the parish work.';
      $('e-demo').hidden = true;
      $('btn-again').textContent = 'Another Season';
    }

    $('e-score').textContent = 'Standing ' + (st.rep > 0 ? '+' : '') + st.rep +
      '  ·  ' + st.gallery.length + ' windows  ·  best: ' + (best ? best.verdict : '—');
    renderGallery('e-strip', true);
  }

  /* ============================== title ============================== */

  // A slowly turning rose on the title screen, re-glazed as it goes so the player sees the
  // generator working before they are told about it.
  let titleSpec = null;
  function titleTick() {
    titleAngle += 1;
    if (titleAngle % 220 === 0 || !titleSpec) {
      const r = new root.GWRng('title-' + Math.floor(titleAngle / 220));
      const radial = MOTIFS.filter((m) => m.family === 'radial' || m.family === 'medallion');
      titleSpec = {
        motifId: r.pick(radial).id,
        paletteId: r.pick(PALETTES).id,
        formId: r.pick(['rose', 'quatrefoil', 'trefoil', 'oculus']),
        lead: r.int(2, 4),
        flourish: r.pick(['none', 'jewels', 'rondel']),
        tilt: r.int(-1, 2),
        seed: 'title' + titleAngle
      };
      drawInto($('title-canvas'), titleSpec, { size: 420 });
    }
  }

  /* ============================== wiring ============================== */

  function bind() {
    $('btn-begin').addEventListener('click', () => {
      S.unlock(); S.play('select'); S.musicStart();
      st = newGame(); clearSave(); renderWorkshop();
    });
    $('btn-continue').addEventListener('click', () => {
      S.unlock(); S.play('select'); S.musicStart();
      if (st.index >= COMMISSIONS.length || isDemoWall()) showEnding(); else renderWorkshop();
    });
    $('btn-design').addEventListener('click', () => { S.play('select'); renderBench(); show('s-design'); });
    $('btn-back').addEventListener('click', () => { S.play('tick'); renderWorkshop(); });
    $('btn-gallery').addEventListener('click', () => { S.play('tick'); renderGallery(); show('s-gallery'); });
    $('btn-gallery-back').addEventListener('click', () => { S.play('tick'); renderWorkshop(); });
    $('btn-fire').addEventListener('click', fire);
    $('btn-next').addEventListener('click', () => {
      S.play('tick');
      if (st.index >= COMMISSIONS.length || isDemoWall()) showEnding(); else renderWorkshop();
    });
    $('btn-again').addEventListener('click', () => { S.play('select'); st = newGame(); clearSave(); renderWorkshop(); });
    $('btn-see').addEventListener('click', () => { S.play('tick'); renderGallery(); show('s-gallery'); });

    $('lead').addEventListener('input', (e) => {
      st.design.lead = Number(e.target.value);
      $('lead-val').textContent = st.design.lead;
      S.play('nudge'); repaintPreview();
    });
    $('tilt').addEventListener('input', (e) => {
      st.design.tilt = Number(e.target.value);
      $('tilt-val').textContent = ['cheapest', 'cheaper', 'even', 'dearer', 'dearest'][st.design.tilt + 2];
      S.play('nudge'); repaintPreview();
    });

    const mute = $('btn-mute');
    function paintMute() { mute.style.opacity = S.isMuted() ? 0.4 : 1; mute.title = S.isMuted() ? 'Sound off' : 'Sound on'; }
    mute.addEventListener('click', () => { S.setMuted(!S.isMuted()); paintMute(); if (!S.isMuted()) S.play('tick'); });
    paintMute();

    // Keyboard: the bench is the screen worth having shortcuts on.
    D.addEventListener('keydown', (e) => {
      if (current !== 's-design') return;
      if (e.key === 'Enter') { fire(); e.preventDefault(); }
      if (e.key === 'Escape') { renderWorkshop(); e.preventDefault(); }
      if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
        const i = st.motifs.indexOf(st.design.motifId);
        const n = st.motifs.length;
        st.design.motifId = st.motifs[(i + (e.key === 'ArrowRight' ? 1 : n - 1)) % n];
        S.play('tick'); renderBench(); e.preventDefault();
      }
    });

    // First real gesture anywhere unlocks audio (§1b: no autoplay, and the itch iframe enforces it)
    D.addEventListener('pointerdown', function once() {
      S.unlock(); S.musicStart();
      D.removeEventListener('pointerdown', once);
    });
  }

  /* ============================== boot ============================== */

  function loop() {
    frames++;
    if (current === 's-title') titleTick();
    if (root.GLASSWRIGHT) root.GLASSWRIGHT.frames = frames;
    requestAnimationFrame(loop);
  }

  function boot() {
    try {
      bind();
      const saved = load();
      st = saved || newGame();
      if (saved) $('btn-continue').hidden = false;
      titleTick();
      requestAnimationFrame(loop);
      root.GLASSWRIGHT.ready = true;
    } catch (err) {
      root.GLASSWRIGHT.error = String(err && err.stack || err);
      // Never fail silently: a black canvas with a clean console is the worst outcome.
      const n = D.createElement('pre');
      n.style.cssText = 'position:fixed;inset:0;padding:24px;background:#17161a;color:#b4553f;font:13px monospace;white-space:pre-wrap;z-index:99';
      n.textContent = 'GLASSWRIGHT failed to start:\n\n' + root.GLASSWRIGHT.error;
      D.body.appendChild(n);
    }
  }

  /**
   * The probe surface. Wing §1a: an automation tab is visibilityState "hidden", rAF never fires,
   * and a frame counter pinned at zero is a stalled loop rather than a broken game. step(n)
   * drives the game synchronously so a hidden tab can still be verified.
   */
  root.GLASSWRIGHT = {
    ready: false,
    error: null,
    frames: 0,
    screen: 's-title',
    edition: EDITION,
    demoCommissions: DEMO_COMMISSIONS,
    step: function (n) {
      for (let i = 0; i < (n || 1); i++) { frames++; if (current === 's-title') titleTick(); }
      this.frames = frames;
      return frames;
    },
    state: function () {
      return st ? { day: st.day, coin: st.coin, rep: st.rep, index: st.index, gallery: st.gallery.length,
        motifs: st.motifs.length, palettes: st.palettes.length } : null;
    },
    // Used by the headless playtest to drive a whole run without a browser event loop.
    _internal: function () {
      return {
        get st() { return st; }, set st(v) { st = v; },
        newGame: newGame, marketCost: marketCost, marketCostFor: marketCostFor, firingDays: firingDays, settle: settle, UPKEEP: UPKEEP,
        commission: commission, buildMarket: buildMarket, offerPatterns: offerPatterns,
        STARTING_MOTIFS: STARTING_MOTIFS, STARTING_PALETTES: STARTING_PALETTES
      };
    }
  };

  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', boot);
  else boot();
})(typeof window !== 'undefined' ? window : globalThis);
