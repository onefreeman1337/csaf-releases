/**
 * GLASSWRIGHT — the Canvas2D Surface.
 *
 * The browser half of the four-method contract GW.paint() draws through. The Node half lives in
 * Internal_Ops/softsurface.js and rasterises the same calls in software, which is how the store
 * gallery and the contact sheet are drawn by the same code the player sees.
 *
 * ⛔ KEEP THIS THIN. Every line of drawing intelligence that leaks in here is a line the Node
 *    renderer does not have, and the two silently diverge — at which point the contact sheet
 *    stops being evidence about the game. If a drawing decision is worth making, it belongs in
 *    glass.js where both backends get it.
 */
(function (root) {
  'use strict';

  function CanvasSurface(ctx, width, height) {
    this.ctx = ctx;
    this.width = width;
    this.height = height;
  }

  const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a === undefined ? 1 : a})`;

  CanvasSurface.prototype.clear = function (rgb) {
    this.ctx.fillStyle = rgba(rgb, 1);
    this.ctx.fillRect(0, 0, this.width, this.height);
  };

  CanvasSurface.prototype.fillRect = function (x, y, w, h, rgb, a) {
    this.ctx.fillStyle = rgba(rgb, a);
    this.ctx.fillRect(x, y, w, h);
  };

  CanvasSurface.prototype._path = function (pts, closed) {
    const c = this.ctx;
    c.beginPath();
    c.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]);
    if (closed !== false) c.closePath();
  };

  CanvasSurface.prototype.fillPoly = function (pts, rgb, a) {
    if (!pts || pts.length < 3) return;
    this._path(pts, true);
    this.ctx.fillStyle = rgba(rgb, a);
    this.ctx.fill();
  };

  CanvasSurface.prototype.strokePoly = function (pts, width, rgb, a, closed) {
    if (!pts || pts.length < 2) return;
    const c = this.ctx;
    this._path(pts, closed);
    c.lineWidth = width;
    c.lineJoin = 'round';
    c.lineCap = 'round';
    c.strokeStyle = rgba(rgb, a);
    c.stroke();
  };

  CanvasSurface.prototype.pushClipPoly = function (pts) {
    this.ctx.save();
    this._path(pts, true);
    this.ctx.clip();
  };

  CanvasSurface.prototype.popClip = function () { this.ctx.restore(); };

  CanvasSurface.prototype.radialWash = function (cx, cy, rInner, rOuter, rgb, aInner, aOuter) {
    if (rOuter <= 0) return;
    const g = this.ctx.createRadialGradient(cx, cy, Math.max(0, rInner), cx, cy, rOuter);
    g.addColorStop(0, rgba(rgb, aInner));
    g.addColorStop(1, rgba(rgb, aOuter));
    this.ctx.fillStyle = g;
    this.ctx.beginPath();
    this.ctx.arc(cx, cy, rOuter, 0, Math.PI * 2);
    this.ctx.fill();
  };

  root.GW_CanvasSurface = CanvasSurface;
})(typeof window !== 'undefined' ? window : globalThis);
