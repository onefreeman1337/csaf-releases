/**
 * GLASSWRIGHT — sound.
 *
 * Procedural WebAudio, synthesised at runtime. Wing §0-ART rule 4 makes audio non-optional and
 * §1b puts SFX FIRST: "good SFX and no music feels finished; music with no SFX feels broken."
 *
 * ⚠️ Procedural synthesis is NOT generative AI — itch says so, and this wing's constitution
 *    records it (§0-ART). The AI disclosure for this product is Code = yes, Graphics = yes,
 *    Sounds = NO, Text & Dialog = yes (the patrons speak).
 *
 * ⛔ NO AUTOPLAY. The context is created suspended and only resumed on the first real click,
 *    because the itch iframe will otherwise block it and the game ships silent (§1b).
 *
 * The palette is deliberately narrow and made of the materials: glass, lead, stone, a small bell.
 * Nothing here is a stock arcade blip.
 */
(function (root) {
  'use strict';

  let ctx = null;
  let master = null;
  let muted = false;
  let musicGain = null;
  let musicTimer = null;
  let started = false;

  function ensure() {
    if (ctx) return ctx;
    const AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.9;
    master.connect(ctx.destination);
    musicGain = ctx.createGain();
    musicGain.gain.value = 0.0;
    musicGain.connect(master);
    return ctx;
  }

  // Called from a real user gesture. Until this runs the game is silent by design.
  function unlock() {
    const c = ensure();
    if (!c) return;
    if (c.state === 'suspended') c.resume();
    started = true;
  }

  function now() { return ctx ? ctx.currentTime : 0; }

  function env(node, t0, a, d, peak) {
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), t0 + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + a + d);
    node.connect(g);
    return g;
  }

  function tone(freq, t0, dur, type, peak, detune) {
    const o = ctx.createOscillator();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, t0);
    if (detune) o.detune.setValueAtTime(detune, t0);
    const g = env(o, t0, Math.min(0.02, dur * 0.2), dur, peak);
    g.connect(master);
    o.start(t0);
    o.stop(t0 + dur + 0.08);
    return o;
  }

  function noise(t0, dur, peak, filterHz, q) {
    const n = Math.floor(ctx.sampleRate * dur);
    const buf = ctx.createBuffer(1, Math.max(1, n), ctx.sampleRate);
    const d = buf.getChannelData(0);
    // A deterministic-ish noise: no Math.random in the product (rng.js §), and the ear cannot
    // tell a fixed noise burst from a fresh one at these lengths.
    let s = 22222;
    for (let i = 0; i < n; i++) { s = (s * 1103515245 + 12345) & 0x7fffffff; d[i] = (s / 0x3fffffff) - 1; }
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const f = ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = filterHz || 2000;
    f.Q.value = q || 1;
    src.connect(f);
    const g = env(f, t0, 0.004, dur, peak);
    g.connect(master);
    src.start(t0);
    return src;
  }

  /* --------------------------------------------------------------------------------------------
   * THE SFX SET. Each one is the sound of the material it belongs to.
   * ------------------------------------------------------------------------------------------ */
  const SFX = {
    // a fingernail on a sheet of glass — short, bright, glassy
    tick: () => { const t = now(); tone(2400, t, 0.05, 'sine', 0.05); tone(3600, t, 0.035, 'sine', 0.025); },

    // moving a slider: the same, quieter and lower, so holding a key does not become a fire alarm
    nudge: () => { const t = now(); tone(1400, t, 0.04, 'sine', 0.032); },

    // selecting: two glass notes a fifth apart
    select: () => {
      const t = now();
      tone(880, t, 0.09, 'sine', 0.07); tone(1320, t + 0.045, 0.12, 'sine', 0.055);
    },

    // the glass cutter scoring a sheet
    cut: () => { const t = now(); noise(t, 0.13, 0.10, 3200, 6); tone(520, t, 0.06, 'triangle', 0.03); },

    // lead being tapped into the came with a wooden mallet
    lead: () => { const t = now(); noise(t, 0.07, 0.09, 420, 2); tone(180, t, 0.09, 'sine', 0.06); },

    // the kiln door: low, heavy stone
    kiln: () => {
      const t = now();
      noise(t, 0.5, 0.10, 140, 0.7);
      tone(70, t, 0.55, 'sine', 0.10);
      tone(104, t + 0.03, 0.4, 'triangle', 0.04);
    },

    // the window is revealed: a bell and a rising glass chord
    reveal: () => {
      const t = now();
      [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => tone(f, t + i * 0.10, 1.4, 'sine', 0.075));
      tone(261.63, t, 2.0, 'triangle', 0.05);
      tone(1567.98, t + 0.42, 1.6, 'sine', 0.028);
    },

    // a masterwork: the bell again, higher, with a shimmer
    triumph: () => {
      const t = now();
      [659.25, 783.99, 987.77, 1318.5, 1567.98].forEach((f, i) => tone(f, t + i * 0.085, 1.8, 'sine', 0.07));
      tone(329.63, t, 2.4, 'triangle', 0.055);
    },

    // refused: the patron turns away
    refuse: () => {
      const t = now();
      tone(220, t, 0.5, 'triangle', 0.08);
      tone(207.65, t + 0.10, 0.7, 'sine', 0.06);
      noise(t, 0.3, 0.05, 300, 1);
    },

    coin: () => {
      const t = now();
      tone(1760, t, 0.07, 'square', 0.028); tone(2637, t + 0.05, 0.10, 'square', 0.020);
    },

    deny: () => { const t = now(); tone(150, t, 0.16, 'square', 0.05); }
  };

  function play(name) {
    if (muted || !started) return;
    const c = ensure();
    if (!c || c.state !== 'running') return;
    const fn = SFX[name];
    if (fn) { try { fn(); } catch (e) { /* an audio failure must never stop the game */ } }
  }

  /* --------------------------------------------------------------------------------------------
   * MUSIC — a slow modal drone with a plainchant-shaped melody above it.
   *
   * Dorian on D, which is the mode most of the surviving chant repertory sits in, and it is the
   * reason this does not sound like fantasy-game music. The melody walks by step with an
   * occasional third, phrases end on the final or the fifth, and there are real rests: chant
   * breathes, and a line with no breath is the tell that a computer wrote it.
   * ------------------------------------------------------------------------------------------ */
  const D_DORIAN = [146.83, 164.81, 174.61, 196.00, 220.00, 246.94, 261.63, 293.66, 329.63, 349.23, 392.00];
  let mi = 3;          // index into the mode
  let phrasePos = 0;
  let step = 0;

  function musicTick() {
    if (muted || !ctx || ctx.state !== 'running') return;
    const t = now();

    // the drone: the final and its fifth, re-struck slowly
    if (step % 16 === 0) {
      const d1 = ctx.createOscillator(); d1.type = 'triangle'; d1.frequency.value = 73.42;
      const d2 = ctx.createOscillator(); d2.type = 'sine'; d2.frequency.value = 110.0;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.055, t + 1.2);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 7.5);
      d1.connect(g); d2.connect(g); g.connect(musicGain);
      d1.start(t); d2.start(t); d1.stop(t + 8); d2.stop(t + 8);
    }

    // the melody, one note per tick with rests between phrases
    phrasePos++;
    const resting = phrasePos > 7 && phrasePos < 11;
    if (!resting) {
      // walk by step, occasionally a third, and pull back toward the middle of the range
      const r = ((step * 2654435761) >>> 0) / 4294967296;
      let move = r < 0.42 ? 1 : r < 0.84 ? -1 : (r < 0.92 ? 2 : -2);
      if (mi <= 1) move = Math.abs(move);
      if (mi >= 9) move = -Math.abs(move);
      mi = Math.max(0, Math.min(D_DORIAN.length - 1, mi + move));
      if (phrasePos === 7 || phrasePos === 14) mi = (step % 32 < 16) ? 3 : 0;   // cadence
      const f = D_DORIAN[mi];
      const o = ctx.createOscillator();
      o.type = 'sine';
      o.frequency.value = f;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.040, t + 0.28);
      g.gain.setValueAtTime(0.040, t + 0.85);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 1.5);
      o.connect(g); g.connect(musicGain);
      o.start(t); o.stop(t + 1.6);
      // a quiet parallel fifth below, the organum that makes it read as medieval
      if (step % 4 === 0) {
        const o2 = ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = f * 0.6674;
        const g2 = ctx.createGain();
        g2.gain.setValueAtTime(0.0001, t);
        g2.gain.exponentialRampToValueAtTime(0.020, t + 0.3);
        g2.gain.exponentialRampToValueAtTime(0.0001, t + 1.4);
        o2.connect(g2); g2.connect(musicGain);
        o2.start(t); o2.stop(t + 1.5);
      }
    }
    if (phrasePos >= 14) phrasePos = 0;
    step++;
  }

  /* ============================ the rendered score ============================
   *
   * The shipped tracks (audio/mus_workshop.ogg, audio/mus_reveal.ogg) are the SAME Dorian
   * material as the live synthesis above, composed as note data in Internal_Ops/Audio/compose.js
   * and rendered offline. The file is preferred when it loads; the live synthesiser is the
   * fallback, so the game is never silent even if the audio fails to fetch.
   *
   * ⛔ IT PLAYS THROUGH AN <audio> ELEMENT, NOT A FETCHED BUFFER, AND THAT IS THE WHOLE POINT.
   *    Wing §8a trap 2, measured in real Chrome and nearly shipped on the Brass Orrery: the paid
   *    desktop build loads from file://, where XHR and fetch are BOTH BLOCKED while
   *    <audio> + createMediaElementSource works. A buffer-based player is perfect in the free
   *    web demo and leaves the PAID DOWNLOAD SILENT — backwards, and invisible to an iframe
   *    probe, because an iframe probe correctly tests over http.
   */
  let musicEl = null;
  let musicSrc = null;
  let usingFile = false;

  /**
   * ⛔ THE MUSIC ELEMENT IS NOT ROUTED THROUGH WEBAUDIO, AND BOTH HALVES OF THAT ARE DELIBERATE.
   *
   * MEASURED 2026-08-25 in real Chromium on file:// — a NEW FORM of wing §8a trap 2, which the
   * existing note does not cover. The first version did the textbook thing: set
   * `crossOrigin = 'anonymous'` and connect through `createMediaElementSource` so the track
   * obeys the master gain. On file:// that is fatal twice over:
   *
   *   Access to audio at 'file:///…/mus_workshop.ogg' from origin 'null' has been blocked by
   *   CORS policy: Cross origin requests are only supported for protocol schemes: chrome,
   *   chrome-untrusted, data, http, https.
   *
   * Setting crossOrigin turns a plain media load into a CORS request that a file:// origin can
   * never satisfy; and even without it, Chrome treats every file:// document as an opaque origin,
   * so feeding the element into the audio graph would yield a tainted node — i.e. silence — in
   * exactly the PAID DOWNLOAD, while the free web demo over http sounded perfect.
   *
   * So the score plays as a bare <audio> element with its own `volume`, and only the SFX go
   * through WebAudio. The mute control drives both.
   */
  function tryFile(name) {
    try {
      const el = new Audio();
      el.src = 'audio/' + name + '.ogg';
      el.loop = true;
      el.preload = 'auto';
      el.volume = muted ? 0 : MUSIC_VOL;
      musicEl = el;
      // If it cannot play at all, fall back to live synthesis rather than leaving it silent.
      el.addEventListener('error', () => { usingFile = false; musicEl = null; startSynth(); });
      const pr = el.play();
      if (pr && pr.catch) pr.catch(() => { usingFile = false; musicEl = null; startSynth(); });
      usingFile = true;
      return true;
    } catch (e) {
      return false;
    }
  }
  const MUSIC_VOL = 0.55;

  function startSynth() {
    if (musicTimer) return;
    musicTick();
    musicTimer = setInterval(musicTick, 1150);
  }

  function musicStart(which) {
    const c = ensure();
    if (c) musicGain.gain.setTargetAtTime(0.85, c.currentTime, 2.0);
    const name = which === 'reveal' ? 'mus_reveal' : 'mus_workshop';
    if (usingFile && musicEl) {
      if (musicEl.src.indexOf(name) < 0) { musicEl.pause(); musicEl.src = 'audio/' + name + '.ogg'; }
      musicEl.volume = muted ? 0 : MUSIC_VOL;
      const pr = musicEl.play();
      if (pr && pr.catch) pr.catch(() => { /* a blocked resume is not a game failure */ });
      return;
    }
    if (musicTimer) return;
    if (!tryFile(name)) startSynth();
  }

  function musicStop() {
    if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
    if (musicEl) { try { musicEl.pause(); } catch (e) { /* ignore */ } }
    if (musicGain && ctx) musicGain.gain.setTargetAtTime(0.0, ctx.currentTime, 0.5);
  }

  function musicBackend() { return usingFile ? 'file' : (musicTimer ? 'synth' : 'none'); }

  function setMuted(v) {
    muted = !!v;
    if (master && ctx) master.gain.setTargetAtTime(muted ? 0 : 0.9, ctx.currentTime, 0.05);
    // The score sits OUTSIDE the audio graph (see tryFile), so the master gain cannot reach it.
    if (musicEl) musicEl.volume = muted ? 0 : MUSIC_VOL;
    try { root.localStorage.setItem('gw_muted', muted ? '1' : '0'); } catch (e) { /* private mode */ }
  }

  function isMuted() { return muted; }

  try { muted = root.localStorage.getItem('gw_muted') === '1'; } catch (e) { /* private mode */ }

  root.GW_SOUND = {
    unlock: unlock, play: play, musicStart: musicStart, musicStop: musicStop,
    setMuted: setMuted, isMuted: isMuted,
    backend: musicBackend,
    names: Object.keys(SFX)
  };
})(typeof window !== 'undefined' ? window : globalThis);
