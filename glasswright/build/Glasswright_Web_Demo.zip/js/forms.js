/**
 * GLASSWRIGHT — window FORMS.
 *
 * A form is the shape of the hole in the wall. It does three things:
 *   1. clips the tracery (a rose motif in a lancet reads completely differently from the same
 *      motif in a wheel — this is why one motif set yields far more than 53 pictures),
 *   2. sets the aspect ratio the motif is squeezed into,
 *   3. decides how much stone surrounds the glass, which is most of the "this is a WINDOW, not a
 *      pattern" impression.
 *
 * Coordinates are the same unit space the motifs use: x,y in [-1,1], y DOWN. The outline is a
 * closed polygon. `scale` maps unit space into the form: a lancet is tall, so the motif is
 * compressed horizontally and repeated vertically by the glazier rather than stretched — a
 * stretched trefoil looks wrong immediately.
 *
 * ⛔ Do not add a form without drawing it. Every form here was checked on the contact sheet;
 *    a form that clips a motif down to four cells produces an empty-looking window and the
 *    density floor will not catch it (wing §10b: a density pass means "not empty", never "good").
 */
(function (root) {
  'use strict';

  const TAU = Math.PI * 2;

  function arcPts(cx, cy, r, a0, a1, steps) {
    const p = [];
    for (let i = 0; i <= steps; i++) {
      const a = a0 + (a1 - a0) * (i / steps);
      p.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
    }
    return p;
  }

  // ---- outline builders -------------------------------------------------------------------

  /**
   * A pointed arch over a rectangle: the definitive Gothic light.
   *
   * ⛔ REBUILT 2026-08-25 after the first contact sheet showed a torn outline. The two-centred
   * construction has to be written parametrically or the atan2 branch cuts tear it apart, which
   * is exactly what happened: the polygon self-intersected and every point-in-polygon test
   * downstream then answered nonsense, so the quarry ground rendered OUTSIDE the window.
   *
   * ⛔ CORRECTED A SECOND TIME. The first rewrite put the left arc's centre on the RIGHT JAMB,
   * which is only correct for the equilateral arch R = 2w. Twin Lancet uses a drop arch
   * (R = 1.35w) and tore open again: at t = PI the arc began at x = w - R = -0.14 while the jamb
   * was at -0.40. A form that is right for one parameter and wrong for another is worse than one
   * that is wrong for both, because the sheet shows nine good plates and one that reads as a
   * rendering glitch.
   *
   * The general two-centred arch, span 2w, radius R >= w:
   *   the left arc must pass through the left jamb (-w, springY) AND the apex (0, apexY),
   *   so its centre sits at (R - w, springY) — inboard of the jamb, not on it.
   *   rise = sqrt(R^2 - (R-w)^2) = sqrt(2Rw - w^2).
   *   R = 2w recovers the equilateral arch (centre at +w, rise = w*sqrt(3)). Checked by hand.
   */
  function lancet(width, headSharp) {
    const w = width, bot = 1;
    const R = w * (headSharp ? 2.0 : 1.35);
    const c = R - w;                              // arc centre offset from the axis
    const rise = Math.sqrt(Math.max(0.0001, 2 * R * w - w * w));
    const springY = -1 + rise;                    // so the apex lands exactly on y = -1
    const tApex = Math.acos(-c / R);              // where the left arc reaches x = 0
    const pts = [[-w, bot], [-w, springY]];
    const N = 20;
    for (let i = 0; i <= N; i++) {                // left arc: PI (left jamb) -> apex
      const t = Math.PI + (tApex - Math.PI) * (i / N);
      pts.push([c + R * Math.cos(t), springY - R * Math.sin(t)]);
    }
    for (let i = 0; i <= N; i++) {                // right arc: apex -> right jamb, mirrored
      const t = (Math.PI - tApex) + (0 - (Math.PI - tApex)) * (i / N);
      pts.push([-c + R * Math.cos(t), springY - R * Math.sin(t)]);
    }
    pts.push([w, bot]);
    return pts;
  }

  function circle(r) { return arcPts(0, 0, r, 0, TAU, 96); }

  function foilOutline(r, lobes, phase) {
    const p = [];
    const steps = lobes * 24;
    for (let i = 0; i < steps; i++) {
      const a = (i / steps) * TAU + (phase || 0);
      const k = 0.70 + 0.30 * Math.abs(Math.cos(lobes * (a - (phase || 0)) / 2));
      p.push([Math.cos(a) * r * k, Math.sin(a) * r * k]);
    }
    return p;
  }

  function vesica(w, h) {
    // Two circular arcs meeting at top and bottom points — the almond.
    const p = [];
    const R = (w * w + h * h) / (2 * w);
    const cx = R - w;
    for (let i = 0; i <= 40; i++) {
      const t = -1 + 2 * (i / 40);
      const y = t * h;
      const x = Math.sqrt(Math.max(0, R * R - y * y)) - cx;
      p.push([x, y]);
    }
    for (let i = 40; i >= 0; i--) {
      const t = -1 + 2 * (i / 40);
      const y = t * h;
      const x = Math.sqrt(Math.max(0, R * R - y * y)) - cx;
      p.push([-x, y]);
    }
    return p;
  }

  // Romanesque semicircular head. The spring line is placed so the apex lands on y = -1;
  // computing it any other way leaves dead stone above the arch (measured on the first sheet).
  function roundHead(w) {
    const springY = -1 + w;
    const p = [[-w, 1], [-w, springY]];
    p.push(...arcPts(0, springY, w, Math.PI, TAU, 30));
    p.push([w, 1]);
    return p;
  }

  function panel(w, h) { return [[-w, -h], [w, -h], [w, h], [-w, h]]; }

  // ---- the catalogue ----------------------------------------------------------------------
  //
  // `tiles` tells the glazier how many times the motif repeats down the light. A tall lancet
  // holding ONE motif stretched to fit is the ugliest thing this generator can produce; real
  // lancets stack registers, so tall forms tile.

  const FORMS = [
    {
      id: 'rose', name: 'Rose Window', kind: 'round',
      w: 1, h: 1, tiles: 1, stone: 0.085,
      outline: () => circle(0.985),
      note: 'The great wheel. One motif, full round, maximum ceremony.'
    },
    {
      id: 'oculus', name: 'Oculus', kind: 'round',
      w: 1, h: 1, tiles: 1, stone: 0.13,
      outline: () => circle(0.90),
      note: 'A small round light with heavy stone. Cheap glass, strong silhouette.'
    },
    {
      id: 'quatrefoil', name: 'Quatrefoil', kind: 'foil',
      w: 1, h: 1, tiles: 1, stone: 0.10,
      outline: () => foilOutline(0.98, 4, Math.PI / 4),
      note: 'Four cusped lobes. The tracery shape a patron asks for by name.'
    },
    {
      id: 'trefoil', name: 'Trefoil', kind: 'foil',
      w: 1, h: 1, tiles: 1, stone: 0.11,
      outline: () => foilOutline(0.97, 3, -Math.PI / 2),
      note: 'Three lobes for the Trinity. Reads instantly at thumbnail size.'
    },
    {
      id: 'lancet', name: 'Lancet', kind: 'tall',
      w: 0.46, h: 1, tiles: 3, stone: 0.07,
      outline: () => lancet(0.46, true),
      note: 'A tall pointed light. Stacks three registers of tracery.'
    },
    {
      id: 'twin-lancet', name: 'Twin Lancet', kind: 'tall',
      w: 0.40, h: 1, tiles: 2, stone: 0.07,
      outline: () => lancet(0.40, false),
      note: 'Broader arch, two registers. The parish standard.'
    },
    {
      id: 'round-head', name: 'Round-Headed Light', kind: 'tall',
      w: 0.52, h: 1, tiles: 2, stone: 0.075,
      outline: () => roundHead(0.52),
      note: 'The older Romanesque head. Solid, unfashionable, cheap to glaze.'
    },
    {
      id: 'vesica', name: 'Vesica', kind: 'tall',
      w: 0.55, h: 0.98, tiles: 2, stone: 0.10,
      outline: () => vesica(0.55, 0.96),
      note: 'The almond. Points top and bottom; the hardest form to fill well.'
    },
    {
      id: 'panel', name: 'Square Panel', kind: 'panel',
      w: 0.94, h: 0.94, tiles: 1, stone: 0.06,
      outline: () => panel(0.94, 0.94),
      note: 'A guild panel or a donor light. No arch, all glass.'
    },
    {
      id: 'tall-panel', name: 'Register Panel', kind: 'panel',
      w: 0.60, h: 0.96, tiles: 2, stone: 0.065,
      outline: () => panel(0.60, 0.96),
      note: 'A narrow rectangle of two registers, set into a larger scheme.'
    }
  ];

  const byId = {};
  FORMS.forEach((f) => { byId[f.id] = f; });

  root.GW_FORMS = FORMS;
  root.GW_FORM_BY_ID = byId;
})(typeof window !== 'undefined' ? window : globalThis);
