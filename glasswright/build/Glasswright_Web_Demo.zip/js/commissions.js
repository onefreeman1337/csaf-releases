/**
 * GLASSWRIGHT — patrons, commissions and the scoring of a finished window.
 *
 * THE DESIGN RULE THAT MAKES THIS A GAME RATHER THAN A TOY: the score is read off the ARTEFACT,
 * not off the menu. When you fire a window the glazier hands back real measured properties —
 * luminosity, chroma, contrast, which glass ended up dominant, how many pieces were cut, what it
 * cost — and the patron judges THOSE. You cannot satisfy a patron by selecting the right item
 * from a list; you have to make a window that actually comes out the way they asked.
 *
 * That is also why the design screen re-glazes live. The player is not choosing options, they
 * are watching a window change.
 */
(function (root) {
  'use strict';

  const GLASS = root.GW_GLASS;

  /* -------------------------------------------------------------------------------------------
   * PATRONS. Each wants a different KIND of window, so the twelve commissions of a run pull the
   * player in genuinely different directions instead of being the same puzzle with new numbers.
   * ----------------------------------------------------------------------------------------- */
  const PATRONS = [
    { id: 'abbot',    name: 'Abbot Ceolwulf',      style: 'The abbey keeps the Rule. Plain glass, no vanity.' },
    { id: 'bishop',   name: 'Bishop Hauteclere',   style: 'The bishop wants Chartres, and he wants it larger.' },
    { id: 'guild',    name: 'The Weavers Guild',   style: 'Guildsmen pay for their own colours, prominently.' },
    { id: 'widow',    name: 'The Widow Alys',      style: 'A memorial light. Sombre, and it must be beautiful.' },
    { id: 'king',     name: "The King's Almoner",  style: 'Nothing cheap. The crown notices cheapness.' },
    { id: 'merchant', name: 'Guiscard the Factor', style: 'A merchant counts coin. Impress him, but not with his money.' },
    { id: 'prior',    name: 'Prior Aethelred',     style: 'Wants light. Says the nave is a cellar.' },
    { id: 'mason',    name: 'Warin the Mason',     style: 'He built the tracery and has opinions about it.' }
  ];

  /* -------------------------------------------------------------------------------------------
   * THE TWELVE COMMISSIONS. Hand-authored, in a deliberate difficulty curve: the first two teach
   * one constraint each, the middle six combine them, the last four are genuinely hard and the
   * final one asks for everything at once.
   *
   * ⛔ Wing §4: the slice is FIXED at twelve. Depth comes from the generator, never from more
   *    commissions. A thirteenth is scope creep wearing a content costume.
   *
   * ⛔ EVERY NUMBER BELOW IS READ OFF stats_probe.js, NOT CHOSEN. The first draft was written by
   *    eye and solve.js found one brief that NO design in 17,172 could satisfy, plus a
   *    difficulty curve that ran backwards — the two tutorial commissions were the tightest in
   *    the game. The measured distribution of a fired window (all forms, p10/p25/p50/p75/p90):
   *
   *      luminosity   38 / 40 / 44 / 47 / 51        (max ~81, but the tail is thin)
   *      contrast    1.0 / 2.6 / 5.9 / 10.1 / 15.6  (max ~39)
   *      pieces       20 / 150 / 260 / 390 / 600
   *      cost (rose) 151 / 213 / 277 / 381 / 460
   *
   *    So: "bright" is >=47, "sombre" is <=41, a demanding contrast floor is 12, and a budget
   *    at p50 is a real squeeze while one at p75 is comfortable. Targets are placed against
   *    those percentiles ON PURPOSE, loosest first.
   * ----------------------------------------------------------------------------------------- */
  const COMMISSIONS = [
    {
      id: 'c1', patron: 'prior', title: 'A Light for the Nave', form: 'oculus',
      fee: 336, days: 6, budget: 300,
      brief: 'The nave is dark as a cellar. Give me light — a bright window, and never mind the fashion.',
      wants: { luminosity: [43, 100], device: null, mustUse: null, avoid: null, minPieces: 0 },
      teaches: 'LUMINOSITY — the patron judges how bright the finished glass actually reads.'
    },
    {
      id: 'c2', patron: 'guild', title: 'The Weavers Mark', form: 'panel',
      fee: 358, days: 6, budget: 320,
      brief: 'Our cloth is dyed with weld and the town knows it. Let amber be the colour a man sees first.',
      wants: { luminosity: null, device: null, mustUse: 'amber', avoid: null, minPieces: 0 },
      teaches: 'DOMINANCE — one named glass must end up covering more of the window than any other.'
    },
    {
      id: 'c3', patron: 'abbot', title: 'The Chapter House', form: 'lancet',
      fee: 336, days: 7, budget: 300,
      brief: 'The Rule forbids display. No gold ruby in my chapter house, and I will know.',
      wants: { luminosity: [0, 44], device: null, mustUse: null, avoid: 'ruby', minPieces: 0 },
      teaches: 'PROSCRIPTION — a forbidden glass, and a sober window.'
    },
    {
      id: 'c4', patron: 'mason', title: 'Warin Tests You', form: 'quatrefoil',
      fee: 370, days: 7, budget: 330,
      brief: 'I cut that tracery myself. Fill it with something that answers it — foliage, and plenty of cuts.',
      wants: { luminosity: null, device: 'foliate', mustUse: null, avoid: null, minPieces: 200 },
      teaches: 'DEVICE and CRAFT — a required motif family, and a floor on how finely it is cut.'
    },
    {
      id: 'c5', patron: 'widow', title: 'A Memorial Light', form: 'vesica',
      fee: 336, days: 7, budget: 300,
      brief: 'For my husband. Sombre — I am not celebrating. But make it beautiful, glazier.',
      wants: { luminosity: [0, 42], device: null, mustUse: null, avoid: 'amber', minContrast: 9 },
      teaches: 'CONTRAST — sombre is not the same as flat, and the patron can tell.'
    },
    {
      id: 'c6', patron: 'merchant', title: 'Guiscards Counting House', form: 'round-head',
      fee: 291, days: 6, budget: 260,
      brief: 'I am told glass is dear. Prove otherwise. Spend little and impress me anyway.',
      wants: { luminosity: [43, 100], device: null, mustUse: null, avoid: null, thrift: true },
      teaches: 'THRIFT — the budget is the point, not a limit you happen to respect.'
    },
    {
      id: 'c7', patron: 'bishop', title: 'The Bishops Rose', form: 'rose',
      fee: 482, days: 9, budget: 430,
      brief: 'Chartres. Cobalt first, ruby beside it, and a wheel a man can see from the west door.',
      wants: { luminosity: null, device: 'radial', mustUse: 'cobalt', avoid: null, minPieces: 240 },
      teaches: null
    },
    {
      id: 'c8', patron: 'abbot', title: 'The Refectory', form: 'twin-lancet',
      fee: 381, days: 7, budget: 340,
      brief: 'Grisaille. Silver and quiet. The brothers eat here; they are not to be dazzled.',
      wants: { luminosity: [44, 100], device: null, mustUse: 'grisaille', avoid: 'ruby', minContrast: 8 },
      teaches: null
    },
    {
      id: 'c9', patron: 'king', title: 'The Almoners Gift', form: 'trefoil',
      fee: 470, days: 8, budget: 420,
      brief: 'The crown gives no cheap gifts. Gold ruby, and jewels set in the border. Do not economise.',
      wants: { luminosity: null, device: null, mustUse: 'ruby', avoid: null, flourish: 'jewels', lavish: true },
      teaches: null
    },
    {
      id: 'c10', patron: 'mason', title: 'The Great Cross', form: 'tall-panel',
      fee: 403, days: 8, budget: 360,
      brief: 'A cross. A real one, not a pattern that happens to have arms. And it must hold together at distance.',
      wants: { luminosity: null, device: 'cross', mustUse: null, avoid: null, minContrast: 12 },
      teaches: null
    },
    {
      id: 'c11', patron: 'widow', title: 'The Chantry Chapel', form: 'lancet',
      fee: 426, days: 8, budget: 380,
      brief: 'Violet, for mourning. Dark, but with light coming through it — you will know what I mean when you see it.',
      wants: { luminosity: [0, 45], device: null, mustUse: 'violet', avoid: 'honey', minContrast: 10 },
      teaches: null
    },
    {
      id: 'c12', patron: 'bishop', title: 'The West Window', form: 'rose',
      fee: 560, days: 11, budget: 500,
      brief: 'The west window. It is the last thing I will commission and the first thing anyone will see. Everything you know, glazier.',
      wants: { luminosity: [42, 100], device: 'radial', mustUse: 'cobalt', avoid: null, minPieces: 300, minContrast: 11 },
      teaches: null,
      finale: true
    }
  ];

  /* -------------------------------------------------------------------------------------------
   * SCORING — every clause is measured against the fired window's own statistics.
   * Returns { total, clauses: [{label, got, ok, points, max}], verdict }
   * ----------------------------------------------------------------------------------------- */
  function score(commission, win) {
    const w = commission.wants || {};
    const st = win.stats;
    const clauses = [];

    function clause(label, ok, points, max, got) {
      clauses.push({ label: label, ok: ok, points: Math.round(points), max: max, got: got });
    }

    // --- the form is not scored: it is the hole in the wall and the player cannot change it.

    if (w.luminosity) {
      const [lo, hi] = w.luminosity;
      const L = st.luminosity;
      let p;
      if (L >= lo && L <= hi) p = 25;
      else {
        const miss = L < lo ? lo - L : L - hi;
        p = Math.max(0, 25 - miss * 2.2);       // graceful, not a cliff: near-misses still pay
      }
      clause(L < lo ? 'Too dark for the brief' : L > hi ? 'Brighter than asked' : 'Light as asked',
        p >= 20, p, 25, Math.round(L));
    }

    if (w.device) {
      const ok = win.motif.family === w.device;
      clause(ok ? `A ${w.device} device, as asked` : `Wanted a ${w.device} device, got ${win.motif.family}`,
        ok, ok ? 20 : 0, 20, win.motif.family);
    }

    if (w.mustUse) {
      const share = st.share;
      const isDom = st.dominant === w.mustUse;
      const present = !!st.units[w.mustUse];
      let p = 0;
      if (isDom) p = 22;
      else if (present) p = 9;
      clause(isDom ? `${GLASS[w.mustUse].name} leads the window`
        : present ? `${GLASS[w.mustUse].name} is present but not dominant`
          : `No ${GLASS[w.mustUse].name} in the window at all`,
      isDom, p, 22, isDom ? Math.round(share * 100) + '%' : (present ? 'minor' : 'absent'));
    }

    if (w.avoid) {
      const used = !!st.units[w.avoid];
      clause(used ? `${GLASS[w.avoid].name} was forbidden` : `No ${GLASS[w.avoid].name}, as instructed`,
        !used, used ? -18 : 12, 12, used ? 'used' : 'none');
    }

    if (w.minPieces) {
      const ok = st.pieces >= w.minPieces;
      const p = ok ? 16 : Math.max(0, 16 * (st.pieces / w.minPieces) - 4);
      clause(ok ? `${st.pieces} pieces cut — fine work` : `Only ${st.pieces} pieces; ${w.minPieces} was the mark`,
        ok, p, 16, st.pieces);
    }

    if (w.minContrast) {
      const ok = st.contrast >= w.minContrast;
      const p = ok ? 16 : Math.max(0, 16 * (st.contrast / w.minContrast) - 3);
      clause(ok ? 'Reads clearly at a distance' : 'Flat — figure and field are too alike',
        ok, p, 16, st.contrast.toFixed(1));
    }

    if (w.flourish) {
      const ok = win.flourish === w.flourish;
      clause(ok ? 'Finished as asked' : `Wanted ${w.flourish}, got ${win.flourish}`, ok, ok ? 12 : 0, 12, win.flourish);
    }

    // ⛔ WORKMANSHIP IS SCORED ON EVERY COMMISSION, AND IT EXISTS TO KILL A DOMINANT STRATEGY.
    //
    // MEASURED 2026-08-25 by playtest.js: with only some briefs carrying a piece floor, LEAD
    // DENSITY 1 was strictly dominant. It has no quarry ground, so it cuts a third of the pieces,
    // costs a fifth of the coin and fires in half the days — and it still satisfied most briefs.
    // The thrifty bot chose lead 1 for eleven of twelve windows and finished with 3,318 coin.
    // A control that is always correct is not a decision, it is a dead button (wing §6, and the
    // Brass Orrery's v31 defect is the same shape).
    //
    // The fix is not a coefficient, it is a missing rule: a window with very few pieces IS crude,
    // and every patron in the world would say so. Bands read off the measured piece distribution
    // (p25 ~150, p50 ~260).
    const pcs = st.pieces;
    const wm = pcs >= 220 ? 14 : pcs >= 140 ? 8 : pcs >= 80 ? 2 : -7;
    clause(pcs >= 220 ? 'Finely leaded throughout'
      : pcs >= 140 ? 'Sound workmanship'
        : pcs >= 80 ? 'Coarsely cut for the price' : 'Crude — barely leaded at all',
    wm >= 8, wm, 14, pcs);

    // Budget is always scored, and it is the management half of the game.
    const over = st.cost - commission.budget;
    if (w.thrift) {
      // Guiscard pays for restraint: coming in far under is worth more than coming in just under.
      const frac = st.cost / commission.budget;
      const p = frac <= 0.6 ? 22 : frac <= 0.8 ? 16 : frac <= 1 ? 9 : Math.max(-20, -over / 6);
      clause(frac <= 0.8 ? `Built for ${st.cost} against ${commission.budget} — thrifty`
        : frac <= 1 ? `Inside budget, but only just` : `Over budget by ${over}`,
      frac <= 0.8, p, 22, st.cost);
    } else if (w.lavish) {
      // The crown pays for evident expense; a cheap window is the insult.
      const frac = st.cost / commission.budget;
      const p = frac >= 0.75 ? 18 : Math.max(-10, 18 * (frac / 0.75) - 6);
      clause(frac >= 0.75 ? 'Evidently expensive, as the crown expects' : 'Reads cheap for a royal gift',
        frac >= 0.75, p, 18, st.cost);
    } else {
      const p = over <= 0 ? 14 : Math.max(-25, -over / 5);
      clause(over <= 0 ? `Within budget (${st.cost} of ${commission.budget})` : `Over budget by ${over} coin`,
        over <= 0, p, 14, st.cost);
    }

    let total = 0, max = 0;
    for (const c of clauses) { total += c.points; max += Math.max(0, c.max); }
    const pct = max > 0 ? Math.max(0, Math.min(1, total / max)) : 0;

    const verdict = pct >= 0.92 ? 'A MASTERWORK'
      : pct >= 0.76 ? 'HANDSOMELY DONE'
        : pct >= 0.58 ? 'ACCEPTED'
          : pct >= 0.36 ? 'GRUDGINGLY TAKEN'
            : 'REFUSED';

    // Payment follows the verdict. A refusal still costs the glass — that is the whole risk.
    const payMul = pct >= 0.92 ? 1.35 : pct >= 0.76 ? 1.1 : pct >= 0.58 ? 1.0 : pct >= 0.36 ? 0.6 : 0.15;
    const rep = pct >= 0.92 ? 3 : pct >= 0.76 ? 2 : pct >= 0.58 ? 1 : pct >= 0.36 ? 0 : -2;

    return {
      clauses: clauses,
      total: Math.round(total),
      max: Math.round(max),
      pct: pct,
      verdict: verdict,
      fee: Math.round(commission.fee * payMul),
      reputation: rep
    };
  }

  function patronOf(c) { return PATRONS.find((p) => p.id === c.patron) || PATRONS[0]; }

  root.GW_PATRONS = PATRONS;
  root.GW_COMMISSIONS = COMMISSIONS;
  root.GW_SCORE = score;
  root.GW_PATRON_OF = patronOf;
})(typeof window !== 'undefined' ? window : globalThis);
