/**
 * GLASSWRIGHT — glass palettes.
 *
 * Real medieval glass is not "blue" and "red". It is a small set of metal-oxide colours whose
 * cost and availability drove what a workshop could actually build, and that economic fact is
 * the management game. Each entry carries:
 *
 *   hue/sat/light  — HSL base, so a cell can be varied WITHIN a colour (real glass is streaky;
 *                    flat fills are the single biggest tell that something is vector art, not glass)
 *   cost           — coin per unit. Cobalt and gold-ruby were genuinely dear; green and amber cheap.
 *   name           — what the patron and the ledger call it
 *
 * ⛔ Do not "simplify" these to hex strings. The generator varies lightness and saturation per
 * cell and per streak; it needs the components, not a frozen colour.
 */
(function (root) {
  'use strict';

  // The glass stock. Cost is in coin per unit; a large window eats 12-20 units.
  const GLASS = {
    cobalt:    { name: 'Cobalt',      h: 220, s: 78, l: 34, cost: 9 },
    azure:     { name: 'Azure',       h: 205, s: 70, l: 46, cost: 6 },
    ruby:      { name: 'Gold Ruby',   h: 354, s: 72, l: 38, cost: 12 },
    madder:    { name: 'Madder',      h: 8,   s: 58, l: 42, cost: 5 },
    emerald:   { name: 'Emerald',     h: 152, s: 62, l: 32, cost: 4 },
    verdigris: { name: 'Verdigris',   h: 172, s: 44, l: 44, cost: 4 },
    amber:     { name: 'Amber',       h: 38,  s: 82, l: 50, cost: 3 },
    honey:     { name: 'Honey',       h: 46,  s: 74, l: 58, cost: 3 },
    violet:    { name: 'Violet',      h: 276, s: 46, l: 40, cost: 8 },
    murrey:    { name: 'Murrey',      h: 320, s: 40, l: 34, cost: 7 },
    white:     { name: 'White Glass', h: 44,  s: 16, l: 84, cost: 2 },
    grisaille: { name: 'Grisaille',   h: 70,  s: 12, l: 66, cost: 2 }
  };

  // A PALETTE is a workshop's colour discipline — which glasses it draws on and in what
  // proportion. Historically grounded, and each reads differently at thumbnail size, which is
  // the point (wing doctrine: the bottleneck is EARNING THE CLICK on a 315x250 tile).
  const PALETTES = [
    { id: 'chartres',   name: 'Chartres Blue',    glasses: ['cobalt', 'ruby', 'azure', 'white', 'amber'],        weights: [40, 24, 16, 12, 8] },
    { id: 'canterbury', name: 'Canterbury',       glasses: ['ruby', 'cobalt', 'emerald', 'honey', 'white'],      weights: [32, 26, 18, 14, 10] },
    // ⛔ EVERY PALETTE MUST CONTAIN AT LEAST ONE GLASS BELOW l=42. Measured 2026-08-25 on the
    // first full 53-motif contact sheet: Cistercian Grey and Lenten held nothing darker than
    // l=44, so rolePools() had no dark glass to give the BORDER role, every window drawn in them
    // came out as silver mush with no structure, and ten of fifty-three plates failed Gate 1 for
    // a reason that had nothing to do with their motif. A grisaille window in the real world is
    // silvery BECAUSE a dark accent and dark paint hold it together — take the accent away and
    // you do not get subtlety, you get fog.
    { id: 'grisaillon', name: 'Cistercian Grey',  glasses: ['grisaille', 'white', 'verdigris', 'honey', 'emerald'], weights: [40, 26, 16, 10, 8] },
    { id: 'sainte',     name: 'Sainte Lumiere',   glasses: ['cobalt', 'ruby', 'violet', 'white', 'amber'],       weights: [34, 24, 18, 14, 10] },
    { id: 'marigold',   name: 'Marigold',         glasses: ['amber', 'honey', 'madder', 'white', 'emerald'],     weights: [34, 26, 18, 12, 10] },
    { id: 'seaglass',   name: 'Sea Glass',        glasses: ['verdigris', 'azure', 'emerald', 'white', 'honey'],  weights: [32, 26, 20, 14, 8] },
    { id: 'vesper',     name: 'Vespers',          glasses: ['violet', 'murrey', 'cobalt', 'grisaille', 'amber'], weights: [32, 24, 20, 14, 10] },
    { id: 'martyr',     name: 'Martyrs Red',      glasses: ['ruby', 'madder', 'murrey', 'honey', 'white'],       weights: [38, 24, 16, 12, 10] },
    { id: 'orchard',    name: 'Orchard',          glasses: ['emerald', 'amber', 'madder', 'white', 'verdigris'], weights: [32, 26, 18, 14, 10] },
    { id: 'nocturn',    name: 'Nocturn',          glasses: ['cobalt', 'violet', 'murrey', 'azure', 'white'],     weights: [36, 24, 18, 14, 8] },
    { id: 'reliquary',  name: 'Reliquary',        glasses: ['amber', 'ruby', 'cobalt', 'white', 'honey'],        weights: [30, 26, 22, 12, 10] },
    { id: 'lenten',     name: 'Lenten',           glasses: ['grisaille', 'murrey', 'violet', 'white', 'cobalt'], weights: [38, 24, 20, 12, 6] }
  ];

  root.GW_GLASS = GLASS;
  root.GW_PALETTES = PALETTES;
})(typeof window !== 'undefined' ? window : globalThis);
