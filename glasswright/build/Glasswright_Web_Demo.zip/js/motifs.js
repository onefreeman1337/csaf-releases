/**
 * GLASSWRIGHT — the tracery motifs. THIS FILE IS THE MOAT.
 *
 * ⛔ READ THIS BEFORE EDITING. Wing doctrine (CLAUDE.md §1.1, §10b): the only products this
 * factory has ever sold generate their own artwork from MANY hand-authored motifs — Meridian:
 * 60 motifs x 8 palettes = 480 marks, no PNG anywhere. "An LLM writes skill-tree rules in an
 * afternoon; it does not cheaply produce 60 motifs that cohere. THAT VOLUME IS THE MOAT, and it
 * is the first thing throughput pressure destroys." The same bargain holds here: the tracery
 * count is the product. Deleting motifs to ship faster deletes the reason to buy.
 *
 * A motif is a pure function of (rng) -> array of CELLS, in a unit disc/box centred on (0,0)
 * with radius 1. The window FORM clips them; the palette colours them; the lead draws between
 * them. A motif never picks a colour — it only decides SHAPE and ROLE.
 *
 * ROLES drive colour so a window reads as designed rather than confetti:
 *   'field'  — the background glass, the dominant colour
 *   'figure' — the feature shapes the eye lands on
 *   'border' — the outer band, usually darker, frames the light
 *   'jewel'  — small accents, the brightest/rarest glass
 *
 * ⚠️ Measured trap, wing §0-ART-b and §6: "all N outputs are pixel-distinct" is NOT a proof of
 * variety — it passed 48/48 on 48 identical chess pawns. The only check that answers this is a
 * CONTACT SHEET of every motif rendered at once, looked at. `verify/contact_sheet.js` builds it.
 */
(function (root) {
  'use strict';

  const TAU = Math.PI * 2;

  /* ---------- geometry helpers ---------- */

  const pt = (a, r) => [Math.cos(a) * r, Math.sin(a) * r];

  // An annular sector (a ring segment) as a polygon, with enough steps to read as a curve.
  function arcBand(a0, a1, r0, r1, steps) {
    steps = steps || Math.max(3, Math.ceil(Math.abs(a1 - a0) / 0.22));
    const p = [];
    for (let i = 0; i <= steps; i++) p.push(pt(a0 + (a1 - a0) * (i / steps), r1));
    for (let i = steps; i >= 0; i--) p.push(pt(a0 + (a1 - a0) * (i / steps), r0));
    return p;
  }

  // A circle / regular polygon centred anywhere.
  function disc(cx, cy, r, n) {
    n = n || 24;
    const p = [];
    for (let i = 0; i < n; i++) { const a = (i / n) * TAU; p.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); }
    return p;
  }

  // A cusped foil (trefoil/quatrefoil/cinquefoil...) — the single most recognisably Gothic shape.
  function foil(cx, cy, r, lobes, phase) {
    const p = [];
    const steps = lobes * 18;
    for (let i = 0; i < steps; i++) {
      const a = (i / steps) * TAU;
      // lobed radius: cusps pinch inward between lobes
      const k = 0.72 + 0.28 * Math.abs(Math.cos(lobes * (a - (phase || 0)) / 2));
      p.push([cx + Math.cos(a) * r * k, cy + Math.sin(a) * r * k]);
    }
    return p;
  }

  function star(cx, cy, rOuter, rInner, points, phase) {
    const p = [];
    for (let i = 0; i < points * 2; i++) {
      const a = (i / (points * 2)) * TAU + (phase || 0);
      const r = i % 2 ? rInner : rOuter;
      p.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
    }
    return p;
  }

  const quad = (x0, y0, x1, y1) => [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];

  // Clip helper: keep a polygon only if its centroid is inside the unit disc (forms clip properly
  // later; this just stops motifs wasting cells far outside the glazing).
  function inUnit(poly) {
    let x = 0, y = 0;
    for (const p of poly) { x += p[0]; y += p[1]; }
    x /= poly.length; y /= poly.length;
    return x * x + y * y <= 1.15;
  }

  const cell = (poly, role) => ({ poly, role });

  /* ---------- the motifs ----------
   * Grouped by family so a window's tracery reads as one idea rather than noise. Each is a
   * genuinely different partition of the glazing, not a parameter tweak of its neighbour.
   */
  const M = [];
  const add = (id, name, family, fn) => M.push({ id, name, family, cells: fn });

  /* --- RADIAL family: rose windows, wheels, oculi --- */

  add('wheel-spoke', 'Spoked Wheel', 'radial', (rng) => {
    const n = 8 + 2 * rng.int(0, 4), out = [];
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * TAU, a1 = ((i + 1) / n) * TAU;
      out.push(cell(arcBand(a0 + 0.02, a1 - 0.02, 0.30, 0.86), i % 2 ? 'field' : 'figure'));
    }
    out.push(cell(disc(0, 0, 0.26), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.88, 1.0, 64), 'border'));
    return out;
  });

  add('rose-petal', 'Petalled Rose', 'radial', (rng) => {
    const n = 6 + rng.int(0, 6), out = [];
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      out.push(cell(foil(Math.cos(a) * 0.55, Math.sin(a) * 0.55, 0.30, 3, a), 'figure'));
    }
    for (let i = 0; i < n; i++) {
      const a = ((i + 0.5) / n) * TAU;
      out.push(cell(disc(Math.cos(a) * 0.62, Math.sin(a) * 0.62, 0.11), 'jewel'));
    }
    out.push(cell(foil(0, 0, 0.28, 6), 'figure'));
    out.push(cell(arcBand(0, TAU, 0.86, 1.0, 64), 'border'));
    return out;
  });

  add('double-rose', 'Double Rose', 'radial', (rng) => {
    const n = 8 + 2 * rng.int(0, 3), out = [];
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * TAU, a1 = ((i + 1) / n) * TAU;
      out.push(cell(arcBand(a0 + 0.015, a1 - 0.015, 0.58, 0.85), i % 2 ? 'field' : 'figure'));
      out.push(cell(arcBand(a0 + 0.03, a1 - 0.03, 0.30, 0.54), i % 2 ? 'figure' : 'field'));
    }
    out.push(cell(foil(0, 0, 0.26, 4), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.87, 1.0, 64), 'border'));
    return out;
  });

  add('cusped-oculus', 'Cusped Oculus', 'radial', (rng) => {
    const lobes = 5 + rng.int(0, 6), out = [];
    out.push(cell(foil(0, 0, 0.92, lobes), 'field'));
    out.push(cell(foil(0, 0, 0.60, lobes, Math.PI / lobes), 'figure'));
    out.push(cell(disc(0, 0, 0.24), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  add('star-of-n', 'Star Compass', 'radial', (rng) => {
    const pts = 6 + rng.int(0, 6), out = [];
    out.push(cell(disc(0, 0, 0.95, 48), 'field'));
    out.push(cell(star(0, 0, 0.88, 0.40, pts), 'figure'));
    out.push(cell(star(0, 0, 0.52, 0.22, pts, Math.PI / pts), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  add('whirl', 'Whirling Vane', 'radial', (rng) => {
    const n = 7 + rng.int(0, 6), out = [], skew = 0.55;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      out.push(cell([
        pt(a, 0.22), pt(a + skew, 0.92), pt(a + skew + 0.34, 0.92), pt(a + 0.30, 0.22)
      ], i % 2 ? 'figure' : 'field'));
    }
    out.push(cell(disc(0, 0, 0.20), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  add('concentric-rings', 'Concentric Bands', 'radial', (rng) => {
    const rings = 3 + rng.int(0, 3), out = [];
    for (let r = 0; r < rings; r++) {
      const r0 = 0.16 + (r / rings) * 0.72, r1 = 0.16 + ((r + 1) / rings) * 0.72;
      const n = 6 + r * 4;
      for (let i = 0; i < n; i++) {
        const a0 = (i / n) * TAU, a1 = ((i + 1) / n) * TAU;
        out.push(cell(arcBand(a0 + 0.01, a1 - 0.01, r0, r1 - 0.012), (r + i) % 2 ? 'field' : 'figure'));
      }
    }
    out.push(cell(disc(0, 0, 0.14), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('flamboyant', 'Flamboyant', 'radial', (rng) => {
    const n = 5 + rng.int(0, 4), out = [];
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      const p = [];
      for (let t = 0; t <= 20; t++) {
        const u = t / 20;
        const aa = a + Math.sin(u * Math.PI) * 0.62;
        p.push(pt(aa, 0.18 + u * 0.74));
      }
      for (let t = 20; t >= 0; t--) {
        const u = t / 20;
        const aa = a + Math.sin(u * Math.PI) * 0.62 + 0.40 * (1 - u * 0.5);
        p.push(pt(aa, 0.18 + u * 0.74));
      }
      out.push(cell(p, i % 2 ? 'figure' : 'field'));
    }
    out.push(cell(foil(0, 0, 0.19, 3), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  add('mandorla-ring', 'Mandorla Ring', 'radial', (rng) => {
    const n = 6 + rng.int(0, 4), out = [];
    out.push(cell(disc(0, 0, 0.95, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      const cx = Math.cos(a) * 0.58, cy = Math.sin(a) * 0.58;
      const p = [];
      for (let t = 0; t < 24; t++) {
        const u = (t / 24) * TAU;
        p.push([cx + Math.cos(u) * 0.15, cy + Math.sin(u) * 0.30 * (1 + 0.4 * Math.cos(u))]);
      }
      out.push(cell(p, 'figure'));
    }
    out.push(cell(foil(0, 0, 0.30, 4), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  add('sunburst', 'Sunburst', 'radial', (rng) => {
    const n = 16 + 4 * rng.int(0, 4), out = [];
    out.push(cell(disc(0, 0, 0.95, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * TAU;
      out.push(cell([pt(a0, 0.30), pt(a0 + TAU / n * 0.52, 0.92), pt(a0 - TAU / n * 0.10, 0.92)], 'figure'));
    }
    out.push(cell(disc(0, 0, 0.28), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  /* --- LATTICE family: fields of repeating glass, the cheap-to-glaze workhorses --- */

  add('quarry-diamond', 'Quarry Diamonds', 'lattice', (rng) => {
    const n = 5 + rng.int(0, 4), out = [], s = 2.0 / n;
    for (let i = -n; i <= n; i++) for (let j = -n; j <= n; j++) {
      const cx = i * s + (j % 2 ? s / 2 : 0), cy = j * s * 0.72;
      const p = [[cx, cy - s * 0.42], [cx + s * 0.5, cy], [cx, cy + s * 0.42], [cx - s * 0.5, cy]];
      if (inUnit(p)) out.push(cell(p, (i + j) % 3 === 0 ? 'figure' : 'field'));
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('honeycomb', 'Honeycomb', 'lattice', (rng) => {
    const n = 4 + rng.int(0, 3), out = [], s = 1.05 / n;
    for (let i = -n - 1; i <= n + 1; i++) for (let j = -n - 1; j <= n + 1; j++) {
      const cx = i * s * 1.5, cy = j * s * 1.732 + (i % 2 ? s * 0.866 : 0);
      const p = disc(cx, cy, s * 0.96, 6);
      if (inUnit(p)) out.push(cell(p, (i * 3 + j) % 4 === 0 ? 'figure' : 'field'));
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('chequy', 'Chequy', 'lattice', (rng) => {
    const n = 5 + rng.int(0, 4), out = [], s = 2.0 / n;
    for (let i = -n; i <= n; i++) for (let j = -n; j <= n; j++) {
      const p = quad(i * s, j * s, (i + 1) * s, (j + 1) * s);
      if (inUnit(p)) out.push(cell(p, (i + j) % 2 ? 'figure' : 'field'));
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('imbrication', 'Imbricated Scales', 'lattice', (rng) => {
    const rows = 6 + rng.int(0, 4), out = [], s = 2.0 / rows;
    for (let j = -rows; j <= rows; j++) for (let i = -rows; i <= rows; i++) {
      const cx = i * s + (j % 2 ? s / 2 : 0), cy = j * s * 0.62;
      const p = [];
      for (let t = 0; t <= 14; t++) { const a = Math.PI * (t / 14); p.push([cx - Math.cos(a) * s * 0.52, cy - Math.sin(a) * s * 0.52]); }
      p.push([cx + s * 0.52, cy + s * 0.34]); p.push([cx - s * 0.52, cy + s * 0.34]);
      if (inUnit(p)) out.push(cell(p, (i + j) % 3 === 0 ? 'figure' : 'field'));
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('fret', 'Greek Fret', 'lattice', (rng) => {
    const n = 4 + rng.int(0, 3), out = [], s = 2.0 / n;
    for (let i = -n; i <= n; i++) for (let j = -n; j <= n; j++) {
      const x = i * s, y = j * s;
      const a = quad(x, y, x + s * 0.66, y + s * 0.22);
      const b = quad(x + s * 0.44, y, x + s * 0.66, y + s * 0.66);
      if (inUnit(a)) out.push(cell(a, 'figure'));
      if (inUnit(b)) out.push(cell(b, 'figure'));
      const c = quad(x, y + s * 0.30, x + s * 0.34, y + s * 0.66);
      if (inUnit(c)) out.push(cell(c, 'field'));
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('lozenge-net', 'Lozenge Net', 'lattice', (rng) => {
    const n = 5 + rng.int(0, 4), out = [], s = 2.0 / n;
    for (let i = -n; i <= n; i++) for (let j = -n; j <= n; j++) {
      const cx = i * s, cy = j * s * 0.8;
      const p = [[cx, cy - s * 0.5], [cx + s * 0.34, cy], [cx, cy + s * 0.5], [cx - s * 0.34, cy]];
      if (inUnit(p)) out.push(cell(p, (i + 2 * j) % 4 === 0 ? 'jewel' : ((i + j) % 2 ? 'field' : 'figure')));
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('brickwork', 'Brick Bond', 'lattice', (rng) => {
    const rows = 7 + rng.int(0, 5), out = [], s = 2.0 / rows;
    for (let j = -rows; j <= rows; j++) for (let i = -rows; i <= rows; i++) {
      const x = i * s * 1.6 + (j % 2 ? s * 0.8 : 0);
      const p = quad(x, j * s, x + s * 1.5, j * s + s * 0.86);
      if (inUnit(p)) out.push(cell(p, (i + j) % 5 === 0 ? 'figure' : 'field'));
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('basket-weave', 'Basket Weave', 'lattice', (rng) => {
    const n = 4 + rng.int(0, 3), out = [], s = 2.0 / n;
    for (let i = -n; i <= n; i++) for (let j = -n; j <= n; j++) {
      const x = i * s, y = j * s, horiz = (i + j) % 2 === 0;
      for (let k = 0; k < 2; k++) {
        const p = horiz ? quad(x, y + k * s * 0.5, x + s, y + (k + 1) * s * 0.5)
          : quad(x + k * s * 0.5, y, x + (k + 1) * s * 0.5, y + s);
        if (inUnit(p)) out.push(cell(p, k ? 'figure' : 'field'));
      }
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('triangle-field', 'Triangle Field', 'lattice', (rng) => {
    const n = 5 + rng.int(0, 4), out = [], s = 2.0 / n;
    for (let i = -n; i <= n; i++) for (let j = -n; j <= n; j++) {
      const x = i * s, y = j * s;
      const up = [[x, y + s], [x + s, y + s], [x + s / 2, y]];
      const dn = [[x + s / 2, y], [x + s * 1.5, y], [x + s, y + s]];
      if (inUnit(up)) out.push(cell(up, (i + j) % 2 ? 'field' : 'figure'));
      if (inUnit(dn)) out.push(cell(dn, (i + j) % 2 ? 'figure' : 'field'));
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('pinwheel-tile', 'Pinwheel Tiles', 'lattice', (rng) => {
    const n = 4 + rng.int(0, 3), out = [], s = 2.0 / n;
    for (let i = -n; i <= n; i++) for (let j = -n; j <= n; j++) {
      const x = i * s, y = j * s, m = s / 2;
      const c = [[x + m, y + m]];
      const corners = [[x, y], [x + s, y], [x + s, y + s], [x, y + s]];
      for (let k = 0; k < 4; k++) {
        const p = [c[0], corners[k], corners[(k + 1) % 4]];
        if (inUnit(p)) out.push(cell(p, k % 2 ? 'field' : 'figure'));
      }
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  /* --- MEDALLION family: the narrative shape — panels set in a field --- */

  add('medallion-column', 'Medallion Column', 'medallion', (rng) => {
    const n = 3 + rng.int(0, 3), out = [];
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const cy = -0.72 + (i + 0.5) * (1.44 / n);
      out.push(cell(foil(0, cy, 0.34, 4), 'figure'));
      out.push(cell(disc(0, cy, 0.13), 'jewel'));
    }
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  add('medallion-grid', 'Medallion Grid', 'medallion', (rng) => {
    const n = 2 + rng.int(0, 2), out = [];
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) for (let j = 0; j < n + 1; j++) {
      const cx = -0.62 + (i + 0.5) * (1.24 / n), cy = -0.78 + (j + 0.5) * (1.56 / (n + 1));
      out.push(cell(foil(cx, cy, 0.26, 4), 'figure'));
      out.push(cell(disc(cx, cy, 0.09), 'jewel'));
    }
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  add('vesica-stack', 'Vesica Stack', 'medallion', (rng) => {
    const n = 3 + rng.int(0, 2), out = [];
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const cy = -0.70 + (i + 0.5) * (1.40 / n), p = [];
      for (let t = 0; t < 28; t++) {
        const u = (t / 28) * TAU;
        p.push([Math.cos(u) * 0.30, cy + Math.sin(u) * 0.42 * (1 + 0.28 * Math.cos(u))]);
      }
      out.push(cell(p, 'figure'));
      out.push(cell(disc(0, cy, 0.11), 'jewel'));
    }
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  add('canopy-niche', 'Canopy Niches', 'medallion', (rng) => {
    const n = 2 + rng.int(0, 2), out = [];
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const cy = -0.62 + (i + 0.5) * (1.30 / n), w = 0.36;
      const p = [[-w, cy + 0.34], [-w, cy - 0.10]];
      for (let t = 0; t <= 12; t++) { const a = Math.PI * (t / 12); p.push([-Math.cos(a) * w, cy - 0.10 - Math.sin(a) * 0.30]); }
      p.push([w, cy + 0.34]);
      out.push(cell(p, 'figure'));
      out.push(cell(quad(-w * 0.42, cy + 0.02, w * 0.42, cy + 0.30), 'jewel'));
    }
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  add('roundel-scatter', 'Scattered Roundels', 'medallion', (rng) => {
    const n = 5 + rng.int(0, 5), out = [];
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const a = rng.next() * TAU, r = Math.sqrt(rng.next()) * 0.66;
      const rr = 0.14 + rng.next() * 0.14;
      out.push(cell(disc(Math.cos(a) * r, Math.sin(a) * r, rr, 20), 'figure'));
      out.push(cell(disc(Math.cos(a) * r, Math.sin(a) * r, rr * 0.36, 14), 'jewel'));
    }
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  add('shield-panel', 'Armorial Shields', 'medallion', (rng) => {
    const n = 3 + rng.int(0, 3), out = [];
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU - Math.PI / 2;
      const cx = Math.cos(a) * 0.52, cy = Math.sin(a) * 0.52, w = 0.24;
      const p = [[cx - w, cy - w], [cx + w, cy - w], [cx + w, cy + w * 0.3]];
      for (let t = 0; t <= 10; t++) { const u = t / 10; p.push([cx + w * (1 - 2 * u), cy + w * 0.3 + Math.sin(u * Math.PI) * w * 0.9]); }
      p.push([cx - w, cy + w * 0.3]);
      out.push(cell(p, 'figure'));
      out.push(cell(quad(cx - w * 0.4, cy - w * 0.5, cx + w * 0.4, cy), 'jewel'));
    }
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  /* --- BAND family: horizontal registers, chevrons, ladders --- */

  add('chevron-band', 'Chevron Bands', 'band', (rng) => {
    const rows = 5 + rng.int(0, 5), out = [], h = 2.0 / rows;
    for (let j = 0; j < rows; j++) {
      const y = -1 + j * h, n = 6;
      for (let i = 0; i < n; i++) {
        const x = -1 + (i / n) * 2, w = 2 / n;
        const p = [[x, y + h], [x + w / 2, y], [x + w, y + h], [x + w, y + h * 0.6], [x + w / 2, y + h * 0.35], [x, y + h * 0.6]];
        if (inUnit(p)) out.push(cell(p, (i + j) % 2 ? 'figure' : 'field'));
      }
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('ladder-register', 'Ladder Registers', 'band', (rng) => {
    const rows = 6 + rng.int(0, 6), out = [], h = 2.0 / rows;
    for (let j = 0; j < rows; j++) {
      const y = -1 + j * h;
      const wide = j % 2 === 0;
      const n = wide ? 1 : 5;
      for (let i = 0; i < n; i++) {
        const p = quad(-1 + (i / n) * 2 + 0.01, y + 0.01, -1 + ((i + 1) / n) * 2 - 0.01, y + h - 0.01);
        if (inUnit(p)) out.push(cell(p, wide ? 'figure' : 'field'));
      }
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('zigzag-column', 'Zigzag Columns', 'band', (rng) => {
    const cols = 5 + rng.int(0, 5), out = [], w = 2.0 / cols;
    for (let i = 0; i < cols; i++) {
      const x = -1 + i * w, steps = 8;
      for (let j = 0; j < steps; j++) {
        const y = -1 + (j / steps) * 2, hh = 2 / steps;
        const off = (j % 2 ? w * 0.3 : -w * 0.3);
        const p = [[x + off, y], [x + w + off, y], [x + w - off, y + hh], [x - off, y + hh]];
        if (inUnit(p)) out.push(cell(p, (i + j) % 2 ? 'figure' : 'field'));
      }
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('dagged-border', 'Dagged Border', 'band', (rng) => {
    const out = [], n = 20 + 4 * rng.int(0, 4);
    out.push(cell(disc(0, 0, 0.74, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * TAU, a1 = ((i + 1) / n) * TAU;
      out.push(cell([pt(a0, 0.74), pt((a0 + a1) / 2, 0.98), pt(a1, 0.74)], i % 2 ? 'figure' : 'jewel'));
    }
    out.push(cell(foil(0, 0, 0.44, 6), 'figure'));
    out.push(cell(disc(0, 0, 0.18), 'jewel'));
    return out;
  });

  add('wave-register', 'Wave Registers', 'band', (rng) => {
    const rows = 5 + rng.int(0, 4), out = [], h = 2.0 / rows;
    for (let j = 0; j < rows; j++) {
      const y = -1 + j * h, n = 8;
      for (let i = 0; i < n; i++) {
        const x0 = -1 + (i / n) * 2, x1 = -1 + ((i + 1) / n) * 2;
        const p = [];
        for (let t = 0; t <= 8; t++) { const u = t / 8; p.push([x0 + (x1 - x0) * u, y + Math.sin((i + u) * Math.PI) * h * 0.22]); }
        for (let t = 8; t >= 0; t--) { const u = t / 8; p.push([x0 + (x1 - x0) * u, y + h + Math.sin((i + u) * Math.PI) * h * 0.22]); }
        if (inUnit(p)) out.push(cell(p, (i + j) % 2 ? 'figure' : 'field'));
      }
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  /* --- FOLIATE family: vine, leaf, wheat — the naturalistic glaziers' repertoire --- */

  add('vine-scroll', 'Vine Scroll', 'foliate', (rng) => {
    const out = [], turns = 2.4 + rng.next() * 1.6, n = 90;
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const u = i / n, a = u * TAU * turns, r = 0.16 + u * 0.74;
      const w = 0.055 + 0.03 * Math.sin(u * Math.PI);
      const p = [pt(a, r - w), pt(a + 0.14, r - w), pt(a + 0.14, r + w), pt(a, r + w)];
      out.push(cell(p, 'figure'));
      if (i % 9 === 0) {
        const lp = [];
        for (let t = 0; t < 18; t++) {
          const uu = (t / 18) * TAU;
          const [lx, ly] = pt(a, r + w * 2.4);
          lp.push([lx + Math.cos(uu) * 0.075, ly + Math.sin(uu) * 0.045]);
        }
        out.push(cell(lp, 'jewel'));
      }
    }
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  add('leaf-spray', 'Leaf Spray', 'foliate', (rng) => {
    const n = 5 + rng.int(0, 5), out = [];
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      for (let k = 1; k <= 3; k++) {
        const r = 0.24 * k, p = [];
        for (let t = 0; t < 20; t++) {
          const u = (t / 20) * TAU;
          const [cx, cy] = pt(a, r);
          p.push([cx + Math.cos(u) * 0.16 * Math.cos(a) - Math.sin(u) * 0.07 * Math.sin(a),
                  cy + Math.cos(u) * 0.16 * Math.sin(a) + Math.sin(u) * 0.07 * Math.cos(a)]);
        }
        out.push(cell(p, k === 2 ? 'jewel' : 'figure'));
      }
    }
    out.push(cell(foil(0, 0, 0.16, 3), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  add('wheat-sheaf', 'Wheat Sheaf', 'foliate', (rng) => {
    const n = 9 + rng.int(0, 7), out = [];
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const x = -0.72 + (i / (n - 1)) * 1.44;
      const lean = x * 0.28;
      out.push(cell([[x - 0.035, 0.86], [x + 0.035, 0.86], [x + 0.035 + lean, -0.30], [x - 0.035 + lean, -0.30]], 'figure'));
      for (let k = 0; k < 4; k++) {
        const y = -0.30 - k * 0.14;
        const p = disc(x + lean * (1 + k * 0.1), y, 0.055, 12);
        out.push(cell(p, 'jewel'));
      }
    }
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  add('rosette-field', 'Rosette Field', 'foliate', (rng) => {
    const n = 3 + rng.int(0, 2), out = [], s = 2.0 / n;
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = -n; i <= n; i++) for (let j = -n; j <= n; j++) {
      const cx = i * s * 0.72, cy = j * s * 0.72;
      const p = foil(cx, cy, s * 0.32, 6);
      if (inUnit(p)) { out.push(cell(p, 'figure')); out.push(cell(disc(cx, cy, s * 0.10, 12), 'jewel')); }
    }
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  add('pomegranate', 'Pomegranate', 'foliate', (rng) => {
    const n = 4 + rng.int(0, 4), out = [];
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU, [cx, cy] = pt(a, 0.52);
      const p = [];
      for (let t = 0; t < 26; t++) {
        const u = (t / 26) * TAU;
        p.push([cx + Math.cos(u) * 0.22, cy + Math.sin(u) * 0.26 - (Math.cos(u) > 0.9 ? 0.06 : 0)]);
      }
      out.push(cell(p, 'figure'));
      for (let k = 0; k < 5; k++) {
        const aa = (k / 5) * TAU;
        out.push(cell(disc(cx + Math.cos(aa) * 0.09, cy + Math.sin(aa) * 0.10, 0.045, 10), 'jewel'));
      }
    }
    out.push(cell(foil(0, 0, 0.20, 4), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  add('thorn-ring', 'Crown of Thorns', 'foliate', (rng) => {
    const n = 22 + 2 * rng.int(0, 6), out = [];
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      out.push(cell([pt(a, 0.50), pt(a + 0.10, 0.86), pt(a + 0.20, 0.50)], i % 2 ? 'figure' : 'jewel'));
    }
    out.push(cell(disc(0, 0, 0.44, 32), 'figure'));
    out.push(cell(foil(0, 0, 0.24, 5), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  /* --- CROSS family: the explicitly devotional forms --- */

  add('latin-cross', 'Latin Cross', 'cross', (rng) => {
    const out = [], w = 0.15 + rng.next() * 0.07;
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    out.push(cell(quad(-w, -0.88, w, 0.88), 'figure'));
    out.push(cell(quad(-0.62, -0.40, 0.62, -0.40 + 2 * w), 'figure'));
    out.push(cell(disc(0, -0.40 + w, w * 1.25, 20), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  add('cross-fleury', 'Cross Fleury', 'cross', (rng) => {
    const out = [], w = 0.13;
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let k = 0; k < 4; k++) {
      const a = k * Math.PI / 2;
      const p = [];
      for (let t = 0; t <= 1; t++) p.push([Math.cos(a) * w * (t ? 1 : -1) - Math.sin(a) * w, Math.sin(a) * w * (t ? 1 : -1) + Math.cos(a) * w]);
      out.push(cell([
        [-w, -w], [w, -w],
        [Math.cos(a) * 0.78 + Math.sin(a) * w, Math.sin(a) * 0.78 - Math.cos(a) * w],
        [Math.cos(a) * 0.78 - Math.sin(a) * w, Math.sin(a) * 0.78 + Math.cos(a) * w]
      ], 'figure'));
      out.push(cell(foil(Math.cos(a) * 0.80, Math.sin(a) * 0.80, 0.17, 3, a), 'jewel'));
    }
    out.push(cell(foil(0, 0, 0.20, 4), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  add('greek-cross-quarters', 'Quartered Cross', 'cross', (rng) => {
    const out = [], w = 0.14;
    out.push(cell(quad(-1, -1, -w, -w), 'field'));
    out.push(cell(quad(w, -1, 1, -w), 'figure'));
    out.push(cell(quad(-1, w, -w, 1), 'figure'));
    out.push(cell(quad(w, w, 1, 1), 'field'));
    out.push(cell(quad(-w, -0.92, w, 0.92), 'jewel'));
    out.push(cell(quad(-0.92, -w, 0.92, w), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  add('saltire', 'Saltire', 'cross', (rng) => {
    const out = [], w = 0.13;
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (const s of [1, -1]) {
      out.push(cell([[-0.86 * s, -0.86 + w * 2], [-0.86 * s + w * 2 * s, -0.86], [0.86 * s, 0.86 - w * 2], [0.86 * s - w * 2 * s, 0.86]], 'figure'));
    }
    out.push(cell(foil(0, 0, 0.22, 4), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  /* --- ABSTRACT family: the glazier showing off --- */

  add('interlace-knot', 'Interlace Knot', 'abstract', (rng) => {
    const out = [], n = 5 + rng.int(0, 4), R = 0.62, w = 0.075;
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU, p = [];
      for (let t = 0; t <= 30; t++) {
        const u = (t / 30) * TAU;
        p.push([Math.cos(u) * (R + w) + Math.cos(a) * 0.20, Math.sin(u) * (R + w) + Math.sin(a) * 0.20]);
      }
      for (let t = 30; t >= 0; t--) {
        const u = (t / 30) * TAU;
        p.push([Math.cos(u) * (R - w) + Math.cos(a) * 0.20, Math.sin(u) * (R - w) + Math.sin(a) * 0.20]);
      }
      out.push(cell(p, i % 2 ? 'figure' : 'jewel'));
    }
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  add('nested-squares', 'Nested Squares', 'abstract', (rng) => {
    const rings = 5 + rng.int(0, 4), out = [];
    for (let r = rings; r >= 1; r--) {
      const s = (r / rings) * 0.95;
      const rot = r * 0.22;
      const p = [];
      for (let k = 0; k < 4; k++) { const a = rot + k * Math.PI / 2 + Math.PI / 4; p.push(pt(a, s * 1.414)); }
      out.push(cell(p, r % 3 === 0 ? 'jewel' : (r % 2 ? 'field' : 'figure')));
    }
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  add('radiant-diamond', 'Radiant Diamond', 'abstract', (rng) => {
    const n = 10 + 2 * rng.int(0, 6), out = [];
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * TAU, mid = a0 + TAU / n / 2;
      out.push(cell([pt(a0, 0.18), pt(mid, 0.60), pt(a0 + TAU / n, 0.18), pt(mid, 0.02)], i % 2 ? 'figure' : 'jewel'));
      out.push(cell([pt(a0, 0.62), pt(mid, 0.94), pt(a0 + TAU / n, 0.62), pt(mid, 0.50)], i % 2 ? 'jewel' : 'figure'));
    }
    out.push(cell(arcBand(0, TAU, 0.95, 1.0, 64), 'border'));
    return out;
  });

  add('shatter', 'Shattered Field', 'abstract', (rng) => {
    const out = [], n = 26 + rng.int(0, 18);
    const seeds = [];
    for (let i = 0; i < n; i++) { const a = rng.next() * TAU, r = Math.sqrt(rng.next()) * 0.95; seeds.push([Math.cos(a) * r, Math.sin(a) * r]); }
    // cheap Voronoi-ish: each seed gets a small irregular polygon toward its neighbours
    for (const s of seeds) {
      const p = [], k = 5 + Math.floor(rng.next() * 4);
      for (let i = 0; i < k; i++) {
        const a = (i / k) * TAU + rng.next() * 0.3;
        const rr = 0.10 + rng.next() * 0.13;
        p.push([s[0] + Math.cos(a) * rr, s[1] + Math.sin(a) * rr]);
      }
      out.push(cell(p, rng.next() < 0.18 ? 'jewel' : (rng.next() < 0.5 ? 'field' : 'figure')));
    }
    out.push(cell(arcBand(0, TAU, 0.92, 1.0, 64), 'border'));
    return out;
  });

  add('spiral-arms', 'Spiral Arms', 'abstract', (rng) => {
    const arms = 3 + rng.int(0, 4), out = [], n = 40;
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let k = 0; k < arms; k++) {
      const base = (k / arms) * TAU;
      for (let i = 0; i < n; i++) {
        const u = i / n, a = base + u * 2.4, r = 0.12 + u * 0.80, w = 0.10 * (1 - u * 0.55);
        out.push(cell([pt(a, r - w), pt(a + 0.20, r - w), pt(a + 0.20, r + w), pt(a, r + w)], i % 3 === 0 ? 'jewel' : 'figure'));
      }
    }
    out.push(cell(disc(0, 0, 0.14), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  add('eye-of-light', 'Eye of Light', 'abstract', (rng) => {
    const out = [], rings = 6 + rng.int(0, 4);
    for (let r = rings; r >= 1; r--) {
      const rr = (r / rings) * 0.96;
      out.push(cell(disc(0, 0, rr, 40), r % 3 === 0 ? 'jewel' : (r % 2 ? 'field' : 'figure')));
    }
    const n = 18;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      out.push(cell([pt(a, 0.30), pt(a + 0.06, 0.92), pt(a + 0.12, 0.30)], 'jewel'));
    }
    out.push(cell(arcBand(0, TAU, 0.96, 1.0, 64), 'border'));
    return out;
  });

  add('tears', 'Falling Tears', 'abstract', (rng) => {
    const n = 16 + rng.int(0, 14), out = [];
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const x = -0.85 + rng.next() * 1.70, y = -0.85 + rng.next() * 1.70;
      const s = 0.06 + rng.next() * 0.09, p = [];
      for (let t = 0; t < 20; t++) {
        const u = (t / 20) * TAU;
        p.push([x + Math.sin(u) * s, y - Math.cos(u) * s * (u < Math.PI ? 1.9 : 1.0)]);
      }
      if (inUnit(p)) out.push(cell(p, rng.next() < 0.3 ? 'jewel' : 'figure'));
    }
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  add('keystone-fan', 'Keystone Fan', 'abstract', (rng) => {
    const n = 9 + rng.int(0, 7), out = [], rows = 4;
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let j = 0; j < rows; j++) {
      const r0 = 0.16 + (j / rows) * 0.78, r1 = 0.16 + ((j + 1) / rows) * 0.78;
      for (let i = 0; i < n; i++) {
        const a0 = Math.PI + (i / n) * Math.PI, a1 = Math.PI + ((i + 1) / n) * Math.PI;
        out.push(cell(arcBand(a0 + 0.01, a1 - 0.01, r0, r1 - 0.01), (i + j) % 2 ? 'figure' : 'jewel'));
      }
    }
    out.push(cell(arcBand(0, TAU, 0.93, 1.0, 64), 'border'));
    return out;
  });

  add('lattice-rose', 'Latticed Rose', 'abstract', (rng) => {
    const out = [], n = 12 + 2 * rng.int(0, 5);
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      out.push(cell([pt(a, 0.20), pt(a + TAU / n, 0.20), pt(a + TAU / n * 1.6, 0.90), pt(a + TAU / n * 0.6, 0.90)], i % 2 ? 'figure' : 'field'));
    }
    out.push(cell(foil(0, 0, 0.22, 8), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.94, 1.0, 64), 'border'));
    return out;
  });

  add('compass-quarters', 'Compass Quarters', 'abstract', (rng) => {
    const out = [], rings = 3 + rng.int(0, 3);
    for (let q = 0; q < 4; q++) {
      const a0 = q * Math.PI / 2, a1 = (q + 1) * Math.PI / 2;
      for (let r = 0; r < rings; r++) {
        const r0 = 0.14 + (r / rings) * 0.78, r1 = 0.14 + ((r + 1) / rings) * 0.78;
        out.push(cell(arcBand(a0 + 0.02, a1 - 0.02, r0, r1 - 0.015), (q + r) % 2 ? 'figure' : 'field'));
      }
    }
    out.push(cell(star(0, 0, 0.20, 0.08, 4), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.94, 1.0, 64), 'border'));
    return out;
  });

  add('herringbone', 'Herringbone', 'abstract', (rng) => {
    const n = 6 + rng.int(0, 5), out = [], s = 2.0 / n;
    for (let j = -n; j <= n; j++) for (let i = -n; i <= n; i++) {
      const x = i * s, y = j * s * 0.5, flip = (j % 2 === 0);
      const p = flip ? quad(x, y, x + s, y + s * 0.42) : quad(x, y, x + s * 0.42, y + s);
      if (inUnit(p)) out.push(cell(p, (i + j) % 3 === 0 ? 'jewel' : ((i + j) % 2 ? 'field' : 'figure')));
    }
    out.push(cell(arcBand(0, TAU, 0.90, 1.0, 64), 'border'));
    return out;
  });

  add('sunwheel-cross', 'Sunwheel', 'abstract', (rng) => {
    const out = [], n = 12 + 4 * rng.int(0, 4), w = 0.10;
    out.push(cell(disc(0, 0, 0.98, 48), 'field'));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      out.push(cell([pt(a - 0.03, 0.24), pt(a + 0.03, 0.24), pt(a + 0.03, 0.92), pt(a - 0.03, 0.92)], 'jewel'));
    }
    out.push(cell(arcBand(0, TAU, 0.52, 0.62, 64), 'figure'));
    out.push(cell(quad(-w, -0.92, w, 0.92), 'figure'));
    out.push(cell(quad(-0.92, -w, 0.92, w), 'figure'));
    out.push(cell(disc(0, 0, 0.19), 'jewel'));
    out.push(cell(arcBand(0, TAU, 0.94, 1.0, 64), 'border'));
    return out;
  });

  /* -------------------------------------------------------------------------------------------
   * ⛔ RETIRED MOTIFS — cut from the product, not hidden inside it.
   *
   * The full contact sheet was rendered and looked at on 2026-08-25 (Internal_Ops/renders/
   * contact_motifs.png). Forty-five of the fifty-three read as real windows. These eight did not:
   * they are scattered small shapes with no zone coherence, or grey mush with no structure, and
   * no amount of palette work fixed them because the fault is in the partition itself.
   *
   * They are REMOVED from the exported set rather than left in and quietly avoided. Wing §1.1
   * and the operator's standing instruction: shipping content you have already judged weak is
   * exactly the thing that is not allowed, and "the player probably will not unlock it" is not a
   * defence. Forty-five still clears the 40+ volume floor that makes the pattern book a moat.
   *
   * The code stays in the file on purpose. Each is a candidate for a REWRITE — the idea behind
   * `shatter` and `tears` is good and the execution is not — and a future session should fix and
   * reinstate them rather than re-invent them from nothing.
   * ----------------------------------------------------------------------------------------- */
  const RETIRED = ['shatter', 'roundel-scatter', 'spiral-arms', 'imbrication',
    'lozenge-net', 'chevron-band', 'compass-quarters', 'tears'];

  const SHIPPED = M.filter((m) => RETIRED.indexOf(m.id) < 0);

  root.GW_MOTIFS = SHIPPED;
  root.GW_MOTIFS_ALL = M;          // every motif including the retired ones, for the contact sheet
  root.GW_MOTIFS_RETIRED = RETIRED;
})(typeof window !== 'undefined' ? window : globalThis);
