/**
 * GLASSWRIGHT — the GLAZIER and the PAINTER. This is the product.
 *
 * Two pure stages, deliberately separated:
 *
 *   glaze(spec)          -> a WINDOW: cells with glass, shade and role decided. No drawing.
 *   paint(surface, win)  -> pixels, through a tiny Surface interface.
 *
 * The split is what lets THREE renderers agree: the browser game, the Node contact sheet, and
 * the Node store-capture all call the same glaze() and the same paint(), and differ only in the
 * ~80-line Surface underneath. Wing doctrine, earned by the Brass Orrery: "the gate derives its
 * space from the same function, so game and gate cannot disagree."
 *
 * ⛔ THE ONE RULE THAT MAKES THIS LOOK LIKE GLASS RATHER THAN VECTOR ART:
 *    no two pieces of glass in a real window are the same colour. Medieval glass was blown in
 *    small batches, streaky and uneven, and cut from different sheets. A flat fill per cell is
 *    the single biggest tell that a picture was drawn by a computer. Every cell here gets its
 *    own lightness/saturation jitter AND interior streak bands cut from its own polygon.
 *
 * ⛔ SECOND RULE: cells do NOT get independent random colours. That is confetti. Colour is
 *    assigned by ZONE — a band of radius, a rank of a grid, a role — so the window reads as
 *    something a person designed. The zoning function is chosen by the motif's family.
 */
(function (root) {
  'use strict';

  const TAU = Math.PI * 2;
  const GLASS = root.GW_GLASS;
  const PALETTES = root.GW_PALETTES;

  /* ============================ geometry ============================ */

  function polyArea(p) {
    let a = 0;
    for (let i = 0, n = p.length; i < n; i++) {
      const q = p[(i + 1) % n];
      a += p[i][0] * q[1] - q[0] * p[i][1];
    }
    return Math.abs(a) / 2;
  }

  function centroid(p) {
    let x = 0, y = 0;
    for (const q of p) { x += q[0]; y += q[1]; }
    return [x / p.length, y / p.length];
  }

  // Sutherland-Hodgman against ONE half-plane (nx*x + ny*y <= d). A half-plane is convex, so
  // this is exact for any input polygon that is itself convex, and visually harmless for the
  // mildly concave ones (arc bands, foils) we actually have.
  function clipHalf(poly, nx, ny, d) {
    const out = [];
    const n = poly.length;
    if (!n) return out;
    for (let i = 0; i < n; i++) {
      const a = poly[i], b = poly[(i + 1) % n];
      const da = nx * a[0] + ny * a[1] - d;
      const db = nx * b[0] + ny * b[1] - d;
      const ain = da <= 0, bin = db <= 0;
      if (ain) out.push(a);
      if (ain !== bin) {
        const t = da / (da - db);
        out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
      }
    }
    return out;
  }

  // A band of the polygon between two parallel lines, in direction (dx,dy).
  function band(poly, dx, dy, lo, hi) {
    let p = clipHalf(poly, dx, dy, hi);
    if (p.length < 3) return null;
    p = clipHalf(p, -dx, -dy, -lo);
    return p.length >= 3 ? p : null;
  }

  function pointInPoly(x, y, poly) {
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const xi = poly[i][0], yi = poly[i][1], xj = poly[j][0], yj = poly[j][1];
      if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) inside = !inside;
    }
    return inside;
  }

  /* ============================ colour ============================ */

  // HSL -> RGB, 0..255. Kept local so the product has no colour dependency.
  function hsl(h, s, l) {
    h = ((h % 360) + 360) % 360; s = Math.max(0, Math.min(100, s)) / 100; l = Math.max(0, Math.min(100, l)) / 100;
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = l - c / 2;
    let r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; } else if (h < 120) { r = x; g = c; } else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; } else if (h < 300) { r = x; b = c; } else { r = c; b = x; }
    return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
  }

  function mix(a, b, t) {
    return [Math.round(a[0] + (b[0] - a[0]) * t), Math.round(a[1] + (b[1] - a[1]) * t), Math.round(a[2] + (b[2] - a[2]) * t)];
  }

  /* ============================ the glazier ============================ */

  // Which glasses a role prefers, expressed as a sort over the palette's own glasses. This is
  // what makes twelve palettes read as twelve DESIGNS rather than twelve colour swaps: the
  // border is always the palette's darkest glass, the jewel always its brightest and rarest.
  function rolePools(palette) {
    const list = palette.glasses.map((id, i) => ({ id, g: GLASS[id], w: palette.weights[i] }));
    const byWeight = list.slice().sort((a, b) => b.w - a.w);
    const byLight = list.slice().sort((a, b) => a.g.l - b.g.l);
    // A JEWEL IS RARE FIRST AND BRIGHT SECOND. Sorting on cost alone handed the role to cobalt in
    // every dark palette; then weighting lightness at parity over-corrected and handed it to
    // WHITE GLASS — the cheapest thing on the shelf. On the cover plate the set jewels came out
    // as a ring of grey rivets round the border, which is the opposite of what a cabochon is for.
    // Cost dominates now (x6 against lightness x0.4): in Chartres that is gold ruby at 87 against
    // white at 46, which is the right answer and the historically true one.
    const byJewel = list.slice().sort((a, b) => (b.g.l * 0.4 + b.g.cost * 6) - (a.g.l * 0.4 + a.g.cost * 6));
    return {
      field: byWeight.slice(0, Math.max(2, Math.ceil(list.length / 2))),
      figure: byWeight.slice(0, list.length),
      border: byLight.slice(0, Math.max(2, Math.min(3, list.length))),
      jewel: byJewel.slice(0, Math.max(2, Math.min(3, list.length)))
    };
  }

  // ZONING — the coherence rule. Returns a small integer key for a cell; cells sharing a key
  // share a glass. Chosen by motif family because a grid and a wheel want different logic.
  function zoneKeyFor(family) {
    if (family === 'radial' || family === 'medallion') {
      // concentric rings
      return (c, i) => {
        const [x, y] = c.centre;
        return 'r' + Math.round(Math.sqrt(x * x + y * y) * 7);
      };
    }
    if (family === 'lattice' || family === 'abstract') {
      // diagonal ranks — a grid coloured by ring looks like a mandala, by rank like a weave
      return (c, i) => {
        const [x, y] = c.centre;
        return 'd' + Math.round((x + y) * 4) + '_' + (Math.round((x - y) * 4) & 1);
      };
    }
    if (family === 'band') {
      return (c) => 'y' + Math.round(c.centre[1] * 6);
    }
    // cross, foliate: the role IS the design; vary only by coarse radius so it is not flat
    return (c) => 'q' + Math.round(Math.sqrt(c.centre[0] * c.centre[0] + c.centre[1] * c.centre[1]) * 3);
  }

  /**
   * spec = {
   *   motifId, paletteId, formId,
   *   lead:   1..5   how finely the glazier cuts (came width, quarry ground, subdivision)
   *   flourish: 'none'|'jewels'|'silver-stain'|'rondel'|'grisaille'
   *   tilt:   -2..2  palette weighting: negative favours the cool/cheap glasses, positive the
   *                  dear ones. This is the money decision made visible.
   *   seed:   string|number
   * }
   */
  function glaze(spec) {
    const Rng = root.GWRng;
    const motif = root.GW_MOTIFS.find((m) => m.id === spec.motifId) || root.GW_MOTIFS[0];
    const palette = PALETTES.find((p) => p.id === spec.paletteId) || PALETTES[0];
    const form = root.GW_FORM_BY_ID[spec.formId] || root.GW_FORMS[0];
    const lead = Math.max(1, Math.min(5, spec.lead || 3));
    const flourish = spec.flourish || 'none';
    const tilt = Math.max(-2, Math.min(2, spec.tilt || 0));

    const rng = new Rng(spec.seed === undefined ? 'glasswright' : spec.seed);
    const outline = form.outline();

    // --- 1. lay the tracery, tiled down the light if the form is tall ------------------------
    const raw = [];
    const tiles = form.tiles || 1;
    for (let t = 0; t < tiles; t++) {
      const sub = rng.fork('register' + t);
      const cells = motif.cells(sub);
      // map unit motif space into this register's box inside the form
      const h = 2 / tiles;
      const cy = -1 + h * (t + 0.5);
      const sx = form.w * 0.985;
      const sy = (h / 2) * 0.985;
      for (const c of cells) {
        const poly = c.poly.map((p) => [p[0] * sx, cy + p[1] * sy]);
        // Carry the register's area scale so the sliver cull below can be applied in MOTIF space.
        raw.push({ poly: poly, role: c.role, register: t, scale: sx * sy });
      }
    }

    // --- 2. cull to the form, and measure -----------------------------------------------------
    const cells = [];
    for (const c of raw) {
      const ctr = centroid(c.poly);
      if (!pointInPoly(ctr[0], ctr[1], outline)) continue;
      const area = polyArea(c.poly);
      // ⛔ CULL IN MOTIF SPACE, NOT FORM SPACE. A lancet squeezes the motif to 0.45 x 0.33, an
      // area scale of 0.14 — so a fixed form-space threshold silently deleted almost the whole
      // tracery in every tall form while leaving round forms untouched. Measured on the third
      // contact sheet: four of ten plates rendered as bare quarry ground with no design at all.
      // The threshold is a statement about the MOTIF's own proportions, so it must be applied
      // to the motif's own area.
      if (area / (c.scale || 1) < 0.00018) continue;
      c.centre = ctr; c.area = area;
      cells.push(c);
    }

    // --- 3. QUARRY GROUND: at low lead density the glazier leaves plain diamond panes behind
    //        the tracery. At high density they are small and numerous. This is the single
    //        cheapest way to make a sparse motif read as a real window instead of a diagram.
    const quarry = [];
    if (lead >= 2) {
      // ⛔ THE STEP MUST SCALE WITH THE FORM. An absolute step put four enormous panes across a
      // narrow lancet while the same number filled a rose window correctly — measured on the
      // second contact sheet, where every tall form read as grey wallpaper.
      const step = (0.255 - 0.031 * lead) * Math.min(1, form.w * 1.7);
      // ⛔ A QUARRY LATTICE TILES THE PLANE. Stepping both axes by `step` with half-width
      // diamonds leaves a gap at every other position, and the dark ground showing through those
      // gaps is what produced a hard black-and-grey CHECKERBOARD on four of ten forms — a defect
      // that looks like a deliberate pattern, which is why three sheets went by without me
      // naming it. Offset alternate rows by half a step and advance y by half a step: diamonds
      // then meet edge to edge, which is how leaded quarry glazing is actually set.
      const half = step / 2;
      let row = 0;
      for (let gy = -1.05; gy < 1.06; gy += half, row++) {
        const xoff = (row % 2) ? half : 0;
        for (let gx = -1.05 + xoff; gx < 1.06; gx += step) {
          const d = [[gx, gy - half], [gx + half, gy], [gx, gy + half], [gx - half, gy]];
          const ctr = [gx, gy];
          if (!pointInPoly(ctr[0], ctr[1], outline)) continue;
          quarry.push({ poly: d, role: 'ground', centre: ctr, area: polyArea(d) });
        }
      }
    }

    // --- 4. colour ---------------------------------------------------------------------------
    const pools = rolePools(palette);
    const zoneOf = zoneKeyFor(motif.family);
    const zoneGlass = {};
    const crng = rng.fork('colour');

    // ⛔ ADJACENT ZONES MUST NOT REPEAT A GLASS. Without this the weighted pick keeps returning
    // the palette's dominant colour and a twelve-glass palette renders as two colours — measured
    // on the second contact sheet, where Chartres (cobalt/ruby/azure/white/amber) produced no
    // amber and no azure anywhere in ten plates. Real glaziers alternate bands on purpose; this
    // is that rule, and it costs four lines.
    const lastByRole = {};
    const usedInZone = {};      // zone (WITHOUT role) -> {glassId: true}

    function glassFor(cell, i) {
      const pool = pools[cell.role] || pools.figure;
      const zone = zoneOf(cell, i);
      const key = cell.role + '#' + zone;
      if (zoneGlass[key]) return zoneGlass[key];
      const prev = lastByRole[cell.role];
      const here = usedInZone[zone] || (usedInZone[zone] = {});
      const weights = pool.map((e) => {
        // tilt shifts the pick toward dear glass (+) or cheap glass (-)
        const costBias = 1 + tilt * 0.28 * ((e.g.cost - 6) / 6);
        const repeatPenalty = (e.id === prev) ? 0.18 : 1;
        // ⛔ AND A DIFFERENT ROLE IN THE SAME ZONE MUST NOT REUSE THE GLASS. Measured on the
        //    bench at full size: Spoked Wheel in Chartres Blue came out with figure, field AND
        //    jewel all ruby — a fourteen-piece wheel rendered in two colours, from a
        //    five-glass palette. The per-role anti-repeat could not see it, because each role
        //    was choosing for the first time and so had nothing to repeat. Radial motifs put
        //    every spoke at the SAME radius, so the whole design lives in one zone and the only
        //    thing distinguishing a spoke from its neighbour is its role. If the roles agree on
        //    a colour there is no design left.
        const sameZonePenalty = here[e.id] ? 0.05 : 1;
        return Math.max(0.02, e.w * costBias * repeatPenalty * sameZonePenalty);
      });
      const chosen = crng.weighted(pool, weights);
      zoneGlass[key] = chosen.id;
      lastByRole[cell.role] = chosen.id;
      here[chosen.id] = true;
      return chosen.id;
    }

    // THE QUARRY GROUND IS PLAIN GLASS, AND THAT IS HISTORY AS WELL AS DESIGN. Medieval glaziers
    // filled the ground with white or grisaille diamond panes because colour was expensive — and
    // it is also what makes the coloured tracery read: a ground in a strong glass turns the whole
    // window into wallpaper. Measured on the first contact sheet, where a cobalt ground swallowed
    // seven of ten forms.
    const groundGlass = palette.glasses.indexOf('grisaille') >= 0 ? 'grisaille'
      : palette.glasses.indexOf('white') >= 0 ? 'white'
        : palette.glasses.slice().sort((a, b) => GLASS[b].l - GLASS[a].l)[0];

    function shadeCell(cell, glassId, srng, jitter) {
      const g = GLASS[glassId];
      // Per-piece variation. THIS is the glass tell. Ranges chosen by eye on the contact sheet:
      // below ~4 the window looks printed, above ~12 the design falls apart into noise.
      // ⚠️ The GROUND takes a fraction of it: full jitter on hundreds of small quarry panes
      // reads as a checkerboard, not as glass — measured on the third sheet.
      const k = jitter === undefined ? 1 : jitter;
      const dl = srng.range(-7.5, 7.5) * k;
      const ds = srng.range(-9, 6) * k;
      const dh = srng.range(-4, 4) * k;
      return { h: g.h + dh, s: g.s + ds, l: g.l + dl };
    }

    const srng = rng.fork('shade');
    const painted = [];
    for (const q of quarry) {
      q.glass = groundGlass;
      q.shade = shadeCell(q, groundGlass, srng, 0.35);
      q.shade.l = q.shade.l * 0.62 - 4;               // the ground sits WELL back from the tracery
      q.shade.s *= 0.40;                              // and holds almost no colour
      painted.push(q);
    }
    cells.forEach((c, i) => {
      c.glass = glassFor(c, i);
      c.shade = shadeCell(c, c.glass, srng);
      // The border band is the frame that holds the light in. Darkening it explicitly means a
      // pale palette still gets an edge, rather than dissolving into the stone around it.
      if (c.role === 'border') { c.shade.l -= 9; c.shade.s = Math.min(100, c.shade.s + 6); }
      painted.push(c);
    });

    // --- 5. FLOURISH — the finishing decision, and every one is historically real -------------
    const frng = rng.fork('flourish');
    const extras = [];
    if (flourish === 'jewels') {
      // Cabochon jewels set into the border: small bright discs on the outer band.
      const n = 10 + frng.int(0, 8);
      const jg = pools.jewel[0].id;
      for (let i = 0; i < n; i++) {
        const a = (i / n) * TAU + frng.range(-0.05, 0.05);
        // ⚠️ 0.90 sat ON the glazing edge, and on a cusped form (quatrefoil, trefoil) the outline
        //    pinches to 0.70 between lobes — so most jewels landed outside the window and were
        //    culled. Measured on the finishes plate, where "Set Jewels" was indistinguishable
        //    from "Plain": the flourish the player paid for was simply not there. 0.78 sits
        //    inside every form's narrowest point, and a slightly larger stone reads at
        //    thumbnail size.
        const rr = 0.78;
        const cx = Math.cos(a) * rr * form.w, cy = Math.sin(a) * rr;
        if (!pointInPoly(cx, cy, outline)) continue;
        const rad = 0.040 + frng.range(0, 0.018);
        const p = [];
        for (let k = 0; k < 14; k++) { const t = (k / 14) * TAU; p.push([cx + Math.cos(t) * rad, cy + Math.sin(t) * rad]); }
        extras.push({ poly: p, role: 'jewel', glass: jg, shade: shadeCell({}, jg, frng), centre: [cx, cy], area: polyArea(p), gem: true });
      }
    } else if (flourish === 'rondel') {
      // A crown-glass rondel: the bullseye left in the centre of a spun disc. Concentric rings.
      const rg = pools.jewel[0].id, fg = pools.field[0].id;
      for (let k = 5; k >= 1; k--) {
        const rad = 0.30 * (k / 5);
        const p = [];
        for (let i = 0; i < 40; i++) { const t = (i / 40) * TAU; p.push([Math.cos(t) * rad * form.w, Math.sin(t) * rad]); }
        const gid = k % 2 ? rg : fg;
        extras.push({ poly: p, role: k === 1 ? 'jewel' : 'figure', glass: gid, shade: shadeCell({}, gid, frng), centre: [0, 0], area: polyArea(p) });
      }
    } else if (flourish === 'silver-stain') {
      // Silver stain: a 14th-c. innovation that turns white glass yellow where painted on.
      // Recolour a deterministic third of the lightest cells to honey/amber.
      const targets = painted.filter((c) => GLASS[c.glass] && GLASS[c.glass].l > 60);
      targets.forEach((c, i) => {
        if (i % 3 !== 0) return;
        c.glass = 'honey'; const s = shadeCell(c, 'honey', frng); c.shade = s; c.stained = true;
      });
    }

    // --- 6. GRISAILLE PAINT — the vine tracery painted ON the glass, not cut into it ----------
    // ⛔ PAINT ONLY WHEN THE PLAYER ASKS FOR IT. This used to fire automatically at lead >= 4 as
    // well, and on the bench at full size the loose strands read as CRACKS IN THE GLASS rather
    // than as painted decoration — on a plain spoked wheel it looked like damage. It also quietly
    // stole the Painted Vine finish's only visible effect, which makes a control the player
    // chose mean less than a slider they moved for another reason.
    const paintLines = [];
    if (flourish === 'grisaille') {
      const prng = rng.fork('paint');
      const strands = 9;
      for (let i = 0; i < strands; i++) {
        const a0 = prng.range(0, TAU);
        const line = [];
        let x = Math.cos(a0) * 0.12 * form.w, y = Math.sin(a0) * 0.12;
        let dir = a0;
        for (let k = 0; k < 26; k++) {
          line.push([x, y]);
          dir += prng.range(-0.42, 0.42);
          const st = 0.052;
          x += Math.cos(dir) * st * form.w; y += Math.sin(dir) * st;
          if (!pointInPoly(x, y, outline)) break;
        }
        if (line.length > 4) paintLines.push(line);
      }
    }

    const all = painted.concat(extras);

    // --- 7. derived properties. THE SCORE IS READ OFF THE ARTEFACT, NOT OFF THE MENU. ---------
    let totalArea = 0, lSum = 0, sSum = 0, byGlass = {}, byTracery = {}, traceryArea = 0;
    let figL = 0, figA = 0, fldL = 0, fldA = 0;
    for (const c of all) {
      const a = c.area;
      totalArea += a; lSum += c.shade.l * a; sSum += c.shade.s * a;
      byGlass[c.glass] = (byGlass[c.glass] || 0) + a;
      // ⛔ DOMINANCE IS A CLAIM ABOUT THE DESIGN, SO IT EXCLUDES THE GROUND. The quarry ground is
      // plain grisaille or white and covers more area than anything else, so counting it made
      // grisaille the "dominant" glass of nearly every window — and a patron asking for cobalt
      // first could only be satisfied by dropping the ground entirely. That is not the decision
      // the brief is trying to pose. Cost still counts every piece, because the glazier still
      // buys every piece.
      if (c.role !== 'ground') { byTracery[c.glass] = (byTracery[c.glass] || 0) + a; traceryArea += a; }
      if (c.role === 'figure' || c.role === 'jewel') { figL += c.shade.l * a; figA += a; }
      if (c.role === 'field' || c.role === 'ground') { fldL += c.shade.l * a; fldA += a; }
    }
    const dominant = Object.keys(byTracery).sort((x, y) => byTracery[y] - byTracery[x])[0] || null;
    const luminosity = totalArea ? lSum / totalArea : 0;
    const chroma = totalArea ? sSum / totalArea : 0;
    const contrast = (figA && fldA) ? Math.abs(figL / figA - fldL / fldA) : 0;

    // Cost in coin: glass UNITS by colour, plus lead by total cut length.
    //
    // ⛔ THE SCALE HERE IS MEASURED, NOT CHOSEN. The first version multiplied area by 26 and
    // produced a median window costing ~1,400 coin against commission budgets of 150-700 — so
    // every one of the twelve briefs was unaffordable and solve.js scored the whole game as a
    // near-miss. Read off stats_probe.js and re-tuned so a median rose lands near 190 coin, and
    // units come out as small integers a player can hold in their head: you buy NINE units of
    // cobalt, not two hundred. The stock economy only works at that magnitude.
    let glassCost = 0;
    const units = {};
    for (const gid of Object.keys(byGlass)) {
      const u = Math.max(1, Math.round(byGlass[gid] * 8));
      units[gid] = u;
      glassCost += u * GLASS[gid].cost;
    }
    let cutLength = 0;
    for (const c of all) cutLength += Math.sqrt(c.area) * 4;
    const leadCost = Math.round(cutLength * (0.15 + lead * 0.09));

    return {
      spec: { motifId: motif.id, paletteId: palette.id, formId: form.id, lead: lead, flourish: flourish, tilt: tilt, seed: spec.seed },
      motif: motif, palette: palette, form: form, outline: outline,
      cells: all, paintLines: paintLines, lead: lead, flourish: flourish,
      stats: {
        pieces: all.length,
        tracery: cells.length,
        luminosity: luminosity,
        chroma: chroma,
        contrast: contrast,
        dominant: dominant,
        share: traceryArea ? (byTracery[dominant] || 0) / traceryArea : 0,
        units: units,
        glassCost: glassCost,
        leadCost: leadCost,
        cost: glassCost + leadCost
      }
    };
  }

  /* ============================ the painter ============================ */

  /**
   * paint(surface, win, opts)
   *
   * surface must provide, all in PIXEL coordinates:
   *   fillPoly(pts, rgb, alpha)
   *   strokePoly(pts, widthPx, rgb, alpha, closed)
   *   fillRect(x, y, w, h, rgb, alpha)
   *   radialWash(cx, cy, rInner, rOuter, rgb, aInner, aOuter)
   *
   * opts: {x, y, size, stone: bool, glow: 0..1}
   */
  function paint(surface, win, opts) {
    opts = opts || {};
    const size = opts.size || Math.min(surface.width, surface.height);
    const cx = (opts.x === undefined ? surface.width / 2 : opts.x);
    const cy = (opts.y === undefined ? surface.height / 2 : opts.y);
    const R = size / 2;
    const form = win.form;
    const glowAmt = opts.glow === undefined ? 1 : opts.glow;

    const T = (p) => [cx + p[0] * R, cy + p[1] * R];
    const out = win.outline.map(T);

    // --- stone surround: the window is a hole in a wall, and saying so is most of the effect --
    if (opts.stone !== false) {
      const sw = (form.stone || 0.08) * R;
      // outer reveal, lit from upper-left
      const grown = growPoly(win.outline, form.stone || 0.08).map(T);
      surface.fillPoly(grown, [58, 54, 48], 1);
      const grown2 = growPoly(win.outline, (form.stone || 0.08) * 0.55).map(T);
      surface.fillPoly(grown2, [42, 39, 34], 1);
      // chamfer highlight on the upper-left of the stone
      surface.strokePoly(grown2, Math.max(1, sw * 0.16), [96, 90, 79], 0.55, true);
    }

    // ⛔ EVERYTHING FROM HERE IS CLIPPED TO THE FORM. Culling cells by centroid is NOT clipping:
    //    a quarry pane whose centre is inside a lancet still hangs half its diamond out in the
    //    stonework, which is precisely what the first contact sheet showed on 7 of 10 forms.
    surface.pushClipPoly(out);

    // --- the dark ground behind the glass: unglazed gaps must read as night, not as paper -----
    surface.fillPoly(out, [10, 9, 12], 1);

    // --- glass ---------------------------------------------------------------------------------
    // Light source: slightly above and left of centre, which is where medieval photography and
    // every painting of a window puts it. Cells nearer the source are lifted.
    const lx = -0.30, ly = -0.42;

    // ⛔ THE GROUND IS A SEPARATE PANEL BEHIND THE TRACERY, AND IT IS PAINTED THAT WAY.
    // Drawing every piece in one pass made the quarry ground compete with the design: a bright
    // lozenge grid with its own lead, as loud as the thing it was supposed to sit behind. That
    // is what "the board IS the art" fails as. Ground panes get their own thin lead and are then
    // VEILED, so the tracery is unambiguously in front. Measured over three contact sheets.
    const ground = win.cells.filter((c) => c.role === 'ground');
    const tracery = win.cells.filter((c) => c.role !== 'ground');

    for (const c of ground) {
      const sh = c.shade;
      surface.fillPoly(c.poly.map(T), hsl(sh.h, sh.s, sh.l), 1);
    }
    const groundCame = Math.max(0.8, R * 0.007);
    for (const c of ground) {
      surface.strokePoly(c.poly.map(T), groundCame, [14, 13, 16], 0.75, true);
    }
    surface.fillPoly(out, [10, 10, 18], 0.34);

    for (const c of tracery) {
      const sh = c.shade;
      const d = Math.sqrt((c.centre[0] - lx) * (c.centre[0] - lx) + (c.centre[1] - ly) * (c.centre[1] - ly));
      const lift = (1 - Math.min(1, d / 1.9)) * 9 * glowAmt;
      const base = hsl(sh.h, sh.s, sh.l + lift);
      const pts = c.poly.map(T);
      surface.fillPoly(pts, base, 1);

      // Interior streaks, cut from the cell's own polygon: the reamy, uneven texture of blown
      // glass, and the single strongest "this is glass, not vector art" cue in the renderer.
      //
      // ⛔ THESE NEVER DREW UNTIL 2026-08-25, AND NOTHING CAUGHT IT. The band offsets were
      //    absolute — the loop started 1.4 units from the cell centroid and crept in by about
      //    0.05 per step, so for every cell in the game the band lay entirely OUTSIDE the
      //    polygon and band() returned null three times. Exit codes were clean, the contact
      //    sheet looked plausible at 150px, and the texture I had written a paragraph of comment
      //    about was simply absent. Found by opening the bench at full size and asking why the
      //    glass looked flat, then MEASURING the cell's extent along the streak direction
      //    (-0.997 .. 0.971 against a loop that never got past -1.15).
      //
      //    The offsets are now RELATIVE to the cell's own measured extent, which is the only
      //    thing they could ever have been: cells here range from a tiny quarry pane to a
      //    half-window arc band, so no absolute number can work for both.
      if (c.area > 0.0016 && !c.gem) {
        const seedv = Math.abs(Math.round((c.centre[0] * 733 + c.centre[1] * 941) * 100));
        const dirA = ((seedv % 7) / 7) * Math.PI;
        const dx = Math.cos(dirA), dy = Math.sin(dirA);
        let mn = Infinity, mx = -Infinity;
        for (const p of c.poly) { const q = p[0] * dx + p[1] * dy; if (q < mn) mn = q; if (q > mx) mx = q; }
        const span = mx - mn;
        if (span > 1e-4) {
          const n = 3;
          for (let k = 0; k < n; k++) {
            // Bands sit at uneven fractions of the span so they do not read as stripes.
            const centre = mn + span * (0.16 + 0.30 * k + ((seedv >> (k * 3)) % 5) * 0.028);
            const w = span * (0.045 + ((seedv >> (k * 2)) % 6) * 0.018);
            const b = band(c.poly, dx, dy, centre, centre + w);
            if (b && b.length >= 3) {
              const dl = (k % 2 ? 5.5 : -5.0);
              surface.fillPoly(b.map(T), hsl(sh.h, sh.s * 0.94, sh.l + lift + dl), 0.55);
            }
          }
        }
      }

      // a gem catches a specular chip
      if (c.gem) {
        const g = c.poly.map((p) => T([c.centre[0] + (p[0] - c.centre[0]) * 0.42 - 0.010, c.centre[1] + (p[1] - c.centre[1]) * 0.42 - 0.012]));
        surface.fillPoly(g, hsl(sh.h, Math.max(0, sh.s - 26), Math.min(96, sh.l + 30)), 0.75);
      }
    }

    // --- painted grisaille vine, ON the glass, under the lead ----------------------------------
    for (const line of win.paintLines) {
      surface.strokePoly(line.map(T), Math.max(1, R * 0.011), [30, 28, 24], 0.5, false);
      surface.strokePoly(line.map(T), Math.max(1, R * 0.004), [16, 15, 13], 0.42, false);
    }

    // --- LEAD CAMES, in THREE passes. This is the whole difference between glass and vector art.
    //
    // 1. SHADOW. Glass is thicker and darker where it is held: the came casts a soft dark rim
    //    inward across every piece. Without it each cell is a flat plate of colour and the
    //    window reads as a diagram. Widest, lowest alpha, drawn first.
    // 2. The came itself: dark grey lead, opaque.
    // 3. HALATION. Bright glass bleeds light OVER the came it sits behind — the reason a real
    //    window's lead looks thinner where the light is strong and fat where the glass is dark.
    //    Drawn only for the light pieces, and that asymmetry is the effect.
    const cameW = Math.max(1.05, R * (0.0135 + win.lead * 0.0028));
    // ⚠️ The shadow must be narrow relative to the PIECE, not to the came. A shadow three times
    // the came width swallows a small quarry pane whole, which turned the ground into a hard
    // checkerboard on the third sheet. Small pieces get the narrow pass only.
    const bigEnough = (c) => Math.sqrt(c.area) * R > cameW * 5;
    for (const c of tracery) {
      if (bigEnough(c)) surface.strokePoly(c.poly.map(T), cameW * 3.0, [8, 7, 10], 0.20, true);
    }
    for (const c of tracery) {
      surface.strokePoly(c.poly.map(T), cameW * 1.7, [10, 9, 12], bigEnough(c) ? 0.35 : 0.20, true);
    }
    for (const c of tracery) {
      const pts = c.poly.map(T);
      surface.strokePoly(pts, cameW, [20, 19, 23], 0.96, true);
      surface.strokePoly(pts, Math.max(0.7, cameW * 0.28), [118, 116, 124], 0.28, true);
    }
    for (const c of tracery) {
      const sh = c.shade;
      if (sh.l < 52) continue;                            // only light glass halates
      const t = Math.min(1, (sh.l - 52) / 34);
      surface.strokePoly(c.poly.map(T), cameW * (0.9 + t * 1.4), hsl(sh.h, sh.s * 0.5, 92), 0.10 + t * 0.22, true);
    }

    // --- saddle bars: the iron the panel is tied to. Real, and they sell the scale. ------------
    const bars = form.kind === 'round' || form.kind === 'foil' ? 2 : (form.tiles || 1) + 1;
    for (let i = 1; i <= bars; i++) {
      const y = -1 + (2 * i) / (bars + 1);
      const seg = [];
      for (let t = -1; t <= 1.0001; t += 0.02) {
        if (pointInPoly(t * form.w * 1.02, y, win.outline)) seg.push([t * form.w * 1.02, y]);
      }
      if (seg.length > 3) {
        surface.strokePoly(seg.map(T), Math.max(1.2, R * 0.012), [24, 22, 22], 0.85, false);
        surface.strokePoly(seg.map(T), Math.max(0.6, R * 0.004), [92, 88, 84], 0.35, false);
      }
    }

    // --- the light itself: a wash that makes the glass GLOW rather than sit flat ---------------
    if (glowAmt > 0) {
      surface.radialWash(cx + lx * R * 0.6, cy + ly * R * 0.6, R * 0.05, R * 1.15,
        [255, 246, 214], 0.17 * glowAmt, 0);
      surface.radialWash(cx, cy, R * 0.86, R * 1.6, [8, 8, 14], 0, 0.34 * glowAmt);
    }

    surface.popClip();

    // --- the light thrown BACK onto the stone. Drawn outside the clip, on purpose: a lit window
    //     spills onto the reveal around it, and nothing says "this is a hole in a thick wall"
    //     more cheaply. Subtle by design — at high alpha it reads as a bug.
    if (opts.stone !== false && glowAmt > 0) {
      surface.radialWash(cx, cy, R * 0.98, R * 1.34, [214, 186, 128], 0.14 * glowAmt, 0);
    }
  }

  function dot(p, dx, dy) { return p[0] * dx + p[1] * dy; }

  // Grow a polygon outward from its centroid by a fraction — cheap, stable, and correct enough
  // for a stone surround (a true offset would need mitring and would look no different here).
  function growPoly(poly, amount) {
    const c = centroid(poly);
    return poly.map((p) => {
      const dx = p[0] - c[0], dy = p[1] - c[1];
      const d = Math.sqrt(dx * dx + dy * dy) || 1;
      return [p[0] + (dx / d) * amount, p[1] + (dy / d) * amount];
    });
  }

  root.GW = root.GW || {};
  root.GW.glaze = glaze;
  root.GW.paint = paint;
  root.GW.hsl = hsl;
  root.GW.mix = mix;
  root.GW.polyArea = polyArea;
  root.GW.centroid = centroid;
  root.GW.pointInPoly = pointInPoly;
})(typeof window !== 'undefined' ? window : globalThis);
