/**
 * GLASSWRIGHT — deterministic RNG.
 *
 * Every window in this game must be reproducible from (commission seed + the player's choices)
 * and from nothing else. That is not a purity preference: the gallery re-draws finished windows
 * from their record, the store captures re-draw them offline in Node, and the contact sheet
 * re-draws all 53 motifs — three separate renderers that must agree pixel for pixel.
 *
 * ⛔ Never call Math.random() anywhere in the product. A single unseeded draw makes a shipped
 *    window unreproducible and the gallery starts lying about what the player made.
 *
 * mulberry32 — 32-bit state, well-distributed, ~10 lines. Same stream in browser and in Node.
 */
(function (root) {
  'use strict';

  function GWRng(seed) {
    if (!(this instanceof GWRng)) return new GWRng(seed);
    // Accept a string or a number. Strings are hashed so commission ids can seed directly.
    this.s = (typeof seed === 'string') ? GWRng.hash(seed) : ((seed | 0) >>> 0);
    if (this.s === 0) this.s = 0x9e3779b9;
  }

  // FNV-1a, so a seed string maps to a stable 32-bit value across engines.
  GWRng.hash = function (str) {
    let h = 0x811c9dc5;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 0x01000193) >>> 0;
    }
    return h >>> 0;
  };

  GWRng.prototype.next = function () {
    this.s = (this.s + 0x6D2B79F5) >>> 0;
    let t = this.s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };

  // Inclusive on both ends — the motif file was written against this contract.
  GWRng.prototype.int = function (lo, hi) {
    return lo + Math.floor(this.next() * (hi - lo + 1));
  };

  GWRng.prototype.range = function (lo, hi) { return lo + this.next() * (hi - lo); };

  GWRng.prototype.pick = function (arr) { return arr[this.int(0, arr.length - 1)]; };

  // Weighted pick over parallel arrays. Used for glass selection inside a palette.
  GWRng.prototype.weighted = function (items, weights) {
    let total = 0;
    for (let i = 0; i < weights.length; i++) total += weights[i];
    let r = this.next() * total;
    for (let i = 0; i < items.length; i++) {
      r -= weights[i];
      if (r <= 0) return items[i];
    }
    return items[items.length - 1];
  };

  // A fresh independent stream, derived deterministically. Lets one subsystem draw without
  // shifting another's stream — the defect PROOFMARK paid for (wing Devlog 2026-08-25).
  GWRng.prototype.fork = function (tag) {
    return new GWRng((this.s ^ GWRng.hash(String(tag))) >>> 0);
  };

  root.GWRng = GWRng;
  if (typeof module !== 'undefined' && module.exports) module.exports = { GWRng: GWRng };
})(typeof window !== 'undefined' ? window : globalThis);
