//=============================================================================
// Refectory.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Refectory [4/4] — the scenes, parameters and commands. Your players see the meal their ingredients actually made: a plated dish on a walnut table with a hand-set menu card. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Refectory — the finished dish, plated
 * ============================================================================
 * Load this LAST, after RefectoryRender, RefectoryDish and RefectoryPlate.
 *
 * WHAT IT DOES
 * Whatever your cooking or crafting system makes, Refectory plates it. It
 * reads the ingredients that went into a dish and draws the meal: a service
 * vessel chosen from the kind of dish and how grand it is, a principal
 * component built from the ingredients (a joint with char and fibre, a pie
 * whose filling shows between the lattice, a stew with the chunks that are
 * actually in it), a sauce, garnish set by placement rules, steam if it is
 * hot, and a hand-set menu card naming the dish and listing what went in.
 * Change the ingredients and the picture changes. Nothing is an image file.
 *
 * INSTALL
 * 1. Copy the four .js files into js/plugins and enable them in this order:
 *    RefectoryRender, RefectoryDish, RefectoryPlate, Refectory.
 * 2. Copy the two .woff2 files from fonts/ into your project's fonts/ folder.
 *    (Optional but recommended. Without them the card falls back to Georgia
 *    and a system sans — it never falls back to RPG Maker's own font, and a
 *    missing font can never stop your game from booting.)
 *
 * MAKING AN ITEM A DISH — notetags on the Item
 *   <refectory ingredients: Boar Haunch, Wild Thyme, Coarse Salt>
 *   <refectory: stew>             force the kind of dish (optional)
 *   <refectory vessel: cauldron>  force the vessel (optional)
 *   <refectory quality: 4>        1 plain … 5 a feast (default 2)
 * An item with the notetag but no ingredient list is read from its own name.
 * The dish name matters too: "Woodcutter's Bean Pot" is served in a pot,
 * "Cellar Cheese Board" on a board, "Hunter's Pie" as a pie.
 *
 * THE THREE PLACES PLAYERS MEET FOOD
 *   Cooking result   Plugin command "Serve Dish" after your crafting plugin
 *                    gives the item — or turn on "Plate dishes as they are
 *                    gained" and it happens by itself on the map.
 *   Tavern menu      Plugin command "Open Tavern Menu": a menu card of dishes
 *                    with the selected one plated beside it. Can sell them.
 *   Item detail      Using a dish from the Item menu plates it (on by
 *                    default), and "Show Dish" displays one from an event.
 *
 * SCRIPT
 *   CSAF.Refectory.serve(itemId)        plate a database item
 *   CSAF.Refectory.plate({ name: 'Hunter\'s Pie',
 *                          ingredients: ['Venison', 'Turnip', 'Sage'] })
 *   CSAF.Refectory.read(spec)           the dish profile, for your own UI
 *
 * COMPATIBILITY
 * Adds two scenes. Extends Game_System.prototype.initialize,
 * Scene_Boot.prototype.start, Scene_Item.prototype.useItem,
 * Game_Party.prototype.gainItem and Scene_Map.prototype.update — each by
 * saving the original and calling it. Replaces nothing.
 * ============================================================================
 *
 * @param menuTitle
 * @text Tavern menu heading
 * @desc The heading set at the top of the tavern menu card.
 * @type string
 * @default Tonight's Table
 *
 * @param servedEyebrow
 * @text Served caption
 * @desc The small line above the dish name when a dish is served.
 * @type string
 * @default A dish is served
 *
 * @param continueHint
 * @text Continue hint
 * @desc The quiet line at the foot of the plate. Leave blank for none.
 * @type string
 * @default OK to continue
 *
 * @param currencyUnit
 * @text Price suffix
 * @desc Written after prices on the tavern menu. Blank uses the database currency.
 * @type string
 * @default
 *
 * @param plateOnUse
 * @text Plate a dish when used
 * @desc Using a dish item from the Item menu shows it plated.
 * @type boolean
 * @default true
 *
 * @param autoPlateOnGain
 * @text Plate dishes as they are gained
 * @desc When the party gains a dish on the map (a cooking event, a chest), show it plated.
 * @type boolean
 * @default false
 *
 * @param tableGround
 * @text Table
 * @desc The surface every dish is served on. Walnut is the default.
 * @type select
 * @option Dark walnut
 * @value walnut
 * @option Pale oak
 * @value paleOak
 * @option Dark slate
 * @value darkSlate
 * @option Linen cloth
 * @value linen
 * @default walnut
 *
 * @param tableTint
 * @text Table tint
 * @desc Optional hex colour shifted into the table, for a game with its own palette. Blank leaves it alone.
 * @type string
 * @default
 *
 * @param fontFolder
 * @text Font folder
 * @desc Where the two shipped .woff2 files live, relative to the game root.
 * @type string
 * @default fonts/
 *
 * @command serveDish
 * @text Serve Dish
 * @desc Plate a dish item as a cooking result.
 *
 * @arg itemId
 * @text Dish item
 * @type item
 * @default 0
 *
 * @command showDish
 * @text Show Dish
 * @desc Show a dish item plated, with its description (item detail).
 *
 * @arg itemId
 * @text Dish item
 * @type item
 * @default 0
 *
 * @command openMenu
 * @text Open Tavern Menu
 * @desc Open a menu card of dishes, each plated as it is chosen.
 *
 * @arg itemIds
 * @text Dishes on the menu
 * @desc Leave empty to list every item that carries a refectory notetag.
 * @type item[]
 * @default []
 *
 * @arg title
 * @text Heading
 * @desc Blank uses the plugin parameter.
 * @type string
 * @default
 *
 * @arg sell
 * @text Sell dishes
 * @desc Choosing a dish buys it at its database price, then serves it.
 * @type boolean
 * @default true
 */

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};
var CSAF = globalThis.CSAF;

CSAF.Refectory = (function () {
  'use strict';

  var PLUGIN = 'Refectory';
  var SAVE_VERSION = 1;

  /* ⛔ Siblings at FIRST USE — the harness loads the plugin folder
   * alphabetically (wing §8 trap 2), so `Refectory.js` is parsed FIRST of the
   * four even though it is [4/4]. Nothing below touches a sibling at load. */
  var _R = null; var _D = null; var _P = null;
  function deps() {
    if (!_R) { _R = CSAF.RefectoryRender; _D = CSAF.RefectoryDish; _P = CSAF.RefectoryPlate; }
    if (!_R || !_D || !_P) throw new Error('Refectory: enable RefectoryRender, RefectoryDish and RefectoryPlate too.');
    return _R;
  }

  /**
   * Plugin parameters.
   * ⛔ wing §16: parameters arrive as STRINGS, `Number('')` is 0, and `"0"` is
   * TRUTHY. Nothing here tests a raw parameter for truthiness.
   * @returns {object} Parsed parameters.
   */
  function params() {
    var raw = (typeof PluginManager !== 'undefined' && PluginManager.parameters)
      ? PluginManager.parameters(PLUGIN) : {};
    function str(k, dflt) {
      var v = raw[k];
      return (v === undefined || v === null || String(v).trim() === '') ? dflt : String(v);
    }
    function strAllowBlank(k, dflt) {
      var v = raw[k];
      return (v === undefined || v === null) ? dflt : String(v);
    }
    function bool(k, dflt) {
      var v = raw[k];
      if (v === undefined || v === null || String(v).trim() === '') return dflt;
      return String(v) === 'true';
    }
    return {
      menuTitle: str('menuTitle', "Tonight's Table"),
      servedEyebrow: strAllowBlank('servedEyebrow', 'A dish is served'),
      continueHint: strAllowBlank('continueHint', 'OK to continue'),
      currencyUnit: strAllowBlank('currencyUnit', ''),
      plateOnUse: bool('plateOnUse', true),
      autoPlateOnGain: bool('autoPlateOnGain', false),
      tableGround: str('tableGround', 'walnut'),
      tableTint: str('tableTint', ''),
      fontFolder: str('fontFolder', 'fonts/'),
    };
  }

  /**
   * The ground options both scenes hand to `RefectoryPlate.table`.
   * ⛔ wing §16: a parameter arrives as a STRING and a buyer can type anything
   * into a `@type string`. An unknown ground falls back to walnut rather than
   * drawing nothing, and a malformed tint is DROPPED rather than passed into a
   * colour parser that would keep the previous fill (wing §21c).
   * @returns {object} `{ground, tint}` for `table()`.
   */
  function tableOptions() {
    var p = params();
    var P = CSAF.RefectoryPlate;
    var ground = (P.GROUND_IDS.indexOf(p.tableGround) >= 0) ? p.tableGround : 'walnut';
    var tint = /^#[0-9a-fA-F]{6}$/.test(String(p.tableTint).trim()) ? String(p.tableTint).trim() : null;
    return tint ? { ground: ground, tint: tint } : { ground: ground };
  }

  /**
   * Parse an `@type item[]` argument. ⛔ wing §16: an array parameter is a JSON
   * string of strings; a blank or malformed one is EMPTY, never an error.
   * @param {*} raw The argument as received.
   * @returns {number[]} Positive item ids.
   */
  function parseIdList(raw) {
    var list = raw;
    if (typeof raw === 'string') {
      try { list = raw.trim() ? JSON.parse(raw) : []; } catch (e) { list = []; }
    }
    if (!Array.isArray(list)) return [];
    var out = [];
    for (var i = 0; i < list.length; i++) {
      var n = Number(list[i]);
      if (n > 0 && out.indexOf(n) < 0) out.push(n);
    }
    return out;
  }

  /* ------------------------------------------------------------ save data --
   * ⛔ A VERSIONED, LOSSLESS SCHEMA. How many times each dish has been served
   * is real play history and is saved normally (enumerable). The auto-plate
   * queue is RUNTIME state and lives on $gameTemp, which MZ never saves. */
  function store() {
    if (typeof $gameSystem === 'undefined' || !$gameSystem) return { v: SAVE_VERSION, served: {} };
    if (!$gameSystem._csafRefectory || typeof $gameSystem._csafRefectory !== 'object') {
      $gameSystem._csafRefectory = { v: SAVE_VERSION, served: {} };
    }
    var s = $gameSystem._csafRefectory;
    if (!s.served || typeof s.served !== 'object' || Array.isArray(s.served)) s.served = {};
    if (typeof s.v !== 'number') s.v = SAVE_VERSION;
    return s;
  }

  /** @param {number} itemId @returns {number} times served so far */
  function servedCount(itemId) {
    var n = store().served[String(Number(itemId))];
    return typeof n === 'number' ? n : 0;
  }

  /** @param {number} itemId @returns {number} the new count */
  function markServed(itemId) {
    var id = Number(itemId);
    if (!(id > 0)) return 0;
    var s = store();
    var k = String(id);
    s.served[k] = (typeof s.served[k] === 'number' ? s.served[k] : 0) + 1;
    return s.served[k];
  }

  /** The item database, injectable for the headless suite. */
  var _items = null;
  function items() {
    if (_items) return _items;
    return (typeof $dataItems !== 'undefined' && $dataItems) ? $dataItems : [];
  }
  function _setItemsForTest(list) { _items = list; }

  /** @param {object} item @returns {boolean} whether the buyer marked it a dish */
  function isDish(item) {
    deps();
    return !!(item && _D.fromNote(item.note));
  }

  /**
   * The dish profile for an item id, or null if that item is not a dish.
   * @param {number} itemId A database item id.
   * @returns {object|null} Profile, with `item` attached.
   */
  function dishOf(itemId) {
    deps();
    var item = items()[Number(itemId)];
    var spec = _D.fromItem(item);
    if (!spec) return null;
    var prof = _D.read(spec);
    prof.item = item;
    return prof;
  }

  /**
   * The rows of a tavern menu.
   * @param {number[]} ids Item ids; empty means every dish in the database.
   * @returns {Array<{itemId:number,name:string,price:number,profile:object}>} Rows.
   */
  function menuModel(ids) {
    deps();
    var list = items();
    var want = ids && ids.length ? ids : [];
    if (!want.length) {
      for (var i = 1; i < list.length; i++) if (list[i] && isDish(list[i])) want.push(i);
    }
    var rows = [];
    for (var j = 0; j < want.length; j++) {
      var prof = dishOf(want[j]);
      if (!prof) continue;
      rows.push({ itemId: want[j], name: prof.name, price: Number(prof.item.price) || 0, profile: prof });
    }
    return rows;
  }

  /* --------------------------------------------------------- scene hand-off --
   * What the next plate scene should show. A module slot, set immediately
   * before the push and consumed by the scene's `create`, so no scene is ever
   * built from stale data. */
  var _pending = null;
  var _menuState = { ids: [], title: '', sell: true, index: 0 };

  function requestPlate(profile, mode) {
    _pending = { profile: profile, mode: mode || 'result' };
  }
  function takePending() { var p = _pending; _pending = null; return p; }

  /** Plate a database item as a cooking result. @returns {boolean} pushed */
  function serve(itemId) {
    var prof = dishOf(itemId);
    if (!prof || typeof SceneManager === 'undefined') return false;
    markServed(itemId);
    requestPlate(prof, 'result');
    SceneManager.push(Scene_RefectoryPlate);
    return true;
  }

  /** Show a database item plated with its description. @returns {boolean} pushed */
  function show(itemId) {
    var prof = dishOf(itemId);
    if (!prof || typeof SceneManager === 'undefined') return false;
    requestPlate(prof, 'detail');
    SceneManager.push(Scene_RefectoryPlate);
    return true;
  }

  /** Plate an arbitrary dish that is not in the database. @returns {object} profile */
  function plate(spec) {
    deps();
    var prof = _D.read(spec || {});
    if (typeof SceneManager !== 'undefined') {
      requestPlate(prof, 'result');
      SceneManager.push(Scene_RefectoryPlate);
    }
    return prof;
  }

  function openMenu(ids, title, sell) {
    _menuState.ids = ids || [];
    _menuState.title = title || '';
    _menuState.sell = sell !== false;
    _menuState.index = 0;
    if (typeof SceneManager !== 'undefined') SceneManager.push(Scene_RefectoryMenu);
  }

  /** @param {object} spec @returns {object} a dish profile */
  function read(spec) { deps(); return _D.read(spec || {}); }

  return {
    PLUGIN: PLUGIN,
    SAVE_VERSION: SAVE_VERSION,
    deps: deps,
    params: params,
    tableOptions: tableOptions,
    parseIdList: parseIdList,
    store: store,
    servedCount: servedCount,
    markServed: markServed,
    isDish: isDish,
    dishOf: dishOf,
    menuModel: menuModel,
    requestPlate: requestPlate,
    takePending: takePending,
    menuState: function () { return _menuState; },
    serve: serve,
    show: show,
    plate: plate,
    openMenu: openMenu,
    read: read,
    _setItemsForTest: _setItemsForTest,
  };
})();

/* ==========================================================================
 * ENGINE SEAMS. Every one is a PROTOTYPE EXTENSION with a saved original that
 * is actually CALLED — wing §24c: a saved handle that is never invoked is a
 * replacement with a courtesy handle, and the compatibility block depends on
 * the difference. Names verified against the engine source (wing §8 trap 10):
 * rmmz_objects.js:177, :5641 · rmmz_scenes.js:321, :819, :1745.
 * ========================================================================== */
(function () {
  'use strict';
  if (typeof Game_System === 'undefined') return;      // headless: nothing to patch
  var RF = CSAF.Refectory;

  var _Game_System_initialize = Game_System.prototype.initialize;
  Game_System.prototype.initialize = function () {
    _Game_System_initialize.apply(this, arguments);     // ⛔ forward arguments (§8 trap 7)
    this._csafRefectory = { v: RF.SAVE_VERSION, served: {} };
  };

  /* Fonts start loading at boot, deferred so load order cannot matter (§8/2). */
  var _Scene_Boot_start = Scene_Boot.prototype.start;
  Scene_Boot.prototype.start = function () {
    _Scene_Boot_start.apply(this, arguments);
    try { RF.deps().ensureFonts(RF.params().fontFolder); } catch (e) { /* siblings missing: reported on first use */ }
  };

  /* Item detail: using a dish from the Item menu plates it. */
  var _Scene_Item_useItem = Scene_Item.prototype.useItem;
  Scene_Item.prototype.useItem = function () {
    var item = this.item ? this.item() : null;
    _Scene_Item_useItem.apply(this, arguments);
    if (item && RF.params().plateOnUse && RF.isDish(item)) RF.serve(item.id);
  };

  /* Cooking result, automatically: a dish gained on the map is queued and
   * plated at the next quiet frame. The queue lives on $gameTemp — never
   * saved — so a save taken mid-queue cannot resurrect a plate on load. */
  var _Game_Party_gainItem = Game_Party.prototype.gainItem;
  Game_Party.prototype.gainItem = function (item, amount) {
    _Game_Party_gainItem.apply(this, arguments);
    if (!(Number(amount) > 0) || !item || typeof DataManager === 'undefined' || !DataManager.isItem(item)) return;
    if (!RF.params().autoPlateOnGain || !(SceneManager._scene instanceof Scene_Map)) return;
    if (!RF.isDish(item)) return;
    if (!$gameTemp._csafRefectoryQueue) $gameTemp._csafRefectoryQueue = [];
    $gameTemp._csafRefectoryQueue.push(item.id);
  };

  var _Scene_Map_update = Scene_Map.prototype.update;
  Scene_Map.prototype.update = function () {
    _Scene_Map_update.apply(this, arguments);
    var q = $gameTemp._csafRefectoryQueue;
    /* ⛔ zero allocation on the hot path: one property read per frame when idle */
    if (!q || q.length === 0) return;
    if (SceneManager.isSceneChanging() || $gameMessage.isBusy() || $gamePlayer.isTransferring()) return;
    RF.serve(q.shift());
  };

  if (typeof PluginManager !== 'undefined' && PluginManager.registerCommand) {
    PluginManager.registerCommand('Refectory', 'serveDish', function (args) {
      RF.serve(Number(args.itemId));
    });
    PluginManager.registerCommand('Refectory', 'showDish', function (args) {
      RF.show(Number(args.itemId));
    });
    PluginManager.registerCommand('Refectory', 'openMenu', function (args) {
      RF.openMenu(RF.parseIdList(args.itemIds), String(args.title || ''), String(args.sell) !== 'false');
    });
  }
})();

/* ==========================================================================
 * Scene_RefectoryPlate — the cooking result and the item detail.
 *
 * ⛔ EXTENDS Scene_Base, NOT Scene_MenuBase. Scene_MenuBase brings the engine's
 * own background and a cancel Sprite_Button, and wing §15 is the rule that a
 * `windows: 0` count reports a clean scene while stock buttons sit on it.
 *
 * Four sprites, each baked ONCE in `create`: the table, the plate, the steam
 * and the card. `update` moves them and reads input and allocates nothing.
 * ========================================================================== */
function Scene_RefectoryPlate() { this.initialize.apply(this, arguments); }

if (typeof Scene_Base !== 'undefined') {
  Scene_RefectoryPlate.prototype = Object.create(Scene_Base.prototype);
  Scene_RefectoryPlate.prototype.constructor = Scene_RefectoryPlate;

  Scene_RefectoryPlate.REVEAL = 26;     // frames for the plate to settle
  Scene_RefectoryPlate.CARD_IN = 14;    // frame the card starts sliding
  Scene_RefectoryPlate.CARD_DUR = 22;   // frames the card takes

  Scene_RefectoryPlate.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._t = 0;
    this._cardX = 0;
  };

  Scene_RefectoryPlate.prototype.create = function () {
    Scene_Base.prototype.create.call(this);
    var RF = CSAF.Refectory;
    var R = RF.deps();
    var P = CSAF.RefectoryPlate;
    var job = RF.takePending();
    if (!job) job = { profile: RF.read({ name: 'Dish', ingredients: [] }), mode: 'result' };
    this._profile = job.profile;
    this._mode = job.mode;
    var W = Graphics.width; var H = Graphics.height;
    var g = this.plateGeometry(W, H);
    this._geom = g;

    this._tableSprite = new Sprite(new Bitmap(W, H));
    P.table(this.ctxOf(this._tableSprite.bitmap), 0, 0, W, H, R.hash(this._profile.name), RF.tableOptions());
    this.drawCaption(this.ctxOf(this._tableSprite.bitmap), W, H);
    this.touch(this._tableSprite.bitmap);
    this.addChild(this._tableSprite);

    /* The plate is drawn onto its own transparent bitmap so it can scale in
     * about its own centre: anchor (0.5, 0.5) at the plate centre. */
    this._plateSprite = new Sprite(new Bitmap(W, H));
    this._well = P.plate(this.ctxOf(this._plateSprite.bitmap), this._profile, g, { noSteam: true });
    this.touch(this._plateSprite.bitmap);
    this._plateSprite.anchor.x = g.cx / W;
    this._plateSprite.anchor.y = g.cy / H;
    this._plateSprite.x = g.cx;
    this._plateSprite.y = g.cy;
    this.addChild(this._plateSprite);

    this._steamSprite = new Sprite(new Bitmap(W, H));
    P.steam(this.ctxOf(this._steamSprite.bitmap), this._well, this._profile, R.rngFrom(this._profile.seed), 0);
    this.touch(this._steamSprite.bitmap);
    this.addChild(this._steamSprite);

    var cw = Math.round(Math.min(250, W * 0.28));
    this._cardSprite = new Sprite(new Bitmap(cw + 40, Math.round(H * 0.5)));
    this._cardSize = P.card(this.ctxOf(this._cardSprite.bitmap), this._profile, 14, 10, cw,
      { maxIngredients: 8 });
    this.touch(this._cardSprite.bitmap);
    this._cardHome = Math.round(Math.min(W - cw - 40, g.cx + g.r * 0.62));
    this._cardSprite.x = this._cardHome;
    this._cardSprite.y = Math.round(Math.min(H - this._cardSize.h - 36, g.cy + g.r * 0.18));
    this.addChild(this._cardSprite);

    this.applyReveal(0);
  };

  /**
   * Where the plate sits. The cooking result: left of centre, leaving the card
   * room at the rim.
   * ⛔ THE ITEM DETAIL IS A CLOSE LOOK. MEASURED art stage, 2026-09-10: with
   * the result's geometry the two screens were ONE picture (dedupe d=6 between
   * the GIF and the detail still), and a player inspecting a dish learned
   * nothing the result had not already shown. Inspecting leans in: the plate
   * is DRAWN at 1.4x the result's size by the same renderer (wing §17b — never
   * a magnified bitmap), so every char mark, crumb and glint it knows how to
   * make is on the screen, and the card still sits at the rim.
   * @param {number} W Screen width.
   * @param {number} H Screen height.
   * @returns {{cx:number, cy:number, r:number}}
   */
  Scene_RefectoryPlate.prototype.plateGeometry = function (W, H) {
    if (this._mode === 'detail') {
      return { cx: Math.round(W * 0.46), cy: Math.round(H * 0.63), r: Math.round(Math.min(W, H) * 0.42) };
    }
    return { cx: Math.round(W * 0.43), cy: Math.round(H * 0.55), r: Math.round(Math.min(W, H) * 0.30) };
  };

  Scene_RefectoryPlate.prototype.ctxOf = function (bitmap) {
    return bitmap._context || (bitmap.canvas && bitmap.canvas.getContext('2d'));
  };

  /** Tell PIXI the canvas changed — MZ's own draw methods do this per call. */
  Scene_RefectoryPlate.prototype.touch = function (bitmap) {
    if (bitmap._baseTexture) bitmap._baseTexture.update();
  };

  /** The words at the top of the table: never a window, always our type. */
  Scene_RefectoryPlate.prototype.drawCaption = function (ctx, W, H) {
    var RF = CSAF.Refectory;
    var R = RF.deps();
    var p = RF.params();
    var x = Math.round(W * 0.06);
    var y = Math.round(H * 0.10);
    ctx.save();
    ctx.textBaseline = 'alphabetic';
    ctx.textAlign = 'left';
    var ink = R.P.cream;
    if (this._mode === 'detail') {
      var item = this._profile.item;
      var fit = R.fitText(ctx, this._profile.name, W * 0.62, 'menu', Math.round(H * 0.064), '', 16);
      ctx.font = R.font('menu', fit.px, '');
      ctx.fillStyle = ink;
      ctx.fillText(this._profile.name, x, y + fit.px * 0.5);
      var desc = item && item.description ? String(item.description).replace(/\\[a-zA-Z]+\[\d*\]/g, '') : '';
      if (desc) {
        ctx.font = R.font('note', Math.round(H * 0.028), '');
        ctx.fillStyle = R.rgba(ink, 0.78);
        var lines = R.wrap(ctx, desc, W * 0.52, 3);
        for (var i = 0; i < lines.length; i++) {
          ctx.fillText(lines[i], x, y + fit.px * 0.5 + Math.round(H * 0.05) + i * Math.round(H * 0.038));
        }
      }
    } else {
      if (p.servedEyebrow) {
        ctx.font = R.font('note', Math.round(H * 0.024), '');
        ctx.fillStyle = R.rgba(ink, 0.62);
        ctx.fillText(p.servedEyebrow.toUpperCase().split('').join(' '), x, y - Math.round(H * 0.012));
      }
      var fit2 = R.fitText(ctx, this._profile.name, W * 0.62, 'menu', Math.round(H * 0.07), '', 16);
      ctx.font = R.font('menu', fit2.px, '');
      ctx.fillStyle = ink;
      ctx.fillText(this._profile.name, x, y + fit2.px * 0.72);
    }
    if (p.continueHint) {
      ctx.font = R.font('note', Math.round(H * 0.022), 'italic');
      ctx.fillStyle = R.rgba(ink, 0.45);
      ctx.fillText(p.continueHint, x, H - Math.round(H * 0.05));
    }
    ctx.restore();
  };

  /**
   * Set every animated value for frame `t`. ⛔ wing §15e: the engine's own rAF
   * loop keeps running during a capture, so the scene exposes an EXPLICIT
   * state setter — a capture pins a frame by calling this, never by racing
   * the easing. Zero allocation: numbers in, numbers out.
   * @param {number} t Frame since the scene started.
   */
  Scene_RefectoryPlate.prototype.applyReveal = function (t) {
    var S = Scene_RefectoryPlate;
    var a = Math.min(1, t / S.REVEAL);
    var ease = 1 - (1 - a) * (1 - a) * (1 - a);           // easeOutCubic
    this._plateSprite.opacity = Math.round(255 * ease);
    var s = 0.94 + 0.06 * ease;
    this._plateSprite.scale.x = s;
    this._plateSprite.scale.y = s;
    var c = Math.max(0, Math.min(1, (t - S.CARD_IN) / S.CARD_DUR));
    var ce = 1 - (1 - c) * (1 - c) * (1 - c);
    this._cardSprite.opacity = Math.round(255 * ce);
    this._cardSprite.x = this._cardHome + Math.round(70 * (1 - ce));
    /* steam breathes: rises with the reveal, then pulses gently for ever */
    var breathe = 0.78 + 0.22 * Math.sin(t * 0.045);
    this._steamSprite.opacity = Math.round(255 * ease * breathe);
    this._steamSprite.y = Math.round(-6 * Math.sin(t * 0.03));
  };

  Scene_RefectoryPlate.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    this._t++;
    this.applyReveal(this._t);
    if (this._t < Scene_RefectoryPlate.REVEAL) return;   // let the plate land first
    if (Input.isTriggered('ok') || Input.isTriggered('cancel')
      || TouchInput.isTriggered() || TouchInput.isCancelled()) {
      SoundManager.playCancel();
      this.popScene();
    }
  };
}

/* ==========================================================================
 * Scene_RefectoryMenu — the tavern menu.
 *
 * A bone-paper menu card on the left, the chosen dish plated on the table to
 * its right. The list is ONE bitmap (one draw call however long it is, and it
 * pages rather than growing), redrawn only when the selection changes; the
 * plate is re-baked only when the selection changes. `update` reads input and
 * allocates nothing.
 * ========================================================================== */
function Scene_RefectoryMenu() { this.initialize.apply(this, arguments); }

if (typeof Scene_Base !== 'undefined') {
  Scene_RefectoryMenu.prototype = Object.create(Scene_Base.prototype);
  Scene_RefectoryMenu.prototype.constructor = Scene_RefectoryMenu;

  Scene_RefectoryMenu.ROW_H = 38;

  Scene_RefectoryMenu.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
    this._index = 0;
    this._top = 0;
    this._t = 0;
    this._shownIndex = -1;
  };

  Scene_RefectoryMenu.prototype.create = function () {
    Scene_Base.prototype.create.call(this);
    var RF = CSAF.Refectory;
    var R = RF.deps();
    var st = RF.menuState();
    this._rows = RF.menuModel(st.ids);
    this._sell = st.sell;
    this._title = st.title || RF.params().menuTitle;
    this._index = Math.max(0, Math.min(this._rows.length - 1, st.index || 0));
    var W = Graphics.width; var H = Graphics.height;

    this._tableSprite = new Sprite(new Bitmap(W, H));
    CSAF.RefectoryPlate.table(this.ctxOf(this._tableSprite.bitmap), 0, 0, W, H, R.hash(this._title),
      CSAF.Refectory.tableOptions());
    this.touch(this._tableSprite.bitmap);
    this.addChild(this._tableSprite);

    this._plateSprite = new Sprite(new Bitmap(W, H));
    this.addChild(this._plateSprite);

    this._cardRect = { x: Math.round(W * 0.045), y: Math.round(H * 0.07), w: Math.round(W * 0.40), h: Math.round(H * 0.86) };
    this._listSprite = new Sprite(new Bitmap(this._cardRect.w + 24, this._cardRect.h + 24));
    this._listSprite.x = this._cardRect.x - 8;
    this._listSprite.y = this._cardRect.y - 8;
    this.addChild(this._listSprite);

    this.visibleRows();
    this.refresh();
  };

  Scene_RefectoryMenu.prototype.ctxOf = Scene_RefectoryPlate.prototype.ctxOf;
  Scene_RefectoryMenu.prototype.touch = Scene_RefectoryPlate.prototype.touch;

  /** Rows that fit on the card below its heading. */
  Scene_RefectoryMenu.prototype.visibleRows = function () {
    var head = 92; var foot = 52;
    this._rowsFit = Math.max(1, Math.floor((this._cardRect.h - head - foot) / Scene_RefectoryMenu.ROW_H));
    return this._rowsFit;
  };

  /** Redraw what depends on the selection. Called on CHANGE, never per frame. */
  Scene_RefectoryMenu.prototype.refresh = function () {
    if (this._index < this._top) this._top = this._index;
    if (this._index >= this._top + this._rowsFit) this._top = this._index - this._rowsFit + 1;
    this.drawList();
    if (this._shownIndex !== this._index) {
      this.drawPlate();
      this._shownIndex = this._index;
    }
  };

  Scene_RefectoryMenu.prototype.currencyUnit = function () {
    var u = CSAF.Refectory.params().currencyUnit;
    return u || (typeof TextManager !== 'undefined' ? TextManager.currencyUnit : 'G');
  };

  Scene_RefectoryMenu.prototype.drawList = function () {
    var RF = CSAF.Refectory;
    var R = RF.deps();
    var b = this._listSprite.bitmap;
    var ctx = this.ctxOf(b);
    var c = this._cardRect;
    ctx.clearRect(0, 0, b.width, b.height);
    ctx.save();
    ctx.translate(8, 8);
    /* shadow on the table, then the card */
    ctx.fillStyle = R.rgba(R.P.char, 0.36);
    ctx.fillRect(10, 12, c.w, c.h);
    var g = ctx.createLinearGradient(0, 0, c.w * 0.4, c.h);
    g.addColorStop(0, R.P.cream);
    g.addColorStop(1, R.shade(R.P.cream, -0.08));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, c.w, c.h);
    ctx.strokeStyle = R.rgba(R.shade(R.P.shadow, -0.3), 0.6);
    ctx.lineWidth = 1;
    ctx.strokeRect(0.5, 0.5, c.w - 1, c.h - 1);
    ctx.strokeRect(6.5, 6.5, c.w - 13, c.h - 13);

    var ink = R.P.char;
    var pad = 26;
    ctx.textBaseline = 'alphabetic';
    ctx.textAlign = 'center';
    var fit = R.fitText(ctx, this._title, c.w - pad * 2, 'menu', 34, '', 16);
    ctx.font = R.font('menu', fit.px, '');
    ctx.fillStyle = ink;
    ctx.fillText(this._title, c.w / 2, 30 + fit.px);
    ctx.beginPath();
    ctx.moveTo(c.w * 0.3, 30 + fit.px + 14);
    ctx.lineTo(c.w * 0.7, 30 + fit.px + 14);
    ctx.strokeStyle = R.rgba(ink, 0.5);
    ctx.lineWidth = 0.8;
    ctx.stroke();

    var rowH = Scene_RefectoryMenu.ROW_H;
    var y0 = 92;
    ctx.textAlign = 'left';
    if (!this._rows.length) {
      ctx.font = R.font('note', 16, 'italic');
      ctx.fillStyle = R.rgba(ink, 0.6);
      ctx.fillText('Nothing on the menu tonight.', pad, y0 + 24);
    }
    var end = Math.min(this._rows.length, this._top + this._rowsFit);
    var unit = this.currencyUnit();
    for (var i = this._top; i < end; i++) {
      var row = this._rows[i];
      var y = y0 + (i - this._top) * rowH;
      var sel = i === this._index;
      if (sel) {
        ctx.fillStyle = R.rgba(R.P.roast, 0.20);
        ctx.fillRect(pad - 12, y + 3, c.w - pad * 2 + 24, rowH - 6);
        /* a hand-set lozenge in the margin marks the choice */
        ctx.beginPath();
        ctx.moveTo(pad - 6, y + rowH / 2);
        ctx.lineTo(pad - 2, y + rowH / 2 - 4);
        ctx.lineTo(pad + 2, y + rowH / 2);
        ctx.lineTo(pad - 2, y + rowH / 2 + 4);
        ctx.closePath();
        ctx.fillStyle = R.P.sauce;
        ctx.fill();
      }
      var priceText = this._sell ? String(row.price) + ' ' + unit : '';
      ctx.font = R.font('note', 15, '');
      var pw = priceText ? ctx.measureText(priceText).width : 0;
      var nameMax = c.w - pad * 2 - pw - 26;
      var nf = R.fitText(ctx, row.name, nameMax, 'menu', 21, '', 13);
      ctx.font = R.font('menu', nf.px, '');
      ctx.fillStyle = ink;
      ctx.fillText(row.name, pad + 8, y + rowH * 0.66);
      if (priceText) {
        /* a dotted leader from the name to the price, as a printed menu has */
        var lx0 = pad + 8 + nf.width + 8;
        var lx1 = c.w - pad - pw - 8;
        ctx.fillStyle = R.rgba(ink, 0.35);
        for (var d = lx0; d < lx1; d += 6) ctx.fillRect(d, y + rowH * 0.62, 1.4, 1.4);
        ctx.font = R.font('note', 15, '');
        ctx.fillStyle = R.rgba(ink, 0.85);
        ctx.fillText(priceText, c.w - pad - pw, y + rowH * 0.66);
      }
    }
    /* foot: what the party holds, and whether the list continues */
    ctx.font = R.font('note', 14, 'italic');
    ctx.fillStyle = R.rgba(ink, 0.6);
    if (this._sell && typeof $gameParty !== 'undefined' && $gameParty) {
      ctx.fillText('Purse  ' + $gameParty.gold() + ' ' + unit, pad, c.h - 24);
    }
    if (this._rows.length > this._rowsFit) {
      ctx.textAlign = 'right';
      ctx.fillText((this._index + 1) + ' / ' + this._rows.length, c.w - pad, c.h - 24);
    }
    ctx.restore();
    this.touch(b);
  };

  Scene_RefectoryMenu.prototype.drawPlate = function () {
    var b = this._plateSprite.bitmap;
    var ctx = this.ctxOf(b);
    ctx.clearRect(0, 0, b.width, b.height);
    var row = this._rows[this._index];
    if (row) {
      var W = b.width; var H = b.height;
      var g = { cx: Math.round(W * 0.72), cy: Math.round(H * 0.47), r: Math.round(Math.min(W, H) * 0.25) };
      var P = CSAF.RefectoryPlate;
      P.plate(ctx, row.profile, g, {});
      /* the card is TUCKED AT THE RIM (design brief motif), overlapping the
       * vessel's lower edge — at 0.70 H it floated below it (art stage,
       * in-engine photograph, 2026-09-10) */
      /* ⛔ AT FOUR THIS CARD SAID "and 2 more" WHILE THE RESULT SCENE'S CARD
       * LISTED ALL SIX (art-director defect 7, polish stage 2026-09-11). The
       * motif of the pack is the FULL list and this is the surface a buyer reads
       * longest; the two surfaces cannot disagree about it. Eight, and the card
       * tightens its pitch above six so it still clears the frame. */
      P.card(ctx, row.profile, Math.round(W * 0.57), Math.round(H * 0.595), Math.round(W * 0.26), { maxIngredients: 8 });
    }
    this.touch(b);
  };

  Scene_RefectoryMenu.prototype.move = function (d) {
    if (!this._rows.length) return;
    var n = this._rows.length;
    var next = (this._index + d + n) % n;
    if (next !== this._index) {
      this._index = next;
      SoundManager.playCursor();
      this.refresh();
    }
  };

  Scene_RefectoryMenu.prototype.choose = function () {
    var RF = CSAF.Refectory;
    var row = this._rows[this._index];
    if (!row) { SoundManager.playBuzzer(); return; }
    if (this._sell) {
      if ($gameParty.gold() < row.price) { SoundManager.playBuzzer(); return; }
      $gameParty.loseGold(row.price);
      $gameParty.gainItem(row.profile.item, 1);
      SoundManager.playShop();
    } else {
      SoundManager.playOk();
    }
    RF.menuState().index = this._index;
    RF.serve(row.itemId);
  };

  /** Touch: which row, if any, sits under the pointer. */
  Scene_RefectoryMenu.prototype.rowAt = function (x, y) {
    var c = this._cardRect;
    var ly = y - c.y - 92;
    if (x < c.x || x > c.x + c.w || ly < 0) return -1;
    var r = Math.floor(ly / Scene_RefectoryMenu.ROW_H);
    if (r < 0 || r >= this._rowsFit) return -1;
    var i = this._top + r;
    return i < this._rows.length ? i : -1;
  };

  Scene_RefectoryMenu.prototype.update = function () {
    Scene_Base.prototype.update.call(this);
    this._t++;
    if (SceneManager.isSceneChanging()) return;
    if (Input.isRepeated('down')) this.move(1);
    else if (Input.isRepeated('up')) this.move(-1);
    else if (Input.isTriggered('ok')) this.choose();
    else if (Input.isTriggered('cancel') || TouchInput.isCancelled()) {
      SoundManager.playCancel();
      this.popScene();
    } else if (TouchInput.isTriggered()) {
      var i = this.rowAt(TouchInput.x, TouchInput.y);
      if (i >= 0 && i === this._index) this.choose();
      else if (i >= 0) { this._index = i; SoundManager.playCursor(); this.refresh(); }
    }
  };
}

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.Refectory;
