//=============================================================================
// RefectoryDish.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Refectory [2/4] — the reading. Turns an ingredient list into a dish profile: component, vessel, sauce behaviour, colour, portions, char. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Refectory — the reading
 * ============================================================================
 * Load this SECOND. It defines no scene and patches no core method.
 *
 * This file is the whole argument of the product. A pack of food icons ships a
 * fixed set of pictures; this reads the ingredients the buyer actually wrote
 * and derives what the dish IS — so a boar haunch with thyme and a river trout
 * with lemon do not merely get different labels, they get a different vessel, a
 * different principal mass, a different sauce and a different colour.
 *
 * NOTETAGS (on Items, Weapons, Armors or Events — anything with a note)
 *   <refectory ingredients: Boar Haunch, Wild Thyme, Coarse Salt>
 *   <refectory: stew>            force the component
 *   <refectory vessel: cauldron> force the service vessel
 *   <refectory quality: 3>       1 plain … 5 a feast (default 2)
 *
 * SCRIPT
 *   CSAF.Refectory.plate({ name: 'Hunter\'s Pie',
 *                          ingredients: ['Venison', 'Turnip', 'Sage'] })
 * ============================================================================
 */

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};
var CSAF = globalThis.CSAF;

CSAF.RefectoryDish = (function () {
  'use strict';

  /* ⛔ Siblings at FIRST USE (wing §8 trap 2 — the harness loads the plugin
   * folder ALPHABETICALLY, so this file is parsed before RefectoryRender
   * despite being [2/4]). */
  var _R = null;
  function R() { if (!_R) _R = CSAF.RefectoryRender; return _R; }

  /* ------------------------------------------------------------- the axes --
   * Every ingredient contributes to these and NOTHING else. They are the only
   * bridge between what the buyer typed and what gets drawn, which is why they
   * are declared once, here, and read everywhere. */
  var AXES = ['meat', 'fish', 'green', 'root', 'fungus', 'grain', 'dairy', 'fruit',
    'herb', 'spice', 'liquid', 'sweet', 'fat', 'acid', 'smoke', 'egg', 'arcane'];

  /* ------------------------------------------------------------- the pantry --
   * word → [axes it feeds, local colour, mass]. Deliberately a LEXICON rather
   * than a rule: food words are irregular and a generative guess produces blue
   * meat. Anything not in here is still read (see `unknown()`), it simply gets
   * its properties from its own name instead of from knowledge. */
  var PANTRY = [
    /* --- red meat --------------------------------------------------- */
    ['boar', ['meat', 'fat'], '#8E4433', 1.0], ['pork', ['meat', 'fat'], '#C77E6B', 1.0],
    /* ⛔ `['ox', ...]` USED TO SIT HERE AND COULD NEVER MATCH — `namesWord`
     * refuses a word under three letters on purpose, so the row was declared,
     * typed and unreachable (polish stage, 2026-09-11). Removed rather than
     * left as decoration; `oxtail` and the cut nouns below carry the animal,
     * and `dish.test.js` now fails on any pantry row the matcher cannot reach. */
    ['beef', ['meat'], '#7E3A31', 1.0],
    ['mutton', ['meat', 'fat'], '#8A4436', 1.0], ['lamb', ['meat'], '#9A5747', 0.9],
    ['venison', ['meat', 'smoke'], '#6E3129', 1.0], ['deer', ['meat', 'smoke'], '#6E3129', 1.0],
    ['rabbit', ['meat'], '#B98A6E', 0.7], ['hare', ['meat'], '#A9765C', 0.8],
    ['bear', ['meat', 'fat'], '#5F2C25', 1.2], ['goat', ['meat'], '#8E5340', 0.9],
    ['haunch', ['meat', 'fat'], '#87412F', 1.2], ['ribs', ['meat', 'fat', 'smoke'], '#7B382C', 1.1],
    /* ⛔ THE HEAD NOUN IS THE LAST WORD, AND A CUT IS A NOUN. Without these the
     * head of "Ox Cheek" is `cheek`, which was in no table, and `ox` cannot help
     * because `namesWord` refuses a word under three letters ON PURPOSE
     * (`dish.test.js` asserts that refusal). So the pantry carried a DEAD `ox`
     * row while our own demo database's `Ox Cheek` fell down the unknown path,
     * came back ["root","meat"] and drew a PIE in a cauldron — found at the
     * polish stage, 2026-09-11, by installing the shipped zip and typing a
     * stew a buyer would actually type. A cut noun is how meat is sold. */
    ['cheek', ['meat', 'fat'], '#74352C', 1.1], ['shin', ['meat'], '#7A392F', 1.1],
    ['shank', ['meat', 'fat'], '#804033', 1.2], ['brisket', ['meat', 'fat'], '#883F31', 1.2],
    ['oxtail', ['meat', 'fat'], '#6B2F28', 1.1], ['loin', ['meat'], '#9A5342', 1.0],
    ['chop', ['meat', 'fat'], '#8E4736', 0.9], ['rump', ['meat'], '#82392E', 1.1],
    ['sausage', ['meat', 'fat', 'spice'], '#9E4E39', 0.8], ['bacon', ['meat', 'fat', 'smoke'], '#C06A55', 0.6],
    ['liver', ['meat'], '#5B2A2A', 0.7], ['marrow', ['meat', 'fat'], '#D9B79A', 0.5],
    /* --- fowl ------------------------------------------------------- */
    ['chicken', ['meat'], '#D8A468', 0.8], ['fowl', ['meat'], '#CE9A5F', 0.8],
    ['duck', ['meat', 'fat'], '#A9683F', 0.9], ['goose', ['meat', 'fat'], '#B37546', 1.0],
    ['quail', ['meat'], '#C79463', 0.5], ['pigeon', ['meat'], '#9A6A4A', 0.5],
    /* ⛔ An egg is not dairy. Tagged `dairy`, it pushed `Skillet Eggs and Bacon`
     * into the cheese-board branch (MEASURED by `_probe/why.js`, 2026-09-10). */
    ['pheasant', ['meat', 'smoke'], '#B27B4C', 0.9], ['egg', ['egg'], '#F2D98C', 0.4],
    /* --- water ------------------------------------------------------ */
    ['fish', ['fish'], '#C9CBB4', 0.8], ['trout', ['fish'], '#C7B7A2', 0.8],
    ['salmon', ['fish', 'fat'], '#E08A62', 0.9], ['carp', ['fish'], '#BDBBA0', 0.8],
    ['eel', ['fish', 'smoke'], '#6F6A55', 0.8], ['cod', ['fish'], '#E2DCC8', 0.8],
    ['crab', ['fish'], '#D2603F', 0.7], ['shrimp', ['fish'], '#E58A65', 0.5],
    ['prawn', ['fish'], '#E58A65', 0.5], ['clam', ['fish'], '#D8CBB0', 0.5],
    ['oyster', ['fish'], '#CFC6AE', 0.5], ['squid', ['fish'], '#E6DED0', 0.7],
    ['roe', ['fish', 'fat'], '#E07A45', 0.3], ['seaweed', ['green', 'fish'], '#4C5F3B', 0.3],
    /* --- roots and vegetables --------------------------------------- */
    ['turnip', ['root'], '#E4DFCB', 0.6], ['carrot', ['root', 'sweet'], '#D97F32', 0.5],
    ['potato', ['root', 'grain'], '#DCC79A', 0.7], ['parsnip', ['root', 'sweet'], '#E7DDBE', 0.5],
    ['beet', ['root', 'sweet'], '#7A2740', 0.5], ['radish', ['root', 'acid'], '#C8465A', 0.3],
    /* ⛔ Alliums are savoury. Tagged `sweet`, one onion turned `Ale-Braised Ox
     * Cheek` into a CAKE (MEASURED 2026-09-10). */
    ['onion', ['root'], '#E3D5C0', 0.5], ['leek', ['green', 'root'], '#9FB871', 0.4],
    ['garlic', ['spice', 'root'], '#EDE3D1', 0.2], ['shallot', ['root'], '#C9A08C', 0.3],
    ['cabbage', ['green'], '#8FA86A', 0.6], ['kale', ['green'], '#4F6F3A', 0.4],
    ['lettuce', ['green'], '#A7C177', 0.3], ['cress', ['green', 'herb'], '#6E8C46', 0.2],
    ['pea', ['green', 'sweet'], '#7FA24C', 0.3], ['bean', ['green', 'grain'], '#A98C55', 0.45],
    ['lentil', ['grain'], '#B07A4E', 0.45], ['pumpkin', ['root', 'sweet'], '#D98A31', 0.9],
    ['gourd', ['root'], '#C9A24E', 0.8], ['squash', ['root', 'sweet'], '#D9973E', 0.8],
    ['mushroom', ['fungus'], '#B49A78', 0.4], ['truffle', ['fungus', 'spice'], '#4A3A2E', 0.2],
    ['morel', ['fungus'], '#8C6A4A', 0.3], ['cap', ['fungus'], '#A98A66', 0.3],
    /* --- grain and bread -------------------------------------------- */
    ['flour', ['grain'], '#EBE0C8', 0.6], ['bread', ['grain'], '#C79B5E', 0.8],
    ['loaf', ['grain'], '#C1934F', 0.9], ['dough', ['grain'], '#E5D4B0', 0.7],
    ['oat', ['grain'], '#D8C69B', 0.5], ['barley', ['grain'], '#CBB37F', 0.5],
    ['wheat', ['grain'], '#D6BE86', 0.5], ['rice', ['grain'], '#EFE9D8', 0.5],
    ['noodle', ['grain'], '#E7D49A', 0.6], ['pastry', ['grain', 'fat'], '#DCB878', 0.6],
    ['crust', ['grain'], '#C79B5E', 0.5], ['rye', ['grain'], '#9E7A4C', 0.6],
    /* --- dairy ------------------------------------------------------ */
    ['cheese', ['dairy', 'fat'], '#E0C066', 0.6], ['curd', ['dairy'], '#F0E6D2', 0.4],
    ['milk', ['dairy', 'liquid'], '#F4EFE2', 0.5], ['cream', ['dairy', 'fat', 'liquid'], '#F2E6CC', 0.5],
    ['butter', ['dairy', 'fat'], '#EFCE72', 0.3],
    /* --- fruit ------------------------------------------------------ */
    ['apple', ['fruit', 'acid', 'sweet'], '#B33A32', 0.5], ['pear', ['fruit', 'sweet'], '#C8C066', 0.5],
    ['plum', ['fruit', 'sweet'], '#5E3357', 0.4], ['fig', ['fruit', 'sweet'], '#6B3B4A', 0.4],
    ['berry', ['fruit', 'acid', 'sweet'], '#7A2743', 0.3], ['grape', ['fruit', 'sweet'], '#5D3E62', 0.3],
    ['cherry', ['fruit', 'acid', 'sweet'], '#94263A', 0.3], ['lemon', ['fruit', 'acid'], '#E4C64A', 0.3],
    ['orange', ['fruit', 'acid', 'sweet'], '#DE8A2E', 0.4], ['peach', ['fruit', 'sweet'], '#E8A96E', 0.4],
    ['apricot', ['fruit', 'sweet'], '#E0964A', 0.3], ['currant', ['fruit', 'acid'], '#6E2436', 0.2],
    ['date', ['fruit', 'sweet'], '#6E452C', 0.3], ['quince', ['fruit', 'acid', 'sweet'], '#D8B64A', 0.4],
    /* --- herb and spice --------------------------------------------- */
    ['thyme', ['herb'], '#5E7F3A', 0.1], ['sage', ['herb'], '#7A8C68', 0.1],
    ['rosemary', ['herb'], '#4F6E3E', 0.1], ['parsley', ['herb'], '#4E7E33', 0.1],
    ['mint', ['herb'], '#5C9159', 0.1], ['bay', ['herb'], '#4A6438', 0.1],
    ['dill', ['herb'], '#6E9147', 0.1], ['chive', ['herb', 'root'], '#5C8340', 0.1],
    ['basil', ['herb'], '#4C7C3A', 0.1], ['salt', ['spice'], '#F4F0E6', 0.05],
    ['pepper', ['spice'], '#3B322A', 0.05], ['clove', ['spice'], '#5A3A26', 0.05],
    ['cinnamon', ['spice', 'sweet'], '#8E5327', 0.05], ['saffron', ['spice'], '#E0952A', 0.05],
    ['ginger', ['spice'], '#D2A65E', 0.15], ['mustard', ['spice', 'acid'], '#D6B03A', 0.1],
    ['nutmeg', ['spice', 'sweet'], '#7A5433', 0.05], ['cumin', ['spice'], '#9A6B33', 0.05],
    ['paprika', ['spice'], '#B84A2A', 0.05], ['chilli', ['spice'], '#B02A22', 0.05],
    ['seed', ['spice', 'grain'], '#B79A62', 0.1], ['nut', ['spice', 'fat'], '#A87B4E', 0.2],
    /* --- liquid ----------------------------------------------------- */
    ['broth', ['liquid'], '#B98341', 0.8], ['stock', ['liquid'], '#B4823F', 0.8],
    /* ⛔ Water carries volume but NO colour. At mass 0.6 it tinted a rye loaf
     * sage-green through the blend in `read()` — MEASURED by spread_check on the
     * demo database, 2026-09-10, and invisible to every other instrument here. */
    ['water', ['liquid'], '#C9D2CE', 0.22], ['wine', ['liquid', 'acid'], '#6B2338', 0.6],
    ['ale', ['liquid', 'sweet'], '#A96A22', 0.6], ['mead', ['liquid', 'sweet'], '#D6A032', 0.6],
    ['cider', ['liquid', 'acid', 'sweet'], '#C68B2C', 0.6], ['vinegar', ['liquid', 'acid'], '#C2A05A', 0.2],
    ['oil', ['liquid', 'fat'], '#C9A63E', 0.2], ['honey', ['sweet', 'liquid'], '#DFA326', 0.3],
    ['syrup', ['sweet', 'liquid'], '#8E5A1E', 0.3], ['sugar', ['sweet'], '#F3EEE0', 0.2],
    ['jam', ['sweet', 'fruit'], '#8C2B36', 0.4], ['smoke', ['smoke'], '#4A3F36', 0.1],
    /* --- the fantastical -------------------------------------------- */
    ['mana', ['arcane', 'liquid'], '#4C6FA8', 0.4], ['ember', ['arcane', 'smoke'], '#C64C1E', 0.3],
    ['frost', ['arcane'], '#A8C6D2', 0.3], ['slime', ['arcane'], '#6EA85C', 0.5],
    ['dragon', ['meat', 'arcane', 'smoke'], '#7A3A46', 1.3], ['wyvern', ['meat', 'arcane'], '#6E4048', 1.2],
    ['griffin', ['meat', 'arcane'], '#A87A52', 1.1], ['moon', ['arcane', 'sweet'], '#C9C2D8', 0.3],
    ['star', ['arcane'], '#D9CE8E', 0.2], ['spirit', ['arcane', 'liquid'], '#8E9CC2', 0.3],
    ['glow', ['arcane'], '#C8D26E', 0.2], ['void', ['arcane'], '#3A3348', 0.4],
  ];

  /* --------------------------------------------------------- the components --
   * 20 principal components. Each declares the vessels that make sense for it,
   * ORDERED, plus its own wetness and heat. ⛔ wing §21i: a decision tree that
   * returns one answer per branch is how a 320-plate corpus collapses to five
   * pictures in a buyer's project, so the vessel is chosen by an INDEX into
   * this list derived from magnitude and wetness, not by the branch. */
  /* ⛔ EACH LIST IS ORDERED HUMBLEST → GRANDEST, AND THE ORDER IS THE MEANING.
   * wing §21i's fix for a classifier that returns one answer per branch is to
   * throw small, standard and great versions of each job as DIFFERENT FORMS,
   * with magnitude computed ONCE. MEASURED 2026-09-10: with a hash choosing the
   * vessel, four correctly-classified roasts all landed on a trencher; indexed
   * by magnitude, a ration comes wrapped in cloth and a feast comes on a
   * platter — which is also what a player expects to see. */
  var COMPONENTS = {
    roast: { vessels: ['trencher', 'board', 'stoneSlab', 'platter'], wet: 0.15, heat: 0.9, name: 'roast' },
    fillet: { vessels: ['leafWrap', 'board', 'stoneSlab', 'platter'], wet: 0.25, heat: 0.7, name: 'fillet' },
    stew: { vessels: ['breadBowl', 'bowl', 'cauldron', 'tureen'], wet: 0.85, heat: 0.95, name: 'stew' },
    /* not a trencher: a trencher IS bread, and a loaf on bread photographed as a
     * bun in a bun (2026-09-10) */
    loaf: { vessels: ['clothBundle', 'board', 'tray', 'stoneSlab'], wet: 0.05, heat: 0.4, name: 'loaf' },
    soup: { vessels: ['cup', 'breadBowl', 'bowl', 'tureen'], wet: 1.0, heat: 0.9, name: 'soup' },
    pie: { vessels: ['skillet', 'board', 'tray', 'pieDish'], wet: 0.3, heat: 0.8, name: 'pie' },
    salad: { vessels: ['leafWrap', 'trencher', 'bowl', 'platter'], wet: 0.2, heat: 0.0, name: 'salad' },
    skewers: { vessels: ['stoneSlab', 'tray', 'platter', 'skewerRack'], wet: 0.2, heat: 0.85, name: 'skewers' },
    porridge: { vessels: ['cup', 'skillet', 'bowl', 'cauldron'], wet: 0.7, heat: 0.8, name: 'porridge' },
    /* ⛔ No tankard. MEASURED at product size, art stage 2026-09-10: `Morel
     * Broth` indexed into a pewter tankard and read as a pint of beer — the
     * same defect as a drink in a tureen, the other way round. */
    broth: { vessels: ['cup', 'bowl', 'tureen'], wet: 1.0, heat: 0.85, name: 'broth' },
    jerky: { vessels: ['clothBundle', 'stoneSlab', 'board', 'tray'], wet: 0.0, heat: 0.0, name: 'dried' },
    cake: { vessels: ['clothBundle', 'tray', 'pieDish', 'platter'], wet: 0.2, heat: 0.2, name: 'cake' },
    pastry: { vessels: ['clothBundle', 'leafWrap', 'board', 'tray'], wet: 0.1, heat: 0.4, name: 'pastry' },
    dumplings: { vessels: ['leafWrap', 'skillet', 'bowl', 'tray'], wet: 0.5, heat: 0.85, name: 'dumplings' },
    noodles: { vessels: ['bowl', 'breadBowl', 'platter', 'tureen'], wet: 0.6, heat: 0.8, name: 'noodles' },
    eggs: { vessels: ['cup', 'skillet', 'trencher', 'board'], wet: 0.35, heat: 0.75, name: 'eggs' },
    cheeseboard: { vessels: ['trencher', 'stoneSlab', 'board', 'tray'], wet: 0.05, heat: 0.0, name: 'board' },
    fruit: { vessels: ['leafWrap', 'bowl', 'tray', 'platter'], wet: 0.15, heat: 0.0, name: 'fruit' },
    /* ⛔ A preserve is served IN ITS JAR, set on something. MEASURED at product
     * size, art stage 2026-09-10: in a cup or a bowl the jam was drawn as a
     * liquid surface and `Bramble Berry Preserve` read as a cup of tea. Every
     * vessel here is flat, so the plate draws the jar standing on it. */
    preserves: { vessels: ['clothBundle', 'board', 'stoneSlab', 'tray'], wet: 0.55, heat: 0.0, name: 'preserve' },
    /* ⛔ Three vessels, not four. A drink served in a tureen reads as soup on
     * the contact sheet (MEASURED 2026-09-10) — the list is what is plausible,
     * never padded to a tidy length. The DECLARED list is the union; which part
     * of it a drink may use is decided by what is in it (DRINK_BREWED below). */
    drink: { vessels: ['tankard', 'cup', 'bowl'], wet: 1.0, heat: 0.35, name: 'draught' },
  };
  var COMPONENT_IDS = Object.keys(COMPONENTS);

  /* ⛔ THE VESSEL OF A DRINK IS A FACT ABOUT WHAT IS IN IT, NOT ABOUT HOW GRAND
   * IT IS. MEASURED at product size, art stage 2026-09-10: indexed by magnitude,
   * `Tavern Brown Ale` landed in a porcelain TEACUP and its head of foam read as
   * a latte. Anything brewed is poured into a tankard; a tea, a cordial, a
   * tonic or a potion goes in a cup, or a bowl when it is a feast's. */
  var BREWED = ['ale', 'beer', 'mead', 'cider', 'stout', 'porter', 'lager', 'grog', 'perry'];
  var DRINK_BREWED = ['tankard'];
  var DRINK_STILL = ['cup', 'bowl'];

  /**
   * Only ever asked of a dish already read as a DRINK, so "Ale-Braised Ox
   * Cheek" (a stew) never reaches it.
   * @param {Array<object>} ings Read ingredients.
   * @param {string} name The dish name.
   * @returns {boolean} whether an ingredient's HEAD noun, or a word of the
   * name's head clause, is a brewed drink. The name is read too because a
   * buyer's "Dwarven Stout" may list only barley and water — and several of
   * these words are not pantry words, so no ingredient can carry them as a head.
   */
  function isBrewed(ings, name) {
    for (var i = 0; i < ings.length; i++) {
      if (BREWED.indexOf(String(ings[i].head || '')) >= 0) return true;
    }
    var words = String(name || '').split(ACCOMPANIMENT)[0].toLowerCase().split(/[^a-z]+/);
    for (var j = 0; j < words.length; j++) {
      if (BREWED.indexOf(words[j]) >= 0) return true;
    }
    return false;
  }

  /* 16 service vessels. `deep` drives how much of the food is hidden in it. */
  var VESSELS = {
    bowl: { deep: 0.75, wood: false, name: 'bowl' },
    board: { deep: 0.0, wood: true, name: 'board' },
    trencher: { deep: 0.12, wood: false, name: 'trencher' },
    skillet: { deep: 0.30, wood: false, name: 'skillet' },
    tureen: { deep: 0.80, wood: false, name: 'tureen' },
    platter: { deep: 0.10, wood: false, name: 'platter' },
    skewerRack: { deep: 0.0, wood: true, name: 'rack' },
    cup: { deep: 0.85, wood: false, name: 'cup' },
    pieDish: { deep: 0.45, wood: false, name: 'dish' },
    cauldron: { deep: 0.85, wood: false, name: 'cauldron' },
    leafWrap: { deep: 0.20, wood: false, name: 'leaf' },
    breadBowl: { deep: 0.60, wood: false, name: 'bread bowl' },
    tankard: { deep: 0.90, wood: false, name: 'tankard' },
    tray: { deep: 0.05, wood: true, name: 'tray' },
    clothBundle: { deep: 0.25, wood: false, name: 'cloth' },
    stoneSlab: { deep: 0.0, wood: false, name: 'slab' },
  };
  var VESSEL_IDS = Object.keys(VESSELS);

  /* 10 sauce and garnish behaviours, each with the axis that earns it. */
  var BEHAVIOURS = {
    jus: { axis: 'fat', pooled: 0.8, gloss: 0.7, garnish: 'crackedPepper', name: 'jus' },
    gremolata: { axis: 'acid', pooled: 0.2, gloss: 0.3, garnish: 'zest', name: 'gremolata' },
    glaze: { axis: 'sweet', pooled: 0.25, gloss: 0.95, garnish: 'seed', name: 'glaze' },
    dusting: { axis: 'spice', pooled: 0.0, gloss: 0.15, garnish: 'dust', name: 'dusting' },
    charOil: { axis: 'smoke', pooled: 0.45, gloss: 0.6, garnish: 'charFleck', name: 'burnt oil' },
    herbOil: { axis: 'herb', pooled: 0.5, gloss: 0.65, garnish: 'herbLeaf', name: 'herb oil' },
    brothPool: { axis: 'liquid', pooled: 1.0, gloss: 0.45, garnish: 'herbLeaf', name: 'broth' },
    crumb: { axis: 'grain', pooled: 0.0, gloss: 0.1, garnish: 'crumb', name: 'crumb' },
    cream: { axis: 'dairy', pooled: 0.6, gloss: 0.5, garnish: 'herbLeaf', name: 'cream' },
    bare: { axis: null, pooled: 0.0, gloss: 0.2, garnish: 'none', name: 'plain' },
  };
  var BEHAVIOUR_IDS = Object.keys(BEHAVIOURS);

  /* Words in a dish NAME that name its component outright. The buyer's own
   * title is the strongest signal there is and ignoring it is how a "Hunter's
   * Pie" comes out as a stew. */
  var NAME_WORDS = {
    roast: 'roast', roasted: 'roast', joint: 'roast', haunch: 'roast', spit: 'roast',
    grill: 'roast', grilled: 'roast', steak: 'fillet', fillet: 'fillet', filet: 'fillet',
    cutlet: 'fillet', escalope: 'fillet', stew: 'stew', ragout: 'stew', goulash: 'stew',
    casserole: 'stew', hotpot: 'stew', pottage: 'stew', braised: 'stew', braise: 'stew',
    bread: 'loaf', loaf: 'loaf', hardtack: 'loaf', biscuit: 'loaf', cracker: 'loaf',
    flatbread: 'loaf', bannock: 'loaf', baked: 'roast',
    bun: 'loaf', roll: 'loaf', soup: 'soup', bisque: 'soup', chowder: 'soup',
    pie: 'pie', tart: 'pie', pasty: 'pie', quiche: 'pie', salad: 'salad', slaw: 'salad',
    greens: 'salad', skewer: 'skewers', skewers: 'skewers', kebab: 'skewers',
    brochette: 'skewers', porridge: 'porridge', gruel: 'porridge', pudding: 'porridge',
    risotto: 'porridge', broth: 'broth', consomme: 'broth', bouillon: 'broth',
    jerky: 'jerky', dried: 'jerky', cured: 'jerky', smoked: 'jerky', biltong: 'jerky', cake: 'cake',
    gateau: 'cake', sponge: 'cake', pastry: 'pastry', pastries: 'pastry', croissant: 'pastry',
    scone: 'pastry', turnover: 'pastry', dumpling: 'dumplings', dumplings: 'dumplings',
    ravioli: 'dumplings', gyoza: 'dumplings', noodle: 'noodles', noodles: 'noodles',
    pasta: 'noodles', spaghetti: 'noodles', omelette: 'eggs', omelet: 'eggs',
    scramble: 'eggs', frittata: 'eggs', eggs: 'eggs', cheese: 'cheeseboard',
    fruit: 'fruit', compote: 'fruit', jam: 'preserves', preserve: 'preserves',
    preserves: 'preserves', pickle: 'preserves', conserve: 'preserves', ale: 'drink',
    wine: 'drink', mead: 'drink', cider: 'drink', tea: 'drink', draught: 'drink',
    cordial: 'drink', tonic: 'drink', brew: 'drink',
  };

  /* Words in a dish NAME that name its VESSEL. "Woodcutter's Bean Pot", "Cellar
   * Cheese Board", "Crab Legs on Stone" — the buyer has already said what it is
   * served in, and reading that is derivation, not decoration. */
  var VESSEL_WORDS = {
    bowl: 'bowl', board: 'board', trencher: 'trencher', skillet: 'skillet', pan: 'skillet',
    tureen: 'tureen', platter: 'platter', rack: 'skewerRack', cup: 'cup', mug: 'tankard',
    tankard: 'tankard', flagon: 'tankard', stein: 'tankard', cauldron: 'cauldron', pot: 'cauldron',
    kettle: 'cauldron', leaf: 'leafWrap', wrap: 'leafWrap', bundle: 'clothBundle',
    parcel: 'clothBundle', tray: 'tray', slab: 'stoneSlab', stone: 'stoneSlab', slate: 'stoneSlab',
  };

  /* Words that introduce what the dish is served WITH, IN or ON. Everything
   * after the first of these is an accompaniment or a vessel, never the dish:
   * `Long Noodles in Broth` is noodles, `Oat Porridge with Cream` is porridge. */
  var ACCOMPANIMENT = /\s(with|in|on|over|and\s+a|au|a\s+la)\s/i;

  /* --------------------------------------------------------------- matching --
   * ⛔ wing §21f-5 / §12.10: a substring matcher INVENTS territory (`ward`
   * matched 18 rows, 4 were real) and a bad pattern fails in the direction that
   * looks like diligence. Word boundaries, escaped literals, one plural rule,
   * and both controls in the suite: phantoms it must REJECT, targets it must
   * ACCEPT. */
  function esc(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  /**
   * Does `text` name `word`, as a word rather than as a fragment?
   * @param {string} text Haystack.
   * @param {string} word Needle, 3+ characters.
   * @returns {boolean} True on a real mention.
   */
  function namesWord(text, word) {
    var w = String(word || '').trim();
    if (w.length < 3) return false;             // too short to be safe: refuse, never guess
    var re = new RegExp('(^|[^a-z0-9])' + esc(w.toLowerCase()) + '(e?s)?([^a-z0-9]|$)', 'i');
    return re.test(String(text || '').toLowerCase());
  }

  /** Properties for a word the pantry does not know. */
  function unknown(word) {
    var r = R();
    var h = r.hash('ingredient:' + String(word).toLowerCase());
    var rng = r.rngFrom(h);
    /* ⛔ A hashed colour must stay in a FOOD gamut or an unknown ingredient
     * paints the plate blue. Warm browns through greens through creams only. */
    var hues = ['#8E5A3A', '#B0763F', '#C79B5E', '#6E7F45', '#8C9A5E', '#D8C69B', '#A8543A', '#5F6E4A'];
    var pool = ['meat', 'root', 'green', 'grain', 'herb', 'fungus', 'fruit'];
    var a = pool[Math.floor(rng() * pool.length)];
    var b = pool[Math.floor(rng() * pool.length)];
    var axes = a === b ? [a] : [a, b];
    /* ⛔ AN UNKNOWN WORD MUST NOT OUTWEIGH A KNOWN ONE. At mass 0.35-0.85 the
     * word "Caraway" out-weighed the flour it seasons and turned a rye loaf
     * green in-engine (2026-09-10). What the pantry cannot name is more often a
     * seasoning than a joint, so it is weighed like one. */
    return { axes: axes, colour: hues[Math.floor(rng() * hues.length)], mass: 0.15 + rng() * 0.25, known: false };
  }

  /**
   * Read one ingredient name into properties.
   * @param {string} name What the buyer wrote.
   * @returns {{name:string, axes:string[], colour:string, mass:number, known:boolean}} Properties.
   */
  function readIngredient(name) {
    var text = String(name || '').trim();
    if (!text) return null;
    var hits = [];
    for (var i = 0; i < PANTRY.length; i++) {
      if (namesWord(text, PANTRY[i][0])) hits.push(PANTRY[i]);
    }
    if (!hits.length) {
      var u = unknown(text);
      return { name: text, axes: u.axes, colour: u.colour, mass: u.mass, known: false };
    }
    /* Several pantry words can appear in one ingredient ("Chicken Stock").
     * ⛔ THE HEAD NOUN IS THE LAST ONE, NOT THE HEAVIEST. MEASURED 2026-09-10:
     * taking the heaviest word made "Chicken Stock" a piece of MEAT and gave
     * `Morel Broth` a meat share of 0.67. In English the thing is named last
     * and everything before it describes it, so the head supplies the kind,
     * colour and mass, and a modifier contributes only its FLAVOUR — smoke,
     * spice, herb, acid, sweetness, fat, magic — plus a little of its colour. */
    var head = hits[0];
    var headAt = -1;
    var low = text.toLowerCase();
    for (var j = 0; j < hits.length; j++) {
      var at = lastIndexOfWord(low, hits[j][0]);
      if (at > headAt) { headAt = at; head = hits[j]; }
    }
    var axes = head[1].slice();
    var colour = head[2];
    for (var k = 0; k < hits.length; k++) {
      if (hits[k] === head) continue;
      for (var f = 0; f < hits[k][1].length; f++) {
        var ax1 = hits[k][1][f];
        if (MODIFIER_AXES.indexOf(ax1) >= 0 && axes.indexOf(ax1) < 0) axes.push(ax1);
      }
      colour = R().mix(colour, hits[k][2], 0.25);
    }
    return { name: text, axes: axes, colour: colour, mass: head[3], known: true, head: head[0] };
  }

  /* Axes a MODIFIER word may pass to its head: flavour, never kind. */
  var MODIFIER_AXES = ['smoke', 'spice', 'herb', 'acid', 'sweet', 'fat', 'arcane'];

  /** Index of the last whole-word occurrence of `word` (with plural) in `low`. */
  function lastIndexOfWord(low, word) {
    var re = new RegExp('(^|[^a-z0-9])(' + esc(word) + '(?:e?s)?)(?=[^a-z0-9]|$)', 'g');
    var m; var last = -1;
    while ((m = re.exec(low)) !== null) {
      last = m.index + m[1].length;
      if (re.lastIndex === m.index) re.lastIndex++;
    }
    return last;
  }

  /** Parse `<refectory ...>` notetags off any database record. */
  function fromNote(note) {
    var text = String(note || '');
    var out = null;
    var m = text.match(/<refectory\s+ingredients\s*:\s*([^>]*)>/i);
    if (m) {
      out = out || {};
      out.ingredients = m[1].split(/[,;]/).map(function (s) { return s.trim(); }).filter(Boolean);
    }
    m = text.match(/<refectory\s*:\s*([a-z]+)\s*>/i);
    if (m && COMPONENTS[m[1].toLowerCase()]) { out = out || {}; out.component = m[1].toLowerCase(); }
    m = text.match(/<refectory\s+vessel\s*:\s*([a-zA-Z]+)\s*>/i);
    if (m && VESSELS[m[1]]) { out = out || {}; out.vessel = m[1]; }
    m = text.match(/<refectory\s+quality\s*:\s*(\d+)\s*>/i);
    /* ⛔ wing §16: `Number('')` is 0 and `"0"` is TRUTHY. Compare, never test. */
    if (m) { var q = Number(m[1]); if (!isNaN(q) && q > 0) { out = out || {}; out.quality = q; } }
    return out;
  }

  /**
   * Turn an MZ database item into a dish specification, or null if it is not
   * one. ⛔ An item is a dish only when the buyer SAID SO with a notetag, so
   * this never guesses over a whole database (wing §24a: score only what the
   * buyer changed).
   * @param {object} item A $dataItems entry.
   * @returns {object|null} The spec.
   */
  function fromItem(item) {
    if (!item || !item.name) return null;
    var note = fromNote(item.note);
    if (!note) return null;
    var spec = { name: item.name, iconIndex: item.iconIndex, itemId: item.id };
    if (note.ingredients) spec.ingredients = note.ingredients;
    if (note.component) spec.component = note.component;
    if (note.vessel) spec.vessel = note.vessel;
    if (note.quality) spec.quality = note.quality;
    /* No ingredient list? The dish name is itself a list of words, and reading
     * it is better than plating nothing. */
    if (!spec.ingredients || !spec.ingredients.length) {
      spec.ingredients = String(item.name).split(/\s+/).filter(function (w) { return w.length > 2; });
      spec.derivedFromName = true;
    }
    return spec;
  }

  /* --------------------------------------------------------------- the read -- */

  /**
   * Read a dish specification into the profile the plate draws.
   *
   * ⛔ MAGNITUDE IS COMPUTED ONCE HERE AND READ EVERYWHERE (wing §11 / §21i):
   * portions, vessel choice and card size all derive from this one number, so
   * two code paths cannot disagree about how big the dish is.
   *
   * @param {object} spec {name, ingredients:[string], component?, vessel?, quality?}
   * @returns {object} The dish profile.
   */
  function read(spec) {
    var r = R();
    var s = spec || {};
    var name = String(s.name || 'Dish').trim() || 'Dish';
    var rawList = Array.isArray(s.ingredients) ? s.ingredients : [];
    var ings = [];
    for (var i = 0; i < rawList.length; i++) {
      var one = readIngredient(typeof rawList[i] === 'string' ? rawList[i] : (rawList[i] && rawList[i].name));
      if (one) ings.push(one);
    }

    /* --- the axis vector, weighted by mass ------------------------------ */
    var ax = {};
    for (var a = 0; a < AXES.length; a++) ax[AXES[a]] = 0;
    var totalMass = 0;
    for (var n = 0; n < ings.length; n++) {
      totalMass += ings[n].mass;
      for (var t = 0; t < ings[n].axes.length; t++) {
        if (ax[ings[n].axes[t]] !== undefined) ax[ings[n].axes[t]] += ings[n].mass;
      }
    }
    var norm = Math.max(0.001, totalMass);
    for (var b = 0; b < AXES.length; b++) ax[AXES[b]] = ax[AXES[b]] / norm;

    /* ⛔ SOME AXES ARE WEIGHT AND SOME ARE PRESENCE, AND SCORING BOTH BY MASS
     * DELETES THE PRESENCE ONES. MEASURED 2026-09-10: a herb weighs 0.1 against
     * a joint of meat at 1.0, so `ax.herb` never beat `ax.fat` and THREE of the
     * ten finishes — herb oil, dusting and plain — were unreachable on a
     * 40-dish database while every test stayed green. A cook who reaches for
     * three herbs has made a herby dish whatever the scales say. */
    var pres = {};
    for (var pz = 0; pz < AXES.length; pz++) pres[AXES[pz]] = 0;
    for (var p2 = 0; p2 < ings.length; p2++) {
      for (var p3 = 0; p3 < ings[p2].axes.length; p3++) {
        if (pres[ings[p2].axes[p3]] !== undefined) pres[ings[p2].axes[p3]] += 1;
      }
    }
    var pnorm = Math.max(1, ings.length);
    for (var p4 = 0; p4 < AXES.length; p4++) pres[AXES[p4]] = pres[AXES[p4]] / pnorm;

    /* --- magnitude, ONCE ------------------------------------------------ */
    var quality = (typeof s.quality === 'number' && s.quality > 0) ? Math.min(5, s.quality) : 2;
    /* ⛔ QUALITY IS THE BUYER'S STATED INTENT AND IT MUST BE ABLE TO REACH THE
     * TOP TIER ON ITS OWN. MEASURED 2026-09-10: weighted at 0.25, a quality-5
     * `Dragon Rib Roast` scored 0.56 and could never be served on the grandest
     * vessel — the feast looked like supper. */
    var magnitude = Math.max(0, Math.min(1,
      ((quality - 1) / 4) * 0.45 + Math.min(1, totalMass / 3.5) * 0.35 + Math.min(1, ings.length / 7) * 0.20));

    /* --- component ------------------------------------------------------ */
    var component = null;
    var why = 'axes';
    if (s.component && COMPONENTS[s.component]) { component = s.component; why = 'declared'; }
    if (!component) {
      /* ⛔ THE HEAD NOUN IS THE LAST WORD OF THE HEAD CLAUSE. MEASURED
       * 2026-09-10: reading the FIRST matching word made `Salt-Cured Ham Haunch`
       * a jerky ("cured") and `Ale-Braised Ox Cheek` a drink ("ale"). Cut the
       * accompaniment clause off, then walk the remaining words from the END. */
      var headClause = name.split(ACCOMPANIMENT)[0];
      var words = headClause.toLowerCase().split(/[^a-z]+/).filter(Boolean);
      for (var w = words.length - 1; w >= 0; w--) {
        var cand = NAME_WORDS[words[w]];
        /* A name word that is often a MODIFIER must be corroborated by the
         * ingredients; a failed guard keeps walking rather than guessing. */
        if (cand && nameGuardPasses(words[w], ax)) { component = cand; why = 'name'; break; }
      }
    }
    if (!component) {
      /* An INGREDIENT may name the method ("Broth", "Pastry Dough") — but ⛔
       * ONLY WHEN IT IS THE BULK OF THE DISH. MEASURED 2026-09-10: without the
       * share test, `Goose and Sage Trencher` came out a LOAF because it lists
       * bread among four ingredients. A minor ingredient names its own kind, not
       * the dish's. */
      var heavyIng = null;
      for (var g0 = 0; g0 < ings.length; g0++) {
        if (!heavyIng || ings[g0].mass > heavyIng.mass) heavyIng = ings[g0];
      }
      if (heavyIng && totalMass > 0 && heavyIng.mass / totalMass >= 0.35) {
        var iw = heavyIng.name.toLowerCase().split(/[^a-z]+/);
        for (var h = 0; h < iw.length; h++) {
          if (NAME_WORDS[iw[h]]) { component = NAME_WORDS[iw[h]]; why = 'ingredient'; break; }
        }
      }
    }
    if (!component) { component = componentFromAxes(ax, ings.length); why = 'axes'; }

    /* --- vessel: an INDEX into the component's own list, so the same
     * component spreads across vessels instead of collapsing (wing §21i) --- */
    var comp = COMPONENTS[component];
    var vessel;
    var vesselWhy = 'derived';
    var named = null;
    var vw = name.toLowerCase().split(/[^a-z]+/).filter(Boolean);
    for (var v0 = vw.length - 1; v0 >= 0; v0--) {
      if (VESSEL_WORDS[vw[v0]]) { named = VESSEL_WORDS[vw[v0]]; break; }
    }
    if (s.vessel && VESSELS[s.vessel]) {
      vessel = s.vessel;
      vesselWhy = 'declared';
    } else if (named) {
      vessel = named;
      vesselWhy = 'name';
    } else {
      var list = comp.vessels;
      if (component === 'drink') list = isBrewed(ings, name) ? DRINK_BREWED : DRINK_STILL;
      /* ⛔ MEASURED 2026-09-10: magnitude spans only ~0.16-0.78 over a real
       * database, so indexing by raw magnitude parked every dish in the middle
       * of its list. Stretch it over its own observed span first. The hash is a
       * minority term that only separates two dishes of the SAME magnitude; the
       * tier is the dish's grandeur (see COMPONENTS). */
      var mSpread = Math.max(0, Math.min(1, (magnitude - 0.12) / 0.70));
      var pick = Math.floor((mSpread * 0.65
        + (r.hash(name + '|' + component) % 1000) / 1000 * 0.35) * list.length);
      vessel = list[Math.max(0, Math.min(list.length - 1, pick))];
    }

    /* --- behaviour: the strongest axis that earns one -------------------
     * ⛔ THE RAW AXIS IS NOT ENOUGH. MEASURED: `Plum Turnover` came out with a
     * JUS, because pastry and butter both carry `fat` and outweighed the plum's
     * sweetness. A finish belongs to the FORM as much as to the ingredients, so
     * each score is scaled by what that form can plausibly wear. */
    var behaviour = 'bare';
    var bestScore = 0.08;                       // a floor, so `bare` is reachable
    for (var k2 = 0; k2 < BEHAVIOUR_IDS.length; k2++) {
      var bid = BEHAVIOUR_IDS[k2];
      var axis = BEHAVIOURS[bid].axis;
      if (!axis) continue;
      var source = PRESENCE_AXES.indexOf(axis) >= 0 ? pres : ax;
      var score = (source[axis] || 0) * affinity(component, bid, comp);
      if (score > bestScore) { bestScore = score; behaviour = bid; }
    }

    /* --- colour: mixed from what actually went in ---------------------- */
    var body = ings.length ? ings[0].colour : r.P.roast;
    var heaviest = null;
    for (var c = 0; c < ings.length; c++) if (!heaviest || ings[c].mass > heaviest.mass) heaviest = ings[c];
    if (heaviest) body = heaviest.colour;
    if (heaviest && ings.length > 1) {
      /* ⛔ BLEND BY MASS SHARE OF THE WHOLE DISH, not by a flat cap. A flat 0.42
       * let a pinch of salt (mass 0.05) pull the body colour toward white as
       * hard as a second joint of meat would. */
      var acc = heaviest.colour;
      for (var e = 0; e < ings.length; e++) {
        if (ings[e] === heaviest) continue;
        acc = r.mix(acc, ings[e].colour, Math.min(0.45, 0.9 * ings[e].mass / norm));
      }
      body = acc;
    }

    var heat = Math.max(0, Math.min(1, comp.heat * (0.7 + ax.smoke * 0.5) + (ax.arcane > 0.2 ? 0.15 : 0)));
    var char = Math.max(0, Math.min(1, ax.smoke * 0.8 + (comp.heat > 0.7 ? 0.22 : 0.04) + (quality >= 4 ? 0.06 : 0)));
    var gloss = Math.max(0, Math.min(1, BEHAVIOURS[behaviour].gloss * 0.7 + ax.fat * 0.5 + ax.sweet * 0.3));
    var portions = Math.max(1, Math.min(7, Math.round(
      1 + magnitude * 3.6 + (comp.wet > 0.7 ? 1 : 0) + (quality >= 4 ? 1 : 0))));
    /* ⛔ COUNT THE THINGS, DO NOT INTEGRATE THE AXIS. Herbs weigh almost nothing,
     * so scaling garnish by `ax.herb` capped every plate at four or five marks
     * whatever the cook put on it (MEASURED 2026-09-10). A garnish is a COUNT of
     * ingredients that garnish, and a dish with three herbs looks like it. */
    var seasoners = 0;
    for (var q2 = 0; q2 < ings.length; q2++) {
      if (ings[q2].axes.indexOf('herb') >= 0 || ings[q2].axes.indexOf('spice') >= 0) seasoners++;
    }
    var garnishCount = Math.max(0, Math.min(14, Math.round(
      seasoners * 2.4 + (BEHAVIOURS[behaviour].garnish === 'none' ? 0 : 1.5) + magnitude * 4.5)));

    var sauceColour = r.mix(r.P.sauce, body, Math.min(0.55, ax.fat * 0.6 + ax.liquid * 0.3));
    if (ax.dairy > 0.25) sauceColour = r.mix(sauceColour, r.P.cream, Math.min(0.7, ax.dairy));
    /* ⛔ A MAGICAL INGREDIENT TINTS THE SAUCE ITS OWN COLOUR. The first build
     * mixed every arcane sauce toward one blue, so an ember-roasted dragon rib
     * sat in a PURPLE-GREY pool (art stage, 2026-09-10, looked at in the
     * product-size render). Ember glazes orange-red, mana blue, slime green. */
    if (ax.arcane > 0.25) {
      var magic = null;
      for (var mg = 0; mg < ings.length; mg++) {
        if (ings[mg].axes.indexOf('arcane') >= 0 && (!magic || ings[mg].mass > magic.mass)) magic = ings[mg];
      }
      sauceColour = r.mix(sauceColour, magic ? magic.colour : '#5C74B0', Math.min(0.5, ax.arcane));
    }
    var garnishColour = pres.herb > 0 ? r.P.herb : (pres.spice > 0 ? r.mix(r.P.char, r.P.roast, 0.35) : r.P.shadow);

    return {
      name: name,
      itemId: s.itemId || 0,
      ingredients: ings,
      ingredientNames: ings.map(function (x) { return x.name; }),
      knownCount: ings.filter(function (x) { return x.known; }).length,
      axes: ax,
      presence: pres,
      quality: quality,
      magnitude: Math.round(magnitude * 1000) / 1000,
      component: component,
      componentWhy: why,
      vessel: vessel,
      vesselWhy: vesselWhy,
      vesselTier: comp.vessels.indexOf(vessel),
      behaviour: behaviour,
      portions: portions,
      heat: Math.round(heat * 1000) / 1000,
      char: Math.round(char * 1000) / 1000,
      gloss: Math.round(gloss * 1000) / 1000,
      wetness: Math.round(Math.max(comp.wet, ax.liquid) * 1000) / 1000,
      bodyColour: body,
      sauceColour: sauceColour,
      garnishColour: garnishColour,
      garnishCount: garnishCount,
      garnishKind: BEHAVIOURS[behaviour].garnish,
      seed: r.hash(name + '|' + ings.map(function (x) { return x.name; }).join(',') + '|' + quality),
      profileKey: component + '/' + vessel + '/' + behaviour,
    };
  }

  /* What the ingredients must at least contain for a title word to be believed.
   * Only the forms a stray modifier can plausibly steal are listed; everything
   * else takes the buyer's title at face value, which is the right default. */
  /* ⛔ THE GUARD IS KEYED ON THE WORD, NOT ON THE COMPONENT. MEASURED
   * 2026-09-10, twice over: guarding the SOUP component rejected
   * `Fisherman's Chowder` (liquid 0.196 — a chowder is thick) and drew it as a
   * PIE, while the only title the guard ever needed to stop was `ale` in
   * `Ale-Braised Ox Cheek`. "Chowder", "soup", "stew" are always the dish;
   * "ale", "wine", "cheese", "fruit", "jam" are often only what is IN it.
   *
   * ⛔ wing §12b-1: each bar sits BETWEEN a measured known-good and known-bad —
   *   `Tavern Brown Ale`       liquid 0.62  MUST PASS (it is a drink)
   *   `Ale-Braised Ox Cheek`   liquid 0.21  MUST FAIL (ale is a braising liquor)
   * Both are pinned in dish.test.js; moving a bar here without moving that test
   * is how a guard quietly stops guarding. */
  var NAME_GUARD = {
    ale: { liquid: 0.45 }, wine: { liquid: 0.45 }, mead: { liquid: 0.45 },
    cider: { liquid: 0.45 }, tea: { liquid: 0.45 }, brew: { liquid: 0.45 },
    cheese: { dairy: 0.22 },
    fruit: { fruit: 0.30 },
    jam: { fruit: 0.20 },
  };

  /**
   * Does the ingredient evidence permit this title word?
   * @param {string} word The title word (lower case).
   * @param {object} ax The axis vector.
   * @returns {boolean} True when nothing contradicts it.
   */
  function nameGuardPasses(word, ax) {
    var g = NAME_GUARD[word];
    if (!g) return true;
    for (var k in g) {
      if (!Object.prototype.hasOwnProperty.call(g, k)) continue;
      if ((ax[k] || 0) < g[k]) return false;
    }
    return true;
  }

  /* Forms that are eaten sweet, and forms that are eaten wet. Two small sets
   * rather than a 20x10 affinity table: the table would be typed taste, these
   * are facts about the form. */
  /* Axes a cook judges by REACH, not by weight (see `read()`). */
  var PRESENCE_AXES = ['herb', 'spice', 'acid', 'smoke'];
  var SWEET_FORMS = ['cake', 'pastry', 'fruit', 'preserves', 'drink'];
  var WET_FORMS = ['soup', 'broth', 'stew', 'noodles', 'porridge', 'drink'];
  var SAVOURY_FINISH = ['jus', 'charOil', 'herbOil', 'gremolata', 'brothPool'];
  var SWEET_FINISH = ['glaze', 'dusting', 'cream', 'crumb'];

  /**
   * How plausible a finish is on a form. 1.0 is neutral.
   * @param {string} component The form.
   * @param {string} behaviourId The finish.
   * @param {object} comp The component record.
   * @returns {number} A multiplier.
   */
  function affinity(component, behaviourId, comp) {
    var m = 1;
    var sweetForm = SWEET_FORMS.indexOf(component) >= 0;
    var wetForm = WET_FORMS.indexOf(component) >= 0;
    if (sweetForm) {
      if (SAVOURY_FINISH.indexOf(behaviourId) >= 0) m *= 0.35;
      if (SWEET_FINISH.indexOf(behaviourId) >= 0) m *= 1.65;
    }
    if (wetForm) {
      if (behaviourId === 'brothPool') m *= 1.45;
      if (behaviourId === 'crumb' || behaviourId === 'dusting') m *= 0.5;
    } else if (behaviourId === 'brothPool') {
      m *= (comp && comp.wet > 0.4) ? 0.8 : 0.25;   // a dry form does not sit in a pool
    }
    return m;
  }

  /**
   * The fallback read: no declared component, nothing in the name. Ordered so
   * the most specific evidence wins; every branch is reachable and the suite
   * proves it by sweeping the pantry.
   * @param {object} ax Axis vector.
   * @param {number} count How many ingredients.
   * @returns {string} A component id.
   */
  function componentFromAxes(ax, count) {
    if (ax.arcane > 0.45 && ax.liquid > 0.3) return 'drink';
    if (ax.liquid > 0.55) return (ax.meat + ax.fish + ax.root > 0.25) ? 'soup' : 'broth';
    if (ax.sweet > 0.35 && ax.grain > 0.2 && ax.meat < 0.15) return 'cake';
    if (ax.sweet > 0.45 && ax.fruit > 0.3) return 'preserves';
    if (ax.grain > 0.45) return ax.liquid > 0.25 ? 'porridge' : 'loaf';
    /* Grain simmered in liquid is a porridge whatever else is in it — without
     * this, `Saffron Rice` fell past every branch and came out a STEW. */
    if (ax.grain > 0.25 && ax.liquid > 0.30) return 'porridge';
    if (ax.grain > 0.22 && (ax.meat > 0.2 || ax.root > 0.2)) return 'pie';
    if (ax.egg > 0.25) return 'eggs';
    if (ax.dairy > 0.4) return 'cheeseboard';
    if (ax.fruit > 0.45) return 'fruit';
    if (ax.green > 0.42) return 'salad';
    if (ax.fish > 0.3) return 'fillet';
    if (ax.meat > 0.3) {
      if (count >= 5 || ax.liquid > 0.2) return 'stew';
      if (ax.smoke > 0.3) return 'jerky';
      /* ⛔ Skewers come from the NAME, never from a count. `count >= 3` used to
       * turn every three-ingredient joint into kebabs. */
      return 'roast';
    }
    /* ⛔ Roots are not leaves: a root-led dish was falling into SALAD and was
     * drawn as green leaves (`Boiled Roots`, MEASURED on the contact sheet). */
    if (ax.fungus > 0.3 || ax.root > 0.3) return (count >= 4 || ax.liquid > 0.3) ? 'stew' : 'roast';
    /* ⛔ THE DEFAULT IS WHERE A CLASSIFIER LIES. MEASURED 2026-09-10:
     * `Woodcutter's Bean Pot` (bean, bacon, onion, stock, bay) matched no branch
     * and fell out as a LOAF, because `loaf` was a constant default. A default
     * must still read the data it was given. */
    if (ax.liquid > 0.22 && count >= 3) return 'stew';
    if (ax.liquid > 0.22) return 'soup';
    if (ax.grain > 0.12) return 'loaf';
    return count >= 4 ? 'salad' : 'fillet';
  }

  return {
    AXES: AXES,
    PANTRY: PANTRY,
    COMPONENTS: COMPONENTS,
    COMPONENT_IDS: COMPONENT_IDS,
    VESSELS: VESSELS,
    VESSEL_IDS: VESSEL_IDS,
    BEHAVIOURS: BEHAVIOURS,
    BEHAVIOUR_IDS: BEHAVIOUR_IDS,
    NAME_WORDS: NAME_WORDS,
    VESSEL_WORDS: VESSEL_WORDS,
    NAME_GUARD: NAME_GUARD,
    nameGuardPasses: nameGuardPasses,
    namesWord: namesWord,
    readIngredient: readIngredient,
    fromNote: fromNote,
    fromItem: fromItem,
    componentFromAxes: componentFromAxes,
    read: read,
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.RefectoryDish;
