//=============================================================================
// RefectoryPlate.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Refectory [3/4] — the drawing. Sixteen service vessels, twenty principal components, ten finishes, garnish placement, steam and the hand-set menu card. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Refectory — the drawing
 * ============================================================================
 * Load this THIRD. It defines no scene and patches no core method.
 *
 * Everything here is drawn, in code, from the profile RefectoryDish read out of
 * the buyer's ingredients. There are no image assets in this product: no food
 * PNGs, no icon sheet, nothing to run out of. That is the difference between
 * this and a pack of food icons — an icon cannot be told what went into it.
 *
 * The component names the FORM (a roast, a stew, a pie). The ingredients then
 * decide what that form looks like: a roast of boar is a joint with a bone and
 * a carved face, a roast of ribs is a lacquered rack, a roast goose is a whole
 * bird, roast turnips are caramelised halves. A stew shows the pieces of what
 * actually went into it, each drawn as that ingredient.
 *
 * ONE LIGHT, upper left, from RefectoryRender.LIGHT. Every highlight and every
 * shadow in every function below derives from it.
 * ============================================================================
 */

if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};
var CSAF = globalThis.CSAF;

CSAF.RefectoryPlate = (function () {
  'use strict';

  /* ⛔ Siblings at FIRST USE — the harness loads alphabetically (wing §8/2). */
  var _R = null; var _D = null;
  function deps() {
    if (!_R) { _R = CSAF.RefectoryRender; _D = CSAF.RefectoryDish; }
    return _R;
  }

  var TAU = Math.PI * 2;
  /* The deepest shadow on the table. Darker than the palette's `char`, because
   * a contact shadow drawn in a food colour reads as a stain, not as depth. */
  var SHADOW = '#120B08';

  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

  /* ================================================================ paths ===
   * Every shape below is a PATH FUNCTION: it adds subpaths and never calls
   * `beginPath`, so one outline can be filled, clipped and edge-shaded without
   * being regenerated — and a regenerated outline is a different outline. */

  /** @returns {function(object):void} an ellipse subpath, radii clamped >= 0.01 */
  function ellPath(cx, cy, rx, ry, rot) {
    var a = Math.max(0.01, rx); var b = Math.max(0.01, ry); var t = rot || 0;
    return function (c) {
      c.moveTo(cx + Math.cos(t) * a, cy + Math.sin(t) * a);
      c.ellipse(cx, cy, a, b, t, 0, TAU);
      c.closePath();
    };
  }

  /** @returns {function(object):void} a smooth closed curve through `pts` */
  function ptsPath(pts) {
    return function (c) { deps().smoothPath(c, pts); };
  }

  /** @returns {function(object):void} a straight-edged polygon through `pts` */
  function polyPath(pts) {
    return function (c) {
      c.moveTo(pts[0][0], pts[0][1]);
      for (var i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]);
      c.closePath();
    };
  }

  /** @returns {{x:number,y:number,w:number,h:number}} the box around `pts` */
  function boundsOf(pts) {
    var x0 = Infinity; var y0 = Infinity; var x1 = -Infinity; var y1 = -Infinity;
    for (var i = 0; i < pts.length; i++) {
      if (pts[i][0] < x0) x0 = pts[i][0];
      if (pts[i][0] > x1) x1 = pts[i][0];
      if (pts[i][1] < y0) y0 = pts[i][1];
      if (pts[i][1] > y1) y1 = pts[i][1];
    }
    return { x: x0, y: y0, w: Math.max(1, x1 - x0), h: Math.max(1, y1 - y0) };
  }

  /** @returns {{x:number,y:number,w:number,h:number}} the box around an ellipse */
  function ellBounds(cx, cy, rx, ry) {
    return { x: cx - rx, y: cy - ry, w: Math.max(1, rx * 2), h: Math.max(1, ry * 2) };
  }

  /** Local points → world points: rotate by `rot`, then move to (x, y). */
  function place(pts, x, y, rot) {
    var c = Math.cos(rot || 0); var s = Math.sin(rot || 0);
    var out = [];
    for (var i = 0; i < pts.length; i++) {
      out.push([x + pts[i][0] * c - pts[i][1] * s, y + pts[i][0] * s + pts[i][1] * c]);
    }
    return out;
  }

  /** Nudge every point by up to `amt` — hand-made rather than machined. */
  function jitter(pts, rng, amt) {
    for (var i = 0; i < pts.length; i++) {
      pts[i][0] += (rng() - 0.5) * 2 * amt;
      pts[i][1] += (rng() - 0.5) * 2 * amt;
    }
    return pts;
  }

  /* ========================================================== ingredients ===
   * The drawing reads the ingredient list directly for anything that decides
   * WHAT A PIECE LOOKS LIKE. Each lookup is by the head noun RefectoryDish
   * already found (never a substring of the whole name — wing §12.10). */

  /**
   * The first ingredient whose HEAD NOUN is in `words`. ⛔ Head only by
   * default: "Chicken Stock" is stock, not a chicken, and a name-word match
   * would roast a whole bird for it. `loose` also accepts any word of the name
   * — for modifiers that ARE the thing (a "Wild Thyme" is thyme either way).
   * @returns {object|null}
   */
  function findIng(p, words, loose) {
    deps();
    var list = p.ingredients || [];
    for (var i = 0; i < list.length; i++) {
      var head = String(list[i].head || '').toLowerCase();
      for (var j = 0; j < words.length; j++) {
        if (head === words[j]) return list[i];
      }
    }
    if (!loose) return null;
    for (var k = 0; k < list.length; k++) {
      for (var m = 0; m < words.length; m++) {
        if (_D && _D.namesWord && _D.namesWord(list[k].name, words[m])) return list[k];
      }
    }
    return null;
  }

  /**
   * @returns {boolean} whether the dish NAME carries one of `words`
   * ⛔ deps() FIRST. MEASURED 2026-09-10 (art stage, _probe/forms_count.js):
   * called before anything had been drawn, `_D` was still null and every name
   * test answered false — `Pigeon Pasty` came back a closed pie and `Hardtack
   * Ration` a loaf. The engine never saw it (a plate is always drawn first) and
   * the suite passed only because earlier tests had already drawn: a green that
   * depended on test ORDER.
   */
  function nameHas(p, words) {
    deps();
    for (var i = 0; i < words.length; i++) {
      if (_D && _D.namesWord && _D.namesWord(p.name, words[i])) return true;
    }
    return false;
  }

  /** @returns {number} an axis of the profile, 0 when absent */
  function ax(p, k) { return (p.axes && p.axes[k]) || 0; }

  /**
   * What a piece of one ingredient looks like when it is IN something — read
   * from that ingredient's own axes, never from the dish. Liquids, herbs and
   * spices return null: they are the broth, the garnish or the finish.
   * @param {object} ing An ingredient from the profile.
   * @returns {string|null} meat | fish | fungus | root | fruit | green | grain | egg | dairy
   */
  function pieceKind(ing) {
    var a = ing.axes || [];
    /* ⛔ A bean carries `green` and `grain` in the pantry, so the axis order
     * drew the Bean Pot's beans as LEAF SHREDS (art stage contact sheet,
     * 2026-09-10). Pulses are their own shape. */
    var head = String(ing.head || '');
    if (head === 'bean' || head === 'pea' || head === 'lentil') return 'legume';
    var order = ['meat', 'fish', 'fungus', 'egg', 'dairy', 'root', 'fruit', 'green', 'grain'];
    for (var i = 0; i < order.length; i++) if (a.indexOf(order[i]) >= 0) return order[i];
    return null;
  }

  /* ================================================================ solids ===
   * A lit solid: occlusion beneath it, a lit fill, texture, the edge shading
   * that makes an outline a volume, and glints where it is wet. Every piece of
   * food in the product is one or more of these. */

  /**
   * @param {object} ctx Context.
   * @param {function(object):void} pathFn The outline.
   * @param {{x:number,y:number,w:number,h:number}} b Its bounds.
   * @param {string} colour Local colour.
   * @param {function():number} rng Seeded stream.
   * @param {object} [o] {ao, lift, drop, texture:{n,size,dark,light,a}, char, detail(ctx,cx,cy,rx,ry), core, rim, gloss, depthK, blurK}
   * @returns {void}
   */
  function solid(ctx, pathFn, b, colour, rng, o) {
    var R = deps();
    var opt = o || {};
    var cx = b.x + b.w / 2; var cy = b.y + b.h / 2;
    var r = Math.max(1, Math.max(b.w, b.h) / 2);
    var rs = Math.max(1, Math.min(b.w, b.h) / 2);
    if (opt.ao !== 0) {
      R.contactShadow(ctx, cx, cy + b.h * 0.18, b.w * 0.52, b.h * 0.42, opt.ao === undefined ? 0.40 : opt.ao);
    }
    ctx.beginPath();
    pathFn(ctx);
    R.litFill(ctx, cx, cy, r, colour, { lift: opt.lift === undefined ? 0.30 : opt.lift,
      drop: opt.drop === undefined ? 0.30 : opt.drop });
    if (opt.texture || opt.char > 0.04 || opt.detail) {
      ctx.save();
      ctx.beginPath();
      pathFn(ctx);
      ctx.clip();
      if (opt.char > 0.04) charPatches(ctx, cx, cy, b.w / 2, b.h / 2, rng, opt.char);
      if (opt.texture) {
        var tx = opt.texture;
        R.stipple(ctx, cx, cy, b.w / 2, b.h / 2, rng, tx.n, tx.size,
          tx.dark || R.shade(colour, -0.45), tx.light || R.shade(colour, 0.5), tx.a);
      }
      if (opt.detail) opt.detail(ctx, cx, cy, b.w / 2, b.h / 2);
      ctx.restore();
    }
    R.innerShade(ctx, pathFn, b.x, b.y, b.w, b.h, {
      depth: rs * (opt.depthK || 0.30), blur: rs * (opt.blurK || 0.46),
      darkA: opt.core === undefined ? 0.42 : opt.core,
      light: R.shade(colour, 0.7), lightA: opt.rim === undefined ? 0.22 : opt.rim,
    });
    glints(ctx, cx, cy, b.w / 2, b.h / 2, rs, opt.gloss || 0, rng);
  }

  /** Glints on the lit shoulder of a form, each lying ALONG the surface. */
  function glints(ctx, cx, cy, rx, ry, rs, gloss, rng) {
    if (gloss <= 0.08) return;
    var R = deps();
    var la = Math.atan2(R.LIGHT.y, R.LIGHT.x);
    var n = 1 + Math.round(gloss * 2);
    for (var i = 0; i < n; i++) {
      var ang = la + ((i + rng() * 0.6) / n - 0.5) * 1.4;
      var k = 0.50 + rng() * 0.12;
      var gx = cx + Math.cos(ang) * rx * k;
      var gy = cy + Math.sin(ang) * ry * k;
      R.glint(ctx, gx, gy, rs * (0.16 + rng() * 0.12) * (i === 0 ? 1.25 : 0.8), rs * 0.05,
        ang + Math.PI / 2, 0.28 + gloss * 0.5);
    }
  }

  /** Browning where heat reached: soft dark patches biased to the edges. */
  function charPatches(ctx, cx, cy, rx, ry, rng, amount) {
    var R = deps();
    var n = 3 + Math.round(amount * 7);
    for (var i = 0; i < n; i++) {
      var a = rng() * TAU;
      var rr = 0.45 + rng() * 0.65;
      var s = Math.min(rx, ry) * (0.22 + rng() * 0.36);
      R.puff(ctx, cx + Math.cos(a) * rx * rr, cy + Math.sin(a) * ry * rr, s, '#2A140C', 0.22 + amount * 0.38);
    }
  }

  /**
   * A lit mass from a jittered ellipse. Kept for callers that want a lump and
   * nothing more specific (and for the public API of the first build).
   * @returns {Array<Array<number>>} The outline, for anything that follows it.
   */
  function mass(ctx, x, y, rx, ry, colour, rng, o) {
    var R = deps();
    var opt = o || {};
    var pts = R.blobPts(x, y, Math.max(0.5, rx), Math.max(0.5, ry), rng,
      opt.wobble === undefined ? 0.15 : opt.wobble, opt.lobes || 9, opt.rot || 0);
    solid(ctx, ptsPath(pts), boundsOf(pts), colour, rng, {
      ao: opt.ao, lift: opt.lift, char: opt.char, gloss: opt.gloss === undefined ? 0.3 : opt.gloss,
      core: opt.core, rim: opt.rim,
      texture: opt.fibres ? { n: opt.fibres, size: Math.max(0.5, Math.min(rx, ry) * 0.07),
        dark: opt.fibreColour, a: 0.30 } : opt.texture,
    });
    return pts;
  }

  /**
   * The liquid laps over the lower part of a piece sitting IN it — the cue that
   * puts a chunk inside a stew instead of on top of one.
   */
  function submerge(ctx, pathFn, b, liquid, depth) {
    var R = deps();
    if (!(depth > 0.02)) return;
    ctx.save();
    ctx.beginPath();
    pathFn(ctx);
    ctx.clip();
    var y0 = b.y + b.h * (1 - depth);
    var g = ctx.createLinearGradient(0, y0 - b.h * 0.08, 0, b.y + b.h);
    g.addColorStop(0, R.rgba(liquid, 0));
    g.addColorStop(0.35, R.rgba(liquid, 0.70));
    g.addColorStop(1, R.rgba(R.shade(liquid, -0.06), 0.88));
    ctx.fillStyle = g;
    ctx.fillRect(b.x - 2, y0 - b.h * 0.08, b.w + 4, b.h * depth + b.h * 0.1 + 2);
    ctx.restore();
    /* the meniscus: a hairline of light where the surface meets the piece */
    ctx.save();
    ctx.beginPath();
    ctx.ellipse(b.x + b.w / 2, y0 + b.h * 0.04, b.w * 0.46, Math.max(0.5, b.h * 0.07), 0, Math.PI * 0.95, Math.PI * 2.05);
    ctx.strokeStyle = R.rgba(R.shade(liquid, 0.55), 0.45);
    ctx.lineWidth = Math.max(0.6, b.h * 0.035);
    ctx.stroke();
    ctx.restore();
  }

  /* ============================================================ materials === */

  /**
   * Wood grain that FLOWS: every line in a run follows one shared wave, the way
   * a board's figure does, with darker streaks of figure among the fine lines.
   * ⛔ The first build drew evenly spaced independent curves, which read as
   * corduroy (the in-engine table, 2026-09-10).
   * @param {object} ctx Context (clip to the board first).
   * @param {number} x Left.
   * @param {number} y Top.
   * @param {number} w Width.
   * @param {number} h Height.
   * @param {function():number} rng Seeded stream.
   * @param {string} base The wood's local colour.
   * @param {number} [density] Lines per pixel of height, default 0.42.
   * @returns {void}
   */
  function woodGrain(ctx, x, y, w, h, rng, base, density) {
    var R = deps();
    var lines = Math.max(6, Math.round(h * (density || 0.42)));
    var amp = h * (0.05 + rng() * 0.06);
    var f1 = (1.2 + rng() * 1.6) / Math.max(1, w) * Math.PI;
    var f2 = (3.5 + rng() * 3) / Math.max(1, w) * Math.PI;
    var ph1 = rng() * TAU; var ph2 = rng() * TAU;
    var steps = Math.max(8, Math.round(w / 26));
    ctx.save();
    ctx.lineCap = 'round';
    for (var i = 0; i < lines; i++) {
      var y0 = y + (i + rng() * 0.8) * (h / lines);
      var local = (rng() - 0.5) * 2;
      var streak = rng() < 0.10;
      ctx.beginPath();
      for (var s = 0; s <= steps; s++) {
        var xx = x + (s / steps) * w;
        var yy = y0 + Math.sin(xx * f1 + ph1) * amp + Math.sin(xx * f2 + ph2 + local) * amp * 0.25;
        if (s === 0) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy);
      }
      var dark = rng() > 0.4;
      ctx.strokeStyle = R.rgba(R.shade(base, dark ? -0.35 - rng() * 0.2 : 0.14 + rng() * 0.12),
        streak ? 0.16 : 0.06 + rng() * 0.10);
      ctx.lineWidth = streak ? 2.4 + rng() * 3.5 : 0.5 + rng() * 1.0;
      ctx.stroke();
    }
    ctx.restore();
  }

  /**
   * A SLATE FIELD — the surface treatment behind the `Dark slate` table, and the
   * reason that option is not just wood in grey. Slate has no planks and no
   * seams: it has broad tonal mottling where the bed varies, fine cleavage
   * striations raked off the horizontal, bright mineral flecks, and a few
   * hairline fractures with a lit lip on one side. Every mark comes off the
   * passed stream, so the surface is identical on every render (wing §12.9).
   *
   * @param {object} ctx Canvas 2D context.
   * @param {number} x Left.
   * @param {number} y Top.
   * @param {number} w Width.
   * @param {number} h Height.
   * @param {function} rng Seeded stream.
   * @param {object} G The ground record.
   * @param {function} T Tint mixer applied to every colour.
   * @returns {void}
   */
  function stoneField(ctx, x, y, w, h, rng, G, T) {
    var R = deps();
    var i; var s; var steps;
    var warm = T(G.warm); var cool = T(G.cool); var vein = T(G.vein); var fleck = T(G.fleck);
    ctx.save();
    /* the bed: broad soft blotches, warm and cool, so the slab is not one flat
     * value — this is what a stone has instead of grain */
    var blots = Math.max(10, Math.round((w * h) / 42000));
    for (i = 0; i < blots; i++) {
      var bx = x + rng() * w; var by = y + rng() * h;
      var br = Math.min(w, h) * (0.10 + rng() * 0.22);
      var bg = ctx.createRadialGradient(bx, by, 0, bx, by, br);
      bg.addColorStop(0, R.rgba(rng() < 0.5 ? warm : cool, 0.21 + rng() * 0.14));
      bg.addColorStop(1, R.rgba(rng() < 0.5 ? warm : cool, 0));
      ctx.fillStyle = bg;
      ctx.fillRect(bx - br, by - br, br * 2, br * 2);
    }
    /* cleavage: long shallow striations, all raked the same way, because slate
     * splits along one plane */
    var rake = (rng() - 0.5) * 0.10;
    var lines = Math.max(16, Math.round(h * 0.17));
    ctx.lineCap = 'round';
    for (i = 0; i < lines; i++) {
      var y0 = y + (i + rng() * 0.9) * (h / lines);
      var amp = h * 0.012 * (0.4 + rng());
      var f1 = (1.1 + rng() * 1.5) / Math.max(1, w) * Math.PI;
      var ph = rng() * TAU;
      steps = Math.max(8, Math.round(w / 40));
      ctx.beginPath();
      for (s = 0; s <= steps; s++) {
        var sx = x + (s / steps) * w;
        var sy = y0 + (sx - x) * rake + Math.sin(sx * f1 + ph) * amp;
        if (s === 0) ctx.moveTo(sx, sy); else ctx.lineTo(sx, sy);
      }
      ctx.strokeStyle = R.rgba(R.shade(cool, rng() > 0.45 ? -0.38 : 0.26), 0.08 + rng() * 0.10);
      ctx.lineWidth = 0.5 + rng() * 1.3;
      ctx.stroke();
    }
    /* mineral flecks: the quartz and pyrite that make slate read as stone at a
     * glance rather than as a grey card */
    var flecks = Math.max(90, Math.round((w * h) / 1500));
    for (i = 0; i < flecks; i++) {
      var fx = x + rng() * w; var fy = y + rng() * h;
      var fr = 0.4 + rng() * 1.5;
      ctx.beginPath();
      ctx.arc(fx, fy, fr, 0, TAU);
      ctx.fillStyle = R.rgba(rng() < 0.62 ? fleck : vein, 0.07 + rng() * 0.21);
      ctx.fill();
    }
    /* fractures: few, kinked, each with a lit lip on the lower side */
    var cracks = Math.max(2, Math.round(w / 620));
    for (i = 0; i < cracks; i++) {
      var cx0 = x + rng() * w * 0.9; var cy0 = y + rng() * h;
      var ang = rake * 3 + (rng() - 0.5) * 0.5;
      var len = w * (0.18 + rng() * 0.4);
      steps = 7;
      var pts = [];
      for (s = 0; s <= steps; s++) {
        var t = s / steps;
        pts.push([cx0 + Math.cos(ang) * len * t + (rng() - 0.5) * h * 0.012,
          cy0 + Math.sin(ang) * len * t + (rng() - 0.5) * h * 0.016]);
      }
      ctx.beginPath();
      pts.forEach(function (p, k) { if (k === 0) ctx.moveTo(p[0], p[1]); else ctx.lineTo(p[0], p[1]); });
      ctx.strokeStyle = R.rgba(vein, 0.42);
      ctx.lineWidth = 1.1;
      ctx.stroke();
      ctx.beginPath();
      pts.forEach(function (p, k) { if (k === 0) ctx.moveTo(p[0], p[1] + 1.2); else ctx.lineTo(p[0], p[1] + 1.2); });
      ctx.strokeStyle = R.rgba(fleck, 0.07);
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    ctx.restore();
  }

  /**
   * A LINEN WEAVE — the surface treatment behind the `Linen cloth` table. A cloth
   * is a GRID OF THREADS, not a board: warp and weft at one pitch, irregular
   * slubs where the flax thickened, and soft folds lying across it. No seam, no
   * joint, no grain.
   *
   * @param {object} ctx Canvas 2D context.
   * @param {number} x Left.
   * @param {number} y Top.
   * @param {number} w Width.
   * @param {number} h Height.
   * @param {function} rng Seeded stream.
   * @param {object} G The ground record.
   * @param {function} T Tint mixer applied to every colour.
   * @returns {void}
   */
  function clothWeave(ctx, x, y, w, h, rng, G, T) {
    var R = deps();
    var i;
    var warm = T(G.warm); var cool = T(G.cool); var thread = T(G.thread); var slub = T(G.slub);
    /* ⛔ The pitch is a THREAD pitch, so it is a constant in screen pixels — it
     * must NOT scale with the canvas, or a contact sheet would weave a blanket
     * and a game screen a gauze. 7 px reads as linen at 816x624 and still reads
     * on a 1632-wide sheet. */
    var pitch = 7;
    ctx.save();
    /* folds first, under the threads: broad soft troughs and crests */
    var folds = Math.max(2, Math.round(h / 300));
    for (i = 0; i < folds; i++) {
      var fy = y + h * (0.12 + rng() * 0.76);
      var fh = h * (0.06 + rng() * 0.10);
      var fg = ctx.createLinearGradient(0, fy - fh, 0, fy + fh);
      fg.addColorStop(0, R.rgba(warm, 0));
      fg.addColorStop(0.42, R.rgba(cool, 0.20));
      fg.addColorStop(0.58, R.rgba(slub, 0.09));
      fg.addColorStop(1, R.rgba(warm, 0));
      ctx.fillStyle = fg;
      ctx.fillRect(x, fy - fh, w, fh * 2);
    }
    /* the weave: weft across, warp down, each thread alternately lit and shaded
     * so the crossing points read as a woven grid rather than as a screen door */
    ctx.lineWidth = 1;
    var k = 0;
    for (var wy = y - (y % pitch); wy < y + h; wy += pitch) {
      ctx.beginPath();
      ctx.moveTo(x, wy);
      ctx.lineTo(x + w, wy);
      ctx.strokeStyle = R.rgba(k % 2 ? thread : slub, k % 2 ? 0.13 : 0.09);
      ctx.stroke();
      k++;
    }
    k = 0;
    for (var wx = x - (x % pitch); wx < x + w; wx += pitch) {
      ctx.beginPath();
      ctx.moveTo(wx, y);
      ctx.lineTo(wx, y + h);
      ctx.strokeStyle = R.rgba(k % 2 ? thread : slub, k % 2 ? 0.10 : 0.07);
      ctx.stroke();
      k++;
    }
    /* slubs: the thick irregular bits of flax that tell linen from cotton */
    var slubs = Math.max(30, Math.round((w * h) / 5200));
    ctx.lineCap = 'round';
    for (i = 0; i < slubs; i++) {
      var sx = x + rng() * w; var sy = y + rng() * h;
      var across = rng() < 0.5;
      /* ⛔ A slub is a THICKENED THREAD, so it is SHORT and lies along the weave.
       * At `pitch * (1.6 + 3.4)` they read as scratches on the cloth (looked at
       * 3x, polish round 2) — the fault is length, not alpha. */
      var len = pitch * (1.0 + rng() * 1.9);
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(across ? sx + len : sx, across ? sy : sy + len);
      ctx.strokeStyle = R.rgba(rng() < 0.5 ? slub : thread, 0.06 + rng() * 0.09);
      ctx.lineWidth = 1.1 + rng() * 1.1;
      ctx.stroke();
    }
    ctx.restore();
  }

  /** A lit ceramic disc. Kept for the public API; vessels use dishForm/walledForm. */
  function ceramic(ctx, cx, cy, rx, ry, base, rimLift) {
    var R = deps();
    ctx.beginPath();
    ellPath(cx, cy, rx, ry)(ctx);
    R.litFill(ctx, cx, cy, Math.max(rx, ry), base, { lift: 0.20, drop: 0.30 });
    edgeArcs(ctx, cx, cy, rx, ry, base, Math.max(1.2, rx * 0.02), rimLift);
  }

  /** What an object throws on the table: a wide soft penumbra and a tight core. */
  function tableShadow(ctx, cx, cy, rx, ry, s) {
    var R = deps();
    var k = s === undefined ? 1 : s;
    /* ⛔ A SOFT PENUMBRA LOSES ITS CONTRAST WHEN IT IS ONLY A FEW PIXELS WIDE:
     * on the forty-dish contact sheet, at a 69 px plate radius, several vessels
     * FLOATED on the wood (art-director defect 5, polish stage 2026-09-11). The
     * falloff is the same SHAPE at every size, so the only thing that can carry
     * a small shadow is strength. Raised smoothly below 120 px and capped, so
     * nothing moves at the sizes the scenes themselves draw at (r = 180-262). */
    var big = Math.max(rx, ry);
    k *= 1 + Math.max(0, Math.min(1, (120 - big) / 90)) * 0.55;
    R.contactShadow(ctx, cx, cy, rx * 1.10, ry * 1.25, 0.36 * k);
    R.contactShadow(ctx, cx, cy - ry * 0.10, rx * 0.88, ry * 0.70, 0.46 * k);
  }

  /** The outer edge of a round form: light where it faces the lamp, dark where it turns away. */
  function edgeArcs(ctx, cx, cy, rx, ry, body, lw, lift) {
    var R = deps();
    ctx.save();
    ctx.lineWidth = lw;
    ctx.beginPath();
    ctx.ellipse(cx, cy, Math.max(0.01, rx), Math.max(0.01, ry), 0, Math.PI * 0.85, Math.PI * 1.75);
    ctx.strokeStyle = R.rgba(R.shade(body, lift === undefined ? 0.75 : lift), 0.55);
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(cx, cy, Math.max(0.01, rx), Math.max(0.01, ry), 0, Math.PI * 1.95, Math.PI * 0.65);
    ctx.strokeStyle = R.rgba(R.shade(body, -0.55), 0.55);
    ctx.stroke();
    ctx.restore();
  }

  /** The glaze's reflection of the window: a sharp arc and a wide soft one, upper left. */
  function sheen(ctx, cx, cy, rx, ry, lw, a) {
    var R = deps();
    var al = a === undefined ? 1 : a;
    ctx.save();
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.ellipse(cx, cy, Math.max(0.01, rx), Math.max(0.01, ry), 0, Math.PI * 1.00, Math.PI * 1.56);
    ctx.strokeStyle = R.rgba('#FFFFFF', 0.13 * al);
    ctx.lineWidth = lw * 2.8;
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(cx, cy, Math.max(0.01, rx), Math.max(0.01, ry), 0, Math.PI * 1.10, Math.PI * 1.40);
    ctx.strokeStyle = R.rgba('#FFFFFF', 0.58 * al);
    ctx.lineWidth = lw;
    ctx.stroke();
    ctx.restore();
  }

  /** @returns {{x:number,y:number,rot:number}} the point on an ellipse facing the light, and its tangent */
  function towardLight(cx, cy, rx, ry, k) {
    var R = deps();
    var t = Math.atan2(R.LIGHT.y * rx, R.LIGHT.x * ry);
    return { x: cx + Math.cos(t) * rx * k, y: cy + Math.sin(t) * ry * k,
      rot: Math.atan2(ry * Math.cos(t), -rx * Math.sin(t)) };
  }

  /**
   * A flat ceramic form — platter, plate — seen at three-quarters: its
   * thickness at the front, a lit top, an optional painted band, a CONCAVE
   * well (dark on the side toward the light, lit on the far side — the
   * opposite of a dome, and the reason a well reads as a hollow), and the
   * glaze's sheen on the rim.
   * @returns {object} The well: {cx, cy, rx, ry}.
   */
  function dishForm(ctx, cx, cy, rx, ry, o) {
    var R = deps();
    var body = o.body;
    var t = o.thick;
    tableShadow(ctx, cx, cy + t + ry * 0.05, rx, ry, o.shadow);
    ctx.beginPath();
    ellPath(cx, cy + t, rx, ry)(ctx);
    var sg = ctx.createLinearGradient(cx - rx, 0, cx + rx, 0);
    sg.addColorStop(0, R.shade(body, -0.10));
    sg.addColorStop(0.45, R.shade(body, -0.26));
    sg.addColorStop(1, R.shade(body, -0.52));
    ctx.fillStyle = sg;
    ctx.fill();
    ctx.beginPath();
    ellPath(cx, cy, rx, ry)(ctx);
    var tg = ctx.createLinearGradient(cx + R.LIGHT.x * rx, cy + R.LIGHT.y * ry, cx - R.LIGHT.x * rx, cy - R.LIGHT.y * ry);
    tg.addColorStop(0, R.shade(body, 0.32));
    tg.addColorStop(0.5, body);
    tg.addColorStop(1, R.shade(body, -0.14));
    ctx.fillStyle = tg;
    ctx.fill();
    edgeArcs(ctx, cx, cy, rx, ry, body, Math.max(1, rx * 0.012));
    if (o.band) {
      ctx.save();
      ctx.beginPath();
      ellPath(cx, cy, rx * 0.93, ry * 0.93)(ctx);
      ctx.strokeStyle = R.rgba(o.band, 0.82);
      ctx.lineWidth = Math.max(1, rx * 0.018);
      ctx.stroke();
      ctx.beginPath();
      ellPath(cx, cy, rx * 0.893, ry * 0.893)(ctx);
      ctx.strokeStyle = R.rgba(o.band, 0.50);
      ctx.lineWidth = Math.max(0.6, rx * 0.006);
      ctx.stroke();
      ctx.restore();
    }
    var k = o.rimK;
    var wcy = cy + t * 0.25;
    var wx = rx * k; var wy = ry * k;
    var wp = ellPath(cx, wcy, wx, wy);
    ctx.beginPath();
    wp(ctx);
    ctx.fillStyle = R.shade(body, -0.035);
    ctx.fill();
    R.innerShade(ctx, wp, cx - wx, wcy - wy, wx * 2, wy * 2, {
      invert: true, depth: wy * 0.16, blur: wy * 0.24, darkA: 0.30, light: '#FFFFFF', lightA: 0.40,
    });
    sheen(ctx, cx, cy, rx * 0.965, ry * 0.965, Math.max(1.2, rx * 0.02));
    var gp = towardLight(cx, cy, rx, ry, 0.965);
    R.glint(ctx, gp.x, gp.y, rx * 0.075, Math.max(0.6, rx * 0.012), gp.rot, 0.85);
    return { cx: cx, cy: wcy, rx: wx * 0.92, ry: wy * 0.92 };
  }

  /**
   * A walled form — bowl, cup, tankard, cauldron, tureen, skillet — seen at
   * three-quarters: the outer wall shaded as a turned cylinder, the rim as a
   * lit ring, the inside as a hollow, and the contents as a plane `fill` of the
   * way up. Returns the contents' surface and a CLIP that keeps them inside the
   * opening at the front while letting a heap rise above the back rim.
   * @returns {object} well {cx, cy, rx, ry, clip, surface, opening}
   */
  function walledForm(ctx, cx, cy, rx, ry, o) {
    var R = deps();
    var body = o.body;
    var H = o.height;
    var fx = rx * (o.foot === undefined ? 0.62 : o.foot);
    var fry = fx * ry / rx;
    var bulge = o.bulge === undefined ? 0.06 : o.bulge;
    var lip = o.lip || rx * 0.07;
    var metal = !!o.metal;
    if (o.under) o.under(ctx);
    tableShadow(ctx, cx, cy + H, Math.max(fx * 1.3, rx * 0.92), Math.max(fry * 1.3, ry * 0.62), o.shadow);
    if (o.feet) o.feet(ctx);
    var wall = function (c) {
      c.moveTo(cx - rx, cy);
      c.bezierCurveTo(cx - rx * (1 + bulge), cy + H * 0.50, cx - fx * (1 + bulge * 1.6), cy + H * 0.94, cx - fx, cy + H);
      c.ellipse(cx, cy + H, Math.max(0.01, fx), Math.max(0.01, fry), 0, Math.PI, 0, true);
      c.bezierCurveTo(cx + fx * (1 + bulge * 1.6), cy + H * 0.94, cx + rx * (1 + bulge), cy + H * 0.50, cx + rx, cy);
      c.ellipse(cx, cy, Math.max(0.01, rx), Math.max(0.01, ry), 0, 0, Math.PI, false);
      c.closePath();
    };
    ctx.beginPath();
    wall(ctx);
    var wg = ctx.createLinearGradient(cx - rx * (1 + bulge), 0, cx + rx * (1 + bulge), 0);
    wg.addColorStop(0, R.shade(body, metal ? -0.18 : -0.08));
    wg.addColorStop(0.20, R.shade(body, metal ? 0.50 : 0.26));
    wg.addColorStop(0.40, R.shade(body, 0.04));
    wg.addColorStop(0.80, R.shade(body, metal ? -0.58 : -0.40));
    wg.addColorStop(1, R.shade(body, metal ? -0.32 : -0.26));
    ctx.fillStyle = wg;
    ctx.fill();
    ctx.save();
    ctx.beginPath();
    wall(ctx);
    ctx.clip();
    var vg = ctx.createLinearGradient(0, cy, 0, cy + H + fry);
    vg.addColorStop(0, R.rgba(SHADOW, 0));
    vg.addColorStop(0.55, R.rgba(SHADOW, 0));
    vg.addColorStop(1, R.rgba(SHADOW, 0.38));
    ctx.fillStyle = vg;
    ctx.fillRect(cx - rx * 1.4, cy, rx * 2.8, H + fry + 2);
    /* the rim throws a thin shadow on the wall just under the lip */
    ctx.beginPath();
    ctx.ellipse(cx, cy + lip * 0.45, rx, ry, 0, 0.05, Math.PI - 0.05);
    ctx.strokeStyle = R.rgba(SHADOW, 0.24);
    ctx.lineWidth = Math.max(1, lip * 0.7);
    ctx.stroke();
    if (o.wallDetail) o.wallDetail(ctx, wall, H, fx, fry);
    ctx.restore();
    R.glint(ctx, cx - rx * 0.58, cy + H * 0.45, H * 0.32, rx * (metal ? 0.05 : 0.04), Math.PI / 2 - 0.10, metal ? 0.60 : 0.32);
    if (o.side) o.side(ctx);
    /* the rim: a lit ring */
    var irx = Math.max(1, rx - lip);
    var iry = Math.max(1, ry - lip * ry / rx);
    var rimC = o.rim || body;
    ctx.beginPath();
    ellPath(cx, cy, rx, ry)(ctx);
    ellPath(cx, cy, irx, iry)(ctx);
    var rg = ctx.createLinearGradient(cx + R.LIGHT.x * rx, cy + R.LIGHT.y * ry, cx - R.LIGHT.x * rx, cy - R.LIGHT.y * ry);
    rg.addColorStop(0, R.shade(rimC, metal ? 0.55 : 0.36));
    rg.addColorStop(0.5, rimC);
    rg.addColorStop(1, R.shade(rimC, -0.24));
    ctx.fillStyle = rg;
    ctx.fill('evenodd');
    edgeArcs(ctx, cx, cy, rx, ry, rimC, Math.max(1, rx * 0.012));
    /* the hollow */
    var ip = ellPath(cx, cy, irx, iry);
    var inside = o.inside || body;
    ctx.beginPath();
    ip(ctx);
    var ig = ctx.createLinearGradient(0, cy - iry, 0, cy + iry);
    ig.addColorStop(0, R.shade(inside, -0.50));
    ig.addColorStop(0.55, R.shade(inside, -0.14));
    ig.addColorStop(1, R.shade(inside, 0.10));
    ctx.fillStyle = ig;
    ctx.fill();
    R.innerShade(ctx, ip, cx - irx, cy - iry, irx * 2, iry * 2, {
      invert: true, depth: iry * 0.28, blur: iry * 0.40, darkA: 0.42, light: '#FFFFFF', lightA: metal ? 0.28 : 0.20,
    });
    sheen(ctx, cx, cy, rx - lip * 0.45, ry - lip * 0.45 * ry / rx, Math.max(1.1, lip * 0.30), metal ? 1.2 : 1);
    var f = o.fill === undefined ? 0.8 : o.fill;
    var drop = (1 - f) * Math.min(H * 0.55, iry * 0.9);
    var srx = irx * (0.97 - (1 - f) * 0.10);
    var sry = iry * (0.97 - (1 - f) * 0.10);
    var scy = cy + drop;
    var clip = function (c) {
      ellPath(cx, cy, irx, iry)(c);
      c.rect(cx - irx, cy - iry * 5, irx * 2, iry * 5);
    };
    return {
      cx: cx, cy: scy, rx: srx * 0.9, ry: sry * 0.9, clip: clip, deep: true,
      surface: { cx: cx, cy: scy, rx: srx, ry: sry },
      opening: { cx: cx, cy: cy, rx: irx, ry: iry },
    };
  }

  /** After the contents: the lip's own shadow falls on them, upper left. */
  function walledOver(ctx, w) {
    var R = deps();
    if (!w || !w.opening) return;
    /* ⛔ Food HEAPED above the rim stands in front of the lip, so the lip
     * casts nothing on it. Laid over the rice, the lip's shadow stopped dead
     * at the rim line and the heap read as rice under a GLASS CLOCHE (2x crop,
     * art stage 2026-09-10). A heaping component sets `heaped`. */
    if (w.heaped) return;
    var o = w.opening;
    R.innerShade(ctx, ellPath(o.cx, o.cy, o.rx, o.ry), o.cx - o.rx, o.cy - o.ry, o.rx * 2, o.ry * 2, {
      invert: true, depth: o.ry * 0.14, blur: o.ry * 0.22, darkA: 0.34, lightA: 0,
    });
  }

  /** A loop handle: a thick shaded C, drawn as three strokes so it reads as round stock. */
  function loopHandle(ctx, cx, cy, rx, ry, a0, a1, lw, colour) {
    var R = deps();
    ctx.save();
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.ellipse(cx, cy, Math.max(0.01, rx), Math.max(0.01, ry), 0, a0, a1);
    ctx.strokeStyle = R.shade(colour, -0.45);
    ctx.lineWidth = lw * 1.18;
    ctx.stroke();
    ctx.strokeStyle = colour;
    ctx.lineWidth = lw;
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(cx - lw * 0.18, cy - lw * 0.22, Math.max(0.01, rx), Math.max(0.01, ry), 0, a0 + 0.25, a1 - 0.35);
    ctx.strokeStyle = R.rgba(R.shade(colour, 0.6), 0.55);
    ctx.lineWidth = Math.max(0.8, lw * 0.28);
    ctx.stroke();
    ctx.restore();
  }

  /** The decorative band a potter paints round a bowl, following the wall's curve. */
  function wallBand(ctx, cx, y, rx, ry, colour, lw) {
    var R = deps();
    ctx.beginPath();
    ctx.ellipse(cx, y, Math.max(0.01, rx), Math.max(0.01, ry), 0, 0.02, Math.PI - 0.02);
    ctx.strokeStyle = R.rgba(colour, 0.78);
    ctx.lineWidth = lw;
    ctx.stroke();
  }

  /* The glaze colours a potter uses for a band: the brief's oxide, a slate
   * blue and an umber — chosen per dish from its seed, so two bowls on one
   * menu are two different bowls. */
  var BANDS = ['#8C3B22', '#4A5A6E', '#6B5530'];
  function bandOf(p) { return BANDS[((p.seed >>> 5) % BANDS.length + BANDS.length) % BANDS.length]; }
  /* Boards are cut from different timbers — oak, a darker cherry, pale ash —
   * so seven dishes on boards are seven boards, not one board seven times
   * (the contact sheet, art stage 2026-09-10). */
  var TIMBERS = ['#A3713F', '#8C5634', '#BE8E58'];
  function timberOf(p) { return TIMBERS[((p.seed >>> 9) % TIMBERS.length + TIMBERS.length) % TIMBERS.length]; }

  /* ============================================================== vessels ===
   * Each `base` draws the vessel and returns the WELL — where the food goes —
   * so no component needs to know what it is served in. A deep vessel's well
   * carries a `clip` (contents stay inside the opening at the front) and its
   * `over` lays the lip's shadow back across the contents.
   *
   * ⛔ wing §18b / the build's own defect (6): food in a cup or tankard was a
   * speck at contact-sheet scale. Every vessel here is sized so its WELL, not
   * its silhouette, fills the cell: a cup is drawn large and close. */

  var IRON = '#35312D';
  var PEWTER = '#8E8B83';
  var OAK = '#A3713F';

  var VESSEL_DRAW = {
    bowl: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var cx = g.cx; var cy = g.cy - g.r * 0.12; var rx = g.r * 0.94; var ry = g.r * 0.50;
        var band = bandOf(p);
        return walledForm(ctx, cx, cy, rx, ry, {
          body: R.P.bone, inside: R.P.bone, height: g.r * 0.46, foot: 0.52, bulge: 0.12,
          lip: g.r * 0.065, fill: 0.84,
          wallDetail: function (c, wall, H) {
            wallBand(c, cx, cy + H * 0.32, rx * 1.05, ry, band, Math.max(1, g.r * 0.024));
            wallBand(c, cx, cy + H * 0.44, rx * 1.02, ry * 0.98, band, Math.max(0.6, g.r * 0.008));
          },
        });
      },
      over: function (ctx, g, w) { walledOver(ctx, w); },
    },
    cup: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var cx = g.cx - g.r * 0.10; var cy = g.cy - g.r * 0.30; var rx = g.r * 0.66; var ry = g.r * 0.30;
        var H = g.r * 0.70;
        var band = bandOf(p);
        return walledForm(ctx, cx, cy, rx, ry, {
          body: R.P.bone, inside: R.P.bone, height: H, foot: 0.70, bulge: 0.05, lip: g.r * 0.05, fill: 0.86,
          side: function (c) {
            loopHandle(c, cx + rx * 1.02, cy + H * 0.40, rx * 0.30, H * 0.28, -1.45, 1.45,
              Math.max(3, g.r * 0.075), R.shade(R.P.bone, -0.04));
          },
          wallDetail: function (c, wall, H2) {
            wallBand(c, cx, cy + H2 * 0.16, rx * 1.03, ry, band, Math.max(1, g.r * 0.022));
          },
        });
      },
      over: function (ctx, g, w) { walledOver(ctx, w); },
    },
    tankard: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var cx = g.cx - g.r * 0.12; var cy = g.cy - g.r * 0.46; var rx = g.r * 0.58; var ry = g.r * 0.26;
        var H = g.r * 1.02;
        return walledForm(ctx, cx, cy, rx, ry, {
          body: PEWTER, rim: R.shade(PEWTER, 0.08), inside: R.shade(PEWTER, -0.2), height: H, foot: 1.07,
          bulge: -0.02, lip: g.r * 0.045, fill: 0.88, metal: true,
          side: function (c) {
            loopHandle(c, cx + rx * 1.02, cy + H * 0.42, rx * 0.36, H * 0.34, -1.40, 1.40,
              Math.max(4, g.r * 0.10), PEWTER);
          },
          wallDetail: function (c, wall, H2) {
            for (var b = 0; b < 2; b++) {
              var y = cy + H2 * (b ? 0.82 : 0.14);
              var k = b ? 1.055 : 1.005;
              wallBand(c, cx, y, rx * k, ry * k, R.shade(PEWTER, -0.5), Math.max(1.5, g.r * 0.03));
              wallBand(c, cx, y - Math.max(1, g.r * 0.02), rx * k, ry * k, R.shade(PEWTER, 0.6), Math.max(1, g.r * 0.014));
            }
          },
        });
      },
      over: function (ctx, g, w) { walledOver(ctx, w); },
    },
    cauldron: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var cx = g.cx; var cy = g.cy - g.r * 0.24; var rx = g.r * 0.80; var ry = g.r * 0.37;
        var H = g.r * 0.72;
        return walledForm(ctx, cx, cy, rx, ry, {
          body: IRON, inside: R.shade(IRON, 0.05), height: H, foot: 0.55, bulge: 0.24,
          lip: g.r * 0.085, fill: 0.80,
          under: function (c) {
            /* the bail, laid back behind the pot */
            c.save();
            c.beginPath();
            c.ellipse(cx, cy + ry * 0.1, rx * 1.10, ry * 2.1, 0, Math.PI * 1.03, Math.PI * 1.97);
            c.strokeStyle = R.shade(IRON, -0.2);
            c.lineWidth = Math.max(2, g.r * 0.035);
            c.stroke();
            c.strokeStyle = R.rgba(R.shade(IRON, 0.5), 0.5);
            c.lineWidth = Math.max(0.8, g.r * 0.01);
            c.stroke();
            c.restore();
          },
          feet: function (c) {
            for (var l = -1; l <= 1; l++) {
              var lx = cx + l * rx * 0.46; var ly = cy + H * (l === 0 ? 1.10 : 0.98);
              var pts = [[lx - g.r * 0.07, ly - g.r * 0.10], [lx + g.r * 0.07, ly - g.r * 0.10],
                [lx + g.r * 0.05, ly + g.r * 0.08], [lx - g.r * 0.05, ly + g.r * 0.08]];
              solid(c, ptsPath(pts), boundsOf(pts), IRON, rng, { ao: 0.5, core: 0.4, rim: 0.3, gloss: 0 });
            }
          },
          side: function (c) {
            for (var s = -1; s <= 1; s += 2) {
              var ex = cx + s * rx * 1.02; var ey = cy + H * 0.06;
              var pts2 = R.blobPts(ex, ey, g.r * 0.09, g.r * 0.07, rng, 0.08, 7, 0);
              solid(c, ptsPath(pts2), boundsOf(pts2), IRON, rng, { ao: 0, core: 0.45, rim: 0.3, gloss: 0.1 });
            }
          },
          wallDetail: function (c) {
            R.stipple(c, cx, cy + H * 0.5, rx * 1.2, H * 0.7, rng, 90, Math.max(0.6, g.r * 0.008),
              '#0E0C0A', '#77716A', 0.35);
          },
        });
      },
      over: function (ctx, g, w) { walledOver(ctx, w); },
    },
    tureen: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var cx = g.cx; var cy = g.cy - g.r * 0.18; var rx = g.r * 0.88; var ry = g.r * 0.42;
        var H = g.r * 0.56;
        var band = bandOf(p);
        return walledForm(ctx, cx, cy, rx, ry, {
          body: R.P.bone, inside: R.P.bone, height: H, foot: 0.42, bulge: 0.22, lip: g.r * 0.06, fill: 0.84,
          feet: function (c) {
            var fx = rx * 0.42 * 1.45; var fy = cy + H + g.r * 0.05;
            c.beginPath();
            ellPath(cx, fy + g.r * 0.03, fx, fx * ry / rx)(c);
            c.fillStyle = R.shade(R.P.bone, -0.42);
            c.fill();
            c.beginPath();
            ellPath(cx, fy, fx, fx * ry / rx)(c);
            R.litFill(c, cx, fy, fx, R.shade(R.P.bone, -0.12), { lift: 0.25, drop: 0.35 });
            /* ⛔ The handles are drawn BEFORE the wall so the wall covers their
             * roots — drawn after it, at 1.13 rx, they floated beside the
             * tureen as two brackets (art stage, 2026-09-10). */
            var lw = Math.max(3, g.r * 0.065);
            loopHandle(c, cx - rx * 1.06, cy + H * 0.22, rx * 0.17, H * 0.22, Math.PI * 0.42, Math.PI * 1.58, lw, R.P.bone);
            loopHandle(c, cx + rx * 1.06, cy + H * 0.22, rx * 0.17, H * 0.22, -Math.PI * 0.58, Math.PI * 0.58, lw, R.P.bone);
          },
          wallDetail: function (c, wall, H2) {
            wallBand(c, cx, cy + H2 * 0.26, rx * 1.10, ry * 1.02, band, Math.max(1.2, g.r * 0.03));
            wallBand(c, cx, cy + H2 * 0.62, rx * 0.95, ry * 0.9, band, Math.max(0.6, g.r * 0.01));
          },
        });
      },
      over: function (ctx, g, w) { walledOver(ctx, w); },
    },
    skillet: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var cx = g.cx - g.r * 0.16; var cy = g.cy + g.r * 0.02; var rx = g.r * 0.86; var ry = g.r * 0.47;
        var H = g.r * 0.16;
        return walledForm(ctx, cx, cy, rx, ry, {
          body: IRON, inside: R.shade(IRON, 0.10), height: H, foot: 0.90, bulge: 0.02, lip: g.r * 0.075,
          fill: 0.5, metal: true,
          under: function (c) {
            var x0 = cx + rx * 0.86; var y0 = cy + H * 0.25;
            var x1 = cx + rx * 1.80; var y1 = cy - ry * 0.28;
            var ang = Math.atan2(y1 - y0, x1 - x0);
            var nx = -Math.sin(ang); var ny = Math.cos(ang);
            var w0 = g.r * 0.11; var w1 = g.r * 0.075;
            var pts = [[x0 + nx * w0, y0 + ny * w0], [x1 + nx * w1, y1 + ny * w1],
              [x1 + Math.cos(ang) * w1 * 1.2, y1 + Math.sin(ang) * w1 * 1.2],
              [x1 - nx * w1, y1 - ny * w1], [x0 - nx * w0, y0 - ny * w0]];
            R.contactShadow(c, (x0 + x1) / 2, (y0 + y1) / 2 + g.r * 0.10, (x1 - x0) * 0.55, g.r * 0.08, 0.45);
            solid(c, ptsPath(pts), boundsOf(pts), IRON, rng, { ao: 0, core: 0.5, rim: 0.35, gloss: 0.3 });
            c.beginPath();
            ellPath(x1 - Math.cos(ang) * w1 * 0.4, y1 - Math.sin(ang) * w1 * 0.4, w1 * 0.42, w1 * 0.32, ang)(c);
            c.fillStyle = R.P.table;
            c.fill();
          },
        });
      },
      over: function (ctx, g, w) { walledOver(ctx, w); },
    },
    pieDish: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var cx = g.cx; var cy = g.cy - g.r * 0.02; var rx = g.r * 0.96; var ry = g.r * 0.54;
        var H = g.r * 0.18; var lip = g.r * 0.14;
        var band = bandOf(p);
        var w = walledForm(ctx, cx, cy, rx, ry, {
          body: R.P.bone, inside: R.P.bone, height: H, foot: 0.84, bulge: 0.0, lip: lip, fill: 0.86,
          wallDetail: function (c, wall, H2, fx, fry) {
            /* fluting: the tell of a pie dish, as ridges running down the wall */
            for (var i = 1; i < 30; i++) {
              var t = (i / 30) * Math.PI;
              c.beginPath();
              c.moveTo(cx + Math.cos(t) * rx, cy + Math.sin(t) * ry);
              c.lineTo(cx + Math.cos(t) * fx, cy + H2 + Math.sin(t) * fry);
              c.strokeStyle = R.rgba(i % 2 ? '#FFFFFF' : SHADOW, i % 2 ? 0.20 : 0.16);
              c.lineWidth = Math.max(0.8, g.r * 0.018);
              c.stroke();
            }
          },
        });
        /* the flat rim, fluted: a groove and a highlight at every scallop */
        ctx.save();
        ctx.lineCap = 'round';
        for (var k = 0; k < 36; k++) {
          var a = (k / 36) * TAU;
          var ox = cx + Math.cos(a) * rx * 0.985; var oy = cy + Math.sin(a) * ry * 0.985;
          var ix = cx + Math.cos(a) * (rx - lip * 0.55); var iy = cy + Math.sin(a) * (ry - lip * 0.55 * ry / rx);
          ctx.beginPath();
          ctx.moveTo(ox, oy);
          ctx.lineTo(ix, iy);
          ctx.strokeStyle = R.rgba(SHADOW, 0.10);
          ctx.lineWidth = Math.max(0.8, g.r * 0.012);
          ctx.stroke();
        }
        ctx.beginPath();
        ellPath(cx, cy, rx - lip * 0.72, ry - lip * 0.72 * ry / rx)(ctx);
        ctx.strokeStyle = R.rgba(band, 0.75);
        ctx.lineWidth = Math.max(1, g.r * 0.016);
        ctx.stroke();
        ctx.restore();
        return w;
      },
      over: function (ctx, g, w) { walledOver(ctx, w); },
    },
    breadBowl: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var cx = g.cx; var cy = g.cy - g.r * 0.12; var rx = g.r * 0.82; var ry = g.r * 0.40;
        var H = g.r * 0.52;
        var crust = '#9A5A26';
        return walledForm(ctx, cx, cy, rx, ry, {
          body: crust, rim: '#DCC095', inside: '#C9A06A', height: H, foot: 0.70, bulge: 0.28,
          lip: g.r * 0.10, fill: 0.78,
          wallDetail: function (c, wall, H2) {
            R.stipple(c, cx, cy + H2 * 0.5, rx * 1.2, H2 * 0.7, rng, 120, Math.max(0.6, g.r * 0.009),
              '#5A3214', '#F2E6CC', 0.40);
            for (var i = 0; i < 3; i++) {
              var t = 0.28 + i * 0.22;
              c.beginPath();
              c.ellipse(cx, cy + H2 * (0.30 + i * 0.12), rx * (1.12 - i * 0.05), ry * 0.9, 0, Math.PI * (t), Math.PI * (t + 0.22));
              c.strokeStyle = R.rgba('#E8CFA0', 0.55);
              c.lineWidth = Math.max(1.4, g.r * 0.03);
              c.stroke();
            }
          },
        });
      },
      over: function (ctx, g, w) { walledOver(ctx, w); },
    },
    platter: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        return dishForm(ctx, g.cx, g.cy, g.r * 1.06, g.r * 0.57, {
          body: R.P.bone, thick: g.r * 0.045, rimK: 0.78, band: bandOf(p),
        });
      },
    },
    board: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var w = g.r * 1.78; var h = g.r * 1.00; var t = g.r * 0.075;
        var x = g.cx - w * 0.56; var y = g.cy - h * 0.5;
        var hw = g.r * 0.36; var hh = h * 0.36; var rad = g.r * 0.10;
        var WOOD = timberOf(p);
        var outline = function (c) { boardOutline(c, x, y, w, h, hw, hh, rad); };
        tableShadow(ctx, x + (w + hw) / 2, y + h / 2 + t + h * 0.06, (w + hw) * 0.50, h * 0.50, 0.95);
        for (var k = 3; k >= 1; k--) {
          ctx.save();
          ctx.translate(0, t * k / 3);
          ctx.beginPath();
          outline(ctx);
          ctx.fillStyle = R.shade(WOOD, -0.30 - k * 0.06);
          ctx.fill();
          ctx.restore();
        }
        ctx.beginPath();
        outline(ctx);
        R.litFill(ctx, g.cx, g.cy, w * 0.62, WOOD, { lift: 0.18, drop: 0.30 });
        ctx.save();
        ctx.beginPath();
        outline(ctx);
        ctx.clip();
        woodGrain(ctx, x - 4, y - 4, w + hw + 8, h + 8, rng, WOOD, 0.30);
        ctx.lineCap = 'round';
        for (var i = 0; i < 9; i++) {
          var sx = x + w * (0.18 + rng() * 0.6); var sy = y + h * (0.2 + rng() * 0.6);
          var sa = -0.4 + rng() * 0.8 + (rng() > 0.5 ? Math.PI / 2 : 0); var sl = g.r * (0.08 + rng() * 0.16);
          ctx.beginPath();
          ctx.moveTo(sx, sy);
          ctx.lineTo(sx + Math.cos(sa) * sl, sy + Math.sin(sa) * sl * 0.6);
          ctx.strokeStyle = R.rgba(R.shade(WOOD, 0.45), 0.16);
          ctx.lineWidth = Math.max(0.6, g.r * 0.006);
          ctx.stroke();
        }
        R.puff(ctx, g.cx - w * 0.04, g.cy + h * 0.04, w * 0.38, R.shade(WOOD, -0.55), 0.16);
        ctx.restore();
        R.innerShade(ctx, outline, x, y, w + hw, h, {
          depth: g.r * 0.04, blur: g.r * 0.05, darkA: 0.5, light: '#FFE9C8', lightA: 0.42,
        });
        var hx = x + w + hw - hh * 0.55; var hy = y + h / 2;
        var hp = ellPath(hx, hy, hh * 0.21, hh * 0.16);
        ctx.beginPath();
        hp(ctx);
        ctx.fillStyle = '#1C1410';
        ctx.fill();
        R.innerShade(ctx, hp, hx - hh * 0.21, hy - hh * 0.16, hh * 0.42, hh * 0.32, {
          invert: true, depth: hh * 0.06, blur: hh * 0.06, darkA: 0.6, light: WOOD, lightA: 0.5,
        });
        return { cx: g.cx - w * 0.05, cy: g.cy - h * 0.02, rx: w * 0.40, ry: h * 0.34 };
      },
    },
    trencher: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var rx = g.r * 0.94; var ry = g.r * 0.56; var t = g.r * 0.13;
        var crust = '#8C5224'; var crumb = '#E0C595';
        var pts = R.blobPts(g.cx, g.cy, rx, ry, R.rngFrom((p.seed ^ 0x77) >>> 0), 0.045, 12, 0.2);
        tableShadow(ctx, g.cx, g.cy + t + ry * 0.05, rx, ry, 0.9);
        for (var k = 4; k >= 1; k--) {
          var sp = [];
          for (var i = 0; i < pts.length; i++) sp.push([pts[i][0], pts[i][1] + t * k / 4]);
          ctx.beginPath();
          R.smoothPath(ctx, sp);
          ctx.fillStyle = R.shade(crust, -0.12 - k * 0.05);
          ctx.fill();
        }
        var top = ptsPath(pts);
        ctx.beginPath();
        top(ctx);
        ctx.fillStyle = crust;
        ctx.fill();
        var inner = [];
        for (var j = 0; j < pts.length; j++) {
          inner.push([g.cx + (pts[j][0] - g.cx) * 0.90, g.cy + (pts[j][1] - g.cy) * 0.88]);
        }
        var face = ptsPath(inner);
        var fb = boundsOf(inner);
        ctx.beginPath();
        face(ctx);
        R.litFill(ctx, g.cx, g.cy, rx * 0.9, crumb, { lift: 0.18, drop: 0.22 });
        ctx.save();
        ctx.beginPath();
        face(ctx);
        ctx.clip();
        R.stipple(ctx, g.cx, g.cy, rx * 0.9, ry * 0.9, rng, Math.round(g.r * 2.2), Math.max(0.6, g.r * 0.012),
          '#9C7442', '#FFF6E2', 0.45);
        R.puff(ctx, g.cx + rx * 0.05, g.cy + ry * 0.05, rx * 0.55, '#8A5A2C', 0.30);
        ctx.restore();
        R.innerShade(ctx, face, fb.x, fb.y, fb.w, fb.h, { invert: true, depth: ry * 0.10, blur: ry * 0.14, darkA: 0.32, light: '#FFF4DC', lightA: 0.3 });
        R.innerShade(ctx, top, g.cx - rx * 1.05, g.cy - ry * 1.05, rx * 2.1, ry * 2.1, { depth: ry * 0.05, blur: ry * 0.06, darkA: 0.45, light: '#E8B878', lightA: 0.45 });
        return { cx: g.cx, cy: g.cy - g.r * 0.02, rx: rx * 0.64, ry: ry * 0.60 };
      },
    },
    stoneSlab: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var w = g.r * 1.94; var h = g.r * 1.06; var t = g.r * 0.10;
        var SLATE = '#44494D';
        var pts = slabPts(g.cx, g.cy, w, h, g.r, R.rngFrom((p.seed ^ 0x51ab) >>> 0));
        var b = boundsOf(pts);
        tableShadow(ctx, g.cx, g.cy + t + h * 0.06, w * 0.52, h * 0.52, 0.95);
        for (var k = 4; k >= 1; k--) {
          var sp = [];
          for (var i = 0; i < pts.length; i++) sp.push([pts[i][0], pts[i][1] + t * k / 4]);
          ctx.beginPath();
          polyPath(sp)(ctx);
          ctx.fillStyle = R.shade('#6E7377', -0.05 - k * 0.07);
          ctx.fill();
        }
        var top = polyPath(pts);
        ctx.beginPath();
        top(ctx);
        R.litFill(ctx, g.cx, g.cy, w * 0.6, SLATE, { lift: 0.20, drop: 0.30 });
        ctx.save();
        ctx.beginPath();
        top(ctx);
        ctx.clip();
        var tones = ['#50565B', '#393D41', '#5B6166'];
        for (var m = 0; m < 12; m++) {
          R.puff(ctx, b.x + rng() * b.w, b.y + rng() * b.h, g.r * (0.18 + rng() * 0.3), tones[m % 3], 0.22);
        }
        ctx.lineCap = 'round';
        for (var s = 0; s < 14; s++) {
          var sx = b.x + rng() * b.w; var sy = b.y + rng() * b.h; var sl = g.r * (0.05 + rng() * 0.2);
          ctx.beginPath();
          ctx.moveTo(sx, sy);
          ctx.lineTo(sx + sl, sy + (rng() - 0.5) * sl * 0.3);
          ctx.strokeStyle = R.rgba('#8E969B', 0.10 + rng() * 0.08);
          ctx.lineWidth = Math.max(0.5, g.r * 0.005);
          ctx.stroke();
        }
        ctx.restore();
        R.innerShade(ctx, top, b.x, b.y, b.w, b.h, { depth: g.r * 0.04, blur: g.r * 0.05, darkA: 0.45, light: '#C9D0D4', lightA: 0.45 });
        return { cx: g.cx, cy: g.cy - g.r * 0.03, rx: w * 0.38, ry: h * 0.34 };
      },
    },
    leafWrap: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var LEAF = '#3C6A2B';
        leaf(ctx, g.cx + g.r * 0.16, g.cy + g.r * 0.06, g.r * 1.00, g.r * 0.46, 0.30, R.shade(LEAF, -0.25), rng);
        leaf(ctx, g.cx - g.r * 0.04, g.cy, g.r * 1.10, g.r * 0.58, -0.10, LEAF, rng);
        return { cx: g.cx - g.r * 0.04, cy: g.cy - g.r * 0.02, rx: g.r * 0.64, ry: g.r * 0.32 };
      },
    },
    clothBundle: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var LINEN = '#E8DCC2'; var CHECK = '#9A3B2A';
        var T = [g.cx + g.r * 0.06, g.cy - g.r * 0.62]; var Rt = [g.cx + g.r * 1.12, g.cy + g.r * 0.02];
        var B = [g.cx - g.r * 0.04, g.cy + g.r * 0.66]; var L = [g.cx - g.r * 1.10, g.cy - g.r * 0.04];
        var pts = [T, [(T[0] + Rt[0]) / 2 + g.r * 0.02, (T[1] + Rt[1]) / 2 - g.r * 0.03], Rt,
          [(Rt[0] + B[0]) / 2 + g.r * 0.04, (Rt[1] + B[1]) / 2 + g.r * 0.02], B,
          [(B[0] + L[0]) / 2 - g.r * 0.03, (B[1] + L[1]) / 2 + g.r * 0.03], L,
          [(L[0] + T[0]) / 2 - g.r * 0.02, (L[1] + T[1]) / 2 - g.r * 0.02]];
        jitter(pts, rng, g.r * 0.02);
        var shape = ptsPath(pts);
        var b = boundsOf(pts);
        tableShadow(ctx, g.cx, g.cy + g.r * 0.08, g.r * 1.04, g.r * 0.60, 0.7);
        ctx.beginPath();
        shape(ctx);
        R.litFill(ctx, g.cx, g.cy, g.r * 1.0, LINEN, { lift: 0.16, drop: 0.20 });
        ctx.save();
        ctx.beginPath();
        shape(ctx);
        ctx.clip();
        var sp = g.r * 0.135;
        var dirs = [[Rt[0] - T[0], Rt[1] - T[1]], [T[0] - L[0], T[1] - L[1]]];
        for (var d = 0; d < 2; d++) {
          var len = Math.sqrt(dirs[d][0] * dirs[d][0] + dirs[d][1] * dirs[d][1]);
          var ux = dirs[d][0] / len; var uy = dirs[d][1] / len;
          var nx = -uy; var ny = ux;
          for (var k2 = -10; k2 <= 10; k2++) {
            var ox = g.cx + nx * k2 * sp; var oy = g.cy + ny * k2 * sp;
            ctx.beginPath();
            ctx.moveTo(ox - ux * g.r * 2.4, oy - uy * g.r * 2.4);
            ctx.lineTo(ox + ux * g.r * 2.4, oy + uy * g.r * 2.4);
            ctx.strokeStyle = R.rgba(CHECK, 0.30);
            ctx.lineWidth = sp * 0.48;
            ctx.stroke();
          }
        }
        for (var f = 0; f < 4; f++) {
          var corner = [T, Rt, B, L][f];
          for (var q = 1; q <= 4; q++) {
            var tt = q / 5;
            R.puff(ctx, g.cx + (corner[0] - g.cx) * tt, g.cy + (corner[1] - g.cy) * tt, g.r * 0.10, SHADOW, 0.09);
          }
        }
        ctx.restore();
        R.innerShade(ctx, shape, b.x, b.y, b.w, b.h, { depth: g.r * 0.05, blur: g.r * 0.08, darkA: 0.32, light: '#FFFFFF', lightA: 0.35 });
        return { cx: g.cx, cy: g.cy - g.r * 0.02, rx: g.r * 0.62, ry: g.r * 0.32 };
      },
    },
    tray: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var w = g.r * 1.96; var h = g.r * 1.10; var t = g.r * 0.06; var rad = g.r * 0.28;
        var x = g.cx - w / 2; var y = g.cy - h / 2;
        var lip = g.r * 0.12;
        var outer = function (c) { R.rrect(c, x, y, w, h, rad); };
        var inner = function (c) { R.rrect(c, x + lip, y + lip * 0.62, w - lip * 2, h - lip * 1.24, rad * 0.7); };
        tableShadow(ctx, g.cx, g.cy + t + h * 0.06, w * 0.52, h * 0.52, 0.9);
        ctx.save();
        ctx.translate(0, t);
        ctx.beginPath();
        outer(ctx);
        ctx.fillStyle = R.shade(PEWTER, -0.45);
        ctx.fill();
        ctx.restore();
        ctx.beginPath();
        outer(ctx);
        var mg = ctx.createLinearGradient(x, y, x + w, y + h);
        mg.addColorStop(0, R.shade(PEWTER, 0.55));
        mg.addColorStop(0.35, PEWTER);
        mg.addColorStop(0.7, R.shade(PEWTER, -0.30));
        mg.addColorStop(1, R.shade(PEWTER, 0.05));
        ctx.fillStyle = mg;
        ctx.fill();
        ctx.beginPath();
        inner(ctx);
        R.litFill(ctx, g.cx, g.cy, w * 0.55, R.shade(PEWTER, -0.10), { lift: 0.30, drop: 0.25 });
        ctx.save();
        ctx.beginPath();
        inner(ctx);
        ctx.clip();
        R.stipple(ctx, g.cx, g.cy, w * 0.5, h * 0.5, rng, Math.round(g.r * 1.4), Math.max(0.8, g.r * 0.018),
          '#3E3C38', '#F2F0EA', 0.20);
        ctx.restore();
        R.innerShade(ctx, inner, x + lip, y + lip * 0.62, w - lip * 2, h - lip * 1.24, {
          invert: true, depth: g.r * 0.05, blur: g.r * 0.06, darkA: 0.45, light: '#FFFFFF', lightA: 0.4,
        });
        for (var s = -1; s <= 1; s += 2) {
          var hx = g.cx + s * (w / 2 - lip * 0.5);
          var slot = function (c) { R.rrect(c, hx - lip * 0.18, g.cy - h * 0.13, lip * 0.36, h * 0.26, lip * 0.18); };
          ctx.beginPath();
          slot(ctx);
          ctx.fillStyle = '#1C1410';
          ctx.fill();
        }
        R.innerShade(ctx, outer, x, y, w, h, { depth: g.r * 0.03, blur: g.r * 0.04, darkA: 0.4, light: '#FFFFFF', lightA: 0.5 });
        return { cx: g.cx, cy: g.cy - g.r * 0.01, rx: w * 0.36, ry: h * 0.32 };
      },
    },
    skewerRack: {
      base: function (ctx, g, p, rng) {
        var R = deps();
        var w = g.r * 1.90; var h = g.r * 0.70; var t = g.r * 0.06;
        var x = g.cx - w / 2; var y = g.cy - h / 2 + g.r * 0.12;
        var plank = function (c) { R.rrect(c, x, y, w, h, g.r * 0.08); };
        tableShadow(ctx, g.cx, y + h / 2 + t, w * 0.52, h * 0.55, 0.9);
        ctx.save();
        ctx.translate(0, t);
        ctx.beginPath();
        plank(ctx);
        ctx.fillStyle = R.shade(OAK, -0.45);
        ctx.fill();
        ctx.restore();
        ctx.beginPath();
        plank(ctx);
        R.litFill(ctx, g.cx, y + h / 2, w * 0.6, OAK, { lift: 0.16, drop: 0.3 });
        ctx.save();
        ctx.beginPath();
        plank(ctx);
        ctx.clip();
        woodGrain(ctx, x, y, w, h, rng, OAK, 0.35);
        ctx.restore();
        R.innerShade(ctx, plank, x, y, w, h, { depth: g.r * 0.03, blur: g.r * 0.04, darkA: 0.45, light: '#FFE9C8', lightA: 0.4 });
        var up = g.r * 0.22; var bw = g.r * 0.16; var bd = h * 0.86;
        var rails = [];
        for (var s = -1; s <= 1; s += 2) {
          var bx = g.cx + s * w * 0.40 - bw / 2; var by = y + h * 0.07;
          R.contactShadow(ctx, bx + bw * 0.7, by + bd * 0.55, bw * 0.9, bd * 0.45, 0.45);
          var front = [[bx, by + bd - up], [bx + bw, by + bd - up], [bx + bw, by + bd], [bx, by + bd]];
          ctx.beginPath();
          polyPath(front)(ctx);
          ctx.fillStyle = R.shade(OAK, -0.28);
          ctx.fill();
          var top = [[bx, by - up], [bx + bw, by - up], [bx + bw, by + bd - up], [bx, by + bd - up]];
          ctx.beginPath();
          polyPath(top)(ctx);
          R.litFill(ctx, bx + bw / 2, by + bd / 2 - up, bd * 0.6, R.shade(OAK, 0.06), { lift: 0.22, drop: 0.2 });
          rails.push({ x: bx + bw / 2, top: by - up, depth: bd, w: bw });
        }
        return { cx: g.cx, cy: y + h * 0.40 - up, rx: w * 0.44, ry: h * 0.40, rack: rails };
      },
    },
  };

  /** A cutting board's outline: a rounded slab with a handle tab and its fillets. */
  function boardOutline(c, x, y, w, h, hw, hh, r) {
    var my = y + h / 2;
    var rr = Math.max(0, Math.min(r, h / 2 - hh / 2 - 1));
    var f = Math.max(0, Math.min(r * 0.8, hh * 0.4));
    c.moveTo(x + rr, y);
    c.lineTo(x + w - rr, y);
    c.arcTo(x + w, y, x + w, y + rr, rr);
    c.lineTo(x + w, my - hh / 2 - f);
    c.arcTo(x + w, my - hh / 2, x + w + f, my - hh / 2, f);
    c.lineTo(x + w + hw - hh / 2, my - hh / 2);
    c.arc(x + w + hw - hh / 2, my, hh / 2, -Math.PI / 2, Math.PI / 2);
    c.lineTo(x + w + f, my + hh / 2);
    c.arcTo(x + w, my + hh / 2, x + w, my + hh / 2 + f, f);
    c.lineTo(x + w, y + h - rr);
    c.arcTo(x + w, y + h, x + w - rr, y + h, rr);
    c.lineTo(x + rr, y + h);
    c.arcTo(x, y + h, x, y + h - rr, rr);
    c.lineTo(x, y + rr);
    c.arcTo(x, y, x + rr, y, rr);
    c.closePath();
  }

  /** A hand-split slab: straight breaks between jittered corners, with a chip or two. */
  function slabPts(cx, cy, w, h, r, rng) {
    var corners = [[cx - w / 2, cy - h / 2], [cx + w / 2, cy - h / 2], [cx + w / 2, cy + h / 2], [cx - w / 2, cy + h / 2]];
    var pts = [];
    for (var i = 0; i < 4; i++) {
      var a = corners[i]; var b = corners[(i + 1) % 4];
      var segs = 5;
      for (var s = 0; s < segs; s++) {
        var t = s / segs;
        var px = a[0] + (b[0] - a[0]) * t; var py = a[1] + (b[1] - a[1]) * t;
        var nx = -(b[1] - a[1]); var ny = b[0] - a[0];
        var nl = Math.sqrt(nx * nx + ny * ny) || 1;
        var off = (rng() - 0.5) * r * 0.035 - (rng() < 0.12 ? r * 0.05 : 0);
        if (s === 0) { px += (cx - px) * 0.035; py += (cy - py) * 0.06; }
        pts.push([px + nx / nl * off, py + ny / nl * off]);
      }
    }
    return pts;
  }

  /** A broad leaf with a midrib, parallel veins and a wet sheen. */
  function leaf(ctx, cx, cy, L, W, rot, colour, rng) {
    var R = deps();
    var local = [[-0.96 * L, 0.02 * W], [-0.84 * L, -0.56 * W], [-0.40 * L, -0.96 * W], [0.20 * L, -0.92 * W],
      [0.68 * L, -0.56 * W], [1.00 * L, -0.02 * W], [0.70 * L, 0.52 * W], [0.20 * L, 0.90 * W],
      [-0.40 * L, 0.96 * W], [-0.84 * L, 0.56 * W]];
    jitter(local, rng, W * 0.04);
    var pts = place(local, cx, cy, rot);
    var shape = ptsPath(pts);
    var b = boundsOf(pts);
    tableShadow(ctx, cx, cy + W * 0.25, L * 0.95, W * 0.62, 0.7);
    ctx.beginPath();
    shape(ctx);
    R.litFill(ctx, cx, cy, L, colour, { lift: 0.24, drop: 0.32 });
    ctx.save();
    ctx.beginPath();
    shape(ctx);
    ctx.clip();
    ctx.translate(cx, cy);
    ctx.rotate(rot);
    ctx.lineCap = 'round';
    for (var i = -18; i <= 18; i++) {
      if (i === 0) continue;
      var x0 = (i / 18) * L * 0.95;
      ctx.beginPath();
      ctx.moveTo(x0, 0);
      ctx.quadraticCurveTo(x0 + L * 0.08, -W * 0.5, x0 + L * 0.14, -W * 1.05);
      ctx.moveTo(x0, 0);
      ctx.quadraticCurveTo(x0 + L * 0.08, W * 0.5, x0 + L * 0.14, W * 1.05);
      ctx.strokeStyle = R.rgba(R.shade(colour, 0.35), 0.13);
      ctx.lineWidth = Math.max(0.5, W * 0.012);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.moveTo(-L * 1.0, W * 0.02);
    ctx.quadraticCurveTo(0, -W * 0.06, L * 0.98, 0);
    ctx.strokeStyle = R.rgba(R.mix(colour, '#C9D98E', 0.55), 0.85);
    ctx.lineWidth = Math.max(1.2, W * 0.05);
    ctx.stroke();
    ctx.restore();
    R.innerShade(ctx, shape, b.x, b.y, b.w, b.h, { depth: W * 0.14, blur: W * 0.18, darkA: 0.40, light: '#DCEBB0', lightA: 0.30 });
    R.glint(ctx, cx - L * 0.35, cy - W * 0.40, L * 0.34, W * 0.06, rot - 0.12, 0.30);
  }

  /* =============================================================== pieces ===
   * A stew is read from what is IN it. These draw one piece of one ingredient,
   * shaped by that ingredient's kind and coloured by the ingredient itself —
   * so a stew of beef, carrot and barley shows browned cubes, orange coins and
   * pale grains, and a stew of cod and potato does not. */

  /** The colour an ingredient takes once it has been cooked. */
  function cookedColour(ing, kind) {
    var R = deps();
    var c = ing.colour;
    if (kind === 'meat') return R.mix(c, '#7A4526', 0.40);
    if (kind === 'fish') return R.mix(c, '#F2E8D8', 0.45);
    if (kind === 'root') return R.mix(c, '#D9A860', 0.14);
    if (kind === 'fungus') return R.mix(c, '#6E4A2E', 0.22);
    if (kind === 'green') return R.mix(c, '#4E6E2E', 0.25);
    if (kind === 'grain') return R.mix(c, '#E8D6A8', 0.35);
    return c;
  }

  /** @returns {Array<Array<number>>} the convex hull of `pts` (monotone chain) */
  function hull(pts) {
    var p = pts.slice().sort(function (a, b) { return a[0] - b[0] || a[1] - b[1]; });
    function cross(o, a, b) { return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]); }
    var lo = []; var up = [];
    for (var i = 0; i < p.length; i++) {
      while (lo.length >= 2 && cross(lo[lo.length - 2], lo[lo.length - 1], p[i]) <= 0) lo.pop();
      lo.push(p[i]);
    }
    for (var j = p.length - 1; j >= 0; j--) {
      while (up.length >= 2 && cross(up[up.length - 2], up[up.length - 1], p[j]) <= 0) up.pop();
      up.push(p[j]);
    }
    up.pop(); lo.pop();
    return lo.concat(up);
  }

  /**
   * A cube seen from above at three-quarters: lit top, the two faces that turn
   * toward the viewer, softened corners. Diced root, cheese, curd.
   * @returns {{path:function, b:object}} the silhouette
   */
  function cube(ctx, x, y, s, col, rng, rot, o) {
    var R = deps();
    var opt = o || {};
    var h = s * 0.85;
    var c = Math.cos(rot); var sn = Math.sin(rot);
    var sq = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
    var top = []; var bot = [];
    for (var i = 0; i < 4; i++) {
      var u = sq[i][0] * s * (0.9 + rng() * 0.2); var v = sq[i][1] * s * (0.9 + rng() * 0.2);
      var px = x + u * c - v * sn; var py = y - h * 0.5 + (u * sn + v * c) * 0.58;
      top.push([px, py]);
      bot.push([px, py + h]);
    }
    var sil = hull(top.concat(bot));
    var silPath = polyPath(sil);
    var b = boundsOf(sil);
    if (opt.ao !== 0) R.contactShadow(ctx, x, y + h * 0.5, s * 1.1, s * 0.5, opt.ao === undefined ? 0.4 : opt.ao);
    for (var e = 0; e < 4; e++) {
      var a0 = top[e]; var a1 = top[(e + 1) % 4];
      var midY = (a0[1] + a1[1]) / 2 - (y - h * 0.5);
      if (midY <= 0) continue;
      var nx = (a1[1] - a0[1]);
      var face = [a0, a1, bot[(e + 1) % 4], bot[e]];
      ctx.beginPath();
      polyPath(face)(ctx);
      ctx.fillStyle = R.shade(col, nx > 0 ? -0.12 : -0.34);
      ctx.fill();
    }
    var tb = boundsOf(top);
    ctx.beginPath();
    polyPath(top)(ctx);
    R.litFill(ctx, tb.x + tb.w / 2, tb.y + tb.h / 2, Math.max(tb.w, tb.h) / 2, R.shade(col, 0.06), { lift: 0.28, drop: 0.12 });
    R.innerShade(ctx, silPath, b.x, b.y, b.w, b.h, { depth: s * 0.18, blur: s * 0.3, darkA: 0.30, light: R.shade(col, 0.7), lightA: 0.25 });
    if (opt.gloss) glints(ctx, tb.x + tb.w / 2, tb.y + tb.h / 2, tb.w / 2, tb.h / 2, s * 0.8, opt.gloss, rng);
    return { path: silPath, b: b };
  }

  /**
   * One piece of one ingredient, as it looks IN a dish.
   * @param {object} ctx Context.
   * @param {string} kind From pieceKind().
   * @param {object} ing The ingredient.
   * @param {number} x Centre x.
   * @param {number} y Centre y.
   * @param {number} s Size (half-width).
   * @param {function():number} rng Seeded stream.
   * @param {object} [o] {ao, gloss, char}
   * @returns {{path:function, b:object}} the silhouette, for submerge()
   */
  function piece(ctx, kind, ing, x, y, s, rng, o) {
    var R = deps();
    var opt = o || {};
    var col = cookedColour(ing, kind);
    /* a piece that has simmered in a liquid takes a little of its colour — a
     * turnip in beef broth is not paper-white (art stage, 2026-09-10) */
    if (opt.tint && kind !== 'meat') col = R.mix(col, opt.tint, 0.22);
    var head = String(ing.head || '').toLowerCase();
    var rot = rng() * TAU;
    var pts;
    if (kind === 'meat') {
      /* ⛔ A braised chunk is ANGULAR. A round blob with its lower half in the
       * gravy read as an olive (art stage, 2026-09-10): the meat is a rough
       * cube, browned on its top, fibrous, glossy where the sauce clings. */
      var mc = cube(ctx, x, y, s * 0.82, R.shade(col, 0.08), rng, rot, { ao: opt.ao, gloss: opt.gloss === undefined ? 0.5 : opt.gloss });
      ctx.save();
      ctx.beginPath();
      mc.path(ctx);
      ctx.clip();
      R.stipple(ctx, mc.b.x + mc.b.w / 2, mc.b.y + mc.b.h / 2, mc.b.w / 2, mc.b.h / 2, rng, 8, Math.max(0.5, s * 0.10),
        R.shade(col, -0.5), R.shade(col, 0.45), 0.45);
      ctx.restore();
      return mc;
    }
    if (kind === 'fish') {
      pts = R.blobPts(x, y, s * 1.05, s * 0.72, rng, 0.20, 7, rot);
      solid(ctx, ptsPath(pts), boundsOf(pts), col, rng, {
        ao: opt.ao, gloss: 0.35, core: 0.30, rim: 0.30,
        detail: function (c, cx, cy, rx, ry) {
          for (var k = -1; k <= 1; k++) {
            c.beginPath();
            c.moveTo(cx + k * rx * 0.45 - rx * 0.15, cy - ry);
            c.quadraticCurveTo(cx + k * rx * 0.45 + rx * 0.2, cy, cx + k * rx * 0.45 - rx * 0.15, cy + ry);
            c.strokeStyle = R.rgba(R.shade(col, -0.35), 0.45);
            c.lineWidth = Math.max(0.5, s * 0.08);
            c.stroke();
          }
        },
      });
      return { path: ptsPath(pts), b: boundsOf(pts) };
    }
    if (kind === 'root' && (head === 'carrot' || head === 'parsnip' || head === 'leek' || head === 'radish' || head === 'beet')) {
      var coin = ellPath(x, y, s * 0.92, s * 0.60, (rng() - 0.5) * 0.3);
      var cb = ellBounds(x, y, s * 0.92, s * 0.60);
      solid(ctx, coin, cb, col, rng, {
        ao: opt.ao, gloss: 0.45, core: 0.35, rim: 0.30,
        detail: function (c, cx, cy, rx, ry) {
          c.beginPath();
          ellPath(cx, cy, rx * 0.48, ry * 0.48)(c);
          c.strokeStyle = R.rgba(R.shade(col, head === 'leek' ? -0.25 : 0.38), 0.65);
          c.lineWidth = Math.max(0.6, s * 0.09);
          c.stroke();
        },
      });
      return { path: coin, b: cb };
    }
    if (kind === 'root' || kind === 'dairy') {
      return cube(ctx, x, y, s * 0.78, col, rng, rot, { ao: opt.ao, gloss: 0.35 });
    }
    if (kind === 'fungus') {
      var L = [[-1, 0.05], [-0.92, -0.45], [-0.55, -0.86], [0, -0.98], [0.55, -0.86], [0.92, -0.45], [1, 0.05],
        [0.34, 0.10], [0.30, 0.92], [-0.30, 0.92], [-0.34, 0.10]];
      for (var i = 0; i < L.length; i++) { L[i][0] *= s; L[i][1] *= s * 0.8; }
      pts = place(L, x, y, (rng() - 0.5) * 1.6);
      var flesh = R.mix(col, '#E6D4B4', 0.55);
      var morel = head === 'morel';
      solid(ctx, ptsPath(pts), boundsOf(pts), flesh, rng, {
        ao: opt.ao, gloss: 0.3, core: 0.35, rim: 0.25,
        texture: morel ? { n: 14, size: Math.max(0.6, s * 0.16), dark: R.shade(col, -0.55), light: R.shade(col, -0.2), a: 0.85 } : null,
        detail: function (c) {
          c.beginPath();
          R.smoothPath(c, pts);
          c.strokeStyle = R.rgba(R.shade(col, -0.30), 0.9);
          c.lineWidth = Math.max(0.8, s * 0.16);
          c.stroke();
        },
      });
      return { path: ptsPath(pts), b: boundsOf(pts) };
    }
    if (kind === 'green') {
      var gl = [[-1.2, 0], [-0.4, -0.55], [0.5, -0.45], [1.2, 0.05], [0.5, 0.5], [-0.4, 0.45]];
      for (var j = 0; j < gl.length; j++) { gl[j][0] *= s; gl[j][1] *= s; }
      pts = place(jitter(gl, rng, s * 0.12), x, y, rot);
      solid(ctx, ptsPath(pts), boundsOf(pts), col, rng, {
        ao: opt.ao === undefined ? 0.25 : opt.ao, gloss: 0.45, core: 0.3, rim: 0.3,
        detail: function (c, cx, cy) {
          c.beginPath();
          c.moveTo(pts[0][0], pts[0][1]);
          c.lineTo(pts[3][0], pts[3][1]);
          c.strokeStyle = R.rgba(R.shade(col, 0.45), 0.55);
          c.lineWidth = Math.max(0.5, s * 0.08);
          c.stroke();
        },
      });
      return { path: ptsPath(pts), b: boundsOf(pts) };
    }
    if (kind === 'legume') {
      var peas = head === 'pea';
      var nb = peas ? 5 : 4;
      for (var lb = 0; lb < nb; lb++) {
        var la = rng() * TAU; var lr = Math.sqrt(rng()) * s * 0.9;
        var bx = x + Math.cos(la) * lr; var by = y + Math.sin(la) * lr * 0.6;
        var bp = peas ? ellPath(bx, by, s * 0.30, s * 0.28) : ellPath(bx, by, s * 0.44, s * 0.26, rng() * TAU);
        solid(ctx, bp, ellBounds(bx, by, s * 0.44, s * 0.3), R.shade(col, (rng() - 0.5) * 0.2), rng,
          { ao: opt.ao === undefined ? 0.3 : opt.ao, gloss: 0.7, core: 0.5, rim: 0.25 });
      }
      return { path: ellPath(x, y, s * 1.2, s * 0.8), b: ellBounds(x, y, s * 1.2, s * 0.8) };
    }
    if (kind === 'grain') {
      var n = 7;
      for (var k2 = 0; k2 < n; k2++) {
        var a = rng() * TAU; var rr = Math.sqrt(rng()) * s * 1.2;
        var gx = x + Math.cos(a) * rr; var gy = y + Math.sin(a) * rr * 0.6;
        var gp = ellPath(gx, gy, s * 0.30, s * 0.18, rng() * TAU);
        ctx.beginPath();
        gp(ctx);
        R.litFill(ctx, gx, gy, s * 0.3, col, { lift: 0.4, drop: 0.25 });
        R.glint(ctx, gx - s * 0.08, gy - s * 0.06, s * 0.12, s * 0.05, -0.5, 0.5);
      }
      var gb = ellBounds(x, y, s * 1.3, s * 0.8);
      return { path: ellPath(x, y, s * 1.3, s * 0.8), b: gb };
    }
    if (kind === 'egg') {
      var ep = ellPath(x, y, s * 1.0, s * 0.72, rot * 0.2);
      var eb = ellBounds(x, y, s, s * 0.72);
      solid(ctx, ep, eb, '#F6F0E2', rng, { ao: opt.ao, gloss: 0.4, core: 0.3, rim: 0.3,
        detail: function (c, cx, cy, rx, ry) {
          c.beginPath();
          ellPath(cx + rx * 0.05, cy + ry * 0.05, rx * 0.46, ry * 0.46)(c);
          R.litFill(c, cx, cy, rx * 0.5, '#E9A93A', { lift: 0.3, drop: 0.3 });
        } });
      return { path: ep, b: eb };
    }
    /* fruit, and anything else: a small glossy round */
    pts = R.blobPts(x, y, s * 0.8, s * 0.74, rng, 0.06, 8, rot);
    solid(ctx, ptsPath(pts), boundsOf(pts), col, rng, { ao: opt.ao, gloss: 0.8, core: 0.45, rim: 0.2 });
    return { path: ptsPath(pts), b: boundsOf(pts) };
  }

  /**
   * The pieces a wet dish shows, derived from its own ingredient list: how
   * many of each by mass, each drawn as that ingredient, back to front, each
   * lapped by the liquid it sits in.
   * @param {object} ctx Context.
   * @param {object} w Well.
   * @param {object} p Profile.
   * @param {function():number} rng Seeded stream.
   * @param {object} o {count, size, submerge, liquid, rMax, sep}
   * @returns {number} how many pieces were drawn
   */
  function piecesOf(ctx, w, p, rng, o) {
    var R = deps();
    var list = [];
    var ings = p.ingredients || [];
    for (var i = 0; i < ings.length; i++) {
      var k = pieceKind(ings[i]);
      if (!k) continue;
      var n = Math.max(1, Math.round((1 + ings[i].mass * 3) * (o.count || 1)));
      for (var j = 0; j < n; j++) list.push({ ing: ings[i], kind: k });
    }
    if (!list.length) return 0;
    for (var s = list.length - 1; s > 0; s--) {
      var r = Math.floor(rng() * (s + 1));
      var t = list[s]; list[s] = list[r]; list[r] = t;
    }
    var pts = R.scatter(rng, list.length, { rMin: 0.0, rMax: o.rMax || 0.78, sep: o.sep || 0.24, tries: 30 });
    var items = [];
    for (var q = 0; q < pts.length; q++) {
      items.push({ x: w.cx + pts[q].x * w.rx, y: w.cy + pts[q].y * w.ry / 0.82 * 0.92, it: list[q], k: pts[q].s });
    }
    items.sort(function (a, b) { return a.y - b.y; });
    var size = o.size || w.rx * 0.10;
    for (var m = 0; m < items.length; m++) {
      var kd = items[m].it.kind;
      var sz = size * (kd === 'grain' ? 0.55 : (kd === 'green' ? 0.9 : 1)) * (0.8 + items[m].k * 0.3);
      var drawn = piece(ctx, kd, items[m].it.ing, items[m].x, items[m].y, sz, rng,
        { ao: o.submerge ? 0.2 : 0.4, char: p.char * 0.5, tint: o.submerge ? o.liquid : null });
      if (drawn && o.submerge && kd !== 'grain' && kd !== 'legume') submerge(ctx, drawn.path, drawn.b, o.liquid, o.submerge * (0.7 + rng() * 0.6));
    }
    return items.length;
  }

  /* ============================================================== accents ===
   * The few things a cook adds that are named in the ingredient list and must
   * read as THEMSELVES: a slice of lemon, a sprig, a pat of butter, a clove. */

  /** A lemon (or orange) wheel lying flat: rind, pith, segments, wet. */
  function citrusWheel(ctx, x, y, r, rot, rind, flesh) {
    var R = deps();
    R.contactShadow(ctx, x, y + r * 0.2, r * 1.05, r * 0.6, 0.35);
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rot);
    ctx.scale(1, 0.62);
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.fillStyle = rind;
    ctx.fill();
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.88, 0, TAU);
    ctx.fillStyle = '#F7F0D8';
    ctx.fill();
    for (var i = 0; i < 9; i++) {
      var a0 = (i / 9) * TAU + 0.05; var a1 = ((i + 1) / 9) * TAU - 0.05;
      ctx.beginPath();
      ctx.moveTo(Math.cos((a0 + a1) / 2) * r * 0.08, Math.sin((a0 + a1) / 2) * r * 0.08);
      ctx.arc(0, 0, r * 0.80, a0, a1);
      ctx.closePath();
      var g = ctx.createRadialGradient(-r * 0.2, -r * 0.2, 0, 0, 0, r * 0.8);
      g.addColorStop(0, R.shade(flesh, 0.35));
      g.addColorStop(1, flesh);
      ctx.fillStyle = g;
      ctx.fill();
    }
    ctx.restore();
    R.glint(ctx, x - r * 0.3, y - r * 0.18, r * 0.35, r * 0.06, rot - 0.4, 0.55);
  }

  /** A sprig of a small-leaved herb: a stem and paired leaves. */
  function sprig(ctx, x, y, len, rot, colour, rng) {
    var R = deps();
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rot);
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-len / 2, 0);
    ctx.quadraticCurveTo(0, -len * 0.08, len / 2, len * 0.02);
    ctx.strokeStyle = R.shade(colour, -0.35);
    ctx.lineWidth = Math.max(0.8, len * 0.035);
    ctx.stroke();
    var pairs = 7;
    for (var i = 0; i < pairs; i++) {
      var t = (i + 0.6) / pairs;
      var px = -len / 2 + len * t; var py = -len * 0.08 * 4 * t * (1 - t);
      var ls = len * (0.10 - t * 0.04);
      for (var s = -1; s <= 1; s += 2) {
        ctx.save();
        ctx.translate(px, py);
        ctx.rotate(s * 0.9 + (rng() - 0.5) * 0.3);
        ctx.beginPath();
        ctx.ellipse(ls * 0.6, 0, Math.max(0.3, ls * 0.62), Math.max(0.2, ls * 0.26), 0, 0, TAU);
        ctx.fillStyle = R.shade(colour, (rng() - 0.3) * 0.3);
        ctx.fill();
        ctx.restore();
      }
    }
    ctx.restore();
  }

  /** A pat of butter, softening into a glossy pool. */
  function butterPat(ctx, x, y, s, rng) {
    var R = deps();
    R.puff(ctx, x + s * 0.2, y + s * 0.3, s * 1.8, '#F2D27A', 0.35);
    cube(ctx, x, y, s * 0.7, '#F1D986', rng, 0.5 + rng() * 0.4, { ao: 0.2, gloss: 0.8 });
  }

  /** A clove pressed into a crust: a four-pointed head on a dark stalk. */
  function clove(ctx, x, y, s) {
    var R = deps();
    ctx.save();
    ctx.translate(x, y);
    ctx.beginPath();
    for (var i = 0; i < 4; i++) {
      var a = i * Math.PI / 2 + 0.4;
      ctx.lineTo(Math.cos(a) * s, Math.sin(a) * s * 0.7);
      ctx.lineTo(Math.cos(a + Math.PI / 4) * s * 0.35, Math.sin(a + Math.PI / 4) * s * 0.25);
    }
    ctx.closePath();
    ctx.fillStyle = '#3A2214';
    ctx.fill();
    ctx.beginPath();
    ctx.arc(-s * 0.1, -s * 0.12, Math.max(0.4, s * 0.28), 0, TAU);
    ctx.fillStyle = R.rgba('#C98A55', 0.8);
    ctx.fill();
    ctx.restore();
  }

  /** A drizzle — honey, syrup, cream — as a ribbon: dark edge, body, a thread of light. */
  function drizzle(ctx, pts, lw, colour) {
    var R = deps();
    if (pts.length < 2) return;
    function path() {
      ctx.beginPath();
      ctx.moveTo(pts[0][0], pts[0][1]);
      for (var i = 1; i < pts.length - 1; i++) {
        var mx = (pts[i][0] + pts[i + 1][0]) / 2; var my = (pts[i][1] + pts[i + 1][1]) / 2;
        ctx.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
      }
      ctx.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
    }
    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    path();
    ctx.strokeStyle = R.rgba(R.shade(colour, -0.45), 0.75);
    ctx.lineWidth = lw * 1.3;
    ctx.stroke();
    path();
    ctx.strokeStyle = R.rgba(colour, 0.92);
    ctx.lineWidth = lw;
    ctx.stroke();
    ctx.translate(-lw * 0.18, -lw * 0.22);
    path();
    ctx.strokeStyle = R.rgba('#FFFFFF', 0.45);
    ctx.lineWidth = Math.max(0.5, lw * 0.22);
    ctx.stroke();
    ctx.restore();
  }

  /* ============================================================== liquids === */

  /**
   * The top of a liquid: a plane in a deep vessel, a thick irregular pool on a
   * flat one. Darker at the back where the wall shades it, the window's
   * reflection on the upper left, glints, and the meniscus at the edge.
   * @param {object} o {colour, alpha, gloss, eyes, detail(ctx, surface)}
   * @returns {{path:function, b:object, s:object}}
   */
  function liquidSurface(ctx, w, p, rng, o) {
    var R = deps();
    var s = w.surface || { cx: w.cx, cy: w.cy, rx: w.rx * 1.04, ry: w.ry * 1.04 };
    var path = w.surface ? ellPath(s.cx, s.cy, s.rx, s.ry)
      : ptsPath(R.blobPts(s.cx, s.cy, s.rx * 0.96, s.ry * 0.96, R.rngFrom((p.seed ^ 0x33) >>> 0), 0.06, 12, 0));
    var b = ellBounds(s.cx, s.cy, s.rx, s.ry);
    var col = o.colour;
    var gl = o.gloss === undefined ? 0.5 : o.gloss;
    if (!w.surface) R.contactShadow(ctx, s.cx, s.cy + s.ry * 0.2, s.rx * 1.02, s.ry * 0.8, 0.3);
    ctx.beginPath();
    path(ctx);
    var g = ctx.createLinearGradient(0, s.cy - s.ry, 0, s.cy + s.ry);
    g.addColorStop(0, R.shade(col, -0.34));
    g.addColorStop(0.5, col);
    g.addColorStop(1, R.shade(col, 0.10));
    ctx.save();
    ctx.globalAlpha = o.alpha === undefined ? 1 : o.alpha;
    ctx.fillStyle = g;
    ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.beginPath();
    path(ctx);
    ctx.clip();
    R.puff(ctx, s.cx - s.rx * 0.36, s.cy - s.ry * 0.40, s.rx * 0.62, '#FFF3DC', 0.08 + gl * 0.12);
    if (o.detail) o.detail(ctx, s);
    var eyes = o.eyes || 0;
    for (var i = 0; i < eyes; i++) {
      var a = rng() * TAU; var rr = Math.sqrt(rng()) * 0.85;
      var ex = s.cx + Math.cos(a) * s.rx * rr; var ey = s.cy + Math.sin(a) * s.ry * rr;
      var er = s.rx * (0.012 + rng() * rng() * 0.05);
      ctx.beginPath();
      ellPath(ex, ey, er, er * 0.62)(ctx);
      ctx.fillStyle = R.rgba(R.mix(col, '#F2C86A', 0.45), 0.35);
      ctx.fill();
      ctx.strokeStyle = R.rgba(R.shade(col, 0.55), 0.55);
      ctx.lineWidth = Math.max(0.5, er * 0.25);
      ctx.stroke();
      R.glint(ctx, ex - er * 0.35, ey - er * 0.3, er * 0.5, er * 0.18, -0.4, 0.7);
    }
    ctx.restore();
    edgeArcs(ctx, s.cx, s.cy, s.rx, s.ry, col, Math.max(0.8, s.rx * 0.012), 0.5);
    R.glint(ctx, s.cx - s.rx * 0.46, s.cy - s.ry * 0.50, s.rx * 0.22, Math.max(0.5, s.ry * 0.05), -0.18, 0.35 + gl * 0.35);
    R.glint(ctx, s.cx - s.rx * 0.18, s.cy - s.ry * 0.62, s.rx * 0.10, Math.max(0.4, s.ry * 0.035), -0.1, 0.25 + gl * 0.3);
    return { path: path, b: b, s: s };
  }

  /* ================================================================ roast ===
   * One form, four pictures, chosen by WHAT is being roasted. */

  var BIRDS = ['chicken', 'fowl', 'duck', 'goose', 'quail', 'pigeon', 'pheasant'];

  /** @returns {string} joint | ribs | bird | roots */
  function roastForm(p) {
    if (findIng(p, ['ribs'])) return 'ribs';
    if (findIng(p, BIRDS)) return 'bird';
    if (ax(p, 'meat') + ax(p, 'fish') < 0.25 && ax(p, 'root') + ax(p, 'fungus') + ax(p, 'green') > 0.25) return 'roots';
    return 'joint';
  }

  /** The knuckle of a roast's bone: a shaft and a two-lobed condyle with a notch — never a pill. */
  function boneEnd(ctx, x, y, rot, L, rng) {
    var R = deps();
    var loc = [[0.48, -0.055], [0.84, -0.070], [0.90, -0.150], [0.975, -0.165], [1.035, -0.105],
      [1.005, -0.035], [1.05, 0.030], [1.00, 0.095], [0.905, 0.085], [0.85, 0.035], [0.48, 0.050]];
    for (var i = 0; i < loc.length; i++) { loc[i][0] *= L; loc[i][1] *= L; }
    var pts = place(loc, x, y, rot);
    var b = boundsOf(pts);
    solid(ctx, ptsPath(pts), b, '#E8DCC2', rng, {
      ao: 0.45, gloss: 0.25, core: 0.50, rim: 0.40, depthK: 0.35,
      texture: { n: 12, size: Math.max(0.4, L * 0.009), dark: '#9C8A6A', light: '#FFFFFF', a: 0.3 },
      detail: function (c) {
        var q = place([[0.55 * L, 0]], x, y, rot)[0];
        R.puff(c, q[0], q[1], L * 0.14, '#6A3A1A', 0.55);
      },
    });
  }

  /** Scored crackling: a diamond lattice cut into the skin, opened by the oven; cloves at the crossings. */
  function scoreSkin(c, x, y, rot, L, skin, studs, rng) {
    var R = deps();
    c.save();
    c.translate(x, y);
    c.rotate(rot);
    var sp = L * 0.15;
    var dirs = [-0.72, 0.72];
    for (var d = 0; d < 2; d++) {
      var ux = Math.cos(dirs[d]); var uy = Math.sin(dirs[d]);
      for (var k = -9; k <= 9; k++) {
        var ox = -uy * k * sp; var oy = ux * k * sp;
        c.beginPath();
        c.moveTo(ox - ux * L * 1.6, oy - uy * L * 1.6);
        c.lineTo(ox + ux * L * 1.6, oy + uy * L * 1.6);
        c.strokeStyle = R.rgba(R.shade(skin, -0.6), 0.42);
        c.lineWidth = Math.max(0.7, L * 0.016);
        c.stroke();
        c.beginPath();
        c.moveTo(ox - ux * L * 1.6 + 1.1, oy - uy * L * 1.6 - 1.1);
        c.lineTo(ox + ux * L * 1.6 + 1.1, oy + uy * L * 1.6 - 1.1);
        c.strokeStyle = R.rgba(R.shade(skin, 0.55), 0.20);
        c.lineWidth = Math.max(0.5, L * 0.008);
        c.stroke();
      }
    }
    if (studs) {
      var u1x = Math.cos(dirs[0]); var u1y = Math.sin(dirs[0]);
      var u2x = Math.cos(dirs[1]); var u2y = Math.sin(dirs[1]);
      var det = u1x * (-u2y) - u1y * (-u2x);
      for (var a = -6; a <= 6; a++) {
        for (var b2 = -6; b2 <= 6; b2++) {
          if ((a + b2) % 2 !== 0) continue;
          var ax1 = -u1y * a * sp; var ay1 = u1x * a * sp;
          var bx1 = -u2y * b2 * sp; var by1 = u2x * b2 * sp;
          var rx = bx1 - ax1; var ry = by1 - ay1;
          var t = (rx * (-u2y) - ry * (-u2x)) / det;
          var px = ax1 + u1x * t; var py = ay1 + u1y * t;
          if (Math.abs(px) > L || Math.abs(py) > L * 0.5) continue;
          clove(c, px, py, Math.max(1.2, L * 0.035));
        }
      }
    }
    c.restore();
  }

  /** The cut end of a joint: crust, a ring of fat, then the cooked meat with its grain. */
  function carvedFace(ctx, x, y, rx, ry, rot, skin, inner, rng) {
    var R = deps();
    ctx.beginPath();
    ellPath(x, y, rx, ry, rot)(ctx);
    ctx.fillStyle = R.shade(skin, -0.30);
    ctx.fill();
    ctx.beginPath();
    ellPath(x - rx * 0.03, y - ry * 0.03, rx * 0.90, ry * 0.88, rot)(ctx);
    ctx.fillStyle = '#E4CFAA';
    ctx.fill();
    var mp = ellPath(x - rx * 0.05, y - ry * 0.05, rx * 0.78, ry * 0.74, rot);
    ctx.beginPath();
    mp(ctx);
    R.litFill(ctx, x, y, rx * 0.8, inner, { lift: 0.26, drop: 0.28 });
    ctx.save();
    ctx.beginPath();
    mp(ctx);
    ctx.clip();
    for (var i = 1; i < 6; i++) {
      ctx.beginPath();
      ctx.ellipse(x + rx * 0.2, y + ry * 0.25, Math.max(0.1, rx * i * 0.17), Math.max(0.1, ry * i * 0.15), rot, Math.PI * 0.9, Math.PI * 1.9);
      ctx.strokeStyle = R.rgba(R.shade(inner, -0.4), 0.18);
      ctx.lineWidth = Math.max(0.5, rx * 0.03);
      ctx.stroke();
    }
    ctx.restore();
    R.innerShade(ctx, mp, x - rx, y - ry, rx * 2, ry * 2, { depth: ry * 0.18, blur: ry * 0.3, darkA: 0.35, light: '#FFFFFF', lightA: 0.18 });
    R.glint(ctx, x - rx * 0.28, y - ry * 0.25, rx * 0.30, ry * 0.07, rot, 0.45);
  }

  /**
   * The cut end of a RACK, which is a different object from the carved end of a
   * joint and must not be drawn with `carvedFace`.
   *
   * ⛔ A tall narrow oval with a pale ring, a darker interior and a centred
   * glint is an EYE (polish stage, 2026-09-11: the item-detail hero read as a
   * grub — ringed eye at one end, segmented body, pale stubs beneath). §22's
   * collision failure: every mark rendered, the deck read as something else.
   * The cut end of a rack shows meat with the rib sections in a ROW down it,
   * crust along the TOP edge only, and no ring and no iris highlight.
   *
   * @param {CanvasRenderingContext2D} ctx canvas context
   * @param {number} x centre x of the cut face, in world pixels
   * @param {number} y centre y of the cut face, in world pixels
   * @param {number} rx half-width of the cut (the rack's thickness)
   * @param {number} ry half-height of the cut (the rack's depth)
   * @param {number} rot plate rotation, radians
   * @param {string} crust the lacquered outside colour
   * @param {string} meat the cut muscle colour
   * @param {number} nb how many rib sections the cut crosses
   * @param {function():number} rng seeded RNG (§6 rule 2 — never Math.random)
   * @returns {void}
   */
  function ribCutFace(ctx, x, y, rx, ry, rot, crust, meat, nb, rng) {
    var R = deps();
    /* ⛔ AN ELLIPSE AT EACH END OF AN ELONGATED BODY IS A PAIR OF EYES, whatever
     * is drawn inside it (art-director defect 2, polish stage 2026-09-11): the
     * rack read as a segmented creature with a pale round face and a bone dot at
     * each end. A rack is SAWN, so its cut is a rectangle with a corner radius
     * you can barely see — the flat top and the two square corners are the
     * strongest single cue in the whole form that this is a cut object. */
    var face = function (c) {
      c.save();
      c.translate(x, y);
      c.rotate(rot);
      R.rrect(c, -rx, -ry, rx * 2, ry * 2, Math.min(rx, ry) * 0.22);
      c.restore();
    };
    ctx.beginPath();
    face(ctx);
    /* ⛔ THE CUT FACE MUST BE A FACET OF THE SAME OBJECT, NOT A PANEL ON IT: at
     * full `meat` it sat two values lighter than the charred body and read as a
     * plate bolted to each end (polish stage, second look 2026-09-11). Most of
     * the crust's value, a little of the muscle's colour. */
    var cutCol = R.mix(crust, meat, 0.42);
    R.litFill(ctx, x, y - ry * 0.2, ry * 0.9, cutCol, { lift: 0.16, drop: 0.34 });
    ctx.save();
    ctx.beginPath();
    face(ctx);
    ctx.clip();
    /* crust along the TOP edge only — the rack is lacquered on its back, not
     * all the way round, so a full rim would be the ring that made the iris */
    ctx.beginPath();
    ellPath(x, y - ry * 0.98, rx * 1.25, ry * 0.34, rot)(ctx);
    ctx.fillStyle = R.rgba(R.shade(crust, -0.10), 0.95);
    ctx.fill();
    /* ⛔ THE RIB SECTIONS WERE A DIAGONAL PAIR NEAR THE CORNERS, WHICH ON A
     * RECTANGULAR FACE IS TWO SCREW HEADS. A row down the cut means down the
     * MIDDLE of it, tight to the centre line, and smaller than the face. */
    for (var i = 0; i < nb; i++) {
      var t = nb === 1 ? 0.5 : 0.36 + (i / (nb - 1)) * 0.28;
      var by = y - ry + t * ry * 2;
      var bx = x;
      var brx = Math.max(0.5, rx * 0.26);
      var bry = Math.max(0.5, ry * 0.065);
      ctx.beginPath();
      ellPath(bx, by, brx, bry, rot)(ctx);
      ctx.fillStyle = R.rgba('#D8C8A6', 0.86);
      ctx.fill();
      ctx.beginPath();
      ellPath(bx, by, brx * 0.48, bry * 0.5, rot)(ctx);
      ctx.fillStyle = R.rgba('#8A6A4A', 0.6);
      ctx.fill();
    }
    /* grain running across the cut, not concentric rings */
    for (var g = 0; g < 4; g++) {
      var gy = y - ry * 0.55 + (g / 3) * ry * 1.1;
      ctx.beginPath();
      ctx.moveTo(x - rx, gy);
      ctx.quadraticCurveTo(x, gy + ry * 0.05, x + rx, gy - ry * 0.02);
      ctx.strokeStyle = R.rgba(R.shade(meat, -0.42), 0.2);
      ctx.lineWidth = Math.max(0.4, rx * 0.10);
      ctx.stroke();
    }
    ctx.restore();
    R.innerShade(ctx, face, x - rx, y - ry, rx * 2, ry * 2, { depth: ry * 0.12, blur: ry * 0.26, darkA: 0.4, light: '#FFFFFF', lightA: 0.10 });
  }

  /** A carved slice lying flat: its cut face, a crust rim along one edge, a line of fat. */
  function carvedSlice(ctx, x, y, rx, ry, rot, skin, inner, rng) {
    var R = deps();
    var pts = R.blobPts(x, y, rx, ry, rng, 0.07, 10, rot);
    var b = boundsOf(pts);
    R.contactShadow(ctx, x, y + ry * 0.4, rx * 1.05, ry * 0.8, 0.45);
    ctx.beginPath();
    R.smoothPath(ctx, pts);
    ctx.fillStyle = R.shade(skin, -0.12);
    ctx.fill();
    var inPts = [];
    for (var i = 0; i < pts.length; i++) {
      inPts.push([x + (pts[i][0] - x) * 0.86 - rx * 0.03, y + (pts[i][1] - y) * 0.80 - ry * 0.06]);
    }
    solid(ctx, ptsPath(inPts), boundsOf(inPts), inner, rng, {
      ao: 0, gloss: 0.45, core: 0.28, rim: 0.2,
      detail: function (c, cx, cy, hrx, hry) {
        c.save();
        c.translate(cx, cy);
        c.rotate(rot + 0.9);
        for (var k = -6; k <= 6; k++) {
          c.beginPath();
          c.moveTo(k * hrx * 0.16, -hry * 2);
          c.lineTo(k * hrx * 0.16 + hrx * 0.05, hry * 2);
          c.strokeStyle = R.rgba(R.shade(inner, -0.35), 0.14);
          c.lineWidth = Math.max(0.5, hrx * 0.03);
          c.stroke();
        }
        c.restore();
        c.beginPath();
        c.ellipse(cx, cy - hry * 0.78, hrx * 0.92, hry * 0.30, 0, Math.PI * 1.05, Math.PI * 1.95);
        c.strokeStyle = R.rgba('#EAD8B6', 0.85);
        c.lineWidth = Math.max(0.8, hry * 0.22);
        c.stroke();
      },
    });
    R.innerShade(ctx, ptsPath(pts), b.x, b.y, b.w, b.h, { depth: ry * 0.14, blur: ry * 0.2, darkA: 0.3, lightA: 0 });
  }

  function drawJoint(ctx, w, p, rng) {
    var R = deps();
    var L = Math.min(w.rx * 0.90, w.ry * 2.1);
    var slices = clamp(p.portions - 1, 0, 4);
    var jx = w.cx - (slices ? L * 0.22 : 0);
    var jy = w.cy - (slices ? w.ry * 0.18 : 0);
    var rot = -0.20;
    var skin = R.shade(R.mix(p.bodyColour, '#A8622E', 0.55), -p.char * 0.20);
    var inner = R.mix(p.bodyColour, '#D08878', 0.55);
    var local = [[0.60, -0.11], [0.30, -0.22], [-0.10, -0.36], [-0.48, -0.40], [-0.80, -0.20], [-0.84, 0.08],
      [-0.62, 0.32], [-0.24, 0.38], [0.14, 0.28], [0.44, 0.15], [0.62, 0.07]];
    for (var i = 0; i < local.length; i++) { local[i][0] *= L; local[i][1] *= L; }
    jitter(local, rng, L * 0.022);
    var world = place(local, jx, jy, rot);
    var b = boundsOf(world);
    boneEnd(ctx, jx, jy, rot, L, rng);
    var crackling = ax(p, 'fat') > 0.15 || !!findIng(p, ['pork', 'boar', 'bacon']);
    var studs = findIng(p, ['clove']);
    solid(ctx, ptsPath(world), b, skin, rng, {
      ao: 0.55, gloss: p.gloss, char: p.char * 0.9, core: 0.55, rim: 0.30, depthK: 0.26, blurK: 0.42,
      texture: { n: Math.round(L * 1.2), size: Math.max(0.5, L * 0.013), dark: R.shade(skin, -0.5), light: R.shade(skin, 0.45), a: 0.45 },
      detail: crackling ? function (c) { scoreSkin(c, jx, jy, rot, L, skin, studs, rng); } : null,
    });
    var honey = findIng(p, ['honey', 'syrup']);
    if (honey) {
      /* ⛔ One drizzled line across the joint read as a yellow STRAW (art
       * stage, 2026-09-10). A glaze is a sheen that follows the form: amber
       * light on the crown, runs pooled in the low places, glints. */
      ctx.save();
      ctx.beginPath();
      R.smoothPath(ctx, world);
      ctx.clip();
      var amber = honey.head === 'syrup' ? '#8E5A1E' : '#D8921E';
      var crown = place([[-0.30 * L, -0.18 * L], [0.15 * L, -0.10 * L]], jx, jy, rot);
      R.puff(ctx, crown[0][0], crown[0][1], L * 0.42, amber, 0.35);
      R.puff(ctx, crown[1][0], crown[1][1], L * 0.30, amber, 0.28);
      for (var gr = 0; gr < 5; gr++) {
        var gp = place([[(-0.6 + gr * 0.26) * L, (0.08 + (gr % 2) * 0.06) * L]], jx, jy, rot)[0];
        R.puff(ctx, gp[0], gp[1], L * 0.08, R.shade(amber, -0.3), 0.45);
      }
      ctx.restore();
      glints(ctx, jx, jy - L * 0.06, L * 0.7, L * 0.3, L * 0.3, 0.9, rng);
    }
    var sprigHerb = findIng(p, ['thyme', 'rosemary', 'sage', 'bay'], true);
    if (sprigHerb) sprig(ctx, jx + L * 0.10, jy - L * 0.34, L * 0.62, -0.28, R.shade(sprigHerb.colour, 0.05), rng);
    var fc = place([[-0.60 * L, 0.15 * L]], jx, jy, rot)[0];
    carvedFace(ctx, fc[0], fc[1], L * 0.24, L * 0.18, rot - 0.55, skin, inner, rng);
    for (var s = slices - 1; s >= 0; s--) {
      carvedSlice(ctx, w.cx + L * (0.10 + s * 0.26), w.cy + w.ry * (0.46 - s * 0.07), L * 0.30, L * 0.17,
        -0.35 + s * 0.12, skin, inner, rng);
    }
  }

  /**
   * Every bone of a rack rakes off one spine, so the lean is shared, not
   * per-bone — and it is STEEP. ⛔ A near-vertical stub under a body is a leg
   * whatever else is true of it (polish stage, 2026-09-11); measured by eye at
   * 0.30 rad (17deg, still legs) and 0.80 rad (46deg, reads as a raked rack).
   */
  var RACK_RAKE = 0.80;

  function drawRibs(ctx, w, p, rng) {
    var R = deps();
    var L = Math.min(w.rx * 0.90, w.ry * 2.1);
    var n = clamp(3 + p.portions, 4, 8);
    var rot = -0.12;
    var lacquer = R.shade(R.mix(p.bodyColour, '#6A2716', 0.5), -p.char * 0.12);
    var embers = ax(p, 'arcane') > 0.12;
    var xs = [];
    for (var i = 0; i < n; i++) xs.push(-L * 0.80 + ((i + 0.5) / n) * L * 1.60);
    /* ⛔ Evenly spaced, equal, straight stubs read as a COMB of teeth (art
     * stage, 2026-09-10). A rack's bones differ in length, lean a little,
     * curve, and end in a knob scorched by the fire. */
    for (var j = 0; j < n; j++) {
      /* ⛔ Long thin bones hanging under the rack read as the LEGS of a table
       * (item-detail capture, art stage 2026-09-10): a rib end is short and
       * thick, and most of its length is under the meat. */
      var bx = xs[j] + (rng() - 0.5) * L * 0.04;
      /* ⛔ Equal exposed lengths are a COMB. A real rack is trimmed unevenly and
       * the meat rides further up some bones than others, so the spread has to
       * be wide enough to break the rhythm, not a 40% wobble. */
      var blen = L * (0.15 + rng() * 0.19);
      /* ⛔ A per-bone RANDOM lean splays the stubs, and splayed stubs under a
       * body are LEGS (polish stage, 2026-09-11). Every bone in a rack comes
       * off one spine, so they all rake the SAME way; only the amount jitters. */
      var lean = RACK_RAKE + (rng() - 0.5) * 0.09;
      /* ⛔ At the item detail's 1.4x a fat pale stub is a knuckle, not a bone
       * (polish stage, 2026-09-11). A rib bone is thin for its length. */
      var bw = L * (0.040 + rng() * 0.010);
      var loc = [];
      for (var q = 0; q <= 4; q++) {
        var t = q / 4;
        var yy = 0.10 * L + t * blen;
        var xx = bx + Math.sin(lean) * t * blen + Math.sin(t * Math.PI) * L * 0.012;
        loc.push([xx, yy]);
      }
      var outline = [];
      for (var q2 = 0; q2 < loc.length; q2++) outline.push([loc[q2][0] - bw, loc[q2][1]]);
      var tip = loc[loc.length - 1];
      outline.push([tip[0] - bw * 1.3, tip[1] + bw * 0.6], [tip[0], tip[1] + bw * 1.5], [tip[0] + bw * 1.3, tip[1] + bw * 0.6]);
      for (var q3 = loc.length - 1; q3 >= 0; q3--) outline.push([loc[q3][0] + bw, loc[q3][1]]);
      var bp = place(outline, w.cx, w.cy, rot);
      var bb = boundsOf(bp);
      solid(ctx, ptsPath(bp), bb, '#E6D8BC', rng, {
        ao: 0.35, core: 0.45, rim: 0.35, gloss: 0.2,
        detail: function (c) {
          var root = place([[bx, 0.14 * L]], w.cx, w.cy, rot)[0];
          R.puff(c, root[0], root[1], L * 0.10, '#5A2A12', 0.7);
          /* ⛔ A dark blob on the end of a pale stub is a FOOT. A French-trimmed
           * bone end is scorched, not black, and the scorch is a graze. */
          var end = place([[tip[0], tip[1] + bw * 0.8]], w.cx, w.cy, rot)[0];
          R.puff(c, end[0], end[1], bw * 1.1, '#6B3A1C', 0.12 + rng() * 0.22);
        },
      });
    }
    /* the rack's outline is SCALLOPED — a swell over every rib, a dip between —
     * which is the silhouette that says ribs rather than loaf */
    var local = [[-1.02, 0.03], [-0.97, -0.20]];
    for (var tq = 0; tq < n; tq++) {
      var ux = xs[tq] / L;
      local.push([ux - 0.06, -0.30], [ux, -0.345]);
      if (tq < n - 1) local.push([(xs[tq] + xs[tq + 1]) / 2 / L, -0.300]);
    }
    local.push([0.95, -0.24], [1.03, -0.07], [1.00, 0.12]);
    for (var bq = n - 1; bq >= 0; bq--) {
      var bxq = xs[bq] / L;
      local.push([bxq + 0.04, 0.235]);
      if (bq > 0) local.push([(xs[bq] + xs[bq - 1]) / 2 / L, 0.195]);
    }
    local.push([-0.94, 0.20]);
    for (var k = 0; k < local.length; k++) { local[k][0] *= L; local[k][1] *= L; }
    jitter(local, rng, L * 0.008);
    var world = place(local, w.cx, w.cy, rot);
    solid(ctx, ptsPath(world), boundsOf(world), lacquer, rng, {
      ao: 0.55, gloss: Math.max(0.6, p.gloss), char: p.char, core: 0.55, rim: 0.25, depthK: 0.24,
      /* bark: the rub and the fire's crust, dense enough to read as meat's
       * surface at the item detail's close range */
      texture: { n: Math.round(L * 2.2), size: Math.max(0.5, L * 0.014), a: 0.5 },
      detail: function (c) {
        c.save();
        c.translate(w.cx, w.cy);
        c.rotate(rot);
        /* ⛔⛔ THE SEGMENT LINES CROSSED THE ENTIRE BODY AND THE MEAT WAS ONE
         * FLAT TONE, so before the card named it the silhouette still read as a
         * segmented creature (art-director defect 2, polish stage 2026-09-11).
         * A rack is a SLAB, and a slab has two faces with an edge between them:
         * a dark glossy BARK on the top, a paler cut MEAT face down the front
         * where the bones come out. The gutters between ribs belong on the front
         * face ONLY — a line running over the crown is what makes a tube out of
         * a slab, and a tube with regular bands on it is a grub. */
        var arris = -L * 0.055;
        var bark = R.shade(R.mix(lacquer, '#3A1408', 0.42), -0.06);
        c.save();
        c.beginPath();
        c.rect(-L * 1.2, -L * 0.60, L * 2.4, (arris + L * 0.60));
        c.clip();
        var bg = c.createLinearGradient(0, -L * 0.38, 0, arris);
        bg.addColorStop(0, R.rgba(R.shade(bark, 0.10), 0.92));
        bg.addColorStop(1, R.rgba(bark, 0.86));
        c.fillStyle = bg;
        c.fillRect(-L * 1.2, -L * 0.60, L * 2.4, arris + L * 0.60);
        /* the crust: bark is not a flat colour, it is a scorched crumb */
        for (var bk = 0; bk < Math.round(L * 1.6); bk++) {
          var kx = (rng() - 0.5) * L * 2.0;
          var ky = arris - rng() * L * 0.30;
          c.beginPath();
          c.arc(kx, ky, Math.max(0.4, L * (0.004 + rng() * 0.010)), 0, TAU);
          c.fillStyle = R.rgba(rng() < 0.55 ? '#1A0A04' : R.shade(bark, 0.45), 0.18 + rng() * 0.34);
          c.fill();
        }
        /* the swell over each rib, ON THE BARK ONLY, with its short glint */
        for (var sw = 0; sw < n; sw++) {
          c.beginPath();
          c.moveTo(xs[sw] - L * 0.01, -L * 0.32);
          c.quadraticCurveTo(xs[sw] + L * 0.015, arris * 0.5, xs[sw], arris);
          c.strokeStyle = R.rgba(R.shade(bark, 0.50), 0.20);
          c.lineWidth = Math.max(1, L * 0.055);
          c.stroke();
          R.glint(c, xs[sw] - L * 0.012, -L * 0.20, L * 0.042, L * 0.011, Math.PI / 2, 0.46);
        }
        c.restore();
        /* the FRONT face: paler cut muscle, so the two faces differ in VALUE and
         * not only in the marks on them — a slab you can see the thickness of */
        c.save();
        c.beginPath();
        c.rect(-L * 1.2, arris, L * 2.4, L * 0.9);
        c.clip();
        var fg = c.createLinearGradient(0, arris, 0, L * 0.26);
        fg.addColorStop(0, R.rgba(R.shade(R.mix(lacquer, '#C4705A', 0.42), 0.10), 0.62));
        fg.addColorStop(0.62, R.rgba(R.mix(lacquer, '#A85644', 0.34), 0.42));
        fg.addColorStop(1, R.rgba('#2A1008', 0.30));
        c.fillStyle = fg;
        c.fillRect(-L * 1.2, arris, L * 2.4, L * 0.9);
        /* the grain of the cut, running ALONG the rack, across the gutters */
        for (var gr2 = 0; gr2 < 5; gr2++) {
          var gy2 = arris + L * (0.05 + gr2 * 0.042);
          c.beginPath();
          c.moveTo(-L * 0.98, gy2);
          c.quadraticCurveTo(0, gy2 + L * 0.012, L * 0.98, gy2 - L * 0.006);
          c.strokeStyle = R.rgba(R.shade(lacquer, -0.35), 0.16);
          c.lineWidth = Math.max(0.5, L * 0.011);
          c.stroke();
        }
        c.restore();
        /* ⛔ ONE STRAIGHT LINE FROM END TO END IS A MACHINED EDGE, AND WITH A
         * BLOCK AT EACH END IT READ AS A BENCH (polish stage, second look
         * 2026-09-11). The edge of a rack RISES over every rib and DIPS between
         * them, exactly where the gutters are, so the arris is drawn as the
         * scallop it really is and it ties the two faces to the bones. */
        function arrisAt(px) {
          var near = 0; var best = 1e9;
          for (var a2 = 0; a2 < n; a2++) { var dd = Math.abs(px - xs[a2]); if (dd < best) { best = dd; near = a2; } }
          var span = n > 1 ? Math.abs(xs[1] - xs[0]) : L;
          var t2 = Math.min(1, best / (span * 0.5));
          return arris - L * 0.020 * (1 - t2 * t2);
        }
        function arrisStroke(dy2, colour, alpha, wide) {
          c.beginPath();
          for (var sx2 = -L * 1.00; sx2 <= L * 1.00; sx2 += L * 0.04) {
            var yy2 = arrisAt(sx2) + dy2;
            if (sx2 <= -L * 1.00) c.moveTo(sx2, yy2); else c.lineTo(sx2, yy2);
          }
          c.strokeStyle = R.rgba(colour, alpha);
          c.lineWidth = Math.max(0.6, L * wide);
          c.stroke();
        }
        arrisStroke(L * 0.010, R.shade(lacquer, 0.62), 0.38, 0.015);
        arrisStroke(L * 0.026, '#2A1008', 0.24, 0.011);
        for (var q = 0; q < n - 1; q++) {
          var gx = (xs[q] + xs[q + 1]) / 2;
          /* the gutter, on the FRONT FACE only: it starts at the arris, never
           * above it, and it stops where the meat meets the bone */
          c.beginPath();
          c.moveTo(gx - L * 0.004, arris + L * 0.012);
          c.quadraticCurveTo(gx + L * 0.016, L * 0.10, gx + L * 0.004, L * 0.235);
          c.strokeStyle = R.rgba('#1E0C06', 0.46);
          c.lineWidth = Math.max(0.7, L * 0.018);
          c.stroke();
        }
        if (embers) {
          c.shadowColor = 'rgba(255,110,30,0.9)';
          c.shadowBlur = Math.max(2, L * 0.05);
          for (var e = 0; e < 7; e++) {
            var ex = (rng() - 0.5) * L * 1.6; var ey = (rng() - 0.5) * L * 0.4;
            c.beginPath();
            c.moveTo(ex, ey);
            for (var z = 0; z < 4; z++) { ex += L * (0.04 + rng() * 0.05); ey += (rng() - 0.5) * L * 0.08; c.lineTo(ex, ey); }
            c.strokeStyle = 'rgba(255,170,70,0.9)';
            c.lineWidth = Math.max(0.8, L * 0.012);
            c.stroke();
          }
          c.shadowBlur = 0;
          c.shadowColor = 'rgba(0,0,0,0)';
        }
        c.restore();
      },
    });
    /* ⛔ A rack is a SECTION cut out of a ribcage, so it is cut at BOTH ends.
     * One cut end and one closed end is the asymmetry of a head on a body, and
     * it is half of why this plate read as a grub (polish stage, 2026-09-11):
     * a symmetric object cannot be an animal. Both ends, the same cut. */
    /* ⛔ TWO BONE SECTIONS ON A RECTANGULAR END READ AS TWO RIVETS, and a block
     * at each end of a long body reads as the feet of a bench (polish stage,
     * second look 2026-09-11). One section, centred, on a narrower face that is
     * a FACET of the slab rather than a plate bolted to it. */
    var ribMeat = R.mix(p.bodyColour, '#B85A4A', 0.55);
    var endAt = place([[0.985 * L, 0.03 * L]], w.cx, w.cy, rot)[0];
    ribCutFace(ctx, endAt[0], endAt[1], L * 0.050, L * 0.205, rot, lacquer, ribMeat, 1, rng);
    var headAt = place([[-0.985 * L, 0.02 * L]], w.cx, w.cy, rot)[0];
    ribCutFace(ctx, headAt[0], headAt[1], L * 0.046, L * 0.196, rot, lacquer, ribMeat, 1, rng);
  }

  function drawBird(ctx, w, p, rng) {
    var R = deps();
    /* ⛔ A roast bird is MAHOGANY and fills its trencher: the first pass was
     * tan and a third of the vessel wide (art stage, 2026-09-10). */
    var L = Math.min(w.rx * 0.94, w.ry * 1.95);
    var skin = R.shade(R.mix(p.bodyColour, '#A35A24', 0.66), -p.char * 0.16);
    var bx = w.cx - L * 0.08; var by = w.cy - w.ry * 0.06;
    var rot = -0.10;
    function part(loc, colour, o) {
      for (var i = 0; i < loc.length; i++) { loc[i][0] *= L; loc[i][1] *= L; }
      var pts = place(jitter(loc, rng, L * 0.015), bx, by, rot);
      solid(ctx, ptsPath(pts), boundsOf(pts), colour, rng, o);
      return pts;
    }
    var tex = { n: Math.round(L * 1.4), size: Math.max(0.5, L * 0.014), dark: R.shade(skin, -0.45), light: R.shade(skin, 0.55), a: 0.5 };
    part([[-0.70, -0.30], [-0.42, -0.50], [-0.12, -0.46], [-0.30, -0.28]], R.shade(skin, -0.1), { ao: 0.3, gloss: p.gloss * 0.6, char: p.char, core: 0.5, rim: 0.2 });
    part([[-0.80, -0.04], [-0.64, -0.38], [-0.20, -0.52], [0.28, -0.48], [0.66, -0.28], [0.82, 0.02],
      [0.66, 0.34], [0.22, 0.48], [-0.28, 0.46], [-0.66, 0.30]], skin, {
      ao: 0.6, gloss: Math.max(0.55, p.gloss), char: p.char * 0.8, core: 0.62, rim: 0.34, depthK: 0.24, lift: 0.42, texture: tex,
      detail: function (c) {
        c.save();
        c.translate(bx, by);
        c.rotate(rot);
        c.beginPath();
        c.moveTo(-L * 0.6, -L * 0.02);
        c.quadraticCurveTo(0, -L * 0.10, L * 0.62, -L * 0.02);
        c.strokeStyle = R.rgba(R.shade(skin, -0.55), 0.35);
        c.lineWidth = Math.max(0.8, L * 0.02);
        c.stroke();
        c.restore();
        var hi = place([[-0.05 * L, -0.24 * L], [-0.05 * L, 0.22 * L]], bx, by, rot);
        R.puff(c, hi[0][0], hi[0][1], L * 0.34, R.shade(skin, 0.5), 0.35);
        R.puff(c, hi[1][0], hi[1][1], L * 0.30, R.shade(skin, 0.35), 0.22);
      },
    });
    for (var s = -1; s <= 1; s += 2) {
      var dx = 0.52; var dy = 0.24 + s * 0.13;
      part([[dx - 0.12, dy - 0.13], [dx + 0.14, dy - 0.12], [dx + 0.40, dy - 0.05], [dx + 0.46, dy + 0.02],
        [dx + 0.40, dy + 0.08], [dx + 0.14, dy + 0.14], [dx - 0.12, dy + 0.14], [dx - 0.20, dy]], skin, {
        ao: 0.45, gloss: p.gloss, char: p.char, core: 0.5, rim: 0.3, texture: { n: 10, size: tex.size, a: 0.4 },
      });
      var tip = place([[(dx + 0.46) * L, (dy + 0.015) * L]], bx, by, rot)[0];
      boneEnd(ctx, tip[0] - L * 0.34 * 0.95, tip[1], rot + 0.05, L * 0.34, rng);
    }
    part([[0.10, -0.46], [0.36, -0.54], [0.56, -0.44], [0.30, -0.34]], R.shade(skin, 0.05), { ao: 0.3, gloss: p.gloss * 0.7, char: p.char, core: 0.45, rim: 0.3 });
    var hb = findIng(p, ['sage', 'thyme', 'rosemary', 'bay'], true);
    if (hb) {
      sprig(ctx, bx - L * 0.55, by + L * 0.42, L * 0.55, 0.35, R.shade(hb.colour, 0.05), rng);
      sprig(ctx, bx + L * 0.10, by - L * 0.58, L * 0.45, -0.2, R.shade(hb.colour, -0.05), rng);
    }
  }

  function drawRoastRoots(ctx, w, p, rng) {
    var R = deps();
    var list = [];
    var ings = p.ingredients || [];
    for (var i = 0; i < ings.length; i++) {
      var k = pieceKind(ings[i]);
      if (k === 'root' || k === 'fungus' || k === 'green' || k === 'fruit') list.push(ings[i]);
    }
    if (!list.length) list.push({ colour: p.bodyColour, head: 'root', axes: ['root'] });
    /* ⛔ A one-ingredient `Baked Turnip` was two specks on a trencher (art
     * stage contact sheet, 2026-09-10). A single root is served as its two
     * halves, LARGE; a tray of them gets smaller the more there are. */
    var n = p.portions <= 1 ? 2 : clamp(2 + p.portions, 3, 7);
    var s = Math.min(w.rx * (n <= 2 ? 0.50 : (n > 4 ? 0.34 : 0.42)), w.ry * (n <= 2 ? 0.95 : 0.78));
    var pts = n <= 2 ? [{ x: -0.36, y: -0.08, s: 1.0, a: 0 }, { x: 0.40, y: 0.16, s: 0.9, a: 0 }]
      : R.scatter(rng, n, { rMin: 0, rMax: 0.66, sep: 0.46, tries: 40 });
    var items = [];
    for (var j = 0; j < pts.length; j++) items.push({ x: w.cx + pts[j].x * w.rx * 0.9, y: w.cy + pts[j].y * w.ry, k: pts[j].s });
    items.sort(function (a, b) { return a.y - b.y; });
    for (var m = 0; m < items.length; m++) {
      var ing = list[m % list.length];
      var head = String(ing.head || '').toLowerCase();
      var skinC = R.mix(ing.colour, '#B98A55', 0.2);
      var sz = s * (0.8 + items[m].k * 0.3);
      var x = items[m].x; var y = items[m].y;
      var rot = (rng() - 0.5) * 1.2;
      if (head === 'carrot' || head === 'parsnip') {
        var loc = [[-1.0, -0.14], [0.2, -0.26], [1.0, -0.10], [1.05, 0.02], [0.9, 0.12], [0.2, 0.24], [-1.0, 0.14], [-1.06, 0]];
        for (var q = 0; q < loc.length; q++) { loc[q][0] *= sz * 1.2; loc[q][1] *= sz * 1.2; }
        var bp = place(loc, x, y, rot);
        solid(ctx, ptsPath(bp), boundsOf(bp), R.mix(ing.colour, '#A8561E', 0.25), rng, {
          ao: 0.45, gloss: p.gloss, char: p.char + 0.25, core: 0.45, rim: 0.3,
        });
        continue;
      }
      /* ⛔ TWO PASSES READ AS BOWLS, AND THE SECOND WAS THE SAME DEFECT (art
       * stage, 2026-09-10). A root cut ACROSS and set face up is a flat ellipse
       * over a visible hemisphere — which is the silhouette of a bowl, however
       * the face is shaded. Cut LENGTHWISE and laid face up, the face carries
       * the root's own profile: a round shoulder, a stem end with stubs of
       * green, and a tap root tapering to a point. That silhouette is a turnip. */
      var purple = (head === 'turnip' || head === 'beet' || head === 'radish');
      var shoulder = head === 'beet' ? '#6A1E3A' : (purple ? '#7E3A6E' : R.shade(skinC, -0.15));
      var root = purple ? '#EDE4DA' : R.mix(skinC, '#F2EAD6', 0.3);
      var ang = rot + (rng() - 0.5) * 0.6;
      /* ⛔ With the stem end NOTCHED (two lobes above a dip) every half read as
       * a HEART (product size, 2026-09-10): the shoulder is one convex curve,
       * and the tap root is long and thin enough to be a root */
      /* ⛔ REMOVING THE NOTCH WAS NOT ENOUGH — it still read as a heart at
       * product size (polish stage, 2026-09-11). A wide shoulder tapering
       * SMOOTHLY to a point IS a heart (or a peach); what a heart does not have
       * is a TAIL. So the body ends bluntly and a thin taproot whisker carries
       * on past it — the one feature of the silhouette that cannot be read as
       * anything but a root. */
      var PROFILE = [[0, -1.00], [0.40, -0.96], [0.80, -0.74], [1.0, -0.28], [0.94, 0.18], [0.72, 0.60],
        [0.48, 0.86], [0.26, 0.99], [0.115, 1.04], [0.075, 1.34], [0.05, 1.92],
        [-0.05, 1.92], [-0.075, 1.34], [-0.115, 1.04], [-0.26, 0.99], [-0.48, 0.86], [-0.72, 0.60],
        [-0.94, 0.18], [-1.0, -0.28], [-0.80, -0.74], [-0.40, -0.96]];
      var ca = Math.cos(ang); var sa = Math.sin(ang);
      var faceW = []; var sideW = [];
      var thick = sz * 0.20;
      for (var q2 = 0; q2 < PROFILE.length; q2++) {
        /* turn in the TABLE's plane, then foreshorten: the face lies flat */
        var lx = PROFILE[q2][0] * sz * 0.78; var ly = PROFILE[q2][1] * sz * 0.78;
        var px = x + lx * ca - ly * sa; var py = y + (lx * sa + ly * ca) * 0.62;
        faceW.push([px, py - thick * 0.5]);
        sideW.push([px, py + thick * 0.5]);
      }
      var stemEnd = [x + (0 * ca - (-1.0 * sz * 0.78) * sa), y + (0 * sa + (-1.0 * sz * 0.78) * ca) * 0.62];
      /* ⛔ wing §11a: a second copy of a constant does not drift, it WINS. The
       * gradient's far end is the profile's own tip, read off PROFILE. */
      var tipY = PROFILE.reduce(function (mx, q) { return Math.max(mx, q[1]); }, 0);
      var tipEnd = [x + (0 * ca - (tipY * sz * 0.78) * sa), y + (0 * sa + (tipY * sz * 0.78) * ca) * 0.62];
      /* the side: the half's thickness, its skin, seen below the face */
      solid(ctx, ptsPath(sideW), boundsOf(sideW), R.mix(shoulder, root, 0.55), rng, {
        ao: 0.55, gloss: 0.35, core: 0.55, rim: 0.20, char: 0.10,
        detail: function (c) {
          var sg = c.createLinearGradient(stemEnd[0], stemEnd[1], tipEnd[0], tipEnd[1]);
          sg.addColorStop(0, R.rgba(shoulder, 0.95));
          sg.addColorStop(0.45, R.rgba(R.mix(shoulder, root, 0.6), 0.85));
          sg.addColorStop(1, R.rgba(root, 0.90));
          c.fillStyle = sg;
          c.fillRect(Math.min(stemEnd[0], tipEnd[0]) - sz * 2, Math.min(stemEnd[1], tipEnd[1]) - sz * 2, sz * 4 + Math.abs(tipEnd[0] - stemEnd[0]), sz * 4 + Math.abs(tipEnd[1] - stemEnd[1]));
        },
      });
      /* the cut face: pale flesh, caramel where the heat reached its edge */
      var facePath = ptsPath(faceW);
      var fbb = boundsOf(faceW);
      ctx.beginPath();
      facePath(ctx);
      var fcx = fbb.x + fbb.w / 2; var fcy = fbb.y + fbb.h / 2;
      var fg = ctx.createRadialGradient(fcx - fbb.w * 0.12, fcy - fbb.h * 0.14, 0, fcx, fcy, Math.max(fbb.w, fbb.h) * 0.62);
      fg.addColorStop(0, R.mix(ing.colour, '#F8E8C0', 0.72));
      fg.addColorStop(0.50, R.mix(ing.colour, '#E6AC58', 0.72));
      fg.addColorStop(0.84, R.mix(ing.colour, '#A65A1C', 0.86));
      fg.addColorStop(1, '#5E3010');
      ctx.fillStyle = fg;
      ctx.fill();
      ctx.save();
      ctx.beginPath();
      facePath(ctx);
      ctx.clip();
      charPatches(ctx, fcx, fcy, fbb.w * 0.45, fbb.h * 0.45, rng, 0.20 + p.char * 0.45);
      /* the root's grain runs from the stem to the tip */
      for (var gl = -2; gl <= 2; gl++) {
        ctx.beginPath();
        ctx.moveTo(stemEnd[0] + gl * sz * 0.14 * ca, stemEnd[1] + gl * sz * 0.14 * sa * 0.62);
        ctx.quadraticCurveTo(x + gl * sz * 0.30 * ca, y + gl * sz * 0.30 * sa * 0.62, tipEnd[0], tipEnd[1]);
        ctx.strokeStyle = R.rgba('#FFF2CC', 0.22);
        ctx.lineWidth = Math.max(0.5, sz * 0.025);
        ctx.stroke();
      }
      ctx.restore();
      /* a hairline of skin round the face, purple at the shoulder */
      ctx.beginPath();
      facePath(ctx);
      var rg2 = ctx.createLinearGradient(stemEnd[0], stemEnd[1], tipEnd[0], tipEnd[1]);
      rg2.addColorStop(0, shoulder);
      rg2.addColorStop(0.5, R.mix(shoulder, root, 0.7));
      rg2.addColorStop(1, root);
      ctx.strokeStyle = rg2;
      ctx.lineWidth = Math.max(1, sz * 0.07);
      ctx.stroke();
      R.innerShade(ctx, facePath, fbb.x, fbb.y, fbb.w, fbb.h, { depth: sz * 0.06, blur: sz * 0.10, darkA: 0.30, light: '#FFE6A8', lightA: 0.45 });
      glints(ctx, fcx, fcy, fbb.w * 0.4, fbb.h * 0.4, sz * 0.4, 0.40 + p.gloss * 0.5, rng);
      /* the stem end keeps stubs of its greens */
      if (purple || head === 'root') {
        ctx.save();
        ctx.lineCap = 'round';
        for (var sb = -1; sb <= 1; sb++) {
          var sAng = ang - Math.PI / 2 + sb * 0.35;
          ctx.beginPath();
          ctx.moveTo(stemEnd[0], stemEnd[1] - thick * 0.5);
          ctx.lineTo(stemEnd[0] + Math.cos(sAng) * sz * 0.34, stemEnd[1] - thick * 0.5 + Math.sin(sAng) * sz * 0.34 * 0.62);
          ctx.strokeStyle = sb === 0 ? '#5E8A3A' : '#4C7430';
          ctx.lineWidth = Math.max(1.2, sz * 0.09);
          ctx.stroke();
        }
        ctx.restore();
      }
    }
    var herb = findIng(p, ['rosemary', 'thyme', 'sage', 'bay'], true);
    if (herb) {
      sprig(ctx, w.cx - w.rx * 0.2, w.cy - w.ry * 0.5, w.rx * 0.7, -0.4, herb.colour, rng);
    }
  }

  /* =============================================================== fillet === */

  /* The fish a cook serves WHOLE. ⛔ MEASURED at product size, art stage
   * 2026-09-10: a trout drawn as a FILLET read as two bananas in the GIF's
   * fourth state and on the contact sheet's hero row — a fillet has no
   * silhouette of its own, and neither colour nor sear marks rescued it (three
   * passes). A whole fish has the most legible silhouette in food: a head, an
   * eye, a tail. The small freshwater fish in the pantry are served whole; a
   * salmon or a cod is still cut into fillets, and a title that says "fillet"
   * is obeyed. */
  var WHOLE_FISH = ['trout', 'carp', 'fish'];

  /** @returns {string} whole | fish | shellfish | steak  (`fish` is a fillet) */
  function filletForm(p) {
    if (findIng(p, ['crab', 'shrimp', 'prawn', 'clam', 'oyster', 'squid'])) return 'shellfish';
    if (ax(p, 'meat') > ax(p, 'fish')) return 'steak';
    if (findIng(p, WHOLE_FISH) && !nameHas(p, ['fillet', 'filet', 'fillets', 'steak', 'cutlet', 'loin'])) return 'whole';
    return 'fish';
  }

  /**
   * A whole fish lying on its side, cooked: head, cooked eye, gill cover,
   * dorsal and tail fins with rays, a lateral line, the scored slashes a cook
   * cuts so it cooks through (showing the flesh), grill bars, and the skin's
   * own pattern — a trout's dark spots and rose band, other fish their scales.
   * Local units: x from -1 (snout) to +1 (tail tip), y down, times L; the
   * flank is foreshortened by FS because the table is seen at three-quarters.
   */
  function drawWholeFish(ctx, w, p, rng) {
    var R = deps();
    var n = p.portions >= 4 ? 2 : 1;
    /* ⛔ ry-limited at 2.5 the fish was a third of its board (first render,
     * 2026-09-10): a whole fish is long and low, so it may use the width */
    var L = Math.min(w.rx * (n > 1 ? 0.92 : 1.08), w.ry * (n > 1 ? 2.3 : 3.3));
    var FS = 0.80;
    var trout = !!findIng(p, ['trout']);
    /* cooked skin is bronze and gold; the pantry's grey-beige trout read khaki */
    var back = R.shade(R.mix(p.bodyColour, '#4A3518', 0.74), -p.char * 0.15);
    var flank = R.mix(p.bodyColour, '#CF9044', 0.74);
    var band = R.mix(flank, '#CF7466', 0.50);
    var belly = R.mix(p.bodyColour, '#F0E4C8', 0.78);
    var flesh = trout ? '#F2B9A0' : '#F4E6D2';
    var finC = R.shade(R.mix(back, flank, 0.35), -0.05);
    var sear = 0.20 + p.char * 0.45;
    /* the outline: top edge snout → tail base, then the belly back */
    var TOP = [[-1.00, 0.01], [-0.965, -0.07], [-0.88, -0.14], [-0.76, -0.20], [-0.60, -0.235], [-0.42, -0.245],
      [-0.20, -0.235], [0.05, -0.20], [0.28, -0.145], [0.46, -0.095], [0.58, -0.066], [0.66, -0.056]];
    var BOT = [[0.66, 0.050], [0.58, 0.060], [0.46, 0.085], [0.28, 0.130], [0.05, 0.180], [-0.20, 0.215],
      [-0.42, 0.225], [-0.60, 0.215], [-0.76, 0.190], [-0.88, 0.140], [-0.965, 0.080]];
    function local(pts, fx, fy, rot) {
      var o = [];
      for (var i = 0; i < pts.length; i++) o.push([pts[i][0] * L, pts[i][1] * L * FS]);
      return place(o, fx, fy, rot);
    }
    function fin(pts, fx, fy, rot, rays, root) {
      var wp = local(pts, fx, fy, rot);
      solid(ctx, ptsPath(wp), boundsOf(wp), finC, rng, {
        ao: 0.25, gloss: 0.25, core: 0.35, rim: 0.30, lift: 0.25,
        detail: function (c) {
          c.save();
          c.translate(fx, fy);
          c.rotate(rot);
          for (var k = 0; k < rays.length; k++) {
            c.beginPath();
            c.moveTo(root[0] * L, root[1] * L * FS);
            c.lineTo(rays[k][0] * L, rays[k][1] * L * FS);
            c.strokeStyle = R.rgba(R.shade(finC, -0.55), 0.55);
            c.lineWidth = Math.max(0.5, L * 0.008);
            c.stroke();
          }
          c.restore();
          /* a fin's thin edge crisps first in the heat */
          c.beginPath();
          R.smoothPath(c, wp);
          c.strokeStyle = R.rgba('#2A1608', 0.35 + sear * 0.4);
          c.lineWidth = Math.max(0.8, L * 0.02);
          c.stroke();
        },
      });
    }
    for (var f = n - 1; f >= 0; f--) {
      var fx = w.cx + (n > 1 ? (f ? 0.10 : -0.06) : 0.02) * L;
      var fy = w.cy + (n > 1 ? (f ? -0.30 : 0.26) : -0.06) * w.ry;
      var rot = -0.10 + (n > 1 ? f * 0.07 : 0);
      /* behind the body: the tail, the dorsal, the anal fin */
      fin([[0.60, -0.070], [0.76, -0.150], [0.93, -0.270], [1.00, -0.240], [0.93, -0.080], [0.88, 0.005],
        [0.93, 0.080], [1.00, 0.235], [0.93, 0.265], [0.76, 0.145], [0.60, 0.064]], fx, fy, rot,
      [[0.97, -0.25], [0.95, -0.17], [0.92, -0.09], [0.90, 0.0], [0.92, 0.09], [0.95, 0.17], [0.97, 0.24]], [0.62, 0.0]);
      fin([[-0.30, -0.232], [-0.24, -0.345], [-0.12, -0.370], [-0.02, -0.330], [0.08, -0.205]], fx, fy, rot,
        [[-0.23, -0.34], [-0.16, -0.36], [-0.08, -0.35], [0.0, -0.32], [0.05, -0.25]], [-0.10, -0.20]);
      fin([[0.18, 0.150], [0.26, 0.255], [0.38, 0.235], [0.42, 0.105]], fx, fy, rot,
        [[0.25, 0.25], [0.32, 0.25], [0.38, 0.22]], [0.30, 0.12]);
      var body = local(TOP.concat(BOT), fx, fy, rot);
      /* solid() calls `detail` synchronously, so the loop's fx/fy/rot are the
       * current fish's when it runs */
      solid(ctx, ptsPath(body), boundsOf(body), flank, rng, {
        ao: 0.55, gloss: 0.55 + p.gloss * 0.35, core: 0.50, rim: 0.30, depthK: 0.22, blurK: 0.40, lift: 0.40,
        detail: function (c) {
          c.save();
          c.translate(fx, fy);
          c.rotate(rot);
          var yT = -0.25 * L * FS; var yB = 0.23 * L * FS;
          var g = c.createLinearGradient(0, yT, 0, yB);
          g.addColorStop(0.00, R.shade(back, -0.10));
          g.addColorStop(0.30, back);
          g.addColorStop(0.46, flank);
          g.addColorStop(trout ? 0.56 : 0.60, trout ? band : flank);
          g.addColorStop(0.70, R.mix(flank, belly, 0.45));
          g.addColorStop(0.86, belly);
          g.addColorStop(1.00, R.shade(belly, -0.12));
          c.fillStyle = g;
          c.fillRect(-1.1 * L, yT - 2, 2.2 * L, yB - yT + 4);
          /* the skin's own pattern */
          if (trout) {
            for (var s = 0; s < 46; s++) {
              var sx = (-0.62 + rng() * 1.26) * L;
              var sy = (-0.24 + rng() * 0.24) * L * FS;
              var sr = L * (0.006 + rng() * 0.009);
              c.beginPath();
              ellPath(sx, sy, sr, sr * 0.75)(c);
              c.fillStyle = R.rgba('#1E140A', 0.55 + rng() * 0.3);
              c.fill();
            }
          } else {
            for (var row = 0; row < 7; row++) {
              for (var col = 0; col < 18; col++) {
                var qx = (-0.56 + col * 0.068 + (row % 2) * 0.034) * L;
                var qy = (-0.20 + row * 0.062) * L * FS;
                c.beginPath();
                c.arc(qx, qy, L * 0.032, Math.PI * 0.30, Math.PI * 1.70, true);
                c.strokeStyle = R.rgba(R.shade(flank, -0.45), 0.22);
                c.lineWidth = Math.max(0.5, L * 0.006);
                c.stroke();
              }
            }
          }
          /* the lateral line — the stripe every fish carries, head to tail */
          c.beginPath();
          c.moveTo(-0.58 * L, -0.02 * L * FS);
          c.quadraticCurveTo(0.0, 0.02 * L * FS, 0.62 * L, 0.0);
          c.strokeStyle = R.rgba(R.shade(flank, 0.55), 0.55);
          c.lineWidth = Math.max(0.6, L * 0.010);
          c.stroke();
          /* grill bars across the flank */
          for (var gb = 0; gb < 5; gb++) {
            var gx = (-0.52 + gb * 0.26) * L;
            c.beginPath();
            c.moveTo(gx + 0.10 * L, -0.30 * L * FS);
            c.lineTo(gx - 0.10 * L, 0.30 * L * FS);
            c.strokeStyle = R.rgba('#2A1206', sear);
            c.lineWidth = Math.max(1.2, L * 0.040);
            c.stroke();
          }
          /* a head is not scaled: the gill cover and the cheek are smooth,
           * lit, and a little paler */
          var hg = c.createRadialGradient(-0.80 * L, -0.08 * L * FS, 0, -0.80 * L, 0, 0.28 * L);
          hg.addColorStop(0, R.rgba(R.shade(flank, 0.35), 0.55));
          hg.addColorStop(1, R.rgba(R.shade(flank, 0.35), 0));
          c.fillStyle = hg;
          c.fillRect(-1.05 * L, -0.3 * L, 0.5 * L, 0.6 * L);
          c.restore();
        },
      });
      /* the scored slashes: the pale flesh shows where the knife went in */
      for (var sl = 0; sl < 3; sl++) {
        var sxc = -0.36 + sl * 0.25;
        /* ⛔ 0.012 L across, the first slash was a dark LINE with no flesh in
         * it (2x crop, 2026-09-10): a slash that opened in the heat gapes */
        var lens = local([[sxc + 0.042, -0.180], [sxc - 0.004, -0.050], [sxc - 0.044, 0.080], [sxc - 0.056, 0.152],
          [sxc - 0.008, 0.086], [sxc + 0.032, -0.044]], fx, fy, rot);
        ctx.beginPath();
        R.smoothPath(ctx, lens);
        ctx.fillStyle = flesh;
        ctx.fill();
        ctx.save();
        ctx.beginPath();
        R.smoothPath(ctx, lens);
        ctx.clip();
        R.puff(ctx, lens[1][0], lens[1][1], L * 0.06, R.shade(flesh, -0.35), 0.45);
        ctx.restore();
        ctx.beginPath();
        ctx.moveTo(lens[0][0], lens[0][1]);
        ctx.quadraticCurveTo(lens[1][0] - L * 0.012, lens[1][1], lens[3][0], lens[3][1]);
        ctx.strokeStyle = R.rgba('#2A1608', 0.70);
        ctx.lineWidth = Math.max(0.8, L * 0.012);
        ctx.stroke();
      }
      /* gill cover: a curved lip of skin with its own lit edge */
      var gc = local([[-0.64, -0.205], [-0.555, -0.02], [-0.625, 0.185]], fx, fy, rot);
      ctx.save();
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(gc[0][0], gc[0][1]);
      ctx.quadraticCurveTo(gc[1][0], gc[1][1], gc[2][0], gc[2][1]);
      ctx.strokeStyle = R.rgba('#2A1608', 0.62);
      ctx.lineWidth = Math.max(0.9, L * 0.016);
      ctx.stroke();
      var gl = local([[-0.625, -0.19], [-0.54, -0.02], [-0.61, 0.17]], fx, fy, rot);
      ctx.beginPath();
      ctx.moveTo(gl[0][0], gl[0][1]);
      ctx.quadraticCurveTo(gl[1][0], gl[1][1], gl[2][0], gl[2][1]);
      ctx.strokeStyle = R.rgba(R.shade(flank, 0.6), 0.45);
      ctx.lineWidth = Math.max(0.6, L * 0.008);
      ctx.stroke();
      /* the mouth */
      var mo = local([[-0.995, 0.02], [-0.95, 0.045], [-0.90, 0.040]], fx, fy, rot);
      ctx.beginPath();
      ctx.moveTo(mo[0][0], mo[0][1]);
      ctx.quadraticCurveTo(mo[1][0], mo[1][1], mo[2][0], mo[2][1]);
      ctx.strokeStyle = R.rgba('#2A1608', 0.65);
      ctx.lineWidth = Math.max(0.7, L * 0.010);
      ctx.stroke();
      ctx.restore();
      /* the eye, cooked: an opaque pale lens in a dark ring, and the lamp in it */
      var ey = local([[-0.80, -0.060]], fx, fy, rot)[0];
      ctx.beginPath();
      ellPath(ey[0], ey[1], L * 0.044, L * 0.044 * 0.9)(ctx);
      ctx.fillStyle = '#3A2812';
      ctx.fill();
      ctx.beginPath();
      ellPath(ey[0], ey[1], L * 0.036, L * 0.036 * 0.9)(ctx);
      R.litFill(ctx, ey[0], ey[1], L * 0.036, '#E2DACB', { lift: 0.3, drop: 0.35 });
      ctx.beginPath();
      ellPath(ey[0] + L * 0.004, ey[1] + L * 0.004, L * 0.015, L * 0.014)(ctx);
      ctx.fillStyle = R.rgba('#5A5048', 0.85);
      ctx.fill();
      R.glint(ctx, ey[0] - L * 0.014, ey[1] - L * 0.014, L * 0.016, L * 0.008, -0.6, 0.9);
      /* the pectoral fin lies against the flank, over it */
      var pf = local([[-0.56, 0.060], [-0.44, 0.105], [-0.36, 0.175], [-0.42, 0.195], [-0.52, 0.160]], fx, fy, rot);
      ctx.beginPath();
      R.smoothPath(ctx, pf);
      ctx.fillStyle = R.rgba(R.shade(finC, 0.12), 0.72);
      ctx.fill();
      ctx.strokeStyle = R.rgba('#2A1608', 0.40);
      ctx.lineWidth = Math.max(0.6, L * 0.009);
      ctx.stroke();
    }
    /* what went in with it */
    /* ⛔ A sprig laid ALONG the back read as a spiny fin (first render,
     * 2026-09-10): it crosses the flank on a diagonal, away from the head. */
    var herb = findIng(p, ['dill', 'thyme', 'parsley', 'fennel', 'rosemary', 'sage', 'chive'], true);
    if (herb) sprig(ctx, w.cx + L * 0.16, w.cy - w.ry * 0.02, L * 0.46, 0.62, R.shade(herb.colour, 0.08), rng);
    var lemon = findIng(p, ['lemon', 'orange']);
    if (lemon) {
      var rind = lemon.head === 'orange' ? '#E08A2A' : '#E7C23A';
      var fl = lemon.head === 'orange' ? '#F2A64A' : '#F4DE7A';
      citrusWheel(ctx, w.cx - L * 0.40, w.cy + w.ry * 0.40, L * 0.17, -0.2, rind, fl);
      citrusWheel(ctx, w.cx - L * 0.12, w.cy + w.ry * 0.52, L * 0.15, 0.3, rind, fl);
    }
    var butter = findIng(p, ['butter']);
    if (butter) butterPat(ctx, w.cx + L * 0.16, w.cy - w.ry * 0.12, L * 0.09, rng);
  }

  function drawFish(ctx, w, p, rng) {
    var R = deps();
    /* ⛔ The first pass was a pale sliver a third of its leaf wide (art stage,
     * 2026-09-10): a served fillet is broad, fills the vessel, and is SEARED
     * gold on top — the sear is what says cooked. */
    var n = clamp(p.portions - 1, 1, 3);
    var L = Math.min(w.rx * (n > 1 ? 0.78 : 1.04), w.ry * 2.4);
    /* ⛔ Trout's pantry colour is a grey-beige; mixed toward cream it read as
     * RAW grey fish in the GIF's fourth state (2026-09-10). Cooked flesh is
     * warm and opaque, and the sear is a real gold-brown. */
    var flesh = R.mix(p.bodyColour, '#F2CDA4', 0.48);
    var sear = R.mix(p.bodyColour, '#B26A26', 0.80);
    for (var i = n - 1; i >= 0; i--) {
      var fx = w.cx + (i - (n - 1) / 2) * L * 0.34; var fy = w.cy + (i - (n - 1) / 2) * w.ry * 0.46;
      var rot = -0.22 + i * 0.10;
      var loc = [[-0.96, -0.02], [-0.78, -0.30], [-0.40, -0.40], [0.20, -0.32], [0.72, -0.14], [1.0, -0.02],
        [0.74, 0.10], [0.20, 0.22], [-0.40, 0.28], [-0.82, 0.20]];
      for (var k = 0; k < loc.length; k++) { loc[k][0] *= L; loc[k][1] *= L; }
      jitter(loc, rng, L * 0.012);
      var pts = place(loc, fx, fy, rot);
      solid(ctx, ptsPath(pts), boundsOf(pts), flesh, rng, {
        ao: 0.5, gloss: 0.4 + p.gloss * 0.4, core: 0.30, rim: 0.34, depthK: 0.20, lift: 0.36,
        detail: function (c) {
          c.save();
          c.translate(fx, fy);
          c.rotate(rot);
          var g = c.createLinearGradient(0, -L * 0.40, 0, L * 0.14);
          g.addColorStop(0, R.rgba(R.shade(sear, -0.2), 0.95));
          g.addColorStop(0.35, R.rgba(sear, 0.85));
          g.addColorStop(0.75, R.rgba(sear, 0.30));
          g.addColorStop(1, R.rgba(sear, 0));
          c.fillStyle = g;
          c.fillRect(-L * 1.1, -L * 0.4, L * 2.2, L * 0.5);
          for (var m = 0; m < 9; m++) {
            var xx = -0.78 * L + m * (1.5 * L / 8);
            var hw = L * 0.30 * (1 - Math.pow((xx / L), 2) * 0.7);
            c.beginPath();
            c.moveTo(xx, -hw);
            c.quadraticCurveTo(xx + L * 0.10, -hw * 0.1, xx + L * 0.02, hw * 0.75);
            c.strokeStyle = R.rgba(R.shade(sear, -0.35), 0.28);
            c.lineWidth = Math.max(0.7, L * 0.013);
            c.stroke();
            c.beginPath();
            c.moveTo(xx + L * 0.02, -hw);
            c.quadraticCurveTo(xx + L * 0.12, -hw * 0.1, xx + L * 0.04, hw * 0.75);
            c.strokeStyle = R.rgba('#FFFFFF', 0.30);
            c.lineWidth = Math.max(0.5, L * 0.008);
            c.stroke();
          }
          c.beginPath();
          c.moveTo(-0.84 * L, 0.18 * L);
          c.quadraticCurveTo(-0.3 * L, 0.27 * L, 0.2 * L, 0.20 * L);
          c.quadraticCurveTo(0.6 * L, 0.12 * L, 0.98 * L, 0.0);
          c.strokeStyle = R.rgba('#9A8C74', 0.75);
          c.lineWidth = Math.max(1, L * 0.028);
          c.stroke();
          c.restore();
        },
      });
    }
    var lemon = findIng(p, ['lemon', 'orange']);
    if (lemon) {
      var rind = lemon.head === 'orange' ? '#E08A2A' : '#E7C23A';
      var fl = lemon.head === 'orange' ? '#F2A64A' : '#F4DE7A';
      citrusWheel(ctx, w.cx - L * 0.62, w.cy + w.ry * 0.46, L * 0.22, -0.2, rind, fl);
      citrusWheel(ctx, w.cx - L * 0.36, w.cy + w.ry * 0.62, L * 0.19, 0.3, rind, fl);
    }
    var butter = findIng(p, ['butter']);
    if (butter) butterPat(ctx, w.cx + L * 0.10, w.cy - w.ry * 0.10, L * 0.10, rng);
  }

  function drawShellfish(ctx, w, p, rng) {
    var R = deps();
    /* ⛔ Six hairline legs read as twigs at contact-sheet scale (art stage,
     * 2026-09-10): fewer, THICKER legs, boiled scarlet, and a claw — the claw
     * is the silhouette that says crab. */
    var shell = R.mix(p.bodyColour, '#C8402A', 0.55);
    var meat = '#F4EADB';
    var n = clamp(1 + p.portions, 3, 5);
    var L = Math.min(w.rx * 0.95, w.ry * 2.2);
    var ox = w.cx - L * 0.62; var oy = w.cy + w.ry * 0.05;
    clawAt(ctx, w.cx + L * 0.30, w.cy + w.ry * 0.36, L * 0.34, -0.25, shell, rng);
    for (var i = 0; i < n; i++) {
      var ang = -0.80 + (i / Math.max(1, n - 1)) * 1.10;
      var x = ox; var y = oy;
      var segs = [0.46, 0.40, 0.32];
      var wd = L * 0.12;
      for (var s = 0; s < segs.length; s++) {
        var len = L * segs[s];
        var a = ang + s * 0.22 * (i % 2 ? 1 : -1);
        var ex = x + Math.cos(a) * len; var ey = y + Math.sin(a) * len * 0.6;
        var nx = -Math.sin(a); var ny = Math.cos(a) * 0.6;
        var w0 = wd * (1 - s * 0.18); var w1 = wd * (0.9 - s * 0.2);
        var pts = [[x + nx * w0, y + ny * w0], [ex + nx * w1, ey + ny * w1], [ex + Math.cos(a) * w1 * 0.4, ey + Math.sin(a) * w1 * 0.3],
          [ex - nx * w1, ey - ny * w1], [x - nx * w0, y - ny * w0], [x - Math.cos(a) * w0 * 0.3, y - Math.sin(a) * w0 * 0.2]];
        var cracked = (i === 1 && s === 2);
        solid(ctx, ptsPath(pts), boundsOf(pts), cracked ? meat : shell, rng, {
          ao: 0.4, gloss: 0.55, core: 0.5, rim: 0.35,
          texture: cracked ? { n: 8, size: wd * 0.12, dark: '#C9B89E', light: '#FFFFFF', a: 0.5 }
            : { n: 10, size: Math.max(0.5, wd * 0.10), dark: '#6A1E10', light: '#F2C49E', a: 0.55 },
          detail: cracked ? null : function (c) {
            c.beginPath();
            c.moveTo(x - nx * w0 * 0.2, y - ny * w0 * 0.2);
            c.lineTo(ex - nx * w1 * 0.2, ey - ny * w1 * 0.2);
            c.strokeStyle = R.rgba('#F6DDBE', 0.55);
            c.lineWidth = Math.max(0.8, w1 * 0.5);
            c.stroke();
          },
        });
        ctx.beginPath();
        ellPath(ex, ey, w1 * 0.55, w1 * 0.45)(ctx);
        ctx.fillStyle = R.shade(shell, -0.5);
        ctx.fill();
        x = ex; y = ey;
      }
    }
    var lemon = findIng(p, ['lemon']);
    if (lemon) citrusWheel(ctx, w.cx + L * 0.52, w.cy + w.ry * 0.40, L * 0.20, 0.2, '#E7C23A', '#F4DE7A');
    var butter = findIng(p, ['butter']);
    if (butter) butterPat(ctx, w.cx + L * 0.30, w.cy - w.ry * 0.30, L * 0.09, rng);
  }

  /** A crab claw: a swollen palm and two curved fingers with dark tips. */
  function clawAt(ctx, x, y, s, rot, shell, rng) {
    var R = deps();
    var palm = place([[-0.9, 0], [-0.6, -0.42], [0.1, -0.48], [0.55, -0.26], [0.62, 0.08], [0.3, 0.40], [-0.3, 0.44], [-0.8, 0.28]], 0, 0, 0);
    for (var i = 0; i < palm.length; i++) { palm[i][0] *= s; palm[i][1] *= s; }
    var wp = place(palm, x, y, rot);
    var fingers = [
      [[0.50, -0.26], [0.95, -0.34], [1.30, -0.22], [1.42, -0.10], [1.20, -0.14], [0.90, -0.10], [0.55, -0.02]],
      [[0.55, 0.06], [0.90, 0.14], [1.20, 0.10], [1.34, 0.18], [1.10, 0.26], [0.80, 0.28], [0.45, 0.24]],
    ];
    for (var f = 0; f < 2; f++) {
      var fp = [];
      for (var k = 0; k < fingers[f].length; k++) fp.push([fingers[f][k][0] * s, fingers[f][k][1] * s]);
      var wf = place(fp, x, y, rot);
      solid(ctx, ptsPath(wf), boundsOf(wf), shell, rng, {
        ao: 0.35, gloss: 0.6, core: 0.5, rim: 0.35,
        detail: function (c) {
          var tip = wf[3];
          R.puff(c, tip[0], tip[1], s * 0.28, '#2A0E08', 0.85);
        },
      });
    }
    solid(ctx, ptsPath(wp), boundsOf(wp), shell, rng, {
      ao: 0.45, gloss: 0.65, core: 0.5, rim: 0.35,
      texture: { n: 14, size: Math.max(0.5, s * 0.04), dark: '#6A1E10', light: '#F6CBA4', a: 0.6 },
      detail: function (c, cx, cy, hrx, hry) {
        R.puff(c, cx - hrx * 0.1, cy + hry * 0.4, hrx * 0.7, '#F2D2AE', 0.45);
      },
    });
  }

  function drawSteak(ctx, w, p, rng) {
    var R = deps();
    var L = Math.min(w.rx * 0.72, w.ry * 1.7);
    var crust = R.shade(R.mix(p.bodyColour, '#7A3E1E', 0.55), -p.char * 0.15);
    var inner = R.mix(p.bodyColour, '#C8645A', 0.5);
    var loc = [[-0.9, -0.1], [-0.6, -0.45], [0.1, -0.52], [0.7, -0.35], [0.95, 0.05], [0.7, 0.42], [0.0, 0.5], [-0.65, 0.40]];
    for (var i = 0; i < loc.length; i++) { loc[i][0] *= L; loc[i][1] *= L * 0.8; }
    var pts = place(jitter(loc, rng, L * 0.03), w.cx - L * 0.15, w.cy - w.ry * 0.1, -0.15);
    solid(ctx, ptsPath(pts), boundsOf(pts), crust, rng, {
      ao: 0.55, gloss: p.gloss, char: p.char, core: 0.55, rim: 0.3,
      texture: { n: Math.round(L), size: Math.max(0.5, L * 0.014), a: 0.45 },
      detail: function (c) {
        grill(c, w.cx - L * 0.15, w.cy - w.ry * 0.1, L, 0.55 + p.char * 0.4);
        c.beginPath();
        R.smoothPath(c, pts);
        c.strokeStyle = R.rgba('#EAD6B0', 0.75);
        c.lineWidth = Math.max(1.5, L * 0.07);
        c.stroke();
      },
    });
    var sl = clamp(p.portions - 1, 1, 4);
    for (var s = sl - 1; s >= 0; s--) {
      carvedSlice(ctx, w.cx + L * (0.35 + s * 0.2), w.cy + w.ry * (0.45 - s * 0.05), L * 0.28, L * 0.14, -0.4, crust, inner, rng);
    }
  }

  /** Grill marks, a cross-hatch of seared bars. */
  function grill(c, x, y, L, amount) {
    var R = deps();
    c.save();
    c.translate(x, y);
    for (var d = 0; d < 2; d++) {
      c.save();
      c.rotate(d ? 0.85 : -0.55);
      for (var k = -3; k <= 3; k++) {
        c.beginPath();
        c.moveTo(-L * 1.2, k * L * 0.24);
        c.lineTo(L * 1.2, k * L * 0.24);
        c.strokeStyle = R.rgba('#1A0A04', 0.30 + amount * 0.35);
        c.lineWidth = Math.max(1.2, L * 0.06);
        c.stroke();
      }
      c.restore();
    }
    c.restore();
  }

  /* ========================================================== wet dishes === */

  function drawStew(ctx, w, p, rng) {
    var R = deps();
    var liquid = R.mix(p.sauceColour, p.bodyColour, 0.25);
    liquidSurface(ctx, w, p, rng, {
      colour: liquid, gloss: 0.35 + p.gloss * 0.4, eyes: ax(p, 'fat') > 0.1 ? 6 : 0,
      detail: function (c, s) {
        /* a thick gravy is never one flat colour: it is darker where it is
         * deep and catches light where it has skinned over */
        for (var i = 0; i < 9; i++) {
          R.puff(c, s.cx + (rng() - 0.5) * s.rx * 1.6, s.cy + (rng() - 0.5) * s.ry * 1.4, s.rx * (0.15 + rng() * 0.2),
            i % 2 ? R.shade(liquid, -0.35) : R.shade(liquid, 0.25), 0.22);
        }
      },
    });
    var drawn = piecesOf(ctx, w, p, rng, { count: 1.0 + p.portions * 0.25, size: w.rx * 0.115, submerge: 0.42, liquid: liquid, rMax: 0.80, sep: 0.20 });
    if (!drawn) {
      for (var i = 0; i < 5; i++) {
        mass(ctx, w.cx + (rng() - 0.5) * w.rx * 1.2, w.cy + (rng() - 0.5) * w.ry, w.rx * 0.11, w.rx * 0.08,
          R.shade(p.bodyColour, -0.1), rng, { gloss: 0.5 });
      }
    }
  }

  function drawSoup(ctx, w, p, rng) {
    var R = deps();
    var creamy = ax(p, 'dairy') > 0.12 || p.behaviour === 'cream';
    var liquid = creamy ? R.mix(p.bodyColour, '#F3E7CF', 0.45) : R.mix(p.sauceColour, p.bodyColour, 0.55);
    liquidSurface(ctx, w, p, rng, {
      colour: liquid, gloss: 0.4, eyes: creamy ? 0 : 8,
      detail: creamy ? function (c, s) {
        c.beginPath();
        for (var t = 0; t < 40; t++) {
          var a = t * 0.36; var rr = 0.05 + t * 0.016;
          var x = s.cx + s.rx * 0.08 + Math.cos(a) * s.rx * rr; var y = s.cy + Math.sin(a) * s.ry * rr;
          if (t === 0) c.moveTo(x, y); else c.lineTo(x, y);
        }
        c.strokeStyle = R.rgba('#FFFBF0', 0.55);
        c.lineWidth = Math.max(1, s.rx * 0.03);
        c.stroke();
      } : null,
    });
    piecesOf(ctx, w, p, rng, { count: 0.55 + p.portions * 0.1, size: w.rx * 0.09, submerge: 0.62, liquid: liquid, rMax: 0.74, sep: 0.26 });
  }

  function drawBroth(ctx, w, p, rng) {
    var R = deps();
    var arcane = ax(p, 'arcane') > 0.12;
    var clear = R.mix(p.sauceColour, p.bodyColour, 0.6);
    liquidSurface(ctx, w, p, rng, {
      colour: clear, alpha: 0.86, gloss: 0.6, eyes: 10 + p.portions * 3,
      detail: function (c, s) {
        R.puff(c, s.cx + s.rx * 0.1, s.cy + s.ry * 0.12, s.rx * 0.7, R.shade(clear, 0.35), 0.28);
        if (arcane) {
          for (var i = 0; i < 16; i++) {
            var a = rng() * TAU; var rr = Math.sqrt(rng()) * 0.8;
            R.puff(c, s.cx + Math.cos(a) * s.rx * rr, s.cy + Math.sin(a) * s.ry * rr, s.rx * (0.03 + rng() * 0.05), '#D8E6FF', 0.7);
          }
          R.puff(c, s.cx, s.cy, s.rx * 0.8, '#8FB4FF', 0.22);
        }
      },
    });
    piecesOf(ctx, w, p, rng, { count: 0.5, size: w.rx * 0.085, submerge: 0.5, liquid: clear, rMax: 0.7, sep: 0.3 });
    var chive = findIng(p, ['chive', 'leek'], true);
    if (chive) {
      for (var k = 0; k < 7; k++) {
        var cx = w.cx + (rng() - 0.5) * w.rx * 1.3; var cy = w.cy + (rng() - 0.5) * w.ry * 1.1;
        var r = w.rx * 0.028;
        ctx.beginPath();
        ellPath(cx, cy, r, r * 0.7)(ctx);
        ctx.strokeStyle = R.rgba('#5E8A3A', 0.95);
        ctx.lineWidth = Math.max(0.8, r * 0.55);
        ctx.stroke();
      }
    }
  }

  /* ================================================================= loaf === */

  /** @returns {string} cracker | buns | flat | loaf */
  function loafForm(p) {
    if (nameHas(p, ['hardtack', 'cracker', 'biscuit'])) return 'cracker';
    if (nameHas(p, ['bun', 'roll'])) return 'buns';
    if (nameHas(p, ['flatbread', 'bannock'])) return 'flat';
    return 'loaf';
  }

  /** The crust a grain bakes to: rye goes dark, oats and barley to amber, wheat to gold. */
  function crustOf(p) {
    var R = deps();
    var base = findIng(p, ['rye']) ? '#5C3A1F' : (findIng(p, ['oat', 'barley']) ? '#9A6632' : '#A8662B');
    return R.shade(R.mix(base, p.bodyColour, 0.18), -p.char * 0.1);
  }

  function drawLoaf(ctx, w, p, rng) {
    var R = deps();
    var form = loafForm(p);
    var crust = crustOf(p);
    var crumb = R.mix('#E6D2A8', p.bodyColour, 0.25);
    var seeds = null;
    for (var i = 0; i < (p.ingredients || []).length; i++) {
      if (!p.ingredients[i].known) { seeds = p.ingredients[i]; break; }
    }
    if (form === 'cracker') {
      var n = clamp(2 + p.portions, 3, 6);
      var s = Math.min(w.rx * 0.48, w.ry * 1.0);
      for (var c = 0; c < n; c++) {
        var x = w.cx + (c - (n - 1) / 2) * s * 0.9 + (rng() - 0.5) * s * 0.3;
        var y = w.cy + (c % 2 ? 0.2 : -0.18) * w.ry;
        crackerAt(ctx, x, y, s, R.mix('#D9B477', p.bodyColour, 0.25), rng, (rng() - 0.5) * 0.7);
      }
      return;
    }
    var L = Math.min(w.rx * 0.82, w.ry * 1.9);
    var slice = p.portions >= 2;
    var lx = w.cx - (slice ? L * 0.14 : 0); var ly = w.cy - w.ry * 0.08;
    var long = p.magnitude > 0.3;
    var loc = long ? [[-0.95, 0], [-0.8, -0.34], [-0.3, -0.48], [0.3, -0.48], [0.8, -0.34], [0.95, 0], [0.8, 0.32], [0.3, 0.44], [-0.3, 0.44], [-0.8, 0.32]]
      : [[-0.72, 0], [-0.58, -0.44], [0, -0.60], [0.58, -0.44], [0.72, 0], [0.58, 0.42], [0, 0.56], [-0.58, 0.42]];
    for (var k = 0; k < loc.length; k++) { loc[k][0] *= L; loc[k][1] *= L; }
    var pts = place(jitter(loc, rng, L * 0.02), lx, ly, -0.12);
    var b = boundsOf(pts);
    var rye = !!findIng(p, ['rye']);
    solid(ctx, ptsPath(pts), b, crust, rng, {
      ao: 0.55, gloss: 0.12, core: 0.55, rim: 0.3, depthK: 0.24,
      texture: { n: Math.round(L * 1.5), size: Math.max(0.5, L * 0.012), a: 0.35 },
      detail: function (c2) {
        c2.save();
        c2.translate(lx, ly);
        c2.rotate(-0.12);
        var cuts = long ? 3 : 2;
        for (var q = 0; q < cuts; q++) {
          var cx = long ? (-0.5 + q * 0.5) * L : (q ? 0.14 : -0.14) * L;
          var ang = long ? 0.9 : (q ? 0.7 : -0.7);
          c2.save();
          c2.translate(cx, -L * 0.08);
          c2.rotate(ang);
          var cl = L * (long ? 0.26 : 0.34); var cw = L * 0.055;
          c2.beginPath();
          c2.moveTo(-cl, 0);
          c2.quadraticCurveTo(0, -cw * 2, cl, 0);
          c2.quadraticCurveTo(0, cw * 1.2, -cl, 0);
          c2.closePath();
          c2.fillStyle = R.mix(crumb, crust, 0.25);
          c2.fill();
          c2.beginPath();
          c2.moveTo(-cl, 0);
          c2.quadraticCurveTo(0, -cw * 2, cl, 0);
          c2.strokeStyle = R.rgba(R.shade(crust, -0.5), 0.8);
          c2.lineWidth = Math.max(0.8, L * 0.02);
          c2.stroke();
          c2.beginPath();
          c2.moveTo(-cl * 0.8, cw * 0.4);
          c2.quadraticCurveTo(0, cw * 1.0, cl * 0.8, cw * 0.3);
          c2.strokeStyle = R.rgba(R.shade(crust, 0.55), 0.5);
          c2.lineWidth = Math.max(0.6, L * 0.012);
          c2.stroke();
          c2.restore();
        }
        c2.restore();
        R.stipple(c2, lx - L * 0.05, ly - L * 0.2, L * 0.7, L * 0.30, rng, Math.round(L * (rye ? 3.2 : 1.4)),
          Math.max(0.5, L * 0.012), '#F4EEE2', '#FFFFFF', rye ? 0.55 : 0.35);
        if (seeds) {
          for (var sd = 0; sd < 26; sd++) {
            var a = rng() * TAU; var rr = Math.sqrt(rng());
            var sx = lx + Math.cos(a) * L * 0.7 * rr; var sy = ly + Math.sin(a) * L * 0.4 * rr;
            c2.beginPath();
            ellPath(sx, sy, Math.max(0.5, L * 0.018), Math.max(0.3, L * 0.007), rng() * TAU)(c2);
            c2.fillStyle = R.rgba(R.shade(seeds.colour, -0.35), 0.9);
            c2.fill();
          }
        }
      },
    });
    if (slice) {
      var sx2 = w.cx + L * 0.62; var sy2 = w.cy + w.ry * 0.30;
      var sp = place([[-0.26, -0.40], [0.20, -0.46], [0.30, 0], [0.22, 0.44], [-0.24, 0.40], [-0.32, 0]], 0, 0, 0);
      for (var z = 0; z < sp.length; z++) { sp[z][0] *= L; sp[z][1] *= L * 0.8; }
      var wp = place(sp, sx2, sy2, 0.35);
      R.contactShadow(ctx, sx2, sy2 + L * 0.2, L * 0.3, L * 0.2, 0.45);
      ctx.beginPath();
      R.smoothPath(ctx, wp);
      ctx.fillStyle = crust;
      ctx.fill();
      var ip = [];
      for (var y2 = 0; y2 < wp.length; y2++) ip.push([sx2 + (wp[y2][0] - sx2) * 0.84, sy2 + (wp[y2][1] - sy2) * 0.86]);
      solid(ctx, ptsPath(ip), boundsOf(ip), crumb, rng, {
        ao: 0, gloss: 0, core: 0.25, rim: 0.3,
        texture: { n: Math.round(L * 1.4), size: Math.max(0.6, L * 0.018), dark: R.shade(crumb, -0.45), light: '#FFF8E8', a: 0.6 },
      });
    }
  }

  /** A ship's biscuit: a square with softened corners, docking holes, browned edges. */
  function crackerAt(ctx, x, y, s, col, rng, rot) {
    var R = deps();
    var loc = [[-1, -0.9], [0, -1.0], [1, -0.9], [1.02, 0], [0.95, 0.92], [0, 1.0], [-0.95, 0.9], [-1.0, 0]];
    for (var i = 0; i < loc.length; i++) { loc[i][0] *= s * 0.62; loc[i][1] *= s * 0.40; }
    var pts = place(jitter(loc, rng, s * 0.02), x, y, rot);
    solid(ctx, ptsPath(pts), boundsOf(pts), col, rng, {
      ao: 0.5, gloss: 0, core: 0.45, rim: 0.35, char: 0.25,
      texture: { n: Math.round(s * 1.2), size: Math.max(0.5, s * 0.02), a: 0.3 },
      detail: function (c) {
        c.save();
        c.translate(x, y);
        c.rotate(rot);
        for (var a = -1; a <= 1; a++) {
          for (var b = -1; b <= 1; b++) {
            c.beginPath();
            ellPath(a * s * 0.34, b * s * 0.22, Math.max(0.5, s * 0.035), Math.max(0.4, s * 0.025))(c);
            c.fillStyle = R.rgba(R.shade(col, -0.6), 0.75);
            c.fill();
          }
        }
        c.restore();
      },
    });
  }

  /* ================================================================== pie === */

  /** @returns {string} pasty | tart | lattice | closed */
  function pieForm(p) {
    if (nameHas(p, ['pasty', 'turnover'])) return 'pasty';
    if (nameHas(p, ['tart', 'quiche'])) return 'tart';
    return p.magnitude > 0.42 ? 'lattice' : 'closed';
  }

  /** The twisted rope of pastry round a pie's rim: slanted, shaded lozenges, not beads. */
  function crimpRope(ctx, cx, cy, rx, ry, crust, n, rng) {
    var R = deps();
    for (var i = 0; i < n; i++) {
      var a = (i / n) * TAU;
      var x = cx + Math.cos(a) * rx; var y = cy + Math.sin(a) * ry;
      var tan = Math.atan2(ry * Math.cos(a), -rx * Math.sin(a));
      var len = (TAU * Math.sqrt((rx * rx + ry * ry) / 2) / n) * 0.72;
      var pp = ellPath(x, y, len, Math.max(0.6, len * 0.42), tan + 0.65);
      var bb = ellBounds(x, y, len, len);
      ctx.beginPath();
      pp(ctx);
      R.litFill(ctx, x, y, len, R.shade(crust, Math.sin(a) > 0 ? -0.04 : 0.06), { lift: 0.4, drop: 0.35 });
      R.innerShade(ctx, pp, bb.x, bb.y, bb.w, bb.h, { depth: len * 0.35, blur: len * 0.4, darkA: 0.35, lightA: 0 });
    }
  }

  function drawPie(ctx, w, p, rng) {
    var R = deps();
    /* ⛔ THE FILLING IS THE INGREDIENTS, AND IT WAS NEVER DRAWN. MEASURED on the
     * 2026-09-10 contact sheet: four pies with four different fillings were
     * four identical golden lattices, because the crust colour was the only
     * thing the ingredients reached. The crust is pastry — the same pastry
     * whatever is inside — so it never takes the body colour; the filling does,
     * visible between the bars, through the vents, in the open tart, in the
     * bite taken out of a pasty. `tests/sabotage.js` replaces the filling with
     * the crust and REQUIRES plate.test.js to go red. */
    var crust = R.mix('#D9A24E', R.P.roast, 0.25);
    var filling = R.shade(p.bodyColour, -0.08);
    var form = pieForm(p);
    if (form === 'pasty') return drawPasty(ctx, w, p, rng, crust, filling);
    if (form === 'tart') return drawTart(ctx, w, p, rng, crust, filling);
    var rx = Math.min(w.rx * 1.0, w.ry * 2.1); var ry = Math.min(w.ry * 1.0, rx * 0.56);
    var cx = w.cx; var cy = w.cy;
    if (!w.deep) {
      R.contactShadow(ctx, cx, cy + ry * 0.35, rx * 1.02, ry * 0.8, 0.5);
      ctx.beginPath();
      ellPath(cx, cy + ry * 0.12, rx * 0.98, ry * 0.98)(ctx);
      ctx.fillStyle = R.shade(crust, -0.35);
      ctx.fill();
    }
    var inner = ellPath(cx, cy, rx * 0.84, ry * 0.84);
    ctx.beginPath();
    ellPath(cx, cy, rx * 0.98, ry * 0.98)(ctx);
    R.litFill(ctx, cx, cy, rx, crust, { lift: 0.22, drop: 0.30 });
    ctx.beginPath();
    inner(ctx);
    R.litFill(ctx, cx, cy, rx * 0.84, filling, { lift: 0.10, drop: 0.58 });
    ctx.save();
    ctx.beginPath();
    inner(ctx);
    ctx.clip();
    /* what went in, bubbling up between the bars (a filling is not a flat colour) */
    piecesOf(ctx, { cx: cx, cy: cy, rx: rx * 0.72, ry: ry * 0.70 }, p, rng,
      { count: 0.9, size: rx * 0.075, submerge: 0.55, liquid: filling, rMax: 0.9, sep: 0.2 });
    for (var bI = 0; bI < 14; bI++) {
      var ba = rng() * TAU; var br = Math.sqrt(rng()) * 0.8;
      R.glint(ctx, cx + Math.cos(ba) * rx * 0.84 * br, cy + Math.sin(ba) * ry * 0.84 * br, rx * 0.035, rx * 0.02, 0, 0.55);
    }
    if (form === 'closed') {
      ctx.beginPath();
      ellPath(cx, cy - ry * 0.04, rx * 0.86, ry * 0.86)(ctx);
      var lid = ctx.createRadialGradient(cx - rx * 0.25, cy - ry * 0.4, 0, cx, cy, rx * 0.9);
      lid.addColorStop(0, R.shade(crust, 0.35));
      lid.addColorStop(0.55, R.shade(crust, 0.05));
      lid.addColorStop(1, R.shade(crust, -0.28));
      ctx.fillStyle = lid;
      ctx.fill();
      R.stipple(ctx, cx, cy, rx * 0.8, ry * 0.8, rng, Math.round(rx * 0.9), Math.max(0.5, rx * 0.01), R.shade(crust, -0.4), '#FFF1CC', 0.35);
      for (var v = 0; v < 4; v++) {
        var va = -0.9 + v * 0.6 + Math.PI * (v % 2);
        var vx = cx + Math.cos(va) * rx * 0.30; var vy = cy + Math.sin(va) * ry * 0.30;
        var vp = ellPath(vx, vy, rx * 0.10, Math.max(0.6, ry * 0.035), va);
        ctx.beginPath();
        vp(ctx);
        ctx.fillStyle = R.shade(filling, -0.15);
        ctx.fill();
        ctx.beginPath();
        ctx.ellipse(vx, vy, rx * 0.10, Math.max(0.6, ry * 0.035), va, Math.PI * 1.05, Math.PI * 1.95);
        ctx.strokeStyle = R.rgba(R.shade(crust, -0.5), 0.6);
        ctx.lineWidth = Math.max(0.6, rx * 0.012);
        ctx.stroke();
      }
      pastryLeaf(ctx, cx + rx * 0.02, cy - ry * 0.02, rx * 0.20, -0.5, crust, rng);
    } else {
      var bars = 5;
      var strips = [];
      for (var d = 0; d < 2; d++) {
        var ang = d ? 0.62 : -0.62;
        for (var s = 0; s < bars; s++) {
          strips.push({ d: d, off: (s - (bars - 1) / 2) * 0.36, ang: ang, s: s });
        }
      }
      var drawStrip = function (st, clipCell) {
        var ux = Math.cos(st.ang); var uy = Math.sin(st.ang);
        var nx = -uy; var ny = ux;
        var hw = 0.075;
        var q = [[st.off * nx - ux * 1.2 + nx * hw, st.off * ny - uy * 1.2 + ny * hw],
          [st.off * nx + ux * 1.2 + nx * hw, st.off * ny + uy * 1.2 + ny * hw],
          [st.off * nx + ux * 1.2 - nx * hw, st.off * ny + uy * 1.2 - ny * hw],
          [st.off * nx - ux * 1.2 - nx * hw, st.off * ny - uy * 1.2 - ny * hw]];
        var sc = [];
        for (var k = 0; k < 4; k++) sc.push([cx + q[k][0] * rx * 0.84, cy + q[k][1] * ry * 0.84]);
        var shadowQ = [];
        for (var k2 = 0; k2 < 4; k2++) shadowQ.push([sc[k2][0] + rx * 0.02, sc[k2][1] + ry * 0.035]);
        ctx.save();
        if (clipCell) { ctx.beginPath(); clipCell(ctx); ctx.clip(); }
        ctx.beginPath();
        polyPath(shadowQ)(ctx);
        ctx.fillStyle = R.rgba(SHADOW, 0.30);
        ctx.fill();
        var sp = polyPath(sc);
        var sb = boundsOf(sc);
        ctx.beginPath();
        sp(ctx);
        var sg = ctx.createLinearGradient(sc[0][0], sc[0][1], sc[3][0], sc[3][1]);
        sg.addColorStop(0, R.shade(crust, 0.20));
        sg.addColorStop(0.45, crust);
        sg.addColorStop(1, R.shade(crust, -0.40));
        ctx.fillStyle = sg;
        ctx.fill();
        ctx.save();
        ctx.beginPath();
        sp(ctx);
        ctx.clip();
        R.stipple(ctx, sb.x + sb.w / 2, sb.y + sb.h / 2, sb.w / 2, sb.h / 2, rng, 10, Math.max(0.5, rx * 0.012), R.shade(crust, -0.45), '#FFF1C8', 0.35);
        ctx.restore();
        ctx.beginPath();
        ctx.moveTo(sc[0][0], sc[0][1]);
        ctx.lineTo(sc[1][0], sc[1][1]);
        ctx.strokeStyle = R.rgba('#FFF0C8', 0.35);
        ctx.lineWidth = Math.max(0.6, rx * 0.008);
        ctx.stroke();
        ctx.restore();
        return sb;
      };
      for (var a1 = 0; a1 < strips.length; a1++) if (strips[a1].d === 0) drawStrip(strips[a1]);
      for (var a2 = 0; a2 < strips.length; a2++) if (strips[a2].d === 1) drawStrip(strips[a2]);
      /* the weave: where an even crossing belongs to the first family, lay it back over */
      for (var i1 = 0; i1 < strips.length; i1++) {
        if (strips[i1].d !== 0) continue;
        for (var i2 = 0; i2 < strips.length; i2++) {
          if (strips[i2].d !== 1 || (strips[i1].s + strips[i2].s) % 2) continue;
          var A = strips[i1]; var B = strips[i2];
          var cellFn = (function (Aa, Bb) {
            return function (c) {
              var ux1 = Math.cos(Aa.ang); var uy1 = Math.sin(Aa.ang);
              var ux2 = Math.cos(Bb.ang); var uy2 = Math.sin(Bb.ang);
              var n1x = -uy1; var n1y = ux1; var n2x = -uy2; var n2y = ux2;
              var det = ux1 * (-uy2) - uy1 * (-ux2);
              var ox = Bb.off * n2x - Aa.off * n1x; var oy = Bb.off * n2y - Aa.off * n1y;
              var t = (ox * (-uy2) - oy * (-ux2)) / det;
              var px = Aa.off * n1x + ux1 * t; var py = Aa.off * n1y + uy1 * t;
              /* the cell is strip B's own band, a short way either side of the
               * crossing: strip A redrawn inside it lies OVER B there only */
              var hh = 0.16;
              c.moveTo(cx + (px - ux2 * hh - n2x * 0.09) * rx * 0.84, cy + (py - uy2 * hh - n2y * 0.09) * ry * 0.84);
              c.lineTo(cx + (px + ux2 * hh - n2x * 0.09) * rx * 0.84, cy + (py + uy2 * hh - n2y * 0.09) * ry * 0.84);
              c.lineTo(cx + (px + ux2 * hh + n2x * 0.09) * rx * 0.84, cy + (py + uy2 * hh + n2y * 0.09) * ry * 0.84);
              c.lineTo(cx + (px - ux2 * hh + n2x * 0.09) * rx * 0.84, cy + (py - uy2 * hh + n2y * 0.09) * ry * 0.84);
              c.closePath();
            };
          })(A, B);
          drawStrip(A, cellFn);
        }
      }
    }
    /* the oven browns a pie from its edge in */
    var bake = ctx.createRadialGradient(cx - rx * 0.1, cy - ry * 0.15, rx * 0.25, cx, cy, rx * 0.9);
    bake.addColorStop(0, R.rgba('#6A3410', 0));
    bake.addColorStop(1, R.rgba('#6A3410', 0.38));
    ctx.fillStyle = bake;
    ctx.fillRect(cx - rx, cy - ry, rx * 2, ry * 2);
    ctx.restore();
    R.innerShade(ctx, inner, cx - rx * 0.84, cy - ry * 0.84, rx * 1.68, ry * 1.68, { invert: true, depth: ry * 0.08, blur: ry * 0.12, darkA: 0.35, lightA: 0 });
    crimpRope(ctx, cx, cy, rx * 0.91, ry * 0.91, crust, 34, rng);
    if (p.char > 0.05) {
      ctx.save();
      ctx.beginPath();
      ellPath(cx, cy, rx * 0.93, ry * 0.93)(ctx);
      ctx.strokeStyle = R.rgba(R.shade(crust, -0.6), 0.10 + p.char * 0.25);
      ctx.lineWidth = Math.max(2, ry * 0.10);
      ctx.stroke();
      ctx.restore();
    }
    glints(ctx, cx, cy, rx * 0.8, ry * 0.8, ry * 0.5, 0.3 + p.gloss * 0.4, rng);
  }

  /** A leaf cut from pastry and laid on a pie lid. */
  function pastryLeaf(ctx, x, y, s, rot, crust, rng) {
    var R = deps();
    var loc = [[-1, 0], [-0.4, -0.42], [0.4, -0.36], [1, 0], [0.4, 0.36], [-0.4, 0.42]];
    for (var i = 0; i < loc.length; i++) { loc[i][0] *= s; loc[i][1] *= s * 0.8; }
    var pts = place(loc, x, y, rot);
    solid(ctx, ptsPath(pts), boundsOf(pts), R.shade(crust, 0.12), rng, {
      ao: 0.35, gloss: 0.3, core: 0.4, rim: 0.35,
      detail: function (c) {
        c.save();
        c.translate(x, y);
        c.rotate(rot);
        c.beginPath();
        c.moveTo(-s * 0.85, 0);
        c.lineTo(s * 0.85, 0);
        for (var k = -2; k <= 2; k++) {
          c.moveTo(k * s * 0.3, 0);
          c.lineTo(k * s * 0.3 + s * 0.2, -s * 0.22);
          c.moveTo(k * s * 0.3, 0);
          c.lineTo(k * s * 0.3 + s * 0.2, s * 0.22);
        }
        c.strokeStyle = R.rgba(R.shade(crust, -0.45), 0.55);
        c.lineWidth = Math.max(0.5, s * 0.05);
        c.stroke();
        c.restore();
      },
    });
  }

  /** A pasty: a half-moon with a crimped seam along its crown, and a bite of filling. */
  function drawPasty(ctx, w, p, rng, crust, filling) {
    var R = deps();
    var n = p.portions >= 3 ? 2 : 1;
    var L = Math.min(w.rx * (n > 1 ? 0.62 : 0.84), w.ry * 1.9);
    for (var i = n - 1; i >= 0; i--) {
      var x = w.cx + (i - (n - 1) / 2) * L * 0.9; var y = w.cy + (i - (n - 1) / 2) * w.ry * 0.3;
      var rot = -0.15 + i * 0.3;
      var loc = [[-1.0, 0.18], [-0.86, -0.22], [-0.45, -0.52], [0, -0.60], [0.45, -0.52], [0.86, -0.22], [1.0, 0.18], [0.5, 0.30], [0, 0.32], [-0.5, 0.30]];
      for (var k = 0; k < loc.length; k++) { loc[k][0] *= L; loc[k][1] *= L * 0.75; }
      var pts = place(jitter(loc, rng, L * 0.015), x, y, rot);
      solid(ctx, ptsPath(pts), boundsOf(pts), crust, rng, {
        ao: 0.55, gloss: 0.35 + p.gloss * 0.3, char: p.char * 0.6, core: 0.55, rim: 0.3,
        texture: { n: Math.round(L), size: Math.max(0.5, L * 0.012), a: 0.3 },
      });
      var seam = [];
      for (var q = 0; q <= 14; q++) {
        var t = q / 14;
        var sx = (-0.92 + 1.84 * t) * L; var sy = (-0.34 - Math.sin(Math.PI * t) * 0.20) * L * 0.75;
        seam.push(place([[sx, sy]], x, y, rot)[0]);
      }
      for (var z = 0; z < seam.length; z++) {
        var sp = ellPath(seam[z][0], seam[z][1], L * 0.07, Math.max(0.6, L * 0.03), rot + 0.7);
        var sb = ellBounds(seam[z][0], seam[z][1], L * 0.07, L * 0.07);
        ctx.beginPath();
        sp(ctx);
        R.litFill(ctx, seam[z][0], seam[z][1], L * 0.07, R.shade(crust, 0.12), { lift: 0.4, drop: 0.35 });
        R.innerShade(ctx, sp, sb.x, sb.y, sb.w, sb.h, { depth: L * 0.02, blur: L * 0.025, darkA: 0.35, lightA: 0 });
      }
      var bite = place([[0.58 * L, 0.02 * L]], x, y, rot)[0];
      var bp = ellPath(bite[0], bite[1], L * 0.16, L * 0.10, rot);
      ctx.beginPath();
      bp(ctx);
      R.litFill(ctx, bite[0], bite[1], L * 0.16, filling, { lift: 0.3, drop: 0.4 });
      R.innerShade(ctx, bp, bite[0] - L * 0.16, bite[1] - L * 0.1, L * 0.32, L * 0.2, { invert: true, depth: L * 0.03, blur: L * 0.04, darkA: 0.45, lightA: 0 });
    }
  }

  /** An open tart: a fluted pastry case and a glossy filling with what went in it. */
  function drawTart(ctx, w, p, rng, crust, filling) {
    var R = deps();
    var rx = Math.min(w.rx * 0.95, w.ry * 2.0); var ry = Math.min(w.ry * 0.95, rx * 0.56);
    var cx = w.cx; var cy = w.cy;
    var wallH = ry * 0.18;
    R.contactShadow(ctx, cx, cy + ry * 0.4, rx, ry * 0.8, 0.5);
    ctx.beginPath();
    ellPath(cx, cy + wallH, rx, ry)(ctx);
    ctx.fillStyle = R.shade(crust, -0.32);
    ctx.fill();
    ctx.save();
    ctx.beginPath();
    ellPath(cx, cy + wallH, rx, ry)(ctx);
    ctx.clip();
    for (var f = 0; f < 40; f++) {
      var a = (f / 40) * Math.PI;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * rx, cy + Math.sin(a) * ry);
      ctx.lineTo(cx + Math.cos(a) * rx, cy + wallH + Math.sin(a) * ry);
      ctx.strokeStyle = R.rgba(f % 2 ? '#FFE8B8' : SHADOW, 0.25);
      ctx.lineWidth = Math.max(0.8, rx * 0.02);
      ctx.stroke();
    }
    ctx.restore();
    ctx.beginPath();
    ellPath(cx, cy, rx, ry)(ctx);
    R.litFill(ctx, cx, cy, rx, crust, { lift: 0.3, drop: 0.3 });
    var fp = ellPath(cx, cy + ry * 0.02, rx * 0.86, ry * 0.84);
    var jelly = ax(p, 'arcane') > 0.12;
    ctx.beginPath();
    fp(ctx);
    R.litFill(ctx, cx, cy, rx * 0.86, filling, { lift: jelly ? 0.5 : 0.3, drop: 0.35 });
    ctx.save();
    ctx.beginPath();
    fp(ctx);
    ctx.clip();
    if (jelly) {
      /* a magical jelly glows its own colour through the sugar it was set with */
      var magic = null;
      for (var mI = 0; mI < (p.ingredients || []).length; mI++) {
        if ((p.ingredients[mI].axes || []).indexOf('arcane') >= 0) { magic = p.ingredients[mI]; break; }
      }
      if (magic) {
        R.puff(ctx, cx, cy, rx * 1.1, magic.colour, 0.85);
        R.puff(ctx, cx, cy, rx * 0.6, R.shade(magic.colour, 0.2), 0.6);
        R.puff(ctx, cx - rx * 0.25, cy - ry * 0.2, rx * 0.4, R.shade(magic.colour, 0.6), 0.5);
      }
      R.puff(ctx, cx + rx * 0.2, cy + ry * 0.15, rx * 0.6, R.shade(filling, 0.5), 0.35);
      for (var bI = 0; bI < 12; bI++) {
        var bx = cx + (rng() - 0.5) * rx * 1.4; var by = cy + (rng() - 0.5) * ry * 1.3; var br = rx * (0.02 + rng() * 0.04);
        ctx.beginPath();
        ellPath(bx, by, br, br * 0.8)(ctx);
        ctx.strokeStyle = R.rgba(R.shade(filling, 0.6), 0.6);
        ctx.lineWidth = Math.max(0.5, br * 0.25);
        ctx.stroke();
      }
    }
    ctx.restore();
    piecesOf(ctx, { cx: cx, cy: cy, rx: rx * 0.7, ry: ry * 0.62 }, p, rng, { count: 0.5, size: rx * 0.08, submerge: 0.35, liquid: filling, rMax: 0.8, sep: 0.3 });
    R.innerShade(ctx, fp, cx - rx * 0.86, cy - ry * 0.84, rx * 1.72, ry * 1.68, { invert: true, depth: ry * 0.10, blur: ry * 0.14, darkA: 0.4, lightA: 0 });
    R.glint(ctx, cx - rx * 0.35, cy - ry * 0.38, rx * 0.26, ry * 0.05, -0.15, 0.7);
    crimpRope(ctx, cx, cy, rx * 0.93, ry * 0.93, crust, 30, rng);
  }

  /* ================================================================ salad === */

  function drawSalad(ctx, w, p, rng) {
    var R = deps();
    var greens = []; var others = [];
    var ings = p.ingredients || [];
    for (var i = 0; i < ings.length; i++) {
      var k = pieceKind(ings[i]);
      if (k === 'green') greens.push(ings[i]);
      else if (k) others.push({ ing: ings[i], kind: k });
    }
    if (!greens.length) greens.push({ colour: R.P.herb, head: 'lettuce', axes: ['green'] });
    /* ⛔ A salad is a HEAP: the first pass scattered a dozen leaves over the
     * vessel and read as a pizza with toppings (art stage, 2026-09-10). Broad
     * leaves are laid first, overlapping, from the back; small leaves (cress)
     * are strewn on top; then whatever else went in. */
    var broad = []; var small = [];
    for (var gI = 0; gI < greens.length; gI++) {
      if (String(greens[gI].head || '') === 'cress') small.push(greens[gI]); else broad.push(greens[gI]);
    }
    if (!broad.length) broad.push(greens[0]);
    var n = clamp(12 + p.portions * 3, 14, 26);
    var pts = R.scatter(rng, n, { rMin: 0.0, rMax: 0.74, sep: 0.13, tries: 40 });
    pts.sort(function (a, b) { return a.y - b.y; });
    var s = Math.min(w.rx * 0.40, w.ry * 0.80);
    for (var j = 0; j < pts.length; j++) {
      var g = broad[j % broad.length];
      var x = w.cx + pts[j].x * w.rx * 0.9; var y = w.cy + pts[j].y * w.ry - (1 - Math.abs(pts[j].x)) * w.ry * 0.1;
      var col = R.shade(R.mix(g.colour, j % 3 ? '#7FA24C' : '#3F6A2C', 0.3), (rng() - 0.5) * 0.25);
      var loc = [[-1.1, 0], [-0.7, -0.45], [-0.1, -0.62], [0.5, -0.55], [1.0, -0.2], [1.1, 0.1], [0.6, 0.45], [0, 0.55], [-0.6, 0.42]];
      for (var q = 0; q < loc.length; q++) { loc[q][0] *= s * pts[j].s; loc[q][1] *= s * pts[j].s * 0.7; }
      var lpts = place(jitter(loc, rng, s * 0.10), x, y, pts[j].a * 2);
      solid(ctx, ptsPath(lpts), boundsOf(lpts), col, rng, {
        ao: 0.35, gloss: 0.45, core: 0.40, rim: 0.35,
        detail: function (cc) {
          cc.beginPath();
          cc.moveTo(lpts[0][0], lpts[0][1]);
          cc.quadraticCurveTo(lpts[2][0], (lpts[2][1] + lpts[7][1]) / 2, lpts[5][0], lpts[5][1]);
          cc.strokeStyle = R.rgba('#E6F0C0', 0.55);
          cc.lineWidth = Math.max(0.6, s * 0.035);
          cc.stroke();
        },
      });
    }
    for (var sm = 0; sm < small.length; sm++) {
      var clusters = 5 + p.portions * 2;
      for (var cI = 0; cI < clusters; cI++) {
        var qx = w.cx + (rng() - 0.5) * w.rx * 1.4; var qy = w.cy + (rng() - 0.5) * w.ry * 1.1;
        for (var c = 0; c < 4; c++) {
          var lx = qx + (rng() - 0.5) * s * 0.5; var ly = qy + (rng() - 0.5) * s * 0.3;
          var lcol = R.shade(R.mix(small[sm].colour, '#7FA24C', 0.3), (rng() - 0.5) * 0.25);
          var lp = ellPath(lx, ly, s * 0.13, s * 0.10, rng() * TAU);
          solid(ctx, lp, ellBounds(lx, ly, s * 0.13, s * 0.1), lcol, rng, { ao: 0.25, gloss: 0.5, core: 0.35, rim: 0.3 });
        }
      }
    }
    for (var o = 0; o < others.length; o++) {
      var hd = String(others[o].ing.head || '').toLowerCase();
      var m = 2 + Math.round(p.portions / 2);
      for (var r2 = 0; r2 < m; r2++) {
        var px = w.cx + (rng() - 0.5) * w.rx * 1.3; var py = w.cy + (rng() - 0.5) * w.ry * 1.1;
        if (hd === 'radish' || hd === 'beet') {
          var rr = s * 0.28;
          var rp = ellPath(px, py, rr, rr * 0.62, rng() * 0.5);
          solid(ctx, rp, ellBounds(px, py, rr, rr * 0.62), '#F3ECE6', rng, {
            ao: 0.3, gloss: 0.5, core: 0.25, rim: 0.3,
            detail: function (cc, cx2, cy2, hx, hy) {
              cc.beginPath();
              ellPath(cx2, cy2, hx, hy)(cc);
              cc.strokeStyle = R.rgba(others[o].ing.colour, 0.95);
              cc.lineWidth = Math.max(1, hx * 0.22);
              cc.stroke();
            },
          });
        } else {
          piece(ctx, others[o].kind, others[o].ing, px, py, s * 0.22, rng, { ao: 0.3 });
        }
      }
    }
  }

  /* ============================================================== skewers === */

  function drawSkewers(ctx, w, p, rng) {
    var R = deps();
    var list = [];
    var ings = p.ingredients || [];
    for (var i = 0; i < ings.length; i++) { var k = pieceKind(ings[i]); if (k) list.push({ ing: ings[i], kind: k }); }
    if (!list.length) list.push({ ing: { colour: p.bodyColour, head: '', axes: ['meat'] }, kind: 'meat' });
    var rows = clamp(p.portions, 2, 4);
    var rack = w.rack;
    for (var r = 0; r < rows; r++) {
      var t = rows === 1 ? 0.5 : r / (rows - 1);
      var x0, y0, x1, y1;
      if (rack) {
        var yy = rack[0].top + rack[0].depth * (0.15 + t * 0.7);
        x0 = rack[0].x - rack[0].w * 1.6; x1 = rack[1].x + rack[1].w * 1.6; y0 = yy; y1 = yy;
      } else {
        var off = (t - 0.5) * w.ry * 1.3;
        x0 = w.cx - w.rx * 1.05; y0 = w.cy + off + w.ry * 0.35; x1 = w.cx + w.rx * 1.05; y1 = w.cy + off - w.ry * 0.35;
      }
      var ang = Math.atan2(y1 - y0, x1 - x0);
      var len = Math.sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0));
      R.contactShadow(ctx, (x0 + x1) / 2, (y0 + y1) / 2 + w.ry * 0.18, len * 0.5, w.ry * 0.16, 0.35);
      ctx.save();
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.lineTo(x1, y1);
      ctx.strokeStyle = '#8A6A44';
      ctx.lineWidth = Math.max(1.5, w.rx * 0.030);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x0, y0 - 0.6);
      ctx.lineTo(x1, y1 - 0.6);
      ctx.strokeStyle = R.rgba('#E2C99A', 0.6);
      ctx.lineWidth = Math.max(0.6, w.rx * 0.010);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x1 - Math.cos(ang) * len * 0.06, y1 - Math.sin(ang) * len * 0.06);
      ctx.lineTo(x1, y1);
      ctx.strokeStyle = '#2A1A10';
      ctx.lineWidth = Math.max(1.5, w.rx * 0.030);
      ctx.stroke();
      ctx.restore();
      var n = clamp(4 + Math.round(p.magnitude * 3), 4, 7);
      var s = Math.min(len / n * 0.52, w.ry * 0.40);
      for (var c = 0; c < n; c++) {
        var tt = 0.16 + (c / (n - 1)) * 0.68;
        var px = x0 + (x1 - x0) * tt; var py = y0 + (y1 - y0) * tt;
        var it = list[(c + r) % list.length];
        var hd = String(it.ing.head || '').toLowerCase();
        if (it.kind === 'root' && (hd === 'onion' || hd === 'shallot')) {
          for (var l = 2; l >= 0; l--) {
            var op = ellPath(px, py, s * (0.5 + l * 0.18), s * (0.9 - l * 0.05), ang);
            solid(ctx, op, ellBounds(px, py, s, s), R.shade('#EADAC0', -l * 0.08), rng, { ao: l === 2 ? 0.35 : 0, gloss: 0.5, core: 0.3, rim: 0.3, char: 0.2 });
          }
          continue;
        }
        /* ⛔ Round blobs in a row read as BEADS (art stage contact sheet,
         * 2026-09-10). Skewered meat is a rough charred cube; everything else
         * is drawn as the piece it is. */
        if (it.kind === 'meat') {
          var col = cookedColour(it.ing, it.kind);
          var mc = cube(ctx, px, py, s * 0.78, R.shade(col, 0.05), rng, ang + (rng() - 0.5) * 0.8, { ao: 0.4, gloss: p.gloss });
          ctx.save();
          ctx.beginPath();
          mc.path(ctx);
          ctx.clip();
          charPatches(ctx, mc.b.x + mc.b.w / 2, mc.b.y + mc.b.h / 2, mc.b.w / 2, mc.b.h / 2, rng, 0.35 + p.char * 0.6);
          ctx.restore();
        } else {
          piece(ctx, it.kind, it.ing, px, py, s * 0.9, rng, { ao: 0.4, gloss: 0.5, char: p.char * 0.5 });
        }
      }
    }
  }

  /* ============================================================= porridge === */

  function drawPorridge(ctx, w, p, rng) {
    var R = deps();
    var rice = !!findIng(p, ['rice']) || nameHas(p, ['risotto', 'pilaf', 'pilau']);
    /* ⛔ Rice is served HEAPED. Drawn as a porridge's flat surface with grains
     * stippled into it, `Saffron Rice` read as a bowl of soup (product size,
     * art stage 2026-09-10). */
    if (rice) return drawRice(ctx, w, p, rng);
    var base = R.mix(p.bodyColour, '#EADBB8', 0.35);
    liquidSurface(ctx, w, p, rng, {
      colour: base, gloss: 0.25,
      detail: function (c, s) {
        R.stipple(c, s.cx, s.cy, s.rx, s.ry, rng, Math.round(s.rx * 2.4), Math.max(0.6, s.rx * 0.02), R.shade(base, -0.3), '#FFFFFF', 0.4);
        c.beginPath();
        for (var t = 0; t < 36; t++) {
          var aa = t * 0.42; var r2 = 0.06 + t * 0.022;
          var x = s.cx + Math.cos(aa) * s.rx * r2; var y = s.cy + Math.sin(aa) * s.ry * r2;
          if (t === 0) c.moveTo(x, y); else c.lineTo(x, y);
        }
        c.strokeStyle = R.rgba(R.shade(base, -0.35), 0.35);
        c.lineWidth = Math.max(1, s.rx * 0.03);
        c.stroke();
      },
    });
    var s2 = w.surface || w;
    /* ⛔ A pool of CREAM needs cream in the list. Keyed on the dairy axis, a
     * pat of butter poured a white pool into `Saffron Rice` that read as a
     * fried egg (product size, 2026-09-10). Butter is a melting pat. */
    var creamy = findIng(p, ['cream', 'milk', 'curd']);
    if (creamy || p.behaviour === 'cream') {
      var cp = R.blobPts(s2.cx + s2.rx * 0.1, s2.cy + s2.ry * 0.05, s2.rx * 0.34, s2.ry * 0.3, rng, 0.15, 9, 0);
      ctx.beginPath();
      R.smoothPath(ctx, cp);
      ctx.fillStyle = R.rgba('#FBF5E8', 0.92);
      ctx.fill();
      R.glint(ctx, s2.cx - s2.rx * 0.05, s2.cy - s2.ry * 0.08, s2.rx * 0.12, s2.ry * 0.04, -0.2, 0.7);
    }
    var honey = findIng(p, ['honey', 'syrup']);
    if (honey) {
      /* ⛔ At rx * 0.065 the drizzle was a TUBE and read as a bent orange
       * noodle (product size, art stage 2026-09-10). Honey poured from a spoon
       * is a THIN translucent thread that loops back over itself in figure
       * eights, and where it lands it spreads into small glossy pools. */
      var amber = honey.head === 'syrup' ? '#8E5A1E' : '#DDA02A';
      var hp = [];
      for (var h = 0; h < 22; h++) {
        var ht = h / 21;
        hp.push([s2.cx + Math.sin(ht * Math.PI * 3.2 + 0.4) * s2.rx * (0.52 - ht * 0.18) + (rng() - 0.5) * s2.rx * 0.03,
          s2.cy - s2.ry * 0.46 + ht * s2.ry * 0.92 + Math.cos(ht * Math.PI * 6.4) * s2.ry * 0.10]);
      }
      for (var hq = 0; hq < 4; hq++) {
        var at = hp[3 + hq * 5];
        R.puff(ctx, at[0], at[1], s2.rx * 0.09, amber, 0.45);
      }
      ctx.save();
      ctx.globalAlpha = 0.85;
      drizzle(ctx, hp, Math.max(1.0, s2.rx * 0.022), amber);
      ctx.restore();
    }
    if (findIng(p, ['butter'])) butterPat(ctx, s2.cx + s2.rx * 0.28, s2.cy - s2.ry * 0.12, s2.rx * 0.10, rng);
    piecesOf(ctx, w, p, rng, { count: 0.4, size: w.rx * 0.08, submerge: 0.3, liquid: base, rMax: 0.7, sep: 0.3 });
  }

  /**
   * A heap of rice in its bowl: a lit dome that rises above the back rim (the
   * well's clip lets it), every grain a small lit lozenge lying along the
   * slope, saffron threads, and butter melting on the crown.
   */
  function drawRice(ctx, w, p, rng) {
    var R = deps();
    var s = w.surface || { cx: w.cx, cy: w.cy, rx: w.rx, ry: w.ry };
    var saffron = findIng(p, ['saffron']);
    var grain = saffron ? R.mix(p.bodyColour, '#EDB43E', 0.60) : R.mix(p.bodyColour, '#F4EEDD', 0.40);
    /* ⛔ At 1.25 x ry the heap rose a whole bowl-height above the rim and
     * read as a golden BUN (first render, 2026-09-10): a serving of rice
     * crowns the far rim by a third, no more */
    var hMound = s.ry * 0.70;
    var dcx = s.cx; var dcy = s.cy - hMound * 0.30;
    var drx = s.rx * 0.94; var dry = s.ry * 0.80 + hMound * 0.52;
    var dome = ellPath(dcx, dcy, drx, dry);
    w.steamTop = dcy - dry * 0.85;
    w.heaped = true;
    R.contactShadow(ctx, s.cx, s.cy + s.ry * 0.15, s.rx * 0.95, s.ry * 0.7, 0.35);
    ctx.beginPath();
    dome(ctx);
    /* the ground between grains is the grains' own shadow */
    R.litFill(ctx, dcx, dcy, Math.max(drx, dry), R.shade(grain, -0.28), { lift: 0.30, drop: 0.36 });
    ctx.save();
    ctx.beginPath();
    dome(ctx);
    ctx.clip();
    /* grains: enough to cover the heap, each lying roughly along its slope.
     * ⛔ drx * 1.9 grains in +/-0.2 of the base colour left the heap a smooth
     * dome — the texture IS the rice, so it must carry contrast */
    var n = Math.round(drx * 3.4);
    var gl = Math.max(1.2, drx * 0.052); var gw = Math.max(0.6, drx * 0.020);
    for (var i = 0; i < n; i++) {
      var a = rng() * TAU; var rr = Math.sqrt(rng());
      var gx = dcx + Math.cos(a) * drx * rr;
      var gy = dcy + Math.sin(a) * dry * rr;
      var tilt = a + Math.PI / 2 + (rng() - 0.5) * 1.4;
      var lit = -(Math.cos(a) * 0.6 + Math.sin(a) * 0.8) * rr;
      ctx.beginPath();
      ellPath(gx + gw * 0.6, gy + gw * 0.8, gl, gw, tilt)(ctx);
      ctx.fillStyle = R.rgba(R.shade(grain, -0.55), 0.42);
      ctx.fill();
      ctx.beginPath();
      ellPath(gx, gy, gl, gw, tilt)(ctx);
      ctx.fillStyle = R.shade(grain, 0.06 + lit * 0.30 + (rng() - 0.5) * 0.16);
      ctx.fill();
      if (rng() < 0.35) {
        ctx.beginPath();
        ellPath(gx - gw * 0.25, gy - gw * 0.3, gl * 0.55, gw * 0.35, tilt)(ctx);
        ctx.fillStyle = R.rgba('#FFFBEA', 0.55);
        ctx.fill();
      }
    }
    if (saffron) {
      for (var t = 0; t < 9; t++) {
        var tx = dcx + (rng() - 0.5) * drx * 1.2; var ty = dcy + (rng() - 0.5) * dry * 1.0;
        var ta = rng() * TAU; var tl = drx * (0.07 + rng() * 0.05);
        ctx.beginPath();
        ctx.moveTo(tx - Math.cos(ta) * tl, ty - Math.sin(ta) * tl);
        ctx.quadraticCurveTo(tx + Math.sin(ta) * tl * 0.4, ty - Math.cos(ta) * tl * 0.4, tx + Math.cos(ta) * tl, ty + Math.sin(ta) * tl);
        ctx.strokeStyle = R.rgba('#B8260E', 0.9);
        ctx.lineWidth = Math.max(0.7, drx * 0.012);
        ctx.lineCap = 'round';
        ctx.stroke();
      }
    }
    ctx.restore();
    /* ⛔ No glints and no lit rim: with both, the heap read as rice under a
     * GLASS CLOCHE (product size, 2026-09-10). Rice is matte; its light is in
     * the grains, and the heap is only shaded where it turns away. */
    R.innerShade(ctx, dome, dcx - drx, dcy - dry, drx * 2, dry * 2, {
      depth: dry * 0.20, blur: dry * 0.30, darkA: 0.40, lightA: 0,
    });
    if (findIng(p, ['butter'])) butterPat(ctx, dcx + drx * 0.10, dcy - dry * 0.30, drx * 0.13, rng);
    var herb = findIng(p, ['parsley', 'chive', 'coriander', 'mint', 'dill'], true);
    if (herb) {
      for (var hb = 0; hb < 7; hb++) {
        GARNISH_DRAW.herbLeaf(ctx, dcx + (rng() - 0.5) * drx * 1.1, dcy + (rng() - 0.5) * dry * 0.9,
          drx * 0.05, rng() * TAU, herb.colour, rng);
      }
    }
  }

  /* ================================================================ jerky === */

  /**
   * A whole smoked eel lying in a lazy S, sliced through in three places.
   * The body is built from its CENTRELINE with a half-width that swells behind
   * the head and tapers to the tail, so the outline and every cut follow the
   * same curve (wing §11: one path, not two that must agree).
   */
  function drawSmokedEel(ctx, w, p, rng) {
    var R = deps();
    /* ⛔ first render (2026-09-10): olive, thin and nearly straight, it read
     * as a SAUSAGE — an eel is lacquer-dark with the smoke's gold on it, as
     * thick as a wrist, and it lies in a real S */
    var skin = R.mix(p.bodyColour, '#2A1C0C', 0.72);
    var flesh = '#E4CCA2';
    var span = w.rx * 1.00;
    var amp = w.ry * 0.62;
    var steps = 44;
    var dia = w.rx * 0.19;
    var mid = [];
    for (var i = 0; i <= steps; i++) {
      var t = i / steps;
      mid.push([w.cx - span + t * span * 2, w.cy + Math.sin(t * Math.PI * 1.6 - 0.5) * amp * (0.85 + 0.15 * t) - amp * 0.10]);
    }
    function halfW(t) {
      if (t < 0.05) return dia * (0.55 + t / 0.05 * 0.30);
      if (t < 0.12) return dia * (0.85 + (t - 0.05) / 0.07 * 0.15);
      if (t < 0.62) return dia;
      return dia * Math.max(0.10, 1 - (t - 0.62) / 0.38 * 0.90);
    }
    function normalAt(i) {
      var a = mid[Math.max(0, i - 1)]; var b = mid[Math.min(steps, i + 1)];
      var dx = b[0] - a[0]; var dy = b[1] - a[1]; var l = Math.sqrt(dx * dx + dy * dy) || 1;
      return [-dy / l, dx / l];
    }
    var upper = []; var lower = [];
    for (var j = 0; j <= steps; j++) {
      var nrm = normalAt(j); var hw = halfW(j / steps);
      /* foreshortened: the body is a tube seen from above at three-quarters */
      upper.push([mid[j][0] + nrm[0] * hw, mid[j][1] + nrm[1] * hw * 0.82]);
      lower.push([mid[j][0] - nrm[0] * hw, mid[j][1] - nrm[1] * hw * 0.82]);
    }
    /* a rounded snout closes the head; the tail closes to a point */
    var head = [mid[0][0] - dia * 0.45, mid[0][1]];
    var outline = [head].concat(upper, lower.reverse());
    solid(ctx, ptsPath(outline), boundsOf(outline), skin, rng, {
      ao: 0.55, gloss: 1.0, core: 0.55, rim: 0.40, lift: 0.38, depthK: 0.20, blurK: 0.36,
      detail: function (c) {
        /* the smoke's gold along the lit flank, skin fine as leather */
        for (var g = 2; g < steps - 4; g += 3) {
          var nn = normalAt(g); var hw2 = halfW(g / steps);
          R.puff(c, mid[g][0] + nn[0] * hw2 * 0.40, mid[g][1] + nn[1] * hw2 * 0.34, hw2 * 0.9, '#D49C48', 0.20);
        }
        R.stipple(c, w.cx, w.cy, span, amp + dia, rng, 90, Math.max(0.5, dia * 0.05), '#140C06', '#F2CC88', 0.30);
      },
    });
    /* the dorsal fin: a fine crimped ridge along the back from mid-body to tail */
    ctx.save();
    ctx.beginPath();
    for (var d = Math.round(steps * 0.30); d <= steps - 1; d++) {
      var nd = normalAt(d); var hd = halfW(d / steps);
      var dx2 = mid[d][0] + nd[0] * hd * 1.05; var dy2 = mid[d][1] + nd[1] * hd * 0.86;
      if (d === Math.round(steps * 0.30)) ctx.moveTo(dx2, dy2); else ctx.lineTo(dx2, dy2);
    }
    ctx.strokeStyle = R.rgba('#1A1008', 0.75);
    ctx.lineWidth = Math.max(0.8, dia * 0.12);
    ctx.lineJoin = 'round';
    ctx.stroke();
    /* the belly is paler than the back: a gold-grey band along the lower edge */
    ctx.beginPath();
    for (var bl = 3; bl <= Math.round(steps * 0.86); bl++) {
      var nb = normalAt(bl); var hb = halfW(bl / steps);
      var bx0 = mid[bl][0] - nb[0] * hb * 0.62; var by0 = mid[bl][1] - nb[1] * hb * 0.52;
      if (bl === 3) ctx.moveTo(bx0, by0); else ctx.lineTo(bx0, by0);
    }
    ctx.strokeStyle = R.rgba('#B89A62', 0.45);
    ctx.lineWidth = Math.max(1, dia * 0.26);
    ctx.lineCap = 'round';
    ctx.stroke();
    ctx.restore();
    /* three cuts: a sliver of pale flesh across the body, the far edge in shadow */
    var cuts = [0.30, 0.46, 0.62];
    for (var k = 0; k < cuts.length; k++) {
      var ci = Math.round(cuts[k] * steps);
      var nc = normalAt(ci); var hc = halfW(cuts[k]);
      var tx = nc[1]; var ty = -nc[0];
      var ax2 = mid[ci][0] + nc[0] * hc * 0.98; var ay2 = mid[ci][1] + nc[1] * hc * 0.80;
      var bx2 = mid[ci][0] - nc[0] * hc * 0.98; var by2 = mid[ci][1] - nc[1] * hc * 0.80;
      var gap = dia * 0.20;
      ctx.beginPath();
      ctx.moveTo(ax2, ay2);
      ctx.quadraticCurveTo(mid[ci][0] + tx * gap, mid[ci][1] + ty * gap, bx2, by2);
      ctx.quadraticCurveTo(mid[ci][0] - tx * gap * 0.2, mid[ci][1] - ty * gap * 0.2, ax2, ay2);
      ctx.closePath();
      ctx.fillStyle = flesh;
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(ax2, ay2);
      ctx.quadraticCurveTo(mid[ci][0] - tx * gap * 0.2, mid[ci][1] - ty * gap * 0.2, bx2, by2);
      ctx.strokeStyle = R.rgba('#120A04', 0.75);
      ctx.lineWidth = Math.max(0.8, dia * 0.07);
      ctx.stroke();
    }
    /* the head: a small dark eye with the lamp in it, the mouth, a gill slit */
    var n0 = normalAt(2);
    var ex = mid[1][0] + n0[0] * dia * 0.30 - dia * 0.05; var ey = mid[1][1] + n0[1] * dia * 0.22;
    ctx.beginPath();
    ellPath(ex, ey, dia * 0.19, dia * 0.17)(ctx);
    ctx.fillStyle = R.shade(skin, 0.45);
    ctx.fill();
    ctx.beginPath();
    ellPath(ex, ey, dia * 0.13, dia * 0.12)(ctx);
    ctx.fillStyle = '#0E0804';
    ctx.fill();
    R.glint(ctx, ex - dia * 0.04, ey - dia * 0.04, dia * 0.07, dia * 0.035, -0.6, 0.95);
    ctx.save();
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(head[0] + dia * 0.05, head[1] + dia * 0.05);
    ctx.quadraticCurveTo(mid[1][0], mid[1][1] + dia * 0.18, mid[2][0] + dia * 0.1, mid[2][1] + dia * 0.12);
    ctx.strokeStyle = R.rgba('#120A04', 0.7);
    ctx.lineWidth = Math.max(0.7, dia * 0.07);
    ctx.stroke();
    var gi = 5; var ng = normalAt(gi); var hg = halfW(gi / steps);
    ctx.beginPath();
    ctx.moveTo(mid[gi][0] + ng[0] * hg * 0.7, mid[gi][1] + ng[1] * hg * 0.55);
    ctx.quadraticCurveTo(mid[gi][0] + dia * 0.12, mid[gi][1], mid[gi][0] - ng[0] * hg * 0.7, mid[gi][1] - ng[1] * hg * 0.55);
    ctx.strokeStyle = R.rgba('#120A04', 0.55);
    ctx.lineWidth = Math.max(0.6, dia * 0.06);
    ctx.stroke();
    ctx.restore();
    /* salt on the skin where it was cured */
    if (findIng(p, ['salt'], true)) {
      for (var z = 0; z < 26; z++) {
        var zi = 2 + Math.floor(rng() * (steps - 6));
        var nz = normalAt(zi); var hz = halfW(zi / steps) * (rng() - 0.3);
        ctx.fillStyle = R.rgba('#FFFFFF', 0.80);
        var zs = Math.max(0.7, dia * 0.06);
        ctx.fillRect(mid[zi][0] + nz[0] * hz, mid[zi][1] + nz[1] * hz * 0.8, zs, zs);
      }
    }
  }

  function drawJerky(ctx, w, p, rng) {
    var R = deps();
    var fishy = ax(p, 'fish') > ax(p, 'meat');
    var L = Math.min(w.rx * 0.84, w.ry * 1.9);
    if (fishy) {
      /* ⛔ FOUR PASSES, EACH MEASURED AT PRODUCT SIZE (art stage 2026-09-10).
       * Thin cylinders read as sticks; fat ones with ringed cut faces read as
       * FIREWOOD; a white face with a spine dot read as a googly EYE; a warm
       * face without the dot still read as a pile of logs. Sections of anything
       * round are logs — the section has no silhouette. What does is the WHOLE
       * eel: a long body in a lazy S with a head at one end and a tail at the
       * other, sliced through where the cook has portioned it. */
      drawSmokedEel(ctx, w, p, rng);
      return;
    }
    var strips = clamp(3 + p.portions, 4, 7);
    var dark = R.mix(p.bodyColour, '#4A1E14', 0.45);
    for (var s = 0; s < strips; s++) {
      var t = strips === 1 ? 0.5 : s / (strips - 1);
      var sx = w.cx + (t - 0.5) * L * 1.2; var sy = w.cy + (rng() - 0.5) * w.ry * 0.5;
      var ang = -1.0 + rng() * 0.6;
      var len = L * (0.62 + rng() * 0.28); var wd = L * (0.10 + rng() * 0.05);
      var left = []; var right = [];
      for (var q = 0; q <= 8; q++) {
        var u = q / 8 - 0.5;
        var cxq = u * len; var cyq = Math.sin(u * 3 + s) * wd * 0.8;
        var ww = wd * (0.8 + 0.3 * Math.sin(u * 7 + s * 2)) * (1 - Math.abs(u) * 0.6);
        left.push([cxq + (rng() - 0.5) * wd * 0.2, cyq - ww + (rng() - 0.5) * wd * 0.25]);
        right.push([cxq + (rng() - 0.5) * wd * 0.2, cyq + ww + (rng() - 0.5) * wd * 0.25]);
      }
      var outline = left.concat(right.reverse());
      var sp = place(outline, sx, sy, ang);
      var col = R.shade(dark, (rng() - 0.5) * 0.2);
      solid(ctx, polyPath(sp), boundsOf(sp), col, rng, {
        ao: 0.5, gloss: 0.12, core: 0.45, rim: 0.3, depthK: 0.2,
        detail: function (c) {
          c.save();
          c.translate(sx, sy);
          c.rotate(ang);
          for (var f = -3; f <= 3; f++) {
            c.beginPath();
            c.moveTo(-len * 0.5, f * wd * 0.22);
            c.bezierCurveTo(-len * 0.2, f * wd * 0.22 + wd * 0.2, len * 0.2, f * wd * 0.22 - wd * 0.2, len * 0.5, f * wd * 0.22);
            c.strokeStyle = R.rgba(f % 2 ? R.shade(col, 0.35) : R.shade(col, -0.5), 0.35);
            c.lineWidth = Math.max(0.5, wd * 0.06);
            c.stroke();
          }
          c.restore();
        },
      });
    }
    if (findIng(p, ['salt'], true)) {
      for (var z = 0; z < 22; z++) {
        var zx = w.cx + (rng() - 0.5) * L * 1.5; var zy = w.cy + (rng() - 0.5) * w.ry * 1.2;
        var zs = Math.max(0.6, L * 0.012);
        ctx.fillStyle = R.rgba('#FFFFFF', 0.85);
        ctx.fillRect(zx, zy, zs, zs);
      }
    }
  }

  /* ================================================================= cake === */

  function drawCake(ctx, w, p, rng) {
    var R = deps();
    /* ⛔ An iced cylinder with a ring of almonds round its rim read as a DRUM
     * with a crown of teeth (tavern menu capture, art stage 2026-09-10). The
     * side is SPONGE, golden and baked; the top is a glaze that runs down it;
     * nuts are scattered flakes, never a ring. */
    var sponge = R.mix(p.bodyColour, '#D7A25A', 0.55);
    var icing = R.mix(R.P.cream, p.sauceColour, 0.18);
    var honey = findIng(p, ['honey', 'syrup']);
    if (honey) icing = R.mix('#D8902A', R.P.cream, 0.18);
    var L = Math.min(w.rx * 0.62, w.ry * 1.25);
    var cx = w.cx - L * 0.35; var cy = w.cy - w.ry * 0.28;
    var rx = L; var ry = L * 0.46; var H = L * 0.62;
    R.contactShadow(ctx, cx, cy + H + ry * 0.3, rx * 1.05, ry * 0.9, 0.55);
    var side = function (c) {
      c.moveTo(cx - rx, cy);
      c.lineTo(cx - rx, cy + H);
      c.ellipse(cx, cy + H, rx, ry, 0, Math.PI, 0, true);
      c.lineTo(cx + rx, cy);
      c.ellipse(cx, cy, rx, ry, 0, 0, Math.PI, false);
      c.closePath();
    };
    ctx.beginPath();
    side(ctx);
    var sg = ctx.createLinearGradient(cx - rx, 0, cx + rx, 0);
    sg.addColorStop(0, R.shade(sponge, -0.06));
    sg.addColorStop(0.25, R.shade(sponge, 0.22));
    sg.addColorStop(0.8, R.shade(sponge, -0.38));
    sg.addColorStop(1, R.shade(sponge, -0.22));
    ctx.fillStyle = sg;
    ctx.fill();
    ctx.save();
    ctx.beginPath();
    side(ctx);
    ctx.clip();
    R.stipple(ctx, cx, cy + H * 0.5, rx, H * 0.6, rng, Math.round(rx * 1.6), Math.max(0.5, rx * 0.012), R.shade(sponge, -0.4), '#FFF1CC', 0.35);
    /* the glaze runs over the edge in drips, each with a glossy bead at its tip */
    for (var d = 0; d < 13; d++) {
      var a = 0.12 + (d / 12) * (Math.PI - 0.24);
      var dx = cx + Math.cos(a) * rx; var dy = cy + Math.sin(a) * ry;
      var dl = H * (0.14 + rng() * 0.42);
      var dw = rx * (0.035 + rng() * 0.03);
      ctx.beginPath();
      ctx.moveTo(dx - dw * 1.3, dy - 1);
      ctx.lineTo(dx - dw, dy + dl);
      ctx.arc(dx, dy + dl, dw, Math.PI, 0, true);
      ctx.lineTo(dx + dw * 1.3, dy - 1);
      ctx.closePath();
      ctx.fillStyle = R.shade(icing, -0.08);
      ctx.fill();
      R.glint(ctx, dx - dw * 0.3, dy + dl - dw * 0.2, dw * 0.8, dw * 0.35, Math.PI / 2, 0.6);
    }
    ctx.restore();
    ctx.beginPath();
    ellPath(cx, cy, rx, ry)(ctx);
    R.litFill(ctx, cx, cy, rx, icing, { lift: 0.36, drop: 0.18 });
    R.innerShade(ctx, ellPath(cx, cy, rx, ry), cx - rx, cy - ry, rx * 2, ry * 2, { depth: ry * 0.14, blur: ry * 0.2, darkA: 0.25, light: '#FFFFFF', lightA: 0.35 });
    var nut = findIng(p, ['nut']);
    if (nut) {
      for (var k = 0; k < 18; k++) {
        var na = rng() * TAU; var nr = Math.sqrt(rng()) * 0.78;
        var nx = cx + Math.cos(na) * rx * nr; var ny = cy + Math.sin(na) * ry * nr;
        var fl = rx * (0.06 + rng() * 0.03);
        var np = ellPath(nx, ny, fl, fl * 0.42, rng() * TAU);
        solid(ctx, np, ellBounds(nx, ny, fl, fl * 0.6), rng() > 0.5 ? '#EBD6AC' : '#D9B47A', rng, { ao: 0.25, gloss: 0.25, core: 0.35, rim: 0.25 });
      }
    }
    glints(ctx, cx, cy, rx * 0.8, ry * 0.8, ry * 0.6, 0.8, rng);
    /* the slice, cut and laid in front: it is the slice that shows the layers */
    var sx = w.cx + L * 0.55; var sy = w.cy + w.ry * 0.42;
    var sl = L * 0.95; var sh = H * 0.9;
    var apex = [sx - sl * 0.55, sy - sh * 0.10];
    var back1 = [sx + sl * 0.45, sy - sh * 0.45];
    var back2 = [sx + sl * 0.52, sy + sh * 0.05];
    R.contactShadow(ctx, sx, sy + sh * 0.9, sl * 0.7, sh * 0.35, 0.5);
    var face = [apex, back2, [back2[0], back2[1] + sh], [apex[0], apex[1] + sh]];
    ctx.beginPath();
    polyPath(face)(ctx);
    ctx.fillStyle = sponge;
    ctx.fill();
    var layers = 2 + (p.magnitude > 0.5 ? 1 : 0);
    for (var l = 1; l <= layers; l++) {
      var f = l / (layers + 1);
      ctx.beginPath();
      ctx.moveTo(apex[0], apex[1] + sh * f);
      ctx.lineTo(back2[0], back2[1] + sh * f);
      ctx.strokeStyle = R.rgba(honey ? '#D9982A' : p.sauceColour, 0.9);
      ctx.lineWidth = Math.max(1.5, sh * 0.07);
      ctx.stroke();
    }
    ctx.save();
    ctx.beginPath();
    polyPath(face)(ctx);
    ctx.clip();
    R.stipple(ctx, (apex[0] + back2[0]) / 2, apex[1] + sh * 0.55, sl * 0.6, sh * 0.6, rng, Math.round(sl * 1.2),
      Math.max(0.5, sl * 0.012), R.shade(sponge, -0.4), '#FFF6E0', 0.5);
    ctx.restore();
    var topFace = [apex, back1, back2];
    ctx.beginPath();
    polyPath(topFace)(ctx);
    R.litFill(ctx, sx, sy - sh * 0.2, sl * 0.6, icing, { lift: 0.3, drop: 0.1 });
    ctx.beginPath();
    polyPath(face)(ctx);
    ctx.strokeStyle = R.rgba(R.shade(sponge, -0.45), 0.4);
    ctx.lineWidth = Math.max(0.6, sl * 0.01);
    ctx.stroke();
    if (nut) {
      for (var z = 0; z < 3; z++) {
        var zx = apex[0] + (back1[0] - apex[0]) * (0.35 + z * 0.2); var zy = apex[1] + (back1[1] - apex[1]) * (0.35 + z * 0.2) + sh * 0.05;
        solid(ctx, ellPath(zx, zy, sl * 0.06, sl * 0.03, -0.4), ellBounds(zx, zy, sl * 0.06, sl * 0.04), '#E6CFA2', rng, { ao: 0.2, core: 0.3, rim: 0.2 });
      }
    }
  }

  /* =============================================================== pastry === */

  function drawPastry(ctx, w, p, rng) {
    var R = deps();
    var n = clamp(p.portions, 2, 4);
    var golden = R.mix(p.bodyColour, '#D9A452', 0.6);
    var fruit = null;
    var ings = p.ingredients || [];
    for (var i = 0; i < ings.length; i++) if (pieceKind(ings[i]) === 'fruit') { fruit = ings[i]; break; }
    var fillC = fruit ? R.shade(fruit.colour, -0.1) : R.mix(p.sauceColour, golden, 0.4);
    var L = Math.min(w.rx * (n > 2 ? 0.42 : 0.56), w.ry * 1.1);
    for (var k = n - 1; k >= 0; k--) {
      var t = n === 1 ? 0.5 : k / (n - 1);
      var x = w.cx + (t - 0.5) * w.rx * 1.1; var y = w.cy + (k % 2 ? 0.22 : -0.16) * w.ry;
      var rot = (rng() - 0.5) * 0.6;
      var loc = [[-1.0, 0.30], [-0.9, -0.2], [-0.5, -0.62], [0.1, -0.72], [0.6, -0.5], [0.95, -0.05], [0.9, 0.34], [0, 0.40]];
      for (var q = 0; q < loc.length; q++) { loc[q][0] *= L; loc[q][1] *= L * 0.8; }
      var pts = place(jitter(loc, rng, L * 0.02), x, y, rot);
      solid(ctx, ptsPath(pts), boundsOf(pts), golden, rng, {
        ao: 0.5, gloss: 0.35 + p.gloss * 0.45, char: 0.15 + p.char * 0.3, core: 0.5, rim: 0.35,
        texture: { n: Math.round(L * 0.9), size: Math.max(0.5, L * 0.018), dark: R.shade(golden, -0.35), light: '#FFFFFF', a: 0.45 },
        detail: function (c) {
          c.save();
          c.translate(x, y);
          c.rotate(rot);
          for (var f = 0; f < 7; f++) {
            var fx = -0.84 * L + f * 0.28 * L;
            c.beginPath();
            c.moveTo(fx, 0.34 * L * 0.8);
            c.lineTo(fx + 0.04 * L, 0.20 * L * 0.8);
            c.strokeStyle = R.rgba(R.shade(golden, -0.5), 0.55);
            c.lineWidth = Math.max(0.6, L * 0.025);
            c.stroke();
          }
          c.beginPath();
          c.moveTo(-0.3 * L, -0.30 * L);
          c.quadraticCurveTo(0.05 * L, -0.40 * L, 0.35 * L, -0.26 * L);
          c.strokeStyle = R.rgba(fillC, 0.95);
          c.lineWidth = Math.max(1.4, L * 0.07);
          c.lineCap = 'round';
          c.stroke();
          c.restore();
        },
      });
    }
  }

  /* ============================================================ dumplings === */

  function drawDumplings(ctx, w, p, rng) {
    var R = deps();
    var skin = R.mix(R.P.cream, p.bodyColour, 0.18);
    var seared = p.char > 0.3 || w.deep === undefined;
    var n = clamp(3 + p.portions, 4, 8);
    var s = Math.min(w.rx * (n > 5 ? 0.24 : 0.30), w.ry * 0.62);
    var pts = R.scatter(rng, n, { rMin: 0.0, rMax: 0.72, sep: 0.38, tries: 40 });
    pts.sort(function (a, b) { return a.y - b.y; });
    for (var i = 0; i < pts.length; i++) {
      var x = w.cx + pts[i].x * w.rx * 0.9; var y = w.cy + pts[i].y * w.ry;
      var rot = (rng() - 0.5) * 0.9;
      var loc = [[-1.0, 0.25], [-0.8, -0.2], [-0.4, -0.52], [0.0, -0.62], [0.4, -0.52], [0.8, -0.2], [1.0, 0.25], [0.4, 0.42], [-0.4, 0.42]];
      for (var q = 0; q < loc.length; q++) { loc[q][0] *= s; loc[q][1] *= s * 0.85; }
      var dp = place(loc, x, y, rot);
      solid(ctx, ptsPath(dp), boundsOf(dp), skin, rng, {
        ao: 0.45, gloss: 0.55 + p.gloss * 0.3, core: 0.40, rim: 0.40,
        detail: function (c, cx, cy, hrx, hry) {
          R.puff(c, cx, cy + hry * 0.1, hrx * 0.6, p.bodyColour, 0.22);
          if (seared) {
            var g = c.createLinearGradient(0, cy, 0, cy + hry);
            g.addColorStop(0, R.rgba('#B8702E', 0));
            g.addColorStop(1, R.rgba('#8A4A1C', 0.8));
            c.fillStyle = g;
            c.fillRect(cx - hrx, cy, hrx * 2, hry + 1);
          }
          c.save();
          c.translate(x, y);
          c.rotate(rot);
          for (var f = 0; f < 6; f++) {
            var fx = (-0.55 + f * 0.22) * s;
            c.beginPath();
            c.moveTo(fx, -0.52 * s * 0.85);
            c.quadraticCurveTo(fx + 0.12 * s, -0.25 * s * 0.85, fx + 0.04 * s, -0.05 * s * 0.85);
            c.strokeStyle = R.rgba(R.shade(skin, -0.35), 0.55);
            c.lineWidth = Math.max(0.6, s * 0.04);
            c.stroke();
            c.beginPath();
            c.moveTo(fx + 0.05 * s, -0.52 * s * 0.85);
            c.quadraticCurveTo(fx + 0.17 * s, -0.25 * s * 0.85, fx + 0.09 * s, -0.05 * s * 0.85);
            c.strokeStyle = R.rgba('#FFFFFF', 0.4);
            c.lineWidth = Math.max(0.5, s * 0.025);
            c.stroke();
          }
          c.restore();
        },
      });
    }
  }

  /* ============================================================== noodles === */

  function drawNoodles(ctx, w, p, rng) {
    var R = deps();
    var broth = R.mix(p.sauceColour, '#C28A44', 0.4);
    liquidSurface(ctx, w, p, rng, { colour: broth, gloss: 0.5, eyes: 6 });
    var s = w.surface || w;
    var noodle = R.mix(p.bodyColour, '#EBD493', 0.5);
    var strands = 14 + p.portions * 3;
    ctx.save();
    ctx.beginPath();
    ellPath(s.cx, s.cy, s.rx * 0.96, s.ry * 0.96)(ctx);
    ctx.clip();
    ctx.lineCap = 'round';
    for (var i = 0; i < strands; i++) {
      var ph = rng() * TAU; var r0 = 0.15 + rng() * 0.55;
      var pts = [];
      for (var t = 0; t <= 16; t++) {
        var a = ph + t * 0.34;
        var rr = r0 + Math.sin(t * 0.7 + i) * 0.14;
        pts.push([s.cx + Math.cos(a) * s.rx * rr, s.cy + Math.sin(a) * s.ry * rr]);
      }
      var lw = Math.max(1.4, s.rx * 0.042);
      var passes = [[R.shade(noodle, -0.45), lw * 1.3, 0, 0], [noodle, lw, 0, 0], [R.rgba('#FFFFFF', 0.45), lw * 0.3, -lw * 0.2, -lw * 0.25]];
      for (var pI = 0; pI < passes.length; pI++) {
        ctx.beginPath();
        ctx.moveTo(pts[0][0] + passes[pI][2], pts[0][1] + passes[pI][3]);
        for (var k = 1; k < pts.length - 1; k++) {
          ctx.quadraticCurveTo(pts[k][0] + passes[pI][2], pts[k][1] + passes[pI][3],
            (pts[k][0] + pts[k + 1][0]) / 2 + passes[pI][2], (pts[k][1] + pts[k + 1][1]) / 2 + passes[pI][3]);
        }
        ctx.strokeStyle = passes[pI][0];
        ctx.lineWidth = passes[pI][1];
        ctx.stroke();
      }
    }
    ctx.restore();
    var chive = findIng(p, ['chive', 'leek', 'parsley'], true);
    if (chive) {
      for (var c = 0; c < 12; c++) {
        var cx = s.cx + (rng() - 0.5) * s.rx * 1.2; var cy = s.cy + (rng() - 0.5) * s.ry * 1.0;
        var r = s.rx * 0.030;
        ctx.beginPath();
        ellPath(cx, cy, r, r * 0.7)(ctx);
        ctx.strokeStyle = R.rgba('#5A8A36', 0.95);
        ctx.lineWidth = Math.max(0.8, r * 0.5);
        ctx.stroke();
      }
    }
  }

  /* ================================================================= eggs === */

  function drawEggs(ctx, w, p, rng) {
    var R = deps();
    var scramble = nameHas(p, ['scramble', 'scrambled', 'omelette', 'omelet', 'frittata']);
    var yolkC = R.mix('#EBA42A', p.bodyColour, 0.2);
    if (scramble) {
      var n = clamp(10 + p.portions * 4, 12, 30);
      var curd = R.mix('#F2D36B', p.bodyColour, 0.3);
      var pts = R.scatter(rng, n, { rMin: 0.0, rMax: 0.78, sep: 0.16, tries: 40 });
      pts.sort(function (a, b) { return a.y - b.y; });
      var s = Math.min(w.rx * 0.18, w.ry * 0.4);
      for (var i = 0; i < pts.length; i++) {
        var x = w.cx + pts[i].x * w.rx * 0.85; var y = w.cy + pts[i].y * w.ry * 0.95 - (1 - Math.abs(pts[i].x)) * w.ry * 0.12;
        mass(ctx, x, y, s * pts[i].s, s * 0.72 * pts[i].s, R.shade(curd, (rng() - 0.5) * 0.18), rng,
          { wobble: 0.28, lobes: 8, gloss: 0.45, core: 0.35, rim: 0.3, ao: 0.3 });
      }
      return;
    }
    var bacon = findIng(p, ['bacon']);
    if (bacon) {
      for (var b = 0; b < 2; b++) {
        var by = w.cy + w.ry * (0.35 + b * 0.18); var bx0 = w.cx - w.rx * 0.8; var bx1 = w.cx + w.rx * 0.5;
        var top = []; var bot = [];
        for (var q = 0; q <= 10; q++) {
          var t = q / 10;
          var xx = bx0 + (bx1 - bx0) * t; var yy = by + Math.sin(t * 9 + b) * w.ry * 0.07 - t * w.ry * 0.25;
          top.push([xx, yy - w.ry * 0.09]);
          bot.push([xx, yy + w.ry * 0.09]);
        }
        var strip = top.concat(bot.reverse());
        solid(ctx, polyPath(strip), boundsOf(strip), R.mix(bacon.colour, '#8E3226', 0.35), rng, {
          ao: 0.4, gloss: 0.5, char: 0.3 + p.char * 0.5, core: 0.4, rim: 0.3,
          detail: function (c) {
            c.beginPath();
            for (var z = 0; z <= 10; z++) {
              var tz = z / 10;
              var zx = bx0 + (bx1 - bx0) * tz; var zy = by + Math.sin(tz * 9 + b) * w.ry * 0.07 - tz * w.ry * 0.25;
              if (z === 0) c.moveTo(zx, zy); else c.lineTo(zx, zy);
            }
            c.strokeStyle = R.rgba('#F0D9BE', 0.8);
            c.lineWidth = Math.max(1, w.ry * 0.05);
            c.stroke();
          },
        });
      }
    }
    var ne = clamp(p.portions, 1, 3);
    var er = Math.min(w.rx * (ne > 1 ? 0.36 : 0.46), w.ry * 0.9);
    for (var e = 0; e < ne; e++) {
      var ex = w.cx + (e - (ne - 1) / 2) * er * 1.2; var ey = w.cy - w.ry * (bacon ? 0.18 : 0) + (e % 2 ? 0.1 : -0.05) * w.ry;
      var white = R.blobPts(ex, ey, er, er * 0.66, rng, 0.20, 12, rng());
      var wb = boundsOf(white);
      R.contactShadow(ctx, ex, ey + er * 0.2, er * 1.02, er * 0.6, 0.25);
      ctx.beginPath();
      R.smoothPath(ctx, white);
      R.litFill(ctx, ex, ey, er, '#F8F3E8', { lift: 0.1, drop: 0.12 });
      if (p.char > 0.25) {
        ctx.save();
        ctx.beginPath();
        R.smoothPath(ctx, white);
        ctx.clip();
        R.innerShade(ctx, ptsPath(white), wb.x, wb.y, wb.w, wb.h, { depth: er * 0.10, blur: er * 0.14, dark: '#9A5A20', darkA: 0.7, lightA: 0 });
        ctx.restore();
        ctx.beginPath();
        R.smoothPath(ctx, white);
        ctx.strokeStyle = R.rgba('#8A4A18', 0.65);
        ctx.lineWidth = Math.max(0.8, er * 0.03);
        ctx.stroke();
      }
      var yx = ex + er * 0.06; var yy2 = ey - er * 0.02;
      R.contactShadow(ctx, yx, yy2 + er * 0.08, er * 0.36, er * 0.2, 0.3);
      var yp = ellPath(yx, yy2 - er * 0.04, er * 0.30, er * 0.25);
      solid(ctx, yp, ellBounds(yx, yy2 - er * 0.04, er * 0.3, er * 0.25), yolkC, rng, { ao: 0, gloss: 0.9, core: 0.45, rim: 0.3, depthK: 0.35 });
    }
  }

  /* ========================================================== cheeseboard === */

  function drawCheeseboard(ctx, w, p, rng) {
    var R = deps();
    var items = [];
    var ings = p.ingredients || [];
    for (var i = 0; i < ings.length; i++) {
      var h = String(ings[i].head || '').toLowerCase();
      var k = pieceKind(ings[i]);
      if (h === 'cheese') items.push({ t: 'wedge', ing: ings[i] });
      else if (h === 'curd' || h === 'cream' || h === 'butter') items.push({ t: 'round', ing: ings[i] });
      else if (h === 'fig') items.push({ t: 'fig', ing: ings[i] });
      else if (h === 'bread' || h === 'loaf') items.push({ t: 'bread', ing: ings[i] });
      else if (h === 'grape' || h === 'berry' || h === 'currant') items.push({ t: 'grapes', ing: ings[i] });
      else if (k === 'fruit') items.push({ t: 'fig', ing: ings[i] });
    }
    if (!items.length) items.push({ t: 'wedge', ing: { colour: p.bodyColour } });
    if (items.length === 1) items.push({ t: items[0].t === 'wedge' ? 'round' : 'wedge', ing: items[0].ing });
    var slots = [[-0.45, -0.22], [0.40, -0.28], [-0.05, 0.30], [0.62, 0.30], [-0.70, 0.30]];
    var S = Math.min(w.rx * 0.48, w.ry * 1.0);
    for (var j = 0; j < items.length && j < slots.length; j++) {
      var x = w.cx + slots[j][0] * w.rx; var y = w.cy + slots[j][1] * w.ry;
      var it = items[j];
      if (it.t === 'wedge') cheeseWedge(ctx, x, y, S, R.mix(it.ing.colour, '#E8C45A', 0.35), rng);
      else if (it.t === 'round') softRound(ctx, x, y, S * 0.8, R.mix(it.ing.colour, '#F4EEDF', 0.5), rng);
      else if (it.t === 'fig') { figHalf(ctx, x - S * 0.25, y, S * 0.36, rng); figHalf(ctx, x + S * 0.22, y + S * 0.1, S * 0.32, rng); }
      else if (it.t === 'bread') { for (var b = 0; b < 3; b++) breadSlice(ctx, x + b * S * 0.22, y - b * S * 0.08, S * 0.46, rng); }
      else grapes(ctx, x, y, S * 0.5, R.mix(it.ing.colour, '#5D3E62', 0.3), rng);
    }
  }

  function cheeseWedge(ctx, x, y, S, paste, rng) {
    var R = deps();
    var h = S * 0.36;
    var apex = [x + S * 0.62, y + S * 0.10]; var b1 = [x - S * 0.55, y - S * 0.30]; var b2 = [x - S * 0.62, y + S * 0.18];
    R.contactShadow(ctx, x, y + h + S * 0.08, S * 0.7, S * 0.3, 0.5);
    var front = [b2, apex, [apex[0], apex[1] + h], [b2[0], b2[1] + h]];
    ctx.beginPath();
    polyPath(front)(ctx);
    ctx.fillStyle = R.shade(paste, -0.12);
    ctx.fill();
    var rind = [b1, b2, [b2[0], b2[1] + h], [b1[0], b1[1] + h]];
    ctx.beginPath();
    polyPath(rind)(ctx);
    ctx.fillStyle = R.shade(paste, -0.45);
    ctx.fill();
    var top = [apex, b1, b2];
    ctx.beginPath();
    polyPath(top)(ctx);
    R.litFill(ctx, x, y, S * 0.6, paste, { lift: 0.3, drop: 0.2 });
    ctx.save();
    ctx.beginPath();
    polyPath(front)(ctx);
    polyPath(top)(ctx);
    ctx.clip();
    for (var e = 0; e < 6; e++) {
      var ex = x + (rng() - 0.3) * S * 0.9; var ey = y + (rng() - 0.3) * (S * 0.3 + h);
      var er = S * (0.025 + rng() * 0.04);
      var ep = ellPath(ex, ey, er, er * 0.75);
      ctx.beginPath();
      ep(ctx);
      ctx.fillStyle = R.shade(paste, -0.28);
      ctx.fill();
      R.innerShade(ctx, ep, ex - er, ey - er, er * 2, er * 2, { invert: true, depth: er * 0.4, blur: er * 0.4, darkA: 0.5, lightA: 0 });
    }
    ctx.restore();
    ctx.beginPath();
    ctx.moveTo(apex[0], apex[1]);
    ctx.lineTo(b1[0], b1[1]);
    ctx.strokeStyle = R.rgba('#FFFFFF', 0.45);
    ctx.lineWidth = Math.max(0.6, S * 0.012);
    ctx.stroke();
  }

  function softRound(ctx, x, y, S, rind, rng) {
    var R = deps();
    var rx = S; var ry = S * 0.52; var h = S * 0.28;
    R.contactShadow(ctx, x, y + h + ry * 0.2, rx, ry * 0.8, 0.45);
    ctx.beginPath();
    ellPath(x, y + h, rx, ry)(ctx);
    ctx.fillStyle = R.shade(rind, -0.2);
    ctx.fill();
    ctx.fillRect(x - rx, y, rx * 2, h);
    ctx.beginPath();
    ellPath(x, y, rx, ry)(ctx);
    R.litFill(ctx, x, y, rx, rind, { lift: 0.3, drop: 0.15 });
    R.stipple(ctx, x, y, rx * 0.9, ry * 0.9, rng, Math.round(S * 1.2), Math.max(0.5, S * 0.02), R.shade(rind, -0.18), '#FFFFFF', 0.4);
    var cut = [[x, y], [x + rx * 0.95, y + ry * 0.25], [x + rx * 0.6, y + ry * 0.82]];
    ctx.beginPath();
    polyPath(cut)(ctx);
    ctx.fillStyle = '#F6E9C4';
    ctx.fill();
    var side = [cut[1], cut[2], [cut[2][0], cut[2][1] + h], [cut[1][0], cut[1][1] + h]];
    ctx.beginPath();
    polyPath(side)(ctx);
    ctx.fillStyle = '#EFDDAE';
    ctx.fill();
    R.glint(ctx, x + rx * 0.45, y + ry * 0.45, rx * 0.16, ry * 0.05, 0.5, 0.5);
  }

  function figHalf(ctx, x, y, r, rng) {
    var R = deps();
    var fp = ellPath(x, y, r, r * 0.72, -0.3);
    solid(ctx, fp, ellBounds(x, y, r, r * 0.72), '#5B2E48', rng, { ao: 0.45, gloss: 0.4, core: 0.4, rim: 0.2 });
    var ip = ellPath(x, y, r * 0.82, r * 0.58, -0.3);
    ctx.beginPath();
    ip(ctx);
    R.litFill(ctx, x, y, r * 0.82, '#C8505A', { lift: 0.3, drop: 0.3 });
    ctx.save();
    ctx.beginPath();
    ip(ctx);
    ctx.clip();
    for (var i = 0; i < 26; i++) {
      var a = rng() * TAU; var rr = 0.2 + rng() * 0.6;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + Math.cos(a) * r * rr, y + Math.sin(a) * r * 0.6 * rr);
      ctx.strokeStyle = R.rgba('#F2D6A8', 0.35);
      ctx.lineWidth = Math.max(0.4, r * 0.03);
      ctx.stroke();
    }
    ctx.restore();
    ctx.beginPath();
    ellPath(x, y, r * 0.5, r * 0.34, -0.3)(ctx);
    ctx.strokeStyle = R.rgba('#F3E2C4', 0.7);
    ctx.lineWidth = Math.max(0.6, r * 0.06);
    ctx.stroke();
  }

  function breadSlice(ctx, x, y, s, rng) {
    var R = deps();
    var pts = R.blobPts(x, y, s, s * 0.62, rng, 0.05, 9, -0.2);
    R.contactShadow(ctx, x, y + s * 0.2, s, s * 0.5, 0.4);
    ctx.beginPath();
    R.smoothPath(ctx, pts);
    ctx.fillStyle = '#8E5A2A';
    ctx.fill();
    var inPts = [];
    for (var i = 0; i < pts.length; i++) inPts.push([x + (pts[i][0] - x) * 0.86, y + (pts[i][1] - y) * 0.82]);
    solid(ctx, ptsPath(inPts), boundsOf(inPts), '#E4CC9C', rng, {
      ao: 0, gloss: 0, core: 0.2, rim: 0.3,
      texture: { n: Math.round(s * 1.4), size: Math.max(0.5, s * 0.03), dark: '#A6824E', light: '#FFF6E2', a: 0.55 },
    });
  }

  function grapes(ctx, x, y, s, col, rng) {
    var R = deps();
    var pts = R.scatter(rng, 11, { rMin: 0, rMax: 0.9, sep: 0.34, tries: 30 });
    pts.sort(function (a, b) { return a.y - b.y; });
    R.contactShadow(ctx, x, y + s * 0.3, s * 1.1, s * 0.6, 0.45);
    for (var i = 0; i < pts.length; i++) {
      var gx = x + pts[i].x * s; var gy = y + pts[i].y * s * 0.8;
      var gp = ellPath(gx, gy, s * 0.22, s * 0.20);
      solid(ctx, gp, ellBounds(gx, gy, s * 0.22, s * 0.2), R.shade(col, (rng() - 0.5) * 0.2), rng, { ao: 0.2, gloss: 0.6, core: 0.45, rim: 0.2 });
    }
  }

  /* ================================================================ fruit === */

  function drawFruit(ctx, w, p, rng) {
    var R = deps();
    var fruits = [];
    var ings = p.ingredients || [];
    for (var i = 0; i < ings.length; i++) if (pieceKind(ings[i]) === 'fruit') fruits.push(ings[i]);
    if (!fruits.length) fruits.push({ colour: p.bodyColour, head: 'apple' });
    var n = clamp(3 + p.portions, 4, 8);
    var pts = R.scatter(rng, n, { rMin: 0.0, rMax: 0.70, sep: 0.44, tries: 40 });
    pts.sort(function (a, b) { return a.y - b.y; });
    var s = Math.min(w.rx * 0.30, w.ry * 0.66);
    for (var j = 0; j < pts.length; j++) {
      var f = fruits[j % fruits.length];
      var head = String(f.head || '').toLowerCase();
      var x = w.cx + pts[j].x * w.rx * 0.85; var y = w.cy + pts[j].y * w.ry - s * 0.15;
      var sz = s * (0.8 + pts[j].s * 0.25);
      if (head === 'grape' || head === 'berry' || head === 'currant') { grapes(ctx, x, y, sz * 0.9, f.colour, rng); continue; }
      if (head === 'cherry') {
        for (var c = -1; c <= 1; c += 2) {
          var cx = x + c * sz * 0.25; var cy = y + sz * 0.1;
          solid(ctx, ellPath(cx, cy, sz * 0.26, sz * 0.24), ellBounds(cx, cy, sz * 0.26, sz * 0.24), f.colour, rng, { ao: 0.35, gloss: 0.9, core: 0.5, rim: 0.2 });
        }
        ctx.beginPath();
        ctx.moveTo(x - sz * 0.25, y - sz * 0.1);
        ctx.quadraticCurveTo(x, y - sz * 0.9, x + sz * 0.1, y - sz * 0.95);
        ctx.moveTo(x + sz * 0.25, y - sz * 0.1);
        ctx.quadraticCurveTo(x + sz * 0.15, y - sz * 0.7, x + sz * 0.1, y - sz * 0.95);
        ctx.strokeStyle = '#4E5A2A';
        ctx.lineWidth = Math.max(0.8, sz * 0.04);
        ctx.stroke();
        continue;
      }
      var pear = head === 'pear' || head === 'quince';
      var citrus = head === 'lemon' || head === 'orange';
      var loc = pear ? [[0, -1.0], [0.28, -0.8], [0.35, -0.35], [0.72, 0.15], [0.66, 0.6], [0, 0.82], [-0.66, 0.6], [-0.72, 0.15], [-0.35, -0.35], [-0.28, -0.8]]
        : [[0, -0.78], [0.55, -0.72], [0.9, -0.2], [0.82, 0.45], [0.35, 0.8], [-0.35, 0.8], [-0.82, 0.45], [-0.9, -0.2], [-0.55, -0.72]];
      for (var q = 0; q < loc.length; q++) { loc[q][0] *= sz * 0.62; loc[q][1] *= sz * 0.62; }
      var fp = place(jitter(loc, rng, sz * 0.02), x, y, (rng() - 0.5) * 0.5);
      var fcol = f.colour;
      solid(ctx, ptsPath(fp), boundsOf(fp), fcol, rng, {
        ao: 0.45, gloss: citrus ? 0.4 : 0.85, core: 0.5, rim: 0.25,
        texture: citrus ? { n: Math.round(sz * 1.2), size: Math.max(0.4, sz * 0.02), a: 0.4 } : null,
        detail: head === 'apple' ? function (c, cx2, cy2, hrx, hry) {
          for (var st = 0; st < 8; st++) {
            c.beginPath();
            c.moveTo(cx2 + (st - 4) * hrx * 0.2, cy2 - hry);
            c.quadraticCurveTo(cx2 + (st - 4) * hrx * 0.26, cy2, cx2 + (st - 4) * hrx * 0.2, cy2 + hry);
            c.strokeStyle = R.rgba(st % 2 ? '#E8C05A' : '#6E1818', 0.20);
            c.lineWidth = Math.max(0.6, hrx * 0.08);
            c.stroke();
          }
        } : null,
      });
      var top = [x, y - sz * (pear ? 0.62 : 0.44)];
      ctx.beginPath();
      ctx.moveTo(top[0], top[1] + sz * 0.05);
      ctx.quadraticCurveTo(top[0] + sz * 0.06, top[1] - sz * 0.15, top[0] + sz * 0.12, top[1] - sz * 0.22);
      ctx.strokeStyle = '#4A3520';
      ctx.lineWidth = Math.max(0.8, sz * 0.05);
      ctx.stroke();
      if (j % 3 === 0 && !citrus) {
        var lf = [[0, 0], [0.4, -0.25], [0.8, -0.05], [0.4, 0.12]];
        for (var z = 0; z < lf.length; z++) { lf[z][0] *= sz; lf[z][1] *= sz; }
        var lp = place(lf, top[0] + sz * 0.08, top[1] - sz * 0.12, -0.5);
        solid(ctx, ptsPath(lp), boundsOf(lp), '#4E7A34', rng, { ao: 0.2, gloss: 0.4, core: 0.35, rim: 0.3 });
      }
    }
  }

  /* ============================================================ preserves === */

  function drawPreserves(ctx, w, p, rng) {
    var R = deps();
    var jam = R.shade(R.mix(p.bodyColour, '#7A1E30', 0.45), -0.1);
    if (w.surface) {
      liquidSurface(ctx, w, p, rng, { colour: jam, gloss: 0.9 });
      piecesOf(ctx, w, p, rng, { count: 1.2, size: w.rx * 0.10, submerge: 0.55, liquid: jam, rMax: 0.7, sep: 0.26 });
      var s = w.surface;
      var x0 = s.cx - s.rx * 0.15; var y0 = s.cy + s.ry * 0.1;
      var x1 = s.cx + s.rx * 1.35; var y1 = s.cy - s.ry * 1.6;
      ctx.save();
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.lineTo(x1, y1);
      ctx.strokeStyle = '#8A6238';
      ctx.lineWidth = Math.max(2, s.rx * 0.10);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x0 - 1, y0 - 1.5);
      ctx.lineTo(x1 - 1, y1 - 1.5);
      ctx.strokeStyle = R.rgba('#E6C898', 0.55);
      ctx.lineWidth = Math.max(0.8, s.rx * 0.03);
      ctx.stroke();
      ctx.restore();
      ctx.beginPath();
      ellPath(x0, y0, s.rx * 0.10, s.ry * 0.08)(ctx);
      ctx.fillStyle = R.rgba(jam, 0.9);
      ctx.fill();
      return;
    }
    /* ⛔ An opaque berry-coloured cylinder under a gingham cap, on a gingham
     * cloth, read as a TIN (product size, art stage 2026-09-10). A preserve
     * reads as preserve through the GLASS: the jam's own dark body with the
     * fruit pressed against the jar, a band of empty glass above it, a linen
     * cover tied with twine, a label, and a spoon beside it with a dollop. */
    var jr = Math.min(w.rx * 0.50, w.ry * 1.15); var jh = jr * 1.30;
    var jx = w.cx - jr * 0.25; var jy = w.cy - jh * 0.62;
    var ery = jr * 0.36;
    R.contactShadow(ctx, jx, jy + jh + ery * 0.4, jr * 1.15, ery * 1.1, 0.55);
    /* the spoon first, lying beside the jar on the vessel */
    var sx0 = jx + jr * 0.85; var sy0 = jy + jh + ery * 0.55;
    var sx1 = jx + jr * 2.15; var sy1 = jy + jh - ery * 0.40;
    ctx.save();
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(sx0 + jr * 0.30, sy0 - ery * 0.15);
    ctx.lineTo(sx1, sy1);
    ctx.strokeStyle = '#7A5230';
    ctx.lineWidth = Math.max(1.5, jr * 0.10);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(sx0 + jr * 0.30, sy0 - ery * 0.15 - 1);
    ctx.lineTo(sx1, sy1 - 1);
    ctx.strokeStyle = R.rgba('#D8B48A', 0.55);
    ctx.lineWidth = Math.max(0.6, jr * 0.035);
    ctx.stroke();
    ctx.restore();
    var bowl = ellPath(sx0, sy0, jr * 0.34, jr * 0.22, -0.35);
    R.contactShadow(ctx, sx0, sy0 + jr * 0.08, jr * 0.36, jr * 0.16, 0.45);
    ctx.beginPath();
    bowl(ctx);
    R.litFill(ctx, sx0, sy0, jr * 0.34, '#8C5E36', { lift: 0.35, drop: 0.35 });
    var dp = R.blobPts(sx0 - jr * 0.02, sy0 - jr * 0.03, jr * 0.24, jr * 0.14, rng, 0.18, 8, -0.35);
    ctx.beginPath();
    R.smoothPath(ctx, dp);
    R.litFill(ctx, sx0, sy0, jr * 0.24, jam, { lift: 0.45, drop: 0.35 });
    R.glint(ctx, sx0 - jr * 0.08, sy0 - jr * 0.07, jr * 0.10, jr * 0.03, -0.4, 0.9);
    /* the jar: a glass cylinder */
    var body = function (c) {
      c.moveTo(jx - jr, jy);
      c.lineTo(jx - jr, jy + jh);
      c.ellipse(jx, jy + jh, jr, ery, 0, Math.PI, 0, true);
      c.lineTo(jx + jr, jy);
      c.ellipse(jx, jy, jr, ery, 0, 0, Math.PI, false);
      c.closePath();
    };
    var fillTop = jy + jh * 0.20;
    ctx.save();
    ctx.beginPath();
    body(ctx);
    ctx.clip();
    /* the empty glass above the jam shows the cloth through it */
    var eg = ctx.createLinearGradient(jx - jr, 0, jx + jr, 0);
    eg.addColorStop(0, R.rgba('#DDE6E2', 0.55));
    eg.addColorStop(0.5, R.rgba('#F4F7F2', 0.25));
    eg.addColorStop(1, R.rgba('#9AA8A4', 0.55));
    ctx.fillStyle = eg;
    ctx.fillRect(jx - jr - 2, jy - ery - 2, jr * 2 + 4, fillTop - jy + ery + 4);
    /* the jam, deep at the edges where the glass is thickest */
    var jg = ctx.createLinearGradient(jx - jr, 0, jx + jr, 0);
    jg.addColorStop(0, R.shade(jam, -0.30));
    jg.addColorStop(0.28, R.shade(jam, 0.18));
    jg.addColorStop(0.62, jam);
    jg.addColorStop(1, R.shade(jam, -0.55));
    ctx.fillStyle = jg;
    ctx.fillRect(jx - jr - 2, fillTop, jr * 2 + 4, jh + ery + 4);
    ctx.beginPath();
    ctx.ellipse(jx, fillTop, jr, ery, 0, 0, TAU);
    ctx.fillStyle = R.shade(jam, -0.12);
    ctx.fill();
    /* the fruit pressed against the glass, and its seeds */
    var fruit = null;
    var ings = p.ingredients || [];
    for (var fi = 0; fi < ings.length; fi++) if (pieceKind(ings[fi]) === 'fruit') { fruit = ings[fi]; break; }
    var berry = fruit ? R.mix(fruit.colour, jam, 0.35) : R.shade(jam, -0.25);
    for (var b = 0; b < 16; b++) {
      var bx = jx + (rng() - 0.5) * jr * 1.7;
      var by = fillTop + ery * 0.6 + rng() * (jh - ery * 0.2);
      var br = jr * (0.08 + rng() * 0.07);
      ctx.beginPath();
      ellPath(bx, by, br, br * 0.9)(ctx);
      R.litFill(ctx, bx, by, br, berry, { lift: 0.30, drop: 0.45 });
      R.glint(ctx, bx - br * 0.35, by - br * 0.35, br * 0.35, br * 0.15, -0.5, 0.5);
    }
    for (var sd = 0; sd < 30; sd++) {
      ctx.fillStyle = R.rgba('#F2D08A', 0.55);
      ctx.fillRect(jx + (rng() - 0.5) * jr * 1.8, fillTop + ery + rng() * jh * 0.9, Math.max(0.6, jr * 0.02), Math.max(0.6, jr * 0.02));
    }
    ctx.restore();
    /* the glass itself: its edges, a window of light down the left, a thin one on the right */
    ctx.beginPath();
    body(ctx);
    ctx.strokeStyle = R.rgba('#E8F0EC', 0.55);
    ctx.lineWidth = Math.max(1, jr * 0.04);
    ctx.stroke();
    R.glint(ctx, jx - jr * 0.62, jy + jh * 0.55, jh * 0.46, jr * 0.09, Math.PI / 2, 0.85);
    R.glint(ctx, jx + jr * 0.70, jy + jh * 0.60, jh * 0.26, jr * 0.04, Math.PI / 2, 0.45);
    ctx.beginPath();
    ctx.ellipse(jx, jy + jh, jr * 0.98, ery * 0.95, 0, 0.1, Math.PI - 0.1);
    ctx.strokeStyle = R.rgba('#FFFFFF', 0.30);
    ctx.lineWidth = Math.max(1, jr * 0.05);
    ctx.stroke();
    /* a paper label with the cook's two lines of hand */
    var lw2 = jr * 0.92; var lh = jh * 0.34; var lx = jx - lw2 / 2 + jr * 0.08; var ly = jy + jh * 0.46;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(lx, ly);
    ctx.quadraticCurveTo(lx + lw2 / 2, ly + ery * 0.30, lx + lw2, ly);
    ctx.lineTo(lx + lw2, ly + lh);
    ctx.quadraticCurveTo(lx + lw2 / 2, ly + lh + ery * 0.30, lx, ly + lh);
    ctx.closePath();
    R.litFill(ctx, lx + lw2 / 2, ly + lh / 2, lw2 * 0.6, '#EFE4CC', { lift: 0.15, drop: 0.30 });
    ctx.strokeStyle = R.rgba('#8C3B22', 0.55);
    ctx.lineWidth = Math.max(0.6, jr * 0.02);
    ctx.stroke();
    for (var ln = 0; ln < 2; ln++) {
      var yy = ly + lh * (0.40 + ln * 0.30) + ery * 0.14;
      ctx.beginPath();
      ctx.moveTo(lx + lw2 * 0.16, yy);
      for (var st = 1; st <= 8; st++) {
        ctx.lineTo(lx + lw2 * (0.16 + st * (ln ? 0.06 : 0.085)), yy + Math.sin(st * 1.9 + ln) * lh * 0.05);
      }
      ctx.strokeStyle = R.rgba('#3A2618', 0.60);
      ctx.lineWidth = Math.max(0.6, jr * 0.025);
      ctx.stroke();
    }
    ctx.restore();
    /* the cover: plain linen drawn over the rim, hanging in folds, tied */
    var linen = '#EADFC8';
    var cp = [];
    for (var k = 0; k <= 16; k++) {
      var a = Math.PI + (k / 16) * Math.PI;
      cp.push([jx + Math.cos(a) * jr * 1.24, jy + Math.sin(a) * ery * 1.45 - ery * 0.10]);
    }
    for (var k2 = 0; k2 <= 12; k2++) {
      var t2 = k2 / 12;
      var hx = jx + jr * 1.24 - t2 * jr * 2.48;
      var hang = jh * (0.20 + 0.06 * Math.sin(t2 * Math.PI * 5 + 0.5)) + ery * Math.sin(t2 * Math.PI) * 0.6;
      cp.push([hx, jy + hang]);
    }
    solid(ctx, ptsPath(cp), boundsOf(cp), linen, rng, {
      ao: 0.25, gloss: 0, core: 0.30, rim: 0.30, lift: 0.30,
      texture: { n: 40, size: Math.max(0.5, jr * 0.02), dark: '#B8A888', light: '#FFFFFF', a: 0.35 },
      detail: function (c) {
        /* the folds fall from the tie */
        for (var fd = 0; fd < 6; fd++) {
          var fxx = jx - jr * 1.0 + fd * jr * 0.40;
          c.beginPath();
          c.moveTo(fxx, jy + jh * 0.08);
          c.quadraticCurveTo(fxx + jr * 0.05, jy + jh * 0.16, fxx - jr * 0.02, jy + jh * 0.26);
          c.strokeStyle = R.rgba('#9A8A6A', 0.45);
          c.lineWidth = Math.max(0.6, jr * 0.03);
          c.stroke();
        }
      },
    });
    ctx.beginPath();
    ctx.ellipse(jx, jy + jh * 0.09, jr * 1.04, ery * 1.02, 0, 0.12, Math.PI - 0.12);
    ctx.strokeStyle = '#8C3B22';
    ctx.lineWidth = Math.max(1.2, jr * 0.055);
    ctx.stroke();
    var knot = [jx + jr * 0.55, jy + jh * 0.09 + ery * 0.86];
    ctx.beginPath();
    ctx.moveTo(knot[0], knot[1]);
    ctx.quadraticCurveTo(knot[0] + jr * 0.18, knot[1] + jh * 0.10, knot[0] + jr * 0.10, knot[1] + jh * 0.20);
    ctx.moveTo(knot[0], knot[1]);
    ctx.quadraticCurveTo(knot[0] + jr * 0.30, knot[1] + jh * 0.04, knot[0] + jr * 0.36, knot[1] + jh * 0.14);
    ctx.strokeStyle = '#8C3B22';
    ctx.lineWidth = Math.max(1, jr * 0.045);
    ctx.lineCap = 'round';
    ctx.stroke();
  }

  /* ================================================================ drink === */

  function drawDrink(ctx, w, p, rng) {
    var R = deps();
    var foam = !!findIng(p, ['ale']) || nameHas(p, ['ale', 'beer', 'stout']);
    var arcane = ax(p, 'arcane') > 0.15;
    var liquid = R.shade(p.bodyColour, -0.18);
    liquidSurface(ctx, w, p, rng, {
      colour: liquid, gloss: 0.8, alpha: 0.95,
      detail: function (c, s) {
        if (foam) {
          /* ⛔ Foam to the very rim read as a cup of MILK (art stage,
           * 2026-09-10): the head sits inside a ring of the ale itself. */
          var fp = R.blobPts(s.cx - s.rx * 0.03, s.cy - s.ry * 0.02, s.rx * 0.84, s.ry * 0.82, rng, 0.08, 14, 0);
          c.beginPath();
          R.smoothPath(c, fp);
          var fg = c.createRadialGradient(s.cx - s.rx * 0.3, s.cy - s.ry * 0.3, 0, s.cx, s.cy, s.rx);
          fg.addColorStop(0, '#FFFBF0');
          fg.addColorStop(0.7, R.mix('#F2E6CC', liquid, 0.1));
          fg.addColorStop(1, R.mix('#D9C69E', liquid, 0.3));
          c.fillStyle = fg;
          c.fill();
          for (var i = 0; i < Math.round(s.rx * 1.6); i++) {
            var a = rng() * TAU; var rr = Math.sqrt(rng()) * 0.92;
            var bx = s.cx + Math.cos(a) * s.rx * rr; var by = s.cy + Math.sin(a) * s.ry * rr; var br = s.rx * (0.015 + rng() * rng() * 0.05);
            c.beginPath();
            ellPath(bx, by, br, br * 0.8)(c);
            c.strokeStyle = R.rgba('#B8A27A', 0.35);
            c.lineWidth = Math.max(0.4, br * 0.25);
            c.stroke();
            R.glint(c, bx - br * 0.3, by - br * 0.3, br * 0.4, br * 0.2, -0.5, 0.6);
          }
        } else if (arcane) {
          R.puff(c, s.cx, s.cy, s.rx * 0.9, '#9FC2FF', 0.45);
          for (var m = 0; m < 12; m++) R.puff(c, s.cx + (rng() - 0.5) * s.rx * 1.6, s.cy + (rng() - 0.5) * s.ry * 1.4, s.rx * 0.05, '#FFFFFF', 0.8);
        }
      },
    });
    var s2 = w.surface || w;
    if (!foam) {
      var cinn = findIng(p, ['cinnamon'], true);
      if (cinn) {
        var cx = s2.cx - s2.rx * 0.15; var cy = s2.cy - s2.ry * 0.1;
        var stick = [[cx - s2.rx * 0.55, cy + s2.ry * 0.2], [cx + s2.rx * 0.6, cy - s2.ry * 0.35]];
        ctx.save();
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(stick[0][0], stick[0][1]);
        ctx.lineTo(stick[1][0], stick[1][1]);
        ctx.strokeStyle = '#6E3A1C';
        ctx.lineWidth = Math.max(2, s2.rx * 0.12);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(stick[0][0], stick[0][1] - 1);
        ctx.lineTo(stick[1][0], stick[1][1] - 1);
        ctx.strokeStyle = R.rgba('#C98A55', 0.6);
        ctx.lineWidth = Math.max(0.8, s2.rx * 0.04);
        ctx.stroke();
        ctx.restore();
      }
      if (findIng(p, ['clove'], true)) {
        for (var k = 0; k < 4; k++) clove(ctx, s2.cx + (rng() - 0.2) * s2.rx * 0.9, s2.cy + (rng() - 0.5) * s2.ry * 0.9, Math.max(1.2, s2.rx * 0.07));
      }
      var lemon = findIng(p, ['lemon', 'orange']);
      if (lemon) citrusWheel(ctx, s2.cx + s2.rx * 0.3, s2.cy + s2.ry * 0.15, s2.rx * 0.32, 0.2, '#E7C23A', '#F4DE7A');
    }
  }

  /* ========================================================== the twenty === */

  var COMPONENT_DRAW = {
    roast: function (ctx, w, p, rng) {
      var f = roastForm(p);
      if (f === 'ribs') return drawRibs(ctx, w, p, rng);
      if (f === 'bird') return drawBird(ctx, w, p, rng);
      if (f === 'roots') return drawRoastRoots(ctx, w, p, rng);
      return drawJoint(ctx, w, p, rng);
    },
    fillet: function (ctx, w, p, rng) {
      var f = filletForm(p);
      if (f === 'shellfish') return drawShellfish(ctx, w, p, rng);
      if (f === 'steak') return drawSteak(ctx, w, p, rng);
      if (f === 'whole') return drawWholeFish(ctx, w, p, rng);
      return drawFish(ctx, w, p, rng);
    },
    stew: drawStew,
    loaf: drawLoaf,
    soup: drawSoup,
    pie: drawPie,
    salad: drawSalad,
    skewers: drawSkewers,
    porridge: drawPorridge,
    broth: drawBroth,
    jerky: drawJerky,
    cake: drawCake,
    pastry: drawPastry,
    dumplings: drawDumplings,
    noodles: drawNoodles,
    eggs: drawEggs,
    cheeseboard: drawCheeseboard,
    fruit: drawFruit,
    preserves: drawPreserves,
    drink: drawDrink,
  };

  /* ============================================================ the sauce ===
   * `pooled` from the behaviour: how much of the well the liquid claims. The
   * edge is irregular, there are drops beside it, and it is glossy — a sauce
   * that is a neat ellipse in the middle of a plate reads as a sticker. */
  /* What each finish looks like as a liquid. The profile's sauce colour is the
   * dish's own; the finish decides whether it is a brown jus, a green oil, a
   * cream or a lacquer — the first build pooled a BROWN gremolata under a
   * trout (art stage, 2026-09-10). */
  var FINISH_TINT = {
    /* ⛔ gremolata sits in OIL: at '#7E8A3A' it pooled olive-brown and read as
     * a burn under the whole trout (product size, 2026-09-10) — golden oil */
    jus: ['#5A2412', 0.25], gremolata: ['#B0A64A', 0.66], glaze: ['#C98A26', 0.45],
    charOil: ['#2A1C12', 0.55], herbOil: ['#5E7F3A', 0.60], brothPool: ['#B07A3C', 0.30],
    cream: ['#F2E8D4', 0.55], dusting: ['#8C5A30', 0.2], crumb: ['#C8A064', 0.2], bare: ['#8C3B22', 0],
  };
  /* Wood, bread, leaf, cloth and stone drink a sauce — it sits as a smaller
   * pool there than on glazed ceramic. */
  var ABSORBENT = ['board', 'trencher', 'stoneSlab', 'leafWrap', 'clothBundle', 'tray', 'skewerRack'];
  /* Dry forms carry no pool at all: a sauce under bread, cheese or jerky is a
   * spill, not a finish. */
  var DRY = ['jerky', 'loaf', 'cheeseboard', 'cake', 'pastry', 'fruit'];

  function pool(ctx, w, p, rng, scale) {
    var R = deps();
    var B = _D.BEHAVIOURS[p.behaviour];
    var k = scale === undefined ? 1 : scale;
    if (DRY.indexOf(p.component) >= 0) k = 0;
    else if (p.component === 'pie' && w.deep) k = 0;
    else if (p.component === 'fruit' || p.component === 'salad') k *= 0.45;
    if (ABSORBENT.indexOf(p.vessel) >= 0) k *= 0.6;
    /* ⛔ A fish or a steak laid on wood, leaf or stone is served DRY: its pool
     * showed only as a dark stain under the belly of the whole trout (product
     * size, 2026-09-10). Its finish is the garnish scattered over it. */
    if (p.component === 'fillet' && ABSORBENT.indexOf(p.vessel) >= 0) k = 0;
    var amount = B.pooled * k;
    if (amount <= 0.02) return;
    var rx = w.rx * (0.46 + amount * 0.56);
    var ry = w.ry * (0.46 + amount * 0.56);
    var cy = w.cy + w.ry * 0.10 * (1 - amount);
    var prng = R.rngFrom((p.seed ^ 0x5bf03635) >>> 0);
    var pts = R.blobPts(w.cx, cy, rx, ry, prng, 0.11, 13, 0.3);
    var path = ptsPath(pts);
    var b = boundsOf(pts);
    var tint = FINISH_TINT[p.behaviour] || FINISH_TINT.jus;
    var sauce = R.mix(p.sauceColour, tint[0], tint[1]);
    var soaked = ABSORBENT.indexOf(p.vessel) >= 0;
    ctx.save();
    /* on wood, bread or cloth a sauce is a translucent glossy spread — drawn
     * opaque there it read as a burnt lump (art stage, 2026-09-10) */
    if (soaked) ctx.globalAlpha = 0.72;
    ctx.beginPath();
    path(ctx);
    R.litFill(ctx, w.cx, cy, Math.max(rx, ry), sauce, { lift: 0.18, drop: 0.28 });
    ctx.restore();
    R.innerShade(ctx, path, b.x, b.y, b.w, b.h, {
      invert: false, depth: ry * 0.10, blur: ry * 0.12, dark: R.shade(sauce, -0.6), darkA: 0.35,
      light: R.shade(sauce, 0.7), lightA: 0.35,
    });
    for (var d = 0; d < 4; d++) {
      var a = prng() * TAU;
      var dx = w.cx + Math.cos(a) * rx * (1.08 + prng() * 0.14);
      var dy = cy + Math.sin(a) * ry * (1.08 + prng() * 0.14);
      var dr = Math.max(0.8, rx * (0.018 + prng() * 0.03));
      ctx.beginPath();
      ellPath(dx, dy, dr, dr * 0.7)(ctx);
      ctx.fillStyle = R.shade(sauce, -0.1);
      ctx.fill();
      R.glint(ctx, dx - dr * 0.3, dy - dr * 0.25, dr * 0.5, dr * 0.2, -0.4, 0.6);
    }
    var gl = B.gloss * (0.4 + p.gloss * 0.6);
    R.glint(ctx, w.cx - rx * 0.55, cy - ry * 0.45, rx * 0.20, Math.max(0.5, ry * 0.05), -0.25, 0.25 + gl * 0.5);
    R.glint(ctx, w.cx + rx * 0.42, cy + ry * 0.55, rx * 0.14, Math.max(0.4, ry * 0.035), 0.2, 0.15 + gl * 0.3);
  }

  /* ==================================================== the surface finish ===
   * ⛔ A FINISH THAT POOLS HAS NO DRAW CALL AT ALL ON A DRY COMPONENT, AND A
   * STORE IMAGE CAPTIONED IT ANYWAY (art-director defect 1, polish stage
   * 2026-09-11). The ten-finishes sheet read GLAZE over two matte turnovers with
   * no specular on them and CREAM over a cheese board with no cream drawn
   * anywhere. Found by reading `pool()` rather than by looking harder at the
   * picture: `DRY` sets the pool amount to zero, so on a cake, pastry, loaf,
   * fruit, cheese board or jerky the finish produced NOTHING — wing §17c, a
   * caption naming a property the product never draws, and it was a defect for
   * every BUYER with a dry dish, not only for the sheet.
   *
   * A dry dish is not unfinished. It is finished ON THE SURFACE: a glaze is a
   * lacquer over the crown with a specular and a run down the side, a cream is a
   * spoonful set beside the food, an oil is a sheen. Drawn after the component,
   * inside the vessel's clip, so it lies ON the food.
   */
  var DRY_FINISH = {
    glaze: { kind: 'lacquer', alpha: 0.52, spec: 0.95, runs: 3 },
    cream: { kind: 'dollop', alpha: 0.94, spec: 0.55 },
    /* ⛔ `crumb` MEASURED 0.000% — it changed not one pixel on its own specimen
     * (finish-is-drawn proof, 2026-09-11). `pooled: 0` and a garnish count of
     * zero on a plain loaf left the whole finish to the loaf component's cut
     * end; the sheet's CRUMB cell was carried by the bread, not by the finish.
     * A crumb finish is crumbs: shed on the vessel around the food, where bread
     * actually sheds them. */
    crumb: { kind: 'crumbs', alpha: 0.9, spec: 0.2 },
    jus: { kind: 'lacquer', alpha: 0.34, spec: 0.55, runs: 2 },
    gremolata: { kind: 'sheen', alpha: 0.30, spec: 0.45 },
    charOil: { kind: 'sheen', alpha: 0.40, spec: 0.50 },
    herbOil: { kind: 'sheen', alpha: 0.34, spec: 0.55 },
    brothPool: { kind: 'sheen', alpha: 0.26, spec: 0.35 },
  };

  /**
   * The finish as a SURFACE, for the components a pool would be a spill on.
   * @param {object} ctx Canvas 2D context.
   * @param {object} w The vessel's well geometry.
   * @param {object} p A dish profile.
   * @param {function():number} rng Seeded stream (unused; the finish has its own).
   * @returns {string|null} The kind drawn, or null when this dish takes a pool.
   */
  function dryFinish(ctx, w, p, rng) {
    var R = deps();
    if (DRY.indexOf(p.component) < 0) return null;
    var F = DRY_FINISH[p.behaviour];
    if (!F) return null;
    var tint = FINISH_TINT[p.behaviour] || FINISH_TINT.jus;
    var col = R.mix(p.sauceColour, tint[0], tint[1]);
    var prng = R.rngFrom((p.seed ^ 0x2f6d41a7) >>> 0);
    var rs = Math.min(w.rx, w.ry);

    if (F.kind === 'crumbs') {
      /* crumbs shed on the vessel AROUND the food, in a loose drift to the
       * lower right where a knife would have pushed them, each one a lit
       * irregular chip rather than a dot */
      var crumbCol = R.shade(R.mix(p.bodyColour, '#D8B678', 0.55), 0.05);
      var nC = Math.max(18, Math.min(64, Math.round(rs * 0.46)));
      for (var ci = 0; ci < nC; ci++) {
        var ca = prng() * TAU;
        var ck = 0.62 + prng() * 0.46;
        var cxp = w.cx + Math.cos(ca) * w.rx * ck + w.rx * 0.10;
        var cyp = w.cy + Math.sin(ca) * w.ry * ck + w.ry * 0.16;
        var cs = Math.max(0.9, rs * (0.030 + prng() * 0.048));
        ctx.save();
        ctx.translate(cxp, cyp);
        ctx.rotate(prng() * TAU);
        ctx.beginPath();
        ctx.moveTo(-cs, 0);
        ctx.lineTo(-cs * 0.25, -cs * 0.8);
        ctx.lineTo(cs * 0.9, -cs * 0.2);
        ctx.lineTo(cs * 0.3, cs * 0.75);
        ctx.closePath();
        ctx.fillStyle = R.shade(crumbCol, (prng() - 0.4) * 0.35);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(-cs * 0.5, -cs * 0.25);
        ctx.lineTo(cs * 0.35, -cs * 0.1);
        ctx.strokeStyle = R.rgba(R.shade(crumbCol, 0.5), 0.5);
        ctx.lineWidth = Math.max(0.4, cs * 0.3);
        ctx.stroke();
        ctx.restore();
      }
      return 'crumbs';
    }

    if (F.kind === 'dollop') {
      /* a spoonful set down beside the food, on the vessel — the one place a
       * cream can be on a cheese board without pretending the cheese is wet.
       * ⛔ At 0.42/0.30 of the well it landed ON a pale curd and vanished into
       * it (polish stage, second look 2026-09-11): a pale finish has to be put
       * where the vessel is, not where the food is, or it is §17c-1 — the draw
       * call executes and no pixel changes. */
      var dx = w.cx - w.rx * 0.54;
      var dy = w.cy + w.ry * 0.40;
      var drx = w.rx * 0.34; var dry = w.ry * 0.29;
      R.contactShadow(ctx, dx, dy + dry * 0.55, drx * 1.05, dry * 0.85, 0.34);
      var dpts = R.blobPts(dx, dy, drx, dry, prng, 0.17, 11, 0.6);
      var dpath = ptsPath(dpts);
      var db = boundsOf(dpts);
      ctx.save();
      ctx.globalAlpha = F.alpha;
      ctx.beginPath();
      dpath(ctx);
      R.litFill(ctx, dx, dy, Math.max(drx, dry), col, { lift: 0.34, drop: 0.22 });
      ctx.restore();
      R.innerShade(ctx, dpath, db.x, db.y, db.w, db.h, {
        depth: dry * 0.22, blur: dry * 0.30, dark: R.shade(col, -0.45), darkA: 0.30,
        light: R.shade(col, 0.65), lightA: 0.40,
      });
      /* the spoon's own swirl, so it is a served spoonful and not a puddle */
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(dx, dy, drx * 0.62, dry * 0.58, -0.3, Math.PI * 0.15, Math.PI * 1.25);
      ctx.strokeStyle = R.rgba(R.shade(col, -0.35), 0.34);
      ctx.lineWidth = Math.max(0.7, rs * 0.020);
      ctx.stroke();
      ctx.restore();
      R.glint(ctx, dx - drx * 0.38, dy - dry * 0.44, drx * 0.42, Math.max(0.5, dry * 0.14), -0.22, F.spec);
      /* two drips of it on the food itself, so the finish is ON the dish */
      for (var s = 0; s < 2; s++) {
        var sx = w.cx + (prng() - 0.2) * w.rx * 0.55;
        var sy = w.cy - w.ry * (0.05 + prng() * 0.22);
        var sr = rs * (0.07 + prng() * 0.05);
        ctx.beginPath();
        ellPath(sx, sy, sr, sr * 0.72)(ctx);
        ctx.fillStyle = R.rgba(col, 0.85);
        ctx.fill();
        R.glint(ctx, sx - sr * 0.3, sy - sr * 0.3, sr * 0.5, sr * 0.2, -0.4, F.spec * 0.8);
      }
      return 'dollop';
    }

    /* lacquer / sheen: a veil over the crown of the food, a lit shoulder, and
     * for a lacquer the runs that say it was POURED and then set */
    var vx = w.cx + w.rx * 0.02;
    var vy = w.cy - w.ry * 0.16;
    var vrx = w.rx * (F.kind === 'lacquer' ? 0.72 : 0.76);
    var vry = w.ry * (F.kind === 'lacquer' ? 0.60 : 0.64);
    var vpts = R.blobPts(vx, vy, vrx, vry, prng, 0.15, 11, 0.35);
    var vpath = ptsPath(vpts);
    ctx.save();
    ctx.globalAlpha = F.alpha;
    ctx.beginPath();
    vpath(ctx);
    R.litFill(ctx, vx, vy, Math.max(vrx, vry), col, { lift: 0.40, drop: 0.18 });
    if (F.kind === 'lacquer') {
      /* the runs: a lacquer that stops dead at an outline is a sticker */
      for (var r = 0; r < (F.runs || 2); r++) {
        var ang = 0.5 + (r + prng() * 0.5) / (F.runs || 2) * 2.1;
        var bx = vx + Math.cos(ang) * vrx * 0.86;
        var by = vy + Math.sin(ang) * vry * 0.86;
        var len = vry * (0.30 + prng() * 0.42);
        var wid = rs * (0.045 + prng() * 0.035);
        ctx.beginPath();
        ctx.moveTo(bx - wid, by);
        ctx.quadraticCurveTo(bx - wid * 0.8, by + len * 0.7, bx, by + len);
        ctx.quadraticCurveTo(bx + wid * 0.8, by + len * 0.7, bx + wid, by);
        ctx.closePath();
        ctx.fillStyle = R.shade(col, -0.08);
        ctx.fill();
      }
    }
    ctx.restore();
    /* ⛔ the caption says "a glaze takes a SPECULAR" — so the specular is a draw
     * call, bright, short and lying along the surface, not an implied gloss */
    var la = Math.atan2(R.LIGHT.y, R.LIGHT.x);
    var nSpec = F.kind === 'lacquer' ? 3 : 2;
    for (var i = 0; i < nSpec; i++) {
      var sa = la + ((i + 0.35) / nSpec - 0.5) * 1.25;
      var gx = vx + Math.cos(sa) * vrx * (0.44 + prng() * 0.14);
      var gy = vy + Math.sin(sa) * vry * (0.44 + prng() * 0.14);
      R.glint(ctx, gx, gy, rs * (0.20 + prng() * 0.10) * (i === 0 ? 1.3 : 0.85),
        Math.max(0.6, rs * 0.055), sa + Math.PI / 2, F.spec * (i === 0 ? 1 : 0.7));
    }
    return F.kind;
  }

  /**
   * ⛔ `dusting` IS THE ONE FINISH THAT NEVER POOLED ANYWHERE — `pooled: 0` — so
   * across the whole product its entire visible existence was sixteen specks per
   * garnish placement, and on the Honey Almond Cake the honey's own drip beat it
   * outright (art-director defect 1). A dusting is a LAYER: a veil of powder
   * that sits on the top surface, thins over the shoulder, and drifts a little
   * onto the vessel. Drawn for every component, not only the dry ones.
   *
   * @param {object} ctx Canvas 2D context.
   * @param {object} w The vessel's well geometry.
   * @param {object} p A dish profile.
   * @returns {number} How many grains were laid, so a probe can count the work.
   */
  function powderVeil(ctx, w, p) {
    var R = deps();
    if (p.behaviour !== 'dusting') return 0;
    var prng = R.rngFrom((p.seed ^ 0x71c3ab05) >>> 0);
    var rs = Math.min(w.rx, w.ry);
    /* the powder takes its warmth from the dish's own spice, never a flat white */
    var powder = R.mix('#FFF6E4', R.shade(p.sauceColour, 0.42), 0.30);
    var cx = w.cx; var cy = w.cy - w.ry * 0.20;
    ctx.save();
    /* the veil itself: soft, low, and wider than it is tall — a layer seen from
     * above and in front, not a cloud */
    R.puff(ctx, cx, cy, Math.max(w.rx, w.ry) * 0.60, powder, 0.14);
    R.puff(ctx, cx - w.rx * 0.20, cy - w.ry * 0.10, Math.max(w.rx, w.ry) * 0.34, powder, 0.10);
    var n = Math.max(48, Math.min(260, Math.round(w.rx * w.ry / 70)));
    var grain = Math.max(0.45, rs * 0.023);
    for (var i = 0; i < n; i++) {
      var a = prng() * TAU;
      /* sqrt keeps the grains even over the area instead of piling at the middle */
      var k = Math.sqrt(prng());
      var gx = cx + Math.cos(a) * w.rx * 0.80 * k;
      var gy = cy + Math.sin(a) * w.ry * 0.70 * k;
      /* thinner down the shaded side, the way a dusting actually lands */
      var lit = 0.55 + 0.45 * (-(Math.sin(a)) * 0.6 + 0.4);
      ctx.beginPath();
      ctx.arc(gx, gy, grain * (0.45 + prng() * 0.85), 0, TAU);
      ctx.fillStyle = R.rgba(powder, (0.30 + prng() * 0.48) * lit);
      ctx.fill();
    }
    /* the drift that missed the food and landed on the vessel */
    for (var d = 0; d < 7; d++) {
      var da = prng() * TAU;
      var dxp = w.cx + Math.cos(da) * w.rx * (1.02 + prng() * 0.14);
      var dyp = w.cy + Math.sin(da) * w.ry * (1.02 + prng() * 0.14);
      ctx.beginPath();
      ctx.arc(dxp, dyp, grain * (0.4 + prng() * 0.7), 0, TAU);
      ctx.fillStyle = R.rgba(powder, 0.22 + prng() * 0.30);
      ctx.fill();
    }
    ctx.restore();
    return n + 7;
  }

  /* ========================================================== the garnish ===
   * ⛔ Placement rules, never a loop over a lattice (design brief). The marks
   * land ON the food and sauce, and each kind is drawn differently enough to be
   * named at plate scale — pepper as tight angular flecks (the first build's
   * pepper read as dirt), zest as curls, seeds as teardrops. */
  var GARNISH_DRAW = {
    herbLeaf: function (ctx, x, y, s, a, colour, rng) {
      var R = deps();
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(a);
      ctx.beginPath();
      ctx.moveTo(-s, 0);
      ctx.quadraticCurveTo(0, -s * 0.66, s, 0);
      ctx.quadraticCurveTo(0, s * 0.66, -s, 0);
      ctx.closePath();
      R.litFill(ctx, 0, 0, s, R.shade(colour, (rng() - 0.4) * 0.3), { lift: 0.36, drop: 0.32 });
      ctx.beginPath();
      ctx.moveTo(-s * 0.85, 0);
      ctx.lineTo(s * 0.85, 0);
      ctx.strokeStyle = R.rgba(R.shade(colour, 0.5), 0.55);
      ctx.lineWidth = Math.max(0.4, s * 0.12);
      ctx.stroke();
      ctx.restore();
      for (var i = 0; i < 3; i++) {
        ctx.beginPath();
        ellPath(x + (rng() - 0.5) * s * 3, y + (rng() - 0.5) * s * 2, Math.max(0.4, s * 0.22), Math.max(0.3, s * 0.15), rng() * TAU)(ctx);
        ctx.fillStyle = R.rgba(R.shade(colour, -0.1), 0.85);
        ctx.fill();
      }
    },
    crackedPepper: function (ctx, x, y, s, a, colour, rng) {
      var R = deps();
      var n = 4 + Math.floor(rng() * 4);
      for (var i = 0; i < n; i++) {
        var px = x + (rng() - 0.5) * s * 1.6; var py = y + (rng() - 0.5) * s * 1.1;
        var fs = Math.max(0.5, s * (0.12 + rng() * 0.16));
        ctx.beginPath();
        ctx.moveTo(px - fs, py - fs * 0.3);
        ctx.lineTo(px + fs * 0.2, py - fs * 0.8);
        ctx.lineTo(px + fs, py + fs * 0.2);
        ctx.lineTo(px - fs * 0.3, py + fs * 0.7);
        ctx.closePath();
        ctx.fillStyle = R.rgba(rng() > 0.75 ? '#6E5238' : '#1A1210', 0.9);
        ctx.fill();
      }
    },
    zest: function (ctx, x, y, s, a, colour, rng) {
      /* ⛔ TWO SHAPES FAILED, IN OPPOSITE DIRECTIONS. A long thin S read as a
       * WORM at product size; the stubby bent strip that replaced it read as a
       * yellow GRUB on the whole trout (2x crop, art stage 2026-09-10). A
       * gremolata is CHOPPED: fine slivers of peel among flecks of parsley and
       * a little garlic — confetti, never one legible curl. */
      var R = deps();
      ctx.save();
      ctx.lineCap = 'round';
      for (var z = 0; z < 3; z++) {
        var zx = x + (rng() - 0.5) * s * 1.6; var zy = y + (rng() - 0.5) * s * 1.0;
        var za = a + (rng() - 0.5) * 1.8; var zl = s * (0.30 + rng() * 0.22);
        ctx.beginPath();
        ctx.moveTo(zx - Math.cos(za) * zl, zy - Math.sin(za) * zl);
        ctx.quadraticCurveTo(zx + Math.sin(za) * zl * 0.25, zy - Math.cos(za) * zl * 0.25,
          zx + Math.cos(za) * zl, zy + Math.sin(za) * zl);
        ctx.strokeStyle = '#D9A21C';
        ctx.lineWidth = Math.max(0.9, s * 0.16);
        ctx.stroke();
        ctx.strokeStyle = '#F6D35A';
        ctx.lineWidth = Math.max(0.5, s * 0.08);
        ctx.stroke();
      }
      ctx.restore();
      for (var i = 0; i < 6; i++) {
        var px = x + (rng() - 0.5) * s * 2.2; var py = y + (rng() - 0.5) * s * 1.4;
        var ps = Math.max(0.6, s * (0.10 + rng() * 0.10));
        var pp = R.blobPts(px, py, ps, ps * 0.8, rng, 0.35, 5, rng() * TAU);
        ctx.beginPath();
        R.smoothPath(ctx, pp);
        ctx.fillStyle = R.rgba(i === 5 ? '#F2EAD2' : (rng() > 0.5 ? '#3F7A2C' : '#5E9540'), 0.92);
        ctx.fill();
      }
    },
    seed: function (ctx, x, y, s, a, colour, rng) {
      var R = deps();
      for (var i = 0; i < 5; i++) {
        var sx = x + (rng() - 0.5) * s * 2.0; var sy = y + (rng() - 0.5) * s * 1.4;
        ctx.save();
        ctx.translate(sx, sy);
        ctx.rotate(rng() * TAU);
        ctx.beginPath();
        ctx.moveTo(-s * 0.32, 0);
        ctx.quadraticCurveTo(0, -s * 0.2, s * 0.32, 0);
        ctx.quadraticCurveTo(0, s * 0.2, -s * 0.32, 0);
        ctx.closePath();
        ctx.fillStyle = '#EAD7A8';
        ctx.fill();
        ctx.strokeStyle = R.rgba('#8A6A3A', 0.6);
        ctx.lineWidth = Math.max(0.3, s * 0.05);
        ctx.stroke();
        ctx.restore();
      }
    },
    dust: function (ctx, x, y, s, a, colour, rng) {
      var R = deps();
      for (var i = 0; i < 16; i++) {
        var r = Math.sqrt(rng()) * s * 1.5; var ang = rng() * TAU;
        ctx.beginPath();
        ctx.arc(x + Math.cos(ang) * r, y + Math.sin(ang) * r * 0.7, Math.max(0.35, s * (0.05 + rng() * 0.06)), 0, TAU);
        ctx.fillStyle = R.rgba(colour, 0.35 + rng() * 0.35);
        ctx.fill();
      }
    },
    charFleck: function (ctx, x, y, s, a, colour, rng) {
      var R = deps();
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(a);
      ctx.beginPath();
      ctx.moveTo(-s * 0.7, 0);
      ctx.lineTo(-s * 0.1, -s * 0.34);
      ctx.lineTo(s * 0.7, s * 0.08);
      ctx.lineTo(0, s * 0.3);
      ctx.closePath();
      ctx.fillStyle = R.rgba('#1A0F0A', 0.85);
      ctx.fill();
      ctx.restore();
      R.glint(ctx, x - s * 0.2, y - s * 0.1, s * 0.3, s * 0.08, a, 0.5);
    },
    crumb: function (ctx, x, y, s, a, colour, rng) {
      var R = deps();
      for (var i = 0; i < 5; i++) {
        var cx = x + (rng() - 0.5) * s * 2.0; var cy = y + (rng() - 0.5) * s * 1.4;
        var cs = s * (0.18 + rng() * 0.18);
        var pts = R.blobPts(cx, cy, cs, cs * 0.8, rng, 0.3, 6, rng() * TAU);
        ctx.beginPath();
        R.smoothPath(ctx, pts);
        R.litFill(ctx, cx, cy, cs, R.mix('#D6B477', colour, 0.2), { lift: 0.35, drop: 0.35 });
      }
    },
    none: function () {},
  };

  /* Forms whose top is PASTRY or crust: loose pepper, dust or crumbs on them
   * read as dirt (the lattice pie, art stage 2026-09-10). They take only a
   * herb, and fewer of them. */
  var CRUST_TOPS = ['pie', 'pastry', 'loaf'];

  function garnish(ctx, w, p, rng) {
    var R = deps();
    if (p.garnishCount <= 0) return;
    var kind = GARNISH_DRAW[p.garnishKind] ? p.garnishKind : 'herbLeaf';
    var count = p.garnishCount;
    /* ⛔ A LEAF IS DRAWN ONLY WHEN A LEAF WENT IN. A broth or cream finish
     * garnishes with herb leaves, and on a dish with no herb those leaves took
     * the spice-brown fallback colour — `Saffron Rice` wore brown leaves that
     * read as seeds, or bugs (product size, art stage 2026-09-10). No herb: a
     * spiced dish gets a dusting of its spice, a plain one gets nothing. */
    var herbed = p.presence && p.presence.herb > 0;
    if (kind === 'herbLeaf' && !herbed) {
      if (p.presence && p.presence.spice > 0) kind = 'dust';
      else return;
    }
    /* ⛔ Burnt-oil flecks belong in an oil. On a DRY form they scatter across
     * the cloth or board beside the food and read as dirt (the smoked eel,
     * 2x crop, 2026-09-10); a dry smoked thing carries its smoke in its own
     * skin. */
    if (kind === 'charFleck' && DRY.indexOf(p.component) >= 0) return;
    if (CRUST_TOPS.indexOf(p.component) >= 0 && kind !== 'herbLeaf' && kind !== 'zest' && kind !== 'seed') {
      if (!(p.presence && p.presence.herb > 0)) return;
      kind = 'herbLeaf';
      count = Math.ceil(count / 2);
    }
    var pts = R.scatter(rng, count, { rMin: 0.20, rMax: 0.86, sep: 0.19 });
    var s = Math.max(2.2, w.rx * 0.07);
    var colour = kind === 'dust' ? (SWEET_DUST.indexOf(p.component) >= 0 ? '#F4EFE4' : p.garnishColour) : p.garnishColour;
    for (var i = 0; i < pts.length; i++) {
      GARNISH_DRAW[kind](ctx, w.cx + pts[i].x * w.rx * 0.92, w.cy + pts[i].y * w.ry * 0.92,
        s * pts[i].s, pts[i].a, colour, rng);
    }
  }
  /* A dusting on a sweet form is sugar, not spice. */
  var SWEET_DUST = ['cake', 'pastry', 'fruit', 'preserves'];

  /* ================================================================ steam ===
   * ⛔ The first build's steam was two long straight strokes and read as smoke
   * (in-engine photograph, 2026-09-10). Steam is SHORT, soft and wide: puffs
   * along a curling path, each larger and fainter than the last, gone within
   * a plate's height. */
  function steam(ctx, w, p, rng, phase) {
    var R = deps();
    if (p.heat < 0.25) return;
    /* ⛔ Three strands rising straight read as PILLARS of smoke over the
     * dragon rack (item-detail capture, art stage 2026-09-10): a wisp CURLS
     * — two harmonics, a sway that grows as it rises — and breaks up. */
    var strands = p.heat > 0.7 ? 3 : 2;
    var ph = phase || 0;
    var srng = R.rngFrom((p.seed ^ 0x2545f491) >>> 0);
    for (var i = 0; i < strands; i++) {
      var x0 = w.cx + (i - (strands - 1) / 2) * w.rx * 0.42 + (srng() - 0.5) * w.rx * 0.12;
      /* ⛔ Steam leaves the TOP of the food. From the well's plane it rose
       * through the rice heap and glazed it like a glass cloche (product size,
       * 2026-09-10); a heaped component records its crown in `steamTop`. */
      var y0 = w.steamTop !== undefined ? w.steamTop : w.cy - w.ry * 0.25;
      var h = w.ry * (1.3 + p.heat * 0.7) * (0.75 + srng() * 0.4);
      var sway = w.rx * (0.16 + srng() * 0.10);
      var k0 = srng() * TAU; var k1 = srng() * TAU;
      var lean = (srng() - 0.35) * w.rx * 0.22;
      var steps = 18;
      for (var t = 0; t <= steps; t++) {
        var f = t / steps;
        var x = x0 + (Math.sin(f * 5.0 + k0 + ph) * 0.75 + Math.sin(f * 11.0 + k1) * 0.25) * sway * (0.25 + f) + lean * f;
        var y = y0 - h * f;
        var r = w.rx * (0.045 + f * 0.14);
        var gap = 0.55 + 0.45 * Math.abs(Math.sin(f * 7.0 + k1));
        R.puff(ctx, x, y, r, '#FFFFFF', 0.10 * p.heat * gap * Math.sin(Math.PI * Math.min(1, f * 1.1 + 0.06)));
      }
    }
  }

  /* ============================================================ the table === */

  /* ⛔ THE GROUND WAS ONE HARD-CODED WALNUT AND NOTHING COULD CHANGE IT (polish
   * stage, 2026-09-11, art-director defect 4). The Gate 2 incumbent's own
   * buyers' second complaint is that a cooking scene cannot be made to fit their
   * game, and a pastel, sci-fi or paper-styled project could not use this one.
   * Four grounds, each a real surface with its own grain and seam treatment, and
   * an optional hue shift on top of whichever is chosen.
   *
   * ⛔ wing §11a: walnut's base IS `R.P.table` — the palette's constant, not a
   * second copy of it. A ground that typed '#3B2A24' here would stop tracking
   * the palette the moment the brief's walnut moved. */
  /* ⛔⛔ AND THE FIRST VERSION OF THIS TABLE DREW WOOD GRAIN AND PLANK SEAMS UNDER
   * ALL FOUR NAMES (found by LOOKING at `_probe/polish_look.js`'s ground sheet,
   * polish round 2, 2026-09-11). The parameter offers a buyer `Dark slate` and
   * `Linen cloth`; what came out was stained oak in a grey-blue and stained oak
   * in a cream. That is wing §17c exactly — a name that promises a property the
   * draw call never puts on the bitmap — and it is the WORST place for it,
   * because the whole point of the parameter is that a project which cannot use
   * a wooden table can use this one. A material is a SURFACE TREATMENT, not a
   * palette: `kind` selects it, and stone and cloth get their own. */
  var GROUNDS = {
    walnut: { kind: 'plank', base: null, warm: '#4A3024', cool: '#34241E', seam: '#0B0705', seamLight: '#FFE6C8',
      joint: '#0E0907', grainA: 0.36, lamp: '#FFC98A', lampA: 0.13, vignette: 0.62 },
    paleOak: { kind: 'plank', base: '#A8875E', warm: '#B9976B', cool: '#9B7A52', seam: '#4A3620', seamLight: '#FFF3DC',
      joint: '#5A4127', grainA: 0.30, lamp: '#FFE2B0', lampA: 0.16, vignette: 0.44 },
    darkSlate: { kind: 'stone', base: '#3A3F45', warm: '#484F57', cool: '#2C3137', fleck: '#C7D6E4',
      vein: '#171B1F', lamp: '#CBDCEC', lampA: 0.10, vignette: 0.66 },
    linen: { kind: 'cloth', base: '#C9BCA4', warm: '#D8CCB6', cool: '#B3A48A', thread: '#8A7A60',
      slub: '#FFFBF0', lamp: '#FFF0D2', lampA: 0.18, vignette: 0.36 },
  };
  var GROUND_IDS = Object.keys(GROUNDS);

  /**
   * The warm pool of lamplight toward the plate and the vignette to the corners.
   * ⛔ wing §11a: EVERY ground ends this way, so it is ONE function that all
   * three surface kinds call — a second copy would not drift, it would win.
   *
   * @param {object} ctx Canvas 2D context.
   * @param {number} x Left.
   * @param {number} y Top.
   * @param {number} w Width.
   * @param {number} h Height.
   * @param {object} G The ground record.
   * @returns {void}
   */
  function lampAndVignette(ctx, x, y, w, h, G) {
    var R = deps();
    var lamp = ctx.createRadialGradient(x + w * 0.42, y + h * 0.46, 0, x + w * 0.42, y + h * 0.46, Math.max(w, h) * 0.62);
    lamp.addColorStop(0, R.rgba(G.lamp, G.lampA));
    lamp.addColorStop(0.5, R.rgba(G.lamp, G.lampA * 0.3));
    lamp.addColorStop(1, R.rgba(G.lamp, 0));
    ctx.fillStyle = lamp;
    ctx.fillRect(x, y, w, h);
    var g = ctx.createRadialGradient(x + w * 0.45, y + h * 0.48, Math.min(w, h) * 0.20, x + w * 0.5, y + h * 0.5, Math.max(w, h) * 0.78);
    g.addColorStop(0, R.rgba('#000000', 0));
    g.addColorStop(0.6, R.rgba('#000000', G.vignette * 0.29));
    g.addColorStop(1, R.rgba('#000000', G.vignette));
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);
  }

  /**
   * The ground every plate sits on. ⛔ Its MATERIAL is chosen by the ground's
   * `kind`, never by its colours: planks take flowing grain and seams, slate
   * takes mottling, cleavage and fractures, linen takes a woven thread grid and
   * slubs. All three end with a warm
   * pool of lamplight toward the plate and a vignette to the corners.
   * ⛔ The design brief bans a checkerboard, a black void and a gradient: the
   * ground is ALWAYS a surface.
   *
   * @param {object} ctx Canvas 2D context.
   * @param {number} x Left.
   * @param {number} y Top.
   * @param {number} w Width.
   * @param {number} h Height.
   * @param {number} [seed] Seeded stream for the grain.
   * @param {object} [opt] {ground:'walnut'|'paleOak'|'darkSlate'|'linen', tint:'#rrggbb',
   *   tintK:number, pitch:number, originY:number, joints:boolean}
   * @returns {void}
   */
  function table(ctx, x, y, w, h, seed, opt) {
    var R = deps();
    var o = opt || {};
    var G = GROUNDS[o.ground] || GROUNDS.walnut;
    /* the tint shifts the WHOLE ground, so every tone below is mixed the same
     * way and the surface stays one material rather than a recoloured seam set */
    var tk = o.tint ? (o.tintK === undefined ? 0.45 : o.tintK) : 0;
    function T(c) { return tk > 0 ? R.mix(c, o.tint, tk) : c; }
    var baseCol = T(G.base || R.P.table);
    var rng = R.rngFrom(seed || 1);
    ctx.save();
    ctx.beginPath();
    ctx.rect(x, y, w, h);
    ctx.fillStyle = baseCol;
    ctx.fill();
    ctx.clip();
    if (G.kind === 'stone' || G.kind === 'cloth') {
      /* ⛔ A stone and a cloth have no planks, so they take NEITHER the seam grid
       * NOR `joints` — a caller passing `pitch` for a contact sheet is talking
       * about plank seams, and there are none to align. */
      if (G.kind === 'stone') stoneField(ctx, x, y, w, h, rng, G, T);
      else clothWeave(ctx, x, y, w, h, rng, G, T);
      lampAndVignette(ctx, x, y, w, h, G);
      ctx.restore();
      return;
    }
    /* ⛔ A plank grid that cannot be ALIGNED puts a seam through a caption and a
     * gutter (art-director defect 5): a contact sheet knows where its rows are
     * and the ground has to be able to agree with them. `pitch` and `originY`
     * are the seam grid; without them the old h/150 behaviour is unchanged. */
    var ph = o.pitch > 0 ? o.pitch : h / Math.max(3, Math.round(h / 150));
    var oy = o.originY === undefined ? y : o.originY;
    var first = y - ((y - oy) % ph + ph) % ph;
    var jointChance = o.joints === false ? 0 : 0.7;
    var i = 0;
    for (var py = first; py < y + h; py += ph) {
      var tone = R.shade(R.mix(baseCol, T(i % 2 ? G.warm : G.cool), 0.5), (rng() - 0.5) * 0.06);
      ctx.fillStyle = tone;
      ctx.fillRect(x, py, w, ph + 1);
      woodGrain(ctx, x - 10, py, w + 20, ph, rng, tone, G.grainA);
      if (rng() < jointChance) {
        var jx = x + w * (0.15 + rng() * 0.7);
        ctx.beginPath();
        ctx.moveTo(jx, py + 1);
        ctx.lineTo(jx, py + ph - 1);
        ctx.strokeStyle = R.rgba(G.joint, 0.55);
        ctx.lineWidth = 1.4;
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(jx + 1.4, py + 1);
        ctx.lineTo(jx + 1.4, py + ph - 1);
        ctx.strokeStyle = R.rgba('#FFFFFF', 0.05);
        ctx.lineWidth = 1;
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.moveTo(x, py);
      ctx.lineTo(x + w, py);
      ctx.strokeStyle = R.rgba(G.seam, 0.75);
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x, py + 2);
      ctx.lineTo(x + w, py + 2);
      ctx.strokeStyle = R.rgba(G.seamLight, 0.07);
      ctx.lineWidth = 1;
      ctx.stroke();
      i++;
    }
    lampAndVignette(ctx, x, y, w, h, G);
    ctx.restore();
  }

  /* ======================================================== the menu card ===
   * The motif of the whole pack (design brief): a hand-set card at the lower
   * right rim of every plate, naming the dish and listing what actually went
   * into it. It is the thing the incumbent's buyers said was missing. */
  function card(ctx, p, x, y, w, opt) {
    var R = deps();
    var o = opt || {};
    /* ⛔ THE MOTIF IS THE FULL LIST (art-director defect 7, polish stage
     * 2026-09-11): at five the tavern card truncated a six-ingredient dish to
     * "and 2 more" while the result scene's card listed all six — the two
     * surfaces disagreed about the one thing the product is selling, and the
     * tavern card is the surface a buyer reads longest. Eight lines, then and
     * only then a count. Above six the pitch tightens so the card does not
     * outgrow the room its caller reserved. */
    var lines = p.ingredientNames.slice(0, o.maxIngredients || 8);
    var pad = Math.max(8, w * 0.075);
    var titleSize = Math.max(13, w * 0.115);
    var bodySize = Math.max(9, w * 0.068);
    var pitch = lines.length > 6 ? 1.18 : 1.34;
    var h = pad * 2 + titleSize * 1.5 + 10 + lines.length * bodySize * pitch;
    /* ⛔ EVERY CARD AT THE SAME OFFSET, SIZE AND 0 DEGREES IS A STAMPED PANEL,
     * NOT A CARD SOMEONE PLACED (art-director defect 6): four of them in a row
     * on the one-roast sheet read as UI. The tilt and the nudge are HASHED FROM
     * THE DISH NAME, so the sheet and the in-game scene place the same dish's
     * card identically — a hand, not a random number. */
    var hr = R.rngFrom(R.hash('cardset|' + p.name));
    var tilt = o.tilt === undefined ? (hr() - 0.5) * 0.070 : o.tilt;
    var dx = o.dx === undefined ? (hr() - 0.5) * 12 : o.dx;
    var dy = o.dy === undefined ? (hr() - 0.5) * 10 : o.dy;
    ctx.save();
    ctx.translate(x + dx, y + dy);
    ctx.rotate(tilt);
    ctx.beginPath();
    R.rrect(ctx, 0, 0, w, h, 2);
    var g = ctx.createLinearGradient(0, 0, w * 0.4, h);
    g.addColorStop(0, R.P.cream);
    g.addColorStop(1, R.shade(R.P.cream, -0.09));
    ctx.save();
    /* ⛔ The shadow OFFSET stays in device space on purpose: canvas shadow
     * offsets ignore the transform, and that is the right answer here because
     * the pack has ONE light direction (RefectoryRender LIGHT). A card tilted 2
     * degrees still takes its shadow from the same lamp; rotating the offset
     * with the card would light each card from its own direction. */
    ctx.shadowColor = 'rgba(12, 7, 5, 0.55)';
    ctx.shadowBlur = Math.max(4, w * 0.05);
    ctx.shadowOffsetX = Math.max(2, w * 0.022);
    ctx.shadowOffsetY = Math.max(3, w * 0.03);
    ctx.fillStyle = g;
    ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.beginPath();
    R.rrect(ctx, 0, 0, w, h, 2);
    ctx.clip();
    var prng = R.rngFrom(R.hash('card|' + p.name));
    R.stipple(ctx, w / 2, h / 2, w * 0.7, h * 0.7, prng, Math.round(w * h / 90), 0.5, '#B9A98F', '#FFFFFF', 0.18);
    ctx.restore();
    ctx.beginPath();
    R.rrect(ctx, 0.5, 0.5, w - 1, h - 1, 2);
    ctx.strokeStyle = R.rgba(R.shade(R.P.shadow, -0.25), 0.55);
    ctx.lineWidth = 1;
    ctx.stroke();

    var ink = R.pickContrast(R.P.cream, R.P.char, '#FFFFFF', 4.5).ink;
    ctx.textBaseline = 'alphabetic';
    ctx.textAlign = 'left';
    var fit = R.fitText(ctx, p.name, w - pad * 2, 'menu', titleSize, '', 11);
    ctx.font = R.font('menu', fit.px, '');
    ctx.fillStyle = ink;
    ctx.fillText(p.name, pad, pad + fit.px);

    /* the hairline rule under the name, with a small lozenge at its middle —
     * the card's one piece of furniture */
    var ruleY = pad + fit.px + Math.max(6, fit.px * 0.38);
    ctx.beginPath();
    ctx.moveTo(pad, ruleY);
    ctx.lineTo(w - pad, ruleY);
    ctx.strokeStyle = R.rgba(ink, 0.40);
    ctx.lineWidth = 0.8;
    ctx.stroke();
    var lz = Math.max(2.2, w * 0.014);
    ctx.beginPath();
    ctx.moveTo(w / 2 - lz * 1.6, ruleY);
    ctx.lineTo(w / 2, ruleY - lz);
    ctx.lineTo(w / 2 + lz * 1.6, ruleY);
    ctx.lineTo(w / 2, ruleY + lz);
    ctx.closePath();
    ctx.fillStyle = R.P.cream;
    ctx.fill();
    ctx.fillStyle = R.P.sauce;
    ctx.beginPath();
    ctx.moveTo(w / 2 - lz * 1.1, ruleY);
    ctx.lineTo(w / 2, ruleY - lz * 0.7);
    ctx.lineTo(w / 2 + lz * 1.1, ruleY);
    ctx.lineTo(w / 2, ruleY + lz * 0.7);
    ctx.closePath();
    ctx.fill();

    ctx.font = R.font('note', bodySize, '');
    ctx.fillStyle = R.rgba(ink, 0.82);
    for (var i = 0; i < lines.length; i++) {
      var text = lines[i];
      var lf = R.fitText(ctx, text, w - pad * 2, 'note', bodySize, '', 8);
      ctx.font = R.font('note', lf.px, '');
      ctx.fillText(text, pad, ruleY + bodySize * 1.6 + i * bodySize * pitch);
    }
    if (p.ingredientNames.length > lines.length) {
      ctx.font = R.font('note', bodySize * 0.92, 'italic');
      ctx.fillStyle = R.rgba(ink, 0.55);
      ctx.fillText('and ' + (p.ingredientNames.length - lines.length) + ' more',
        pad, ruleY + bodySize * 1.6 + lines.length * bodySize * pitch);
    }
    ctx.restore();
    return { w: w, h: h };
  }

  /**
   * Draw one complete plate. This is the product.
   *
   * @param {object} ctx Canvas 2D context (MZ: `bitmap.context`).
   * @param {object} profile A RefectoryDish profile.
   * @param {object} g {cx, cy, r} — plate centre and radius in pixels.
   * @param {object} [opt] {steamPhase:number, noSteam:boolean}
   * @returns {object} The well geometry, for anything that wants to sit on it.
   */
  function plate(ctx, profile, g, opt) {
    var R = deps();
    var o = opt || {};
    var rng = R.rngFrom(profile.seed);
    var V = VESSEL_DRAW[profile.vessel] || VESSEL_DRAW.platter;
    var w = V.base(ctx, g, profile, rng);
    var C = COMPONENT_DRAW[profile.component] || COMPONENT_DRAW.roast;
    /* the sauce goes UNDER everything except the components that own their own
     * liquid (a stew is not a joint sitting in gravy) */
    var ownsLiquid = profile.component === 'stew' || profile.component === 'soup'
      || profile.component === 'broth' || profile.component === 'drink'
      || profile.component === 'noodles' || profile.component === 'porridge'
      || (profile.component === 'preserves' && !!w.surface);
    ctx.save();
    if (w.clip) {
      ctx.beginPath();
      w.clip(ctx);
      ctx.clip();
    }
    if (!ownsLiquid) pool(ctx, w, profile, rng, 1);
    C(ctx, w, profile, rng);
    /* the finish AFTER the food, because a finish lies on top of it — and for a
     * dry component this is the only place the finish exists at all */
    dryFinish(ctx, w, profile, rng);
    powderVeil(ctx, w, profile);
    garnish(ctx, w, profile, rng);
    ctx.restore();
    if (V.over) V.over(ctx, g, w);
    if (!o.noSteam) steam(ctx, w, profile, rng, o.steamPhase);
    return w;
  }

  return {
    table: table,
    plate: plate,
    card: card,
    steam: steam,
    pool: pool,
    dryFinish: dryFinish,
    powderVeil: powderVeil,
    garnish: garnish,
    GROUNDS: GROUNDS,
    GROUND_IDS: GROUND_IDS,
    mass: mass,
    solid: solid,
    ceramic: ceramic,
    woodGrain: woodGrain,
    pieceKind: pieceKind,
    roastForm: roastForm,
    filletForm: filletForm,
    loafForm: loafForm,
    pieForm: pieForm,
    VESSEL_DRAW: VESSEL_DRAW,
    COMPONENT_DRAW: COMPONENT_DRAW,
    GARNISH_DRAW: GARNISH_DRAW,
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.RefectoryPlate;
