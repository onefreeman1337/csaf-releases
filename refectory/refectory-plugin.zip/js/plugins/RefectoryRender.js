//=============================================================================
// RefectoryRender.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc Refectory [1/4] — drawing primitives. One light, the pantry palette, seeded RNG, lit masses, garnish placement rules, the shipped typefaces. v1.0.0
 * @author CSAF — Core Systems Asset Factory
 * @url https://csaf.itch.io
 *
 * @help
 * ============================================================================
 * Refectory — drawing primitives
 * ============================================================================
 * Load this FIRST. It defines no scene and patches no core method; it is the
 * pen every other file draws with.
 *
 * Nothing here knows what a dish is. It knows table, light, ink and the one
 * thing food needs and a silhouette cannot give it: interior detail under a
 * single fixed light.
 * ============================================================================
 */

/* ⛔ ATTACH TO THE GLOBAL EXPLICITLY. In MZ every plugin is a <script> tag so a
 * top-level `var` IS a global; under Node's `require` it is module-scoped, so
 * each file would get its OWN `CSAF`, `deps()` would never find a sibling, and
 * the headless suite would exercise a DIFFERENT code path from the engine —
 * exactly the shape wing §11 bans. Measured on Glaze, 2026-08-29. */
if (typeof globalThis.CSAF === 'undefined') globalThis.CSAF = {};
var CSAF = globalThis.CSAF;

CSAF.RefectoryRender = (function () {
  'use strict';

  /* ------------------------------------------------------------- the light --
   * ⛔ ONE LIGHT DIRECTION FOR THE WHOLE PACK (design brief, Craft_Doctrine
   * `lighting-direction`). Upper left, stated once, and every highlight, every
   * relief and every contact shadow in the product derives from THIS rather
   * than from a per-call guess. A plate lit from two directions reads as a
   * collage, and no counter in this factory can see that. */
  var LIGHT = { x: -0.60, y: -0.80 };

  /* ------------------------------------------------------------- the palette --
   * The design brief's eight, named once. ⛔ wing §11a: a second copy of a
   * constant does not drift, it WINS — so nothing else in this product types a
   * hex string for these. */
  var P = {
    table: '#3B2A24',   // walnut ground
    bone: '#EDE3D1',    // ceramic
    shadow: '#B9A98F',  // glaze shadow
    cream: '#F6EFE2',   // card paper
    sauce: '#8C3B22',   // sauce oxide
    roast: '#D08A3C',   // roast gold
    herb: '#5E7F3A',    // herb
    char: '#2B1E19',    // char
  };

  /* ------------------------------------------------------------- the faces --
   * ⛔ wing §15a: `windowsDrawn: 0` IS BLIND TO THE FONT. MZ's own
   * `$gameSystem.mainFontFace()` is the loudest "this is RPG Maker" signal
   * there is and a product can pass every mechanical gate while using it. The
   * rule is not merely to avoid that face, it is to require A STACK YOU CHOSE.
   *
   * These two families are loaded by `ensureFonts()` from woff2 files shipped
   * inside the product. Each stack keeps real fallbacks so a buyer who has not
   * copied the fonts across still gets a serif menu card and a humanist sans
   * ingredient list — degraded, never broken, never MZ's monospace. */
  var MENU_FAMILY = 'RefectoryMenu';
  var NOTE_FAMILY = 'RefectoryNote';
  var FACES = {
    menu: '"' + MENU_FAMILY + '", "Cormorant Garamond", Garamond, Georgia, "Times New Roman", serif',
    note: '"' + NOTE_FAMILY + '", "Alegreya Sans", "Segoe UI", "Helvetica Neue", Arial, sans-serif',
  };

  /**
   * Load the two shipped faces, once, without ever being able to break a boot.
   *
   * ⛔ DO NOT USE `FontManager.load` FOR AN OPTIONAL SHIPPED FONT. MEASURED in
   * the engine source, `rmmz_managers.js:806-839`: a failed load sets
   * `FontManager._states[family] = "error"`, and `FontManager.isReady()` — which
   * `Scene_Boot` polls every frame — calls `throwLoadError()`, which THROWS. A
   * buyer who installs the plugin and forgets to copy `fonts/` would get a
   * crashed title screen rather than a fallback typeface. `new FontFace(...)`
   * with our own `.catch()` cannot do that: `document.fonts` is untouched on
   * failure and the CSS stack above falls through.
   *
   * @param {string} [dir] Folder the faces live in, relative to the game root.
   * @returns {boolean} true if loading was started (or already done).
   */
  var _fontState = 'idle';
  function ensureFonts(dir) {
    if (_fontState !== 'idle') return true;
    if (typeof document === 'undefined' || typeof FontFace === 'undefined') {
      _fontState = 'unavailable';
      return false;
    }
    _fontState = 'loading';
    /* ⛔ No regex here. The first version was `.replace(/\/*$/, '/')`, and the
     * slash-star inside that literal reads as a BLOCK-COMMENT OPENER to any
     * source scanner that strips comments — plate.test.js's did, ate the rest of
     * this file, and reported the FontFace loader missing (MEASURED 2026-09-10). */
    var base = String(dir || 'fonts/');
    if (base.charAt(base.length - 1) !== '/') base += '/';
    var want = [
      [MENU_FAMILY, base + 'Refectory-Menu.woff2'],
      [NOTE_FAMILY, base + 'Refectory-Note.woff2'],
    ];
    var done = 0;
    for (var i = 0; i < want.length; i++) {
      (function (family, url) {
        try {
          var face = new FontFace(family, 'url(' + url + ')');
          face.load().then(function (f) {
            document.fonts.add(f);
            done++;
            if (done === want.length) _fontState = 'loaded';
            return 0;
          }).catch(function () {
            /* ⛔ Silent by design. The stack falls back; the game does not stop. */
            _fontState = 'fallback';
          });
        } catch (e) {
          _fontState = 'fallback';
        }
      })(want[i][0], want[i][1]);
    }
    return true;
  }

  /** @returns {string} idle | loading | loaded | fallback | unavailable */
  function fontState() { return _fontState; }

  /**
   * Build a font string from a chosen stack. Nothing in this product types a
   * font string any other way, so the two halves of one drawing cannot ask for
   * different typefaces (wing §15a, the Hearsay label defect).
   * @param {string} which 'menu' or 'note'
   * @param {number} px Pixel size.
   * @param {string} [style] e.g. 'italic' or 'bold'.
   * @returns {string} A CSS font string.
   */
  function font(which, px, style) {
    var stack = FACES[which] || FACES.note;
    return (style ? style + ' ' : '') + Math.round(px) + 'px ' + stack;
  }

  /* --------------------------------------------------------------- identity --
   * FNV-1a. ⛔ `Math.random()` appears NOWHERE in this product: the same
   * ingredients must plate identically every time or a player's screenshot is
   * not reproducible, a save/load changes the picture, and the capture pipeline
   * cannot pin a frame (wing §6 rule 2, §15e). */
  function hash(str) {
    var h = 0x811c9dc5;
    var s = String(str);
    for (var i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
    }
    return h >>> 0;
  }

  /**
   * A deterministic stream from a seed. mulberry32.
   * @param {number|string} seed Any seed.
   * @returns {function():number} Next float in [0,1).
   */
  function rngFrom(seed) {
    var a = (typeof seed === 'number' ? seed : hash(seed)) >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ---------------------------------------------------------------- colour -- */

  /** @param {string} hex '#rrggbb' @returns {{r:number,g:number,b:number}} */
  function parse(hex) {
    var s = String(hex).replace('#', '');
    if (s.length === 3) s = s[0] + s[0] + s[1] + s[1] + s[2] + s[2];
    var n = parseInt(s, 16);
    if (isNaN(n)) return { r: 0, g: 0, b: 0 };
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }

  /** @param {{r:number,g:number,b:number}} c @returns {string} '#rrggbb' */
  function css(c) {
    function q(v) { var x = Math.max(0, Math.min(255, Math.round(v))).toString(16); return x.length < 2 ? '0' + x : x; }
    return '#' + q(c.r) + q(c.g) + q(c.b);
  }

  /** @param {{r,g,b}|string} c @param {number} a 0..1 @returns {string} rgba() */
  function rgba(c, a) {
    var o = typeof c === 'string' ? parse(c) : c;
    return 'rgba(' + Math.round(o.r) + ',' + Math.round(o.g) + ',' + Math.round(o.b) + ',' + (Math.round(a * 1000) / 1000) + ')';
  }

  /** Linear blend. @param {string} a @param {string} b @param {number} t @returns {string} hex */
  function mix(a, b, t) {
    var x = parse(a); var y = parse(b);
    var u = Math.max(0, Math.min(1, t));
    return css({ r: x.r + (y.r - x.r) * u, g: x.g + (y.g - x.g) * u, b: x.b + (y.b - x.b) * u });
  }

  /** Toward white (amt>0) or char (amt<0). @param {string} c @param {number} amt @returns {string} */
  function shade(c, amt) {
    return amt >= 0 ? mix(c, '#FFFFFF', amt) : mix(c, P.char, -amt);
  }

  /** @param {string} c @returns {number} WCAG relative luminance 0..1 */
  function relLum(c) {
    var o = parse(c);
    function ch(v) { var s = v / 255; return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4); }
    return 0.2126 * ch(o.r) + 0.7152 * ch(o.g) + 0.0722 * ch(o.b);
  }

  /** @param {string} a @param {string} b @returns {number} contrast ratio 1..21 */
  function contrastRatio(a, b) {
    var x = relLum(a); var y = relLum(b);
    var hi = Math.max(x, y); var lo = Math.min(x, y);
    return (hi + 0.05) / (lo + 0.05);
  }

  /**
   * Pick an ink that can actually be read on a ground.
   *
   * ⛔ wing §25h: a plain average picks the WRONG direction because contrast is
   * gamma-expanded — BLACK was chosen at 4.01:1 where WHITE was worth 5.24:1.
   * ⛔ And the bar is `min(want, what the surface allows)`: a flat 7:1 demand
   * goes red on a legitimate mid-tone ground. Try both directions, keep the
   * first that clears, else keep the better one, and let the caller ask what it
   * actually got.
   *
   * @param {string} ground The colour the ink lands on.
   * @param {string} dark Candidate dark ink.
   * @param {string} light Candidate light ink.
   * @param {number} [want] Wanted ratio, default 4.5 (AA).
   * @returns {{ink:string, ratio:number, met:boolean}} The choice and its ratio.
   */
  function pickContrast(ground, dark, light, want) {
    var target = want || 4.5;
    var dr = contrastRatio(ground, dark);
    var lr = contrastRatio(ground, light);
    var best = dr >= lr ? { ink: dark, ratio: dr } : { ink: light, ratio: lr };
    var first = dr >= target ? { ink: dark, ratio: dr } : (lr >= target ? { ink: light, ratio: lr } : null);
    var out = first || best;
    return { ink: out.ink, ratio: Math.round(out.ratio * 100) / 100, met: out.ratio >= target };
  }

  /* ------------------------------------------------------------------ form -- */

  /**
   * An irregular closed outline. Food is never an ellipse; an ellipse is the
   * fastest way to make a render read as a diagram (design brief, Avoid).
   *
   * @param {object} ctx Canvas 2D context.
   * @param {number} cx Centre x.
   * @param {number} cy Centre y.
   * @param {number} rx Radius x.
   * @param {number} ry Radius y.
   * @param {function():number} rng Seeded stream.
   * @param {number} [wobble] 0..1 irregularity, default 0.16.
   * @param {number} [lobes] Control points, default 9.
   * @param {number} [rot] Rotation in radians.
   * @returns {void}
   */
  function blob(ctx, cx, cy, rx, ry, rng, wobble, lobes, rot) {
    ctx.beginPath();
    smoothPath(ctx, blobPts(cx, cy, rx, ry, rng, wobble, lobes, rot));
  }

  /**
   * The points of an irregular closed outline, generated ONCE so the same
   * outline can be filled, clipped and shaded. ⛔ The first build regenerated a
   * blob from a fresh stream to clip its fibres, so the texture was clipped to
   * a DIFFERENT outline from the one that was filled (MEASURED 2026-09-10, art
   * stage): generate the points once and re-issue them.
   * @returns {Array<Array<number>>} [[x,y], ...]
   */
  function blobPts(cx, cy, rx, ry, rng, wobble, lobes, rot) {
    var w = wobble === undefined ? 0.16 : wobble;
    var n = lobes || 9;
    var a0 = rot || 0;
    var pts = [];
    for (var i = 0; i < n; i++) {
      var a = a0 + (i / n) * Math.PI * 2;
      var k = 1 + (rng() - 0.5) * 2 * w;
      pts.push([cx + Math.cos(a) * rx * k, cy + Math.sin(a) * ry * k]);
    }
    return pts;
  }

  /**
   * Add a closed Catmull-Rom curve through `pts` to the current path — no
   * `beginPath`, so it can be combined with other subpaths (a frame with a hole,
   * a clip that is a union). Emitted as cubic Béziers, so the outline is smooth
   * rather than faceted at any size.
   * @param {object} ctx Context.
   * @param {Array<Array<number>>} pts Points, at least 3.
   * @returns {void}
   */
  function smoothPath(ctx, pts) {
    var n = pts.length;
    for (var j = 0; j < n; j++) {
      var p0 = pts[(j - 1 + n) % n];
      var p1 = pts[j];
      var p2 = pts[(j + 1) % n];
      var p3 = pts[(j + 2) % n];
      if (j === 0) ctx.moveTo(p1[0], p1[1]);
      ctx.bezierCurveTo(
        p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6,
        p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6,
        p2[0], p2[1]
      );
    }
    ctx.closePath();
  }

  /**
   * Add a rounded rectangle to the current path. ⛔ Not `ctx.roundRect`: it is
   * absent from the Chromium in older MZ builds, and the fallback silently
   * drew square corners. ⛔ wing §8 trap 3: `arcTo` THROWS on a negative
   * radius, so the radius is clamped to [0, min(w, h) / 2].
   * @returns {void}
   */
  function rrect(ctx, x, y, w, h, r) {
    var rr = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.moveTo(x + rr, y);
    ctx.lineTo(x + w - rr, y);
    ctx.arcTo(x + w, y, x + w, y + rr, rr);
    ctx.lineTo(x + w, y + h - rr);
    ctx.arcTo(x + w, y + h, x + w - rr, y + h, rr);
    ctx.lineTo(x + rr, y + h);
    ctx.arcTo(x, y + h, x, y + h - rr, rr);
    ctx.lineTo(x, y + rr);
    ctx.arcTo(x, y, x + rr, y, rr);
    ctx.closePath();
  }

  /**
   * Shade the INSIDE of a shape from its edges — the cue that turns a filled
   * outline into a solid. The side away from the light falls into a core
   * shadow; the side toward it catches a rim of light. A radial fill alone
   * cannot do this: it lights the middle and leaves every edge the same, which
   * is exactly what made the first roast read as three flat lumps.
   *
   * The classic inner-shadow construction: clip to the shape, then fill a frame
   * AROUND it (a rectangle with the shape as an even-odd hole) with a canvas
   * shadow. The frame itself is clipped away; only its blurred, offset shadow
   * lands inside. ⛔ `shadowOffset` and `shadowBlur` are NOT transformed by the
   * current matrix (canvas spec) — which is what we want: the light is fixed in
   * SCREEN space whatever an object is rotated to.
   *
   * @param {object} ctx Context.
   * @param {function(object):void} pathFn Adds the shape's subpaths; never calls beginPath.
   * @param {number} bx Bounds x (in the CURRENT coordinate space).
   * @param {number} by Bounds y.
   * @param {number} bw Bounds width.
   * @param {number} bh Bounds height.
   * @param {object} [o] {depth, blur, dark, darkA, light, lightA, invert}
   *   `invert` shades a CONCAVE form (a well): dark toward the light.
   * @returns {void}
   */
  function innerShade(ctx, pathFn, bx, by, bw, bh, o) {
    var opt = o || {};
    var depth = opt.depth === undefined ? Math.max(2, Math.min(bw, bh) * 0.10) : opt.depth;
    var blur = opt.blur === undefined ? depth * 1.4 : opt.blur;
    var sgn = opt.invert ? -1 : 1;
    var pad = depth * 2 + blur * 2 + 6;
    ctx.save();
    ctx.beginPath();
    pathFn(ctx);
    ctx.clip();
    ctx.fillStyle = '#000000';
    if ((opt.darkA === undefined ? 0.5 : opt.darkA) > 0) {
      ctx.beginPath();
      ctx.rect(bx - pad, by - pad, bw + pad * 2, bh + pad * 2);
      pathFn(ctx);
      ctx.shadowColor = rgba(opt.dark || P.char, opt.darkA === undefined ? 0.5 : opt.darkA);
      ctx.shadowBlur = blur;
      ctx.shadowOffsetX = sgn * LIGHT.x * depth;
      ctx.shadowOffsetY = sgn * LIGHT.y * depth;
      ctx.fill('evenodd');
    }
    if (opt.lightA && opt.lightA > 0) {
      ctx.beginPath();
      ctx.rect(bx - pad, by - pad, bw + pad * 2, bh + pad * 2);
      pathFn(ctx);
      ctx.shadowColor = rgba(opt.light || '#FFFFFF', opt.lightA);
      ctx.shadowBlur = blur * 0.7;
      ctx.shadowOffsetX = -sgn * LIGHT.x * depth * 0.55;
      ctx.shadowOffsetY = -sgn * LIGHT.y * depth * 0.55;
      ctx.fill('evenodd');
    }
    ctx.restore();
  }

  /**
   * A sharp specular glint: the small, bright, hard-edged highlight that says
   * WET. The first build's only highlight was a large soft white blob, which is
   * what plastic looks like.
   * @param {object} ctx Context.
   * @param {number} x Centre x.
   * @param {number} y Centre y.
   * @param {number} rx Half-length.
   * @param {number} ry Half-width.
   * @param {number} rot Rotation.
   * @param {number} a Peak alpha 0..1.
   * @returns {void}
   */
  function glint(ctx, x, y, rx, ry, rot, a) {
    if (!(a > 0.01) || !(rx > 0.2)) return;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rot || 0);
    ctx.scale(1, Math.max(0.05, ry / rx));
    var g = ctx.createRadialGradient(0, 0, 0, 0, 0, rx);
    g.addColorStop(0, rgba('#FFFFFF', a));
    g.addColorStop(0.45, rgba('#FFFFFF', a * 0.55));
    g.addColorStop(1, rgba('#FFFFFF', 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, rx, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  /**
   * A soft disc — steam, glow, a pool of lamplight. Radial falloff to zero, so
   * overlapping puffs build a cloud with no edge anywhere.
   * @returns {void}
   */
  function puff(ctx, x, y, r, colour, a) {
    if (!(r > 0.3) || !(a > 0.003)) return;
    var g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, rgba(colour, a));
    g.addColorStop(0.55, rgba(colour, a * 0.45));
    g.addColorStop(1, rgba(colour, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  /**
   * Texture: `n` small marks inside an ellipse (the caller clips to the real
   * outline). Marks on the lit side take `light`, the rest `dark`, so a crumb or
   * a sear follows the form instead of lying on it like a sticker.
   * @param {object} ctx Context.
   * @param {number} cx Centre x.
   * @param {number} cy Centre y.
   * @param {number} rx Radius x.
   * @param {number} ry Radius y.
   * @param {function():number} rng Seeded stream.
   * @param {number} n How many.
   * @param {number} size Mark radius.
   * @param {string} dark Ink for the shaded side.
   * @param {string} light Ink for the lit side.
   * @param {number} [a] Alpha scale, default 0.35.
   * @returns {void}
   */
  function stipple(ctx, cx, cy, rx, ry, rng, n, size, dark, light, a) {
    var al = a === undefined ? 0.35 : a;
    for (var i = 0; i < n; i++) {
      var ang = rng() * Math.PI * 2;
      var rr = Math.sqrt(rng());
      var x = Math.cos(ang) * rr;
      var y = Math.sin(ang) * rr;
      var lit = (x * LIGHT.x + y * LIGHT.y) > (rng() - 0.5) * 0.8;
      ctx.beginPath();
      ctx.ellipse(cx + x * rx, cy + y * ry, size * (0.5 + rng() * 0.8), size * (0.4 + rng() * 0.6),
        rng() * Math.PI, 0, Math.PI * 2);
      ctx.fillStyle = rgba(lit ? light : dark, al * (0.45 + rng() * 0.55));
      ctx.fill();
    }
  }

  /**
   * Fill the current path as a lit mass: a radial gradient whose hot spot sits
   * toward the light and whose far side falls to a shaded version of the same
   * colour. This is the single most important primitive in the product — a flat
   * one-colour fill is the "brown smear" the brief bans.
   *
   * @param {object} ctx Context (path already built).
   * @param {number} cx Mass centre x.
   * @param {number} cy Mass centre y.
   * @param {number} r Mass radius.
   * @param {string} base Local colour.
   * @param {object} [opt] {lift:number, drop:number, spec:number}
   * @returns {void}
   */
  function litFill(ctx, cx, cy, r, base, opt) {
    var o = opt || {};
    var lift = o.lift === undefined ? 0.28 : o.lift;
    var drop = o.drop === undefined ? 0.34 : o.drop;
    var hx = cx + LIGHT.x * r * 0.45;
    var hy = cy + LIGHT.y * r * 0.45;
    var g = ctx.createRadialGradient(hx, hy, Math.max(1, r * 0.06), cx, cy, Math.max(2, r * 1.12));
    g.addColorStop(0, shade(base, lift));
    g.addColorStop(0.45, base);
    g.addColorStop(1, shade(base, -drop));
    ctx.fillStyle = g;
    ctx.fill();
  }

  /**
   * The shadow a solid object casts on the table, offset away from the light.
   * @param {object} ctx Context.
   * @param {number} cx Centre x.
   * @param {number} cy Centre y.
   * @param {number} rx Radius x.
   * @param {number} ry Radius y.
   * @param {number} [strength] 0..1 opacity at the core, default 0.5.
   * @returns {void}
   */
  function contactShadow(ctx, cx, cy, rx, ry, strength) {
    var s = strength === undefined ? 0.5 : strength;
    var a = Math.max(1, rx);
    var ox = cx - LIGHT.x * a * 0.10;
    var oy = cy - LIGHT.y * Math.max(1, ry) * 0.18;
    /* ⛔ THE GRADIENT MUST BE ELLIPTICAL. The first build drew a CIRCULAR
     * gradient of radius rx clipped to a flat ellipse, so the falloff was cut
     * off at the top and bottom while still at ~80% — a hard-edged dark band
     * under every vessel (seen in-engine under the board, 2026-09-10 art
     * stage). Scaling the space makes the falloff reach zero on every side. */
    ctx.save();
    ctx.translate(ox, oy);
    ctx.scale(1, Math.max(0.05, Math.max(1, ry) / a));
    var g = ctx.createRadialGradient(0, 0, 0, 0, 0, a * 1.2);
    g.addColorStop(0, rgba('#120B08', s));
    g.addColorStop(0.5, rgba('#120B08', s * 0.55));
    g.addColorStop(1, rgba('#120B08', 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, a * 1.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  /**
   * Garnish placement. ⛔ The design brief bans a lattice and bans dead centre;
   * this is the rule that keeps a scatter looking SET rather than sprinkled by
   * a loop: dart throwing with a minimum separation, an annulus preference so
   * marks sit where a cook would put them, and a hashed jitter per mark.
   *
   * Allocates. ⛔ That is deliberate and safe: every caller runs at BAKE time,
   * never inside `update()` (wing §3, zero allocation in per-frame hot paths).
   *
   * @param {function():number} rng Seeded stream.
   * @param {number} n How many marks.
   * @param {object} [opt] {rMin, rMax, sep, tries}
   * @returns {Array<{x:number,y:number,a:number,s:number}>} Unit-disc placements.
   */
  function scatter(rng, n, opt) {
    var o = opt || {};
    var rMin = o.rMin === undefined ? 0.30 : o.rMin;   // never dead centre
    var rMax = o.rMax === undefined ? 0.92 : o.rMax;
    var sep = o.sep === undefined ? 0.22 : o.sep;
    var tries = o.tries || 24;
    var out = [];
    for (var i = 0; i < n; i++) {
      var placed = null;
      for (var t = 0; t < tries; t++) {
        var ang = rng() * Math.PI * 2;
        /* sqrt keeps the density even across the annulus instead of piling up
         * at the inner edge, which is what a naive uniform radius does. */
        var rad = Math.sqrt(rMin * rMin + rng() * (rMax * rMax - rMin * rMin));
        var x = Math.cos(ang) * rad;
        var y = Math.sin(ang) * rad * 0.82;   // the plate is seen at an angle
        var ok = true;
        for (var j = 0; j < out.length; j++) {
          var dx = out[j].x - x; var dy = out[j].y - y;
          if (dx * dx + dy * dy < sep * sep) { ok = false; break; }
        }
        if (ok) { placed = { x: x, y: y, a: rng() * Math.PI, s: 0.7 + rng() * 0.6 }; break; }
      }
      if (placed) out.push(placed);
    }
    return out;
  }

  /* ------------------------------------------------------------------ type -- */

  /**
   * Shrink type until it fits, and report what it settled on.
   * ⛔ wing §21h: the assert that pins a caption must run at PRODUCT size, so
   * this returns the size rather than silently clipping.
   * @param {object} ctx Context.
   * @param {string} text The words.
   * @param {number} maxW Available width.
   * @param {string} which 'menu' or 'note'.
   * @param {number} px Wanted size.
   * @param {string} [style] Font style.
   * @param {number} [floor] Smallest acceptable size, default 9.
   * @returns {{px:number, width:number, fitted:boolean}} What it settled on.
   */
  function fitText(ctx, text, maxW, which, px, style, floor) {
    var lo = floor || 9;
    var size = Math.round(px);
    for (; size >= lo; size--) {
      ctx.font = font(which, size, style);
      if (ctx.measureText(text).width <= maxW) {
        return { px: size, width: ctx.measureText(text).width, fitted: true };
      }
    }
    ctx.font = font(which, lo, style);
    return { px: lo, width: ctx.measureText(text).width, fitted: false };
  }

  /**
   * Wrap words to a width at a fixed size.
   * @param {object} ctx Context with `font` already set.
   * @param {string} text The words.
   * @param {number} maxW Available width.
   * @param {number} [maxLines] Cap; the last line gets an ellipsis.
   * @returns {string[]} The lines.
   */
  function wrap(ctx, text, maxW, maxLines) {
    var words = String(text).split(/\s+/).filter(Boolean);
    var lines = [];
    var line = '';
    for (var i = 0; i < words.length; i++) {
      var next = line ? line + ' ' + words[i] : words[i];
      if (ctx.measureText(next).width <= maxW || !line) {
        line = next;
      } else {
        lines.push(line);
        line = words[i];
        if (maxLines && lines.length >= maxLines) break;
      }
    }
    if (line && (!maxLines || lines.length < maxLines)) lines.push(line);
    if (maxLines && lines.length >= maxLines && words.length) {
      var last = lines[lines.length - 1];
      while (last.length > 1 && ctx.measureText(last + '…').width > maxW) last = last.slice(0, -1);
      var joined = lines.join(' ');
      if (joined.split(/\s+/).length < words.length) lines[lines.length - 1] = last + '…';
    }
    return lines;
  }

  /* ------------------------------------------------------------ instrument --
   * A context that draws nothing and counts everything. The headless suite uses
   * it to ask wing §25a's question — does this declared value actually LAND A
   * MARK, and does the mark CHANGE when the field changes — without needing a
   * canvas. ⛔ It is not a substitute for looking at pixels (§25a: a TYPE is
   * not a draw call, and an op counter proves a call happened, never that a
   * pixel changed, §17c-1). The pixel arm lives in `_probe/`. */
  function Counted() {
    var self = {
      ops: 0,
      counts: {},
      inks: [],
      texts: [],
      /* ⛔ GEOMETRY, NOT JUST CALL COUNTS. MEASURED 2026-09-10: with counts
       * alone, three different sauce behaviours produced byte-identical
       * signatures — same calls, different SIZES — and the probe reported them
       * as dead values. An op counter proves a call happened, never that a
       * pixel changed (wing §17c-1); recording the numbers the call was made
       * with is the cheapest instrument that can tell a bigger pool from a
       * smaller one. It is still not a pixel. */
      geom: [],
      _bump: function (k) { this.ops++; this.counts[k] = (this.counts[k] || 0) + 1; },
      _args: function (k, a) {
        this.geom.push(k);
        for (var i = 0; i < a.length; i++) {
          if (typeof a[i] === 'number' && isFinite(a[i])) this.geom.push(Math.round(a[i] * 50) / 50);
        }
      },
    };
    var METHODS = ['beginPath', 'closePath', 'moveTo', 'lineTo', 'bezierCurveTo', 'quadraticCurveTo',
      'arc', 'arcTo', 'ellipse', 'rect', 'roundRect', 'fill', 'stroke', 'clip', 'save', 'restore',
      'translate', 'rotate', 'scale', 'setTransform', 'resetTransform', 'setLineDash',
      'fillRect', 'strokeRect', 'clearRect', 'drawImage'];
    METHODS.forEach(function (m) {
      self[m] = function () {
        self._bump(m);
        self._args(m, arguments);
        if (m === 'fill' || m === 'stroke') {
          /* through the getters defined below, never the private stores */
          var ink = m === 'fill' ? self.fillStyle : self.strokeStyle;
          self.inks.push(typeof ink === 'string' ? ink : 'gradient');
        }
      };
    });
    self.fillText = function (t, x, y) {
      self._bump('fillText'); self.texts.push(String(t)); self._args('text', [x, y]);
    };
    self.strokeText = function (t, x, y) {
      self._bump('strokeText'); self.texts.push(String(t)); self._args('text', [x, y]);
    };
    self.measureText = function (t) {
      /* A stable, monotonic stand-in. ⛔ wing §3a: this is NOT the engine's
       * metric and no test may assert a pixel width from it — it exists so
       * layout code can run headless. Real widths are measured in `_probe/`. */
      return { width: String(t).length * 0.52 * (self._fontPx || 12) };
    };
    self.createRadialGradient = function () {
      self._bump('gradient'); self._args('gradient', arguments);
      return { addColorStop: function (o, c) { self.inks.push('stop:' + o + ':' + c); } };
    };
    self.createLinearGradient = function () {
      self._bump('gradient'); self._args('lgradient', arguments);
      return { addColorStop: function (o, c) { self.inks.push('stop:' + o + ':' + c); } };
    };
    self.createPattern = function () { return null; };
    ['fillStyle', 'strokeStyle', 'globalAlpha', 'lineWidth', 'lineCap', 'lineJoin',
      'globalCompositeOperation', 'shadowColor', 'shadowBlur', 'textAlign', 'textBaseline',
      'shadowOffsetX', 'shadowOffsetY', 'miterLimit', 'filter'].forEach(function (prop) {
      var store = '_' + prop;
      Object.defineProperty(self, prop, {
        get: function () { return self[store]; },
        set: function (v) { self[store] = v; self._bump('set:' + prop); },
        configurable: true,
      });
    });
    Object.defineProperty(self, 'font', {
      get: function () { return self._font; },
      set: function (v) {
        self._font = v;
        var m = String(v).match(/(\d+(?:\.\d+)?)px/);
        self._fontPx = m ? Number(m[1]) : 12;
        self._bump('set:font');
      },
      configurable: true,
    });
    return self;
  }

  return {
    LIGHT: LIGHT,
    P: P,
    FACES: FACES,
    MENU_FAMILY: MENU_FAMILY,
    NOTE_FAMILY: NOTE_FAMILY,
    ensureFonts: ensureFonts,
    fontState: fontState,
    font: font,
    hash: hash,
    rngFrom: rngFrom,
    parse: parse,
    css: css,
    rgba: rgba,
    mix: mix,
    shade: shade,
    relLum: relLum,
    contrastRatio: contrastRatio,
    pickContrast: pickContrast,
    blob: blob,
    blobPts: blobPts,
    smoothPath: smoothPath,
    rrect: rrect,
    innerShade: innerShade,
    glint: glint,
    puff: puff,
    stipple: stipple,
    litFill: litFill,
    contactShadow: contactShadow,
    scatter: scatter,
    fitText: fitText,
    wrap: wrap,
    Counted: Counted,
  };
})();

// The headless suite requires this file directly. In MZ the export is inert.
if (typeof module !== 'undefined' && module.exports) module.exports = CSAF.RefectoryRender;
