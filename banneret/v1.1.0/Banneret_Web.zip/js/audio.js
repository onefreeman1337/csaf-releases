/* =====================================================================
   audio.js — BANNERET. Every sound in this game is synthesised at the
   moment it plays. There are no audio files in this product, which is why
   the whole thing is a few tens of kilobytes.

   The jam this ships into scores AUDIO as its own category, and most
   one-mechanic browser entries ship silence, so this is cheap ground to
   take. It is also the only channel that can tell the player something the
   picture cannot: a trample and a stall look similar for a frame, and they
   sound nothing alike.

   THE IFRAME RULE. itch embeds the game in a cross-origin <iframe> and
   browsers refuse to start an AudioContext there without a real user
   gesture. The title veil in index.html exists to be that gesture — the
   context is created on the first click and never before, so nothing here
   can produce the "AudioContext was not allowed to start" console warning
   that would (rightly) fail the boot gate.
   ===================================================================== */
'use strict';

(function (root) {

  var ctx = null;
  var master = null;
  var muted = false;

  function ensure() {
    if (ctx) return ctx;
    var AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.5;
    master.connect(ctx.destination);
    return ctx;
  }

  /* A short burst of filtered noise. Hooves, dust and impact are all this
     with different filters and envelopes — real percussive sound is mostly
     shaped noise, and a sample would not be any more convincing. */
  function noise(dur, type, freq, q, gain, when) {
    if (!ctx || muted) return;
    var n = Math.max(1, Math.floor(ctx.sampleRate * dur));
    var buf = ctx.createBuffer(1, n, ctx.sampleRate);
    var d = buf.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;

    var src = ctx.createBufferSource(); src.buffer = buf;
    var f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
    var g = ctx.createGain();
    var t = (when || ctx.currentTime);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(master);
    src.start(t); src.stop(t + dur + 0.02);
  }

  function tone(freq, dur, type, gain, when, bendTo) {
    if (!ctx || muted) return;
    var o = ctx.createOscillator();
    var g = ctx.createGain();
    o.type = type || 'sine';
    var t = when || ctx.currentTime;
    o.frequency.setValueAtTime(freq, t);
    if (bendTo) o.frequency.exponentialRampToValueAtTime(bendTo, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master);
    o.start(t); o.stop(t + dur + 0.03);
  }

  var API = {

    /* Called from the veil's click handler — the one real gesture we get. */
    unlock: function () {
      var c = ensure();
      if (c && c.state === 'suspended') c.resume();
      return !!c;
    },

    setMuted: function (m) { muted = !!m; if (master) master.gain.value = m ? 0 : 0.5; },
    isMuted: function () { return muted; },

    /* Wooden thunk of a staff going into the ground. */
    plant: function () {
      if (!ensure()) return;
      noise(0.09, 'lowpass', 420, 1.2, 0.32);
      tone(140, 0.12, 'triangle', 0.16, ctx.currentTime, 90);
    },

    /* The charge call. Two stacked fifths with a rising bend — a horn shape
       without pretending to be a sampled horn. */
    horn: function () {
      if (!ensure()) return;
      var t = ctx.currentTime;
      tone(196, 0.42, 'sawtooth', 0.10, t, 233);
      tone(294, 0.42, 'sawtooth', 0.07, t + 0.02, 349);
      tone(98,  0.46, 'triangle', 0.09, t);
    },

    /* Gallop: a run of hoof-beats whose spacing tightens with the number of
       tiles covered, so a long charge audibly builds speed. */
    gallop: function (tiles) {
      if (!ensure()) return;
      var t = ctx.currentTime;
      var n = Math.max(2, Math.min(10, tiles * 2));
      for (var i = 0; i < n; i++) {
        var at = t + i * (0.075 - Math.min(0.03, i * 0.004));
        noise(0.045, 'bandpass', 180 + (i % 2) * 90, 1.6, 0.16, at);
      }
    },

    /* Trample. Low body-blow plus a bright shatter of mail — deliberately
       the most satisfying sound in the game, because it is the goal. */
    trample: function () {
      if (!ensure()) return;
      var t = ctx.currentTime;
      noise(0.22, 'lowpass', 260, 0.9, 0.55, t);
      noise(0.16, 'highpass', 2600, 0.7, 0.20, t + 0.01);
      tone(72, 0.26, 'triangle', 0.34, t, 44);
    },

    /* A charge that never started. Dead, metallic, and nothing like a
       trample — the player should be able to hear the mistake with their
       eyes shut. */
    stall: function () {
      if (!ensure()) return;
      var t = ctx.currentTime;
      noise(0.30, 'bandpass', 1500, 8, 0.24, t);
      tone(150, 0.5, 'square', 0.10, t, 74);
      tone(151.5, 0.5, 'square', 0.08, t, 73);   /* a beat against the above */
    },

    /* Level cleared — a plain rising triad, played once, no loop. */
    clear: function () {
      if (!ensure()) return;
      var t = ctx.currentTime;
      [262, 330, 392, 523].forEach(function (f, i) {
        tone(f, 0.55 - i * 0.06, 'triangle', 0.15, t + i * 0.075);
      });
    },

    /* Out of charges. */
    fail: function () {
      if (!ensure()) return;
      var t = ctx.currentTime;
      [330, 294, 233].forEach(function (f, i) {
        tone(f, 0.4, 'triangle', 0.13, t + i * 0.11, f * 0.94);
      });
    },

    /* The whole field is taken. */
    victory: function () {
      if (!ensure()) return;
      var t = ctx.currentTime;
      [262, 392, 523, 659, 784].forEach(function (f, i) {
        tone(f, 0.9 - i * 0.08, 'triangle', 0.15, t + i * 0.11);
        tone(f / 2, 0.9, 'sine', 0.07, t + i * 0.11);
      });
    },

    /* Cursor moving between tiles. Very quiet on purpose — it should read as
       texture, not as feedback. */
    tick: function () {
      if (!ensure()) return;
      noise(0.02, 'highpass', 5200, 0.7, 0.035);
    }
  };

  root.Snd = API;

})(typeof window !== 'undefined' ? window : globalThis);
