/* =====================================================================
   levels.js — GENERATED, DO NOT HAND-EDIT.

   Produced by Internal_Ops/generate_levels.js with seed 20260811.

   `minMoves` on each level is not an estimate. It is the length of the
   shortest solution that exists, established by breadth-first search over
   every reachable position using the same Rules.resolve() the game runs.
   Internal_Ops/verify_levels.js re-derives all twelve from this file and
   fails if any disagrees, so the numbers on screen cannot drift from the
   truth about the board.

   `budget` is minMoves plus the slack that slot allows.
   ===================================================================== */
'use strict';

(function (root) {
  root.LEVELS = [
  {"w":7,"h":7,"walls":[[3,1],[3,5]],"knights":[[1,3]],"pikes":[[4,3]],"budget":3,"minMoves":1,"teach":"Ride them down."},
  {"w":7,"h":7,"walls":[[0,2],[2,0],[6,4]],"knights":[[3,3]],"pikes":[[4,3]],"budget":4,"minMoves":2,"teach":"Not from a standstill."},
  {"w":7,"h":7,"walls":[[5,1],[4,6],[0,6]],"knights":[[0,1],[3,4]],"pikes":[[4,4],[2,1]],"budget":4,"minMoves":2,"teach":null},
  {"w":7,"h":7,"walls":[[1,6],[1,1],[6,6],[6,0]],"knights":[[3,3],[1,5]],"pikes":[[0,0],[5,5],[1,3]],"budget":4,"minMoves":2,"teach":null},
  {"w":7,"h":7,"walls":[[6,6],[6,4],[6,0],[6,2]],"knights":[[4,6],[1,4]],"pikes":[[0,5],[5,1],[1,0]],"budget":5,"minMoves":3,"teach":null},
  {"w":7,"h":7,"walls":[[0,2],[0,6],[6,6],[0,5],[3,6]],"knights":[[4,0],[3,3]],"pikes":[[6,5],[4,4],[3,0],[6,3]],"budget":4,"minMoves":3,"teach":null},
  {"w":7,"h":7,"walls":[[4,1],[6,0],[1,2],[5,1],[1,1],[1,0]],"knights":[[4,0],[4,6],[5,4]],"pikes":[[5,0],[6,5],[4,2],[0,4]],"budget":4,"minMoves":3,"teach":null},
  {"w":7,"h":7,"walls":[[0,4],[3,5],[6,6],[2,5],[5,5]],"knights":[[0,3],[0,0]],"pikes":[[4,6],[5,4],[5,2],[1,2]],"budget":5,"minMoves":4,"teach":null},
  {"w":7,"h":7,"walls":[[1,0],[0,4],[4,6],[1,1],[4,4],[2,5]],"knights":[[0,2],[5,3],[0,6]],"pikes":[[6,4],[4,3],[3,1],[1,2],[2,3]],"budget":5,"minMoves":4,"teach":null},
  {"w":7,"h":7,"walls":[[3,4],[4,0],[0,2],[2,2],[3,3],[4,5],[0,0]],"knights":[[2,4],[5,1],[0,3]],"pikes":[[0,6],[6,2],[5,6],[2,1],[4,2]],"budget":5,"minMoves":4,"teach":null},
  {"w":7,"h":7,"walls":[[4,3],[0,1],[5,5],[3,5],[6,2],[3,3]],"knights":[[6,5],[3,4],[1,2]],"pikes":[[6,1],[3,6],[1,0],[2,1],[2,4]],"budget":6,"minMoves":5,"teach":null},
  {"w":7,"h":7,"walls":[[2,0],[4,3],[3,4],[3,2],[0,0],[5,6],[0,4]],"knights":[[2,3],[0,3],[1,3]],"pikes":[[0,1],[4,5],[4,2],[6,3],[2,6],[4,4]],"budget":6,"minMoves":5,"teach":null}
  ];
})(typeof window !== 'undefined' ? window : globalThis);

if (typeof module !== 'undefined' && module.exports) {
  module.exports = (typeof window !== 'undefined' ? window : globalThis).LEVELS;
}
