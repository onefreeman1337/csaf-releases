/* =====================================================================
   heraldry.js — THE ARMORY. Every coat of arms in this game is DRAWN,
   not loaded. There is no image file anywhere in this product.

   WHY THIS EXISTS, stated plainly so nobody optimises it away:

   BANNERET shipped with four drawn things — a wall, a pike, a knight, a
   banner — and the whole board was four shapes on beige. It measured 148
   distinct colours on its emptiest store image against 742-2729 for work
   this factory is willing to sell. The fix was never a nicer screenshot.
   It was that the product did not GENERATE anything a player would look at.

   So: real blazonry, which is already a combinatorial visual language and
   has been for eight hundred years. A coat of arms is a FIELD (its
   division and tinctures) bearing a CHARGE (its device). Vary those
   independently and the arms are all different and all coherent, because
   the grammar — not the artist — is what makes them look related.

       50 charges  x  11 divisions  x  8 tincture pairs  =  4,400 arms

   Every one is a canvas path. Nothing is sampled, tiled or blitted.

   THE RULE OF TINCTURE is obeyed, and it is the reason these read as
   heraldry rather than as random colour: metal never goes on metal, and
   colour never goes on colour. That single constraint is what stops the
   generator producing the muddy, low-contrast arms that give procedural
   heraldry away. It also happens to guarantee the charge is legible at
   the 22px the board draws it at, which is not a coincidence — the rule
   exists because these had to be recognised across a battlefield.

   `arms(seed)` is PURE and DETERMINISTIC. The same seed gives the same
   arms forever, so a lord's shield is his shield in the HUD, on his
   pikes, and on the trophy wall at the end, with nothing threaded
   between them.
   ===================================================================== */
'use strict';

(function (root) {

  /* ------------------------------------------------------------ tinctures

     Heraldry's palette is fixed and tiny: five colours, two metals, and
     two furs. These are tuned warm to sit on this game's parchment
     without going fluorescent against it — a pure #ff0000 gules would
     tear a hole in the page. */

  var COLOURS = [
    { id: 'gules',   name: 'gules',   hex: '#a9302a', dark: '#7d1f1b' },
    { id: 'azure',   name: 'azure',   hex: '#2e4f80', dark: '#1f3557' },
    { id: 'sable',   name: 'sable',   hex: '#2b241d', dark: '#171310' },
    { id: 'vert',    name: 'vert',    hex: '#3f6b3c', dark: '#2a4a29' },
    { id: 'purpure', name: 'purpure', hex: '#6b3560', dark: '#4b2343' }
  ];

  var METALS = [
    { id: 'or',     name: 'or',     hex: '#c9a13b', dark: '#a37f27' },
    { id: 'argent', name: 'argent', hex: '#e7dfc8', dark: '#c3b99c' }
  ];

  /* ------------------------------------------------------------- charges

     Each charge is a function (c, s) that paints inside a box running
     -s..+s on both axes, with the current fillStyle/strokeStyle already
     set by the caller. They are silhouettes on purpose: a charge has to
     survive being 20 pixels wide on a pike pennon, and interior detail
     turns to mud long before the outline does. Where a charge needs an
     internal cut (an eye, a portcullis grid) it is punched with the
     background tincture by the caller, never with white.

     They are hand-authored one at a time. That is the expensive part and
     it is the entire point — an LLM writes the RULES of a generator in an
     afternoon; it does not cheaply produce fifty devices that look like
     they came out of the same roll of arms. */

  function poly(c, pts, s) {
    c.beginPath();
    for (var i = 0; i < pts.length; i += 2) {
      var x = pts[i] * s, y = pts[i + 1] * s;
      if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
    }
    c.closePath();
    c.fill();
  }

  function star(c, s, points, inner, rot) {
    c.beginPath();
    for (var i = 0; i < points * 2; i++) {
      var r = (i % 2 ? inner : 1) * s;
      var a = (i / (points * 2)) * Math.PI * 2 - Math.PI / 2 + (rot || 0);
      var x = Math.cos(a) * r, y = Math.sin(a) * r;
      if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
    }
    c.closePath();
    c.fill();
  }

  function disc(c, x, y, r) {
    c.beginPath(); c.arc(x, y, r, 0, 6.2832); c.fill();
  }

  var CHARGES = [

    /* ---- beasts ------------------------------------------------------ */
    { id: 'lion', name: 'a lion rampant', draw: function (c, s) {
      /* Rampant, facing dexter. Built from PARTS rather than as one
         polygon: the first version was a single 19-point outline and it
         read as a blob with a hook. A beast is legible because of the
         relationship between a maned head, a raised foreleg and a
         flourished tail — draw those as separate masses and the eye
         assembles them itself, even at 22 pixels. */

      /* Haunch and hind leg, taking the weight. */
      c.beginPath();
      c.moveTo(0.10 * s, -0.02 * s);
      c.quadraticCurveTo(0.62 * s, 0.06 * s, 0.54 * s, 0.52 * s);
      c.quadraticCurveTo(0.50 * s, 0.86 * s, 0.30 * s, 0.92 * s);
      c.lineTo(0.16 * s, 0.62 * s);
      c.quadraticCurveTo(0.16 * s, 0.34 * s, -0.02 * s, 0.24 * s);
      c.closePath(); c.fill();

      /* Chest and body, rising to the left. */
      c.beginPath();
      c.moveTo(-0.34 * s, -0.30 * s);
      c.quadraticCurveTo(0.14 * s, -0.34 * s, 0.24 * s, 0.10 * s);
      c.quadraticCurveTo(0.10 * s, 0.52 * s, -0.16 * s, 0.56 * s);
      c.quadraticCurveTo(-0.44 * s, 0.44 * s, -0.42 * s, 0.06 * s);
      c.closePath(); c.fill();

      /* Standing hind foot. */
      poly(c, [-0.30, 0.50, -0.06, 0.50, -0.02, 0.94, -0.40, 0.94], s);

      /* Raised foreleg, thrown forward — the single strongest rampant cue. */
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.17 * s; c.lineCap = 'round';
      c.beginPath();
      c.moveTo(-0.24 * s, -0.14 * s);
      c.quadraticCurveTo(-0.66 * s, -0.20 * s, -0.78 * s, -0.52 * s);
      c.stroke();
      c.beginPath();
      c.moveTo(-0.14 * s, 0.10 * s);
      c.quadraticCurveTo(-0.54 * s, 0.16 * s, -0.62 * s, -0.10 * s);
      c.stroke();
      c.restore();

      /* Maned head. The mane is a disc, the muzzle a wedge off it. */
      disc(c, -0.36 * s, -0.52 * s, 0.30 * s);
      poly(c, [-0.58, -0.62, -0.92, -0.56, -0.90, -0.38, -0.54, -0.36], s);
      /* Ear. */
      poly(c, [-0.30, -0.76, -0.16, -0.92, -0.12, -0.68], s);

      /* Tail, flourished up over the spine and tufted. */
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.11 * s; c.lineCap = 'round';
      c.beginPath();
      c.moveTo(0.44 * s, 0.30 * s);
      c.quadraticCurveTo(0.96 * s, -0.06 * s, 0.72 * s, -0.60 * s);
      c.stroke();
      c.restore();
      poly(c, [0.72, -0.54, 0.94, -0.86, 0.56, -0.82], s);
    } },

    { id: 'eagle', name: 'an eagle displayed', draw: function (c, s) {
      /* Displayed: wings spread symmetrically, the commonest arrangement. */
      poly(c, [0, -0.86, 0.16, -0.62, 0.44, -0.74, 0.86, -0.42,
               0.60, -0.30, 0.92, -0.02, 0.54, -0.06, 0.70, 0.30,
               0.34, 0.10, 0.30, 0.52, 0.14, 0.30, 0.16, 0.92,
               -0.16, 0.92, -0.14, 0.30, -0.30, 0.52, -0.34, 0.10,
               -0.70, 0.30, -0.54, -0.06, -0.92, -0.02, -0.60, -0.30,
               -0.86, -0.42, -0.44, -0.74, -0.16, -0.62], s);
    } },

    { id: 'boar', name: "a boar's head couped", draw: function (c, s) {
      /* In profile, facing dexter. The first attempt was an oval with the
         tusks drawn INSIDE its own silhouette, so they vanished and it
         read as a lemon. The snout must project past the mass and the
         tusks must break the outline — that is the whole recognition. */

      /* Skull and jowl. */
      c.beginPath();
      c.moveTo(-0.30 * s, -0.40 * s);
      c.quadraticCurveTo(0.34 * s, -0.68 * s, 0.72 * s, -0.20 * s);
      c.quadraticCurveTo(0.94 * s, 0.30 * s, 0.52 * s, 0.72 * s);
      c.quadraticCurveTo(0.10 * s, 0.96 * s, -0.28 * s, 0.62 * s);
      c.lineTo(-0.46 * s, 0.20 * s);
      c.closePath(); c.fill();

      /* Snout, thrust forward and blunt-ended. */
      c.beginPath();
      c.moveTo(-0.30 * s, -0.36 * s);
      c.lineTo(-0.92 * s, -0.14 * s);
      c.quadraticCurveTo(-1.0 * s, 0.10 * s, -0.86 * s, 0.26 * s);
      c.lineTo(-0.40 * s, 0.28 * s);
      c.closePath(); c.fill();

      /* Bristled crest along the top of the skull. */
      poly(c, [-0.06, -0.52, 0.06, -0.86, 0.18, -0.56], s);
      poly(c, [0.20, -0.54, 0.34, -0.84, 0.42, -0.48], s);

      /* Tusks, curving UP and clear of the snout. */
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.10 * s; c.lineCap = 'round';
      c.beginPath();
      c.moveTo(-0.74 * s, 0.24 * s);
      c.quadraticCurveTo(-0.96 * s, 0.16 * s, -0.90 * s, -0.30 * s);
      c.stroke();
      c.beginPath();
      c.moveTo(-0.50 * s, 0.32 * s);
      c.quadraticCurveTo(-0.68 * s, 0.24 * s, -0.64 * s, -0.12 * s);
      c.stroke();
      c.restore();

      /* Ear. */
      poly(c, [0.46, -0.44, 0.78, -0.76, 0.80, -0.30], s);
    } },

    { id: 'stag', name: "a stag's head attired", draw: function (c, s) {
      /* The antlers carry the recognition; the head is deliberately plain. */
      poly(c, [-0.26, 0.94, -0.34, 0.34, -0.24, -0.06, 0, -0.22,
               0.24, -0.06, 0.34, 0.34, 0.26, 0.94, 0, 0.72], s);
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.10 * s; c.lineCap = 'round';
      var side = [-1, 1];
      for (var k = 0; k < 2; k++) {
        var d = side[k];
        c.beginPath();
        c.moveTo(0.16 * d * s, -0.16 * s);
        c.quadraticCurveTo(0.52 * d * s, -0.56 * s, 0.40 * d * s, -0.96 * s);
        c.moveTo(0.30 * d * s, -0.44 * s); c.lineTo(0.66 * d * s, -0.60 * s);
        c.moveTo(0.38 * d * s, -0.66 * s); c.lineTo(0.76 * d * s, -0.76 * s);
        c.stroke();
      }
      c.restore();
    } },

    { id: 'wolf', name: "a wolf's head erased", draw: function (c, s) {
      /* Profile, dexter, jaws open — the open jaw is what separates a wolf
         from every other pointed head in this armory. */
      c.beginPath();
      c.moveTo(0.22 * s, -0.44 * s);          /* between the ears */
      c.lineTo(0.40 * s, -0.92 * s);          /* rear ear */
      c.lineTo(0.62 * s, -0.46 * s);
      c.quadraticCurveTo(0.86 * s, -0.10 * s, 0.72 * s, 0.44 * s);
      c.lineTo(0.44 * s, 0.92 * s);           /* erased (ragged) neck */
      c.lineTo(0.24 * s, 0.58 * s);
      c.lineTo(0.04 * s, 0.92 * s);
      c.lineTo(-0.10 * s, 0.50 * s);
      c.quadraticCurveTo(-0.44 * s, 0.44 * s, -0.62 * s, 0.30 * s);
      c.lineTo(-0.98 * s, 0.34 * s);          /* lower jaw, thrust out */
      c.lineTo(-0.66 * s, 0.10 * s);
      c.lineTo(-0.96 * s, -0.10 * s);         /* upper jaw */
      c.lineTo(-0.44 * s, -0.14 * s);
      c.quadraticCurveTo(-0.24 * s, -0.34 * s, -0.06 * s, -0.36 * s);
      c.lineTo(-0.02 * s, -0.88 * s);         /* forward ear */
      c.closePath(); c.fill();
    } },

    { id: 'martlet', name: 'a martlet', draw: function (c, s) {
      /* The heraldic swallow, footless by convention, standing in profile.
         The first version was one flat polygon and read as a dart. A bird
         needs three things in the outline: a beak, a folded wing that
         breaks the body, and a forked tail. */
      /* Built from PARTS, like the lion. A single outline flattened the
         head into the body and it read as a leaf. A bird needs the head
         to be a visibly separate mass from the breast. */

      /* Body and breast. */
      c.save();
      c.translate(0.10 * s, 0.12 * s);
      c.rotate(-0.30);
      c.beginPath();
      c.ellipse(0, 0, 0.56 * s, 0.36 * s, 0, 0, 6.2832);
      c.fill();
      c.restore();

      /* Head, a clear disc set forward and above the shoulder. */
      disc(c, -0.44 * s, -0.42 * s, 0.27 * s);
      /* Beak, projecting past the head. */
      poly(c, [-0.62, -0.50, -0.99, -0.36, -0.60, -0.26], s);

      /* Forked tail, swept back and up. */
      poly(c, [0.40, 0.18, 0.99, 0.02, 0.72, 0.34, 0.99, 0.56, 0.44, 0.50], s);

      /* Throat, joining head to breast so they read as one bird. */
      poly(c, [-0.50, -0.20, -0.16, -0.32, -0.06, 0.16, -0.40, 0.14], s);

      /* Folded wing, cut into the body in the FIELD tincture — which is
         how real heraldry shows internal detail, and the only safe way to
         do it here. `destination-out` would have punched a hole straight
         through the shield to the parchment underneath: correct-looking
         on a white test page, a hole in the product. */
      c.save();
      c.strokeStyle = c.__cut || 'rgba(0,0,0,.35)';
      c.lineWidth = 0.10 * s; c.lineCap = 'round';
      c.beginPath();
      c.moveTo(-0.10 * s, -0.06 * s);
      c.quadraticCurveTo(0.26 * s, 0.04 * s, 0.46 * s, 0.28 * s);
      c.stroke();
      c.restore();
    } },

    { id: 'dolphin', name: 'a dolphin haurient', draw: function (c, s) {
      poly(c, [0.02, -0.94, 0.34, -0.54, 0.40, -0.10, 0.66, 0.10,
               0.36, 0.24, 0.30, 0.62, 0.62, 0.88, 0.10, 0.80,
               -0.34, 0.92, -0.14, 0.56, -0.26, 0.16, -0.56, 0.04,
               -0.24, -0.14, -0.22, -0.58], s);
    } },

    { id: 'ram', name: "a ram's head caboshed", draw: function (c, s) {
      /* Caboshed: full face, no neck. The horns are the charge — they must
         be FAT spirals sweeping out and down past the jaw, not the thin
         arcs of the first version, which read as two stray hooks. */
      /* Horns curl OUTWARD ONLY. The previous pass let them sweep back
         across the face at x=0.30 and the two curls closed into a pair of
         goggles — the face disappeared inside its own horns. Nothing here
         crosses x = +/-0.34, which is the face's own edge. */
      c.save();
      c.strokeStyle = c.fillStyle;
      c.lineWidth = 0.20 * s; c.lineCap = 'round';
      for (var k = 0; k < 2; k++) {
        var d = k ? 1 : -1;
        c.beginPath();
        c.moveTo(0.34 * d * s, -0.54 * s);
        c.quadraticCurveTo(0.96 * d * s, -0.62 * s, 0.94 * d * s, -0.02 * s);
        c.quadraticCurveTo(0.92 * d * s, 0.44 * s, 0.52 * d * s, 0.34 * s);
        c.stroke();
      }
      c.restore();

      /* Face: a blunt wedge, wide at the brow, narrow at the muzzle. */
      c.beginPath();
      c.moveTo(-0.34 * s, -0.62 * s);
      c.lineTo(0.34 * s, -0.62 * s);
      c.quadraticCurveTo(0.38 * s, 0.16 * s, 0.19 * s, 0.74 * s);
      c.quadraticCurveTo(0, 0.96 * s, -0.19 * s, 0.74 * s);
      c.quadraticCurveTo(-0.38 * s, 0.16 * s, -0.34 * s, -0.62 * s);
      c.closePath(); c.fill();

      /* Eyes, cut in the field tincture so the face is not a blank wedge. */
      c.save();
      c.fillStyle = c.__cut || 'rgba(0,0,0,.45)';
      disc(c, -0.16 * s, -0.24 * s, 0.075 * s);
      disc(c, 0.16 * s, -0.24 * s, 0.075 * s);
      c.restore();
    } },

    /* ---- plants ------------------------------------------------------ */
    { id: 'rose', name: 'a rose', draw: function (c, s) {
      /* Heraldic rose: five petals, seeded and barbed, flat on. */
      for (var i = 0; i < 5; i++) {
        var a = (i / 5) * 6.2832 - Math.PI / 2;
        c.save(); c.rotate(a);
        c.beginPath();
        c.moveTo(0, -0.18 * s);
        c.quadraticCurveTo(-0.62 * s, -0.52 * s, 0, -1.0 * s);
        c.quadraticCurveTo(0.62 * s, -0.52 * s, 0, -0.18 * s);
        c.fill();
        c.restore();
      }
      disc(c, 0, 0, 0.24 * s);
    } },

    { id: 'fleur', name: 'a fleur-de-lys', draw: function (c, s) {
      poly(c, [0, -1.0, 0.16, -0.50, 0.30, -0.26, 0.30, 0.02,
               0.62, -0.20, 0.86, 0.10, 0.60, 0.44, 0.26, 0.34,
               0.30, 0.86, -0.30, 0.86, -0.26, 0.34, -0.60, 0.44,
               -0.86, 0.10, -0.62, -0.20, -0.30, 0.02, -0.30, -0.26,
               -0.16, -0.50], s);
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.16 * s;
      c.beginPath(); c.moveTo(-0.46 * s, 0.34 * s); c.lineTo(0.46 * s, 0.34 * s); c.stroke();
      c.restore();
    } },

    { id: 'trefoil', name: 'a trefoil slipped', draw: function (c, s) {
      for (var i = 0; i < 3; i++) {
        var a = (i / 3) * 6.2832 - Math.PI / 2;
        disc(c, Math.cos(a) * 0.44 * s, Math.sin(a) * 0.44 * s - 0.12 * s, 0.34 * s);
      }
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.13 * s; c.lineCap = 'round';
      c.beginPath();
      c.moveTo(0, 0.24 * s); c.quadraticCurveTo(0.16 * s, 0.70 * s, -0.06 * s, 0.98 * s);
      c.stroke();
      c.restore();
    } },

    { id: 'cinquefoil', name: 'a cinquefoil', draw: function (c, s) {
      for (var i = 0; i < 5; i++) {
        var a = (i / 5) * 6.2832 - Math.PI / 2;
        disc(c, Math.cos(a) * 0.52 * s, Math.sin(a) * 0.52 * s, 0.38 * s);
      }
    } },

    { id: 'oakleaf', name: 'an oak leaf', draw: function (c, s) {
      /* Four lobes a side around a central rib. The two earlier attempts
         both interpolated the lobe width with a sine and produced a stack
         of discs — a caterpillar, not a leaf. An oak leaf reads because
         the lobes get WIDER toward the middle and the notches between
         them cut deep, so the widths are now a hand-written table. */
      var W = [0.30, 0.62, 0.70, 0.44];   /* lobe half-widths, tip -> stalk */
      var Y = [-0.62, -0.24, 0.16, 0.52]; /* lobe centres */
      var NOTCH = 0.20;
      var i;

      c.beginPath();
      c.moveTo(0, -0.98 * s);
      for (i = 0; i < W.length; i++) {                        /* down the right */
        c.quadraticCurveTo(W[i] * 1.22 * s, (Y[i] - 0.16) * s, W[i] * s, Y[i] * s);
        c.quadraticCurveTo(W[i] * 0.86 * s, (Y[i] + 0.14) * s, NOTCH * s, (Y[i] + 0.20) * s);
      }
      c.lineTo(0.09 * s, 0.98 * s);                           /* stalk */
      c.lineTo(-0.09 * s, 0.98 * s);
      for (i = W.length - 1; i >= 0; i--) {                   /* back up the left */
        c.lineTo(-NOTCH * s, (Y[i] + 0.20) * s);
        c.quadraticCurveTo(-W[i] * 0.86 * s, (Y[i] + 0.14) * s, -W[i] * s, Y[i] * s);
        c.quadraticCurveTo(-W[i] * 1.22 * s, (Y[i] - 0.16) * s,
                           i === 0 ? 0 : -NOTCH * s, i === 0 ? -0.98 * s : (Y[i - 1] + 0.20) * s);
      }
      c.closePath(); c.fill();
    } },

    { id: 'acorn', name: 'an acorn', draw: function (c, s) {
      c.beginPath();
      c.moveTo(-0.44 * s, -0.10 * s);
      c.quadraticCurveTo(-0.46 * s, 0.78 * s, 0, 0.94 * s);
      c.quadraticCurveTo(0.46 * s, 0.78 * s, 0.44 * s, -0.10 * s);
      c.closePath(); c.fill();
      c.beginPath();
      c.moveTo(-0.58 * s, -0.14 * s);
      c.quadraticCurveTo(0, -0.58 * s, 0.58 * s, -0.14 * s);
      c.quadraticCurveTo(0, 0.10 * s, -0.58 * s, -0.14 * s);
      c.closePath(); c.fill();
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.11 * s; c.lineCap = 'round';
      c.beginPath(); c.moveTo(0, -0.44 * s); c.lineTo(0, -0.92 * s); c.stroke();
      c.restore();
    } },

    { id: 'garb', name: 'a garb', draw: function (c, s) {
      /* A wheatsheaf bound at the waist. The first version was one smooth
         outline and read as a cushion: a sheaf is legible only if you can
         see that it is made of SEPARATE STALKS, so they are drawn as
         individual ears fanning out above and below the band. */
      var i, t, a;
      for (i = 0; i < 7; i++) {
        t = i / 6;
        a = (t - 0.5) * 1.30;
        c.save();
        c.translate(0, -0.10 * s);
        c.rotate(a);
        /* stalk */
        c.fillStyle = c.fillStyle;
        poly(c, [-0.07, 0, 0.07, 0, 0.07, -0.62, -0.07, -0.62], s);
        /* ear of grain */
        c.beginPath();
        c.ellipse(0, -0.76 * s, 0.13 * s, 0.24 * s, 0, 0, 6.2832);
        c.fill();
        c.restore();
      }
      for (i = 0; i < 5; i++) {
        t = i / 4;
        a = (t - 0.5) * 1.10;
        c.save();
        c.translate(0, 0.16 * s);
        c.rotate(-a);
        poly(c, [-0.07, 0, 0.07, 0, 0.07, 0.80, -0.07, 0.80], s);
        c.restore();
      }
      /* The band. */
      poly(c, [-0.46, -0.16, 0.46, -0.16, 0.46, 0.22, -0.46, 0.22], s);
      c.save();
      c.strokeStyle = c.__cut || 'rgba(0,0,0,.3)';
      c.lineWidth = 0.06 * s;
      c.beginPath();
      c.moveTo(-0.46 * s, 0.03 * s); c.lineTo(0.46 * s, 0.03 * s);
      c.stroke();
      c.restore();
    } },

    { id: 'thistle', name: 'a thistle', draw: function (c, s) {
      star(c, 0.56 * s, 9, 0.44, 0);
      c.save(); c.translate(0, -0.30 * s); star(c, 0.42 * s, 7, 0.40, 0.3); c.restore();
      poly(c, [-0.34, 0.10, 0.34, 0.10, 0.24, 0.62, -0.24, 0.62], s);
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.12 * s; c.lineCap = 'round';
      c.beginPath(); c.moveTo(0, 0.52 * s); c.lineTo(0, 0.98 * s); c.stroke();
      c.restore();
    } },

    /* ---- celestial --------------------------------------------------- */
    { id: 'mullet', name: 'a mullet', draw: function (c, s) { star(c, s, 5, 0.42, 0); } },

    { id: 'mullet6', name: 'a mullet of six points', draw: function (c, s) { star(c, s, 6, 0.46, 0); } },

    { id: 'estoile', name: 'an estoile', draw: function (c, s) {
      /* Six WAVY rays — the distinction from a mullet is the wave. */
      for (var i = 0; i < 6; i++) {
        var a = (i / 6) * 6.2832;
        c.save(); c.rotate(a);
        c.beginPath();
        c.moveTo(-0.20 * s, 0);
        c.quadraticCurveTo(-0.10 * s, -0.40 * s, 0, -1.0 * s);
        c.quadraticCurveTo(0.10 * s, -0.40 * s, 0.20 * s, 0);
        c.closePath(); c.fill();
        c.restore();
      }
      disc(c, 0, 0, 0.22 * s);
    } },

    { id: 'sun', name: 'a sun in splendour', draw: function (c, s) {
      for (var i = 0; i < 16; i++) {
        var a = (i / 16) * 6.2832;
        c.save(); c.rotate(a);
        poly(c, [-0.10, -0.52, 0.10, -0.52, 0, -1.0], s);
        c.restore();
      }
      disc(c, 0, 0, 0.54 * s);
    } },

    { id: 'crescent', name: 'a crescent', draw: function (c, s) {
      /* Horns upward, as heraldry always sets it. The two arcs were nearly
         concentric (0.88 vs 0.80, offset 0.26) so the moon came out a
         thread — it measured 273 ink pixels against a 1000+ median and was
         the thinnest thing in the armory. A heraldic crescent is FAT: the
         inner arc is much smaller and pushed well up. */
      /* Canvas angles with y DOWN: 0 = right, PI/2 = down, PI = left.
         So the BOTTOM of a circle is swept by INCREASING angle from
         up-right round to up-left — which is the opposite of the
         intuition that produced the thread twice. */
      c.beginPath();
      c.arc(0, 0.06 * s, 0.94 * s, -0.52, Math.PI + 0.52, false);   /* outer, along the bottom */
      c.arc(0, -0.40 * s, 0.72 * s, Math.PI + 0.40, -0.40, true);   /* inner bite, back along ITS bottom */
      c.closePath(); c.fill();
    } },

    /* ---- crosses ----------------------------------------------------- */
    { id: 'crosspatee', name: 'a cross patée', draw: function (c, s) {
      c.beginPath();
      for (var i = 0; i < 4; i++) {
        var a = (i / 4) * 6.2832;
        var ca = Math.cos(a), sa = Math.sin(a);
        function P(x, y) { return [(x * ca - y * sa) * s, (x * sa + y * ca) * s]; }
        var p1 = P(-0.16, -0.16), p2 = P(-0.52, -1.0), p3 = P(0.52, -1.0), p4 = P(0.16, -0.16);
        if (i === 0) c.moveTo(p1[0], p1[1]); else c.lineTo(p1[0], p1[1]);
        c.quadraticCurveTo(P(-0.30, -0.62)[0], P(-0.30, -0.62)[1], p2[0], p2[1]);
        c.lineTo(p3[0], p3[1]);
        c.quadraticCurveTo(P(0.30, -0.62)[0], P(0.30, -0.62)[1], p4[0], p4[1]);
      }
      c.closePath(); c.fill();
    } },

    { id: 'crossmoline', name: 'a cross moline', draw: function (c, s) {
      for (var i = 0; i < 4; i++) {
        var a = (i / 4) * 6.2832;
        c.save(); c.rotate(a);
        poly(c, [-0.15, 0.10, 0.15, 0.10, 0.15, -0.62, 0.52, -0.94,
                 0.20, -0.98, 0, -0.72, -0.20, -0.98, -0.52, -0.94,
                 -0.15, -0.62], s);
        c.restore();
      }
    } },

    { id: 'crossfleury', name: 'a cross fleury', draw: function (c, s) {
      for (var i = 0; i < 4; i++) {
        var a = (i / 4) * 6.2832;
        c.save(); c.rotate(a);
        poly(c, [-0.15, 0.14, 0.15, 0.14, 0.15, -0.58, 0.44, -0.62,
                 0.20, -0.80, 0.30, -1.0, 0, -0.86, -0.30, -1.0,
                 -0.20, -0.80, -0.44, -0.62, -0.15, -0.58], s);
        c.restore();
      }
    } },

    { id: 'crosscrosslet', name: 'a cross crosslet', draw: function (c, s) {
      for (var i = 0; i < 4; i++) {
        var a = (i / 4) * 6.2832;
        c.save(); c.rotate(a);
        poly(c, [-0.14, 0.14, 0.14, 0.14, 0.14, -0.60, 0.44, -0.60,
                 0.44, -0.82, 0.14, -0.82, 0.14, -1.0, -0.14, -1.0,
                 -0.14, -0.82, -0.44, -0.82, -0.44, -0.60, -0.14, -0.60], s);
        c.restore();
      }
    } },

    { id: 'saltirecross', name: 'a saltire couped', draw: function (c, s) {
      for (var i = 0; i < 2; i++) {
        c.save(); c.rotate(Math.PI / 4 + i * Math.PI / 2);
        poly(c, [-0.16, -0.98, 0.16, -0.98, 0.16, 0.98, -0.16, 0.98], s);
        c.restore();
      }
    } },

    /* ---- war --------------------------------------------------------- */
    { id: 'sword', name: 'a sword', draw: function (c, s) {
      poly(c, [0, -1.0, 0.14, -0.72, 0.14, 0.30, -0.14, 0.30, -0.14, -0.72], s);
      poly(c, [-0.58, 0.30, 0.58, 0.30, 0.58, 0.46, -0.58, 0.46], s);
      poly(c, [-0.12, 0.46, 0.12, 0.46, 0.12, 0.88, -0.12, 0.88], s);
      poly(c, [-0.26, 0.88, 0.26, 0.88, 0.26, 1.0, -0.26, 1.0], s);
    } },

    { id: 'axe', name: 'a battle-axe', draw: function (c, s) {
      poly(c, [-0.08, -0.96, 0.08, -0.96, 0.08, 0.98, -0.08, 0.98], s);
      c.beginPath();
      c.moveTo(0.06 * s, -0.86 * s);
      c.quadraticCurveTo(0.94 * s, -0.66 * s, 0.72 * s, -0.02 * s);
      c.lineTo(0.06 * s, -0.18 * s);
      c.closePath(); c.fill();
      c.beginPath();
      c.moveTo(-0.06 * s, -0.86 * s);
      c.quadraticCurveTo(-0.60 * s, -0.70 * s, -0.48 * s, -0.26 * s);
      c.lineTo(-0.06 * s, -0.34 * s);
      c.closePath(); c.fill();
    } },

    { id: 'hammer', name: 'a hammer', draw: function (c, s) {
      poly(c, [-0.11, -0.30, 0.11, -0.30, 0.11, 0.98, -0.11, 0.98], s);
      poly(c, [-0.78, -0.86, 0.78, -0.86, 0.66, -0.30, -0.66, -0.30], s);
    } },

    { id: 'arrow', name: 'an arrow', draw: function (c, s) {
      poly(c, [0, -1.0, 0.34, -0.44, 0.12, -0.44, 0.12, 0.52, -0.12, 0.52,
               -0.12, -0.44, -0.34, -0.44], s);
      poly(c, [-0.36, 0.52, 0.36, 0.52, 0.16, 0.98, -0.16, 0.98], s);
    } },

    { id: 'pheon', name: 'a pheon', draw: function (c, s) {
      /* A broad barbed arrowhead, point downward — the Board of Ordnance mark. */
      poly(c, [0, 1.0, 0.86, -0.62, 0.30, -0.32, 0.16, -0.96,
               -0.16, -0.96, -0.30, -0.32, -0.86, -0.62], s);
    } },

    { id: 'bow', name: 'a bow bent and an arrow', draw: function (c, s) {
      /* The stave alone read as a half-moon — indistinguishable from the
         crescent two cells away. A bow is recognised by the STRING and the
         nocked arrow, so both are now part of the charge. */
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.15 * s; c.lineCap = 'round';
      /* Stave, recurved at the tips. */
      c.beginPath();
      c.moveTo(-0.52 * s, -0.94 * s);
      c.quadraticCurveTo(-0.20 * s, -0.86 * s, -0.14 * s, -0.62 * s);
      c.quadraticCurveTo(0.62 * s, 0, -0.14 * s, 0.62 * s);
      c.quadraticCurveTo(-0.20 * s, 0.86 * s, -0.52 * s, 0.94 * s);
      c.stroke();
      /* String, straight and taut between the tips. */
      c.lineWidth = 0.05 * s;
      c.beginPath();
      c.moveTo(-0.50 * s, -0.92 * s); c.lineTo(-0.50 * s, 0.92 * s);
      c.stroke();
      /* Arrow on the string. */
      c.lineWidth = 0.07 * s;
      c.beginPath();
      c.moveTo(-0.60 * s, 0); c.lineTo(0.58 * s, 0);
      c.stroke();
      c.restore();
      poly(c, [0.58, -0.20, 0.96, 0, 0.58, 0.20], s);      /* head */
      poly(c, [-0.60, -0.22, -0.44, 0, -0.60, 0.22, -0.76, 0], s); /* fletching */
    } },

    { id: 'caltrap', name: 'a caltrap', draw: function (c, s) {
      poly(c, [0, -1.0, 0.16, -0.20, 0.94, 0.60, 0.10, 0.24,
               0, 1.0, -0.10, 0.24, -0.94, 0.60, -0.16, -0.20], s);
    } },

    { id: 'helm', name: 'a great helm', draw: function (c, s) {
      c.beginPath();
      c.moveTo(-0.62 * s, -0.44 * s);
      c.quadraticCurveTo(0, -1.02 * s, 0.62 * s, -0.44 * s);
      c.lineTo(0.58 * s, 0.62 * s);
      c.quadraticCurveTo(0, 0.98 * s, -0.58 * s, 0.62 * s);
      c.closePath(); c.fill();
    } },

    { id: 'gauntlet', name: 'a gauntlet', draw: function (c, s) {
      poly(c, [-0.52, 0.98, -0.58, 0.10, -0.44, -0.30, -0.30, -0.86,
               -0.10, -0.30, 0.02, -0.98, 0.16, -0.30, 0.34, -0.82,
               0.36, -0.24, 0.62, -0.44, 0.56, 0.24, 0.44, 0.98], s);
    } },

    { id: 'spur', name: 'a spur rowel', draw: function (c, s) {
      star(c, s, 6, 0.34, 0);
      disc(c, 0, 0, 0.20 * s);
    } },

    /* ---- building ---------------------------------------------------- */
    { id: 'tower', name: 'a tower', draw: function (c, s) {
      poly(c, [-0.68, -0.64, -0.68, -0.90, -0.40, -0.90, -0.40, -0.64,
               -0.14, -0.64, -0.14, -0.90, 0.14, -0.90, 0.14, -0.64,
               0.40, -0.64, 0.40, -0.90, 0.68, -0.90, 0.68, -0.64,
               0.56, -0.40, 0.56, 0.96, -0.56, 0.96, -0.56, -0.40], s);
    } },

    { id: 'portcullis', name: 'a portcullis', draw: function (c, s) {
      var i;
      for (i = -2; i <= 2; i++) poly(c, [i * 0.36 - 0.07, -0.82, i * 0.36 + 0.07, -0.82,
                                         i * 0.36 + 0.07, 0.68, i * 0.36 - 0.07, 0.68], s);
      for (i = -2; i <= 1; i++) poly(c, [-0.86, i * 0.38 - 0.06, 0.86, i * 0.38 - 0.06,
                                         0.86, i * 0.38 + 0.06, -0.86, i * 0.38 + 0.06], s);
      poly(c, [-0.86, 0.68, 0.86, 0.68, 0.72, 0.98, -0.72, 0.98], s);
    } },

    { id: 'key', name: 'a key', draw: function (c, s) {
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.18 * s;
      c.beginPath(); c.arc(0, -0.58 * s, 0.36 * s, 0, 6.2832); c.stroke();
      c.restore();
      poly(c, [-0.11, -0.22, 0.11, -0.22, 0.11, 0.98, -0.11, 0.98], s);
      poly(c, [0.11, 0.40, 0.62, 0.40, 0.62, 0.58, 0.11, 0.58], s);
      poly(c, [0.11, 0.70, 0.46, 0.70, 0.46, 0.88, 0.11, 0.88], s);
    } },

    { id: 'bell', name: 'a bell', draw: function (c, s) {
      c.beginPath();
      c.moveTo(-0.72 * s, 0.62 * s);
      c.quadraticCurveTo(-0.62 * s, -0.72 * s, 0, -0.86 * s);
      c.quadraticCurveTo(0.62 * s, -0.72 * s, 0.72 * s, 0.62 * s);
      c.closePath(); c.fill();
      poly(c, [-0.82, 0.62, 0.82, 0.62, 0.82, 0.80, -0.82, 0.80], s);
      disc(c, 0, 0.92 * s, 0.16 * s);
    } },

    { id: 'harp', name: 'a harp', draw: function (c, s) {
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.15 * s; c.lineCap = 'round';
      c.beginPath();
      c.moveTo(-0.46 * s, 0.94 * s);
      c.quadraticCurveTo(-0.86 * s, -0.30 * s, 0.10 * s, -0.94 * s);
      c.stroke();
      c.lineWidth = 0.13 * s;
      c.beginPath(); c.moveTo(0.10 * s, -0.94 * s); c.lineTo(0.52 * s, 0.94 * s); c.stroke();
      c.beginPath(); c.moveTo(-0.46 * s, 0.94 * s); c.lineTo(0.52 * s, 0.94 * s); c.stroke();
      c.lineWidth = 0.05 * s;
      for (var i = 1; i <= 4; i++) {
        var t = i / 5;
        c.beginPath();
        c.moveTo((-0.46 + t * 0.98) * s, 0.94 * s);
        c.lineTo((-0.62 + t * 0.80) * s, (0.30 - t * 0.94) * s);
        c.stroke();
      }
      c.restore();
    } },

    { id: 'ship', name: 'a lymphad', draw: function (c, s) {
      poly(c, [-0.92, 0.30, 0.92, 0.30, 0.62, 0.86, -0.62, 0.86], s);
      poly(c, [-0.06, -0.96, 0.06, -0.96, 0.06, 0.30, -0.06, 0.30], s);
      c.beginPath();
      c.moveTo(0.06 * s, -0.86 * s);
      c.quadraticCurveTo(0.78 * s, -0.44 * s, 0.06 * s, 0.10 * s);
      c.closePath(); c.fill();
    } },

    { id: 'anchor', name: 'an anchor', draw: function (c, s) {
      poly(c, [-0.10, -0.62, 0.10, -0.62, 0.10, 0.86, -0.10, 0.86], s);
      poly(c, [-0.50, -0.50, 0.50, -0.50, 0.50, -0.32, -0.50, -0.32], s);
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.16 * s; c.lineCap = 'round';
      c.beginPath(); c.arc(0, 0.30 * s, 0.66 * s, 0.30, Math.PI - 0.30); c.stroke();
      c.restore();
      poly(c, [-0.78, 0.56, -0.52, 0.86, -0.86, 0.84], s);
      poly(c, [0.78, 0.56, 0.52, 0.86, 0.86, 0.84], s);
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.13 * s;
      c.beginPath(); c.arc(0, -0.74 * s, 0.24 * s, 0, 6.2832); c.stroke();
      c.restore();
    } },

    /* ---- abstract ordinaries used as charges -------------------------- */
    { id: 'lozenge', name: 'a lozenge', draw: function (c, s) {
      poly(c, [0, -1.0, 0.62, 0, 0, 1.0, -0.62, 0], s);
    } },

    { id: 'annulet', name: 'an annulet', draw: function (c, s) {
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.28 * s;
      c.beginPath(); c.arc(0, 0, 0.72 * s, 0, 6.2832); c.stroke();
      c.restore();
    } },

    { id: 'billets', name: 'three billets', draw: function (c, s) {
      poly(c, [-0.72, -0.92, 0.02, -0.92, 0.02, -0.42, -0.72, -0.42], s);
      poly(c, [-0.36, -0.24, 0.38, -0.24, 0.38, 0.26, -0.36, 0.26], s);
      poly(c, [-0.02, 0.44, 0.72, 0.44, 0.72, 0.94, -0.02, 0.94], s);
    } },

    { id: 'roundels', name: 'three roundels', draw: function (c, s) {
      disc(c, 0, -0.58 * s, 0.38 * s);
      disc(c, -0.54 * s, 0.36 * s, 0.38 * s);
      disc(c, 0.54 * s, 0.36 * s, 0.38 * s);
    } },

    { id: 'chessrook', name: 'a chess rook', draw: function (c, s) {
      poly(c, [-0.66, -0.86, -0.66, -0.52, -0.24, -0.52, -0.24, -0.86,
               0.24, -0.86, 0.24, -0.52, 0.66, -0.52, 0.66, -0.86,
               0.52, -0.86, 0.36, -0.20, 0.44, 0.62, 0.66, 0.96,
               -0.66, 0.96, -0.44, 0.62, -0.36, -0.20, -0.52, -0.86], s);
    } },

    { id: 'waterbouget', name: 'a water bouget', draw: function (c, s) {
      poly(c, [-0.10, -0.92, 0.10, -0.92, 0.10, 0.92, -0.10, 0.92], s);
      c.beginPath();
      c.moveTo(-0.10 * s, -0.66 * s);
      c.quadraticCurveTo(-0.98 * s, -0.42 * s, -0.66 * s, 0.62 * s);
      c.quadraticCurveTo(-0.34 * s, 0.94 * s, -0.10 * s, 0.34 * s);
      c.closePath(); c.fill();
      c.beginPath();
      c.moveTo(0.10 * s, -0.66 * s);
      c.quadraticCurveTo(0.98 * s, -0.42 * s, 0.66 * s, 0.62 * s);
      c.quadraticCurveTo(0.34 * s, 0.94 * s, 0.10 * s, 0.34 * s);
      c.closePath(); c.fill();
    } },

    { id: 'escallop', name: 'an escallop', draw: function (c, s) {
      c.beginPath();
      c.moveTo(-0.86 * s, 0.36 * s);
      for (var i = 0; i <= 7; i++) {
        var t = i / 7;
        var x = (-0.86 + t * 1.72) * s;
        var yy = (0.36 - Math.sin(t * Math.PI) * 1.16) * s;
        if (i === 0) c.lineTo(x, yy);
        else {
          var pt = (i - 0.5) / 7;
          c.quadraticCurveTo((-0.86 + pt * 1.72) * s,
                             (0.36 - Math.sin(pt * Math.PI) * 1.34) * s, x, yy);
        }
      }
      c.quadraticCurveTo(0, 0.98 * s, -0.86 * s, 0.36 * s);
      c.closePath(); c.fill();
      poly(c, [-0.22, 0.40, 0.22, 0.40, 0.14, 0.86, -0.14, 0.86], s);
    } },

    { id: 'heart', name: 'a heart', draw: function (c, s) {
      c.beginPath();
      c.moveTo(0, 0.96 * s);
      c.bezierCurveTo(-1.24 * s, 0.10 * s, -0.60 * s, -1.06 * s, 0, -0.34 * s);
      c.bezierCurveTo(0.60 * s, -1.06 * s, 1.24 * s, 0.10 * s, 0, 0.96 * s);
      c.closePath(); c.fill();
    } },

    { id: 'flame', name: 'a flame', draw: function (c, s) {
      c.beginPath();
      c.moveTo(0, -1.0 * s);
      c.quadraticCurveTo(0.52 * s, -0.40 * s, 0.44 * s, 0.10 * s);
      c.quadraticCurveTo(0.86 * s, 0.02 * s, 0.72 * s, -0.34 * s);
      c.quadraticCurveTo(1.02 * s, 0.38 * s, 0.46 * s, 0.92 * s);
      c.lineTo(-0.46 * s, 0.92 * s);
      c.quadraticCurveTo(-1.02 * s, 0.38 * s, -0.72 * s, -0.34 * s);
      c.quadraticCurveTo(-0.86 * s, 0.02 * s, -0.44 * s, 0.10 * s);
      c.quadraticCurveTo(-0.52 * s, -0.40 * s, 0, -1.0 * s);
      c.closePath(); c.fill();
    } },

    { id: 'wing', name: 'a wing displayed', draw: function (c, s) {
      /* A wing is legible only if the FLIGHT FEATHERS are separate. The
         first version smoothed them into one leaf-shaped blob. Drawn now
         as a shoulder plus five distinct pinions of decreasing length. */
      var i, t, len, x0, y0;
      /* Pinions, longest at the leading edge. */
      for (i = 0; i < 5; i++) {
        t = i / 4;
        len = 1.0 - t * 0.42;
        x0 = -0.52 + t * 0.62;
        y0 = -0.46 + t * 0.30;
        c.save();
        c.translate(x0 * s, y0 * s);
        c.rotate(0.42 + t * 0.46);
        c.beginPath();
        c.moveTo(-0.13 * s, 0);
        c.quadraticCurveTo(-0.17 * s, len * 0.72 * s, 0, len * 1.02 * s);
        c.quadraticCurveTo(0.17 * s, len * 0.72 * s, 0.13 * s, 0);
        c.closePath(); c.fill();
        c.restore();
      }
      /* Shoulder and covert feathers, over the top of the quills. */
      c.beginPath();
      c.moveTo(-0.66 * s, -0.92 * s);
      c.quadraticCurveTo(0.30 * s, -0.76 * s, 0.42 * s, -0.06 * s);
      c.quadraticCurveTo(-0.10 * s, -0.10 * s, -0.42 * s, -0.34 * s);
      c.closePath(); c.fill();
    } },

    { id: 'horn', name: 'a bugle horn', draw: function (c, s) {
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.20 * s; c.lineCap = 'round';
      c.beginPath();
      c.moveTo(-0.80 * s, -0.30 * s);
      c.quadraticCurveTo(0, 0.98 * s, 0.72 * s, -0.16 * s);
      c.stroke();
      c.restore();
      poly(c, [0.58, -0.44, 0.98, -0.72, 0.94, 0.10, 0.56, 0.02], s);
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.09 * s;
      c.beginPath();
      c.moveTo(-0.80 * s, -0.30 * s);
      c.quadraticCurveTo(-0.20 * s, -0.96 * s, 0.70 * s, -0.58 * s);
      c.stroke();
      c.restore();
    } },

    { id: 'crown', name: 'a ducal coronet', draw: function (c, s) {
      poly(c, [-0.88, 0.34, 0.88, 0.34, 0.88, 0.76, -0.88, 0.76], s);
      for (var i = -1; i <= 1; i++) {
        poly(c, [i * 0.62 - 0.22, 0.34, i * 0.62 + 0.22, 0.34,
                 i * 0.62 + 0.30, -0.30, i * 0.62, -0.62, i * 0.62 - 0.30, -0.30], s);
        disc(c, i * 0.62 * s, -0.72 * s, 0.16 * s);
      }
    } },

    { id: 'mitre', name: 'a mitre', draw: function (c, s) {
      c.beginPath();
      c.moveTo(-0.62 * s, 0.62 * s);
      c.quadraticCurveTo(-0.56 * s, -0.30 * s, 0, -0.98 * s);
      c.quadraticCurveTo(0.56 * s, -0.30 * s, 0.62 * s, 0.62 * s);
      c.closePath(); c.fill();
      poly(c, [-0.70, 0.62, 0.70, 0.62, 0.70, 0.82, -0.70, 0.82], s);
      poly(c, [-0.44, 0.82, -0.20, 0.82, -0.28, 1.0, -0.52, 1.0], s);
      poly(c, [0.44, 0.82, 0.20, 0.82, 0.28, 1.0, 0.52, 1.0], s);
    } },

    { id: 'buckle', name: 'a buckle', draw: function (c, s) {
      c.save();
      c.strokeStyle = c.fillStyle; c.lineWidth = 0.22 * s;
      c.beginPath();
      c.moveTo(-0.62 * s, -0.72 * s); c.lineTo(0.62 * s, -0.72 * s);
      c.lineTo(0.62 * s, 0.72 * s); c.lineTo(-0.62 * s, 0.72 * s);
      c.closePath(); c.stroke();
      c.lineWidth = 0.14 * s;
      c.beginPath(); c.moveTo(-0.62 * s, 0); c.lineTo(0.92 * s, 0); c.stroke();
      c.restore();
    } },

    { id: 'tun', name: 'a tun', draw: function (c, s) {
      c.beginPath();
      c.moveTo(-0.52 * s, -0.80 * s);
      c.quadraticCurveTo(-0.86 * s, 0, -0.52 * s, 0.80 * s);
      c.lineTo(0.52 * s, 0.80 * s);
      c.quadraticCurveTo(0.86 * s, 0, 0.52 * s, -0.80 * s);
      c.closePath(); c.fill();
    } },

    { id: 'cup', name: 'a covered cup', draw: function (c, s) {
      c.beginPath();
      c.moveTo(-0.56 * s, -0.16 * s);
      c.quadraticCurveTo(-0.44 * s, 0.44 * s, 0, 0.50 * s);
      c.quadraticCurveTo(0.44 * s, 0.44 * s, 0.56 * s, -0.16 * s);
      c.closePath(); c.fill();
      poly(c, [-0.10, 0.44, 0.10, 0.44, 0.10, 0.82, -0.10, 0.82], s);
      poly(c, [-0.50, 0.82, 0.50, 0.82, 0.50, 0.98, -0.50, 0.98], s);
      c.beginPath();
      c.moveTo(-0.58 * s, -0.20 * s);
      c.quadraticCurveTo(0, -0.90 * s, 0.58 * s, -0.20 * s);
      c.closePath(); c.fill();
      disc(c, 0, -0.92 * s, 0.14 * s);
    } }
  ];

  /* ----------------------------------------------------------- divisions

     The field's own geometry. Each returns a clip path over the shield
     box (-1..1 in x, -1..1.25 in y is the shield's own space) marking
     where the SECOND tincture goes; the first is painted underneath as a
     plain field. `plain` returns nothing and the field stays one colour. */

  var DIVISIONS = [
    { id: 'plain',   name: '', paint: null },

    { id: 'perpale', name: 'per pale', paint: function (c, w, h) {
      c.beginPath(); c.rect(0, -h, w, h * 2.4); c.fill();
    } },

    { id: 'perfess', name: 'per fess', paint: function (c, w, h) {
      c.beginPath(); c.rect(-w, 0, w * 2, h * 2.4); c.fill();
    } },

    { id: 'perbend', name: 'per bend', paint: function (c, w, h) {
      c.beginPath();
      c.moveTo(-w, -h); c.lineTo(w, h * 1.4); c.lineTo(w, -h);
      c.closePath(); c.fill();
    } },

    { id: 'perbendsin', name: 'per bend sinister', paint: function (c, w, h) {
      c.beginPath();
      c.moveTo(w, -h); c.lineTo(-w, h * 1.4); c.lineTo(-w, -h);
      c.closePath(); c.fill();
    } },

    { id: 'perchevron', name: 'per chevron', paint: function (c, w, h) {
      c.beginPath();
      c.moveTo(-w, h * 1.4); c.lineTo(-w, h * 0.30);
      c.lineTo(0, -h * 0.34); c.lineTo(w, h * 0.30); c.lineTo(w, h * 1.4);
      c.closePath(); c.fill();
    } },

    { id: 'quarterly', name: 'quarterly', paint: function (c, w, h) {
      c.beginPath();
      c.rect(-w, -h, w, h); c.rect(0, 0, w, h * 1.4);
      c.fill();
    } },

    { id: 'persaltire', name: 'per saltire', paint: function (c, w, h) {
      c.beginPath();
      c.moveTo(-w, -h); c.lineTo(0, 0); c.lineTo(w, -h); c.closePath();
      c.moveTo(-w, h * 1.4); c.lineTo(0, 0); c.lineTo(w, h * 1.4); c.closePath();
      c.fill();
    } },

    { id: 'barry', name: 'barry', paint: function (c, w, h) {
      c.beginPath();
      for (var i = 0; i < 3; i++) {
        c.rect(-w, -h + (i * 2 + 1) * (h * 2.2 / 6), w * 2, h * 2.2 / 6);
      }
      c.fill();
    } },

    { id: 'chief', name: 'a chief', paint: function (c, w, h) {
      c.beginPath(); c.rect(-w, -h, w * 2, h * 0.62); c.fill();
    } },

    { id: 'bordure', name: 'a bordure', paint: function (c, w, h) {
      /* Painted as a thick stroke that the shield clip trims to shape —
         so the border always follows the shield's curve exactly, rather
         than being a second guessed outline. */
      c.save();
      c.lineWidth = w * 0.30;
      c.strokeStyle = c.fillStyle;
      shieldPath(c, w, h);
      c.stroke();
      c.restore();
    } }
  ];

  /* --------------------------------------------------------------- names

     Cheap by comparison with the art, and it does real work: an unnamed
     shield is decoration, a named one is an opponent. */

  var NAME_A = ['Aur', 'Bran', 'Cav', 'Dun', 'Elm', 'Far', 'Gars', 'Hald', 'Ives',
                'Kerr', 'Loth', 'Mar', 'Ner', 'Orm', 'Pell', 'Quen', 'Rav', 'Sarn',
                'Thorn', 'Ulf', 'Vane', 'Wex', 'Yar', 'Zel'];
  var NAME_B = ['mont', 'wold', 'garde', 'holm', 'march', 'fell', 'stead', 'water',
                'crag', 'vale', 'gate', 'ford', 'burn', 'reach', 'moor', 'keep'];
  var TITLES = ['Lord', 'Baron', 'the Marshal', 'Count', 'the Elder', 'Ser',
                'the Younger', 'Earl'];

  /* -------------------------------------------------------------- shield

     One shield outline, used by every drawing path so the bordure, the
     clip and the outline can never disagree about the shape. */
  function shieldPath(c, w, h) {
    c.beginPath();
    c.moveTo(-w, -h);
    c.lineTo(w, -h);
    c.lineTo(w, h * 0.30);
    c.quadraticCurveTo(w * 0.92, h * 1.02, 0, h * 1.30);
    c.quadraticCurveTo(-w * 0.92, h * 1.02, -w, h * 0.30);
    c.closePath();
  }

  /* ----------------------------------------------------------------- rng */
  function rnd(seed, salt) {
    var h = (seed * 374761393 + salt * 668265263) ^ 0x5bf03635;
    h = (h ^ (h >>> 13)) * 1274126177;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }
  function pick(arr, seed, salt) {
    return arr[Math.floor(rnd(seed, salt) * arr.length) % arr.length];
  }

  /* ---------------------------------------------------------------- arms

     Pure. Same seed, same arms, forever — which is what lets the HUD, the
     pikes and the trophy wall all draw one lord's shield with nothing
     passed between them. */
  function arms(seed) {
    var charge = pick(CHARGES, seed, 11);
    var division = pick(DIVISIONS, seed, 23);

    /* THE RULE OF TINCTURE. Pick the field first, then force the charge
       into the opposite class. Metal-on-metal and colour-on-colour are
       the two combinations that look wrong to anyone who has seen real
       arms, and they are also the two that go illegible when the shield
       is 22 pixels wide on a pennon. */
    var fieldIsMetal = rnd(seed, 31) < 0.42;
    var field  = fieldIsMetal ? pick(METALS, seed, 41) : pick(COLOURS, seed, 41);
    var charged = fieldIsMetal ? pick(COLOURS, seed, 53) : pick(METALS, seed, 53);

    /* The second tincture of a divided field must contrast with the first,
       or the division vanishes — so it is the opposite class, same rule
       applied again.

       ⚠️ BUT THAT MAKES IT THE SAME CLASS AS THE CHARGE, and when the two
       land on the SAME tincture the blazon comes out saying, in the real
       grammar, something no herald would ever write: measured on a live
       capture, "per bend sinister argent and gules, a sun in splendour
       gules" — a gules charge on a field that is half gules. The halo
       keeps it legible, but the game PRINTS its own blazons on screen, so
       the text was advertising the error to anyone who can read it.
       Nudge the second field off the charge's tincture. */
    var pool = fieldIsMetal ? COLOURS : METALS;
    var field2 = pick(pool, seed, 67);
    if (field2 === charged && pool.length > 1) {
      field2 = pool[(pool.indexOf(field2) + 1 + Math.floor(rnd(seed, 89) * (pool.length - 1))) % pool.length];
    }

    var name = pick(NAME_A, seed, 71) + pick(NAME_B, seed, 79);
    var title = pick(TITLES, seed, 83);

    return {
      seed: seed,
      charge: charge,
      division: division,
      field: field,
      field2: field2,
      charged: charged,
      name: name,
      title: title,
      house: 'House ' + name,
      /* The blazon, in something close to the real grammar. Shown in the
         HUD because it is genuinely the most evocative text in the game
         and it costs nothing — the data is already here. */
      blazon: (division.id === 'plain'
                 ? field.name
                 : (division.id === 'bordure' || division.id === 'chief'
                      ? field.name + ', ' + division.name + ' ' + field2.name
                      : division.name + ' ' + field.name + ' and ' + field2.name))
              + ', ' + charge.name + ' ' + charged.name
    };
  }

  /* ------------------------------------------------------------ drawing

     `drawArms` paints a complete shield centred on the current origin,
     `w` half-wide. Everything is clipped to the shield outline, so a
     division or a bordure can be drawn as a simple rectangle or stroke
     and still come out shield-shaped. */
  function drawArms(c, a, w, opts) {
    opts = opts || {};
    var h = w * 1.06;

    c.save();

    if (opts.shadow) {
      c.save();
      c.shadowColor = 'rgba(48,34,16,.34)';
      c.shadowBlur = w * 0.30; c.shadowOffsetY = w * 0.12;
      c.fillStyle = 'rgba(0,0,0,.5)';
      shieldPath(c, w, h); c.fill();
      c.restore();
    }

    c.save();
    shieldPath(c, w, h);
    c.clip();

    /* Field. */
    c.fillStyle = a.field.hex;
    c.fillRect(-w * 1.2, -h * 1.2, w * 2.4, h * 3);

    /* Division. */
    if (a.division.paint) {
      c.fillStyle = a.field2.hex;
      c.strokeStyle = a.field2.hex;
      a.division.paint(c, w, h);
    }

    /* A little parchment tooth over the flat colour, so the shield sits
       in the same world as the paper rather than on top of it. */
    c.globalAlpha = 0.10;
    for (var i = 0; i < 26; i++) {
      var gx = (rnd(a.seed, 300 + i) * 2 - 1) * w;
      var gy = (rnd(a.seed, 400 + i) * 2.3 - 1) * h;
      c.fillStyle = i % 2 ? '#2a2018' : '#fff8e0';
      c.fillRect(gx, gy, w * 0.16, h * 0.10);
    }
    c.globalAlpha = 1;

    /* Charge, inset so it never touches the edge — heraldry always
       leaves the charge room to breathe, and at 22px it is the
       difference between a device and a smudge. */
    c.save();
    c.translate(0, h * 0.10);

    /* ⚠️ THE RULE OF TINCTURE ONLY PROTECTS THE CHARGE AGAINST THE FIRST
       FIELD TINCTURE. On a DIVIDED field the charge also crosses `field2`,
       and `field2` is deliberately the opposite class to `field` — so it
       is the SAME class as the charge, and the charge goes colour-on-colour
       over half its area. Measured by looking at a 36-shield sample sheet:
       House Fargate's martlet vanished into its purple half and House
       Ormford's flame into its sable half. Every mechanical check passed
       them; only the eye caught it.

       The fix is what painted heraldry has always done — delineate the
       charge. A halo in the OPPOSITE class to the charge separates it from
       any background it can possibly land on, and because it is a shadow
       rather than a second traced path it works for every charge here
       regardless of how many sub-shapes it is built from. */
    var haloIsDark = (a.charged === METALS[0] || a.charged === METALS[1]);
    c.shadowColor = haloIsDark ? 'rgba(24,16,10,.95)' : 'rgba(246,240,216,.95)';
    c.shadowBlur = Math.max(2, w * 0.075);
    c.shadowOffsetX = 0; c.shadowOffsetY = 0;

    c.fillStyle = a.charged.hex;
    c.strokeStyle = a.charged.hex;
    /* The tincture a charge may cut its OWN interior detail in. Heraldry
       shows a folded wing or a portcullis grid by letting the field show
       through, never by punching to transparent — which inside this
       shield clip would be a hole through to the parchment. */
    c.__cut = a.field.hex;
    a.charge.draw(c, w * 0.56);
    c.__cut = null;
    c.restore();

    /* Inner shade along the top-left, giving the flat field a lit edge. */
    var g = c.createLinearGradient(-w, -h, w * 0.6, h);
    g.addColorStop(0, 'rgba(255,246,214,.20)');
    g.addColorStop(0.55, 'rgba(255,246,214,0)');
    g.addColorStop(1, 'rgba(28,18,10,.22)');
    c.fillStyle = g;
    c.fillRect(-w * 1.2, -h * 1.2, w * 2.4, h * 3);

    c.restore();

    /* Outline last, on top of everything, unclipped so it stays crisp. */
    c.strokeStyle = 'rgba(30,22,14,.85)';
    c.lineWidth = Math.max(1, w * 0.075);
    shieldPath(c, w, h);
    c.stroke();

    c.restore();
  }

  /* A pennon — the same arms on a flying swallow-tail, for the banner and
     for the pike companies. Drawn from the same record, so a lord's
     pennon and his shield cannot disagree. */
  function drawPennon(c, a, len, flutter) {
    var hgt = len * 0.52;
    var f = Math.sin(flutter * 3.1) * (len * 0.10);

    c.save();
    c.beginPath();
    c.moveTo(0, -hgt / 2);
    c.quadraticCurveTo(len * 0.52, -hgt / 2 - f, len, -hgt / 2 + f * 0.6);
    c.lineTo(len * 0.72, 0);
    c.lineTo(len, hgt / 2 + f * 0.6);
    c.quadraticCurveTo(len * 0.52, hgt / 2 - f, 0, hgt / 2);
    c.closePath();
    c.save();
    c.clip();

    c.fillStyle = a.field.hex;
    c.fillRect(0, -hgt, len * 1.1, hgt * 2);
    if (a.division.paint) {
      c.fillStyle = a.field2.hex;
      c.strokeStyle = a.field2.hex;
      c.save();
      c.translate(len * 0.42, 0);
      a.division.paint(c, len * 0.42, hgt * 0.5);
      c.restore();
    }
    c.save();
    c.translate(len * 0.36, 0);
    c.fillStyle = a.charged.hex;
    c.strokeStyle = a.charged.hex;
    a.charge.draw(c, hgt * 0.34);
    c.restore();
    c.restore();

    c.strokeStyle = 'rgba(30,22,14,.55)';
    c.lineWidth = Math.max(0.8, len * 0.022);
    c.stroke();
    c.restore();
  }

  /* ------------------------------------------------------------ campaign

     Who fights whom, for one whole run. This lives HERE rather than in
     game.js because the cover art needs the same answer: the cover shows
     the player's arms and a defending house, and if the two files derived
     them separately they would drift, and the most-viewed image on the
     listing would advertise a game that does not exist. One
     implementation, two consumers.

     Constraint: no two houses in a campaign share a charge, and none
     shares the player's. Twelve arms are shown TOGETHER on the end card,
     so a repeat is visible there in a way it never is on the board. */
  function campaign(seed, n) {
    var mine = arms(seed);
    var taken = {};
    taken[mine.charge.id] = true;
    var out = [];
    for (var i = 0; i < n; i++) {
      var chosen = null;
      for (var bump = 0; bump < 96 && !chosen; bump++) {
        var cand = arms(seed + 1 + i * 977 + bump * 31);
        if (!taken[cand.charge.id]) chosen = cand;
      }
      /* 59 charges against a dozen or so bearers, so this cannot
         realistically fail — but take a repeat over a blank shield. */
      if (!chosen) chosen = arms(seed + 1 + i * 977);
      taken[chosen.charge.id] = true;
      out.push(chosen);
    }
    return { mine: mine, lords: out };
  }

  root.Heraldry = {
    arms: arms,
    campaign: campaign,
    drawArms: drawArms,
    drawPennon: drawPennon,
    shieldPath: shieldPath,
    CHARGES: CHARGES,
    DIVISIONS: DIVISIONS,
    COLOURS: COLOURS,
    METALS: METALS,
    /* The catalogue size, computed rather than claimed — a number in a
       Readme that nothing produces is exactly what §2 forbids. */
    combinations: function () {
      return CHARGES.length * DIVISIONS.length * (COLOURS.length * METALS.length +
                                                  METALS.length * COLOURS.length);
    }
  };

})(typeof window !== 'undefined' ? window : globalThis);

if (typeof module !== 'undefined' && module.exports) {
  module.exports = (typeof window !== 'undefined' ? window : globalThis).Heraldry;
}
