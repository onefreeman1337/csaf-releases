/* =====================================================================
   rules.js — BANNERET. The whole game, as one pure function.

   A banneret is a knight who leads men into battle under his own banner.
   That is the entire control scheme: you never move a knight. You plant
   the banner, and every knight you have charges it at once.

   ONE SENTENCE, THREE CONSEQUENCES
   --------------------------------
   "Plant the banner; every knight charges it, and a charge that never
    starts is a death."

     1. DIRECTION IS LOCKED AT THE MOMENT THE BANNER LANDS. A knight picks
        the axis it is furthest from the banner on, and commits. It does not
        steer, it does not stop early, it does not go around. A charge is a
        decision you make once — which is what the word means.

     2. MOMENTUM IS THE WEAPON. A knight that is already moving tramples a
        pike and rides straight through it. A knight standing still next to
        one is simply killed: a pike beats a stationary horse, which is the
        historical fact the whole formation exists to exploit.

     3. THE BANNER IS ALSO THE DANGER. Knights stop when they reach it and
        when they run into each other, and a knight that moved ZERO tiles
        this charge dies to any pike beside it. So the thing that directs
        your army is the same thing that bunches it up and gets it killed.

   Everything visible on screen is this file's output. `resolve()` is pure —
   no canvas, no audio, no clock, no randomness — which is why the solver in
   Internal_Ops/generate_levels.js can search it exhaustively, why the tests
   can assert on it, and why every shipped level is PROVEN solvable rather
   than hoped to be.
   ===================================================================== */
'use strict';

(function (root) {

  /* A tile is identified by "x,y" wherever a Set or key is needed. Grids in
     this game are never bigger than 8x8, so clarity beats bit-packing. */
  function key(x, y) { return x + ',' + y; }

  /* --------------------------------------------------------------- geometry */

  var ORTHO = [[1, 0], [-1, 0], [0, 1], [0, -1]];

  /* The direction a knight commits to. It charges along whichever axis it is
     FURTHEST from the banner on; a tie goes to horizontal, so the rule is
     total and the preview can never disagree with what happens. */
  function chargeDir(from, banner) {
    var dx = banner.x - from.x;
    var dy = banner.y - from.y;
    if (dx === 0 && dy === 0) return null;          // standing on the banner
    if (Math.abs(dx) >= Math.abs(dy)) return { dx: dx > 0 ? 1 : -1, dy: 0 };
    return { dx: 0, dy: dy > 0 ? 1 : -1 };
  }

  function inBounds(level, x, y) {
    return x >= 0 && y >= 0 && x < level.w && y < level.h;
  }

  function isWall(level, x, y) {
    return level.wallSet.has(key(x, y));
  }

  /* Levels arrive as plain arrays (they are generated offline and shipped as
     data). This builds the lookup the resolver wants without mutating input. */
  function prepare(level) {
    if (level.wallSet) return level;
    var l = {
      w: level.w, h: level.h,
      walls: level.walls || [],
      knights: level.knights || [],
      pikes: level.pikes || [],
      budget: level.budget,
      minMoves: level.minMoves,
      wallSet: new Set()
    };
    for (var i = 0; i < l.walls.length; i++) l.wallSet.add(key(l.walls[i][0], l.walls[i][1]));
    return l;
  }

  function startState(level) {
    return {
      knights: level.knights.map(function (p) { return { x: p[0], y: p[1] }; }),
      pikes:   level.pikes.map(function (p) { return { x: p[0], y: p[1] }; }),
      moves: 0
    };
  }

  /* Order-insensitive identity, for the solver's visited set. Knights are
     interchangeable — two states that differ only in which knight is which
     are the same position, and treating them as distinct is what makes a
     search of this shape explode. */
  function stateKey(st) {
    var k = st.knights.map(function (u) { return key(u.x, u.y); }).sort().join(' ');
    var p = st.pikes.map(function (u) { return key(u.x, u.y); }).sort().join(' ');
    return k + '|' + p;
  }

  /* Legal banner placements: anywhere that is not a wall. Planting on top of
     a knight is legal and is usually a mistake — that knight stalls. */
  function legalMoves(level) {
    var out = [];
    for (var y = 0; y < level.h; y++) {
      for (var x = 0; x < level.w; x++) {
        if (!isWall(level, x, y)) out.push({ x: x, y: y });
      }
    }
    return out;
  }

  function adjacentToPike(st, x, y) {
    for (var i = 0; i < ORTHO.length; i++) {
      var ax = x + ORTHO[i][0], ay = y + ORTHO[i][1];
      for (var j = 0; j < st.pikes.length; j++) {
        if (st.pikes[j].x === ax && st.pikes[j].y === ay) return true;
      }
    }
    return false;
  }

  /* ------------------------------------------------------------- the charge

     Resolves one banner plant, completely. Returns a NEW state plus a full
     per-knight record of what happened, which is what the renderer animates
     and what the hover preview shows — the preview is not a separate
     prediction that could drift out of sync with the rules, it is this exact
     function run against the tile under the cursor. */
  function resolve(rawLevel, st, banner) {
    var level = prepare(rawLevel);

    /* Each rider carries its own committed direction and the distance it has
       covered, because distance IS whether it is lethal or vulnerable. */
    var riders = st.knights.map(function (u) {
      var d = chargeDir(u, banner);
      return {
        x: u.x, y: u.y, sx: u.x, sy: u.y,
        dir: d, dist: 0,
        moving: d !== null,
        dead: false,
        path: [{ x: u.x, y: u.y }],
        trampled: []
      };
    });

    var pikes = st.pikes.map(function (u) { return { x: u.x, y: u.y }; });
    var trampledAll = [];

    function pikeAt(x, y) {
      for (var i = 0; i < pikes.length; i++) if (pikes[i].x === x && pikes[i].y === y) return i;
      return -1;
    }
    function riderAt(x, y, skip) {
      for (var i = 0; i < riders.length; i++) {
        if (i !== skip && !riders[i].dead && riders[i].x === x && riders[i].y === y) return i;
      }
      return -1;
    }

    /* Everyone charges at the same time. Within a step we keep sweeping until
       nothing else can move, so a column of riders advances as a column
       instead of the front one being "blocked" by a rider that is itself
       about to vacate the tile. */
    var maxSteps = level.w + level.h + 2;
    for (var step = 0; step < maxSteps; step++) {
      var anyMoving = riders.some(function (r) { return r.moving && !r.dead; });
      if (!anyMoving) break;

      var movedThisStep = new Set();
      var progress = true;

      while (progress) {
        progress = false;

        for (var i = 0; i < riders.length; i++) {
          var r = riders[i];
          if (r.dead || !r.moving || movedThisStep.has(i)) continue;

          /* Reaching the banner ends the charge — it is what they were
             riding at. */
          if (r.x === banner.x && r.y === banner.y) { r.moving = false; continue; }

          var nx = r.x + r.dir.dx, ny = r.y + r.dir.dy;

          if (!inBounds(level, nx, ny) || isWall(level, nx, ny)) { r.moving = false; continue; }

          var pi = pikeAt(nx, ny);
          if (pi >= 0) {
            if (r.dist >= 1) {
              /* Trampled. The rider rides straight through and keeps going —
                 momentum does not stop for a body. */
              trampledAll.push({ x: nx, y: ny, by: i, atStep: step });
              r.trampled.push({ x: nx, y: ny });
              pikes.splice(pi, 1);
            } else {
              /* From a standing start the pike wins. The rider does not move,
                 which leaves it with dist 0 and adjacent to a pike — and the
                 end-of-charge rule below is what actually kills it. One rule,
                 not two. */
              r.moving = false;
              continue;
            }
          }

          if (riderAt(nx, ny, i) >= 0) continue;  /* may clear on a later sweep */

          r.x = nx; r.y = ny; r.dist++;
          r.path.push({ x: nx, y: ny });
          movedThisStep.add(i);
          progress = true;
        }
      }

      /* Anything still "moving" that could not move this step is jammed
         behind another rider that also could not move. That is a stop. */
      for (var j = 0; j < riders.length; j++) {
        if (riders[j].moving && !riders[j].dead && !movedThisStep.has(j)) riders[j].moving = false;
      }
    }

    /* ---- the rule the game is named for ----------------------------------
       A charge that never started is a death. Any rider that covered zero
       tiles and is standing beside a surviving pike is killed. Riders that
       actually charged are safe wherever they stopped. */
    var after = { knights: [], pikes: pikes, moves: st.moves + 1 };
    for (var m = 0; m < riders.length; m++) {
      var rr = riders[m];
      if (rr.dist === 0 && adjacentToPike({ pikes: pikes }, rr.x, rr.y)) {
        rr.dead = true;
        rr.stalled = true;
      } else {
        after.knights.push({ x: rr.x, y: rr.y });
      }
    }

    return {
      state: after,
      riders: riders,
      trampled: trampledAll,
      banner: { x: banner.x, y: banner.y },
      won: pikes.length === 0,
      lost: after.knights.length === 0 ||
            (pikes.length > 0 && after.moves >= level.budget)
    };
  }

  var API = {
    key: key,
    ORTHO: ORTHO,
    chargeDir: chargeDir,
    prepare: prepare,
    startState: startState,
    stateKey: stateKey,
    legalMoves: legalMoves,
    resolve: resolve
  };

  root.Rules = API;

})(typeof window !== 'undefined' ? window : globalThis);

/* Node's test runner and the level generator load this file directly; the
   browser ignores this block. */
if (typeof module !== 'undefined' && module.exports) {
  module.exports = (typeof window !== 'undefined' ? window : globalThis).Rules;
}
