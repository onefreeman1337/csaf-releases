# BANNERET

**You never move a knight. You plant a banner, and they charge it.**

A banneret is a knight who leads men into battle under his own banner. That is the
whole control scheme. You choose one tile per turn, the banner lands there, and
every knight you have rides at it simultaneously — in a straight line, without
steering, without stopping early, and without going around anything.

---

## The whole rule

> **Momentum kills. A charge that never started is a death.**

Everything else in the game follows from it.

### What happens the moment the banner lands

- **Every knight charges at once.** Nobody waits, nobody takes a turn.
- Each knight rides along **the axis it is furthest from the banner on**. If it is
  four tiles across and two tiles down, it charges across. A tie goes horizontal.
- **Direction is locked when the banner lands.** No steering, no turning, no
  stopping early. A charge is a decision you make once.
- A knight **stops** at a wall, at the edge of the field, on the banner tile
  itself, or behind another knight that has already stopped.

### Momentum is the weapon

| | What happens |
| --- | --- |
| A knight that has covered **at least one tile** | **Tramples** any pike in its path and rides straight through it — several in one charge, if they are in line |
| A knight that covered **zero tiles** and ends beside a pike still standing | **Killed.** A pike beats a stationary horse |

So **you cannot break a pike you are standing next to.** Charging straight into an
adjacent pike is a first step you never take, which leaves you standing still next
to it, which kills you. Ride away first and come back at it with speed.

The same rule catches a knight that is simply boxed in. If a wall, the board edge
or another knight blocks its first step, it has covered zero tiles — and if a pike
is beside it, that is a death.

**Pikes never move.** That is the point of pikes.

### The banner is also the danger

Knights stop when they reach the banner, and they stop when they run into each
other. So the thing that directs your army is the same thing that bunches it up and
strands it. Planting the banner **on top of** a knight is legal and stalls that
knight completely — usually fatally.

### Winning and losing a field

- **Take the field** by trampling every pike on it.
- **You lose** if you run out of charges, or if you lose every knight.

Losing costs nothing but the attempt: the field re-forms by itself a moment later
and you start it again. There is no menu, no confirmation and no penalty. Clearing
a field loads the next one the same way.

---

## The preview is the game, not a guess

Hover a tile — or move the keyboard cursor onto it — and the board draws exactly
what planting there does:

- a **dashed line** along the path each knight will ride, with an arrow showing the
  committed direction and a pip marking which knight it belongs to,
- a **faint knight** on the tile where that rider will come to a stop,
- a **gold ring** around every pike that plant will break,
- a **pulsing crimson ring and cross** over any knight that plant would strand and
  kill.

This is not a separate prediction that could drift out of step with the rules. It
is the same function that resolves the move, run against the tile under your
cursor. What you are shown is what you get, by construction.

---

## Controls

| Action | Input |
| --- | --- |
| Plant the banner | **Click** a tile, or **tap** it |
| Move the cursor | **Arrow keys** |
| Plant at the cursor | **Enter** or **Space** |
| Re-form the charge (restart the field) | **R** |
| Mute | **M** |

On the end card, **R** starts the twelve fields over.

Touch works, but the preview does not: a tap plants immediately. A mouse or the
arrow keys is how you see what a plant will do before committing to it.

---

## What the screen tells you

| On screen | Meaning |
| --- | --- |
| **FIELD** | Which of the twelve you are on, in roman numerals |
| **CHARGES** | One pennant per banner you may still plant here. They fade as you spend them; run out with pikes still standing and the field is lost |
| **KNIGHTS** | Your riders. A lost one greys out |
| **PIKES** | How many are still standing. Zero is the win |
| **MINIMUM** | The shortest solution that exists for this field |

**MINIMUM is not a target someone estimated.** It is the length of the shortest
solution the field has, established by exhaustive search before the game shipped.
Clear a field in that many charges and the end card records it as a perfect charge,
one pennant per field.

The first two fields carry a line of red text on the right. That is the tutorial,
and it is the only hand-holding in the game.

---

## What this is, and what it isn't

**It is** a complete, self-contained tactics puzzle: twelve fields on a seven by
seven board, from one knight against one pike to three knights against six, and
then an end card telling you how many you took at the minimum. It is short. It is
meant to be.

**It is not** a campaign, a roguelike, a score chase or a story. There is no level
select, no unlocking, no upgrades, no randomness anywhere — the fields play out
identically every time, which is what makes them puzzles rather than attempts.
Progress is not saved; the twelve run in order from the title screen.

**Every field was proved solvable before it shipped**, by breadth-first search over
every reachable position using the exact rules the game runs. Nothing here is
unwinnable, and no field is padded with charges it does not need.

The difficulty was measured the same way rather than guessed at:

| Player | Fields cleared |
| --- | --- |
| Perfect play | **12 of 12** |
| A player who always takes the best kill available right now, one move deep | **6 of 12**, first failing on field V |
| Random planting | **1 of 12** |

Around the fifth field, looking one move ahead stops being enough. That gap is the
game.

---

## What it runs on

Anything with a browser. No install, no account, no plugin, no download. No network
requests after load, and no third-party code of any kind — no engine, no framework,
no library, no font file, no image file and no audio file ships with it. The
parchment, the board, the knights, the pikes and the banners are drawn to a 2D
canvas every frame, and every sound is synthesised on the fly by the Web Audio API.
The typography is whatever serif your own system provides.

If you have no audio, click once: browsers refuse to make sound until you do, which
is why the title screen asks for a click.

---

## Disclosure

This game was written by an AI agent, and is tagged as AI-generated on its itch.io
page. The rules engine, the renderer, the sound, the level generator and this file
are all AI-authored. There are no audio files and no image files, so nothing was
produced by an image or music model — the sound is oscillators and filtered noise,
made by code.

Made by **CSAF** — Corey Gallant and Stephanie Thomason.
